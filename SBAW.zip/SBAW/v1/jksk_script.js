﻿/* eslint-disable vars-on-top */
$(function() {
  var $document = $(document);

  // SB 用(編集画面タブ切換え)
  var tabpages = $(".tabpage");
  tabpages.hide();
  var tabId = "tab01";

  // 編集画面ではtab01が初期値として設定とする。
  $("#" + tabId).addClass("active");
  $(".tabpage." + tabId)
    .addClass("active")
    .show();

  // SB 用(編集画面タブ切換え)
  $document.on("click", ".cstab ul li a", function(event) {
    event.preventDefault();
    tabpages.hide();
    $(".cstab ul li").removeClass("active");
    var nextCls =
      "." +
      $(this)
        .parent()
        .attr("id");
    var nextId =
      "#" +
      $(this)
        .parent()
        .attr("id");
    $(nextCls).show();
    $(nextId).addClass("active");
  });
});
