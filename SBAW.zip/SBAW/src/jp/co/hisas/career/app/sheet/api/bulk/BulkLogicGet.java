package jp.co.hisas.career.app.sheet.api.bulk;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jp.co.hisas.career.app.sheet.api.mold.Fill;
import jp.co.hisas.career.app.sheet.deliver.bulk.BulkGetOrder;
import jp.co.hisas.career.app.sheet.deliver.bulk.export.BulkExportGetOrder;
import jp.co.hisas.career.app.sheet.dto.CstFillInvalidDto;
import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.app.sheet.garage.BulkGetGarage;
import jp.co.hisas.career.app.sheet.garage.SheetGarage;
import jp.co.hisas.career.app.sheet.util.CareerSheetLabel;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.log.Log;

public class BulkLogicGet {
	
	private String daoLoginNo;
	
	public BulkLogicGet(String daoLoginNo) {
		this.daoLoginNo = daoLoginNo;
	}
	
	protected BulkEvRslt main( BulkGetOrder o ) {
		BulkEvRslt r = new BulkEvRslt();
		BulkGetGarage ggBG = new BulkGetGarage( daoLoginNo );
		
		ggBG.refreshBulkSheetExclusiveKey( o.sessionId, o.wkIdxFrom, o.wkIdxTo );
		
		List<Map<String, String>> bulkSheetList = ggBG.fetchBulkSheetList( o.sessionId, o.operatorGuid, o.wkIdxFrom, o.wkIdxTo );
		List<Map<String, String>> colDefMap = ggBG.getBulkColumns( o.instCd, "WEB" );
		Map<String, List<CstFillInvalidDto>> fillInvalidList = ggBG.getFillInvalidList( o.sessionId );
		Map<String, BulkSheet> bulkSheetSet = makeBulkSheetSet( o.operatorGuid, bulkSheetList, colDefMap, fillInvalidList, o.langNo );
		r.bulkSheetSet = bulkSheetSet;
		
		return r;
	}
	
	public BulkEvRslt makeSheetListForCsv( BulkExportGetOrder o ) {
		BulkEvRslt r = new BulkEvRslt();
		BulkGetGarage ggBG = new BulkGetGarage( daoLoginNo );
		
		List<Map<String, String>> bulkSheetList = ggBG.fetchBulkSheetList( o.sessionId, o.operatorGuid, 0, 99999 );
		List<Map<String, String>> colDefMap = ggBG.getBulkColumns( o.instCd, o.scene );
		Map<String, BulkSheet> bulkSheetSet = makeBulkSheetSet( o.operatorGuid, bulkSheetList, colDefMap, null, o.langNo );
		
		r.colDefMap = colDefMap;
		r.bulkSheetSet = bulkSheetSet;
		
		return r;
	}
	
	private Map<String, BulkSheet> makeBulkSheetSet( String operatorGuid, List<Map<String, String>> bulkSheetList, List<Map<String, String>> colDefMap, Map<String, List<CstFillInvalidDto>> fillInvalidList, int langNo ) {
		Map<String, BulkSheet> bulkSheetSet = new HashMap<String, BulkSheet>();
		for (Map<String, String> sheet : bulkSheetList) {
			String sheetId = sheet.get( "SHEET_ID" );
			VCsInfoAttrDto ia = getSheetInfoAttr( sheetId );
			Map<String, Fill> maskedFills = getMaskedFills( ia, sheet.get( "ACTOR_CD" ) );
			BulkSheet bs = new BulkSheet();
			bs.sheetId = sheetId;
			bs.ownPersonName = ia.getOwnPersonName();
			Map<String, BulkSheetColumn> cols = new HashMap<String, BulkSheetColumn>();
			for (Map<String, String> e : colDefMap) {
				String columnName = "col" + e.get( "SEQ_NO" );
				String columnId = e.get( "COLUMN_ID" );
				cols.put( columnName, makeColumn( columnId, ia, maskedFills ) );
			}
			bs.cols = cols;
			bs.statusCd = ia.getStatusCd();
			bs.statusNm = ia.getStatusNm();
			bs.isHold = SU.equals( ia.getHoldGuid(), operatorGuid );
			bs.flowPtn = ia.getFlowPtn();
			bs.bulkActorCd = sheet.get( "ACTOR_CD" );
			bs.exclusiveKey = sheet.get( "EXC_KEY" );
			bs.wkIdx = sheet.get( "WK_IDX" );
			if (fillInvalidList != null) {
				List<CstFillInvalidDto> invalidList = fillInvalidList.get( sheetId );
				bs.invalidMsgList = makeInvalidMsgList( invalidList, ia.getLabelSetCd(), langNo );
			}
			bulkSheetSet.put( sheetId, bs );
		}
		return bulkSheetSet;
	}
	
	private Set<String> makeInvalidMsgList( List<CstFillInvalidDto> invalidList, String labelSetCd, int langNo ) {
		Set<String> set = new HashSet<String>();
		if (invalidList == null) {
			return set;
		}
		for (CstFillInvalidDto dto : invalidList) {
			String msg = CareerSheetLabel.getLabel( labelSetCd, dto.getMsgId(), langNo );
			set.add( msg );
		}
		return set;
	}
	
	private BulkSheetColumn makeColumn( String columnId, VCsInfoAttrDto ia, Map<String, Fill> maskedFills ) {
		BulkSheetColumn col = new BulkSheetColumn();
		String[] colIdArr = columnId.split( "\\." );
		String kind = colIdArr[0];
		if (SU.equals( kind, "Info" )) {
			col.text = getInfoAttrFieldValue( ia, colIdArr[1] );
		}
		else if (SU.equals( kind, "Attr" )) {
			col.text = getInfoAttrFieldValue( ia, colIdArr[1] );
		}
		else if (SU.equals( kind, "Fill" )) {
			String fillId = colIdArr[1];
			Fill fill = maskedFills.get( fillId );
			col.fill = fill != null ? fill : new Fill( fillId, false );
		}
		return col;
	}
	
	private String getInfoAttrFieldValue( VCsInfoAttrDto ia, String field ) {
		String text = null;
		try {
			text = (String)ia.getClass().getMethod( "get" + field ).invoke( ia );
		} catch (Exception e) {
			Log.error( "", e );
			e.printStackTrace();
		}
		return text;
	}
	
	private VCsInfoAttrDto getSheetInfoAttr( String sheetId ) {
		SheetGarage ggSh = new SheetGarage( daoLoginNo );
		return ggSh.getSheetInfoAttr( sheetId );
	}
	
	private Map<String, Fill> getMaskedFills( VCsInfoAttrDto ia, String actorCd ) {
		SheetGarage ggSh = new SheetGarage( daoLoginNo );
		
		return ggSh.getMaskedFillsForBulk( ia, actorCd );
	}
	
}
