package jp.co.hisas.career.app.sheet.deliver.sheet;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CsmSheetOperationDto;
import jp.co.hisas.career.ejb.AbstractEventResult;

public class SheetEvRslt extends AbstractEventResult {
	
	public CsmSheetOperationDto operation;
	public List<String> fillIdList;
}
