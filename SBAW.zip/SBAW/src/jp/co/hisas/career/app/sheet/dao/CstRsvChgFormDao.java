/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.CstRsvChgFormDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CstRsvChgFormDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " SHEET_ID as sheetId,"
                     + " FORM_CD as formCd"
                     ;

    public CstRsvChgFormDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CstRsvChgFormDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public void insert(CstRsvChgFormDto dto) {

        final String sql = "INSERT INTO CST_RSV_CHG_FORM ("
                         + "SHEET_ID,"
                         + "FORM_CD"
                         + ")VALUES(?,? )"
                         ;
        Log.sql("[DaoMethod Call] CstRsvChgFormDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getSheetId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getFormCd());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void update(CstRsvChgFormDto dto) {

        final String sql = "UPDATE CST_RSV_CHG_FORM SET "
                         + "FORM_CD = ?"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CstRsvChgFormDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getFormCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getSheetId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void delete(String sheetId) {

        final String sql = "DELETE FROM CST_RSV_CHG_FORM"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CstRsvChgFormDao.delete");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally { 
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public CstRsvChgFormDto select(String sheetId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CST_RSV_CHG_FORM"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CstRsvChgFormDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            rs = pstmt.executeQuery();
            CstRsvChgFormDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CstRsvChgFormDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CstRsvChgFormDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CstRsvChgFormDto> lst = new ArrayList<CstRsvChgFormDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CstRsvChgFormDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CstRsvChgFormDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("[DaoMethod Call] CstRsvChgFormDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void executeDynamic(String sql) {

        Log.sql("[DaoMethod Call] CstRsvChgFormDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    private CstRsvChgFormDto transferRsToDto(ResultSet rs) throws SQLException {

        CstRsvChgFormDto dto = new CstRsvChgFormDto();
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setFormCd(DaoUtil.convertNullToString(rs.getString("formCd")));
        return dto;
    }

}

