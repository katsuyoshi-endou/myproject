/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class VCsmActiveOpeFormDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String party;
    private String operationSort;
    private String operationCd;
    private String operationNm;
    private String formGrpCd;
    private String formGrpNm;
    private String formCd;
    private String formNm;
    private String formSort;

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getOperationSort() {
        return operationSort;
    }

    public void setOperationSort(String operationSort) {
        this.operationSort = operationSort;
    }

    public String getOperationCd() {
        return operationCd;
    }

    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    public String getOperationNm() {
        return operationNm;
    }

    public void setOperationNm(String operationNm) {
        this.operationNm = operationNm;
    }

    public String getFormGrpCd() {
        return formGrpCd;
    }

    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    public String getFormGrpNm() {
        return formGrpNm;
    }

    public void setFormGrpNm(String formGrpNm) {
        this.formGrpNm = formGrpNm;
    }

    public String getFormCd() {
        return formCd;
    }

    public void setFormCd(String formCd) {
        this.formCd = formCd;
    }

    public String getFormNm() {
        return formNm;
    }

    public void setFormNm(String formNm) {
        this.formNm = formNm;
    }

    public String getFormSort() {
        return formSort;
    }

    public void setFormSort(String formSort) {
        this.formSort = formSort;
    }

}

