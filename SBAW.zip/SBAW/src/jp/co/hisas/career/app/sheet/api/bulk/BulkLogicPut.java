package jp.co.hisas.career.app.sheet.api.bulk;

import jp.co.hisas.career.app.sheet.deliver.bulk.BulkPutOrder;
import jp.co.hisas.career.app.sheet.garage.BulkPutGarage;

public class BulkLogicPut {
	
	private String daoLoginNo;
	
	public BulkLogicPut(String daoLoginNo) {
		this.daoLoginNo = daoLoginNo;
	}
	
	protected BulkEvRslt main( BulkPutOrder o ) {
		BulkEvRslt r = new BulkEvRslt();
		BulkPutGarage ggBP = new BulkPutGarage( daoLoginNo );
		
		/* Clear */
		ggBP.clearBulkPool( o.operatorGuid );
		
		/* Load All Sheets for this session */
		ggBP.refreshBulkPool( o );
		
		/* Reduce sheets by conditions */
		reduceBulkPool( o );
		
		/* Update ACTOR_CD with auto judge */
		ggBP.assignBulkPoolActor( o.sessionId, o.operatorGuid );
		
		/* Update all EXC_KEY for the option: "isTargetAll" */
		ggBP.updateBulkPoolExclusiveKey( o.sessionId );
		
		/* Update WK_IDX */
		ggBP.updateBulkPoolWkIdx( o.sessionId, o.operatorGuid );
		
		return r;
	}
	
	private void reduceBulkPool( BulkPutOrder o ) {
		BulkPutGarage ggBP = new BulkPutGarage( daoLoginNo );
		ggBP.reduceByHoldFilter( o );
		ggBP.reduceBySheetEmbeddedInfo( o );
	}
	
}
