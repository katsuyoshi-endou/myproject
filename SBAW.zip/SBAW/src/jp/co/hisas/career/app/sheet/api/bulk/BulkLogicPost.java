package jp.co.hisas.career.app.sheet.api.bulk;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.deliver.bulk.BulkPostOrder;
import jp.co.hisas.career.app.sheet.deliver.sheet.SheetUnit;
import jp.co.hisas.career.app.sheet.dto.CstBulkPoolDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.app.sheet.event.CsSheetEventArg;
import jp.co.hisas.career.app.sheet.event.CsSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.CsSheetEventResult;
import jp.co.hisas.career.app.sheet.garage.BulkGetGarage;
import jp.co.hisas.career.app.sheet.garage.BulkPutGarage;
import jp.co.hisas.career.app.sheet.garage.SheetGarage;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerSecurityException;
import jp.co.hisas.career.util.SU;

public class BulkLogicPost {
	
	private String daoLoginNo;
	
	public BulkLogicPost(String daoLoginNo) {
		this.daoLoginNo = daoLoginNo;
	}
	
	protected BulkEvRslt main( BulkPostOrder o ) throws CareerException {
		BulkEvRslt r = new BulkEvRslt();
		SheetUnit u = new SheetUnit( daoLoginNo );
		BulkPutGarage ggBP = new BulkPutGarage( daoLoginNo );
		boolean hasInvalid = false;
		boolean hasExclusiveError = false;
		
		List<CstSheetExclusiveDto> sheetList = extractSheetList( o );
		
		for (CstSheetExclusiveDto excDto : sheetList) {
			String sheetId = excDto.getSheetId();
			
			/* アクション権限チェック */
			checkActionIsAllowed( sheetId, o );
			
			/* 回答内容エラーチェック */
			boolean isValidSheet = true;
			if (SU.matches( o.actionCd, "FORWARD|SKIP" )) {
				isValidSheet = u.validateFills( sheetId, o.actorCd );
			}
			
			/* アクションの実行 */
			if (isValidSheet) {
				CsSheetEventArg arg = new CsSheetEventArg( daoLoginNo, o.operatorGuid );
				arg.sharp = o.actionCd;
				arg.sheetId = sheetId;
				arg.exclusiveKey = excDto;
				arg.actionCd = o.actionCd;
				CsSheetEventResult rslt = CsSheetEventHandler.exec( arg );
				if (rslt.getResultErrorMessage() != null) {
					hasExclusiveError = true;
				}
			}
			else {
				hasInvalid = true;
			}
		}
		
		ggBP.updateBulkPoolExclusiveKey( o.sessionId );
		
		/* 回答検証無効の有無 */
		r.hasInvalid = hasInvalid;
		r.hasExclusiveError = hasExclusiveError;
		
		return r;
	}
	
	private List<CstSheetExclusiveDto> extractSheetList( BulkPostOrder o ) throws CareerException {
		List<CstSheetExclusiveDto> list = new ArrayList<CstSheetExclusiveDto>();
		List<String> sheetWithExcList = null;
		
		if (o.isTargetAll) {
			BulkGetGarage ggBg = new BulkGetGarage( daoLoginNo );
			sheetWithExcList = ggBg.fetchBulkPoolByTargetAll( o.sessionId, o.actorCd, o.statusCd, o.flowPtn );
		}
		else {
			sheetWithExcList = o.sheetList;
		}
		
		for (String sheetWithExc : sheetWithExcList) {
			CstSheetExclusiveDto dto = getExclusiveKey( sheetWithExc );
			list.add( dto );
		}
		return list;
	}
	
	private void checkActionIsAllowed( String sheetId, BulkPostOrder o ) {
		BulkGetGarage ggBg = new BulkGetGarage( daoLoginNo );
		SheetGarage ggSh = new SheetGarage( daoLoginNo );
		CstBulkPoolDto bp = ggBg.getBulkPoolByPK( o.sessionId, sheetId );
		String msg = "Requested sheet action is not allowed.";
		if (bp == null) {
			throw new CareerSecurityException( msg );
		}
		if (!SU.equals( bp.getActorCd(), o.actorCd )) {
			throw new CareerSecurityException( msg );
		}
		boolean exists = ggSh.existsSheetAction( o.party, o.operationCd, o.flowPtn, o.statusCd, o.actorCd, o.actionCd );
		if (!exists) {
			throw new CareerSecurityException( msg );
		}
	}
	
	private CstSheetExclusiveDto getExclusiveKey( String sheetWithExclusiveKey ) throws CareerException {
		String[] arr = sheetWithExclusiveKey.split( "#" );
		if (arr.length != 2)
			throw new CareerException( "Illegal sheet string. Expected: <SHEET_ID#EXCLUSIVE_KEY>" );
		CstSheetExclusiveDto excDto = new CstSheetExclusiveDto();
		excDto.setSheetId( arr[0] );
		excDto.setExclusiveKey( SU.toInt( arr[1], 0 ) );
		return excDto;
	}
	
}
