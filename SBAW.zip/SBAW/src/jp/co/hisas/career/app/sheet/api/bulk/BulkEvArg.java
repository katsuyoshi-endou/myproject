package jp.co.hisas.career.app.sheet.api.bulk;

import jp.co.hisas.career.app.sheet.deliver.bulk.BulkGetOrder;
import jp.co.hisas.career.app.sheet.deliver.bulk.BulkPostOrder;
import jp.co.hisas.career.app.sheet.deliver.bulk.BulkPutOrder;
import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class BulkEvArg extends AbstractEventArg {
	
	public String sharp = null;
	public BulkGetOrder orderGET;
	public BulkPostOrder orderPOST;
	public BulkPutOrder orderPUT;
	
	public BulkEvArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: loginNo is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		String className = BulkEvArg.class.getName();
		if (SU.isBlank( sharp )) {
			throw new CareerException( className + "Invalid: sharp is null." );
		}
		// TODO: リクエストチェック機構
	}
	
}
