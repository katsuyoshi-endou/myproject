package jp.co.hisas.career.app.sheet.util;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.hisas.career.app.sheet.event.CsSheetEventHandler;

public final class CsFillMaskCache {
	
	private ConcurrentHashMap<String, Map<String, String>> cache = new ConcurrentHashMap<String, Map<String, String>>();
	
	/**
	 * Singleton パターン - Wikipedia https://ja.wikipedia.org/wiki/Singleton_パターン
	 */
	private CsFillMaskCache() {
	}
	
	private static class CsFillMaskCacheHolder {
		private static final CsFillMaskCache instance = new CsFillMaskCache();
	}
	
	private static CsFillMaskCache getInstance() {
		return CsFillMaskCacheHolder.instance;
	}
	
	public static Map<String, String> get( String fillSetCd, String maskCd, String statusCd, String actorCd ) {
		CsFillMaskCache instance = CsFillMaskCache.getInstance();
		return instance.getCacheData( fillSetCd, maskCd, statusCd, actorCd );
	}
	
	private Map<String, String> getCacheData( String fillSetCd, String maskCd, String statusCd, String actorCd ) {
		String key = String.format( "%s#%s#%s#%s", fillSetCd, maskCd, statusCd, actorCd );
		if (!cache.containsKey( key )) {
			addCache( key, fillSetCd, maskCd, statusCd, actorCd );
		}
		return cache.get( key );
	}
	
	private void addCache( String key, String fillSetCd, String maskCd, String statusCd, String actorCd ) {
		String daoLoginNo = "Cache";
		HashMap<String, String> fillMaskMap = CsSheetEventHandler.getFillMaskMap( daoLoginNo, fillSetCd, maskCd, statusCd, actorCd );
		cache.put( key, fillMaskMap );
	}
	
	public static void clearCache() {
		CsFillMaskCache instance = CsFillMaskCache.getInstance();
		instance.clearCacheData();
	}
	
	private void clearCacheData() {
		cache = new ConcurrentHashMap<String, Map<String, String>>();
	}
	
}
