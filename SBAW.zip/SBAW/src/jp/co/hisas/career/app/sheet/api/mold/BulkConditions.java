package jp.co.hisas.career.app.sheet.api.mold;

import java.io.Serializable;

public class BulkConditions implements Serializable {
	
	public String statusCd;
	public String formCtgCd;
	public String formCd;
	public String bind;
	public String companyCd;
	public String deptNm;
	public String stfNo;
	public String stfNm;
	public String stfKana;
	public String clsANm;
	public String clsBNm;
	public String clsCNm;
}
