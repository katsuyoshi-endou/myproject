package jp.co.hisas.career.app.sheet.deliver.bulk.context;

import jp.co.hisas.career.app.sheet.api.bulk.context.BulkContextEvRslt;
import jp.co.hisas.career.app.sheet.api.mold.BulkPageState;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Tray;

public class BulkContextPutDeliver {
	
	public static BulkContextEvRslt go( Tray tray, BulkContextPutOrder order ) throws CareerException {
		BulkPageState ps = order.pageState;
		tray.session.setAttribute( CsSessionKey.CS_BULK_PAGE_STATE, ps );
		return null;
	}
	
}
