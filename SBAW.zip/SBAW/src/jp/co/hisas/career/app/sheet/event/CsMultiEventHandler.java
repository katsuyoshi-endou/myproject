package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import jp.co.hisas.career.app.sheet.dao.CsmSheetFormDao;
import jp.co.hisas.career.app.sheet.dao.CsmSheetFormGrpDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetFillDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetSrchRsltDao;
import jp.co.hisas.career.app.sheet.dao.VCsInfoAttrDao;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFormDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFormGrpDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetFillDto;
import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.ValueTextSortDao;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;
import jp.co.hisas.career.util.log.Log;

public class CsMultiEventHandler extends AbstractEventHandler<CsMultiEventArg, CsMultiEventResult> {
	
	private String daoLoginNo;
	private String operatorGuid;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static CsMultiEventResult exec( CsMultiEventArg arg ) throws CareerException {
		CsMultiEventHandler handler = new CsMultiEventHandler();
		return handler.call( arg );
	}
	
	public CsMultiEventResult call( CsMultiEventArg arg ) throws CareerException {
		CsMultiEventResult result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CsMultiEventResult execute( CsMultiEventArg arg ) throws CareerException {
		
		arg.validateArg();
		// Application Login User GUID (for dao logging)
		this.daoLoginNo = arg.getLoginNo();
		// [CAREER_GUID].[OPERATOR_FLG] (Proxied) GUID or equals login GUID
		this.operatorGuid = arg.operatorGuid;
		
		CsMultiEventResult result = new CsMultiEventResult();
		
		if ("PREPARE".equals( arg.sharp )) {
			
			// 分類リストの取得
			List<ValueTextSortDto> divList = getDivList( arg );
			result.divList = divList;
			
			// 運用リストの取得
			List<ValueTextSortDto> opeList = getOpeList( arg );
			result.opeList = opeList;
			
			// [一括用] アクターコードリスト
			List<ValueTextSortDto> actorOptionList = getActorCdListWithCond( arg );
			result.setActorOptionList( actorOptionList );
			
			// [一括用] 紐付けシート内で優先すべきアクターを取得
			String actorCdTaskPrimary = getActorCdTaskPrimary( arg );
			result.setActorCdTaskPrimary( actorCdTaskPrimary );
			
		} else if ("SEARCH".equals( arg.sharp )) {
			
			// フローステータスリストの取得
			List<ValueTextSortDto> staList = new ArrayList<ValueTextSortDto>();
			if (!CsUtil.isBlank( arg.srchCondMap.get( "operationCd" ) )) {
				staList = getStatusList( arg );
			}
			result.staList = staList;
			
			// [検索] 取扱可能な範囲すべてをワークに登録
			loadAllSheetSrchRslt( arg );
			
			// [検索] ワークから検索条件に従ってデータを削る
			result.hitCnt = reduceSheetSrchRslt( arg );
			
			// [検索] ワークに残ったシートデータを取得
			List<VCsInfoAttrDto> sheetList = getMultiSheetList( arg );
			result.setSheetList( sheetList );
			
		} else if ("FILL_DATA".equals( arg.sharp )) {
			
			HashMap<String, HashMap<String, String>> multiFillMap = getMultiFillMap( arg );
			result.setMultiFillMap( multiFillMap );
			
			HashMap<String, HashMap<String, String>> multiFillMaskMap = getMultiFillMaskMap( arg );
			result.setMultiFillMaskMap( multiFillMaskMap );
			
		} else if ("ALLOWED_ACTIONS".equals( arg.sharp )) {
			
			List<ValueTextSortDto> allowedActionList = getAllowedActionList( arg );
			result.setAllowedActionList( allowedActionList );
		} else if ("CHANGE_OPERATION".equals( arg.sharp )) {
			
			// 分類リストの取得
			List<ValueTextSortDto> divList = getDivList( arg );
			result.divList = divList;
			
			// 運用リストの取得
			List<ValueTextSortDto> opeList = getOpeList( arg );
			result.opeList = opeList;
			
			// フローステータスリストの取得
			List<ValueTextSortDto> staList = new ArrayList<ValueTextSortDto>();
			if (!CsUtil.isBlank( arg.srchCondMap.get( "operationCd" ) )) {
				staList = getStatusList( arg );
			}
			result.staList = staList;
		}
		
		return result;
	}

	private void loadAllSheetSrchRslt( CsMultiEventArg arg ) {
		//clear
		CstSheetSrchRsltDao dao = new CstSheetSrchRsltDao( daoLoginNo );
		dao.executeDynamic( "delete from CST_SHEET_SRCH_RSLT where LOGIN_PERSON_ID = '" + this.daoLoginNo + "'" );
		
		//insert
		/* Dynamic SQL */
		String targetTable = getTargetTable( arg );
		StringBuilder sql = new StringBuilder();
		sql.append( "insert into CST_SHEET_SRCH_RSLT " );
		sql.append( "select ?, s.SHEET_ID, s.OWN_GUID " );
		sql.append( "  from cst_sheet s " );
		/* STAMP or CASCADE */
		sql.append( " inner join ( select * " );
		sql.append( "                from CSM_SHEET_OPERATION " );
		sql.append( "               where OPEN_FLG = '1' ) ope " );
		sql.append( " on ope.OPERATION_CD = s.OPERATION_CD " );
		if ( SU.equals( arg.opeType, "STAMP" ) ) {
			sql.append( " and ope.OPERATION_TYPE = 'STAMP' " );
		}
		else if ( SU.equals( arg.opeType, "CASCADE" ) ) {
			sql.append( " and ope.OPERATION_TYPE = 'CASCADE' " );
		}
		if ( SU.isNotBlank( arg.operationCd ) ) {
			sql.append( " and ope.OPERATION_CD = ? " );
		}
		
		sql.append( " where s.PARTY = ? " );
		sql.append( "   and exists ( " );
		sql.append( "         select 'X' from " + targetTable + " a " );
		sql.append( "          where a.SHEET_ID = s.SHEET_ID and a.GUID = ? " );
		sql.append( "       ) " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.daoLoginNo );
		if ( SU.isNotBlank( arg.operationCd ) ) {
			paramList.add( arg.operationCd );
		}
		paramList.add( arg.party );
		paramList.add( this.operatorGuid );
		
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	private int reduceSheetSrchRslt( CsMultiEventArg arg ) {
		
		// 特定のアクター（owner/follow）による絞込
		reduceBySpecialActorfilter( arg );
		
		// ホールドフィルタによる絞込
		reduceByActorAndHoldfilter( arg );
				
		// シートに埋め込まれた情報に対する絞込 (CST_SHEET, CST_SHEET_ATTR)
		reduceBySheetEmbeddedInfo( arg );
		
		// 絞込み後のシート件数を取得。表示時はROWNUM制限をかけているのでここでカウント。
		return countSheetsAfterReduce( arg );
	}
	
	private int countSheetsAfterReduce( CsMultiEventArg arg ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "select count('X') from CST_SHEET_SRCH_RSLT wk " );
		sql.append( " where wk.LOGIN_PERSON_ID = ? " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.daoLoginNo );
		
		CstSheetSrchRsltDao dao = new CstSheetSrchRsltDao( daoLoginNo );
		return dao.selectCountDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	private void reduceBySpecialActorfilter( CsMultiEventArg arg ) {
		
		String holdFilter = arg.srchCondMap.get( "holdFilter" );
		boolean isFollowMode = "FOLLOW".equals( holdFilter );
		String whereActor = (isFollowMode) ? " and a.ACTOR_CD = 'ref-follow' " : " and a.ACTOR_CD <> 'ref-follow' ";
		/* 組織シートは記入者がact-ownerで設定される  */
		if ( !( SU.equals( arg.opeType, "CASCADE" ) ) ) {
			whereActor = whereActor + " and a.ACTOR_CD <> 'act-owner' ";
		}
		/* Dynamic SQL */
		String targetTable = getTargetTable( arg );
		StringBuilder sql = new StringBuilder();
		sql.append( "delete from CST_SHEET_SRCH_RSLT wk " );
		sql.append( " where wk.LOGIN_PERSON_ID = ? " );
		sql.append( "   and not exists ( " );
		sql.append( "         select 'X' " );
		sql.append( "           from " + targetTable + " a " );
		sql.append( "          where a.SHEET_ID = wk.SHEET_ID " );
		sql.append( "            and a.GUID     = ? " );
		sql.append( whereActor );
		sql.append( "       ) " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.daoLoginNo );
		paramList.add( this.operatorGuid );
		
		CstSheetSrchRsltDao dao = new CstSheetSrchRsltDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	private void reduceByActorAndHoldfilter( CsMultiEventArg arg ) {
		
		String holdFilter = arg.srchCondMap.get( "holdFilter" );
		boolean isHoldMode = "HOLD".equals( holdFilter );
		boolean isFollowMode = "FOLLOW".equals( holdFilter );
		boolean isRetire = (CsUtil.srchCondAvailable( arg.srchCondMap, "retireFlg" ) && "checked".equals( arg.srchCondMap.get( "retireFlg" ) ));
		boolean needsExec = isHoldMode || (isFollowMode && !isRetire);
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "delete from CST_SHEET_SRCH_RSLT wk " );
		sql.append( " where wk.LOGIN_PERSON_ID = ? " );
		if (isHoldMode) {
			sql.append( " and not exists ( " );
			sql.append( "     select 'X' from V_CST_SHEET_INFO vi " );
			sql.append( "      where vi.SHEET_ID  = wk.SHEET_ID " );
			sql.append( "        and vi.HOLD_GUID = ? " );
			sql.append( " ) " );
		}
		if (isFollowMode && !isRetire) {
			sql.append( " and not exists ( " );
			sql.append( "     select 'X' from CA_REGIST_MAIN cp " );
			sql.append( "      where cp.GUID = wk.OWN_GUID " );
			sql.append( "        and cp.FOLLOW_FLG = '1' " );
			sql.append( " ) " );
		}
		
		if (needsExec) {
			/* Parameter List */
			ArrayList<String> paramList = new ArrayList<String>();
			paramList.add( this.daoLoginNo );
			paramList.add( this.operatorGuid );
			
			CstSheetSrchRsltDao dao = new CstSheetSrchRsltDao( daoLoginNo );
			dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
		}
	}

	private void reduceBySheetEmbeddedInfo( CsMultiEventArg arg ) {
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "delete from CST_SHEET_SRCH_RSLT wk " );
		sql.append( " where LOGIN_PERSON_ID = ? " );	paramList.add( this.daoLoginNo );
		sql.append( "   and not exists ( " );
		sql.append( "         select 'X' " );
		sql.append( "           from V_CS_INFO_ATTR vcia " );
		sql.append( "          where vcia.SHEET_ID = wk.SHEET_ID " );
		if (CsUtil.srchCondAvailable( arg.srchCondMap, "personId" )) {
			sql.append( "        and vcia.STF_NO like ? " );
			paramList.add( "%" + arg.srchCondMap.get( "personId" ) + "%" );
		}
		if (CsUtil.srchCondAvailable( arg.srchCondMap, "personNm" )) {
			sql.append( "        and vcia.OWN_PERSON_KANA like ? " );
			paramList.add( arg.srchCondMap.get( "personNm" ) + "%" );
		}
		if (CsUtil.srchCondAvailable( arg.srchCondMap, "deptNm" )) {
			sql.append( "        and vcia.DEPT_NM like ? " );
			paramList.add( "%" + arg.srchCondMap.get( "deptNm" ) + "%" );
		}
		if (CsUtil.srchCondAvailable( arg.srchCondMap, "clsBCd" )) {
			sql.append( "        and vcia.CLS_B_CD = ? " );
			paramList.add( arg.srchCondMap.get( "clsBCd" ) );
		}
		if (!CsUtil.isBlank( arg.operationCd )) {
			sql.append( "        and vcia.OPERATION_CD = ? " );
			paramList.add( arg.operationCd );
		}
		if (!CsUtil.isBlank( arg.statusCd )) {
			sql.append( "        and vcia.STATUS_CD = ? " );
			paramList.add( arg.statusCd );
		}
		sql.append( "       ) " );
		
		CstSheetSrchRsltDao dao = new CstSheetSrchRsltDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	private String getTargetTable( CsMultiEventArg arg ) {
		String holdFilter = arg.srchCondMap.get( "holdFilter" );
		String targetTable = "V_CST_SHEET_ACTOR_AND_REF";
		if (arg.srchCondMap != null) {
			if (CsUtil.srchCondAvailable( arg.srchCondMap, "holdFilter" )) {
				// ALL or ACTOR or HOLD
				if ("ALL".equals( holdFilter )) {
					targetTable = "V_CST_SHEET_ACTOR_AND_REF";
				} else if ("ACTOR".equals( holdFilter )) {
					targetTable = "CST_SHEET_ACTOR";
				} else if ("HOLD".equals( holdFilter )) {
					targetTable = "CST_SHEET_ACTOR";
				} else if ("FOLLOW".equals( holdFilter )) {
					targetTable = "CST_SHEET_ACTOR_REF";
				}
			}
		}
		return targetTable;
	}
	
	private List<VCsInfoAttrDto> getMultiSheetList( CsMultiEventArg arg ) {
		
		boolean isUnlimited = SU.equals( arg.srchCondMap.get( "search_limit" ), "UNLIMITED" );
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + CsUtil.addPrefixOnDaoAllCols( "wrap", VCsInfoAttrDao.ALLCOLS ) );
		sql.append( "   from (select vcia.* " );
		sql.append( "           from V_CS_INFO_ATTR vcia " );
		sql.append( "                inner join CST_SHEET_SRCH_RSLT wk " );
		sql.append( "                  on (wk.SHEET_ID = vcia.SHEET_ID) " );
		sql.append( "          where wk.LOGIN_PERSON_ID = ? " );
		sql.append( "          order by vcia.OPERATION_SORT desc, vcia.CMPA_CD, vcia.SHEET_SORT " );
		sql.append( "        ) wrap " );
		if (!isUnlimited) {
			sql.append( " where ROWNUM <= 500 " );
		}
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.daoLoginNo );
		
		VCsInfoAttrDao dao = new VCsInfoAttrDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	private HashMap<String, HashMap<String, String>> getMultiFillMap( CsMultiEventArg arg ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + CsUtil.addPrefixOnDaoAllCols( "V", CstSheetFillDao.ALLCOLS ) );
		sql.append( "   from V_CST_ALL_FILLS V " );
		sql.append( "  where exists ( " );
		sql.append( "          select 'X' from CST_SHEET_SRCH_RSLT SR " );
		sql.append( "           where SR.LOGIN_PERSON_ID = ? and SR.SHEET_ID = V.SHEET_ID " );
		sql.append( "        ) " );
		sql.append( "  order by 1,2 " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.daoLoginNo );
		
		CstSheetFillDao dao = new CstSheetFillDao( daoLoginNo );
		List<CstSheetFillDto> fillList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		fillList.add( new CstSheetFillDto() ); // dummy for loop
		
		HashMap<String, HashMap<String, String>> multiFillMap = new HashMap<String, HashMap<String, String>>();
		HashMap<String, String> fillMap = new HashMap<String, String>();
		HashMap<String, String> relFillMap = new HashMap<String, String>();
		String nowSheetId = null, befSheetId = null;
		for (CstSheetFillDto dto : fillList) {
			nowSheetId = dto.getSheetId();
			String fc = (dto.getFillContent() != null) ? dto.getFillContent() : "" ;
			if (befSheetId == null || befSheetId.equals( nowSheetId )) {
				fillMap.put( dto.getFillId(), fc );
			}
			else {
				relFillMap = CsSheetEventHandler.getAllRelFillList( daoLoginNo, fillMap );
				fillMap.putAll( relFillMap );
				multiFillMap.put( befSheetId, fillMap );
				
				fillMap = new HashMap<String, String>();
				fillMap.put( dto.getFillId(), fc );
			}
			befSheetId = nowSheetId;
		}
		return multiFillMap;
	}
	
	/**
	 * Multi CareerSheet用のマスク情報を取得する。<br>
	 * シートごとにどのアクター・どのステータスで閲覧するのかが可変である仕様とするため、
	 * マップのキーをマスク用のテーブルに合わせて以下のように定義する。<br>
	 * MaskMap Key: <code>MASK_CD $ STATUS_CD $ ACTOR_CD</code><br>
	 * ※実装難易度の都合上、会社コード・運用コード・書式グループコード・フローコードをまたいだ出力を想定しない。
	 * つまり、運用コードが決まれば、書式グループコード・フローコードが一意に定まる前提としている。
	 */
	private HashMap<String, HashMap<String, String>> getMultiFillMaskMap( CsMultiEventArg arg ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + CsmSheetFormDao.ALLCOLS );
		sql.append( "   from CSM_SHEET_FORM " );
		sql.append( "  where PARTY = ? and OPERATION_CD = ? and FORM_GRP_CD = ? " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.party );
		paramList.add( arg.operationCd );
		paramList.add( arg.formGrpCd );
		
		CsmSheetFormDao fdao = new CsmSheetFormDao( daoLoginNo );
		List<CsmSheetFormDto> fList = fdao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		
		// フローコードが混在しないことを前提とする（対応が難しい）
		String flowCd = (fList.size() > 0) ? fList.get( 0 ).getFlowCd(): "";
		
		/* Dynamic SQL */
		StringBuilder sql2 = new StringBuilder();
		sql2.append( " select ACTOR_CD as value, 'X' as text, 'X' as sort " );
		sql2.append( "   from CSM_SHEET_ACTOR " );
		sql2.append( "  where FLOW_CD = ? " );
		
		/* Parameter List */
		ArrayList<String> paramList2 = new ArrayList<String>();
		paramList2.add( flowCd );
		
		ValueTextSortDao adao = new ValueTextSortDao( daoLoginNo );
		List<ValueTextSortDto> aDtoList = adao.selectDynamic( DaoUtil.getPstmt( sql2, paramList2 ) );
		
		List<String> actorCdList = new ArrayList<String>();
		for (ValueTextSortDto dto : aDtoList) {
			actorCdList.add( dto.getValue() );
		}
		
		HashMap<String, HashMap<String, String>> multiMaskMap = new HashMap<String, HashMap<String, String>>();
		for (CsmSheetFormDto fDto : fList) {
			String statusCd = arg.statusCd;
			HashMap<String, String> maskMap = null;
			if (!CsUtil.isBlank( statusCd )) {
				for (String actorCd : actorCdList) {
					String mapKey = fDto.getMaskCd() + "$" + statusCd + "$" + actorCd;
					if (!multiMaskMap.containsKey( mapKey )) {
						maskMap = CsSheetEventHandler.getFillMaskMap( daoLoginNo, fDto.getFillSetCd(), fDto.getMaskCd(), statusCd, actorCd );
						multiMaskMap.put( fDto.getMaskCd() + "$" + statusCd + "$" + actorCd, maskMap ); // keyがformCdであることに注意。会社・運用は同一前提。
					}
				}
			} else {
				List<String> statusList = getStatusCdListBySheetIdList( arg.sheetIdList );
				for (String statusCdOfList : statusList) {
					for (String actorCd : actorCdList) {
						String mapKey = fDto.getMaskCd() + "$" + statusCdOfList + "$" + actorCd;
						if (!multiMaskMap.containsKey( mapKey )) {
							//System.out.println( mapKey );
							maskMap = CsSheetEventHandler.getFillMaskMap( daoLoginNo, fDto.getFillSetCd(), fDto.getMaskCd(), statusCdOfList, actorCd );
							multiMaskMap.put( mapKey, maskMap ); // keyがformCdであることに注意。会社・運用は同一前提。
						}
					}
				}
			}
		}
		return multiMaskMap;
	}
	
	private List<String> getStatusCdListBySheetIdList( List<String> sheetIdList ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select distinct CS.STATUS_CD as value, 'X' as text, 'X' as sort " );
		sql.append( "   from CST_SHEET CS " );
		sql.append( "  where exists ( " );
		sql.append( "          select 'X' from CST_SHEET_SRCH_RSLT SR " );
		sql.append( "           where SR.LOGIN_PERSON_ID = ? and SR.SHEET_ID = CS.SHEET_ID " );
		sql.append( "        ) " );
		sql.append( "  order by 1 " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.daoLoginNo );
		
		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		List<ValueTextSortDto> dtoList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		List<String> result = new ArrayList<String>();
		for (ValueTextSortDto dto : dtoList) {
			result.add( dto.getValue() );
		}
		return result;
	}
	
	private List<ValueTextSortDto> getActorCdListWithCond( CsMultiEventArg arg ) {
		
		StringBuilder sql = new StringBuilder();
		ArrayList<String> paramList = new ArrayList<String>();
		
		/* Dynamic SQL */
		sql.append( " select A.ACTOR_CD as value, A.ACTOR_NM as text, M.LPAD_SORT as sort " );
		sql.append( "   from ( " );
		sql.append( "          select distinct ACT.ACTOR_CD, ACT.ACTOR_NM, V.FLOW_CD " );
		sql.append( "            from V_CST_SHEET_ACTOR_AND_REF ACT " );
		sql.append( "                 inner join V_CST_SHEET_INFO V on (V.SHEET_ID = ACT.SHEET_ID) " );
		sql.append( "           where ACT.GUID = ? and V.OWN_GUID <> ? " );
		sql.append( "             and V.PARTY = ? and V.OPERATION_CD = ? and V.FORM_GRP_CD = ? " );
		sql.append( "        ) A " );
		sql.append( "        inner join CSM_SHEET_ACTOR M on (M.FLOW_CD = A.FLOW_CD and M.ACTOR_CD = A.ACTOR_CD) " );
		sql.append( "  order by sort " );
		
		/* Parameter List */
		paramList.add( this.operatorGuid );
		paramList.add( this.operatorGuid );
		paramList.add( arg.party );
		paramList.add( arg.operationCd );
		paramList.add( arg.formGrpCd );
		
		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private String getActorCdTaskPrimary( CsMultiEventArg arg ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select AR.MAIN_ACTOR_CD as value, null as text, null as sort " );
		sql.append( "   from V_CST_SHEET_ACTOR_AND_REF AR " );
		sql.append( "        inner join V_CST_SHEET_INFO I " );
		sql.append( "          on (I.SHEET_ID = AR.SHEET_ID and I.PARTY = ? and I.OPERATION_CD = ? and I.FORM_GRP_CD = ?) " );
		sql.append( "  where AR.GUID = ? and AR.HOLD_GUID = ? " );
		sql.append( "    and I.OWN_GUID <> ? " );
		if (!CsUtil.isBlank( arg.srchCondMap.get( "statusCd" ) )) {
		sql.append( "    and I.STATUS_CD = ? " );
		}
		// ステータスが与えられていない時はソートの若いものを返す
		sql.append( "  order by AR.ACTOR_SORT " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.party );
		paramList.add( arg.operationCd );
		paramList.add( arg.formGrpCd );
		paramList.add( this.operatorGuid );
		paramList.add( this.operatorGuid );
		paramList.add( this.operatorGuid );
		if (!CsUtil.isBlank( arg.srchCondMap.get( "statusCd" ) )) {
		paramList.add( arg.srchCondMap.get( "statusCd" ) ); //argから直接とってはならない。シート一覧を絞るかどうかで利用されている。
		}
		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		List<ValueTextSortDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		ValueTextSortDto dto = new ValueTextSortDto();
		if (list.size() > 0) {
			dto = list.get( 0 );
		}
		String actorCdTaskPrimary = dto.getValue();
		return actorCdTaskPrimary;
	}
	
	private List<ValueTextSortDto> getAllowedActionList( CsMultiEventArg arg ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		// FLOW_PTNをまたいだ抽出であることに注意
		sql.append( " select distinct ACTION_CD as value, ACTION_NM as text, " );
		sql.append( "        case when ACTION_CD = 'RESUME'   then 0 ");
		sql.append( "             when ACTION_CD = 'BACKWARD' then 1 ");
		sql.append( "             when ACTION_CD = 'STAY'     then 2 ");
		sql.append( "             when ACTION_CD = 'FORWARD'  then 3 ");
		sql.append( "             when ACTION_CD = 'SKIP'     then 4 ");
		sql.append( "         end as sort ");
		sql.append( "   from CSM_SHEET_ACTION ");
		sql.append( "  where FLOW_CD = ? and STATUS_CD = ? and ACTOR_CD = ? ");
		sql.append( "  order by sort, text ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.flowCd );
		paramList.add( arg.statusCd );
		paramList.add( arg.actorCd );
		
		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<ValueTextSortDto> getDivList( CsMultiEventArg arg ) {
		
		/* シート検索用。組織のシート検索では使用不可。*/
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select /*+ ORDERED */ distinct " );
		sql.append( "        cm.CLS_CD    as value " );
		sql.append( "      , cm.CLS_NM    as text " );
		sql.append( "      , cm.LPAD_SORT as sort " );
		sql.append( "   from CSM_SHEET_OPERATION ope " );
		sql.append( "        inner join CSM_SHEET_FORM form " );
		sql.append( "          on (form.PARTY = ope.PARTY AND form.OPERATION_CD = ope.OPERATION_CD) " );
		sql.append( "        inner join CSM_SHEET_ACTOR mact " );
		sql.append( "          on (mact.FLOW_CD = form.FLOW_CD AND mact.ACTOR_CD <> 'act-owner') " );
		sql.append( "        inner join CST_SHEET st " );
		sql.append( "          on (st.PARTY = ope.PARTY AND st.OPERATION_CD = ope.OPERATION_CD and st.FORM_CD = form.FORM_CD ) " );
		sql.append( "        inner join CST_SHEET_ATTR at " );
		sql.append( "          on (at.SHEET_ID = st.SHEET_ID ) " );
		sql.append( "        left outer join CST_SHEET_ACTOR act " );
		sql.append( "          on (act.SHEET_ID = st.SHEET_ID and act.ACTOR_CD = mact.ACTOR_CD and act.GUID = ?) " );
		sql.append( "        left outer join CST_SHEET_ACTOR_REF ref " );
		sql.append( "          on (ref.SHEET_ID = st.SHEET_ID and ref.ACTOR_CD = mact.ACTOR_CD and ref.GUID = ?) " );
		sql.append( "        inner join AR_SLC_CA_BELONG_CLS_MST cm " );
		sql.append( "          on (cm.SLC_ID = AT.SLC_ID and cm.CMPA_CD = at.CMPA_CD and cm.BEL_CLS = 'B' and cm.CLS_CD = at.CLS_B_CD) " );
		sql.append( "  where ope.PARTY = ? " );
		sql.append( "    and ope.OPERATION_TYPE = 'STAMP' " );
		sql.append( "    and ope.OPEN_FLG = '1' " );
		sql.append( "    and ( act.GUID is not null or ref.GUID is not null ) " );
		sql.append( "  order by cm.LPAD_SORT " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.operatorGuid );
		paramList.add( this.operatorGuid );
		paramList.add( arg.party );
		
		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<ValueTextSortDto> getOpeList( CsMultiEventArg arg ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select /*+ ORDERED */ distinct " );
		sql.append( "        ope.OPERATION_CD as value " );
		sql.append( "      , ope.OPERATION_NM as text " );
		sql.append( "      , ope.LPAD_SORT    as sort " );
		sql.append( "   from CSM_SHEET_OPERATION ope " );
		sql.append( "        inner join CSM_SHEET_FORM form " );
		sql.append( "          on (form.PARTY = ope.PARTY AND form.OPERATION_CD = ope.OPERATION_CD) " );
		sql.append( "        inner join CSM_SHEET_ACTOR mact " );
		sql.append( "          on (mact.FLOW_CD = form.FLOW_CD) " );
		sql.append( "        inner join CST_SHEET st " );
		sql.append( "          on (st.PARTY = ope.PARTY AND st.OPERATION_CD = ope.OPERATION_CD and st.FORM_CD = form.FORM_CD ) " );
		sql.append( "        inner join CST_SHEET_ATTR at " );
		sql.append( "          on (at.SHEET_ID = st.SHEET_ID ) " );
		sql.append( "        left outer join CST_SHEET_ACTOR act " );
		sql.append( "          on (act.SHEET_ID = st.SHEET_ID and act.ACTOR_CD = mact.ACTOR_CD and act.GUID = ?) " );
		sql.append( "        left outer join CST_SHEET_ACTOR_REF ref " );
		sql.append( "          on (ref.SHEET_ID = st.SHEET_ID and ref.ACTOR_CD = mact.ACTOR_CD and ref.GUID = ?) " );
		sql.append( "  where ope.PARTY = ? " );
		sql.append( "    and ope.OPERATION_TYPE = ? " );
		sql.append( "    and ope.OPEN_FLG = '1' " );
		sql.append( "    and ( act.GUID is not null or ref.GUID is not null ) " );
		if (!SU.equals( arg.opeType, "CASCADE" )) {
		sql.append( "    and mact.ACTOR_CD <> 'act-owner' " );
		}
		sql.append( "  order by ope.LPAD_SORT desc " );

		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.operatorGuid );
		paramList.add( this.operatorGuid );
		paramList.add( arg.party );
		paramList.add( arg.opeType );
		
		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}

	private List<ValueTextSortDto> getStatusList( CsMultiEventArg arg ) {
		
		String opeCd = arg.srchCondMap.get( "operationCd" );
		if (opeCd == null) { return null; }
		
		/* Dynamic SQL */
		StringBuilder gsql = new StringBuilder();
		gsql.append( " select" + CsmSheetFormGrpDao.ALLCOLS );
		gsql.append( "   from CSM_SHEET_FORM_GRP " );
		gsql.append( "  where PARTY = ? " );
		gsql.append( "    and OPERATION_CD = ? " );
		gsql.append( "  order by FORM_GRP_CD " );
		
		/* Parameter List */
		ArrayList<String> gParamList = new ArrayList<String>();
		gParamList.add( arg.party );
		gParamList.add( opeCd );
		
		CsmSheetFormGrpDao gDao = new CsmSheetFormGrpDao( daoLoginNo );
		List<CsmSheetFormGrpDto> gDtoList = gDao.selectDynamic( DaoUtil.getPstmt( gsql, gParamList ) );
		CsmSheetFormGrpDto gDto = gDtoList.get( 0 );
		String formGrpCd = gDto.getFormGrpCd();
		if (formGrpCd == null) { return null; }
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select STATUS_CD as value, STATUS_NM as text, SEQ_NO as sort " );
		sql.append( "   from CSM_SHEET_FLOW " );
		sql.append( "  where FLOW_CD = ? " );
		sql.append( "  order by SEQ_NO " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		String flowCd = formGrpCd.replaceAll( "^grp-", "flw-" );
		paramList.add( flowCd );
		
		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
}
