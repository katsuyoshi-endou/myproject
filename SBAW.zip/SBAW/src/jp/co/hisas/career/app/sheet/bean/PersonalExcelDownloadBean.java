package jp.co.hisas.career.app.sheet.bean;

import java.util.HashMap;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

public class PersonalExcelDownloadBean {
	
	@SuppressWarnings("unused")
	private HttpServletRequest request = null;
	
	public PersonalExcelDownloadBean(HttpServletRequest request) throws Exception {
		this.request = request;
	}
	
	/**
	 * 設定情報マップの作成を行う。
	 * 
	 * @param loginNo ログインユーザーNo
	 * @param personID 対象社員番号
	 * @return 設定情報マップ
	 * @throws NamingException ホームインタフェースの参照取得時にネーミング例外が発生した場合
	 * @throws ClassCastException リモートインタフェースのオブジェクトのキャストに失敗した場合
	 * @throws Exception その他の上位からスローされる例外をキャッチした場合
	 */
	public HashMap<String, String> gettingInfoMap( String loginNo, String personID, HttpSession session ) throws NamingException, ClassCastException, Exception {
		try {
			// メソッドトレース開始
			Log.method( loginNo, "IN", "" );
			
			// 設定情報マップの作成
			HashMap<String, String> settingInfoMap = new HashMap<String, String>();
			
			// ダウンロード対象 人ID
			settingInfoMap.put( "&target_person_id", personID );
			
			// ダウンロード実行 人ID
			settingInfoMap.put( "&download_person_id", loginNo );
			
			// ダウンロード日時
			settingInfoMap.put( "&download_date", PZZ010_CharacterUtil.getDayTime() );
			
			// 出力シート名
			settingInfoMap.put( "outputSheetName", "template" );
			
			// メソッドトレース終了
			Log.method( loginNo, "OUT", "" );
			return settingInfoMap;
		} catch (final ClassCastException cce) {
			Log.error( loginNo, cce );
			throw cce;
		} catch (final Exception e) {
			Log.error( loginNo, e );
			throw e;
		}
	}
	
}
