package jp.co.hisas.career.app.sheet.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dao.CsmSheetLabelDao;
import jp.co.hisas.career.app.sheet.dto.CsmSheetLabelDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;

public class CareerSheetLabel {
	
	private static HashMap<String, HashMap<String, CsmSheetLabelDto>> csLabelSetMap = new HashMap<String, HashMap<String, CsmSheetLabelDto>>();
	
	static {
		Connection conn = null;
		try {
			conn = PZZ040_SQLUtility.getConnection( "" );
			CareerSheetLabel.find( conn );
		} catch (final Exception e) {
			Log.error( "", e );
		} finally {
			PZZ040_SQLUtility.close( conn );
		}
	}
	
	private CareerSheetLabel() {
	}
	
	/**
	 * データベースからラベルの値を取得しなおす。
	 */
	public static void find( Connection conn ) throws SQLException {
		
		CsmSheetLabelDao dao = new CsmSheetLabelDao( conn );
		List<CsmSheetLabelDto> result = dao.selectAll();
		
		csLabelSetMap = new HashMap<String, HashMap<String, CsmSheetLabelDto>>();
		for (CsmSheetLabelDto dto : result) {
			String labelSetCd = dto.getLabelSetCd();
			String labelId    = dto.getLabelId();
			HashMap<String, CsmSheetLabelDto> labelMap = null;
			if (csLabelSetMap.containsKey( labelSetCd )) {
				labelMap = csLabelSetMap.get( labelSetCd );
			} else {
				labelMap = new HashMap<String, CsmSheetLabelDto>();
			}
			labelMap.put( labelId, dto );
			csLabelSetMap.put( labelSetCd, labelMap );
		}
	}
	
	public static HashMap<String, String> getLabelSetMap( String labelSetCd, int langNo ) {
		return makeLangMap( labelSetCd, langNo );
	}
	
	private static HashMap<String, String> makeLangMap( String labelSetCd, int langNo ) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		HashMap<String, CsmSheetLabelDto> labelSetMap = CareerSheetLabel.csLabelSetMap.get( labelSetCd );
		if (labelSetMap == null) {
			Log.warn( String.format( "ラベルセットコード: %s の取得結果が null です。", labelSetCd ) );
			return new HashMap<String, String>();
		}
		for (Map.Entry<String, CsmSheetLabelDto> entry : labelSetMap.entrySet()) {
			String key = entry.getKey();
			CsmSheetLabelDto dto = entry.getValue();
			String result = "";
			if (langNo == 1) {
				result = dto.getLabelText();
			} else if (langNo == 2) {
				result = dto.getLabelTextL2();
			} else if (langNo == 3) {
				result = dto.getLabelTextL3();
			}
			resultMap.put( key, result );
		}
		return resultMap;
	}
	
	public static String getLabel( final String labelSetCd, final String labelId ) {
		return getLabel( labelSetCd, labelId, 1 );
	}
	
	public static String getLabel( final String labelSetCd, final String labelId, int langNo ) {
		final HashMap<String, CsmSheetLabelDto> labelMap = CareerSheetLabel.csLabelSetMap.get( labelSetCd );
		String result = "";
		if (labelMap == null || !labelMap.containsKey( labelId )) {
			return null;
		}
		CsmSheetLabelDto dto = labelMap.get( labelId );
		if (langNo == 1) {
			result = dto.getLabelText();
		} else if (langNo == 2) {
			result = dto.getLabelTextL2();
		} else if (langNo == 3) {
			result = dto.getLabelTextL3();
		}
		return result;
	}
	
	public static String getLabel( final String labelSetCd, final String labelId, boolean isVisible ) {
		if (isVisible) {
			return getLabel( labelSetCd, labelId );
		}
		return null;
	}
	
}