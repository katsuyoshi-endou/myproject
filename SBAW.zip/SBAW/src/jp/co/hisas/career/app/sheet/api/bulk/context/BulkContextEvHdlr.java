package jp.co.hisas.career.app.sheet.api.bulk.context;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class BulkContextEvHdlr extends AbstractEventHandler<BulkContextEvArg, BulkContextEvRslt> {
	
	public static BulkContextEvRslt exec( BulkContextEvArg arg ) throws CareerException {
		BulkContextEvHdlr handler = new BulkContextEvHdlr();
		return handler.call( arg );
	}
	
	public BulkContextEvRslt call( BulkContextEvArg arg ) throws CareerException {
		return this.callEjb( arg );
	}
	
	protected BulkContextEvRslt execute( BulkContextEvArg arg ) throws CareerException {
		arg.validateArg();
		String daoLoginNo = arg.getLoginNo();
		BulkContextEvRslt result = new BulkContextEvRslt();
		
		if (SU.equals( "GET", arg.sharp )) {
			
			BulkContextLogicGet logic = new BulkContextLogicGet( daoLoginNo );
			result = logic.main( arg.orderGET );
		}
		
		return result;
	}
	
}
