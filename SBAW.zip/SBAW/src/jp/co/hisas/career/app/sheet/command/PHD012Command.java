package jp.co.hisas.career.app.sheet.command;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.sheet.event.PersonBelongEventArg;
import jp.co.hisas.career.app.sheet.event.PersonBelongEventHandler;
import jp.co.hisas.career.app.sheet.event.PersonBelongEventResult;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.framework.trans.StateTransitionEvent;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class PHD012Command extends AbstractCommand {
	
	public static final String KINOU_ID = "VHD012";
	private HttpServletRequest request;
	private HttpSession session;
	private String state;
	
	public PHD012Command() {
		super( PHD012Command.class, KINOU_ID, null );
	}
	
	public void init( StateTransitionEvent e ) {
		try {
			request = e.getRequest();
			session = request.getSession( false );
			/* Not Update Token While Single Sheet.
			CSRFTokenUtil.setNewTokenNo( request, e.getResponse() ); */
			state = request.getParameter( "state" );
			main();
		} catch (CareerException ex) {
			throw new CareerRuntimeException( ex );
		}
	}
	
	private void main() throws CareerException {
		
		if ("INIT".equals( state )) {
			HashMap<String, String> srchCondMap = new HashMap<String, String>();
			srchCondMap.put( "SrchCondPersonNm",  CsUtil.getRequestValue( request, "SrchCondPersonNm"  ) );
			srchCondMap.put( "SrchCondShozoku",   CsUtil.getRequestValue( request, "SrchCondShozoku"   ) );
			srchCondMap.put( "SrchCondYakushoku", CsUtil.getRequestValue( request, "SrchCondYakushoku" ) );
			session.setAttribute( CsSessionKey.VHD012_SRCH_COND, srchCondMap );
			execEventUnion();
		}
		else if ("RESTORE".equals( state )) {
			execEventUnion();
		}
		
		/* 操作ログ */
		OutLogBean.outputLogSousa( request, KINOU_ID, (String)AU.getSessionAttr( session, CsSessionKey.CS_SHEET_ID ), state );
	}
	
	private void execEventUnion() throws CareerException {
		
		/* Set Args */
		PersonBelongEventArg arg = new PersonBelongEventArg( super.getLoginNo() );
		arg.sharp = "UNION";
		arg.party = AU.getParty( this.session );
		arg.srchCondMap = AU.getSessionAttr( session, CsSessionKey.VHD012_SRCH_COND );
		
		/* Execute Event */
		PersonBelongEventResult result = PersonBelongEventHandler.exec( arg );
		
		/* Return to session */
		session.setAttribute( CsSessionKey.PERSON_BELONG_LIST, result.getBelList() );
	}
}
