/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActorAndRefDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class VCstSheetActorAndRefDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " ACT_OR_REF as actOrRef,"
                     + " SHEET_ID as sheetId,"
                     + " ACTOR_CD as actorCd,"
                     + " ACTOR_NM as actorNm,"
                     + " ACTOR_SORT as actorSort,"
                     + " GUID as guid,"
                     + " PERSON_NAME as personName,"
                     + " MAIN_ACTOR_CD as mainActorCd,"
                     + " HOLD_GUID as holdGuid"
                     ;

    public VCstSheetActorAndRefDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public VCstSheetActorAndRefDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public List<VCstSheetActorAndRefDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] VCstSheetActorAndRefDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<VCstSheetActorAndRefDto> lst = new ArrayList<VCstSheetActorAndRefDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<VCstSheetActorAndRefDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] VCstSheetActorAndRefDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private VCstSheetActorAndRefDto transferRsToDto(ResultSet rs) throws SQLException {

        VCstSheetActorAndRefDto dto = new VCstSheetActorAndRefDto();
        dto.setActOrRef(DaoUtil.convertNullToString(rs.getString("actOrRef")));
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setActorCd(DaoUtil.convertNullToString(rs.getString("actorCd")));
        dto.setActorNm(DaoUtil.convertNullToString(rs.getString("actorNm")));
        dto.setActorSort(DaoUtil.convertNullToString(rs.getString("actorSort")));
        dto.setGuid(DaoUtil.convertNullToString(rs.getString("guid")));
        dto.setPersonName(DaoUtil.convertNullToString(rs.getString("personName")));
        dto.setMainActorCd(DaoUtil.convertNullToString(rs.getString("mainActorCd")));
        dto.setHoldGuid(DaoUtil.convertNullToString(rs.getString("holdGuid")));
        return dto;
    }

}

