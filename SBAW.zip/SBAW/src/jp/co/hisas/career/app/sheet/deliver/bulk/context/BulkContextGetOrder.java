package jp.co.hisas.career.app.sheet.deliver.bulk.context;

import jp.co.hisas.career.app.sheet.deliver.DeliverOrder;
import jp.co.hisas.career.util.Tray;

public class BulkContextGetOrder extends DeliverOrder {
	
	public String operationCd;
	
	public BulkContextGetOrder(Tray tray) {
		super( tray );
	}
}
