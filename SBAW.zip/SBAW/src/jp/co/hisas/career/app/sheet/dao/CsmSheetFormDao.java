/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFormDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CsmSheetFormDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " PARTY as party,"
                     + " OPERATION_CD as operationCd,"
                     + " FORM_GRP_CD as formGrpCd,"
                     + " FORM_CTG_CD as formCtgCd,"
                     + " FORM_CD as formCd,"
                     + " FORM_NM as formNm,"
                     + " FORM_SORT as formSort,"
                     + " LAYOUT_CD as layoutCd,"
                     + " LABEL_SET_CD as labelSetCd,"
                     + " PARAM_SET_CD as paramSetCd,"
                     + " FILL_SET_CD as fillSetCd,"
                     + " MASK_CD as maskCd,"
                     + " FLOW_CD as flowCd,"
                     + " MULTI_FORM_FLG as multiFormFlg"
                     ;

    public CsmSheetFormDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CsmSheetFormDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public List<CsmSheetFormDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CsmSheetFormDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CsmSheetFormDto> lst = new ArrayList<CsmSheetFormDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CsmSheetFormDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CsmSheetFormDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private CsmSheetFormDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmSheetFormDto dto = new CsmSheetFormDto();
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setOperationCd(DaoUtil.convertNullToString(rs.getString("operationCd")));
        dto.setFormGrpCd(DaoUtil.convertNullToString(rs.getString("formGrpCd")));
        dto.setFormCtgCd(DaoUtil.convertNullToString(rs.getString("formCtgCd")));
        dto.setFormCd(DaoUtil.convertNullToString(rs.getString("formCd")));
        dto.setFormNm(DaoUtil.convertNullToString(rs.getString("formNm")));
        dto.setFormSort(DaoUtil.convertNullToString(rs.getString("formSort")));
        dto.setLayoutCd(DaoUtil.convertNullToString(rs.getString("layoutCd")));
        dto.setLabelSetCd(DaoUtil.convertNullToString(rs.getString("labelSetCd")));
        dto.setParamSetCd(DaoUtil.convertNullToString(rs.getString("paramSetCd")));
        dto.setFillSetCd(DaoUtil.convertNullToString(rs.getString("fillSetCd")));
        dto.setMaskCd(DaoUtil.convertNullToString(rs.getString("maskCd")));
        dto.setFlowCd(DaoUtil.convertNullToString(rs.getString("flowCd")));
        dto.setMultiFormFlg(DaoUtil.convertNullToString(rs.getString("multiFormFlg")));
        return dto;
    }

}

