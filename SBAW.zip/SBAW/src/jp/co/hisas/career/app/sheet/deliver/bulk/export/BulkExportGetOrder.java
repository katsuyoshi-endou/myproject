package jp.co.hisas.career.app.sheet.deliver.bulk.export;

import jp.co.hisas.career.app.sheet.deliver.DeliverOrder;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class BulkExportGetOrder extends DeliverOrder {
	
	public String instCd;
	public String scene;
	
	public BulkExportGetOrder(Tray tray) {
		super( tray );
	}
	
	public void validate() throws CareerBusinessException {
		String INVALID_ORDER = CareerBusinessException.INVALID_ORDER;
		if (this.instCd == null) {
			throw new CareerBusinessException( INVALID_ORDER );
		}
		if (this.scene == null) {
			throw new CareerBusinessException( INVALID_ORDER );
		}
		SU.allowsOnlyCode( this.instCd );
		SU.allowsOnlyCode( this.scene );
	}
}
