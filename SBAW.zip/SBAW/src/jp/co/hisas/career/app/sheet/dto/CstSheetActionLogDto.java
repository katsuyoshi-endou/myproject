/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CstSheetActionLogDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String timestamp;
    private String sheetId;
    private String flowCd;
    private String flowPtn;
    private String statusCd;
    private String actorCd;
    private String loginPersonId;
    private String actionCd;
    private String afterStatusCd;
    private String delivMsg;

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getSheetId() {
        return sheetId;
    }

    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    public String getFlowCd() {
        return flowCd;
    }

    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    public String getFlowPtn() {
        return flowPtn;
    }

    public void setFlowPtn(String flowPtn) {
        this.flowPtn = flowPtn;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    public String getActorCd() {
        return actorCd;
    }

    public void setActorCd(String actorCd) {
        this.actorCd = actorCd;
    }

    public String getLoginPersonId() {
        return loginPersonId;
    }

    public void setLoginPersonId(String loginPersonId) {
        this.loginPersonId = loginPersonId;
    }

    public String getActionCd() {
        return actionCd;
    }

    public void setActionCd(String actionCd) {
        this.actionCd = actionCd;
    }

    public String getAfterStatusCd() {
        return afterStatusCd;
    }

    public void setAfterStatusCd(String afterStatusCd) {
        this.afterStatusCd = afterStatusCd;
    }

    public String getDelivMsg() {
        return delivMsg;
    }

    public void setDelivMsg(String delivMsg) {
        this.delivMsg = delivMsg;
    }

}

