package jp.co.hisas.career.app.sheet.event;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import jp.co.hisas.career.app.sheet.dao.CsmSheetActionDao;
import jp.co.hisas.career.app.sheet.dao.CsmSheetFillDao;
import jp.co.hisas.career.app.sheet.dao.CsmSheetFillMaskDao;
import jp.co.hisas.career.app.sheet.dao.CsmSheetLayoutDao;
import jp.co.hisas.career.app.sheet.dao.CsmSheetLayoutJsDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetActionLogDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetActorDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetExclusiveDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetFillAutoDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetFillDao;
import jp.co.hisas.career.app.sheet.dao.CsxSheetStatusDao;
import jp.co.hisas.career.app.sheet.dao.VCsInfoAttrDao;
import jp.co.hisas.career.app.sheet.dao.VCsmFlowStatusDao;
import jp.co.hisas.career.app.sheet.dao.VCstSheetActionLogDao;
import jp.co.hisas.career.app.sheet.dao.VCstSheetActorAndRefDao;
import jp.co.hisas.career.app.sheet.dao.VCstSheetInfoDao;
import jp.co.hisas.career.app.sheet.deliver.sheet.SheetUnit;
import jp.co.hisas.career.app.sheet.dto.CsmSheetActionDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFillDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFillMaskDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetLayoutDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetLayoutJsDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetActionLogDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetActorDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetFillDto;
import jp.co.hisas.career.app.sheet.dto.CsxSheetStatusDto;
import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.app.sheet.dto.VCsmFlowStatusDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActionLogDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActorAndRefDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetInfoDto;
import jp.co.hisas.career.app.sheet.garage.GetActorListGarage;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.ConnDef;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.CaRegistMainDao;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.PulldownMasterDao;
import jp.co.hisas.career.util.dto.CaRegistMainDto;
import jp.co.hisas.career.util.dto.PulldownMasterDto;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.CommonLabel;

public class CsSheetEventHandler extends AbstractEventHandler<CsSheetEventArg, CsSheetEventResult> {
	
	private String originGuid;
	private String daoLoginNo;
	private String operatorGuid;
	private String sharp;
	private String mailSenderName;
	private String sheetId;
	private String actionCd;
	private Map<String, String> fillReqMap;
	private VCstSheetInfoDto info;
	private String ownPersonId, party, operationCd, formCd, flowCd, flowPtn, statusCd;	
	private String actorCd;
	private String resultMsg;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static CsSheetEventResult exec( CsSheetEventArg arg ) throws CareerException {
		CsSheetEventHandler handler = new CsSheetEventHandler();
		return handler.call( arg );
	}
	
	public CsSheetEventResult call( CsSheetEventArg arg ) throws CareerException {
		CsSheetEventResult result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CsSheetEventResult execute( CsSheetEventArg arg ) throws CareerException {
		
		arg.validateArg();
		this.originGuid     = arg.getLoginNo();
		this.daoLoginNo     = arg.getLoginNo();
		this.operatorGuid   = arg.operatorGuid;
		this.sharp          = arg.sharp;
		this.mailSenderName = arg.mailSenderName;
		this.sheetId        = arg.sheetId;
		this.actionCd       = arg.actionCd;
		this.actorCd        = arg.actorCd;
		this.fillReqMap     = arg.fillReqMap;
		
		CsSheetEventResult result = new CsSheetEventResult();
		
		try {
			
			// シート情報の取得
			this.info        = getSheetInfo();
			this.ownPersonId = info.getOwnGuid();
			this.party       = info.getParty();
			this.operationCd = info.getOperationCd();
			this.formCd      = info.getFormCd();
			this.flowCd      = info.getFlowCd();
			this.flowPtn     = info.getFlowPtn();
			this.statusCd    = info.getStatusCd();
			result.setSheetInfoDto( info );
			
			// アクターの設定
			GetActorListGarage galg = new GetActorListGarage( daoLoginNo ); 
			List<VCstSheetActorAndRefDto> actorCdList = galg.getActorList( this.sheetId, this.operatorGuid );
			
			if (CsUtil.isBlank( this.actorCd )) {
				if (actorCdList != null && actorCdList.size() > 0) {
					this.actorCd = actorCdList.get( 0 ).getActorCd();
				} else {
					this.actorCd = "Default";
				}
			}
			result.usingActorCd = this.actorCd;
			result.actorCdList = actorCdList;
			
			if (SU.matches( sharp, "INIT|PAST" )) {
				
				// 排他キーの取得
				CstSheetExclusiveDto excDto = getExclusiveKeyFromDB();
				result.setExclusiveKey( excDto );
				
				// 属性の取得
				VCsInfoAttrDto infoAttrDto = getAttrUnify();
				result.setInfoAttrDto( infoAttrDto );
				
				// 回答データマップの取得
				HashMap<String, String> fillMap = getAllFillList( this.sheetId );
				HashMap<String, String> relFillMap = getAllRelFillList( fillMap );
				fillMap.putAll( relFillMap );
				result.setFillMap( fillMap );
				
				// マスク情報の取得
				HashMap<String, String> fillMaskMap = getFillMaskMap( this.info, this.actorCd );
				result.setFillMaskMap( fillMaskMap );
				
				// 回答マスタからFILL_IDリストを取得
				List<CsmSheetFillDto> fillIdList = getFillIdList( info.getFillSetCd() );
				result.setFillIdList( fillIdList );
				
				// フローステータスリストの取得
				List<CsxSheetStatusDto> flowStatusList = getFlowStatus( this.flowCd );
				result.setFlowStatusList( flowStatusList );
				
				// ボタンリストの取得
				List<CsmSheetActionDto> actionList = getActionList( info.getFlowCd(), info.getFlowPtn(), info.getStatusCd(), this.actorCd );
				result.setActionList( actionList );
				
				// レイアウトJSの取得
				List<CsmSheetLayoutJsDto> layoutJsList = getLayoutJS( info.getLayoutCd() );
				result.setLayoutJsList( layoutJsList );
				
				// レイアウトプルダウンの取得
				Map<String, List<PulldownMasterDto>> layoutPdList = getLayoutPD( info.getLayoutCd() );
				result.setLayoutPdList( layoutPdList );
				
				// 操作履歴の取得
				List<VCstSheetActionLogDto> actionLogList = getActionLogList( this.sheetId );
				result.setActionLogList( actionLogList );
				
			} else if (SU.matches( sharp, "STAY|FORWARD|SKIP" )) {
				
				// 排他キーの比較と更新
				if (!checkExclusiveKey( arg.exclusiveKey )) {
					result.setResultErrorMessage( CommonLabel.getLabel( "LSHSHT_MSG_EXCLUSIVE_ERR" ) );
					return result;
				} else {
					updateExclusiveKey( arg.exclusiveKey );
				}
				
				// シートステータスの更新とアクションログ
				updateCstSheetStatus( arg );
				
				// 回答データの登録と更新
				updateCstSheetFills();
				
				// オプションによる更新
				updateWithOptions( arg );
				
				// [V_CST_SHEET_FILL_AUTO]から[CST_SHEET_FILL_AUTO]に更新(性能改善のため自動計算のビューをテーブルに保持)
				updateCstSheetFillAuto( arg );
				
				// 回答更新後に改めて検証
				SheetUnit u = new SheetUnit( daoLoginNo );
				u.validateFills( sheetId, this.actorCd );
				
				// 処理完了メッセージ
				result.setResultMessage( this.resultMsg );
				
			} else if (SU.matches( sharp, "BACKWARD|RESUME" )) {
				
				// 排他キーの比較と更新
				if (!checkExclusiveKey( arg.exclusiveKey )) {
					result.setResultErrorMessage( CommonLabel.getLabel( "LSHSHT_MSG_EXCLUSIVE_ERR" ) );
					return result;
				} else {
					updateExclusiveKey( arg.exclusiveKey );
				}
				
				// シートステータスの更新とアクションログ
				updateCstSheetStatus( arg );
				
				// 処理完了メッセージ
				result.setResultMessage( this.resultMsg );
				
			} else if (SU.matches( sharp, "DELETE" )) {
				
				// 排他キーの比較と更新
				if (!checkExclusiveKey( arg.exclusiveKey )) {
					result.setResultErrorMessage( CommonLabel.getLabel( "LSHSHT_MSG_EXCLUSIVE_ERR" ) );
					return result;
				} else {
					updateExclusiveKey( arg.exclusiveKey );
				}
				
				// シート削除
				int exitCd = deleteSheet( arg );
				if (exitCd == 0) {
					// シートを削除しました。
					result.setResultMessage( CommonLabel.getLabel( "LSHSHT_MSG_SHEET_DELETE_DONE" ) );
				} else {
					// シートの削除に失敗しました。
					result.setResultErrorMessage( CommonLabel.getLabel( "LSHSHT_MSG_SHEET_DELETE_FAILURE" ) );
				}
				
			} else if (SU.matches( sharp, "LAYOUT_TEMPLATE" )) {
				
				String version = SU.extract( info.getLayoutCd(), "-(v[0-9]?[0-9])$" );
				result.layoutTemplateDto = getLayout( party, info.getLayoutCd(), version );
				
			} else if (SU.matches( sharp, "EXCEL_DL" )) {
				
				// 属性の取得
				VCsInfoAttrDto infoAttrDto = getAttrUnify();
				result.setInfoAttrDto( infoAttrDto );
				
				// 運用タイプ SINGLE / UNIFY で処理分岐
				String opeType = this.info.getOperationType();
				List<VCstSheetInfoDto> neighborSheetInfoList;
				if ("UNIFY".equals( opeType )) {
					// 同一運用コードのシート情報を取得（タブ切替用）
					neighborSheetInfoList = getNeighborSheetInfo( this.party, this.operationCd, this.ownPersonId );
				} else {
					// SINGLE
					neighborSheetInfoList = new ArrayList<VCstSheetInfoDto>();
					neighborSheetInfoList.add( this.info );
				}
				result.setNeighborList( neighborSheetInfoList );
				
				// FILLデータの取得 ※同一運用コードのシートまとめて
				HashMap<String, String> unifiedFillMap = new HashMap<String, String>();
				HashMap<String, String> unifiedNestFillMap = new HashMap<String, String>();
				HashMap<String, String> unifiedFillMaskMap = new HashMap<String, String>();
				for (VCstSheetInfoDto info : neighborSheetInfoList) {
					
					String actorCd = null;
					List<VCstSheetActorAndRefDto> actorList = getActorList( info.getSheetId() );
					if (actorList != null && actorList.size() > 0) {
						actorCd = actorList.get( 0 ).getActorCd();
					} else {
						actorCd = "Default";
					}
					
					// 回答データマップの取得
					HashMap<String, String> fillMap = getAllFillList( info.getSheetId() );
					HashMap<String, String> relFillMap = getAllRelFillList( fillMap );
					fillMap.putAll( relFillMap );
					
					unifiedFillMap.putAll( fillMap );
					
					// マスク情報の取得
					HashMap<String, String> fillMaskMap = getFillMaskMap( info, actorCd );
					
					unifiedFillMaskMap.putAll( fillMaskMap );
				}
				result.setFillMap( unifiedFillMap );
				result.setNestFillMap( unifiedNestFillMap );
				result.setFillMaskMap( unifiedFillMaskMap );
			}
			
			return result;
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
	}
	
	private void updateCstSheetFillAuto( CsSheetEventArg arg ) {
		
		String sheetId = arg.sheetId;
		
		/* Clear */
		CstSheetFillAutoDao dao = new CstSheetFillAutoDao( daoLoginNo );
		dao.executeDynamic( " delete from CST_SHEET_FILL_AUTO where SHEET_ID = '" + sheetId + "'" );
		
		/* Insert */
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "insert into CST_SHEET_FILL_AUTO " );
		sql.append( " select v.SHEET_ID, v.FILL_ID, v.FILL_CONTENT " );
		sql.append( "   from V_CST_SHEET_FILL_AUTO v " );
		sql.append( "    where SHEET_ID = ? " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	private VCstSheetInfoDto getSheetInfo() throws CareerException {
		VCstSheetInfoDao dao = new VCstSheetInfoDao( daoLoginNo );
		VCstSheetInfoDto dto = dao.select( this.sheetId );
		if (dto == null) {
			System.err.println( "[V_CST_SHEET_INFO]からレコードが取得できませんでした。" );
			System.err.println( "・シート作成時に発生した場合、[CSM_SHEET_FLOW]にステータス 00-New が定義されていない可能性があります。" );
			System.err.println( "SHEET_ID: " + this.sheetId );
			throw new CareerException( "Couldn't select V_CST_SHEET_INFO." );
		}
		return dto;
	}
	
	private CstSheetExclusiveDto getExclusiveKeyFromDB() throws Exception {
		CstSheetExclusiveDao excDao = new CstSheetExclusiveDao( daoLoginNo );
		CstSheetExclusiveDto excDto = excDao.select( this.sheetId );
		if (excDto == null) {
			excDao = new CstSheetExclusiveDao( daoLoginNo );
			excDto = new CstSheetExclusiveDto();
			excDto.setSheetId( this.sheetId );
			excDto.setExclusiveKey( 0 );
			excDao.insert( excDto );
		}
		return excDto;
	}
	
	private boolean checkExclusiveKey( CstSheetExclusiveDto exclusiveKey ) throws Exception {
		CstSheetExclusiveDto excDtoDB  = getExclusiveKeyFromDB();
		CstSheetExclusiveDto excDtoSes = exclusiveKey;
		if (excDtoDB != null && excDtoSes != null) {
			String dbSId  = excDtoDB.getSheetId();
			String sesSId = excDtoSes.getSheetId();
			if (dbSId.equals( sesSId )) {
				Integer dbKey  = excDtoDB.getExclusiveKey();
				Integer sesKey = excDtoSes.getExclusiveKey();
				if (dbKey.equals( sesKey )){
					// Check OK
					return true;
				}
			}
		}
		return false;
	}
	
	private void updateExclusiveKey( CstSheetExclusiveDto exclusiveKey ) throws Exception {
		Integer key = exclusiveKey.getExclusiveKey();
		exclusiveKey.setExclusiveKey( key + 1 );
		CstSheetExclusiveDao excDao = new CstSheetExclusiveDao( daoLoginNo );
		excDao.update( exclusiveKey );
	}
	
	private VCsInfoAttrDto getAttrUnify() throws Exception {
		VCsInfoAttrDao dao = new VCsInfoAttrDao( daoLoginNo );
		VCsInfoAttrDto dto = dao.select( this.sheetId );
		if (dto == null) {
			dto = new VCsInfoAttrDto();
		}
		return dto;
	}
	
	private List<VCstSheetInfoDto> getNeighborSheetInfo( String companyCd, String operationCd, String personId ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + VCstSheetInfoDao.ALLCOLS + " from V_CST_SHEET_INFO " );
		sql.append( " where PARTY = ? and OPERATION_CD = ? and OWN_GUID = ? " );
		sql.append( " order by FORM_GRP_CD " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( companyCd );
		paramList.add( operationCd );
		paramList.add( personId );
		
		VCstSheetInfoDao dao = new VCstSheetInfoDao( daoLoginNo );
		List<VCstSheetInfoDto> neighborSheetDtoList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		return neighborSheetDtoList;
	}
	
	private List<CsxSheetStatusDto> getFlowStatus( String flowCd ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select ACT.SHEET_ID as sheetId " );
		sql.append( "      , FLW.FLOW_CD as flowCd " );
		sql.append( "      , FLW.SEQ_NO as seqNo " );
		sql.append( "      , FLW.STATUS_CD as statusCd " );
		sql.append( "      , FLW.STATUS_NM as statusNm " );
		sql.append( "      , FLW.MAIN_ACTOR_CD as mainActorCd " );
		sql.append( "      , ACT.GUID as mainPersonId " );
		sql.append( "      , CG.GUNM as mainPersonName " );
		sql.append( "      , LOG.DONE_PERSON_ID as donePersonId " );
		sql.append( "      , LOG.DONE_PERSON_NAME as donePersonName " );
		sql.append( "      , LOG.TIMESTAMP as timestamp " );
		sql.append( "   from CSM_SHEET_FLOW FLW " );
		sql.append( "        left outer join CST_SHEET_ACTOR ACT " );
		sql.append( "          on (ACT.SHEET_ID = ? and ACT.ACTOR_CD = FLW.MAIN_ACTOR_CD) " );
		sql.append( "        left outer join CAREER_GUID CG " );
		sql.append( "          on (CG.GUID = ACT.GUID) " );
		sql.append( "        left outer join ( " );
		sql.append( "          select LOG.SHEET_ID, LOG.STATUS_CD, LOG.TIMESTAMP " );
		sql.append( "               , LOG.LOGIN_PERSON_ID as DONE_PERSON_ID, CG2.GUNM as DONE_PERSON_NAME " );
		sql.append( "            from CST_SHEET_ACTION_LOG LOG " );
		sql.append( "                 inner join ( " );
		sql.append( "                   select SHEET_ID, STATUS_CD, max(TIMESTAMP) as TIMESTAMP " );
		sql.append( "                     from CST_SHEET_ACTION_LOG " );
		sql.append( "                    where SHEET_ID = ? " );
		sql.append( "                    group by SHEET_ID, STATUS_CD " );
		sql.append( "                 ) MAXLOG " );
		sql.append( "                   on (MAXLOG.SHEET_ID  = LOG.SHEET_ID " );
		sql.append( "                   and MAXLOG.STATUS_CD = LOG.STATUS_CD " );
		sql.append( "                   and MAXLOG.TIMESTAMP = LOG.TIMESTAMP) " );
		sql.append( "                 left outer join CAREER_GUID CG2 " );
		sql.append( "                   on (CG2.GUID = LOG.LOGIN_PERSON_ID) " );
		sql.append( "        ) LOG on (LOG.SHEET_ID = ? and LOG.STATUS_CD = FLW.STATUS_CD) " );
		sql.append( " where FLW.FLOW_CD = ? " );
		sql.append( " order by FLW.SEQ_NO " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.sheetId );
		paramList.add( this.sheetId );
		paramList.add( this.sheetId );
		paramList.add( flowCd );
		
		CsxSheetStatusDao dao = new CsxSheetStatusDao( daoLoginNo );
		List<CsxSheetStatusDto> neighborSheetDtoList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		return neighborSheetDtoList;
	}
	
	private HashMap<String, String> getAllFillList( String sheetId, String fillIdPrefix ) {
		return getAllFillList( daoLoginNo, sheetId, fillIdPrefix );
	}
	
	public static HashMap<String, String> getAllFillList( String daoLoginNo, String sheetId, String fillIdPrefix ) {
		boolean isVisible = true;
		if (SU.isNotBlank( fillIdPrefix )) {
			// If prefix exists, that means Related-Sheet mode.
			isVisible = isVisibleRelatedSheet( daoLoginNo, sheetId );
		}
		CstSheetFillDao dao = new CstSheetFillDao( daoLoginNo );
		List<CstSheetFillDto> fillList = dao.selectAllFillsBySheetId( sheetId );
		HashMap<String, String> fillMap = new HashMap<String, String>();
		for (CstSheetFillDto fillDto : fillList) {
			String fillContent = "";
			if (isVisible) {
				fillContent = SU.ntb( fillDto.getFillContent() );
			}
			// Even if related sheet is INvisible, FILL_ID is needed (for Underscore template).
			fillMap.put( fillIdPrefix + fillDto.getFillId(), fillContent );
		}
		return fillMap;
	}
	
	private HashMap<String, String> getAllFillList( String sheetId ) {
		return getAllFillList( sheetId, "" );
	}
	
	private static boolean isVisibleRelatedSheet( String daoLoginNo, String sheetId ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + SU.addPrefixOnDaoAllCols( "f", VCsmFlowStatusDao.ALLCOLS ) );
		sql.append( "   from V_CST_SHEET_INFO i " );
		sql.append( "        inner join V_CSM_FLOW_STATUS f " );
		sql.append( "          on (f.FLOW_CD = i.FLOW_CD and f.STATUS_CD = i.STATUS_CD) " );
		sql.append( "  where i.SHEET_ID = ? " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		
		VCsmFlowStatusDao dao = new VCsmFlowStatusDao( daoLoginNo );
		List<VCsmFlowStatusDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		if (list.size() > 0) {
			VCsmFlowStatusDto dto = list.get( 0 );
			return SU.equals( "visible", dto.getRelated() );
		}
		return false;
	}
	
	private List<CsmSheetFillDto> getFillIdList( String fillSetCd ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + CsmSheetFillDao.ALLCOLS + " from CSM_SHEET_FILL where FILL_SET_CD = ? order by FILL_ID " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( fillSetCd );
		
		CsmSheetFillDao dao = new CsmSheetFillDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public static HashMap<String, String> getAllRelFillList( String daoLoginNo, HashMap<String, String> fillMap ) {
		HashMap<String, String> relFillMap = new HashMap<String, String>();
		HashMap<String, String> relSheetIdMap = CsUtil.extractMapWithKeyRegex( fillMap, "^RelatedSheetID-.*$" );
		String relSheetId;
		for (Map.Entry<String, String> entry : relSheetIdMap.entrySet()) {
			String relFillIdPrefix = CsUtil.extractWithRegex( entry.getKey(), "^RelatedSheetID-(.*)$" );
			relSheetId = entry.getValue();
			HashMap<String, String> tmpFillMap = new HashMap<String, String>();
			tmpFillMap = getAllFillList( daoLoginNo, relSheetId, relFillIdPrefix + "_" );
			relFillMap.putAll( tmpFillMap );
		}
		return relFillMap;
	}
	
	private HashMap<String, String> getAllRelFillList( HashMap<String, String> fillMap ) throws Exception {
		return getAllRelFillList( daoLoginNo, fillMap );
	}
	
	private HashMap<String, String> getFillMaskMap( VCstSheetInfoDto info, String actorCd ) {
		return getFillMaskMap( daoLoginNo, info.getFillSetCd(), info.getMaskCd(), info.getStatusCd(), actorCd );
	}
	
	public static HashMap<String, String> getFillMaskMap( String daoLoginNo, String fillSetCd, String maskCd, String statusCd, String actorCd ) {
		List<CsmSheetFillMaskDto> maskDtoList = new ArrayList<CsmSheetFillMaskDto>();
		CsmSheetFillMaskDao allDao = new CsmSheetFillMaskDao( daoLoginNo );
		CsmSheetFillMaskDto allDto = allDao.select( maskCd, statusCd, actorCd, "ALL" );
		
		CsmSheetFillMaskDao dao = new CsmSheetFillMaskDao( daoLoginNo );
		if (allDto != null) {
			// FILL_ID に 'ALL' が存在する → 処理中のシートをすべてそのREAD_OR_WRITEでマスク。ALL以外の定義でオーバーライド。
			maskDtoList = getFillMasksWithALL( daoLoginNo, fillSetCd, maskCd, statusCd, actorCd, allDto.getReadOrWrite() );
		} else {
			// FILL_ID に 'ALL' が存在しない
			maskDtoList = dao.selectFillMasks( maskCd, statusCd, actorCd );
		}
		HashMap<String, String> fillMaskMap = new HashMap<String, String>();
		for (CsmSheetFillMaskDto maskDto : maskDtoList) {
			String mode = maskDto.getReadOrWrite();
			if ("read".equals( mode ) || "write".equals( mode )) {
				fillMaskMap.put( maskDto.getFillId(), mode );
			}
		}
		return fillMaskMap;
	}
	
	private static List<CsmSheetFillMaskDto> getFillMasksWithALL( String daoLoginNo, String fillSetCd, String maskCd, String statusCd, String actorCd, String readOrWrite ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select mask.MASK_CD as maskCd, mask.STATUS_CD as statusCd, mask.ACTOR_CD as actorCd, mask.FILL_ID as fillId, mask.READ_OR_WRITE as readOrWrite from " );
		sql.append( " ( " );
		sql.append( "   select ? as MASK_CD, ? as STATUS_CD, ? as ACTOR_CD, FILL_ID, ? as READ_OR_WRITE, 100 as LV " );
		sql.append( "     from CSM_SHEET_FILL where FILL_SET_CD = ? " );
		sql.append( "   union " );
		sql.append( "   select MASK_CD, STATUS_CD, ACTOR_CD, FILL_ID, READ_OR_WRITE, 999 as LV " );
		sql.append( "     from CSM_SHEET_FILL_MASK where MASK_CD = ? and STATUS_CD = ? and ACTOR_CD = ? " );
		sql.append( " ) mask " );
		sql.append( "   inner join ( " );
		sql.append( "     select FILL_ID, max(LV) as LV from " );
		sql.append( "     ( " );
		sql.append( "       select FILL_ID, 100 as LV from CSM_SHEET_FILL where FILL_SET_CD = ? " );
		sql.append( "       union " );
		sql.append( "       select FILL_ID, 999 as LV from CSM_SHEET_FILL_MASK where FILL_ID <> 'ALL' and MASK_CD = ? and STATUS_CD = ? and ACTOR_CD = ? " );
		sql.append( "     ) " );
		sql.append( "     group by FILL_ID " );
		sql.append( "   ) sub on (sub.FILL_ID = mask.FILL_ID and sub.LV = mask.LV) " );
		sql.append( " order by mask.MASK_CD, mask.STATUS_CD, mask.ACTOR_CD, mask.FILL_ID " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( maskCd );  paramList.add( statusCd );  paramList.add( actorCd );  paramList.add( readOrWrite );
		paramList.add( fillSetCd );
		paramList.add( maskCd );  paramList.add( statusCd );  paramList.add( actorCd );
		paramList.add( fillSetCd );
		paramList.add( maskCd );  paramList.add( statusCd );  paramList.add( actorCd );
		
		CsmSheetFillMaskDao dao = new CsmSheetFillMaskDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<VCstSheetActorAndRefDto> getActorList( String sheetId ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + VCstSheetActorAndRefDao.ALLCOLS );
		sql.append( "   from V_CST_SHEET_ACTOR_AND_REF ");
		sql.append( "  where SHEET_ID = ? and GUID = ? ");
		sql.append( "  order by case when ACTOR_CD = MAIN_ACTOR_CD then '999' else ACTOR_SORT end desc ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		paramList.add( this.operatorGuid );
		
		VCstSheetActorAndRefDao dao = new VCstSheetActorAndRefDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<CsmSheetActionDto> getActionList( String flowCd, String flowPtn, String statusCd, String actorCd ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + CsmSheetActionDao.ALLCOLS );
		sql.append( "   from CSM_SHEET_ACTION ");
		sql.append( "  where FLOW_CD = ? and FLOW_PTN = ? and STATUS_CD = ? and ACTOR_CD = ? ");
		sql.append( "  order by LPAD_SORT ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( flowCd );
		paramList.add( flowPtn );
		paramList.add( statusCd );
		paramList.add( actorCd );
		
		CsmSheetActionDao dao = new CsmSheetActionDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<CsmSheetLayoutJsDto> getLayoutJS( String layoutCd ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + CsmSheetLayoutJsDao.ALLCOLS );
		sql.append( "   from CSM_SHEET_LAYOUT_JS ");
		sql.append( "  where LAYOUT_CD = ? ");
		sql.append( "  order by LINE_NO ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( layoutCd );
		
		CsmSheetLayoutJsDao dao = new CsmSheetLayoutJsDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private Map<String, List<PulldownMasterDto>> getLayoutPD( String layoutCd ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + CsUtil.addPrefixOnDaoAllCols( "pm", PulldownMasterDao.ALLCOLS ) );
		sql.append( "   from CSM_SHEET_LAYOUT_PD pd ");
		sql.append( "        inner join PULLDOWN_MASTER pm ");
		sql.append( "          on (pm.PD_SET_CD = pd.PD_SET_CD) ");
		sql.append( "  where pd.LAYOUT_CD = ? ");
		sql.append( "  order by pm.PD_SET_CD, pm.LPAD_SORT ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( layoutCd );
		
		PulldownMasterDao dao = new PulldownMasterDao( daoLoginNo );
		List<PulldownMasterDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		
		Map<String, List<PulldownMasterDto>> result = AU.toMap( list, "pdSetCd" );
		return result;
	}
	
	private CsmSheetLayoutDto getLayout( String party, String layoutCd, String version ) {
		CsmSheetLayoutDao dao = new CsmSheetLayoutDao( daoLoginNo );
		return dao.select( party, layoutCd, version );
	}
	
	private List<VCstSheetActionLogDto> getActionLogList( String sheetId ) {
		VCstSheetActionLogDao dao = new VCstSheetActionLogDao( daoLoginNo );
		return dao.getActionLoglist( sheetId );
	}
	
	private void updateCstSheetFills() {
		
		CstSheetFillDao cstdao = new CstSheetFillDao( daoLoginNo );
		
		/*
		 * 対象シートのFILL_IDリスト取得し、すでにあるものはupdate、ないものはinsertする
		 * ※V_CST_FILL_AUTOの内容も取得するため、自動用のFILL_IDを登録更新の対象としてはならない。
		 */
		List<CstSheetFillDto> existFillDtoList = cstdao.selectAllFillsBySheetId( this.sheetId );
		HashMap<String, String> existFillMap = new HashMap<String, String>();
		for (CstSheetFillDto fillDto : existFillDtoList) {
			existFillMap.put( fillDto.getFillId(), fillDto.getFillContent() );
		}
		
		if (this.fillReqMap == null) {
			return;
		}
		HashMap<String, String> fillMaskMap = getFillMaskMap( this.info, this.actorCd );
		for (Entry<String, String> entry : this.fillReqMap.entrySet()) {
			String fillId = entry.getKey();
			String maskMode = fillMaskMap.get( fillId );
			if (!SU.equals( maskMode, "write" )) {
				continue;
			}
			String fillContent = entry.getValue();
			CstSheetFillDto dto = new CstSheetFillDto();
			dto.setSheetId( this.sheetId );
			dto.setFillId( fillId );
			fillContent = fillContent.replaceAll( "<", "＜" ); // タグ無効化
			fillContent = fillContent.replaceAll( ">", "＞" ); // タグ無効化
			dto.setFillContent( fillContent );
			
			if (existFillMap.containsKey( fillId )) {
				cstdao.update( dto );
			} else {
				cstdao.insert( dto );
			}
			
		}
	}
	
	private void updateWithOptions( CsSheetEventArg arg ) {
		/* Request name が Opt-- で始まるものを使って処理 */
		Map<String, String> options = arg.optFillReqMap;
		if (options == null) {
			return;
		}
	}
	
	private void updateCstSheetStatus( CsSheetEventArg arg ) throws Exception {
		
		/* [CSM_SHEET_ACTION].[AFTER_STATUS_CD]を取得 */
		CsmSheetActionDao aDao = new CsmSheetActionDao( daoLoginNo );
		CsmSheetActionDto aDto = aDao.select( this.flowCd, this.flowPtn, this.statusCd, this.actorCd, this.actionCd );
		String afterStatusCd = null;
		String mailTemplate = null;
		String resultMsg = null;
		if ( aDto != null ) {
			afterStatusCd = aDto.getAfterStatusCd();
			mailTemplate = aDto.getMailTemplate();
			resultMsg = aDto.getResultMsg();
		} else {
			// 操作後ステータスが取得できなかった場合はupdate処理をしない。FILL更新の前にこの判断を行っている。
			// ※フローパターン思想導入により、一括処理にて未定義アクション命令が来る可能性がある。
			//   空振りを許可するため、Exceptionを投げない。
			Log.debug( "[CSM_SHEET_ACTION]: Couldn't select after status. Process for this sheet will be skipped. (SHEET_ID:" + this.sheetId + ")" );
			return;
		}
		
		/* [CST_SHEET].[STATUS_CD]を更新 */
		CstSheetDao sDao = new CstSheetDao( daoLoginNo );
		CstSheetDto sDto = new CstSheetDto();
		sDto.setSheetId( this.sheetId );
		sDto.setParty( this.party );
		sDto.setOperationCd( this.operationCd );
		sDto.setFormCd( this.formCd );
		sDto.setOwnGuid( this.ownPersonId ); // シート本人
		sDto.setStatusCd( afterStatusCd );
		sDto.setFlowPtn( this.flowPtn );
		sDao.update( sDto );
		
		/* リザルトメッセージの格納 */
		this.resultMsg = resultMsg;
		
		/* [CST_SHEET_ACTION_LOG]に変更内容を登録 */
		CstSheetActionLogDao lDao = new CstSheetActionLogDao( daoLoginNo );
		CstSheetActionLogDto lDto = new CstSheetActionLogDto();
		lDto.setTimestamp( CsUtil.getTimestamp() );
		lDto.setSheetId( this.sheetId );
		lDto.setFlowCd( this.flowCd );
		lDto.setFlowPtn( this.flowPtn );
		lDto.setStatusCd( this.statusCd );
		lDto.setActorCd( this.actorCd );
		lDto.setLoginPersonId( this.operatorGuid );
		lDto.setActionCd( this.sharp );
		lDto.setAfterStatusCd( afterStatusCd );
		lDto.setDelivMsg( arg.delivMsg );
		lDao.insert( lDto );
		
		if (!CsUtil.isBlank( mailTemplate )) {
			List<CstSheetActorDto> aftDto = getNextMainActor( this.sheetId, this.flowCd, afterStatusCd );
			if (aftDto.size() > 0) {
				// 操作後ステータスのメインアクター情報を取得
				CstSheetActorDto dto = aftDto.get( 0 );
				String sendTargetGuid = dto.getGuid();
				CaRegistMainDao cpDao = new CaRegistMainDao( daoLoginNo );
				CaRegistMainDto cpDto = cpDao.select( this.party, sendTargetGuid );
				String toMailAddress = null;
				if (cpDto != null) {
					toMailAddress = cpDto.getMailAddress();
				}
				if (toMailAddress != null && toMailAddress.matches( "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$" )) {
					sendMail( this.sheetId + "_to_" + sendTargetGuid, toMailAddress, mailTemplate, arg.delivMsg );
				}
			}
		}
	}
	
	private int deleteSheet( CsSheetEventArg arg ) throws Exception {
		return execPlpkgWebDelSheet( arg.sheetId );
	}
	
	/**
	 * PLPKG_WEB_DEL_SHEET.MAIN(ログインGUID, 実行機能ID, 削除対象シートID)
	 */
	private int execPlpkgWebDelSheet( String sheetId ) throws SQLException {
		int exitCd = 0;
		CallableStatement cstmt = null;
		Connection conn = null;
		try {
			InitialContext ctx = new InitialContext();
			DataSource ds = (DataSource)ctx.lookup( ConnDef.DATASOURCE_NAME );
			conn = ds.getConnection();
			String sql = "{?=call BATCH_WEB_DEL_SHEET.MAIN(?,?,?)}";
			cstmt = conn.prepareCall( sql );
			cstmt.registerOutParameter( 1, java.sql.Types.INTEGER );
			cstmt.setString( 2, this.originGuid ); // Not 統合GUID
			cstmt.setString( 3, "VHD010" );
			cstmt.setString( 4, sheetId );
			cstmt.execute();
			exitCd = cstmt.getInt( 1 );
		} catch (NamingException e) {
			throw new CareerSQLException( e );
		} catch (SQLException e) {
			throw new CareerSQLException( e );
		} finally {
			cstmt.close();
			conn.close();
		}
		return exitCd;
	}
	
	private List<CstSheetActorDto> getNextMainActor( String sheetId, String flowCd, String afterStatusCd ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + CstSheetActorDao.ALLCOLS );
		sql.append( "   from CST_SHEET_ACTOR ");
		sql.append( "  where SHEET_ID = ? ");
		sql.append( "    and ACTOR_CD = ( select MAIN_ACTOR_CD from CSM_SHEET_FLOW ");
		sql.append( "                      where FLOW_CD = ? and STATUS_CD = ? ) ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		paramList.add( flowCd );
		paramList.add( afterStatusCd );
		
		CstSheetActorDao dao = new CstSheetActorDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private void sendMail( String mailId, String toMailAddress, String mailTemplateId, String delivMsg ) throws Exception {
		LysitheaSendMailEventArg arg = new LysitheaSendMailEventArg( originGuid, operatorGuid );
		VCsInfoAttrDto infoAttrDto = getAttrUnify();
		HashMap<String, String> replaceMap = new HashMap<String, String>();
		replaceMap.put( "sender_name", this.mailSenderName );
		replaceMap.put( "sheet_name",  infoAttrDto.getFormNm() );
		replaceMap.put( "deliv_msg",  delivMsg );
		arg.setAll( "SEND", mailId, toMailAddress, mailTemplateId, replaceMap );
		LysitheaSendMailEventHandler.exec( arg );
	}
	
}
