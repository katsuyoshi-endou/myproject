package jp.co.hisas.career.app.sheet.api.bulk.export;

import java.util.List;

import jp.co.hisas.career.ejb.AbstractEventResult;

public class BulkExportEvRslt extends AbstractEventResult {
	
	public List<String> dlCsvHeader;
	public List<List<String>> dlCsvRows;
}
