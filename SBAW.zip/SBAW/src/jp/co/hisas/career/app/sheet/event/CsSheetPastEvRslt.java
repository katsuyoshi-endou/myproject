package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.VCstSheetActorAndRefDto;
import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class CsSheetPastEvRslt extends AbstractEventResult {

	public String relatedSheetId;
	public List<VCstSheetActorAndRefDto> actorCdList;
	public boolean sheetExistance;

}