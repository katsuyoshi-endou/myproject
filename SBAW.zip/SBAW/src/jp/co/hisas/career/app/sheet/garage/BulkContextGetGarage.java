package jp.co.hisas.career.app.sheet.garage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dao.extra.GeneralMapDao;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.PulldownMasterDao;
import jp.co.hisas.career.util.dto.PulldownMasterDto;

public class BulkContextGetGarage extends Garage {
	
	public BulkContextGetGarage(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public List<Map<String, String>> getFormMaster( String party, String operationCd ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select fm.FORM_CTG_CD, 'LSHBLK_INST.' || op.INST_CD ||'.'|| fm.FORM_CTG_CD as FORM_CTG_LABEL_ID, fm.FORM_CD, fm.FORM_NM, fm.FORM_SORT" );
		sql.append( "   from CSM_SHEET_FORM fm" );
		sql.append( "        inner join (" );
		sql.append( "          select PARTY, OPERATION_CD, INST_CD" );
		sql.append( "            from CSM_SHEET_OPERATION" );
		sql.append( "           where OPEN_FLG = '1'" );
		sql.append( "        ) op" );
		sql.append( "          on (op.PARTY = fm.PARTY" );
		sql.append( "          and op.OPERATION_CD = fm.OPERATION_CD)" );
		sql.append( "  where fm.PARTY = ? " );
		sql.append( "    and fm.OPERATION_CD = ? " );
		sql.append( "  order by fm.FORM_SORT" );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( party );
		paramList.add( operationCd );
		
		String[] cols = { "FORM_CTG_CD", "FORM_CTG_LABEL_ID", "FORM_CD", "FORM_NM", "FORM_SORT" };
		
		GeneralMapDao dao = new GeneralMapDao( this.daoLoginNo );
		return dao.select( cols, DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public List<Map<String, String>> getStatusMaster( String party, String operationCd ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select gr.STATUS_GRP_CD, gr.STATUS_GRP_NM, fm.STATUS_CD, fm.STATUS_NM, fm.SEQ_NO" );
		sql.append( "   from CSM_SHEET_FLOW fm" );
		sql.append( "        inner join (" );
		sql.append( "          select FLOW_CD" );
		sql.append( "            from V_CSM_OPERATION_FLOW_MAP" );
		sql.append( "           where PARTY = ? " );
		sql.append( "             and OPERATION_CD = ? " );
		sql.append( "        ) fl" );
		sql.append( "          on (fl.FLOW_CD = fm.FLOW_CD)" );
		sql.append( "        left outer join CSM_STATUS_GRP gr" );
		sql.append( "          on (gr.FLOW_CD = fm.FLOW_CD" );
		sql.append( "          and gr.STATUS_GRP_CD = fm.STATUS_GRP_CD" );
		sql.append( "          )" );
		sql.append( "  order by fm.SEQ_NO" );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( party );
		paramList.add( operationCd );
		
		String[] cols = { "STATUS_GRP_CD", "STATUS_GRP_NM", "STATUS_CD", "STATUS_NM", "SEQ_NO" };
		
		GeneralMapDao dao = new GeneralMapDao( this.daoLoginNo );
		return dao.select( cols, DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public Map<String, List<PulldownMasterDto>> getPulldownMaster( String party, String operationCd ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + SU.addPrefixOnDaoAllCols( "pm", PulldownMasterDao.ALLCOLS ) );
		sql.append( "   from PULLDOWN_MASTER pm" );
		sql.append( "        inner join (" );
		sql.append( "          select distinct PD_SET_CD" );
		sql.append( "            from CSM_SHEET_LAYOUT_PD pd" );
		sql.append( "                 inner join (" );
		sql.append( "                   select distinct LAYOUT_CD" );
		sql.append( "                     from CSM_SHEET_FORM" );
		sql.append( "                    where PARTY = ? " );
		sql.append( "                      and OPERATION_CD = ? " );
		sql.append( "                 ) sub" );
		sql.append( "                   on (sub.LAYOUT_CD = pd.LAYOUT_CD)" );
		sql.append( "        ) ps" );
		sql.append( "          on (ps.PD_SET_CD = pm.PD_SET_CD)" );
		sql.append( "  order by pm.PD_SET_CD, pm.LPAD_SORT" );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( party );
		paramList.add( operationCd );
		
		PulldownMasterDao dao = new PulldownMasterDao( this.daoLoginNo );
		List<PulldownMasterDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		return AU.toMap( list, "pdSetCd" );
	}
	
}
