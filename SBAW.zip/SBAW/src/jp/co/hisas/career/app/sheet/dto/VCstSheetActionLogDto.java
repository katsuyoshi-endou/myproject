/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class VCstSheetActionLogDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String timestamp;
    private String sheetId;
    private String personName;
    private String actorNm;
    private String statusNm;
    private String actionCd;
    private String actionNm;
    private String delivMsg;

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getSheetId() {
        return sheetId;
    }

    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getActorNm() {
        return actorNm;
    }

    public void setActorNm(String actorNm) {
        this.actorNm = actorNm;
    }

    public String getStatusNm() {
        return statusNm;
    }

    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    public String getActionCd() {
        return actionCd;
    }

    public void setActionCd(String actionCd) {
        this.actionCd = actionCd;
    }

    public String getActionNm() {
        return actionNm;
    }

    public void setActionNm(String actionNm) {
        this.actionNm = actionNm;
    }

    public String getDelivMsg() {
        return delivMsg;
    }

    public void setDelivMsg(String delivMsg) {
        this.delivMsg = delivMsg;
    }

}

