package jp.co.hisas.career.app.sheet.servlet;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.event.CsFloodEvArg;
import jp.co.hisas.career.app.sheet.event.CsFloodEvHdlr;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.NewTokenServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class CsFloodServlet extends NewTokenServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "VSHSTC";
	private static final String FORWARD_PAGE = "/view/sheet/VSHSTC_CsFlood.jsp";
	
	public String serviceMain( Tray tray ) throws CareerException {
		
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( tray.session, UserInfoBean.SESSION_KEY );
		tray.operatorGuid = userInfo.getOperatorGuid();
		
		if (SU.equals( tray.state, "SEARCH" )) {
			
		}
		else if (SU.equals( tray.state, "CHANGE_OPERATION" )) {
			
		}
		else if (SU.equals( tray.state, "CHANGE_STATUS" )) {
			execStateChangeStatus( tray );
		}
		
		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, "", tray.state );
		
		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}
	
	private void execStateChangeStatus( Tray tray ) throws CareerException {
		CsFloodEvArg arg = new CsFloodEvArg( tray.loginNo );
		arg.sharp = "CHANGE_STATUS";
		arg.party = tray.party;
		arg.slctedOperation = AU.getRequestValue( tray.request, "operationCd" );
		arg.beforeChangeStatus = AU.getRequestValue( tray.request, "statusCd" );
		arg.actorCd = "act-jinji";
		arg.loginNo = tray.loginNo;
		arg.afterChangeStatus = AU.getRequestValue( tray.request, "afterChangeStatus" );
		arg.delivMsg = AU.getRequestValue( tray.request, "delivMsg" );
		CsFloodEvHdlr.exec( arg );
	}
}
