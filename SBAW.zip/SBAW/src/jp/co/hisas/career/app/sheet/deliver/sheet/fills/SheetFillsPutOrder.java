package jp.co.hisas.career.app.sheet.deliver.sheet.fills;

import java.util.Map;

import jp.co.hisas.career.app.sheet.deliver.DeliverOrder;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class SheetFillsPutOrder extends DeliverOrder {
	
	public String sheetId;
	public String exclusiveKey;
	public String actorCd;
	public Map<String, String> fills;
	
	public SheetFillsPutOrder(Tray tray) {
		super( tray );
	}
	
	public void validate() throws CareerBusinessException {
		if (SU.isBlank( this.sheetId )) {
			throw new CareerBusinessException( CareerBusinessException.INVALID_ORDER );
		}
	}
}
