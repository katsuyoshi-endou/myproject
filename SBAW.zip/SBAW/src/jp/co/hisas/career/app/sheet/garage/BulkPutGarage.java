package jp.co.hisas.career.app.sheet.garage;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.api.mold.BulkConditions;
import jp.co.hisas.career.app.sheet.dao.CstBulkPoolDao;
import jp.co.hisas.career.app.sheet.deliver.bulk.BulkPutOrder;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;

public class BulkPutGarage extends Garage {
	
	public BulkPutGarage(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public void clearBulkPool( String guid ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " delete from CST_BULK_POOL where UPD_GUID = ? " );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( guid );
		
		CstBulkPoolDao dao = new CstBulkPoolDao( this.daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public void refreshBulkPool( BulkPutOrder o ) {
		
		BulkConditions conds = o.conditions;
		String actTable = "CST_SHEET_ACTOR";
		if (SU.equals( conds.bind, "ALL" )) {
			actTable = "V_CST_SHEET_ACTOR_AND_REF";
		}
		
		StringBuilder sql = new StringBuilder();
		sql.append( " insert into CST_BULK_POOL" );
		sql.append( " select ?, st.SHEET_ID, null, null, ?, null" );
		sql.append( "   from CST_SHEET st" );
		sql.append( "  where st.PARTY = ? " );
		sql.append( "    and st.OPERATION_CD = ? " );
		sql.append( "    and exists ( " );
		sql.append( "          select 'X' from " + actTable + " ac " );
		sql.append( "           where ac.SHEET_ID = st.SHEET_ID and ac.ACTOR_CD <> 'act-owner' and ac.GUID = ? " );
		sql.append( "        ) " );
		sql.append( " order by st.SHEET_ID" );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( o.sessionId );
		paramList.add( o.operatorGuid );
		paramList.add( o.party );
		paramList.add( o.operationCd );
		paramList.add( o.operatorGuid );
		
		CstBulkPoolDao dao = new CstBulkPoolDao( this.daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public void reduceByHoldFilter( BulkPutOrder o ) {
		
		BulkConditions conds = o.conditions;
		if (!SU.equals( conds.bind, "HOLD" )) {
			return;
		}
		
		StringBuilder sql = new StringBuilder();
		sql.append( "delete from CST_BULK_POOL wk " );
		sql.append( " where SESSION_ID = ? " );
		sql.append( "   and not exists ( " );
		sql.append( "         select 'X' from V_CST_SHEET_INFO vi " );
		sql.append( "          where vi.SHEET_ID  = wk.SHEET_ID " );
		sql.append( "            and vi.HOLD_GUID = ? " );
		sql.append( "       ) " );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( o.sessionId );
		paramList.add( o.operatorGuid );
		
		CstBulkPoolDao dao = new CstBulkPoolDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
		
	}
	
	public void reduceBySheetEmbeddedInfo( BulkPutOrder o ) {
		
		BulkConditions conds = o.conditions;
		List<String> paramList = new ArrayList<String>();
		
		StringBuilder sql = new StringBuilder();
		sql.append( "delete from CST_BULK_POOL wk " );
		sql.append( " where SESSION_ID = ? " );
		paramList.add( o.sessionId );
		sql.append( "   and not exists ( " );
		sql.append( "         select 'X' " );
		sql.append( "           from V_CS_INFO_ATTR vcia " );
		sql.append( "          where vcia.SHEET_ID = wk.SHEET_ID " );
		if (SU.isNotBlank( conds.formCtgCd )) {
			sql.append( "        and vcia.FORM_CTG_CD = ? " );
			paramList.add( conds.formCtgCd );
		}
		if (SU.isNotBlank( conds.formCd )) {
			sql.append( "        and vcia.FORM_CD = ? " );
			paramList.add( conds.formCd );
		}
		if (SU.isNotBlank( conds.companyCd )) {
			sql.append( "        and vcia.CMPA_CD = ? " );
			paramList.add( conds.companyCd );
		}
		if (SU.isNotBlank( conds.deptNm )) {
			sql.append( "        and vcia.DEPT_NM like ? " );
			paramList.add( "%" + conds.deptNm + "%" );
		}
		if (SU.isNotBlank( conds.stfNo )) {
			sql.append( "        and vcia.STF_NO like ? " );
			paramList.add( "%" + conds.stfNo + "%" );
		}
		if (SU.isNotBlank( conds.stfNm )) {
			sql.append( "        and vcia.OWN_PERSON_NAME like ? " );
			paramList.add( "%" + conds.stfNm + "%" );
		}
		if (SU.isNotBlank( conds.stfKana )) {
			sql.append( "        and vcia.OWN_PERSON_KANA like ? " );
			paramList.add( "%" + conds.stfKana + "%" );
		}
		if (SU.isNotBlank( conds.clsANm )) {
			sql.append( "        and vcia.CLS_A_NM like ? " );
			paramList.add( "%" + conds.clsANm + "%" );
		}
		if (SU.isNotBlank( conds.clsBNm )) {
			sql.append( "        and vcia.CLS_B_NM like ? " );
			paramList.add( "%" + conds.clsBNm + "%" );
		}
		if (SU.isNotBlank( conds.clsCNm )) {
			sql.append( "        and vcia.CLS_C_NM like ? " );
			paramList.add( "%" + conds.clsCNm + "%" );
		}
		if (SU.isNotBlank( conds.statusCd )) {
			sql.append( "        and vcia.STATUS_CD = ? " );
			paramList.add( conds.statusCd );
		}
		sql.append( "       ) " );
		
		CstBulkPoolDao dao = new CstBulkPoolDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	/**
	 * ログインユーザがプールに格納されたシート群に対し、アクターを割り当てる。
	 * １ユーザで複数のアクター、例えば「１次評価者であり２次評価者である」ような場合には
	 * メインアクターを最優先とし、そうでない場合はアクターソート値を使って１つ自動で選択する。
	 */
	public void assignBulkPoolActor( String sessionId, String updGuid ) {
		
		// http://labs.timedia.co.jp/2014/10/selecting-max-record-in-group-by.html
		// https://www.shift-the-oracle.com/sql/merge.html
		StringBuilder sql = new StringBuilder();
		sql.append( " merge into CST_BULK_POOL pl" );
		sql.append( " using (" );
		sql.append( "   select SHEET_ID, ACTOR_CD" );
		sql.append( "     from (" );
		sql.append( "            select xbp.SHEET_ID" );
		sql.append( "                 , xac.ACTOR_CD" );
		sql.append( "                 , case when xac.ACTOR_CD = xac.MAIN_ACTOR_CD then '999' else xac.ACTOR_SORT end as PRIO_LV" );
		sql.append( "              from CST_BULK_POOL xbp" );
		sql.append( "                   inner join V_CST_SHEET_ACTOR_AND_REF xac" );
		sql.append( "                     on (xbp.SESSION_ID = ? " );
		sql.append( "                     and xbp.SHEET_ID = xac.SHEET_ID" );
		sql.append( "                     and xac.GUID = ? " );
		sql.append( "                     and xac.ACTOR_CD <> 'act-owner')" );
		sql.append( "          ) pp" );
		sql.append( "    where not exists (" );
		sql.append( "            select 'X'" );
		sql.append( "              from (" );
		sql.append( "                     select xbp.SHEET_ID" );
		sql.append( "                          , xac.ACTOR_CD" );
		sql.append( "                          , case when xac.ACTOR_CD = xac.MAIN_ACTOR_CD then '999' else xac.ACTOR_SORT end as PRIO_LV" );
		sql.append( "                       from CST_BULK_POOL xbp" );
		sql.append( "                            inner join V_CST_SHEET_ACTOR_AND_REF xac" );
		sql.append( "                              on (xbp.SESSION_ID = ? " );
		sql.append( "                              and xbp.SHEET_ID = xac.SHEET_ID" );
		sql.append( "                              and xac.GUID = ? " );
		sql.append( "                              and xac.ACTOR_CD <> 'act-owner')" );
		sql.append( "                   ) qq" );
		sql.append( "             where pp.SHEET_ID = qq.SHEET_ID" );
		sql.append( "               and pp.PRIO_LV < qq.PRIO_LV" );
		sql.append( "          )" );
		sql.append( " ) sub" );
		sql.append( " on (sub.SHEET_ID = pl.SHEET_ID and pl.SESSION_ID = ?)" );
		sql.append( " when matched then" );
		sql.append( "   update set" );
		sql.append( "     ACTOR_CD = sub.ACTOR_CD" );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( sessionId );
		paramList.add( updGuid );
		paramList.add( sessionId );
		paramList.add( updGuid );
		paramList.add( sessionId );
		
		CstBulkPoolDao dao = new CstBulkPoolDao( this.daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public void updateBulkPoolExclusiveKey( String sessionId ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " update CST_BULK_POOL bp" );
		sql.append( "    set EXC_KEY = (" );
		sql.append( "                    select nvl(ex.EXCLUSIVE_KEY, 0)" );
		sql.append( "                      from CST_BULK_POOL sub" );
		sql.append( "                           left outer join CST_SHEET_EXCLUSIVE ex" );
		sql.append( "                             on (ex.SHEET_ID = sub.SHEET_ID)" );
		sql.append( "                     where sub.SESSION_ID = ? " );
		sql.append( "                       and sub.SHEET_ID = bp.SHEET_ID" );
		sql.append( "                  )" );
		sql.append( "  where bp.SESSION_ID = ? " );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( sessionId );
		paramList.add( sessionId );
		
		CstBulkPoolDao dao = new CstBulkPoolDao( this.daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public void updateBulkPoolWkIdx( String sessionId, String updGuid ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " merge into CST_BULK_POOL w" );
		sql.append( " using (" );
		sql.append( "     select x.SESSION_ID" );
		sql.append( "          , x.SHEET_ID" );
		sql.append( "          , x.ACTOR_CD" );
		sql.append( "          , v.EXCLUSIVE_KEY" );
		sql.append( "          , x.UPD_GUID" );
		sql.append( "          , ROW_NUMBER() OVER(order by v.SHEET_SORT) as WK_IDX" );
		sql.append( "       from CST_BULK_POOL x" );
		sql.append( "            inner join V_CS_INFO_ATTR v" );
		sql.append( "              on (v.SHEET_ID = x.SHEET_ID)" );
		sql.append( "      where x.SESSION_ID = ? " );
		sql.append( "        and x.UPD_GUID = ? " );
		sql.append( " ) s" );
		sql.append( "   on (w.SESSION_ID = s.SESSION_ID and w.SHEET_ID = s.SHEET_ID)" );
		sql.append( " when matched then update" );
		sql.append( "  set w.WK_IDX = s.WK_IDX" );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( sessionId );
		paramList.add( updGuid );
		
		CstBulkPoolDao dao = new CstBulkPoolDao( this.daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
}
