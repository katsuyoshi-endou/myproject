package jp.co.hisas.career.app;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;

import org.apache.commons.io.FileUtils;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.common.event.CareerMenuEvArg;
import jp.co.hisas.career.app.common.event.CareerMenuEvHdlr;
import jp.co.hisas.career.app.common.event.CareerMenuEvRslt;
import jp.co.hisas.career.app.common.event.DualEvArg;
import jp.co.hisas.career.app.common.event.DualEvHdlr;
import jp.co.hisas.career.app.common.event.UserInfoEvArg;
import jp.co.hisas.career.app.common.event.UserInfoEvHdlr;
import jp.co.hisas.career.app.common.event.UserInfoEvRslt;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.property.ReadFile;

public class AppState {
	
	private Tray tray;
	
	public AppState(Tray tray) {
		this.tray = tray;
	}
	
	public void initialize() throws CareerException {
		
		prepareServer();
		
		clearAllSessionAttributes();
		
		updateUserInfo();
		
		getExternalHtml();
		
		execEventInit();
	}
	
	private void prepareServer() throws CareerException {
		
		/* Check DB access */
		DualEvHdlr.exec( new DualEvArg( "AppState" ) );
		
		/* Read property files and DB parameters */
		ReadFile.loadIfNotCached();
	}
	
	private void updateUserInfo() throws CareerException {
		
		/* Set Args */
		UserInfoEvArg arg = new UserInfoEvArg( tray.loginNo );
		arg.sharp = "INIT";
		arg.guid = tray.loginNo;
		
		/* Execute Event */
		UserInfoEvRslt result = UserInfoEvHdlr.exec( arg );
		
		/* Update UserInfo */
		UserInfoBean userInfo = tray.getSessionAttr( UserInfoBean.SESSION_KEY );
		userInfo.setKanjiSimei( result.careerGuidDto.getGunm() );
		String operatorFlg = result.careerGuidDto.getOperatorFlg();
		userInfo.isOperator = "1".equals( operatorFlg );
		String operatorGuid = (userInfo.isOperator) ? AU.getCareerProperty( "OPERATOR_GUID" ) : tray.loginNo;
		userInfo.setOperatorGuid( operatorGuid );
		
		/* Return to session */
		tray.session.setAttribute( UserInfoBean.SESSION_KEY, userInfo );
		
		/* Update Tray with new UserInfo */
		tray.init( tray.request, tray.response, true );
	}
	
	private void getExternalHtml() {
		String exHtml = AU.getSessionAttr( tray.session, "MENU_EXTERNAL_HTML" );
		if (SU.isNotBlank( exHtml )) {
			return;
		}
		String menuPtn = AU.getSessionAttr( tray.session, AppSessionKey.CAREER_MENU_PTN );
		try {
			String filePath = AppDef.APP_DIR + "/htmltemplate/Menu_" + menuPtn + ".html";
			String str = FileUtils.readFileToString( new File( filePath ) );
			tray.session.setAttribute( "MENU_EXTERNAL_HTML", str );
		} catch (IOException e) {
		}
	}
	
	private void execEventInit() throws CareerException {
		
		String menuGrp = "mg-" + AU.getParty( tray.session );
		tray.session.setAttribute( AppSessionKey.CAREER_MENU_GRP, menuGrp );
		
		/* Set Args */
		CareerMenuEvArg arg = new CareerMenuEvArg( tray.loginNo );
		arg.sharp = "INIT";
		arg.menuGrp = AU.getSessionAttr( tray.session, AppSessionKey.CAREER_MENU_GRP );
		arg.party = tray.party;
		arg.guid = tray.loginNo;
		arg.operatorGuid = tray.operatorGuid;
		
		/* Execute Event */
		CareerMenuEvRslt result = CareerMenuEvHdlr.exec( arg );
		
		/* Return to session */
		tray.session.setAttribute( AppSessionKey.CAREER_MENU_LIST, result.careerMenuList );
		tray.session.setAttribute( AppSessionKey.CAREER_MENU_PTN, result.careerMenuPtn );
		tray.session.setAttribute( AppSessionKey.BASE_ROLE_ID, result.baseRoleId );
		tray.session.setAttribute( AppSessionKey.PLAN_ROLE_ID, result.planRoleId );
	}
	
	private void clearAllSessionAttributes() {
		/* Application */
		removeSessionAttr( AppSessionKey.class.getDeclaredFields() );
		/* CareerSheet */
		removeSessionAttr( CsSessionKey.class.getDeclaredFields() );
	}
	
	private void removeSessionAttr( Field[] fields ) {
		for (Field field : fields) {
			try {
				String sessionKey = (String)field.get( field.getName() );
				if (SU.startsWith( sessionKey, "APP_RESULT_MSG" )) {
					continue;
				}
				tray.session.removeAttribute( sessionKey );
			} catch (IllegalArgumentException e) {
			} catch (IllegalAccessException e) {
			}
		}
	}
	
}
