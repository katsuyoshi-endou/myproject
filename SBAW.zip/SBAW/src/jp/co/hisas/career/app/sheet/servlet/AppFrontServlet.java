package jp.co.hisas.career.app.sheet.servlet;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.framework.trans.NoTokenRedirectServlet;
import jp.co.hisas.career.util.Tray;

public class AppFrontServlet extends NoTokenRedirectServlet {
	
	private static final long serialVersionUID = 1L;
	
	@Override
	public String serviceMain( Tray tray ) throws Exception {
		
		return AppDef.HOME_JSP;
	}
	
}
