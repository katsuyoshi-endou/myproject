package jp.co.hisas.career.app.sheet.garage;

public class ServiceUnit {
	
	public String daoLoginNo;
	
	public ServiceUnit(String daoLoginNo) {
		this.daoLoginNo = daoLoginNo;
	}
	
}
