/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CstSheetActorDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sheetId;
    private String actorCd;
    private String guid;
    private String autoFlg;

    public String getSheetId() {
        return sheetId;
    }

    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    public String getActorCd() {
        return actorCd;
    }

    public void setActorCd(String actorCd) {
        this.actorCd = actorCd;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getAutoFlg() {
        return autoFlg;
    }

    public void setAutoFlg(String autoFlg) {
        this.autoFlg = autoFlg;
    }

}

