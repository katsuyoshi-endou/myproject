/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.Arrays;
import java.util.Comparator;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.base.menu.bean.MenuSeigyoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.bean.PCY_HonninKensyuJyohouBean;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_HonninKensyuJyohouEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_HonninKensyuJyohouEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuJouhouBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_SearchKeyBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY194_MousikomiClassIchiranServlet �N���X �@�\�����F �ȖڃR�[�h�A�J�Ó����L�[�Ƃ��ăN���X�̈ꗗ���擾���܂��B
 * 
 * </PRE>
 */
public class PCY194_MousikomiClassIchiranServlet extends PCY010_ControllerServlet {

	/**
	 * ���N�G�X�g����ȖڃR�[�h���擾���A�ȖڃR�[�h�Ɉ�v���铖���ȍ~�̊J�ÃN���X�����擾���܂��B �N���X���̓��N�G�X�g(�������F"classBeans")�Ɋi�[���܂��B �N���X��񂪑��݂��Ȃ��ꍇ�A���N�G�X�g�ɂ͋�̔z�񂪊i�[����܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean )
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			Exception {

		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.transaction(loginuser.getSimeiNo(), true, "");

		// CHG#2007/3/27 s-hiura start
		final PCY_HonninKensyuJyohouEJBHome home = (PCY_HonninKensyuJyohouEJBHome) EJBHomeFactory.getInstance().lookup(PCY_HonninKensyuJyohouEJBHome.class);
		final PCY_HonninKensyuJyohouEJB ejb = home.create();

        // ADD 2018/01/18 COMTURE �ꊇ�\���Ή� START
        MenuSeigyoBean menuSeigyo = (MenuSeigyoBean) request.getSession().getAttribute("menuSeigyo");
        String subSiteMenuId = menuSeigyo.getTargetGamenLinkId();
        String shoninMenuFlg = "0";
        if ("DMU193".equals(subSiteMenuId)) {
            shoninMenuFlg = "1";
        }
        
        // ADD 2018/01/18 COMTURE �ꊇ�\���Ή� END
		/* �����������i�[���� */
		final PCY_SearchKeyBean searchKey = new PCY_SearchKeyBean(request);
		final String[] kamokuCodes = new String[1];
		kamokuCodes[0] = request.getParameter("kamoku_code");
		searchKey.setKaisibi(PZZ010_CharacterUtil.GetDay());

		if (request.getParameter("simei_no") != null) {
			searchKey.setSimeiNo(request.getParameter("simei_no"));
		} else {
			searchKey.setSimeiNo(loginuser.getSimeiNo());
		}

		PCY_ClassBean[] classBeans = null;
        // ADD 2018/01/22 COMTURE �ꊇ�\���Ή� START
        if ("1".equals(shoninMenuFlg)) {
            final PCY_ClassEJBHome classEjbHome = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
            final PCY_ClassEJB classEjb = classEjbHome.create();

            final PCY_ClassBean classCond = new PCY_ClassBean(request);
            classCond.getKamokuBean().setKamokuMei1(classCond.getKamokuBean().getKamokuMei1());
            classBeans = classEjb.doSelect(classCond, false, loginuser);
        } else {
        // ADD 2018/01/22 COMTURE �ꊇ�\���Ή� END
		final PCY_HonninKensyuJyohouBean kensyuBean = new PCY_HonninKensyuJyohouBean();

		final PCY_KensyuJouhouBean[] tempKensyuJouhouBeans = ejb.getKensakuKamokuList(searchKey, loginuser);
		if (tempKensyuJouhouBeans != null) {
			classBeans = new PCY_ClassBean[tempKensyuJouhouBeans.length];
			for (int i = 0; i < tempKensyuJouhouBeans.length; i++) {
				classBeans[i] = tempKensyuJouhouBeans[i].getClassBean();
			}
		} else {
			classBeans = new PCY_ClassBean[0];
		}

		PCY_PersonalBean target_user = null;
		if (request.getParameter("simei_no") != null) {
			final PCY_PersonalEJBHome home2 = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
			final PCY_PersonalEJB ejb2 = home2.create();
			target_user = ejb2.getPersonalInfo(request.getParameter("simei_no"), loginuser);
		}

		PCY_ClassBean kensakuClassBean = null;
		for (int i = 0; i < classBeans.length; i++) {
			if (request.getParameter("simei_no") != null) {
				kensakuClassBean = kensyuBean.doSelectMousikomi(classBeans[i], target_user, loginuser);
			} else {
				kensakuClassBean = kensyuBean.doSelectMousikomi(classBeans[i], loginuser, loginuser);
			}
			classBeans[i].getKamokuBean().setKamokuSyuryoFlg(kensakuClassBean.getKamokuBean().getKamokuSyuryoFlg());
		}
        // ADD 2018/01/22 COMTURE �ꊇ�\���Ή� START
        }
        // ADD 2018/01/22 COMTURE �ꊇ�\���Ή� END
		// �\�[�g
		Arrays.sort(classBeans, new ClassBeanComparator());
		// CHG#2007/3/27 s-hiura end
		request.setAttribute("classBeans", classBeans);

		Log.transaction(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

	// ADD#2007/3/27 s-hiura start
	/**
	 * �J�n���A�I�����A�n��R�[�h���L�[�Ƀ\�[�g���܂��B
	 */
	private class ClassBeanComparator implements Comparator {
		public int compare(final Object o1, final Object o2) {
			final PCY_ClassBean class1 = (PCY_ClassBean) o1;
			final PCY_ClassBean class2 = (PCY_ClassBean) o2;

			if (class1.getKaisibi().equals(class2.getKaisibi())) {
				if (class1.getSyuryobi().equals(class2.getSyuryobi())) {
					if (class1.getChikuCode() != null && class2.getChikuCode() != null) {
						return class1.getChikuCode().compareTo(class2.getChikuCode());
					} else {
						return 0;
					}
				}
				return class1.getSyuryobi().compareTo(class2.getSyuryobi());
			}
			return class1.getKaisibi().compareTo(class2.getKaisibi());
		}
	}
	// ADD#2007/3/27 s-hiura end
}
