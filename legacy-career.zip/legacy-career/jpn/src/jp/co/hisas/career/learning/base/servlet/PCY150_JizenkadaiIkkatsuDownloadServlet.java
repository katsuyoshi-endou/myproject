/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJB;
import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJBHome;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_JizenkadaiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_JizenkadaiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_JizenkadaiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipOutputStream;

/**
 * <PRE>
 * �N���X���F PCY150_JizenkadaiIkkatsuDownloadServlet �N���X �@�\�����F ���O�ۑ���ꊇ�o�͂��܂��B
 * </PRE>
 * ADD 2017/05/17 COMTURE VCC050_�N���X�����iver.02-00�j
 */
public class PCY150_JizenkadaiIkkatsuDownloadServlet extends PCY010_ControllerServlet {

    /**
     * ���N�G�X�g����v���C�}���L�[���擾���A�N���X�����擾���܂��B �N���X���̓��N�G�X�g(�������F"classBean")�Ɋi�[���܂��B �N���X��񂪑��݂��Ȃ��ꍇ�A���N�G�X�g�ɂ� null ���i�[����܂��B
     * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
     * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean )
     */
    protected String execute(final HttpServletRequest request, final HttpServletResponse response,
            final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException, Exception {

        // ���\�b�h�g���[�X�o��
        Log.method(loginuser.getSimeiNo(), "IN", "");

        final EJBHomeFactory fact = EJBHomeFactory.getInstance();

        // �N���X�����擾
        final PCY_ClassEJBHome classHome = (PCY_ClassEJBHome)fact.lookup(PCY_ClassEJBHome.class);
        final PCY_ClassEJB classEjb = classHome.create();
        final PCY_ClassBean classBean = classEjb.doSelectByPrimaryKey(new PCY_ClassBean(request), loginuser);

        // ���O�ۑ�󋵗p
        final PCY_JizenkadaiJyokyoEJBHome home =
                (PCY_JizenkadaiJyokyoEJBHome)fact.lookup(PCY_JizenkadaiJyokyoEJBHome.class);
        final PCY_JizenkadaiJyokyoEJB ejb = home.create();

        // �p�����[�^�擾
        String[] simeiNoArray = request.getParameterValues("simei_no");

        // �_�E�����[�h�t�@�C���擾
        List<PCY_JizenkadaiJyokyoBean> jizenkadaiJyokyoList = new ArrayList<PCY_JizenkadaiJyokyoBean>();
        final PCY_JizenkadaiJyokyoBean jizenkadaiJyokyoBean = new PCY_JizenkadaiJyokyoBean();
        jizenkadaiJyokyoBean.setKamokuCode(request.getParameter("kamoku_code"));
        jizenkadaiJyokyoBean.setClassCode(request.getParameter("class_code"));
        for (String simeiNo : simeiNoArray) {
            jizenkadaiJyokyoBean.setSimeiNo(simeiNo);

            // ���O�ۑ�󋵂��擾
            PCY_JizenkadaiJyokyoBean param = ejb.doSelectByPrimaryKey(jizenkadaiJyokyoBean, loginuser);

            // ���O�ۑ�󋵑��݃`�F�b�N
            if (param == null) {
                request.setAttribute("warningID", "WCC274");
                throw new PCY_WarningException("WCC274");
            }

            // �L�[
            final String[] primaryKey = { "KAMOKU_CODE", "CLASS_CODE", "SIMEI_NO" };

            // �L�[�l
            final String[] keyValue =
                    { jizenkadaiJyokyoBean.getKamokuCode(), jizenkadaiJyokyoBean.getClassCode(),
                            jizenkadaiJyokyoBean.getSimeiNo() };

            // �t�@�C�����擾
            final PYF_BlobDBAccessEJBHome blobHome =
                    (PYF_BlobDBAccessEJBHome)fact.lookup(PYF_BlobDBAccessEJBHome.class);
            final PYF_BlobDBAccessEJB blobEjb = blobHome.create();
            final byte[] jizenkadai =
                    blobEjb.SelectBLOB(loginuser.getSimeiNo(), HcdbDef.L15_JIZENKADAI_JYOKYO_TBL, "JIZENKADAI",
                            primaryKey, keyValue);

            // �t�@�C�����݃`�F�b�N
            if ((jizenkadai == null) || (jizenkadai.length == 0)) {
                request.setAttribute("warningID", "WCC274");
                throw new PCY_WarningException("WCC274");
            }
            param.setJizenkadai(jizenkadai);

            // ���X�g�ɒǉ�
            jizenkadaiJyokyoList.add(param);
        }

        // ���k�t�@�C���쐬
        byte[] zipData = compressFileData(jizenkadaiJyokyoList);

        // ���O�ۑ�󋵂̍X�V
        Log.transaction(loginuser.getSimeiNo(), true, "");
        for (PCY_JizenkadaiJyokyoBean bean : jizenkadaiJyokyoList) {
            // �_�E�����[�h��
            bean.setDownloadbi(PZZ010_CharacterUtil.GetDay());
            // �_�E�����[�h����
            bean.setDownloadjikoku(PZZ010_CharacterUtil.GetTime());
            // �_�E�����[�h��
            bean.setDownloadsya(loginuser.getSimeiNo());

            // �X�V
            ejb.doUpdateForDownload(bean, loginuser);
        }
        Log.transaction(loginuser.getSimeiNo(), false, "");

        // ZIP�t�@�C�����̍쐬 ���Ȗږ�_�N���X��_YYMMDDHH24MISS.zip
        StringBuilder sb = new StringBuilder();
        sb.append(classBean.getKamokuBean().getKamokuMei1());
        sb.append("_");
        sb.append(classBean.getClassMei());
        sb.append("_");
        sb.append(PZZ010_CharacterUtil.getDayTime());
        sb.append(".zip");

        // �t�@�C�����
        request.setAttribute("H080_FileName", PZZ010_CharacterUtil.normalizedStr(sb.toString()));
        request.setAttribute("H081_ContentType", "application/octet-stream");
        request.setAttribute("STREAM", new ByteArrayInputStream(zipData));

        // ���\�b�h�g���[�X�o��
        Log.method(loginuser.getSimeiNo(), "OUT", "");

        return this.getForwardPath();
    }

    /**
     * ���k�t�@�C���̍쐬
     * @param jizenkadaiJyokyoList ���O�ۑ�󋵃f�[�^
     * @return ���k�t�@�C��
     */
    private byte[] compressFileData(List<PCY_JizenkadaiJyokyoBean> jizenkadaiJyokyoList) {

        try {
            ByteArrayOutputStream zip = new ByteArrayOutputStream();
            ZipOutputStream zipOutStream = new ZipOutputStream(zip);

            // �����R�[�h�w�� ���t�@�C������2byte�����Ή�
            zipOutStream.setEncoding("MS932");

            for (PCY_JizenkadaiJyokyoBean bean : jizenkadaiJyokyoList) {
                // ZipOutputStream��ZipEntry��ݒ�
                ZipEntry objZe = new ZipEntry(bean.getJizenkadaiFilename());
                objZe.setMethod(ZipOutputStream.DEFLATED);
                zipOutStream.putNextEntry(objZe);
                zipOutStream.write(bean.getJizenkadai(), 0, bean.getJizenkadai().length);

                // ZipEntry�̃N���[�Y
                zipOutStream.closeEntry();
            }
            zip.close();
            zipOutStream.close();

            return zip.toByteArray();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
