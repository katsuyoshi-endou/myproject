/**
 * バイト数をチェックします。（半角桁数）
 */

function checkByteSize(name, tani, element, min, max)
{
   var byteNumber = byte(element.value);
   if(byteNumber != 0 &&(byteNumber < min || max < byteNumber))
   {
      if(min == max)
      {
         alert(getParameter(param_JS_001, [name,min + tani]));
      }
      else if ( min == 0 )
      {
          alert(getParameter(param_JS_002, [max + tani,name]));
      
      }	
      else
      {
         alert(getParameter(param_JS_003, [name,min + tani,max + tani]));
      }
      element.focus();
      return false;
   }
   return true;
}

/**
 * バイト数をチェックします。（全角桁数）
 */

function checkByteSizeForZenkaku(name, tani, element, min, max)
{
   var byteNumber =  new Number( byte(element.value) ) / new Number( 2 );
   Math.ceil( byteNumber );
   if(byteNumber != 0 &&(byteNumber < min || max < byteNumber))
   {
      if(min == max)
      {
         alert(getParameter(param_JS_004, [name,min + tani]));
      }
      else if ( min == 0 )
      {
          alert(getParameter(param_JS_005, [max + tani,name]));
      }	
      else
      {
         alert(getParameter(param_JS_006, [name,min + tani,max + tani]));
      }
      element.focus();
      return false;
   }
   return true;
}

/**
 * 半角数字をチェックします。
 */

function checkNumber(name, element)
{
   if(!element.value.match(/^\d*$/))
   {
      alert(getParameter(param_JS_007, [name]));
      element.focus();
      return false;
   }
   return true;
}
/**
 * ２桁以上で、１文字目が０の場合アラートを出す。
 */

function checkNotFirstZero(name, element)
{
   if(element.value.match(/^0(\d)+/))
   {
      alert(getParameter(param_JS_008, [name]));
      element.focus();
      return false;
   }
   return true;
}
/**
 * 日付をチェックします。
 */

function checkDate(name, element)
{
   if(!checkByteSize(name, param_JS_009, element, 8, 8))
   {
      element.focus();
      return false;
   }
   if(!checkNumber(name, element))
   {
      element.focus();
      return false;
   }
   element.value.match(/^(\d{4})(\d{2})(\d{2})$/);
   var year = RegExp.$1;
   var month = RegExp.$2;
   var date = RegExp.$3;
   var regularDate = new Date(year + "/" + month + "/" + date);
   if(element.value != "" &&(year != regularDate.getFullYear() || month != regularDate.getMonth() + 1 || date != regularDate.getDate()))
   {
      alert(getParameter(param_JS_008, [name]));
      element.focus();
      return false;
   }
   return true;
}
/**
 * 時刻をチェックします。
 */

function checkTime(name, element)
{
   if(!checkByteSize(name, param_JS_010, element, 4, 4))
   {
      return false;
   }
   if(!checkNumber(name, element))
   {
      return false;
   }
   if(!element.value.match(/^([0-1][0-9][0-5][0-9]|2[0-3][0-5][0-9])?$/))
   {
      alert(getParameter(param_JS_008, [name]));
      element.focus();
      return false;
   }
   return true;
}
/**
 * 入力有無をチェックします。
 */

function checkNotNull(name, element)
{
   if(element.value == null || element.value == "")
   {
      alert(getParameter(param_JS_011, [name]));
      element.focus();
      return false;
   }
   return true;
}
/**
 * 半角英数字をチェックします。
 */

function checkAlphameric(name, element)
{
   if(!element.value.match(/^\w*$/))
   {
      alert(getParameter(param_JS_012, [name]));
      element.focus();
      return false;
   }
   return true;
}
/**
 * １つ以上選択されていることをチェックします。
 */

function checkSelected(name, element)
{
   if(countSelected(element) < 1)
   {
      alert(getParameter(param_JS_013, [name]));
      return false;
   }
   return true;
}
/**
 * １つだけ選択されていることをチェックします。
 */

function checkSingleSelected(name, element)
{
   if(countSelected(element) != 1)
   {
      alert(getParameter(param_JS_014, [name]));
      return false;
   }
   return true;
}
/**
 * 選択されている要素の数を返します。
 */

function countSelected(element)
{
   if(element == void(0))
   {
      // 定義なし
      return 0;
   }
   else if(element.length != void(0))
   {
      // 配列
      var count = 0;
      var lengths = element.length;
      for(var i = 0; i < lengths; i++)
      {
         if(element[i].checked)
         {
            count++;
         }
      }
      return count;
   }
   else if(element.value != void(0))
   {
      // 一つ
      if(element.checked)
      {
         return 1;
      }
      return 0;
   }
   else 
   {
      // 多分ないと思うけど念のため
      return 0;
   }
}
/**
 * 入力可能文字をチェックします。
 */

function checkInvalidCharacter(name, element)
{
   if(!htmlEncode(name, element.value))
   {
      element.focus();
      return false;
   }
   return true;
}

/**
 * 入力文字がオールスペースでないかチェックします。
 */
function checkAllSpace( name, element )
{
    if ( element == null )
    {
        return false;
    }

    var str = element.value;
	if ( str == "" ) {
		return true;
	}
	
    if ( str.match(/^\s*$/) )
    {
        alert(getParameter(param_JS_008, [name]));
        element.focus();
        return false;
    }
    return true;
}
/**
 * すべてチェック、リセット押下
 *
 * checkObj: チェックボックスオブジェクトを指定　　例：「document.F001.C001_CheckBox」
 * check   : true  チェックボックスにチェック    false: チェックボックスのチェックを除去
 */

function setCheckBox(checkObj, check)
{
   if(checkObj != null)
   {
      /* checkObjのチェックボックス数を取得 */
      var pro_no = 1;
      if(checkObj.length)
      {
         pro_no = checkObj.length;
      }
      /* チェックボックス値を変更 */
      if(parseInt(pro_no) > 1)
      {
         for(var i = 0; i < pro_no; i++)
         {
            checkObj[i].checked = check;
         }
      }
      else 
      {
         checkObj.checked = check;
      }
   }
}
/*
 *チェックボックスの選択結果の値のみ取得する
 */

function getCheckedArrays(element)
{
   var result = new Array();
   if(element == void(0))
   {
      // 定義なし
						
   }
   else if(element.length != void(0))
   {
      // 配列
      var count = 0;
      var lengths = element.length;
      for(var i = 0; i < lengths; i++)
      {
         if(element[i].checked)
         {
            result = result.concat(new Array( element[i].value ));
         }
      }
   }
   else if(element.value != void(0))
   {
      // 一つ
      if(element.checked)
      {
         result = result.concat(new Array(element.value));
      }
   }
   else 
   {
      // 多分ないと思うけど念のため
   }
   return result;
}

/**
 * ラジオボタンの選択された値を返します。
 */
function getRadioButtonValue( element ){
    if ( element == null ) {
        return false;
    }
    var i;
    if (element.length) {
        for (i = 0; i < element.length; i++) {
            if (element[i].checked) {
                return element[i].value;
            }
        }
    } else {
        if (element.checked) {
            return element.value;
        }
    }
}

/**
 *  プルダウンの選択された値を返します。
 */
function getPullDownValue( element ) {
    if( element == null ) {
        return false;
    }
    var i;
    if (element.length) {
        for (i = 0; i < element.length; i++) {
            if (element[i].selected) {
                return element[i].value;
            }
        }
    } else {
        if (element.selected) {
            return element.value;
        }
    }
}


/**
 *  プルダウンの選択された文字列を返します。
 */
function getPullDownText( element ) {
    if( element == null ) {
        return false;
    }
    var i;
    if (element.length) {
        for (i = 0; i < element.length; i++) {
            if (element[i].selected) {
                return element[i].text;
            }
        }
    } else {
        if (element.selected) {
            return element.text;
        }
    }
}

/**
 * 日付の大小関係をチェックします。
 */

function checkDateHani(name, namekaisibi, namesyuryobi, element, kaisibi, syuryobi)
{
   if(element.value < kaisibi)
   {
      alert(getParameter(param_JS_015, [name,namekaisibi]));
      element.focus();
      return false;
   }
   if(element.value > syuryobi)
   {
      alert(getParameter(param_JS_016, [name,namesyuryobi]));
      element.focus();
      return false;
   }
   return true;
}

/**
 * 日付の大小関係をチェックします。
 */

function checkDateComp(namekaisibi, namesyuryobi, kaisibi, syuryobi)
{
   if( syuryobi.value < kaisibi.value)
   {
      alert(getParameter(param_JS_016, [namekaisibi,namesyuryobi]));
      return false;
   }
   return true;
}

/**
 * 時間の大小関係をチェックします。
 */

function checkTimeComp(namekaisijikan, namesyuryojikan, kaisijikan, syuryojikan)
{
   if( syuryojikan.value < kaisijikan.value)
   {
      alert(getParameter(param_JS_017, [namekaisijikan,namesyuryojikan]));
      return false;
   }
   
   return true;
}

/**
 * 数値の上限をチェックします。（10進数）
 */

function checkSize(name, element, max)
{
   var intNumber = parseInt(element.value,10);
   if(intNumber != 0 && max < intNumber)
   {
      alert(getParameter(param_JS_018, [name,max]));
      element.focus();
      return false;
   }
   return true;
}

// ADD 2017/10/20 HISOL 申込取消期間追加対応 START
/**
 * 引数で指定された日付を現在日付と比較する
 * 
 * 戻り値
 *   0   : 同じ
 *   < 0 : 現在日付より小さい（現在日付以前）
 *   > 0 : 現在日付より大きい（現在日付以降）
 */
//= 0 同じ
//< 0 小さい（現在日付より以前）
//> 0 大きい（現在日付より以後）
function compareWithCurrentDate(checkDate) {
	var today = new Date();
	
	var year = today.getFullYear();
	var month = today.getMonth() + 1;
	var day = today.getDate();

	// 比較対象
	var dstYear = checkDate.substr(0, 4);
	var dstMonth = checkDate.substr(4, 2);
	var dstDay = checkDate.substr(6, 2);
	
	if(year == dstYear) {
		if(month == dstMonth) {
			return dstDay -day;
		} else {
			return dstMonth - month;
		}
	} else {
		return dstYear - year;
	}
}
// ADD 2017/10/20 HISOL 申込取消期間追加対応 END

/**
 * URL入力可能なフィールドの入力チェックを行う
 * ※通常フィールドの入力チェックとの違いは、URLでの有効文字"&"を許容するか、しないか
 *
 * @param {*} name フィールド名
 * @param {*} element 項目要素
 */
function checkInvalidCharacterWithURL( name, element ) {
	var chkVal = element.value;

	if ( chkVal.indexOf( '>', 0 ) != -1 ) {
		alert(getParameter(param_JS_019, [name]));
		element.focus();
		return false;
	}

	if ( chkVal.indexOf( '<', 0 ) != -1 ) {
		alert(getParameter(param_JS_020, [name]));
		element.focus();
		return false;
	}

	if ( chkVal.indexOf( '\"', 0 ) != -1 ) {
		alert(getParameter(param_JS_021, [name]));
		element.focus();
		return false;
	}
	return true;
}

/**
 * 文字数のチェックを行う
 *   例）'あいうABC' → 6文字としてチェック
 * 
 * @param name フィールド名
 * @param unit 入力単位
 * @param element 項目要素
 * @param min 入力最小文字数
 * @param max 入力最大文字数
 */
function checkWordCount( name, unit, element, min, max ) {
	var count = stringToArray( element.value ).length;

	if( count != 0 && ( count < min || max < count )) {
		if( min === max ) {
			alert( getParameter( param_JS_001, [ name, min + unit ] ));
		} else if ( min === 0 ) {
			alert( getParameter( param_JS_002, [ max + unit, name ] ));
		} else {
			alert( getParameter( param_JS_003, [ name, min + unit, max + unit ] ));
		}
		element.focus();
		return false;
	}
	return true;
}

/**
 * 指定された文字列を文字配列にして返す
 *   例）'あいうABC' → ['あ','い','う','A','B','C']
 * 
 * @param str 検査文字列
 * @returns 文字配列
 */
function stringToArray( str ) {
	return str.match(/[\uD800-\uDBFF][\uDC00-\uDFFF]|[^\uD800-\uDFFF]/g) || [];
}

/**
 * 指定された文字列のバイト数を返す
 *   encodeURIComponentメソッドでUTF-8のバイト列の16進数バイト表記になおして正規表現で処理してバイト数を取得する
 * 
 * @param str 検査文字列
 * @returns 文字列長
 */
function getStringLength( str ) {
	return (encodeURIComponent(str).replace(/%../g, "x").length);
}

/**
 * 文字バイト数のチェックを行う
 *   例）'あいうABC' → 12バイト（UTF-8環境下）としてチェック
 * 
 * @param name フィールド名
 * @param unit 入力単位
 * @param element 項目要素
 * @param min 入力最小文字数
 * @param max 入力最大文字数
 * @return チェック結果（TRUE : OK, FALSE : NG）
 */
function checkWordBytes( name, unit, element, min, max ) {
	var count = getStringLength(element.value);

	if( count != 0 && ( count < min || max < count )) {
		if( min === max ) {
			alert( getParameter( param_JS_001, [ name, min + unit ] ));
		} else if ( min === 0 ) {
			alert( getParameter( param_JS_024, [name, max] ));
		} else {
			alert( getParameter( param_JS_003, [ name, min + unit, max + unit ] ));
		}
		element.focus();
		return false;
	}
	return true;
}
