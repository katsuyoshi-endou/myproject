/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.bean;

import java.io.Serializable;

/**
 * ���M�ݒ���eBean
 * @author ���
 */
public class PED_SoushinNaiyouSetteiBean implements Serializable {

	/** �A���P�[�gNO */
	private String enqueteNo;

	/** �A���P�[�g���� */
	private String enqueteNm;

	/** �A���P�[�g��� */
	private String enqueteStatus;

	/** �e���v���[�g */
	private String template;

	/** �J�n�� */
	private String startDate;

	/** �J�n���� */
	private String startTime;

	/** �I���� */
	private String endDate;

	/** �I������ */
	private String endTime;

	/** �ǉ��R�����g */
	private String addComment;

	public String getEnqueteNm() {
		return this.enqueteNm;
	}

	public void setEnqueteNm(final String enqueteNm) {
		this.enqueteNm = enqueteNm;
	}

	public String getEnqueteNo() {
		return this.enqueteNo;
	}

	public void setEnqueteNo(final String enqueteNo) {
		this.enqueteNo = enqueteNo;
	}

	public String getEnqueteStatus() {
		return this.enqueteStatus;
	}

	public void setEnqueteStatus(final String enqueteStatus) {
		this.enqueteStatus = enqueteStatus;
	}

	public String getTemplate() {
		return this.template;
	}

	public void setTemplate(final String template) {
		this.template = template;
	}

	public String getStartDate() {
		return this.startDate;
	}

	public void setStartDate(final String startDate) {
		this.startDate = startDate;
	}

	public String getStartTime() {
		return this.startTime;
	}

	public void setStartTime(final String startTime) {
		this.startTime = startTime;
	}

	public String getEndDate() {
		return this.endDate;
	}

	public void setEndDate(final String endDate) {
		this.endDate = endDate;
	}

	public String getEndTime() {
		return this.endTime;
	}

	public void setEndTime(final String endTime) {
		this.endTime = endTime;
	}

	public String getAddComment() {
		return this.addComment;
	}

	public void setAddComment(final String addComment) {
		this.addComment = addComment;
	}
}