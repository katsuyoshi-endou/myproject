/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.base.upload.bean.PYF010_FileUploadBean;
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_EsNinsyoRirekiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_EsNinsyoRirekiEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_EsNinsyoRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuJouhouBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F PCY166_ReportUploadServlet �N���X �@�\�����F ���|�[�g�̕񍐂��s���܂��B
 * 
 * </PRE>
 */
public class PCY167_ReportUploadServlet extends PCY010_ControllerServlet {
	/**
	 * ���N�G�X�g����t�@�C�����擾���A�񍐂��s���܂��B
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		try {

			PCY_KensyuJouhouBean kensyuBean = null;

			if (request.getParameter("simei_no") != null) {
				// ES�F�ؗL�̏ꍇ�͏��session�ɂ̂��Ă���
				kensyuBean = (PCY_KensyuJouhouBean) request.getSession().getAttribute("houkou.report");
			} else {
				// ES�F�ؖ��̏ꍇ�͂̂��Ă��Ȃ�

				/* ���N�G�X�g����t�@�C���y�сA���̑��̃t�B�[���h���擾 */
				final PYF010_FileUploadBean fileUploadBean = new PYF010_FileUploadBean(loginuser.getSimeiNo(), request);

				// �t�@�C�������擾
				final String reportFilename = fileUploadBean.getFile_name("report");

				// �R���e���g�^�C�v���擾
				final String reportContentType = fileUploadBean.getFile_contentType("report");

				// �t�@�C�����擾
				final byte[] houkoku = (byte[]) fileUploadBean.getParameter("report");
				final long fileSize = Long.parseLong((String) ReadFile.fileMapData.get("REPORT_SIZE"));

				/* �t�@�C���T�C�Y�O�o�C�g�`�F�b�N */
				if (houkoku.length == 0) {
					request.setAttribute("warningID", "WCA030");
					throw new PCY_WarningException("WCA030");
				}

				/* �ő�t�@�C���T�C�Y�`�F�b�N */
				if (houkoku.length > fileSize) {
					request.setAttribute("warningID", "WCA020");
					throw new PCY_WarningException("WCA020");
				}

				// ������(��u��)���擾
				final String jyukoubi = (String) fileUploadBean.getParameter("T001_jyukoubi");

				/* �l�̊i�[ */
				final PCY_KamokuBean kamokuBean = new PCY_KamokuBean(request);
				kamokuBean.setKamokuCode((String) fileUploadBean.getParameter("H001_kamoku_code"));

				final PCY_ClassBean classBean = new PCY_ClassBean(request);
				classBean.setKamokuBean(kamokuBean);
				classBean.setClassCode((String) fileUploadBean.getParameter("H002_class_code"));
				classBean.setHoukokuKubun((String) fileUploadBean.getParameter("H003_houkoku_kubun"));
				classBean.setHanteiKubun((String) fileUploadBean.getParameter("H009_hantei_kubun"));
				classBean.setNinsyoKubun((String) fileUploadBean.getParameter("H004_ninsyo_kubun"));
				classBean.setKousinbi((String) fileUploadBean.getParameter("H005_class_kousinbi"));
				classBean.setKousinjikoku((String) fileUploadBean.getParameter("H006_class_kousinjikoku"));
				classBean.setZensyaTaisyoFlg((String) fileUploadBean.getParameter("H015_zensya_taisyo_flg"));

				final PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean();
				mousikomiBean.setClassBean(classBean);
				mousikomiBean.setSimeiNo(loginuser.getSimeiNo());
				mousikomiBean.setStatus((String) fileUploadBean.getParameter("H009_status"));
				mousikomiBean.setReportFileName(reportFilename);
				mousikomiBean.setReportContentType(reportContentType);
				mousikomiBean.setHoukoku(houkoku);
				mousikomiBean.setHoukokubi(PZZ010_CharacterUtil.GetDay());
				mousikomiBean.setHoukokujikoku(PZZ010_CharacterUtil.GetTime());
				mousikomiBean.setHoukokusya(loginuser.getSimeiNo());
				mousikomiBean.setJyukoubi(jyukoubi);
				mousikomiBean.setKousinbi((String) fileUploadBean.getParameter("H007_mousikomi_kousinbi"));
				mousikomiBean.setKousinjikoku((String) fileUploadBean.getParameter("H008_mousikomi_kousinjikoku"));

				final PCY_KensyuRirekiBean rirekiBean = new PCY_KensyuRirekiBean();
				rirekiBean.setReportFilename(reportFilename);
				rirekiBean.setReportContentType(reportContentType);
				rirekiBean.setHoukoku(houkoku);
				rirekiBean.setJyukoubi(jyukoubi);
				rirekiBean.setSyuryoHantei("1");

				final UserInfoBean userinfo = (UserInfoBean) request.getSession().getAttribute("userinfo");
				rirekiBean.setKokaiFlg(userinfo.getKyoiku_kokai_flg());
				rirekiBean.setHonninSyuseiFlg("0");
				kensyuBean = new PCY_KensyuJouhouBean();
				kensyuBean.setClassBean(classBean);
				kensyuBean.setMousikomiBean(mousikomiBean);
				kensyuBean.setRirekiBean(rirekiBean);
			}

			/* �F�؋敪���v�̏ꍇ��ES�F�؂��s�� */
			String ninsyoKekka = "1";

			if (kensyuBean.getClassBean().getNinsyoKubun().equals("1")) {
				// ����NO�̔�r
				if (!request.getParameter("simei_no").equals(loginuser.getSimeiNo().trim())) {
					ninsyoKekka = "0";
				}

				// �p�X���[�h�̔�r
				if (!request.getParameter("password").equals(loginuser.getPassword())) {
					ninsyoKekka = "0";
				}
			}

			/* �F�،��ʂ̊i�[ */
			final PCY_EsNinsyoRirekiBean ninsyoBean = new PCY_EsNinsyoRirekiBean();

			// ����NO
			ninsyoBean.setSimeiNo(loginuser.getSimeiNo());

			// �ȖڃR�[�h
			ninsyoBean.setKamokuCode(kensyuBean.getClassBean().getKamokuBean().getKamokuCode());

			// �N���X�R�[�h
			ninsyoBean.setClassCode(kensyuBean.getClassBean().getClassCode());

			// �F�ؓ�
			ninsyoBean.setNinsyobi(PZZ010_CharacterUtil.GetDay());

			// �F�؎���
			ninsyoBean.setNinsyojikoku(PZZ010_CharacterUtil.GetTime());

			// �񍐋敪
			ninsyoBean.setHoukokuKubun(kensyuBean.getClassBean().getHoukokuKubun());

			// �F�،���
			ninsyoBean.setNinsyoKekka(ninsyoKekka);

			// ��u��
			ninsyoBean.setJyukoubi(kensyuBean.getMousikomiBean().getJyukoubi());

			// �ύX���R
			ninsyoBean.setHenkouriyuu(request.getParameter("henkouriyuu"));

			if (ninsyoKekka.equals("0")) {
				/* �F�؂Ɏ��s�����ꍇ��ES�F�ؗ������쐬���A�x����ʂɑJ�ڂ��܂��B */
				final PCY_EsNinsyoRirekiEJBHome ninsyoHome = (PCY_EsNinsyoRirekiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_EsNinsyoRirekiEJBHome.class);
				final PCY_EsNinsyoRirekiEJB ninsyoEjb = ninsyoHome.create();

				/* Es�F�ؗ����̍쐬 */
				ninsyoEjb.doInsert(new PCY_EsNinsyoRirekiBean[] { ninsyoBean }, loginuser);

				request.setAttribute("warningID", "WCA010");
				throw new PCY_WarningException();
			}
			// �\����
			final PCY_MousikomiJyokyoEJBHome mousikomiHome = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
			final PCY_MousikomiJyokyoEJB mousikomiEjb = mousikomiHome.create();

			if (kensyuBean.getClassBean().getHanteiKubun().equals("0")) {
				// ����敪���s�v�̏ꍇ�́A�\���󋵂c�a�̃��R�[�h���폜���ċ��猤�C���c�a�ɃC���T�[�g����

				/* �������s */
				Log.transaction(loginuser.getSimeiNo(), true, "");
				mousikomiEjb.doHoukoku(kensyuBean.getMousikomiBean(), kensyuBean.getRirekiBean(), ninsyoBean, loginuser);
				Log.transaction(loginuser.getSimeiNo(), false, "");
			} else {
				if (kensyuBean.getMousikomiBean().getKousinbi() == null || kensyuBean.getMousikomiBean().getKousinbi().trim().equals("")) {
					/* ����v�E�\���s�v�E�V�K�o�^�̏ꍇ�͔���҂���ԂŐ\���󋵂c�a�Ƀ��R�[�h��ǉ����� */
					Log.transaction(loginuser.getSimeiNo(), true, "");
					kensyuBean.getMousikomiBean().setStatus("3");
					mousikomiEjb.doInsertWithEsNinsyo(kensyuBean.getMousikomiBean(), ninsyoBean, loginuser);
					Log.transaction(loginuser.getSimeiNo(), false, "");
				} else {
					// ����敪���v�̏ꍇ�́A�\���󋵂c�a�̃��R�[�h���X�V����

					/* �X�e�[�^�X���Z�b�g */
					kensyuBean.getMousikomiBean().setStatus("3");

					/* �������s */
					Log.transaction(loginuser.getSimeiNo(), true, "");
					mousikomiEjb.doUpdateWithEsNinsyo(kensyuBean.getMousikomiBean(), ninsyoBean, loginuser);
					Log.transaction(loginuser.getSimeiNo(), false, "");
				}
			}

			/* Session�Ɋi�[�������|�[�g�����폜���� */
			request.getSession().removeAttribute("houkou.report");

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return this.getForwardPath();
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RemoteException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final PCY_WarningException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		}
	}
}
