/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ejb.EJBException;
import javax.naming.NamingException;

import jp.co.hisas.career.department.offer.bean.PEB_KouboAnkenBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboExtBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboKibouSyokusyuBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PEB010_OpportunityAnnouncementDao �@�\�����F �w�肳�ꂽ����Č�ID�ɊY������Г�����Č�PDF�쐬�p�̃f�[�^�𒊏o����B
 * 
 * </PRE>
 */
public class PEB_KouboSelectDao {

	/** S01_����e�[�u�����f�[�^���o����ׂ�SQL */
	private static String KOUBO_SELECT_SQL = null;

	static {
		/** �₢���킹SQL���쐬 */
		final StringBuffer buf = new StringBuffer();
		buf.append("SELECT ");
		for (int i = 0; i < HcdbDef.s01_column.length; ++i) {
			if (i > 0) {
				buf.append(", ");
			}
			buf.append("A." + HcdbDef.s01_column[i] + " as " + HcdbDef.s01_column[i]);
		}
		buf.append(", B.kanji_simei as kanji_simei");
		buf.append(", B.busyo_ryakusyo_mei as busyo_ryakusyo_mei");
		buf.append(" FROM ");
		buf.append(HcdbDef.D01_TBL + " A");
		buf.append(", " + HcdbDef.personalTbl + " B");
		buf.append(" WHERE A.KOUBO_ANKEN_ID=CAST(? AS CHAR(10))");
		buf.append(" AND A.SIMEI_NO = B.SIMEI_NO(+)");
		PEB_KouboSelectDao.KOUBO_SELECT_SQL = buf.toString();
	}

	/** S02_����_��]�E��e�[�u�����f�[�^���o����ׂ�SQL */
	private static final String KOUBO_KIBOUSYOKUSYU_SQL = "SELECT " + "A.KOUBO_ANKEN_ID AS KOUBO_ANKEN_ID" + ", A.SEQ_NO AS SEQ_NO" + ", B.SYOKU_NAME AS SYOKU_NAME" + ", B.SYOKU_CODE AS SYOKU_CODE"
			+ ", C.SENMON_NAME AS SENMON_NAME" + ", C.SENMON_CODE AS SENMON_CODE" + ", A.LEVEL_CODE AS LEVEL_CODE" + ", A.KOUSINBI AS KOUSINBI" + ", A.KOUSINJIKOKU AS KOUSINJIKOKU" + " FROM "
			+ HcdbDef.D02_TBL + " A" + ", " + HcdbDef.p_syokusyuTbl + " B" + ", " + HcdbDef.p_senmonTbl + " C" + " WHERE " + "A.KOUBO_ANKEN_ID=CAST(? AS CHAR(10))"
			+ " AND A.SYOKU_CODE = B.SYOKU_CODE(+)" + " AND A.SYOKU_CODE = C.SYOKU_CODE(+)" + " AND A.SENMON_CODE = C.SENMON_CODE(+)" + " ORDER BY SEQ_NO ASC";

	/**
	 * �R���X�g���N�^�B
	 * @param dataSource
	 */
	public PEB_KouboSelectDao() {
	}

	/**
	 * �Г�����Č�PDF�o�͗p�f�[�^�̎擾�B
	 * @param ankenId ���o�ΏۂƂ������Č�ID
	 * @return �Г�����Č�PDF�o�͗p�f�[�^�B
	 */
	public PEB_KouboAnkenBean doSelect(final String ankenId) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		PEB_KouboExtBean kouboBean = null;
		final PEB_KouboAnkenBean kouboAnkenBean = new PEB_KouboAnkenBean();

		try {
			con = PZZ040_SQLUtility.getConnection("");
			ps = con.prepareStatement(PEB_KouboSelectDao.KOUBO_SELECT_SQL);
			ps.setString(1, ankenId);
			rs = ps.executeQuery();

			if (rs.next()) {
				kouboBean = new PEB_KouboExtBean(rs, null);
				kouboAnkenBean.setKouboBean(kouboBean);
				this.selectKibouSyokusyu(ankenId, kouboAnkenBean);
			}
			return kouboAnkenBean;

		} catch (final SQLException e) {
			Log.error("", e);
			throw new EJBException(e);
		} catch (final NamingException e) {
			Log.error("", e);
			throw new EJBException(e);
		} finally {
			PZZ040_SQLUtility.closeConnection("", con, ps, rs);
		}
	}

	/**
	 * �w�肳�ꂽ����Č�ID�ɊY�������]�E���Ԃ��B
	 */
	private void selectKibouSyokusyu(final String ankenId, final PEB_KouboAnkenBean kouboPdfBean) throws SQLException, NamingException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = PZZ040_SQLUtility.getConnection("");
			ps = con.prepareStatement(PEB_KouboSelectDao.KOUBO_KIBOUSYOKUSYU_SQL);
			ps.setString(1, ankenId);
			rs = ps.executeQuery();

			while (rs.next()) {
				final PEB_KouboKibouSyokusyuBean ks = new PEB_KouboKibouSyokusyuBean(rs);
				kouboPdfBean.addKouboKibouSyokusyuBean(ks);
			}
		} finally {
			if (ps != null) {
				PZZ040_SQLUtility.closeConnection("", con, ps, rs);
			}
		}
	}
}
