/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.taglib;

import java.util.List;

import javax.servlet.jsp.JspException;

import jp.co.hisas.career.base.sosiki.bean.SosikiBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY_SosikiTag �N���X �@�\�����F �g�D�R�[�h���畔�����̖���\�����܂��B
 * 
 * </PRE>
 */
public class PCY_SosikiTag extends PCY_CodeTag {

	private Object kaisou = null;

	/**
	 * �K�w��ݒ肵�܂��B
	 * @param kaisou �K�w
	 */
	public void setKaisou(final Object kaisou) {
		this.kaisou = kaisou;
	}

	/**
	 * �K�w���擾���܂��B
	 * @return �K�w
	 */
	public Object getKaisou() {
		return this.kaisou;
	}

	/**
	 * �g�D�R�[�h���畔�����̖���\�����܂��B
	 * @see javax.servlet.jsp.tagext.Tag#doEndTag()
	 */
	public int doEndTag() throws JspException {
		if (this.getCode() != null) {
			try {
				if (this.getKaisou() == null) {
					this.setValue(SosikiBean.getSosikiByCode(this.getCode().toString().trim(), "")[2]);
				} else {
					final List sosikiKaisou = SosikiBean.getSosikiKaisouByCode(this.getCode().toString().trim(), this.getKaisou().toString());
					if (Integer.parseInt(this.getKaisou().toString()) < sosikiKaisou.size()) {
						final String[] sosikiInfo = (String[]) sosikiKaisou.get(Integer.parseInt(this.getKaisou().toString()));
						this.setValue(sosikiInfo[2]);
					} else {
						this.setValue("");
					}
				}
			} catch (final NumberFormatException e) {
				Log.error("", e);
			} catch (final Exception e) {
				Log.error("", e);
			}
		} else {
			this.setValue("");
		}
		return super.doEndTag();
	}

}
