/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_OubosyaJyohoBean;
import jp.co.hisas.career.department.offer.ejb.PEB_OubosyaJyohoEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_OubosyaJyohoEJBHome;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.pdf.PZE140_OubosyaJyohoPDF;

/**
 * <PRE>
 * 
 * �N���X���F PEB055_OubosyaJyohoPdfServlet �@�\�����F ����ҏ��Ɋւ���PDF���쐬����B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PEB059_OubosyaJyohoPdfServlet extends PEY010_ControllerServlet {
	/**
	 * request������̓f�[�^���擾���A�c�a�Ƀf�[�^���������܂��B
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws Exception {

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		/* request ����A�l���擾 */
		final String simeiNo = request.getParameter("simei_no");
		final String kouboAnkenId = PZZ010_CharacterUtil.changeAnkenIdLength(request.getParameter("koubo_anken_id"));
		/* session ����A�l���擾 */
		final HttpSession session = request.getSession(false);
		final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
		final String login_no = bean.getLogin_no();
		final String simei_no = bean.getSimei_no();

		if (simeiNo == null || simeiNo.length() <= 0) {
			this.redirectErrorView(request, response, loginuser);
			return null;
		}

		if (kouboAnkenId == null || kouboAnkenId.length() <= 0) {
			this.redirectErrorView(request, response, loginuser);
			return null;
		}

		try {
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PEB_OubosyaJyohoEJBHome home = (PEB_OubosyaJyohoEJBHome) fact.lookup(PEB_OubosyaJyohoEJBHome.class);
			final PEB_OubosyaJyohoEJB ejb = home.create();

			/* �f�[�^���擾���� */
			final PEB_OubosyaJyohoBean koubooubosyaBean = ejb.getOubosyaJyohoInfo(kouboAnkenId, simeiNo);

			if (koubooubosyaBean == null) {
				// �Y���f�[�^�����B
				throw new PEY_WarningException();
			}

			/* �t�@�C���ǂݍ��ݗp�o�b�t�@ */
			final byte[] buffer = new byte[4096];

			final PZE140_OubosyaJyohoPDF pdfMaker = new PZE140_OubosyaJyohoPDF();

			/* contentType���o�� */
			response.setContentType("application/pdf");

			/* �t�@�C�����̑��M(attachment������inline�ɕύX����΃C�����C���\��) */
			response.setHeader("Content-Disposition", "inline;");
			final String pdfFileName = this.makePdfFileName(loginuser);
			response.setHeader("Content-Disposition", "attachment; filename=\"" + pdfFileName + "\"");

			final ByteArrayOutputStream baos = new ByteArrayOutputStream();

			boolean pdfOutput = pdfMaker.makePDF(baos, koubooubosyaBean);

			if (!pdfOutput) {
				this.redirectErrorView(request, response, loginuser);
			}
			final ServletOutputStream out = response.getOutputStream();
			final ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
			if (bais != null) {
				int size;

				while ((size = bais.read(buffer)) != -1) {
					out.write(buffer, 0, size);
				}

				bais.close();
			}
			out.close();
			response.flushBuffer();

			/* ���샍�O�o�� */
			OutLogBean.sousaKojinJohoLog("SYA001", login_no, simei_no, kouboAnkenId);

			/* ���\�b�h�g���[�X�o�� */
			Log.method("", "OUT", "");
			return null;
		} catch (final Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		}

	}

	/**
	 * �G���[��ʂ�\������B
	 */
	private void redirectErrorView(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws ServletException {
		try {
			this.getServletConfig().getServletContext().getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		} catch (final IOException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * PDF�t�@�C�������쐬����B
	 * @param userinfo
	 * @return PDF�t�@�C�����B
	 */
	private String makePdfFileName(final PEY_PersonalBean userinfo) {
		final StringBuffer buf = new StringBuffer();
		buf.append(userinfo.getSimeiNo());
		buf.append("_");
		final SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		buf.append(df.format(Calendar.getInstance().getTime()));
		buf.append("_");
		buf.append("VEB055");
		buf.append(".pdf");
		return buf.toString();
	}

}
