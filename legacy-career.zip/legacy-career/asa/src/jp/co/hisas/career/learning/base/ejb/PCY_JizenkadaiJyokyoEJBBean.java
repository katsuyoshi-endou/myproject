/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJB;
import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJBHome;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.valuebean.PCY_JizenkadaiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_JizenkadaiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * ���O�ۑ�󋵂ւ̑�����s���܂��B<br>
 * ADD 2017/05/15 COMTURE VCA350_�{�l���C���iver.02-00�j
 * @ejb.bean name="PCY_JizenkadaiJyokyoEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_JizenkadaiJyokyoEJBBean implements SessionBean {

    private SessionContext context = null;

    /**
     * �N���X�}�X�^���v���C�}���[�L�[�Ō������Č��ʂ�Ԃ��܂��B �������ʂ����������ꍇ�� null ��Ԃ��܂��B
     * @param jizenkadaiJyokyoBean ��������
     * @param loginuser ���O�C�����[�U
     * @return ��������
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_JizenkadaiJyokyoBean doSelectByPrimaryKey(final PCY_JizenkadaiJyokyoBean jizenkadaiJyokyoBean,
            final PCY_PersonalBean loginuser) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "IN", "");

            PCY_JizenkadaiJyokyoBean ret = null;
            final StringBuilder sql = new StringBuilder();
            sql.append("SELECT " + PCY_JizenkadaiBean.getColumns("M") + ", ");
            sql.append(PCY_JizenkadaiJyokyoBean.getColumns("T"));
            sql.append("  FROM ");
            sql.append(HcdbDef.L02_JIZENKADAI_TBL);
            sql.append(" M, ");
            sql.append(HcdbDef.L15_JIZENKADAI_JYOKYO_TBL);
            sql.append(" T");
            sql.append("  WHERE T.KAMOKU_CODE=?");
            sql.append("    AND T.CLASS_CODE=?");
            sql.append("    AND T.SIMEI_NO=?");
            sql.append("    AND T.KAMOKU_CODE=M.KAMOKU_CODE");
            sql.append("    AND T.CLASS_CODE=M.CLASS_CODE");

            // �R�l�N�V�����擾
            con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

            // �������s
            ps = con.prepareStatement(sql.toString());
            ps.setString(1, jizenkadaiJyokyoBean.getKamokuCode());
            ps.setString(2, jizenkadaiJyokyoBean.getClassCode());
            ps.setString(3, jizenkadaiJyokyoBean.getSimeiNo());

            rs = ps.executeQuery();

            if (rs.next()) {
                ret = new PCY_JizenkadaiJyokyoBean(rs, "M", "T");
            }

            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "OUT", "");

            return ret;

        } catch (final NamingException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } catch (final SQLException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } catch (final RuntimeException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;

        } finally {
            PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
        }
    }

    /**
     * ���O�ۑ�󋵂��쐬���܂��B
     * @param jizenkadaiJyokyoBean �쐬���e
     * @param loginuser ���O�C�����[�U
     * @throws PCY_WarningException �C���T�[�g�� SQLException �����������ꍇ�A�y�я����������قȂ����ꍇ
     * @param RemoteException RemoteException
     * @param CreateException CreateException
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public void doInsert(final PCY_JizenkadaiJyokyoBean jizenkadaiJyokyoBean, final PCY_PersonalBean loginuser)
            throws PCY_WarningException, RemoteException, CreateException {
        Connection con = null;
        PreparedStatement ps = null;
        try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "IN", "");

            // SQL�쐬
            final StringBuilder sql = new StringBuilder();
            sql.append("INSERT INTO ");
            sql.append(HcdbDef.L15_JIZENKADAI_JYOKYO_TBL);
            sql.append(" (");
            sql.append("    KAMOKU_CODE,");
            sql.append("    CLASS_CODE,");
            sql.append("    SIMEI_NO,");
            sql.append("    JIZENKADAI_FILENAME,");
            sql.append("    JIZENKADAI_CONTENT_TYPE,");
            sql.append("    JIZENKADAI,");
            sql.append("    UPLOADBI,");
            sql.append("    UPLOADJIKOKU,");
            sql.append("    UPLOADSYA,");
            sql.append("    DOWNLOADBI,");
            sql.append("    DOWNLOADJIKOKU,");
            sql.append("    DOWNLOADSYA)");
            sql.append("  VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ? , ? , ? , ? )");

            // �R�l�N�V�����擾
            con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

            // �f�o�b�O���O���o��
            Log.debug(sql.toString());

            // �X�V���s
            ps = con.prepareStatement(sql.toString());

            ps.setString(1, jizenkadaiJyokyoBean.getKamokuCode());
            ps.setString(2, jizenkadaiJyokyoBean.getClassCode());
            ps.setString(3, jizenkadaiJyokyoBean.getSimeiNo());
            ps.setString(4, jizenkadaiJyokyoBean.getJizenkadaiFilename());
            ps.setString(5, jizenkadaiJyokyoBean.getJizenkadaiContentType());
            ps.setNull(6, java.sql.Types.BLOB);
            ps.setString(7, jizenkadaiJyokyoBean.getUploadbi());
            ps.setString(8, jizenkadaiJyokyoBean.getUploadjikoku());
            ps.setString(9, jizenkadaiJyokyoBean.getUploadsya());
            ps.setString(10, jizenkadaiJyokyoBean.getDownloadbi());
            ps.setString(11, jizenkadaiJyokyoBean.getDownloadjikoku());
            ps.setString(12, jizenkadaiJyokyoBean.getDownloadsya());
            int count = ps.executeUpdate();

            if (count != 1) {
                this.context.setRollbackOnly();
                throw new PCY_WarningException();
            }

            // ���O�ۑ�t�@�C���̍X�V
            updateFile(jizenkadaiJyokyoBean, loginuser);

            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "OUT", "");

        } catch (final NamingException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } catch (final SQLException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } catch (final RuntimeException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;

        } catch (final CreateException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;

        } catch (final RemoteException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;

        } catch (final Exception e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } finally {
            PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
        }
    }

    /**
     * �v���C�}���[�L�[���L�[�Ƃ��Ď��O�ۑ�󋵂��폜���܂��B
     * @param jizenkadaiJyokyoBean �폜����
     * @param loginuser ���O�C�����[�U
     * @return �폜����
     * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍ폜����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doDeleteByPrimaryKey(final PCY_JizenkadaiJyokyoBean jizenkadaiJyokyoBean,
            final PCY_PersonalBean loginuser) throws PCY_WarningException {
        Connection con = null;
        PreparedStatement ps = null;
        try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "IN", "");

            final StringBuilder sql = new StringBuilder();
            sql.append("DELETE FROM ");
            sql.append(HcdbDef.L15_JIZENKADAI_JYOKYO_TBL);
            sql.append("  WHERE KAMOKU_CODE=?");
            sql.append("    AND CLASS_CODE=?");
            sql.append("    AND SIMEI_NO=?");

            // �R�l�N�V�����擾
            con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

            // �f�o�b�O���O���o��
            Log.debug(sql.toString());

            // �X�V���s
            ps = con.prepareStatement(sql.toString());
            ps.setString(1, jizenkadaiJyokyoBean.getKamokuCode());
            ps.setString(2, jizenkadaiJyokyoBean.getClassCode());
            ps.setString(3, jizenkadaiJyokyoBean.getSimeiNo());
            int count = ps.executeUpdate();

            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "OUT", "");

            return count;

        } catch (final NamingException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } catch (final SQLException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } catch (final RuntimeException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;

        } finally {
            PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
        }
    }

    /**
     * ���O�ۑ�󋵂��폜���܂��B
     * @param mousikomiBeans �폜����
     * @param loginuser ���O�C�����[�U
     * @return �폜����
     * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍ폜����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doDelete(final PCY_MousikomiJyokyoBean[] mousikomiBeans, final PCY_PersonalBean loginuser)
            throws PCY_WarningException {
        Connection con = null;
        PreparedStatement ps = null;
        try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "IN", "");

            int count = 0;
            PCY_JizenkadaiJyokyoBean jizenkadaiJyokyoBean = new PCY_JizenkadaiJyokyoBean();
            for (int i = 0; i < mousikomiBeans.length; i++) {
                // �����ݒ�
                PCY_MousikomiJyokyoBean paramBean = mousikomiBeans[i];
                jizenkadaiJyokyoBean.setKamokuCode(paramBean.getKamokuCode());
                jizenkadaiJyokyoBean.setClassCode(paramBean.getClassCode());
                jizenkadaiJyokyoBean.setSimeiNo(paramBean.getSimeiNo());

                // �폜
                count += this.doDeleteByPrimaryKey(jizenkadaiJyokyoBean, loginuser);
            }

            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "OUT", "");

            return count;

        } catch (final RuntimeException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;

        } finally {
            PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
        }
    }

    /**
     * ���O�ۑ�󋵂��X�V���܂��B
     * @param paramBean �X�V���e
     * @param loginuser ���O�C�����[�U
     * @return �X�V����
     * @throws PCY_WarningException �C���T�[�g�� SQLException �����������ꍇ�A�y�я����������قȂ����ꍇ
     * @param RemoteException RemoteException
     * @param CreateException CreateException
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdate(final PCY_JizenkadaiJyokyoBean paramBean, final PCY_PersonalBean loginuser)
            throws PCY_WarningException, RemoteException, CreateException {
        Connection con = null;
        PreparedStatement ps = null;
        try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "IN", "");

            // SQL�쐬
            final StringBuilder sql = new StringBuilder();
            sql.append("UPDATE ");
            sql.append(HcdbDef.L15_JIZENKADAI_JYOKYO_TBL);
            sql.append("    SET JIZENKADAI_FILENAME=?,");
            sql.append("        JIZENKADAI_CONTENT_TYPE=?,");
            sql.append("        JIZENKADAI=?,");
            sql.append("        UPLOADBI=?,");
            sql.append("        UPLOADJIKOKU=?,");
            sql.append("        UPLOADSYA=?,");
            sql.append("        DOWNLOADBI=null,");
            sql.append("        DOWNLOADJIKOKU=null,");
            sql.append("        DOWNLOADSYA=null");
            sql.append("  WHERE KAMOKU_CODE=?");
            sql.append("    AND CLASS_CODE=?");
            sql.append("    AND SIMEI_NO=?");

            // �R�l�N�V�����擾
            con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

            // �f�o�b�O���O���o��
            Log.debug(sql.toString());

            // �X�V���s
            ps = con.prepareStatement(sql.toString());

            ps.setString(1, paramBean.getJizenkadaiFilename());
            ps.setString(2, paramBean.getJizenkadaiContentType());
            ps.setNull(3, java.sql.Types.BLOB);
            ps.setString(4, paramBean.getUploadbi());
            ps.setString(5, paramBean.getUploadjikoku());
            ps.setString(6, paramBean.getUploadsya());
            ps.setString(7, paramBean.getKamokuCode());
            ps.setString(8, paramBean.getClassCode());
            ps.setString(9, paramBean.getSimeiNo());
            int count = ps.executeUpdate();

            if (count != 1) {
                this.context.setRollbackOnly();
                throw new PCY_WarningException();
            }

            // ���O�ۑ�t�@�C���̍X�V
            updateFile(paramBean, loginuser);

            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "OUT", "");

            return count;

        } catch (final NamingException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } catch (final SQLException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } catch (final RuntimeException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;

        } catch (final CreateException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;

        } catch (final RemoteException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;

        } catch (final Exception e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } finally {
            PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
        }
    }

    /**
     * ���O�ۑ�󋵂��X�V���܂��B ���_�E�����[�h��
     * @param jizenkadaiJyokyoBean �X�V���e
     * @param loginuser ���O�C�����[�U
     * @return �X�V����
     * @throws PCY_WarningException �C���T�[�g�� SQLException �����������ꍇ�A�y�я����������قȂ����ꍇ
     * @param RemoteException RemoteException
     * @param CreateException CreateException
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdateForDownload(final PCY_JizenkadaiJyokyoBean jizenkadaiJyokyoBean, final PCY_PersonalBean loginuser)
            throws PCY_WarningException, RemoteException, CreateException {
        Connection con = null;
        PreparedStatement ps = null;
        try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "IN", "");

            // SQL�쐬
            final StringBuilder sql = new StringBuilder();
            sql.append("UPDATE ");
            sql.append(HcdbDef.L15_JIZENKADAI_JYOKYO_TBL);
            sql.append("    SET DOWNLOADBI=?,");
            sql.append("        DOWNLOADJIKOKU=?,");
            sql.append("        DOWNLOADSYA=?");
            sql.append("  WHERE KAMOKU_CODE=?");
            sql.append("    AND CLASS_CODE=?");
            sql.append("    AND SIMEI_NO=?");

            // �R�l�N�V�����擾
            con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

            // �f�o�b�O���O���o��
            Log.debug(sql.toString());

            // �X�V���s
            ps = con.prepareStatement(sql.toString());

            ps.setString(1, jizenkadaiJyokyoBean.getDownloadbi());
            ps.setString(2, jizenkadaiJyokyoBean.getDownloadjikoku());
            ps.setString(3, jizenkadaiJyokyoBean.getDownloadsya());
            ps.setString(4, jizenkadaiJyokyoBean.getKamokuCode());
            ps.setString(5, jizenkadaiJyokyoBean.getClassCode());
            ps.setString(6, jizenkadaiJyokyoBean.getSimeiNo());
            int count = ps.executeUpdate();

            if (count != 1) {
                this.context.setRollbackOnly();
                throw new PCY_WarningException();
            }

            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "OUT", "");

            return count;

        } catch (final NamingException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } catch (final SQLException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } catch (final RuntimeException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;

        } catch (final Exception e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } finally {
            PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
        }
    }

    /**
     * ���O�ۑ�t�@�C���̍X�V
     * @param jizenkadaiJyokyoBean �X�V���e
     * @param loginuser ���O�C�����[�U
     * @throws Exception ��O
     */
    private void updateFile(final PCY_JizenkadaiJyokyoBean jizenkadaiJyokyoBean, final PCY_PersonalBean loginuser)
            throws Exception {

        if (jizenkadaiJyokyoBean.getJizenkadai() == null) {
            return;
        }

        // �J�����Z�b�g
        final String[] columns = { "JIZENKADAI" };

        // �}���l�Z�b�g
        final String[] values = { "BLOB_DATA" };

        // �L�[
        final String[] primaryKey = { "KAMOKU_CODE", "CLASS_CODE", "SIMEI_NO" };

        // �L�[�l
        final String[] keyValue =
                { jizenkadaiJyokyoBean.getKamokuCode(), jizenkadaiJyokyoBean.getClassCode(),
                        jizenkadaiJyokyoBean.getSimeiNo() };

        // EJB�擾
        final EJBHomeFactory fact = EJBHomeFactory.getInstance();
        final PYF_BlobDBAccessEJBHome blobHome = (PYF_BlobDBAccessEJBHome)fact.lookup(PYF_BlobDBAccessEJBHome.class);
        final PYF_BlobDBAccessEJB blobEjb = blobHome.create();

        // �o�C�i���f�[�^ (��U�AString�̔z��Ɋi�[����)
        blobEjb.UpdateBLOB(loginuser.getSimeiNo(), HcdbDef.L15_JIZENKADAI_JYOKYO_TBL, columns, values,
                jizenkadaiJyokyoBean.getJizenkadai(), primaryKey, keyValue);
    }

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate() throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove() throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate() throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate() throws EJBException, RemoteException {
    }
}
