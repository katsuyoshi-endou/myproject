/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboAnkenBean;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenEJBHome;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �T�v�F �Г�����Č��̃f�[�^���擾����B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PEB070_KouboAnkenHyoujiServlet extends PEY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		PEB_KouboAnkenBean kouboAnkenData = null;
		final String kouboAnkenId = PZZ010_CharacterUtil.changeAnkenIdLength(request.getParameter("koubo_anken_id"));

		kouboAnkenData = new PEB_KouboAnkenBean();

		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEB_KouboAnkenEJBHome kouboAnkenEJBHome = (PEB_KouboAnkenEJBHome) fact.lookup(PEB_KouboAnkenEJBHome.class);
		final PEB_KouboAnkenEJB kouboAnkenEJB = kouboAnkenEJBHome.create();
		kouboAnkenData = kouboAnkenEJB.getKouboAnkenInfo(kouboAnkenId);

		request.setAttribute("kouboAnkenBean", kouboAnkenData);

		request.setAttribute("hide_flg", request.getParameter("hide_flg"));
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");
		return this.getForwardPath();
	}
}
