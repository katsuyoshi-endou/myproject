/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.personal.maintenance.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.personal.maintenance.bean.BumonKanriBean;
import jp.co.hisas.career.personal.maintenance.ejb.BumonKanriEJB;
import jp.co.hisas.career.personal.maintenance.ejb.BumonKanriEJBHome;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.CommonParameter;

public class KnowledgeKanriServlet extends HttpServlet {
	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	private static final String ACTION_KEY_INIT = "INIT";

	private static final String ACTION_KEY_ADD = "ADD";

	private static final String ACTION_KEY_DELETE = "DELETE";

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException,
			ServletException {
		String loginNo = null;
		try {
			Log.method(loginNo, "IN", "");

			/* session�X�R�[�v��Beans���擾���� */
			final HttpSession session = request.getSession(false);

			if (session == null) {
				/* JSP�y�[�W���Ăяo�� */
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
				loginNo = bean.getLogin_no();

				String actionKey = request.getParameter("ACTION_KEY");
				if (actionKey == null || actionKey.length() == 0) {
					actionKey = KnowledgeKanriServlet.ACTION_KEY_INIT;
				}

				// EJB�擾
				final BumonKanriEJBHome my_home = (BumonKanriEJBHome) EJBHomeFactory.getInstance().lookup(
						BumonKanriEJBHome.class);
				final BumonKanriEJB userSession = my_home.create();

				if (actionKey.equals(KnowledgeKanriServlet.ACTION_KEY_INIT)) {
					// �g�D���擾
					Log.performance(loginNo, true, "");
					final LinkedHashMap soshikiMap = userSession.getSoshikiList(loginNo,
							Integer.parseInt(CommonParameter.getValue("Base", "KNOWLEDGE_SEARCH_SOSIKI_KAISO_MIN")),
							Integer.parseInt(CommonParameter.getValue("Base", "KNOWLEDGE_SEARCH_SOSIKI_KAISO_MAX")));
					Log.performance(loginNo, false, "");
					session.setAttribute("knowledgeSoshikiMap", soshikiMap);

					// �ŐV���擾
					Log.performance(loginNo, true, "");
					final ArrayList kanriList = userSession.getKnowledgeKanriList(loginNo);
					Log.performance(loginNo, false, "");
					session.setAttribute("knowledgeKanriList", kanriList);
				} else if (actionKey.equals(KnowledgeKanriServlet.ACTION_KEY_ADD)) {
					// �ǉ�����
					final BumonKanriBean kanri = new BumonKanriBean();
					kanri.setShimeiNo((String) request.getParameter("shimeiNo"));
					kanri.setSoshikiCode((String) request.getParameter("soshikiCode"));
					Log.performance(loginNo, true, "");
					userSession.addKnowledgeKanri(loginNo, kanri);
					Log.performance(loginNo, false, "");

					// �ŐV���擾
					Log.performance(loginNo, true, "");
					final ArrayList kanriList = userSession.getKnowledgeKanriList(loginNo);
					Log.performance(loginNo, false, "");
					session.setAttribute("knowledgeKanriList", kanriList);
				} else if (actionKey.equals(KnowledgeKanriServlet.ACTION_KEY_DELETE)) {
					// �폜����
					final BumonKanriBean kanri = new BumonKanriBean();
					kanri.setShimeiNo((String) request.getParameter("shimeiNo"));
					kanri.setSoshikiCode((String) request.getParameter("soshikiCode"));
					Log.performance(loginNo, true, "");
					userSession.deleteKnowledgeKanri(loginNo, kanri);
					Log.performance(loginNo, false, "");

					// �ŐV���擾
					Log.performance(loginNo, true, "");
					final ArrayList kanriList = userSession.getKnowledgeKanriList(loginNo);
					Log.performance(loginNo, false, "");
					session.setAttribute("knowledgeKanriList", kanriList);
				}

				final RequestDispatcher rd = this.ctx
						.getRequestDispatcher("/view/personal/maintenance/VAX170_KnowledgeKanriMain.jsp");
				rd.forward(request, response);

				Log.method(loginNo, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(loginNo, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}
}
