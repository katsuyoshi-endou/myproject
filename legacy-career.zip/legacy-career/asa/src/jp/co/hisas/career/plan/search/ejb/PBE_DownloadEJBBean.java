/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.search.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.plan.search.bean.PBE_DownloadCsvSkillBean;
import jp.co.hisas.career.plan.search.bean.PBE_SosikiBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PBE_DownloadEJBBean�N���X �@�\�����F �e��Ώۃ}�X�^����ꗗ���擾���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="PBE_TaisyoEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PBE_DownloadEJBBean implements SessionBean {

	/** �g�D�}�X�^�e�[�u�� */
	private static final String T19_SOSIKI_TBL = HcdbDef.sosikiTbl;

	/** �g�D�}�X�^�J�����F�g�D�R�[�h */
	private static final String SOSIKI_CODE_T19COL = HcdbDef.T19_SOSIKI_COLUMNS[0];

	/** �g�D�}�X�^�J�����F�g�D�� */
	private static final String SOSIKI_MEI_T19COL = HcdbDef.T19_SOSIKI_COLUMNS[1];

	/** �g�D�}�X�^�J�����F�������̖� */
	private static final String BUSYO_RYAKUSYO_T19COL = HcdbDef.T19_SOSIKI_COLUMNS[2];

	/** �g�D�}�X�^�J�����F��ʑg�D�R�[�h */
	private static final String JOUI_SOSIKI_CODE_T19COL = HcdbDef.T19_SOSIKI_COLUMNS[3];

	/** �g�D�}�X�^�J�����F�K�w */
	private static final String KAISOU_T19COL = HcdbDef.T19_SOSIKI_COLUMNS[4];

	/** �g�D�}�X�^�J�����F���ʑg�D�L�� */
	private static final String KAI_SOSIKI_UMU_T19COL = HcdbDef.T19_SOSIKI_COLUMNS[5];

	/** �p�[�\�i���e�[�u�� */
	private static final String T01_PERSONAL_TBL = HcdbDef.personalTbl;

	/** �p�[�\�i���J�����F����NO */
	private static final String SIMEI_NO_T01COL = HcdbDef.t01_column[0];

	/** �p�[�\�i���J�����F�������� */
	private static final String KANJI_SIMEI_T01COL = HcdbDef.t01_column[4];

	/** �p�[�\�i���J�����F�J�i���� */
	private static final String KANA_SIMEI_T01COL = HcdbDef.t01_column[5];

	/** �p�[�\�i���J�����F�p������ */
	private static final String EIJI_SIMEI_T01COL = HcdbDef.t01_column[6];

	/** �p�[�\�i���J�����F�g�D�R�[�h */
	private static final String SOSIKI_CODE_T01COL = HcdbDef.t01_column[11];

	/** �p�[�\�i���J�����F��E�R�[�h */
	private static final String YAKUSYOKU_CODE_T01COL = HcdbDef.t01_column[12];

	/** �p�[�\�i���J�����F�{���t���O */
	private static final String HONMU_FLG_T01COL = HcdbDef.t01_column[2];

	/** �p�[�\�i���J�����F���E�ސE�t���O */
	private static final String GENSYOKU_TAISYOKU_FLG_T01COL = HcdbDef.t01_column[19];

	/** �A�Z�X�����g�f�f�e�[�u�� */
	private static final String P21_ASSESSMENT_SINDAN_TBL = HcdbDef.p_assessment_sindanTbl;

	/** �A�Z�X�����g�f�f�J�����F�f�f�� */
	private static final String SINDANSYA_P21COL = HcdbDef.p21_column[0];

	/** �A�Z�X�����g�f�f�J�����F�E��R�[�h */
	private static final String SYOKU_CODE_P21COL = HcdbDef.p21_column[1];

	/** �A�Z�X�����g�f�f�J�����F���R�[�h */
	private static final String SENMON_CODE_P21COL = HcdbDef.p21_column[2];

	/** �A�Z�X�����g�f�f�J�����F���x���R�[�h */
	private static final String LEVEL_CODE_P21COL = HcdbDef.p21_column[3];

	/** �A�Z�X�����g�f�f�J�����F���{�� */
	private static final String JISSI_KAISU_P21COL = HcdbDef.p21_column[4];

	/** �A�Z�X�����g�f�f�J�����F���{�N���� */
	private static final String JISSI_NENGAPPI_P21COL = HcdbDef.p21_column[5];

	/** ��E�}�X�^�e�[�u�� */
	private static final String T15_YAKUSYOKU_TBL = HcdbDef.yakusyokuTbl;

	/** ��E�}�X�^�J�����F��E�R�[�h */
	private static final String YAKUSYOKU_CODE_T15COL = HcdbDef.yakusyoku_code;

	/** �E��}�X�^�e�[�u�� */
	private static final String P01_C_SYOKUSYU_TBL = HcdbDef.p_syokusyuTbl;

	/** �E��}�X�^�J�����F�E��R�[�h */
	private static final String SYOKU_CODE_P01COL = HcdbDef.p01_column[0];

	/** �E��}�X�^�J�����F�E�햼�� */
	private static final String SYOKU_NAME_P01COL = HcdbDef.p01_column[1];

	/** ���x�����̃e�[�u�� */
	private static final String P12_C_LEVEL_NAME_TBL = HcdbDef.p_level_nameTbl;

	/** ���x�����̃e�[�u���J�����F���x���R�[�h */
	private static final String LEVEL_CODE_P12COL = HcdbDef.p12_column[0];

	/** ���x�����̃e�[�u���J�����F���x������ */
	private static final String LEVEL_NAME_P12COL = HcdbDef.p12_column[1];

	/** ��啪��}�X�^�e�[�u�� */
	private static final String P02_C_SENMONBUNYA_TBL = HcdbDef.p_senmonTbl;

	/** ��啪��}�X�^�J�����F�E��R�[�h */
	private static final String SYOKU_CODE_P02COL = HcdbDef.p02_column[0];

	/** ��啪��}�X�^�J�����F���R�[�h */
	private static final String SENMON_CODE_P02COL = HcdbDef.p02_column[1];

	/** ��啪��}�X�^�J�����F��啪�얼�� */
	private static final String SENMON_NAME_P02COL = HcdbDef.p02_column[2];

	/** �Ɩ��o���f�f�]���e�[�u�� */
	private static final String P22_GYOMU_HYOKA_TBL = HcdbDef.p_gyomu_hyokaTbl;

	/** �Ɩ��o���f�f�]���J�����F�f�f�� */
	private static final String SINDANSYA_P22COL = HcdbDef.p22_column[0];

	/** �Ɩ��o���f�f�]���J�����F�E��R�[�h */
	private static final String SYOKU_CODE_P22COL = HcdbDef.p22_column[1];

	/** �Ɩ��o���f�f�]���J�����F���R�[�h */
	private static final String SENMON_CODE_P22COL = HcdbDef.p22_column[2];

	/** �Ɩ��o���f�f�]���J�����F���x���R�[�h */
	private static final String LEVEL_CODE_P22COL = HcdbDef.p22_column[3];

	/** �Ɩ��o���f�f�]���J�����F���{�� */
	private static final String JISSI_KAISU_P22COL = HcdbDef.p22_column[4];

	/** �Ɩ��o���f�f�]���J�����F�敪 */
	private static final String KUBUN_P22COL = HcdbDef.p22_column[5];

	/** �Ɩ��o���f�f�]���J�����F�]���� */
	private static final String HYOKASYA_P22COL = HcdbDef.p22_column[6];

	/** �Ɩ��o���f�f�]���J�����F�B���x�敪�R�[�h */
	private static final String TASSEIDO_KUBUN_CODE_P22COL = HcdbDef.p22_column[7];

	/** �Ɩ��o���f�f�]���J�����F�B���x�w�W�R�[�h */
	private static final String TASSEIDO_SIHYO_CODE_P22COL = HcdbDef.p22_column[8];

	/** �Ɩ��o���f�f�]���J�����F�I���t���O */
	private static final String SENTAKU_FLG_P22COL = HcdbDef.p22_column[9];

	/** �X�L���f�f�]���e�[�u�� */
	private static final String P23_SKILL_HYOKA_TBL = HcdbDef.p_skill_hyokaTbl;

	/** �X�L���f�f�]���J�����F�f�f�� */
	private static final String SINDANSYA_P23COL = HcdbDef.p23_column[0];

	/** �X�L���f�f�]���J�����F�E��R�[�h */
	private static final String SYOKU_CODE_P23COL = HcdbDef.p23_column[1];

	/** �X�L���f�f�]���J�����F���R�[�h */
	private static final String SENMON_CODE_P23COL = HcdbDef.p23_column[2];

	/** �X�L���f�f�]���J�����F���x���R�[�h */
	private static final String LEVEL_CODE_P23COL = HcdbDef.p23_column[3];

	/** �X�L���f�f�]���J�����F���{�� */
	private static final String JISSI_KAISU_P23COL = HcdbDef.p23_column[4];

	/** �X�L���f�f�]���J�����F�敪 */
	private static final String KUBUN_P23COL = HcdbDef.p23_column[5];

	/** �X�L���f�f�]���J�����F�]���� */
	private static final String HYOKASYA_P23COL = HcdbDef.p23_column[6];

	/** �X�L���f�f�]���J�����F�X�L���R�[�h */
	private static final String SKILL_CODE_P23COL = HcdbDef.p23_column[7];

	/** �X�L���f�f�]���J�����F�X�R�A */
	private static final String SCORE_P23COL = HcdbDef.p23_column[8];

	/** �X�L���}�X�^�e�[�u�� */
	private static final String P03_C_SKILL_KOMOKU_TBL = HcdbDef.p_skill_komokuTbl;

	/** �X�L���}�X�^�J�����F�E��R�[�h */
	private static final String SYOKU_CODE_P03COL = HcdbDef.p03_column[0];

	/** �X�L���}�X�^�J�����F���R�[�h */
	private static final String SENMON_CODE_P03COL = HcdbDef.p03_column[1];

	/** �X�L���}�X�^�J�����F�X�L���R�[�h */
	private static final String SKILL_CODE_P03COL = HcdbDef.p03_column[2];

	/** �X�L���}�X�^�J�����F�X�L������ */
	private static final String SKILL_NAME_P03COL = HcdbDef.p03_column[3];

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}

	/**
	 * �g�D�e�[�u������ꗗ���擾���܂��B �߂�l�͑g�D��񂪊i�[���ꂽ �g�D ValueBean �ł��B
	 * @param loginuser ���O�C�����[�U���
	 * @param kaiso �K�w�̍i������
	 * @return �Ώۑg�D���̈ꗗ
	 * @exception NamingException ���O�����Ɏ��s�����ꍇ
	 * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
	 * @throws SQLException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PBE_SosikiBean[] getSosiki(final PEY_PersonalBean loginuser, final String kaisoMax, final String kaisoMin) throws NamingException, SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		PBE_SosikiBean sosiki = null;
		ResultSet rs = null;
		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final String sibori = " WHERE " + PBE_DownloadEJBBean.KAISOU_T19COL + " <= ? AND " + PBE_DownloadEJBBean.KAISOU_T19COL + " >= ? ";

			final StringBuffer sql = new StringBuffer();

			sql.append("SELECT ").append(PBE_DownloadEJBBean.SOSIKI_CODE_T19COL + ",").append(PBE_DownloadEJBBean.SOSIKI_MEI_T19COL + ",").append(PBE_DownloadEJBBean.BUSYO_RYAKUSYO_T19COL + ",")
					.append(PBE_DownloadEJBBean.JOUI_SOSIKI_CODE_T19COL + ",").append(PBE_DownloadEJBBean.KAISOU_T19COL + ",").append(PBE_DownloadEJBBean.KAI_SOSIKI_UMU_T19COL).append(" FROM ")
					.append(PBE_DownloadEJBBean.T19_SOSIKI_TBL).append(sibori).append(" ORDER BY " + PBE_DownloadEJBBean.SOSIKI_CODE_T19COL);

			/* �f�o�b�O���O */
			Log.debug(sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");
			ps = con.prepareStatement(sql.toString());
			ps.setInt(1, Integer.parseInt(kaisoMax));
			ps.setInt(2, Integer.parseInt(kaisoMin));

			rs = ps.executeQuery();

			final Vector ret = new Vector();

			while (rs.next()) {
				sosiki = new PBE_SosikiBean(rs, "");
				ret.add(sosiki);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return (PBE_SosikiBean[]) ret.toArray(new PBE_SosikiBean[0]);
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * �g�D�e�[�u������ꗗ���擾���܂��B �߂�l�͑g�D��񂪊i�[���ꂽ �g�D ValueBean �ł��B
	 * @param loginuser ���O�C�����[�U���
	 * @param kaisoMax �ΏۂƂ���g�D�K�w���
	 * @param kaisoMin �ΏۂƂ���g�D�K�w����
	 * @return �Ώۑg�D���̈ꗗ
	 * @exception NamingException ���O�����Ɏ��s�����ꍇ
	 * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
	 * @throws SQLException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PBE_SosikiBean[] getKaiSosiki(final String login_no, final String kaisoMax, final String kaisoMin) throws NamingException, SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		PBE_SosikiBean sosiki = null;
		ResultSet ret = null;
		PreparedStatement tmpPstmt = null;
		ResultSet tmpRet = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(login_no, "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(login_no);

			// ���[�U�̏����g�D���X�g���擾
			String sql = "SELECT " + PBE_DownloadEJBBean.SOSIKI_CODE_T01COL + " FROM " + PBE_DownloadEJBBean.T01_PERSONAL_TBL + " WHERE " + PBE_DownloadEJBBean.SIMEI_NO_T01COL + " = ?";

			pstmt = con.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, login_no);
			ret = pstmt.executeQuery();
			final ArrayList sosikiList = new ArrayList();
			while (ret.next()) {
				final String sosikiCode = ret.getString(1);

				final String tmpSql = "SELECT " + PBE_DownloadEJBBean.SOSIKI_CODE_T19COL + " FROM " + "(SELECT * FROM " + PBE_DownloadEJBBean.T19_SOSIKI_TBL + " WHERE "
						+ PBE_DownloadEJBBean.KAISOU_T19COL + " <= ? AND " + PBE_DownloadEJBBean.KAISOU_T19COL + " >= ?) " + "START WITH " + PBE_DownloadEJBBean.SOSIKI_CODE_T19COL + " = ? "
						+ "CONNECT BY PRIOR " + PBE_DownloadEJBBean.SOSIKI_CODE_T19COL + " =  " + PBE_DownloadEJBBean.JOUI_SOSIKI_CODE_T19COL;
				tmpPstmt = con.prepareStatement(tmpSql);
				tmpPstmt.clearParameters();

				tmpPstmt.setInt(1, Integer.parseInt(kaisoMax));
				tmpPstmt.setInt(2, Integer.parseInt(kaisoMin));

				tmpPstmt.setString(3, sosikiCode);
				tmpRet = tmpPstmt.executeQuery();
				while (tmpRet.next()) {
					sosikiList.add(tmpRet.getString(1));
				}
				PZZ040_SQLUtility.closeConnection(login_no, null, tmpPstmt, tmpRet);
			}
			PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, ret);

			if (sosikiList.size() < 1) {
				return null;
			}

			String where = " WHERE " + PBE_DownloadEJBBean.SOSIKI_CODE_T19COL + " IN ( ? ";
			for (int i = 1; i < sosikiList.size(); i++) {
				where += ", ? ";
			}
			where += " ) ";

			sql = "SELECT " + PBE_DownloadEJBBean.SOSIKI_CODE_T19COL + ", " + PBE_DownloadEJBBean.SOSIKI_MEI_T19COL + ", BUSYO_RYAKUSYO_MEI, " + PBE_DownloadEJBBean.JOUI_SOSIKI_CODE_T19COL + ", "
					+ PBE_DownloadEJBBean.KAISOU_T19COL + ", " + PBE_DownloadEJBBean.KAI_SOSIKI_UMU_T19COL + ", SOSIKI_MEI_KANA, SOSIKI_MEI_EIJI " + "FROM " + PBE_DownloadEJBBean.T19_SOSIKI_TBL
					+ where + " ORDER BY " + PBE_DownloadEJBBean.SOSIKI_CODE_T19COL;

			pstmt = con.prepareStatement(sql);
			pstmt.clearParameters();
			for (int i = 0; i < sosikiList.size(); i++) {
				pstmt.setString(i + 1, (String) sosikiList.get(i));
			}
			ret = pstmt.executeQuery();

			final Vector result = new Vector();

			while (ret.next()) {
				sosiki = new PBE_SosikiBean(ret, "");
				result.add(sosiki);
			}

			Log.method(login_no, "OUT", "");

			return (PBE_SosikiBean[]) result.toArray(new PBE_SosikiBean[0]);
		} catch (final NamingException e) {
			Log.error(login_no, e);
			throw e;
		} catch (final SQLException e) {
			Log.error(login_no, e);
			throw e;
		} catch (final RuntimeException e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(login_no, null, tmpPstmt, tmpRet);
			PZZ040_SQLUtility.closeConnection(login_no, con, pstmt, ret);
		}
	}

	/**
	 * �A�Z�X�����g�����擾���܂��B �߂�l��PBE_DownloadCsvSougouBean��Vector�Ɋi�[�������̂ł��B
	 * @param loginuser ���O�C�����[�U���
	 * @param busyo_cd �i�肱�ݏ����ƂȂ镔���R�[�h NULL�̏ꍇ�͎w��Ȃ�
	 * @param taisyokikan �i�肱�ݏ����ƂȂ�A�Z�X�����g�f�f�̎��{�N���� Null�̏ꍇ�͎w�薳��
	 * @return �A�Z�X�����g���̈ꗗ
	 * @exception NamingException ���O�����Ɏ��s�����ꍇ
	 * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
	 * @throws SQLException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public Vector getCsvSougou(final PEY_PersonalBean loginuser, final String busyo_cd, final String taisyokikan, final String max, final String min) throws NamingException, SQLException {

		Connection con = null;
		PreparedStatement pstmt = null;

		final Vector v_result = new Vector();
		ResultSet rs = null;
		PreparedStatement tmpPstmt = null;
		ResultSet tmprs = null;
		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			String where = "";
			if (taisyokikan != null && !taisyokikan.equals("")) {
				where = " AND p21." + PBE_DownloadEJBBean.JISSI_NENGAPPI_P21COL + " >= ? ";
			}

			String sql = "";

			sql = "SELECT " + "DISTINCT p21." + PBE_DownloadEJBBean.SINDANSYA_P21COL + "," + "substr(t01." + PBE_DownloadEJBBean.KANJI_SIMEI_T01COL + ",2)sindansya_kanji_simei," + "substr(t01."
					+ PBE_DownloadEJBBean.KANA_SIMEI_T01COL + ",2)sindansya_kana_simei," + "substr(t01." + PBE_DownloadEJBBean.EIJI_SIMEI_T01COL + ",2)sindansya_eiji_simei," + "t01."
					+ PBE_DownloadEJBBean.YAKUSYOKU_CODE_T01COL + "," + "t15.yakusyoku," + "p21.syoku_code," + "p01.syoku_name," + "p21.senmon_code," + "p02.senmon_name," + "p21.level_code,"
					+ "p12.level_name," + "p21.jissi_kaisu," + "p21.jissi_nengappi," + "p21.GYOMU_KEIKEN_T_DO," + "p21.SKILL_T_DO," + "p21.SOUGOU_T_DO," + "p24.HYOKASYA,"
					+ "substr(t012.kanji_simei,2)hyokasya_kanji_simei," + "substr(t012.kana_simei,2)hyokasya_kana_simei," + "substr(t012.eiji_simei,2)hyokasya_eiji_simei," + "p24.jissi_nengappi,"
					+ "p24.GYOMU_KEIKEN_T_DO," + "p24.SKILL_T_DO," + "p24.SOUGOU_T_DO," + "p21.CAREER_CHALLENGE_KIKAN_MEI," + "t01.sosiki_code" + " FROM " + "( SELECT * FROM "
					+ PBE_DownloadEJBBean.P21_ASSESSMENT_SINDAN_TBL + " WHERE " + PBE_DownloadEJBBean.SINDANSYA_P21COL + " IN (" + "SELECT " + PBE_DownloadEJBBean.SIMEI_NO_T01COL + " FROM "
					+ PBE_DownloadEJBBean.T01_PERSONAL_TBL + " WHERE " + PBE_DownloadEJBBean.SOSIKI_CODE_T01COL + " IN (SELECT SOSIKI_CODE" + " FROM t19_sosiki_tbl" + " START WITH SOSIKI_CODE = ?"
					+ " CONNECT BY PRIOR SOSIKI_CODE = JOUI_SOSIKI_CODE)" + " AND " + PBE_DownloadEJBBean.HONMU_FLG_T01COL + " = '1'" + " AND " + PBE_DownloadEJBBean.GENSYOKU_TAISYOKU_FLG_T01COL
					+ " = '1'" + ")" + ")p21," + "(SELECT * FROM " + PBE_DownloadEJBBean.T01_PERSONAL_TBL + " WHERE " + PBE_DownloadEJBBean.HONMU_FLG_T01COL + " = '1')t01," + "(SELECT * FROM "
					+ PBE_DownloadEJBBean.T01_PERSONAL_TBL + " WHERE " + PBE_DownloadEJBBean.HONMU_FLG_T01COL + " = '1')t012," + PBE_DownloadEJBBean.T15_YAKUSYOKU_TBL + " t15,"
					+ "p01_C_syokusyu_tbl p01," + "P02_C_SENMONBUNYA_TBL p02," + "P24_ASSESSMENT_HYOKA_TBL p24," + "P12_C_LEVEL_NAME_TBL p12" + " WHERE " + "p21.sindansya = t01.simei_no"
					+ " AND t01." + PBE_DownloadEJBBean.YAKUSYOKU_CODE_T01COL + " = t15." + PBE_DownloadEJBBean.YAKUSYOKU_CODE_T15COL + " AND p21." + PBE_DownloadEJBBean.SYOKU_CODE_P21COL + " = p01."
					+ PBE_DownloadEJBBean.SYOKU_CODE_P21COL + " AND p21." + PBE_DownloadEJBBean.SYOKU_CODE_P21COL + " = p02." + PBE_DownloadEJBBean.SYOKU_CODE_P02COL + " AND p21."
					+ PBE_DownloadEJBBean.SENMON_CODE_P21COL + " = p02." + PBE_DownloadEJBBean.SENMON_CODE_P02COL + " AND p21." + PBE_DownloadEJBBean.LEVEL_CODE_P21COL + " = p12."
					+ PBE_DownloadEJBBean.LEVEL_CODE_P12COL + " AND p21." + PBE_DownloadEJBBean.SYOKU_CODE_P21COL + " = p24.syoku_code" + " AND p21.senmon_code = p24.senmon_code"
					+ " AND p21.level_code = p24.level_code" + " AND p21.jissi_kaisu = p24.jissi_kaisu" + " AND p21.sindansya = p24.sindansya" + " AND p24.hyokasya = t012."
					+ PBE_DownloadEJBBean.SIMEI_NO_T01COL + where + " ORDER BY t01." + PBE_DownloadEJBBean.SOSIKI_CODE_T01COL + ",p21." + PBE_DownloadEJBBean.SINDANSYA_P21COL + ",p21."
					+ PBE_DownloadEJBBean.SYOKU_CODE_P22COL + ",p21.senmon_code,p21.level_code,p21.jissi_kaisu";
			/* �f�o�b�O���O */
			Log.debug("getCsvSougou:SQL=" + sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, busyo_cd);
			if (!where.equals("")) {
				pstmt.setString(2, taisyokikan);
			}
			rs = pstmt.executeQuery();
			HashMap csvMap;
			while (rs.next()) {
				csvMap = new HashMap();
				csvMap.put("Sindansya", rs.getString(1));
				csvMap.put("Kanji_simei", rs.getString(2));
				csvMap.put("Kana_simei", rs.getString(3));
				csvMap.put("Eiji_simei", rs.getString(4));
				csvMap.put("Yakusyoku_code", rs.getString(5));
				csvMap.put("Yakusyoku_name", rs.getString(6));
				csvMap.put("Syoku_code", rs.getString(7));
				csvMap.put("Syoku_name", rs.getString(8));
				csvMap.put("Senmon_code", rs.getString(9));
				csvMap.put("Senmon_name", rs.getString(10));
				csvMap.put("Level_code", rs.getString(11));
				csvMap.put("Level_name", rs.getString(12));
				csvMap.put("Jissi_kaisu", rs.getString(13));
				csvMap.put("Jissi_nengappi", rs.getString(14));
				csvMap.put("Gyomu_keiken_t_do", rs.getString(15));
				csvMap.put("Skill_t_do", rs.getString(16));
				csvMap.put("Sougou_t_do", rs.getString(17));
				csvMap.put("Hyokasya", rs.getString(18));
				csvMap.put("KanjiSimeiHyo", rs.getString(19));
				csvMap.put("KanaSimeiHyo", rs.getString(20));
				csvMap.put("EijiSimeiHyo", rs.getString(21));
				csvMap.put("HyokaNengappi", rs.getString(22));
				csvMap.put("Gyomu_keiken_t_do_hyo", rs.getString(23));
				csvMap.put("Skill_t_do_hyo", rs.getString(24));
				csvMap.put("Sougou_t_do_hyo", rs.getString(25));
				csvMap.put("Career_challenge_kikan_mei", rs.getString(26));

				final String tmpSosiki = rs.getString(27);// �g�D�R�[�h�ޔ�

				final String tmpSql = "SELECT SOSIKI_CODE,joui_sosiki_code,kaisou,sosiki_mei FROM" + " t19_sosiki_tbl " + " START WITH SOSIKI_CODE = ?"
						+ " CONNECT BY PRIOR joui_SOSIKI_CODE = SOSIKI_CODE";
				tmpPstmt = null;
				tmpPstmt = con.prepareStatement(tmpSql);
				tmpPstmt.setString(1, tmpSosiki);
				tmprs = tmpPstmt.executeQuery();
				while (tmprs.next()) {
					final int tmpKaisou = tmprs.getInt(3);
					if (Integer.parseInt(max) < tmpKaisou || Integer.parseInt(min) > tmpKaisou) {
						// �擾������ʑg�D���p�����[�^�͈̔͊O�ł���Ζ���
						continue;
					}

					switch (Integer.parseInt(tmprs.getString(3))) {
					case 1:
						csvMap.put("Syozoku_code_1", tmprs.getString(1));
						csvMap.put("Syozoku_name_1", tmprs.getString(4));
						break;
					case 2:
						csvMap.put("Syozoku_code_2", tmprs.getString(1));
						csvMap.put("Syozoku_name_2", tmprs.getString(4));
						break;
					case 3:
						csvMap.put("Syozoku_code_3", tmprs.getString(1));
						csvMap.put("Syozoku_name_3", tmprs.getString(4));
						break;
					case 4:
						csvMap.put("Syozoku_code_4", tmprs.getString(1));
						csvMap.put("Syozoku_name_4", tmprs.getString(4));
						break;
					case 5:
						csvMap.put("Syozoku_code_5", tmprs.getString(1));
						csvMap.put("Syozoku_name_5", tmprs.getString(4));
						break;
					case 6:
						csvMap.put("Syozoku_code_6", tmprs.getString(1));
						csvMap.put("Syozoku_name_6", tmprs.getString(4));
						break;
					case 7:
						csvMap.put("Syozoku_code_7", tmprs.getString(1));
						csvMap.put("Syozoku_name_7", tmprs.getString(4));
						break;
					case 8:
						csvMap.put("Syozoku_code_8", tmprs.getString(1));
						csvMap.put("Syozoku_name_8", tmprs.getString(4));
						break;
					case 9:
						csvMap.put("Syozoku_code_9", tmprs.getString(1));
						csvMap.put("Syozoku_name_9", tmprs.getString(4));
						break;

					}
				}
				PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", null, tmpPstmt, tmprs);
				v_result.add(csvMap);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return v_result;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", null, tmpPstmt, tmprs);
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, pstmt, rs);
		}
	}

	/**
	 * �A�Z�X�����g�����擾���܂��B �߂�l��PBE_DownloadCsvGyomuBean��Vector�Ɋi�[�������̂ł��B
	 * @param loginuser ���O�C�����[�U���
	 * @param busyo_cd �i�肱�ݏ����ƂȂ镔���R�[�h NULL�̏ꍇ�͎w��Ȃ�
	 * @param taisyokikan �i�肱�ݏ����ƂȂ�A�Z�X�����g�f�f�̎��{�N���� Null�̏ꍇ�͎w�薳��
	 * @return �A�Z�X�����g���̈ꗗ
	 * @exception NamingException ���O�����Ɏ��s�����ꍇ
	 * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
	 * @throws SQLException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public Vector getCsvGyomu(final PEY_PersonalBean loginuser, final String busyo_cd, final String taisyokikan) throws NamingException, SQLException {

		Connection con = null;
		PreparedStatement ps = null;

		final Vector v_result = new Vector();
		ResultSet rs = null;
		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			String taisyoKikanCondition = "";

			if (taisyokikan != null && !"".equalsIgnoreCase(taisyokikan)) {
				taisyoKikanCondition = " AND P21." + PBE_DownloadEJBBean.JISSI_NENGAPPI_P21COL + " >= ? ";
			}

			String sql = "";

			sql = "SELECT " + "T01P21." + PBE_DownloadEJBBean.SINDANSYA_P21COL + ", " + "SUBSTR(T01P21." + PBE_DownloadEJBBean.KANJI_SIMEI_T01COL + ",2), " + "SUBSTR(T01P21."
					+ PBE_DownloadEJBBean.KANA_SIMEI_T01COL + ",2), " + "SUBSTR(T01P21." + PBE_DownloadEJBBean.EIJI_SIMEI_T01COL + ",2), " + "P22." + PBE_DownloadEJBBean.SYOKU_CODE_P22COL + ", "
					+ "P01." + PBE_DownloadEJBBean.SYOKU_NAME_P01COL + ", " + "P22." + PBE_DownloadEJBBean.SENMON_CODE_P22COL + ", " + "P02." + PBE_DownloadEJBBean.SENMON_NAME_P02COL + ", " + "P22."
					+ PBE_DownloadEJBBean.LEVEL_CODE_P22COL + ", " + "P12." + PBE_DownloadEJBBean.LEVEL_NAME_P12COL + ", " + "P22." + PBE_DownloadEJBBean.JISSI_KAISU_P22COL + ", " + "P22."
					+ PBE_DownloadEJBBean.TASSEIDO_KUBUN_CODE_P22COL + ", " + "P22_1." + PBE_DownloadEJBBean.TASSEIDO_KUBUN_CODE_P22COL + ", " + "P22."
					+ PBE_DownloadEJBBean.TASSEIDO_SIHYO_CODE_P22COL + ", " + "P22_1." + PBE_DownloadEJBBean.TASSEIDO_SIHYO_CODE_P22COL + ", " + "P22." + PBE_DownloadEJBBean.SENTAKU_FLG_P22COL + ", "
					+ "P22_1." + PBE_DownloadEJBBean.SENTAKU_FLG_P22COL + ", " + "P22_1." + PBE_DownloadEJBBean.HYOKASYA_P22COL + ", " + "SUBSTR(P22_1." + PBE_DownloadEJBBean.KANJI_SIMEI_T01COL
					+ ",2), " + "SUBSTR(P22_1." + PBE_DownloadEJBBean.KANA_SIMEI_T01COL + ",2), " + "SUBSTR(P22_1." + PBE_DownloadEJBBean.EIJI_SIMEI_T01COL + ",2) " + "FROM " + "(SELECT * FROM "
					+ PBE_DownloadEJBBean.P22_GYOMU_HYOKA_TBL + " WHERE " + PBE_DownloadEJBBean.KUBUN_P22COL + " = '1') P22, " + "(SELECT " + "* " + "FROM " + PBE_DownloadEJBBean.P22_GYOMU_HYOKA_TBL
					+ ", " + "(SELECT " + PBE_DownloadEJBBean.SIMEI_NO_T01COL + ", " + PBE_DownloadEJBBean.KANJI_SIMEI_T01COL + ", " + PBE_DownloadEJBBean.KANA_SIMEI_T01COL + ", "
					+ PBE_DownloadEJBBean.EIJI_SIMEI_T01COL + " " + "FROM " + PBE_DownloadEJBBean.T01_PERSONAL_TBL + " " + "WHERE " + PBE_DownloadEJBBean.HONMU_FLG_T01COL + " = '1' " + ")T01 "
					+ "WHERE " + PBE_DownloadEJBBean.P22_GYOMU_HYOKA_TBL + "." + PBE_DownloadEJBBean.KUBUN_P22COL + " = '2' " + "AND " + PBE_DownloadEJBBean.P22_GYOMU_HYOKA_TBL + "."
					+ PBE_DownloadEJBBean.HYOKASYA_P22COL + " = T01." + PBE_DownloadEJBBean.SIMEI_NO_T01COL + " " + ")P22_1, " + "(SELECT " + PBE_DownloadEJBBean.SINDANSYA_P21COL + ", "
					+ PBE_DownloadEJBBean.SYOKU_CODE_P21COL + ", " + PBE_DownloadEJBBean.SENMON_CODE_P21COL + ", " + PBE_DownloadEJBBean.LEVEL_CODE_P21COL + ", "
					+ PBE_DownloadEJBBean.JISSI_KAISU_P21COL + ", " + PBE_DownloadEJBBean.JISSI_NENGAPPI_P21COL + ", " + "GYOMU_KEIKEN_T_DO, " + "SKILL_T_DO, " + "SOUGOU_T_DO, "
					+ "CAREER_CHALLENGE_KIKAN_MEI, " + "SYOKU_NAME, " + "SENMON_NAME, " + "LEVEL_NAME, " + "SIMEI_NO, " + "KANJI_SIMEI, " + "KANA_SIMEI, " + "EIJI_SIMEI, " + "SOSIKI_CODE, "
					+ "YAKUSYOKU " + "FROM " + PBE_DownloadEJBBean.P21_ASSESSMENT_SINDAN_TBL + " P21, " + "(SELECT " + "* " + "FROM " + PBE_DownloadEJBBean.T01_PERSONAL_TBL + " " + "WHERE "
					+ PBE_DownloadEJBBean.SOSIKI_CODE_T01COL + " IN ( " + "SELECT " + PBE_DownloadEJBBean.SOSIKI_CODE_T19COL + " " + "FROM " + PBE_DownloadEJBBean.T19_SOSIKI_TBL + " " + "START WITH "
					+ PBE_DownloadEJBBean.SOSIKI_CODE_T19COL + " = ? " + "CONNECT BY PRIOR " + PBE_DownloadEJBBean.SOSIKI_CODE_T19COL + " = " + PBE_DownloadEJBBean.JOUI_SOSIKI_CODE_T19COL + " "
					+ ") " + "AND " + PBE_DownloadEJBBean.HONMU_FLG_T01COL + " = '1' " + "AND " + PBE_DownloadEJBBean.GENSYOKU_TAISYOKU_FLG_T01COL + " = '1' " + ")T01 " + "WHERE " + "T01."
					+ PBE_DownloadEJBBean.SIMEI_NO_T01COL + " = P21." + PBE_DownloadEJBBean.SINDANSYA_P21COL + " " + taisyoKikanCondition + ") T01P21, " + PBE_DownloadEJBBean.P01_C_SYOKUSYU_TBL
					+ " P01, " + PBE_DownloadEJBBean.P02_C_SENMONBUNYA_TBL + " P02, " + PBE_DownloadEJBBean.P12_C_LEVEL_NAME_TBL + " P12 " + "WHERE " + "T01P21."
					+ PBE_DownloadEJBBean.SINDANSYA_P21COL + " = P22." + PBE_DownloadEJBBean.SINDANSYA_P22COL + " " + "AND T01P21." + PBE_DownloadEJBBean.SYOKU_CODE_P21COL + " = P22."
					+ PBE_DownloadEJBBean.SYOKU_CODE_P22COL + " " + "AND T01P21." + PBE_DownloadEJBBean.SENMON_CODE_P21COL + " = P22." + PBE_DownloadEJBBean.SENMON_CODE_P22COL + " " + "AND T01P21."
					+ PBE_DownloadEJBBean.LEVEL_CODE_P21COL + " = P22." + PBE_DownloadEJBBean.LEVEL_CODE_P22COL + " " + "AND T01P21." + PBE_DownloadEJBBean.JISSI_KAISU_P21COL + " = P22."
					+ PBE_DownloadEJBBean.JISSI_KAISU_P22COL + " " + "AND P22." + PBE_DownloadEJBBean.SINDANSYA_P22COL + " = P22_1." + PBE_DownloadEJBBean.SINDANSYA_P22COL + "(+) " + "AND P22."
					+ PBE_DownloadEJBBean.SYOKU_CODE_P22COL + " = P22_1." + PBE_DownloadEJBBean.SYOKU_CODE_P22COL + "(+) " + "AND P22." + PBE_DownloadEJBBean.SENMON_CODE_P22COL + " = P22_1."
					+ PBE_DownloadEJBBean.SENMON_CODE_P22COL + "(+) " + "AND P22." + PBE_DownloadEJBBean.LEVEL_CODE_P22COL + " = P22_1." + PBE_DownloadEJBBean.LEVEL_CODE_P22COL + "(+) " + "AND P22."
					+ PBE_DownloadEJBBean.JISSI_KAISU_P22COL + " = P22_1." + PBE_DownloadEJBBean.JISSI_KAISU_P22COL + "(+) " + "AND P22." + PBE_DownloadEJBBean.TASSEIDO_KUBUN_CODE_P22COL
					+ " = P22_1." + PBE_DownloadEJBBean.TASSEIDO_KUBUN_CODE_P22COL + "(+)" + "AND P22." + PBE_DownloadEJBBean.TASSEIDO_SIHYO_CODE_P22COL + " = P22_1."
					+ PBE_DownloadEJBBean.TASSEIDO_SIHYO_CODE_P22COL + "(+)" + "AND T01P21." + PBE_DownloadEJBBean.SYOKU_CODE_P21COL + " = P01." + PBE_DownloadEJBBean.SYOKU_CODE_P01COL + " "
					+ "AND T01P21." + PBE_DownloadEJBBean.SYOKU_CODE_P21COL + " = P02." + PBE_DownloadEJBBean.SYOKU_CODE_P02COL + " " + "AND T01P21." + PBE_DownloadEJBBean.SENMON_CODE_P21COL
					+ " = P02." + PBE_DownloadEJBBean.SENMON_CODE_P02COL + " " + "AND T01P21." + PBE_DownloadEJBBean.LEVEL_CODE_P21COL + " = P12." + PBE_DownloadEJBBean.LEVEL_CODE_P12COL + " "
					+ "ORDER BY " + "T01P21." + PBE_DownloadEJBBean.SOSIKI_CODE_T01COL + ", " + "P22." + PBE_DownloadEJBBean.SINDANSYA_P22COL + ", " + "P22." + PBE_DownloadEJBBean.SYOKU_CODE_P22COL
					+ ", " + "P22." + PBE_DownloadEJBBean.SENMON_CODE_P22COL + ", " + "P22." + PBE_DownloadEJBBean.LEVEL_CODE_P22COL + ", " + "P22." + PBE_DownloadEJBBean.JISSI_KAISU_P22COL;

			/* �f�o�b�O���O */
			Log.debug("getCsvGyomu:SQL=" + sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");
			ps = con.prepareStatement(sql);

			ps.setString(1, busyo_cd);
			if (!taisyoKikanCondition.equals("")) {
				ps.setString(2, taisyokikan);
			}

			rs = ps.executeQuery();

			HashMap csvMap;
			while (rs.next()) {

				csvMap = new HashMap();
				csvMap.put("Sindansya", rs.getString(1));
				csvMap.put("SindansyaKanjiSimei", rs.getString(2));
				csvMap.put("SindansyaKanaSimei", rs.getString(3));
				csvMap.put("SindansyaEijiSimei", rs.getString(4));
				csvMap.put("Syoku_code", rs.getString(5));
				csvMap.put("SyokuName", rs.getString(6));
				csvMap.put("Senmon_code", rs.getString(7));
				csvMap.put("SenmonName", rs.getString(8));
				csvMap.put("Level_code", rs.getString(9));
				csvMap.put("LevelName", rs.getString(10));
				csvMap.put("Jissi_kaisu", rs.getString(11));
				csvMap.put("Tasseido_kubun_code", rs.getString(12));
				csvMap.put("Tasseido_kubun", rs.getString(13));
				csvMap.put("Tasseido_sihyo_code", rs.getString(14));
				csvMap.put("Tasseido_sihyo", rs.getString(15));
				csvMap.put("SentakuFlgSindansya", rs.getString(16));
				csvMap.put("SentakuFlgHyokasya", rs.getString(17));
				csvMap.put("Hyokasya", rs.getString(18));
				csvMap.put("HyokasyaKanjiSimei", rs.getString(19));
				csvMap.put("HyokasyaKanaSimei", rs.getString(20));
				csvMap.put("HyokasyaEijiSimei", rs.getString(21));

				v_result.add(csvMap);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return v_result;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * �A�Z�X�����g�����擾���܂��B �߂�l��PBE_DownloadCsvGyomuBean��Vector�Ɋi�[�������̂ł��B
	 * @param loginuser ���O�C�����[�U���
	 * @param busyo_cd �i�肱�ݏ����ƂȂ镔���R�[�h NULL�̏ꍇ�͎w��Ȃ�
	 * @param taisyokikan �i�肱�ݏ����ƂȂ�A�Z�X�����g�f�f�̎��{�N���� Null�̏ꍇ�͎w�薳��
	 * @return �A�Z�X�����g���̈ꗗ
	 * @exception NamingException ���O�����Ɏ��s�����ꍇ
	 * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
	 * @throws SQLException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public Vector getCsvSkill(final PEY_PersonalBean loginuser, final String busyo_cd, final String taisyokikan) throws NamingException, SQLException {

		Connection con = null;
		PreparedStatement ps = null;

		PBE_DownloadCsvSkillBean csvData = null;

		final Vector v_result = new Vector();
		ResultSet rs = null;
		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			String taisyoKikanCondition = "";

			if (taisyokikan != null && !"".equalsIgnoreCase(taisyokikan)) {
				taisyoKikanCondition = " AND P21." + PBE_DownloadEJBBean.JISSI_NENGAPPI_P21COL + " >= ? ";
			}

			String sql = "";

			sql = "SELECT " + "T01P21." + PBE_DownloadEJBBean.SINDANSYA_P23COL + ", " + "SUBSTR(T01P21." + PBE_DownloadEJBBean.KANJI_SIMEI_T01COL + ",2), " + "SUBSTR(T01P21."
					+ PBE_DownloadEJBBean.KANA_SIMEI_T01COL + ",2), " + "SUBSTR(T01P21." + PBE_DownloadEJBBean.EIJI_SIMEI_T01COL + ",2), " + "P23." + PBE_DownloadEJBBean.SYOKU_CODE_P23COL + ", "
					+ "P01." + PBE_DownloadEJBBean.SYOKU_NAME_P01COL + ", " + "P23." + PBE_DownloadEJBBean.SENMON_CODE_P23COL + ", " + "P02." + PBE_DownloadEJBBean.SENMON_NAME_P02COL + ", " + "P23."
					+ PBE_DownloadEJBBean.LEVEL_CODE_P23COL + ", " + "P12." + PBE_DownloadEJBBean.LEVEL_NAME_P12COL + ", " + "P23." + PBE_DownloadEJBBean.JISSI_KAISU_P23COL + ", " + "P23."
					+ PBE_DownloadEJBBean.SKILL_CODE_P23COL + ", " + "P03." + PBE_DownloadEJBBean.SKILL_NAME_P03COL + ", " + "P23." + PBE_DownloadEJBBean.SCORE_P23COL + ", " + "P23_1."
					+ PBE_DownloadEJBBean.SCORE_P23COL + ", " + "P23_1." + PBE_DownloadEJBBean.HYOKASYA_P23COL + " , " + "SUBSTR(P23_1." + PBE_DownloadEJBBean.KANJI_SIMEI_T01COL + ",2), "
					+ "SUBSTR(P23_1." + PBE_DownloadEJBBean.KANA_SIMEI_T01COL + ",2), " + "SUBSTR(P23_1." + PBE_DownloadEJBBean.EIJI_SIMEI_T01COL + ",2) " + "FROM " + "(SELECT * FROM "
					+ PBE_DownloadEJBBean.P23_SKILL_HYOKA_TBL + " WHERE " + PBE_DownloadEJBBean.KUBUN_P23COL + " = '1') P23, " + "(SELECT " + "* " + "FROM " + PBE_DownloadEJBBean.P23_SKILL_HYOKA_TBL
					+ ", " + "(SELECT " + PBE_DownloadEJBBean.SIMEI_NO_T01COL + ", " + PBE_DownloadEJBBean.KANJI_SIMEI_T01COL + ", " + PBE_DownloadEJBBean.KANA_SIMEI_T01COL + ", "
					+ PBE_DownloadEJBBean.EIJI_SIMEI_T01COL + " " + "FROM " + PBE_DownloadEJBBean.T01_PERSONAL_TBL + " " + "WHERE " + PBE_DownloadEJBBean.HONMU_FLG_T01COL + " = '1' " + ")T01 "
					+ "WHERE " + PBE_DownloadEJBBean.P23_SKILL_HYOKA_TBL + "." + PBE_DownloadEJBBean.KUBUN_P23COL + " = '2' " + "AND " + PBE_DownloadEJBBean.P23_SKILL_HYOKA_TBL + "."
					+ PBE_DownloadEJBBean.HYOKASYA_P23COL + " = T01." + PBE_DownloadEJBBean.SIMEI_NO_T01COL + " " + ")P23_1, " + "(SELECT " + PBE_DownloadEJBBean.SINDANSYA_P21COL + ", "
					+ PBE_DownloadEJBBean.SYOKU_CODE_P21COL + ", " + PBE_DownloadEJBBean.SENMON_CODE_P21COL + ", " + PBE_DownloadEJBBean.LEVEL_CODE_P21COL + ", "
					+ PBE_DownloadEJBBean.JISSI_KAISU_P21COL + ", " + PBE_DownloadEJBBean.JISSI_NENGAPPI_P21COL + ", " + PBE_DownloadEJBBean.SIMEI_NO_T01COL + ", "
					+ PBE_DownloadEJBBean.KANJI_SIMEI_T01COL + ", " + PBE_DownloadEJBBean.KANA_SIMEI_T01COL + ", " + PBE_DownloadEJBBean.EIJI_SIMEI_T01COL + ", "
					+ PBE_DownloadEJBBean.SOSIKI_CODE_T01COL + " " + "FROM " + PBE_DownloadEJBBean.P21_ASSESSMENT_SINDAN_TBL + " P21, " + "(SELECT " + "* " + "FROM "
					+ PBE_DownloadEJBBean.T01_PERSONAL_TBL + " " + "WHERE " + PBE_DownloadEJBBean.SOSIKI_CODE_T01COL + " IN ( " + "SELECT " + PBE_DownloadEJBBean.SOSIKI_CODE_T01COL + " " + "FROM "
					+ PBE_DownloadEJBBean.T19_SOSIKI_TBL + " " + "START WITH " + PBE_DownloadEJBBean.SOSIKI_CODE_T19COL + " = ? " + "CONNECT BY PRIOR " + PBE_DownloadEJBBean.SOSIKI_CODE_T19COL
					+ " = " + PBE_DownloadEJBBean.JOUI_SOSIKI_CODE_T19COL + ") " + "AND " + PBE_DownloadEJBBean.HONMU_FLG_T01COL + " = '1' " + "AND "
					+ PBE_DownloadEJBBean.GENSYOKU_TAISYOKU_FLG_T01COL + " = '1' " + ")T01 " + "WHERE " + "T01." + PBE_DownloadEJBBean.SIMEI_NO_T01COL + " = P21."
					+ PBE_DownloadEJBBean.SINDANSYA_P21COL + " " + taisyoKikanCondition + ") T01P21, " + PBE_DownloadEJBBean.P01_C_SYOKUSYU_TBL + " P01, " + PBE_DownloadEJBBean.P02_C_SENMONBUNYA_TBL
					+ " P02, " + PBE_DownloadEJBBean.P12_C_LEVEL_NAME_TBL + " P12, " + PBE_DownloadEJBBean.P03_C_SKILL_KOMOKU_TBL + " P03 " + "WHERE " + "T01P21."
					+ PBE_DownloadEJBBean.SINDANSYA_P21COL + " = P23." + PBE_DownloadEJBBean.SINDANSYA_P23COL + " " + "AND T01P21." + PBE_DownloadEJBBean.SYOKU_CODE_P21COL + " = P23."
					+ PBE_DownloadEJBBean.SYOKU_CODE_P23COL + " " + "AND T01P21." + PBE_DownloadEJBBean.SENMON_CODE_P21COL + " = P23." + PBE_DownloadEJBBean.SENMON_CODE_P23COL + " " + "AND T01P21."
					+ PBE_DownloadEJBBean.LEVEL_CODE_P21COL + " = P23." + PBE_DownloadEJBBean.LEVEL_CODE_P23COL + " " + "AND T01P21." + PBE_DownloadEJBBean.JISSI_KAISU_P21COL + " = P23."
					+ PBE_DownloadEJBBean.JISSI_KAISU_P23COL + " " + "AND P23." + PBE_DownloadEJBBean.SINDANSYA_P23COL + " = P23_1." + PBE_DownloadEJBBean.SINDANSYA_P23COL + "(+) " + "AND P23."
					+ PBE_DownloadEJBBean.SYOKU_CODE_P23COL + " = P23_1." + PBE_DownloadEJBBean.SYOKU_CODE_P23COL + "(+) " + "AND P23." + PBE_DownloadEJBBean.SENMON_CODE_P23COL + " = P23_1."
					+ PBE_DownloadEJBBean.SENMON_CODE_P23COL + "(+) " + "AND P23." + PBE_DownloadEJBBean.LEVEL_CODE_P23COL + " = P23_1." + PBE_DownloadEJBBean.LEVEL_CODE_P23COL + "(+) " + "AND P23."
					+ PBE_DownloadEJBBean.JISSI_KAISU_P23COL + " = P23_1." + PBE_DownloadEJBBean.JISSI_KAISU_P23COL + "(+) " + "AND P23." + PBE_DownloadEJBBean.SKILL_CODE_P23COL + " = P23_1."
					+ PBE_DownloadEJBBean.SKILL_CODE_P23COL + "(+) " + "AND T01P21." + PBE_DownloadEJBBean.SYOKU_CODE_P21COL + " = P01." + PBE_DownloadEJBBean.SYOKU_CODE_P01COL + " " + "AND T01P21."
					+ PBE_DownloadEJBBean.SYOKU_CODE_P21COL + " = P02." + PBE_DownloadEJBBean.SYOKU_CODE_P02COL + " " + "AND T01P21." + PBE_DownloadEJBBean.SENMON_CODE_P21COL + " = P02."
					+ PBE_DownloadEJBBean.SENMON_CODE_P02COL + " " + "AND T01P21." + PBE_DownloadEJBBean.LEVEL_CODE_P21COL + " = P12." + PBE_DownloadEJBBean.LEVEL_CODE_P12COL + " " + "AND P23."
					+ PBE_DownloadEJBBean.SYOKU_CODE_P23COL + " = P03." + PBE_DownloadEJBBean.SYOKU_CODE_P03COL + " " + "AND P23." + PBE_DownloadEJBBean.SENMON_CODE_P23COL + " = P03."
					+ PBE_DownloadEJBBean.SENMON_CODE_P03COL + " " + "AND P23." + PBE_DownloadEJBBean.SKILL_CODE_P23COL + " = P03." + PBE_DownloadEJBBean.SKILL_CODE_P03COL + " " + "ORDER BY "
					+ "T01P21." + PBE_DownloadEJBBean.SOSIKI_CODE_T01COL + ", " + "P23." + PBE_DownloadEJBBean.SINDANSYA_P23COL + ", " + "P23." + PBE_DownloadEJBBean.SYOKU_CODE_P23COL + ", " + "P23."
					+ PBE_DownloadEJBBean.SENMON_CODE_P23COL + ", " + "P23." + PBE_DownloadEJBBean.LEVEL_CODE_P23COL + ", " + "P23." + PBE_DownloadEJBBean.JISSI_KAISU_P23COL;

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");
			ps = con.prepareStatement(sql);

			ps.setString(1, busyo_cd);
			if (!taisyoKikanCondition.equals("")) {
				ps.setString(2, taisyokikan);
			}

			rs = ps.executeQuery();

			while (rs.next()) {

				csvData = new PBE_DownloadCsvSkillBean();
				csvData.setSindansya(rs.getString(1));
				csvData.setSindansyaKanjiSime(rs.getString(2));
				csvData.setSindansyaKanaSimei(rs.getString(3));
				csvData.setSindansyaEijiSimei(rs.getString(4));
				csvData.setSyoku_code(rs.getString(5));
				csvData.setSyokuName(rs.getString(6));
				csvData.setSenmon_code(rs.getString(7));
				csvData.setSenmonName(rs.getString(8));
				csvData.setLevel_code(rs.getString(9));
				csvData.setLevelName(rs.getString(10));
				csvData.setJissi_kaisu(rs.getString(11));
				csvData.setSkill_code(rs.getString(12));
				csvData.setSkill_name(rs.getString(13));
				csvData.setScore(rs.getString(14));
				csvData.setScoreHyokasya(rs.getString(15));
				csvData.setHyokasya(rs.getString(16));
				csvData.setHyokasyaKanjiSimei(rs.getString(17));
				csvData.setHyokasyaKanaSimei(rs.getString(18));
				csvData.setHyokasyaEijiSimei(rs.getString(19));

				v_result.add(csvData);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return v_result;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}
}
