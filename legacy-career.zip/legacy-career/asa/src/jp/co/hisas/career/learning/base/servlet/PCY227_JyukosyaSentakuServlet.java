package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.base.sosiki.bean.SosikiBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaExBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY224_JyukosyaSentakuServlet �N���X �@�\�����F ��s���͂����u�҂�I�����܂��B
 * 
 * </PRE>
 */
public class PCY227_JyukosyaSentakuServlet extends PCY010_ControllerServlet {
	/**
	 * ��s���͂̌������������ɁA��s���͂����u�҂�I�����܂��B
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		// ���p����EJB�𐶐�
		final PCY_ClassEJBHome class_home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_TaisyoEJBHome taisyo_home = (PCY_TaisyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_TaisyoEJBHome.class);
		final PCY_MousikomiJyokyoEJBHome mousikomi_home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_PersonalEJBHome personal_home = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
		final PCY_ClassEJB class_ejb = class_home.create();
		final PCY_TaisyoEJB taisyo_ejb = taisyo_home.create();
		final PCY_MousikomiJyokyoEJB mousikomi_ejb = mousikomi_home.create();
		final PCY_PersonalEJB personal_ejb = personal_home.create();
		
		// �l����������PCY_PersonalBean���쐬
        String syoninsyaSimeiNo = loginuser.getSimeiNo();
        // ���������ɊY������l�����擾
        final PCY_PersonalBean[] personalBeans =
                personal_ejb.getListBySyoninsya(syoninsyaSimeiNo, loginuser);
		
		// ��s���͑Ώۂ̃N���X�����擾
		PCY_ClassBean classBean = new PCY_ClassBean(request);
		classBean = class_ejb.doSelectByPrimaryKey(classBean, loginuser);
		
		// �Y������Ώێ҂��擾
		final PCY_TaisyosyaBean[] taisyosyaBeans = taisyo_ejb.getAllTaisyosya(classBean, true, loginuser);
        Map<String, String> taisyoKubunMap = new HashMap<String, String>();
        for (PCY_TaisyosyaBean taisyosyaBean : taisyosyaBeans) {
            taisyoKubunMap.put(taisyosyaBean.getSimeiNo(), taisyosyaBean.getTaisyoKubun());
        }

		// ���������ɊY������Ώێ҂��쐬
        List<String> searchSimeiNoList = new ArrayList<String>();
        for (PCY_PersonalBean personalBean : personalBeans) {
            searchSimeiNoList.add(personalBean.getSimeiNo());
        }

		// L15,L51���Q�Ƃ��Ď�u�󋵁A�\���󋵂�ݒ肷��
		List<PCY_TaisyosyaExBean> taisyosyaBeanList = new ArrayList<PCY_TaisyosyaExBean>();
		final PCY_MousikomiJyokyoBean kensakuMousikomi = new PCY_MousikomiJyokyoBean();
		final PCY_KensyuRirekiBean kensakuRireki = new PCY_KensyuRirekiBean();
		for (PCY_PersonalBean personalBean : personalBeans) {
			
			if (searchSimeiNoList.contains(personalBean.getSimeiNo())) {
	            PCY_TaisyosyaExBean taisyosyaExBean = new PCY_TaisyosyaExBean();
	            taisyosyaExBean.setPersonalBean(personalBean);
	            if (taisyoKubunMap.containsKey(personalBean.getSimeiNo())) {
	                taisyosyaExBean.setTaisyoKubun(taisyoKubunMap.get(personalBean.getSimeiNo()));
	            } else {
	                if ("0".equals(classBean.getZensyaTaisyoFlg())) {
	                    continue;
	                }
	            }

	            kensakuMousikomi.setClassBean(classBean);
	            kensakuMousikomi.setSimeiNo(personalBean.getSimeiNo());
	            final PCY_MousikomiJyokyoBean[] mousikomiBeans = mousikomi_ejb.getList(kensakuMousikomi, loginuser);
				
	            kensakuRireki.setClassCode(classBean.getClassCode());
	            kensakuRireki.setKamokuCode(classBean.getKamokuBean().getKamokuCode());
	            kensakuRireki.setSimeiNo(personalBean.getSimeiNo());
	            final PCY_KensyuRirekiBean[] rirekiBeans = mousikomi_ejb.getListL51(kensakuRireki, loginuser);

				String st = null;
				String uk = null;
				String syu = null;
				
				if (mousikomiBeans != null && mousikomiBeans.length > 0) {
					st = mousikomiBeans[0].getStatus();
					uk = mousikomiBeans[0].getUketsukeJyotai();
				}
				if (rirekiBeans != null && rirekiBeans.length > 0) {
					syu = rirekiBeans[0].getSyuryoHantei();
				}

				if (st == null && uk == null && syu == null) {
					taisyosyaExBean.setJyukoJyokyo("0");
					taisyosyaExBean.setMousikomiJyokyo("0");
				} else if ("0".equals(st) && uk == null && syu == null) {
					taisyosyaExBean.setJyukoJyokyo("0");
					taisyosyaExBean.setMousikomiJyokyo("1");
				} else if ("1".equals(st) && "0".equals(uk) && syu == null) {
					taisyosyaExBean.setJyukoJyokyo("0");
					taisyosyaExBean.setMousikomiJyokyo("2");
				} else if ("1".equals(st) && "1".equals(uk) && syu == null) {
					taisyosyaExBean.setJyukoJyokyo("0");
					taisyosyaExBean.setMousikomiJyokyo("3");
				} else if ("1".equals(st) && "2".equals(uk) && syu == null) {
					taisyosyaExBean.setJyukoJyokyo("0");
					taisyosyaExBean.setMousikomiJyokyo("4");
				} else if ("1".equals(st) && "3".equals(uk) && syu == null) {
					taisyosyaExBean.setJyukoJyokyo("0");
					taisyosyaExBean.setMousikomiJyokyo("5");
				} else if ("1".equals(st) && "4".equals(uk) && syu == null) {
					taisyosyaExBean.setJyukoJyokyo("0");
					taisyosyaExBean.setMousikomiJyokyo("6");
				} else if ("2".equals(st) && uk == null && syu == null) {
					taisyosyaExBean.setJyukoJyokyo("1");
					taisyosyaExBean.setMousikomiJyokyo("");
				} else if ("3".equals(st) && uk == null && syu == null) {
					taisyosyaExBean.setJyukoJyokyo("2");
					taisyosyaExBean.setMousikomiJyokyo("");
				} else if (st == null && uk == null && syu.equals("0")) {
					taisyosyaExBean.setJyukoJyokyo("3");
					taisyosyaExBean.setMousikomiJyokyo("");
				} else if (st == null && uk == null && syu.equals("1")) {
					taisyosyaExBean.setJyukoJyokyo("4");
					taisyosyaExBean.setMousikomiJyokyo("");
				} else {
					taisyosyaExBean.setJyukoJyokyo("");
					taisyosyaExBean.setMousikomiJyokyo("");
				}
				
				taisyosyaBeanList.add(taisyosyaExBean);
			}
		}

		request.setAttribute("taisyosyaBeans", taisyosyaBeanList.toArray(new PCY_TaisyosyaExBean[0]));
		request.setAttribute("classBean", classBean);

		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
	
	/**
	 * ���������ƂȂ邷��PCY_PersonalBean���擾����
	 * @param request
	 * @param loginuser
	 * @return
	 */
	private PCY_PersonalBean getPersonalBean (final HttpServletRequest request, final PCY_PersonalBean loginuser) {

		final String searchSimeiNo = request.getParameter("T001_simei_no");
		final String searchSimeiKanji = request.getParameter("T002_kanji_simei");
		final String searchSimeiKana = request.getParameter("T003_kana_simei");
		final String searchSimeiEiji = request.getParameter("T004_eigo_simei");
		final String searchBusyo = request.getParameter("S001_sosiki_code");

		PCY_PersonalBean kensakuPersnalBean = new PCY_PersonalBean();
		if (searchSimeiNo != null && !searchSimeiNo.equals("")) {
			kensakuPersnalBean.setSimeiNo(searchSimeiNo);
		}

		if (searchSimeiKanji != null && !searchSimeiKanji.equals("")) {
			kensakuPersnalBean.setKanjiSimei(searchSimeiKanji);
		}

		if (searchSimeiKana != null && !searchSimeiKana.equals("")) {
			kensakuPersnalBean.setKanaSimei(searchSimeiKana);
		}

		if (searchSimeiEiji != null && !searchSimeiEiji.equals("")) {
			kensakuPersnalBean.setEigoSimei(searchSimeiEiji);
		}

		// �g�D�R�[�h���擾���A�Ώۂ̑g�D�K�w�ɃZ�b�g����
		if (searchBusyo != null && !searchBusyo.equals("")) {
			final String[] sosiki_info = SosikiBean.getSosikiByCode(searchBusyo, loginuser.getSimeiNo());

			if (sosiki_info[4].equals("1")) {
				kensakuPersnalBean.setSyozokuCode1(searchBusyo);
			} else if (sosiki_info[4].equals("2")) {
				kensakuPersnalBean.setSyozokuCode2(searchBusyo);
			} else if (sosiki_info[4].equals("3")) {
				kensakuPersnalBean.setSyozokuCode3(searchBusyo);
			} else if (sosiki_info[4].equals("4")) {
				kensakuPersnalBean.setSyozokuCode4(searchBusyo);
			} else if (sosiki_info[4].equals("5")) {
				kensakuPersnalBean.setSyozokuCode5(searchBusyo);
			} else if (sosiki_info[4].equals("6")) {
				kensakuPersnalBean.setSyozokuCode6(searchBusyo);
			} else if (sosiki_info[4].equals("7")) {
				kensakuPersnalBean.setSyozokuCode7(searchBusyo);
			} else if (sosiki_info[4].equals("8")) {
				kensakuPersnalBean.setSyozokuCode8(searchBusyo);
			} else if (sosiki_info[4].equals("9")) {
				kensakuPersnalBean.setSyozokuCode9(searchBusyo);
			}
		}
		
		return kensakuPersnalBean;
		
	}
}
