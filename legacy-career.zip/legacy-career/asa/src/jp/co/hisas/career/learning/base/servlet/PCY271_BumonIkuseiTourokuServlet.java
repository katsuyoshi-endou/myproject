/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_BumonIkuseiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_BumonIkuseiEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_BumonIkuseiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY271_BumonIkuseiTourokuServlet �N���X �@�\�����F ����琬�e�[�u���ւ�insert�������s���܂��B
 * 
 * </PRE>
 */
public class PCY271_BumonIkuseiTourokuServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws RemoteException, SQLException, Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		/* BumonIkuseiEJB */
		final PCY_BumonIkuseiEJBHome bumonikusei_home = (PCY_BumonIkuseiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_BumonIkuseiEJBHome.class);
		final PCY_BumonIkuseiEJB bumonikusei_ejb = bumonikusei_home.create();

		Log.transaction(loginuser.getSimeiNo(), true, "");

		final String bumonSosikiCode = request.getParameter("sosiki_code");
		final PCY_BumonIkuseiBean insert_bumonBean = new PCY_BumonIkuseiBean();
		insert_bumonBean.setSosikiCode(bumonSosikiCode);
		insert_bumonBean.setIkuseiHousin(request.getParameter("H002_HTMLcomment").getBytes());

		final int count = bumonikusei_ejb.doInsert(insert_bumonBean, loginuser);

		Log.transaction(loginuser.getSimeiNo(), false, "");

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
