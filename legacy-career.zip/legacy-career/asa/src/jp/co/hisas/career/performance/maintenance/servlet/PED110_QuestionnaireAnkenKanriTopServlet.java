/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.performance.maintenance.bean.PED_QuestionnaireAnkenKanriBean;
import jp.co.hisas.career.performance.maintenance.bean.PED_QuestionnaireBean;
import jp.co.hisas.career.performance.util.bean.PED_PerformanceBean;
import jp.co.hisas.career.util.log.Log;

/**
 * �A���P�[�g�Č��Ǘ��g�b�v�t���[��
 * @author Torigoe
 */
public class PED110_QuestionnaireAnkenKanriTopServlet extends HttpServlet {

	/** �G���[�y�[�W */
	private static final String ERROR_PAGE = "/view/base/error/VYY_Error.jsp";

	/** �J�ڐ�y�[�W */
	private static final String SUCCESS_PAGE = "/view/performance/maintenance/VED110_QuestionnaireAnkenKanriTop.jsp";

	private ServletContext ctx = null;

	public void init(final ServletConfig config) throws ServletException {
		super.init(config);

		// ���\�b�h�g���[�X�o��
		Log.method("", "IN", "");

		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
		// ���\�b�h�g���[�X�o��
		Log.method("", "OUT", "");
	}

	public void service(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {

		final HttpSession session = request.getSession(false);
		// �Z�b�V�����A�܂���userinfo���擾�ł��Ȃ��ꍇ�A�G���[�y�[�W�֑J��
		if (session == null || (UserInfoBean) session.getAttribute("userinfo") == null) {
			this.ctx.getRequestDispatcher(PED110_QuestionnaireAnkenKanriTopServlet.ERROR_PAGE).forward(request, response);
		} else {
			String loginNo = null;
			try {
				final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");
				loginNo = userinfo.getLogin_no();
				Log.performance(userinfo.getLogin_no(), true, "");
				// �A���P�[�gBean
				PED_PerformanceBean eBean = (PED_PerformanceBean) session.getAttribute(PED_PerformanceBean.SESSION_KEY);
				if (eBean == null) {
					eBean = new PED_PerformanceBean();
				}
				// �Z�b�V�����N���A
				eBean.setSousinTaisyoValueBean(null);
				eBean.setSoushinNaiyouSetteiBean(null);
				eBean.setAnkenTorokuKoshinValueBean(null);
				// �A���P�[�g��ʍ��ڊ֘ABean
				PED_QuestionnaireBean bean = eBean.getAnkenKanriBean();
				if (bean == null) {
					bean = new PED_QuestionnaireBean();
					eBean.setAnkenKanriBean(bean);
					final PED_QuestionnaireAnkenKanriBean Qbean = new PED_QuestionnaireAnkenKanriBean(userinfo.getLogin_no());
					bean.setBunruiList(Qbean.getBunruiList());
					bean.setStatusList(Qbean.getStatusList());
				}
				if (request.getParameter("no") != null) {
					bean.setNo(request.getParameter("no"));
				}
				if (request.getParameter("bunrui") != null) {
					bean.setBunrui(request.getParameter("bunrui"));
				}
				if (request.getParameterValues("status") != null) {
					bean.setStatus(request.getParameterValues("status"));
				}
				if (request.getParameter("kikan_kaisi") != null) {
					bean.setKikanKaisi(request.getParameter("kikan_kaisi"));
				}
				if (request.getParameter("kikan_shuryo") != null) {
					bean.setKikanSyuryo(request.getParameter("kikan_shuryo"));
				}
				eBean.setAnkenKanriBean(bean);
				session.setAttribute(PED_PerformanceBean.SESSION_KEY, eBean);
				// �Y��JSP�y�[�W�֑J��
				final RequestDispatcher rd = this.ctx.getRequestDispatcher(PED110_QuestionnaireAnkenKanriTopServlet.SUCCESS_PAGE);
				rd.forward(request, response);
				Log.performance(userinfo.getLogin_no(), false, "");

			} catch (final Exception e) {
				Log.error(loginNo, e);
				this.ctx.getRequestDispatcher(PED110_QuestionnaireAnkenKanriTopServlet.ERROR_PAGE).forward(request, response);
			}
		}
	}
}
