package jp.co.hisas.career.learning.base.valuebean;

import java.io.Serializable;

/**
 * <PRE>
 * 
 * �N���X���F PCY_TaisyosyaBean �N���X �@�\�����F �Ώێ҂�\��ValueBean�ł��B
 * 
 * </PRE>
 */
public class PCY_TaisyosyaExBean extends PCY_TaisyosyaBean implements Serializable {

	private String mousikomiJyokyo;
	private String jyukoJyokyo;

	public PCY_TaisyosyaExBean() {
	}
	public PCY_TaisyosyaExBean(PCY_TaisyosyaBean taisyosyaBean) {
		super.setPersonalBean(taisyosyaBean.getPersonalBean());
	}
	
	public String getMousikomiJyokyo() {
		return mousikomiJyokyo;
	}
	public void setMousikomiJyokyo(String mousikomiJyokyo) {
		this.mousikomiJyokyo = mousikomiJyokyo;
	}
	public String getJyukoJyokyo() {
		return jyukoJyokyo;
	}
	public void setJyukoJyokyo(String jyukoJyokyo) {
		this.jyukoJyokyo = jyukoJyokyo;
	}
	
	
}
