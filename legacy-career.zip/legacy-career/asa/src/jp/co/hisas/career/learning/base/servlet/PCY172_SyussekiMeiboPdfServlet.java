/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Map;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.base.sosiki.bean.SosikiBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.bean.PCY_CodeBean;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.pdf.PZE120_SyussekiMeiboPDF;

import com.lowagie.text.DocumentException;

/**
 * <PRE>
 * 
 * �T�v�F �o�ȎҖ����PDF�쐬���s���B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PCY172_SyussekiMeiboPdfServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException, IOException, DocumentException, Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		try {
			/* �g�D�}�b�v�擾 */
			final Map sosikiMap = PCY_CodeBean.getInstance().getCodeMap(PCY_CodeBean.SOSIKI);

			final PCY_TaisyoEJBHome taisyoHome = (PCY_TaisyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_TaisyoEJBHome.class);
			final PCY_TaisyoEJB taisyoEJB = taisyoHome.create();

			final PCY_ClassEJBHome classHome = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);

			final PCY_ClassEJB classEJB = classHome.create();

			final PCY_ClassBean classBean = classEJB.doSelectByPrimaryKey(new PCY_ClassBean(request), loginuser);

			final PCY_TaisyosyaBean[] taisyosyaBeans = taisyoEJB.getAllTaisyosya(classBean, false, loginuser);

			final String[] sosikiMei = new String[taisyosyaBeans.length];

			for (int i = 0; i < taisyosyaBeans.length; i++) {
				sosikiMei[i] = SosikiBean.getSosikiKaisouNameByCode(taisyosyaBeans[i].getPersonalBean().getSosikiCode(), loginuser.getSimeiNo());
			}

			/* �t�@�C���ǂݍ��ݗp�o�b�t�@ */
			final byte[] buffer = new byte[4096];

			/* �t�@�C�����e�̏o�� */
			final ServletOutputStream out = response.getOutputStream();

			/* PDF�쐬 */
			final PZE120_SyussekiMeiboPDF pdf = new PZE120_SyussekiMeiboPDF();

			/* contentType���o�� */
			response.setContentType("application/pdf");

			/* �t�@�C�����̑��M(attachment������inline�ɕύX����΃C�����C���\��) */
			response.setHeader("Content-Disposition", "inline;");

			final ByteArrayOutputStream baos = new ByteArrayOutputStream();
			boolean pdfOutput = pdf.makePDF(baos, classBean, taisyosyaBeans, sosikiMei, loginuser);
			final ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());

			if (!pdfOutput) {
				/* �G���[��ʂɑJ�� */
				this.getServletConfig().getServletContext().getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			}

			if (bais != null) {
				int size;
				while ((size = bais.read(buffer)) != -1) {
					out.write(buffer, 0, size);
				}
				bais.close();
			}
			out.close();
			response.flushBuffer();

			Log.performance(loginuser.getSimeiNo(), false, "");

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return null;
		} catch (final Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		}
	}
}
