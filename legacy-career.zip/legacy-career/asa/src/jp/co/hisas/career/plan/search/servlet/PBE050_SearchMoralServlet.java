/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.search.servlet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.sosiki.bean.SosikiBean;
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.plan.careerchallenge.bean.PBB_ChallengeBean;
import jp.co.hisas.career.plan.search.bean.PBE_SearchMoralBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ050_FileUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �����[���T�[�x�C���ʂ�CSV�f�[�^�o�͂��s��
 */
public class PBE050_SearchMoralServlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
	 * @param response Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet�̐���ȏ������W����ꂽ���ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = "";
		
		try {

			final HttpSession session = request.getSession(false);

			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");

				login_no = bean.getLogin_no();

				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				// ����ChallengeBean�Ăяo��
				PBB_ChallengeBean challengebean = (PBB_ChallengeBean) session.getAttribute("challenge");

				if (challengebean == null) {
					challengebean = new PBB_ChallengeBean(login_no);
					session.setAttribute("challenge", challengebean);
				}

				/* �����[���T�[�x�C�}�X�^�R�[�h���擾 */
				challengebean.SearchMoralCode();
				String[][] moralcode;
				moralcode = challengebean.getMoralCodeData();
				final int moralCount = moralcode.length;

				// ����SearchBean�Ăяo��
				PBE_SearchMoralBean searchmoralbean = (PBE_SearchMoralBean) session.getAttribute("searchmoral");

				if (searchmoralbean == null) {
					searchmoralbean = new PBE_SearchMoralBean(login_no);
					session.setAttribute("searchmoral", searchmoralbean);
				}

				final String engName = (String) ReadFile.fileMapData.get(HcdbDef.searchParam1);
				final String yakuMaster = (String) ReadFile.fileMapData.get(HcdbDef.yakusyoku_master);
				String busyoPos = (String) ReadFile.fileMapData.get(HcdbDef.busyo_code);
				String idoKibou = request.getParameter("C004_IdoKibou");

				if (idoKibou == null) {
					idoKibou = "0";
				} else {
					idoKibou = "1";
				}

				/* ���������w���ʂőI�������������擾 */
				final String nendo = PZZ010_CharacterUtil.strEncode(request.getParameter("S001_Kikan"));
				final String ki = request.getParameter("S002_Ki");
				final String simeino = PZZ010_CharacterUtil.strEncode(request.getParameter("T001_SimeiNo"));
				final String simeikanji = PZZ010_CharacterUtil.strEncode(request.getParameter("T002_SimeiKanji"));
				final String simeikana = PZZ010_CharacterUtil.strEncode(request.getParameter("T003_SimeiKana"));
				String simeieiji = "";
				final String buryakusyo = request.getParameter("S012_Busyo").trim();

				if (engName.equals("1")) {
					/* ���������w���ʂœ��͂��������p�����擾���� */
					simeieiji = PZZ010_CharacterUtil.strEncode(request.getParameter("T014_SimeiEiji"));
				}

				if (!buryakusyo.equals("")) {
					busyoPos = SosikiBean.getSosikiByCode(buryakusyo, login_no)[4];
				}

				/* �������T�[�x�C�f�[�^���擾 */
				String[][] moraldata;
				final String[] searchcnd = {
						engName,
						yakuMaster,
						busyoPos,
						idoKibou,
						nendo,
						ki,
						PZZ010_CharacterUtil.normalizedStr(simeino),
						PZZ010_CharacterUtil.normalizedStr(simeikanji),
						PZZ010_CharacterUtil.normalizedStr(simeikana),
						PZZ010_CharacterUtil.normalizedStr(simeieiji),
						buryakusyo };
				searchmoralbean.search_moral_list(searchcnd);
				moraldata = searchmoralbean.getMoralList();

				final ByteArrayOutputStream baos = new ByteArrayOutputStream();

				/* �ݖ���e�o�� */
				String setumon = "";
				byte[] add;
				for (int i = 0; i < moralCount; i++) {
					setumon = "\"" + "�ݖ�" + (i + 1) + "\"" + "," + "\"" + moralcode[i][1] + "\"" + HcdbDef.CSV_LINE_FEED_CODE;
					add = setumon.getBytes();
					baos.write(add);
				}
				/* �w�b�_���o�� */
				final String labelItem1 = (String) ReadFile.paramMapData.get("DZZ002");
				final String labelItem2 = (String) ReadFile.paramMapData.get("DZZ003");
				final String labelItem3 = (String) ReadFile.paramMapData.get("DZZ004");
				final String labelItem4 = (String) ReadFile.paramMapData.get("DZZ005");
				final String labelItem5 = (String) ReadFile.paramMapData.get("DZZ014");
				final String labelItem6 = (String) ReadFile.paramMapData.get("DZZ017");
				final String labelItem7 = (String) ReadFile.paramMapData.get("DZZ118");
				final String labelItem8 = (String) ReadFile.paramMapData.get("DZZ119");
				final String labelItem9 = (String) ReadFile.paramMapData.get("DZZ144");
				final String labelItem10 = (String) ReadFile.paramMapData.get("DZZ145");

				String header = "";

				header = HcdbDef.CSV_LINE_FEED_CODE + "\"" + labelItem1 + "\"" + "," + "\"" + labelItem2 + "\"" + "," + "\"" + labelItem3 + "\"" + ",";
				if (engName.equals("1")) {
					header = header + "\"" + labelItem4 + "\"" + ",";
				}
				header = header + "\"" + labelItem9 + "\"" + "," + "\"" + labelItem5 + "\"" + "," + "\"" + labelItem6 + "\"" + "," + "\"" + "�N��" + "\"" + "," + "\"" + labelItem10 + "\"" + "," + "\""
						+ "���Ԗ�" + "\"" + ",";

				for (int i = 0; i < moralcode.length; i++) {
					header = header + "\"" + "�ݖ�" + (i + 1) + "\"" + ",";
				}
				header = header + "\"" + labelItem8 + "\"";
				if (idoKibou.equals("1")) {
					header = header + "," + "\"" + labelItem7 + "\"";
				}

				header = header + HcdbDef.CSV_LINE_FEED_CODE;
				add = header.getBytes();
				baos.write(add);

				/* �f�[�^���o�� */
				// �ݖ�ɑ΂���񓚂��O�̔z��i�[���ڐ�
				int index = 9;
				int indadd = 0;
				if (engName.equals("1")) {
					index += 1;
					indadd = 1;
				}

				for (int i = 0; i < moraldata.length; i++) {
					String data = "";
					data = "\"" + moraldata[i][0].trim() + "\"" + ",";
					data = data + "\"" + moraldata[i][1].substring(1) + "\"" + ",";
					data = data + "\"" + moraldata[i][2].substring(1) + "\"" + ",";
					if (engName.equals("1")) {
						data = data + "\"" + moraldata[i][3].substring(1) + "\"" + ",";
					}
					data = data + "\"" + moraldata[i][3 + indadd] + "\"" + ",";
					data = data + "\"" + SosikiBean.getSosikiByCode(moraldata[i][3 + indadd].trim(), login_no)[2] + "\"" + ",";
					if (yakuMaster.equals("0")) {
						data = data + "\"" + moraldata[i][4 + indadd].substring(1) + "\"" + ",";
					} else {
						data = data + "\"" + moraldata[i][4 + indadd] + "\"" + ",";
					}
					final int age = (Integer.parseInt(PZZ010_CharacterUtil.GetDay()) - Integer.parseInt(moraldata[i][5 + indadd].substring(1))) / 10000;
					data = data + "\"" + Integer.toString(age) + "\"" + ",";
					data = data + "\"" + moraldata[i][6 + indadd].substring(1, 7) + "\"" + ",";
					data = data + "\"" + moraldata[i][7 + indadd] + "\"" + ",";

					int j;
					for (j = index; j < index + moralCount; j++) {
						// �o�͍��ڐ���25�𒴂����ꍇ
						if (j - index >= 25) {
							break;
						}
						data = data + "\"" + moraldata[i][j] + "\"" + ",";
					}

					// �ǋL����
					j = HcdbDef.tuiki_pos + indadd;

					// ���ړ��e26�`50�o�͂̃��[�v
					for (int n = j + 1; n < index + moralCount + 1; n++) {
						data = data + "\"" + moraldata[i][n] + "\"" + ",";
					}

					data = data + "\"" + moraldata[i][j] + "\"";
					// �ٓ��Ɋւ����]
					if (idoKibou.equals("1")) {
						data = data + "," + "\"" + moraldata[i][60] + "\"";
					}
					data = data + HcdbDef.CSV_LINE_FEED_CODE;
					add = data.getBytes();
					baos.write(add);
				}
				baos.close();

				/* ���샍�O�o�� */
				OutLogBean.sousaKojinJohoLog("SEA002", login_no, "", nendo + "," + simeino + "," + simeikanji + "," + simeikana + "," + simeieiji + "," + buryakusyo);

				final ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
				request.setAttribute("STREAM", bais);
				request.setAttribute("H080_FileName", PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_MORALSURVEY_LIST_CSV, new String[] { login_no }));

				final RequestDispatcher rd = this.ctx.getRequestDispatcher("/servlet/PYE010_FileDownloadServlet");
				rd.forward(request, response);

			}
			Log.performance(login_no, false, "");
			Log.method(login_no, "OUT", "");
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}
}