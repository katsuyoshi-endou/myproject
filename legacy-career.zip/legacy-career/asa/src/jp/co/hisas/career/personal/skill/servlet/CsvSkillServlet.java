/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.personal.skill.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Writer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.personal.accesslog.bean.AccesslogBean;
import jp.co.hisas.career.personal.skill.bean.SkillBean;
import jp.co.hisas.career.personal.skill.bean.SkillCsvValueBean;
import jp.co.hisas.career.personal.util.CsvConditionHeaderValueBean;
import jp.co.hisas.career.personal.util.CsvValueBeanList;
import jp.co.hisas.career.plan.base.VelocityHelper;
import jp.co.hisas.career.search.jiyukensaku.bean.JiyuKensakuBean;
import jp.co.hisas.career.util.common.PZZ050_FileUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �p�[�\�i���̃X�L���Ǘ�CSV�t�@�C���̏o�͂��s��
 */
public class CsvSkillServlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
	 * @param response Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet�̐���ȏ������W����ꂽ���ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = null;
		try {
			final HttpSession session = request.getSession(false);
			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
				final AccesslogBean accesslogbean = (AccesslogBean) session.getAttribute("accesslog");
				login_no = bean.getLogin_no();
				/* �J�n���O�o�� */
				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				String simei_no;
				String kanji_simei;
				String busyo_ryakusyou;
				final String hikokai = "����J";
				String syoriID = "";
				String logjouken = "";

				final String passfilter = request.getParameter("H999_PassFilter");

				simei_no = bean.getSimei_no_flg(); // ����NO
				kanji_simei = bean.getKanji_simei(); // �����i�����j
				final String server = bean.getServer();
				final String kokai_flg = bean.getSkill();

				/* CSV�o�̓t���O�̎擾 */
				final String csv_flg = request.getParameter("Csv_flg");

				/* �X�L���Ǘ�Bean�擾 */
				SkillBean skillbean = (SkillBean) session.getAttribute("skillinfo");
				
				//CsvValueBeanList�̍쐬
				CsvValueBeanList valueBeanList = new CsvValueBeanList();
				
				SkillCsvValueBean header = new SkillCsvValueBean();

				// �Ǝ�E�Ɩ��m��
				final String l_gyomu1 = (String) ReadFile.paramMapData.get("DZZ046");// �Ǝ�Ɩ����P
				final String l_gyomu2 = (String) ReadFile.paramMapData.get("DZZ047");// �Ǝ�Ɩ����Q
				final String l_gyomu3 = (String) ReadFile.paramMapData.get("DZZ048");// �Ǝ�Ɩ����R
				final String l_gyosyu_mei = (String) ReadFile.paramMapData.get("DZZ049");// �Ǝ햼
				final String l_gyomu_mei = (String) ReadFile.paramMapData.get("DZZ050");// �Ɩ���
				final String l_gyomu_level = (String) ReadFile.paramMapData.get("DZZ051");// ���x��
				final String l_gyomu_naiyo = (String) ReadFile.paramMapData.get("DZZ052");// �ڍד��e
			
				header.setShimeiNo((String) ReadFile.paramMapData.get("DZZ002"));
				header.setShimei((String) ReadFile.paramMapData.get("DZZ001"));
				header.setBusyo((String) ReadFile.paramMapData.get("DZZ013"));
				header.setOs1Name((String) ReadFile.paramMapData.get("DAB002") + "�P����");
				header.setOs1Level((String) ReadFile.paramMapData.get("DAB002") + "�P���x��");
				header.setOs2Name((String) ReadFile.paramMapData.get("DAB002") + "�Q����");
				header.setOs2Level((String) ReadFile.paramMapData.get("DAB002") + "�Q���x��");
				header.setOs3Name((String) ReadFile.paramMapData.get("DAB002") + "�R����");
				header.setOs3Level((String) ReadFile.paramMapData.get("DAB002") + "�R���x��");
				header.setOnline1Name((String) ReadFile.paramMapData.get("DAB003") + "�P����");
				header.setOnline1Level((String) ReadFile.paramMapData.get("DAB003") + "�P���x��");
				header.setOnline2Name((String) ReadFile.paramMapData.get("DAB003") + "�Q����");
				header.setOnline2Level((String) ReadFile.paramMapData.get("DAB003") + "�Q���x��");
				header.setOnline3Name((String) ReadFile.paramMapData.get("DAB003") + "�R����");
				header.setOnline3Level((String) ReadFile.paramMapData.get("DAB003") + "�R���x��");
				header.setDbms1Name((String) ReadFile.paramMapData.get("DAB004") + "�P����");
				header.setDbms1Level((String) ReadFile.paramMapData.get("DAB004") + "�P���x��");
				header.setDbms2Name((String) ReadFile.paramMapData.get("DAB004") + "�Q����");
				header.setDbms2Level((String) ReadFile.paramMapData.get("DAB004") + "�Q���x��");
				header.setDbms3Name((String) ReadFile.paramMapData.get("DAB004") + "�R����");
				header.setDbms3Level((String) ReadFile.paramMapData.get("DAB004") + "�R���x��");
				header.setProgram1Name((String) ReadFile.paramMapData.get("DAB005") + "�P����");
				header.setProgram1Level((String) ReadFile.paramMapData.get("DAB005") + "�P���x��");
				header.setProgram2Name((String) ReadFile.paramMapData.get("DAB005") + "�Q����");
				header.setProgram2Level((String) ReadFile.paramMapData.get("DAB005") + "�Q���x��");
				header.setProgram3Name((String) ReadFile.paramMapData.get("DAB005") + "�R����");
				header.setProgram3Level((String) ReadFile.paramMapData.get("DAB005") + "�R���x��");
				header.setSonotaSeihin1((String) ReadFile.paramMapData.get("DAB006") + "�P");
				header.setSonotaSeihin1Level((String) ReadFile.paramMapData.get("DAB006") + "�P���x��");
				header.setSonotaSeihin2((String) ReadFile.paramMapData.get("DAB006") + "�Q");
				header.setSonotaSeihin2Level((String) ReadFile.paramMapData.get("DAB006") + "�Q���x��");
				header.setSonotaSeihin3((String) ReadFile.paramMapData.get("DAB006") + "�R");
				header.setSonotaSeihin3Level((String) ReadFile.paramMapData.get("DAB006") + "�R���x��");
				header.setSonotaSeihin4((String) ReadFile.paramMapData.get("DAB006") + "�S");
				header.setSonotaSeihin4Level((String) ReadFile.paramMapData.get("DAB006") + "�S���x��");
				header.setSonotaSeihin5((String) ReadFile.paramMapData.get("DAB006") + "�T");
				header.setSonotaSeihin5Level((String) ReadFile.paramMapData.get("DAB006") + "�T���x��");
				header.setSonotaSeihin6((String) ReadFile.paramMapData.get("DAB006") + "�U");
				header.setSonotaSeihin6Level((String) ReadFile.paramMapData.get("DAB006") + "�U���x��");
				header.setSeihinShosaiNaiyo((String) ReadFile.paramMapData.get("DAB007") );
				header.setJinkoChino((String) ReadFile.paramMapData.get("DAC012"));
				header.setManMachineSystem((String) ReadFile.paramMapData.get("DAC013"));
				header.setDatabaseSystem((String) ReadFile.paramMapData.get("DAC014"));
				header.setBunsanSystem((String) ReadFile.paramMapData.get("DAC015"));
				header.setComputerNetwork((String) ReadFile.paramMapData.get("DAC016"));
				header.setComputerVision((String) ReadFile.paramMapData.get("DAC017"));
				header.setImageProcessing((String) ReadFile.paramMapData.get("DAC018"));
				header.setOperatingSystem((String) ReadFile.paramMapData.get("DAC019"));
				header.setSystemHyoka((String) ReadFile.paramMapData.get("DAC020"));
				header.setKeisankiArch((String) ReadFile.paramMapData.get("DAC021"));
				header.setGraphics((String) ReadFile.paramMapData.get("DAC022"));
				header.setBunshoShori((String) ReadFile.paramMapData.get("DAC023"));
				header.setSuchiKaiseki((String) ReadFile.paramMapData.get("DAC024"));
				header.setArgorithm((String) ReadFile.paramMapData.get("DAC025"));
				header.setGroupware((String) ReadFile.paramMapData.get("DAC026"));
				header.setComputerSecurity((String) ReadFile.paramMapData.get("DAC027"));
				header.setKigoShori((String) ReadFile.paramMapData.get("DAC028"));
				header.setProgramLanguage((String) ReadFile.paramMapData.get("DAC029"));
				header.setSonotaJohoShori1Name((String) ReadFile.paramMapData.get("DAB027") + "�P����");
				header.setSonotaJohoShori1Level((String) ReadFile.paramMapData.get("DAB027") + "�P���x��");
				header.setSonotaJohoShori2Name((String) ReadFile.paramMapData.get("DAB027") + "�Q����");
				header.setSonotaJohoShori2Level((String) ReadFile.paramMapData.get("DAB027") + "�Q���x��");
				header.setSonotaJohoShori3Name((String) ReadFile.paramMapData.get("DAB027") + "�R����");
				header.setSonotaJohoShori3Level((String) ReadFile.paramMapData.get("DAB027") + "�R���x��");
				header.setJohoShoriChishikiShosaiNaiyo((String) ReadFile.paramMapData.get("DAB028") );
				header.setGyoshu1GyoshuName(l_gyomu1 + l_gyosyu_mei);
				header.setGyoshu1GyomuName(l_gyomu1 + l_gyomu_mei);
				header.setGyoshu1Level(l_gyomu1 + l_gyomu_level);
				header.setGyoshu1ShosaiNaiyo(l_gyomu1 + l_gyomu_naiyo);
				header.setGyoshu2GyoshuName(l_gyomu2 + l_gyosyu_mei);
				header.setGyoshu2GyomuName(l_gyomu2 + l_gyomu_mei);
				header.setGyoshu2Level(l_gyomu2 + l_gyomu_level);
				header.setGyoshu2ShosaiNaiyo(l_gyomu2 + l_gyomu_naiyo);
				header.setGyoshu3GyoshuName(l_gyomu3 + l_gyosyu_mei);
				header.setGyoshu3GyomuName(l_gyomu3 + l_gyomu_mei);
				header.setGyoshu3Level(l_gyomu3 + l_gyomu_level);
				header.setGyoshu3ShosaiNaiyo(l_gyomu3 + l_gyomu_naiyo);
				header.setLeaderShip((String) ReadFile.paramMapData.get("DAC030"));
				header.setComunication((String) ReadFile.paramMapData.get("DAC031"));
				header.setNegotiation((String) ReadFile.paramMapData.get("DAC032"));
				header.setMondaiKaiketsu((String) ReadFile.paramMapData.get("DAC033"));
				header.setSoshikika((String) ReadFile.paramMapData.get("DAC034"));
				header.setHyojunka((String) ReadFile.paramMapData.get("DAC035"));
				header.setKokusaika((String) ReadFile.paramMapData.get("DAC036"));
				header.setSogoManagement((String) ReadFile.paramMapData.get("DAC037"));
				header.setScopeManagement((String) ReadFile.paramMapData.get("DAC038"));
				header.setTimeManagement((String) ReadFile.paramMapData.get("DAC039"));
				header.setCostManagement((String) ReadFile.paramMapData.get("DAC040"));
				header.setQualityManagement((String) ReadFile.paramMapData.get("DAC041"));
				header.setSoshikiManagement((String) ReadFile.paramMapData.get("DAC042"));
				header.setRiskManagement((String) ReadFile.paramMapData.get("DAC043"));
				header.setComunicationManagement((String) ReadFile.paramMapData.get("DAC044"));
				header.setChotatsuManagement((String) ReadFile.paramMapData.get("DAC045"));
				header.setJohoShushu((String) ReadFile.paramMapData.get("DAC046"));
				header.setKokyakuSessho((String) ReadFile.paramMapData.get("DAC047"));
				header.setTeianKatsudo((String) ReadFile.paramMapData.get("DAC048"));
				header.setPresentation((String) ReadFile.paramMapData.get("DAC049"));
				header.setChangeManagement((String) ReadFile.paramMapData.get("DAC050"));
				header.setShinkiKikaku((String) ReadFile.paramMapData.get("DAC051"));
				header.setJinmyakuKochiku((String) ReadFile.paramMapData.get("DAC052"));
				header.setTrouble((String) ReadFile.paramMapData.get("DAC053"));
				header.setGogaku((String) ReadFile.paramMapData.get("DAC054"));
				header.setBuisinessSkillSyosaiNaiyo((String) ReadFile.paramMapData.get("DZZ053"));

				valueBeanList.setHeader(header);

				if ("1".equals(csv_flg)) {
					if (skillbean == null) {
						skillbean = new SkillBean();
					}

					int count = 0;

					String simei_no_flg = "";
					String busyo_ryakusyo = "";

					final JiyuKensakuBean kensakubean = (JiyuKensakuBean) session.getAttribute("jiyukensaku");

					/* �K�{���� */
					final String[][] kekka = kensakubean.getKekka();

					if (kekka != null) {
						/*
						 * JiyuKensakuEJB��search���\�b�h�ɂ�����,���ʔz������Ƃ��� ���������{�P�̒����ɂ��Ă���̂�,������-1����B
						 */
						count = kekka.length - 1;
					} else {
						count = 0;
					}

					/* �����������w�b�_�ɏo�� */
					logjouken = kensakubean.getSQL1JP() + " " + kensakubean.getSQL2JP() + " " + kensakubean.getSQL3JP() + " " + kensakubean.getSQL4JP() + " " + kensakubean.getSQL5JP();
					if (request.getParameter("kensakujyoken") != null) {
						final String SQL1JP = kensakubean.getSQL1JP();
						final String SQL2JP = kensakubean.getSQL2JP();
						final String SQL3JP = kensakubean.getSQL3JP();
						final String SQL4JP = kensakubean.getSQL4JP();
						final String SQL5JP = kensakubean.getSQL5JP();

						//�ǉ��w�b�_���i�[����ValueBeanList
						CsvValueBeanList addHeaderList = new CsvValueBeanList();
						CsvConditionHeaderValueBean addHeader = null;

						if (SQL1JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL1JP);
							addHeaderList.add(addHeader);
						}
						if (SQL2JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL2JP);
							addHeaderList.add(addHeader);
						}
						if (SQL3JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL3JP);
							addHeaderList.add(addHeader);
						}
						if (SQL4JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL4JP);
							addHeaderList.add(addHeader);
						}
						if (SQL5JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL5JP);
							addHeaderList.add(addHeader);
						}

						//�e��ValueBeanList�ɒǉ��w�b�_��ݒ�
						valueBeanList.setAdditionalHeader(addHeaderList);
					}

					for (int j = 0; j < count; j++) {
						simei_no = kekka[j][0]; // ����NO

						bean.searchsansyo(simei_no, server, "1");
						simei_no_flg = bean.getSimei_no_flg();
						kanji_simei = bean.getKanji_simei();

						if (!simei_no_flg.equals(hikokai)) {
							/* ����NO�̓��ꌅ�폜 */
							simei_no_flg = simei_no_flg.substring(1, simei_no_flg.length());
						}

						if (!kanji_simei.equals(hikokai)) {
							/* �����i�����j�̓��ꌅ�폜 */
							final int kanji_simei_length = kanji_simei.length();
							kanji_simei = kanji_simei.substring(1, kanji_simei_length);
						}

						if (!bean.getBusyo_ryakusyo_mei().equals(hikokai)) {
							/* �������̖��̓��ꌅ�폜 */
							final int busyo_ryakusyou_length = bean.getBusyo_ryakusyo_mei().length();
							busyo_ryakusyo = bean.getBusyo_ryakusyo_mei().substring(1, busyo_ryakusyou_length);
						} else {
							busyo_ryakusyo = bean.getBusyo_ryakusyo_mei();
						}
						
						if (bean.getSkill_kokai_flg().equals(hikokai)) {
							SkillCsvValueBean valueBean = new SkillCsvValueBean();
							valueBean.setShimeiNo(simei_no_flg);
							valueBean.setShimei(kanji_simei);
							valueBean.setBusyo(busyo_ryakusyo);
							//����J
							valueBean.setHikokai(hikokai);
							
							valueBeanList.add(valueBean);
						} else {
							/* �E�����e�����������s�� */
							skillbean.searchskill(simei_no, login_no, server, kokai_flg);
							/* �X�L���Ǘ��f�[�^ */
							SkillCsvValueBean valueBean = skillbean.getCsvValue();
							valueBean.setShimeiNo(simei_no_flg);
							valueBean.setShimei(kanji_simei);
							valueBean.setBusyo(busyo_ryakusyo);
							
							valueBeanList.add(valueBean);

						}
					}

					syoriID = "PPP046";

					OutLogBean.sousaKojinJohoLog(syoriID, login_no, "", logjouken);
				} else {

					/* UserInfoBean���f�[�^�擾 */
					simei_no = bean.getSimei_no_flg(); // ����NO
					kanji_simei = bean.getKanji_simei(); // �����i�����j
					busyo_ryakusyou = bean.getBusyo_ryakusyo_mei(); // �������̖�

					if (!simei_no.equals(hikokai)) {
						/* ����NO�̓��ꌅ�폜 */
						simei_no = simei_no.substring(1, simei_no.length());
					}

					if(!hikokai.equals( kanji_simei )){
						/* �����i�����j�̓��ꌅ�폜 */
						final int kanji_simei_length = kanji_simei.length();
						kanji_simei = kanji_simei.substring(1, kanji_simei_length);
					}
					if(!hikokai.equals( busyo_ryakusyou )){
						/* �������̖��̓��ꌅ�폜 */
						final int busyo_ryakusyou_length = busyo_ryakusyou.length();
						busyo_ryakusyou = busyo_ryakusyou.substring(1, busyo_ryakusyou_length);
					}
					if (bean.getSkill_kokai_flg().equals(hikokai)) {
						SkillCsvValueBean valueBean = new SkillCsvValueBean();
						valueBean.setShimeiNo(simei_no);
						valueBean.setShimei(kanji_simei);
						valueBean.setBusyo(busyo_ryakusyou);
						//����J
						valueBean.setHikokai(hikokai);
						
						valueBeanList.add(valueBean);
					} else {

						skillbean = new SkillBean();
						simei_no = bean.getSimei_no();
						skillbean.searchskill(simei_no, login_no, server, kokai_flg);

						/* �X�L���Ǘ��f�[�^ */
						SkillCsvValueBean valueBean = skillbean.getCsvValue();
						valueBean.setShimeiNo(simei_no);
						valueBean.setShimei(kanji_simei);
						valueBean.setBusyo(busyo_ryakusyou);

						valueBeanList.add(valueBean);
		
					}

					if (passfilter != null && passfilter.equals("a")) {
						syoriID = "PPP023";
					} else {
						syoriID = "PPP011";
					}
					logjouken = simei_no;
					OutLogBean.sousaKojinJohoLog(syoriID, login_no, simei_no, null);
				}
				/* Velocity��p���āA�o�̓t�@�C���e���v���[�g�Ƀf�[�^��ݒ肷�� */
				final VelocityHelper vh = new VelocityHelper(HcdbDef.SKILL_CSV_TEMPLATE);
				vh.setParameter("BeanList", valueBeanList);
				final Writer w = vh.getWriter();
				final ByteArrayInputStream bais = new ByteArrayInputStream(w.toString().getBytes());
				request.setAttribute("H080_FileName", PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_PERSONAL_SKILL_CSV, new String[] { login_no }));
				request.setAttribute("H081_ContentType", HcdbDef.CONTENT_TYPE);
				request.setAttribute("STREAM", bais);
				
				final RequestDispatcher rd = this.ctx.getRequestDispatcher("/servlet/PYE010_FileDownloadServlet");
				rd.forward(request, response);

				/* �A�N�Z�X���O�b�r�u�o�͉񐔂��P���₷ */
				accesslogbean.skillCsvCount();
				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}

}