/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.TreeMap;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_KanrenKyoikuKamokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KanrenKyoikuKamokuEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_KensyuRirekiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KensyuRirekiEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_KanrenKyoikuKamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY111_ClassSyosaiServlet �N���X �@�\�����F �N���X�̈ꗗ���擾���܂��B
 * 
 * </PRE>
 */
public class PCY122_RirekiSyosaiServlet extends PCY010_ControllerServlet {
	/**
	 * ���N�G�X�g����v���C�}���L�[���擾���A�N���X�����擾���܂��B �N���X���̓��N�G�X�g(�������F"classBean")�Ɋi�[���܂��B �N���X��񂪑��݂��Ȃ��ꍇ�A���N�G�X�g�ɂ� null ���i�[����܂��B
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		final PCY_KensyuRirekiEJBHome home = (PCY_KensyuRirekiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KensyuRirekiEJBHome.class);
		final PCY_KensyuRirekiEJB ejb = home.create();
		final PCY_KensyuRirekiBean rirekiBean = ejb.doSelectByPrimaryKey(new PCY_KensyuRirekiBean(request), loginuser);

		if ("1".equals(request.getParameter("kanren_syokusyu_syutoku")) && rirekiBean.getKamokuCode() != null && !rirekiBean.getKamokuCode().equals("")) {
			final PCY_KanrenKyoikuKamokuEJBHome kanren_home = (PCY_KanrenKyoikuKamokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KanrenKyoikuKamokuEJBHome.class);
			final PCY_KanrenKyoikuKamokuEJB kanren_ejb = kanren_home.create();

			final PCY_KanrenKyoikuKamokuBean[] kanrenBeans = kanren_ejb.doSelectByKamokuCode(rirekiBean.getKamokuCode(), loginuser);
			final TreeMap kanrenList = new TreeMap();

			for (int i = 0; i < kanrenBeans.length; i++) {
				final StringBuffer key = new StringBuffer();

				key.append(kanrenBeans[i].getSyokusyuCode() + ",");
				key.append(kanrenBeans[i].getSenmonCode() + ",");
				key.append(kanrenBeans[i].getLevelCode());

				if (!kanrenList.containsKey(key.toString())) {

					kanrenList.put(key.toString(), kanrenBeans[i]);
				}
			}
			rirekiBean.setKanrenKamokuBeans((PCY_KanrenKyoikuKamokuBean[]) kanrenList.values().toArray(new PCY_KanrenKyoikuKamokuBean[0]));
		}

		request.setAttribute("rirekiBean", rirekiBean);

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
