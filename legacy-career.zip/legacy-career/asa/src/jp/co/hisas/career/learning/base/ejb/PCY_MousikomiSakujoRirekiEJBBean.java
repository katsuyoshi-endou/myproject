/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiSakujoRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PCY_MousikomiSakujoRirekiEJBBean�N���X �@�\�����F �\���폜�����ւ̑�����s���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="PCY_MousikomiSakujoRirekiEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_MousikomiSakujoRirekiEJBBean implements SessionBean {
	private SessionContext context = null;

	/**
	 * �\���폜�������쐬���܂��B
	 * @param mousikomiSakujoRireki �쐬���e
	 * @param loginuser ���O�C�����[�U
	 * @return
	 * @throws PCY_WarningException �C���T�[�g�� SQLException �����������ꍇ�A�y�я����������قȂ����ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doInsert(final PCY_MousikomiSakujoRirekiBean[] mousikomiSakujoRireki, final PCY_PersonalBean loginuser) throws PCY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// SQL�쐬
			final StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO ");
			sql.append(HcdbDef.L94_TBL);
			sql.append(" (");
			sql.append(PCY_MousikomiSakujoRirekiBean.getColumns());
			sql.append(") ");
			sql.append("  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,");
			sql.append("          ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,");
			sql.append("          ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,");
			sql.append("          ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,");
			sql.append("          ?,?,?,?,?,?,?,?)");

			Log.debug(sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// SQL�ݒ�
			ps = con.prepareStatement(sql.toString());

			// �����Ώې\���폜���𐔂������[�v����SQL���s
			int count = 0;
			for (int i = 0; i < mousikomiSakujoRireki.length; i++) {
				// �p�����[�^�ݒ�
				ps.setString(1, mousikomiSakujoRireki[i].getSyoribi());
				ps.setString(2, mousikomiSakujoRireki[i].getSyorijikoku());
				ps.setString(3, mousikomiSakujoRireki[i].getSyorisya());
				ps.setString(4, mousikomiSakujoRireki[i].getSyoriflg());
				ps.setString(5, mousikomiSakujoRireki[i].getSimei_no());
				ps.setString(6, mousikomiSakujoRireki[i].getKamoku_code());
				ps.setString(7, mousikomiSakujoRireki[i].getKamoku_mei1());
				ps.setString(8, mousikomiSakujoRireki[i].getKamoku_mei2());
				ps.setString(9, mousikomiSakujoRireki[i].getKamoku_mei3());
				ps.setString(10, mousikomiSakujoRireki[i].getKamoku_mei4());
				ps.setString(11, mousikomiSakujoRireki[i].getVersion_kanri());
				ps.setString(12, mousikomiSakujoRireki[i].getKamoku_group());
				ps.setString(13, mousikomiSakujoRireki[i].getKamoku_group_mei());
				ps.setString(14, mousikomiSakujoRireki[i].getCategory_code1());
				ps.setString(15, mousikomiSakujoRireki[i].getCategory_mei1());
				ps.setString(16, mousikomiSakujoRireki[i].getCategory_code2());
				ps.setString(17, mousikomiSakujoRireki[i].getCategory_mei2());
				ps.setString(18, mousikomiSakujoRireki[i].getCategory_code3());
				ps.setString(19, mousikomiSakujoRireki[i].getCategory_mei3());
				ps.setString(20, mousikomiSakujoRireki[i].getCategory_code4());
				ps.setString(21, mousikomiSakujoRireki[i].getCategory_mei4());
				ps.setString(22, mousikomiSakujoRireki[i].getCategory_code5());
				ps.setString(23, mousikomiSakujoRireki[i].getCategory_mei5());
				ps.setString(24, mousikomiSakujoRireki[i].getKanrimoto_code());
				ps.setString(25, mousikomiSakujoRireki[i].getKanrimoto_mei());
				if (mousikomiSakujoRireki[i].getTanka() == null || mousikomiSakujoRireki[i].getTanka().equals("")) {
					ps.setInt(26, 0);
				} else {
					ps.setInt(26, Integer.parseInt(mousikomiSakujoRireki[i].getTanka()));
				}
				ps.setString(27, mousikomiSakujoRireki[i].getKamoku_naiyou());
				ps.setString(28, mousikomiSakujoRireki[i].getJyukou_jyoken());
				ps.setString(29, mousikomiSakujoRireki[i].getYobi1());
				ps.setString(30, mousikomiSakujoRireki[i].getYobi2());
				ps.setString(31, mousikomiSakujoRireki[i].getClass_code());
				ps.setString(32, mousikomiSakujoRireki[i].getClass_mei());
				if (mousikomiSakujoRireki[i].getNissuu() == null || mousikomiSakujoRireki[i].getNissuu().equals("")) {
					ps.setFloat(33, 0);
				} else {
					ps.setFloat(33, Float.parseFloat(mousikomiSakujoRireki[i].getNissuu()));
				}
				ps.setString(34, mousikomiSakujoRireki[i].getKaisibi());
				ps.setString(35, mousikomiSakujoRireki[i].getSyuryobi());
				ps.setString(36, mousikomiSakujoRireki[i].getKaisaijikan());
				ps.setString(37, mousikomiSakujoRireki[i].getKaisijikoku());
				ps.setString(38, mousikomiSakujoRireki[i].getSyuryojikoku());
				ps.setString(39, mousikomiSakujoRireki[i].getMousikomi_kaisibi());
				ps.setString(40, mousikomiSakujoRireki[i].getMousikomi_syuryobi());
				ps.setString(41, mousikomiSakujoRireki[i].getJyukou_kigen());
				ps.setString(42, mousikomiSakujoRireki[i].getChiku_code());
				ps.setString(43, mousikomiSakujoRireki[i].getChiku_mei());
				ps.setString(44, mousikomiSakujoRireki[i].getKyositu_code());
				ps.setString(45, mousikomiSakujoRireki[i].getKyositu_mei());
				if (mousikomiSakujoRireki[i].getTeiin() == null || mousikomiSakujoRireki[i].getTeiin().equals("")) {
					ps.setInt(46, 0);
				} else {
					ps.setInt(46, Integer.parseInt(mousikomiSakujoRireki[i].getTeiin()));
				}
				if (mousikomiSakujoRireki[i].getKaisai_saisyo_ninzuu() == null || mousikomiSakujoRireki[i].getKaisai_saisyo_ninzuu().equals("")) {
					ps.setInt(47, 0);
				} else {
					ps.setInt(47, Integer.parseInt(mousikomiSakujoRireki[i].getKaisai_saisyo_ninzuu()));
				}
				ps.setString(48, mousikomiSakujoRireki[i].getKousi_code());
				ps.setString(49, mousikomiSakujoRireki[i].getKousi_mei());
				ps.setString(50, mousikomiSakujoRireki[i].getKisyo_ikkatsu_flg());
				ps.setString(51, mousikomiSakujoRireki[i].getZensya_taisyo_flg());
				ps.setString(52, mousikomiSakujoRireki[i].getMousikomi_kubun());
				ps.setString(53, mousikomiSakujoRireki[i].getSyonin_kubun());
				ps.setString(54, mousikomiSakujoRireki[i].getUketuke_kubun());
				ps.setString(55, mousikomiSakujoRireki[i].getHoukoku_kubun());
				ps.setString(56, mousikomiSakujoRireki[i].getNinsyo_kubun());
				ps.setString(57, mousikomiSakujoRireki[i].getHantei_kubun());
				ps.setString(58, mousikomiSakujoRireki[i].getKaisai_jyotai());
				ps.setString(59, mousikomiSakujoRireki[i].getAnnai_mail_kubun());
				ps.setString(60, mousikomiSakujoRireki[i].getFollow_mail_kubun());
				if (mousikomiSakujoRireki[i].getFollow_mail_nissuu1() == null || mousikomiSakujoRireki[i].getFollow_mail_nissuu1().equals("")) {
					ps.setInt(61, 0);
				} else {
					ps.setInt(61, Integer.parseInt(mousikomiSakujoRireki[i].getFollow_mail_nissuu1()));
				}
				if (mousikomiSakujoRireki[i].getFollow_mail_nissuu2() == null || mousikomiSakujoRireki[i].getFollow_mail_nissuu2().equals("")) {
					ps.setInt(62, 0);
				} else {
					ps.setInt(62, Integer.parseInt(mousikomiSakujoRireki[i].getFollow_mail_nissuu2()));
				}
				ps.setString(63, mousikomiSakujoRireki[i].getBikou());
				ps.setString(64, mousikomiSakujoRireki[i].getTaisyo_kubun());
				ps.setString(65, mousikomiSakujoRireki[i].getMousikomibi());
				ps.setString(66, mousikomiSakujoRireki[i].getMousikomijikoku());
				ps.setString(67, mousikomiSakujoRireki[i].getMousikomisya());
				ps.setString(68, mousikomiSakujoRireki[i].getSyoninbi1());
				ps.setString(69, mousikomiSakujoRireki[i].getSyoninjikoku1());
				ps.setString(70, mousikomiSakujoRireki[i].getSyoninsya1());
				ps.setString(71, mousikomiSakujoRireki[i].getSyoninbi2());
				ps.setString(72, mousikomiSakujoRireki[i].getSyoninjikoku2());
				ps.setString(73, mousikomiSakujoRireki[i].getSyoninsya2());
				ps.setString(74, mousikomiSakujoRireki[i].getUketukebi());
				ps.setString(75, mousikomiSakujoRireki[i].getUketukejikoku());
				ps.setString(76, mousikomiSakujoRireki[i].getUketukesya());
				// SQL���s
				count += ps.executeUpdate();
			}

			if (count != mousikomiSakujoRireki.length) {
				this.context.setRollbackOnly();
				throw new PCY_WarningException();
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");
			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
}
