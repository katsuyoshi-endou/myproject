/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.report.bean;

import java.io.Serializable;

/**
 * ���|�[�g�o�͑ΏێЈ�Bean
 * @author �Β�
 */
public class PED_ReportShainValueBean implements Serializable {

	/** �l�h�c */
	private String personID;

	/** �v���b�g�p���� */
	private String plotName;

	/** �m�I�\�͔����x */
	private String chitekiNyoryoku;

	/** ���[�L���O���`�x�[�V���� */
	private String workingMotivation;

	/** �p�t�H�[�}���X�]�[�� */
	private String performance;

	/** �l�g�D */
	private String kojinSoshiki;

	/** ���萬�� */
	private String anteiSeicho;

	/** �r�W�l�X���i�� */
	private String businessSuishinryoku;

	/** �֌W�\�z�� */
	private String kankeiKochikuryoku;

	/** �r�W�l�X�X�^�C���]�[�� */
	private String businessStyle;

	/** ���[�_�[�V�b�v�]�[�� */
	private String leadershipZone;

	/** ��E�h�c */
	private String postID;

	/** �K�w�i��E�j */
	private String kaisou;

	public String getAnteiSeicho() {
		return this.anteiSeicho;
	}

	public void setAnteiSeicho(final String anteiSeicho) {
		this.anteiSeicho = anteiSeicho;
	}

	public String getBusinessStyle() {
		return this.businessStyle;
	}

	public void setBusinessStyle(final String businessStyle) {
		this.businessStyle = businessStyle;
	}

	public String getBusinessSuishinryoku() {
		return this.businessSuishinryoku;
	}

	public void setBusinessSuishinryoku(final String businessSuishinryoku) {
		this.businessSuishinryoku = businessSuishinryoku;
	}

	public String getChitekiNyoryoku() {
		return this.chitekiNyoryoku;
	}

	public void setChitekiNyoryoku(final String chitekiNyoryoku) {
		this.chitekiNyoryoku = chitekiNyoryoku;
	}

	public String getKaisou() {
		return this.kaisou;
	}

	public void setKaisou(final String kaisou) {
		this.kaisou = kaisou;
	}

	public String getKankeiKochikuryoku() {
		return this.kankeiKochikuryoku;
	}

	public void setKankeiKochikuryoku(final String kankeiKochikuryoku) {
		this.kankeiKochikuryoku = kankeiKochikuryoku;
	}

	public String getKojinSoshiki() {
		return this.kojinSoshiki;
	}

	public void setKojinSoshiki(final String kojinSoshiki) {
		this.kojinSoshiki = kojinSoshiki;
	}

	public String getLeadershipZone() {
		return this.leadershipZone;
	}

	public void setLeadershipZone(final String leadershipZone) {
		this.leadershipZone = leadershipZone;
	}

	public String getPerformance() {
		return this.performance;
	}

	public void setPerformance(final String performance) {
		this.performance = performance;
	}

	public String getPersonID() {
		return this.personID;
	}

	public void setPersonID(final String personID) {
		this.personID = personID;
	}

	public String getPlotName() {
		return this.plotName;
	}

	public void setPlotName(final String plotName) {
		this.plotName = plotName;
	}

	public String getPostID() {
		return this.postID;
	}

	public void setPostID(final String postID) {
		this.postID = postID;
	}

	public String getWorkingMotivation() {
		return this.workingMotivation;
	}

	public void setWorkingMotivation(final String workingMotivation) {
		this.workingMotivation = workingMotivation;
	}

}
