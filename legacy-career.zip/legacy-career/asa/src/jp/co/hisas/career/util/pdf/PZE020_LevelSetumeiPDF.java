/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.util.pdf;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;

import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class PZE020_LevelSetumeiPDF {
	/* ���O�C��No */
	private String login_no;

	private String[][] setumei_list;

	private String syoku_name;

	private String senmon_name;

	private String level_name;

	/* �O��������ږ� */
	private final String pram_syokusyu = (String) ReadFile.paramMapData.get("DZZ008");

	private final String pram_senmon_bunya = (String) ReadFile.paramMapData.get("DZZ009");

	private final String pram_level = (String) ReadFile.paramMapData.get("DZZ010");

	/**
	 * @param login_no
	 */
	public PZE020_LevelSetumeiPDF(final String login_no) {
		this.login_no = login_no;
	}

	/**
	 * @param syoku_name
	 * @param senmon_name
	 * @param level_name
	 */
	public void setSkill(final String syoku_name, final String senmon_name, final String level_name) {
		this.syoku_name = syoku_name;
		this.senmon_name = senmon_name;
		this.level_name = level_name;
	}

	/**
	 * �o�͏����i�[����
	 * @param syoku_yakuwari
	 * @param senmon_yakuwari
	 */
	public void setData(final String[][] setumei_list) {
		this.setumei_list = setumei_list;
	}

	/**
	 * PDF���쐬����
	 * @return
	 */
	public void executePDF(final OutputStream ops) throws Exception {
		Log.method(this.login_no, "IN", "");
		/* �f�t�H���g�e�[�u���̐ݒ� */
		class MyTable extends Table {
			/**
			 * @param arg0
			 * @throws BadElementException
			 */
			public MyTable(final int arg0) throws BadElementException {
				super(arg0);
				this.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
				this.setDefaultVerticalAlignment(Element.ALIGN_MIDDLE);

				this.setPadding(2);
			}
		}

		/*
		 * Document�I�u�W�F�N�g�̐��� A4�c�́A Document document = new Document(PageSize.A4); A4���́ADocument document = new Document(PageSize.A4.rotate());
		 */
		final Document document = new Document(PageSize.A4);
		PdfWriter pw = null;

		try {
			/* PdfWriter�I�u�W�F�N�g�̐��� */
			pw = PdfWriter.getInstance(document, ops);
			pw.setCloseStream(true);

			/* �w�i�F */
			final Color BackColor = Color.white;

			/* �h�L�������g��OPEN */
			final HeaderFooter footer = new HeaderFooter(new Phrase("- "), new Phrase(" -"));
			footer.setBorderColor(BackColor);
			footer.setAlignment(Element.ALIGN_CENTER);
			document.setFooter(footer);
			document.open();

			/* �t�H���g�̐ݒ� */
			final float default_font_size = 10;
			final BaseFont bf = BaseFont.createFont("HeiseiMin-W3", "UniJIS-UCS2-HW-H", false);
			final Font font = new Font(bf, default_font_size);

			/* �P�s�X�y�[�X�̒�` */
			final Table space = new MyTable(1);
			space.setBorderColor(BackColor);
			space.addCell("");

			final int TableWidth = 100;

			/* �R���e���c�̋L�q */
			MyTable table;
			Cell cell;
			PdfPCell cellpdf = null;

			/* �w�b�_�̕\�� */
			final PdfPTable pTableHead = new PdfPTable(6);
			final int[] header_widths = { 10, 20, 15, 25, 10, 20 };
			pTableHead.setWidths(header_widths);
			pTableHead.setWidthPercentage(TableWidth);

			/* �E�� */
			cellpdf = new PdfPCell(new Phrase(this.pram_syokusyu + "�F", font));
			cellpdf.setBorderColor(BackColor);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			pTableHead.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.syoku_name, font));
			cellpdf.setBorderColor(BackColor);
			pTableHead.addCell(cellpdf);

			/* ��啪�� */
			cellpdf = new PdfPCell(new Phrase(this.pram_senmon_bunya + "�F", font));
			cellpdf.setBorderColor(BackColor);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			pTableHead.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.senmon_name, font));
			cellpdf.setBorderColor(BackColor);
			pTableHead.addCell(cellpdf);

			/* ���x�� */
			cellpdf = new PdfPCell(new Phrase(this.pram_level + "�F", font));
			cellpdf.setBorderColor(BackColor);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			pTableHead.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.level_name, font));
			cellpdf.setBorderColor(BackColor);
			pTableHead.addCell(cellpdf);

			document.add(pTableHead);

			/* �� */
			document.add(space);

			for (int i = 0; i < this.setumei_list.length; i++) {
				/* �f�o�b�O���O���o�� */
				Log.debug(this.setumei_list[i][2] + ":" + this.setumei_list[i][3] + ":" + this.setumei_list[i][4]);

				table = new MyTable(3);
				table.setBorderColor(BackColor);
				table.setWidth(TableWidth);
				final int[] setumei_widths = { 3, 5, 92 };
				table.setWidths(setumei_widths);

				/* �B���x�敪 */
				cell = new Cell(new Phrase("��", font));
				cell.setBorderColor(BackColor);
				table.addCell(cell);

				cell = new Cell(new Phrase(this.setumei_list[i][2], font));
				cell.setBorderColor(BackColor);
				cell.setColspan(2);
				table.addCell(cell);

				/* �B���x�敪���� */
				cell = new Cell(new Phrase("", font));
				cell.setBorderColor(BackColor);
				table.addCell(cell);

				cell = new Cell(new Phrase(this.setumei_list[i][3], font));
				cell.setBorderColor(BackColor);
				cell.setColspan(2);
				table.addCell(cell);

				/* �B���x�g�p�T�v */
				while (true) {
					cell = new Cell(new Phrase("", font));
					cell.setBorderColor(BackColor);
					cell.setColspan(2);
					table.addCell(cell);

					cell = new Cell(new Phrase(this.setumei_list[i][4], font));
					cell.setBorderColor(BackColor);
					table.addCell(cell);

					/* ���[�v�I������ */
					if (i + 1 == this.setumei_list.length) {
						break;
					} else if (!this.setumei_list[i][0].equals(this.setumei_list[i + 1][0])) {
						break;
					}
					i++;
				}
				document.add(table);
				document.add(space);
			}

		} catch (final BadElementException e) {
			Log.error(this.login_no, e);
			throw e;
		} catch (final DocumentException e) {
			Log.error(this.login_no, e);
			throw e;
		} catch (final IOException e) {
			Log.error(this.login_no, e);
			throw e;
		} catch (final Exception e) {
			Log.error(this.login_no, e);
			throw e;
		} finally {
			/* �h�L�������g����� */
			if (document != null) {
				try {
					document.close();
				} catch (final Exception e) {
					Log.error(this.login_no, e);
					throw e;
				}
			}
			if (pw != null) {
				try {
					pw.close();
				} catch (final Exception e) {
					Log.error(this.login_no, e);
					throw e;
				}
			}
		}
	}
}
