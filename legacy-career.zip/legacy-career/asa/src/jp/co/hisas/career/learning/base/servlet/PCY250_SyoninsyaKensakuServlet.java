/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_SyoninsyaBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PCY250_SyoninsyaKensakuServlet �N���X �@�\�����F ���O�C�����[�U�̏��F�Ҍ������s���B
 * 
 * </PRE>
 */
public class PCY250_SyoninsyaKensakuServlet extends PCY010_ControllerServlet {

	/**
	 * ���O�C�����[�U�̏��F�Ҍ������s�Ȃ��܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {

		final boolean lock = false;
		final String[] simeiNo = new String[1];
		// CHG#P-BPX-0301J-3004-S
		final PCY_PersonalBean[] reqPersonalBeans = (PCY_PersonalBean[]) request.getAttribute("personalBeans");
		/* ���C�Ǘ��҂ɂ�鏳�F�ҕύX�̏ꍇ */
		if (this.getForwardPath("success").indexOf("VCC371") != -1) {
			/* ���݂��Ȃ�����NO�̏ꍇ */
			if (reqPersonalBeans == null || reqPersonalBeans.length == 0) {
				request.setAttribute("syoninsyaList", new String[0]);
				request.setAttribute("reqPersonalBeans", reqPersonalBeans);
				return this.getForwardPath();
			}
			simeiNo[0] = reqPersonalBeans[0].getSimeiNo();
			/* �{�l�ɂ�鏳�F�ҕύX�̏ꍇ */
		} else {
			simeiNo[0] = loginuser.getSimeiNo();
		}
		// CHG#P-BPX-0301J-3004-E
		/* ���\�b�h�g���[�X�E�p�t�H�[�}���X�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final PCY_SyoninsyaEJBHome home = (PCY_SyoninsyaEJBHome) EJBHomeFactory.getInstance().lookup(PCY_SyoninsyaEJBHome.class);
		final PCY_SyoninsyaEJB ejb = home.create();
		Log.transaction(loginuser.getSimeiNo(), true, "");
		final PCY_SyoninsyaBean[] syoninsyaBeans = ejb.doSelect(simeiNo, lock, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		final PCY_PersonalEJBHome homePersonal = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
		final PCY_PersonalEJB ejbPersonal = homePersonal.create();

		String syoninsya1 = "";
		String[] syoninsyaList;
		/* ���F�҂��ݒ肳��Ă���ꍇ */
		if (syoninsyaBeans.length != 0) {
			syoninsya1 = syoninsyaBeans[0].getSyoninsya1();

			final String[] syoninsya = new String[1];
			syoninsya[0] = syoninsya1;

			Log.transaction(loginuser.getSimeiNo(), true, "");
			final PCY_PersonalBean[] personalBeans = ejbPersonal.getPersonalInfo(syoninsya, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");

			syoninsyaList = new String[6];
			if (syoninsya1 != null) {
				syoninsyaList[0] = personalBeans[0].getSimeiNo();
				syoninsyaList[1] = personalBeans[0].getKanjiSimei();
				syoninsyaList[2] = personalBeans[0].getKanaSimei();
				syoninsyaList[3] = personalBeans[0].getSosikiCode();
				syoninsyaList[4] = syoninsyaBeans[0].getKousinbi();
				syoninsyaList[5] = syoninsyaBeans[0].getKousinjikoku();
			}
		} else {
			syoninsyaList = new String[syoninsyaBeans.length];
			for (int i = 0; i < syoninsyaList.length; i++) {
				syoninsyaList[i] = "";
			}
		}
		request.setAttribute("syoninsyaList", syoninsyaList);
		request.setAttribute("reqPersonalBeans", reqPersonalBeans);
		try {
			OutLogBean.sousaKojinJohoLog("VCC371", loginuser.getSimeiNo(), reqPersonalBeans[0].getSimeiNo(), null);
		} catch (final Exception e) {
		}
		/* ���\�b�h�g���[�X�E�p�t�H�[�}���X�g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

}