/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_JyukouJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PCY144_JyukoJyokyoServlet �N���X �@�\�����F ��u�󋵂̈ꗗ���擾���܂��B
 * 
 * </PRE>
 */
public class PCY144_JyukoJyokyoServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		/* SyoninsyaEJB */
		final PCY_SyoninsyaEJBHome syoninsya_home = (PCY_SyoninsyaEJBHome) EJBHomeFactory.getInstance().lookup(PCY_SyoninsyaEJBHome.class);
		final PCY_SyoninsyaEJB syoninsya_ejb = syoninsya_home.create();

		Log.transaction(loginuser.getSimeiNo(), true, "");
		final PCY_JyukouJyokyoBean[] personalBeans = syoninsya_ejb.getKensyusyaListBySyoninsya(loginuser.getSimeiNo(), loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		request.setAttribute("personalBeans", personalBeans);

		float nissuu = 0;
		int total = 0;

		for (int i = 0; i < personalBeans.length; i++) {
			if (personalBeans[i].getNissuu() != null) {
				nissuu += personalBeans[i].getNissuu().floatValue();
			}

			if (personalBeans[i].getTotal() != null) {
				total += personalBeans[i].getTotal().intValue();
			}
		}
		try {
			OutLogBean.sousaKojinJohoLog("LNG002", loginuser.getSimeiNo(), "", loginuser.getSimeiNo());
		} catch (final Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
		}

		request.setAttribute("nissuu", Float.toString(nissuu));
		request.setAttribute("total", Integer.toString(total));

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
