/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.bean;

import java.io.Serializable;
import java.util.HashMap;

/**
 * �A���P�[�g�����e�i���X�����t�^Bean
 * @author torigoe
 */
public class PEX_EnqueteMaintenanceKengenFuyoValueBean implements Serializable {

	/** �Ώۃ��[�U�i�[HashMap */
	private HashMap targetUserBean = null;

	private boolean kengenFlg = false;

	/**
	 * targetUserBean���Z�b�g����
	 */
	public void setTargetUserBean(final HashMap targetUserBean) {
		this.targetUserBean = targetUserBean;
	}

	/**
	 * targetUserHashMap��Ԃ�
	 * @return
	 */
	public HashMap getTargetUserBean() {
		return this.targetUserBean;
	}

	/**
	 * kengenFlg��ݒ肷��
	 * @param kengenFlg
	 */
	public void setKengenFlg(final boolean kengenFlg) {
		this.kengenFlg = kengenFlg;
	}

	/**
	 * kengenFlg��Ԃ�
	 * @return
	 */
	public boolean getKengenFlg() {
		return this.kengenFlg;
	}

}
