/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_OsiraseEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_OsiraseEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_OsiraseBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F ���m�点���T�[�u���b�g�N���X �@�\�����F ���m�点�e�[�u�����f�[�^���X�V����
 * 
 * </PRE>
 */
public class PCX095_OsiraseKousinServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		final PCY_OsiraseEJBHome home = (PCY_OsiraseEJBHome) EJBHomeFactory.getInstance().lookup(PCY_OsiraseEJBHome.class);
		final PCY_OsiraseEJB ejb = home.create();

		/* �X�V�f�[�^���i�[���� */
		final PCY_OsiraseBean osiraseBeans = new PCY_OsiraseBean();

		final String editNo = request.getParameter("editNo");
		osiraseBeans.setHakkoubi(request.getParameter("hiduke_" + editNo));
		osiraseBeans.setHakkoujikoku(request.getParameter("syori_jikan_" + editNo));
		osiraseBeans.setSyubetsuFlg(request.getParameter("syubetu_" + editNo));
		osiraseBeans.setKigenbi(request.getParameter("kigen_" + editNo));
		osiraseBeans.setNaiyou(request.getParameter("HTMLcomment_" + editNo));
		osiraseBeans.setTsuutatsu_page(request.getParameter("tuutatu_" + editNo));
		osiraseBeans.setHyoujiFlg(request.getParameter("hyoji_flag_" + editNo));
		osiraseBeans.setseqNo(request.getParameter("seqNo_" + editNo));
		osiraseBeans.setKousinbi(request.getParameter("kousinbi_" + editNo));
		osiraseBeans.setKousinjikoku(request.getParameter("kousinjikoku_" + editNo));

		/* HTMLcomment���擾���A�G���R�[�h���ݒ肵�܂��B */
		try {
			final String comment = request.getParameter("HTMLcomment_" + editNo);
			String encComment;
// MOD 2017/12/13 COMTURE UTF-8�Ή� START
//			encComment = new String(comment.getBytes("iso-8859-1"), "Shift_JIS");
			encComment = new String(comment.getBytes("iso-8859-1"), "UTF-8");
// MOD 2017/12/13 COMTURE UTF-8�Ή� END
			osiraseBeans.setNaiyou(encComment);

			final String tuutatu = request.getParameter("tuutatu_" + editNo);
// MOD 2017/12/13 COMTURE UTF-8�Ή� START
//			final String encTuutatu = new String(tuutatu.getBytes("iso-8859-1"), "Shift_JIS");
			final String encTuutatu = new String(tuutatu.getBytes("iso-8859-1"), "UTF-8");
// MOD 2017/12/13 COMTURE UTF-8�Ή� END
			osiraseBeans.setTsuutatsu_page(encTuutatu);

		} catch (final UnsupportedEncodingException e) {
			request.setAttribute("warningID", "WCX070");
			final PCY_WarningException ex = new PCY_WarningException(e);
			throw ex;
		}

		/* �f�[�^���X�V���� */

		try {
			final int count = ejb.doUpdate(osiraseBeans, loginuser);
		} catch (final PCY_WarningException e) {
			request.setAttribute("warningID", "WCX070");
			throw e;
		}

		request.setAttribute("osiraseBeans", osiraseBeans);

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();
	}
}
