/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.personal.sikaku.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Writer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.personal.accesslog.bean.AccesslogBean;
import jp.co.hisas.career.personal.sikaku.bean.ShikakuCsvValueBean;
import jp.co.hisas.career.personal.sikaku.bean.SikakuBean;
import jp.co.hisas.career.personal.util.CsvConditionHeaderValueBean;
import jp.co.hisas.career.personal.util.CsvValueBeanList;
import jp.co.hisas.career.plan.base.VelocityHelper;
import jp.co.hisas.career.search.jiyukensaku.bean.JiyuKensakuBean;
import jp.co.hisas.career.util.common.PZZ050_FileUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �p�[�\�i�� ���i�Ƌ���CSV�f�[�^�o�͂��s��
 */
public class CsvSikakuServlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
	 * @param response Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet�̐���ȏ������W����ꂽ���ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = null;
		try {

			String simei_no = "";
			String simei_no_flg = "";
			String simei_no_2 = "";
			String kanji_simei = "";
			String busyo_ryakusyo = "";
			String server;
			int count = 0;
			final String hikokai = "����J";
			String syoriID = "";
			String logsimei = "";
			String logjouken = "";

			final HttpSession session = request.getSession(false);
			final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
			login_no = bean.getLogin_no();
			Log.method(login_no, "IN", "");
			Log.performance(login_no, true, "");

			//CSV ValueBeanList���쐬�i�e�ʁj
			CsvValueBeanList valueBeanList = new CsvValueBeanList();
			
			ShikakuCsvValueBean header = new ShikakuCsvValueBean();
			header.setShimeiNo((String) ReadFile.paramMapData.get("DZZ002"));
			header.setShimei((String) ReadFile.paramMapData.get("DZZ001"));
			header.setBusyo((String) ReadFile.paramMapData.get("DZZ013"));
			header.setShikakuCode((String) ReadFile.paramMapData.get("DZZ083"));
			header.setShikakuName((String) ReadFile.paramMapData.get("DZZ085"));
			header.setShikakuLevel((String) ReadFile.paramMapData.get("DZZ128"));
			header.setShutokuNengetsu((String) ReadFile.paramMapData.get("DZZ086"));
			header.setScore((String) ReadFile.paramMapData.get("DZZ087"));
			header.setSikkoNengetsu((String) ReadFile.paramMapData.get("DZZ088"));
			header.setYueki((String) ReadFile.paramMapData.get("DZZ089"));
			header.setNum((String) ReadFile.paramMapData.get("DZZ130"));
			header.setShikakuShubetsu((String) ReadFile.paramMapData.get("DZZ994"));
			
			//�w�b�_��ݒ�
			valueBeanList.setHeader(header);
			
			final String l_ari = "�L";
			final String l_nasi = "��";

			SikakuBean sikakubean = (SikakuBean) session.getAttribute("sikakuinfo");
			if (sikakubean == null) {
				sikakubean = new SikakuBean();
				session.setAttribute("sikakuinfo", sikakubean);
			}
			final AccesslogBean accesslogbean = (AccesslogBean) session.getAttribute("accesslog");
			simei_no = bean.getSimei_no();
			server = bean.getServer();

			/* CSV�o�̓t���O�̎擾 */
			final String csv_flg = request.getParameter("Csv_flg");

			/* ���R������������CSV�o�͂̏ꍇ */
			if (csv_flg.equals("1")) {
				final JiyuKensakuBean kensakubean = (JiyuKensakuBean) session.getAttribute("jiyukensaku");
				/* �K�{���� */
				final String kekka[][] = kensakubean.getKekka();
				if (kekka != null) {
					count = kekka.length - 1;
				} else {
					count = 0;
				}
				/* �����������w�b�_�ɏo�� */
				logjouken = kensakubean.getSQL1JP() + " " + kensakubean.getSQL2JP() + " " + kensakubean.getSQL3JP() + " " + kensakubean.getSQL4JP() + " " + kensakubean.getSQL5JP();
				if (request.getParameter("kensakujyoken") != null) {
					final String SQL1JP = kensakubean.getSQL1JP();
					final String SQL2JP = kensakubean.getSQL2JP();
					final String SQL3JP = kensakubean.getSQL3JP();
					final String SQL4JP = kensakubean.getSQL4JP();
					final String SQL5JP = kensakubean.getSQL5JP();

					//�ǉ��w�b�_���i�[����ValueBeanList
					CsvValueBeanList addHeaderList = new CsvValueBeanList();
					CsvConditionHeaderValueBean addHeader = null;

					if (SQL1JP.length() != 0) {
						addHeader = new CsvConditionHeaderValueBean();
						addHeader.setCondition(SQL1JP);
						addHeaderList.add(addHeader);
					}
					if (SQL2JP.length() != 0) {
						addHeader = new CsvConditionHeaderValueBean();
						addHeader.setCondition(SQL2JP);
						addHeaderList.add(addHeader);
					}
					if (SQL3JP.length() != 0) {
						addHeader = new CsvConditionHeaderValueBean();
						addHeader.setCondition(SQL3JP);
						addHeaderList.add(addHeader);
					}
					if (SQL4JP.length() != 0) {
						addHeader = new CsvConditionHeaderValueBean();
						addHeader.setCondition(SQL4JP);
						addHeaderList.add(addHeader);
					}
					if (SQL5JP.length() != 0) {
						addHeader = new CsvConditionHeaderValueBean();
						addHeader.setCondition(SQL5JP);
						addHeaderList.add(addHeader);
					}

					//�e��ValueBeanList�ɒǉ��w�b�_��ݒ�
					valueBeanList.setAdditionalHeader(addHeaderList);
				}

				for (int i = 0; i < count; i++) {

					simei_no = kekka[i][0]; // ����NO
					bean.searchsansyo(simei_no, server, "1");
					simei_no_flg = bean.getSimei_no_flg();
					kanji_simei = bean.getKanji_simei();

					if (!simei_no_flg.equals(hikokai)) {
						/* ����NO�̓��ꌅ�폜 */
						simei_no_flg = simei_no_flg.substring(1, simei_no_flg.length());
					}

					if (!kanji_simei.equals(hikokai)) {
						/* �����i�����j�̓��ꌅ�폜 */
						final int kanji_simei_length = kanji_simei.length();
						kanji_simei = kanji_simei.substring(1, kanji_simei_length);
					}

					if (!bean.getBusyo_ryakusyo_mei().equals(hikokai)) {
						/* �������̖��̓��ꌅ�폜 */
						final int busyo_ryakusyou_length = bean.getBusyo_ryakusyo_mei().length();
						busyo_ryakusyo = bean.getBusyo_ryakusyo_mei().substring(1, busyo_ryakusyou_length);
					} else {
						busyo_ryakusyo = bean.getBusyo_ryakusyo_mei();
					}
					
					if (bean.getFlg().equals("0") || !bean.getSikaku_kokai_flg().equals("����J")) {

						sikakubean.searchsikaku(simei_no, login_no);

						/* ���i�E�Ƌ��f�[�^ */
						final int line = sikakubean.getCount();
						final String[][] sikaku_data = sikakubean.getSikaku();

						/* ���i�E�Ƌ��f�[�^�o�� */
						ShikakuCsvValueBean valueBean = null;
						for (int k = 0; k < line; k++) {
							/* ����NO, �����i�����j, �������̖� */
							valueBean = new ShikakuCsvValueBean();
							valueBean.setShimeiNo(simei_no_flg);
							valueBean.setShimei(kanji_simei);
							valueBean.setBusyo(busyo_ryakusyo);
							valueBean.setShikakuCode(sikaku_data[k][0]);
							valueBean.setShikakuName(sikaku_data[k][1]);
							valueBean.setShikakuLevel(sikaku_data[k][2]);
							valueBean.setShutokuNengetsu(sikaku_data[k][3].trim());
							valueBean.setScore(sikaku_data[k][4].trim());
							valueBean.setSikkoNengetsu(sikaku_data[k][5].trim());
							valueBean.setYueki(sikaku_data[k][6].equals("1") ? l_ari : l_nasi);
							valueBean.setNum(sikaku_data[k][7]);
							valueBean.setShikakuShubetsu(sikaku_data[k][11]);
							
							//�e�ʂɊi�[
							valueBeanList.add(valueBean);

						}

						/* �A�N�Z�X���O�b�r�u�o�͉񐔂��P���₷ */
						accesslogbean.sikakuCsvCount();

					} else {
						ShikakuCsvValueBean valueBean = new ShikakuCsvValueBean();
						valueBean.setShimeiNo(simei_no_flg);
						valueBean.setShimei(kanji_simei);
						valueBean.setBusyo(busyo_ryakusyo);
						//����J
						valueBean.setHikokai(hikokai);
						
						//�e�ʂɊi�[
						valueBeanList.add(valueBean);
						
					}
				}
				syoriID = "PPP049";
				OutLogBean.sousaKojinJohoLog(syoriID, login_no, logsimei, logjouken);

				/* �p�[�\�i���v���t�@�C������̂b�r�u�o�͂̏ꍇ */
			} else {
				/* UserInfoBean���f�[�^�擾 */
				simei_no = bean.getSimei_no_flg(); // ����NO
				simei_no_2 = bean.getSimei_no(); // ����NO�t���O�Ȃ�
				kanji_simei = bean.getKanji_simei(); // �����i�����j
				busyo_ryakusyo = bean.getBusyo_ryakusyo_mei(); // �������̖�

				if (!simei_no.equals(hikokai)) {
					/* ����NO�̓��ꌅ�폜 */
					simei_no = simei_no.substring(1, simei_no.length());
				}

				if (!kanji_simei.equals(hikokai)) {
					/* �����i�����j�̓��ꌅ�폜 */
					final int kanji_simei_length = kanji_simei.length();
					kanji_simei = kanji_simei.substring(1, kanji_simei_length);
				}

				if (!busyo_ryakusyo.equals(hikokai)) {
					/* �������̖��̓��ꌅ�폜 */
					final int busyo_ryakusyou_length = busyo_ryakusyo.length();
					busyo_ryakusyo = busyo_ryakusyo.substring(1, busyo_ryakusyou_length);
				}

				// ���i�E�Ƌ��f�[�^�o��
				if (bean.getFlg().equals("0") || !bean.getSikaku_kokai_flg().equals("����J")) {

					sikakubean.searchsikaku(simei_no_2, login_no);
					final int line = sikakubean.getCount(); // ���R�[�h��
					final String[][] sikaku_data = sikakubean.getSikaku(); // �f�[�^�Q�����z��

					ShikakuCsvValueBean valueBean = null;
					for (int k = 0; k < line; k++) {
						/* ����NO, �����i�����j, �������̖� */
						valueBean = new ShikakuCsvValueBean();
						valueBean.setShimeiNo(simei_no);
						valueBean.setShimei(kanji_simei);
						valueBean.setBusyo(busyo_ryakusyo);
						valueBean.setShikakuCode(sikaku_data[k][0]);
						valueBean.setShikakuName(sikaku_data[k][1]);
						valueBean.setShikakuLevel(sikaku_data[k][2]);
						valueBean.setShutokuNengetsu(sikaku_data[k][3].trim());
						valueBean.setScore(sikaku_data[k][4].trim());
						valueBean.setSikkoNengetsu(sikaku_data[k][5].trim());
						valueBean.setYueki(sikaku_data[k][6].equals("1") ? l_ari : l_nasi);
						valueBean.setNum(sikaku_data[k][7]);
						valueBean.setShikakuShubetsu(sikaku_data[k][11]);
						
						//�e�ʂɊi�[
						valueBeanList.add(valueBean);
					}

					/* �A�N�Z�X���O�b�r�u�o�͉񐔂��P���₷ */
					accesslogbean.sikakuCsvCount();

				} else {
					ShikakuCsvValueBean valueBean = new ShikakuCsvValueBean();
					valueBean.setShimeiNo(simei_no);
					valueBean.setShimei(kanji_simei);
					valueBean.setBusyo(busyo_ryakusyo);
					//����J
					valueBean.setHikokai(hikokai);
					//�e�ʂɊi�[
					valueBeanList.add(valueBean);
				}
				syoriID = "PPP014";
				logsimei = simei_no;
				OutLogBean.sousaKojinJohoLog(syoriID, login_no, logsimei, logjouken);
			}
			/* Velocity��p���āA�o�̓t�@�C���e���v���[�g�Ƀf�[�^��ݒ肷�� */
			final VelocityHelper vh = new VelocityHelper(HcdbDef.SHIKAKU_CSV_TEMPLATE);
			vh.setParameter("BeanList", valueBeanList);
			final Writer w = vh.getWriter();
			final ByteArrayInputStream bais = new ByteArrayInputStream(w.toString().getBytes());
			request.setAttribute("H080_FileName", PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_PERSONAL_SIKAKU_CSV, new String[] { login_no }));
			request.setAttribute("H081_ContentType", HcdbDef.CONTENT_TYPE);
			request.setAttribute("STREAM", bais);
			
			final RequestDispatcher rd = this.ctx.getRequestDispatcher("/servlet/PYE010_FileDownloadServlet");
			rd.forward(request, response);

			Log.performance(login_no, false, "");
			Log.method(login_no, "OUT", "");
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}

}