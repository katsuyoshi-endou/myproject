/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/03/17  01.00       ���� ��F    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.valuebean;

import java.io.Serializable;

import javax.servlet.ServletRequest;

/**
 * <PRE>
 * 
 * �N���X���F PCY_DefaultBean �N���X �@�\�����F ���[�U�f�t�H���g��\��ValueBean�ł��B
 * 
 * </PRE>
 */
public class PCY_DefaultBean extends PCY_ValueBean implements Serializable {

	// ���[�U�f�t�H���g
	private String simeiNo = null;

	private String gamenId = null;

	private String koumokuId = null;

	private String defaultValue = null;

	// ���C�Ǘ������
	private String categoryCode1 = null;

	private String categoryCode2 = null;

	private String categoryCode3 = null;

	private String sort = null;

	private String chikuCode = null;

	private String kanrimotoCode = null;

	private String kisyoIkkatsuFlg = null;

	// ���ѓ��͉��
	private String kijyunten = null;

	private String syuryoHantei = null;

	// �Ȗړo�^���
	private String kamokuKanrimotoCode = null;

	private String kamokuCategoryCode1 = null;

	private String kamokuCategoryCode2 = null;

	private String kamokuCategoryCode3 = null;

	// �N���X�o�^���
	private String classClassCode = null;

	private String classMousikomiKubun = null;

	private String classSyoninKubun = null;

	private String classUketukeKubun = null;

	private String classHoukokuKubun = null;

	private String classHanteiKubun = null;

	private String classKisyoIkkatsuFlg = null;

	private String classZensyaTaisyoFlg = null;

	private String classMansekiFlg = null;

	private String classChikuCode = null;

	private String classKousiCode = null;

	private String classKyosituCode = null;

	private String classAnnaiMailKubun = null;

	private String classFollowMailKubun = null;

	/**
	 * �f�t�H���g�̃R���X�g���N�^�ł��B
	 */
	public PCY_DefaultBean() {
		super();
	}

	/**
	 * request ����l���擾���Č�������Bean���쐬���܂��B
	 * @param request �T�[�u���b�g���N�G�X�g
	 */
	public PCY_DefaultBean(final ServletRequest request) {

		this.setCategoryCode1(request.getParameter("category_code1"));
		this.setCategoryCode2(request.getParameter("category_code2"));
		this.setCategoryCode3(request.getParameter("category_code3"));
		this.setSort(request.getParameter("sort"));
		this.setChikuCode(request.getParameter("chiku_code"));
		this.setKanrimotoCode(request.getParameter("kanrimoto_code"));
		this.setKisyoIkkatsuFlg(request.getParameter("kisyo_ikkatsu_flg"));

		this.setKijyunten(request.getParameter("kijyunten"));
		this.setSyuryoHantei(request.getParameter("syuryo_hantei"));

		this.setKamokuKanrimotoCode(request.getParameter("kamoku_kanrimoto_code"));
		this.setKamokuCategoryCode1(request.getParameter("kamoku_category_code1"));
		this.setKamokuCategoryCode2(request.getParameter("kamoku_category_code2"));
		this.setKamokuCategoryCode3(request.getParameter("kamoku_category_code3"));

		this.setClassClassCode(request.getParameter("class_class_code"));
		this.setClassMousikomiKubun(request.getParameter("class_mousikomi_kubun"));
		this.setClassSyoninKubun(request.getParameter("class_syonin_kubun"));
		this.setClassUketukeKubun(request.getParameter("class_uketuke_kubun"));
		this.setClassHoukokuKubun(request.getParameter("class_houkoku_kubun"));
		this.setClassHanteiKubun(request.getParameter("class_hantei_kubun"));
		this.setClassKisyoIkkatsuFlg(request.getParameter("class_kisyo_ikkatsu_flg"));
		this.setClassZensyaTaisyoFlg(request.getParameter("class_zensya_taisyo_flg"));
		this.setClassMansekiFlg(request.getParameter("class_manseki_flg"));
		this.setClassChikuCode(request.getParameter("class_chiku_code"));
		this.setClassKousiCode(request.getParameter("class_kousi_code"));
		this.setClassKyosituCode(request.getParameter("class_kyositu_code"));
		this.setClassAnnaiMailKubun(request.getParameter("class_annai_mail_kubun"));
		this.setClassFollowMailKubun(request.getParameter("class_follow_mail_kubun"));

		this.setSimeiNo(request.getParameter("simei_no"));
		this.setGamenId(request.getParameter("gamen_id"));
		this.setKoumokuId(request.getParameter("koumoku_Id"));
		this.setDefaultValue(request.getParameter("default_value"));

	}

	/**
	 * @return
	 */
	public String getCategoryCode1() {
		return this.categoryCode1;
	}

	/**
	 * @return
	 */
	public String getCategoryCode2() {
		return this.categoryCode2;
	}

	/**
	 * @return
	 */
	public String getCategoryCode3() {
		return this.categoryCode3;
	}

	/**
	 * @return
	 */
	public String getChikuCode() {
		return this.chikuCode;
	}

	/**
	 * @return
	 */
	public String getClassAnnaiMailKubun() {
		return this.classAnnaiMailKubun;
	}

	/**
	 * @return
	 */
	public String getClassChikuCode() {
		return this.classChikuCode;
	}

	/**
	 * @return
	 */
	public String getClassClassCode() {
		return this.classClassCode;
	}

	/**
	 * @return
	 */
	public String getClassFollowMailKubun() {
		return this.classFollowMailKubun;
	}

	/**
	 * @return
	 */
	public String getClassHanteiKubun() {
		return this.classHanteiKubun;
	}

	/**
	 * @return
	 */
	public String getClassHoukokuKubun() {
		return this.classHoukokuKubun;
	}

	/**
	 * @return
	 */
	public String getClassKisyoIkkatsuFlg() {
		return this.classKisyoIkkatsuFlg;
	}

	/**
	 * @return
	 */
	public String getClassKousiCode() {
		return this.classKousiCode;
	}

	/**
	 * @return
	 */
	public String getClassKyosituCode() {
		return this.classKyosituCode;
	}

	/**
	 * @return
	 */
	public String getClassMansekiFlg() {
		return this.classMansekiFlg;
	}

	/**
	 * @return
	 */
	public String getClassMousikomiKubun() {
		return this.classMousikomiKubun;
	}

	/**
	 * @return
	 */
	public String getClassSyoninKubun() {
		return this.classSyoninKubun;
	}

	/**
	 * @return
	 */
	public String getClassUketukeKubun() {
		return this.classUketukeKubun;
	}

	/**
	 * @return
	 */
	public String getClassZensyaTaisyoFlg() {
		return this.classZensyaTaisyoFlg;
	}

	/**
	 * @return
	 */
	public String getDefaultValue() {
		return this.defaultValue;
	}

	/**
	 * @return
	 */
	public String getGamenId() {
		return this.gamenId;
	}

	/**
	 * @return
	 */
	public String getKamokuCategoryCode1() {
		return this.kamokuCategoryCode1;
	}

	/**
	 * @return
	 */
	public String getKamokuCategoryCode2() {
		return this.kamokuCategoryCode2;
	}

	/**
	 * @return
	 */
	public String getKamokuCategoryCode3() {
		return this.kamokuCategoryCode3;
	}

	/**
	 * @return
	 */
	public String getKamokuKanrimotoCode() {
		return this.kamokuKanrimotoCode;
	}

	/**
	 * @return
	 */
	public String getKanrimotoCode() {
		return this.kanrimotoCode;
	}

	/**
	 * @return
	 */
	public String getKijyunten() {
		return this.kijyunten;
	}

	/**
	 * @return
	 */
	public String getKisyoIkkatsuFlg() {
		return this.kisyoIkkatsuFlg;
	}

	/**
	 * @return
	 */
	public String getKoumokuId() {
		return this.koumokuId;
	}

	/**
	 * @return
	 */
	public String getSimeiNo() {
		return this.simeiNo;
	}

	/**
	 * @return
	 */
	public String getSort() {
		return this.sort;
	}

	/**
	 * @return
	 */
	public String getSyuryoHantei() {
		return this.syuryoHantei;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode1(final String string) {
		this.categoryCode1 = string;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode2(final String string) {
		this.categoryCode2 = string;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode3(final String string) {
		this.categoryCode3 = string;
	}

	/**
	 * @param string
	 */
	public void setChikuCode(final String string) {
		this.chikuCode = string;
	}

	/**
	 * @param string
	 */
	public void setClassAnnaiMailKubun(final String string) {
		this.classAnnaiMailKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassChikuCode(final String string) {
		this.classChikuCode = string;
	}

	/**
	 * @param string
	 */
	public void setClassClassCode(final String string) {
		this.classClassCode = string;
	}

	/**
	 * @param string
	 */
	public void setClassFollowMailKubun(final String string) {
		this.classFollowMailKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassHanteiKubun(final String string) {
		this.classHanteiKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassHoukokuKubun(final String string) {
		this.classHoukokuKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassKisyoIkkatsuFlg(final String string) {
		this.classKisyoIkkatsuFlg = string;
	}

	/**
	 * @param string
	 */
	public void setClassKousiCode(final String string) {
		this.classKousiCode = string;
	}

	/**
	 * @param string
	 */
	public void setClassKyosituCode(final String string) {
		this.classKyosituCode = string;
	}

	/**
	 * @param string
	 */
	public void setClassMansekiFlg(final String string) {
		this.classMansekiFlg = string;
	}

	/**
	 * @param string
	 */
	public void setClassMousikomiKubun(final String string) {
		this.classMousikomiKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassSyoninKubun(final String string) {
		this.classSyoninKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassUketukeKubun(final String string) {
		this.classUketukeKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassZensyaTaisyoFlg(final String string) {
		this.classZensyaTaisyoFlg = string;
	}

	/**
	 * @param string
	 */
	public void setDefaultValue(final String string) {
		this.defaultValue = string;
	}

	/**
	 * @param string
	 */
	public void setGamenId(final String string) {
		this.gamenId = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuCategoryCode1(final String string) {
		this.kamokuCategoryCode1 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuCategoryCode2(final String string) {
		this.kamokuCategoryCode2 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuCategoryCode3(final String string) {
		this.kamokuCategoryCode3 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuKanrimotoCode(final String string) {
		this.kamokuKanrimotoCode = string;
	}

	/**
	 * @param string
	 */
	public void setKanrimotoCode(final String string) {
		this.kanrimotoCode = string;
	}

	/**
	 * @param string
	 */
	public void setKijyunten(final String string) {
		this.kijyunten = string;
	}

	/**
	 * @param string
	 */
	public void setKisyoIkkatsuFlg(final String string) {
		this.kisyoIkkatsuFlg = string;
	}

	/**
	 * @param string
	 */
	public void setKoumokuId(final String string) {
		this.koumokuId = string;
	}

	/**
	 * @param string
	 */
	public void setSimeiNo(final String string) {
		this.simeiNo = string;
	}

	/**
	 * @param string
	 */
	public void setSort(final String string) {
		this.sort = string;
	}

	/**
	 * @param string
	 */
	public void setSyuryoHantei(final String string) {
		this.syuryoHantei = string;
	}

}
