/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PEY_KouboEJBBean �N���X �@�\�����F ������e�[�u���ւ̑�����s���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="PEY_KouboEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PEY_KouboEJBBean implements SessionBean {
	/**
	 * ������e�[�u������f�[�^�擾���Ԃ��܂��B
	 * @param osiraseBean ��������
	 * @param loginuser ���O�C�����[�U
	 * @param moreconditions IN�匟������
	 * @return PEY_KouboBean[] �擾����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PEY_KouboBean[] doSelect(final PEY_KouboBean osiraseBean, final PEY_PersonalBean loginuser, final Hashtable moreconditions) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		final Vector appendvalue = new Vector();

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// ���������̍쐬
			final Map conditions = osiraseBean.extractConditions();

			PEY_KouboBean[] kouboBeans = null;
			final StringBuffer sql = new StringBuffer();

			sql.append("SELECT * ");
			sql.append(" FROM " + HcdbDef.D01_TBL);

			final StringBuffer where = new StringBuffer();

			for (final Iterator ite = conditions.keySet().iterator(); ite.hasNext();) {
				final Object column = ite.next();
				where.append(" AND " + column + "=?");
			}

			if (moreconditions != null) {
				final Enumeration keys = moreconditions.keys();

				while (keys.hasMoreElements()) {
					final String key = (String) keys.nextElement();
					final Vector value = (Vector) moreconditions.get(key);
					where.append(" AND " + key + " IN(");

					for (int i = 0; i < value.size(); i++) {
						if (value != null && !((String) value.elementAt(i)).equals("")) {
							where.append("?,");
							appendvalue.add(value.elementAt(i));
						}
					}

					where.append(") ");
				}
			}

			sql.append(where.toString().replaceFirst("AND", "WHERE"));

			// ����e�[�u���\�[�g���̍쐬
			sql.append("  ORDER BY JIGYOBUTYO_SYONINBI");

			// �f�o�b�O�̏o��
			Log.debug(sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �������s
			ps = con.prepareStatement(sql.toString());

			final List kouboBeanList = new ArrayList();

			int count = 1;

			for (final Iterator ite = conditions.keySet().iterator(); ite.hasNext(); count++) {
				final Object key = ite.next();
				Log.debug(Integer.toString(count) + ":" + key + ":" + conditions.get(key));
				ps.setObject(count, conditions.get(key));
			}

			if (moreconditions != null) {
				for (int i = 0; i < appendvalue.size(); i++) {
					ps.setObject(count, appendvalue.elementAt(i));
					count++;
				}
			}

			rs = ps.executeQuery();

			while (rs.next()) {
				kouboBeanList.add(new PEY_KouboBean(rs, null));
			}

			rs.close();
			ps.clearParameters();
			kouboBeans = new PEY_KouboBean[kouboBeanList.size()];
			kouboBeanList.toArray(kouboBeans);

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return kouboBeans;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
}
