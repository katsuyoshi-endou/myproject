/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.base.valuebean;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletRequest;

import jp.co.hisas.career.department.offer.bean.PEB_KouboKibouAssessmentBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboKibouSyokusyuBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X��: PEY_KouboOubosyaBean �N���X �@�\����: ����_����҃e�[�u���̃f�[�^�ێ����s���B
 * 
 * </PRE>
 */
public class PEY_KouboOubosyaBean extends PEY_MasterBean implements Serializable {
	private String kouboankenid = null;

	private String simeino = null;

	private String sosikicode = null;

	private String oubosyagrade = null;

	private String oubosyarate = null;

	private String kibougyomu = null;

	private String siboudouki = null;

	private String jikopr = null;

	private String gouhistatus = null;

	private String saiyostatus = null;

	private String toiawasesyozoku = null;

	private String toiawasesimei = null;

	private String toiawasegaisen = null;

	private String toiawasenaisen = null;

	private String toiawasemail = null;

	private String renrakujikou = null;

	private final ArrayList kouboKibouSyokusyuList = new ArrayList();

	private final ArrayList KouboKibouAssessmentList = new ArrayList();

	/**
	 * �f�t�H���g�̃R���X�g���N�^
	 */
	public PEY_KouboOubosyaBean() {
	}

	/**
	 * �f�t�H���g�̃R���X�g���N�^
	 */
	public PEY_KouboOubosyaBean(final ServletRequest request) {
		this.setKouboankenid(request.getParameter("koubo_anken_id"));
		this.setSimeino(request.getParameter("simei_no"));
		this.setSosikicode(request.getParameter("sosiki_code"));
		this.setKouboankenid(request.getParameter("kouboankenid"));
		this.setSimeino(request.getParameter("simeino"));
		this.setSosikicode(request.getParameter("sosikicode"));
		this.setOubosyagrade(request.getParameter("oubosyagrade"));
		this.setOubosyarate(request.getParameter("oubosyarate"));
		this.setKibougyomu(request.getParameter("kibou_gyomu"));
		this.setSiboudouki(request.getParameter("sibou_douki"));
		this.setJikopr(request.getParameter("jiko_pr"));
		this.setGouhistatus(request.getParameter("gouhistatus"));
		this.setSaiyostatus(request.getParameter("saiyostatus"));
		this.setToiawasesyozoku(request.getParameter("toiawase_syozoku"));
		this.setToiawasesimei(request.getParameter("toiawase_simei"));
		this.setToiawasegaisen(request.getParameter("toiawase_gaisen"));
		this.setToiawasenaisen(request.getParameter("toiawase_naisen"));
		this.setToiawasemail(request.getParameter("toiawase_mail"));
		this.setRenrakujikou(request.getParameter("renraku_jikou"));
	}

	/**
	 * ResultSet ����l���擾���Č���_�����ValueBean���쐬���܂��B
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param TableName ���m�点���̃e�[�u����
	 */
	public PEY_KouboOubosyaBean(final ResultSet rs, final String TableName) throws SQLException {

		super(rs, TableName);

		try {
			this.setKouboankenid(rs.getString(this.getIdentifier() + "KOUBO_ANKEN_ID"));
			this.setSimeino(rs.getString(this.getIdentifier() + "SIMEI_NO"));
			this.setSosikicode(rs.getString(this.getIdentifier() + "SOSIKI_CODE"));
			this.setGouhistatus(rs.getString(this.getIdentifier() + "GOUHI_STATUS"));
			this.setSaiyostatus(rs.getString(this.getIdentifier() + "SAIYO_STATUS"));
			this.setOubosyagrade(rs.getString(this.getIdentifier() + "OUBOSYA_GRADE"));
			this.setOubosyarate(rs.getString(this.getIdentifier() + "OUBOSYA_RATE"));
			this.setKibougyomu(rs.getString(this.getIdentifier() + "KIBOU_GYOMU"));
			this.setSiboudouki(rs.getString(this.getIdentifier() + "SIBOU_DOUKI"));
			this.setJikopr(rs.getString(this.getIdentifier() + "JIKO_PR"));
			this.setToiawasesyozoku(rs.getString(this.getIdentifier() + "TOIAWASE_SYOZOKU"));
			this.setToiawasesimei(rs.getString(this.getIdentifier() + "TOIAWASE_SIMEI"));
			this.setToiawasegaisen(rs.getString(this.getIdentifier() + "TOIAWASE_GAISEN"));
			this.setToiawasenaisen(rs.getString(this.getIdentifier() + "TOIAWASE_NAISEN"));
			this.setToiawasemail(rs.getString(this.getIdentifier() + "TOIAWASE_MAIL"));
			this.setRenrakujikou(rs.getString(this.getIdentifier() + "RENRAKU_JIKOU"));

		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		}
	}

	/**
	 * <pre>
	 *           ����_����҃e�[�u���̌��������𒊏o���܂��B
	 *           �ȉ��̍��ڂ����������Ƃ��Ďg�p�ł��܂��B
	 *           �E����Č�ID
	 * </pre>
	 * 
	 * @return ���o���ꂽ��������
	 */
	public Map extractConditions() {
		final Map conditions = new LinkedHashMap();

		if (this.getKouboankenid() != null && !this.getKouboankenid().equals("")) {
			conditions.put("KOUBO_ANKEN_ID", this.getKouboankenid());
		}
		if (this.getSimeino() != null && !this.getSimeino().equals("")) {
			conditions.put("SIMEI_NO", this.getSimeino());
		}

		return conditions;
	}

	/**
	 * @param PEB_KouboKibouSyokusyuBean
	 * @return kouboKibouSyokusyuList
	 */
	public void addKouboKibouSyokusyuBean(final PEB_KouboKibouSyokusyuBean bean) {
		this.kouboKibouSyokusyuList.add(bean);
	}

	/**
	 * @param PEB_KouboKibouAssessmentBean
	 * @return KouboKibouAssessmentList
	 */
	public void addKouboKibouAssessmentBean(final PEB_KouboKibouAssessmentBean bean) {
		this.KouboKibouAssessmentList.add(bean);
	}

	/**
	 * @return gouhistatus
	 */
	public String getGouhistatus() {
		return this.gouhistatus;
	}

	/**
	 * @return jikopr
	 */
	public String getJikopr() {
		return this.jikopr;
	}

	/**
	 * @return kibougyomu
	 */
	public String getKibougyomu() {
		return this.kibougyomu;
	}

	/**
	 * @return kouboankenid
	 */
	public String getKouboankenid() {
		return this.kouboankenid;
	}

	/**
	 * @return oubosyagrade
	 */
	public String getOubosyagrade() {
		return this.oubosyagrade;
	}

	/**
	 * @return oubosyarate
	 */
	public String getOubosyarate() {
		return this.oubosyarate;
	}

	/**
	 * @return renrakujikou
	 */
	public String getRenrakujikou() {
		return this.renrakujikou;
	}

	/**
	 * @return saiyostatus
	 */
	public String getSaiyostatus() {
		return this.saiyostatus;
	}

	/**
	 * @return siboudouki
	 */
	public String getSiboudouki() {
		return this.siboudouki;
	}

	/**
	 * @return simeino
	 */
	public String getSimeino() {
		return this.simeino;
	}

	/**
	 * @return sosikicode
	 */
	public String getSosikicode() {
		return this.sosikicode;
	}

	/**
	 * @return toiawasegaisen
	 */
	public String getToiawasegaisen() {
		return this.toiawasegaisen;
	}

	/**
	 * @return toiawasemail
	 */
	public String getToiawasemail() {
		return this.toiawasemail;
	}

	/**
	 * @return toiawasenaisen
	 */
	public String getToiawasenaisen() {
		return this.toiawasenaisen;
	}

	/**
	 * @return toiawasesimei
	 */
	public String getToiawasesimei() {
		return this.toiawasesimei;
	}

	/**
	 * @return toiawasesyozoku
	 */
	public String getToiawasesyozoku() {
		return this.toiawasesyozoku;
	}

	/**
	 * @param string
	 */
	public void setGouhistatus(final String string) {
		this.gouhistatus = string;
	}

	/**
	 * @param string
	 */
	public void setJikopr(final String string) {
		this.jikopr = string;
	}

	/**
	 * @param string
	 */
	public void setKibougyomu(final String string) {
		this.kibougyomu = string;
	}

	/**
	 * @param string
	 */
	public void setKouboankenid(final String string) {
		this.kouboankenid = string;
	}

	/**
	 * @param string
	 */
	public void setOubosyagrade(final String string) {
		this.oubosyagrade = string;
	}

	/**
	 * @param string
	 */
	public void setOubosyarate(final String string) {
		this.oubosyarate = string;
	}

	/**
	 * @param string
	 */
	public void setRenrakujikou(final String string) {
		this.renrakujikou = string;
	}

	/**
	 * @param string
	 */
	public void setSaiyostatus(final String string) {
		this.saiyostatus = string;
	}

	/**
	 * @param string
	 */
	public void setSiboudouki(final String string) {
		this.siboudouki = string;
	}

	/**
	 * @param string
	 */
	public void setSimeino(final String string) {
		this.simeino = string;
	}

	/**
	 * @param string
	 */
	public void setSosikicode(final String string) {
		this.sosikicode = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasegaisen(final String string) {
		this.toiawasegaisen = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasemail(final String string) {
		this.toiawasemail = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasenaisen(final String string) {
		this.toiawasenaisen = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasesimei(final String string) {
		this.toiawasesimei = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasesyozoku(final String string) {
		this.toiawasesyozoku = string;
	}

}