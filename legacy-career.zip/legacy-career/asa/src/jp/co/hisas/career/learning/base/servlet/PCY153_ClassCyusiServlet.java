/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.CreateException;
import javax.mail.internet.AddressException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_KensyuMailSender;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.bean.PCY_KensyuKanriJohoBean;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY153_ClassCyusiServlet �N���X �@�\�����F �N���X���~���s���܂��B
 * 
 * </PRE>
 */
public class PCY153_ClassCyusiServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException, Exception {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		PCY_ClassBean classBean = new PCY_ClassBean(request);

		classBean.getKamokuBean().setKousinbi(null);
		classBean.getKamokuBean().setKousinjikoku(null);
		classBean.getKamokuBean().setKousinsya(null);

		/* �N���X�ڍ׏����擾���� */
		final PCY_ClassEJBHome classHome = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB classEjb = classHome.create();
		classBean = classEjb.doSelectByPrimaryKey(classBean, loginuser);

		/* ���C�Ǘ������擾 */
		final PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_MousikomiJyokyoEJB mousikomi_ejb = home.create();

		final PCY_KensyuKanriJohoBean[] KensyuKanriJohoBeans = mousikomi_ejb.getKensyuKanriJoho(classBean.getKamokuBean().getKamokuCode(), classBean.getClassCode(), "", "", loginuser);

		final PCY_MousikomiJyokyoBean[] MousikomiJyokyoBeans = mousikomi_ejb.getMousikomi(classBean.getKamokuBean().getKamokuCode(), classBean.getClassCode(), "", "", loginuser);
		final List mousikomisyaList = new ArrayList();
		final List taisyosyaList = new ArrayList();
		final PCY_MousikomiJyokyoBean mousikomi = new PCY_MousikomiJyokyoBean();
		for (int t = 0; t < KensyuKanriJohoBeans.length; t++) {
			mousikomisyaList.add(KensyuKanriJohoBeans[t].getMousikomiBean());
			taisyosyaList.add(KensyuKanriJohoBeans[t].getTaisyousyaBean());
		}

		final PCY_MousikomiJyokyoBean[] mousikomiBeans = new PCY_MousikomiJyokyoBean[mousikomisyaList.size()];
		mousikomisyaList.toArray(mousikomiBeans);

		final PCY_TaisyosyaBean[] taisyosyaBeans_cyusi = new PCY_TaisyosyaBean[taisyosyaList.size()];
		taisyosyaList.toArray(taisyosyaBeans_cyusi);

		/* �N���X���~���� */
		try {
			Log.transaction(loginuser.getSimeiNo(), true, "");
			classEjb.doClassCyusi(classBean, mousikomiBeans, taisyosyaBeans_cyusi, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");
		} catch (final PCY_WarningException e) {
			if ("WCC230".equals(e.getMessage())) {
				request.setAttribute("warningID", "WCC230");
			} else if ("WCC240".equals(e.getMessage())) {
				request.setAttribute("warningID", "WCC240");
			} else if ("WCC250".equals(e.getMessage())) {
				request.setAttribute("warningID", "WCC250");
			}
			throw e;
		}

		if (classBean.getAnnaiMailKubun().equals("1")) {
			/* �N���X�}�X�^�̈ē����[���敪���f�v�f�̏ꍇ�A���[���𑗐M���� */
			/* �N���X�ڍ׏����擾���� */
			classBean = classEjb.doSelectByPrimaryKey(classBean, loginuser);

			String[] simei_no;
			if (classBean.getZensyaTaisyoFlg().equals("1")) {

				/* �Ώێ҃��X�g���擾���� */
				simei_no = new String[MousikomiJyokyoBeans.length];
				for (int i = 0; i < simei_no.length; i++) {
					// DEL#2007/3/27 s-hiura
					for (int j = 0; j < taisyosyaList.size(); j++) {
						final String simei = mousikomiBeans[j].getSimeiNo();
						final String kubunn = taisyosyaBeans_cyusi[j].getTaisyoKubun();
						if (!"2".equals(kubunn)) {
							simei_no[i] = MousikomiJyokyoBeans[i].getSimeiNo();
						}
					}
					// DEL#2007/3/27 s-hiura
				}
			} else {

				/* �S�Ώێ҃��X�g���擾���� */
				/* TaisyoEJB */
				final PCY_TaisyoEJBHome taisyo_home = (PCY_TaisyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_TaisyoEJBHome.class);
				final PCY_TaisyoEJB taisyo_ejb = taisyo_home.create();
				final PCY_TaisyosyaBean[] taisyosyaBeans = taisyo_ejb.getAllTaisyosya(classBean, false, loginuser);

				simei_no = new String[taisyosyaBeans.length];
				for (int i = 0; i < simei_no.length; i++) {
					simei_no[i] = taisyosyaBeans[i].getSimeiNo();
				}
			}

			/* Mail���� */
			final PCY_PersonalEJBHome personalHome = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
			final PCY_PersonalEJB personalEjb = personalHome.create();

			Log.transaction(loginuser.getSimeiNo(), true, "");

			final PCY_PersonalBean[] personalBeans = personalEjb.getPersonalInfo(simei_no, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");

			final String MAILcomment = request.getParameter("MAILcomment");

			try {
				/* ���[�����M */
				PCY_KensyuMailSender.sendClassCyusi(personalBeans, classBean, loginuser, MAILcomment);
			} catch (final AddressException e) {
				request.setAttribute("warningID", "WCC140");
				throw new PCY_WarningException(e);
			} catch (final Exception e) {
				request.setAttribute("warningID", "WCC140");
				throw new PCY_WarningException(e);
			}
		}

		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
