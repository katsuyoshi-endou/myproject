/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.import_personal.ejb;

/**
 * Remote interface for ImportPersonalEJB.
 * @xdoclet-generated at 2005/11/07
 */
public interface ImportPersonalEJB extends javax.ejb.EJBObject {
	/**
	 * @throws NamingException
	 * @throws WrongArgumentException
	 * @throws SQLException
	 * @throws IOException
	 */
	public jp.co.hisas.addon.batch.import_personal.vo.BatchResultVO execute(jp.co.hisas.addon.batch.import_personal.vo.PersonalCsvVOList csvVOList) throws javax.naming.NamingException,
			jp.co.hisas.addon.batch.import_personal.exception.WrongArgumentException, java.sql.SQLException, java.io.IOException, java.rmi.RemoteException;

}
