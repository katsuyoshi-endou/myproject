/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.learning.result;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jp.co.hisas.addon.batch.util.SQLFactory;
import jp.co.hisas.addon.batch.util.TextReader;
import jp.co.hisas.addon.batch.util.csv.CSVParser;

/** CSV�捞 */
public class CSVImport {
	private static final CSVImport singleton = new CSVImport();

	private static final String SQL_FILE_PATH = "/jp/co/hisas/addon/batch/learning/result/SQL.properties";

	private static final String SQL_IMPORT_CSV_DATA;

	static {
		SQL_IMPORT_CSV_DATA = SQLFactory.getInstance().getSQL(CSVImport.SQL_FILE_PATH, "IMPORT_CSV_DATA");
	}

	/** �B��̃C���X�^���X��Ԃ� */
	public static CSVImport getInstance() {
		return CSVImport.singleton;
	}

	/**
	 * CSV�f�[�^�𐳋K����DB�ɕێ�����B �ۑ���e�[�u����CPW_IMPORT_CSV
	 */
	public void importCSVtoDB(final Connection conn, final String csvFilePath, final String charsetName, final String sessionSeq) throws IOException {

		TextReader csv = null;
		try {
			csv = new TextReader(csvFilePath, charsetName);
			final CSVParser cp = CSVParser.getInstance();
			PreparedStatement pstmt = null;
			try {
				pstmt = conn.prepareStatement(CSVImport.SQL_IMPORT_CSV_DATA);
				long row = 0;
				while (true) {
					final String token = csv.getLine();
					if (token == null) {
						break;
					}
					final String[] data = cp.parse(token);
					// ��s���ۑ�����
					if (data.length == 0) {
						pstmt.setString(1, sessionSeq);
						pstmt.setLong(2, row);
						pstmt.setLong(3, 0L);
						pstmt.setString(4, "");
						pstmt.execute();
					} else {
						for (int col = 0, len = data.length; col < len; ++col) {
							pstmt.setString(1, sessionSeq);
							pstmt.setLong(2, row);
							pstmt.setLong(3, col);
							pstmt.setString(4, data[col]);
							pstmt.execute();
						}
					}
					++row;
				}
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			} finally {
				try {
					pstmt.close();
				} catch (final SQLException e) {
					throw new RuntimeException(e);
				}
			}
		} finally {
			csv.dispose();
		}
	}
}
