/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.base.valuebean;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletRequest;

import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X��: PEY_KouboBean �N���X �@�\����: ����e�[�u���̃f�[�^�ێ����s���B
 * 
 * </PRE>
 */
public class PEY_KouboBean extends PEY_MasterBean implements Serializable {
	private String kouboankenid = null;

	private String kouboankenmei = null;

	private String jigyobumei = null;

	private String jigyoubutyomei = null;

	private String sosikicode = null;

	private String simeino = null;

	private String ankengaiyo = null;

	private Integer bosyuninzu = null;

	private String idoukiboujiki = null;

	private String kibousyokusyusonota = null;

	private String syozokukinmuti = null;

	private String kitaiyakuwaributyo = null;

	private String kitaiyakuwarisyuningisi = null;

	private String kitaiyakuwarigisi = null;

	private String kitaiyakuwariippan = null;

	private String gyomunaiyo = null;

	private String jobgrade = null;

	private String syokumurireki = null;

	private String oubosyayoukensonota = null;

	private String koubopr = null;

	private String sinseiriyu = null;

	private String syoristatus = null;

	private String jigyobutyosyoninbi = null;

	private String keieikaigibi = null;

	private String koukaibi = null;

	private String toiawasesyozoku = null;

	private String toiawasesimei = null;

	private String toiawasegaisen = null;

	private String toiawasenaisen = null;

	private String toiawasemail = null;

	private String renrakujikou = null;

	/**
	 * �f�t�H���g�̃R���X�g���N�^
	 */
	public PEY_KouboBean() {

	}

	/**
	 * �f�t�H���g�̃R���X�g���N�^
	 */
	public PEY_KouboBean(final ServletRequest request) {

		super(request);

		this.setAnkengaiyo(request.getParameter("anken_gaiyo"));
		try {
			this.setBosyuninzu(new Integer(request.getParameter("bosyu_ninzu")));
		} catch (final NumberFormatException e) {
			Log.debug(e.getMessage());
		}
		this.setGyomunaiyo(request.getParameter("gyomu_naiyo"));
		this.setIdoukiboujiki(request.getParameter("idou_kibou_jiki"));
		this.setJigyobumei(request.getParameter("jigyobu_mei"));
		this.setJigyoubutyomei(request.getParameter("jigyobutyo_mei"));
		this.setJigyobutyoSyoninbi(request.getParameter("jigyobutyo_syoninbi"));
		this.setJobgrade(request.getParameter("job_grade"));
		this.setKeieikaigibi(request.getParameter("keiei_kaigibi"));
		this.setKibousyokusyuSonota(request.getParameter("kibou_syokusyu_sonota"));
		this.setKitaiyakuwaributyo(request.getParameter("kitai_yakuwari_butyo"));
		this.setKitaiyakuwarigisi(request.getParameter("kitai_yakuwari_gisi"));
		this.setKitaiyakuwariippan(request.getParameter("kitai_yakuwari_ippan"));
		this.setKitaiyakuwarisyuningisi(request.getParameter("kitai_yakuwari_syuningisi"));
		this.setKouboankenid(request.getParameter("koubo_anken_id"));
		this.setKouboankenmei(request.getParameter("koubo_anken_mei"));
		this.setKoubopr(request.getParameter("koubo_pr"));
		this.setKoukaibi(request.getParameter("koukaibi"));
		this.setOubosyayoukensonota(request.getParameter("oubosya_youken_sonota"));
		this.setRenrakujikou(request.getParameter("renraku_jikou"));
		this.setSimeino(request.getParameter("simei_no"));
		this.setSinseiriyu(request.getParameter("sinsei_riyu"));
		this.setSosikicode(request.getParameter("sosiki_code"));
		this.setSyokumurireki(request.getParameter("syokumu_rireki"));
		this.setSyoristatus(request.getParameter("syori_status"));
		this.setSyozokukinmuti(request.getParameter("syozoku_kinmuti"));
		this.setToiawasegaisen(request.getParameter("toiawase_gaisen"));
		this.setToiawasemail(request.getParameter("toiawase_mail"));
		this.setToiawasenaisen(request.getParameter("toiawase_naisen"));
		this.setToiawasesimei(request.getParameter("toiawase_simei"));
		this.setToiawasesyozoku(request.getParameter("toiawase_syozoku"));

	}

	/**
	 * ResultSet ����l���擾���Ă��m�点ValueBean���쐬���܂��B
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param TableName ���m�点���̃e�[�u����
	 */
	public PEY_KouboBean(final ResultSet rs, final String TableName) throws SQLException {

		super(rs, TableName);

		try {

			this.setAnkengaiyo(rs.getString(this.getIdentifier() + "ANKEN_GAIYO"));
			if (rs.getString(this.getIdentifier() + "BOSYU_NINZU") != null) {
				this.setBosyuninzu(new Integer(rs.getInt(this.getIdentifier() + "BOSYU_NINZU")));
			} else {
				this.setBosyuninzu(null);
			}
			this.setGyomunaiyo(rs.getString(this.getIdentifier() + "GYOMU_NAIYO"));
			this.setIdoukiboujiki(rs.getString(this.getIdentifier() + "IDOU_KIBOU_JIKI"));
			this.setJigyobumei(rs.getString(this.getIdentifier() + "JIGYOBU_MEI"));
			this.setJigyoubutyomei(rs.getString(this.getIdentifier() + "JIGYOBUTYO_MEI"));
			this.setJigyobutyoSyoninbi(rs.getString(this.getIdentifier() + "JIGYOBUTYO_SYONINBI"));
			this.setJobgrade(rs.getString(this.getIdentifier() + "JOB_GRADE"));
			this.setKeieikaigibi(rs.getString(this.getIdentifier() + "KEIEI_KAIGIBI"));
			this.setKibousyokusyuSonota(rs.getString(this.getIdentifier() + "KIBOU_SYOKUSYU_SONOTA"));
			this.setKitaiyakuwaributyo(rs.getString(this.getIdentifier() + "KITAI_YAKUWARI_BUTYO"));
			this.setKitaiyakuwarigisi(rs.getString(this.getIdentifier() + "KITAI_YAKUWARI_GISI"));
			this.setKitaiyakuwariippan(rs.getString(this.getIdentifier() + "KITAI_YAKUWARI_IPPAN"));
			this.setKitaiyakuwarisyuningisi(rs.getString(this.getIdentifier() + "KITAI_YAKUWARI_SYUNINGISI"));
			this.setKouboankenid(rs.getString(this.getIdentifier() + "KOUBO_ANKEN_ID"));
			this.setKouboankenmei(rs.getString(this.getIdentifier() + "KOUBO_ANKEN_MEI"));
			this.setKoubopr(rs.getString(this.getIdentifier() + "KOUBO_PR"));
			this.setKoukaibi(rs.getString(this.getIdentifier() + "KOUKAIBI"));
			this.setOubosyayoukensonota(rs.getString(this.getIdentifier() + "OUBOSYA_YOUKEN_SONOTA"));
			this.setRenrakujikou(rs.getString(this.getIdentifier() + "RENRAKU_JIKOU"));
			this.setSimeino(rs.getString(this.getIdentifier() + "SIMEI_NO"));
			this.setSinseiriyu(rs.getString(this.getIdentifier() + "SINSEI_RIYU"));
			this.setSosikicode(rs.getString(this.getIdentifier() + "SOSIKI_CODE"));
			this.setSyokumurireki(rs.getString(this.getIdentifier() + "SYOKUMU_RIREKI"));
			this.setSyoristatus(rs.getString(this.getIdentifier() + "SYORI_STATUS"));
			this.setSyozokukinmuti(rs.getString(this.getIdentifier() + "SYOZOKU_KINMUTI"));
			this.setToiawasegaisen(rs.getString(this.getIdentifier() + "TOIAWASE_GAISEN"));
			this.setToiawasemail(rs.getString(this.getIdentifier() + "TOIAWASE_MAIL"));
			this.setToiawasenaisen(rs.getString(this.getIdentifier() + "TOIAWASE_NAISEN"));
			this.setToiawasesimei(rs.getString(this.getIdentifier() + "TOIAWASE_SIMEI"));
			this.setToiawasesyozoku(rs.getString(this.getIdentifier() + "TOIAWASE_SYOZOKU"));

		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		}
	}

	/**
	 * @return
	 */
	public String getAnkengaiyo() {
		return this.ankengaiyo;
	}

	/**
	 * @return
	 */
	public Integer getBosyuninzu() {
		return this.bosyuninzu;
	}

	/**
	 * @return
	 */
	public String getGyomunaiyo() {
		return this.gyomunaiyo;
	}

	/**
	 * @return
	 */
	public String getIdoukiboujiki() {
		return this.idoukiboujiki;
	}

	/**
	 * @return
	 */
	public String getJigyobumei() {
		return this.jigyobumei;
	}

	/**
	 * @return
	 */
	public String getJigyobutyoSyoninbi() {
		return this.jigyobutyosyoninbi;
	}

	/**
	 * @return
	 */
	public String getJobgrade() {
		return this.jobgrade;
	}

	/**
	 * @return
	 */
	public String getKeieikaigibi() {
		return this.keieikaigibi;
	}

	/**
	 * @return
	 */
	public String getKibousyokusyuSonota() {
		return this.kibousyokusyusonota;
	}

	/**
	 * @return
	 */
	public String getKitaiyakuwaributyo() {
		return this.kitaiyakuwaributyo;
	}

	/**
	 * @return
	 */
	public String getKitaiyakuwarigisi() {
		return this.kitaiyakuwarigisi;
	}

	/**
	 * @return
	 */
	public String getKitaiyakuwariippan() {
		return this.kitaiyakuwariippan;
	}

	/**
	 * @return
	 */
	public String getKitaiyakuwarisyuningisi() {
		return this.kitaiyakuwarisyuningisi;
	}

	/**
	 * @return
	 */
	public String getKouboankenid() {
		return this.kouboankenid;
	}

	/**
	 * @return
	 */
	public String getKouboankenmei() {
		return this.kouboankenmei;
	}

	/**
	 * @return
	 */
	public String getKoubopr() {
		return this.koubopr;
	}

	/**
	 * @return
	 */
	public String getKoukaibi() {
		return this.koukaibi;
	}

	/**
	 * @return
	 */
	public String getOubosyayoukensonota() {
		return this.oubosyayoukensonota;
	}

	/**
	 * @return
	 */
	public String getRenrakujikou() {
		return this.renrakujikou;
	}

	/**
	 * @return
	 */
	public String getSimeino() {
		return this.simeino;
	}

	/**
	 * @return
	 */
	public String getSinseiriyu() {
		return this.sinseiriyu;
	}

	/**
	 * @return
	 */
	public String getSosikicode() {
		return this.sosikicode;
	}

	/**
	 * @return
	 */
	public String getSyokumurireki() {
		return this.syokumurireki;
	}

	/**
	 * @return
	 */
	public String getSyoristatus() {
		return this.syoristatus;
	}

	/**
	 * @return
	 */
	public String getSyozokukinmuti() {
		return this.syozokukinmuti;
	}

	/**
	 * @return
	 */
	public String getToiawasegaisen() {
		return this.toiawasegaisen;
	}

	/**
	 * @return
	 */
	public String getToiawasemail() {
		return this.toiawasemail;
	}

	/**
	 * @return
	 */
	public String getToiawasenaisen() {
		return this.toiawasenaisen;
	}

	/**
	 * @return
	 */
	public String getToiawasesimei() {
		return this.toiawasesimei;
	}

	/**
	 * @return
	 */
	public String getToiawasesyozoku() {
		return this.toiawasesyozoku;
	}

	/**
	 * @param string
	 */
	public void setAnkengaiyo(final String string) {
		this.ankengaiyo = string;
	}

	/**
	 * @param string
	 */
	public void setBosyuninzu(final Integer integer) {
		this.bosyuninzu = integer;
	}

	/**
	 * @param string
	 */
	public void setGyomunaiyo(final String string) {
		this.gyomunaiyo = string;
	}

	/**
	 * @param string
	 */
	public void setIdoukiboujiki(final String string) {
		this.idoukiboujiki = string;
	}

	/**
	 * @param string
	 */
	public void setJigyobumei(final String string) {
		this.jigyobumei = string;
	}

	/**
	 * @param string
	 */
	public void setJigyobutyoSyoninbi(final String string) {
		this.jigyobutyosyoninbi = string;
	}

	/**
	 * @param string
	 */
	public void setJobgrade(final String string) {
		this.jobgrade = string;
	}

	/**
	 * @param string
	 */
	public void setKeieikaigibi(final String string) {
		this.keieikaigibi = string;
	}

	/**
	 * @param string
	 */
	public void setKibousyokusyuSonota(final String string) {
		this.kibousyokusyusonota = string;
	}

	/**
	 * @param string
	 */
	public void setKitaiyakuwaributyo(final String string) {
		this.kitaiyakuwaributyo = string;
	}

	/**
	 * @param string
	 */
	public void setKitaiyakuwarigisi(final String string) {
		this.kitaiyakuwarigisi = string;
	}

	/**
	 * @param string
	 */
	public void setKitaiyakuwariippan(final String string) {
		this.kitaiyakuwariippan = string;
	}

	/**
	 * @param string
	 */
	public void setKitaiyakuwarisyuningisi(final String string) {
		this.kitaiyakuwarisyuningisi = string;
	}

	/**
	 * @param string
	 */
	public void setKouboankenid(final String string) {
		this.kouboankenid = string;
	}

	/**
	 * @param string
	 */
	public void setKouboankenmei(final String string) {
		this.kouboankenmei = string;
	}

	/**
	 * @param string
	 */
	public void setKoubopr(final String string) {
		this.koubopr = string;
	}

	/**
	 * @param string
	 */
	public void setKoukaibi(final String string) {
		this.koukaibi = string;
	}

	/**
	 * @param string
	 */
	public void setOubosyayoukensonota(final String string) {
		this.oubosyayoukensonota = string;
	}

	/**
	 * @param string
	 */
	public void setRenrakujikou(final String string) {
		this.renrakujikou = string;
	}

	/**
	 * @param string
	 */
	public void setSimeino(final String string) {
		this.simeino = string;
	}

	/**
	 * @param string
	 */
	public void setSinseiriyu(final String string) {
		this.sinseiriyu = string;
	}

	/**
	 * @param string
	 */
	public void setSosikicode(final String string) {
		this.sosikicode = string;
	}

	/**
	 * @param string
	 */
	public void setSyokumurireki(final String string) {
		this.syokumurireki = string;
	}

	/**
	 * @param string
	 */
	public void setSyoristatus(final String string) {
		this.syoristatus = string;
	}

	/**
	 * @param string
	 */
	public void setSyozokukinmuti(final String string) {
		this.syozokukinmuti = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasegaisen(final String string) {
		this.toiawasegaisen = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasemail(final String string) {
		this.toiawasemail = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasenaisen(final String string) {
		this.toiawasenaisen = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasesimei(final String string) {
		this.toiawasesimei = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasesyozoku(final String string) {
		this.toiawasesyozoku = string;
	}

	/**
	 * <pre>
	 *     ����e�[�u���̌��������𒊏o���܂��B
	 *     �ȉ��̍��ڂ����������Ƃ��Ďg�p�ł��܂��B
	 *     �E����Č�ID
	 * </pre>
	 * 
	 * @return ���o���ꂽ��������
	 */
	public Map extractConditions() {
		final Map conditions = new LinkedHashMap();

		if (this.getKouboankenid() != null && !this.getKouboankenid().equals("")) {
			conditions.put("KOUBO_ANKEN_ID", this.getKouboankenid());
		}
		if (this.getSyoristatus() != null && !this.getSyoristatus().equals("")) {
			conditions.put("SYORI_STATUS", this.getSyoristatus());
		}

		return conditions;
	}

	/**
	 * @return
	 */
	public String getJigyoubutyomei() {
		return this.jigyoubutyomei;
	}

	/**
	 * @param string
	 */
	public void setJigyoubutyomei(final String string) {
		this.jigyoubutyomei = string;
	}

}