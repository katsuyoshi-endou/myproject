/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.department.base.PEY_DBUtils;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.valuebean.PEY_BaseCodeBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PEY_CodeEJBBean�N���X �@�\�����F �e��}�X�^����ꗗ���擾���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="PEY_CodeEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PEY_CodeEJBBean implements SessionBean {
	private static final String[][] tables = {
			{ HcdbDef.p_kamoku_groupTbl, "KAMOKU_GROUP_CODE", "KAMOKU_GROUP" },
			{ HcdbDef.L03_TBL, "CATEGORY_CODE1", "CATEGORY_MEI1" },
			{ HcdbDef.L04_TBL, "CATEGORY_CODE2", "CATEGORY_MEI2" },
			{ HcdbDef.L05_TBL, "CATEGORY_CODE3", "CATEGORY_MEI3" },
			{ HcdbDef.L06_TBL, "CATEGORY_CODE4", "CATEGORY_MEI4" },
			{ HcdbDef.L07_TBL, "CATEGORY_CODE5", "CATEGORY_MEI5" },
			{ HcdbDef.L08_TBL, "KANRIMOTO_CODE", "KANRIMOTO_MEI" },
			{ HcdbDef.L09_TBL, "CHIKU_CODE", "CHIKU_MEI" },
			{ HcdbDef.L10_TBL, "KYOSITU_CODE", "KYOSITU_MEI" },
			{ HcdbDef.L11_TBL, "KOUSI_CODE", "KOUSI_MEI" },
			{ HcdbDef.p_kyoiku_kubunTbl, "KYOIKU_KUBUN_CODE", "KYOIKU_KUBUN" },
			{ HcdbDef.sosikiTbl, "SOSIKI_CODE", "SOSIKI_MEI" } };

	private SessionContext context = null;

	/**
	 * �e��}�X�^����ꗗ���擾���AMap �Ɋi�[���ĕԂ��܂��B �߂�l�̓}�X�^���ƃ}�X�^�̓��e�� Map �ŁA�}�X�^���e�́A�R�[�h�Ɩ��̂� Map �ł��B
	 * @return �e��}�X�^�̈ꗗ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public Map getCodeMaps() {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method("", "IN", "");

			final Map ret = new HashMap();
			con = PZZ040_SQLUtility.getConnection("");

			for (int i = 0; i < PEY_CodeEJBBean.tables.length; i++) {
				ps = con.prepareStatement("SELECT " + PEY_CodeEJBBean.tables[i][1] + ", " + PEY_CodeEJBBean.tables[i][2] + " FROM " + PEY_CodeEJBBean.tables[i][0]);

				rs = ps.executeQuery();
				final Map code = new LinkedHashMap();

				while (rs.next()) {
					code.put(rs.getString(PEY_CodeEJBBean.tables[i][1]), rs.getString(PEY_CodeEJBBean.tables[i][2]));
				}

				ret.put(PEY_CodeEJBBean.tables[i][0], code);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method("", "OUT", "");

			return ret;
		} catch (final NamingException e) {
			Log.error("", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error("", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error("", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection("", con, ps, rs);
		}
	}

	/**
	 * �e��R�[�h�}�X�^�̃f�[�^���Q�Ƃ��܂��B
	 * @param baseCodeBean PEY_BaseCodeBean �̌�������
	 * @param lock true�̏ꍇ���b�N����Afalse�̏ꍇ���b�N�Ȃ�
	 * @param loginuser ���O�C�����[�U
	 * @return ��������
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PEY_BaseCodeBean[] doSelect(final PEY_BaseCodeBean baseCodeBean, final boolean lock, final PEY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		// map �쐬
		final Map codeMap = new HashMap();
		final Map nameMap = new HashMap();

		for (int i = 0; i < PEY_CodeEJBBean.tables.length; i++) {
			codeMap.put(PEY_CodeEJBBean.tables[i][0], PEY_CodeEJBBean.tables[i][1]);
			nameMap.put(PEY_CodeEJBBean.tables[i][0], PEY_CodeEJBBean.tables[i][2]);
		}

		try {
			final String tabName = baseCodeBean.getCodeTableName();
			final String codeCol = (String) codeMap.get(tabName);
			final String nameCol = (String) nameMap.get(tabName);

			final Collection ret = new ArrayList();
			final StringBuffer sql = new StringBuffer();
			sql.append("SELECT ");
			sql.append(codeCol + ", ");
			sql.append(nameCol + ", ");
			sql.append("        TOUROKUBI,");
			sql.append("        TOUROKUJIKOKU,");
			sql.append("        TOUROKUSYA,");
			sql.append("        KOUSINBI,");
			sql.append("        KOUSINJIKOKU,");
			sql.append("        KOUSINSYA ");
			sql.append("  FROM ");
			sql.append(tabName);
			sql.append("  WHERE ");
			sql.append(codeCol + "=?");

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// ���b�N
			sql.append(PEY_DBUtils.getInstance().getLock(lock));

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �������s
			Log.debug(sql.toString());
			ps = con.prepareStatement(sql.toString());

			ps.setString(1, baseCodeBean.getCode());

			rs = ps.executeQuery();

			while (rs.next()) {
				ret.add(new PEY_BaseCodeBean(rs, tabName, codeCol, nameCol));
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return (PEY_BaseCodeBean[]) ret.toArray(new PEY_BaseCodeBean[0]);
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * �e��R�[�h�}�X�^�Ƀf�[�^��}�����܂��B
	 * @param baseCodeBeans �X�V����PEY_BaseCodeBean�̔z��
	 * @param loginuser ���O�C�����[�U
	 * @return �쐬����
	 * @throws PEY_WarningException �C���T�[�g�� SQLException �����������ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doInsert(final PEY_BaseCodeBean[] baseCodeBeans, final PEY_PersonalBean loginuser) throws PEY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		// map �쐬
		final Map codeMap = new HashMap();
		final Map nameMap = new HashMap();

		for (int i = 0; i < PEY_CodeEJBBean.tables.length; i++) {
			codeMap.put(PEY_CodeEJBBean.tables[i][0], PEY_CodeEJBBean.tables[i][1]);
			nameMap.put(PEY_CodeEJBBean.tables[i][0], PEY_CodeEJBBean.tables[i][2]);
		}

		try {
			final String tabName = baseCodeBeans[0].getCodeTableName();

			final StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO ");
			sql.append(tabName);
			sql.append(" (");
			sql.append((String) codeMap.get(tabName) + ", ");
			sql.append((String) nameMap.get(tabName) + ", ");
			sql.append("    TOUROKUBI, ");
			sql.append("    TOUROKUJIKOKU, ");
			sql.append("    TOUROKUSYA, ");
			sql.append("    KOUSINBI, ");
			sql.append("    KOUSINJIKOKU, ");
			sql.append("    KOUSINSYA ) ");
			sql.append("  VALUES ( ?, ?, ?, ?, ?, ?, ?, ? )");

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �}�����s
			ps = con.prepareStatement(sql.toString());

			int count = 0;

			for (int i = 0; i < baseCodeBeans.length; i++) {
				ps.setString(1, baseCodeBeans[i].getCode());
				ps.setString(2, baseCodeBeans[i].getName());
				ps.setString(3, PZZ010_CharacterUtil.GetDay());
				ps.setString(4, PZZ010_CharacterUtil.GetTime());
				ps.setString(5, loginuser.getSimeiNo());
				ps.setString(6, "        ");
				ps.setString(7, "      ");
				ps.setString(8, "          ");
				count += ps.executeUpdate();
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * �e��R�[�h�}�X�^�Ƀf�[�^��}�����܂��B
	 * @param baseCodeBean �}������PEY_BaseCodeBean
	 * @param loginuser ���O�C�����[�U
	 * @return �쐬����
	 * @throws PEY_WarningException �C���T�[�g�� SQLException �����������ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doInsert(final PEY_BaseCodeBean baseCodeBean, final PEY_PersonalBean loginuser) throws PEY_WarningException {
		return this.doInsert(new PEY_BaseCodeBean[] { baseCodeBean }, loginuser);
	}

	/**
	 * �e��R�[�h�}�X�^����f�[�^���폜���܂��B
	 * @param baseCodeBeans �X�V����PEY_BaseCodeBean�̔z��
	 * @param loginuser ���O�C�����[�U
	 * @return �폜����
	 * @throws PEY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍ폜����������Ȃ������ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doDelete(final PEY_BaseCodeBean[] baseCodeBeans, final PEY_PersonalBean loginuser) throws PEY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		// map �쐬
		final Map codeMap = new HashMap();

		for (int i = 0; i < PEY_CodeEJBBean.tables.length; i++) {
			codeMap.put(PEY_CodeEJBBean.tables[i][0], PEY_CodeEJBBean.tables[i][1]);
		}

		try {
			final String tabName = baseCodeBeans[0].getCodeTableName();

			final StringBuffer sql = new StringBuffer();
			sql.append("DELETE FROM ");
			sql.append(tabName);
			sql.append("  WHERE ");
			sql.append((String) codeMap.get(tabName) + "=? ");

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �폜���s
			ps = con.prepareStatement(sql.toString());

			int count = 0;

			for (int i = 0; i < baseCodeBeans.length; i++) {
				ps.setString(1, baseCodeBeans[i].getCode());
				count += ps.executeUpdate();
			}

			if (baseCodeBeans.length != count) {
				this.context.setRollbackOnly();
				throw new PEY_WarningException();
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * �e��R�[�h�}�X�^����f�[�^���폜���܂��B
	 * @param baseCodeBean �폜����PEY_BaseCodeBean
	 * @param loginuser ���O�C�����[�U
	 * @return �쐬����
	 * @throws PEY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍ폜����������Ȃ������ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doDelete(final PEY_BaseCodeBean baseCodeBean, final PEY_PersonalBean loginuser) throws PEY_WarningException {
		return this.doDelete(new PEY_BaseCodeBean[] { baseCodeBean }, loginuser);
	}

	/**
	 * �e��R�[�h�}�X�^�Ƀf�[�^���X�V���܂��B
	 * @param baseCodeBeans �X�V����PEY_BaseCodeBean�̔z��
	 * @param currentBeans �X�V�O��PEY_BaseCodeBean�̔z��
	 * @param loginuser ���O�C�����[�U
	 * @return �쐬����
	 * @throws PEY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdate(final PEY_BaseCodeBean[] baseCodeBeans, final PEY_PersonalBean loginuser) throws PEY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		// map �쐬
		final Map codeMap = new HashMap();
		final Map nameMap = new HashMap();

		for (int i = 0; i < PEY_CodeEJBBean.tables.length; i++) {
			codeMap.put(PEY_CodeEJBBean.tables[i][0], PEY_CodeEJBBean.tables[i][1]);
			nameMap.put(PEY_CodeEJBBean.tables[i][0], PEY_CodeEJBBean.tables[i][2]);
		}

		try {
			final String tabName = baseCodeBeans[0].getCodeTableName();

			final StringBuffer sql = new StringBuffer();
			sql.append("UPDATE ");
			sql.append(tabName);
			sql.append("    SET ");
			sql.append((String) nameMap.get(tabName) + "=?, ");
			sql.append("        KOUSINBI=?,");
			sql.append("        KOUSINJIKOKU=?,");
			sql.append("        KOUSINSYA=? ");
			sql.append("  WHERE ");
			sql.append((String) codeMap.get(tabName) + "=? ");
			sql.append("    AND TOUROKUBI=?");
			sql.append("    AND TOUROKUJIKOKU=?");
			sql.append("    AND TOUROKUSYA=?");
			sql.append("    AND KOUSINBI=?");
			sql.append("    AND KOUSINJIKOKU=?");
			sql.append("    AND KOUSINSYA=?");

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �}�����s
			ps = con.prepareStatement(sql.toString());

			int count = 0;

			for (int i = 0; i < baseCodeBeans.length; i++) {
				ps.setString(1, baseCodeBeans[i].getName());
				ps.setString(2, PZZ010_CharacterUtil.GetDay());
				ps.setString(3, PZZ010_CharacterUtil.GetTime());
				ps.setString(4, loginuser.getSimeiNo());
				ps.setString(5, baseCodeBeans[i].getCode());
				ps.setString(6, baseCodeBeans[i].getTourokubi());
				ps.setString(7, baseCodeBeans[i].getTourokujikoku());
				ps.setString(8, baseCodeBeans[i].getTourokusya());
				ps.setString(9, baseCodeBeans[i].getKousinbi());
				ps.setString(10, baseCodeBeans[i].getKousinjikoku());
				ps.setString(11, baseCodeBeans[i].getKousinsya());

				count += ps.executeUpdate();
			}

			if (baseCodeBeans.length != count) {
				this.context.setRollbackOnly();
				throw new PEY_WarningException();
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * �e��R�[�h�}�X�^�Ƀf�[�^���X�V���܂��B
	 * @param baseCodeBean �X�V����PEY_BaseCodeBean
	 * @param currentBean �X�V�O��PEY_BaseCodeBean
	 * @param loginuser ���O�C�����[�U
	 * @return �쐬����
	 * @throws PEY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdate(final PEY_BaseCodeBean baseCodeBean, final PEY_PersonalBean loginuser) throws PEY_WarningException {
		return this.doUpdate(new PEY_BaseCodeBean[] { baseCodeBean }, loginuser);
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
}
