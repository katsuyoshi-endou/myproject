/*
 * All Rights Reserved, Copyright (C) 2004,Hitachi System & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�Г�����@�\�j
 *
 * ���l�@�F
 *
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/11  01.00       �y��         �V�K�쐬
 *
 */

package jp.co.hisas.career.department.offer.bean;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * <PRE>
 * 
 * �N���X��: PEB_KouboKibouSyokusyuBean �N���X �@�\����: �Г�����Č�PDF�o�͗p��]�E��f�[�^��ێ�����B
 * 
 * </PRE>
 */
public class PEB_KouboKibouSyokusyuBean implements Serializable {
	private String KouboAnkenId = null;

	private int seqNo = 0;

	private String syokuName = null;

	private String senmonName = null;

	private String levelCode = null;

	private String syokuCode = null;

	private String senmonCode = null;

	private String kousinbi = null;

	private String kousinjikoku = null;

	/**
	 * 
	 */
	public PEB_KouboKibouSyokusyuBean() {

	}

	public PEB_KouboKibouSyokusyuBean(final ResultSet rs) throws SQLException {
		this.parseKibouSyokusyuResultSet(rs);
	}

	/**
	 * @return
	 */
	public String getKouboAnkenId() {
		return this.KouboAnkenId;
	}

	/**
	 * @return
	 */
	public String getLevelCode() {
		return this.levelCode;
	}

	/**
	 * @return
	 */
	public String getSenmonName() {
		return this.senmonName;
	}

	/**
	 * @return
	 */
	public int getSeqNo() {
		return this.seqNo;
	}

	/**
	 * @return
	 */
	public String getSyokuName() {
		return this.syokuName;
	}

	/**
	 * @param string
	 */
	public void setKouboAnkenId(final String string) {
		this.KouboAnkenId = string;
	}

	/**
	 * @param string
	 */
	public void setLevelCode(final String string) {
		this.levelCode = string;
	}

	/**
	 * @param string
	 */
	public void setSenmonName(final String string) {
		this.senmonName = string;
	}

	/**
	 * @param i
	 */
	public void setSeqNo(final int i) {
		this.seqNo = i;
	}

	/**
	 * @param string
	 */
	public void setSyokuName(final String string) {
		this.syokuName = string;
	}

	/**
	 * �����]�E��₢���킹���ʂ�Bean�ɐݒ肷��B
	 * @param rs �����]�E��₢���킹���ʁB
	 * @return �����]�E���Bean�B
	 */
	public void parseKibouSyokusyuResultSet(final ResultSet rs) throws SQLException {
		this.setKouboAnkenId(rs.getString("KOUBO_ANKEN_ID"));
		this.setSeqNo(rs.getInt("SEQ_NO"));
		this.setSyokuName(rs.getString("SYOKU_NAME"));
		this.setSenmonName(rs.getString("SENMON_NAME"));
		this.setLevelCode(rs.getString("LEVEL_CODE"));
		this.setSenmonCode(rs.getString("SENMON_CODE"));
		this.setSyokuCode(rs.getString("SYOKU_CODE"));
		this.setKousinbi(rs.getString("KOUSINBI"));
		this.setKousinjikoku(rs.getString("KOUSINJIKOKU"));
	}

	/**
	 * @return
	 */
	public String getSenmonCode() {
		return this.senmonCode;
	}

	/**
	 * @return
	 */
	public String getSyokuCode() {
		return this.syokuCode;
	}

	/**
	 * @param string
	 */
	public void setSenmonCode(final String string) {
		this.senmonCode = string;
	}

	/**
	 * @param string
	 */
	public void setSyokuCode(final String string) {
		this.syokuCode = string;
	}

	/**
	 * @return
	 */
	public String getKousinbi() {
		return this.kousinbi;
	}

	/**
	 * @return
	 */
	public String getKousinjikoku() {
		return this.kousinjikoku;
	}

	/**
	 * @param string
	 */
	public void setKousinbi(final String string) {
		this.kousinbi = string;
	}

	/**
	 * @param string
	 */
	public void setKousinjikoku(final String string) {
		this.kousinjikoku = string;
	}

}
