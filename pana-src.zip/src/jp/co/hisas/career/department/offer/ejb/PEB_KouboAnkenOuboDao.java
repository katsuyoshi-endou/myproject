/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;

import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaAssessBean;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboAnkenOuboBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PEB_KouboAnkenOuboDao �@�\�����F ����Č�����Ŏg�p����DAO�B (1)����Č������ʏo�͗p�f�[�^�̎擾(select���\�b�h) (2)����Č�������̐V�K�o�^�y�эX�V(update���\�b�h)
 * 
 * </PRE>
 */
public class PEB_KouboAnkenOuboDao {
	private boolean newEntry;

	private String systemYMD;

	private String systemHMS;

	private String userId;

	/** D01_����e�[�u�����f�[�^���o����ׂ�SQL */
	private static String KOUBO_SELECT_SQL = null;
	static {
		/** �₢���킹SQL���쐬 */
		final StringBuffer buf = new StringBuffer();
		buf.append("SELECT ");
		for (int i = 0; i < HcdbDef.s01_column.length; ++i) {
			if (i > 0) {
				buf.append(", ");
			}
			buf.append(HcdbDef.s01_column[i]);
		}
		buf.append(" FROM ");
		buf.append(HcdbDef.D01_TBL);
		buf.append(" WHERE KOUBO_ANKEN_ID=CAST(? AS CHAR(10))");
		PEB_KouboAnkenOuboDao.KOUBO_SELECT_SQL = buf.toString();
	}

	/** D03_����_����҃e�[�u�����f�[�^���o����ׂ�SQL */
	private static String KOUBO_OUBOSYA_SELECT_SQL = null;
	static {
		/** �₢���킹SQL���쐬 */
		final StringBuffer buf = new StringBuffer();
		buf.append("SELECT ");
		for (int i = 0; i < HcdbDef.s03_column.length; ++i) {
			if (i > 0) {
				buf.append(", ");
			}
			buf.append(HcdbDef.s03_column[i]);
		}
		buf.append(" FROM ");
		buf.append(HcdbDef.D03_TBL);
		buf.append(" WHERE KOUBO_ANKEN_ID=CAST(? AS CHAR(10))");
		buf.append(" AND SIMEI_NO=CAST(? AS CHAR(20))");
		PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_SELECT_SQL = buf.toString();
	}

	/** D04_����_�����_�A�Z�X�����g���ʃe�[�u�����f�[�^���o����ׂ�SQL */
	private static String KOUBO_OUBOSYA_ASSESS_SELECT_SQL = null;
	static {
		/** �₢���킹SQL���쐬 */
		final StringBuffer buf = new StringBuffer();
		buf.append("SELECT ");
		for (int i = 0; i < HcdbDef.s04_column.length; ++i) {
			if (i > 0) {
				buf.append(", ");
			}
			buf.append(HcdbDef.s04_column[i]);
		}
		buf.append(" FROM ");
		buf.append(HcdbDef.D04_TBL);
		buf.append(" WHERE KOUBO_ANKEN_ID=CAST(? AS CHAR(10))");
		buf.append(" AND SIMEI_NO=CAST(? AS CHAR(20))");
		buf.append(" ORDER BY KOUBO_ANKEN_ID,SIMEI_NO,SEQ_NO");
		PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_ASSESS_SELECT_SQL = buf.toString();
	}

	/** D03_����_����҃e�[�u���Ƀf�[�^��}������ׂ�SQL */
	private static String KOUBO_OUBOSYA_INSERT_SQL = null;
	static {
		/** �}��SQL���쐬 */
		final StringBuffer buf = new StringBuffer();
		buf.append("INSERT INTO ");
		buf.append(HcdbDef.D03_TBL);
		buf.append("(");
		buf.append("KOUBO_ANKEN_ID");
		buf.append(",SIMEI_NO");
		buf.append(",SOSIKI_CODE");
		buf.append(",OUBOSYA_GRADE");
		buf.append(",OUBOSYA_RATE");
		buf.append(",KIBOU_GYOMU");
		buf.append(",SIBOU_DOUKI");
		buf.append(",JIKO_PR");
		buf.append(",GOUHI_STATUS");
		buf.append(",SAIYO_STATUS");
		buf.append(",TOUROKUBI");
		buf.append(",TOUROKUJIKOKU");
		buf.append(",TOUROKUSYA");
		buf.append(",KOUSINBI");
		buf.append(",KOUSINJIKOKU");
		buf.append(",KOUSINSYA");
		buf.append(") VALUES (");
		buf.append("?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?");
		buf.append(")");
		PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_INSERT_SQL = buf.toString();
	}

	/** D04_����_�����_�A�Z�X�����g���ʃe�[�u���Ƀf�[�^��}������ׂ�SQL */
	private static String KOUBO_OUBOSYA_ASSESS_INSERT_SQL = null;
	static {
		/** �}��SQL���쐬 */
		final StringBuffer buf = new StringBuffer();
		buf.append("INSERT INTO ");
		buf.append(HcdbDef.D04_TBL);
		buf.append("(");
		buf.append("KOUBO_ANKEN_ID");
		buf.append(",SIMEI_NO");
		buf.append(",SEQ_NO");
		buf.append(",SYOKU_CODE");
		buf.append(",SENMON_CODE");
		buf.append(",LEVEL_CODE");
		buf.append(",JIKO_SOUGOU_T_DO");
		buf.append(",HYOKASYA_SOUGOU_T_DO");
		buf.append(",TOUROKUBI");
		buf.append(",TOUROKUJIKOKU");
		buf.append(",TOUROKUSYA");
		buf.append(",KOUSINBI");
		buf.append(",KOUSINJIKOKU");
		buf.append(",KOUSINSYA");
		buf.append(") VALUES (");
		buf.append("?,?,?,?,?,?,?,?,?,?,?,?,?,?");
		buf.append(")");
		PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_ASSESS_INSERT_SQL = buf.toString();
	}

	/** D03_����_����҃e�[�u���̃f�[�^���X�V����ׂ�SQL */
	private static String KOUBO_OUBOSYA_UPDATE_SQL = null;
	static {
		/** �X�VSQL���쐬 */
		final StringBuffer buf = new StringBuffer();
		buf.append("UPDATE ");
		buf.append(HcdbDef.D03_TBL);
		buf.append(" SET ");
		buf.append("SOSIKI_CODE=?");
		buf.append(",OUBOSYA_GRADE=?");
		buf.append(",OUBOSYA_RATE=?");
		buf.append(",KIBOU_GYOMU=?");
		buf.append(",SIBOU_DOUKI=?");
		buf.append(",JIKO_PR=?");
		buf.append(",TOUROKUBI=?");
		buf.append(",TOUROKUJIKOKU=?");
		buf.append(",TOUROKUSYA=?");
		buf.append(",KOUSINBI=?");
		buf.append(",KOUSINJIKOKU=?");
		buf.append(",KOUSINSYA=?");
		buf.append(" WHERE KOUBO_ANKEN_ID=CAST(? AS CHAR(10))");
		buf.append(" AND SIMEI_NO=CAST(? AS CHAR(20))");
		PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_UPDATE_SQL = buf.toString();
	}

	/** D04_����_�����_�A�Z�X�����g���ʃe�[�u���̃f�[�^���폜����ׂ�SQL */
	private static String KOUBO_OUBOSYA_ASSESS_DELETE_SQL = null;
	static {
		/** �폜SQL���쐬 */
		final StringBuffer buf = new StringBuffer();
		buf.append("DELETE FROM ");
		buf.append(HcdbDef.D04_TBL);
		buf.append(" WHERE KOUBO_ANKEN_ID=CAST(? AS CHAR(10))");
		buf.append(" AND SIMEI_NO=CAST(? AS CHAR(20))");
		PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_ASSESS_DELETE_SQL = buf.toString();
	}

	/**
	 * �R���X�g���N�^�B
	 */
	public PEB_KouboAnkenOuboDao() {
	}

	/**
	 * �w�肳�ꂽ����Č�ID�Ɖ���ҎЈ��ԍ�������Č������ʏo�͗p�f�[�^���擾����B
	 * @param ankenId ���o�ΏۂƂ������Č�ID
	 * @param simeiNo ���o�ΏۂƂ��鉞��ҎЈ��ԍ�
	 * @return ����Č������ʏo�͗p�f�[�^
	 * @throws SQLException
	 */
	public PEB_KouboAnkenOuboBean select(final String ankenId, final String simeiNo) throws SQLException, NamingException {

		Log.method("", "IN", "");

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		PEY_KouboBean kouboBean = null;
		PEY_KouboOubosyaBean kouboOubosyaBean = null;
		PEY_KouboOubosyaAssessBean kouboOubosyaAssessBean = null;
		final PEB_KouboAnkenOuboBean kouboAnkenOuboBean = new PEB_KouboAnkenOuboBean();

		try {
			con = PZZ040_SQLUtility.getConnection("");

			Log.debug(PEB_KouboAnkenOuboDao.KOUBO_SELECT_SQL);

			ps = con.prepareStatement(PEB_KouboAnkenOuboDao.KOUBO_SELECT_SQL);
			ps.setString(1, ankenId);
			rs = ps.executeQuery();

			if (rs.next()) {
				kouboBean = new PEY_KouboBean(rs, null);
				kouboAnkenOuboBean.setKouboBean(kouboBean);
			}

			PZZ040_SQLUtility.closeConnection("", null, ps, rs);

			Log.debug(PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_SELECT_SQL);

			ps = con.prepareStatement(PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_SELECT_SQL);
			ps.setString(1, ankenId);
			ps.setString(2, simeiNo);
			rs = ps.executeQuery();

			if (rs.next()) {
				kouboOubosyaBean = new PEY_KouboOubosyaBean(rs, null);
				kouboAnkenOuboBean.setKouboOubosyaBean(kouboOubosyaBean);
			}

			PZZ040_SQLUtility.closeConnection("", null, ps, rs);

			Log.debug(PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_ASSESS_SELECT_SQL);

			ps = con.prepareStatement(PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_ASSESS_SELECT_SQL);
			ps.setString(1, ankenId);
			ps.setString(2, simeiNo);
			rs = ps.executeQuery();

			while (rs.next()) {
				kouboOubosyaAssessBean = new PEY_KouboOubosyaAssessBean(rs, null);
				kouboAnkenOuboBean.addKouboOubosyaAssessBean(kouboOubosyaAssessBean);
			}

			Log.method("", "OUT", "");

			return kouboAnkenOuboBean;

		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		} catch (final NamingException e) {
			Log.error("", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection("", con, ps, rs);
		}
	}

	/**
	 * �^����ꂽ����Č��������DB���X�V����B
	 * @param kouboAnkenOubo ����Č�������
	 * @param loginuser ���O�C�����[�U���
	 * @throws SQLException,PEY_WarningException
	 */
	public void update(final PEB_KouboAnkenOuboBean kouboAnkenOubo, final PEY_PersonalBean loginuser) throws SQLException, NamingException, PEY_WarningException {

		Log.method("", "IN", "");
		Connection con = null;

		try {
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			if (kouboAnkenOubo.getKouboOubosyaBean().getTourokubi() == null || kouboAnkenOubo.getKouboOubosyaBean().getTourokubi().equals("")) {
				this.newEntry = true;
			} else {
				this.newEntry = false;
			}

			if (this.checkTransaction(con, kouboAnkenOubo) != true) {
				throw new PEY_WarningException("WCB080");
			}

			this.systemYMD = PZZ010_CharacterUtil.GetDay();
			this.systemHMS = PZZ010_CharacterUtil.GetTime();
			this.userId = loginuser.getSimeiNo();

			this.updateKouboOubosyaTbl(con, kouboAnkenOubo, loginuser);
			this.updateKouboOubosyaAssessTbl(con, kouboAnkenOubo, loginuser);

			Log.method("", "OUT", "");

		} catch (final SQLException e) {
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection("", con, null, null);
		}
	}

	/**
	 * D03_����_����҃e�[�u���̍X�V�B
	 * @param con DB�R�l�N�V����
	 * @param kouboAnkenOubo �X�V���
	 * @param loginuser ���O�C�����[�U���
	 * @throws SQLException
	 */
	private void updateKouboOubosyaTbl(final Connection con, final PEB_KouboAnkenOuboBean kouboAnkenOubo, final PEY_PersonalBean loginuser) throws SQLException {

		Log.method("", "IN", "");

		PreparedStatement ps = null;
		PEY_KouboOubosyaBean oubo = null;

		oubo = kouboAnkenOubo.getKouboOubosyaBean();

		try {
			if (this.newEntry == true) {
				Log.debug(PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_INSERT_SQL);

				ps = con.prepareStatement(PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_INSERT_SQL);

				ps.setString(1, oubo.getKouboankenid());
				ps.setString(2, oubo.getSimeino());
				ps.setString(3, oubo.getSosikicode());
				ps.setString(4, oubo.getOubosyagrade());
				ps.setString(5, oubo.getOubosyarate());
				ps.setString(6, oubo.getKibougyomu());
				ps.setString(7, oubo.getSiboudouki());
				ps.setString(8, oubo.getJikopr());
				ps.setString(9, oubo.getGouhistatus());
				ps.setString(10, oubo.getSaiyostatus());
				ps.setString(11, this.systemYMD);
				ps.setString(12, this.systemHMS);
				ps.setString(13, this.userId);
				ps.setString(14, this.systemYMD);
				ps.setString(15, this.systemHMS);
				ps.setString(16, this.userId);

				ps.executeUpdate();
			} else {
				Log.debug(PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_UPDATE_SQL);

				ps = con.prepareStatement(PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_UPDATE_SQL);

				ps.setString(1, oubo.getSosikicode());
				ps.setString(2, oubo.getOubosyagrade());
				ps.setString(3, oubo.getOubosyarate());
				ps.setString(4, oubo.getKibougyomu());
				ps.setString(5, oubo.getSiboudouki());
				ps.setString(6, oubo.getJikopr());
				ps.setString(7, oubo.getTourokubi());
				ps.setString(8, oubo.getTourokujikoku());
				ps.setString(9, oubo.getTourokusya());
				ps.setString(10, this.systemYMD);
				ps.setString(11, this.systemHMS);
				ps.setString(12, this.userId);
				ps.setString(13, oubo.getKouboankenid());
				ps.setString(14, oubo.getSimeino());

				ps.executeUpdate();
			}

			Log.method("", "OUT", "");

		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection("", null, ps, null);
		}
	}

	/**
	 * D04_����_�����_�A�Z�X�����g���ʃe�[�u���̍X�V�B
	 * @param con DB�R�l�N�V����
	 * @param kouboAnkenOubo �X�V���
	 * @param loginuser ���O�C�����[�U���
	 * @throws SQLException
	 */
	private void updateKouboOubosyaAssessTbl(final Connection con, final PEB_KouboAnkenOuboBean kouboAnkenOubo, final PEY_PersonalBean loginuser) throws SQLException {

		Log.method("", "IN", "");

		PreparedStatement ps = null;
		PEY_KouboOubosyaBean oubo = null;
		PEY_KouboOubosyaAssessBean assess = null;

		oubo = kouboAnkenOubo.getKouboOubosyaBean();

		try {
			Log.debug(PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_ASSESS_DELETE_SQL);

			ps = con.prepareStatement(PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_ASSESS_DELETE_SQL);

			ps.setString(1, oubo.getKouboankenid());
			ps.setString(2, oubo.getSimeino());

			ps.executeUpdate();

			PZZ040_SQLUtility.closeConnection("", null, ps, null);

			for (int i = 0; i < kouboAnkenOubo.getKouboOubosyaAssessBean().length; i++) {
				assess = kouboAnkenOubo.getKouboOubosyaAssessBean()[i];

				Log.debug(PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_ASSESS_INSERT_SQL);

				ps = con.prepareStatement(PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_ASSESS_INSERT_SQL);

				ps.setString(1, assess.getKouboankenid());
				ps.setString(2, assess.getSimeino());
				ps.setString(3, assess.getSeqno());
				ps.setString(4, assess.getSyokucode());
				ps.setString(5, assess.getSenmoncode());
				ps.setString(6, assess.getLevelcode());
				ps.setString(7, assess.getJikosougoutdo());
				ps.setString(8, assess.getHyokasyasougoutdo());
				ps.setString(9, this.systemYMD);
				ps.setString(10, this.systemHMS);
				ps.setString(11, this.userId);
				ps.setString(12, this.systemYMD);
				ps.setString(13, this.systemHMS);
				ps.setString(14, this.userId);

				ps.executeUpdate();

				PZZ040_SQLUtility.closeConnection("", null, ps, null);
			}

			Log.method("", "OUT", "");

		} catch (final SQLException e) {
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection("", null, ps, null);
		}
	}

	/**
	 * DB�X�V���̓������s����B
	 * @param con DB�R�l�N�V����
	 * @param updateVal �X�V�f�[�^
	 * @return �X�V�Ώۃf�[�^�̍X�V�̗L��(true:���g�����X�V����,false:���g�����X�V�L)
	 * @throws SQLException
	 */
	private boolean checkTransaction(final Connection con, final PEB_KouboAnkenOuboBean updateVal) throws SQLException {

		Log.method("", "IN", "");

		boolean RetVal = true;
		PEY_KouboOubosyaBean oubo = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = con.prepareStatement(PEB_KouboAnkenOuboDao.KOUBO_OUBOSYA_SELECT_SQL);
			ps.setString(1, updateVal.getKouboOubosyaBean().getKouboankenid());
			ps.setString(2, updateVal.getKouboOubosyaBean().getSimeino());
			rs = ps.executeQuery();

			if (this.newEntry == true) {
				if (rs.next()) {
					RetVal = false;
				}
			} else {
				if (rs.next()) {
					oubo = new PEY_KouboOubosyaBean(rs, null);
					if (updateVal.getKouboOubosyaBean().getTourokubi().equals(oubo.getTourokubi()) != true
							|| updateVal.getKouboOubosyaBean().getTourokujikoku().equals(oubo.getTourokujikoku()) != true
							|| updateVal.getKouboOubosyaBean().getKousinbi().equals(oubo.getKousinbi()) != true
							|| updateVal.getKouboOubosyaBean().getKousinjikoku().equals(oubo.getKousinjikoku()) != true) {
						RetVal = false;
					}
				} else {
					RetVal = false;
				}
			}

			Log.method("", "OUT", "");

			return RetVal;

		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection("", null, ps, rs);
		}
	}
}
