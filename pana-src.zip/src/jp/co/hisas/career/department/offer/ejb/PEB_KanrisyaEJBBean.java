/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�Г�����@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/12  01.00       �c���@�N�W    �V�K�쐬
 */
package jp.co.hisas.career.department.offer.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KanrisyaBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PEY_KanrisyaEJBBean �N���X �@�\�����F ����e�[�u���A����_����e�[�u���ւ̑�����s���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="PEB_KanrisyaEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PEB_KanrisyaEJBBean implements SessionBean {
	/**
	 * ������e�[�u������f�[�^�擾���Ԃ��܂��B
	 * @param osiraseBean ��������
	 * @param loginuser ���O�C�����[�U
	 * @return PEB_KanrisyaBean[] �擾����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PEB_KanrisyaBean[] doSelect(final PEB_KanrisyaBean kanrisyaBean, final PEY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// ���������̍쐬
			PEB_KanrisyaBean[] kanrisyaBeans = null;
			final StringBuffer sql = new StringBuffer();
			sql.append("SELECT ");
			sql.append(" D01.KOUBO_ANKEN_ID,");
			sql.append(" D01.KOUBO_ANKEN_MEI,");
			sql.append(" D01.JIGYOBU_MEI,");
			sql.append(" D01.JIGYOBUTYO_MEI,");
			sql.append(" D01.BOSYU_NINZU,");
			sql.append(" D01.SYORI_STATUS,");
			sql.append(" D01.JIGYOBUTYO_SYONINBI,");
			sql.append(" D01.TOUROKUBI,");
			sql.append(" D01.TOUROKUJIKOKU,");
			sql.append(" D01.TOUROKUSYA,");
			sql.append(" D01.KOUSINBI,");
			sql.append(" D01.KOUSINJIKOKU,");
			sql.append(" D01.KOUSINSYA,");
			sql.append(" D01.RENRAKU_JIKOU, ");
			sql.append(" D03.SIMEI_NO,");
			sql.append(" D03.GOUHI_STATUS");
			sql.append(" FROM " + HcdbDef.D01_TBL + " D01, ");
			sql.append(HcdbDef.D03_TBL + " D03");
			sql.append(" WHERE D01.KOUBO_ANKEN_ID = D03.KOUBO_ANKEN_ID(+)");
			sql.append(" AND D01.SYORI_STATUS NOT IN(" + HcdbDef.D01_SAKUSEIZUMI);
			sql.append(" ," + HcdbDef.D01_SAKUJYO + " ) ");

			// ����e�[�u���\�[�g���̍쐬
			sql.append("  ORDER BY JIGYOBUTYO_SYONINBI");

			// �f�o�b�O�̏o��
			Log.debug(sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �������s
			ps = con.prepareStatement(sql.toString());

			final List kanrisyaBeanList = new ArrayList();

			rs = ps.executeQuery();

			while (rs.next()) {
				kanrisyaBeanList.add(this.parseKanrisyaResultSet(rs));
			}

			rs.close();
			ps.clearParameters();
			kanrisyaBeans = new PEB_KanrisyaBean[kanrisyaBeanList.size()];
			kanrisyaBeanList.toArray(kanrisyaBeans);

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return kanrisyaBeans;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	private PEB_KanrisyaBean parseKanrisyaResultSet(final ResultSet rs) throws SQLException {
		final PEB_KanrisyaBean kb = new PEB_KanrisyaBean();
		kb.setKouboankenid(this.nvl(rs.getString("KOUBO_ANKEN_ID")));
		kb.setKouboankenmei(this.nvl(rs.getString("KOUBO_ANKEN_MEI")));
		kb.setJigyobumei(this.nvl(rs.getString("JIGYOBU_MEI")));
		kb.setJigyoubutyomei(this.nvl(rs.getString("JIGYOBUTYO_MEI")));
		kb.setSyoristatus(this.nvl(rs.getString("SYORI_STATUS")));
		kb.setJigyobutyoSyoninbi(this.nvl(rs.getString("JIGYOBUTYO_SYONINBI")));
		kb.setTourokubi(this.nvl(rs.getString("TOUROKUBI")));
		kb.setTourokujikoku(this.nvl(rs.getString("TOUROKUJIKOKU")));
		kb.setTourokusya(this.nvl(rs.getString("TOUROKUSYA")));
		kb.setKousinbi(this.nvl(rs.getString("KOUSINBI")));
		kb.setKousinjikoku(this.nvl(rs.getString("KOUSINJIKOKU")));
		kb.setKousinsya(this.nvl(rs.getString("KOUSINSYA")));
		kb.setSimeiNo(this.nvl(rs.getString("SIMEI_NO")));
		kb.setBosyuninzu(new Integer(rs.getInt("BOSYU_NINZU")));
		kb.setRenrakujikou(this.nvl(rs.getString("RENRAKU_JIKOU")));
		kb.setGouhiStatus(this.nvl(rs.getString("GOUHI_STATUS")));

		return kb;
	}

	private String nvl(final String str) {
		if (str == null) {
			return "";
		}

		return str;
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
}
