/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaAssessBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenAssessumentRirekiEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenAssessumentRirekiEJBHome;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �T�v�F �A�Z�X�����g�����̈ꗗ�f�[�^���擾���� �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PEB081_KouboAnkenAssessmentRirekiServlet extends PEY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException {

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEB_KouboAnkenAssessumentRirekiEJBHome home = (PEB_KouboAnkenAssessumentRirekiEJBHome) fact.lookup(PEB_KouboAnkenAssessumentRirekiEJBHome.class);

		final PEB_KouboAnkenAssessumentRirekiEJB ejb = home.create();

		/* �f�[�^���擾���� */
		final PEY_KouboOubosyaAssessBean[] kouboBeans = ejb.doSelect(loginuser);

		request.setAttribute("kouboBeans", kouboBeans);

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();
	}

}
