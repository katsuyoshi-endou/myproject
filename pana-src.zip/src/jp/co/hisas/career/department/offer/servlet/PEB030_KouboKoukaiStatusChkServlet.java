/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboKanriBean;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboMenuEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboMenuEJBHome;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PEB030_KouboUpdateServlet �N���X �@�\�����F ����e�[�u���̏����X�e�[�^�X�E���t(���F���E���J�����j ��ύX����
 * 
 * </PRE>
 */
public class PEB030_KouboKoukaiStatusChkServlet extends PEY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws NamingException, CreateException, PEY_WarningException,
			RemoteException, PEY_WarningException {

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");
		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEB_KouboMenuEJBHome home = (PEB_KouboMenuEJBHome) fact.lookup(PEB_KouboMenuEJBHome.class);
		final PEB_KouboMenuEJB ejb = home.create();

		/* ���������̐ݒ� */
		final PEB_KouboKanriBean search_kouboBeans = new PEB_KouboKanriBean(request);

		/* �X�e�[�^�X���擾���� */
		Log.transaction(loginuser.getSimeiNo(), true, "");
		final String status = ejb.doSelectStatus(search_kouboBeans, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		if (!status.equals(HcdbDef.D01_KEIEIKAIGI_SINSATYU)) {
			request.setAttribute("warningID", "WEB003");
			throw new PEY_WarningException();
		}

		return this.getForwardPath();

	}
}
