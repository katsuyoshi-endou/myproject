/*
 * Copyright (C) Hitachi, Ltd. 2004. All rights reserved.
 */

package jp.co.hisas.career.util.pdf;

import java.io.IOException;

import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboAnkenBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboKibouSyokusyuBean;

import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Rectangle;
import com.lowagie.text.Table;

/**
 * @version 1.0
 * @since 1.0
 */
public class PZE_KouboBodyMaker {
	private PZE_KouboPdfMaker parent = null;

	private String prTitle = null;

	public PZE_KouboBodyMaker(final PZE_KouboPdfMaker parent) {
		this.parent = parent;
		if (parent instanceof PZE_KouboAnkenHyojiPDFMaker) {
			this.prTitle = "���啔�������PR";
		} else {
			this.prTitle = "����҂ւ�PR";
		}

	}

	/**
	 * �o�c�e���쐬����B
	 * @param os �o�̓X�g���[��
	 * @param userInfo ���O�C�����[�U���
	 * @param pdfData PDF�o�͗p�f�[�^
	 * @return �����̏ꍇ�Ftrue�A���s�̏ꍇ�Ffalse
	 * @exception DocumentException
	 */
	public void makeBody(final String ankenTitle, final PEY_PersonalBean userInfo, final PEB_KouboAnkenBean pdfData, final Document document) throws DocumentException, IOException {
		this.makeSinseiAnken(ankenTitle, pdfData, document);
		this.makeOuboYouken(pdfData, document);
		this.makeSinseiRiyu(pdfData, document);
	}

	/**
	 * �o�c�e���쐬����B
	 * @param os �o�̓X�g���[��
	 * @param userInfo ���O�C�����[�U���
	 * @param pdfData PDF�o�͗p�f�[�^
	 * @param pdftype PDF�o�̓^�C�v
	 * @return �����̏ꍇ�Ftrue�A���s�̏ꍇ�Ffalse
	 * @exception DocumentException
	 */
	public void makeBody(final String ankenTitle, final PEY_PersonalBean userInfo, final PEB_KouboAnkenBean pdfData, final Document document, final int pdftype) throws DocumentException, IOException {
		this.makeSinseiAnken(ankenTitle, pdfData, document);
		this.makeOuboYouken(pdfData, document);
		// C-ADT02-002-S
		if (pdftype == 1) {
			this.makeSinseiRiyu(pdfData, document);
		}
		// C-ADT02-002-E
	}

	private void makeSinseiAnken(final String ankenTitle, final PEB_KouboAnkenBean pdfData, final Document document) throws DocumentException {

		final Table table = new Table(10, 11);
		this.parent.setTableDefault(table);
		table.setWidths(new int[] { 19, 1, 10, 10, 10, 10, 10, 10, 10, 10 });

		final PEY_KouboBean kouboData = pdfData.getKouboBean();

		Cell cell = null;
		// 0�i��
		cell = this.parent.makeSmallChapterCell(ankenTitle);
		cell.setColspan(10);
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);

		// 1�i��
		cell = this.parent.makeBigChapterCell("����Č���\n�i�v���W�F�N�g���j");
		table.addCell(cell);
		cell = this.parent.makeDmyCell();
		table.addCell(cell);

		cell = this.parent.makeNormalCell(this.parent.nvl(kouboData.getKouboankenmei()));
		cell.setColspan(8);
		table.addCell(cell);

		// 2�i��
		cell = this.parent.makeBigChapterCell("�Č��T�v");
		table.addCell(cell);
		cell = this.parent.makeDmyCell();
		table.addCell(cell);

		cell = this.parent.makeNormalCell(this.parent.nvl(kouboData.getAnkengaiyo()));
		cell.setHorizontalAlignment(Rectangle.LEFT);
		cell.setColspan(8);
		table.addCell(cell);

		// 3�i��
		cell = this.parent.makeBigChapterCell("��W�l��");
		table.addCell(cell);
		cell = this.parent.makeDmyCell();
		table.addCell(cell);

		final Integer bosyuNinzu = kouboData.getBosyuninzu();
		cell = this.parent.makeNormalCell(bosyuNinzu == null ? "0" : bosyuNinzu.toString());
		table.addCell(cell);

		cell = this.parent.makeNormalCell("��");
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setHorizontalAlignment(Rectangle.LEFT);
		cell.setColspan(7);
		table.addCell(cell);

		// 4�i��
		cell = this.parent.makeBigChapterCell("�ٓ���]����");
		table.addCell(cell);
		cell = this.parent.makeDmyCell();
		table.addCell(cell);

		cell = this.parent.makeNormalCell(this.parent.nvl(kouboData.getIdoukiboujiki()));
		cell.setHorizontalAlignment(Rectangle.LEFT);
		cell.setColspan(8);
		table.addCell(cell);

		// 5-7�i��
		cell = this.parent.makeBigChapterCell("��W�E��^\n�Ɩ����e�Ȃ�");
		cell.setVerticalAlignment(Rectangle.ALIGN_MIDDLE);
		cell.setRowspan(10);
		table.addCell(cell);

		final PEB_KouboKibouSyokusyuBean[] kiboSyokusyu = pdfData.getKouboKibouSyokusyuBean();
		int max = kiboSyokusyu.length;
		if (max > 3) {
			max = 3; // 3���ȏ�͕\�����Ȃ��B
		}
		int i = 0;
		for (i = 0; i < max; ++i) {
			table.addCell(this.parent.makeDmyCell());
			table.addCell(this.parent.makeMiddleChapterCell("�E��"));
			cell = this.parent.makeNormalCell(this.parent.nvl(kiboSyokusyu[i].getSyokuName()));
			cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
			cell.setColspan(2);
			table.addCell(cell);
			table.addCell(this.parent.makeMiddleChapterCell("��啪��"));
			cell = this.parent.makeNormalCell(this.parent.nvl(kiboSyokusyu[i].getSenmonName()));
			cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
			cell.setColspan(2);
			table.addCell(cell);
			table.addCell(this.parent.makeMiddleChapterCell("���x��"));
			table.addCell(this.parent.makeNormalCell(this.parent.nvl(kiboSyokusyu[i].getLevelCode())));
		}
		for (int j = i; j < 3; ++j) {
			table.addCell(this.parent.makeDmyCell());
			table.addCell(this.parent.makeMiddleChapterCell("�E��"));
			cell = this.parent.makeNormalCell("");
			cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
			cell.setColspan(2);
			table.addCell(cell);
			table.addCell(this.parent.makeMiddleChapterCell("��啪��"));
			cell = this.parent.makeNormalCell("");
			cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
			cell.setColspan(2);
			table.addCell(cell);
			table.addCell(this.parent.makeMiddleChapterCell("���x��"));
			table.addCell(this.parent.makeNormalCell(""));

		}

		// 8�i��
		table.addCell(this.parent.makeDmyCell());
		cell = this.parent.makeMiddleChapterCell("���̑��E��");
		cell.setColspan(2);
		table.addCell(cell);
		cell = this.parent.makeNormalCell(this.parent.nvl(kouboData.getKibousyokusyuSonota()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		cell.setColspan(6);
		table.addCell(cell);

		// 9�i��
		table.addCell(this.parent.makeDmyCell());
		cell = this.parent.makeMiddleChapterCell("�����^�Ζ��n");
		cell.setColspan(2);
		table.addCell(cell);
		cell = this.parent.makeNormalCell(this.parent.nvl(kouboData.getSyozokukinmuti()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		cell.setColspan(6);
		table.addCell(cell);

		// 10�i��
		table.addCell(this.parent.makeDmyCell());
		cell = this.parent.makeMiddleChapterCell("���Җ���");
		cell.setColspan(2);
		table.addCell(cell);
		boolean added = false;
		final StringBuffer kitaiYakuwari = new StringBuffer();
		if ("1".equals(kouboData.getKitaiyakuwaributyo())) {
			kitaiYakuwari.append("����");
			added = true;
		}
		if ("1".equals(kouboData.getKitaiyakuwarisyuningisi())) {
			if (added) {
				kitaiYakuwari.append(" ");
			}
			kitaiYakuwari.append("��C�Z�t�E�����㗝");
			added = true;
		}
		if ("1".equals(kouboData.getKitaiyakuwarigisi())) {
			if (added) {
				kitaiYakuwari.append(" ");
			}
			kitaiYakuwari.append("�Z�t�E��C");
			added = true;
		}
		if ("1".equals(kouboData.getKitaiyakuwariippan())) {
			if (added) {
				kitaiYakuwari.append(" ");
			}
			kitaiYakuwari.append("���");
		}

		cell = this.parent.makeNormalCell(this.parent.nvl(kitaiYakuwari.toString()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		cell.setColspan(6);
		table.addCell(cell);

		// 11�i��
		table.addCell(this.parent.makeDmyCell());
		cell = this.parent.makeMiddleChapterCell("�Ɩ����e");
		cell.setVerticalAlignment(Rectangle.ALIGN_MIDDLE);
		cell.setColspan(2);
		table.addCell(cell);
		cell = this.parent.makeNormalCell(this.parent.nvl(kouboData.getGyomunaiyo()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		cell.setColspan(6);
		table.addCell(cell);

		document.add(table);
	}

	/**
	 * PDF�̐\�����鉞��҂̗v���������B
	 * @param pdfData PDF�o�͗p�f�[�^�B
	 * @param document PDF�h�L�������g�B
	 * @throws DocumentException
	 */
	private void makeOuboYouken(final PEB_KouboAnkenBean pdfData, final Document document) throws DocumentException {
		final Table table = new Table(4, 5);
		this.parent.setTableDefault(table);
		table.setWidths(new int[] { 19, 1, 30, 50 });

		final PEY_KouboBean kouboData = pdfData.getKouboBean();

		Cell cell = null;
		// 0�i��
		cell = this.parent.makeSmallChapterCell("������҂̗v��");
		cell.setColspan(4);
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);

		// 1�i��
		cell = this.parent.makeBigChapterCell("����҂̗v��");
		cell.setVerticalAlignment(Rectangle.ALIGN_MIDDLE);
		cell.setRowspan(3);
		table.addCell(cell);
		table.addCell(this.parent.makeDmyCell());
		table.addCell(this.parent.makeMiddleChapterCell("�W���u�O���[�h�i�i�t���j"));
		cell = this.parent.makeNormalCell(this.parent.nvl(kouboData.getJobgrade()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);

		// 2�i��
		table.addCell(this.parent.makeDmyCell());
		table.addCell(this.parent.makeMiddleChapterCell("�E���o���^�o���N��"));
		cell = this.parent.makeNormalCell(this.parent.nvl(kouboData.getSyokumurireki()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);

		// 3�i��
		table.addCell(this.parent.makeDmyCell());
		table.addCell(this.parent.makeMiddleChapterCell("���̑�"));
		cell = this.parent.makeNormalCell(this.parent.nvl(kouboData.getOubosyayoukensonota()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);

		// 4�i��
		table.addCell(this.parent.makeBigChapterCell(this.prTitle));
		table.addCell(this.parent.makeDmyCell());
		cell = this.parent.makeNormalCell(this.parent.nvl(kouboData.getKoubopr()));
		cell.setColspan(2);
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);

		document.add(table);

	}

	/**
	 * PDF�̐\�����鉞��҂̐\�����R�������B
	 * @param pdfData PDF�o�͗p�f�[�^�B
	 * @param document PDF�h�L�������g�B
	 * @throws DocumentException
	 */
	private void makeSinseiRiyu(final PEB_KouboAnkenBean pdfData, final Document document) throws DocumentException {
		final Table table = new Table(3, 2);
		this.parent.setTableDefault(table);
		table.setWidths(new int[] { 19, 1, 80 });

		final PEY_KouboBean kouboData = pdfData.getKouboBean();

		Cell cell = null;
		// 0�i��
		cell = this.parent.makeSmallChapterCell("���\�����R");
		cell.setColspan(3);
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);

		// 1�i��
		cell = this.parent.makeBigChapterCell("�\�����R");
		table.addCell(cell);
		table.addCell(this.parent.makeDmyCell());
		cell = this.parent.makeNormalCell(this.parent.nvl(kouboData.getSinseiriyu()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);

		document.add(table);

	}

}
