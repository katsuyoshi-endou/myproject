/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i�v��nCareer@Net�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 */

package jp.co.hisas.career.util.pdf;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;

import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class PZE060_CareerNaviSkillPDF {

	/* ���O�C��No */
	private String login_no;

	/* PDF��� */
	private String[] outDefItem;

	private String[][] outputItem;

	private String[] outNameItem;

	/**
	 * �R���X�g���N�^
	 * @param login_no
	 */
	public PZE060_CareerNaviSkillPDF(final String login_no) {
		this.login_no = login_no;
	}

	/**
	 * �X�L���ʋƖ��o���i�r�Q�[�V���������擾����
	 * @param outDefItem
	 * @param outputItem
	 * @param outNameItem
	 */
	public void setSkillNavi(final String[] outDefItem, final String[][] outputItem, final String[] outNameItem) {
		Log.method(this.login_no, "IN", "");
		this.outDefItem = outDefItem;
		this.outputItem = outputItem;
		this.outNameItem = outNameItem;
		Log.method(this.login_no, "OUT", "");
	}

	/**
	 * PDF���쐬����
	 * @return
	 */
	public void executePDF(final OutputStream ops) throws Exception {
		Log.method(this.login_no, "IN", "");

		/* �f�t�H���g�e�[�u���̐ݒ� */
		class MyTable extends Table {
			/**
			 * @param arg0
			 * @throws BadElementException
			 */
			public MyTable(final int arg0) throws BadElementException {
				super(arg0);
				this.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
				this.setDefaultVerticalAlignment(Element.ALIGN_MIDDLE);

				this.setPadding(2);
			}
		}

		/*
		 * Document�I�u�W�F�N�g�̐��� A4�c�́A Document document = new Document(PageSize.A4); A4���́ADocument document = new Document(PageSize.A4.rotate());
		 */
		final Document document = new Document(PageSize.A4);
		PdfWriter pw = null;

		try {
			/* PdfWriter�I�u�W�F�N�g�̐��� */
			pw = PdfWriter.getInstance(document, ops);
			pw.setCloseStream(true);

			/* �w�i�F */
			final Color BackColor = Color.white;

			/* �h�L�������g��OPEN */
			final HeaderFooter footer = new HeaderFooter(new Phrase("- "), new Phrase(" -"));
			footer.setBorderColor(BackColor);
			footer.setAlignment(Element.ALIGN_CENTER);
			document.setFooter(footer);
			document.open();

			/* �t�H���g�̐ݒ� */
			final float default_font_size = 10;
			final BaseFont bf = BaseFont.createFont("HeiseiMin-W3", "UniJIS-UCS2-HW-H", false);
			final Font font = new Font(bf, default_font_size);

			// 2006/09/12 K.Takagi Add
			final Font fonts = new Font(bf, 3);
			final Paragraph space = new Paragraph(" ", fonts);
			// 2006/09/12 K.Takagi Add

			/* �e�[�u���̕� */
			final int TableWidthTop = 90;
			final int TableWidth = 100;

			/* �J�����̕� */
			final int[] defLabel_widths = { 3, 97 };

			/* �R���e���c�̋L�q */
			MyTable table;
			Cell cell;

			// �E��A��啪��A���x���̑I�����
			table = new MyTable(6);
			final int[] selectinfo_widths = { 8, 22, 12, 40, 10, 8 };
			table.setWidths(selectinfo_widths);
			table.setWidth(TableWidthTop);
			table.setDefaultHorizontalAlignment(Element.ALIGN_CENTER);

			/* �y�E��z */
			cell = new Cell(new Phrase(this.outDefItem[0], font));
			cell.setBackgroundColor(new Color(204, 204, 255));
			table.addCell(cell);
			/* �E�� */
			cell = new Cell(new Phrase(this.outNameItem[0], font));
			cell.setBackgroundColor(BackColor);
			table.addCell(cell);

			/* �y��啪��z */
			cell = new Cell(new Phrase(this.outDefItem[1], font));
			cell.setBackgroundColor(new Color(204, 204, 255));
			table.addCell(cell);
			/* ��啪�� */
			cell = new Cell(new Phrase(this.outNameItem[1], font));
			cell.setBackgroundColor(BackColor);
			table.addCell(cell);

			/* �y���x���z */
			cell = new Cell(new Phrase(this.outDefItem[2], font));
			cell.setBackgroundColor(new Color(204, 204, 255));
			table.addCell(cell);
			/* ���x�� */
			cell = new Cell(new Phrase(this.outNameItem[2], font));
			cell.setBackgroundColor(BackColor);
			table.addCell(cell);

			/* �h�L�������g�ɒǉ� */
			document.add(table);

			// 1�s�X�y�[�X
			// final Table space = new MyTable(1);
			// space.setBorderColor(BackColor);
			// space.addCell("");

			/* �h�L�������g�ɒǉ� */
			document.add(space);

			// �Œ蕶��
			table = new MyTable(1);
			table.setWidth(TableWidth);
			table.setBorderColor(BackColor);
			table.setBackgroundColor(new Color(39, 64, 139));
			final String phrase1 = "���Y" + this.outDefItem[0] + "�E" + this.outDefItem[1] + "�E" + this.outDefItem[2] + "��" + this.outDefItem[3] + "��" + this.outDefItem[4] + "�i�r�Q�[�V�����쐬";

			// �t�H���g�̐F�𔒂ɂ���
			font.setColor(255, 255, 255);
			cell = new Cell(new Phrase(phrase1, font));
			table.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
			table.addCell(cell);

			/* �h�L�������g�ɒǉ� */
			document.add(table);

			// �O����`���b�Z�[�W
			table = new MyTable(2);
			table.setWidths(defLabel_widths);
			table.setWidth(TableWidth);
			table.setBorderColor(BackColor);

			/* �A�i�E���X1 */
			// �t�H���g�̐F��Ԃɂ���
			font.setColor(255, 0, 0);
			cell = new Cell(new Phrase("��", font));
			cell.setBackgroundColor(BackColor);
			cell.setBorderColor(BackColor);
			table.setDefaultHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(cell);
			cell = new Cell(new Phrase(this.outDefItem[5], font));
			cell.setBackgroundColor(BackColor);
			cell.setBorderColor(BackColor);
			table.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
			table.addCell(cell);

			/* �A�i�E���X2 */
			cell = new Cell(new Phrase("��", font));
			cell.setBackgroundColor(BackColor);
			cell.setBorderColor(BackColor);
			table.setDefaultHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(cell);
			cell = new Cell(new Phrase(this.outDefItem[6], font));
			cell.setBackgroundColor(BackColor);
			cell.setBorderColor(BackColor);
			table.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
			table.addCell(cell);

			/* �A�i�E���X3 */
			cell = new Cell(new Phrase("��", font));
			cell.setBackgroundColor(BackColor);
			cell.setBorderColor(BackColor);
			table.setDefaultHorizontalAlignment(Element.ALIGN_RIGHT);
			table.addCell(cell);
			cell = new Cell(new Phrase(this.outDefItem[7], font));
			cell.setBackgroundColor(BackColor);
			cell.setBorderColor(BackColor);
			table.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
			table.addCell(cell);

			/* �h�L�������g�ɒǉ� */
			document.add(table);

			// �t�H���g�̐F�����ɖ߂�
			font.setColor(0, 0, 0);
			PdfPTable pTable = new PdfPTable(3);
			PdfPCell cells = null;
			for (int i = 0; i < this.outputItem.length; i++) {
				/* �h�L�������g�ɒǉ� */
				document.add(space);

				// �i�r�Q�[�V�������
				/* �i�r�Q�[�V�����A�ۑ��A��ۑ� */
				pTable = new PdfPTable(3);
				final int[] navi_widths = { 15, 70, 15 };
				final int[] navi_widths2 = { 100 };

				pTable.setWidths(navi_widths);
				pTable.setWidthPercentage(TableWidth);
				cells = new PdfPCell(new Phrase(this.outDefItem[3] + "����", font));
				cells.setBackgroundColor(new Color(204, 204, 255));
				cells.setHorizontalAlignment(Element.ALIGN_CENTER);
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(1f);
				cells.setBorderWidthBottom(0.3f);
				cells.setBorderWidthLeft(1f);
				cells.setBorderWidthRight(0.3f);
				pTable.addCell(cells);

				final String skill_name = PZZ010_CharacterUtil.strEncode(this.outputItem[i][0]);
				cells = new PdfPCell(new Phrase(skill_name, font));
				cells.setColspan(2);
				cells.setBackgroundColor(BackColor);
				cells.setHorizontalAlignment(Element.ALIGN_CENTER);
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(1f);
				cells.setBorderWidthBottom(0.3f);
				cells.setBorderWidthRight(1f);
				pTable.addCell(cells);
				document.add(pTable);

				pTable = new PdfPTable(1);
				pTable.setWidths(navi_widths2);
				pTable.setWidthPercentage(TableWidth);
				cells = new PdfPCell(new Phrase(this.outDefItem[8], font));
				cells.setHorizontalAlignment(Element.ALIGN_CENTER);
				cells.setBackgroundColor(new Color(204, 204, 255));
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(0.3f);
				cells.setBorderWidthBottom(0.3f);
				cells.setBorderWidthLeft(1f);
				cells.setBorderWidthRight(1f);
				pTable.addCell(cells);
				document.add(pTable);

				pTable = new PdfPTable(1);
				pTable.setWidths(navi_widths2);
				pTable.setWidthPercentage(TableWidth);
				final String skill_deg = PZZ010_CharacterUtil.strEncode(this.outputItem[i][1]);
				cells = new PdfPCell(new Phrase(skill_deg, font));
				cells.setBackgroundColor(BackColor);
				cells.setHorizontalAlignment(Element.ALIGN_LEFT);
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(0.3f);
				cells.setBorderWidthBottom(0.3f);
				cells.setBorderWidthLeft(1f);
				cells.setBorderWidthRight(1f);
				pTable.addCell(cells);
				document.add(pTable);

				pTable = new PdfPTable(1);
				pTable.setWidths(navi_widths2);
				pTable.setWidthPercentage(TableWidth);
				cells = new PdfPCell(new Phrase(this.outDefItem[4] + "�i�r�Q�[�V����", font));
				cells.setBackgroundColor(new Color(255, 228, 225));
				cells.setHorizontalAlignment(Element.ALIGN_CENTER);
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(0.3f);
				cells.setBorderWidthBottom(0.3f);
				cells.setBorderWidthLeft(1f);
				cells.setBorderWidthRight(1f);
				pTable.addCell(cells);
				document.add(pTable);

				pTable = new PdfPTable(3);
				pTable.setWidths(navi_widths);
				pTable.setWidthPercentage(TableWidth);
				final String skill_navi = PZZ010_CharacterUtil.strEncode(this.outputItem[i][2]);
				cells = new PdfPCell(new Phrase(skill_navi, font));
				cells.setColspan(2);
				cells.setBackgroundColor(BackColor);
				cells.setHorizontalAlignment(Element.ALIGN_LEFT);
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(0.3f);
				cells.setBorderWidthBottom(1f);
				cells.setBorderWidthLeft(1f);
				cells.setBorderWidthRight(0.3f);
				pTable.addCell(cells);

				cells = new PdfPCell(new Phrase(this.outputItem[i][3], font));
				cells.setBackgroundColor(BackColor);
				cells.setHorizontalAlignment(Element.ALIGN_CENTER);
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(0.3f);
				cells.setBorderWidthBottom(1f);
				cells.setBorderWidthRight(1f);
				pTable.addCell(cells);

				/* �h�L�������g�ɒǉ� */
				document.add(pTable);

				document.add(space);

				/* DB��̍ŏI�X�V��� */
				pTable = new PdfPTable(7);
				// table = new MyTable(7);
				final int[] lastupdate_widths = { 15, 8, 17, 8, 17, 15, 20 };
				pTable.setWidths(lastupdate_widths);
				pTable.setWidthPercentage(TableWidth);

				cells = new PdfPCell(new Phrase("�ŏI�X�V��", font));
				cells.setBackgroundColor(new Color(204, 204, 255));
				cells.setHorizontalAlignment(Element.ALIGN_CENTER);
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(1f);
				cells.setBorderWidthBottom(1f);
				cells.setBorderWidthRight(0.3f);
				cells.setBorderWidthLeft(1f);
				pTable.addCell(cells);

				cells = new PdfPCell(new Phrase(this.outDefItem[9], font));
				cells.setBackgroundColor(new Color(204, 204, 255));
				cells.setHorizontalAlignment(Element.ALIGN_CENTER);
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(1f);
				cells.setBorderWidthBottom(1f);
				cells.setBorderWidthRight(0.3f);
				pTable.addCell(cells);

				final String busyo = PZZ010_CharacterUtil.strEncode(this.outputItem[i][4]);
				cells = new PdfPCell(new Phrase(busyo, font));
				cells.setHorizontalAlignment(Element.ALIGN_CENTER);
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(1f);
				cells.setBorderWidthBottom(1f);
				cells.setBorderWidthRight(0.3f);
				pTable.addCell(cells);

				cells = new PdfPCell(new Phrase(this.outDefItem[10], font));
				cells.setBackgroundColor(new Color(204, 204, 255));
				cells.setHorizontalAlignment(Element.ALIGN_CENTER);
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(1f);
				cells.setBorderWidthBottom(1f);
				cells.setBorderWidthRight(0.3f);
				pTable.addCell(cells);

				final String simei_kanji = PZZ010_CharacterUtil.strEncode(this.outputItem[i][5]);
				cells = new PdfPCell(new Phrase(simei_kanji, font));
				cells.setHorizontalAlignment(Element.ALIGN_CENTER);
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(1f);
				cells.setBorderWidthBottom(1f);
				cells.setBorderWidthRight(0.3f);
				pTable.addCell(cells);

				cells = new PdfPCell(new Phrase("�ŏI�X�V����", font));
				cells.setBackgroundColor(new Color(204, 204, 255));
				cells.setHorizontalAlignment(Element.ALIGN_CENTER);
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(1f);
				cells.setBorderWidthBottom(1f);
				cells.setBorderWidthRight(0.3f);
				pTable.addCell(cells);

				final String lastuptime = PZZ010_CharacterUtil.strEncode(this.outputItem[i][6]);
				cells = new PdfPCell(new Phrase(lastuptime, font));
				cells.setHorizontalAlignment(Element.ALIGN_CENTER);
				cells.setBorderWidth(0);
				cells.setBorderWidthTop(1f);
				cells.setBorderWidthBottom(1f);
				cells.setBorderWidthRight(1f);
				pTable.addCell(cells);

				/* �h�L�������g�ɒǉ� */
				document.add(pTable);
			}

			Log.method(this.login_no, "OUT", "");

		} catch (final BadElementException e) {
			throw e;
		} catch (final DocumentException e) {
			throw e;
		} catch (final IOException e) {
			throw e;
		} catch (final Exception e) {
			throw e;
		} finally {
			/* �h�L�������g����� */
			if (document != null) {
				try {
					document.close();
				} catch (final Exception e) {
					throw e;
				}
			}
			if (pw != null) {
				try {
					pw.close();
				} catch (final Exception e) {
					throw e;
				}
			}
		}
	}
}
