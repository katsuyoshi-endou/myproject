/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Writer;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.VelocityHelper;
import jp.co.hisas.career.learning.base.bean.PCY_CodeBean;
import jp.co.hisas.career.learning.base.bean.PCY_KensyuKanriJohoBean;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PzValueEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PzValueEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBeanForDL;
import jp.co.hisas.career.learning.base.valuebean.PCY_JizenkadaiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_JizenkadaiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBeanForDL;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PzValueBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_SosikiBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;

import com.lowagie.text.DocumentException;

/**
 * <PRE>
 * 
 * �T�v�F �����CVS�쐬���s���B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PCY330_MeiboDownLoadServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException, IOException, DocumentException, Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		try {

			final HttpSession session = request.getSession(false);
			final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");

			/* �g�D�}�b�v�擾 */
			final Map sosikiMap = PCY_CodeBean.getInstance().getCodeMap(PCY_CodeBean.SOSIKI);

			// EJBHome�Ǘ��N���X�̎擾
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();

			// �N���X���
			final PCY_ClassEJBHome classHome = (PCY_ClassEJBHome) fact.lookup(PCY_ClassEJBHome.class);
			final PCY_ClassEJB classEJB = classHome.create();
			final PCY_ClassBean classBean = classEJB.doSelectByPrimaryKey(new PCY_ClassBean(request), loginuser);

			final PCY_TaisyoEJBHome home_taisyo = (PCY_TaisyoEJBHome) fact.lookup(PCY_TaisyoEJBHome.class);
			final PCY_TaisyoEJB ejb_taisyo = home_taisyo.create();
			final PCY_SosikiBean[] sosikiBeens = ejb_taisyo.getSosiki(loginuser);

			// �\����
			PCY_KensyuKanriJohoBean[] taisyosyaBeans = null;
			final PCY_MousikomiJyokyoEJBHome mousikomihome = (PCY_MousikomiJyokyoEJBHome) fact.lookup(PCY_MousikomiJyokyoEJBHome.class);
			final PCY_MousikomiJyokyoEJB mousikomiejb = mousikomihome.create();
// MOD 2018/07/05 COMTURE 4-3.����o�̓X�e�[�^�X���ڕύX�Ή� START
//			taisyosyaBeans = mousikomiejb.getListWithClass(classBean.getKamokuBean().getKamokuCode(), classBean.getClassCode(), null, loginuser);
			taisyosyaBeans = mousikomiejb.getListWithClass(classBean.getKamokuBean().getKamokuCode(), classBean.getClassCode(), null, loginuser, true);
// MOD 2018/07/05 COMTURE 4-3.����o�̓X�e�[�^�X���ڕύX�Ή� END

			// �\�[�g
			final List taisyosyaList = new ArrayList();
			for (int i = 0; i < taisyosyaBeans.length; i++) {
				taisyosyaList.add(taisyosyaBeans[i]);
			}
			PCY_KensyuKanriJohoBean[] SorttaisyosyaBeans = new PCY_KensyuKanriJohoBean[taisyosyaList.size()];
			SorttaisyosyaBeans = (PCY_KensyuKanriJohoBean[]) taisyosyaList.toArray(SorttaisyosyaBeans);
			
			/* �\�[�g���� */
			// DEL 2017/06/15 COMTURE VCY330_����iver.02-01�j START
			// Arrays.sort(SorttaisyosyaBeans, new SosikiSimeiComparator());
	        // DEL 2017/06/15 COMTURE VCY330_����iver.02-01�j END
			// ADD 2017/06/15 COMTURE VCY330_����iver.02-01�j START
			Arrays.sort(SorttaisyosyaBeans, new MeiboComparator(classBean.getSyoninKubun()));
	        // ADD 2017/06/15 COMTURE VCY330_����iver.02-01�j END

// ADD 2017/05/16 COMTURE VCY330_����(ver.02-00) START
			final PCY_PzValueEJBHome pzvaluehome = (PCY_PzValueEJBHome) fact.lookup(PCY_PzValueEJBHome.class);
			final PCY_PzValueEJB pzvalueejb = pzvaluehome.create();
			final PCY_SyoninsyaEJBHome syoninsya_home = (PCY_SyoninsyaEJBHome) fact.lookup(PCY_SyoninsyaEJBHome.class);
			final PCY_SyoninsyaEJB syoninsya_ejb = syoninsya_home.create();
// ADD 2017/05/16 COMTURE VCY330_����(ver.02-00) END

// ADD 2017/07/12 ���덀�ڒǉ� START
			// ���O�ۑ�Ɋւ�������擾
			SorttaisyosyaBeans = mousikomiejb.addJizenkadaiJyokyoList(SorttaisyosyaBeans, loginuser);
// ADD 2017/07/12 ���덀�ڒǉ� END

			final Vector lines = new Vector();
			for (int i = 0; i < SorttaisyosyaBeans.length; i++) {
				final Vector columns = new Vector();

				// �_�E�����[�h�ΏۃX�e�[�^�X (��u�ҁA�񍐑ҁA����ҁA���C���A�C��)
				// ��u��(�\���󋵃X�e�[�^�X1:��t���2)
				if (SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null && SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("1")
						&& SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() != null && SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai().equals("2")
						|| SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null && SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("2")
						&& SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() == null || SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null
						&& SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("3") && SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() == null
						|| SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei() != null && SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei().equals("0")
// MOD 2018/07/03 COMTURE 4-3.����o�̓X�e�[�^�X���ڕύX�Ή� START
//						|| SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei() != null && SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei().equals("1")) {
						|| SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei() != null && SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei().equals("1")
// MOD 2018/07/03 COMTURE 4-3.����o�̓X�e�[�^�X���ڕύX�Ή� END
// ADD 2018/07/04 COMTURE 4-3.����o�̓X�e�[�^�X���ڕύX�Ή� START
						// ���F�ҁA��t�ҁA��t�������A�F���ǉ�
						|| SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null && SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("0")// ���F��
						|| SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null && SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("1")
						&& SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() != null && SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai().equals("0")// ��t��
						|| SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null && SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("1")
						&& SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() != null && SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai().equals("1")// ��t������
						|| SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei() != null && SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei().equals("2")){ // �F��
// ADD 2018/07/04 COMTURE 4-3.����o�̓X�e�[�^�X���ڕύX�Ή� END

					/* �l���擾 */
					String busyoRyakusyo = "";
					for (int j = 0; j < sosikiBeens.length; j++) {
						if (sosikiBeens[j].getSosikiCode() != null && SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSosikiCode() != null) {
							if (sosikiBeens[j].getSosikiCode().trim().equals(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSosikiCode().trim())) {
								busyoRyakusyo = sosikiBeens[j].getBusyoRyakusyoMei();
								break;
							}
						}
					}
					// �\���Ώێ҂̌��E�ސE�t���O��2(�ސE)�ł���Ε\�����Ȃ�
					final String gensyokuTaisyoku = SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getGensyokuTaisyokuFlg();
					if (gensyokuTaisyoku == null || gensyokuTaisyoku.equals("2")) {
						continue;
					}
					columns.add(busyoRyakusyo);
					columns.add(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSimeiNo());
					columns.add(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getKanjiSimei());
					columns.add(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getEigoSimei());
					columns.add(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getKanaSimei());
					columns.add(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.TAISYO_KUBUN, SorttaisyosyaBeans[i].getTaisyousyaBean().getTaisyoKubun()));
					columns.add(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getMail());
					columns.add(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSosikiCode());

// ADD 2017/05/16 COMTURE VCY330_����(ver.02-00) START
					// T01_�l�����l���擾
					PCY_PzValueBean pzValue = pzvalueejb.getPersonalPzValue(
							SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSimeiNo(), loginuser);
					if (pzValue == null) {
						pzValue = new PCY_PzValueBean();
					}
					
					columns.add(pzValue.getPzVal01());  // T01_�l�����l.�l�����l_01
					columns.add(pzValue.getCmpaCd());   // T01_�l�����l.��ЃR�[�h
					columns.add(pzValue.getPzVal02());  // T01_�l�����l.�l�����l_02
					columns.add(pzValue.getPzVal03());  // T01_�l�����l.�l�����l_03
					columns.add(pzValue.getPzVal04());  // T01_�l�����l.�l�����l_04
					columns.add(pzValue.getPzVal05());  // T01_�l�����l.�l�����l_05

					// L16_���F�҃}�X�^.����NO=��u�҂ƂȂ�L16_���F�҃}�X�^.���F�҂P�ɕR�t���f�[�^���擾
					PCY_PersonalBean syoninsyaPersonalBean = syoninsya_ejb.getSyoninsyaParsonal(
							SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSimeiNo(), false, loginuser);
					PCY_PzValueBean syoninsyaPzValue = null;
					if (syoninsyaPersonalBean == null) {
						syoninsyaPersonalBean = new PCY_PersonalBean(); 
					} else {
						syoninsyaPzValue = pzvalueejb.getPersonalPzValue(syoninsyaPersonalBean.getSimeiNo(), loginuser);
					}
					if (syoninsyaPzValue == null) {
						syoninsyaPzValue = new PCY_PzValueBean(); 
					}

					columns.add(syoninsyaPersonalBean.getSimeiNo());     // T01_�p�[�\�i���v���t�@�C��.����NO
					columns.add(syoninsyaPersonalBean.getKanjiSimei());  // T01_�p�[�\�i���v���t�@�C��.��������
					columns.add(syoninsyaPersonalBean.getEijiSimei());   // T01_�p�[�\�i���v���t�@�C��.�����i�p���j
					columns.add(syoninsyaPersonalBean.getKanaSimei());   // T01_�p�[�\�i���v���t�@�C��.�J�i�����i�S�p�j
					columns.add(syoninsyaPersonalBean.getMail());        // T01_�p�[�\�i���v���t�@�C��.Mail
					columns.add(syoninsyaPzValue.getPzVal01());          // T01_�l�����l.�l�����l_01
					columns.add(syoninsyaPzValue.getCmpaCd());           // T01_�l�����l.��ЃR�[�h
					columns.add(syoninsyaPzValue.getPzVal02());          // T01_�l�����l.�l�����l_02
					columns.add(syoninsyaPzValue.getPzVal03());          // T01_�l�����l.�l�����l_03
					columns.add(syoninsyaPzValue.getPzVal04());          // T01_�l�����l.�l�����l_04
					columns.add(syoninsyaPzValue.getPzVal05());          // T01_�l�����l.�l�����l_05
// ADD 2017/05/16 COMTURE VCY330_����(ver.02-00) END
					
                    // ADD 2017/06/15 COMTURE VCY330_����iver.02-01�j START
                    columns.add(SorttaisyosyaBeans[i].getStatusLabelForMeibo()); // �X�e�[�^�X
                    columns.add(PZZ010_CharacterUtil.ChangeYmdHm(SorttaisyosyaBeans[i].getSyoninNichijiForSort(classBean.getSyoninKubun()))); // ���F����
                    // ADD 2017/06/15 COMTURE VCY330_����iver.02-01�j END
                    
// ADD 2017/07/12 ���덀�ڒǉ� START

					PCY_JizenkadaiJyokyoBean jizenkadaiJyokyoBean = SorttaisyosyaBeans[i].getJizenkadaiJyokyoBean();
					PCY_JizenkadaiBean jizenkadaiBean = null;
					if (jizenkadaiJyokyoBean != null) {
						jizenkadaiBean = jizenkadaiJyokyoBean.getJizenkadaiBean();
					} else {
						jizenkadaiJyokyoBean = new PCY_JizenkadaiJyokyoBean();
					}
					if (jizenkadaiBean == null) {
						jizenkadaiBean = new PCY_JizenkadaiBean();
					}

					String jizenkadaiKubun = jizenkadaiBean.getJizenkadaiKubun();
					String jizenTmplFile = jizenkadaiBean.getJizenkadaiFilename();
					String jizenKadaiFile = jizenkadaiJyokyoBean.getJizenkadaiFilename();

					// ���O�ۑ�X�e�[�^�X
					if("0".equals(jizenkadaiKubun)) {
						columns.add(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.JIZENKADAI_STATUS, "NONE"));
						columns.add("");
					} else if("1".equals(jizenkadaiKubun) && jizenTmplFile == null) {
						columns.add(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.JIZENKADAI_STATUS, "PREPARE"));
						columns.add("");
					} else if("1".equals(jizenkadaiKubun) && jizenTmplFile != null && jizenKadaiFile == null) {
						columns.add(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.JIZENKADAI_STATUS, "NOT_SUBMIT"));
						columns.add("");
					} else if("1".equals(jizenkadaiKubun) && jizenTmplFile != null && jizenKadaiFile != null) {
						// ���O�ۑ�X�e�[�^�X��"��o�ς�"�̏ꍇ�A��o�������Z�b�g����
						columns.add(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.JIZENKADAI_STATUS, "SUBMITTED"));

						// ���O�ۑ��o����
						columns.add(PZZ010_CharacterUtil.ChangeYmdHm(jizenkadaiJyokyoBean.getUploadbi() + jizenkadaiJyokyoBean.getUploadjikoku()));
					} else {
						columns.add("");
						columns.add("");
					}
// ADD 2017/07/12 ���덀�ڒǉ� END
// ADD 2018/07/03 COMTURE 4-3.����o�̓X�e�[�^�X���ڕύX�Ή� START
                    // �����ԍ�
                    columns.add(pzValue.getPzVal08()); // T01_�l�����l.�l�����l_08
                    
                    // ���ݒn
                    columns.add(pzValue.getPzVal09()); // T01_�l�����l.�l�����l_09
// ADD 2018/07/03 COMTURE 4-3.����o�̓X�e�[�^�X���ڕύX�Ή� END

					lines.add(columns);
				}
			}

			// ���݂̓��t�Ǝ���
			final String dateTime = PZZ010_CharacterUtil.getDayTime();
			// �_�E�����[�h�e���v���[�g��
			final String tableName = request.getParameter("download_templete");
			String DLtableName = "";
			if (null != tableName && !tableName.equals("") && tableName.length() >= 4) {
				if (tableName.indexOf("HTML") != -1) {
					DLtableName = "Template_HTML";
				} else if (tableName.indexOf("CVS") != -1) {
					DLtableName = "Template_CVS";
				} else {
					DLtableName = "Template";
				}
			} else {
				DLtableName = "Template";
			}

			/* ���샍�O�o�� */
			final String login_no = userinfo.getLogin_no();
			final String simei_no = userinfo.getSimei_no();
			OutLogBean.sousaKojinJohoLog("LNG004", login_no, simei_no, ("�ȖڃR�[�h:" + classBean.getKamokuBean().getKamokuCode() + ",�N���X�R�[�h:" + classBean.getClassCode()));

			// �t�@�C����
			String fileName = dateTime + "_" + DLtableName;
			// �_�E�����[�h�`��
			final String downloadKeisiki = request.getParameter("download_keisiki");
			if (downloadKeisiki.equals("HTML")) {
				fileName += ".html";
			} else {
				fileName += ".csv";
			}

			/* �w�b�_�������� */
			final VelocityHelper vh = new VelocityHelper(tableName);

			vh.setParameter("classBean", new PCY_ClassBeanForDL(classBean));
			vh.setParameter("kamokuBean", new PCY_KamokuBeanForDL(classBean.getKamokuBean()));
			vh.setParameter("lines", lines);
			vh.setParameter("date", dateTime.substring(0, 4) + "/" + dateTime.substring(4, 6) + "/" + dateTime.substring(6, 8));
			vh.setParameter("time", dateTime.substring(8, 10) + ":" + dateTime.substring(10, 12));
			final Writer w = vh.getWriter();
			final ByteArrayInputStream bais = new ByteArrayInputStream(w.toString().getBytes());
			request.setAttribute("H080_FileName", fileName);
			request.setAttribute("H081_ContentType", HcdbDef.CONTENT_TYPE);
			request.setAttribute("STREAM", bais);

			Log.performance(loginuser.getSimeiNo(), false, "");
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return this.getForwardPath();

		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RemoteException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final IOException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final DocumentException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		}
	}

	/**
	 * ���F�����i�\�[�g�p�j�A�g�D�R�[�h�A����No���L�[�Ƀ\�[�g���܂��B
	 */
    // DEL 2017/06/15 COMTURE VCY330_����iver.02-01�j START
	// private class SosikiSimeiComparator implements Comparator 
    // DEL 2017/06/15 COMTURE VCY330_����iver.02-01�j END
    // ADD 2017/06/15 COMTURE VCY330_����iver.02-01�j START
    private class MeiboComparator implements Comparator<PCY_KensyuKanriJohoBean> {
        
        /** ���F�敪 */
        String syoninKubun = null;
        public MeiboComparator(String syoninKubun){
            this.syoninKubun = syoninKubun;
        }
        
        // ADD 2017/06/15 COMTURE VCY330_����iver.02-01�j END
        

        // DEL 2017/06/15 COMTURE VCY330_����iver.02-01�j START
        // public int compare(final Object o1, final Object o2) {
        // DEL 2017/06/15 COMTURE VCY330_����iver.02-01�j END
		
        // ADD 2017/06/15 COMTURE VCY330_����iver.02-01�j START
        public int compare(final PCY_KensyuKanriJohoBean taisyou1,
                final PCY_KensyuKanriJohoBean taisyou2) {
            // ADD 2017/06/15 COMTURE VCY330_����iver.02-01�j END

            // DEL 2017/06/15 COMTURE VCY330_����iver.02-01�j START
            // final PCY_KensyuKanriJohoBean taisyou1 = (PCY_KensyuKanriJohoBean) o1;
            // final PCY_KensyuKanriJohoBean taisyou2 = (PCY_KensyuKanriJohoBean) o2;
            // DEL 2017/06/15 COMTURE VCY330_����iver.02-01�j END

			int ret = 0;

            // ADD 2017/06/15 COMTURE VCY330_����iver.02-01�j START
            /* ��P�\�[�g�L�[ �\�[�g�p���F���� */
            ret =
                    taisyou1.getSyoninNichijiForSort(this.syoninKubun).compareTo(
                            taisyou2.getSyoninNichijiForSort(this.syoninKubun));

            if (ret != 0) {
                return ret;
            }
            // ADD 2017/06/15 COMTURE VCY330_����iver.02-01�j END
			
			
			/* ��Q�\�[�g�L�[ �g�D�R�[�h */
			if (taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode() != null && taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode() != null) {
				ret = taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode().compareTo(taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode());
			} else if (taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode() == null && taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode() != null) {
				return 1;
			} else if (taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode() != null && taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode() == null) {
				return -1;
			}

			if (ret != 0) {
				return ret;
			}

			/* ��R�\�[�g�L�[ ����No */
			if (taisyou1.getMousikomiBean().getPersonalBean().getSimeiNo() != null && taisyou2.getMousikomiBean().getPersonalBean().getSimeiNo() != null) {
				ret = taisyou1.getMousikomiBean().getPersonalBean().getSimeiNo().compareTo(taisyou2.getMousikomiBean().getPersonalBean().getSimeiNo());
			} else if (taisyou1.getMousikomiBean().getPersonalBean().getSimeiNo() == null && taisyou2.getMousikomiBean().getPersonalBean().getSimeiNo() != null) {
				return 1;
			} else if (taisyou1.getMousikomiBean().getPersonalBean().getSimeiNo() != null && taisyou2.getMousikomiBean().getPersonalBean().getSimeiNo() == null) {
				return -1;
			}

			if (ret != 0) {
				return ret;
			}

			return ret;
		}
	}

}
