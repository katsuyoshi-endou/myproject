/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/12/26  01.00      ��� �ӎ�    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.valuebean;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.hisas.career.learning.base.bean.PCY_CodeBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;

/**
 * �\���폜�����}�X�^��\��ValueBean�ł��B
 */
public class PCY_MousikomiSakujoRirekiBean extends PCY_MasterBean implements Serializable {

	private String syoribi = null;

	private String syorijikoku = null;

	private String syorisya = null;

	private String syori_flg = null;

	private String simei_no = null;

	private String kamoku_code = null;

	private String kamoku_mei1 = null;

	private String kamoku_mei2 = null;

	private String kamoku_mei3 = null;

	private String kamoku_mei4 = null;

	private String version_kanri = null;

	private String kamoku_group = null;

	private String kamoku_group_mei = null;

	private String category_code1 = null;

	private String category_mei1 = null;

	private String category_code2 = null;

	private String category_mei2 = null;

	private String category_code3 = null;

	private String category_mei3 = null;

	private String category_code4 = null;

	private String category_mei4 = null;

	private String category_code5 = null;

	private String category_mei5 = null;

	private String kanrimoto_code = null;

	private String kanrimoto_mei = null;

	private String tanka = null;

	private String kamoku_naiyou = null;

	private String jyukou_jyoken = null;

	private String yobi1 = null;

	private String yobi2 = null;

	private String class_code = null;

	private String class_mei = null;

	private String nissuu = null;

	private String kaisibi = null;

	private String syuryobi = null;

	private String kaisaijikan = null;

	private String kaisijikoku = null;

	private String syuryojikoku = null;

	private String mousikomi_kaisibi = null;

	private String mousikomi_syuryobi = null;

	private String jyukou_kigen = null;

	private String chiku_code = null;

	private String chiku_mei = null;

	private String kyositu_code = null;

	private String kyositu_mei = null;

	private String teiin = null;

	private String kaisai_saisyo_ninzuu = null;

	private String kousi_code = null;

	private String kousi_mei = null;

	private String kisyo_ikkatsu_flg = null;

	private String zensya_taisyo_flg = null;

	private String mousikomi_kubun = null;

	private String syonin_kubun = null;

	private String uketuke_kubun = null;

	private String houkoku_kubun = null;

	private String ninsyo_kubun = null;

	private String hantei_kubun = null;

	private String kaisai_jyotai = null;

	private String annai_mail_kubun = null;

	private String follow_mail_kubun = null;

	private String follow_mail_nissuu1 = null;

	private String follow_mail_nissuu2 = null;

	private String bikou = null;

	private String taisyo_kubun = null;

	private String mousikomibi = null;

	private String mousikomijikoku = null;

	private String mousikomisya = null;

	private String syoninbi1 = null;

	private String syoninjikoku1 = null;

	private String syoninsya1 = null;

	private String syoninbi2 = null;

	private String syoninjikoku2 = null;

	private String syoninsya2 = null;

	private String uketukebi = null;

	private String uketukejikoku = null;

	private String uketukesya = null;

	/**
	 * �f�t�H���g�̃R���X�g���N�^�ł��B
	 */
	public PCY_MousikomiSakujoRirekiBean() {
		super();
	}

	/**
	 * ResultSet ���玁��No���擾���� �����o�ϐ��ɐݒ肵�܂��B
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param TableName �\���폜�����e�[�u���̖��O
	 * @throws SQLException �f�[�^�x�[�X�A�N�Z�X�G���[�����������ꍇ
	 */
	public PCY_MousikomiSakujoRirekiBean(final ResultSet rs, final String tableName) throws SQLException {
		super.setTableName(tableName);
		try {
			this.setSimei_no(rs.getString(this.getIdentifier() + "simei_no"));
			this.setKamoku_code(rs.getString(this.getIdentifier() + "kamoku_code"));
			this.setKamoku_mei1(rs.getString(this.getIdentifier() + "kamoku_mei1"));
			this.setClass_code(rs.getString(this.getIdentifier() + "class_code"));
			this.setClass_mei(rs.getString(this.getIdentifier() + "class_mei"));
			this.setMousikomibi(rs.getString(this.getIdentifier() + "mousikomibi"));
			this.setMousikomijikoku(rs.getString(this.getIdentifier() + "mousikomijikoku"));
			this.setMousikomisya(rs.getString(this.getIdentifier() + "mousikomisya"));
			this.setSyoninbi1(rs.getString(this.getIdentifier() + "syoninbi1"));
			this.setSyoninjikoku1(rs.getString(this.getIdentifier() + "syoninjikoku1"));
			this.setSyoninsya1(rs.getString(this.getIdentifier() + "syoninsya1"));
			this.setSyoninbi2(rs.getString(this.getIdentifier() + "syoninbi2"));
			this.setSyoninjikoku2(rs.getString(this.getIdentifier() + "syoninjikoku2"));
			this.setSyoninsya2(rs.getString(this.getIdentifier() + "syoninsya2"));
			this.setUketukebi(rs.getString(this.getIdentifier() + "uketukebi"));
			this.setUketukejikoku(rs.getString(this.getIdentifier() + "uketukejikoku"));
			this.setUketukesya(rs.getString(this.getIdentifier() + "Uketukesya"));
			this.setTaisyo_kubun(rs.getString(this.getIdentifier() + "taisyo_kubun"));
			this.setKaisai_jyotai(rs.getString(this.getIdentifier() + "kaisai_jyotai"));
			this.setKaisibi(rs.getString(this.getIdentifier() + "kaisibi"));
			this.setSyuryobi(rs.getString(this.getIdentifier() + "syuryobi"));
		} catch (final SQLException e) {
			throw e;
		}
	}

	/**
	 * ����No�J�������擾���܂��B
	 * @param tableName �e�[�u����
	 * @return ����No�J������
	 */
	public static String getColumns(final String tableName) {
		final StringBuffer ret = new StringBuffer();
		ret.append(tableName + ".simei_no as " + tableName + "_simei_no, ");
		ret.append(tableName + ".kamoku_code as " + tableName + "_kamoku_code, ");
		ret.append(tableName + ".kamoku_mei1 as " + tableName + "_kamoku_mei1, ");
		ret.append(tableName + ".class_code as " + tableName + "_class_code, ");
		ret.append(tableName + ".class_mei as " + tableName + "_class_mei, ");
		ret.append(tableName + ".mousikomibi as " + tableName + "_mousikomibi, ");
		ret.append(tableName + ".mousikomijikoku as " + tableName + "_mousikomijikoku, ");
		ret.append(tableName + ".mousikomisya as " + tableName + "_mousikomisya, ");
		ret.append(tableName + ".syoninbi1 as " + tableName + "_syoninbi1, ");
		ret.append(tableName + ".syoninjikoku1 as " + tableName + "_syoninjikoku1, ");
		ret.append(tableName + ".syoninsya1 as " + tableName + "_syoninsya1, ");
		ret.append(tableName + ".syoninbi2 as " + tableName + "_syoninbi2, ");
		ret.append(tableName + ".syoninjikoku2 as " + tableName + "_syoninjikoku2, ");
		ret.append(tableName + ".syoninsya2 as " + tableName + "_syoninsya2, ");
		ret.append(tableName + ".uketukebi as " + tableName + "_uketukebi, ");
		ret.append(tableName + ".uketukejikoku as " + tableName + "_uketukejikoku, ");
		ret.append(tableName + ".uketukesya as " + tableName + "_uketukesya, ");
		ret.append(tableName + ".taisyo_kubun as " + tableName + "_taisyo_kubun, ");
		ret.append(tableName + ".kaisai_jyotai as " + tableName + "_kaisai_jyotai, ");
		ret.append(tableName + ".kaisibi as " + tableName + "_kaisibi, ");
		ret.append(tableName + ".syuryobi as " + tableName + "_syuryobi ");

		return ret.toString();
	}

	public PCY_MousikomiSakujoRirekiBean(final PCY_MousikomiJyokyoBean mousikomiBeanTemp, final PCY_TaisyosyaBean taisyosyaBean, final PCY_PersonalBean loginuser, final String code) {
		super();

		this.setSyoribi(PZZ010_CharacterUtil.GetDay());

		this.setSyorijikoku(PZZ010_CharacterUtil.GetTime());

		this.setSyorisya(loginuser.getSimeiNo());

		this.setSyoriflg(code);

		this.setSimei_no(mousikomiBeanTemp.getSimeiNo());

		this.setKamoku_code(mousikomiBeanTemp.getKamokuCode());

		this.setKamoku_mei1(mousikomiBeanTemp.getClassBean().getKamokuBean().getKamokuMei1());

		this.setKamoku_mei2(mousikomiBeanTemp.getClassBean().getKamokuBean().getKamokuMei2());

		this.setKamoku_mei3(mousikomiBeanTemp.getClassBean().getKamokuBean().getKamokuMei3());

		this.setKamoku_mei4(mousikomiBeanTemp.getClassBean().getKamokuBean().getKamokuMei4());

		this.setVersion_kanri(mousikomiBeanTemp.getClassBean().getKamokuBean().getVersionKanri());

		this.setKamoku_group(mousikomiBeanTemp.getClassBean().getKamokuBean().getKamokuGroup());

		this.setKamoku_group_mei(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.KAMOKUGROUP, mousikomiBeanTemp.getClassBean().getKamokuBean().getKamokuGroup()));

		this.setCategory_code1(mousikomiBeanTemp.getClassBean().getKamokuBean().getCategoryCode1());

		this.setCategory_mei1(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.CATEGORY1, mousikomiBeanTemp.getClassBean().getKamokuBean().getCategoryCode1()));

		this.setCategory_code2(mousikomiBeanTemp.getClassBean().getKamokuBean().getCategoryCode2());

		this.setCategory_mei2(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.CATEGORY2, mousikomiBeanTemp.getClassBean().getKamokuBean().getCategoryCode2()));

		this.setCategory_code3(mousikomiBeanTemp.getClassBean().getKamokuBean().getCategoryCode3());

		this.setCategory_mei3(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.CATEGORY3, mousikomiBeanTemp.getClassBean().getKamokuBean().getCategoryCode3()));

		this.setCategory_code4(mousikomiBeanTemp.getClassBean().getKamokuBean().getCategoryCode4());

		this.setCategory_mei4(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.CATEGORY4, mousikomiBeanTemp.getClassBean().getKamokuBean().getCategoryCode4()));

		this.setCategory_code5(mousikomiBeanTemp.getClassBean().getKamokuBean().getCategoryCode5());

		this.setCategory_mei5(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.CATEGORY5, mousikomiBeanTemp.getClassBean().getKamokuBean().getCategoryCode5()));

		this.setKanrimoto_code(mousikomiBeanTemp.getClassBean().getKamokuBean().getKanrimotoCode());

		this.setKanrimoto_mei(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.KANRIMOTO, mousikomiBeanTemp.getClassBean().getKamokuBean().getKanrimotoCode()));

		this.setTanka(mousikomiBeanTemp.getClassBean().getTanka().toString()); // CHG#2007/3/6 s-hiura

		this.setKamoku_naiyou(mousikomiBeanTemp.getClassBean().getKamokuBean().getKamokuNaiyou());

		this.setJyukou_jyoken(mousikomiBeanTemp.getClassBean().getKamokuBean().getJyukouJyoken());

		this.setYobi1(mousikomiBeanTemp.getClassBean().getKamokuBean().getYobi1());

		this.setYobi2(mousikomiBeanTemp.getClassBean().getKamokuBean().getYobi2());

		this.setClass_code(mousikomiBeanTemp.getClassCode());

		this.setClass_mei(mousikomiBeanTemp.getClassBean().getClassMei());

		this.setNissuu(mousikomiBeanTemp.getClassBean().getNissuu() != null ? mousikomiBeanTemp.getClassBean().getNissuu().toString() : "");

		this.setKaisibi(mousikomiBeanTemp.getClassBean().getKaisibi());

		this.setSyuryobi(mousikomiBeanTemp.getClassBean().getSyuryobi());

		this.setKaisaijikan(mousikomiBeanTemp.getClassBean().getKaisaijikan());

		this.setKaisijikoku(mousikomiBeanTemp.getClassBean().getKaisijikoku());

		this.setSyuryojikoku(mousikomiBeanTemp.getClassBean().getSyuryojikoku());

		this.setMousikomi_kaisibi(mousikomiBeanTemp.getClassBean().getMousikomiKaisibi());

		this.setMousikomi_syuryobi(mousikomiBeanTemp.getClassBean().getMousikomiSyuryobi());

		this.setJyukou_kigen(mousikomiBeanTemp.getClassBean().getJyukouKigen());

		this.setChiku_code(mousikomiBeanTemp.getClassBean().getChikuCode());

		this.setChiku_mei(mousikomiBeanTemp.getClassBean().getChikuMei());

		this.setKyositu_code(mousikomiBeanTemp.getClassBean().getKyosituCode());

		this.setKyositu_mei(mousikomiBeanTemp.getClassBean().getKyosituMei());

		this.setTeiin(mousikomiBeanTemp.getClassBean().getTeiin() != null ? mousikomiBeanTemp.getClassBean().getTeiin().toString() : "");

		this.setKaisai_saisyo_ninzuu(mousikomiBeanTemp.getClassBean().getKaisaiSaisyoNinzuu() != null ? mousikomiBeanTemp.getClassBean().getKaisaiSaisyoNinzuu().toString() : "");

		this.setKousi_code(mousikomiBeanTemp.getClassBean().getKousiCode());

		this.setKousi_mei(mousikomiBeanTemp.getClassBean().getKousiMei());

		this.setKisyo_ikkatsu_flg(mousikomiBeanTemp.getClassBean().getKisyoIkkatsuFlg());

		this.setZensya_taisyo_flg(mousikomiBeanTemp.getClassBean().getZensyaTaisyoFlg());

		this.setMousikomi_kubun(mousikomiBeanTemp.getClassBean().getMousikomiKubun());

		this.setSyonin_kubun(mousikomiBeanTemp.getClassBean().getSyoninKubun());

		this.setUketuke_kubun(mousikomiBeanTemp.getClassBean().getUketukeKubun());

		this.setHoukoku_kubun(mousikomiBeanTemp.getClassBean().getHoukokuKubun());

		this.setNinsyo_kubun(mousikomiBeanTemp.getClassBean().getNinsyoKubun());

		this.setHantei_kubun(mousikomiBeanTemp.getClassBean().getHanteiKubun());

		this.setKaisai_jyotai(mousikomiBeanTemp.getClassBean().getKaisaiJyotai());

		this.setAnnai_mail_kubun(mousikomiBeanTemp.getClassBean().getAnnaiMailKubun());

		this.setFollow_mail_kubun(mousikomiBeanTemp.getClassBean().getFollowMailKubun());

		this.setFollow_mail_nissuu1(mousikomiBeanTemp.getClassBean().getFollowMailNissuu1());

		this.setFollow_mail_nissuu2(mousikomiBeanTemp.getClassBean().getFollowMailNissuu2());

		this.setBikou(mousikomiBeanTemp.getClassBean().getBikou());

		this.setTaisyo_kubun(taisyosyaBean.getTaisyoKubun());

		this.setMousikomibi(mousikomiBeanTemp.getMousikomibi());

		this.setMousikomijikoku(mousikomiBeanTemp.getMousikomijikoku());

		this.setMousikomisya(mousikomiBeanTemp.getMousikomisya());

		this.setSyoninbi1(mousikomiBeanTemp.getSyoninbi1());

		this.setSyoninjikoku1(mousikomiBeanTemp.getSyoninjikoku1());

		this.setSyoninsya1(mousikomiBeanTemp.getSyoninsya1());

		this.setSyoninbi2(mousikomiBeanTemp.getSyoninbi2());

		this.setSyoninjikoku2(mousikomiBeanTemp.getSyoninjikoku2());

		this.setSyoninsya2(mousikomiBeanTemp.getSyoninsya2());

		this.setUketukebi(mousikomiBeanTemp.getUketukebi());

		this.setUketukejikoku(mousikomiBeanTemp.getUketukejikoku());

		this.setUketukesya(mousikomiBeanTemp.getUketukesya());
	}

	/**
	 * �J�����̕ʖ����`���� SQL ����Ԃ��܂��B
	 * @return �J�����̕ʖ����`���� SQL ��
	 */
	public static String getColumns() {

		final StringBuffer ret = new StringBuffer();
		ret.append("SYORIBI, ");
		ret.append("SYORIJIKOKU, ");
		ret.append("SYORISYA, ");
		ret.append("SYORI_FLG, ");
		ret.append("SIMEI_NO, ");
		ret.append("KAMOKU_CODE, ");
		ret.append("KAMOKU_MEI1, ");
		ret.append("KAMOKU_MEI2, ");
		ret.append("KAMOKU_MEI3, ");
		ret.append("KAMOKU_MEI4, ");
		ret.append("VERSION_KANRI, ");
		ret.append("KAMOKU_GROUP, ");
		ret.append("KAMOKU_GROUP_MEI, ");
		ret.append("CATEGORY_CODE1, ");
		ret.append("CATEGORY_MEI1, ");
		ret.append("CATEGORY_CODE2, ");
		ret.append("CATEGORY_MEI2, ");
		ret.append("CATEGORY_CODE3, ");
		ret.append("CATEGORY_MEI3, ");
		ret.append("CATEGORY_CODE4, ");
		ret.append("CATEGORY_MEI4, ");
		ret.append("CATEGORY_CODE5, ");
		ret.append("CATEGORY_MEI5, ");
		ret.append("KANRIMOTO_CODE, ");
		ret.append("KANRIMOTO_MEI, ");
		ret.append("TANKA, ");
		ret.append("KAMOKU_NAIYOU, ");
		ret.append("JYUKOU_JYOKEN, ");
		ret.append("YOBI1, ");
		ret.append("YOBI2, ");
		ret.append("CLASS_CODE, ");
		ret.append("CLASS_MEI, ");
		ret.append("NISSUU, ");
		ret.append("KAISIBI, ");
		ret.append("SYURYOBI, ");
		ret.append("KAISAIJIKAN, ");
		ret.append("KAISIJIKOKU, ");
		ret.append("SYURYOJIKOKU, ");
		ret.append("MOUSIKOMI_KAISIBI, ");
		ret.append("MOUSIKOMI_SYURYOBI, ");
		ret.append("JYUKOU_KIGEN, ");
		ret.append("CHIKU_CODE, ");
		ret.append("CHIKU_MEI, ");
		ret.append("KYOSITU_CODE, ");
		ret.append("KYOSITU_MEI, ");
		ret.append("TEIIN, ");
		ret.append("KAISAI_SAISYO_NINZUU, ");
		ret.append("KOUSI_CODE, ");
		ret.append("KOUSI_MEI, ");
		ret.append("KISYO_IKKATSU_FLG, ");
		ret.append("ZENSYA_TAISYO_FLG, ");
		ret.append("MOUSIKOMI_KUBUN, ");
		ret.append("SYONIN_KUBUN, ");
		ret.append("UKETUKE_KUBUN, ");
		ret.append("HOUKOKU_KUBUN, ");
		ret.append("NINSYO_KUBUN, ");
		ret.append("HANTEI_KUBUN, ");
		ret.append("KAISAI_JYOTAI, ");
		ret.append("ANNAI_MAIL_KUBUN, ");
		ret.append("FOLLOW_MAIL_KUBUN, ");
		ret.append("FOLLOW_MAIL_NISSUU1, ");
		ret.append("FOLLOW_MAIL_NISSUU2, ");
		ret.append("BIKOU, ");
		ret.append("TAISYO_KUBUN, ");
		ret.append("MOUSIKOMIBI, ");
		ret.append("MOUSIKOMIJIKOKU, ");
		ret.append("MOUSIKOMISYA, ");
		ret.append("SYONINBI1, ");
		ret.append("SYONINJIKOKU1, ");
		ret.append("SYONINSYA1, ");
		ret.append("SYONINBI2, ");
		ret.append("SYONINJIKOKU2, ");
		ret.append("SYONINSYA2, ");
		ret.append("UKETUKEBI, ");
		ret.append("UKETUKEJIKOKU, ");
		ret.append("UKETUKESYA ");

		return ret.toString();
	}

	/**
	 * @return
	 */
	public String getAnnai_mail_kubun() {
		return this.annai_mail_kubun;
	}

	/**
	 * @return
	 */
	public String getBikou() {
		return this.bikou;
	}

	/**
	 * @return
	 */
	public String getCategory_code1() {
		return this.category_code1;
	}

	/**
	 * @return
	 */
	public String getCategory_code2() {
		return this.category_code2;
	}

	/**
	 * @return
	 */
	public String getCategory_code3() {
		return this.category_code3;
	}

	/**
	 * @return
	 */
	public String getCategory_code4() {
		return this.category_code4;
	}

	/**
	 * @return
	 */
	public String getCategory_code5() {
		return this.category_code5;
	}

	/**
	 * @return
	 */
	public String getCategory_mei1() {
		return this.category_mei1;
	}

	/**
	 * @return
	 */
	public String getCategory_mei2() {
		return this.category_mei2;
	}

	/**
	 * @return
	 */
	public String getCategory_mei3() {
		return this.category_mei3;
	}

	/**
	 * @return
	 */
	public String getCategory_mei4() {
		return this.category_mei4;
	}

	/**
	 * @return
	 */
	public String getCategory_mei5() {
		return this.category_mei5;
	}

	/**
	 * @return
	 */
	public String getChiku_code() {
		return this.chiku_code;
	}

	/**
	 * @return
	 */
	public String getChiku_mei() {
		return this.chiku_mei;
	}

	/**
	 * @return
	 */
	public String getClass_code() {
		return this.class_code;
	}

	/**
	 * @return
	 */
	public String getClass_mei() {
		return this.class_mei;
	}

	/**
	 * @return
	 */
	public String getFollow_mail_kubun() {
		return this.follow_mail_kubun;
	}

	/**
	 * @return
	 */
	public String getFollow_mail_nissuu1() {
		return this.follow_mail_nissuu1;
	}

	/**
	 * @return
	 */
	public String getFollow_mail_nissuu2() {
		return this.follow_mail_nissuu2;
	}

	/**
	 * @return
	 */
	public String getHantei_kubun() {
		return this.hantei_kubun;
	}

	/**
	 * @return
	 */
	public String getHoukoku_kubun() {
		return this.houkoku_kubun;
	}

	/**
	 * @return
	 */
	public String getJyukou_jyoken() {
		return this.jyukou_jyoken;
	}

	/**
	 * @return
	 */
	public String getJyukou_kigen() {
		return this.jyukou_kigen;
	}

	/**
	 * @return
	 */
	public String getKaisai_jyotai() {
		return this.kaisai_jyotai;
	}

	/**
	 * @return
	 */
	public String getKaisai_saisyo_ninzuu() {
		return this.kaisai_saisyo_ninzuu;
	}

	/**
	 * @return
	 */
	public String getKaisaijikan() {
		return this.kaisaijikan;
	}

	/**
	 * @return
	 */
	public String getKaisibi() {
		return this.kaisibi;
	}

	/**
	 * @return
	 */
	public String getKaisijikoku() {
		return this.kaisijikoku;
	}

	/**
	 * @return
	 */
	public String getKamoku_code() {
		return this.kamoku_code;
	}

	/**
	 * @return
	 */
	public String getKamoku_group() {
		return this.kamoku_group;
	}

	/**
	 * @return
	 */
	public String getKamoku_group_mei() {
		return this.kamoku_group_mei;
	}

	/**
	 * @return
	 */
	public String getKamoku_mei1() {
		return this.kamoku_mei1;
	}

	/**
	 * @return
	 */
	public String getKamoku_mei2() {
		return this.kamoku_mei2;
	}

	/**
	 * @return
	 */
	public String getKamoku_mei3() {
		return this.kamoku_mei3;
	}

	/**
	 * @return
	 */
	public String getKamoku_mei4() {
		return this.kamoku_mei4;
	}

	/**
	 * @return
	 */
	public String getKamoku_naiyou() {
		return this.kamoku_naiyou;
	}

	/**
	 * @return
	 */
	public String getKanrimoto_code() {
		return this.kanrimoto_code;
	}

	/**
	 * @return
	 */
	public String getKanrimoto_mei() {
		return this.kanrimoto_mei;
	}

	/**
	 * @return
	 */
	public String getKisyo_ikkatsu_flg() {
		return this.kisyo_ikkatsu_flg;
	}

	/**
	 * @return
	 */
	public String getKousi_code() {
		return this.kousi_code;
	}

	/**
	 * @return
	 */
	public String getKousi_mei() {
		return this.kousi_mei;
	}

	/**
	 * @return
	 */
	public String getKyositu_code() {
		return this.kyositu_code;
	}

	/**
	 * @return
	 */
	public String getKyositu_mei() {
		return this.kyositu_mei;
	}

	/**
	 * @return
	 */
	public String getMousikomi_kaisibi() {
		return this.mousikomi_kaisibi;
	}

	/**
	 * @return
	 */
	public String getMousikomi_kubun() {
		return this.mousikomi_kubun;
	}

	/**
	 * @return
	 */
	public String getMousikomi_syuryobi() {
		return this.mousikomi_syuryobi;
	}

	/**
	 * @return
	 */
	public String getMousikomibi() {
		return this.mousikomibi;
	}

	/**
	 * @return
	 */
	public String getMousikomijikoku() {
		return this.mousikomijikoku;
	}

	/**
	 * @return
	 */
	public String getMousikomisya() {
		return this.mousikomisya;
	}

	/**
	 * @return
	 */
	public String getNinsyo_kubun() {
		return this.ninsyo_kubun;
	}

	/**
	 * @return
	 */
	public String getNissuu() {
		return this.nissuu;
	}

	/**
	 * @return
	 */
	public String getSimei_no() {
		return this.simei_no;
	}

	/**
	 * @return
	 */
	public String getSyonin_kubun() {
		return this.syonin_kubun;
	}

	/**
	 * @return
	 */
	public String getSyoninbi1() {
		return this.syoninbi1;
	}

	/**
	 * @return
	 */
	public String getSyoninbi2() {
		return this.syoninbi2;
	}

	/**
	 * @return
	 */
	public String getSyoninjikoku1() {
		return this.syoninjikoku1;
	}

	/**
	 * @return
	 */
	public String getSyoninjikoku2() {
		return this.syoninjikoku2;
	}

	/**
	 * @return
	 */
	public String getSyoninsya1() {
		return this.syoninsya1;
	}

	/**
	 * @return
	 */
	public String getSyoninsya2() {
		return this.syoninsya2;
	}

	/**
	 * @return
	 */
	public String getSyoriflg() {
		return this.syori_flg;
	}

	/**
	 * @return
	 */
	public String getSyoribi() {
		return this.syoribi;
	}

	/**
	 * @return
	 */
	public String getSyorijikoku() {
		return this.syorijikoku;
	}

	/**
	 * @return
	 */
	public String getSyorisya() {
		return this.syorisya;
	}

	/**
	 * @return
	 */
	public String getSyuryobi() {
		return this.syuryobi;
	}

	/**
	 * @return
	 */
	public String getSyuryojikoku() {
		return this.syuryojikoku;
	}

	/**
	 * @return
	 */
	public String getTaisyo_kubun() {
		return this.taisyo_kubun;
	}

	/**
	 * @return
	 */
	public String getTanka() {
		return this.tanka;
	}

	/**
	 * @return
	 */
	public String getTeiin() {
		return this.teiin;
	}

	/**
	 * @return
	 */
	public String getUketuke_kubun() {
		return this.uketuke_kubun;
	}

	/**
	 * @return
	 */
	public String getUketukebi() {
		return this.uketukebi;
	}

	/**
	 * @return
	 */
	public String getUketukejikoku() {
		return this.uketukejikoku;
	}

	/**
	 * @return
	 */
	public String getUketukesya() {
		return this.uketukesya;
	}

	/**
	 * @return
	 */
	public String getVersion_kanri() {
		return this.version_kanri;
	}

	/**
	 * @return
	 */
	public String getYobi1() {
		return this.yobi1;
	}

	/**
	 * @return
	 */
	public String getYobi2() {
		return this.yobi2;
	}

	/**
	 * @return
	 */
	public String getZensya_taisyo_flg() {
		return this.zensya_taisyo_flg;
	}

	/**
	 * @param string
	 */
	public void setAnnai_mail_kubun(final String string) {
		if (string == null) {
			this.annai_mail_kubun = "";
		} else {
			this.annai_mail_kubun = string;
		}
	}

	/**
	 * @param string
	 */
	public void setBikou(final String string) {
		if (string == null) {
			this.bikou = "";
		} else {
			this.bikou = string;
		}
	}

	/**
	 * @param string
	 */
	public void setCategory_code1(final String string) {
		if (string == null) {
			this.category_code1 = "";
		} else {
			this.category_code1 = string;
		}
	}

	/**
	 * @param string
	 */
	public void setCategory_code2(final String string) {
		if (string == null) {
			this.category_code2 = "";
		} else {
			this.category_code2 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setCategory_code3(final String string) {
		if (string == null) {
			this.category_code3 = "";
		} else {
			this.category_code3 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setCategory_code4(final String string) {
		if (string == null) {
			this.category_code4 = "";
		} else {
			this.category_code4 = string;
		}
	}

	/**
	 * @param string
	 */
	public void setCategory_code5(final String string) {
		if (string == null) {
			this.category_code5 = "";
		} else {
			this.category_code5 = string;
		}
	}

	/**
	 * @param string
	 */
	public void setCategory_mei1(final String string) {
		if (string == null) {
			this.category_mei1 = "";
		} else {
			this.category_mei1 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setCategory_mei2(final String string) {
		if (string == null) {
			this.category_mei2 = "";
		} else {
			this.category_mei2 = string;
		}
	}

	/**
	 * @param string
	 */
	public void setCategory_mei3(final String string) {
		if (string == null) {
			this.category_mei3 = "";
		} else {
			this.category_mei3 = string;
		}
	}

	/**
	 * @param string
	 */
	public void setCategory_mei4(final String string) {
		if (string == null) {
			this.category_mei4 = "";
		} else {
			this.category_mei4 = string;
		}
	}

	/**
	 * @param string
	 */
	public void setCategory_mei5(final String string) {
		if (string == null) {
			this.category_mei5 = "";
		} else {
			this.category_mei5 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setChiku_code(final String string) {
		if (string == null) {
			this.chiku_code = "";
		} else {
			this.chiku_code = string;
		}

	}

	/**
	 * @param string
	 */
	public void setChiku_mei(final String string) {
		if (string == null) {
			this.chiku_mei = "";
		} else {
			this.chiku_mei = string;
		}

	}

	/**
	 * @param string
	 */
	public void setClass_code(final String string) {
		if (string == null) {
			this.class_code = "";
		} else {
			this.class_code = string;
		}
	}

	/**
	 * @param string
	 */
	public void setClass_mei(final String string) {
		if (string == null) {
			this.class_mei = "";
		} else {
			this.class_mei = string;
		}

	}

	/**
	 * @param string
	 */
	public void setFollow_mail_kubun(final String string) {
		if (string == null) {
			this.follow_mail_kubun = "";
		} else {
			this.follow_mail_kubun = string;
		}

	}

	/**
	 * @param string
	 */
	public void setFollow_mail_nissuu1(final String string) {
		if (string == null) {
			this.follow_mail_nissuu1 = "";
		} else {
			this.follow_mail_nissuu1 = string;
		}
	}

	/**
	 * @param string
	 */
	public void setFollow_mail_nissuu2(final String string) {
		if (string == null) {
			this.follow_mail_nissuu2 = "";
		} else {
			this.follow_mail_nissuu2 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setHantei_kubun(final String string) {
		if (string == null) {
			this.hantei_kubun = "";
		} else {
			this.hantei_kubun = string;
		}

	}

	/**
	 * @param string
	 */
	public void setHoukoku_kubun(final String string) {
		if (string == null) {
			this.houkoku_kubun = "";
		} else {
			this.houkoku_kubun = string;
		}

	}

	/**
	 * @param string
	 */
	public void setJyukou_jyoken(final String string) {
		if (string == null) {
			this.jyukou_jyoken = "";
		} else {
			this.jyukou_jyoken = string;
		}

	}

	/**
	 * @param string
	 */
	public void setJyukou_kigen(final String string) {
		if (string == null) {
			this.jyukou_kigen = "";
		} else {
			this.jyukou_kigen = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKaisai_jyotai(final String string) {
		if (string == null) {
			this.kaisai_jyotai = "";
		} else {
			this.kaisai_jyotai = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKaisai_saisyo_ninzuu(final String string) {
		if (string == null) {
			this.kaisai_saisyo_ninzuu = "";
		} else {
			this.kaisai_saisyo_ninzuu = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKaisaijikan(final String string) {
		if (string == null) {
			this.kaisaijikan = "";
		} else {
			this.kaisaijikan = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKaisibi(final String string) {
		if (string == null) {
			this.kaisibi = "";
		} else {
			this.kaisibi = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKaisijikoku(final String string) {
		if (string == null) {
			this.kaisijikoku = "";
		} else {
			this.kaisijikoku = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKamoku_code(final String string) {
		if (string == null) {
			this.kamoku_code = "";
		} else {
			this.kamoku_code = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKamoku_group(final String string) {
		if (string == null) {
			this.kamoku_group = "";
		} else {
			this.kamoku_group = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKamoku_group_mei(final String string) {
		if (string == null) {
			this.kamoku_group_mei = "";
		} else {
			this.kamoku_group_mei = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKamoku_mei1(final String string) {
		if (string == null) {
			this.kamoku_mei1 = "";
		} else {
			this.kamoku_mei1 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKamoku_mei2(final String string) {
		if (string == null) {
			this.kamoku_mei2 = "";
		} else {
			this.kamoku_mei2 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKamoku_mei3(final String string) {
		if (string == null) {
			this.kamoku_mei3 = "";
		} else {
			this.kamoku_mei3 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKamoku_mei4(final String string) {
		if (string == null) {
			this.kamoku_mei4 = "";
		} else {
			this.kamoku_mei4 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKamoku_naiyou(final String string) {
		if (string == null) {
			this.kamoku_naiyou = "";
		} else {
			this.kamoku_naiyou = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKanrimoto_code(final String string) {
		if (string == null) {
			this.kanrimoto_code = "";
		} else {
			this.kanrimoto_code = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKanrimoto_mei(final String string) {
		if (string == null) {
			this.kanrimoto_mei = "";
		} else {
			this.kanrimoto_mei = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKisyo_ikkatsu_flg(final String string) {
		if (string == null) {
			this.kisyo_ikkatsu_flg = "";
		} else {
			this.kisyo_ikkatsu_flg = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKousi_code(final String string) {
		if (string == null) {
			this.kousi_code = "";
		} else {
			this.kousi_code = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKousi_mei(final String string) {
		if (string == null) {
			this.kousi_mei = "";
		} else {
			this.kousi_mei = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKyositu_code(final String string) {
		if (string == null) {
			this.kyositu_code = "";
		} else {
			this.kyositu_code = string;
		}

	}

	/**
	 * @param string
	 */
	public void setKyositu_mei(final String string) {
		if (string == null) {
			this.kyositu_mei = "";
		} else {
			this.kyositu_mei = string;
		}

	}

	/**
	 * @param string
	 */
	public void setMousikomi_kaisibi(final String string) {
		if (string == null) {
			this.mousikomi_kaisibi = "";
		} else {

			this.mousikomi_kaisibi = string;
		}

	}

	/**
	 * @param string
	 */
	public void setMousikomi_kubun(final String string) {
		if (string == null) {
			this.mousikomi_kubun = "";
		} else {
			this.mousikomi_kubun = string;
		}

	}

	/**
	 * @param string
	 */
	public void setMousikomi_syuryobi(final String string) {
		if (string == null) {
			this.mousikomi_syuryobi = "";
		} else {

			this.mousikomi_syuryobi = string;
		}

	}

	/**
	 * @param string
	 */
	public void setMousikomibi(final String string) {
		if (string == null) {
			this.mousikomibi = "";
		} else {
			this.mousikomibi = string;
		}

	}

	/**
	 * @param string
	 */
	public void setMousikomijikoku(final String string) {
		if (string == null) {
			this.mousikomijikoku = "";
		} else {
			this.mousikomijikoku = string;
		}

	}

	/**
	 * @param string
	 */
	public void setMousikomisya(final String string) {
		if (string == null) {
			this.mousikomisya = "";
		} else {
			this.mousikomisya = string;

		}

	}

	/**
	 * @param string
	 */
	public void setNinsyo_kubun(final String string) {
		if (string == null) {
			this.ninsyo_kubun = "";
		} else {
			this.ninsyo_kubun = string;
		}

	}

	/**
	 * @param string
	 */
	public void setNissuu(final String string) {
		if (string == null) {
			this.nissuu = "";
		} else {
			this.nissuu = string;
		}

	}

	/**
	 * @param string
	 */
	public void setSimei_no(final String string) {
		if (string == null) {
			this.simei_no = "";
		} else {
			this.simei_no = string;
		}

	}

	/**
	 * @param string
	 */
	public void setSyonin_kubun(final String string) {
		if (string == null) {
			this.syonin_kubun = "";
		} else {
			this.syonin_kubun = string;
		}

	}

	/**
	 * @param string
	 */
	public void setSyoninbi1(final String string) {
		if (string == null) {
			this.syoninbi1 = "";
		} else {
			this.syoninbi1 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setSyoninbi2(final String string) {
		if (string == null) {
			this.syoninbi2 = "";
		} else {
			this.syoninbi2 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setSyoninjikoku1(final String string) {
		if (string == null) {
			this.syoninjikoku1 = "";
		} else {
			this.syoninjikoku1 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setSyoninjikoku2(final String string) {
		if (string == null) {
			this.syoninjikoku2 = "";
		} else {
			this.syoninjikoku2 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setSyoninsya1(final String string) {
		if (string == null) {
			this.syoninsya1 = "";
		} else {
			this.syoninsya1 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setSyoninsya2(final String string) {
		if (string == null) {
			this.syoninsya2 = "";
		} else {
			this.syoninsya2 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setSyoriflg(final String string) {
		if (string == null) {
			this.syori_flg = "";
		} else {
			this.syori_flg = string;
		}

	}

	/**
	 * @param string
	 */
	public void setSyoribi(final String string) {
		if (string == null) {
			this.syoribi = "";
		} else {
			this.syoribi = string;
		}

	}

	/**
	 * @param string
	 */
	public void setSyorijikoku(final String string) {
		if (string == null) {
			this.syorijikoku = "";
		} else {
			this.syorijikoku = string;
		}
	}

	/**
	 * @param string
	 */
	public void setSyorisya(final String string) {
		if (string == null) {
			this.syorisya = "";
		} else {
			this.syorisya = string;
		}
	}

	/**
	 * @param string
	 */
	public void setSyuryobi(final String string) {
		if (string == null) {
			this.syuryobi = "";
		} else {
			this.syuryobi = string;
		}
	}

	/**
	 * @param string
	 */
	public void setSyuryojikoku(final String string) {
		if (string == null) {
			this.syuryojikoku = "";
		} else {
			this.syuryojikoku = string;
		}
	}

	/**
	 * @param string
	 */
	public void setTaisyo_kubun(final String string) {
		if (string == null) {
			this.taisyo_kubun = "";
		} else {
			this.taisyo_kubun = string;
		}
	}

	/**
	 * @param string
	 */
	public void setTanka(final String string) {
		if (string == null) {
			this.tanka = "";
		} else {
			this.tanka = string;
		}

	}

	/**
	 * @param string
	 */
	public void setTeiin(final String string) {
		if (string == null) {
			this.teiin = "";
		} else {
			this.teiin = string;
		}
	}

	/**
	 * @param string
	 */
	public void setUketuke_kubun(final String string) {
		if (string == null) {
			this.uketuke_kubun = "";
		} else {
			this.uketuke_kubun = string;
		}
	}

	/**
	 * @param string
	 */
	public void setUketukebi(final String string) {
		if (string == null) {
			this.uketukebi = "";
		} else {
			this.uketukebi = string;
		}
	}

	/**
	 * @param string
	 */
	public void setUketukejikoku(final String string) {
		if (string == null) {
			this.uketukejikoku = "";
		} else {
			this.uketukejikoku = string;
		}

	}

	/**
	 * @param string
	 */
	public void setUketukesya(final String string) {
		if (string == null) {
			this.uketukesya = "";
		} else {
			this.uketukesya = string;
		}
	}

	/**
	 * @param string
	 */
	public void setVersion_kanri(final String string) {
		if (string == null) {
			this.version_kanri = "";
		} else {
			this.version_kanri = string;
		}
	}

	/**
	 * @param string
	 */
	public void setYobi1(final String string) {
		if (string == null) {
			this.yobi1 = "";
		} else {
			this.yobi1 = string;
		}

	}

	/**
	 * @param string
	 */
	public void setYobi2(final String string) {
		if (string == null) {
			this.yobi2 = "";
		} else {
			this.yobi2 = string;
		}
	}

	/**
	 * @param string
	 */
	public void setZensya_taisyo_flg(final String string) {
		if (string == null) {
			this.zensya_taisyo_flg = "";
		} else {
			this.zensya_taisyo_flg = string;
		}
	}

}
