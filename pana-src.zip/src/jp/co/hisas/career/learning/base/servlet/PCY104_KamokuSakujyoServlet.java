/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY104_KamokuSakujyoServlet �N���X �@�\�����F �Ȗڍ폜���s���B
 * 
 * </PRE>
 */
public class PCY104_KamokuSakujyoServlet extends PCY010_ControllerServlet {
	/**
	 * ���N�G�X�g����v���C�}���L�[���擾���A�Ȗڏ����폜���܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		final PCY_KamokuEJBHome home = (PCY_KamokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KamokuEJBHome.class);
		final PCY_KamokuEJB ejb = home.create();

		try {
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doDelete(new PCY_KamokuBean[] { new PCY_KamokuBean(request) }, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");
		} catch (final PCY_WarningException e) {
			Log.error("", e);
			if (e.getMessage().equals("WCC010")) {
				request.setAttribute("warningID", "WCC010");
			} else if (e.getMessage().equals("WCC080")) {
				request.setAttribute("warningID", "WCC080");
				throw e;
			}
			throw e;
		}

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
