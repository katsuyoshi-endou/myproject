/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_OsiraseEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_OsiraseEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_OsiraseBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F ���m�点���T�[�u���b�g�N���X �@�\�����F ���m�点�e�[�u�����f�[�^���폜����
 * 
 * </PRE>
 */
public class PCX097_OsiraseSakujoServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		final PCY_OsiraseEJBHome home = (PCY_OsiraseEJBHome) EJBHomeFactory.getInstance().lookup(PCY_OsiraseEJBHome.class);
		final PCY_OsiraseEJB ejb = home.create();

		/* �폜�f�[�^���i�[���� */
		final String[] index = request.getParameterValues("H004_index");
		final PCY_OsiraseBean[] osiraseBeans = new PCY_OsiraseBean[index.length];

		for (int i = 0; i < index.length; i++) {
			final String seq = index[i];
			final PCY_OsiraseBean osiraseBean = new PCY_OsiraseBean();
			osiraseBean.setseqNo(request.getParameter("H001_seqNo_" + seq));
			osiraseBean.setKousinbi(request.getParameter("kousinbi_" + seq));
			osiraseBean.setKousinjikoku(request.getParameter("kousinjikoku_" + seq));

			osiraseBeans[i] = osiraseBean;
		}

		/* �f�[�^���폜���� */

		try {
			final int count = ejb.doDelete(osiraseBeans, loginuser);
		} catch (final PCY_WarningException e) {
			request.setAttribute("warningID", "WCX080");
			throw e;
		}

		request.setAttribute("osiraseBeans", osiraseBeans);

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();
	}
}
