/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PCY240_PersonalInfoServlet �N���X �@�\�����F �����ԍ������ɁA�p�[�\�i�������������܂��B
 * 
 * </PRE>
 */
public class PCY240_PersonalInfoServlet extends PCY010_ControllerServlet {
	/**
	 * �����ԍ������ɁA�p�[�\�i�������������܂��B �E�����ԍ�
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws Exception {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final String[] simeiNos = request.getParameterValues("simei_no");

		PCY_PersonalBean[] personalBeans = new PCY_PersonalBean[0];

		if (simeiNos != null && simeiNos.length > 0) {
			/* PersonalEJB */
			final PCY_PersonalEJBHome personal_home = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
			final PCY_PersonalEJB personal_ejb = personal_home.create();
			Log.transaction(loginuser.getSimeiNo(), true, "");

			personalBeans = personal_ejb.getPersonalInfo(simeiNos, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");
		}

		request.setAttribute("personalBeans", personalBeans);
		try {
			OutLogBean.sousaKojinJohoLog("VCB070", loginuser.getSimeiNo(), null, personalBeans[0].getSimeiNo() + "," + personalBeans[0].getKanjiSimei() + "," + personalBeans[0].getBusyoRyakusyoMei());
		} catch (final Exception e) {
		}
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
