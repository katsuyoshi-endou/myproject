/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.valuebean.PCY_EsNinsyoRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PCY_EsNinsyoRirekiEJBBean�N���X �@�\�����F ES�F�ؗ����ւ̑�����s���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="PCY_EsNinsyoRirekiEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_EsNinsyoRirekiEJBBean implements SessionBean {
	private SessionContext context = null;

	/**
	 * ES�F�ؗ������쐬���܂��B
	 * @param esNinsyoRirekiBeans �쐬���e
	 * @param loginuser ���O�C�����[�U
	 * @throws PCY_WarningException �C���T�[�g�� SQLException �����������ꍇ�A�y�я����������قȂ����ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public void doInsert(final PCY_EsNinsyoRirekiBean[] esNinsyoRirekiBeans, final PCY_PersonalBean loginuser) throws PCY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// SQL�쐬
			final StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO ");
			sql.append(HcdbDef.L92_TBL);
			sql.append(" (");
			sql.append("    SIMEI_NO,");
			sql.append("    KAMOKU_CODE,");
			sql.append("    CLASS_CODE,");
			sql.append("    NINSYOBI,");
			sql.append("    NINSYOJIKOKU,");
			sql.append("    HOUKOKU_KUBUN,");
			sql.append("    NINSYO_KEKKA,");
			sql.append("    JYUKOUBI,");
			sql.append("    HENKOURIYUU )");
			sql.append("  VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ? )");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �X�V���s
			ps = con.prepareStatement(sql.toString());

			int count = 0;

			for (int i = 0; i < esNinsyoRirekiBeans.length; i++) {
				ps.setString(1, loginuser.getSimeiNo());
				ps.setString(2, esNinsyoRirekiBeans[i].getKamokuCode());
				ps.setString(3, esNinsyoRirekiBeans[i].getClassCode());
				ps.setString(4, esNinsyoRirekiBeans[i].getNinsyobi());
				ps.setString(5, esNinsyoRirekiBeans[i].getNinsyojikoku());
				ps.setString(6, esNinsyoRirekiBeans[i].getHoukokuKubun());
				ps.setString(7, esNinsyoRirekiBeans[i].getNinsyoKekka());
				ps.setString(8, esNinsyoRirekiBeans[i].getJyukoubi());
				ps.setString(9, esNinsyoRirekiBeans[i].getHenkouriyuu());
				count += ps.executeUpdate();
			}

			if (count != esNinsyoRirekiBeans.length) {
				this.context.setRollbackOnly();
				throw new PCY_WarningException();
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
}
