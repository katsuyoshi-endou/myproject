/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.learning.base.bean.PCY_AccessLogBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PCY_AccessLogEJBBean�N���X �@�\�����F ���C�Ǘ��A�N�Z�X���O�̐ݒ���s���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="PCY_AccessLogEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_AccessLogEJBBean implements SessionBean {
	/**
	 * �A�N�Z�X���O���쐬���܂��B
	 * @param accesslogBean
	 * @param loginuser
	 * @return
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doInsert(final PCY_AccessLogBean accesslogBean, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			/* ���C�Ǘ���PCY010_ControllerServlet���Ă΂�Ă��Ȃ� */
			if (loginuser == null) {
				return 0;
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			if (!this.checkAccessLog(accesslogBean, loginuser)) {
				return 0;
			}

			// SQL�쐬
			final StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO ");
			sql.append(HcdbDef.L91_TBL);
			sql.append(" (");
			sql.append("       SESSION_ID,");
			sql.append("       LOGIN_JIKOKU,");
			sql.append("       LOGOUT_JIKOKU,");
			sql.append("       SIMEI_NO,");
			sql.append("       SOSIKI_CODE,");
			sql.append("       HONNIN_KENSYU_JYOHOU,");
			sql.append("       KENSYU_JYOHOU_TUIKA,");
			sql.append("       KENSYU_JYOHOU_KOUSIN,");
			sql.append("       KENSYU_JYOHOU_SAKUJYO,");
			sql.append("       KENSYU_KANRYOBI_KOUSIN,");
			sql.append("       KENSYU_SYOSAI,");
			sql.append("       JIKOSINKOKU_SYOSAI,");
			sql.append("       KENSYUSYA_CLASS_SYOSAI,");
			sql.append("       KENSYU_MOUSIKOMI,");
			sql.append("       MOUSIKOMI_TORIKESI,");
			sql.append("       JYUKOU_HOUKOKU,");
			sql.append("       ES_NINSYO,");
			sql.append("       REPORT_TEISYUTU,");
			sql.append("       SITUMON_NYURYOKU,");
			sql.append("       JIKOHYOKA_NYURYOKU,");
			sql.append("       JYUKOU_SINKOKU_NYURYOKU,");
			sql.append("       KAMOKU_ITIRAN,");
			sql.append("       SYONINSYA_KAKUNIN_HENKOU,");
			sql.append("       SYONINSYA_SENTAKU,");
			sql.append("       SYONINSYA_SETTEI,");
			sql.append("       SYONINSYA_SAKUJYO,");
			sql.append("       SYONIN,");
			sql.append("       SYONIN_SASIMODOSI,");
			sql.append("       KENSYUKANRI_JYOHOU,");
			sql.append("       KENSYUKANRI_CLASS_SYOSAI,");
			sql.append("       CLASS_CYOSEI,");
			sql.append("       UKETUKE,");
			sql.append("       UKETUKE_SASIMODOSI,");
			sql.append("       CLASS_CYUSI,");
			sql.append("       SEISEKI_NYURYOKU,");
			sql.append("       CLASS_SYURYO,");
			sql.append("       DAIKOU_NYURYOKU,");
			sql.append("       SITUMON_HYOJI,");
			sql.append("       CLASS_SAIKAI,");
			sql.append("       KAMOKU_TOUROKU,");
			sql.append("       KAMOKU_HENKOU,");
			sql.append("       KAMOKU_SAKUJYO,");
			sql.append("       KAMOKU_SENTAKU,");
			sql.append("       CLASS_TOUROKU,");
			sql.append("       CLASS_HENKOU,");
			sql.append("       CLASS_SAKUJYO,");
			sql.append("       CURRICULUM_MAP_TOUROKU,");
			sql.append("       TAISYO_BUMON_SETTEI,");
			sql.append("       TAISYO_SYOKUSYU_SETTEI,");
			sql.append("       TAISYOSYA_SETTEI,");
			sql.append("       TAISYOSYA_SETTEI_KENSAKUKEKKA,");
			sql.append("       JYUKOU_JYOKYO,");
			sql.append("       JYUKOU_FOLLOW,");
			sql.append("       NINTEI_TAISYOSYA_KENSAKU,");
			sql.append("       NINTEI_TAISYOSYA_ITIRAN,");
			sql.append("       JYUKOU_NINTEI_TOUROKU,");
			sql.append("       JYUKOU_NINTEI_KAIJYO )");
			sql.append("  VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ");
			sql.append("           ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ");
			sql.append("           ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ");
			sql.append("           ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ");
			sql.append("           ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ");
			sql.append("           ?, ?, ?, ?, ?, ?, ? ) ");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �f�o�b�O���O���o��
			Log.debug(sql.toString());

			// �X�V���s
			ps = con.prepareStatement(sql.toString());

			ps.setString(1, accesslogBean.getSessionId());
			ps.setString(2, accesslogBean.getLoginJikoku());
			ps.setString(3, accesslogBean.getLogoutJikoku());
			ps.setString(4, accesslogBean.getSimeiNo());
			ps.setString(5, accesslogBean.getSosikiCode());
			ps.setString(6, String.valueOf(accesslogBean.getHonninKensyuJyohou()));
			ps.setString(7, String.valueOf(accesslogBean.getKensyuJyohouTuika()));
			ps.setString(8, String.valueOf(accesslogBean.getKensyuJyohouKousin()));
			ps.setString(9, String.valueOf(accesslogBean.getKensyuJyohouSakujyo()));
			ps.setString(10, String.valueOf(accesslogBean.getKensyuKanryobiKousin()));
			ps.setString(11, String.valueOf(accesslogBean.getKensyuSyosai()));
			ps.setString(12, String.valueOf(accesslogBean.getJikosinkokuSyosai()));
			ps.setString(13, String.valueOf(accesslogBean.getKensyusyaClassSyosai()));
			ps.setString(14, String.valueOf(accesslogBean.getKensyuMousikomi()));
			ps.setString(15, String.valueOf(accesslogBean.getMousikomiTorikesi()));
			ps.setString(16, String.valueOf(accesslogBean.getJyukouHoukoku()));
			ps.setString(17, String.valueOf(accesslogBean.getEsNinsyo()));
			ps.setString(18, String.valueOf(accesslogBean.getReportTeisyutu()));
			ps.setString(19, String.valueOf(accesslogBean.getSitumonNyuryoku()));
			ps.setString(20, String.valueOf(accesslogBean.getJikohyokaNyuryoku()));
			ps.setString(21, String.valueOf(accesslogBean.getJyukouSinkokuNyuryoku()));
			ps.setString(22, String.valueOf(accesslogBean.getKamokuItiran()));
			ps.setString(23, String.valueOf(accesslogBean.getSyoninsyaKakuninHenkou()));
			ps.setString(24, String.valueOf(accesslogBean.getSyoninsyaSentaku()));
			ps.setString(25, String.valueOf(accesslogBean.getSyoninsyaSettei()));
			ps.setString(26, String.valueOf(accesslogBean.getSyoninsyaSakujyo()));
			ps.setString(27, String.valueOf(accesslogBean.getSyonin()));
			ps.setString(28, String.valueOf(accesslogBean.getSyoninSasimodosi()));
			ps.setString(29, String.valueOf(accesslogBean.getKensyukanriJyohou()));
			ps.setString(30, String.valueOf(accesslogBean.getKensyukanriClassSyosai()));
			ps.setString(31, String.valueOf(accesslogBean.getClassCyosei()));
			ps.setString(32, String.valueOf(accesslogBean.getUketuke()));
			ps.setString(33, String.valueOf(accesslogBean.getUketukeSasimodosi()));
			ps.setString(34, String.valueOf(accesslogBean.getClassCyusi()));
			ps.setString(35, String.valueOf(accesslogBean.getSeisekiNyuryoku()));
			ps.setString(36, String.valueOf(accesslogBean.getClassSyuryo()));
			ps.setString(37, String.valueOf(accesslogBean.getDaikouNyuryoku()));
			ps.setString(38, String.valueOf(accesslogBean.getSitumonHyoji()));
			ps.setString(39, String.valueOf(accesslogBean.getClassSaikai()));
			ps.setString(40, String.valueOf(accesslogBean.getKamokuTouroku()));
			ps.setString(41, String.valueOf(accesslogBean.getKamokuHenkou()));
			ps.setString(42, String.valueOf(accesslogBean.getKamokuSakujyo()));
			ps.setString(43, String.valueOf(accesslogBean.getKamokuSentaku()));
			ps.setString(44, String.valueOf(accesslogBean.getClassTouroku()));
			ps.setString(45, String.valueOf(accesslogBean.getClassHenkou()));
			ps.setString(46, String.valueOf(accesslogBean.getClassSakujyo()));
			ps.setString(47, String.valueOf(accesslogBean.getCurriculumMapTouroku()));
			ps.setString(48, String.valueOf(accesslogBean.getTaisyoBumonSettei()));
			ps.setString(49, String.valueOf(accesslogBean.getTaisyoSyokusyuSettei()));
			ps.setString(50, String.valueOf(accesslogBean.getTaisyosyaSettei()));
			ps.setString(51, String.valueOf(accesslogBean.getTaisyosyaSetteiKensakukekka()));
			ps.setString(52, String.valueOf(accesslogBean.getJyukouJyokyo()));
			ps.setString(53, String.valueOf(accesslogBean.getJyukouFollow()));
			ps.setString(54, String.valueOf(accesslogBean.getNinteiTaisyosyaKensaku()));
			ps.setString(55, String.valueOf(accesslogBean.getNinteiTaisyosyaItiran()));
			ps.setString(56, String.valueOf(accesslogBean.getJyukouNinteiTouroku()));
			ps.setString(57, String.valueOf(accesslogBean.getJyukouNinteiKaijyo()));

			final int count = ps.executeUpdate();

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * �A�N�Z�X���O�J�E���g�l��S�ă`�F�b�N����
	 * @param accesslog
	 * @param loginuser
	 * @return true �J�E���g��0�łȂ����̂�����B false �S�ẴJ�E���g��0�ł���B
	 */
	private boolean checkAccessLog(final PCY_AccessLogBean accesslogBean, final PCY_PersonalBean loginuser) {
		boolean flg = false;

		if (accesslogBean.getHonninKensyuJyohou() != 0) {
			if (accesslogBean.getHonninKensyuJyohou() > 999) {
				accesslogBean.setHonninKensyuJyohou(999);
			}

			flg = true;
		}

		if (accesslogBean.getKensyuJyohouTuika() != 0) {
			if (accesslogBean.getKensyuJyohouTuika() > 999) {
				accesslogBean.setKensyuJyohouTuika(999);
			}

			flg = true;
		}

		if (accesslogBean.getKensyuJyohouKousin() != 0) {
			if (accesslogBean.getKensyuJyohouKousin() > 999) {
				accesslogBean.setKensyuJyohouKousin(999);
			}

			flg = true;
		}

		if (accesslogBean.getKensyuJyohouSakujyo() != 0) {
			if (accesslogBean.getKensyuJyohouSakujyo() > 999) {
				accesslogBean.setKensyuJyohouSakujyo(999);
			}

			flg = true;
		}

		if (accesslogBean.getKensyuKanryobiKousin() != 0) {
			if (accesslogBean.getKensyuKanryobiKousin() > 999) {
				accesslogBean.setKensyuKanryobiKousin(999);
			}

			flg = true;
		}

		if (accesslogBean.getKensyuSyosai() != 0) {
			if (accesslogBean.getKensyuSyosai() > 999) {
				accesslogBean.setKensyuSyosai(999);
			}

			flg = true;
		}

		if (accesslogBean.getJikosinkokuSyosai() != 0) {
			if (accesslogBean.getJikosinkokuSyosai() > 999) {
				accesslogBean.setJikosinkokuSyosai(999);
			}

			flg = true;
		}

		if (accesslogBean.getKensyusyaClassSyosai() != 0) {
			if (accesslogBean.getKensyusyaClassSyosai() > 999) {
				accesslogBean.setKensyusyaClassSyosai(999);
			}

			flg = true;
		}

		if (accesslogBean.getKensyuMousikomi() != 0) {
			if (accesslogBean.getKensyuMousikomi() > 999) {
				accesslogBean.setKensyuMousikomi(999);
			}

			flg = true;
		}

		if (accesslogBean.getMousikomiTorikesi() != 0) {
			if (accesslogBean.getMousikomiTorikesi() > 999) {
				accesslogBean.setMousikomiTorikesi(999);
			}

			flg = true;
		}

		if (accesslogBean.getJyukouHoukoku() != 0) {
			if (accesslogBean.getJyukouHoukoku() > 999) {
				accesslogBean.setJyukouHoukoku(999);
			}

			flg = true;
		}

		if (accesslogBean.getEsNinsyo() != 0) {
			if (accesslogBean.getEsNinsyo() > 999) {
				accesslogBean.setEsNinsyo(999);
			}

			flg = true;
		}

		if (accesslogBean.getReportTeisyutu() != 0) {
			if (accesslogBean.getReportTeisyutu() > 999) {
				accesslogBean.setReportTeisyutu(999);
			}

			flg = true;
		}

		if (accesslogBean.getSitumonNyuryoku() != 0) {
			if (accesslogBean.getSitumonNyuryoku() > 999) {
				accesslogBean.setSitumonNyuryoku(999);
			}

			flg = true;
		}

		if (accesslogBean.getJikohyokaNyuryoku() != 0) {
			if (accesslogBean.getJikohyokaNyuryoku() > 999) {
				accesslogBean.setJikohyokaNyuryoku(999);
			}

			flg = true;
		}

		if (accesslogBean.getJyukouSinkokuNyuryoku() != 0) {
			if (accesslogBean.getJyukouSinkokuNyuryoku() > 999) {
				accesslogBean.setJyukouSinkokuNyuryoku(999);
			}

			flg = true;
		}

		if (accesslogBean.getKamokuItiran() != 0) {
			if (accesslogBean.getKamokuItiran() > 999) {
				accesslogBean.setKamokuItiran(999);
			}

			flg = true;
		}

		if (accesslogBean.getSyoninsyaKakuninHenkou() != 0) {
			if (accesslogBean.getSyoninsyaKakuninHenkou() > 999) {
				accesslogBean.setSyoninsyaKakuninHenkou(999);
			}

			flg = true;
		}

		if (accesslogBean.getSyoninsyaSentaku() != 0) {
			if (accesslogBean.getSyoninsyaSentaku() > 999) {
				accesslogBean.setSyoninsyaSentaku(999);
			}

			flg = true;
		}

		if (accesslogBean.getSyoninsyaSettei() != 0) {
			if (accesslogBean.getSyoninsyaSettei() > 999) {
				accesslogBean.setSyoninsyaSettei(999);
			}

			flg = true;
		}

		if (accesslogBean.getSyoninsyaSakujyo() != 0) {
			if (accesslogBean.getSyoninsyaSakujyo() > 999) {
				accesslogBean.setSyoninsyaSakujyo(999);
			}

			flg = true;
		}

		if (accesslogBean.getSyonin() != 0) {
			if (accesslogBean.getSyonin() > 999) {
				accesslogBean.setSyonin(999);
			}

			flg = true;
		}

		if (accesslogBean.getSyoninSasimodosi() != 0) {
			if (accesslogBean.getSyoninSasimodosi() > 999) {
				accesslogBean.setSyoninSasimodosi(999);
			}

			flg = true;
		}

		if (accesslogBean.getKensyukanriJyohou() != 0) {
			if (accesslogBean.getKensyukanriJyohou() > 999) {
				accesslogBean.setKensyukanriJyohou(999);
			}

			flg = true;
		}

		if (accesslogBean.getKensyukanriClassSyosai() != 0) {
			if (accesslogBean.getKensyukanriClassSyosai() > 999) {
				accesslogBean.setKensyukanriClassSyosai(999);
			}

			flg = true;
		}

		if (accesslogBean.getClassCyosei() != 0) {
			if (accesslogBean.getClassCyosei() > 999) {
				accesslogBean.setClassCyosei(999);
			}

			flg = true;
		}

		if (accesslogBean.getUketuke() != 0) {
			if (accesslogBean.getUketuke() > 999) {
				accesslogBean.setUketuke(999);
			}

			flg = true;
		}

		if (accesslogBean.getUketukeSasimodosi() != 0) {
			if (accesslogBean.getUketukeSasimodosi() > 999) {
				accesslogBean.setUketukeSasimodosi(999);
			}

			flg = true;
		}

		if (accesslogBean.getClassCyusi() != 0) {
			if (accesslogBean.getClassCyusi() > 999) {
				accesslogBean.setClassCyusi(999);
			}

			flg = true;
		}

		if (accesslogBean.getSeisekiNyuryoku() != 0) {
			if (accesslogBean.getSeisekiNyuryoku() > 999) {
				accesslogBean.setSeisekiNyuryoku(999);
			}

			flg = true;
		}

		if (accesslogBean.getClassSyuryo() != 0) {
			if (accesslogBean.getClassSyuryo() > 999) {
				accesslogBean.setClassSyuryo(999);
			}

			flg = true;
		}

		if (accesslogBean.getDaikouNyuryoku() != 0) {
			if (accesslogBean.getDaikouNyuryoku() > 999) {
				accesslogBean.setDaikouNyuryoku(999);
			}

			flg = true;
		}

		if (accesslogBean.getSitumonHyoji() != 0) {
			if (accesslogBean.getSitumonHyoji() > 999) {
				accesslogBean.setSitumonHyoji(999);
			}

			flg = true;
		}

		if (accesslogBean.getClassSaikai() != 0) {
			if (accesslogBean.getClassSaikai() > 999) {
				accesslogBean.setClassSaikai(999);
			}

			flg = true;
		}

		if (accesslogBean.getKamokuTouroku() != 0) {
			if (accesslogBean.getKamokuTouroku() > 999) {
				accesslogBean.setKamokuTouroku(999);
			}

			flg = true;
		}

		if (accesslogBean.getKamokuHenkou() != 0) {
			if (accesslogBean.getKamokuHenkou() > 999) {
				accesslogBean.setKamokuHenkou(999);
			}

			flg = true;
		}

		if (accesslogBean.getKamokuSakujyo() != 0) {
			if (accesslogBean.getKamokuSakujyo() > 999) {
				accesslogBean.setKamokuSakujyo(999);
			}

			flg = true;
		}

		if (accesslogBean.getKamokuSentaku() != 0) {
			if (accesslogBean.getKamokuSentaku() > 999) {
				accesslogBean.setKamokuSentaku(999);
			}

			flg = true;
		}

		if (accesslogBean.getClassTouroku() != 0) {
			if (accesslogBean.getClassTouroku() > 999) {
				accesslogBean.setClassTouroku(999);
			}

			flg = true;
		}

		if (accesslogBean.getClassHenkou() != 0) {
			if (accesslogBean.getClassHenkou() > 999) {
				accesslogBean.setClassHenkou(999);
			}

			flg = true;
		}

		if (accesslogBean.getClassSakujyo() != 0) {
			if (accesslogBean.getClassSakujyo() > 999) {
				accesslogBean.setClassSakujyo(999);
			}

			flg = true;
		}

		if (accesslogBean.getCurriculumMapTouroku() != 0) {
			if (accesslogBean.getCurriculumMapTouroku() > 999) {
				accesslogBean.setCurriculumMapTouroku(999);
			}

			flg = true;
		}

		if (accesslogBean.getTaisyoBumonSettei() != 0) {
			if (accesslogBean.getTaisyoBumonSettei() > 999) {
				accesslogBean.setTaisyoBumonSettei(999);
			}

			flg = true;
		}

		if (accesslogBean.getTaisyoSyokusyuSettei() != 0) {
			if (accesslogBean.getTaisyoSyokusyuSettei() > 999) {
				accesslogBean.setTaisyoSyokusyuSettei(999);
			}

			flg = true;
		}

		if (accesslogBean.getTaisyosyaSettei() != 0) {
			if (accesslogBean.getTaisyosyaSettei() > 999) {
				accesslogBean.setTaisyosyaSettei(999);
			}

			flg = true;
		}

		if (accesslogBean.getTaisyosyaSetteiKensakukekka() != 0) {
			if (accesslogBean.getTaisyosyaSetteiKensakukekka() > 999) {
				accesslogBean.setTaisyosyaSetteiKensakukekka(999);
			}

			flg = true;
		}

		if (accesslogBean.getJyukouJyokyo() != 0) {
			if (accesslogBean.getJyukouJyokyo() > 999) {
				accesslogBean.setJyukouJyokyo(999);
			}

			flg = true;
		}

		if (accesslogBean.getJyukouFollow() != 0) {
			if (accesslogBean.getJyukouFollow() > 999) {
				accesslogBean.setJyukouFollow(999);
			}

			flg = true;
		}

		if (accesslogBean.getNinteiTaisyosyaKensaku() != 0) {
			if (accesslogBean.getNinteiTaisyosyaKensaku() > 999) {
				accesslogBean.setNinteiTaisyosyaKensaku(999);
			}

			flg = true;
		}

		if (accesslogBean.getNinteiTaisyosyaItiran() != 0) {
			if (accesslogBean.getNinteiTaisyosyaItiran() > 999) {
				accesslogBean.setNinteiTaisyosyaItiran(999);
			}

			flg = true;
		}

		if (accesslogBean.getJyukouNinteiTouroku() != 0) {
			if (accesslogBean.getJyukouNinteiTouroku() > 999) {
				accesslogBean.setJyukouNinteiTouroku(999);
			}

			flg = true;
		}

		if (accesslogBean.getJyukouNinteiKaijyo() != 0) {
			if (accesslogBean.getJyukouNinteiKaijyo() > 999) {
				accesslogBean.setJyukouNinteiKaijyo(999);
			}

			flg = true;
		}

		return flg;
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
}
