/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.mail.internet.AddressException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_KensyuMailSender;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F PCY141_SyoninServlet �N���X �@�\�����F ���F�������s���܂��B
 * 
 * </PRE>
 */
public class PCY141_SyoninServlet extends PCY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final String[] kamokuCode = request.getParameterValues("kamoku_code_array");
		final String[] classCode = request.getParameterValues("class_code_array");
		final String[] simeiNo = request.getParameterValues("simei_no_array");
		final String[] kousinbi = request.getParameterValues("kousinbi");
		final String[] kousinjikoku = request.getParameterValues("kousinjikoku");

		final PCY_ClassEJBHome homeClass = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB ejbClass = homeClass.create();

		final PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = new PCY_MousikomiJyokyoBean[kamokuCode.length];

// ADD 2018/07/03 COMTURE 4-1���F���[�����M�Ή� START
		final PCY_ClassBean[] kensakuClassBeans = new PCY_ClassBean[kamokuCode.length];
// ADD 2018/07/03 COMTURE 4-1���F���[�����M�Ή� END

		for (int i = 0; i < kamokuCode.length; i++) {
			PCY_ClassBean classBeanDummy = new PCY_ClassBean();
			classBeanDummy.getKamokuBean().setKamokuCode(kamokuCode[i]);
			classBeanDummy.setClassCode(classCode[i]);
			Log.transaction(loginuser.getSimeiNo(), true, "");
			PCY_ClassBean classBean = ejbClass.doSelectByPrimaryKey(classBeanDummy, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");

			PCY_MousikomiJyokyoBean mousikomiJyokyoBean = new PCY_MousikomiJyokyoBean();
			mousikomiJyokyoBean.setClassBean(classBean);
			mousikomiJyokyoBean.setKamokuCode(kamokuCode[i]);
			mousikomiJyokyoBean.setClassCode(classCode[i]);
			mousikomiJyokyoBean.setSimeiNo(simeiNo[i]);
			mousikomiJyokyoBean.setSyoninbi1(PZZ010_CharacterUtil.GetDay());
			mousikomiJyokyoBean.setSyoninjikoku1(PZZ010_CharacterUtil.GetTime());
			mousikomiJyokyoBean.setSyoninsya1(loginuser.getSimeiNo());
			mousikomiJyokyoBean.setKousinbi(kousinbi[i]);
			mousikomiJyokyoBean.setKousinjikoku(kousinjikoku[i]);
			/* ��t�敪��"�v"�̏ꍇ */
			if (classBean.getUketukeKubun().equals("1")) {
				mousikomiJyokyoBean.setStatus("1");
				mousikomiJyokyoBean.setUketsukeJyotai("0");
				/* �񍐋敪��"�v"�̏ꍇ */
			} else if (!classBean.getHoukokuKubun().equals("0")) {
				mousikomiJyokyoBean.setStatus("2");
				/* ����敪��"�v"�̏ꍇ */
			} else if (classBean.getHanteiKubun().equals("1")) {
				mousikomiJyokyoBean.setStatus("3");
			}
			mousikomiJyokyoBean.setKousinbi(kousinbi[i]);
			mousikomiJyokyoBean.setKousinjikoku(kousinjikoku[i]);
			mousikomiJyokyoBeans[i] = mousikomiJyokyoBean;

// ADD 2018/07/03 COMTURE 4-1���F���[�����M�Ή� START
			kensakuClassBeans[i] = classBean;
// ADD 2018/07/03 COMTURE 4-1���F���[�����M�Ή� END

			classBeanDummy = null;
			classBean = null;
			mousikomiJyokyoBean = null;
		}

		final PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_MousikomiJyokyoEJB ejb = home.create();

		Log.transaction(loginuser.getSimeiNo(), true, "");
		ejb.doUpdateStatus(mousikomiJyokyoBeans, loginuser, true);
		Log.transaction(loginuser.getSimeiNo(), false, "");

// ADD 2018/07/02 COMTURE 4-1���F���[�����M�Ή� START
		final PCY_PersonalEJBHome personal_home = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
		final PCY_PersonalEJB personal_ejb = personal_home.create();
		final PCY_PersonalBean[] personalBeans = personal_ejb.getPersonalInfo(simeiNo, loginuser);

		PCY_ClassBean[] classBeans = ejbClass.doSelectByPrimaryKey(kensakuClassBeans, loginuser);
// ADD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V START
        for (PCY_ClassBean c : classBeans) {
            Log.transaction(loginuser.getSimeiNo(), true, "");
            ejbClass.doUpdateMansekiFlg(c, loginuser);
            Log.transaction(loginuser.getSimeiNo(), false, "");
        }
// ADD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V END

		if (ReadFile.fileMapData.get("MAIL_XCB020").equals("1")){
			try {
				/* ���[���𑗐M���� */
				PCY_KensyuMailSender.sendSyoninsyaSyonin(personalBeans, classBeans,loginuser);

			} catch (final AddressException e) {
				request.setAttribute("warningID", "WCB120");
				throw new PCY_WarningException(e);
			} catch (final Exception e) {
				request.setAttribute("warningID", "WCB120");
				throw new PCY_WarningException(e);
			}
		}
// ADD 2018/07/02 COMTURE 4-1���F���[�����M�Ή� END

		/* ���\�b�h�g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

}
