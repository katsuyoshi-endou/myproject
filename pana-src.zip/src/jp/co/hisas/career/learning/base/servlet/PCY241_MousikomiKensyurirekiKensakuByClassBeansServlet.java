/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.bean.PCY_KensyuKanriJohoBean;
import jp.co.hisas.career.learning.base.ejb.PCY_KensyuRirekiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KensyuRirekiEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiSakujoRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.personal.kyoiku.bean.KyoikuValueBean;
import jp.co.hisas.career.personal.kyoiku.ejb.KyoikuEJB;
import jp.co.hisas.career.personal.kyoiku.ejb.KyoikuEJBHome;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F PCY241_MousikomiKensyurirekiKensakuByClassBeansServlet �N���X �@�\�����F �����ԍ��A�N���X�������ɁA�\���󋵂ƌ��C���������擾���܂��B
 * 
 * </PRE>
 */
public class PCY241_MousikomiKensyurirekiKensakuByClassBeansServlet extends PCY010_ControllerServlet {
	/**
	 * �����ԍ������ɁA�p�[�\�i�������������܂��B �E�����ԍ� �E�N���X���
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws Exception {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final String simeiNo = request.getParameter("simei_no");

		final PCY_ClassBean[] classBeans = (PCY_ClassBean[]) request.getAttribute("classBeans");

		final ArrayList kamokuNinteiList = new ArrayList();
		final ArrayList sakujoRirekiList = new ArrayList();
		final ArrayList kensyuRirekiList = new ArrayList();
		final ArrayList classList = new ArrayList();
		final ArrayList mousikomiList = new ArrayList();
// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� START
		final ArrayList<KyoikuValueBean> kyoikuList = new ArrayList<KyoikuValueBean>();
// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� EDN

		/* MousikomiEJB */
		final PCY_MousikomiJyokyoEJBHome mousikomi_home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_MousikomiJyokyoEJB mousikomi_ejb = mousikomi_home.create();

		/* KensyuRirekiEJB */
		final PCY_KensyuRirekiEJBHome kensyuRireki_home = (PCY_KensyuRirekiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KensyuRirekiEJBHome.class);
		final PCY_KensyuRirekiEJB kensyuRireki_ejb = kensyuRireki_home.create();

// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� START
		final KyoikuEJBHome kyoiku_home = (KyoikuEJBHome) EJBHomeFactory.getInstance().lookup(KyoikuEJBHome.class);
		final KyoikuEJB kyoiku_Ejb = kyoiku_home.create();
// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� END

		/* �\���󋵂ƌ��C���������� */
		for (int i = 0; i < classBeans.length; i++) {
			boolean saveClass = false;

			/* �\���󋵌������� */
			final PCY_MousikomiJyokyoBean kensakuMousikomiBean = new PCY_MousikomiJyokyoBean();
			kensakuMousikomiBean.setSimeiNo(simeiNo);
			kensakuMousikomiBean.setClassBean(classBeans[i]);

			/* �\���󋵌������s�� */
			Log.transaction(loginuser.getSimeiNo(), true, "");

			final PCY_MousikomiJyokyoBean[] kekka_mousikomiBeans = mousikomi_ejb.getList(kensakuMousikomiBean, loginuser);
			Log.performance(loginuser.getSimeiNo(), false, "");

			if (kekka_mousikomiBeans != null && kekka_mousikomiBeans.length != 0) {
				/* �\���󋵁A��u�󋵂�ݒ肷�� */
				final String st = kekka_mousikomiBeans[0].getStatus();
				final String uk = kekka_mousikomiBeans[0].getUketsukeJyotai();

				if (st.equals("0") && uk == null) {
					kekka_mousikomiBeans[0].setJyukoJyokyo("0");
					kekka_mousikomiBeans[0].setMousikomijyokyo("1");
				} else if (st.equals("1") && uk.equals("0")) {
					kekka_mousikomiBeans[0].setJyukoJyokyo("0");
					kekka_mousikomiBeans[0].setMousikomijyokyo("2");
				} else if (st.equals("1") && uk.equals("1")) {
					kekka_mousikomiBeans[0].setJyukoJyokyo("0");
					kekka_mousikomiBeans[0].setMousikomijyokyo("3");
				} else if (st.equals("1") && uk.equals("2")) {
					kekka_mousikomiBeans[0].setJyukoJyokyo("0");
					kekka_mousikomiBeans[0].setMousikomijyokyo("4");
				} else if (st.equals("1") && uk.equals("3")) {
					kekka_mousikomiBeans[0].setJyukoJyokyo("0");
					kekka_mousikomiBeans[0].setMousikomijyokyo("5");
				} else if (st.equals("1") && uk.equals("4")) {
					kekka_mousikomiBeans[0].setJyukoJyokyo("0");
					kekka_mousikomiBeans[0].setMousikomijyokyo("6");
				} else if (st.equals("2") && uk == null) {
					kekka_mousikomiBeans[0].setJyukoJyokyo("1");
					kekka_mousikomiBeans[0].setMousikomijyokyo("");
				} else if (st.equals("3") && uk == null) {
					kekka_mousikomiBeans[0].setJyukoJyokyo("2");
					kekka_mousikomiBeans[0].setMousikomijyokyo("");
				} else {
					kekka_mousikomiBeans[i].setJyukoJyokyo("");
					kekka_mousikomiBeans[i].setMousikomijyokyo("");
				}
				mousikomiList.add(kekka_mousikomiBeans[0]);
				kensyuRirekiList.add(null);
				classList.add(classBeans[i]);
// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� START
				kyoikuList.add(null);
// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� END
				saveClass = true;
			}

			/* ���C���̌������s�� */
			/* ���C���������� */
			final PCY_KensyuRirekiBean kensakuKensyuRirekiBean = new PCY_KensyuRirekiBean();
			kensakuKensyuRirekiBean.setSimeiNo(simeiNo);
			kensakuKensyuRirekiBean.setKamokuCode(classBeans[i].getKamokuBean().getKamokuCode());
			kensakuKensyuRirekiBean.setClassCode(classBeans[i].getClassCode());

			/* ���C���������s�� */
			Log.transaction(loginuser.getSimeiNo(), true, "");

			final PCY_KensyuRirekiBean[] kekka_kensyurekiBeans = kensyuRireki_ejb.getList(new PCY_KensyuRirekiBean[] { kensakuKensyuRirekiBean }, loginuser);

			Log.performance(loginuser.getSimeiNo(), false, "");

			if (kekka_kensyurekiBeans != null && kekka_kensyurekiBeans.length != 0) {
				for (int t = 0; t < kekka_kensyurekiBeans.length; t++) {
					kensyuRirekiList.add(kekka_kensyurekiBeans[t]);
					mousikomiList.add(null);
					classList.add(classBeans[i]);
// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� START
					kyoikuList.add(null);
// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� END
					saveClass = true;
				}
			}

// ADD 2018/12/20 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� START
			PCY_KensyuKanriJohoBean[] kekka_KyoikuKensyurekiBeans = null;
			
			// T05_���猤�C�����̎擾
			kekka_KyoikuKensyurekiBeans = kyoiku_Ejb.doSelectKyoikuKensyureki(simeiNo, classBeans[i].getKamokuBean().getKamokuCode(), classBeans[i].getKaisibi(), classBeans[i].getClassMei(), loginuser, classBeans[i].getClassCode());
			
			if (kekka_KyoikuKensyurekiBeans != null && kekka_KyoikuKensyurekiBeans.length != 0) {
				for (int t = 0; t < kekka_KyoikuKensyurekiBeans.length; t++) {
					
					kensyuRirekiList.add(null);
					mousikomiList.add(null);
					classList.add(classBeans[i]);
					kyoikuList.add(kekka_KyoikuKensyurekiBeans[t].getKyoikuValueBean());
					saveClass = true;
				}
			}
// ADD 2018/12/20 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� END

			/* �ȖڔF�茟�� */
			kensakuKensyuRirekiBean.setClassCode(null);
			final PCY_KensyuRirekiBean[] kekka_KamokukensyurekiBeans = kensyuRireki_ejb.getList(new PCY_KensyuRirekiBean[] { kensakuKensyuRirekiBean }, loginuser);

			if (kekka_KamokukensyurekiBeans != null && kekka_KamokukensyurekiBeans.length != 0) {
				for (int t = 0; t < kekka_KamokukensyurekiBeans.length; t++) {
					kamokuNinteiList.add(kekka_KamokukensyurekiBeans[t]);
				}
			}

			// INS#P-BPX-0301J-3008-005-S
			if ("1".equals(ReadFile.fileMapData.get("SAKUJYO_RIREKI"))) {
				/* �폜���������� */
				final String[] simei_No = { simeiNo };
				final PCY_KensyuKanriJohoBean[] kensyu = mousikomi_ejb.getListWithClassL94(classBeans[i].getKamokuBean().getKamokuCode(), classBeans[i].getClassCode(), classBeans[i], simei_No,
						loginuser);
				if (kensyu != null && kensyu.length != 0) {
					for (int t = 0; t < kensyu.length; t++) {
						if (kensyu[t].getSakujoRirekiBean() != null) {
							sakujoRirekiList.add(kensyu[t].getSakujoRirekiBean());
						}
					}
				}
			}
			// INS#P-BPX-0301J-3008-005-E
			if (saveClass == false) {
				mousikomiList.add(null);
				kensyuRirekiList.add(null);
				classList.add(classBeans[i]);
// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� START
				kyoikuList.add(null);
// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� END
			}
		}

		/* ���C�����������ʂ�Bean�� */
		PCY_KensyuRirekiBean[] kensyurirekiBeans = new PCY_KensyuRirekiBean[kensyuRirekiList.size()];
		kensyurirekiBeans = (PCY_KensyuRirekiBean[]) kensyuRirekiList.toArray(kensyurirekiBeans);

		/* �\���������ʂ�Bean�� */
		PCY_MousikomiJyokyoBean[] mousikomiBeans = new PCY_MousikomiJyokyoBean[mousikomiList.size()];
		mousikomiBeans = (PCY_MousikomiJyokyoBean[]) mousikomiList.toArray(mousikomiBeans);

		/* �ȖڔF�茟�����ʂ�Bean�� */
		PCY_KensyuRirekiBean[] kensyuKamokuRirekiBeans = new PCY_KensyuRirekiBean[kamokuNinteiList.size()];
		kensyuKamokuRirekiBeans = (PCY_KensyuRirekiBean[]) kamokuNinteiList.toArray(kensyuKamokuRirekiBeans);

// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� START
		/* ���C�����������ʁiT05�j��Bean�� */
		KyoikuValueBean[] kyoikuValueBeans = new KyoikuValueBean[kyoikuList.size()];
		kyoikuValueBeans = (KyoikuValueBean[]) kyoikuList.toArray(kyoikuValueBeans);
// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� END

		if ("1".equals(ReadFile.fileMapData.get("SAKUJYO_RIREKI"))) {
			/* �폜�����������ʂ�Bean�� */
			PCY_MousikomiSakujoRirekiBean[] sakujoRirekiBeans = new PCY_MousikomiSakujoRirekiBean[sakujoRirekiList.size()];
			sakujoRirekiBeans = (PCY_MousikomiSakujoRirekiBean[]) sakujoRirekiList.toArray(sakujoRirekiBeans);
			request.setAttribute("sakujoRirekiBeans", sakujoRirekiBeans);
		}

		/* class����Bean�� */
		PCY_ClassBean[] ret_classBeans = new PCY_ClassBean[classList.size()];
		ret_classBeans = (PCY_ClassBean[]) classList.toArray(ret_classBeans);

		/* ���ʂ��Z�b�g���� */
		request.setAttribute("mousikomiBeans", mousikomiBeans);
		request.setAttribute("rirekiBeans", kensyurirekiBeans);
		request.setAttribute("rirekiKamokuBeans", kensyuKamokuRirekiBeans);
		// DEL#BPX-0301J-0475
		request.setAttribute("classBeans", ret_classBeans);
// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� START
		request.setAttribute("kyoikuValueBeans", kyoikuValueBeans);
// ADD 2018/12/21 COMTURE ��u�F��o�^��ʂւ̎��уf�[�^�\�� END

		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
