/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_SyoninsyaBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ020_MakeSQLUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * �N���X���F PCY_PersonalEJBBean�N���X �@�\�����F �p�[�\�i���v���t�@�C�����烆�[�U�̑������擾���܂��B(���C�n)
 * @ejb.bean name="PCY_PersonalEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_PersonalEJBBean implements SessionBean {
	private SessionContext context = null;

	/**
	 * �p�[�\�i���v���t�@�C�����烆�[�U�����擾���APCY_PersonalBean �Ɋi�[���ĕԂ��܂��B
	 * @param userId ����NO
	 * @param loginuser ���O�C�����[�U���
	 * @return ���[�U���
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_PersonalBean getPersonalInfo(final String userId, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");
			// SQL�ݒ�
			ps = con.prepareStatement("SELECT * FROM " + HcdbDef.personalTbl + " WHERE SIMEI_NO=? and HONMU_FLG='" + HcdbDef.HONMU + "' ");

			// �p�����[�^�ݒ�
			ps.setString(1, userId);
			// SQL���s
			rs = ps.executeQuery();
			PCY_PersonalBean personal = null;

			while (rs.next()) {
				personal = new PCY_PersonalBean(rs, null);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return personal;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * �p�[�\�i���v���t�@�C�����烆�[�U�����擾���APCY_PersonalBean �Ɋi�[���ĕԂ��܂��B
	 * @param userId ����NO
	 * @param loginuser ���O�C�����[�U���
	 * @return ���[�U���
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_PersonalBean[] getPersonalInfo(final String[] userId, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			PCY_PersonalBean[] personalBeans = null;

			if (userId != null && userId.length != 0) {
				// �R�l�N�V�����擾
				con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

				final StringBuffer sql = new StringBuffer("SELECT * FROM " + HcdbDef.personalTbl);
				sql.append(" WHERE SIMEI_NO=?  AND HONMU_FLG='" + HcdbDef.HONMU + "' ");

				/* �f�o�b�O���O�̏o�� */
				Log.debug(sql.toString());

				// SQL�ݒ�
				ps = con.prepareStatement(sql.toString());

				final List personalBeanList = new ArrayList();

				for (int i = 0; i < userId.length; i++) {
					// �p�����[�^�ݒ�
					ps.setString(1, userId[i]);
					// SQL���s
					rs = ps.executeQuery();

					while (rs.next()) {
						personalBeanList.add(new PCY_PersonalBean(rs, null));
					}
				}

				personalBeans = new PCY_PersonalBean[personalBeanList.size()];
				personalBeanList.toArray(personalBeans);
			} else {
				personalBeans = new PCY_PersonalBean[0];
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return personalBeans;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * �p�[�\�i���v���t�@�C������S�Ẵ��[�U�����擾���APCY_PersonalBean �Ɋi�[���ĕԂ��܂��B
	 * @param userId ����NO
	 * @param loginuser ���O�C�����[�U���
	 * @return ���[�U���
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_PersonalBean getAllPersonalInfo(final String userId, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");
			// SQL�ݒ�
			ps = con.prepareStatement("SELECT * FROM " + HcdbDef.personalTbl + " WHERE SIMEI_NO=? and HONMU_FLG='" + HcdbDef.HONMU + "' ");

			// �p�����[�^�ݒ�
			ps.setString(1, userId);
			// SQL���s
			rs = ps.executeQuery();
			PCY_PersonalBean personal = null;

			while (rs.next()) {
				personal = new PCY_PersonalBean();
				personal.setAllData(rs, null);

			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return personal;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * �����������L�[�Ƃ��ăp�[�\�i���v���t�@�C������ꗗ���擾���܂��B �߂�l�͌��������Ƀq�b�g�����p�[�\�i���v���t�@�C�����i�[���ꂽ �p�[�\�i�� ValueBean �ł��B
	 * @param personalBean �Ώێ�Bean
	 * @param loginuser ���O�C�����[�U���
	 * @return �p�[�\�i���v���t�@�C���̈ꗗ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_PersonalBean[] doSelect(final PCY_PersonalBean personalBean, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// SQL���̍쐬
			final StringBuffer sql = new StringBuffer();
			sql.append("SELECT * FROM ");
			sql.append(HcdbDef.personalTbl);

			// ���������̍쐬
			final StringBuffer where = new StringBuffer();
			final Map personalConditions = personalBean.extractConditions();

			for (final Iterator ite = personalConditions.keySet().iterator(); ite.hasNext();) {
				final Object column = ite.next();

				if (column.equals("SIMEI_NO")) {
					where.append(" AND " + column + " LIKE ?");
				} else if (column.equals("KANJI_SIMEI")) {
					where.append(" AND UPPER(" + column + ") LIKE UPPER(?)");
				} else if (column.equals("KANA_SIMEI")) {
					where.append(" AND UPPER(" + column + ") LIKE UPPER(?)");
				} else if (column.equals("EIJI_SIMEI")) {
					where.append(" AND UPPER(" + column + ") LIKE UPPER(?)");
				} else {
					where.append(" AND " + column + "=?");
				}
			}

			where.append(" AND HONMU_FLG='" + HcdbDef.HONMU + "' ");
			sql.append(where.toString().replaceFirst("AND", "WHERE"));

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// SQL�ݒ�
			ps = con.prepareStatement(sql.toString());

			// �p�����[�^�ݒ�
			int count = 1;
			for (final Iterator ite = personalConditions.keySet().iterator(); ite.hasNext();) {
				final Object key = ite.next();
				ps.setObject(count++, personalConditions.get(key));
			}

			// SQL���s �������s
			rs = ps.executeQuery();
			final List ret = new ArrayList();

			while (rs.next()) {
				ret.add(new PCY_PersonalBean(rs, null));
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return (PCY_PersonalBean[]) ret.toArray(new PCY_PersonalBean[0]);
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			// DE�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * �v���C�}���[�L�[���L�[�Ƃ��ăp�[�\�i���v���t�@�C�����X�V���܂��B
	 * @param personalBeans �X�V����PCY_PersonalBean�̔z��
	 * @param loginuser ���O�C�����[�U
	 * @return �X�V����
	 * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
	 * @deprecated �v���N�e�B�X���W���[���p�̋@�\����p�[�\�i�������X�V���Ȃ��ł�������
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdate(final PCY_PersonalBean[] personalBeans, final PCY_PersonalBean loginuser) throws PCY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// ����No.���L�[�Ƀ\�[�g
			Arrays.sort(personalBeans, new ClassCodeComparator());

			// SQL�쐬
			final StringBuffer sql = new StringBuffer();
			sql.append("UPDATE ");
			sql.append(HcdbDef.personalTbl);
			sql.append("    SET ");

			// ���������̍쐬
			sql.append("        PASSWORD=?, ");
			sql.append("        HONMU_FLG=?, ");
			sql.append("        SIMEI_NO_FLG=?, ");
			sql.append("        KANJI_SIMEI=?, ");
			sql.append("        KANA_SIMEI=?, ");
			sql.append("        EIJI_SIMEI=?, ");
			sql.append("        SEIBETU=?, ");
			sql.append("        SEINENGAPPI=?, ");
			sql.append("        GROUP_NYUSYA_NENGETU=?, ");
			sql.append("        NYUSYA_NENGETU=?, ");
			sql.append("        YAKUSYOKU_CODE=?, ");
			sql.append("        SYOKUI_CODE=?, ");
			sql.append("        NAISEN=?, ");
			sql.append("        GAISEN=?, ");
			sql.append("        FAX_NO=?, ");
			sql.append("        MAIL=?, ");
			sql.append("        JIKO_PR=?, ");
			sql.append("        GENSYOKU_TAISYOKU_FLG=?, ");
			sql.append("        TAISYOKU_NENGAPPI=?, ");
			sql.append("        KENGEN_CODE=?, ");
			sql.append("        SYOZOKU_CODE_1=?, ");
			sql.append("        SYOZOKU_CODE_2=?, ");
			sql.append("        SYOZOKU_CODE_3=?, ");
			sql.append("        SYOZOKU_CODE_4=?, ");
			sql.append("        SYOZOKU_CODE_5=?, ");
			sql.append("        SYOZOKU_CODE_6=?, ");
			sql.append("        SYOZOKU_CODE_7=?, ");
			sql.append("        SYOZOKU_CODE_8=?, ");
			sql.append("        SYOZOKU_CODE_9=?, ");
			sql.append("        SYOKU_CODE1=?, ");
			sql.append("        SENMON_CODE1=?, ");
			sql.append("        LEVEL_CODE1=?, ");
			sql.append("        SOUGOU_T_DO1=?, ");
			sql.append("        SYOKU_CODE2=?, ");
			sql.append("        SENMON_CODE2=?, ");
			sql.append("        LEVEL_CODE2=?, ");
			sql.append("        SOUGOU_T_DO2=?, ");
			sql.append("        SYOKU_CODE3=?, ");
			sql.append("        SENMON_CODE3=?, ");
			sql.append("        LEVEL_CODE3=?, ");
			sql.append("        SOUGOU_T_DO3=?, ");
			sql.append("        ASSESSMENT_KOKAI_FLG=?, ");
			sql.append("        KAO_KOKAI_FLG=?, ");
			sql.append("        SKILL_KOKAI_FLG=?, ");
			sql.append("        SYOKUMU_KOKAI_FLG=?, ");
			sql.append("        KYOIKU_KOKAI_FLG=?, ");
			sql.append("        SIKAKU_KOKAI_FLG=?, ");
			sql.append("        HYOSYO_KOKAI_FLG=?, ");
			sql.append("        RONBUN_KOKAI_FLG=?, ");
			sql.append("        SYAGAI_KOKAI_FLG=?, ");
			sql.append("        GAKUREKI_KOKAI_FLG=?, ");
			sql.append("        SYANAIREKI_KOKAI_FLG=?, ");
			sql.append("        ZENSYOKUREKI_KOKAI_FLG=?, ");
			sql.append("        SOSIKI_KOKAI_FLG=?, ");
			sql.append("        YAKUSYOKU_KOKAI_FLG=?, ");
			sql.append("        SYOKUI_KOKAI_FLG=?, ");
			sql.append("        SKILL_MAINTE_FLG=?, ");
			sql.append("        KANREN_GYOMU_TOUROKU_FLG=?, ");
			sql.append("        PERSONAL_MAINTE_FLG=?, ");
			sql.append("        SOSIKI_MAINTE_FLG=?, ");
			sql.append("        KYOIKU_MAINTE_FLG=?, ");
			sql.append("        RONBUN_MAINTE_FLG=?, ");
			sql.append("        SIKAKU_MAINTE_FLG=?, ");
			sql.append("        HYOSYO_MAINTE_FLG=?, ");
			sql.append("        SYAGAI_RONBUN_MAINTE_FLG=?, ");
			sql.append("        KENPO_MAINTE_FLG=?, ");
			sql.append("        SYAGAI_MAINTE_FLG=?, ");
			sql.append("        LOGIN_OSIRASE_MAINTE_FLG=?, ");
			sql.append("        TOKEI_BUNSEKI_KENGEN=?, ");
			sql.append("        TAISYOKUSYA_KENSAKU_KENGEN_FLG=?, ");
			sql.append("        HIKOUKAI_KENSAKU_KENGEN_FLG=?, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI1=?, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI2=?, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI3=?, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI4=?, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI5=?, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI6=?, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI7=?, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI8=?, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI9=?, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI10=?, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI11=?, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI12=?, ");
			sql.append("        MAINTE_FLG_YOBI1=?, ");
			sql.append("        YOBI1=?, ");
			sql.append("        YOBI2=?, ");
			sql.append("        YOBI3=?, ");
			sql.append("        YOBI4=?, ");
			sql.append("        YOBI5=?, ");
			sql.append("        YOBI6=?, ");
			sql.append("        YOBI7=?, ");
			sql.append("        YOBI8=?, ");
			sql.append("        YOBI9=?, ");
			sql.append("        YOBI10=?, ");
			sql.append("        YAKUSYOKU=?, ");
			sql.append("        YOBI_RYOIKI=?, ");
			sql.append("        KAIGAI_KOKAI_FLG=?, ");
			sql.append("        KAIGAI_MAINTE_FLG=?, ");
			sql.append("        JINMEI_RYAKUSYO=?, ");
			sql.append("        BUSYO_RYAKUSYO_MEI=?, ");
			sql.append("        GAKUREKI_GAKKO_MEI=?, ");
			sql.append("        GAKUREKI_GAKUBU_MEI=?, ");
			sql.append("        GAKUREKI_GAKKA_MEI=?, ");
			sql.append("        GAKUREKI_SOTUGYO_NENGETU=? ");
			sql.append("  WHERE SIMEI_NO=? ");
			sql.append("    AND SOSIKI_CODE=? ");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// SQL�ݒ�
			ps = con.prepareStatement(sql.toString());

			int count = 0;

			for (int i = 0; i < personalBeans.length; i++) {
				// �p�����[�^�ݒ�
				ps.setString(1, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getPassword()));
				ps.setString(2, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getHonmuFlg()));
				ps.setString(3, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSimeiNoFlgPublic()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSimeiNoFlg()));
				ps.setString(4, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKanjiSimeiPublic()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKanjiSimei()));
				ps.setString(5, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKanaSimeiPublic()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKanaSimei()));
				ps.setString(6, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getEigoSimeiPublic()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getEigoSimei()));
				ps.setString(7, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSeibetuPublic()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSeibetu()));
				ps.setString(8, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSeinengappiPublic()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSeinengappi()));
				ps.setString(9, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGroupNyusyaNengetuPublic()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGroupNyusyaNengetu()));
				ps.setString(10, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getNyusyaNengetuPublic()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getNyusyaNengetu()));
				ps.setString(11, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYakusyokuCode()));
				ps.setString(12, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyokuiCode()));
				ps.setString(13, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getNaisen()));
				ps.setString(14, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGaisen()));
				ps.setString(15, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getFaxNo()));
				ps.setString(16, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getMail()));
				ps.setString(17, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getJikoPrPublic()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getJikoPr()));
				ps.setString(18, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGensyokuTaisyokuFlg()));
				ps.setString(19, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getTaisyokuNengappi()));
				ps.setString(20, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKengenCode()));
				ps.setString(21, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode1()));
				ps.setString(22, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode2()));
				ps.setString(23, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode3()));
				ps.setString(24, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode4()));
				ps.setString(25, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode5()));
				ps.setString(26, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode6()));
				ps.setString(27, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode7()));
				ps.setString(28, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode8()));
				ps.setString(29, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode9()));
				ps.setString(30, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyokuCode1()));
				ps.setString(31, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSenmonCode1()));
				ps.setString(32, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getLevelCode1()));
				ps.setString(33, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSougouTDo1()));
				ps.setString(34, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyokuCode2()));
				ps.setString(35, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSenmonCode2()));
				ps.setString(36, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getLevelCode2()));
				ps.setString(37, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSougouTDo2()));
				ps.setString(38, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyokuCode3()));
				ps.setString(39, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSenmonCode3()));
				ps.setString(40, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getLevelCode3()));
				ps.setString(41, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSougouTDo3()));
				ps.setString(42, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getAssessmentKokaiFlg()));
				ps.setString(43, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKaoKokaiFlg()));
				ps.setString(44, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSkillKokaiFlg()));
				ps.setString(45, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyokumuKokaiFlg()));
				ps.setString(46, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKyoikuKokaiFlg()));
				ps.setString(47, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSikakuKokaiFlg()));
				ps.setString(48, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getHyosyoKokaiFlg()));
				ps.setString(49, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getRonbunKokaiFlg()));
				ps.setString(50, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyagaiKokaiFlg()));
				ps.setString(51, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGakurekiKokaiFlg()));
				ps.setString(52, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyanairekiKokaiFlg()));
				ps.setString(53, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getZensyokurekiKokaiFlg()));
				ps.setString(54, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSosikiKokaiFlg()));
				ps.setString(55, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYakusyokuKokaiFlg()));
				ps.setString(56, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyokuiKokaiFlg()));
				ps.setString(57, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSkillMainteFlg()));
				ps.setString(58, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKanrenGyomuTourokuFlg()));
				ps.setString(59, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getPersonalMainteFlg()));
				ps.setString(60, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSosikiMainteFlg()));
				ps.setString(61, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKyoikuMainteFlg()));
				ps.setString(62, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getRonbunMainteFlg()));
				ps.setString(63, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSikakuMainteFlg()));
				ps.setString(64, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getHyosyoMainteFlg()));
				ps.setString(65, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyagaiRonbunMainteFlg()));
				ps.setString(66, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKenpoMainteFlg()));
				ps.setString(67, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyagaiMainteFlg()));
				ps.setString(68, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getLoginOsiraseMainteFlg()));
				ps.setString(69, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getTokeiBunsekiKengen()));
				ps.setString(70, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getTaisyokusyaKensakuKengenFlg()));
				ps.setString(71, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getHikoukaiKensakuKengenFlg()));
				ps.setString(72, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi1()));
				ps.setString(73, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi2()));
				ps.setString(74, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi3()));
				ps.setString(75, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi4()));
				ps.setString(76, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi5()));
				ps.setString(77, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi6()));
				ps.setString(78, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi7()));
				ps.setString(79, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi8()));
				ps.setString(80, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi9()));
				ps.setString(81, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi10()));
				ps.setString(82, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi11()));
				ps.setString(83, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi12()));
				ps.setString(84, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getMainteFlgYobi1()));
				ps.setString(85, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi1Public()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi1()));
				ps.setString(86, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi2Public()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi2()));
				ps.setString(87, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi3Public()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi3()));
				ps.setString(88, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi4Public()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi4()));
				ps.setString(89, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi5Public()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi5()));
				ps.setString(90, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi6()));
				ps.setString(91, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi7()));
				ps.setString(92, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi8()));
				ps.setString(93, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi9()));
				ps.setString(94, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi10()));
				ps.setString(95, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYakusyoku()));
				ps.setString(96, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobiRyoiki()));
				ps.setString(97, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKaigaiKokaiFlg()));
				ps.setString(98, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKaigaiMainteFlg()));
				ps.setString(99, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getJinmeiRyakusyo()));
				ps.setString(100, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getBusyoRyakusyoMeiPublic()) + PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getBusyoRyakusyoMei()));
				ps.setString(101, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGakurekiGakkoMei()));
				ps.setString(102, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGakurekiGakubuMei()));
				ps.setString(103, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGakurekiGakkaMei()));
				ps.setString(104, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGakurekiSotugyoNengetu()));
				ps.setString(105, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSimeiNo()));
				ps.setString(106, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSosikiCode()));
				// SQL���s
				count += ps.executeUpdate();
			}

			if (personalBeans.length != count) {
				this.context.setRollbackOnly();
				throw new PCY_WarningException();
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * �v���C�}���[�L�[���L�[�Ƃ��ăp�[�\�i���v���t�@�C�����X�V���܂��B
	 * @param personalBeans �X�V����PCY_PersonalBean
	 * @param loginuser ���O�C�����[�U
	 * @return �X�V����
	 * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
	 * @deprecated �v���N�e�B�X���W���[��������p�[�\�i�������X�V���Ȃ��ŉ�����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdate(final PCY_PersonalBean personalBean, final PCY_PersonalBean loginuser) throws PCY_WarningException {
		return this.doUpdate(new PCY_PersonalBean[] { personalBean }, loginuser);
	}

	/**
	 * �p�[�\�i���v���t�@�C����}�����܂��B
	 * @param personalBeans �X�V����PCY_PersonalBean�̔z��
	 * @param loginuser ���O�C�����[�U
	 * @return �X�V����
	 * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
	 * @deprecated �v���N�e�B�X���W���[��������p�[�\�i������ǉ����Ȃ��ł�������
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doInsert(final PCY_PersonalBean[] personalBeans, final PCY_PersonalBean loginuser) throws PCY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// ����No.���L�[�Ƀ\�[�g
			Arrays.sort(personalBeans, new ClassCodeComparator());

			// SQL�쐬
			final StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO ");
			sql.append(HcdbDef.personalTbl);
			sql.append(" (");
			sql.append("        SIMEI_NO, ");
			sql.append("        PASSWORD, ");
			sql.append("        HONMU_FLG, ");
			sql.append("        SIMEI_NO_FLG, ");
			sql.append("        KANJI_SIMEI, ");
			sql.append("        KANA_SIMEI, ");
			sql.append("        EIJI_SIMEI, ");
			sql.append("        SEIBETU, ");
			sql.append("        SEINENGAPPI, ");
			sql.append("        GROUP_NYUSYA_NENGETU, ");
			sql.append("        NYUSYA_NENGETU, ");
			sql.append("        SOSIKI_CODE, ");
			sql.append("        YAKUSYOKU_CODE, ");
			sql.append("        SYOKUI_CODE, ");
			sql.append("        NAISEN, ");
			sql.append("        GAISEN, ");
			sql.append("        FAX_NO, ");
			sql.append("        MAIL, ");
			sql.append("        JIKO_PR, ");
			sql.append("        GENSYOKU_TAISYOKU_FLG, ");
			sql.append("        TAISYOKU_NENGAPPI, ");
			sql.append("        KENGEN_CODE, ");
			sql.append("        SYOZOKU_CODE_1, ");
			sql.append("        SYOZOKU_CODE_2, ");
			sql.append("        SYOZOKU_CODE_3, ");
			sql.append("        SYOZOKU_CODE_4, ");
			sql.append("        SYOZOKU_CODE_5, ");
			sql.append("        SYOZOKU_CODE_6, ");
			sql.append("        SYOZOKU_CODE_7, ");
			sql.append("        SYOZOKU_CODE_8, ");
			sql.append("        SYOZOKU_CODE_9, ");
			sql.append("        SYOKU_CODE1, ");
			sql.append("        SENMON_CODE1, ");
			sql.append("        LEVEL_CODE1, ");
			sql.append("        SOUGOU_T_DO1, ");
			sql.append("        SYOKU_CODE2, ");
			sql.append("        SENMON_CODE2, ");
			sql.append("        LEVEL_CODE2, ");
			sql.append("        SOUGOU_T_DO2, ");
			sql.append("        SYOKU_CODE3, ");
			sql.append("        SENMON_CODE3, ");
			sql.append("        LEVEL_CODE3, ");
			sql.append("        SOUGOU_T_DO3, ");
			sql.append("        ASSESSMENT_KOKAI_FLG, ");
			sql.append("        KAO_KOKAI_FLG, ");
			sql.append("        SKILL_KOKAI_FLG, ");
			sql.append("        SYOKUMU_KOKAI_FLG, ");
			sql.append("        KYOIKU_KOKAI_FLG, ");
			sql.append("        SIKAKU_KOKAI_FLG, ");
			sql.append("        HYOSYO_KOKAI_FLG, ");
			sql.append("        RONBUN_KOKAI_FLG, ");
			sql.append("        SYAGAI_KOKAI_FLG, ");
			sql.append("        GAKUREKI_KOKAI_FLG, ");
			sql.append("        SYANAIREKI_KOKAI_FLG, ");
			sql.append("        ZENSYOKUREKI_KOKAI_FLG, ");
			sql.append("        SOSIKI_KOKAI_FLG, ");
			sql.append("        YAKUSYOKU_KOKAI_FLG, ");
			sql.append("        SYOKUI_KOKAI_FLG, ");
			sql.append("        SKILL_MAINTE_FLG, ");
			sql.append("        KANREN_GYOMU_TOUROKU_FLG, ");
			sql.append("        PERSONAL_MAINTE_FLG, ");
			sql.append("        SOSIKI_MAINTE_FLG, ");
			sql.append("        KYOIKU_MAINTE_FLG, ");
			sql.append("        RONBUN_MAINTE_FLG, ");
			sql.append("        SIKAKU_MAINTE_FLG, ");
			sql.append("        HYOSYO_MAINTE_FLG, ");
			sql.append("        SYAGAI_RONBUN_MAINTE_FLG, ");
			sql.append("        KENPO_MAINTE_FLG, ");
			sql.append("        SYAGAI_MAINTE_FLG, ");
			sql.append("        LOGIN_OSIRASE_MAINTE_FLG, ");
			sql.append("        TOKEI_BUNSEKI_KENGEN, ");
			sql.append("        TAISYOKUSYA_KENSAKU_KENGEN_FLG, ");
			sql.append("        HIKOUKAI_KENSAKU_KENGEN_FLG, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI1, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI2, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI3, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI4, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI5, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI6, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI7, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI8, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI9, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI10, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI11, ");
			sql.append("        GAMEN_KOKAI_FLG_YOBI12, ");
			sql.append("        MAINTE_FLG_YOBI1, ");
			sql.append("        YOBI1, ");
			sql.append("        YOBI2, ");
			sql.append("        YOBI3, ");
			sql.append("        YOBI4, ");
			sql.append("        YOBI5, ");
			sql.append("        YOBI6, ");
			sql.append("        YOBI7, ");
			sql.append("        YOBI8, ");
			sql.append("        YOBI9, ");
			sql.append("        YOBI10, ");
			sql.append("        YAKUSYOKU, ");
			sql.append("        YOBI_RYOIKI, ");
			sql.append("        KAIGAI_KOKAI_FLG, ");
			sql.append("        KAIGAI_MAINTE_FLG, ");
			sql.append("        JINMEI_RYAKUSYO, ");
			sql.append("        BUSYO_RYAKUSYO_MEI, ");
			sql.append("        GAKUREKI_GAKKO_MEI, ");
			sql.append("        GAKUREKI_GAKUBU_MEI, ");
			sql.append("        GAKUREKI_GAKKA_MEI, ");
			sql.append("        GAKUREKI_SOTUGYO_NENGETU ) ");
			sql
					.append("  VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// SQL�ݒ�
			ps = con.prepareStatement(sql.toString());

			// �����Ώۂ̃��[�U�������[�v����SQL���s
			int count = 0;
			for (int i = 0; i < personalBeans.length; i++) {
				// �p�����[�^�ݒ�
				ps.setString(1, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSimeiNo()));
				ps.setString(2, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getPassword()));
				ps.setString(3, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getHonmuFlg()));
				ps.setString(4, personalBeans[i].getSimeiNoFlgPublic() + personalBeans[i].getSimeiNoFlg());
				ps.setString(5, personalBeans[i].getKanjiSimeiPublic() + personalBeans[i].getKanjiSimei());
				ps.setString(6, personalBeans[i].getKanaSimeiPublic() + personalBeans[i].getKanaSimei());
				ps.setString(7, personalBeans[i].getEigoSimeiPublic() + personalBeans[i].getEigoSimei());
				ps.setString(8, personalBeans[i].getSeibetuPublic() + personalBeans[i].getSeibetu());
				ps.setString(9, personalBeans[i].getSeinengappiPublic() + personalBeans[i].getSeinengappi());
				ps.setString(10, personalBeans[i].getGroupNyusyaNengetuPublic() + personalBeans[i].getGroupNyusyaNengetu());
				ps.setString(11, personalBeans[i].getNyusyaNengetuPublic() + personalBeans[i].getNyusyaNengetu());
				ps.setString(12, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSosikiCode()));
				ps.setString(13, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYakusyokuCode()));
				ps.setString(14, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyokuiCode()));
				ps.setString(15, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getNaisen()));
				ps.setString(16, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGaisen()));
				ps.setString(17, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getFaxNo()));
				ps.setString(18, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getMail()));
				ps.setString(19, personalBeans[i].getJikoPrPublic() + personalBeans[i].getJikoPr());
				ps.setString(20, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGensyokuTaisyokuFlg()));
				ps.setString(21, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getTaisyokuNengappi()));
				ps.setString(22, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKengenCode()));
				ps.setString(23, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode1()));
				ps.setString(24, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode2()));
				ps.setString(25, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode3()));
				ps.setString(26, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode4()));
				ps.setString(27, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode5()));
				ps.setString(28, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode6()));
				ps.setString(29, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode7()));
				ps.setString(30, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode8()));
				ps.setString(31, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyozokuCode9()));
				ps.setString(32, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyokuCode1()));
				ps.setString(33, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSenmonCode1()));
				ps.setString(34, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getLevelCode1()));
				ps.setString(35, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSougouTDo1()));
				ps.setString(36, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyokuCode2()));
				ps.setString(37, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSenmonCode2()));
				ps.setString(38, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getLevelCode2()));
				ps.setString(39, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSougouTDo2()));
				ps.setString(40, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyokuCode3()));
				ps.setString(41, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSenmonCode3()));
				ps.setString(42, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getLevelCode3()));
				ps.setString(43, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSougouTDo3()));
				ps.setString(44, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getAssessmentKokaiFlg()));
				ps.setString(45, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKaoKokaiFlg()));
				ps.setString(46, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSkillKokaiFlg()));
				ps.setString(47, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyokumuKokaiFlg()));
				ps.setString(48, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKyoikuKokaiFlg()));
				ps.setString(49, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSikakuKokaiFlg()));
				ps.setString(50, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getHyosyoKokaiFlg()));
				ps.setString(51, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getRonbunKokaiFlg()));
				ps.setString(52, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyagaiKokaiFlg()));
				ps.setString(53, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGakurekiKokaiFlg()));
				ps.setString(54, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyanairekiKokaiFlg()));
				ps.setString(55, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getZensyokurekiKokaiFlg()));
				ps.setString(56, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSosikiKokaiFlg()));
				ps.setString(57, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYakusyokuKokaiFlg()));
				ps.setString(58, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyokuiKokaiFlg()));
				ps.setString(59, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSkillMainteFlg()));
				ps.setString(60, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKanrenGyomuTourokuFlg()));
				ps.setString(61, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getPersonalMainteFlg()));
				ps.setString(62, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSosikiMainteFlg()));
				ps.setString(63, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKyoikuMainteFlg()));
				ps.setString(64, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getRonbunMainteFlg()));
				ps.setString(65, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSikakuMainteFlg()));
				ps.setString(66, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getHyosyoMainteFlg()));
				ps.setString(67, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyagaiRonbunMainteFlg()));
				ps.setString(68, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKenpoMainteFlg()));
				ps.setString(69, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getSyagaiMainteFlg()));
				ps.setString(70, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getLoginOsiraseMainteFlg()));
				ps.setString(71, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getTokeiBunsekiKengen()));
				ps.setString(72, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getTaisyokusyaKensakuKengenFlg()));
				ps.setString(73, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getHikoukaiKensakuKengenFlg()));
				ps.setString(74, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi1()));
				ps.setString(75, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi2()));
				ps.setString(76, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi3()));
				ps.setString(77, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi4()));
				ps.setString(78, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi5()));
				ps.setString(79, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi6()));
				ps.setString(80, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi7()));
				ps.setString(81, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi8()));
				ps.setString(82, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi9()));
				ps.setString(83, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi10()));
				ps.setString(84, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi11()));
				ps.setString(85, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGamenKokaiFlgYobi12()));
				ps.setString(86, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getMainteFlgYobi1()));
				ps.setString(87, personalBeans[i].getYobi1Public() + personalBeans[i].getYobi1());
				ps.setString(88, personalBeans[i].getYobi2Public() + personalBeans[i].getYobi2());
				ps.setString(89, personalBeans[i].getYobi3Public() + personalBeans[i].getYobi3());
				ps.setString(90, personalBeans[i].getYobi4Public() + personalBeans[i].getYobi4());
				ps.setString(91, personalBeans[i].getYobi5Public() + personalBeans[i].getYobi5());
				ps.setString(92, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi6()));
				ps.setString(93, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi7()));
				ps.setString(94, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi8()));
				ps.setString(95, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi9()));
				ps.setString(96, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobi10()));
				ps.setString(97, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYakusyoku()));
				ps.setString(98, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getYobiRyoiki()));
				ps.setString(99, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKaigaiKokaiFlg()));
				ps.setString(100, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getKaigaiMainteFlg()));
				ps.setString(101, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getJinmeiRyakusyo()));
				ps.setString(102, personalBeans[i].getBusyoRyakusyoMeiPublic() + personalBeans[i].getBusyoRyakusyoMei());
				ps.setString(103, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGakurekiGakkoMei()));
				ps.setString(104, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGakurekiGakubuMei()));
				ps.setString(105, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGakurekiGakkaMei()));
				ps.setString(106, PZZ010_CharacterUtil.normalizedStr(personalBeans[i].getGakurekiSotugyoNengetu()));
				// SQL���s
				count += ps.executeUpdate();
			}

			if (personalBeans.length != count) {
				this.context.setRollbackOnly();
				throw new PCY_WarningException();
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * �p�[�\�i���v���t�@�C����}�����܂��B
	 * @param personalBeans �X�V����PCY_PersonalBean
	 * @param loginuser ���O�C�����[�U
	 * @return �X�V����
	 * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
	 * @deprecated �v���N�e�B�X���W���[��������p�[�\�i�������X�V���Ȃ��ŉ�����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doInsert(final PCY_PersonalBean personalBean, final PCY_PersonalBean loginuser) throws PCY_WarningException {
		return this.doInsert(new PCY_PersonalBean[] { personalBean }, loginuser);
	}

	/**
	 * �p�[�\�i���v���t�@�C����������i�J�������j�̃��[�U�����擾���APCY_PersonalBean �Ɋi�[���ĕԂ��܂��B
	 * @param userId ����NO
	 * @param column �J������
	 * @param loginuser ���O�C�����[�U���
	 * @return �J�����l
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public Object getPersonalInfo(final String userId, final String column, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");
			final String sql = "SELECT " + column + " FROM " + HcdbDef.personalTbl + " WHERE SIMEI_NO=? and HONMU_FLG='" + HcdbDef.HONMU + "' ";

			// SQL�ݒ�
			ps = con.prepareStatement(sql);

			Log.debug(sql);

			// �p�����[�^�ݒ�
			ps.setString(1, userId);

			// SQL���s
			rs = ps.executeQuery();

			String ret = "";
			while (rs.next()) {
				ret = rs.getString(column);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return ret;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * ����NO���L�[�Ƃ��Č��C�Ǘ������e�i���X�������X�V���܂��B
	 * @param personalBean �X�V����PCY_PersonalBean
	 * @param loginuser ���O�C�����[�U
	 * @return �X�V����
	 * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdateKenpoMainteFlg(final PCY_PersonalBean personalBean, final PCY_PersonalBean loginuser) throws PCY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// SQL�쐬
			final StringBuffer sql = new StringBuffer();
			sql.append("UPDATE ");
			sql.append(HcdbDef.personalTbl);
			sql.append("    SET ");
			sql.append("        KENPO_MAINTE_FLG = ? ");
			sql.append("  WHERE SIMEI_NO=? ");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			Log.debug(sql.toString());

			// �X�V���s
			ps = con.prepareStatement(sql.toString());

			int count = 0;
			// �p�����[�^�ݒ�
			ps.setString(1, PZZ010_CharacterUtil.normalizedStr(personalBean.getKenpoMainteFlg()));
			ps.setString(2, PZZ010_CharacterUtil.normalizedStr(personalBean.getSimeiNo()));

			// SQL���s
			count = ps.executeUpdate();

			if (count == 0) {
				this.context.setRollbackOnly();
				throw new PCY_WarningException();
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * �p�[�\�i���v���t�@�C�����烆�[�U�����擾���APCY_PersonalBean �Ɋi�[���ĕԂ��܂��B(�Ώۂ͌��E�҂̂�)
	 * @param userId ����NO
	 * @param loginuser ���O�C�����[�U���
	 * @return ���[�U���
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_PersonalBean getGensyokuPersonalInfo(final String userId, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// SQL�ݒ�
			ps = con.prepareStatement("SELECT * FROM " + HcdbDef.personalTbl + " WHERE SIMEI_NO=? and HONMU_FLG='" + HcdbDef.HONMU + "' " + " AND GENSYOKU_TAISYOKU_FLG='" + HcdbDef.GENSYOKU_TAISYOKU
					+ "' ");

			// �p�����[�^�ݒ�
			ps.setString(1, userId);

			// SQL���s
			rs = ps.executeQuery();
			PCY_PersonalBean personal = null;

			while (rs.next()) {
				personal = new PCY_PersonalBean(rs, null);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return personal;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * �p�[�\�i���v���t�@�C�����烆�[�U�����擾���APCY_PersonalBean �Ɋi�[���ĕԂ��܂��B(�Ώۂ͌��E�҂̂�)
	 * @param userId ����NO
	 * @param loginuser ���O�C�����[�U���
	 * @return ���[�U���
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_PersonalBean[] getGensyokuPersonalInfo(final String[] userId, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			PCY_PersonalBean[] personalBeans = null;

			if (userId != null && userId.length != 0) {
				// �R�l�N�V�����擾
				con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

				final StringBuffer sql = new StringBuffer("SELECT * FROM " + HcdbDef.personalTbl);
				sql.append(" WHERE SIMEI_NO=?  AND HONMU_FLG='" + HcdbDef.HONMU + "' " + " AND GENSYOKU_TAISYOKU_FLG='" + HcdbDef.GENSYOKU_TAISYOKU + "' ");

				/* �f�o�b�O���O�̏o�� */
				Log.debug(sql.toString());

				// SQL�ݒ�
				ps = con.prepareStatement(sql.toString());

				final List personalBeanList = new ArrayList();

				// �����Ώۂ̃��[�U�������[�v����SQL���s
				for (int i = 0; i < userId.length; i++) {
					// �p�����[�^�ݒ�
					ps.setString(1, userId[i]);
					// SQL���s
					rs = ps.executeQuery();

					while (rs.next()) {
						personalBeanList.add(new PCY_PersonalBean(rs, null));
					}
					
					PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", null, null, rs);
				}

				personalBeans = new PCY_PersonalBean[personalBeanList.size()];
				personalBeanList.toArray(personalBeans);
			} else {
				personalBeans = new PCY_PersonalBean[0];
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return personalBeans;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * �����������L�[�Ƃ��ăp�[�\�i���v���t�@�C������ꗗ���擾���܂��B(�Ώۂ͌��E�҂̂�) �߂�l�͌��������Ƀq�b�g�����p�[�\�i���v���t�@�C�����i�[���ꂽ �p�[�\�i�� ValueBean �ł��B
	 * @param personalBean �Ώێ�Bean
	 * @param loginuser ���O�C�����[�U���
	 * @return �p�[�\�i���v���t�@�C���̈ꗗ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_PersonalBean[] doGensyokuSelect(final PCY_PersonalBean personalBean, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// SQL���̍쐬
			final StringBuffer sql = new StringBuffer();
			sql.append("SELECT * FROM ");
			sql.append(HcdbDef.personalTbl);

			// ���������̍쐬
			final StringBuffer where = new StringBuffer();
			final Map personalConditions = personalBean.extractConditions();

			for (final Iterator ite = personalConditions.keySet().iterator(); ite.hasNext();) {
				final Object column = ite.next();

				// ���͒l�����݂��鍀�ڂ̂݌��������ɒǉ��i���P�j
				if (column.equals("SIMEI_NO")) {
					if (personalBean.getSimeiNo() != null) {
						where.append(" AND " + column + " LIKE '%'||?||'%' ESCAPE '#'");
					}
				} else if (column.equals("KANJI_SIMEI")) {
					if (personalBean.getKanjiSimei() != null) {
						where.append(" AND " + column + " LIKE '%'||?||'%' ESCAPE '#'");
					}
				} else if (column.equals("KANA_SIMEI")) {
					if (personalBean.getKanaSimei() != null) {
						where.append(" AND " + column + " LIKE '%'||?||'%' ESCAPE '#'");
					}
				} else if (column.equals("EIJI_SIMEI")) {
					if (personalBean.getEijiSimei() != null) {
						where.append(" AND " + column + " LIKE '%'||?||'%' ESCAPE '#'");
					}
				} else {
					where.append(" AND " + column + "=?");
				}
			}

			where.append(" AND HONMU_FLG='" + HcdbDef.HONMU + "' ");
			where.append(" AND GENSYOKU_TAISYOKU_FLG='" + HcdbDef.GENSYOKU_TAISYOKU + "' ");
			sql.append(where.toString().replaceFirst("AND", "WHERE"));

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// SQL�ݒ�
			ps = con.prepareStatement(sql.toString());

			int count = 1;

			// �i���P�j�ō쐬����WHERE����"?"�ɁA�T�j�^�C�Y�������͒l���Z�b�g
			// PreparedStatement#set�`�ŃT�j�^�C�Y���Ă���܂�
			for (final Iterator ite = personalConditions.keySet().iterator(); ite.hasNext();) {
				final String str = (String) ite.next();
				if (str.equals("SIMEI_NO")) {
					if (personalBean.getSimeiNo() != null && !"".equals(personalBean.getSimeiNo())) {
						ps.setString(count, PZZ020_MakeSQLUtil.sanitizeSQLLikeData(personalBean.getSimeiNo()));
					}
				} else if (str.equals("KANJI_SIMEI")) {
					if (personalBean.getKanjiSimei() != null && !"".equals(personalBean.getKanjiSimei())) {
						ps.setString(count, PZZ020_MakeSQLUtil.sanitizeSQLLikeData(personalBean.getKanjiSimei()));
					}
				} else if (str.equals("KANA_SIMEI")) {
					if (personalBean.getKanaSimei() != null && !"".equals(personalBean.getKanaSimei())) {
						ps.setString(count, PZZ020_MakeSQLUtil.sanitizeSQLLikeData(personalBean.getKanaSimei()));
					}
				} else if (str.equals("EIJI_SIMEI")) {
					if (personalBean.getEijiSimei() != null && !"".equals(personalBean.getEijiSimei())) {
						ps.setString(count, PZZ020_MakeSQLUtil.sanitizeSQLLikeData(personalBean.getEijiSimei()));
					}
				} else {
					ps.setString(count, (String) personalConditions.get(str));
				}
				count++;
			}

			// �������s
			rs = ps.executeQuery();
			final List ret = new ArrayList();

			while (rs.next()) {
				ret.add(new PCY_PersonalBean(rs, null));
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return (PCY_PersonalBean[]) ret.toArray(new PCY_PersonalBean[0]);
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}
// ADD 2019/01/15 COMTURE �ꊇ�\���@�\�ǉ� START
	/**
	 * ���F�҂̎���NO���L�[�Ƀp�[�\�i���v���t�@�C���}�X�^����ꗗ���擾���܂��B
	 * @param userId ���F�҂̎���NO
	 * @param loginuser ���O�C�����[�U���
	 * @return �p�[�\�i���v���t�@�C���ꗗ
	 * @throws NamingException ���O������O
	 * @throws RemoteException �����[�g��O
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_PersonalBean[] getListBySyoninsya(final String userId,
	        final PCY_PersonalBean loginuser) throws NamingException,
	RemoteException {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;

	    try {
	        /* ���\�b�h�g���[�X�o�� */
	        Log.method(loginuser.getSimeiNo(), "IN", "");

	        con =
	                PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo()
	                        : "");

	        final StringBuffer sql = new StringBuffer();
	        sql.append("SELECT ");
	        sql.append("DISTINCT ");
	        sql.append(PCY_PersonalBean.getColumns("PERSONAL") + ", ");
	        sql.append(PCY_SyoninsyaBean.getColumns("SYONINSYA") + " ");
	        sql.append("FROM ");
	        sql.append(HcdbDef.L16_TBL);
	        sql.append(" SYONINSYA, ");
	        sql.append(HcdbDef.personalTbl);
	        sql.append(" PERSONAL ");
	        sql.append("WHERE ");
	        sql.append("      ( SYONINSYA.SYONINSYA1    = ?");
	        sql.append("        OR (     SYONINSYA.SYONINSYA2    = ?");
	        sql.append("             AND SYONINSYA.DAIKOUSYA_FLG = '1' ) )");
	        sql.append("   AND SYONINSYA.SIMEI_NO             = PERSONAL.SIMEI_NO");
	        sql.append("   AND PERSONAL.HONMU_FLG             = '" + HcdbDef.HONMU + "'");
	        sql.append("   AND PERSONAL.GENSYOKU_TAISYOKU_FLG = '" + HcdbDef.GENSYOKU + "'");
	        sql.append(" ORDER BY PERSONAL.SOSIKI_CODE, PERSONAL.SIMEI_NO");

	        ps = con.prepareStatement(sql.toString());
	        ps.setString(1, userId);
	        ps.setString(2, userId);

	        rs = ps.executeQuery();

	        final Vector ret = new Vector();

	        while (rs.next()) {
	            final PCY_PersonalBean mousikomiBean =
	                    new PCY_PersonalBean(rs, "PERSONAL");
	            ret.add(mousikomiBean);
	        }

	        /* ���\�b�h�g���[�X�o�� */
	        Log.method(loginuser.getSimeiNo(), "OUT", "");

	        return (PCY_PersonalBean[])ret.toArray(new PCY_PersonalBean[0]);
	    } catch (final NamingException e) {
	        Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
	        throw new EJBException(e);
	    } catch (final SQLException e) {
	        Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
	        throw new EJBException(e);
	    } catch (final RuntimeException e) {
	        Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
	        throw e;
	    } finally {
	        PZZ040_SQLUtility.closeConnection(
	                loginuser != null ? loginuser.getSimeiNo() : "", con, ps,
	                        rs);
	    }
	}
// ADD 2019/01/15 COMTURE �ꊇ�\���@�\�ǉ� END

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}

	private class ClassCodeComparator implements Comparator {
		public int compare(final Object o1, final Object o2) {
			final PCY_PersonalBean class1 = (PCY_PersonalBean) o1;
			final PCY_PersonalBean class2 = (PCY_PersonalBean) o2;

			if (class1.getSimeiNo().equals(class2.getSimeiNo())) {
				return class1.getSosikiCode().compareTo(class2.getSosikiCode());
			}

			return class1.getSimeiNo().compareTo(class2.getSimeiNo());
		}
	}
}
