/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_OsiraseEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_OsiraseEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_OsiraseBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F ���m�点���T�[�u���b�g�N���X �@�\�����F ���m�点�e�[�u�����f�[�^��ǉ�����
 * 
 * </PRE>
 */
public class PCX092_OsiraseTuikaServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		final PCY_OsiraseEJBHome home = (PCY_OsiraseEJBHome) EJBHomeFactory.getInstance().lookup(PCY_OsiraseEJBHome.class);
		final PCY_OsiraseEJB ejb = home.create();

		/* �ǉ��f�[�^���i�[���� */
		final PCY_OsiraseBean osiraseBeans = new PCY_OsiraseBean();

		osiraseBeans.setHakkoubi(request.getParameter("hiduke_add"));
		osiraseBeans.setHakkoujikoku(request.getParameter("syori_jikan_add"));
		osiraseBeans.setSyubetsuFlg(request.getParameter("syubetu_add"));
		osiraseBeans.setKigenbi(request.getParameter("kigen_add"));

		osiraseBeans.setHyoujiFlg(request.getParameter("hyoji_flag_add"));

		try {
			final String comment = request.getParameter("HTMLcomment");
			final String encComment = new String(comment.getBytes("iso-8859-1"), "Shift_JIS");
			osiraseBeans.setNaiyou(encComment);

			final String tuutatu = request.getParameter("tuutatu_add");
			final String encTuutatu = new String(tuutatu.getBytes("iso-8859-1"), "Shift_JIS");
			osiraseBeans.setTsuutatsu_page(encTuutatu);

		} catch (final UnsupportedEncodingException e) {
			request.setAttribute("warningID", "WCX060");
			final PCY_WarningException ex = new PCY_WarningException(e);
			throw ex;
		}

		/* �f�[�^��ǉ����� */
		try {
			final int count = ejb.doInsert(osiraseBeans, loginuser);
		} catch (final PCY_WarningException e) {
			request.setAttribute("warningID", "WCX060");
			throw e;
		}
		request.setAttribute("osiraseBeans", osiraseBeans);

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();
	}
}
