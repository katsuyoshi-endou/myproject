/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY301_MousikomiTorikesiServlet �N���X �@�\�����F �\������������s���܂��B
 * 
 * </PRE>
 */
public class PCY301_MousikomiTorikesiServlet extends PCY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {

		// Log�o��
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

// MOD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j START
//		final String kamokuCode = request.getParameter("kamoku_code");
//		final String classCode = request.getParameter("class_code");
//		final String simeiNo = request.getParameter("simei_no");
//		final String kousinbi = request.getParameter("kousinbi");
//		final String kousinjikoku = request.getParameter("kousinjikoku");
        final String[] kamokuCode = request.getParameterValues("kamoku_code");
        final String[] classCode = request.getParameterValues("class_code");
        final String[] simeiNo = request.getParameterValues("simei_no");
        final String[] kousinbi = request.getParameterValues("kousinbi");
        final String[] kousinjikoku = request.getParameterValues("kousinjikoku");
// MOD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j END

		final PCY_ClassEJBHome homeClass = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB ejbClass = homeClass.create();

// ADD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j START
        final PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = new PCY_MousikomiJyokyoBean[kamokuCode.length];

        for (int i = 0; i < kamokuCode.length; i++) {
// ADD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j END
// MOD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j START
//		final PCY_MousikomiJyokyoBean mousikomiJyokyoBean = new PCY_MousikomiJyokyoBean();
//		final PCY_ClassBean classBeanDummy = new PCY_ClassBean();
//
//		classBeanDummy.getKamokuBean().setKamokuCode(kamokuCode);
//		classBeanDummy.setClassCode(classCode);

        PCY_MousikomiJyokyoBean mousikomiJyokyoBean = new PCY_MousikomiJyokyoBean();
        PCY_ClassBean classBeanDummy = new PCY_ClassBean();

        classBeanDummy.getKamokuBean().setKamokuCode(kamokuCode[i]);
        classBeanDummy.setClassCode(classCode[i]);
// MOD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j END

		Log.transaction(loginuser.getSimeiNo(), true, "");
// MOD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j START
//		final PCY_ClassBean classBean = ejbClass.doSelectByPrimaryKey(classBeanDummy, loginuser);
		PCY_ClassBean classBean = ejbClass.doSelectByPrimaryKey(classBeanDummy, loginuser);
// MOD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j END
		Log.transaction(loginuser.getSimeiNo(), false, "");

		// �N���X��񂪌�����Ȃ������ꍇ
		if (classBean == null) {
			throw new PCY_WarningException();
		}

		mousikomiJyokyoBean.setClassBean(classBean);
// MOD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j START
//		mousikomiJyokyoBean.setKamokuCode(kamokuCode);
//		mousikomiJyokyoBean.setClassCode(classCode);
//		mousikomiJyokyoBean.setSimeiNo(simeiNo);
//		mousikomiJyokyoBean.setKousinbi(kousinbi);
//		mousikomiJyokyoBean.setKousinjikoku(kousinjikoku);
        mousikomiJyokyoBean.setKamokuCode(kamokuCode[i]);
        mousikomiJyokyoBean.setClassCode(classCode[i]);
        mousikomiJyokyoBean.setSimeiNo(simeiNo[i]);
        mousikomiJyokyoBean.setKousinbi(kousinbi[i]);
        mousikomiJyokyoBean.setKousinjikoku(kousinjikoku[i]);
// MOD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j END
		mousikomiJyokyoBean.setStatus("1");
		mousikomiJyokyoBean.setUketsukeJyotai("3");

// ADD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j START
        mousikomiJyokyoBeans[i] = mousikomiJyokyoBean;
        }
// ADD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j END
		final PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_MousikomiJyokyoEJB ejb = home.create();

		Log.transaction(loginuser.getSimeiNo(), true, "");
// MOD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j START
//		ejb.doUpdateReceiptStatus(new PCY_MousikomiJyokyoBean[] { mousikomiJyokyoBean }, loginuser);
		ejb.doUpdateReceiptStatus(mousikomiJyokyoBeans, loginuser);
// MOD 2018/04/03 COMTURE VCB010_�\�����F �iPh2-3�j END
		Log.transaction(loginuser.getSimeiNo(), false, "");
// ADD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V START
        for (PCY_MousikomiJyokyoBean m : mousikomiJyokyoBeans) {
		Log.transaction(loginuser.getSimeiNo(), true, "");
            ejbClass.doUpdateMansekiFlg(m.getClassBean(), loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");
        }
// ADD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V END

		/* ���\�b�h�g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

}
