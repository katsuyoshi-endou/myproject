/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_DaikoNyuryokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_DaikoNyuryokuEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_SyoninsyaBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_DaikoNyuryokuBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F �\�����݃T�[�u���b�g�N���X �@�\�����F ���C�̐\���݂��s���܂��B
 * 
 * </PRE>
 */
public class PCY121_MousikomiServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		// CHG#2007/2/26 s-hiura start
		final String[] kamokuCodes = request.getParameterValues("kamoku_code_array");
		final String[] classCodes = request.getParameterValues("class_code_array");

		/* �ȖڃR�[�h�ƃN���X�R�[�h���擾 */
		final PCY_ClassBean[] kensakuClassBeans = new PCY_ClassBean[kamokuCodes.length];
		for (int i = 0; i < kamokuCodes.length; i++) {
			final PCY_ClassBean kensakuClassBean = new PCY_ClassBean();
			kensakuClassBean.getKamokuBean().setKamokuCode(kamokuCodes[i]);
			kensakuClassBean.setClassCode(classCodes[i]);
			kensakuClassBeans[i] = kensakuClassBean;
		}

		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PCY_ClassEJBHome classHome = (PCY_ClassEJBHome) fact.lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB classEJB = classHome.create();

		final PCY_ClassBean[] classBeans = new PCY_ClassBean[kensakuClassBeans.length];
		for (int i = 0; i < kensakuClassBeans.length; i++) {
			classBeans[i] = classEJB.doSelectByPrimaryKey(kensakuClassBeans[i], loginuser);
		}

		String simei_no = request.getParameter("simei_no");

		if (simei_no == null || "".equals(simei_no)) {
			simei_no = loginuser.getSimeiNo();
		}

		final PCY_SyoninsyaEJBHome syoninsya_home = (PCY_SyoninsyaEJBHome) EJBHomeFactory.getInstance().lookup(PCY_SyoninsyaEJBHome.class);
		final PCY_SyoninsyaEJB syoninsya_ejb = syoninsya_home.create();

		final PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_MousikomiJyokyoEJB ejb = home.create();

		final HttpSession session = request.getSession();
		// �Z�b�V���������ɐ\���������s���Ă���N���X���擾
		final ArrayList mousikomiKentouList = (ArrayList) session.getAttribute("mousikomiKentouList");
		// DEL#2007/3/21 s-hiura

		final PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = new PCY_MousikomiJyokyoBean[classBeans.length];
		for (int i = 0; i < classBeans.length; i++) {
			/* For SAS-E */
			/* �N���X�̑����̏��F�敪���v�̏ꍇ�A���F�҂��ݒ肳��Ă��邱�Ƃ��`�F�b�N���� */
			if (classBeans[i].getSyoninKubun().equals("1")) {
				/* SyoninsyaEJB */
				final PCY_SyoninsyaBean[] syoninsyaBeans = syoninsya_ejb.doSelect(new String[] { simei_no }, true, loginuser); /* For SAS */

				if (syoninsyaBeans == null || syoninsyaBeans.length == 0 || syoninsyaBeans[0].getSyoninsya1() == null || syoninsyaBeans[0].getSyoninsya1().equals("")) {
					/* ���F�҂��ݒ肵�ĂȂ��ꍇ�A�x����ʂɑJ�ڂ��� */
					request.setAttribute("warningID", "WCA040");
					throw new PCY_WarningException("WCA040");
				}
			}

			mousikomiJyokyoBeans[i] = new PCY_MousikomiJyokyoBean();
			mousikomiJyokyoBeans[i].setClassBean(classBeans[i]);
			mousikomiJyokyoBeans[i].setSimeiNo(simei_no);
			mousikomiJyokyoBeans[i].setMousikomisya(loginuser.getSimeiNo());

			mousikomiJyokyoBeans[i].setMousikomibi(PZZ010_CharacterUtil.GetDay());
			mousikomiJyokyoBeans[i].setMousikomijikoku(PZZ010_CharacterUtil.GetTime());

			/* �N���X�̑�������X�e�[�^�X�𔻕ʂ��Đ\����DB��INSERT */
			String status = "";

			if (mousikomiJyokyoBeans[i].getClassBean().getSyoninKubun().equals("1")) {
				status = "0";
			} else {
				if (mousikomiJyokyoBeans[i].getClassBean().getUketukeKubun().equals("1")) {
					status = "1";
					mousikomiJyokyoBeans[i].setUketsukeJyotai("0");
				} else {
					if (!mousikomiJyokyoBeans[i].getClassBean().getHoukokuKubun().equals("0")) {
						status = "2";
					} else {
						status = "3";
					}
				}
			}

			mousikomiJyokyoBeans[i].setStatus(status);

			mousikomiJyokyoBeans[i].setSeikyuFlg("0");
		}
		ejb.doMousikomiWithZensyaTaisyo(mousikomiJyokyoBeans, loginuser);/* CHG#P-ALC01-030-005 */

		// ��s���͂̏ꍇ�́AL17�ɔ��f����
		PCY_DaikoNyuryokuBean[] daikoNyryokuBeans = null;
		if (request.getParameter("simei_no") != null && (!request.getParameter("simei_no").equals("")) && (request.getParameter("jyukou_jyokyo").equals("1"))) {
			daikoNyryokuBeans = new PCY_DaikoNyuryokuBean[classBeans.length];
			for (int i = 0; i < classBeans.length; i++) {
				daikoNyryokuBeans[i] = new PCY_DaikoNyuryokuBean();
				daikoNyryokuBeans[i].setSimeiNo(request.getParameter("simei_no"));
				daikoNyryokuBeans[i].setKamokuCode(classBeans[i].getKamokuBean().getKamokuCode());
				daikoNyryokuBeans[i].setClassCode(classBeans[i].getClassCode());

				final PCY_DaikoNyuryokuEJBHome daiko_home = (PCY_DaikoNyuryokuEJBHome) fact.lookup(PCY_DaikoNyuryokuEJBHome.class);
				final PCY_DaikoNyuryokuEJB daiko_ejb = daiko_home.create();
				final PCY_DaikoNyuryokuBean kensaku_daikoBean = new PCY_DaikoNyuryokuBean();
				kensaku_daikoBean.setKamokuCode(classBeans[i].getKamokuBean().getKamokuCode());
				kensaku_daikoBean.setClassCode(classBeans[i].getClassCode());

				final PCY_DaikoNyuryokuBean[] daikoBeans = daiko_ejb.doSelect(kensaku_daikoBean, false, loginuser);

				for (int j = 0; j < daikoBeans.length; j++) {
					if (daikoBeans[j].getSimeiNo().equals(request.getParameter("simei_no"))) {
						daikoNyryokuBeans[i].setTaisyoKubunRireki(daikoBeans[j].getTaisyoKubunRireki());
						daikoNyryokuBeans[i].setTourokubi(daikoBeans[j].getTourokubi());
						daikoNyryokuBeans[i].setTourokujikoku(daikoBeans[j].getTourokujikoku());
						daikoNyryokuBeans[i].setTourokusya(daikoBeans[j].getTourokusya());
						break;
					}
				}
				final PCY_DaikoNyuryokuEJBHome home2 = (PCY_DaikoNyuryokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_DaikoNyuryokuEJBHome.class);
				final PCY_DaikoNyuryokuEJB ejb2 = home2.create();

				ejb2.doInsert(daikoNyryokuBeans, loginuser);

			}
		}

		final HashMap classMap = new HashMap();

		for (int i = 0; i < mousikomiJyokyoBeans.length; i++) {
			for (int j = mousikomiKentouList.size() - 1; j >= 0; j--) { // CHG#2007/3/21 s-hiura
				final PCY_ClassBean[] mousikomiKentouBeans = (PCY_ClassBean[]) mousikomiKentouList.toArray(new PCY_ClassBean[0]); // ADD#2007/3/21 s-hiura
				// �\�������{�����N���X���Z�b�V�����Ɋi�[����Ă���ꍇ
				if (mousikomiJyokyoBeans[i].getKamokuCode().equals(mousikomiKentouBeans[j].getKamokuBean().getKamokuCode())
						&& mousikomiJyokyoBeans[i].getClassCode().equals(mousikomiKentouBeans[j].getClassCode())) {
					// �\�����s�����N���X���Z�b�V�������폜
					mousikomiKentouList.remove(j);
					break;
				}
			}
		}
		// CHG#2007/2/26 s-hiura end
// ADD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V START
        for (PCY_ClassBean c : classBeans) {
            classEJB.doUpdateMansekiFlg(c, loginuser);
        }
// ADD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V END

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();
	}
}
