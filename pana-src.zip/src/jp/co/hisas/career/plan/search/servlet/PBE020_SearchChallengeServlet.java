/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.search.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.sosiki.bean.SosikiBean;
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.plan.search.bean.PBE_SearchChallengeBean;
import jp.co.hisas.career.search.kojin.bean.SearchKojinBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �T�v: �u���E�U���猟���������s�v�����󂯎��A�N���C�A���gBean�̕������̈ꗗ�擾���\�b�h���Ăяo���B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PBE020_SearchChallengeServlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U���猟���������s�v�����󂯎��A�N���C�A���gBean�̃L�����A�`�������W���ꗗ�擾���\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
	 * @param response Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet�̐���ȏ������W����ꂽ���ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = "";
		try {

			final HttpSession session = request.getSession(false);

			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
				login_no = bean.getLogin_no();

				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				// ����SearchChallengeBean�Ăяo��
				PBE_SearchChallengeBean challenge = (PBE_SearchChallengeBean) session.getAttribute("searchChallenge");
				if (challenge == null) {
					challenge = new PBE_SearchChallengeBean(login_no);
					session.setAttribute("searchChallenge", challenge);
				}
				SearchKojinBean kojin = (SearchKojinBean) session.getAttribute("kojin");
				if (kojin == null) {
					kojin = new SearchKojinBean();
					session.setAttribute("kojin", kojin);
				}
				// �����ꗗ���擾����
				final String buRyakusyo[][] = kojin.getBusyo();

				// ���p�����ځA�O����`�l�̎擾
				final String search_kbn = request.getParameter("H101_Kensaku"); // 1:�i���󋵂��猟������A2:�\�͊J���v�悩�猟������A3:�Ј������猟������
				final String engName = (String) ReadFile.fileMapData.get(HcdbDef.searchParam1);
				final String jinRyaku = (String) ReadFile.fileMapData.get(HcdbDef.searchParam2);
				final String yakuMaster = (String) ReadFile.fileMapData.get(HcdbDef.yakusyoku_master);
				String busyoPos = (String) ReadFile.fileMapData.get(HcdbDef.busyo_code);
				final String labelItem1 = (String) ReadFile.paramMapData.get("DZZ002");
				final String labelItem2 = (String) ReadFile.paramMapData.get("DZZ003");
				final String labelItem3 = (String) ReadFile.paramMapData.get("DZZ004");
				final String labelItem4 = (String) ReadFile.paramMapData.get("DZZ005");
				final String labelItem5 = (String) ReadFile.paramMapData.get("DZZ011");
				final String labelItem6 = (String) ReadFile.paramMapData.get("DZZ014");
				final String labelItem7 = (String) ReadFile.paramMapData.get("DZZ114");
				final String labelItem8 = (String) ReadFile.paramMapData.get("DZZ116");
				final String labelItem9 = (String) ReadFile.paramMapData.get("DZZ117");
				final String labelItem10 = (String) ReadFile.paramMapData.get("DZZ118");
				final String labelItem11 = (String) ReadFile.paramMapData.get("DZZ119");
				final String labelItem12 = (String) ReadFile.paramMapData.get("DZZ120");

				// �J���v�敶��
				final String[][] kaihatuPlan = { { "1", labelItem5 }, { "2", labelItem7 }, { "3", labelItem8 }, { "4", labelItem9 }, { "5", labelItem10 }, { "6", labelItem11 }, { "7", labelItem12 } };

				// ��������
				String[] search_cnd;
				String search_condition = "";

				int cndnum;
				// �Z�b�V�����E�I�u�W�F�N�g�ɈȑO�̌�����������������폜����

				session.removeAttribute("Kikan_1");
				session.removeAttribute("Kubun_1");
				session.removeAttribute("Sinchoku");
				session.removeAttribute("Busyo_1");
				session.removeAttribute("Kikan_2");
				session.removeAttribute("Kubun_2");
				session.removeAttribute("KaihatuKeikaku");
				session.removeAttribute("Umu");
				session.removeAttribute("Busyo_2");
				session.removeAttribute("SimeiNo");
				session.removeAttribute("SimeiKanji");
				session.removeAttribute("SimeiKana");
				session.removeAttribute("SimeiEiji");
				session.removeAttribute("Busyo_3");

				switch (Integer.parseInt(search_kbn)) {
				case 1:
					cndnum = 8;
					search_cnd = new String[cndnum];

					if (request.getParameter("S012_Busyo_1") != null && !request.getParameter("S012_Busyo_1").equals("")) {
						busyoPos = SosikiBean.getSosikiByCode(request.getParameter("S012_Busyo_1").trim(), login_no)[4];
					}

					search_cnd[0] = engName;
					search_cnd[1] = jinRyaku;
					search_cnd[2] = yakuMaster;
					search_cnd[3] = busyoPos;

					/* ���������̕ύX */
					search_cnd[4] = PZZ010_CharacterUtil.strEncode(request.getParameter("S003_Kikan_1"));
					search_cnd[5] = request.getParameter("S013_Kubun_1");
					search_cnd[6] = request.getParameter("S014_Sinchoku");
					search_cnd[7] = request.getParameter("S012_Busyo_1");

					session.setAttribute("Kikan_1", search_cnd[4]);
					session.setAttribute("Kubun_1", search_cnd[5]);
					session.setAttribute("Sinchoku", search_cnd[6]);
					session.setAttribute("Busyo_1", search_cnd[7]);

					search_condition = search_cnd[4] + "��";
					if (search_cnd[5].equals(HcdbDef.plan)) {
						search_condition = search_condition + "�v��";
					} else {
						search_condition = search_condition + "����";
					}
					search_condition = search_condition + "��";
					int ind = Integer.parseInt(search_cnd[6]) - 1;
					search_condition = search_condition + HcdbDef.sinchoku[ind][1];
					if (!search_cnd[7].equals("")) {
						search_condition = search_condition + "��<br>����";
						int i;
						for (i = 0; i < buRyakusyo.length; i++) {
							if (buRyakusyo[i][0].equals(search_cnd[7])) {
								break;
							}
						}
						search_condition = search_condition + labelItem6 + "��" + buRyakusyo[i][1];
					}
					search_condition = search_condition + "�ł���";
					break;
				case 2:
					cndnum = 9;
					search_cnd = new String[cndnum];

					if (request.getParameter("S012_Busyo_2") != null && !request.getParameter("S012_Busyo_2").equals("")) {
						busyoPos = SosikiBean.getSosikiByCode(request.getParameter("S012_Busyo_2").trim(), login_no)[4];
					}

					search_cnd[0] = engName;
					search_cnd[1] = jinRyaku;
					search_cnd[2] = yakuMaster;
					search_cnd[3] = busyoPos;

					search_cnd[4] = PZZ010_CharacterUtil.strEncode(request.getParameter("S003_Kikan_2"));
					search_cnd[5] = request.getParameter("S013_Kubun_2");
					search_cnd[6] = request.getParameter("S015_KaihatuKeikaku");
					search_cnd[7] = request.getParameter("S016_Umu");
					search_cnd[8] = request.getParameter("S012_Busyo_2");

					session.setAttribute("Kikan_2", search_cnd[4]);
					session.setAttribute("Kubun_2", search_cnd[5]);
					session.setAttribute("KaihatuKeikaku", search_cnd[6]);
					session.setAttribute("Umu", search_cnd[7]);
					session.setAttribute("Busyo_2", search_cnd[8]);

					search_condition = search_cnd[4] + "��";
					if (search_cnd[5].equals(HcdbDef.plan)) {
						search_condition = search_condition + "�v��";
					} else {
						search_condition = search_condition + "����";
					}
					search_condition = search_condition + "��";
					ind = Integer.parseInt(search_cnd[6]) - 1;
					search_condition = search_condition + kaihatuPlan[ind][1] + "��";
					if (search_cnd[7].equals("1")) {
						search_condition = search_condition + "����";
					} else {
						search_condition = search_condition + "�Ȃ�";
					}
					if (!search_cnd[8].equals("")) {
						search_condition = search_condition + "<br>����";
						int i;
						for (i = 0; i < buRyakusyo.length; i++) {
							if (buRyakusyo[i][0].equals(search_cnd[8])) {
								break;
							}
						}
						search_condition = search_condition + labelItem6 + "��" + buRyakusyo[i][1] + "�ł���";
					}
					break;
				case 3:
					cndnum = 9;
					search_cnd = new String[cndnum];

					if (request.getParameter("S012_Busyo_3") != null && !request.getParameter("S012_Busyo_3").equals("")) {
						busyoPos = SosikiBean.getSosikiByCode(request.getParameter("S012_Busyo_3").trim(), login_no)[4];
					}

					search_cnd[0] = engName;
					search_cnd[1] = jinRyaku;
					search_cnd[2] = yakuMaster;
					search_cnd[3] = busyoPos;
					search_cnd[4] = PZZ010_CharacterUtil.changeQuotation(PZZ010_CharacterUtil.strEncode(request.getParameter("T001_SimeiNo")));
					search_cnd[5] = PZZ010_CharacterUtil.changeQuotation(PZZ010_CharacterUtil.strEncode(request.getParameter("T002_SimeiKanji")));
					search_cnd[6] = PZZ010_CharacterUtil.changeQuotation(PZZ010_CharacterUtil.strEncode(request.getParameter("T003_SimeiKana")));
					search_cnd[7] = "";
					search_cnd[8] = request.getParameter("S012_Busyo_3");
					final String snoOut = PZZ010_CharacterUtil.strEncode(request.getParameter("T001_SimeiNo"));
					final String skjOut = PZZ010_CharacterUtil.strEncode(request.getParameter("T002_SimeiKanji"));
					final String sknOut = PZZ010_CharacterUtil.strEncode(request.getParameter("T003_SimeiKana"));
					String senOut = "";

					if (engName.equals("1")) {
						/* ���������w���ʂœ��͂��������p�����擾���� */
						search_cnd[7] = PZZ010_CharacterUtil.changeQuotation(PZZ010_CharacterUtil.strEncode(request.getParameter("T014_SimeiEiji")));
						senOut = PZZ010_CharacterUtil.strEncode(request.getParameter("T014_SimeiEiji"));
					}

					session.setAttribute("SimeiNo", search_cnd[4]);
					session.setAttribute("SimeiKanji", search_cnd[5]);
					session.setAttribute("SimeiKana", search_cnd[6]);
					session.setAttribute("SimeiEiji", search_cnd[7]);
					session.setAttribute("Busyo_3", search_cnd[8]);

					if (!search_cnd[4].equals("")) {
						search_condition = labelItem1 + "��" + snoOut + "�Ŏn�܂�";
					}
					if (!search_cnd[5].equals("")) {
						if (!search_condition.equals("")) {
							search_condition = search_condition + " ���� ";
						}
						search_condition = search_condition + labelItem2 + "��" + skjOut + "�Ŏn�܂�";
					}
					if (!search_cnd[6].equals("")) {
						if (!search_condition.equals("")) {
							search_condition = search_condition + " ���� ";
						}
						search_condition = search_condition + labelItem3 + "��" + sknOut + "�Ŏn�܂�";
					}
					if (engName.equals("1") && !search_cnd[7].equals("")) {
						if (!search_condition.equals("")) {
							search_condition = search_condition + " ���� ";
						}
						search_condition = search_condition + labelItem4 + "��" + senOut + "�Ŏn�܂�";
					}
					if (!search_cnd[8].equals("")) {
						if (!search_condition.equals("")) {
							search_condition = search_condition + "<br>����";
						}
						int i;
						for (i = 0; i < buRyakusyo.length; i++) {
							if (buRyakusyo[i][0].equals(search_cnd[8])) {
								break;
							}
						}
						search_condition = search_condition + labelItem6 + "��" + buRyakusyo[i][1] + "�ł���";
					}
					break;
				default:
					final RequestDispatcher rd = this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp");
					rd.forward(request, response);
					return;
				}

				if (search_condition.equals("")) {
					search_condition = "�Ȃ�";
				} else {
					search_condition = search_condition + "�B";
				}

				// �����������s��
				/* ���������̎��s */
				challenge.search_challenge_list(search_kbn, search_cnd);
				OutLogBean.sousaKojinJohoLog("VBE030", login_no, null, search_condition.replaceAll("<br>", ""));
				// �Z�b�V�����E�I�u�W�F�N�g���i�[����
				session.setAttribute("searchCondition", search_condition);

				// JSP�y�[�W���Ăяo��
				final RequestDispatcher rd = this.ctx.getRequestDispatcher("/view/plan/search/VBE030_ChallengeResMain.jsp");
				rd.forward(request, response);

				// Log�o��
				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}
}
