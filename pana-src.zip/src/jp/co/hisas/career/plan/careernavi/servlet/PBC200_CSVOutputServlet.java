/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.careernavi.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Writer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.plan.base.VelocityHelper;
import jp.co.hisas.career.plan.careernavi.bean.PBC_DownloadNaviBeanList;
import jp.co.hisas.career.plan.careernavi.ejb.PBC_DownloadNaviEJB;
import jp.co.hisas.career.plan.careernavi.ejb.PBC_DownloadNaviEJBHome;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �T�v: �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PBC200_CSVOutputServlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U���瑗�M���ꂽ�l���󂯎��A���������s����B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequest�I�u�W�F�N�g
	 * @param response Servlet ����̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet �̐���ȏ������W����ꂽ�Ƃ��ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = "";
		
		try {

			final HttpSession session = request.getSession(false);
			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
				login_no = bean.getLogin_no();

				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				PBC_DownloadNaviBeanList list = null;

				// EJB�擾
				final PBC_DownloadNaviEJBHome my_home = (PBC_DownloadNaviEJBHome) EJBHomeFactory.getInstance().lookup(PBC_DownloadNaviEJBHome.class);
				final PBC_DownloadNaviEJB ejb = my_home.create();

				final String senimoto_id = request.getParameter("senimoto_id");
				if ("VBC200_IKKATU".equals(senimoto_id)) {
					final String sosiki_code = request.getParameter("S001_sosiki_code");

					Log.transaction(login_no, true, "");
					list = ejb.getNavigationList(login_no, sosiki_code);
					Log.transaction(login_no, false, "");
				} else if ("Sample".equals(senimoto_id)) {
					final String syoku_code = request.getParameter("S001_syoku_code");
					final String senmon_code = request.getParameter("S002_senmon_code");
					final String level_code = request.getParameter("S003_level_code");

					Log.transaction(login_no, true, "");
					list = ejb.getNavigationList(login_no, syoku_code, senmon_code, level_code);
					Log.transaction(login_no, false, "");
				}

				final StringBuffer fileName = new StringBuffer();
				fileName.append(PZZ010_CharacterUtil.getDayTime());
				fileName.append("_");
				fileName.append("P13_GYOMU_KEIKEN_NAVI_TBL");
				fileName.append(".csv");

				final VelocityHelper vh = new VelocityHelper("VBC010");
				vh.setParameter("BeanList", list);
				final Writer w = vh.getWriter();
				final ByteArrayInputStream bais = new ByteArrayInputStream(w.toString().getBytes());
				request.setAttribute("H080_FileName", fileName.toString());
				request.setAttribute("H081_ContentType", HcdbDef.CONTENT_TYPE);
				request.setAttribute("STREAM", bais);

				final RequestDispatcher rd = this.ctx.getRequestDispatcher("/servlet/PYE010_FileDownloadServlet");
				rd.forward(request, response);

				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}
}
