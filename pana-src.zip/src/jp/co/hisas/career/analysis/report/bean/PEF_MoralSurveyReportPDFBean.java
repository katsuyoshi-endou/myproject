/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.analysis.report.bean;

import java.awt.Color;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;

import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;

public class PEF_MoralSurveyReportPDFBean {

	/** �^�C�g�� */
	private String msgDEF028 = null;

	/** �W�v�Ώۃ��x�� */
	private String msgDEF076 = null;

	/** �W�v���ԃ��x�� */
	private String msgDEF029 = null;

	/** �W�v��ʃ��x�� */
	private String msgDEF030 = null;

	/** �W�v�P�ʃ��x�� */
	private String msgDEF031 = null;

	/** �W�v�P�ʁi�g�D�j */
	private String msgDEF005 = null;

	/** �R�����g */
	private String msgDEF032 = null;

	/** �W�v�������x�� */
	private String msgDEF033 = null;

	/** �}�჉�x�� */
	private String msgDEF034 = null;

	/** ���������x�� */
	private String msgDEF035 = null;

	/** �������������x�� */
	private String msgDEF036 = null;

	/** �������x�� */
	private String msgDEF037 = null;

	/** �����������x�� */
	private String msgDEF038 = null;

	/** �ԕ������x�� */
	private String msgDEF039 = null;

	/** �ԕ����������x�� */
	private String msgDEF040 = null;

	/** �S�Е��σ��x�� */
	private String msgDEF041 = null;

	/** �g�D�����x�� */
	private String msgDEF010 = null;

	/** �W�v�P�ʖ�E */
	private String msgDEF006 = null;

	/** �R�����g */
	private String msgDEF042 = null;

	/** ��E�����x�� */
	private String msgDEF013 = null;

	/** 9�s�� */
	private String msgDEF014 = null;

	/** 8�s�� */
	private String msgDEF015 = null;

	/** 7�s�� */
	private String msgDEF016 = null;

	/** 6�s�� */
	private String msgDEF017 = null;

	/** 5�s�� */
	private String msgDEF018 = null;

	/** 4�s�� */
	private String msgDEF019 = null;

	/** 3�s�� */
	private String msgDEF020 = null;

	/** 2�s�� */
	private String msgDEF021 = null;

	/** 1�s�� */
	private String msgDEF022 = null;

	/** ���� */
	private String msgDEF011 = null;

	/** �W�v�P�ʁi�N��j */
	private String msgDEF007 = null;

	/** �R�����g */
	private String msgDEF044 = null;

	/** �N�ド�x�� */
	private String msgDEF043 = null;

	/** 1�s�� */
	private String msgDEF023 = null;

	/** 2�s�� */
	private String msgDEF024 = null;

	/** 3�s�� */
	private String msgDEF025 = null;

	/** 4�s�� */
	private String msgDEF026 = null;

	/** 5�s�� */
	private String msgDEF027 = null;

	/** "*" */
	private String msgDEF012 = null;

	/** �W�v�P�ʃ��x�� */
	private String msgDEF003 = null;

	// PDF�o�͕ϐ�
	private Document document;

	/** ������ */
	private String bushoNm;

	/** �����R�[�h */
	private String bushoCd;

	/** �W�v���� */
	private String shukeiKikan;

	/** �W�v��� */
	private String shukeiType;

	/** �����[���T�[�x�C臒l */
	private double thresHold;

	/** ���f�[�^�̍��ڐ� */
	private int maxCol;

	/** ���ډ����T�C�Y */
	private int rightColumnMaxColSize;

	/** �f�[�^�����ڐ��i�w�b�_�[�����͂ݏo�������j */
	private int rigthNum;

	/** �\���ŏ��l�� */
	private int minGroupNum;

	/** �f�t�H���g�t�H���g�i�f�[�^���j */
	private Font font;

	/** �t�H���g�ԕ��� */
	private Font fontRed;

	/** �t�H���g���� */
	private Font fontBlue;

	/** �󕶎��{�{�[�_�[�L */
	private PdfPCell spaceBorderOn;

	/** �󕶎��{�{�[�_�[�� */
	private PdfPCell spaceBorderOff;

	/** �w�b�_�����̍ő�J������ */
	private static final int HEADER_UNDER_MAX_COL = 17;

	/** �ő��E�K�w */
	private static final int MAX_YAKUSHOKU_KAISO = 9;

	/** �ő�N�㐔 */
	private static final int MAX_NENDAI_NUM = 5;

	/** �f�t�H���g�̐��̑��� */
	private static final float LINE_BORDER = 1.0f;

	/**
	 * �R���X�g���N�^
	 * 
	 * <pre>
	 *  �p�����[�^������
	 *  @param shukeiTaisho �W�v�Ώ�
	 *  @param shukeiKikan �W�v����
	 *  @param shukeiType �W�v���
	 * 
	 */
	public PEF_MoralSurveyReportPDFBean(final String shukeiTaisho, final String shukeiKikan, final String shukeiType, final String bushoCd, final String bushoNm, final Document document) {

		this.document = document;
		this.shukeiKikan = shukeiKikan;
		this.shukeiType = shukeiType;
		this.bushoCd = bushoCd;
		this.bushoNm = bushoNm;
		this.msgDEF003 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF003"));

		this.msgDEF028 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF028"));
		this.msgDEF029 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF029"));
		this.msgDEF030 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF030"));
		this.msgDEF031 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF031"));
		this.msgDEF005 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF005"));
		this.msgDEF032 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF032"));
		this.msgDEF033 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF033"));
		this.msgDEF034 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF034"));
		this.msgDEF035 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF035"));
		this.msgDEF036 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF036"));
		this.msgDEF037 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF037"));
		this.msgDEF038 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF038"));
		this.msgDEF039 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF039"));
		this.msgDEF040 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF040"));
		this.msgDEF041 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF041"));
		this.msgDEF010 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF010"));
		this.msgDEF006 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF006"));
		this.msgDEF042 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF042"));
		this.msgDEF013 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF013"));
		this.msgDEF014 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF014"));
		this.msgDEF015 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF015"));
		this.msgDEF016 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF016"));
		this.msgDEF017 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF017"));
		this.msgDEF018 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF018"));
		this.msgDEF019 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF019"));
		this.msgDEF020 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF020"));
		this.msgDEF021 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF021"));
		this.msgDEF022 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF022"));
		this.msgDEF007 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF007"));
		this.msgDEF044 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF044"));
		this.msgDEF043 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF043"));
		this.msgDEF023 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF023"));
		this.msgDEF024 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF024"));
		this.msgDEF025 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF025"));
		this.msgDEF026 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF026"));
		this.msgDEF027 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF027"));
		this.msgDEF012 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF012"));
		this.msgDEF076 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF076"));
		this.msgDEF011 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF011"));
	}

	/**
	 * PDF�f�[�^�쐬�i�g�D�p�j
	 * @param valueBean PDF�쐬�p�f�[�^
	 * @return byte[] PDF�f�[�^
	 */
	public void makePdfSoshiki(final PEF_MoralSurveyReportPDFValueBean valueBean) throws DocumentException, IOException {

		this.document.add(this.getHeader(this.msgDEF032));
		// �f�[�^�ŗp����font�錾
		this.setFont();

		// �����[���T�[�x�C臒l
		this.thresHold = valueBean.getThresHold();
		this.rightColumnMaxColSize = (int) 66.8 / PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL + 1;
		this.minGroupNum = valueBean.getMinGroupNum();

		// �e�[�u���̕`��
		final PdfPTable table = new PdfPTable(2);
		table.setSplitLate(false);
		table.setWidthPercentage(100);
		table.setWidths(new float[] { 10, 90 });
		table.getDefaultCell().setPadding(0f);

		// �I��g�D�ɑ�����g�D
		final ArrayList sosikiList = valueBean.getSortSoshikiList();

		// �l�X�g�p�g�D�}�b�v
		final HashMap sosikiMap = valueBean.getNestSoshikiMap();

		// �g�D�^�C�g�����쐬
		// �g�D�����[�v
		PdfPTable sosikiNest = null;
		final PdfPCell[] nestCell = new PdfPCell[10];

		nestCell[0] = new PdfPCell(new Paragraph("", this.font));
		nestCell[1] = new PdfPCell(new Paragraph("", this.font));
		nestCell[2] = new PdfPCell(new Paragraph("", this.font));

		nestCell[0].setBorder(Rectangle.NO_BORDER);

		nestCell[1].setBorderWidthBottom(Rectangle.NO_BORDER);
		nestCell[1].setBorderWidthTop(Rectangle.NO_BORDER);

		nestCell[2].setBorder(Rectangle.NO_BORDER);
		nestCell[2].setBorderWidthBottom(Rectangle.NO_BORDER);
		nestCell[2].setBorderWidthTop(Rectangle.NO_BORDER);

		final PdfPTable mainLeftTable = new PdfPTable(1);
		mainLeftTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		mainLeftTable.getDefaultCell().setBorderWidthBottom(Rectangle.NO_BORDER);

		// �g�D�����x��
		PdfPCell cell = new PdfPCell(new Paragraph(this.msgDEF010, this.font));
		cell.setMinimumHeight(30f);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		mainLeftTable.addCell(cell);

		// ��Е��σ��x��
		cell = new PdfPCell(new Paragraph(this.msgDEF041, this.font));
		cell.setMinimumHeight(30f);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		mainLeftTable.addCell(cell);

		for (int i = 0, num = sosikiList.size(); i < num; i++) {

			final String[] sosiki = (String[]) sosikiList.get(i);
			final int nest = PEF_MoralSurveyReportPDFBean.getNest(sosiki[0], sosikiMap);
			sosikiNest = new PdfPTable(2);
			sosikiNest.getDefaultCell().setMinimumHeight(30f);

			if (i == 0) {
				cell = new PdfPCell(new Paragraph(sosiki[1], this.font));
				cell.setBorder(Rectangle.NO_BORDER);
				cell.setMinimumHeight(30f);
				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				mainLeftTable.addCell(cell);
				mainLeftTable.getDefaultCell().setPadding(0f);
				mainLeftTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			} else {
				if (nest == 0) {
					sosikiNest = new PdfPTable(2);
					sosikiNest.setWidths(new float[] { 10, 90 });

					// �l�X�g
					for (int j = 0; j <= nest; j++) {
						sosikiNest.addCell(nestCell[j]);
					}

					final PdfPCell sosikiCell = new PdfPCell(new Paragraph(sosiki[1], this.font));
					sosikiCell.setMinimumHeight(30f);
					sosikiCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
					sosikiCell.setHorizontalAlignment(Element.ALIGN_CENTER);
					sosikiCell.setBorderWidthBottom(Rectangle.NO_BORDER);
					sosikiCell.setBorderWidthRight(Rectangle.NO_BORDER);

					sosikiNest.addCell(sosikiCell);

				} else if (nest == 1) {
					sosikiNest = new PdfPTable(3);
					sosikiNest.setWidths(new float[] { 10, 10, 80 });

					sosikiNest.setWidthPercentage(100);
					sosikiNest.getDefaultCell().setBorderWidth(Rectangle.NO_BORDER);

					nestCell[1].setBorderWidthBottom(PEF_MoralSurveyReportPDFBean.LINE_BORDER);
					nestCell[1].setBorderWidthRight(Rectangle.NO_BORDER);
					final Color whiteColor = new Color(255, 255, 255);
					if (i != num - 1) {
						nestCell[1].setBorderColorBottom(whiteColor);
					} else {
						final Color blackColor = new Color(0, 0, 0);
						nestCell[1].setBorderWidthBottom(0.2f);
						nestCell[1].setBorderColorBottom(blackColor);
					}

					sosikiNest.addCell(nestCell[0]);
					sosikiNest.addCell(nestCell[1]);

					final PdfPCell sosikiCell = new PdfPCell(new Paragraph(sosiki[1], this.font));
					sosikiCell.setMinimumHeight(30f);
					sosikiCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
					sosikiCell.setHorizontalAlignment(Element.ALIGN_CENTER);
					sosikiCell.setBorderWidthBottom(Rectangle.NO_BORDER);
					sosikiCell.setBorderWidthRight(Rectangle.NO_BORDER);
					sosikiNest.addCell(sosikiCell);
				} else if (nest == 2) {
					sosikiNest = new PdfPTable(4);
					sosikiNest.setWidths(new float[] { 10, 10, 10, 70 });
					// �l�X�g
					for (int j = 0; j <= nest; j++) {
						sosikiNest.addCell(nestCell[j]);
					}

					final PdfPCell sosikiCell = new PdfPCell(new Paragraph(sosiki[1], this.font));
					sosikiCell.setMinimumHeight(30f);
					sosikiCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
					sosikiCell.setHorizontalAlignment(Element.ALIGN_CENTER);
					sosikiCell.setBorderWidthBottom(Rectangle.NO_BORDER);
					sosikiNest.addCell(sosikiCell);
				}
				sosikiNest.addCell(this.spaceBorderOn);
				mainLeftTable.addCell(sosikiNest);
			}
		}
		table.addCell(mainLeftTable);

		// ���ڎ擾
		final ArrayList komokuList = valueBean.getMoralList();
		// ���ڐ��擾
		this.maxCol = komokuList.size();;

		// PDF�f�[�^�}�b�v�擾
		final HashMap pdfMap = valueBean.getPdfMap();

		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		// ���������P�F�\�����鍀�ڂ̑��������w�b�_�[�����������ꍇ
		if (this.maxCol > PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL) {

			this.rigthNum = this.maxCol - PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL;

			// �f�[�^���̃e�[�u���쐬
			final PdfPTable mainRightTable = new PdfPTable(2);
			mainRightTable.setWidths(new float[] { (float) 66.85, (float) 33.15 });
			mainRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			mainRightTable.getDefaultCell().setPadding(0f);

			// ���ڍ쐬
			this.setKomokuRecordOver(valueBean, mainRightTable);

			table.addCell(mainRightTable);

			mainRightTable.setWidths(new float[] { (float) 66.85, (float) 33.15 });

			// �f�[�^���쐬

			// �S�Е��ύ쐬
			this.setZenshaRecordOver(valueBean, mainRightTable);

			// �g�D�����[�v
			for (int j = 0, num = sosikiList.size(); j < num; j++) {

				// �f�[�^�擾�̃L�[���擾
				final String dataKey = ((String[]) sosikiList.get(j))[0];
				final int nest = PEF_MoralSurveyReportPDFBean.getNest(dataKey, sosikiMap);
				if (0 <= nest && nest <= 2 || j == 0) {
					// �Y���g�D�̃f�[�^�擾
					final ArrayList dataList = (ArrayList) pdfMap.get(dataKey);
					// �Y���g�D�̑O���ԃf�[�^�擾
					final ArrayList preDataList = (ArrayList) pdfMap.get(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + dataKey);
					// �Y���g�D�̐l���擾
					final int groupNum = ((Integer) pdfMap.get(PEF_MoralSurveyReportPDFValueBean.GROUP_NUM + dataKey)).intValue();

					int recordeNum = 2;
					if (j == num - 1) {
						recordeNum = 0;
					} else if (j == 0) {
						recordeNum = 1;
					}
					// �f�[�^���쐬
					this.setDataRecordOver(valueBean, mainRightTable, dataList, preDataList, groupNum, recordeNum);
				}
			}
			table.addCell(mainRightTable);

			// 17�ȉ�
		} else {
			this.rigthNum = this.maxCol - PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL;

			final PdfPTable mainRightTable = new PdfPTable(2);

			mainRightTable.setWidths(new float[] { (float) 66.85, (float) 33.15 });
			final PdfPTable mainRightSubLeftTable = new PdfPTable(17);
			final PdfPTable mainRightSubRightTable = new PdfPTable(1);
			mainRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			mainRightSubRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			mainRightTable.getDefaultCell().setPadding(0f);

			// ���ڍ쐬
			this.setKomokuRecordUnder(valueBean, mainRightSubLeftTable);
			// �S�Е���
			this.setZenshaRecordUnder(valueBean, mainRightSubLeftTable);

			mainRightSubRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			// �g�D�����[�v
			for (int j = 0, num = sosikiList.size(); j < num; j++) {

				// �f�[�^�擾�̃L�[���擾
				final String dataKey = ((String[]) sosikiList.get(j))[0];
				final int nest = PEF_MoralSurveyReportPDFBean.getNest(dataKey, sosikiMap);
				if (0 <= nest && nest <= 2 || j == 0) {
					// �Y���g�D�̃f�[�^�擾
					final ArrayList dataList = (ArrayList) pdfMap.get(dataKey);
					// �Y���g�D�̑O���ԃf�[�^�擾
					final ArrayList preDataList = (ArrayList) pdfMap.get(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + dataKey);
					// �Y���g�D�̐l���擾
					final int groupNum = ((Integer) pdfMap.get(PEF_MoralSurveyReportPDFValueBean.GROUP_NUM + dataKey)).intValue();
					int recordeNum = 2;
					if (j == num - 1) {
						recordeNum = 0;
					} else if (j == 0) {
						recordeNum = 1;
					}
					this.setDataRecordUnder(valueBean, mainRightSubLeftTable, dataList, preDataList, groupNum, recordeNum);

					mainRightSubRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				}

			}
			mainRightTable.addCell(mainRightSubLeftTable);
			mainRightTable.addCell(mainRightSubRightTable);
			table.addCell(mainRightTable);
		}

		this.document.add(table);
	}

	/**
	 * PDF�f�[�^�쐬�i��E�p�j
	 * @param valueBean PDF�쐬�p�f�[�^
	 * @return byte[] PDF�f�[�^
	 */
	public void makePdfYakushoku(final PEF_MoralSurveyReportPDFValueBean valueBean) throws DocumentException, IOException {

		// �w�b�_�[���쐬
		this.document.add(this.getHeader(this.msgDEF042));

		// �f�[�^�ŗp����font�錾
		this.setFont();

		// �����[���T�[�x�C臒l
		this.thresHold = valueBean.getThresHold();
		this.rightColumnMaxColSize = (int) 66.8 / PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL + 1;
		this.minGroupNum = valueBean.getMinGroupNum();

		// �e�[�u���̕`��
		final PdfPTable table = new PdfPTable(2);

		table.setWidthPercentage(100);
		table.setWidths(new float[] { 10, 90 });
		table.getDefaultCell().setPadding(0f);

		final PdfPCell[] nestCell = new PdfPCell[10];

		nestCell[0] = new PdfPCell(new Paragraph("", this.font));
		nestCell[1] = new PdfPCell(new Paragraph("", this.font));
		nestCell[2] = new PdfPCell(new Paragraph("", this.font));

		nestCell[0].setBorder(Rectangle.NO_BORDER);

		nestCell[1].setBorderWidthBottom(Rectangle.NO_BORDER);
		nestCell[1].setBorderWidthTop(Rectangle.NO_BORDER);

		nestCell[2].setBorder(Rectangle.NO_BORDER);
		nestCell[2].setBorderWidthBottom(Rectangle.NO_BORDER);
		nestCell[2].setBorderWidthTop(Rectangle.NO_BORDER);

		final PdfPTable mainLeftTable = new PdfPTable(1);
		mainLeftTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		mainLeftTable.getDefaultCell().setBorderWidthBottom(Rectangle.NO_BORDER);

		// �g�D�����x��
		PdfPCell cell = new PdfPCell(new Paragraph(this.msgDEF010, this.font));
		cell.setMinimumHeight(30f);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		mainLeftTable.addCell(cell);

		// ��Е��σ��x��
		cell = new PdfPCell(new Paragraph(this.msgDEF041, this.font));
		cell.setMinimumHeight(30f);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		mainLeftTable.addCell(cell);

		mainLeftTable.getDefaultCell().setPadding(0f);
		mainLeftTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		final String[] key = new String[] { this.msgDEF014, this.msgDEF015, this.msgDEF016, this.msgDEF017, this.msgDEF018, this.msgDEF019, this.msgDEF020, this.msgDEF021, this.msgDEF022 };
		for (int i = PEF_MoralSurveyReportPDFBean.MAX_YAKUSHOKU_KAISO - 1; i >= 0; i--) {
			cell = new PdfPCell(new Paragraph(key[i], this.font));
			cell.setMinimumHeight(30f);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			mainLeftTable.addCell(cell);
		}
		table.addCell(mainLeftTable);

		// ���ڎ擾
		final ArrayList komokuList = valueBean.getMoralList();
		// ���ڐ��擾
		this.maxCol = komokuList.size();;

		// PDF�f�[�^�}�b�v�擾
		final HashMap pdfMap = valueBean.getPdfMap();

		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		// �\���Œ�l���擾
		this.minGroupNum = valueBean.getMinGroupNum();

		// ���������P�F�\�����鍀�ڂ̑��������w�b�_�[�����������ꍇ
		if (this.maxCol > PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL) {

			this.rigthNum = this.maxCol - PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL;

			// �f�[�^���̃e�[�u���쐬
			final PdfPTable mainRightTable = new PdfPTable(2);
			mainRightTable.setWidths(new float[] { (float) 66.85, (float) 33.15 });
			mainRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			mainRightTable.getDefaultCell().setPadding(0f);

			// ���ڍ쐬
			this.setKomokuRecordOver(valueBean, mainRightTable);

			table.addCell(mainRightTable);

			mainRightTable.setWidths(new float[] { (float) 66.85, (float) 33.15 });

			// �f�[�^���쐬

			// �S�Е��ύ쐬
			this.setZenshaRecordOver(valueBean, mainRightTable);

			// ��E�K�w�����[�v
			for (int i = PEF_MoralSurveyReportPDFBean.MAX_YAKUSHOKU_KAISO; i > 0; i--) {

				// �f�[�^�擾�̃L�[���擾
				final String dataKey = String.valueOf(i);

				// �Y���g�D�̃f�[�^�擾
				ArrayList dataList = (ArrayList) pdfMap.get(new Integer(dataKey));
				// �Y���g�D�̑O���ԃf�[�^�擾
				ArrayList preDataList = (ArrayList) pdfMap.get(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + dataKey);
				// �Y���g�D�̐l���擾
				int groupNum = -1;
				final Object workNum = pdfMap.get(PEF_MoralSurveyReportPDFValueBean.GROUP_NUM + dataKey);
				if (workNum != null) {
					try {
						groupNum = ((Integer) workNum).intValue();
					} catch (final ClassCastException e) {
						Log.error("", "HJE-0003", e);
					}
				} else {
					Log.error("", "HJE-0013", null);
				}

				if (dataList == null) {
					dataList = new ArrayList();
					for (int j = 0; j < this.maxCol; j++) {
						dataList.add("");
					}
				}
				if (preDataList == null) {
					preDataList = new ArrayList();
					for (int j = 0; j < this.maxCol; j++) {
						preDataList.add("");
					}
				}
				if (i == 1) {
				}

				int recordeNum = 2;
				if (i == 1) {
					recordeNum = 0;
				} else if (i == PEF_MoralSurveyReportPDFBean.MAX_YAKUSHOKU_KAISO) {
					recordeNum = 1;
				}
				// �f�[�^���쐬
				this.setDataRecordOver(valueBean, mainRightTable, dataList, preDataList, groupNum, recordeNum);

			}
			table.addCell(mainRightTable);

			// 17�ȉ�
		} else {
			this.rigthNum = this.maxCol - PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL;

			final PdfPTable mainRightTable = new PdfPTable(2);

			mainRightTable.setWidths(new float[] { (float) 66.85, (float) 33.15 });
			final PdfPTable mainRightSubLeftTable = new PdfPTable(17);
			final PdfPTable mainRightSubRightTable = new PdfPTable(1);
			mainRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			mainRightSubRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			mainRightTable.getDefaultCell().setPadding(0f);

			// ���ڍ쐬
			this.setKomokuRecordUnder(valueBean, mainRightSubLeftTable);
			// �S�Е���
			this.setZenshaRecordUnder(valueBean, mainRightSubLeftTable);

			mainRightSubRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			// ��E�K�w�����[�v
			for (int i = PEF_MoralSurveyReportPDFBean.MAX_YAKUSHOKU_KAISO; i > 0; i--) {

				// �f�[�^�擾�̃L�[���擾
				final String dataKey = String.valueOf(i);
				// �Y���g�D�̃f�[�^�擾
				ArrayList dataList = (ArrayList) pdfMap.get(new Integer(dataKey));
				// �Y���g�D�̑O���ԃf�[�^�擾
				ArrayList preDataList = (ArrayList) pdfMap.get(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + dataKey);
				// �Y���g�D�̐l���擾
				int groupNum = -1;
				final Object workNum = pdfMap.get(PEF_MoralSurveyReportPDFValueBean.GROUP_NUM + dataKey);
				if (workNum != null) {
					try {
						groupNum = ((Integer) workNum).intValue();
					} catch (final ClassCastException e) {
						Log.error("", "HJE-0003", e);
					}
				} else {
					Log.error("", "HJE-0013", null);
				}

				if (dataList == null) {
					dataList = new ArrayList();
					for (int j = 0; j < this.maxCol; j++) {
						dataList.add("");
					}
				}
				if (preDataList == null) {
					preDataList = new ArrayList();
					for (int j = 0; j < this.maxCol; j++) {
						preDataList.add("");
					}
				}
				int recordeNum = 2;
				if (i == 1) {
					recordeNum = 0;
				} else if (i == PEF_MoralSurveyReportPDFBean.MAX_YAKUSHOKU_KAISO) {
					recordeNum = 1;
				}
				this.setDataRecordUnder(valueBean, mainRightSubLeftTable, dataList, preDataList, groupNum, recordeNum);

				mainRightSubRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			}
			mainRightTable.addCell(mainRightSubLeftTable);
			mainRightTable.addCell(mainRightSubRightTable);
			table.addCell(mainRightTable);
		}

		this.document.add(table);

	}

	/**
	 * PDF�f�[�^�쐬�i�N��p�j
	 * @param valueBean PDF�쐬�p�f�[�^
	 * @return byte[] PDF�f�[�^
	 */
	public void makePdfNendai(final PEF_MoralSurveyReportPDFValueBean valueBean) throws DocumentException, IOException {

		this.document.add(this.getHeader(this.msgDEF044));
		// �f�[�^�ŗp����font�錾
		this.setFont();

		// �����[���T�[�x�C臒l
		this.thresHold = valueBean.getThresHold();
		this.rightColumnMaxColSize = (int) 66.8 / PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL + 1;
		this.minGroupNum = valueBean.getMinGroupNum();

		// �e�[�u���̕`��
		final PdfPTable table = new PdfPTable(2);

		table.setWidthPercentage(100);
		table.setWidths(new float[] { 10, 90 });
		table.getDefaultCell().setPadding(0f);

		final PdfPCell[] nestCell = new PdfPCell[10];

		nestCell[0] = new PdfPCell(new Paragraph("", this.font));
		nestCell[1] = new PdfPCell(new Paragraph("", this.font));
		nestCell[2] = new PdfPCell(new Paragraph("", this.font));

		nestCell[0].setBorder(Rectangle.NO_BORDER);

		nestCell[1].setBorderWidthBottom(Rectangle.NO_BORDER);
		nestCell[1].setBorderWidthTop(Rectangle.NO_BORDER);

		nestCell[2].setBorder(Rectangle.NO_BORDER);
		nestCell[2].setBorderWidthBottom(Rectangle.NO_BORDER);
		nestCell[2].setBorderWidthTop(Rectangle.NO_BORDER);

		final PdfPTable mainLeftTable = new PdfPTable(1);
		mainLeftTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		mainLeftTable.getDefaultCell().setBorderWidthBottom(Rectangle.NO_BORDER);

		// �g�D�����x��
		PdfPCell cell = new PdfPCell(new Paragraph(this.msgDEF010, this.font));
		cell.setMinimumHeight(30f);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		mainLeftTable.addCell(cell);

		// ��Е��σ��x��
		cell = new PdfPCell(new Paragraph(this.msgDEF041, this.font));
		cell.setMinimumHeight(30f);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		mainLeftTable.addCell(cell);

		mainLeftTable.getDefaultCell().setPadding(0f);
		mainLeftTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		final String[] key = new String[] { this.msgDEF023, this.msgDEF024, this.msgDEF025, this.msgDEF026, this.msgDEF027 };
		for (int i = 0; i < PEF_MoralSurveyReportPDFBean.MAX_NENDAI_NUM; i++) {
			cell = new PdfPCell(new Paragraph(key[i], this.font));
			cell.setMinimumHeight(30f);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			mainLeftTable.addCell(cell);
		}
		table.addCell(mainLeftTable);

		// ���ڎ擾
		final ArrayList komokuList = valueBean.getMoralList();
		// ���ڐ��擾
		this.maxCol = komokuList.size();;

		// PDF�f�[�^�}�b�v�擾
		final HashMap pdfMap = valueBean.getPdfMap();

		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		// �\���Œ�l���擾
		this.minGroupNum = valueBean.getMinGroupNum();

		// ���������P�F�\�����鍀�ڂ̑��������w�b�_�[�����������ꍇ
		if (this.maxCol > PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL) {

			this.rigthNum = this.maxCol - PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL;

			// �f�[�^���̃e�[�u���쐬
			final PdfPTable mainRightTable = new PdfPTable(2);
			mainRightTable.setWidths(new float[] { (float) 66.85, (float) 33.15 });
			mainRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			mainRightTable.getDefaultCell().setPadding(0f);

			// ���ڍ쐬
			this.setKomokuRecordOver(valueBean, mainRightTable);

			table.addCell(mainRightTable);

			mainRightTable.setWidths(new float[] { (float) 66.85, (float) 33.15 });

			// �f�[�^���쐬

			// �S�Е��ύ쐬
			this.setZenshaRecordOver(valueBean, mainRightTable);

			// �N�㕪���[�v
			for (int i = 0; i < PEF_MoralSurveyReportPDFBean.MAX_NENDAI_NUM; i++) {

				// �f�[�^�擾�̃L�[���擾
				final String dataKey = String.valueOf(i);
				// �Y���g�D�̃f�[�^�擾
				ArrayList dataList = (ArrayList) pdfMap.get(new Integer(dataKey));
				// �Y���g�D�̑O���ԃf�[�^�擾
				ArrayList preDataList = (ArrayList) pdfMap.get(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + dataKey);
				// �Y���g�D�̐l���擾
				int groupNum = -1;
				final Object workNum = pdfMap.get(PEF_MoralSurveyReportPDFValueBean.GROUP_NUM + dataKey);
				if (workNum != null) {
					try {
						groupNum = ((Integer) workNum).intValue();
					} catch (final ClassCastException e) {
						Log.error("", "HJE-0003", e);
					}
				} else {
					Log.error("", "HJE-0013", null);
				}

				if (dataList == null) {
					dataList = new ArrayList();
					for (int j = 0; j < this.maxCol; j++) {
						dataList.add("");
					}
				}
				if (preDataList == null) {
					preDataList = new ArrayList();
					for (int j = 0; j < this.maxCol; j++) {
						preDataList.add("");
					}
				}
				int recordeNum = 2;
				if (i == PEF_MoralSurveyReportPDFBean.MAX_NENDAI_NUM - 1) {
					recordeNum = 0;
				} else if (i == 0) {
					recordeNum = 1;
				}
				// �f�[�^���쐬
				this.setDataRecordOver(valueBean, mainRightTable, dataList, preDataList, groupNum, recordeNum);

			}
			table.addCell(mainRightTable);

			// 17�ȉ�
		} else {
			this.rigthNum = this.maxCol - PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL;

			final PdfPTable mainRightTable = new PdfPTable(2);

			mainRightTable.setWidths(new float[] { (float) 66.85, (float) 33.15 });
			final PdfPTable mainRightSubLeftTable = new PdfPTable(17);
			final PdfPTable mainRightSubRightTable = new PdfPTable(1);
			mainRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			mainRightSubRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			mainRightTable.getDefaultCell().setPadding(0f);

			// ���ڍ쐬
			this.setKomokuRecordUnder(valueBean, mainRightSubLeftTable);
			// �S�Е���
			this.setZenshaRecordUnder(valueBean, mainRightSubLeftTable);

			mainRightSubRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			// �N�㕪���[�v
			for (int i = 0; i < PEF_MoralSurveyReportPDFBean.MAX_NENDAI_NUM; i++) {

				// �f�[�^�擾�̃L�[���擾
				final String dataKey = String.valueOf(i);
				// �Y���g�D�̃f�[�^�擾
				ArrayList dataList = (ArrayList) pdfMap.get(new Integer(dataKey));
				// �Y���g�D�̑O���ԃf�[�^�擾
				ArrayList preDataList = (ArrayList) pdfMap.get(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + dataKey);
				// �Y���g�D�̐l���擾
				int groupNum = -1;
				final Object workNum = pdfMap.get(PEF_MoralSurveyReportPDFValueBean.GROUP_NUM + dataKey);
				if (workNum != null) {
					try {
						groupNum = ((Integer) workNum).intValue();
					} catch (final ClassCastException e) {
						Log.error("", "HJE-0003", e);
					}
				} else {
					Log.error("", "HJE-0013", null);
				}

				if (dataList == null) {
					dataList = new ArrayList();
					for (int j = 0; j < this.maxCol; j++) {
						dataList.add("");
					}
				}
				if (preDataList == null) {
					preDataList = new ArrayList();
					for (int j = 0; j < this.maxCol; j++) {
						preDataList.add("");
					}
				}
				int recordeNum = 2;
				if (i == PEF_MoralSurveyReportPDFBean.MAX_NENDAI_NUM - 1) {
					recordeNum = 0;
				} else if (i == 0) {
					recordeNum = 1;
				}
				this.setDataRecordUnder(valueBean, mainRightSubLeftTable, dataList, preDataList, groupNum, recordeNum);

				mainRightSubRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			}
			mainRightTable.addCell(mainRightSubLeftTable);
			mainRightTable.addCell(mainRightSubRightTable);
			table.addCell(mainRightTable);
		}
		this.document.add(table);
	}

	/**
	 * PDF�w�b�_�[���̐���
	 */
	private Element getHeader(final String comment) throws DocumentException, IOException {

		// �t�H���g�̒�`
		final BaseFont bf = BaseFont.createFont("HeiseiKakuGo-W5", "UniJIS-UCS2-H", false);
		Font font = new Font(bf, 20, Font.BOLD);

		// �e�[�u���̕`��
		final PdfPTable table = new PdfPTable(4);
		table.setSplitLate(false);
		table.setWidthPercentage((float) 70.17);

		table.setWidths(new float[] { 9.999f, 24.2f, 24, 12 });
		table.setHorizontalAlignment(Element.ALIGN_LEFT);

		// ��s��
		PdfPCell cell = new PdfPCell(new Paragraph(this.msgDEF028, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		cell.setColspan(3);
		table.addCell(cell);

		font = new Font(bf, 11.5f);

		PdfPTable nested2 = new PdfPTable(1);
		nested2 = new PdfPTable(1);
		PdfPTable nested3 = new PdfPTable(2);
		nested3.setWidths(new float[] { 30, 70 });
		cell = new PdfPCell(new Paragraph(this.msgDEF033, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested2.addCell(cell);

		// �V�X�e�����t���擾
		String sysdate = PZZ010_CharacterUtil.GetDay();
		String systime = PZZ010_CharacterUtil.GetTime();

		sysdate = sysdate.substring(0, 4) + "/" + sysdate.substring(4, 6) + "/" + sysdate.substring(6, 8);
		systime = systime.substring(0, 2) + ":" + systime.substring(2, 4);
		cell = new PdfPCell(new Paragraph(sysdate + " " + systime, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested2.addCell(cell);

		// �}��
		cell = new PdfPCell(new Paragraph(this.msgDEF034, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested2.addCell(cell);

		// ���������x���A����
		cell = new PdfPCell(new Paragraph(this.msgDEF035, font));
		PdfPCell cell3 = new PdfPCell(new Paragraph(this.msgDEF036, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested3.addCell(cell);
		nested3.addCell(cell3);

		// �������x���A����
		final Font font2 = new Font(bf, 12);
		font2.setColor(new Color(0, 0, 255));
		cell = new PdfPCell(new Paragraph(this.msgDEF037, font2));
		font = new Font(bf, 12);

		cell3 = new PdfPCell(new Paragraph(this.msgDEF038, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested3.addCell(cell);
		nested3.addCell(cell3);

		nested2.getDefaultCell().setPadding(0f);
		nested2.addCell(nested3);
		table.getDefaultCell().setPadding(0f);
		table.addCell(nested2);

		// ��s��
		// ���� �W�v�Ώۃ��x��
		nested2 = new PdfPTable(1);
		cell = new PdfPCell(new Paragraph(this.msgDEF076, font));

		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested2.getDefaultCell().setPadding(0f);
		nested2.addCell(cell);

		// �W�v���ԃ��x��
		cell = new PdfPCell(new Paragraph(this.msgDEF029, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested2.getDefaultCell().setPadding(0f);
		nested2.addCell(cell);

		// �W�v��ʃ��x��
		cell = new PdfPCell(new Paragraph(this.msgDEF031, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested2.getDefaultCell().setPadding(0f);
		nested2.addCell(cell);

		table.addCell(nested2);

		// ����
		// �W�v�Ώ�
		String taisho = null;
		if (this.bushoNm.equals(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF008")))) {
			taisho = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF008"));
		} else {
			taisho = this.bushoCd + ":" + this.bushoNm;
		}
		nested2 = new PdfPTable(1);
		cell = new PdfPCell(new Paragraph(taisho, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested2.getDefaultCell().setPadding(0f);
		nested2.addCell(cell);

		// �W�v����
		cell = new PdfPCell(new Paragraph(this.shukeiKikan, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested2.getDefaultCell().setPadding(0f);
		nested2.addCell(cell);

		// �W�v���
		cell = new PdfPCell(new Paragraph(this.shukeiType, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested2.getDefaultCell().setPadding(0f);
		nested2.addCell(cell);
		table.addCell(nested2);

		// �O��� �R�����g
		cell = new PdfPCell(new Paragraph(comment, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(cell);

		// �l��� �}��

		nested2 = new PdfPTable(1);
		nested3 = new PdfPTable(2);
		nested3.setWidths(new float[] { 30, 70 });
		final Font font3 = new Font(bf, 12);
		font3.setColor(new Color(255, 0, 0));
		cell = new PdfPCell(new Paragraph(this.msgDEF039, font3));
		font = new Font(bf, 12);
		cell3 = new PdfPCell(new Paragraph(this.msgDEF040, font));

		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested3.addCell(cell);
		nested3.addCell(cell3);
		nested2.getDefaultCell().setPadding(0f);
		nested2.addCell(nested3);
		nested3 = new PdfPTable(1);
		cell = new PdfPCell(new Paragraph("", font));
		nested3.addCell(cell);
		nested2.addCell(nested3);
		table.getDefaultCell().setPadding(0f);
		table.addCell(nested2);
		return table;
	}

	/**
	 * ���ڐ�17�ȏ�̃f�[�^�����R�[�h�̍쐬
	 * @param valueBean PDF�쐬���f�[�^
	 * @param mainRightTable �f�[�^���e�[�u��
	 * @param dataList �����ԃf�[�^
	 * @param preDataList �O���ԃf�[�^
	 * @param groupNum �O���[�v�l��
	 * @param recordeNum 0:�ŏI���R�[�h 1�F�擪���R�[�h 2�F����ȊO
	 */
	private void setDataRecordOver(final PEF_MoralSurveyReportPDFValueBean valueBean, final PdfPTable mainRightTable, final ArrayList dataList, final ArrayList preDataList, final int groupNum,
			final int recordeNum) throws DocumentException {
		final PdfPTable mainRightSubLeftTable = new PdfPTable(PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL);

		mainRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		mainRightTable.getDefaultCell().setPadding(0f);

		PdfPCell cell;

		boolean isMoralSurveyAll = valueBean.isMoralSurveyAll();

		for (int i = 0; i < PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL; i++) {

			final String nowData = (String) dataList.get(i);
			final String preData = (String) preDataList.get(i);

			// �f�[�^���擾
			String data = "";
			// �����[���T�[�x�C�S�ЎQ�ƌ������Ȃ� ���� �Ώۑg�D�l�����Œ�\���l�����Ⴂ�ꍇ *��\��
			if (!isMoralSurveyAll && groupNum < this.minGroupNum) {
				data = this.msgDEF012;
				cell = new PdfPCell(new Paragraph(data, this.font));
			} else {
				// �O���Ԃ̃f�[�^����Ȃ炻�̂܂ܕ\��
				if ("".equals(preData)) {
					cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.font));

				} else if ("".equals(nowData)) {
					cell = new PdfPCell(new Paragraph("", this.font));
				} else {

					if (new Double(nowData).doubleValue() - new Double(preData).doubleValue() > this.thresHold) {
						cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.fontBlue));
						// } else if (new Double(nowData).doubleValue() - (new Double(preData).doubleValue() * -1) > thresHold) {
					} else if ((new Double(nowData).doubleValue() - new Double(preData).doubleValue()) * -1 > this.thresHold) {
						cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.fontRed));
					} else {
						cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.font));
					}
				}
			}
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setMinimumHeight(30f);

			mainRightSubLeftTable.addCell(cell);

		}
		mainRightTable.addCell(mainRightSubLeftTable);

		final PdfPTable mainRightSubRightTable = new PdfPTable((int) 33.2 / this.rightColumnMaxColSize);
		final int rightMaxCol = (int) 33.2 / this.rightColumnMaxColSize;
		final float[] size = new float[rightMaxCol];
		for (int i = 0; i < rightMaxCol; i++) {
			size[i] = this.rightColumnMaxColSize;

		}
		mainRightSubRightTable.setWidths(size);
		for (int i = PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL; i < this.maxCol; i++) {
			final String nowData = (String) dataList.get(i);
			final String preData = (String) preDataList.get(i);

			// �f�[�^���擾
			String data = "";
			// �����[���T�[�x�C�S�ЎQ�ƌ������Ȃ� ���� �Ώۑg�D�l�����Œ�\���l�����Ⴂ�ꍇ *��\��
			if (!isMoralSurveyAll && groupNum < this.minGroupNum) {
				data = this.msgDEF012;
				cell = new PdfPCell(new Paragraph(data, this.font));
			} else {
				// �O���Ԃ̃f�[�^����Ȃ炻�̂܂ܕ\��
				if ("".equals(preData)) {
					cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.font));

				} else if ("".equals(nowData)) {
					cell = new PdfPCell(new Paragraph("", this.font));
				} else {

					if (new Double(nowData).doubleValue() - new Double(preData).doubleValue() > this.thresHold) {
						cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.fontBlue));
						// } else if (new Double(nowData).doubleValue() - (new Double(preData).doubleValue() * -1) > thresHold) {
					} else if ((new Double(nowData).doubleValue() - new Double(preData).doubleValue()) * -1 > this.thresHold) {

						cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.fontRed));
					} else {
						cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.font));
					}
				}
			}
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setMinimumHeight(30f);

			mainRightSubRightTable.addCell(cell);

		}
		for (int i = 0; i < rightMaxCol - this.rigthNum; i++) {
			this.spaceBorderOff.setMinimumHeight(30f);
			mainRightSubRightTable.addCell(this.spaceBorderOff);

		}
		mainRightTable.addCell(mainRightSubRightTable);

	}

	/**
	 * ���ڐ�17�����̃f�[�^�����R�[�h�̍쐬
	 * @param valueBean PDF�쐬���f�[�^
	 * @param mainRightSubLeftTable �f�[�^���e�[�u��
	 * @param dataList �����ԃf�[�^
	 * @param preDataList �O���ԃf�[�^
	 * @param groupNum �O���[�v�l��
	 * @param recordeNum 0:�ŏI���R�[�h 1�F�擪���R�[�h 2�F����ȊO
	 */
	private void setDataRecordUnder(final PEF_MoralSurveyReportPDFValueBean valueBean, final PdfPTable mainRightSubLeftTable, final ArrayList dataList, final ArrayList preDataList,
			final int groupNum, final int recordeNum) {

		boolean isMoralSurveyAll = valueBean.isMoralSurveyAll();

		PdfPCell cell;
		for (int i = 0; i < this.maxCol; i++) {
			final String nowData = (String) dataList.get(i);
			final String preData = (String) preDataList.get(i);

			// �f�[�^���擾
			String data = "";
			// �����[���T�[�x�C�S�ЎQ�ƌ������Ȃ� ���� �Ώۑg�D�l�����Œ�\���l�����Ⴂ�ꍇ *��\��
			if (!isMoralSurveyAll && groupNum < this.minGroupNum) {
				data = this.msgDEF012;
				cell = new PdfPCell(new Paragraph(data, this.font));
			} else {
				// �O���Ԃ̃f�[�^����Ȃ炻�̂܂ܕ\��
				if ("".equals(preData)) {
					cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.font));
				} else if ("".equals(nowData)) {
					cell = new PdfPCell(new Paragraph("", this.font));
				} else {

					if (new Double(nowData).doubleValue() - new Double(preData).doubleValue() > this.thresHold) {
						cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.fontBlue));
						// } else if (new Double(nowData).doubleValue() - (new Double(preData).doubleValue() * -1) > thresHold) {
					} else if ((new Double(nowData).doubleValue() - new Double(preData).doubleValue()) * -1 > this.thresHold) {
						cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.fontRed));
					} else {
						cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.font));
					}
				}
			}
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setMinimumHeight(30f);

			mainRightSubLeftTable.addCell(cell);

		}
		// �󔒕\��
		for (int i = 0; i < PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL - this.maxCol; i++) {
			this.spaceBorderOff.setMinimumHeight(30f);
			mainRightSubLeftTable.addCell(this.spaceBorderOff);

		}

	}

	/**
	 * ����17�ȏ�̑S�Е��σ��R�[�h�̍쐬
	 * @param valueBean PDF�쐬���f�[�^
	 * @param mainRightTable �f�[�^���e�[�u��
	 */
	private void setZenshaRecordOver(final PEF_MoralSurveyReportPDFValueBean valueBean, final PdfPTable mainRightTable) throws DocumentException {

		mainRightTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		mainRightTable.getDefaultCell().setPadding(0f);

		// �f�[�^�擾�̃L�[���擾
		final HashMap zenshaMap = valueBean.getAllPdfMap();
		// �����̃f�[�^�擾
		final ArrayList dataList = (ArrayList) zenshaMap.get(PEF_MoralSurveyReportPDFValueBean.ALL_SHAIN);
		// �O���ԃf�[�^�擾
		final ArrayList preDataList = (ArrayList) zenshaMap.get(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + PEF_MoralSurveyReportPDFValueBean.ALL_SHAIN);

		final PdfPTable mainRightSubLeftTable = new PdfPTable(PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL);
		PdfPCell cell;
		for (int i = 0; i < PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL; i++) {

			final String nowData = (String) dataList.get(i);
			final String preData = (String) preDataList.get(i);

			// �O���Ԃ̃f�[�^����Ȃ炻�̂܂ܕ\��
			if ("".equals(preData) || "".equals(nowData)) {
				cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.font));
			} else {

				if (new Double(nowData).doubleValue() - new Double(preData).doubleValue() > this.thresHold) {
					cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.fontBlue));
					// } else if (new Double(nowData).doubleValue() - (new Double(preData).doubleValue() * -1) > thresHold) {
				} else if ((new Double(nowData).doubleValue() - new Double(preData).doubleValue()) * -1 > this.thresHold) {
					cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.fontRed));
				} else {
					cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.font));
				}
			}

			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setMinimumHeight(30f);
			mainRightSubLeftTable.addCell(cell);

		}
		mainRightTable.addCell(mainRightSubLeftTable);

		final PdfPTable mainRightSubRightTable = new PdfPTable((int) 33.2 / this.rightColumnMaxColSize);
		final int rightMaxCol = (int) 33.2 / this.rightColumnMaxColSize;
		final float[] size = new float[rightMaxCol];
		for (int i = 0; i < rightMaxCol; i++) {
			size[i] = this.rightColumnMaxColSize;

		}
		mainRightSubRightTable.setWidths(size);
		for (int i = PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL; i < this.maxCol; i++) {
			final String nowData = (String) dataList.get(i);
			final String preData = (String) preDataList.get(i);

			// �����[���T�[�x�C�S�ЎQ�ƌ������Ȃ� ���� �Ώۑg�D�l�����Œ�\���l�����Ⴂ�ꍇ *��\��
			// �O���Ԃ̃f�[�^����Ȃ炻�̂܂ܕ\��
			if ("".equals(preData) || "".equals(nowData)) {
				cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.font));
			} else {

				if (new Double(nowData).doubleValue() - new Double(preData).doubleValue() > this.thresHold) {
					cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.fontBlue));
					// } else if (new Double(nowData).doubleValue() - (new Double(preData).doubleValue() * -1) > thresHold) {
				} else if ((new Double(nowData).doubleValue() - new Double(preData).doubleValue()) * -1 > this.thresHold) {
					cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.fontRed));
				} else {
					cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.font));
				}
			}

			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setMinimumHeight(30f);
			mainRightSubRightTable.addCell(cell);

		}
		for (int i = 0; i < rightMaxCol - this.rigthNum; i++) {
			this.spaceBorderOff.setMinimumHeight(30f);
			mainRightSubRightTable.addCell(this.spaceBorderOff);

		}
		mainRightTable.addCell(mainRightSubRightTable);

	}

	/**
	 * ����17�����̑S�Е��σ��R�[�h�̍쐬
	 * @param valueBean PDF�쐬���f�[�^
	 * @param mainRightTable �f�[�^���e�[�u��
	 */
	private void setZenshaRecordUnder(final PEF_MoralSurveyReportPDFValueBean valueBean, final PdfPTable mainRightSubLeftTable) {

		// �S�Е���
		// �f�[�^�擾�̃L�[���擾
		final HashMap zenshaMap = valueBean.getAllPdfMap();
		// �����̃f�[�^�擾
		final ArrayList dataList = (ArrayList) zenshaMap.get(PEF_MoralSurveyReportPDFValueBean.ALL_SHAIN);
		// �O���ԃf�[�^�擾
		final ArrayList preDataList = (ArrayList) zenshaMap.get(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + PEF_MoralSurveyReportPDFValueBean.ALL_SHAIN);

		PdfPCell cell;

		for (int i = 0; i < this.maxCol; i++) {
			final String nowData = (String) dataList.get(i);
			final String preData = (String) preDataList.get(i);

			// �O���Ԃ̃f�[�^����Ȃ炻�̂܂ܕ\��
			if ("".equals(preData)) {
				cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.font));
			} else {

				if (new Double(nowData).doubleValue() - new Double(preData).doubleValue() > this.thresHold) {
					cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.fontBlue));
					// } else if (new Double(nowData).doubleValue() - (new Double(preData).doubleValue() * -1) > thresHold) {
				} else if ((new Double(nowData).doubleValue() - new Double(preData).doubleValue()) * -1 > this.thresHold) {
					cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.fontRed));
				} else {
					cell = new PdfPCell(new Paragraph(this.numberFormat(nowData), this.font));
				}
			}

			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setMinimumHeight(30f);
			mainRightSubLeftTable.addCell(cell);

		}
		// �󔒕\��
		for (int i = 0; i < PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL - this.maxCol; i++) {
			this.spaceBorderOff.setMinimumHeight(30f);
			mainRightSubLeftTable.addCell(this.spaceBorderOff);

		}

	}

	/**
	 * �t�B�[���h�ϐ��̏�����
	 * 
	 * <pre>
	 *  font�錾
	 *  CELL�錾
	 * 
	 */
	private void setFont() throws DocumentException, IOException {
		final BaseFont bf = BaseFont.createFont("HeiseiKakuGo-W5", "UniJIS-UCS2-H", false);
		this.font = new Font(bf, 7);

		this.fontRed = new Font(bf, 7);
		this.fontRed.setColor(new Color(255, 0, 0));

		this.fontBlue = new Font(bf, 7);
		this.fontBlue.setColor(new Color(0, 0, 255));

		// �󕶎��{�{�[�_�[�L
		this.spaceBorderOn = new PdfPCell(new Paragraph("", this.font));
		// �󕶎��{�{�[�_�[��
		this.spaceBorderOff = new PdfPCell(new Paragraph("", this.font));
		this.spaceBorderOff.setBorder(Rectangle.NO_BORDER);

	}

	/**
	 * ���l�t�H�[�}�b�g�ϊ� (#0.00)
	 * @param data �Ώۃf�[�^
	 * @return String �ϊ��㕶����
	 */
	private String numberFormat(final String data) {

		if (data == null || "".equals(data)) {
			return "";
		}

		final DecimalFormat df = new DecimalFormat("#0.00");
		String targetData = "";
		try {
			targetData = df.format(new Double(data).doubleValue());
		} catch (final Exception e) {

		}
		return targetData;

	}

	/**
	 * ���ڐ�17�ȏ�̍��ڃ��R�[�h�쐬
	 * @param valueBean PDF�쐬���f�[�^
	 * @param mainRightTable �f�[�^���e�[�u��
	 */
	private void setKomokuRecordOver(final PEF_MoralSurveyReportPDFValueBean valueBean, final PdfPTable mainRightTable) throws DocumentException {

		// ���ڃ��X�g���擾
		final ArrayList komokuList = valueBean.getMoralList();

		PdfPCell cell;

		final PdfPTable mainRightSubLeftTable = new PdfPTable(PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL);

		for (int i = 0; i < PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL; i++) {
			final String komokuNm = ((String[]) komokuList.get(i))[1];
			cell = new PdfPCell(new Paragraph(komokuNm, this.font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setMinimumHeight(30f);
			cell.setBackgroundColor(new Color(230, 230, 250));
			mainRightSubLeftTable.addCell(cell);

		}
		mainRightTable.addCell(mainRightSubLeftTable);

		final PdfPTable mainRightSubRightTable = new PdfPTable((int) 33.2 / this.rightColumnMaxColSize);
		final int rightMaxCol = (int) 33.2 / this.rightColumnMaxColSize;
		final float[] size = new float[rightMaxCol];
		for (int i = 0; i < rightMaxCol; i++) {
			size[i] = this.rightColumnMaxColSize;

		}
		mainRightSubRightTable.setWidths(size);
		for (int i = PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL; i < this.maxCol; i++) {
			final String komokuNm = ((String[]) komokuList.get(i))[1];
			cell = new PdfPCell(new Paragraph(komokuNm, this.font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setMinimumHeight(30f);
			cell.setBackgroundColor(new Color(230, 230, 250));
			mainRightSubRightTable.addCell(cell);

		}
		// ��Z���ǉ�
		for (int i = 0; i < rightMaxCol - this.rigthNum; i++) {
			mainRightSubRightTable.addCell(this.spaceBorderOff);
		}

		mainRightTable.addCell(mainRightSubRightTable);

	}

	/**
	 * ���ڐ�17�����̍��ڃ��R�[�h�쐬
	 * @param valueBean PDF�쐬���f�[�^
	 * @param mainRightTable �f�[�^���e�[�u��
	 */
	private void setKomokuRecordUnder(final PEF_MoralSurveyReportPDFValueBean valueBean, final PdfPTable mainRightSubLeftTable) {

		final ArrayList komokuList = valueBean.getMoralList();
		PdfPCell cell;
		// ���ڕ\��
		for (int i = 0; i < this.maxCol; i++) {
			final String komokuNm = ((String[]) komokuList.get(i))[1];
			cell = new PdfPCell(new Paragraph(komokuNm, this.font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setMinimumHeight(30f);
			cell.setBackgroundColor(new Color(230, 230, 250));
			mainRightSubLeftTable.addCell(cell);

		}
		// �󔒕\��
		for (int i = 0; i < PEF_MoralSurveyReportPDFBean.HEADER_UNDER_MAX_COL - this.maxCol; i++) {
			this.spaceBorderOff.setMinimumHeight(30f);
			mainRightSubLeftTable.addCell(this.spaceBorderOff);
		}

	}

	/**
	 * �g�D�̃l�X�g���擾
	 * @param sosiki �g�D�R�[�h
	 * @param sosikiMap �g�D�R�[�h���L�[�ɏ�ʑg�D�R�[�h���i�[���ꂽ�}�b�v
	 * @return �Ώۑg�D�̃l�X�g��
	 */
	private static int getNest(final String sosiki, final HashMap sosikiMap) {

		boolean isJoui = true;
		int nest = 0;
		String tmpSosiki = sosiki;
		while (isJoui) {
			if (sosikiMap.containsKey(tmpSosiki)) {
				nest++;
				tmpSosiki = (String) sosikiMap.get(tmpSosiki);
			} else {
				isJoui = false;
			}
		}
		return nest - 2;
	}

	/**
	 * CSV�f�[�^�쐬�i�g�D�p�j
	 * @param valueBean CSV�쐬�p�f�[�^
	 * @return String CSVF�f�[�^
	 */
	public String makeCsvSoshiki(final PEF_MoralSurveyReportPDFValueBean valueBean) {

		final StringBuffer sb = new StringBuffer();
		// ��s��
		sb.append(this.addDoubleQuote(this.msgDEF003 + "�F" + this.msgDEF005) + HcdbDef.CSV_LINE_FEED_CODE);
		// ��s��
		if (this.bushoNm.equals(this.addDoubleQuote(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF008"))))) {
			sb.append(this.addDoubleQuote(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF008"))) + HcdbDef.CSV_LINE_FEED_CODE);
		} else {
			sb.append(this.addDoubleQuote(this.bushoCd + "�F" + this.bushoNm) + HcdbDef.CSV_LINE_FEED_CODE);
		}
		// �O�s��
		sb.append(this.addDoubleQuote(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF002")) + "�F" + this.shukeiKikan) + HcdbDef.CSV_LINE_FEED_CODE);
		// �l�s��
		sb.append(this.addDoubleQuote(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF009"))) + ","
				+ this.addDoubleQuote(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF010"))));
		final ArrayList komokuList = valueBean.getMoralList();

		for (int i = 0, num = komokuList.size(); i < num; i++) {
			final String komokuNm = ((String[]) komokuList.get(i))[1];
			sb.append("," + this.addDoubleQuote(komokuNm) + "," + this.addDoubleQuote(komokuNm + this.msgDEF011));

		}
		this.maxCol = komokuList.size();;
		// �\���Œ�l���擾
		this.minGroupNum = valueBean.getMinGroupNum();
		this.thresHold = valueBean.getThresHold();

		sb.append(HcdbDef.CSV_LINE_FEED_CODE);
		final ArrayList sosikiList = valueBean.getSortSoshikiList();
		final HashMap pdfMap = valueBean.getPdfMap();
		final HashMap sosikiMap = valueBean.getNestSoshikiMap();
		// �܍s��
		for (int i = 0, num = sosikiList.size(); i < num; i++) {
			final String dataKey = ((String[]) sosikiList.get(i))[0];
			final int nest = PEF_MoralSurveyReportPDFBean.getNest(dataKey, sosikiMap);
			if (0 <= nest && nest <= 2 || i == 0) {
				// �Y���g�D�̃f�[�^�擾
				final ArrayList dataList = (ArrayList) pdfMap.get(dataKey);
				// �Y���g�D�̑O���ԃf�[�^�擾
				final ArrayList preDataList = (ArrayList) pdfMap.get(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + dataKey);
				// �Y���g�D�̐l���擾
				final int groupNum = ((Integer) pdfMap.get(PEF_MoralSurveyReportPDFValueBean.GROUP_NUM + dataKey)).intValue();
				sb.append(this.addDoubleQuote(((String[]) sosikiList.get(i))[0]) + "," + this.addDoubleQuote(((String[]) sosikiList.get(i))[1]));
				this.setCsvData(sb, dataList, preDataList, valueBean, groupNum);
				sb.append(HcdbDef.CSV_LINE_FEED_CODE);
			}
		}
		return sb.toString();

	}

	/**
	 * �f�[�^CSV�o��
	 * @param sb
	 * @param dataList �����ԃ��X�g
	 * @param preDataList �O���ԃ��X�g
	 * @param valueBean PDF�f�[�^
	 * @param �Ώۑg�D�l��
	 */
	private void setCsvData(final StringBuffer sb, final ArrayList dataList, final ArrayList preDataList, final PEF_MoralSurveyReportPDFValueBean valueBean, final int groupNum) {

		boolean isMoralSurveyAll = valueBean.isMoralSurveyAll();

		for (int i = 0; i < this.maxCol; i++) {
			final String nowData = (String) dataList.get(i);
			final String preData = (String) preDataList.get(i);

			// �f�[�^���擾
			String data = "";
			String compData = "";

			if (!"".equals(preData) && !"".equals(nowData)) {
				compData = this.numberFormat(String.valueOf(new Double(nowData).doubleValue() - new Double(preData).doubleValue()));
			}
			// �����[���T�[�x�C�S�ЎQ�ƌ������Ȃ� ���� �Ώۑg�D�l�����Œ�\���l�����Ⴂ�ꍇ *��\��
			if (!isMoralSurveyAll && groupNum < this.minGroupNum) {
				data = this.msgDEF012;
				// 2006/11/27 UPD STA A.NISHIMURA QUP1-VEF110-001
				// preData = this.msgDEF012;
				compData = this.msgDEF012;
				// 2006/11/27 UPD END A.NISHIMURA QUP1-VEF110-001
			} else {
				// �O���Ԃ̃f�[�^����Ȃ炻�̂܂ܕ\��
				if ("".equals(preData)) {
					data = this.numberFormat(nowData);
				} else if ("".equals(nowData)) {
					data = "";
				} else {

					if (new Double(nowData).doubleValue() - new Double(preData).doubleValue() > this.thresHold) {
						data = this.numberFormat(nowData);
					} else if (new Double(nowData).doubleValue() - new Double(preData).doubleValue() * -1 > this.thresHold) {
						data = this.numberFormat(nowData);
					} else {
						data = this.numberFormat(nowData);
					}
				}
			}
			sb.append("," + this.addDoubleQuote(data) + "," + this.addDoubleQuote(compData));

		}

	}

	/**
	 * CSV�f�[�^�쐬�i��E�p�j
	 * @param valueBean CSV�쐬�p�f�[�^
	 * @return String CSVF�f�[�^
	 */
	public String makeCsvYakushoku(final PEF_MoralSurveyReportPDFValueBean valueBean) {

		final StringBuffer sb = new StringBuffer();
		// ��s��
		sb.append(this.addDoubleQuote(this.msgDEF003 + "�F" + this.msgDEF006) + HcdbDef.CSV_LINE_FEED_CODE);
		// ��s��
		sb.append(this.addDoubleQuote(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF002")) + "�F" + this.shukeiKikan) + HcdbDef.CSV_LINE_FEED_CODE);
		// �O�s��
		sb.append(this.addDoubleQuote(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF006"))));
		final ArrayList komokuList = valueBean.getMoralList();

		for (int i = 0, num = komokuList.size(); i < num; i++) {
			final String komokuNm = ((String[]) komokuList.get(i))[1];
			sb.append("," + this.addDoubleQuote(komokuNm) + "," + this.addDoubleQuote(komokuNm + this.msgDEF011));

		}
		this.maxCol = komokuList.size();;
		// �\���Œ�l���擾
		this.minGroupNum = valueBean.getMinGroupNum();
		this.thresHold = valueBean.getThresHold();

		sb.append(HcdbDef.CSV_LINE_FEED_CODE);
		final HashMap pdfMap = valueBean.getPdfMap();
		// �܍s��
		final String[] key = new String[] { this.msgDEF014, this.msgDEF015, this.msgDEF016, this.msgDEF017, this.msgDEF018, this.msgDEF019, this.msgDEF020, this.msgDEF021, this.msgDEF022 };

		// ��E�K�w�����[�v
		for (int i = PEF_MoralSurveyReportPDFBean.MAX_YAKUSHOKU_KAISO; i > 0; i--) {

			// �f�[�^�擾�̃L�[���擾
			final String dataKey = String.valueOf(i);

			// �Y���g�D�̃f�[�^�擾
			ArrayList dataList = (ArrayList) pdfMap.get(new Integer(dataKey));
			// �Y���g�D�̑O���ԃf�[�^�擾
			ArrayList preDataList = (ArrayList) pdfMap.get(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + dataKey);
			// �Y���g�D�̐l���擾
			int groupNum = -1;
			final Object workNum = pdfMap.get(PEF_MoralSurveyReportPDFValueBean.GROUP_NUM + dataKey);
			if (workNum != null) {
				try {
					groupNum = ((Integer) workNum).intValue();
				} catch (final ClassCastException e) {
					Log.error("", "HJE-0003", e);
				}
			} else {
				Log.error("", "HJE-0013", null);
			}
			if (dataList == null) {
				dataList = new ArrayList();
				for (int j = 0; j < this.maxCol; j++) {
					dataList.add("");
				}
			}
			if (preDataList == null) {
				preDataList = new ArrayList();
				for (int j = 0; j < this.maxCol; j++) {
					preDataList.add("");
				}
			}
			sb.append(this.addDoubleQuote(key[i - 1]));
			this.setCsvData(sb, dataList, preDataList, valueBean, groupNum);
			sb.append(HcdbDef.CSV_LINE_FEED_CODE);

		}

		return sb.toString();

	}

	/**
	 * CSV�f�[�^�쐬�i�N��p�j
	 * @param valueBean CSV�쐬�p�f�[�^
	 * @return String CSVF�f�[�^
	 */
	public String makeCsvNendai(final PEF_MoralSurveyReportPDFValueBean valueBean) {

		final StringBuffer sb = new StringBuffer();
		// ��s��

		sb.append(this.addDoubleQuote(this.msgDEF003 + "�F" + this.msgDEF007) + HcdbDef.CSV_LINE_FEED_CODE);
		// ��s��
		sb.append(this.addDoubleQuote(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF002")) + "�F" + this.shukeiKikan) + HcdbDef.CSV_LINE_FEED_CODE);
		// �O�s��
		sb.append(this.addDoubleQuote(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF007"))));
		final ArrayList komokuList = valueBean.getMoralList();

		for (int i = 0, num = komokuList.size(); i < num; i++) {
			final String komokuNm = ((String[]) komokuList.get(i))[1];
			sb.append("," + this.addDoubleQuote(komokuNm) + "," + this.addDoubleQuote(komokuNm + this.msgDEF011));

		}
		this.maxCol = komokuList.size();;
		// �\���Œ�l���擾
		this.minGroupNum = valueBean.getMinGroupNum();
		this.thresHold = valueBean.getThresHold();

		sb.append(HcdbDef.CSV_LINE_FEED_CODE);
		final HashMap pdfMap = valueBean.getPdfMap();
		// �܍s��
		final String[] key = new String[] { this.msgDEF023, this.msgDEF024, this.msgDEF025, this.msgDEF026, this.msgDEF027 };

		// �N��K�w�����[�v
		for (int i = 0; i < PEF_MoralSurveyReportPDFBean.MAX_NENDAI_NUM; i++) {

			// �f�[�^�擾�̃L�[���擾
			final String dataKey = String.valueOf(i);
			// �Y���g�D�̃f�[�^�擾
			ArrayList dataList = (ArrayList) pdfMap.get(new Integer(dataKey));
			// �Y���g�D�̑O���ԃf�[�^�擾
			ArrayList preDataList = (ArrayList) pdfMap.get(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + dataKey);
			// �Y���g�D�̐l���擾
			// �Y���g�D�̐l���擾
			int groupNum = -1;
			final Object workNum = pdfMap.get(PEF_MoralSurveyReportPDFValueBean.GROUP_NUM + dataKey);
			if (workNum != null) {
				try {
					groupNum = ((Integer) workNum).intValue();
				} catch (final ClassCastException e) {
					Log.error("", "HJE-0003", e);
				}
			} else {
				Log.error("", "HJE-0013", null);
			}
			if (dataList == null) {
				dataList = new ArrayList();
				for (int j = 0; j < this.maxCol; j++) {
					dataList.add("");
				}
			}
			if (preDataList == null) {
				preDataList = new ArrayList();
				for (int j = 0; j < this.maxCol; j++) {
					preDataList.add("");
				}
			}
			sb.append(this.addDoubleQuote(key[i]));
			this.setCsvData(sb, dataList, preDataList, valueBean, groupNum);
			sb.append(HcdbDef.CSV_LINE_FEED_CODE);

		}

		return sb.toString();

	}

	/**
	 * �_�u���N�H�[�e�[�V�����t�^
	 * @param str
	 * @return String
	 */
	private String addDoubleQuote(final String str) {

		final String quete = "\"";
		if (str == null) {
			return quete + quete;
		}
		return quete + str + quete;

	}

}
