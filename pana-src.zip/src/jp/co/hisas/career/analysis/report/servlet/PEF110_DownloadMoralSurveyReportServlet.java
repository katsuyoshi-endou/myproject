/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.analysis.report.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.analysis.report.bean.PEF_MoralSurveyReportBean;
import jp.co.hisas.career.analysis.report.bean.PEF_MoralSurveyReportValueBean;
import jp.co.hisas.career.analysis.report.bean.PEF_ReportValueBean;
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ050_FileUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �����[���T�[�x�C���|�[�g�o��
 */
public class PEF110_DownloadMoralSurveyReportServlet extends HttpServlet {

	/** �G���[�y�[�W */
	private static final String ERROR_PAGE = "/view/base/error/VYY_Error.jsp";

	/** ����y�[�W */
	private static final String SUCCESS_PAGE = "/view/analysis/report/VEF110_DownloadMoralSurveyReportMain.jsp";

	/** ���ʃ_�E�����[�h�N���X */
	private static final String DOWNLOAD_PAGE = "/servlet/PYE010_FileDownloadServlet";

	/** ���[�U�A�N�V������ێ����邽�߂̃L�[ */
	private static final String ACTION_KEY = "ACTION_KEY";

	/** ���ʃ_�E�����[�h�N���X��request���镶���� */
	private static final String DOWNLOAD_STREAM = "STREAM";

	private static final String DOWNLOAD_FILENAME = "H080_FileName";

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * �������������s���B
	 * @param config
	 * @throws javax.servlet.ServletException
	 * @see javax.servlet.Servlet#init(javax.servlet.ServletConfig)
	 */
	public void init(final ServletConfig config) throws ServletException {
		super.init(config);

		// ���\�b�h�g���[�X�o��
		Log.method("", "IN", "");

		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
		// ���\�b�h�g���[�X�o��
		Log.method("", "OUT", "");
	}

	/**
	 * �u���E�U����̌����v�����󂯎��A�{�N���X�̎��s���\�b�h���Ăяo���܂��B
	 * @param request ���N�G�X�g
	 * @param response ���X�|���X
	 * @throws ServletException �T�[�u���b�g��O
	 * @throws IOException ���o�͗�O
	 * @see javax.servlet.http.HttpServlet#service( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse )
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {

		final HttpSession session = request.getSession(false);

		String pageUrl = PEF110_DownloadMoralSurveyReportServlet.SUCCESS_PAGE;
		// �Z�b�V�����A�܂���userinfo���擾�ł��Ȃ��ꍇ�A�G���[�y�[�W�֑J��
		if (session == null || (UserInfoBean) session.getAttribute("userinfo") == null) {
			this.ctx.getRequestDispatcher(PEF110_DownloadMoralSurveyReportServlet.ERROR_PAGE).forward(request, response);
		} else {

			String loginNo = null;
			try {

				// ���ʃr�[���N���X�擾
				PEF_ReportValueBean commonBean = (PEF_ReportValueBean) session.getAttribute(PEF_ReportValueBean.SESSION_KEY);
				final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");

				if( commonBean == null ) {
					commonBean	= new PEF_ReportValueBean();
					session.setAttribute(PEF_ReportValueBean.SESSION_KEY, commonBean);
				}

				// ���O�C�����[�U�擾
				loginNo = userinfo.getLogin_no();

				Log.performance(loginNo, true, "");

				// ��ʏ��̎擾
				final Map userAction = request.getParameterMap();
				// ���[�U�̃A�N�V�������擾
				final String[] actionTmp = (String[]) userAction.get(PEF110_DownloadMoralSurveyReportServlet.ACTION_KEY);
				int action = -1;
				if (actionTmp != null) {
					action = new Integer(actionTmp[0]).intValue();
				}

				// �����[���T�[�x�C�����擾
				final boolean isMoralSurveyAll = userinfo.isMoralSurveyAll();
				final boolean isMoralSurveyHaika = userinfo.isMoralSurveyHaika();

				// ��ʏ��̕ێ�(�����\���ȊO)
				if (action != PEF_ReportValueBean.INIT_ACTION) {
					this.setGamenValue(commonBean, userAction, action, loginNo);
				}
				final PEF_MoralSurveyReportBean bean = new PEF_MoralSurveyReportBean();
				// ��ʕ`�掞
				if (action == PEF_ReportValueBean.INIT_ACTION) {

					ArrayList soshikiList = new ArrayList();
					// �S�Ќ����̏ꍇ
					if (isMoralSurveyAll) {
						soshikiList = bean.getAllSoshiki(loginNo);
					}
					// �����z�������̏ꍇ
					else if (isMoralSurveyHaika) {
						soshikiList = bean.getHaikaSoshiki(loginNo, userinfo.getSosiki_code());
					}

					// �A�Z�X�����g���Ԏ擾
					final ArrayList assessmentKikanList = bean.getAssessmentKikanList(loginNo);

					// �����[���O���[�v�}�X�^�擾
					final ArrayList moralGroupMasterList = bean.getMoralGroupMaster(loginNo);

					commonBean.getMoralBean().setSoshikiList(soshikiList);
					commonBean.getMoralBean().setAssessmentKikanList(assessmentKikanList);
					commonBean.getMoralBean().setMoralGroupMasterList(moralGroupMasterList);

				}
				// CSV�{�^��������
				else if (action == PEF_ReportValueBean.CSV_ACTION) {

					final String csvData = bean.makeCSV(loginNo, commonBean.getMoralBean(), userinfo.isMoralSurveyAll());
					// �t�@�C�����擾
					String fileName = "";
					final String shukei = commonBean.getMoralBean().getShukei();
					// �g�D�I��
					if (PEF_MoralSurveyReportValueBean.SHUKEI_SOSHIKI.equals(shukei)) {
						fileName = PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_MORALSURVEY_SOSIKI_REPORT_CSV);
					}
					// ��E�I��
					else if (PEF_MoralSurveyReportValueBean.SHUKEI_YAKUSHOKU.equals(shukei)) {
						fileName = PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_MORALSURVEY_YAKUSYOKU_REPORT_CSV);
					}
					// �N��I��
					else if (PEF_MoralSurveyReportValueBean.SHUKEI_NENDAI.equals(shukei)) {
						fileName = PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_MORALSURVEY_NENDAI_REPORT_CSV);
					}
					final ByteArrayInputStream bais = new ByteArrayInputStream(csvData.getBytes());
					request.setAttribute(PEF110_DownloadMoralSurveyReportServlet.DOWNLOAD_STREAM, bais);
					request.setAttribute(PEF110_DownloadMoralSurveyReportServlet.DOWNLOAD_FILENAME, fileName);
					pageUrl = PEF110_DownloadMoralSurveyReportServlet.DOWNLOAD_PAGE;
				}
				// PDF�{�^��������
				else if (action == PEF_ReportValueBean.PDF_ACTION) {
					final byte[] pdf = bean.makePDF(loginNo, commonBean.getMoralBean(), userinfo.isMoralSurveyAll());
					final ByteArrayInputStream bais = new ByteArrayInputStream(pdf);

					// �t�@�C�����擾
					String fileName = "";
					final String shukei = commonBean.getMoralBean().getShukei();
					// �g�D�I��
					if (PEF_MoralSurveyReportValueBean.SHUKEI_SOSHIKI.equals(shukei)) {
						fileName = PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_MORALSURVEY_SOSIKI_REPORT_PDF);
					}
					// ��E�I��
					else if (PEF_MoralSurveyReportValueBean.SHUKEI_YAKUSHOKU.equals(shukei)) {
						fileName = PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_MORALSURVEY_YAKUSYOKU_REPORT_PDF);
					}
					// �N��I��
					else if (PEF_MoralSurveyReportValueBean.SHUKEI_NENDAI.equals(shukei)) {
						fileName = PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_MORALSURVEY_NENDAI_REPORT_PDF);
					}
					request.setAttribute(PEF110_DownloadMoralSurveyReportServlet.DOWNLOAD_STREAM, bais);
					request.setAttribute(PEF110_DownloadMoralSurveyReportServlet.DOWNLOAD_FILENAME, fileName);
					pageUrl = PEF110_DownloadMoralSurveyReportServlet.DOWNLOAD_PAGE;
				}

				session.setAttribute(PEF_ReportValueBean.SESSION_KEY, commonBean);
				// �����������A�Y��JSP�y�[�W�֑J��
				final RequestDispatcher rd = this.ctx.getRequestDispatcher(pageUrl);
				rd.forward(request, response);
				Log.performance(loginNo, false, "");
				Log.method(loginNo, "OUT", "");

			} catch (final Exception e) {
				Log.error(loginNo, e);
				this.ctx.getRequestDispatcher(PEF110_DownloadMoralSurveyReportServlet.ERROR_PAGE).forward(request, response);
			}
		}
	}

	/**
	 * ��ʏ��̕ێ�
	 * @param commonBean ���ʃN���X�r�[��
	 * @param userAction ��ʓ��͏��
	 * @param action ���[�U�A�N�V����
	 * @param loginNo ���O�C���ԍ�
	 * @return PEF_ReportValueBean
	 */
	private void setGamenValue(final PEF_ReportValueBean commonBean, final Map userAction, final int action, final String loginNo) throws NamingException, SQLException, Exception {

		final String busho = ((String[]) userAction.get("busho"))[0];
		final String assessment = ((String[]) userAction.get("assessment"))[0];
		final String shukei = ((String[]) userAction.get("shukei"))[0];
		final String bunseki = ((String[]) userAction.get("bunseki"))[0];

		commonBean.getMoralBean().setBusho(busho);
		commonBean.getMoralBean().setAssessment(assessment);
		commonBean.getMoralBean().setShukei(shukei);
		commonBean.getMoralBean().setBunseki(bunseki);

		// �I�������������ɖ��̎擾

		final ArrayList bushoList = commonBean.getMoralBean().getSoshikiList();
		final ArrayList assessmentKikanList = commonBean.getMoralBean().getAssessmentKikanList();
		final ArrayList moralGroupList = commonBean.getMoralBean().getMoralGroupMasterList();

		for (int i = 0, num = bushoList.size(); i < num; i++) {
			final String[] bushoSelect = (String[]) bushoList.get(i);
			if (busho.equals(bushoSelect[0])) {
				commonBean.getMoralBean().setBushoNm(bushoSelect[1]);
			}
		}
		if ("0".equals(busho)) {
			commonBean.getMoralBean().setBushoNm(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF008")));
		}

		for (int i = 0, num = assessmentKikanList.size(); i < num; i++) {
			final String[] assessmentSelect = (String[]) assessmentKikanList.get(i);
			if (assessment.equals(assessmentSelect[0] + "," + assessmentSelect[1])) {
				commonBean.getMoralBean().setAssessmentKikan(assessmentSelect);
			}
		}

		for (int i = 0, num = moralGroupList.size(); i < num; i++) {
			final String[] moralSelect = (String[]) moralGroupList.get(i);
			if (bunseki.equals(moralSelect[0])) {
				commonBean.getMoralBean().setBunsekiNm(moralSelect[1]);
			}
		}

		if (PEF_MoralSurveyReportValueBean.SHUKEI_SOSHIKI.equals(shukei)) {
			commonBean.getMoralBean().setBunsekiNm(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF005")));
		} else if (PEF_MoralSurveyReportValueBean.SHUKEI_YAKUSHOKU.equals(shukei)) {
			commonBean.getMoralBean().setBunsekiNm(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF006")));
		} else if (PEF_MoralSurveyReportValueBean.SHUKEI_NENDAI.equals(shukei)) {
			commonBean.getMoralBean().setBunsekiNm(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF007")));
		}

		// CSV�{�^��������
		if (action == PEF_ReportValueBean.CSV_ACTION) {
			OutLogBean.sousaKojinJohoLog("TOU002", loginNo, null, busho + "," + assessment.substring(0, 1) + "," + commonBean.getMoralBean().getBunsekiNm() + "," + bunseki);
		}
		// PDF�{�^��������
		else if (action == PEF_ReportValueBean.PDF_ACTION) {
			OutLogBean.sousaKojinJohoLog("TOU003", loginNo, null, busho + "," + assessment.substring(0, 1) + "," + commonBean.getMoralBean().getBunsekiNm() + "," + bunseki);
		}

	}
}
