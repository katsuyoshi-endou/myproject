/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.analysis.report.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.analysis.report.bean.PEF_JinzaiPortfolioBean;
import jp.co.hisas.career.analysis.report.bean.PEF_JinzaiPortfolioValueBean;
import jp.co.hisas.career.analysis.report.bean.PEF_ReportValueBean;
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.util.common.PZZ050_FileUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * �l���|�[�g�t�H���I�o��
 */
public class PEF210_DownloadJinzaiPortfolioServlet extends HttpServlet {
	/** �G���[�y�[�W */
	private static final String ERROR_PAGE = "/view/base/error/VYY_Error.jsp";

	/** ����y�[�W */
	private static final String SUCCESS_PAGE = "/view/analysis/report/VEF210_DownloadJinzaiPortfolioMain.jsp";

	/** ���ʃ_�E�����[�h�N���X */
	private static final String DOWNLOAD_PAGE = "/servlet/PYE010_FileDownloadServlet";

	/** ���ʃ_�E�����[�h�N���X��request���镶���� */
	private static final String DOWNLOAD_STREAM = "STREAM";

	private static final String DOWNLOAD_FILENAME = "H080_FileName";

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * �������������s���B
	 * @param config
	 * @throws javax.servlet.ServletException
	 * @see javax.servlet.Servlet#init(javax.servlet.ServletConfig)
	 */
	public void init(final ServletConfig config) throws ServletException {
		super.init(config);

		// ���\�b�h�g���[�X�o��
		Log.method("", "IN", "");

		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
		// ���\�b�h�g���[�X�o��
		Log.method("", "OUT", "");
	}

	/**
	 * �u���E�U����̌����v�����󂯎��A�{�N���X�̎��s���\�b�h���Ăяo���܂��B
	 * @param request ���N�G�X�g
	 * @param response ���X�|���X
	 * @throws ServletException �T�[�u���b�g��O
	 * @throws IOException ���o�͗�O
	 * @see javax.servlet.http.HttpServlet#service( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse )
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {

		final HttpSession session = request.getSession(false);

		String pageUrl = PEF210_DownloadJinzaiPortfolioServlet.SUCCESS_PAGE;
		// �Z�b�V�����A�܂���userinfo���擾�ł��Ȃ��ꍇ�A�G���[�y�[�W�֑J��
		if (session == null || (UserInfoBean) session.getAttribute("userinfo") == null) {
			this.ctx.getRequestDispatcher(PEF210_DownloadJinzaiPortfolioServlet.ERROR_PAGE).forward(request, response);
		} else {

			String loginNo = null;
			try {

				// ���ʃr�[���N���X�擾
				PEF_ReportValueBean commonBean = (PEF_ReportValueBean) session.getAttribute(PEF_ReportValueBean.SESSION_KEY);
				if (commonBean == null ) {
					commonBean = new PEF_ReportValueBean();
					session.setAttribute(PEF_ReportValueBean.SESSION_KEY, commonBean);
				}
				PEF_JinzaiPortfolioValueBean valueBean = commonBean.getJinzaiBean();
				if (valueBean == null) {
					valueBean = new PEF_JinzaiPortfolioValueBean();
					commonBean.setJinzaiBean(valueBean);
				}
				final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");

				// ���O�C�����[�U�擾
				loginNo = userinfo.getLogin_no();

				Log.performance(loginNo, true, "");

				// ���[�U�̃A�N�V�������擾
				final String tmpAction = request.getParameter("ACTION_KEY");
				final int userAction = tmpAction == null ? -1 : Integer.parseInt(tmpAction);

				// �l���|�[�g�t�H���I�����擾
				final boolean isJinzaiPortfolioAll = userinfo.isJinzaiPortfolioAll();
				final boolean isJinzaiPortfolioHaika = userinfo.isJinzaiPortfolioHaika();

				final PEF_JinzaiPortfolioBean bean = new PEF_JinzaiPortfolioBean();

				// ��ʕ`�掞
				if (userAction == PEF_ReportValueBean.INIT_ACTION) {

					ArrayList soshikiList = new ArrayList();
					// �S�Ќ����̏ꍇ
					if (isJinzaiPortfolioAll) {
						soshikiList = bean.getAllSoshiki(loginNo);
					}
					// �����z�������̏ꍇ
					else if (isJinzaiPortfolioHaika) {
						soshikiList = bean.getHaikaSoshiki(loginNo);
					}
					// �����v���_�E�����X�g�ɋ󔒂�ǉ�
					final String tmp[] = { "", "" };
					soshikiList.add(0, tmp);
					valueBean.setSoshikiList(soshikiList);

					// --- 20070117 K.takagi Add Sta---
					// �A�Z�X�����g���Ԏ擾
					final ArrayList assessmentKikanList = bean.getAssessmentKikanList(loginNo);
					commonBean.getJinzaiBean().setAssessmentKikanList(assessmentKikanList);
					// --- 20070117 K.takagi Add End---
				} else if (userAction == PEF_ReportValueBean.CSV_ACTION) {
					final String sosikiCode = request.getParameter("busho");
					final String start = request.getParameter("kikanKaisi");
					final String end = request.getParameter("kikanShuryo");
					// --- 20070117 K.takagi Add Sta---
					final String kikan = request.getParameter("assessment");
					final String kikanWay = request.getParameter("radio_kikanRes");
					// --- 20070117 K.takagi Add End---
					final boolean targetDataCondition = !userinfo.isJinzaiPortfolioAll() && sosikiCode.equals(userinfo.getSosiki_code());
					final ByteArrayInputStream bais = new ByteArrayInputStream(bean.makeCSV(sosikiCode, start, end, kikan, loginNo, targetDataCondition, kikanWay).getBytes());
					request.setAttribute(PEF210_DownloadJinzaiPortfolioServlet.DOWNLOAD_STREAM, bais);
					request.setAttribute(PEF210_DownloadJinzaiPortfolioServlet.DOWNLOAD_FILENAME, PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_PORTFOLIO_REPORT_CSV));
					pageUrl = PEF210_DownloadJinzaiPortfolioServlet.DOWNLOAD_PAGE;

				} else if (userAction == PEF_ReportValueBean.PDF_ACTION) {
					final String sosikiCode = request.getParameter("busho");
					final String start = request.getParameter("kikanKaisi");
					final String end = request.getParameter("kikanShuryo");
					final String kikan = request.getParameter("assessment");
					final String kikanWay = request.getParameter("radio_kikanRes");
					final boolean targetDataCondition = !userinfo.isJinzaiPortfolioAll() && sosikiCode.equals(userinfo.getSosiki_code());
					final ByteArrayInputStream bais = new ByteArrayInputStream(bean.makePDF(sosikiCode, start, end, kikan, loginNo, targetDataCondition, kikanWay));
					request.setAttribute(PEF210_DownloadJinzaiPortfolioServlet.DOWNLOAD_STREAM, bais);
					request.setAttribute(PEF210_DownloadJinzaiPortfolioServlet.DOWNLOAD_FILENAME, PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_PORTFOLIO_REPORT_PDF));
					pageUrl = PEF210_DownloadJinzaiPortfolioServlet.DOWNLOAD_PAGE;
				}

				session.setAttribute(PEF_ReportValueBean.SESSION_KEY, commonBean);
				// �����������A�Y��JSP�y�[�W�֑J��
				final RequestDispatcher rd = this.ctx.getRequestDispatcher(pageUrl);
				rd.forward(request, response);
				Log.performance(loginNo, false, "");
				Log.method(loginNo, "OUT", "");
			} catch (final Exception e) {
				Log.error(loginNo, e);
				this.ctx.getRequestDispatcher(PEF210_DownloadJinzaiPortfolioServlet.ERROR_PAGE).forward(request, response);
			}
		}
	}

}
