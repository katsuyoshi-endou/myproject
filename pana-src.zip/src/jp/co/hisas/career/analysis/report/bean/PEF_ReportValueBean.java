/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.analysis.report.bean;

import java.io.Serializable;

public class PEF_ReportValueBean implements Serializable {

	/** �Z�b�V�����L�[ */
	public static final String SESSION_KEY = "planReportValueBean";

	/** ���[�U�[�A�N�V�������f */
	/** ��ʕ`�掞 */
	public static final int INIT_ACTION = -1;

	/** PDF�{�^�������� */
	public static final int PDF_ACTION = 1;

	/** CSV�{�^�������� */
	public static final int CSV_ACTION = 2;

	PEF_MoralSurveyReportValueBean moralBean = null;

	PEF_JinzaiPortfolioValueBean jinzaiBean = null;

	public PEF_ReportValueBean() {
		this.moralBean = new PEF_MoralSurveyReportValueBean();
	}

	/**
	 * @return moralBean ��߂��܂��B
	 */
	public PEF_MoralSurveyReportValueBean getMoralBean() {
		return this.moralBean;
	}

	/**
	 * @param moralBean �ݒ肷�� moralBean�B
	 */
	public void setMoralBean(final PEF_MoralSurveyReportValueBean moralBean) {
		this.moralBean = moralBean;
	}

	/**
	 * @return jinzaiBean��߂��܂��B
	 */
	public PEF_JinzaiPortfolioValueBean getJinzaiBean() {
		return this.jinzaiBean;
	}

	/**
	 * @param jinzaiBean �ݒ肷�� jinzaiBean�B
	 */
	public void setJinzaiBean(final PEF_JinzaiPortfolioValueBean jinzaiBean) {
		this.jinzaiBean = jinzaiBean;
	}

}
