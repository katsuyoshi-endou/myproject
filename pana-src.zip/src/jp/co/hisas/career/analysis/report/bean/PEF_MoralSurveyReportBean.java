/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.analysis.report.bean;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.naming.NamingException;

import jp.co.hisas.career.analysis.report.ejb.PEF_MoralSurveyReportEJB;
import jp.co.hisas.career.analysis.report.ejb.PEF_MoralSurveyReportEJBHome;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.util.log.Log;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfWriter;

public class PEF_MoralSurveyReportBean {

	/** �����[���T�[�x�C���͍Œ�l�� */
	private static final String MORALESURVEY_SHOW_LEAST_COUNT = "MORALESURVEY_SHOW_LEAST_COUNT";

	/** �����[���T�[�x�C�������� */
	private static final String MORALESURVEY_THRESHOLD = "MORALESURVEY_THRESHOLD";

	/** �����[���T�[�x�C���� */
	private static final String MORAL_BUNRUI = "Base";

	/**
	 * �S�Ќ����̏ꍇ�S�g�D���擾�i���X�g�{�b�N�X�j
	 * @param loginNo
	 * @return ArrayList �g�D���X�g
	 * @throws RemoteException
	 * @throws NamingException
	 * @throws CreateException
	 * @throws SQLException
	 */
	public ArrayList getAllSoshiki(final String loginNo) throws RemoteException, NamingException, CreateException, SQLException {
		try {
			Log.transaction(loginNo, true, "");
			// EJBHome�̎擾
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PEF_MoralSurveyReportEJBHome my_home = (PEF_MoralSurveyReportEJBHome) fact.lookup(PEF_MoralSurveyReportEJBHome.class);
			/* EJBObject�̎擾 */
			final PEF_MoralSurveyReportEJB userSession = my_home.create();
			Log.transaction(loginNo, false, "");
			return userSession.getAllSoshiki(loginNo);
		} catch (final RemoteException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final SQLException e) {
			Log.error(loginNo, e);
			throw e;
		}
	}

	/**
	 * �z�������̏ꍇ�S�g�D���擾�i���X�g�{�b�N�X�j
	 * @param loginNo
	 * @param soshikiCode
	 * @return ArrayList �g�D���X�g
	 * @throws RemoteException
	 * @throws NamingException
	 * @throws CreateException
	 * @throws SQLException
	 */
	public ArrayList getHaikaSoshiki(final String loginNo, final String soshikiCode) throws RemoteException, NamingException, CreateException, SQLException {

		try {
			Log.transaction(loginNo, true, "");
			// EJBHome�̎擾
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PEF_MoralSurveyReportEJBHome my_home = (PEF_MoralSurveyReportEJBHome) fact.lookup(PEF_MoralSurveyReportEJBHome.class);
			/* EJBObject�̎擾 */
			final PEF_MoralSurveyReportEJB userSession = my_home.create();
			Log.transaction(loginNo, false, "");
			return userSession.getHaikaSoshiki(loginNo, soshikiCode);
		} catch (final RemoteException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final SQLException e) {
			Log.error(loginNo, e);
			throw e;
		}

	}

	/**
	 * �A�Z�X�����g���Ԃ̎擾
	 * @param loginNo
	 * @return ArrayList �A�Z�X�����g���Ԃ̃��X�g
	 * @throws RemoteException
	 * @throws NamingException
	 * @throws CreateException
	 * @throws SQLException
	 */
	public ArrayList getAssessmentKikanList(final String loginNo) throws RemoteException, NamingException, CreateException, SQLException {
		try {
			Log.transaction(loginNo, true, "");
			// EJBHome�̎擾
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PEF_MoralSurveyReportEJBHome my_home = (PEF_MoralSurveyReportEJBHome) fact.lookup(PEF_MoralSurveyReportEJBHome.class);

			/* EJBObject�̎擾 */
			final PEF_MoralSurveyReportEJB userSession = my_home.create();
			Log.transaction(loginNo, false, "");
			return userSession.getAssessmentKikanList(loginNo);
		} catch (final RemoteException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final SQLException e) {
			Log.error(loginNo, e);
			throw e;
		}
	}

	/**
	 * �V�X�e���p�����[�^���擾
	 * @param loginNo
	 * @param bunrui ���ޖ���
	 * @param id �p�����[�^ID
	 * @return String �l
	 * @throws RemoteException
	 * @throws NamingException
	 * @throws CreateException
	 * @throws SQLException
	 */
	public String getSystemParameter(final String loginNo, final String bunrui, final String id) throws RemoteException, NamingException, CreateException, SQLException {

		try {
			Log.transaction(loginNo, true, "");
			// EJBHome�̎擾
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PEF_MoralSurveyReportEJBHome my_home = (PEF_MoralSurveyReportEJBHome) fact.lookup(PEF_MoralSurveyReportEJBHome.class);

			/* EJBObject�̎擾 */
			final PEF_MoralSurveyReportEJB userSession = my_home.create();
			Log.transaction(loginNo, false, "");
			return userSession.getSystemParameter(loginNo, bunrui, id);
		} catch (final RemoteException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final SQLException e) {
			Log.error(loginNo, e);
			throw e;
		}

	}

	/**
	 * �����[���O���[�v�}�X�^����O���[�v�R�[�h�A���̂��擾����
	 * @param loginNo ���O�C��NO
	 * @return ArrayList �O���[�v�R�[�h�A���̂̃��X�g
	 * @throws RemoteException
	 * @throws NamingException
	 * @throws CreateException
	 * @throws SQLException
	 */
	public ArrayList getMoralGroupMaster(final String loginNo) throws RemoteException, NamingException, CreateException, SQLException {
		try {
			Log.transaction(loginNo, true, "");
			// EJBHome�̎擾
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PEF_MoralSurveyReportEJBHome my_home = (PEF_MoralSurveyReportEJBHome) fact.lookup(PEF_MoralSurveyReportEJBHome.class);

			/* EJBObject�̎擾 */
			final PEF_MoralSurveyReportEJB userSession = my_home.create();
			Log.transaction(loginNo, false, "");
			return userSession.getMoralGroupMaster(loginNo);
		} catch (final RemoteException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final SQLException e) {
			Log.error(loginNo, e);
			throw e;
		}
	}

	/**
	 * PDF�쐬���C�����W�b�N
	 * @param logiNo ���O�C���Ј��ԍ�
	 * @param moralBean ���[�U���͏��
	 * @param isMoralSurveyAll �S�Ѓ����[���T�[�x�C�Q�ƌ���
	 * @return byte[] PDF�f�[�^
	 * @throws IOException
	 * @throws SQLException
	 * @throws DocumentException
	 * @throws CreateException
	 */
	public byte[] makePDF(final String loginNo, final PEF_MoralSurveyReportValueBean moralBean, final boolean isMoralSurveyAll) throws NamingException, IOException, SQLException, DocumentException,
			CreateException {

		Log.transaction(loginNo, true, "");
		// EJBHome�̎擾
		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEF_MoralSurveyReportEJBHome my_home = (PEF_MoralSurveyReportEJBHome) fact.lookup(PEF_MoralSurveyReportEJBHome.class);
		Document document = null;
		try {

			/* EJBObject�̎擾 */
			final PEF_MoralSurveyReportEJB userSession = my_home.create();
			Log.transaction(loginNo, false, "");
			final String shukei = moralBean.getShukei();
			PEF_MoralSurveyReportPDFValueBean valueBean = null;

			final String busho = moralBean.getBushoNm();
			final String assessment = (moralBean.getAssessmentKikan())[4];
			final String bunseki = moralBean.getBunsekiNm();

			document = new Document(PageSize.A3.rotate(), 10, 10, 10, 10);

			PdfWriter writer;

			final ByteArrayOutputStream baos = new ByteArrayOutputStream();

			writer = PdfWriter.getInstance(document, baos);
			document.open();
			final PEF_MoralSurveyReportPDFBean pBean = new PEF_MoralSurveyReportPDFBean(busho, assessment, bunseki, moralBean.getBusho(), moralBean.getBushoNm(), document);
			final HashMap allMap = userSession.getPDFDataAll(loginNo, moralBean);
			final ArrayList moralList = userSession.getMoralMaster(loginNo, moralBean.getBunseki());
			// �Œ�\���l���擾
			final String minNum = this.getSystemParameter(loginNo, PEF_MoralSurveyReportBean.MORAL_BUNRUI, PEF_MoralSurveyReportBean.MORALESURVEY_SHOW_LEAST_COUNT);
			// �����[���T�[�x�C臒l�擾
			final String thresHold = this.getSystemParameter(loginNo, PEF_MoralSurveyReportBean.MORAL_BUNRUI, PEF_MoralSurveyReportBean.MORALESURVEY_THRESHOLD);
			// �g�D�I��
			if (PEF_MoralSurveyReportValueBean.SHUKEI_SOSHIKI.equals(shukei)) {
				valueBean = userSession.getPDFDataSoshiki(loginNo, moralBean);
				valueBean.setAllPdfMap(allMap);
				valueBean.setMoralList(moralList);
				valueBean.setMinGroupNum(new Integer(minNum).intValue());
				valueBean.setMoralSurveyAll(isMoralSurveyAll);
				valueBean.setThresHold(new Double(thresHold).doubleValue());
				pBean.makePdfSoshiki(valueBean);
			}
			// ��E�I��
			else if (PEF_MoralSurveyReportValueBean.SHUKEI_YAKUSHOKU.equals(shukei)) {
				valueBean = userSession.getPDFDataYakushoku(loginNo, moralBean);
				valueBean.setAllPdfMap(allMap);
				valueBean.setMoralList(moralList);
				valueBean.setMinGroupNum(new Integer(minNum).intValue());
				valueBean.setMoralSurveyAll(isMoralSurveyAll);
				valueBean.setThresHold(new Double(thresHold).doubleValue());
				pBean.makePdfYakushoku(valueBean);
			}
			// �N��I��
			else if (PEF_MoralSurveyReportValueBean.SHUKEI_NENDAI.equals(shukei)) {
				valueBean = userSession.getPDFDataNendai(loginNo, moralBean);
				valueBean.setAllPdfMap(allMap);
				valueBean.setMoralList(moralList);
				valueBean.setMinGroupNum(new Integer(minNum).intValue());
				valueBean.setMoralSurveyAll(isMoralSurveyAll);
				valueBean.setThresHold(new Double(thresHold).doubleValue());
				pBean.makePdfNendai(valueBean);
			}
			document.close();
			// PDF�쐬
			return baos.toByteArray();
		} catch (final IllegalStateException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final IOException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final SQLException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} catch (final DocumentException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginNo, e);
			throw e;
		} finally {
			if (document != null) {
				try {
					document.close();
				} catch (final Exception e) {
					Log.error(loginNo, e);
				}
			}
		}
	}

	/**
	 * CSV�쐬���C�����W�b�N
	 * @param logiNo ���O�C���Ј��ԍ�
	 * @param moralBean ���[�U���͏��
	 * @param isMoralSurveyAll �S�Ѓ����[���T�[�x�C�Q�ƌ���
	 * @return String
	 * @throws RemoteException
	 * @throws NamingException
	 * @throws CreateException
	 * @throws SQLException
	 */
	public String makeCSV(final String loginNo, final PEF_MoralSurveyReportValueBean moralBean, final boolean isMoralSurveyAll) throws RemoteException, NamingException, CreateException, SQLException {

		try {
			String csvData = "";
			Log.transaction(loginNo, true, "");
			// EJBHome�̎擾
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PEF_MoralSurveyReportEJBHome my_home = (PEF_MoralSurveyReportEJBHome) fact.lookup(PEF_MoralSurveyReportEJBHome.class);

			/* EJBObject�̎擾 */
			final PEF_MoralSurveyReportEJB userSession = my_home.create();
			Log.transaction(loginNo, false, "");
			final String shukei = moralBean.getShukei();
			PEF_MoralSurveyReportPDFValueBean valueBean = null;

			final String busho = moralBean.getBushoNm();
			final String assessment = (moralBean.getAssessmentKikan())[4];
			final String bunseki = moralBean.getBunsekiNm();

			final HashMap allMap = userSession.getPDFDataAll(loginNo, moralBean);
			final ArrayList moralList = userSession.getMoralMaster(loginNo, moralBean.getBunseki());
			// �Œ�\���l���擾
			final String minNum = this.getSystemParameter(loginNo, PEF_MoralSurveyReportBean.MORAL_BUNRUI, PEF_MoralSurveyReportBean.MORALESURVEY_SHOW_LEAST_COUNT);
			// �����[���T�[�x�C臒l�擾
			final String thresHold = this.getSystemParameter(loginNo, PEF_MoralSurveyReportBean.MORAL_BUNRUI, PEF_MoralSurveyReportBean.MORALESURVEY_THRESHOLD);

			final PEF_MoralSurveyReportPDFBean pBean = new PEF_MoralSurveyReportPDFBean(busho, assessment, bunseki, moralBean.getBusho(), moralBean.getBushoNm(), null);
			// �g�D�I��
			if (PEF_MoralSurveyReportValueBean.SHUKEI_SOSHIKI.equals(shukei)) {
				valueBean = userSession.getPDFDataSoshiki(loginNo, moralBean);
				valueBean.setAllPdfMap(allMap);
				valueBean.setMoralList(moralList);
				valueBean.setMinGroupNum(new Integer(minNum).intValue());
				valueBean.setMoralSurveyAll(isMoralSurveyAll);
				valueBean.setThresHold(new Double(thresHold).doubleValue());
				csvData = pBean.makeCsvSoshiki(valueBean);
			}
			// ��E�I��
			else if (PEF_MoralSurveyReportValueBean.SHUKEI_YAKUSHOKU.equals(shukei)) {
				valueBean = userSession.getPDFDataYakushoku(loginNo, moralBean);
				valueBean.setAllPdfMap(allMap);
				valueBean.setMoralList(moralList);
				valueBean.setMinGroupNum(new Integer(minNum).intValue());
				valueBean.setMoralSurveyAll(isMoralSurveyAll);
				valueBean.setThresHold(new Double(thresHold).doubleValue());
				csvData = pBean.makeCsvYakushoku(valueBean);
			}
			// �N��I��
			else if (PEF_MoralSurveyReportValueBean.SHUKEI_NENDAI.equals(shukei)) {
				valueBean = userSession.getPDFDataNendai(loginNo, moralBean);
				valueBean.setAllPdfMap(allMap);
				valueBean.setMoralList(moralList);
				valueBean.setMinGroupNum(new Integer(minNum).intValue());
				valueBean.setMoralSurveyAll(isMoralSurveyAll);
				valueBean.setThresHold(new Double(thresHold).doubleValue());
				csvData = pBean.makeCsvNendai(valueBean);
			}
			return csvData;
		} catch (final NumberFormatException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final RemoteException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final SQLException e) {
			Log.error(loginNo, e);
			throw e;
		}
	}
}
