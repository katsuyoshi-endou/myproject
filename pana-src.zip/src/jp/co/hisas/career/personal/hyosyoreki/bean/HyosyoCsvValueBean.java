package jp.co.hisas.career.personal.hyosyoreki.bean;

import jp.co.hisas.career.personal.util.CsvValueBean;

/**
 * �\����CSV�̏o�͓��e�i�P���R�[�h���j��ێ�����
 *
 */
public class HyosyoCsvValueBean extends CsvValueBean {
	/** ����NO */
	private String shimeiNo = null;

	/** ���� */
	private String shimei = null;

	/** ������ */
	private String busyo = null;

	/** �敪 */
	private String kubun = null;

	/** �\���� */
	private String hyosyoName = null;

	/** ���� */
	private String tokyu = null;

	/** ���� */
	private String kenmei = null;

	/** ��ܔN�� */
	private String jusyoNengetsu = null;
	
	/** ����J */
	private String hikokai = null;

	public String getBusyo() {
		return busyo;
	}

	public void setBusyo(String busyo) {
		this.busyo = busyo;
	}

	public String getHyosyoName() {
		return hyosyoName;
	}

	public void setHyosyoName(String hyosyoName) {
		this.hyosyoName = hyosyoName;
	}

	public String getJusyoNengetsu() {
		return jusyoNengetsu;
	}

	public void setJusyoNengetsu(String jusyoNengetsu) {
		this.jusyoNengetsu = jusyoNengetsu;
	}

	public String getKenmei() {
		return kenmei;
	}

	public void setKenmei(String kenmei) {
		this.kenmei = kenmei;
	}

	public String getKubun() {
		return kubun;
	}

	public void setKubun(String kubun) {
		this.kubun = kubun;
	}

	public String getShimei() {
		return shimei;
	}

	public void setShimei(String shimei) {
		this.shimei = shimei;
	}

	public String getShimeiNo() {
		return shimeiNo;
	}

	public void setShimeiNo(String shimeiNo) {
		this.shimeiNo = shimeiNo;
	}

	public String getTokyu() {
		return tokyu;
	}

	public void setTokyu(String tokyu) {
		this.tokyu = tokyu;
	}

	public String getHikokai() {
		return hikokai;
	}

	public void setHikokai(String hikokai) {
		this.hikokai = hikokai;
	}


}
