/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.personal.hyosyoreki.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Writer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.personal.accesslog.bean.AccesslogBean;
import jp.co.hisas.career.personal.hyosyoreki.bean.HyosyoCsvValueBean;
import jp.co.hisas.career.personal.hyosyoreki.bean.HyosyorekiBean;
import jp.co.hisas.career.personal.util.CsvConditionHeaderValueBean;
import jp.co.hisas.career.personal.util.CsvValueBeanList;
import jp.co.hisas.career.plan.base.VelocityHelper;
import jp.co.hisas.career.search.jiyukensaku.bean.JiyuKensakuBean;
import jp.co.hisas.career.util.common.PZZ050_FileUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �p�[�\�i�� �\������CSV�f�[�^�o�͂��s��
 */
public class CsvHyosyorekiServlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
	 * @param response Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet�̐���ȏ������W����ꂽ���ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = null;
		try {
			final HttpSession session = request.getSession(false);
			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean userinfobean = (UserInfoBean) session.getAttribute("userinfo");
				final AccesslogBean accesslogbean = (AccesslogBean) session.getAttribute("accesslog");
				login_no = userinfobean.getLogin_no();
				/* �J�n���O�o�� */
				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				/* CSV�o�̓t���O�̎擾 */
				final String csv_flg = request.getParameter("Csv_flg");

				/* �\����Bean�擾 */
				HyosyorekiBean hyosyorekibean = (HyosyorekiBean) session.getAttribute("hyosyoreki");
				if (hyosyorekibean == null) {
					hyosyorekibean = new HyosyorekiBean();
					session.setAttribute("hyosyoreki", hyosyorekibean);
				}

				String simei_no = "";
				String simei_no_2 = "";
				String simei_no_flg = "";
				String kanji_simei = "";
				String busyo_ryakusyo = "";
				String server = "";
				int count = 0;
				final String hikokai = "����J";
				String syoriID = "";
				String logsimei = "";
				String logjouken = "";

				simei_no = userinfobean.getSimei_no();
				server = userinfobean.getServer();

				//CSV ValueBeanList���쐬�i�e�ʁj
				CsvValueBeanList valueBeanList = new CsvValueBeanList();
				
				//�w�b�_�̐ݒ�
				HyosyoCsvValueBean header = new HyosyoCsvValueBean();
				header.setShimeiNo((String) ReadFile.paramMapData.get("DZZ002"));
				header.setShimei((String) ReadFile.paramMapData.get("DZZ001"));
				header.setBusyo((String) ReadFile.paramMapData.get("DZZ013"));
				header.setKubun((String) ReadFile.paramMapData.get("DZZ215"));
				header.setHyosyoName((String) ReadFile.paramMapData.get("DZZ093"));
				header.setTokyu((String) ReadFile.paramMapData.get("DZZ090"));
				header.setKenmei((String) ReadFile.paramMapData.get("DZZ091"));
				header.setJusyoNengetsu((String) ReadFile.paramMapData.get("DZZ092"));
				//�e�ʂɊi�[
				valueBeanList.setHeader(header);

				/* ���R������������CSV�o�͂̏ꍇ */
				if (csv_flg.equals("1")) {
					final JiyuKensakuBean kensakubean = (JiyuKensakuBean) session.getAttribute("jiyukensaku");
					/* �K�{���� */
					final String kekka[][] = kensakubean.getKekka();
					if (kekka != null) {
						count = kekka.length - 1;
					} else {
						count = 0;
					}
					/* �����������w�b�_�ɏo�� */
					logjouken = kensakubean.getSQL1JP() + " " + kensakubean.getSQL2JP() + " " + kensakubean.getSQL3JP() + " " + kensakubean.getSQL4JP() + " " + kensakubean.getSQL5JP();
					if (request.getParameter("kensakujyoken") != null) {
						final String SQL1JP = kensakubean.getSQL1JP();
						final String SQL2JP = kensakubean.getSQL2JP();
						final String SQL3JP = kensakubean.getSQL3JP();
						final String SQL4JP = kensakubean.getSQL4JP();
						final String SQL5JP = kensakubean.getSQL5JP();

						//�ǉ��w�b�_���i�[����ValueBeanList
						CsvValueBeanList addHeaderList = new CsvValueBeanList();
						CsvConditionHeaderValueBean addHeader = null;

						if (SQL1JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL1JP);
							addHeaderList.add(addHeader);
						}
						if (SQL2JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL2JP);
							addHeaderList.add(addHeader);
						}
						if (SQL3JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL3JP);
							addHeaderList.add(addHeader);
						}
						if (SQL4JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL4JP);
							addHeaderList.add(addHeader);
						}
						if (SQL5JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL5JP);
							addHeaderList.add(addHeader);
						}

						//�e��ValueBeanList�ɒǉ��w�b�_��ݒ�
						valueBeanList.setAdditionalHeader(addHeaderList);
					}

					for (int i = 0; i < count; i++) {

						/* �w�b�_�o�� */
						simei_no = kekka[i][0]; // ����NO

						userinfobean.searchsansyo(simei_no, server, "1");
						simei_no_flg = userinfobean.getSimei_no_flg();
						kanji_simei = userinfobean.getKanji_simei();

						if (!simei_no_flg.equals(hikokai)) {
							/* ����NO�̓��ꌅ�폜 */
							simei_no_flg = simei_no_flg.substring(1, simei_no_flg.length());
						}

						if (!kanji_simei.equals(hikokai)) {
							/* �����i�����j�̓��ꌅ�폜 */
							final int kanji_simei_length = kanji_simei.length();
							kanji_simei = kanji_simei.substring(1, kanji_simei_length);
						}

						if (!userinfobean.getBusyo_ryakusyo_mei().equals(hikokai)) {
							/* �������̖��̓��ꌅ�폜 */
							final int busyo_ryakusyou_length = userinfobean.getBusyo_ryakusyo_mei().length();
							busyo_ryakusyo = userinfobean.getBusyo_ryakusyo_mei().substring(1, busyo_ryakusyou_length);
						} else {
							busyo_ryakusyo = userinfobean.getBusyo_ryakusyo_mei();
						}

						/* �f�[�^�o�� */
						if (userinfobean.getFlg().equals("0") || !userinfobean.getHyosyo_kokai_flg().equals("����J")) {

							hyosyorekibean.searchhyosyoreki(simei_no, login_no, server);
							/* ���R�[�h�� */
							final int hyosyoreki_count = hyosyorekibean.getCount();
							/* �\�����f�[�^ */
							final String[][] hyosyoreki_data = hyosyorekibean.getHyosyoreki();

							/* �\�����f�[�^�o�� */
							HyosyoCsvValueBean valueBean = null;
							for (int k = 0; k < hyosyoreki_count; k++) {
								
								valueBean = new HyosyoCsvValueBean();
								valueBean.setShimeiNo(simei_no_flg);
								valueBean.setShimei(kanji_simei);
								valueBean.setBusyo(busyo_ryakusyo);
								valueBean.setKubun(hyosyoreki_data[k][4]);
								valueBean.setHyosyoName(hyosyoreki_data[k][0]);
								valueBean.setTokyu(hyosyoreki_data[k][1]);
								valueBean.setKenmei(hyosyoreki_data[k][2]);
								valueBean.setJusyoNengetsu(hyosyoreki_data[k][3].trim());
								
								//�e�ʂɊi�[
								valueBeanList.add(valueBean);
							}

							/* �A�N�Z�X���O�b�r�u�o�͉񐔂��P���₷ */
							accesslogbean.hyosyorekiCsvCount();

						} else {
							HyosyoCsvValueBean valueBean = new HyosyoCsvValueBean();
							valueBean.setShimeiNo(simei_no_flg);
							valueBean.setShimei(kanji_simei);
							valueBean.setBusyo(busyo_ryakusyo);
							//����J
							valueBean.setHikokai(hikokai);
							
							valueBeanList.add(valueBean);
						}
					}

					syoriID = "PPP050";
					OutLogBean.sousaKojinJohoLog(syoriID, login_no, logsimei, logjouken);
					/* �p�[�\�i���v���t�@�C������̂b�r�u�o�͂̏ꍇ */
				} else {
					/* UserInfoBean���f�[�^�擾 */
					simei_no = userinfobean.getSimei_no_flg(); // ����NO
					simei_no_2 = userinfobean.getSimei_no(); // ����NO�t���O�Ȃ�
					kanji_simei = userinfobean.getKanji_simei(); // �����i�����j
					busyo_ryakusyo = userinfobean.getBusyo_ryakusyo_mei();// �������̖�
					login_no = userinfobean.getLogin_no();

					if (!simei_no.equals(hikokai)) {
						/* ����NO�̓��ꌅ�폜 */
						simei_no = simei_no.substring(1, simei_no.length());
					}

					if (!kanji_simei.equals(hikokai)) {
						/* �����i�����j�̓��ꌅ�폜 */
						final int kanji_simei_length = kanji_simei.length();
						kanji_simei = kanji_simei.substring(1, kanji_simei_length);
					}

					if (!busyo_ryakusyo.equals(hikokai)) {
						/* �������̖��̓��ꌅ�폜 */
						final int busyo_ryakusyou_length = busyo_ryakusyo.length();
						busyo_ryakusyo = busyo_ryakusyo.substring(1, busyo_ryakusyou_length);
					}

					/* �\�����f�[�^�o�� */
					/* �Z�L�����e�B�`�F�b�N */
					if (userinfobean.getFlg().equals("0") || !userinfobean.getHyosyo_kokai_flg().equals("����J")) {
						hyosyorekibean.searchhyosyoreki(simei_no_2, login_no, server);
						/* ���R�[�h�� */
						final int hyosyoreki_count = hyosyorekibean.getCount();
						/* �\�����f�[�^ */
						final String[][] hyosyoreki_data = hyosyorekibean.getHyosyoreki();

						HyosyoCsvValueBean valueBean = null;
						
						for (int k = 0; k < hyosyoreki_count; k++) {
							
							valueBean = new HyosyoCsvValueBean();
							valueBean.setShimeiNo(simei_no);
							valueBean.setShimei(kanji_simei);
							valueBean.setBusyo(busyo_ryakusyo);
							valueBean.setKubun(hyosyoreki_data[k][4]);
							valueBean.setHyosyoName(hyosyoreki_data[k][0]);
							valueBean.setTokyu(hyosyoreki_data[k][1]);
							valueBean.setKenmei(hyosyoreki_data[k][2]);
							valueBean.setJusyoNengetsu(hyosyoreki_data[k][3].trim());

							//�e�ʂɊi�[
							valueBeanList.add(valueBean);
						}

						/* �A�N�Z�X���O�b�r�u�o�͉񐔂��P���₷ */
						accesslogbean.hyosyorekiCsvCount();

					} else {
						
						HyosyoCsvValueBean valueBean = new HyosyoCsvValueBean();
						valueBean.setShimeiNo(simei_no);
						valueBean.setShimei(kanji_simei);
						valueBean.setBusyo(busyo_ryakusyo);
						//����J
						valueBean.setHikokai(hikokai);
						
						//�e�ʂɊi�[
						valueBeanList.add(valueBean);
						
					}

					logsimei = simei_no_2;
					syoriID = "PPP015";
					OutLogBean.sousaKojinJohoLog(syoriID, login_no, logsimei, logjouken);
				}
				/* Velocity��p���āA�o�̓t�@�C���e���v���[�g�Ƀf�[�^��ݒ肷�� */
				final VelocityHelper vh = new VelocityHelper(HcdbDef.HYOSYOREKI_CSV_TEMPLATE);
				vh.setParameter("BeanList", valueBeanList);
				final Writer w = vh.getWriter();
				final ByteArrayInputStream bais = new ByteArrayInputStream(w.toString().getBytes());
				request.setAttribute("H080_FileName", PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_PERSONAL_HYOSYOREKI_CSV, new String[] { login_no }));
				request.setAttribute("H081_ContentType", HcdbDef.CONTENT_TYPE);
				request.setAttribute("STREAM", bais);
				
				final RequestDispatcher rd = this.ctx.getRequestDispatcher("/servlet/PYE010_FileDownloadServlet");
				rd.forward(request, response);

				/* �I�����O�o�� */
				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}
}