package jp.co.hisas.career.personal.syagai.bean;

import jp.co.hisas.career.personal.util.CsvValueBean;

/**
 * �ЊO��������CSV�o�͓��e�P���R�[�h����ێ�����B
 *
 */
public class SyagaiCsvValueBean extends CsvValueBean {

	/** ����NO */
	private String shimeiNo = null;

	/** ���� */
	private String shimei = null;

	/** ������ */
	private String busyo = null;

	/** �J�n�N�� */
	private String kaishiNengappi = null;

	/** �I���N�� */
	private String shuryoNengappi = null;

	/** �敪 */
	private String kubun = null;

	/** ���� */
	private String meisyo = null;

	/** ��E */
	private String yakusyoku = null;

	/** ��Ȋ������e */
	private String katudoNaiyo = null;
	
	/** ����J */
	private String hikokai = null;

	public String getBusyo() {
		return busyo;
	}

	public void setBusyo(String busyo) {
		this.busyo = busyo;
	}

	public String getKaishiNengappi() {
		return kaishiNengappi;
	}

	public void setKaishiNengappi(String kaishiNengappi) {
		this.kaishiNengappi = kaishiNengappi;
	}

	public String getKatudoNaiyo() {
		return katudoNaiyo;
	}

	public void setKatudoNaiyo(String katudoNaiyo) {
		this.katudoNaiyo = katudoNaiyo;
	}

	public String getKubun() {
		return kubun;
	}

	public void setKubun(String kubun) {
		this.kubun = kubun;
	}

	public String getMeisyo() {
		return meisyo;
	}

	public void setMeisyo(String meisyo) {
		this.meisyo = meisyo;
	}

	public String getShimei() {
		return shimei;
	}

	public void setShimei(String shimei) {
		this.shimei = shimei;
	}

	public String getShimeiNo() {
		return shimeiNo;
	}

	public void setShimeiNo(String shimeiNo) {
		this.shimeiNo = shimeiNo;
	}

	public String getShuryoNengappi() {
		return shuryoNengappi;
	}

	public void setShuryoNengappi(String shuryoNengappi) {
		this.shuryoNengappi = shuryoNengappi;
	}

	public String getYakusyoku() {
		return yakusyoku;
	}

	public void setYakusyoku(String yakusyoku) {
		this.yakusyoku = yakusyoku;
	}

	public String getHikokai() {
		return hikokai;
	}

	public void setHikokai(String hikokai) {
		this.hikokai = hikokai;
	}
	
}
