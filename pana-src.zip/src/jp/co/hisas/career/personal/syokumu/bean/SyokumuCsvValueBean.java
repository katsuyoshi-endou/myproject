package jp.co.hisas.career.personal.syokumu.bean;

import jp.co.hisas.career.personal.util.CsvValueBean;

/**
 * �E�����e��CSV�̏o�͓��e�i�P���R�[�h���j��ێ�����B
 *
 */
public class SyokumuCsvValueBean extends CsvValueBean {

	/** ����NO */
	private String shimeiNo = null;

	/** ���� */
	private String shimei = null;

	/** ���� */
	private String busyo = null;

	/** �v���W�F�N�g�i�Ɩ��j�� */
	private String projectName = null;

	/** �ڋq�� */
	private String kokyakuName = null;

	/** ����z�iK���j */
	private String uriagegaku = null;

	/** ���l�����i�l�j */
	private String sojinin = null;

	/** �J���X�e�b�v���iKS�j */
	private String kaihatsuStep = null;

	/** �J�n�� */
	private String kaishiBi = null;

	/** �I���� */
	private String shuryoBi = null;

	/** ���� */
	private String syokumuBusyo = null;

	/** �E�ʃ��x���P */
	private String syokuiLevel1 = null;

	/** �E�ʃ��x���Q */
	private String syokuiLevel2 = null;

	/** �E���T�v */
	private String syokumuGaiyo = null;

	/** �v�� */
	private String pre = null;

	/** �R���T���e�[�V���� */
	private String consul = null;

	/** �݌v */
	private String sekkei = null;

	/** ���ݒ� */
	private String kankyoSettei = null;

	/** �����E�v���O�����쐬 */
	private String jisso = null;

	/** �g���� */
	private String kumiawase = null;

	/** �e�X�g�E���� */
	private String test = null;

	/** �ڍs�E�{�ԏ��� */
	private String iko = null;

	/** �]���E�^�p�ێ� */
	private String hyoka = null;

	/** �t�H���[ */
	private String follow = null;

	/** �����J�� */
	private String kenkyu = null;

	/** �n�r_1 */
	private String os1 = null;

	/** �n�r_1_VerNo. */
	private String os1Ver = null;

	/** �n�r_2 */
	private String os2 = null;

	/** �n�r_2_VerNo. */
	private String os2Ver = null;

	/** �I�����C���^�l�b�g���[�N_1 */
	private String online1 = null;

	/** O/N_1_VerNo. */
	private String online1Ver = null;

	/** �I�����C���^�l�b�g���[�N_2 */
	private String online2 = null;

	/** O/N_2_VerNo. */
	private String online2Ver = null;

	/** �c�a�l�r_1 */
	private String dbms1 = null;

	/** �c�a�l�r_1_VerNo. */
	private String dbms1Ver = null;

	/** �c�a�l�r_2 */
	private String dbms2 = null;

	/** �c�a�l�r_2_VerNo. */
	private String dbms2Ver = null;

	/** �v���O��������_1 */
	private String program1 = null;

	/** �X�e�b�v(ks) */
	private String program1Step = null;

	/** �v���O��������_2 */
	private String program2 = null;

	/** �X�e�b�v(ks) */
	private String program2Step = null;

	/** ���̑����i�E�Z�p_1 */
	private String sonotaSeihin1 = null;

	/** ���̑����i�E�Z�p_2 */
	private String sonotaSeihin2 = null;

	/** ���̑����i�E�Z�p_3 */
	private String sonotaSeihin3 = null;

	/** ���i�E�Z�p�m���̏ڍד��e */
	private String seihinSyosai = null;

	/** �l�H�m�\ */
	private String jinkoChino = null;

	/** �}���E�}�V���E�V�X�e�� */
	private String manMachineSystem = null;

	/** �f�[�^�x�[�X�V�X�e�� */
	private String databaseSystem = null;

	/** ���U�����V�X�e�� */
	private String bunsanSystem = null;

	/** �R���s���[�^�l�b�g���[�N */
	private String computerNetwork = null;

	/** �R���s���[�^�r�W���� */
	private String computerVision = null;

	/** �C���[�W�v���Z�b�V���O */
	private String imageProcessing = null;

	/** �I�y���[�e�B���O�V�X�e�� */
	private String operatingSystem = null;

	/** �V�X�e�����\�]�� */
	private String systemHyoka = null;

	/** �v�Z�@�A�[�L�e�N�`�� */
	private String keisankiArc = null;

	/** �O���t�B�b�N�X�E�b�`�c */
	private String graphic = null;

	/** �������� */
	private String bunshoShori = null;

	/** ���l��� */
	private String suchiKaiseki = null;

	/** �A���S���Y�� */
	private String argorithm = null;

	/** �O���[�v�E�F�A */
	private String groupware = null;

	/** �R���s���[�^�Z�L�����e�B */
	private String computerSecurity = null;

	/** �L������ */
	private String kigoShori = null;

	/** �v���O�������� */
	private String programLanguage = null;

	/** ��񏈗��Z�p1 */
	private String johoShori1 = null;

	/** ��񏈗��Z�p2 */
	private String johoShori2 = null;

	/** ��񏈗��Z�p3 */
	private String johoShori3 = null;

	/** �ڋq�Ǝ햼 */
	private String kokyakuGyoshuName = null;

	/** ���Y�Ɩ��� */
	private String togaiGyoshuName = null;

	/** �Ǝ�E�Ɩ��m���̏ڍד��e */
	private String gyoshuShosaiNaiyo = null;

	/** ���[�_�V�b�v */
	private String leaderShip = null;

	/** �R�~���j�P�[�V���� */
	private String comunication = null;

	/** �l�S�V�G�[�V���� */
	private String nego = null;

	/** ������ */
	private String mondaiKaiketsu = null;

	/** �g�D�� */
	private String soshikika = null;

	/** �W��(�K�i)�Ɩ@�K */
	private String hyojun = null;

	/** ���ۉ� */
	private String kokusaika = null;

	/** �����}�l�[�W�����g */
	private String togoManagement = null;

	/** �X�R�[�v�}�l�[�W�����g */
	private String scopeManagement = null;

	/** �^�C���}�l�[�W�����g */
	private String timeManagement = null;

	/** �R�X�g�}�l�[�W�����g */
	private String costManagement = null;

	/** �i���}�l�[�W�����g */
	private String hinsitsuManagement = null;

	/** �g�D�}�l�[�W�����g */
	private String soshikiManagement = null;

	/** ���X�N�}�l�[�W�����g */
	private String riskManagement = null;

	/** �R�~���j�P�[�V�����}�l�[�W�����g */
	private String comunicationManagement = null;

	/** ���B�}�l�[�W�����g */
	private String tyotatsuManagement = null;

	/** �����W */
	private String johoShushu = null;

	/** �ڋq�܏� */
	private String kokyakuSessho = null;

	/** ��Ċ��� */
	private String teianKatsudo = null;

	/** �v���[���e�[�V���� */
	private String presentation = null;

	/** �`�F���W�}�l�[�W�����g */
	private String changeManagement = null;

	/** �V�K��� */
	private String shinkiKikaku = null;

	/** �l���\�z */
	private String jinmyakuKochiku = null;

	/** �g���u���Ή� */
	private String troubleTaio = null;

	/** ��w */
	private String gogaku = null;

	/** �r�W�l�X�X�L���̏ڍד��e */
	private String buisinessSkillSyosaiNaiyo = null;

	/** ����J */
	private String hikokai = null;

	public String getArgorithm() {
		return argorithm;
	}

	public void setArgorithm(String argorithm) {
		this.argorithm = argorithm;
	}

	public String getBuisinessSkillSyosaiNaiyo() {
		return buisinessSkillSyosaiNaiyo;
	}

	public void setBuisinessSkillSyosaiNaiyo(String buisinessSkillSyosaiNaiyo) {
		this.buisinessSkillSyosaiNaiyo = buisinessSkillSyosaiNaiyo;
	}

	public String getBunsanSystem() {
		return bunsanSystem;
	}

	public void setBunsanSystem(String bunsanSystem) {
		this.bunsanSystem = bunsanSystem;
	}

	public String getBunshoShori() {
		return bunshoShori;
	}

	public void setBunshoShori(String bunshoShori) {
		this.bunshoShori = bunshoShori;
	}

	public String getBusyo() {
		return busyo;
	}

	public void setBusyo(String busyo) {
		this.busyo = busyo;
	}

	public String getChangeManagement() {
		return changeManagement;
	}

	public void setChangeManagement(String changeManagement) {
		this.changeManagement = changeManagement;
	}

	public String getComputerNetwork() {
		return computerNetwork;
	}

	public void setComputerNetwork(String computerNetwork) {
		this.computerNetwork = computerNetwork;
	}

	public String getComputerSecurity() {
		return computerSecurity;
	}

	public void setComputerSecurity(String computerSecurity) {
		this.computerSecurity = computerSecurity;
	}

	public String getComputerVision() {
		return computerVision;
	}

	public void setComputerVision(String computerVision) {
		this.computerVision = computerVision;
	}

	public String getComunication() {
		return comunication;
	}

	public void setComunication(String comunication) {
		this.comunication = comunication;
	}

	public String getComunicationManagement() {
		return comunicationManagement;
	}

	public void setComunicationManagement(String comunicationManagement) {
		this.comunicationManagement = comunicationManagement;
	}

	public String getConsul() {
		return consul;
	}

	public void setConsul(String consul) {
		this.consul = consul;
	}

	public String getCostManagement() {
		return costManagement;
	}

	public void setCostManagement(String costManagement) {
		this.costManagement = costManagement;
	}

	public String getDatabaseSystem() {
		return databaseSystem;
	}

	public void setDatabaseSystem(String databaseSystem) {
		this.databaseSystem = databaseSystem;
	}

	public String getDbms1() {
		return dbms1;
	}

	public void setDbms1(String dbms1) {
		this.dbms1 = dbms1;
	}

	public String getDbms1Ver() {
		return dbms1Ver;
	}

	public void setDbms1Ver(String dbms1Ver) {
		this.dbms1Ver = dbms1Ver;
	}

	public String getDbms2() {
		return dbms2;
	}

	public void setDbms2(String dbms2) {
		this.dbms2 = dbms2;
	}

	public String getDbms2Ver() {
		return dbms2Ver;
	}

	public void setDbms2Ver(String dbms2Ver) {
		this.dbms2Ver = dbms2Ver;
	}

	public String getFollow() {
		return follow;
	}

	public void setFollow(String follow) {
		this.follow = follow;
	}

	public String getGogaku() {
		return gogaku;
	}

	public void setGogaku(String gogaku) {
		this.gogaku = gogaku;
	}

	public String getGraphic() {
		return graphic;
	}

	public void setGraphic(String graphic) {
		this.graphic = graphic;
	}

	public String getGroupware() {
		return groupware;
	}

	public void setGroupware(String groupware) {
		this.groupware = groupware;
	}

	public String getGyoshuShosaiNaiyo() {
		return gyoshuShosaiNaiyo;
	}

	public void setGyoshuShosaiNaiyo(String gyoshuShosaiNaiyo) {
		this.gyoshuShosaiNaiyo = gyoshuShosaiNaiyo;
	}

	public String getHikokai() {
		return hikokai;
	}

	public void setHikokai(String hikokai) {
		this.hikokai = hikokai;
	}

	public String getHinsitsuManagement() {
		return hinsitsuManagement;
	}

	public void setHinsitsuManagement(String hinsitsuManagement) {
		this.hinsitsuManagement = hinsitsuManagement;
	}

	public String getHyojun() {
		return hyojun;
	}

	public void setHyojun(String hyojun) {
		this.hyojun = hyojun;
	}

	public String getHyoka() {
		return hyoka;
	}

	public void setHyoka(String hyoka) {
		this.hyoka = hyoka;
	}

	public String getIko() {
		return iko;
	}

	public void setIko(String iko) {
		this.iko = iko;
	}

	public String getImageProcessing() {
		return imageProcessing;
	}

	public void setImageProcessing(String imageProcessing) {
		this.imageProcessing = imageProcessing;
	}

	public String getJinkoChino() {
		return jinkoChino;
	}

	public void setJinkoChino(String jinkoChino) {
		this.jinkoChino = jinkoChino;
	}

	public String getJinmyakuKochiku() {
		return jinmyakuKochiku;
	}

	public void setJinmyakuKochiku(String jinmyakuKochiku) {
		this.jinmyakuKochiku = jinmyakuKochiku;
	}

	public String getJisso() {
		return jisso;
	}

	public void setJisso(String jisso) {
		this.jisso = jisso;
	}

	public String getJohoShori1() {
		return johoShori1;
	}

	public void setJohoShori1(String johoShori1) {
		this.johoShori1 = johoShori1;
	}

	public String getJohoShori2() {
		return johoShori2;
	}

	public void setJohoShori2(String johoShori2) {
		this.johoShori2 = johoShori2;
	}

	public String getJohoShori3() {
		return johoShori3;
	}

	public void setJohoShori3(String johoShori3) {
		this.johoShori3 = johoShori3;
	}

	public String getJohoShushu() {
		return johoShushu;
	}

	public void setJohoShushu(String johoShushu) {
		this.johoShushu = johoShushu;
	}

	public String getKaihatsuStep() {
		return kaihatsuStep;
	}

	public void setKaihatsuStep(String kaihatsuStep) {
		this.kaihatsuStep = kaihatsuStep;
	}

	public String getKaishiBi() {
		return kaishiBi;
	}

	public void setKaishiBi(String kaishiBi) {
		this.kaishiBi = kaishiBi;
	}

	public String getKankyoSettei() {
		return kankyoSettei;
	}

	public void setKankyoSettei(String kankyoSettei) {
		this.kankyoSettei = kankyoSettei;
	}

	public String getKeisankiArc() {
		return keisankiArc;
	}

	public void setKeisankiArc(String keisankiArc) {
		this.keisankiArc = keisankiArc;
	}

	public String getKenkyu() {
		return kenkyu;
	}

	public void setKenkyu(String kenkyu) {
		this.kenkyu = kenkyu;
	}

	public String getKigoShori() {
		return kigoShori;
	}

	public void setKigoShori(String kigoShori) {
		this.kigoShori = kigoShori;
	}

	public String getKokusaika() {
		return kokusaika;
	}

	public void setKokusaika(String kokusaika) {
		this.kokusaika = kokusaika;
	}

	public String getKokyakuGyoshuName() {
		return kokyakuGyoshuName;
	}

	public void setKokyakuGyoshuName(String kokyakuGyoshuName) {
		this.kokyakuGyoshuName = kokyakuGyoshuName;
	}

	public String getKokyakuName() {
		return kokyakuName;
	}

	public void setKokyakuName(String kokyakuName) {
		this.kokyakuName = kokyakuName;
	}

	public String getKokyakuSessho() {
		return kokyakuSessho;
	}

	public void setKokyakuSessho(String kokyakuSessho) {
		this.kokyakuSessho = kokyakuSessho;
	}

	public String getKumiawase() {
		return kumiawase;
	}

	public void setKumiawase(String kumiawase) {
		this.kumiawase = kumiawase;
	}

	public String getLeaderShip() {
		return leaderShip;
	}

	public void setLeaderShip(String leaderShip) {
		this.leaderShip = leaderShip;
	}

	public String getManMachineSystem() {
		return manMachineSystem;
	}

	public void setManMachineSystem(String manMachineSystem) {
		this.manMachineSystem = manMachineSystem;
	}

	public String getMondaiKaiketsu() {
		return mondaiKaiketsu;
	}

	public void setMondaiKaiketsu(String mondaiKaiketsu) {
		this.mondaiKaiketsu = mondaiKaiketsu;
	}

	public String getNego() {
		return nego;
	}

	public void setNego(String nego) {
		this.nego = nego;
	}

	public String getOnline1() {
		return online1;
	}

	public void setOnline1(String online1) {
		this.online1 = online1;
	}

	public String getOnline1Ver() {
		return online1Ver;
	}

	public void setOnline1Ver(String online1Ver) {
		this.online1Ver = online1Ver;
	}

	public String getOnline2() {
		return online2;
	}

	public void setOnline2(String online2) {
		this.online2 = online2;
	}

	public String getOnline2Ver() {
		return online2Ver;
	}

	public void setOnline2Ver(String online2Ver) {
		this.online2Ver = online2Ver;
	}

	public String getOperatingSystem() {
		return operatingSystem;
	}

	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}

	public String getOs1() {
		return os1;
	}

	public void setOs1(String os1) {
		this.os1 = os1;
	}

	public String getOs1Ver() {
		return os1Ver;
	}

	public void setOs1Ver(String os1Ver) {
		this.os1Ver = os1Ver;
	}

	public String getOs2() {
		return os2;
	}

	public void setOs2(String os2) {
		this.os2 = os2;
	}

	public String getOs2Ver() {
		return os2Ver;
	}

	public void setOs2Ver(String os2Ver) {
		this.os2Ver = os2Ver;
	}

	public String getPre() {
		return pre;
	}

	public void setPre(String pre) {
		this.pre = pre;
	}

	public String getPresentation() {
		return presentation;
	}

	public void setPresentation(String presentation) {
		this.presentation = presentation;
	}

	public String getProgram1() {
		return program1;
	}

	public void setProgram1(String program1) {
		this.program1 = program1;
	}

	public String getProgram1Step() {
		return program1Step;
	}

	public void setProgram1Step(String program1Step) {
		this.program1Step = program1Step;
	}

	public String getProgram2() {
		return program2;
	}

	public void setProgram2(String program2) {
		this.program2 = program2;
	}

	public String getProgram2Step() {
		return program2Step;
	}

	public void setProgram2Step(String program2Step) {
		this.program2Step = program2Step;
	}

	public String getProgramLanguage() {
		return programLanguage;
	}

	public void setProgramLanguage(String programLanguage) {
		this.programLanguage = programLanguage;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getRiskManagement() {
		return riskManagement;
	}

	public void setRiskManagement(String riskManagement) {
		this.riskManagement = riskManagement;
	}

	public String getScopeManagement() {
		return scopeManagement;
	}

	public void setScopeManagement(String scopeManagement) {
		this.scopeManagement = scopeManagement;
	}

	public String getSeihinSyosai() {
		return seihinSyosai;
	}

	public void setSeihinSyosai(String seihinSyosai) {
		this.seihinSyosai = seihinSyosai;
	}

	public String getSekkei() {
		return sekkei;
	}

	public void setSekkei(String sekkei) {
		this.sekkei = sekkei;
	}

	public String getShimei() {
		return shimei;
	}

	public void setShimei(String shimei) {
		this.shimei = shimei;
	}

	public String getShimeiNo() {
		return shimeiNo;
	}

	public void setShimeiNo(String shimeiNo) {
		this.shimeiNo = shimeiNo;
	}

	public String getShinkiKikaku() {
		return shinkiKikaku;
	}

	public void setShinkiKikaku(String shinkiKikaku) {
		this.shinkiKikaku = shinkiKikaku;
	}

	public String getShuryoBi() {
		return shuryoBi;
	}

	public void setShuryoBi(String shuryoBi) {
		this.shuryoBi = shuryoBi;
	}

	public String getSojinin() {
		return sojinin;
	}

	public void setSojinin(String sojinin) {
		this.sojinin = sojinin;
	}

	public String getSonotaSeihin1() {
		return sonotaSeihin1;
	}

	public void setSonotaSeihin1(String sonotaSeihin1) {
		this.sonotaSeihin1 = sonotaSeihin1;
	}

	public String getSonotaSeihin2() {
		return sonotaSeihin2;
	}

	public void setSonotaSeihin2(String sonotaSeihin2) {
		this.sonotaSeihin2 = sonotaSeihin2;
	}

	public String getSonotaSeihin3() {
		return sonotaSeihin3;
	}

	public void setSonotaSeihin3(String sonotaSeihin3) {
		this.sonotaSeihin3 = sonotaSeihin3;
	}

	public String getSoshikika() {
		return soshikika;
	}

	public void setSoshikika(String soshikika) {
		this.soshikika = soshikika;
	}

	public String getSoshikiManagement() {
		return soshikiManagement;
	}

	public void setSoshikiManagement(String soshikiManagement) {
		this.soshikiManagement = soshikiManagement;
	}

	public String getSuchiKaiseki() {
		return suchiKaiseki;
	}

	public void setSuchiKaiseki(String suchiKaiseki) {
		this.suchiKaiseki = suchiKaiseki;
	}

	public String getSyokuiLevel1() {
		return syokuiLevel1;
	}

	public void setSyokuiLevel1(String syokuiLevel1) {
		this.syokuiLevel1 = syokuiLevel1;
	}

	public String getSyokuiLevel2() {
		return syokuiLevel2;
	}

	public void setSyokuiLevel2(String syokuiLevel2) {
		this.syokuiLevel2 = syokuiLevel2;
	}

	public String getSyokumuGaiyo() {
		return syokumuGaiyo;
	}

	public void setSyokumuGaiyo(String syokumuGaiyo) {
		this.syokumuGaiyo = syokumuGaiyo;
	}

	public String getSystemHyoka() {
		return systemHyoka;
	}

	public void setSystemHyoka(String systemHyoka) {
		this.systemHyoka = systemHyoka;
	}

	public String getTeianKatsudo() {
		return teianKatsudo;
	}

	public void setTeianKatsudo(String teianKatsudo) {
		this.teianKatsudo = teianKatsudo;
	}

	public String getTest() {
		return test;
	}

	public void setTest(String test) {
		this.test = test;
	}

	public String getTimeManagement() {
		return timeManagement;
	}

	public void setTimeManagement(String timeManagement) {
		this.timeManagement = timeManagement;
	}

	public String getTogaiGyoshuName() {
		return togaiGyoshuName;
	}

	public void setTogaiGyoshuName(String togaiGyoshuName) {
		this.togaiGyoshuName = togaiGyoshuName;
	}

	public String getTogoManagement() {
		return togoManagement;
	}

	public void setTogoManagement(String togoManagement) {
		this.togoManagement = togoManagement;
	}

	public String getTroubleTaio() {
		return troubleTaio;
	}

	public void setTroubleTaio(String troubleTaio) {
		this.troubleTaio = troubleTaio;
	}

	public String getTyotatsuManagement() {
		return tyotatsuManagement;
	}

	public void setTyotatsuManagement(String tyotatsuManagement) {
		this.tyotatsuManagement = tyotatsuManagement;
	}

	public String getUriagegaku() {
		return uriagegaku;
	}

	public void setUriagegaku(String uriagegaku) {
		this.uriagegaku = uriagegaku;
	}

	public String getSyokumuBusyo() {
		return syokumuBusyo;
	}

	public void setSyokumuBusyo(String syokumuBusyo) {
		this.syokumuBusyo = syokumuBusyo;
	}
	
}
