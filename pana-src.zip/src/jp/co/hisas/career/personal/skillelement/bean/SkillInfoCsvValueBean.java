package jp.co.hisas.career.personal.skillelement.bean;

import java.util.ArrayList;
import java.util.List;

public class SkillInfoCsvValueBean {

	/** �X�L���R�[�h */
	private String skillCode = null;
	
	/** �X�L������ */
	private String skillName = null;

	public String getSkillCode() {
		return skillCode;
	}

	public void setSkillCode(String skillCode) {
		this.skillCode = skillCode;
	}

	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	
}
