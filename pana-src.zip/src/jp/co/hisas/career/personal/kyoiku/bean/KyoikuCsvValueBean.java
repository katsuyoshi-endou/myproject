package jp.co.hisas.career.personal.kyoiku.bean;

import jp.co.hisas.career.personal.util.CsvValueBean;

/**
 * �����CSV�̏o�͓��e�i�P���R�[�h���j��ێ�����
 *
 */
public class KyoikuCsvValueBean extends CsvValueBean {

	/** ����NO */
	private String shimeiNo = null;

	/** ���� */
	private String shimei = null;

	/** ������ */
	private String busyo = null;

	/** �ȖڃR�[�h */
	private String kamokuCode = null;

	/** �Ȗږ� */
	private String kamokuName = null;

	/** ��Ì� */
	private String shusaimoto = null;

	/** �N���X */
	private String className = null;

	/** �J�n�� */
	private String kaishiBi = null;

	/** �I���� */
	private String shuryoBi = null;

	/** ���� */
	private String seiseki = null;
	
	/** �P�� */
	private String tanka = null;
	
	/** ���� */
	private String nissu = null;

	/** ����J */
	private String hikokai = null;

	public String getBusyo() {
		return busyo;
	}

	public void setBusyo(String busyo) {
		this.busyo = busyo;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getHikokai() {
		return hikokai;
	}

	public void setHikokai(String hikokai) {
		this.hikokai = hikokai;
	}

	public String getKaishiBi() {
		return kaishiBi;
	}

	public void setKaishiBi(String kaishiBi) {
		this.kaishiBi = kaishiBi;
	}

	public String getKamokuCode() {
		return kamokuCode;
	}

	public void setKamokuCode(String kamokuCode) {
		this.kamokuCode = kamokuCode;
	}

	public String getKamokuName() {
		return kamokuName;
	}

	public void setKamokuName(String kamokuName) {
		this.kamokuName = kamokuName;
	}

	public String getSeiseki() {
		return seiseki;
	}

	public void setSeiseki(String seiseki) {
		this.seiseki = seiseki;
	}

	public String getShimei() {
		return shimei;
	}

	public void setShimei(String shimei) {
		this.shimei = shimei;
	}

	public String getShimeiNo() {
		return shimeiNo;
	}

	public void setShimeiNo(String shimeiNo) {
		this.shimeiNo = shimeiNo;
	}

	public String getShuryoBi() {
		return shuryoBi;
	}

	public void setShuryoBi(String shuryoBi) {
		this.shuryoBi = shuryoBi;
	}

	public String getShusaimoto() {
		return shusaimoto;
	}

	public void setShusaimoto(String shusaimoto) {
		this.shusaimoto = shusaimoto;
	}

	public String getNissu() {
		return nissu;
	}

	public void setNissu(String nissu) {
		this.nissu = nissu;
	}

	public String getTanka() {
		return tanka;
	}

	public void setTanka(String tanka) {
		this.tanka = tanka;
	}
}
