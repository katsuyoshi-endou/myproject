package jp.co.hisas.career.personal.maintenance.servlet;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.personal.personal.ejb.SearchEmpEJB;
import jp.co.hisas.career.personal.personal.ejb.SearchEmpEJBHome;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

public class KnowledgeKanriAddServlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException,
			ServletException {
		String loginNo = null;
		try {
			Log.method(loginNo, "IN", "");

			/* session�X�R�[�v��Beans���擾���� */
			final HttpSession session = request.getSession(false);

			if (session == null) {
				/* JSP�y�[�W���Ăяo�� */
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
				loginNo = bean.getLogin_no();

				final String targetShimeiNo = request.getParameter("shimeiNo");
				final String targetSoshikiCode = request.getParameter("soshikiCode");

				// EJB�̎擾
				final SearchEmpEJBHome my_home = (SearchEmpEJBHome) EJBHomeFactory.getInstance().lookup(
						SearchEmpEJBHome.class);
				final SearchEmpEJB userSession = my_home.create();

				/* �Q�ƃ��[�U�̃p�[�\�i���v���t�@�C����񌟍������J�n */
				Log.transaction(loginNo, true, "");
				final String[] data = userSession.kensaku(loginNo, targetShimeiNo, HcdbDef.HONMU);
				Log.transaction(loginNo, false, "");

				final HashMap personMap = new HashMap();
				if (data != null && data[0] != null && !data[0].equals("")) {
					personMap.put("ShimeiNo", data[0]);
					personMap.put("Shimei", PZZ010_CharacterUtil.cutFirstChar(data[3]));
					personMap.put("SoshikiName", PZZ010_CharacterUtil.cutFirstChar(data[78]));
				} else {
					request.setAttribute("errorMsg", PZZ010_CharacterUtil.normalizedStr((String) ReadFile.messageMapData.get("CBS-VAX172-E001")));
				}

				request.setAttribute("targetUserInfo", personMap);
				request.setAttribute("targetSoshiki", targetSoshikiCode);

				final RequestDispatcher rd = this.ctx
						.getRequestDispatcher("/view/personal/maintenance/VAX172_KnowledgeKanriAddConfirm.jsp");
				rd.forward(request, response);

				Log.method(loginNo, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(loginNo, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}
}
