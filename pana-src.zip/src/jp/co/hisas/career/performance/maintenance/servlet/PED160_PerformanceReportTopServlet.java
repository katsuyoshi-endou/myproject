/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.performance.report.bean.PED_PerformanceReportBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * �p�t�H�[�}���X���|�[�g�I���T�[�u���b�g
 */
public class PED160_PerformanceReportTopServlet extends HttpServlet {

	/** �G���[�y�[�W */
	private static final String ERROR_PAGE = "/view/base/error/VYY_Error.jsp";

	/** �J�ڐ�y�[�W */
	private static final String SUCCESS_PAGE = "/view/performance/maintenance/VED160_PerformanceReportTop.jsp";

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * �������������s���B
	 * @param config
	 * @throws javax.servlet.ServletException
	 * @see javax.servlet.Servlet#init(javax.servlet.ServletConfig)
	 */
	public void init(final ServletConfig config) throws ServletException {
		super.init(config);

		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U����̌����v�����󂯎��A�{�N���X�̎��s���\�b�h���Ăяo���܂��B
	 * @param request ���N�G�X�g
	 * @param response ���X�|���X
	 * @throws ServletException �T�[�u���b�g��O
	 * @throws IOException ���o�͗�O
	 * @see javax.servlet.http.HttpServlet#service( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse )
	 */
	protected void service(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {

		final HttpSession session = request.getSession(false);

		// �Z�b�V�����A�܂���userinfo���擾�ł��Ȃ��ꍇ�A�G���[�y�[�W�֑J��
		if (session == null || (UserInfoBean) session.getAttribute("userinfo") == null) {
			this.ctx.getRequestDispatcher(PED160_PerformanceReportTopServlet.ERROR_PAGE).forward(request, response);
		} else {
			final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");

			// ���O�C�����[�U�擾
			final String loginNo = userinfo.getLogin_no();

			Log.method(loginNo, "IN", "");
			Log.performance(loginNo, true, "");

			final String enqueteNo = request.getParameter("S001_enquete");
			final String reloadFlg = request.getParameter("H002_reloadFlg");
			final PED_PerformanceReportBean performanceReportBean = new PED_PerformanceReportBean();

			ArrayList enqueteList = null;
			ArrayList syozokuList = null;
			String[] status = null;

			try {
				if (enqueteNo != null && "1".equals(reloadFlg) && !"".equals(enqueteNo)) {
					// �������X�g�\���̏���
					syozokuList = performanceReportBean.getM_SyozokuListWithStatus(loginNo, enqueteNo, userinfo.getServer());

					final ArrayList syozokuUniqueList = new ArrayList();
					// [�A���P�[�g:NO]��[�g�D�ʃ��|�[�g:�g�D�R�[�h]������
					final ArrayList enqueteTempList = performanceReportBean.getM_PerformanceReport1(loginNo, enqueteNo, null, null, userinfo.getServer());

					// �A���P�[�gNO�ɕR�t���g�D�̂ݏo��
					if (enqueteTempList != null && enqueteTempList.size() != 0) {
						final HashMap syozokuMap = new HashMap();
						for (int i = 0; i < enqueteTempList.size(); i++) {
							syozokuMap.put(((String[]) enqueteTempList.get(i))[17], "dummy");
						}

						if (syozokuList != null && syozokuList.size() != 0) {
							for (int i = 0; i < syozokuList.size(); i++) {
								if (syozokuMap.get(((String[]) syozokuList.get(i))[2]) != null) {
									syozokuUniqueList.add(syozokuList.get(i));
								}
							}
						}
					}
					request.setAttribute("syozokuList", syozokuUniqueList);
				} else {
					request.setAttribute("syozokuList", syozokuList);
				}

				status = new String[2];
				status[0] = HcdbDef.TEISI_STATUS;
				status[1] = HcdbDef.KOKAI_STATUS;

				/* �A���P�[�g�擾 */
				enqueteList = performanceReportBean.getM_PerformanceReport(loginNo, status, userinfo.getServer());

				// �d��������
				final HashMap enqueteMap = new HashMap();
				final ArrayList enqueteUniqueList = new ArrayList();
				if (enqueteList != null && enqueteList.size() != 0) {
					for (int i = 0; i < enqueteList.size(); i++) {
						if (enqueteMap.get(((String[]) enqueteList.get(i))[0]) == null) {
							enqueteMap.put(((String[]) enqueteList.get(i))[0], "dummy");
							enqueteUniqueList.add(enqueteList.get(i));
						}
					}
				}

				request.setAttribute("enqueteList", enqueteUniqueList);
				request.setAttribute("reloadFlg", request.getParameter("H002_reloadFlg"));
				request.setAttribute("selectedEnqueteNo", enqueteNo);
				request.setAttribute("selectedSyozoku", request.getParameter("S002_syozoku"));
				request.setAttribute("warningMsg", request.getAttribute("warningMsg"));
				// �����������A�Y��JSP�y�[�W�֑J��
				final RequestDispatcher rd = this.ctx.getRequestDispatcher(PED160_PerformanceReportTopServlet.SUCCESS_PAGE);
				rd.forward(request, response);
				Log.performance(loginNo, false, "");
				Log.method(loginNo, "OUT", "");

			} catch (final Exception e) {
				Log.error(loginNo, e);
				this.ctx.getRequestDispatcher(PED160_PerformanceReportTopServlet.ERROR_PAGE).forward(request, response);
			}
		}
	}
}
