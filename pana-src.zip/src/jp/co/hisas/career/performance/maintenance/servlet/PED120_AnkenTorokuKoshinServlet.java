/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.performance.maintenance.bean.PED_AnkenTorokuKoshinBean;
import jp.co.hisas.career.performance.maintenance.bean.PED_AnkenTorokuKoshinValueBean;
import jp.co.hisas.career.performance.util.bean.PED_PerformanceBean;
import jp.co.hisas.career.util.log.Log;

public class PED120_AnkenTorokuKoshinServlet extends HttpServlet {

	/** �G���[�y�[�W */
	private static final String ERROR_PAGE = "/view/base/error/VYY_Error.jsp";

	/** �J�ڐ�y�[�W */
	private static final String SUCCESS_PAGE = "/view/performance/maintenance/VED120_AnkenTorokuKoshin.jsp";

	/** �J�ڐ�y�[�W */
	private static final String VED110 = "/view/performance/maintenance/VED110_QuestionnaireAnkenKanriFrame.jsp";

	private ServletContext ctx = null;

	public void init(final ServletConfig config) throws ServletException {
		super.init(config);

		// ���\�b�h�g���[�X�o��
		Log.method("", "IN", "");

		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
		// ���\�b�h�g���[�X�o��
		Log.method("", "OUT", "");
	}

	public void service(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {

		final HttpSession session = request.getSession(false);

		// �Z�b�V�����A�܂���userinfo���擾�ł��Ȃ��ꍇ�A�G���[�y�[�W�֑J��
		if (session == null || (UserInfoBean) session.getAttribute("userinfo") == null) {
			this.ctx.getRequestDispatcher(PED120_AnkenTorokuKoshinServlet.ERROR_PAGE).forward(request, response);
		} else {
			String loginNo = null;
			try {

				final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");
				loginNo = userinfo.getLogin_no();
				Log.method(loginNo, "IN", "");
				Log.performance(loginNo, true, "");
				// �A���P�[�gBean
				PED_PerformanceBean eBean = (PED_PerformanceBean) session.getAttribute(PED_PerformanceBean.SESSION_KEY);
				if (eBean == null) {
					eBean = new PED_PerformanceBean();
				}
				// �ΏۃA���P�[�g���Bean
				PED_AnkenTorokuKoshinValueBean bean = eBean.getAnkenTorokuKoshinValueBean();
				if (bean == null) {
					bean = new PED_AnkenTorokuKoshinValueBean();
					eBean.setAnkenTorokuKoshinValueBean(bean);
				}
				if (request.getParameter("no") != null && bean.getExecMode() != null) {
					final PED_AnkenTorokuKoshinBean QBean = new PED_AnkenTorokuKoshinBean(userinfo.getLogin_no());
					final ArrayList enquete = new ArrayList();
					enquete.add(request.getParameter("no"));
					enquete.add(request.getParameter("bunrui"));
					enquete.add(request.getParameter("name"));
					enquete.add(request.getParameter("kaishiNgp"));
					enquete.add(request.getParameter("shuryoNgp"));
					enquete.add(request.getParameter("kaishiJikoku"));
					enquete.add(request.getParameter("shuryoJikoku"));
					if (bean.getExecMode() == "new") {
						String bunsekiFlg = request.getParameter("bunseki");
						bunsekiFlg = bunsekiFlg == null ? "0" : "1";
						enquete.add(bunsekiFlg);
					}
					enquete.add(request.getParameter("avg"));
					enquete.add(request.getParameter("osirase"));

					if (bean.getExecMode() == "new") {
						String teamCondFlg = request.getParameter("teamCondFlg");
						teamCondFlg = teamCondFlg == null ? "0" : "1";
						enquete.add(teamCondFlg);
						String busMindFlg = request.getParameter("busMindFlg");
						busMindFlg = busMindFlg == null ? "0" : "1";
						enquete.add(busMindFlg);
						String ldrTraitsFlg = request.getParameter("ldrTraitsFlg");
						ldrTraitsFlg = ldrTraitsFlg == null ? "0" : "1";
						enquete.add(ldrTraitsFlg);
						String satisfactionFlg = request.getParameter("satisfactionFlg");
						satisfactionFlg = satisfactionFlg == null ? "0" : "1";
						enquete.add(satisfactionFlg);
						String competencyFlg = request.getParameter("competencyFlg");
						competencyFlg = competencyFlg == null ? "0" : "1";
						enquete.add(competencyFlg);
					}
					String result = null;
					synchronized (this) {
						result = QBean.enqueteRegister(enquete, bean.getExecMode(), loginNo);
					}

					bean.setResult(result);

					if (bean.getExecMode() == "new") {
						bean.setNo((String) enquete.get(0));
						bean.setBunrui((String) enquete.get(1));
						bean.setName((String) enquete.get(2));
						bean.setKaishiNgp((String) enquete.get(3));
						bean.setKaishiJikoku((String) enquete.get(5));
						bean.setShuryoNgp((String) enquete.get(4));
						bean.setShuryoJikoku((String) enquete.get(6));
						bean.setPerformanceBunsekiFlg((String) enquete.get(7));
						bean.setAverageFlg((String) enquete.get(8));
						bean.setOsirase((String) enquete.get(9));
						bean.setTeamCondFlg((String) enquete.get(10));
						bean.setBusMindFlg((String) enquete.get(11));
						bean.setLdrTraitsFlg((String) enquete.get(12));
						bean.setSatisfactionFlg((String) enquete.get(13));
						bean.setCompetencyFlg((String) enquete.get(14));
					} else {
						// �ΏۃA���P�[�g���擾
						final PED_AnkenTorokuKoshinBean QBean2 = new PED_AnkenTorokuKoshinBean(userinfo.getLogin_no());
						final ArrayList result2 = QBean2.getEnqueteInfo(request.getParameter("no"), loginNo);
						bean.setNo((String) result2.get(0));
						bean.setBunrui((String) result2.get(1));
						bean.setName((String) result2.get(2));
						bean.setKaishiNgp((String) result2.get(3));
						bean.setKaishiJikoku((String) result2.get(5));
						bean.setShuryoNgp((String) result2.get(4));
						bean.setShuryoJikoku((String) result2.get(6));
						bean.setPerformanceBunsekiFlg((String) result2.get(8));
						bean.setAverageFlg((String) result2.get(9));
						bean.setOsirase((String) result2.get(10));
						bean.setTeamCondFlg((String) result2.get(12));
						bean.setBusMindFlg((String) result2.get(13));
						bean.setLdrTraitsFlg((String) result2.get(14));
						bean.setSatisfactionFlg((String) result2.get(15));
						bean.setCompetencyFlg((String) result2.get(16));
					}
				} else {
					final String no = eBean.getEnqueteNo();
					if (no != null) {
						// �ΏۃA���P�[�g���擾
						final PED_AnkenTorokuKoshinBean QBean = new PED_AnkenTorokuKoshinBean(userinfo.getLogin_no());
						final ArrayList result = QBean.getEnqueteInfo(no, loginNo);
						bean.setNo((String) result.get(0));
						bean.setBunrui((String) result.get(1));
						bean.setName((String) result.get(2));
						bean.setKaishiNgp((String) result.get(3));
						bean.setKaishiJikoku((String) result.get(5));
						bean.setShuryoNgp((String) result.get(4));
						bean.setShuryoJikoku((String) result.get(6));
						bean.setStatus((String) result.get(7));
						bean.setPerformanceBunsekiFlg((String) result.get(8));
						bean.setAverageFlg((String) result.get(9));
						bean.setOsirase((String) result.get(10));
						bean.setTeamCondFlg((String) result.get(12));
						bean.setBusMindFlg((String) result.get(13));
						bean.setLdrTraitsFlg((String) result.get(14));
						bean.setSatisfactionFlg((String) result.get(15));
						bean.setCompetencyFlg((String) result.get(16));
						bean.setExecMode("update");
						eBean.setEnqueteNo(null);
						eBean.getAnkenKanriBean().setResultFlg(null);
					}
				}
				// �Y��JSP�y�[�W�֑J��
				String forwardPage = "";
				if (request.getParameter("execMode") != null && request.getParameter("execMode").equals("cancel")) {
					if (bean.getResult().equals("true")) {
						// �G���[�Ȃ�
						forwardPage = PED120_AnkenTorokuKoshinServlet.VED110;
						bean.setResult(null);
					} else {
						// �G���[����
						forwardPage = PED120_AnkenTorokuKoshinServlet.SUCCESS_PAGE;
					}
				} else {
					forwardPage = PED120_AnkenTorokuKoshinServlet.SUCCESS_PAGE;
				}
				final RequestDispatcher rd = this.ctx.getRequestDispatcher(forwardPage);
				rd.forward(request, response);
				Log.performance(loginNo, false, "");
				Log.method(loginNo, "OUT", "");
			} catch (final Exception e) {
				Log.error(loginNo, e);
				this.ctx.getRequestDispatcher(PED120_AnkenTorokuKoshinServlet.ERROR_PAGE).forward(request, response);
			}
		}
	}
}
