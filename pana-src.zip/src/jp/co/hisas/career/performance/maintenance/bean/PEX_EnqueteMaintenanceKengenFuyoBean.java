/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.bean;

import java.util.ArrayList;
import java.util.HashMap;

import javax.naming.NamingException;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.performance.maintenance.ejb.PEX_EnqueteMaintenanceKengenEJB;
import jp.co.hisas.career.performance.maintenance.ejb.PEX_EnqueteMaintenanceKengenEJBHome;
import jp.co.hisas.career.util.log.Log;

public class PEX_EnqueteMaintenanceKengenFuyoBean {

	/** �����ǉ��t���O */
	private static final int kengenTsuika = 0;

	/** �����X�V�t���O */
	private static final int kengenKoshin = 2;

	/** ����ID Performance_ALL */
	public static final String performanceAll = "Performance_ALL";

	/** ����ID Moralsurvey_ALL */
	public static final String moralsurveyAll = "Moralsurvey_All";

	/** ����ID Portfolio_ALL */
	public static final String portfolioAll = "Portfolio_All";

	/** ����ID Skillelement_ALL */
	public static final String skillelementAll = "SkillElementHistory_Management";

	/** ����ID Assessment_ALL */
	public static final String assessmentAll = "Assessment_All";

	/** ����ID EnqueteKanri */
	public static final String enqueteKanri = "EnqueteKanri";

	/** ���O�C��ID */
	private final String login_no = "";

	/** �R���X�g���N�^ */
	public PEX_EnqueteMaintenanceKengenFuyoBean() {

	}

	/**
	 * �A���P�[�g�����e�i���X������ύX����
	 * @param simei_no
	 * @param kengenId
	 * @param opFlg
	 * @return
	 * @throws NamingException
	 * @throws ClassCastException
	 * @throws Exception
	 */
	public int setEnqueteMaintenanceKengen(String simei_no, final String kengenId, int opFlg) throws NamingException, ClassCastException, Exception {
		Log.method(this.login_no, "IN", "");

		// EJB�擾
		final PEX_EnqueteMaintenanceKengenEJBHome my_home = (PEX_EnqueteMaintenanceKengenEJBHome) EJBHomeFactory.getInstance().lookup(PEX_EnqueteMaintenanceKengenEJBHome.class);
		final PEX_EnqueteMaintenanceKengenEJB userSession = my_home.create();

		// ����NO�̗]���ȃX�y�[�X������
		simei_no = simei_no.trim();

		if (opFlg == PEX_EnqueteMaintenanceKengenFuyoBean.kengenTsuika) {
			Log.transaction(this.login_no, true, "");
			final ArrayList result = userSession.getEnqueteMaintenanceKengenRecord(simei_no, kengenId);
			Log.transaction(this.login_no, false, "");
			if (result.size() != 0) {
				opFlg = PEX_EnqueteMaintenanceKengenFuyoBean.kengenKoshin;
			}
		}

		Log.transaction(this.login_no, true, "");
		// �����ύX
		final int val = userSession.setEnqueteMaintenanceKengen(simei_no, kengenId, opFlg);
		Log.transaction(this.login_no, false, "");
		Log.method(this.login_no, "OUT", "");
		return val;
	}

	/**
	 * �Ώۃ��[�U�̃A���P�[�g�����e�i���X�������擾����
	 * @param simei_no
	 * @return boolean
	 * @throws NamingException
	 * @throws ClassCastException
	 * @throws Exception
	 */
	public boolean getKengenFlg(final String simei_no, final String kengenId) throws NamingException, ClassCastException, Exception {

		Log.method(this.login_no, "IN", "");

		// EJB�擾
		final PEX_EnqueteMaintenanceKengenEJBHome my_home = (PEX_EnqueteMaintenanceKengenEJBHome) EJBHomeFactory.getInstance().lookup(PEX_EnqueteMaintenanceKengenEJBHome.class);
		final PEX_EnqueteMaintenanceKengenEJB userSession = my_home.create();

		Log.transaction(this.login_no, true, "");
		final ArrayList tmp = userSession.getEnqueteMaintenanceKengenRecord(simei_no, kengenId);
		Log.transaction(this.login_no, false, "");
		boolean val = true;
		if (tmp.size() == 0) {
			val = false;
		} else {
			val = true;
		}

		Log.method(this.login_no, "OUT", "");
		return val;

	}

	/**
	 * �ΏێЈ��̏����擾���� HashMap SIMEI_NO,KANJI_SIMEI,SOSIKI_MEI
	 * @param simei_no
	 * @param userinfo
	 * @return
	 * @throws NamingException
	 * @throws ClassCastException
	 * @throws Exception
	 */
	public HashMap getTargetSyainInfo(final String simei_no, final UserInfoBean userinfo) throws NamingException, ClassCastException, Exception {
		Log.method(this.login_no, "IN", "");

		// EJB�擾
		final PEX_EnqueteMaintenanceKengenEJBHome my_home = (PEX_EnqueteMaintenanceKengenEJBHome) EJBHomeFactory.getInstance().lookup(PEX_EnqueteMaintenanceKengenEJBHome.class);
		final PEX_EnqueteMaintenanceKengenEJB userSession = my_home.create();

		Log.transaction(this.login_no, true, "");
		final HashMap result = userSession.getSyainInfo(simei_no, "");
		Log.transaction(this.login_no, false, "");
		return result;

	}

}
