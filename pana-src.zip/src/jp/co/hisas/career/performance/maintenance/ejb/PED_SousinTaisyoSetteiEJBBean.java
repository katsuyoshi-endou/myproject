/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;

import javax.ejb.CreateException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * ���M�ΏێҐݒ��DB�A�N�Z�X����
 * @author �Β�
 */
public class PED_SousinTaisyoSetteiEJBBean implements SessionBean {

	/** SessionContext�I�u�W�F�N�g */
	private SessionContext my_ssc = null;

	/** �A���P�[�g�}�X�^ */
	private final String enqueteTbl = HcdbDef.CPM_ENQUETE_TBL;

	/** �A���P�[�g�X�e�[�^�X�}�X�^ */
	private final String statusTbl = HcdbDef.CPM_STATUS_TBL;

	/** �A���P�[�g�g�D�}�X�^ */
	private final String soshikiTbl = HcdbDef.CPM_ENQUETE_SOSHIKI_TBL;

	/** �A���P�[�g��E�}�X�^ */
	private final String yakushokuTbl = HcdbDef.CPM_ENQUETE_YAKUSHOKU_TBL;

	/** �A���P�[�g�}�X�^ �J�������� */
	private final String[] enqueteCol = HcdbDef.CPM_ENQUETE_COLUMNS;

	/** �A���P�[�g�X�e�[�^�X�}�X�^ �J�������� */
	private final String[] statusCol = HcdbDef.CPM_STATUS_COLUMNS;

	/** �A���P�[�g�g�D�}�X�^ �J�������� */
	private final String[] soshikiCol = HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS;

	/** �A���P�[�g��E�}�X�^ �J�������� */
	private final String[] yakushokuCol = HcdbDef.CPM_ENQUETE_YAKUSHOKU_COLUMNS;

	/** �{���g�D */
	private final String honmuSoshiki = "HonmuSoshiki";

	/** �����g�D */
	private final String kenmuSoshiki = "KenmuSoshiki";

	/** �{����E */
	private final String honmuYakushoku = "HonmuYakushoku";

	/** ������E */
	private final String kenmuYakushoku = "KenmuYakushoku";

	/** �A���P�[�g�̃X�e�[�^�X */
	private final String enqueteStatusType = "01";

	/** �Ј��̃X�e�[�^�X */
	private final String shainStatusType = "02";

	/**
	 * �A���P�[�g���擾
	 * @param loginNo ���O�C��NO
	 * @param enqueteNo �A���P�[�gNO
	 * @return �A���P�[�g���
	 */
	public String[] getEnqueteInfo(final String loginNo, final String enqueteNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		// �A���P�[�g���
		final String[] enqueteInfo = new String[3];
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �A���P�[�g���̎擾
			final String sql = "SELECT " + " ENQ." + this.enqueteCol[2] + ", " + " STA." + this.statusCol[2] + " " + "FROM " + this.enqueteTbl + " ENQ LEFT JOIN " + this.statusTbl + " STA "
					+ " ON (ENQ." + this.enqueteCol[7] + " = STA." + this.statusCol[1] + " AND STA." + this.statusCol[0] + " = ?) " + "WHERE " + this.enqueteCol[0] + " = ?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, this.enqueteStatusType);
			pstmt.setString(2, enqueteNo);

			rs = pstmt.executeQuery();
			if (rs.next()) {
				final String enqeuteNm = rs.getString(this.enqueteCol[2]);
				final String statusNm = rs.getString(this.statusCol[2]);

				enqueteInfo[0] = enqueteNo;
				enqueteInfo[1] = enqeuteNm != null ? enqeuteNm : "";
				enqueteInfo[2] = statusNm != null ? statusNm : "";
			}

			Log.method(loginNo, "OUT", "");
			return enqueteInfo;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �����ꗗ�擾
	 * @param loginNo ���O�C��NO
	 * @param enqueteNo �A���P�[�gNO
	 * @return �������X�g
	 */
	public ArrayList getSoshikiList(final String loginNo, final String enqueteNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		// �����ꗗ
		final ArrayList soshikiList = new ArrayList();
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �����ꗗ�̎擾
			final String sql = "SELECT " + " SOSHIKI." + this.soshikiCol[1] + ", " + " SOSHIKI." + this.soshikiCol[2] + ", " + " SOSHIKI." + this.soshikiCol[3] + ", " + " SOSHIKI."
					+ this.soshikiCol[4] + ", " + " SOSHIKI." + this.soshikiCol[6] + " ,SOSHIKI." + this.soshikiCol[5] + " " + "FROM " + "( SELECT * FROM " + this.soshikiTbl + " " + "  WHERE "
					+ this.soshikiCol[0] + " = ? " + ") SOSHIKI " + "START WITH SOSHIKI." + this.soshikiCol[6] + " = 0 " + "CONNECT BY PRIOR SOSHIKI." + this.soshikiCol[2] + " = SOSHIKI."
					+ this.soshikiCol[5] + " " + "ORDER SIBLINGS BY SOSHIKI." + this.soshikiCol[2] + " ASC ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, enqueteNo);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				final String groupID = rs.getString(this.soshikiCol[1]);
				final String soshikiCode = rs.getString(this.soshikiCol[2]);
				final String soshikiMei = rs.getString(this.soshikiCol[3]);
				final String soshikiRenketsuMei = rs.getString(this.soshikiCol[4]);
				final String kaisou = rs.getString(this.soshikiCol[6]);
				final String jouiSoshikiCode = rs.getString(this.soshikiCol[5]);
				soshikiList.add(new String[] {
						groupID != null ? groupID : "",
						soshikiCode != null ? soshikiCode : "",
						soshikiMei != null ? soshikiMei : "",
						soshikiRenketsuMei != null ? soshikiRenketsuMei : "",
						kaisou != null ? kaisou : "",
						jouiSoshikiCode != null ? jouiSoshikiCode : "" });
			}

			Log.method(loginNo, "OUT", "");
			return soshikiList;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * ��E�ꗗ�擾
	 * @param loginNo ���O�C��NO
	 * @param enqueteNo �A���P�[�gNO
	 * @return ��E���X�g
	 */
	public TreeMap getYakushokuMap(final String loginNo, final String enqueteNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		// ��E�ꗗ
		final TreeMap yakushokuMap = new TreeMap();
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// ��E�ꗗ�̎擾
			final String sql = "SELECT " + " YAKUSHOKU." + this.yakushokuCol[1] + ", " + " YAKUSHOKU." + this.yakushokuCol[2] + ", " + " YAKUSHOKU." + this.yakushokuCol[3] + ", " + " YAKUSHOKU."
					+ this.yakushokuCol[4] + " " + "FROM " + " " + this.yakushokuTbl + " YAKUSHOKU " + "WHERE " + this.yakushokuCol[0] + " = ? " + "ORDER BY YAKUSHOKU." + this.yakushokuCol[2]
					+ " ASC ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, enqueteNo);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				final String postID = rs.getString(this.yakushokuCol[1]);
				final String yakushokuCode = rs.getString(this.yakushokuCol[2]);
				final String yakushoku = rs.getString(this.yakushokuCol[3]);
				final String kaisou = rs.getString(this.yakushokuCol[4]);

				yakushokuMap.put(postID, new String[] { postID != null ? postID : "", yakushokuCode != null ? yakushokuCode : "", yakushoku != null ? yakushoku : "", kaisou != null ? kaisou : "" });
			}

			Log.method(loginNo, "OUT", "");
			return yakushokuMap;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * ���M�Ώێ҂��擾����
	 * @param loginNo ���O�C��NO
	 * @param addSimeiNo ����NO
	 * @param enqueteNo �A���P�[�gNO
	 * @param shozoku ����
	 * @param yakushokuList ��E
	 * @return ���M�Ώێ҃��X�g
	 */
	public ArrayList getSousinTaisyosha(final String loginNo, final String addSimeiNo, final String enqueteNo, final String shozoku, final ArrayList yakushokuList, final String status)
			throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		// ���M�Ώۃ��X�g
		final ArrayList sousinTaisyoList = new ArrayList();
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// ����NO�������Ƃ��Ĉ�����
			boolean simeiNoFlg = addSimeiNo == null || addSimeiNo.equals("") ? false : true;

			// �X�e�[�^�X�������Ƃ��Ĉ�����
			boolean statusFlg = false;
			if (!simeiNoFlg && (shozoku == null || shozoku.equals("")) && (yakushokuList == null || yakushokuList.size() == 0)) {
				statusFlg = true;
				simeiNoFlg = false;
			}

			// �w�肷���E�̐�
			String yakushokuArgs = "";
			for (int yakushokuCount = 0; yakushokuCount < yakushokuList.size(); yakushokuCount++) {
				yakushokuArgs += yakushokuCount != 0 ? "," : "";
				yakushokuArgs += "?";
			}

			// ���M�ΏێҎ擾SQL
			String sql = "  SELECT   " + " 	person_id,    " + "  	simei_no,     " + "  	kanji_simei,     " + "  	status_name,     " + "  	mail,   " + "  	yakushoku,   " + "  	A.soshiki_code,   "
					+ "  	yakushoku_code,   " + "  	soshiki_nm,   " + "  	yakushoku_nm,   " + "  	zokusei " + " FROM ( " + " SELECT " + " A.person_id AS person_id,  " + " A.simei_no AS simei_no,   "
					+ " A.kanji_simei AS kanji_simei,   " + " A.status_name AS status_name,   " + " A.mail AS mail, " + " A.yakushoku AS yakushoku, " + " A.SOSHIKI_MASTER AS soshiki_code, "
					+ " A.YAKUSHOKU_MASTER AS yakushoku_code, " + " B.SOSIKI_MEI AS soshiki_nm, " + " C.YAKUSYOKU AS yakushoku_nm, " + " A.zokusei AS zokusei " + " FROM ( " + " SELECT  "
					+ " 	A.person_id,   " + " 	A.simei_no,   " + " 	A.kanji_simei,   " + " 	A.status_name,   " + " 	A.mail, " + " 	A.yakushoku , " + " 	A.master_id AS SOSHIKI_MASTER, "
					+ " 	A.ENQUETE_NO, " + " 	B.MASTER_ID AS YAKUSHOKU_MASTER, " + "   A.yakushoku AS zokusei " + " FROM ( " + " 	SELECT  " + " 		A.person_id,   " + " 		A.simei_no,   "
					+ " 		A.kanji_simei,   " + " 		B.status_name,   " + " 		A.mail, " + " 		CASE WHEN C.zokusei_id = ? THEN (?) ELSE REPLACE(C.zokusei_id,?,?) END AS yakushoku , "
					+ " 		C.master_id, " + "       C.zokusei_id, " + " 		C.ENQUETE_NO " + " 	FROM ( " + " 		SELECT  " + " 			DISTINCT  " + " 				person_id , " + "  				master_id, "
					+ " 				zokusei_id, " + " 				ENQUETE_NO " + " 		FROM  " + "  			CPM_ENQUETE_SHAIN_ZOKUSEI  " + " 		WHERE    " + " 			enquete_no = ? AND  "
					+ " 			((zokusei_id = ?) OR (zokusei_id LIKE ?)) AND  ";
			if (!simeiNoFlg) {
				if (!statusFlg) {
					sql += " 				master_id IN (  " + " 		 			SELECT sosiki_code FROM (   " + " 		 				SELECT * FROM CPM_ENQUETE_SOSHIKI WHERE  enquete_no=? " + " 		 			)  "
							+ " 		 			START WITH sosiki_code = ? " + " 		 			CONNECT BY PRIOR sosiki_code=joui_sosiki_code " + " 		 		) ";
				} else {
					sql += " enquete_no = ? AND enquete_no = ? ";

				}
			} else {
				sql += " enquete_no = ? AND person_id = ? ";
			}
			sql += " 	) C, ( " + " 		SELECT  " + " 			JOKYO.person_id,  " + " 			STATUS.status_name,   " + " 			STATUS.status, " + " 			ENQUETE_NO " + " 		FROM  "
					+ " 			CPS_ENQUETE_JOKYO JOKYO LEFT JOIN CPM_STATUS STATUS ON (   " + " 			JOKYO.status = STATUS.status  AND STATUS.status_type = ? ";
			sql += " 		)  " + " 		WHERE enquete_no = ? " + " 	) B,CPM_ENQUETE_SHAIN A " + " 	WHERE  " + " 		A.ENQUETE_NO = B.ENQUETE_NO AND " + " 		A.PERSON_ID = B.PERSON_ID AND "
					+ " 		A.PERSON_ID = C.PERSON_ID " + " ) A, CPM_ENQUETE_SHAIN_ZOKUSEI B " + " WHERE " + " 	A.PERSON_ID = B.PERSON_ID AND " + " 	A.ENQUETE_NO = B.ENQUETE_NO AND "
					+ " 	A.yakushoku = B.ZOKUSEI_ID " + " ) A, CPM_ENQUETE_SOSHIKI B, CPM_ENQUETE_YAKUSHOKU C ";
			if (!simeiNoFlg && statusFlg) {
				if (!status.equals("")) {
					sql += " ,CPS_ENQUETE_JOKYO STATUS ";
				}
			}
			sql += " WHERE " + " B.ENQUETE_NO = A.ENQUETE_NO AND " + " C.ENQUETE_NO = A.ENQUETE_NO AND " + " A.SOSHIKI_MASTER = B.SOSIKI_CODE AND " + " A.YAKUSHOKU_MASTER = C.YAKUSYOKU_CODE  ";
			if (!simeiNoFlg && !statusFlg) {
				sql += "  AND C.YAKUSYOKU_CODE IN ( " + yakushokuArgs + ") ";
			}
			if (!simeiNoFlg && statusFlg) {
				if (!status.equals("")) {
					sql += " AND  STATUS.PERSON_ID = A.person_id AND STATUS.ENQUETE_NO = A.enquete_no " + " AND  STATUS." + this.statusCol[1] + " <> ? ";
				}
			}
			sql += ") A, ( " + " SELECT " + " sosiki_code, rownum as num " + " from( " + " 	SELECT  " + " 		sosiki_code  " + "  	FROM ( " + " 		SELECT *  " + " 		FROM  " + " 			CPM_ENQUETE_SOSHIKI  "
					+ " 		WHERE  enquete_no=?  	 " + " 	)   " + " 	START WITH sosiki_code = '0'  " + " 	CONNECT BY PRIOR sosiki_code=joui_sosiki_code " + " 	ORDER SIBLINGS BY sosiki_code " + " 	) "
					+ " ) B " + " WHERE " + " A.soshiki_code = B.sosiki_code ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			int nowPos = 1;
			pstmt.setString(nowPos, this.honmuSoshiki);
			nowPos++;
			pstmt.setString(nowPos, this.honmuYakushoku);
			nowPos++;
			pstmt.setString(nowPos, "Soshiki");
			nowPos++;
			pstmt.setString(nowPos, "Yakushoku");
			nowPos++;
			pstmt.setString(nowPos, enqueteNo);
			nowPos++;
			pstmt.setString(nowPos, this.honmuSoshiki);
			nowPos++;
			pstmt.setString(nowPos, this.kenmuSoshiki + "%");
			nowPos++;
			pstmt.setString(nowPos, enqueteNo);
			nowPos++;
			if (!simeiNoFlg) {
				if (!statusFlg) {
					pstmt.setString(nowPos, shozoku);
				} else {
					pstmt.setString(nowPos, enqueteNo);
				}
			} else {
				pstmt.setString(nowPos, addSimeiNo);
			}
			nowPos++;
			pstmt.setString(nowPos, this.shainStatusType);
			nowPos++;
			pstmt.setString(nowPos, enqueteNo);
			nowPos++;
			if (!simeiNoFlg && !statusFlg) {
				for (int yakushokuCount = 0; yakushokuCount < yakushokuList.size(); yakushokuCount++) {
					pstmt.setString(nowPos, (String) yakushokuList.get(yakushokuCount));
					nowPos++;
				}
			}
			if (!simeiNoFlg && statusFlg) {
				if (!status.equals("")) {
					pstmt.setString(nowPos, status);
					nowPos++;
				}
			}
			pstmt.setString(nowPos, enqueteNo);
			nowPos++;
			rs = pstmt.executeQuery();
			final HashMap targetMap = new HashMap();
			final HashMap targetKenmuMap = new HashMap();
			final TreeMap targetBeanMap = new TreeMap();
			while (rs.next()) {

				final String personId = rs.getString("person_id");
				final String simeiNo = rs.getString("simei_no");
				final String kanjiSimei = rs.getString("kanji_simei");
				final String soshikiCode = rs.getString("soshiki_code");
				final String yakushokuCode = rs.getString("yakushoku_code");
				final String statusName = rs.getString("status_name");
				final String mail = rs.getString("mail");
				final String zokuseiId = rs.getString("zokusei");
				// ���ɊY���g�D�̃f�[�^���擾���Ă���Ȃ牽�����Ȃ�
				if (!targetMap.containsKey(personId)) {
					// �{���Ȃ�D��I�Ɋi�[
					if (this.honmuYakushoku.equals(zokuseiId)) {
						targetMap.put(personId, zokuseiId);
						targetBeanMap.put(personId, new String[] { "1", personId, simeiNo, kanjiSimei, soshikiCode, yakushokuCode, statusName, mail });
					}
					// �����̏ꍇ�ԍ��̏���
					else {
						// �f�[�^���i�[����Ă��Ȃ��ꍇ�A�V�K�i�[
						if (!targetKenmuMap.containsKey(personId)) {
							targetKenmuMap.put(personId, zokuseiId);
							targetBeanMap.put(personId, new String[] { "1", personId, simeiNo, kanjiSimei, soshikiCode, yakushokuCode, statusName, mail });

						} else {
							final String addZokuseiID = (String) targetKenmuMap.get(personId);
							final int targetNum = new Integer(addZokuseiID.replaceAll(this.kenmuYakushoku, "")).intValue();
							final int num = new Integer(zokuseiId.replaceAll(this.kenmuYakushoku, "")).intValue();
							if (targetNum > num) {
								targetKenmuMap.put(personId, zokuseiId);
								targetBeanMap.put(personId, new String[] { "1", personId, simeiNo, kanjiSimei, soshikiCode, yakushokuCode, statusName, mail });
							}
						}
					}
				}

			}
			final Iterator it = targetBeanMap.keySet().iterator();
			while (it.hasNext()) {
				final Object obj = it.next();
				sousinTaisyoList.add(targetBeanMap.get(obj));

			}
			Log.method(loginNo, "OUT", "");
			return sousinTaisyoList;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * ���M�Ώێ҂��擾����(�S�Ј�)
	 * @param loginNo ���O�C��NO
	 * @param addSimeiNo ����NO
	 * @param enqueteNo �A���P�[�gNO
	 * @param shozoku ����
	 * @param yakushokuList ��E
	 * @return ���M�Ώێ҃��X�g
	 */
	public ArrayList getSortSousinTaisyosha(final String loginNo, final String addSimeiNo, final String enqueteNo, final String shozoku, final ArrayList yakushokuList, final String status)
			throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		// ���M�Ώۃ��X�g
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// ����NO�������Ƃ��Ĉ�����
			boolean simeiNoFlg = addSimeiNo == null || addSimeiNo.equals("") ? false : true;

			if (!simeiNoFlg && (shozoku == null || shozoku.equals("")) && (yakushokuList == null || yakushokuList.size() == 0)) {
				simeiNoFlg = false;
			}

			// �w�肷���E�̐�
			String yakushokuArgs = "";
			for (int yakushokuCount = 0; yakushokuCount < yakushokuList.size(); yakushokuCount++) {
				yakushokuArgs += yakushokuCount != 0 ? "," : "";
				yakushokuArgs += "?";
			}

			// ���M�ΏێҎ擾SQL
			final String sql = " SELECT * " + " FROM ( " + " 	SELECT " + " 			person_id,    " + " 			simei_no,     " + " 			kanji_simei,     " + " 			status_name,     " + " 			mail,   "
					+ " 			yakushoku,   " + " 			soshiki_code,   " + " 			yakushoku_code,   " + " 			zokusei, " + " 			JOUI_SOSIKI_CODE,rownum as a " + " 	FROM ( " + " 		SELECT   "
					+ " 			A.person_id AS person_id,    " + " 			A.simei_no AS simei_no,     " + " 			A.kanji_simei AS kanji_simei,     " + " 			A.status_name AS status_name,     "
					+ " 			A.mail AS mail,   " + " 			A.yakushoku AS yakushoku,   " + " 			B.SOSIKI_CODE AS soshiki_code,   " + " 			A.YAKUSHOKU_MASTER AS yakushoku_code,   "
					+ " 			A.zokusei AS zokusei, " + " 			B.JOUI_SOSIKI_CODE AS JOUI_SOSIKI_CODE  " + " 		FROM (   " + " 			SELECT   	 " + " 				A.person_id,    	 " + " 				A.simei_no,    	 "
					+ " 				A.kanji_simei,   " + " 				A.status_name,    	 " + " 				A.mail,  	 " + " 				A.yakushoku ,  	 " + " 				A.master_id AS SOSHIKI_MASTER,   " + " 				A.ENQUETE_NO,  	 "
					+ " 				B.MASTER_ID AS YAKUSHOKU_MASTER,     " + " 				A.yakushoku AS zokusei   " + " 			FROM (  	 " + " 				SELECT   		 " + " 					A.person_id,    		 "
					+ " 					A.simei_no,    		 " + " 					A.kanji_simei,   " + " 					B.status_name,    		 " + " 					A.mail,  		 "
					+ " 					CASE WHEN C.zokusei_id = ? THEN (?) ELSE REPLACE(C.zokusei_id,?,?) END AS yakushoku ,  		 " + " 					C.master_id,         " + " 					C.zokusei_id,  		 "
					+ " 					C.ENQUETE_NO  	 " + " 				FROM (  		 " + " 					SELECT   				 " + " 						person_id ,   				 " + " 						master_id,  				 " + " 						zokusei_id,  				 "
					+ " 						ENQUETE_NO  		 " + " 					FROM    			 " + " 						CPM_ENQUETE_SHAIN_ZOKUSEI   		 " + " 					WHERE     			 " + " 						enquete_no = ? AND   			 "
					+ " 						((zokusei_id = ?) OR (zokusei_id LIKE ?)) AND   				 " + " 						master_id IN (  " + " 							SELECT  " + " 								sosiki_code  " + " 							FROM (    	 "
					+ " 								SELECT * FROM CPM_ENQUETE_SOSHIKI WHERE  enquete_no=?   " + " 								)   		 			 " + " 							START WITH sosiki_code = ?  		 			 "
					+ " 							CONNECT BY PRIOR sosiki_code=joui_sosiki_code  		 		 " + " 						)  	 " + " 					) C, (  		 " + " 						SELECT   			 " + " 							JOKYO.person_id,   			 "
					+ " 							STATUS.status_name,    			 " + " 							STATUS.status,  			 " + " 							ENQUETE_NO  		 " + " 						FROM   		 "
					+ "    		  					CPS_ENQUETE_JOKYO JOKYO LEFT JOIN CPM_STATUS STATUS ON (    			JOKYO.status = STATUS.status  AND STATUS.status_type = ?  		)   		 "
					+ "    		  				WHERE enquete_no = ?  	 " + "    		  			) B,CPM_ENQUETE_SHAIN A  	 " + "    		  		WHERE   		 " + "    		  			A.ENQUETE_NO = B.ENQUETE_NO AND  		 "
					+ "    		  			A.PERSON_ID = B.PERSON_ID AND  	 " + "    		  			A.PERSON_ID = C.PERSON_ID   " + "    		  		) A, CPM_ENQUETE_SHAIN_ZOKUSEI B  " + "    		  	WHERE  	 "
					+ "    		  		A.PERSON_ID = B.PERSON_ID AND  	 " + "    		  		A.ENQUETE_NO = B.ENQUETE_NO AND  	 " + "    		  		A.yakushoku = B.ZOKUSEI_ID   " + "    		  	) A, "
					+ " 			CPM_ENQUETE_SOSHIKI B " + " 		WHERE  " + " 			B.ENQUETE_NO = A.ENQUETE_NO AND   " + " 			A.SOSHIKI_MASTER(+) = B.SOSIKI_CODE  " + " 		ORDER BY yakushoku_code, PERSON_ID "
					+ " 	) " + " ) A, ( " + " 	SELECT " + " 		SOSIKI_CODE,ROWNUM AS B " + " 	FROM( " + " 		SELECT SOSIKI_CODE " + " 		FROM (SELECT * FROM CPM_ENQUETE_SOSHIKI WHERE ENQUETE_NO=?) "
					+ " 		START WITH sosiki_code = ?   	 " + " 		CONNECT BY PRIOR sosiki_code=joui_sosiki_code " + " 		ORDER SIBLINGS BY sosiki_code " + " 	) " + "  " + " ) B " + " WHERE "
					+ " A.SOSHIKI_CODE = B.SOSIKI_CODE " + " ORDER BY B,A ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			int nowPos = 1;
			pstmt.setString(nowPos, this.honmuSoshiki);
			nowPos++;
			pstmt.setString(nowPos, this.honmuYakushoku);
			nowPos++;
			pstmt.setString(nowPos, "Soshiki");
			nowPos++;
			pstmt.setString(nowPos, "Yakushoku");
			nowPos++;
			pstmt.setString(nowPos, enqueteNo);
			nowPos++;
			pstmt.setString(nowPos, this.honmuSoshiki);
			nowPos++;
			pstmt.setString(nowPos, this.kenmuSoshiki + "%");
			nowPos++;
			pstmt.setString(nowPos, enqueteNo);
			nowPos++;
			pstmt.setString(nowPos, "0");
			nowPos++;
			pstmt.setString(nowPos, this.shainStatusType);
			nowPos++;
			pstmt.setString(nowPos, enqueteNo);
			nowPos++;
			pstmt.setString(nowPos, enqueteNo);
			nowPos++;
			pstmt.setString(nowPos, "0");
			nowPos++;
			rs = pstmt.executeQuery();
			final ArrayList result = new ArrayList();
			while (rs.next()) {
				final String personId = rs.getString("person_id");
				final String simeiNo = rs.getString("simei_no");
				final String kanjiSimei = rs.getString("kanji_simei");
				final String soshikiCode = rs.getString("soshiki_code");
				final String yakushokuCode = rs.getString("yakushoku_code");
				final String statusName = rs.getString("status_name");
				final String mail = rs.getString("mail");
				final String zokuseiId = rs.getString("zokusei");
				result.add(new String[] { "1", personId, simeiNo, kanjiSimei, soshikiCode, yakushokuCode, statusName, mail, zokuseiId });
			}

			Log.method(loginNo, "OUT", "");
			return result;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �����ꗗ�擾
	 * @param loginNo ���O�C��NO
	 * @param enqueteNo �A���P�[�gNO
	 * @return �������X�g
	 */
	public HashMap getTargetSoshikiMap(final String loginNo, final String enqueteNo, final String shozoku) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		// �����ꗗ
		final HashMap soshikiMap = new HashMap();
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �����ꗗ�̎擾
			final String sql = "SELECT " + " SOSHIKI." + this.soshikiCol[1] + ", " + " SOSHIKI." + this.soshikiCol[2] + ", " + " SOSHIKI." + this.soshikiCol[3] + ", " + " SOSHIKI."
					+ this.soshikiCol[4] + ", " + " SOSHIKI." + this.soshikiCol[6] + " ,SOSHIKI." + this.soshikiCol[5] + " " + "FROM " + "( SELECT * FROM " + this.soshikiTbl + " " + "  WHERE "
					+ this.soshikiCol[0] + " = ? " + ") SOSHIKI " + "START WITH SOSHIKI." + this.soshikiCol[2] + " = ? " + "CONNECT BY PRIOR SOSHIKI." + this.soshikiCol[2] + " = SOSHIKI."
					+ this.soshikiCol[5] + " " + "ORDER SIBLINGS BY SOSHIKI." + this.soshikiCol[2] + " ASC ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, enqueteNo);
			pstmt.setString(2, shozoku);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				final String soshikiCode = rs.getString(this.soshikiCol[2]);
				soshikiMap.put(soshikiCode, soshikiCode);
			}

			Log.method(loginNo, "OUT", "");
			return soshikiMap;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException {/* �������܂��� */
	}

	/**
	 * SessionContext�����擾����B
	 * @return SessionContext���
	 */
	public SessionContext getSessionContext() {
		return this.my_ssc;
	}

	/**
	 * EJB�R���e�i���Ǘ�����SessionContext����SessionBean�ɓn���BSessionBean�̍쐬���ɌĂяo�����B
	 * @param val SessionContext���
	 * @exception RemoteException
	 */
	public void setSessionContext(final SessionContext val) throws RemoteException {
		this.my_ssc = val;
	}
}
