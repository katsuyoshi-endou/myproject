/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g��  : ���V�e�A�iCareer�j
 *
 *
 * ���l : �p�[�\�i���e�[�u���ւ̃A�N�Z�X�N���X�B
 *
 * ���� :
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/02/08  1.00       ���� �B��    �V�K�쐬
 *   2005/02/08  1.01       ���� �B��    ���O�o�͂�ǉ��B
 *   2005/10/26  1.02       TUANTT     �V�K��PersonalRecord�ɓK������悤�ɕύX����B
 */
package jp.co.hisas.addon.batch.soshikiupdate.dao;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.naming.NamingException;
import javax.sql.DataSource;

import jp.co.hisas.addon.batch.soshikiupdate.exception.WrongArgumentException;
import jp.co.hisas.addon.batch.soshikiupdate.record.PersonalRecord;
import jp.co.hisas.addon.batch.soshikiupdate.record.Record;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PersonalDAO�N���X �@�\�����F �p�[�\�i���e�[�u���ւ̃A�N�Z�X��S������r�[���N���X�B
 * 
 * </PRE>
 */
public class PersonalDAO extends BaseDAO {

	/** �N���X�h�c */
	private static final String CLASS_ID = "Personal";

	/**
	 * �f�[�^�\�[�X����ݒ肵�āA�I�u�W�F�N�g���\�z����R���X�g���N�^�B
	 * @param dataSourceName String �f�[�^�\�[�X�B
	 * @exception NamingException �l�[�~���O��O�B
	 */
	public PersonalDAO(final String dataSourceName) throws NamingException {
		super(dataSourceName);
	}

	/**
	 * �f�[�^�\�[�X��ݒ肵�āA�I�u�W�F�N�g���\�z����R���X�g���N�^�B
	 * @param ds DataSource �f�[�^�\�[�X�B
	 */
	public PersonalDAO(final DataSource ds) {
		super(ds);
	}

	/**
	 * �w��̃p�[�\�i������߂��B
	 * @param shimeiNo String �����ԍ��B
	 * @return PersonalRecord �����ԍ��̊Y������p�[�\�i�����B �Y������p�[�\�i����񂪂Ȃ��ꍇ�́Anull��߂��B
	 * @exception WrongArgumentException �����G���[�B
	 * @exception IOException IO��O�B
	 * @exception SQLException SQL��O�B
	 */
	public PersonalRecord lookup(final String shimeiNo) throws WrongArgumentException, IOException, SQLException {

		Log.method("", "IN", "");

		// �����`�F�b�N
		if (shimeiNo == null || shimeiNo.equals("")) {
			final WrongArgumentException e = new WrongArgumentException(this.getClass().getName() + "#lookup() shimeiNo is Null or SpaceChr.");
			throw e;
		}

		final Vector vec = new Vector();
		vec.add(shimeiNo);
		final PersonalRecord rtnValue = (PersonalRecord) super.lookup(vec);
		Log.method("", "OUT", "");
		return rtnValue;

	}

	/**
	 * �g�D�Ƃ̐������G���[������p�[�\�i����񃊃X�g��߂��B �Y�����Ȃ��ꍇ�́A��̃��X�g���߂�B
	 * @return Vector �����ԍ��̊Y������p�[�\�i����񃊃X�g�B �Y������p�[�\�i����񂪂Ȃ��ꍇ�́Anull��߂��B
	 * @exception IOException IO��O�B
	 * @exception SQLException SQL��O�B
	 */
	public Vector lookupBySoshikiErrors() throws IOException, SQLException {

		Log.method("", "IN", "");

		// sql lookup�̃L�[
		final String key = "lookupbyerrorsoshiki";
		final Vector vec = new Vector();
		final Vector rtnValues = this.lookupAny(key, vec);

		Log.method("", "OUT", "");
		return rtnValues;
	}

	/**
	 * �P�����̃f�[�^�����R�[�h�I�u�W�F�N�g�ɕϊ�����B
	 * @param rset ResultSet ���ʃZ�b�g�B
	 * @return Record ���R�[�h�B���Ԃ́A�p�[�\�i�����R�[�h�B
	 * @throws SQLException SQL��O�B
	 * @see jp.co.hisas.addon.batch.soshikiupdate.dao.BaseDAO#editResultSet(java.sql.ResultSet)
	 */
	protected Record editResultSet(final ResultSet rset) throws SQLException {
		Log.method("", "IN", "");
		final PersonalRecord pr = new PersonalRecord();

		// 2005/10/26_LYCE-AP_A_TUANTT START
		pr.setSimei_no(rset.getString("simei_no"));
		pr.setSosiki_code(rset.getString("sosiki_code"));
		pr.setGensyoku_taisyoku_flg(rset.getString("gensyoku_taisyoku_flg"));
		// 2005/10/26_LYCE-AP_A_TUANTT END

		// 2005/10/26_LYCE-AP_R_TUANTT START
		// NULL ���ڂ͉������B
		// pr.setSimei_no( rset.getString( "simei_no" ) );
		//
		// pr.setPassword( rset.getString( "password" ) );
		//
		// pr.setHonmu_flg( rset.getString( "honmu_flg" ) );
		//
		// pr.setSimei_no_flg( rset.getString( "simei_no_flg" ) );
		// ss
		// 2005/10/26_LYCE-AP_R_TUANTT END

		pr.setKanji_simei(rset.getString("kanji_simei"));

		pr.setKana_simei(rset.getString("kana_simei"));

		// 2005/10/26_LYCE-AP_R_TUANTT START
		// pr.setEiji_simei( rset.getString( "eiji_simei" ) );
		//
		// pr.setSeibetu( rset.getString( "seibetu" ) );
		//
		// pr.setSeinengappi( rset.getString( "seinengappi" ) );
		//
		// if ( rset.getString( "group_nyusya_nengetu" ) != null ) {
		// pr.setGroup_nyusya_nengetu( rset.getString( "group_nyusya_nengetu" ) );
		// }
		//
		// pr.setNyusya_nengetu( rset.getString( "nyusya_nengetu" ) );
		//
		// pr.setSosiki_code( rset.getString( "sosiki_code" ) );
		//
		// pr.setYakusyoku_code( rset.getString( "yakusyoku_code" ) );
		//
		// if ( rset.getString( "syokui_code" ) != null ) {
		// pr.setSyokui_code( rset.getString( "syokui_code" ) );
		// }
		//
		// if ( rset.getString( "naisen" ) != null ) {
		// pr.setNaisen( rset.getString( "naisen" ) );
		// }
		//
		// if ( rset.getString( "gaisen" ) != null ) {
		// pr.setGaisen( rset.getString( "gaisen" ) );
		// }
		//
		// if ( rset.getString( "fax_no" ) != null ) {
		// pr.setFax_no( rset.getString( "fax_no" ) );
		// }
		//
		// pr.setMail( rset.getString( "mail" ) );
		//
		// pr.setJiko_pr( rset.getString( "jiko_pr" ) );
		//
		// pr.setGensyoku_taisyoku_flg( rset.getString( "gensyoku_taisyoku_flg" ) );
		//
		// if ( rset.getString( "taisyoku_nengappi" ) != null ) {
		// pr.setTaisyoku_nengappi( rset.getString( "taisyoku_nengappi" ) );
		// }
		//
		// pr.setKengen_code( rset.getString( "kengen_code" ) );
		//
		// if ( rset.getString( "syozoku_code_1" ) != null ) {
		// pr.setSyozoku_code_1( rset.getString( "syozoku_code_1" ) );
		// }
		//
		// if ( rset.getString( "syozoku_code_2" ) != null ) {
		// pr.setSyozoku_code_2( rset.getString( "syozoku_code_2" ) );
		// }
		//
		// if ( rset.getString( "syozoku_code_3" ) != null ) {
		// pr.setSyozoku_code_3( rset.getString( "syozoku_code_3" ) );
		// }
		//
		// if ( rset.getString( "syozoku_code_4" ) != null ) {
		// pr.setSyozoku_code_4( rset.getString( "syozoku_code_4" ) );
		// }
		//
		// if ( rset.getString( "syozoku_code_5" ) != null ) {
		// pr.setSyozoku_code_5( rset.getString( "syozoku_code_5" ) );
		// }
		//
		// if ( rset.getString( "syozoku_code_6" ) != null ) {
		// pr.setSyozoku_code_6( rset.getString( "syozoku_code_6" ) );
		// }
		//
		// if ( rset.getString( "syozoku_code_7" ) != null ) {
		// pr.setSyozoku_code_7( rset.getString( "syozoku_code_7" ) );
		// }
		//
		// if ( rset.getString( "syozoku_code_8" ) != null ) {
		// pr.setSyozoku_code_8( rset.getString( "syozoku_code_8" ) );
		// }
		//
		// if ( rset.getString( "syozoku_code_9" ) != null ) {
		// pr.setSyozoku_code_9( rset.getString( "syozoku_code_9" ) );
		// }
		//
		//
		// if ( rset.getString( "syoku_code1" ) != null ) {
		// pr.setSyoku_code1( rset.getString( "syoku_code1" ) );
		// }
		//
		// if ( rset.getString( "senmon_code1" ) != null ) {
		// pr.setSenmon_code1( rset.getString( "senmon_code1" ) );
		// }
		//
		// if ( rset.getString( "level_code1" ) != null ) {
		// pr.setLevel_code1( rset.getString( "level_code1" ) );
		// }
		//
		// if ( rset.getBigDecimal( "sougou_t_do1" ) != null ) {
		// pr.setSougou_t_do1( rset.getBigDecimal( "sougou_t_do1" ) );
		// }
		//
		// if ( rset.getString( "syoku_code2" ) != null ) {
		// pr.setSyoku_code2( rset.getString( "syoku_code2" ) );
		// }
		//
		// if ( rset.getString( "senmon_code2" ) != null ) {
		// pr.setSenmon_code2( rset.getString( "senmon_code2" ) );
		// }
		//
		// if ( rset.getString( "level_code2" ) != null ) {
		// pr.setLevel_code2( rset.getString( "level_code2" ) );
		// }
		//
		// if ( rset.getBigDecimal( "sougou_t_do2" ) != null ) {
		// pr.setSougou_t_do2( rset.getBigDecimal( "sougou_t_do2" ) );
		// }
		//
		// if ( rset.getString( "syoku_code3" ) != null ) {
		// pr.setSyoku_code3( rset.getString( "syoku_code3" ) );
		// }
		//
		// if ( rset.getString( "senmon_code3" ) != null ) {
		// pr.setSenmon_code3( rset.getString( "senmon_code3" ) );
		// }
		//
		// if ( rset.getString( "level_code3" ) != null ) {
		// pr.setLevel_code3( rset.getString( "level_code3" ) );
		// }
		//
		// if ( rset.getBigDecimal( "sougou_t_do3" ) != null ) {
		// pr.setSougou_t_do3( rset.getBigDecimal( "sougou_t_do3" ) );
		// }
		//
		// pr.setAssessment_kokai_flg( rset.getString( "assessment_kokai_flg" ) );
		//
		// pr.setKao_kokai_flg( rset.getString( "kao_kokai_flg" ) );
		//
		// pr.setSkill_kokai_flg( rset.getString( "skill_kokai_flg" ) );
		//
		// pr.setSyokumu_kokai_flg( rset.getString( "syokumu_kokai_flg" ) );
		//
		// pr.setKyoiku_kokai_flg( rset.getString( "kyoiku_kokai_flg" ) );
		//
		// pr.setSikaku_kokai_flg( rset.getString( "sikaku_kokai_flg" ) );
		//
		// pr.setHyosyo_kokai_flg( rset.getString( "hyosyo_kokai_flg" ) );
		//
		// pr.setRonbun_kokai_flg( rset.getString( "ronbun_kokai_flg" ) );
		//
		// pr.setSyagai_kokai_flg( rset.getString( "syagai_kokai_flg" ) );
		//
		// pr.setGakureki_kokai_flg( rset.getString( "gakureki_kokai_flg" ) );
		//
		// pr.setSyanaireki_kokai_flg( rset.getString( "syanaireki_kokai_flg" ) );
		//
		// pr.setZensyokureki_kokai_flg( rset.getString( "zensyokureki_kokai_flg" ) );
		//
		// pr.setSosiki_kokai_flg( rset.getString( "sosiki_kokai_flg" ) );
		//
		// pr.setYakusyoku_kokai_flg( rset.getString( "yakusyoku_kokai_flg" ) );
		//
		// pr.setSyokui_kokai_flg( rset.getString( "syokui_kokai_flg" ) );
		//
		// pr.setSkill_mainte_flg( rset.getString( "skill_mainte_flg" ) );
		//
		// pr.setKanren_gyomu_touroku_flg( rset.getString( "kanren_gyomu_touroku_flg" ) );
		//
		// pr.setPersonal_mainte_flg( rset.getString( "personal_mainte_flg" ) );
		//
		// pr.setSosiki_mainte_flg( rset.getString( "sosiki_mainte_flg" ) );
		//
		// pr.setKyoiku_mainte_flg( rset.getString( "kyoiku_mainte_flg" ) );
		//
		// pr.setRonbun_mainte_flg( rset.getString( "ronbun_mainte_flg" ) );
		//
		// pr.setSikaku_mainte_flg( rset.getString( "sikaku_mainte_flg" ) );
		//
		// pr.setHyosyo_mainte_flg( rset.getString( "hyosyo_mainte_flg" ) );
		//
		// pr.setSyagai_ronbun_mainte_flg( rset.getString( "syagai_ronbun_mainte_flg" ) );
		//
		// pr.setKenpo_mainte_flg( rset.getString( "kenpo_mainte_flg" ) );
		//
		// pr.setSyagai_mainte_flg( rset.getString( "syagai_mainte_flg" ) );
		//
		// pr.setLogin_osirase_mainte_flg( rset.getString( "login_osirase_mainte_flg" ) );
		//
		// pr.setTokei_bunseki_kengen( rset.getString( "tokei_bunseki_kengen" ) );
		//
		// pr.setTaisyokusya_kensaku_kengen_flg( rset.getString( "taisyokusya_kensaku_kengen_flg" ) );
		//
		// pr.setHikoukai_kensaku_kengen_flg( rset.getString( "hikoukai_kensaku_kengen_flg" ) );
		//
		// if ( rset.getString( "gamen_kokai_flg_yobi1" ) != null ) {
		// pr.setGamen_kokai_flg_yobi1( rset.getString( "gamen_kokai_flg_yobi1" ) );
		// }
		//
		// if ( rset.getString( "gamen_kokai_flg_yobi2" ) != null ) {
		// pr.setGamen_kokai_flg_yobi2( rset.getString( "gamen_kokai_flg_yobi2" ) );
		// }
		//
		// if ( rset.getString( "gamen_kokai_flg_yobi3" ) != null ) {
		// pr.setGamen_kokai_flg_yobi3( rset.getString( "gamen_kokai_flg_yobi3" ) );
		// }
		//
		// if ( rset.getString( "gamen_kokai_flg_yobi4" ) != null ) {
		// pr.setGamen_kokai_flg_yobi4( rset.getString( "gamen_kokai_flg_yobi4" ) );
		// }
		//
		// if ( rset.getString( "gamen_kokai_flg_yobi5" ) != null ) {
		// pr.setGamen_kokai_flg_yobi5( rset.getString( "gamen_kokai_flg_yobi5" ) );
		// }
		//
		// if ( rset.getString( "gamen_kokai_flg_yobi6" ) != null ) {
		// pr.setGamen_kokai_flg_yobi6( rset.getString( "gamen_kokai_flg_yobi6" ) );
		// }
		//
		// if ( rset.getString( "gamen_kokai_flg_yobi7" ) != null ) {
		// pr.setGamen_kokai_flg_yobi7( rset.getString( "gamen_kokai_flg_yobi7" ) );
		// }
		//
		// if ( rset.getString( "gamen_kokai_flg_yobi8" ) != null ) {
		// pr.setGamen_kokai_flg_yobi8( rset.getString( "gamen_kokai_flg_yobi8" ) );
		// }
		//
		// if ( rset.getString( "gamen_kokai_flg_yobi9" ) != null ) {
		// pr.setGamen_kokai_flg_yobi9( rset.getString( "gamen_kokai_flg_yobi9" ) );
		// }
		//
		// if ( rset.getString( "gamen_kokai_flg_yobi10" ) != null ) {
		// pr.setGamen_kokai_flg_yobi10( rset.getString( "gamen_kokai_flg_yobi10" ) );
		// }
		//
		// if ( rset.getString( "gamen_kokai_flg_yobi11" ) != null ) {
		// pr.setGamen_kokai_flg_yobi11( rset.getString( "gamen_kokai_flg_yobi11" ) );
		// }
		//
		// if ( rset.getString( "gamen_kokai_flg_yobi12" ) != null ) {
		// pr.setGamen_kokai_flg_yobi12( rset.getString( "gamen_kokai_flg_yobi12" ) );
		// }
		//
		// if ( rset.getString( "mainte_flg_yobi1" ) != null ) {
		// pr.setMainte_flg_yobi1( rset.getString( "mainte_flg_yobi1" ) );
		// }
		//
		// pr.setYobi1( rset.getString( "yobi1" ) );
		//
		// pr.setYobi2( rset.getString( "yobi2" ) );
		//
		// pr.setYobi3( rset.getString( "yobi3" ) );
		//
		// pr.setYobi4( rset.getString( "yobi4" ) );
		//
		// pr.setYobi5( rset.getString( "yobi5" ) );
		//
		// pr.setYobi6( rset.getString( "yobi6" ) );
		//
		// pr.setYobi7( rset.getString( "yobi7" ) );
		//
		// pr.setYobi8( rset.getString( "yobi8" ) );
		//
		//
		// if ( rset.getString( "yobi9" ) != null ) {
		// pr.setYobi9( rset.getString( "yobi9" ) );
		// }
		//
		// if ( rset.getString( "yobi10" ) != null ) {
		// pr.setYobi10( rset.getString( "yobi10" ) );
		// }
		//
		// if ( rset.getString( "yakusyoku" ) != null ) {
		// pr.setYakusyoku( rset.getString( "yakusyoku" ) );
		// }
		//
		// if ( rset.getString( "yobi_ryoiki" ) != null ) {
		// pr.setYobi_ryoiki( rset.getString( "yobi_ryoiki" ) );
		// }
		//
		// if ( rset.getString( "kaigai_kokai_flg" ) != null ) {
		// pr.setKaigai_kokai_flg( rset.getString( "kaigai_kokai_flg" ) );
		// }
		//
		// if ( rset.getString( "kaigai_mainte_flg" ) != null ) {
		// pr.setKaigai_mainte_flg( rset.getString( "kaigai_mainte_flg" ) );
		// }
		//
		// if ( rset.getString( "jinmei_ryakusyo" ) != null ) {
		// pr.setJinmei_ryakusyo( rset.getString( "jinmei_ryakusyo" ) );
		// }
		//
		// if ( rset.getString( "busyo_ryakusyo_mei" ) != null ) {
		// pr.setBusyo_ryakusyo_mei( rset.getString( "busyo_ryakusyo_mei" ) );
		// }
		//
		// if ( rset.getString( "gakureki_gakko_mei" ) != null ) {
		// pr.setGakureki_gakko_mei( rset.getString( "gakureki_gakko_mei" ) );
		// }
		//
		// if ( rset.getString( "gakureki_gakubu_mei" ) != null ) {
		// pr.setGakureki_gakubu_mei( rset.getString( "gakureki_gakubu_mei" ) );
		// }
		//
		// if ( rset.getString( "gakureki_gakka_mei" ) != null ) {
		// pr.setGakureki_gakka_mei( rset.getString( "gakureki_gakka_mei" ) );
		// }
		//
		// if ( rset.getString( "gakureki_sotugyo_nengetu" ) != null ) {
		// pr.setGakureki_sotugyo_nengetu( rset.getString( "gakureki_sotugyo_nengetu" ) );
		// }
		// 2005/10/26_LYCE-AP_R_TUANTT END

		Log.method("", "OUT", "");
		return pr;
	}

	/**
	 * @return String �N���X�h�c��߂��B
	 * @see jp.co.hisas.addon.batch.soshikiupdate.dao.BaseDAO#getClassId()
	 */
	protected String getClassId() {
		return PersonalDAO.CLASS_ID;
	}

}
