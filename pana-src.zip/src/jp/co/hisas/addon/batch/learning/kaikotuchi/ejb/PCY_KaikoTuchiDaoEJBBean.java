/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.learning.kaikotuchi.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.addon.batch.learning.kaikotuchi.valuebean.PCY_KaikoTuchiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KyosituBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PCY_KaikoTuchiDaoEJBBean�N���X �@�\�����F �J�u�ʒm���t�Ɋւ���f�[�^�A�N�Z�X���s���N���X
 * 
 * </PRE>
 * 
 * @ejb.bean name="PCY_KaikoTuchiDaoEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_KaikoTuchiDaoEJBBean implements SessionBean {
	/**
	 * @param kensaku_classBean
	 * @param loginuser
	 * @return
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_KaikoTuchiBean[] doSelectKaikoTuchiInfo(final PCY_ClassBean kensaku_classBean, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final StringBuffer sql = new StringBuffer();
			sql.append("SELECT ");
			sql.append(PCY_KamokuBean.getColumns("KAMOKU") + ", ");
			sql.append(PCY_ClassBean.getColumns("CLASS") + ", ");
			sql.append(PCY_MousikomiJyokyoBean.getColumns("MOUSIKOMI") + ", ");
			sql.append(PCY_PersonalBean.getColumns("PERSONAL") + ", ");
			sql.append(PCY_KyosituBean.getColumns("KYOSITU"));
			sql.append(" FROM ");
			sql.append(HcdbDef.L01_TBL + " KAMOKU, ");
			sql.append(HcdbDef.L02_TBL + " CLASS, ");
			sql.append(HcdbDef.L15_TBL + " MOUSIKOMI, ");
			sql.append(HcdbDef.personalTbl + " PERSONAL, ");
			sql.append(HcdbDef.L10_TBL + " KYOSITU ");
			sql.append(" WHERE CLASS.KAISIBI >=?");
			sql.append("   AND CLASS.KAISIBI <=?");
			sql.append("   AND CLASS.MOUSIKOMI_KUBUN = '1'");
			sql.append("   AND CLASS.KAISAI_JYOTAI = '0'");
			sql.append("   AND CLASS.SAKUJYO_FLG = '0'");
			sql.append("   AND KAMOKU.SAKUJYO_FLG = '0'");
			sql.append("   AND MOUSIKOMI.STATUS = '1'");
			sql.append("   AND ");
			sql.append("     ( MOUSIKOMI.UKETSUKE_JYOTAI = '2' ");
			sql.append("    OR MOUSIKOMI.UKETSUKE_JYOTAI = '3' ");
			sql.append("    OR MOUSIKOMI.UKETSUKE_JYOTAI = '4' ) ");
			sql.append("   AND PERSONAL.HONMU_FLG = '" + HcdbDef.HONMU + "'");
			sql.append("   AND KAMOKU.KAMOKU_CODE = CLASS.KAMOKU_CODE");
			sql.append("   AND CLASS.KAMOKU_CODE  = MOUSIKOMI.KAMOKU_CODE");
			sql.append("   AND CLASS.CLASS_CODE   = MOUSIKOMI.CLASS_CODE");
			sql.append("   AND MOUSIKOMI.SIMEI_NO = PERSONAL.SIMEI_NO");
			sql.append("   AND CLASS.KYOSITU_CODE=KYOSITU.KYOSITU_CODE(+)");
			sql.append("   ORDER BY PERSONAL.SIMEI_NO ASC,CLASS.KAISIBI ASC");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser.getSimeiNo());

			Log.debug(sql.toString());
			ps = con.prepareStatement(sql.toString());

			/* �����ߓ��l���Z�b�g���� */
			ps.setString(1, kensaku_classBean.getKaisibi());

			/* �������l���Z�b�g���� */
			ps.setString(2, kensaku_classBean.getSyuryobi());

			rs = ps.executeQuery();
			final Map kaikoTuchiMap = new HashMap();

			while (rs.next()) {
				/* �L�[�ƂȂ鎁���ԍ����擾���邽�߁A�p�[�\�i�������擾 */
				final PCY_PersonalBean personalBean = new PCY_PersonalBean(rs, "PERSONAL");
				final PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean(rs, "KAMOKU", "CLASS", "PERSONAL", "MOUSIKOMI");

				if (kaikoTuchiMap.containsKey(personalBean.getSimeiNo())) {
					/* ���ɃZ�b�g����Ă���ꍇ�A�\���ݏ���ǉ����� */
					final PCY_KaikoTuchiBean kaikoBean = (PCY_KaikoTuchiBean) kaikoTuchiMap.get(personalBean.getSimeiNo());

					final ArrayList mousikomiList = new ArrayList();
					mousikomiList.addAll(Arrays.asList(kaikoBean.getMousikomiBeans()));
					mousikomiList.add(mousikomiBean);
					kaikoBean.setMousikomiBeans((PCY_MousikomiJyokyoBean[]) mousikomiList.toArray(new PCY_MousikomiJyokyoBean[0]));
				} else {
					/* ���߂ăZ�b�g����ꍇ�A�p�[�\�i�����Ɛ\�����ݏ����Z�b�g���� */
					final PCY_KaikoTuchiBean kaikoBean = new PCY_KaikoTuchiBean();
					kaikoBean.setPersonalBean(personalBean);
					kaikoBean.setMousikomiBeans(new PCY_MousikomiJyokyoBean[] { mousikomiBean });
					kaikoTuchiMap.put(personalBean.getSimeiNo(), kaikoBean);
				}
			}

			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return (PCY_KaikoTuchiBean[]) kaikoTuchiMap.values().toArray(new PCY_KaikoTuchiBean[0]);
		} catch (final NamingException e) {
			Log.error(loginuser.getSimeiNo(), e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			throw new EJBException(e);
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser.getSimeiNo(), con, ps, rs);
		}
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
}
