/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.learning.result;

import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;

import jp.co.hisas.addon.batch.util.SQLFactory;
import jp.co.hisas.addon.batch.util.TextChecker;
import jp.co.hisas.addon.batch.util.TextWriter;
import jp.co.hisas.addon.batch.util.transaction.Transaction;

import org.apache.log4j.Logger;

/**
 * �捞�̃g�����U�N�V��������
 */
public class ImportTransaction implements Transaction {
	// �捞�Ɏg�p����e��p�����[�^
	private transient Connection connection;

	private ImportParameter param;

	private String charsetName;

	private long sessionSeq;

	private TextWriter resultLogWriter;

	private TextWriter unregisterdLogWriter;

	private String seqTimeStamp;

	private String sysdate;

	private String systime;

	private boolean hasUnregisterdData = false;

	private static final String SQL_FILE_PATH = "/jp/co/hisas/addon/batch/learning/result/SQL.properties";

	private static final String L15_STATUS_JYUKOUMACHI = "2";

	private static final String L15_STATUS_HANTEIMACHI = "3";

	// SQL
	private static final String SQL_GET_CSV_ROW_SIZE;

	private static final String SQL_GET_CSV_COL_SIZE;

	private static final String SQL_GET_CSV_DATA;

	private static final String SQL_COUNT_PERSON_BY_SIMEI_NO;

	private static final String SQL_COUNT_KAMOKU_BY_KAMOKU_CODE;

	private static final String SQL_COUNT_CLASS_BY_CLASS_CODE;

	private static final String SQL_COUNT_KENSYUREKI;

	private static final String SQL_GET_MOUSIKOMI_STATUS;

	private static final String SQL_CREATE_KENSYUREKI;

	private static final String SQL_DELETE_KENSYUREKI;

	private static final String SQL_DELETE_SINSEI;

	private static final String SQL_COUNT_TAISYOSYOKUSYU_BY_KUBUN;

	private static final String SQL_COUNT_TAISYOSOSIKI_BY_KUBUN;

	private static final String SQL_COUNT_TAISYOSYA_BY_KUBUN;

	private final Logger logger = Logger.getLogger(this.getClass());

	static {
		SQL_GET_CSV_ROW_SIZE = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "GET_CSV_ROW_SIZE");
		SQL_GET_CSV_COL_SIZE = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "GET_CSV_COL_SIZE");
		SQL_GET_CSV_DATA = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "GET_CSV_DATA");
		SQL_COUNT_PERSON_BY_SIMEI_NO = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "COUNT_PERSON_BY_SIMEI_NO");
		SQL_COUNT_KAMOKU_BY_KAMOKU_CODE = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "COUNT_KAMOKU_BY_KAMOKU_CODE");
		SQL_COUNT_CLASS_BY_CLASS_CODE = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "COUNT_CLASS_BY_CLASS_CODE");
		SQL_COUNT_KENSYUREKI = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "COUNT_KENSYUREKI");
		SQL_GET_MOUSIKOMI_STATUS = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "GET_MOUSIKOMI_STATUS");
		SQL_CREATE_KENSYUREKI = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "CREATE_KENSYUREKI");
		SQL_DELETE_KENSYUREKI = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "DELETE_KENSYUREKI");
		SQL_DELETE_SINSEI = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "DELETE_SINSEI");
		SQL_COUNT_TAISYOSYOKUSYU_BY_KUBUN = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "COUNT_TAISYOSYOKUSYU_BY_KUBUN");
		SQL_COUNT_TAISYOSOSIKI_BY_KUBUN = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "COUNT_TAISYOSOSIKI_BY_KUBUN");
		SQL_COUNT_TAISYOSYA_BY_KUBUN = SQLFactory.getInstance().getSQL(ImportTransaction.SQL_FILE_PATH, "COUNT_TAISYOSYA_BY_KUBUN");
	}

	/**
	 * �捞�g�����U�N�V�����̎��s
	 */
	public Serializable execute() {
		try {
			CSVImport.getInstance().importCSVtoDB(this.connection, this.param.getInputFilePath(), this.charsetName, String.valueOf(this.sessionSeq));

			if (!this.checkParameter()) {
				this.rollback();
				return null;
			}

			final boolean importResult = this.importData();
			this.notice();
		} catch (final IOException e) {
			throw new RuntimeException(e);
		}
		return null;
	}

	/**
	 * �捞�����̎��� 1.�b�r�u�̊e�s���G���[�`�F�b�N 2.�G���[�������ꍇ�捞�����s
	 */
	private boolean importData() {
		final boolean hasError = false;

		final long csvcol = this.getCSVColSize();

		PreparedStatement pstmt = null;
		boolean checkResult = true;
		try {
			pstmt = this.connection.prepareStatement(ImportTransaction.SQL_GET_CSV_DATA);
			ResultSet rs = null;
			// CSV�f�[�^�̊e�s���G���[�`�F�b�N����
			try {
				pstmt.setLong(1, this.param.getCsvColSimeiNo() - 1);
				pstmt.setLong(2, this.param.getCsvColKamokuCode() - 1);
				pstmt.setLong(3, this.param.getCsvColClassCode() - 1);
				pstmt.setLong(4, this.param.getCsvColSyuryoHantei() - 1);
				pstmt.setLong(5, this.param.getCsvColSyussekiNissu() - 1);
				pstmt.setLong(6, this.param.getCsvColTensu() - 1);
				pstmt.setLong(7, this.param.getCsvColSeiseki() - 1);
				pstmt.setLong(8, this.param.getCsvColSeisekibikou() - 1);
				pstmt.setString(9, String.valueOf(this.sessionSeq));
				rs = pstmt.executeQuery();

				for (; rs.next();) {
					long row = rs.getLong(1);
					if (this.param.hasHeader()) {
						// �w�b�_����̏ꍇ�w�b�_�͎�荞�܂Ȃ�
						// �܂��A�s���ɂ��J�E���g���Ȃ�
						if (row == 0) {
							continue;
						} else {
							--row;
						}
					}

					final String simeiNo = rs.getString(2);
					final String kamokuCode = rs.getString(3);
					final String classCode = rs.getString(4);
					final String syuryoHantei = rs.getString(5);
					final String syussekiNissu = rs.getString(6);
					final String tensu = rs.getString(7);
					final String seiseki = rs.getString(8);
					final String seisekibikou = rs.getString(9);
					final long colSize = rs.getLong(10);
					final long syussekiNissuLength = rs.getLong(11);
					final long tensuLength = rs.getLong(12);
					final long seisekiLength = rs.getLong(13);
					final long seisekibikouLength = rs.getLong(14);

					checkResult = this.checkData(row, simeiNo, kamokuCode, classCode, syuryoHantei, syussekiNissu, tensu, seiseki, seisekibikou, colSize, syussekiNissuLength, tensuLength,
							seisekiLength, seisekibikouLength) ? checkResult : false;
				}

				// �`�F�b�N�����������ꍇ�e�s�̓��e��DB�Ɏ�荞��
				if (checkResult) {
					rs.close();
					rs = pstmt.executeQuery();
					for (; rs.next();) {
						long row = rs.getLong(1);
						final String simeiNo = rs.getString(2);
						final String kamokuCode = rs.getString(3);
						final String classCode = rs.getString(4);
						final String syuryoHantei = rs.getString(5);
						final String syussekiNissu = rs.getString(6);
						final String tensu = rs.getString(7);
						final String seiseki = rs.getString(8);
						final String seisekibikou = rs.getString(9);
						final long colSize = rs.getLong(10);
						final long syussekiNissuLength = rs.getLong(11);
						final long tensuLength = rs.getLong(12);
						final long seisekiLength = rs.getLong(13);
						final long seisekibikouLength = rs.getLong(14);

						if (this.param.hasHeader()) {
							// �w�b�_����̏ꍇ�w�b�_�͎�荞�܂Ȃ�
							// �܂��A�s���ɂ��J�E���g���Ȃ�
							if (row == 0) {
								continue;
							} else {
								--row;
							}
						}

						switch (this.param.getMode()) {
						// �X�V���[�h�̏ꍇ�A���C�����X�V
						case ImportParameter.UPDATE:
							final boolean updateSucceed = this.updateKensyureki(row, simeiNo, kamokuCode, classCode, syuryoHantei, syussekiNissu, tensu, seiseki, seisekibikou);

							// �X�V�ɐ��������ꍇ�\�����͍폜
							if (updateSucceed) {
								this.deleteSinsei(simeiNo, kamokuCode, classCode);
							}
							break;
						case ImportParameter.DELETE:
							// �폜���[�h�̏ꍇ�A���C�����폜
							this.deleteKensyureki(simeiNo, kamokuCode, classCode);
							break;
						}
					}

				}
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			} finally {
				rs.close();
			}
		} catch (final SQLException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				pstmt.close();
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			}
		}

		return hasError;
	}

	/** CSV1�s���̃G���[�`�F�b�N */
	private boolean checkData(final long row, final String simeiNo, final String kamokuCode, final String classCode, final String syuryoHantei, final String syussekiNissu, final String tensu,
			final String seiseki, final String seisekibikou, final long colSize, final long syussekiNissuLength, final long tensuLength, final long seisekiLength, final long seisekibikouLength) {

		boolean hasError = false;
		switch (this.param.getMode()) {
		// �X�V���[�h���̃G���[�`�F�b�N
		// Error BJK-2001-E �` BJK-2082-E�ɂ��ď��Ƀ`�F�b�N
		case ImportParameter.UPDATE:

			if (colSize != this.param.getCsvColumnLength()) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.IMP_COL_NUM_UNMATCHED, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			if (this.countPersonBySimeiNo(simeiNo) == 0) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.PERSON_NOT_FOUND, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			if (this.countKamokuByKamokuCode(kamokuCode) == 0) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.KAMOKU_NOT_FOUND, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			if (this.countClassByClassCode(classCode) == 0) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.CLASS_NOT_FOUND, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			if (!this.checkSyuryoHantei(syuryoHantei)) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.SYURYO_HANTEI_INVALID, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			if (syussekiNissu != null && !TextChecker.getInstance().isDecimal(syussekiNissu, 1)) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.SYUSSEKI_NISSU_INVALID, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			if (syussekiNissuLength > Import.SYUSSEKI_NISSU_LENGTH) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.SYUSSEKI_NISSU_SIZE_INVALID, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			if (tensu != null && !TextChecker.getInstance().isInteger(tensu)) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.TENSU_INVALID, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			if (tensuLength > Import.TENSU_LENGTH) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.TENSU_SIZE_INVALID, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			if (seiseki != null && this.hasInvalidChar(seiseki)) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.SEISEKI_INVALID, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			if (seisekiLength > Import.SEISEKI_LENGTH) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.SEISEKI_SIZE_INVALID, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			if (seisekibikou != null && this.hasInvalidChar(seisekibikou)) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.SEISEKIBIKOU_INVALID, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			if (seisekibikouLength > Import.SEISEKIBIKOU_LENGTH) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.SEISEKIBIKOU_SIZE_INVALID, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			break;

		// �폜���[�h���̃G���[�`�F�b�N
		case ImportParameter.DELETE:
			if (colSize != this.param.getCsvColumnLength()) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.IMP_COL_NUM_UNMATCHED_AT_DEL, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}

			if (this.countKensyureki(simeiNo, kamokuCode, classCode) == 0) {
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.L51_RECORD_NOT_FOUND, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
			}
			break;
		}

		return !hasError;
	}

	/**
	 * ImportConfigManager�ł̓`�F�b�N�ł��Ȃ� �p�����[�^�̃`�F�b�N�B CSV���Q�Ƃ��Ȃ��ƃ`�F�b�N�ł��Ȃ��p�����[�^�`�F�b�N
	 */
	private boolean checkParameter() {
		final long csvrow = this.getCSVRowSize();
		if (this.param.hasHeader() && csvrow <= 1 || !this.param.hasHeader() && csvrow == 0) {

			this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.NO_IMPORT_DATA).toCSV());
			return false;
		}
		return true;
	}

	/** �g�����U�N�V�����̃��[���o�b�N */
	private void rollback() {
		try {
			this.connection.rollback();
		} catch (final SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/** CSV�t�@�C���̍s�������߂� */
	private long getCSVRowSize() {
		long ret = 0L;
		PreparedStatement pstmt = null;
		try {
			pstmt = this.connection.prepareStatement(ImportTransaction.SQL_GET_CSV_ROW_SIZE);
			ResultSet rs = null;
			try {
				pstmt.setString(1, String.valueOf(this.sessionSeq));
				rs = pstmt.executeQuery();
				rs.next();
				ret = rs.getLong(1);
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			} finally {
				rs.close();
			}
		} catch (final SQLException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				pstmt.close();
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			}
		}
		return ret;
	}

	/** CSV�t�@�C���̗񐔂����߂� */
	private long getCSVColSize() {
		long ret = 0L;
		PreparedStatement pstmt = null;
		try {
			pstmt = this.connection.prepareStatement(ImportTransaction.SQL_GET_CSV_COL_SIZE);
			ResultSet rs = null;
			try {
				pstmt.setString(1, String.valueOf(this.sessionSeq));
				rs = pstmt.executeQuery();
				rs.next();
				ret = rs.getLong(1);
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			} finally {
				rs.close();
			}
		} catch (final SQLException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				pstmt.close();
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			}
		}
		return ret;
	}

	/** �����ԍ����w�肵�āA�Y������Ј��̐l���𓾂� */
	private long countPersonBySimeiNo(final String simeiNo) {
		long ret = 0L;
		PreparedStatement pstmt = null;
		try {
			pstmt = this.connection.prepareStatement(ImportTransaction.SQL_COUNT_PERSON_BY_SIMEI_NO);
			ResultSet rs = null;
			try {
				pstmt.setString(1, simeiNo);
				rs = pstmt.executeQuery();
				rs.next();
				ret = rs.getLong(1);
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			} finally {
				rs.close();
			}
		} catch (final SQLException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				pstmt.close();
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			}
		}
		return ret;
	}

	/** ���ڃR�[�h���w�肵�āA�Y�����鍀�ڐ��𓾂� */
	private long countKamokuByKamokuCode(final String kamokuCode) {
		long ret = 0L;
		PreparedStatement pstmt = null;
		try {
			pstmt = this.connection.prepareStatement(ImportTransaction.SQL_COUNT_KAMOKU_BY_KAMOKU_CODE);
			ResultSet rs = null;
			try {
				pstmt.setString(1, kamokuCode);
				rs = pstmt.executeQuery();
				rs.next();
				ret = rs.getLong(1);
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			} finally {
				rs.close();
			}
		} catch (final SQLException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				pstmt.close();
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			}
		}
		return ret;
	}

	/** �N���X�R�[�h���w�肵�āA�Y������N���X�̐��𓾂� */
	private long countClassByClassCode(final String classCode) {
		long ret = 0L;
		PreparedStatement pstmt = null;
		try {
			pstmt = this.connection.prepareStatement(ImportTransaction.SQL_COUNT_CLASS_BY_CLASS_CODE);
			ResultSet rs = null;
			try {
				pstmt.setString(1, classCode);
				rs = pstmt.executeQuery();
				rs.next();
				ret = rs.getLong(1);
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			} finally {
				rs.close();
			}
		} catch (final SQLException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				pstmt.close();
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			}
		}
		return ret;
	}

	/** �C������̕�����̑Ó������`�F�b�N���� */
	private boolean checkSyuryoHantei(final String syuryoHantei) {
		if (syuryoHantei == null) {
			return false;
		}
		return syuryoHantei.equals(this.param.getLabelMisyu()) || syuryoHantei.equals(this.param.getLabelSyuryo()) || syuryoHantei.equals(this.param.getLabelNintei());
	}

	/** ���͋֎~�����񂪊܂܂�Ă��邩�ǂ��� */
	private boolean hasInvalidChar(final CharSequence str) {
		return Import.INVALID_CHAR_PATTERN.matcher(str).matches();
	}

	/** �����ɊY�����錤�C���̌����𓾂� */
	private long countKensyureki(final String simeiNo, final String kamokuCode, final String classCode) {

		long ret = 0L;
		PreparedStatement pstmt = null;
		try {
			pstmt = this.connection.prepareStatement(ImportTransaction.SQL_COUNT_KENSYUREKI);
			ResultSet rs = null;
			try {
				pstmt.setString(1, simeiNo);
				pstmt.setString(2, kamokuCode);
				pstmt.setString(3, classCode);
				rs = pstmt.executeQuery();
				rs.next();
				ret = rs.getLong(1);
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			} finally {
				rs.close();
			}
		} catch (final SQLException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				pstmt.close();
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			}
		}
		return ret;
	}

	/**
	 * ���C�����X�V���� �s�ԍ��̓Z�b�V�����ԍ������Ɏg�p
	 */
	private boolean updateKensyureki(final long row, final String simeiNo, final String kamokuCode, final String classCode, final String syuryoHantei, final String syussekiNissu, final String tensu,
			final String seiseki, final String seisekibikou) {

		boolean hasError = false;
		final Boolean isApplied = this.isApplied(kamokuCode, classCode, simeiNo);

		// �\������
		if (isApplied == null) {
			if (this.param.isUnregisterdDataImport()) {
			} else {
				this.unregisterdLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.L15_RECORD_NOT_FOUND_UNRGST_LOG, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
				hasError = true;
				this.hasUnregisterdData = true;
			}
			// �\������t����
		} else if (isApplied.booleanValue()) {
			// �\������t�������Ă��Ȃ�
		} else {
			this.unregisterdLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.L15_STATUS_INVALID, new Long(row), kamokuCode, classCode, simeiNo).toCSV());
			hasError = true;
			this.hasUnregisterdData = true;
		}

		if (!hasError) {
			// �ǉ�
			if (this.countKensyureki(simeiNo, kamokuCode, classCode) == 0) {

				// �X�V
			} else {
				this.deleteKensyureki(simeiNo, kamokuCode, classCode);
			}

			PreparedStatement pstmt = null;
			try {
				pstmt = this.connection.prepareStatement(ImportTransaction.SQL_CREATE_KENSYUREKI);
				try {
					int index = 1;
					pstmt.setString(index++, classCode);
					pstmt.setString(index++, kamokuCode);
					pstmt.setString(index++, simeiNo);
					pstmt.setString(index++, classCode);
					pstmt.setString(index++, kamokuCode);
					pstmt.setString(index++, simeiNo);
					pstmt.setString(index++, classCode);
					pstmt.setString(index++, kamokuCode);
					pstmt.setString(index++, simeiNo);
					pstmt.setString(index++, classCode);
					pstmt.setString(index++, kamokuCode);
					pstmt.setString(index++, simeiNo);
					pstmt.setString(index++, classCode);
					pstmt.setString(index++, kamokuCode);
					pstmt.setString(index++, simeiNo);
					pstmt.setString(index++, classCode);
					pstmt.setString(index++, kamokuCode);
					pstmt.setString(index++, simeiNo);
					pstmt.setString(index++, this.getSeq(row));
					pstmt.setString(index++, simeiNo);
					pstmt.setString(index++, kamokuCode);
					pstmt.setString(index++, classCode);
					pstmt.setString(index++, this.getSyuryoHanteiFlg(syuryoHantei));
					pstmt.setString(index++, syussekiNissu);
					pstmt.setString(index++, tensu);
					pstmt.setString(index++, seiseki);
					pstmt.setString(index++, seisekibikou);
					pstmt.setString(index++, this.sysdate);
					pstmt.setString(index++, this.systime);
					pstmt.executeUpdate();
				} catch (final SQLException e) {
					throw new RuntimeException(e);
				}
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			} finally {
				try {
					pstmt.close();
				} catch (final SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
		return !hasError;
	}

	/**
	 * �Z�b�V�����ԍ��𐶐����� �J�����T�C�Y���l������Ƃ��̏����Ő����ł���ԍ��� 1�����ɂ��čő�9999�܂ŁB
	 */
	private String getSeq(final long row) {
		return MessageFormat.format(Import.SEQ_FORMAT, new Object[] { this.seqTimeStamp, new Long(row + 1) });
	}

	/** ���C�����폜���� */
	private void deleteKensyureki(final String simeiNo, final String kamokuCode, final String classCode) {

		PreparedStatement pstmt = null;
		try {
			pstmt = this.connection.prepareStatement(ImportTransaction.SQL_DELETE_KENSYUREKI);
			try {
				pstmt.setString(1, simeiNo);
				pstmt.setString(2, kamokuCode);
				pstmt.setString(3, classCode);
				pstmt.executeUpdate();
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			}
		} catch (final SQLException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				pstmt.close();
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			}
		}
	}

	/** ���C�̐\�����폜���� */
	private void deleteSinsei(final String simeiNo, final String kamokuCode, final String classCode) {

		PreparedStatement pstmt = null;
		try {
			pstmt = this.connection.prepareStatement(ImportTransaction.SQL_DELETE_SINSEI);
			try {
				pstmt.setString(1, simeiNo);
				pstmt.setString(2, kamokuCode);
				pstmt.setString(3, classCode);
				pstmt.executeUpdate();
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			}
		} catch (final SQLException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				pstmt.close();
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			}
		}
	}

	/**
	 * ����̐\���f�[�^��L15�ɑ��݂� ��t�������Ă��邩���`�F�b�N���� null:�\���f�[�^�Ȃ� TRUE:�\���f�[�^�������t���� FALSE:�\���f�[�^�������t�������Ă��Ȃ�
	 */
	private Boolean isApplied(final String kamokuCode, final String classCode, final String simeiNo) {

		Boolean ret = null;
		String status = null;
		PreparedStatement pstmt = null;
		try {
			pstmt = this.connection.prepareStatement(ImportTransaction.SQL_GET_MOUSIKOMI_STATUS);
			ResultSet rs = null;
			try {
				pstmt.setString(1, kamokuCode);
				pstmt.setString(2, classCode);
				pstmt.setString(3, simeiNo);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					status = rs.getString(1);
				}
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			} finally {
				rs.close();
			}
		} catch (final SQLException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				pstmt.close();
			} catch (final SQLException e) {
				throw new RuntimeException(e);
			}
		}

		if (status != null) {
			ret = status.equals(ImportTransaction.L15_STATUS_HANTEIMACHI) || status.equals(ImportTransaction.L15_STATUS_JYUKOUMACHI) ? Boolean.TRUE : Boolean.FALSE;
		}
		return ret;
	}

	/** �C������𕶎��񂩂�t���O�ɕϊ����� */
	public String getSyuryoHanteiFlg(final String label) {
		if (label.equals(this.param.getLabelMisyu())) {
			return String.valueOf(Import.MISYU_FLG);
		} else if (label.equals(this.param.getLabelSyuryo())) {
			return String.valueOf(Import.SYURYO_FLG);
		} else if (label.equals(this.param.getLabelNintei())) {
			return String.valueOf(Import.NINTEI_FLG);
		} else {
			throw new UnsupportedOperationException();
		}
	}

	/** �I���ʒm */
	private void notice() {
		if (this.hasUnregisterdData) {
			this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.FINISHED_EXISTS_WARNING).toCSV());

			this.logger.info(ImportErrorLog.getInstance(ImportErrorID.FINISHED_EXISTS_WARNING).toString());
		} else {

			switch (this.param.getMode()) {
			case ImportParameter.UPDATE:
				// �ǉ��E�X�V���[�h���̏I���ʒm
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.FINISHED).toCSV());

				this.logger.info(ImportErrorLog.getInstance(ImportErrorID.FINISHED).toString());
				break;

			case ImportParameter.DELETE:
				// �폜���[�h���̏I���ʒm
				this.resultLogWriter.writeln(ImportErrorLog.getInstance(ImportErrorID.FINISHED_AT_DELETE).toCSV());

				this.logger.info(ImportErrorLog.getInstance(ImportErrorID.FINISHED_AT_DELETE).toString());

				break;
			}
		}
	}

	// Setter & Getter
	public void setConnection(final Connection connection) {
		this.connection = connection;
	}

	public Connection getConnection() {
		return this.connection;
	}

	public String getCharsetName() {
		return this.charsetName;
	}

	public ImportParameter getParam() {
		return this.param;
	}

	public long getSessionSeq() {
		return this.sessionSeq;
	}

	public void setCharsetName(final String string) {
		this.charsetName = string;
	}

	public void setParam(final ImportParameter parameter) {
		this.param = parameter;
	}

	public void setSessionSeq(final long l) {
		this.sessionSeq = l;
	}

	public TextWriter getResultLogWriter() {
		return this.resultLogWriter;
	}

	public void setResultLogWriter(final TextWriter writer) {
		this.resultLogWriter = writer;
	}

	public TextWriter getUnregisterdLogWriter() {
		return this.unregisterdLogWriter;
	}

	public void setUnregisterdLogWriter(final TextWriter writer) {
		this.unregisterdLogWriter = writer;
	}

	public String getSeqTimeStamp() {
		return this.seqTimeStamp;
	}

	public String getSysdate() {
		return this.sysdate;
	}

	public String getSystime() {
		return this.systime;
	}

	public void setSeqTimeStamp(final String string) {
		this.seqTimeStamp = string;
	}

	public void setSysdate(final String string) {
		this.sysdate = string;
	}

	public void setSystime(final String string) {
		this.systime = string;
	}

}
