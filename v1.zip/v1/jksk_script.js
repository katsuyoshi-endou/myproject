﻿$(function() {
  var $document = $(document);

  // SB日付
  $(".datepicker-months").datepicker({
    language: "ja",
    startView: 1,
    minViewMode: 1,
    format: "yyyy/mm",
    autoclose: true,
    toggleActive: true,
  });

  $(".datepicker-date").datepicker({
    language: "ja",
    startView: 1,
    minViewMode: 1,
    format: "yyyy/mm/dd",
    autoclose: true,
    toggleActive: true,
  });

  // 「未申請」のとき、「過去業務へ移動」と「回答内容クリア」ボタンを表示
  if (_data.sheet.statusCd === "00-New") {
    var elem = $("div.GeGyomuBtnGrp");
    if (elem !== undefined) {
      elem.show();
    }
  }

  // 「過去業務へ移動」ボタン押下
  $document.on("click", "#btn_AnsMove", function() {
    if (!window.confirm("現在の業務内容を過去の業務内容に移動します。よろしいですか。")) {
      return false;
    }

    // 過去業務欄への移動
    moveCurrentWorkContents();

    return true;
  });

  // 「回答内容クリア」ボタン押下
  $document.on("click", "#btn_AnsClr", function() {
    if(!window.confirm("現在の業務内容の回答内容をクリアします。よろしいですか。")) {
      return false;
    }

    clearGenzaiKaitoNaiyo();

    return true;
  });

  $document.on("blur", "#jksk_ge_kin_kikan", function() {
    var val = $(this).val();

    if (!checkHalfwidthNumbers(val)) {
      alert("半角英数字で入力してください。");
      $(this).val("");
      return false;
    }
    return true;
  });

  $document.on("change", "#jksk_skill_lang_02_nm, #jksk_skill_lang_03_nm", function() {
    ctrlLanguageLavelTableRows($(this));
  });

  $document.on("change", "#jksk_skill_prog_ques_01", function() {
    ctrlProgLevelTableRows($(this));
  });

  $document.on("click", "#btn_skill_onoff", function() {
    ctrlJinjiNaviShikakuTableRows($(this), "toggle");
  });

  $("#jksk_ge_kai").on("changeDate", function(e) {
    var date = new Date($(this).datepicker("getDate"));

    var from = date.getFullYear() + "/" + ("0" + (date.getMonth() + 1)).slice(-2);

    var kikan = calcPeriod(from, $("#jksk_ge_shu").text());

    $("#jksk_ge_jyu").text(kikan);
  });

  $("#jksk_ka_01_kai, #jksk_ka_02_kai, #jksk_ka_03_kai, #jksk_ka_04_kai, #jksk_ka_05_kai").on("changeDate", function(e) {
    var $from = $(this);
    var toName = $(this).attr("id").replace("kai", "shu");
    var tgtName = $(this).attr("id").replace("kai", "jyu");

    var $to = $("#" + toName);
    var $target = $("#" + tgtName);

    var kikan = calcPeriod($from.val(), $to.val());

    $target.text(kikan);
  });

  $("#jksk_ka_01_shu, #jksk_ka_02_shu, #jksk_ka_03_shu, #jksk_ka_04_shu, #jksk_ka_05_shu").on("changeDate", function(e) {
    var $to = $(this);
    var fromName = $(this).attr("id").replace("shu", "kai");
    var tgtName = $(this).attr("id").replace("shu", "jyu");

    var $from = $("#" + fromName);
    var $target = $("#" + tgtName);

    var kikan = calcPeriod($from.val(), $to.val());

    $target.text(kikan);
  });

  $("#jksk_glo_busi_exp_01_kai, #jksk_glo_busi_exp_02_kai, #jksk_glo_busi_exp_03_kai, jksk_glo_ryu_exp_01_kai, jksk_glo_ryu_exp_02_kai, jksk_glo_ryu_exp_03_kai").on("changeDate", function(e) {
    var $from = $(this);
    var toName = $(this).attr("id").replace("kai", "shu");
    var tgtName = $(this).attr("id").replace("kai", "jyu");

    var $to = $("#" + toName);
    var $target = $("#" + tgtName);

    var kikan = calcPeriod($from.val(), $to.val());

    $target.text(kikan);
  });

  $("#jksk_glo_busi_exp_01_shu, #jksk_glo_busi_exp_02_shu, #jksk_glo_busi_exp_03_shu, #jksk_glo_ryu_exp_01_shu, #jksk_glo_ryu_exp_02_shu, #jksk_glo_ryu_exp_03_shu").on("changeDate", function(e) {
    var $from = $(this);
    var toName = $(this).attr("id").replace("kai", "shu");
    var tgtName = $(this).attr("id").replace("kai", "jyu");

    var $to = $("#" + toName);
    var $target = $("#" + tgtName);

    var kikan = calcPeriod($from.val(), $to.val());

    $target.text(kikan);
  });

  $document.on("change", "#jksk_glo_busi_lang_ans01", function() {
    ctrlGloBusiLangTableRows($(this));
  });

  $document.on("change", "#jksk_glo_busi_exp_ans01", function() {
    ctrlGloBusiExpTableRows($(this));
  });

  $document.on("change", "#jksk_glo_ryu_exp_ans01", function() {
    ctrlGloRyuExpTableRows($(this));
  });

  // 初期化処理
  initialJkskSheet();
});

function initialJkskSheet() {
  // 言語レベル（言語1-2）の表示・非表示
  ctrlLanguageLavelTableRows($("#jksk_skill_lang_02_nm"));
  ctrlLanguageLavelTableRows($("#jksk_skill_lang_03_nm"));

  // プログラミングレベル1-20の表示・非表示
  ctrlProgLevelTableRows($("#jksk_skill_prog_ques_01"));

  // 人事Navi登録済み資格6-10の表示・非表示
  ctrlJinjiNaviShikakuTableRows("#btn_skill_onoff", "init");

  ctrlGloBusiLangTableRows($("#jksk_glo_busi_lang_ans01"));

  ctrlGloBusiExpTableRows($("#jksk_glo_busi_exp_ans01"));

  ctrlGloRyuExpTableRows($("#jksk_glo_ryu_exp_ans01"));
}

/**
 * 自己申告シートの申請時チェック処理
 *
 */
function checkJkskSheet() {
  // 必須チェック
  if (!checkJkskRequired()) {
    alert("必須項目が未入力です。");
    return false;
  }

  // 関連する項目の必須チェック
  if (!checkRequireRelatedItems()) {
    alert("「その他」を選択した場合、該当設問に回答してください。");
    return false;
  }

  if (!checkRequiredByJkskAnswer()) {
    return false;
  }

  return true;
}

/**
 * 未入力チェック
 */
function checkJkskRequired() {
  var bErr = false;

  console.log($("td.hissu").text());

  // $("td.hissu").each(function() {
  //   $this= $(this);

  //   console.log($this.text());

  //   // if (elem.text() === "") {
  //   //   elem.addClass("chkNG");
  //   //   bErr = true;
  // });
  return !bErr;
}

/**
 * 関連する項目の必須チェック
 */
function checkRequireRelatedItems() {
  var bErr = false;

  // 保有スキル・免許・資格
  $(".srcNullChk").each(function(i, elem) {
    if (elem.text() === "その他") {
      var tgtElem = elem.closest("tr").children(".tgtNullChk");
      if (tgtElem !== undefined) {
        if (tgtElem.text() === "") {
          tgtElem.addClass("chkNG");
          bErr = true;
        }
      }
    }
  });

  var elem1;
  var elem2;
  var idx;

  // ビジネス経験（言語1-3）
  for (var j = 1; J <= 3; j++) {
    idx = ("0" + j).slice(-2);

    elem1 = $("[name='jksk_glo_busi_lang_" + idx + "_nm']");
    elem2 = $("[name='jksk_glo_busi_lang_" + idx + "_nm_other']");

    if (checkRelatedRequire(elem1, elem2, "その他", "")) {
      elem2.addClass("chkNG");
      bErr = true;
    }
  }

  // 就学・留学経験（経験内容1-3）
  for (var k = 1; k <= 3; k++) {
    idx = ("0" + k).slice(-2);

    elem1 = $("[name='jksk_glo_ryu_exp_" + idx + "_naiyo']");
    elem2 = $("[name='jksk_glo_ryu_exp_" + idx + "_naiyo_other']");

    if (checkRelatedRequire(elem1, elem2, "その他", "")) {
      elem2.addClass("chkNG");
      bErr = true;
    }
  }
  return !bErr;
}

/**
 * 回答項目によって必須となるチェック（自己申告シート）
 */
function checkRequiredByJkskAnswer() {
  var elem1;
  var elem2;

  // その他 -希望勤務地-
  for (var k = 1; k <= 3; k++) {
    idx = ("0" + k).slice(-2);

    elem1 = $(".srcKinNullChk" + idx);
    elem2 = $(".tgtKinNullChk" + idx);

    if (checkRelatedRequire(elem1, elem2, "海外", "")) {
      elem2.addClass("chkNG");
      bErr = true;
    }
  }

  // 今後のキャリア
  elem1 = $(".srcCarQANullChk");
  elem2 = $(".tgtCarQANullChk");

  if (
    checkRelatedRequire(elem1, elem2, "直ちに新しい業務に調整してみたい", "") ||
    checkRelatedRequire(elem1, elem2, "1年以内に新しい業務に挑戦したい", "")
  ) {
    elem2.addClass("chkNG");
    bErr = false;
  }

  // プログラミング関連の受賞歴
  elem1 = $(".srcPrgAwrdNullChk");
  elem2 = $(".tgtPrgAwrdNullChk");

  if (checkRelatedRequire(elem1, elem2, "あり", "")) {
    elem2.addClass("chkNG");
    bErr = false;
  }

  // OSS公開歴
  elem1 = $(".srcOssRlsNullChk");
  elem2 = $(".tgtOssRlsNullChk");

  if (checkRelatedRequire(elem1, elem2, "あり", "")) {
    elem2.addClass("chkNG");
    bErr = false;
  }
  return true;
}

/**
 * 回答項目によって必須となるチェック（海外・外国語利用経験シート）
 */
function checkRequiredByGlobalSheet() {
  var bErr = false;
  var elem;

  // ビジネス経験（日本語以外・日本以外）就学・留学経験の各欄にて「ある」が選択されたときの未入力チェック

  // ビジネス経験（言語）
  if (_data.fill.jksk_glo_busi_lang_ques_01 === "ある") {
    elem = $("[name='jksk_glo_busi_lang_01_nm_other']");
    if (elem !== undefined && elem.text() === "") {
      elem.addClass("chkNG");
      bErr = true;
    }

    elem = $("[name='jksk_glo_busi_lang_01_naiyo']");
    if (elem !== undefined && elem.text() === "") {
      elem.addClass("chkNG");
      bErr = true;
    }
  }

  // ビジネス経験（日本以外の国）
  if (_data.fill.jksk_glo_busi_exp_ques_01 === "ある") {

  }

  return !bErr;
}

function checkSonotaKomoku() {
  var errFlg = false;

  // 「保有スキル・免許・資格」欄の「その他」選択時、未入力チェック
  if (_data.fill.jksk_skill_lang_02_nm === "その他") {
    if (_data.fill.jksk_skill_lang_02_nm_other === "") {
      errFlg = true;
    }
  }
}

/**
 * elem1の要素の値が、value1であるとき、elem2の要素の値がvalue2であるかをチェックする
 */
function checkRelatedRequire(elem1, elem2, value1, value2) {
  if (elem1 === undefined || elem2 === undefined) {
    return true;
  }

  if (elem1.val() === value1 && elem2.val() === value2) {
    return true;
  }
  return false;
}

/**
 * ２つの年月の差分を求めて、「〇年△ヶ月」の形式で返す
 *
 * @param {*} from 開始年月
 * @param {*} to 終了年月
 */
function calcPeriod(from, to) {
  var ret = "";

  var fromDate = from.split("/");
  var toDate = to.split("/");

  var fromYear = parseInt(fromDate[0], 10);
  var fromMonth = parseInt(fromDate[1], 10);

  var toYear = parseInt(toDate[0], 10);
  var toMonth = parseInt(toDate[1], 10);

  var kikYear = parseInt(toYear - fromYear, 10);
  var kikMonth = 0;

  // ex.2019/06 - 2019/04
  if (kikYear === 0 && toMonth < fromMonth) {
    ret = "";
  } else if (kikYear === 0 && toMonth >= fromMonth) {
    // ex.2019/01 - 2019/04
    kikMonth = toMonth - fromMonth;
  } else if (kikYear > 0 && toMonth >= fromMonth) {
    // ex.2018/01 - 2019/04
    kikMonth = toMonth - fromMonth;
  } else if (kikYear > 0 && toMonth < fromMonth) {
    // ex.2019/10 - 2020/04
    kikYear -= 1;
    kikMonth = toMonth + 12 - fromMonth;
  } else {
    kikYear = 0;
    kikMonth = 0;
  }

  // 計算結果を"○年○ヶ月"の形式に
  if (kikYear === 0 && kikMonth > 0) {
    ret = "0年" + kikMonth.toFixed() + "ヶ月";
  } else if (kikYear > 0 && kikMonth === 0) {
    ret = kikYear.toFixed() + "年";
  } else {
    ret = kikYear.toFixed() + "年" + kikMonth.toFixed() + "ヶ月";
  }
  return ret;
}

function getSheetNendo(operCd) {
  if (operCd === "") {
    return "";
  }

  return operCd.slice(0, 4);
}

function moveCurrentWorkContents() {
  // 現在の業務内容が未入力でないか？
  var geShozoku = $("#jksk_ge_shozoku") === undefined ? "" : $("#jksk_ge_shozoku").val();
  var geKigyomei = $("#jksk_ge_kigyomei") === undefined ? "" : $("#jksk_ge_kigyomei").val();
  var geGyoNaiyo = $("#jksk_ge_gyomunaiyo") === undefined ? "" : $("#jksk_ge_gyomunaiyo").val();
  var geKai = $("#jksk_ge_kai") === undefined ? "" : $("#jksk_ge_kai").val();
  var geShu = $("#jksk_ge_shu") === undefined ? "" : $("#jksk_ge_shu").text();
  var geJyu = $("#jksk_ge_jyu") === undefined ? "" : $("#jksk_ge_jyu").text();

  // いずれかが未入力ならば、移動させない
  if (geShozoku === "" || geKigyomei === "" || (geShozoku === "その他" && geKigyomei === "") || geGyoNaiyo === "" || geKai === "" ) {
    alert("移動する「現在業務の内容」がありません。");
    return false;
  }

  // 内容を移動する（現在→過去1、過去1→過去2...）
  for (var i = 4; i >= 1; i--) {
    var from = ("0" + i).slice(-2);
    var to = ("0" + (i + 1)).slice(-2);

    $("#jksk_ka_" + to + "_shozoku").val($("#jksk_ka_" + from + "_shozoku").val());
    $("#jksk_ka_" + to + "_kigyomei").val($("#jksk_ka_" + from + "_kigyomei").val());
    $("#jksk_ka_" + to + "_shokushu_A").text($("#jksk_ka_" + from + "_shokushu_A").text());
    $("#jksk_ka_" + to + "_shokushu_B").text($("#jksk_ka_" + from + "_shokushu_B").text());
    $("#jksk_ka_" + to + "_shokushu_C").text($("#jksk_ka_" + from + "_shokushu_C").text());
    $("#jksk_ka_" + to + "_gyomunaiyo").val($("#jksk_ka_" + from + "_gyomunaiyo").val());
    $("#jksk_ka_" + to + "_kai").val($("#jksk_ka_" + from + "_kai").val());
    $("#jksk_ka_" + to + "_shu").val($("#jksk_ka_" + from + "_shu").val());
    $("#jksk_ka_" + to + "_jyu").val($("#jksk_ka_" + from + "_jyu").val());
  }

  // 現在の業務内容を過去1に移動＆クリア？
  $("#jksk_ka_01_shozoku").val(geShozoku);
  $("#jksk_ka_01_kigyomei").val(geKigyomei);
  $("#jksk_ka_01_shokushu_A").text($("#jksk_ge_shokushu_A").text());
  $("#jksk_ka_01_shokushu_B").text($("#jksk_ge_shokushu_B").text());
  $("#jksk_ka_01_shokushu_C").text($("#jksk_ge_shokushu_C").text());
  $("#jksk_ka_01_gyomunaiyo").val(geGyoNaiyo);
  $("#jksk_ka_01_kai").val(geKai);
  $("#jksk_ka_01_shu").val(geShu);
  $("#jksk_ka_01_jyu").val(geJyu);

  return true;
}

function clearGenzaiKaitoNaiyo() {
  $("#jksk_ge_shozoku").val("");
  $("#jksk_ge_kigyomei").val("");
  $("#jksk_ge_shokushu_A").text("");
  $("#jksk_ge_shokushu_B").text("");
  $("#jksk_ge_shokushu_C").text("");
  $("#jksk_ge_gyomunaiyo").val("");
  $("#jksk_ge_kai").val("");
  $("#jksk_ge_jyu").text("");

  return true;
}

function checkHalfwidthNumbers(numVal) {
  // 半角数字パターン
  var pattern = /^\d*$/;

  return pattern.test(numVal);
}

function ctrlLanguageLavelTableRows($this) {
  if ($this === undefined) {
    return true;
  }

  var idName = $this.attr("id");
  var val = $this.val();

  if (idName === "jksk_skill_lang_02_nm") {
    if (val === "") {
      $("tr.lang02AnsGrp").hide();
    } else {
      $("tr.lang02AnsGrp").show();
    }
  } else if (idName === "jksk_skill_lang_03_nm") {
    if (val === "") {
      $("tr.lang03AnsGrp").hide();
    } else {
      $("tr.lang03AnsGrp").show();
    }
  }
  return true;
}

function ctrlProgLevelTableRows($this) {
  if ($this === undefined) {
    return true;
  }

  if ($this.val() === "ある") {
    $("tr.prgLvlAnsGrp").show();
  } else {
    $("tr.prgLvlAnsGrp").hide();
  }
  return true;
}

function ctrlGloBusiLangTableRows($this) {
  if ($this === undefined) {
    return true;
  }

  if ($this.val() === "ある") {
    $("tr.gloBusiLangAnsGrp").show();
  } else {
    $("tr.gloBusiLangAnsGrp").hide();
  }
  return true;
}

function ctrlJinjiNaviShikakuTableRows($this, mode) {
  if ($this === undefined) {
    return true;
  }

  if (mode === "init") {
    $("tr.naviShikakuGrp").hide();
  } else if (mode === "toggle") {
    $("tr.naviShikakuGrp").toggle();
  }

  return true;
}

function ctrlGloBusiExpTableRows($this) {
  if ($this === undefined) {
    return true;
  }

  if ($this.val() === "ある") {
    $("tr.gloBusiExpAnsGrp").show();
  } else {
    $("tr.gloBusiExpAnsGrp").hide();
  }
  return true;
}

function ctrlGloRyuExpTableRows($this) {
  if ($this === undefined) {
    return true;
  }

  if ($this.val() === "ある") {
    $("tr.gloRyuExpAnsGrp").show();
  } else {
    $("tr.gloRyuExpAnsGrp").hide();
  }
  return true;
}
