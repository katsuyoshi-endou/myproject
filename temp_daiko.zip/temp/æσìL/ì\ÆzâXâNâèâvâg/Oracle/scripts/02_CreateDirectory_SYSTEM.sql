CREATE DIRECTORY &1 AS '&2'
/

exit
