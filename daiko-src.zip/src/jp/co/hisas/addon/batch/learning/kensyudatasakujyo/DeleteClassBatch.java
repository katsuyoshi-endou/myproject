/*
 * All Rights Reserved. Copyright (C) 2003, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i���ьnHCDB�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/10/24  01.00    HuyNT       Create
 */
package jp.co.hisas.addon.batch.learning.kensyudatasakujyo;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

import jp.co.hisas.addon.batch.learning.util.BatchUtil;
import jp.co.hisas.addon.batch.learning.util.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 *<PRE>
 *�e�[�u�����烌�R�[�h���폜����DeleteClassPath�N���X
 *</PRE>
 */
public class DeleteClassBatch {

    private boolean logPathIsValid = true;

    /**
     * �}�C�����\�b�h
     * @param arg
     */
    public static void main(String[] arg) {
        DeleteClassBatch instance = new DeleteClassBatch();
        ArrayList parameters = instance.getParameters();
        if (!instance.parameterIsValid(parameters)){
            return;
        }
        instance.doDeleteData(parameters);
    }

    /**
     * �p�����[�^�ꗗ���`�F�b�N����B
     * @param args:�p�����[�^�ꗗ
     * @return�F�p�����[�^�ꗗ���L���̏ꍇ�Atrue��Ԃ��B
     */
    public boolean parameterIsValid(ArrayList args) {
        boolean result = true;
        int deleteCount = 0;
        String sakujyoHousiki = (String)args.get(0);
        String sakujyoKisanTuki = (String)args.get(1);
        String sakujyoKisanHi = (String)args.get(2);
        String l02SakujyoFlg = (String)args.get(4);
        String l12L13L14SakujyoFlg = (String)args.get(5);
        String l17SakujyoFlg = (String)args.get(6);
        String l94SakujyoFlg = (String)args.get(7);

        if (!logPathIsValid) {
            return false;
        }

        if ((!"1".equals(sakujyoHousiki)) && (!"2".equals(sakujyoHousiki))) {
            Log.message("PCG-0117", true);
            return false;
        }

        if ("1".equals(sakujyoHousiki)) {
            try {
                deleteCount = Integer.parseInt(sakujyoKisanTuki);
            } catch (NumberFormatException e) {
                Log.message("PCG-0110", true);
                return false;
            }
            if (deleteCount <= 0) {
                Log.message("PCG-0111", true);
                return false;
            }
            if (deleteCount >= 1000) {
                Log.message("PCG-0112", true);
                return false;
            }
        }

        if ("2".equals(sakujyoHousiki)) {
            try {
                deleteCount = Integer.parseInt(sakujyoKisanHi);
            } catch (NumberFormatException e) {
                Log.message("PCG-0113", true);
                return false;
            }
            if (deleteCount <= -1) {
                Log.message("PCG-0114", true);
                return false;
            } else if (deleteCount >= 10000) {
                Log.message("PCG-0115", true);
                return false;
            }
        }

        if ((!"0".equals(l02SakujyoFlg)) && (!"1".equals(l02SakujyoFlg))) {
            Log.message("PCG-0118", true);
            return false;
        }
        if ((!"0".equals(l12L13L14SakujyoFlg))
            && (!"1".equals(l12L13L14SakujyoFlg))) {
            Log.message("PCG-0119", true);
            return false;
        }
        if ((!"0".equals(l17SakujyoFlg)) && (!"1".equals(l17SakujyoFlg))) {
            Log.message("PCG-0120", true);
            return false;
        }
        if ((!"0".equals(l94SakujyoFlg)) && (!"1".equals(l94SakujyoFlg))) {
            Log.message("PCG-0121", true);
            return false;
        }

        return result;
    }

    /**
     * �f�[�^���폜���邽�߂̓��t���擾����B
     * @param housiki:�폜����
     * @param kisan_tuki:����
     * @param kisan_hi:����
     * @return�F�f�[�^���폜���邽�߂̓��t
     */
    public Date getDeleteBeginDate(String housiki, String kisan_tuki, String kisan_hi) {
        Calendar cal = new GregorianCalendar();

        if ("1".equals(housiki)) {
            int count = Integer.parseInt(kisan_tuki);
            cal.add(Calendar.MONTH, -count + 1);
            cal.set(Calendar.DAY_OF_MONTH, 1);
        } else if ("2".equals(housiki)) {
            int count = Integer.parseInt(kisan_hi);
            cal.add(Calendar.DAY_OF_MONTH, -count + 1);
        }
        Date beginDeleteDay = cal.getTime();
        return beginDeleteDay;
    }

    /**
     * �e�[�u�����烌�R�[�h���폜����B
     * @param connect:�f�[�^�x�[�X�ւ̐ڑ�
     * @param stmt:���s���閽�ߕ�
     * @param tableName:�폜����e�[�u��
     * @param kamokuCode:tableName�̉ȖڃR�[�h
     * @param classCode:tableName�̃N���X�R�[�h
     */
    public void deleteData(
        PreparedStatement stmt,
        String kamokuCode,
        String classCode)
        throws SQLException {
        stmt.setString(1, kamokuCode);
        stmt.setString(2, classCode);
        stmt.executeUpdate();
    }

    /**
     * �p�����[�^�ꗗ���擾����B
     * @return�F�p�����[�^�ꗗ��Ԃ��B
     */
    public ArrayList getParameters() {
        ArrayList result = new ArrayList();
        result.add(0, System.getProperty("sakujyoHousiki").trim());
        result.add(1, System.getProperty("sakujyoKisanTuki").trim());
        result.add(2, System.getProperty("sakujyoKisanHi").trim());
        result.add(3, System.getProperty("logFilePath").trim());
        result.add(4, System.getProperty("l02SakujyoFlg").trim());
        result.add(5, System.getProperty("l12L13L14SakujyoFlg").trim());
        result.add(6, System.getProperty("l17SakujyoFlg").trim());
        result.add(7, System.getProperty("l94SakujyoFlg").trim());

        String logPath = (String)result.get(3);
        File filePath = new File(logPath);
        
		if ((!filePath.exists()) || (!filePath.isDirectory()) || (!filePath.isAbsolute())) {
			logPathIsValid = false;
		}

        if (!logPathIsValid) {
            ReadFile.refreshFile();
            String msgFileName =
            (String) ReadFile.fileMapData.get(HcdbDef.msgCode);
            HashMap _msgMapData = ReadFile.getMsgMapData(msgFileName);
            String messagePCG0122 = (String) _msgMapData.get("PCG-0122");
            System.out.println(messagePCG0122);
        } else {
            try {
                Log.init("kensyuDataSakujyo", logPath);
            } catch (FileNotFoundException e) {
                ReadFile.refreshFile();
                String msgFileName =
                (String) ReadFile.fileMapData.get(HcdbDef.msgCode);
                HashMap _msgMapData = ReadFile.getMsgMapData(msgFileName);
                String messagePCG0122 = (String) _msgMapData.get("PCG-0122");
                System.out.println(messagePCG0122);
                logPathIsValid = false;
            }
        }
        return result;
    }

    /**
     * �e�[�u������f�[�^���폜����B
     */
    public void doDeleteData(ArrayList args) {
        ArrayList listL02K = new ArrayList();
        ArrayList listL02C = new ArrayList();
        int lengthList = 0;
        Connection connect = null;

        try {
            connect = BatchUtil.getConnection();
            PreparedStatement stmt = null;

            String sakujyoHousiki = (String) args.get(0);
            String sakujyoKisanTuki = (String) args.get(1);
            String sakujyoKisanHi = (String) args.get(2);
            String l02SakujyoFlg = (String) args.get(4);
            String l12L13L14SakujyoFlg = (String) args.get(5);
            String l17SakujyoFlg = (String) args.get(6);
            String l94SakujyoFlg = (String) args.get(7);

            String sql =
                "SELECT KAMOKU_CODE, CLASS_CODE FROM L02_CLASS_TBL "
                    + "WHERE to_date(SYURYOBI, 'YYYYmmDD')< ?";  // CHG#2007/3/7 s-hiura
            stmt = connect.prepareStatement(sql);

            Date toDate =
                this.getDeleteBeginDate(
                    sakujyoHousiki,
                    sakujyoKisanTuki,
                    sakujyoKisanHi);
            java.sql.Date date = new java.sql.Date(toDate.getTime());
            stmt.setDate(1, date);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                listL02K.add(rs.getString(1));
                listL02C.add(rs.getString(2));
            }
            lengthList = listL02K.size();
            connect.setAutoCommit(false);
            if ("1".equals(l02SakujyoFlg)) {
                l12L13L14SakujyoFlg = "1";
                l17SakujyoFlg = "1";
                l94SakujyoFlg = "1";
            }

            String sqlDelL02 =
                "DELETE from L02_CLASS_TBL"
                    + " where KAMOKU_CODE = ? and CLASS_CODE = ?";
            PreparedStatement stmtL02 = connect.prepareStatement(sqlDelL02);

            String sqlDelL12 =
                "DELETE from L12_TAISYOSYOKUSYU_TBL"
                    + " where KAMOKU_CODE = ? and CLASS_CODE = ?";
            PreparedStatement stmtL12 = connect.prepareStatement(sqlDelL12);

            String sqlDelL13=
                "DELETE from L13_TAISYOSOSIKI_TBL"
                    + " where KAMOKU_CODE = ? and CLASS_CODE = ?";
            PreparedStatement stmtL13 = connect.prepareStatement(sqlDelL13);

            String sqlDelL14 =
                "DELETE from L14_TAISYOSYA_TBL"
                    + " where KAMOKU_CODE = ? and CLASS_CODE = ?";
            PreparedStatement stmtL14 = connect.prepareStatement(sqlDelL14);

            String sqlDelL17 =
                "DELETE from L17_DAIKONYURYOKU_TBL"
                    + " where KAMOKU_CODE = ? and CLASS_CODE = ?";
            PreparedStatement stmtL17 = connect.prepareStatement(sqlDelL17);

            String sqlDelL94 =
                "DELETE from L94_MOUSIKOMI_DEL_RIREKI_TBL"
                    + " where KAMOKU_CODE = ? and CLASS_CODE = ?";
            PreparedStatement stmtL94 = connect.prepareStatement(sqlDelL94);

            for (int i = 0; i < lengthList; i++) {
                if ("1".equals(l02SakujyoFlg)) {
                    try {
                        this.deleteData(
                            stmtL02,
                            listL02K.get(i).toString(),
                            listL02C.get(i).toString());
                    } catch (SQLException e) {
                        Log.messagePCG0123(
                            listL02K.get(i).toString(),
                            listL02C.get(i).toString(),
                            e);
                        BatchUtil.rollbackConnection(connect);
                        continue;
                    }
                }
                if ("1".equals(l12L13L14SakujyoFlg)) {
                    try {
                        this.deleteData(
                            stmtL12,
                            listL02K.get(i).toString(),
                            listL02C.get(i).toString());
                    } catch (SQLException e) {
                        Log.messagePCG0123(
                            listL02K.get(i).toString(),
                            listL02C.get(i).toString(),
                            e);
                        BatchUtil.rollbackConnection(connect);
                        continue;
                    }
                }
                if ("1".equals(l12L13L14SakujyoFlg)) {
                    try {
                        this.deleteData(
                            stmtL13,
                            listL02K.get(i).toString(),
                            listL02C.get(i).toString());
                    } catch (SQLException e) {
                        Log.messagePCG0123(
                            listL02K.get(i).toString(),
                            listL02C.get(i).toString(),
                            e);
                        BatchUtil.rollbackConnection(connect);
                        continue;
                    }
                }
                if ("1".equals(l12L13L14SakujyoFlg)) {
                    try {
                        this.deleteData(
                            stmtL14,
                            listL02K.get(i).toString(),
                            listL02C.get(i).toString());
                    } catch (SQLException e) {
                        Log.messagePCG0123(
                            listL02K.get(i).toString(),
                            listL02C.get(i).toString(),
                            e);
                        BatchUtil.rollbackConnection(connect);
                        continue;
                    }
                }
                if ("1".equals(l17SakujyoFlg)) {
                    try {
                        this.deleteData(
                            stmtL17,
                            listL02K.get(i).toString(),
                            listL02C.get(i).toString());
                    } catch (SQLException e) {
                        Log.messagePCG0123(
                            listL02K.get(i).toString(),
                            listL02C.get(i).toString(),
                            e);
                        BatchUtil.rollbackConnection(connect);
                        continue;
                    }
                }
                if ("1".equals(l94SakujyoFlg)) {
                    try {
                        this.deleteData(
                            stmtL94,
                            listL02K.get(i).toString(),
                            listL02C.get(i).toString());
                    } catch (SQLException e) {
                        Log.messagePCG0123(
                            listL02K.get(i).toString(),
                            listL02C.get(i).toString(),
                            e);
                        BatchUtil.rollbackConnection(connect);
                        continue;
                    }
                }
                BatchUtil.commitConnection(connect);
            }

            Log.message("PCG-0116", true);
        } catch (SQLException e) {
            Log.messagePCG0123("", "", e);
        } catch (Exception e) {
            Log.messagePCG0123("", "", e);
        } finally {
            BatchUtil.closeConnection(connect);
        }
    }
}
