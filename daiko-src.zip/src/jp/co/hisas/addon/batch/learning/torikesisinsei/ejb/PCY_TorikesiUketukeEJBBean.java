/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/10/22  01.00      ���� ���V    �V�K�쐬
 */
package jp.co.hisas.addon.batch.learning.torikesisinsei.ejb;

import jp.co.hisas.addon.batch.learning.torikesisinsei.valuebean.*;
import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;

import java.rmi.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_TorikesiUketukeEJBBean�N���X
 *
 * �@�\�����F
 *   ���C�Ǘ��Ҏ����t�@�\
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PCY_TorikesiUketukeEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PCY_TorikesiUketukeEJBBean implements SessionBean {
    private SessionContext context = null;

    /**
     * �����t�������s���܂��B
     *
     * @param loginuser
     * @return
     * @throws PCY_WarningException
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_TorikesiSinseiWorkTableBean[] execTorikesi( PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        try {
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

            /* PCY_TorikesiUketukeDaoEJB */
            PCY_TorikesiUketukeDaoEJBHome torikesiDao_home = ( PCY_TorikesiUketukeDaoEJBHome )locator
                .getServiceLocation( "PCY_TorikesiUketukeDaoEJB",
                    PCY_TorikesiUketukeDaoEJBHome.class );
            PCY_TorikesiUketukeDaoEJB torikesiDao_ejb = torikesiDao_home.create(  );

            /* �����t�Ώۃf�[�^�擾�i�\���󋵃e�[�u���ƌ������Ď擾����j */
            PCY_TorikesiSinseiWorkTableBean kensaku_torikesiBean = new PCY_TorikesiSinseiWorkTableBean(  );
            kensaku_torikesiBean.setSousinFlg( "0" );

            PCY_TorikesiSinseiWorkTableBean[] torikesiBeans = torikesiDao_ejb
                .doSelectWithMousikomiJyokyo( kensaku_torikesiBean, loginuser );

            /* �����t���s���\���󋵏����擾���� */
            ArrayList mousikomiBeanList = new ArrayList(  );

            for ( int i = 0; i < torikesiBeans.length; i++ ) {
                mousikomiBeanList.add( torikesiBeans[i].getMousikomiBean(  ) );
            }

            /* MousikomiEJB */
            PCY_MousikomiJyokyoEJBHome mousikomi_home = ( PCY_MousikomiJyokyoEJBHome )locator
                .getServiceLocation( "PCY_MousikomiJyokyoEJB", PCY_MousikomiJyokyoEJBHome.class );
            PCY_MousikomiJyokyoEJB mousikomi_ejb = mousikomi_home.create(  );

            /* �����t�������s�� */
            mousikomi_ejb.doCancel( ( PCY_MousikomiJyokyoBean[] )mousikomiBeanList.toArray( 
                    new PCY_MousikomiJyokyoBean[0] ), loginuser );
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return torikesiBeans;
        } catch ( NamingException e ) {
            throw new EJBException( e );
        } catch ( CreateException e ) {
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            throw new EJBException( e );
        } catch ( PCY_WarningException e ) {
            throw e;
        }
    }

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }
}
