/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�v��nHCDB�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/04/01  01.00       ����@���V�@�@�V�K�쐬
 */
 
package jp.co.hisas.career.util.pdf;

import java.awt.Color;
import java.io.*;

import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

public class PZE020_LevelSetumeiPDF{
	/* ���O�C��No */
	private String login_no;
	
	/* PDF��� */
	private String str_file;
	private String[][] setumei_list;
	private String syoku_name;
	private String senmon_name;
	private String level_name;
	
	/* �O��������ږ� */
	private String pram_syokusyu     = (String)ReadFile.paramMapData.get("DZZ008");
	private String pram_senmon_bunya = (String)ReadFile.paramMapData.get("DZZ009");
	private String pram_level        = (String)ReadFile.paramMapData.get("DZZ010");

	/**
	 * @param login_no
	 */
	public PZE020_LevelSetumeiPDF(String login_no) {
		this.login_no = login_no;
	}
	
	/**
	 * 
	 * @param syoku_name
	 * @param senmon_name
	 * @param level_name
	 */
	public void setSkill( String syoku_name, String senmon_name, String level_name ) {
		this.syoku_name  = syoku_name;
		this.senmon_name = senmon_name;
		this.level_name  = level_name;
	}
	
	/**
	 * �o�͏����i�[����
	 * @param syoku_yakuwari
	 * @param senmon_yakuwari
	 */
	public void setData( String[][] setumei_list ){
		this.setumei_list = setumei_list;
	}
	
	/**
	 * PDF���쐬����
	 * @return
	 */
	public void executePDF( OutputStream ops ) throws Exception{
		Log.method( login_no, "IN", "");
		/* �f�t�H���g�e�[�u���̐ݒ� */
		class MyTable extends Table {
			/**
			 * @param arg0
			 * @throws BadElementException
			 */
			public MyTable(int arg0) throws BadElementException {
				super( arg0 );
				setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
				setDefaultVerticalAlignment( Element.ALIGN_MIDDLE );
				
				setPadding( 2 );
			}
		}

		/*
		 * Document�I�u�W�F�N�g�̐���
		 *  A4�c�́A Document document = new Document(PageSize.A4);
		 *  A4���́ADocument document = new Document(PageSize.A4.rotate());
		 */ 
		Document document = new Document( PageSize.A4 );
		PdfWriter pw = null;
		
		try {
			/* PdfWriter�I�u�W�F�N�g�̐��� */
			pw = PdfWriter.getInstance( document, ops );
			pw.setCloseStream(true);

			/* �w�i�F */
			Color BackColor = Color.white;
			
			/* �h�L�������g��OPEN */
			HeaderFooter footer = new HeaderFooter(new Phrase("- "), new Phrase(" -"));
			footer.setBorderColor( BackColor );
			footer.setAlignment( Element.ALIGN_CENTER );
			document.setFooter(footer);
			document.open();
	
			/* �t�H���g�̐ݒ� */
			float default_font_size = 10;
			BaseFont bf = BaseFont.createFont( "HeiseiMin-W3", "UniJIS-UCS2-HW-H", false );
			Font font = new Font( bf, default_font_size );			
	
			/* �P�s�X�y�[�X�̒�` */
			Table space = new MyTable( 1 );
			space.setBorderColor( BackColor );
			space.addCell("");
	
			/* �e�e�[�u���̕� */
			int TableWidthTop = 90;
			int TableWidth    = 100;
	
			/* �R���e���c�̋L�q */
			MyTable table;
			Cell  cell;
			
			/* �w�b�_�̕\�� */
			table = new MyTable( 6 );
			table.setBorderColor( BackColor );
			table.setWidth( TableWidthTop );
			int[] header_widths = { 10, 20, 15, 25, 10, 20 }; 
			table.setWidths( header_widths );
			
			/* �E�� */
			cell = new Cell( new Phrase( pram_syokusyu + "�F", font ) );
			cell.setBorderColor( BackColor );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			table.addCell( cell );
			
			cell = new Cell( new Phrase( syoku_name, font ) );
			cell.setBorderColor( BackColor );
			table.addCell( cell );
			
			/* ��啪�� */
			cell = new Cell( new Phrase( pram_senmon_bunya + "�F", font ) );
			cell.setBorderColor( BackColor );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			table.addCell( cell );
			
			cell = new Cell( new Phrase( senmon_name, font ) );
			cell.setBorderColor( BackColor );
			table.addCell( cell );
			
			/* ���x�� */
			cell = new Cell( new Phrase( pram_level + "�F", font ) );
			cell.setBorderColor( BackColor );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			table.addCell( cell );
			
			cell = new Cell( new Phrase( level_name, font ) );
			cell.setBorderColor( BackColor );
			table.addCell( cell );
			
			document.add( table );
			
			/* �� */
			document.add( space );
					
			for ( int i = 0; i < setumei_list.length; i++) {
				/* �f�o�b�O���O���o�� */
				Log.debug( setumei_list[i][2] + ":" + setumei_list[i][3] + ":" + setumei_list[i][4]);
				
				table = new MyTable( 3 );
				table.setBorderColor( BackColor );
				table.setWidth( TableWidth );
				int[] setumei_widths = { 3, 5, 92 }; 
				table.setWidths( setumei_widths );
				
				/* �B���x�敪 */
				cell = new Cell( new Phrase( "��", font ) );
				cell.setBorderColor( BackColor );
				table.addCell( cell );
				
				cell = new Cell( new Phrase( setumei_list[i][2], font ) );
				cell.setBorderColor( BackColor );
				cell.setColspan(2);
				table.addCell( cell );

				/* �B���x�敪���� */
				cell = new Cell( new Phrase( "", font ) );
				cell.setBorderColor( BackColor );
				table.addCell( cell );
				
				cell = new Cell( new Phrase( setumei_list[i][3], font ) );
				cell.setBorderColor( BackColor );
				cell.setColspan(2);
				table.addCell( cell );

				
				/* �B���x�g�p�T�v */
				while(true){
					cell = new Cell( new Phrase( "", font ) );
					cell.setBorderColor( BackColor );
					cell.setColspan(2);
					table.addCell( cell );
					
					cell = new Cell( new Phrase( setumei_list[i][4], font ) );
					cell.setBorderColor( BackColor );
					table.addCell( cell );
					
					/* ���[�v�I������ */
					if ( i+1 == setumei_list.length ){
						break;
					} else if ( !setumei_list[i][0].equals(setumei_list[i+1][0]) ){
						break;
					}
				i++;
				}
				document.add( table );
				document.add( space );
			}
			
		} catch (BadElementException e) {
			Log.error( login_no, "HJE-0017", e);
			throw (Exception)e;
		} catch (DocumentException e) {
			Log.error( login_no, "HJE-0017", e );
			throw (Exception)e;
		} catch (IOException e) {
			Log.error( login_no, "HJE-0017", e );
			throw (Exception)e;
		} catch ( Exception e ) {
			Log.error( login_no, "HJE-0017", e );
			throw e;
		} finally {
			/* �h�L�������g����� */
			if (document != null) {
				try {
					document.close();
				} catch (Exception e) {
					Log.error( login_no, "HJE-0017", e );
					throw e;
				}
			}
			if (pw != null) {
				try {
					pw.close();
				} catch (Exception e) {
					Log.error( login_no, "HJE-0017", e );
					throw e;
				}
			}
		}
	}
}

