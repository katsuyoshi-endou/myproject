/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�v��nHCDB�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/04/01  01.00       ����@���V�@�@�V�K�쐬
 */
 
package jp.co.hisas.career.util.pdf;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.net.*;
import java.util.*;

import javax.imageio.*;
import javax.imageio.stream.*;

import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.*;

import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.Image;
import com.lowagie.text.pdf.*;

public class PZE030_SindanKekkaPDF{
	/* �O��������ږ� */
	private String pram_simei             = (String)ReadFile.paramMapData.get("DZZ001");
	private String pram_syozoku           = (String)ReadFile.paramMapData.get("DZZ007");
	private String pram_syokusyu          = (String)ReadFile.paramMapData.get("DZZ008");
	private String pram_senmon_bunya      = (String)ReadFile.paramMapData.get("DZZ009");
	private String pram_level             = (String)ReadFile.paramMapData.get("DZZ010");
	private String pram_skill             = (String)ReadFile.paramMapData.get("DZZ012");
	private String pram_score             = (String)ReadFile.paramMapData.get("DZZ147");
	private String pram_gyomu_tasseido    = (String)ReadFile.paramMapData.get("DZZ205");
	private String pram_skill_tasseido    = (String)ReadFile.paramMapData.get("DZZ206");
	private String pram_hyokasya_syozoku  = (String)ReadFile.paramMapData.get("DZZ107");
	private String pram_hyokasya_simei    = (String)ReadFile.paramMapData.get("DZZ108");
	private String pram_saisindan_comment = (String)ReadFile.announceMapData.get("AZZ023");
	
	/* �g�p�҃��O�C��NO */
	private String login_no;
	
	/* PDF��� */
	private String syoku_name;
	private String senmon_name;
	private String level_name;
	private String[][] tasseido_sihyo_list;
	private String[][] skill_list;
	
	/* �f�f�ҏ�� */
	private String sindansya_simei;
	private String sindansya_busyo;
	private String sindansya_sogo_tasseido;
	private String sindansya_gyomu_tasseido;
	private String[] sindansya_gyomu_kekka;
	private String sindansya_skill_tasseido;
	private String[] sindansya_skill_kekka;
	private String sindan_nengappi;
	
	/* �]���ҏ�� */
	private String hyokasya_simei;
	private String hyokasya_busyo;
	private String hyokasya_sogo_tasseido;
	private String hyokasya_comment;
	private String hyokasya_gyomu_tasseido;
	private String[] hyokasya_gyomu_kekka;
	private String hyokasya_skill_tasseido;
	private String[] hyokasya_skill_kekka;
	private String hyokasya_jissi_nengappi;

	/**
	 * �R���X�g���N�^
	 * @param login_no
	 */
	public PZE030_SindanKekkaPDF( String login_no ) {
		this.login_no = login_no;
	}
	
	/**
	 * �A�Z�X�����g�����i�[����
	 * @param filename
	 * @param syoku_name
	 * @param senmon_name
	 * @param level_name
	 * @param tasseido_sihyo_list
	 * @param skill_list
	 */
	public void setAssessmentValue( String syoku_name, String senmon_name, String level_name, String[][] tasseido_sihyo_list, String[][] skill_list ){
		this.syoku_name          = syoku_name;
		this.senmon_name         = senmon_name;
		this.level_name          = level_name;
		this.tasseido_sihyo_list = tasseido_sihyo_list;
		this.skill_list          = skill_list;
	}
	
	/**
	 * �f�f�ҏ����i�[����
	 * @param sindansya_simei
	 * @param sindansya_busyo
	 * @param sindansya_sogo_tasseido
	 * @param sindansya_gyomu_tasseido
	 * @param sindansya_gyomu_kekka
	 * @param sindansya_skill_tasseido
	 * @param sindansya_skill_kekka
	 * @param sindan_nengappi
	 */
	public void setSindansyaValue( String sindansya_simei, String sindansya_busyo, String sindansya_sogo_tasseido, String sindansya_gyomu_tasseido, String[] sindansya_gyomu_kekka, String sindansya_skill_tasseido, String[] sindansya_skill_kekka, String sindan_nengappi ) {
	    this.sindansya_simei          = sindansya_simei;
		this.sindansya_busyo          = sindansya_busyo;
		if( sindansya_sogo_tasseido != null ) {
			this.sindansya_sogo_tasseido  = sindansya_sogo_tasseido + " %";
		}
		if( sindansya_gyomu_tasseido != null ) {
			this.sindansya_gyomu_tasseido = sindansya_gyomu_tasseido + " %";
		}
		this.sindansya_gyomu_kekka    = sindansya_gyomu_kekka;
		if( sindansya_skill_tasseido != null ) {
			this.sindansya_skill_tasseido = sindansya_skill_tasseido + " %";
		}
		this.sindansya_skill_kekka    = sindansya_skill_kekka;
		this.sindan_nengappi          = PZZ010_CharacterUtil.ChangeYmd( sindan_nengappi );
	}
	
	/**
	 * �]���ҏ����i�[����
	 * @param hyokasya_simei
	 * @param hyokasya_busyo
	 * @param hyokasya_sogo_tasseido
	 * @param hyokasya_comment
	 * @param hyokasya_gyomu_tasseido
	 * @param hyokasya_gyomu_kekka
	 * @param hyokasya_skill_tasseido
	 * @param hyokasya_skill_kekka
	 * @param hyokasya_jissi_nengappi
	 */
	public void setHyokasyaValue( String hyokasya_simei, String hyokasya_busyo, String hyokasya_sogo_tasseido, String hyokasya_comment, String hyokasya_gyomu_tasseido, String[] hyokasya_gyomu_kekka, String hyokasya_skill_tasseido, String[] hyokasya_skill_kekka, String hyokasya_jissi_nengappi) {
		this.hyokasya_simei           = hyokasya_simei;
		this.hyokasya_busyo           = hyokasya_busyo;
		if( hyokasya_sogo_tasseido != null ) {
			this.hyokasya_sogo_tasseido   = hyokasya_sogo_tasseido + " %";
		}
		this.hyokasya_comment         = hyokasya_comment;
		if( hyokasya_gyomu_tasseido != null ) {
			this.hyokasya_gyomu_tasseido  = hyokasya_gyomu_tasseido + " %";
		}
		this.hyokasya_gyomu_kekka     = hyokasya_gyomu_kekka;
		if(hyokasya_skill_tasseido != null ) {
			this.hyokasya_skill_tasseido  = hyokasya_skill_tasseido + " %";
		}
		this.hyokasya_skill_kekka     = hyokasya_skill_kekka;
		this.hyokasya_jissi_nengappi  = PZZ010_CharacterUtil.ChangeYmd( hyokasya_jissi_nengappi );
	}
	
	/**
	 * PDF���쐬����
	 * @return
	 */
	public void executePDF( OutputStream ops, BufferedImage radarchart ) throws Exception{
		
		/* �f�t�H���g�̃e�[�u�����` */
		class MyTable extends Table {
			public MyTable(int arg0) throws BadElementException {
				super( arg0 );
				setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
				setDefaultVerticalAlignment( Element.ALIGN_MIDDLE );
				setPadding( 2 );
			}
		}
		
		/* �f�o�b�O���O���o�� */
		Log.debug( "syoku_name:" + syoku_name );
		Log.debug( "senmon_name:" + senmon_name );
		Log.debug( "level_name:" + level_name );
		Log.debug( "tasseido_sihyo_list:" + tasseido_sihyo_list );
		Log.debug( "skill_list:" + skill_list );
		Log.debug( "sindansya_simei:" + sindansya_simei );
		Log.debug( "sindansya_busyo:" + sindansya_busyo );
		Log.debug( "sindansya_sogo_tasseido:" + sindansya_sogo_tasseido );
		Log.debug( "sindansya_gyomu_tasseido:" + sindansya_gyomu_tasseido );
		Log.debug( "sindansya_gyomu_kekka:" + sindansya_gyomu_kekka );
		Log.debug( "sindansya_skill_tasseido:" + sindansya_skill_tasseido );
		Log.debug( "sindansya_skill_kekka:" + sindansya_skill_kekka );
		Log.debug( "sindan_nengappi:" + sindan_nengappi );
		Log.debug( "hyokasya_simei:" + hyokasya_simei );
		Log.debug( "hyokasya_busyo:" + hyokasya_busyo );
		Log.debug( "hyokasya_sogo_tasseido:" + hyokasya_sogo_tasseido );
		Log.debug( "hyokasya_comment:" + hyokasya_comment );
		Log.debug( "hyokasya_gyomu_tasseido:" + hyokasya_gyomu_tasseido );
		Log.debug( "hyokasya_gyomu_kekka:" + hyokasya_gyomu_kekka );
		Log.debug( "hyokasya_skill_tasseido:" + hyokasya_skill_tasseido );
		Log.debug( "hyokasya_skill_kekka:" + hyokasya_skill_kekka );
		Log.debug( "hyokasya_jissi_nengappi:" + hyokasya_jissi_nengappi );
		
		/*
		 * Document�I�u�W�F�N�g�̐���
		 *  A4�c�́A Document document = new Document(PageSize.A4);
		 *  A4���́ADocument document = new Document(PageSize.A4.rotate());
		 */ 
		Document document = new Document( PageSize.A4 );
		PdfWriter pw = null;
		
		try {
			/* PdfWriter�I�u�W�F�N�g�̐��� */
			pw = PdfWriter.getInstance( document, ops );
			pw.setCloseStream(true);

			/* �w�i�F */
			Color BackColor = Color.white;
			
			/* �h�L�������g��OPEN */
			HeaderFooter footer = new HeaderFooter(new Phrase("- "), new Phrase(" -"));
			footer.setBorderColor( BackColor );
			footer.setAlignment( Element.ALIGN_CENTER );
			document.setFooter(footer);
			document.open();
			
			/* �t�H���g�̐ݒ� */
			float default_font_size = 10;
			BaseFont bf = BaseFont.createFont( "HeiseiMin-W3", "UniJIS-UCS2-HW-H", false );
			Font font = new Font( bf, default_font_size );
			Color default_color = font.color();
			
			/* �P�s�X�y�[�X�̒�` */
			Table space = new MyTable( 1 );
			space.setBorderColor( BackColor );
			space.addCell("");
	
			/* ���ʃ��C���i�����]���A�Ɩ��o���]���A�X�L���]���j�̒��� */
			int KekkaLineSize = 100;
	
			/* �e�e�[�u���̕� */
			int TableWidthTop = 100;
			int TableWidth    = 100;
	
			/* �R���e���c�̋L�q */
			MyTable table;
			Cell  cell;
	
			/* �f�f�N������\�� */
			if ( sindan_nengappi == null ) {
				sindan_nengappi = "";
			}

			table = new MyTable( 2 );
			int[] sindan_nengappi_widths = { 70, 30 };
			table.setWidths( sindan_nengappi_widths );
			table.setWidth( TableWidth );
			table.setBorderColor( BackColor );
			cell = new Cell( new Phrase( "�f�f�N����" ,font ) );
			cell.setBorderColor( BackColor );
			table.setDefaultHorizontalAlignment( Element.ALIGN_RIGHT );
			table.addCell( cell );
			cell = new Cell( new Phrase( sindan_nengappi ,font ) );
			cell.setBorderColor( BackColor );
			table.addCell( cell );
			table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
	
			/* �h�L�������g�ɒǉ� */
			document.add( table );
	
	
			/* �f�f�ҏ�� */
			if ( sindansya_busyo == null ) {
				sindansya_busyo = "";
			}
			if ( sindansya_simei == null ) {
				sindansya_simei = "";
			}
			table = new MyTable( 5 );
			int[] sindansya_info_widths = { 10, 10, 35, 10, 35 };
			table.setWidths( sindansya_info_widths );
			table.setWidth( TableWidthTop );
			table.addCell( new Cell( new Phrase( "�f�f��" ,font ) ) );
			table.addCell( new Cell( new Phrase( pram_syozoku ,font ) ) );
			table.addCell( new Cell( new Phrase( sindansya_busyo ,font ) ) );
			table.addCell( new Cell( new Phrase( pram_simei ,font ) ) );
			table.addCell( new Cell( new Phrase( sindansya_simei ,font ) ) );
	
			/* �h�L�������g�ɒǉ� */
			document.add( table );
	
			/* �X�y�[�X�}�� */
			document.add( space );

			/* �E��E��啪��E���x�� */
			table = new MyTable( 6 );
			int[] assessment_info_widths = { 10, 25, 15, 25, 10, 15 };
			table.setWidths( assessment_info_widths );
			table.setWidth( TableWidth );
	
			table.addCell( new Cell( new Phrase( pram_syokusyu ,font ) ) );
			table.addCell( new Cell( new Phrase( syoku_name ,font ) ) );
			table.addCell( new Cell( new Phrase( pram_senmon_bunya ,font ) ) );
			table.addCell( new Cell( new Phrase( senmon_name ,font ) ) );
			table.addCell( new Cell( new Phrase( pram_level ,font ) ) );
			table.addCell( new Cell( new Phrase( level_name ,font ) ) );
	
			/* �h�L�������g�ɒǉ� */
			document.add( table );
	
			/* �X�y�[�X�}�� */
			document.add( space );
			
			/* �T�D�����]�� */
			table = new MyTable( 1 );
			table.setWidth( KekkaLineSize );
			table.setBorderColor( BackColor );
			font.setColor( Color.WHITE );
			cell = new Cell( new Phrase( "�P�D�����]��" ,font ) );
			cell.setBackgroundColor( new Color( 0x27, 0x40, 0x8B ) );
			table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
			table.addCell( cell );
			table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
	
			/* �h�L�������g�ɒǉ� */
			document.add( table );
			
			font.setColor( default_color );
	
			/* �����]�� */
			table = new MyTable( 7 );
			int[] sogo_kekka_widths = { 15, 8, 17, 8, 17, 15, 20 };
			table.setWidths( sogo_kekka_widths );
			table.setWidth( TableWidth );
	
			cell = new Cell( new Phrase( "�����B���x", font ) );
			cell.setRowspan( 2 );
			cell.setColspan( 1 );
			table.addCell( cell );
	
			cell = new Cell( new Phrase( "�f�f�Җ{�l�̕]��", font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 2 );
			table.addCell( cell );

			if ( sindansya_sogo_tasseido == null ) {
				sindansya_sogo_tasseido = "";
			}
			cell = new Cell( new Phrase( sindansya_sogo_tasseido, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 2 );
			table.addCell( cell );
	
			font.setSize( 7 );
			cell = new Cell( new Phrase( pram_saisindan_comment, font ) );
			font.setSize( default_font_size );
			cell.setVerticalAlignment( Element.ALIGN_TOP );
			cell.setHorizontalAlignment( Element.ALIGN_LEFT);
			cell.setRowspan( 2 );
			cell.setColspan( 2 );
			table.addCell( cell );
	
			cell = new Cell( new Phrase( "�]���f�f�̕]��" ,font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 2 );
			table.addCell( cell );
			
			if ( hyokasya_sogo_tasseido == null ) {
				hyokasya_sogo_tasseido = "";
			}
			cell = new Cell( new Phrase( hyokasya_sogo_tasseido, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 2 );
			table.addCell( cell );
	
			cell = new Cell( new Phrase( "�]���f�f��\n�R�����g", font ) );
			cell.setRowspan( 2 );
			cell.setColspan( 1 );
			table.addCell( cell );
			
			if ( hyokasya_comment == null ) {
				hyokasya_comment = "";
			}
			cell = new Cell( new Phrase( hyokasya_comment, font ) );
			cell.setVerticalAlignment( Element.ALIGN_TOP );
			cell.setHorizontalAlignment( Element.ALIGN_LEFT);
			cell.setRowspan( 2 );
			cell.setColspan( 6 );
			table.addCell( cell );
	
			cell = new Cell( new Phrase( "�]����", font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
	
			cell = new Cell( new Phrase( pram_hyokasya_syozoku, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
			
			if ( hyokasya_busyo == null ) {
				hyokasya_busyo = "";
			}
			cell = new Cell( new Phrase( hyokasya_busyo, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );	
	
			cell = new Cell( new Phrase( pram_hyokasya_simei, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
			
			if ( hyokasya_simei == null ) {
				hyokasya_simei = "";
			}
			cell = new Cell( new Phrase( hyokasya_simei, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
	
			cell = new Cell( new Phrase( "�]�����{��", font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
			
			if ( hyokasya_jissi_nengappi == null ) {
				hyokasya_jissi_nengappi = "";
			}
			cell = new Cell( new Phrase( hyokasya_jissi_nengappi, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
	
			/* �h�L�������g�ɒǉ� */
			document.add( table );
	
			/* �X�y�[�X�}�� */
			document.add( space );
	
			/* �U�D�Ɩ��o���]�� */
			table = new MyTable( 1 );
			table.setWidth( KekkaLineSize );
			table.setBorderColor( BackColor );
			font.setColor( Color.WHITE );
			cell = new Cell( new Phrase( "�Q�D�Ɩ��o���]��" ,font ) );
			cell.setBackgroundColor( new Color(  0x27, 0x40, 0x8B  ) );
			table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
			table.addCell( cell );
			table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
	
			/* �h�L�������g�ɒǉ� */
			document.add( table );
	
			font.setColor( default_color );
			
			table = new MyTable( 3 );
			int[] gyomu_kekka_widths = { 84, 8, 8 };
			table.setWidths( gyomu_kekka_widths );
			table.setWidth( TableWidth );
	
			cell = new Cell( new Phrase( "����", font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
	
			font.setSize( 7 );
			cell = new Cell( new Phrase( "�f�f�Җ{�l�̑I��", font ) );
			font.setSize( default_font_size );
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell( cell );
	
			font.setSize( 7 );
			cell = new Cell( new Phrase( "�]���f�f�̑I��", font) );
			font.setSize( default_font_size );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
	
			table.endHeaders();
	
			int j = 0;
			for ( int i = 0; i < tasseido_sihyo_list.length; i++ ) {
				cell = new Cell( new Phrase( tasseido_sihyo_list[i][2], font ) );
				cell.setRowspan( 1 );
				cell.setColspan( 3 );
				cell.setBackgroundColor( new Color( 0x99, 0xCC, 0xFF ) );
				table.addCell( cell );

				/* �\�� */
				while( true ){
					String sindansya_gyomu = "";
					String hyokasya_gyomu  = "";
		
					/* �f�f�ҁ@�B���x�w�W�I���`�F�b�N */
					if ( sindansya_gyomu_kekka != null && sindansya_gyomu_kekka.length != 0 ) {
						if ( sindansya_gyomu_kekka[i].equals( "1" ) ) {
							sindansya_gyomu = "��";
						} else {
							sindansya_gyomu = "�~";
						}
					}
		
					/* �]���ҁ@�B���x�w�W�I���`�F�b�N */
					if ( hyokasya_gyomu_kekka != null && hyokasya_gyomu_kekka.length != 0 ) {
						if ( hyokasya_gyomu_kekka[i].equals( "1" ) ) {
							hyokasya_gyomu = "��";
						} else {
							hyokasya_gyomu = "�~";
						}
					}
			
					cell = new Cell( new Phrase( tasseido_sihyo_list[i][3], font ) );
					cell.setRowspan( 1 );
					cell.setColspan( 1 );
					table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
					table.addCell( cell );
					table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
			
					cell = new Cell( new Phrase( sindansya_gyomu, font ) );
					cell.setRowspan( 1 );
					cell.setColspan( 1 );
					table.addCell( cell );
			
					cell = new Cell( new Phrase( hyokasya_gyomu, font ) );
					cell.setRowspan( 1 );
					cell.setColspan( 1 );
					table.addCell( cell );
			
					/* ���[�v�I������ */
					if ( i+1 == tasseido_sihyo_list.length ){
						break;
					} else if ( !tasseido_sihyo_list[i][0].equals( tasseido_sihyo_list[i+1][0] ) ) {
						break;
					}
					i++;
				}
			}
	
			/* �h�L�������g�ɒǉ� */
			document.add( table );
	
			/* �Ɩ��o���B���x */
			table = new MyTable( 5 );
			int[] gyomu_tasseido_widths ={20,20,20,20,20};
			table.setWidths( gyomu_tasseido_widths );
			table.setWidth( TableWidth );
	
			cell = new Cell( new Phrase( pram_gyomu_tasseido, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
	
			cell = new Cell( new Phrase( "�f�f�Җ{�l�̕]��", font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
			
			if ( sindansya_gyomu_tasseido == null ) {
				sindansya_gyomu_tasseido = "";
			}
			cell = new Cell( new Phrase( sindansya_gyomu_tasseido, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
	
			cell = new Cell( new Phrase( "�]���f�f�̕]��", font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
			
			if ( hyokasya_gyomu_tasseido == null ) {
				hyokasya_gyomu_tasseido = "";
			}
			cell = new Cell( new Phrase( hyokasya_gyomu_tasseido, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
	
			/* �h�L�������g�ɒǉ� */
			document.add( table );
	
			/* ���y�[�W */		
			document.newPage();

			/* �V�D�X�L���]�� */
			table = new MyTable( 1 );
			table.setWidth( KekkaLineSize );
			table.setBorderColor( BackColor );
			font.setColor( Color.WHITE );
			cell = new Cell( new Phrase( "�R�D" + pram_skill + "�]��" ,font ) );
			cell.setBackgroundColor( new Color( 0x27, 0x40, 0x8B ) );
			table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
			table.addCell( cell );
			table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
			
			/* �h�L�������g�ɒǉ� */
			document.add( table );
			
			font.setColor( default_color );
			
			table = null;
	
			/* �O�g */
			table = new MyTable( 2 );
			int[] skill_waku_widths={ 60, 40 };
			table.setWidths( skill_waku_widths );
			table.setWidth( TableWidth );
	
	
			/* ���[�_�`���[�g�} */

			/* �O�g�ɒǉ� */
			table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
			table.setDefaultVerticalAlignment( Element.ALIGN_TOP );
			
			if ( radarchart == null ) {
				String png = "";
				table.addCell( new Cell(png) );
			}
			else {
				Iterator ite = ImageIO.getImageWritersByFormatName("png");
				ImageWriter writer = (ImageWriter)ite.next();
				ByteArrayOutputStream  baos = new ByteArrayOutputStream();
				ImageOutputStream ios = ImageIO.createImageOutputStream( baos );
				writer.setOutput( ios );
				writer.write( radarchart );
				Image img_png = Image.getInstance( baos.toByteArray() );
				table.addCell( new Cell(img_png) );
			}
			
			table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
			table.setDefaultVerticalAlignment( Element.ALIGN_MIDDLE );
	
			/* �X�L���f�f���� */
			Table table1 = new MyTable( 3 );
			int[] skill_sindan_widths = { 60, 20, 20 };
			table1.setWidths( skill_sindan_widths );
	
			cell = new Cell( new Phrase( pram_skill, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table1.addCell( cell );
			cell = new Cell( new Phrase( "�f�f�Җ{�l��" + pram_score, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table1.addCell( cell );
			cell = new Cell( new Phrase( "�]���f�f��" + pram_score, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table1.addCell( cell );
	
			table1.endHeaders();
	
			for (int i = 0; i < skill_list.length; i++ ) {
				/* �f�f�Ґf�f��� */
				String sindansya_score = "";
				if ( sindansya_skill_kekka != null && sindansya_skill_kekka.length != 0 ) {
					sindansya_score = sindansya_skill_kekka[i];
				}
				
				/* �]���Ґf�f��� */
				String hyoukasya_score = "";
				if ( hyokasya_skill_kekka != null && hyokasya_skill_kekka.length != 0 ) {
					hyoukasya_score = hyokasya_skill_kekka[i];
				}

				/* �X�L������ */
				cell = new Cell( new Phrase( skill_list[i][1], font ) );
				cell.setRowspan( 1 );
				cell.setColspan( 1 );
				table1.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
				table1.addCell( cell );
				table1.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
		
				/* �f�f�҃X�L���f�f�I������ */
				cell = new Cell( new Phrase( sindansya_score, font ) );
				cell.setRowspan( 1 );
				cell.setColspan( 1 );
				table1.addCell( cell );
		
				/* �]���҃X�L���f�f�I������ */
				cell = new Cell( new Phrase( hyoukasya_score, font ) );
				cell.setRowspan( 1 );
				cell.setColspan( 1 );
				table1.addCell( cell );
			}

			table.insertTable( table1 );
	
			/* �h�L�������g�ɒǉ� */
			document.add(table);
			table = null;
	
			/* �X�y�[�X��}�� */
			document.add( space );
	
			/* �X�L���B���x */
			table = new MyTable( 5 );
			int[] skill_tasseido_widths = { 20, 20, 20, 20, 20 };
			table.setWidths( skill_tasseido_widths );
			table.setWidth( TableWidth );
	
			cell = new Cell( new Phrase( pram_skill_tasseido, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
	
			cell = new Cell( new Phrase( "�f�f�Җ{�l�̕]��", font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
			
			if ( sindansya_skill_tasseido == null ){
				sindansya_skill_tasseido = "";
			}
			cell = new Cell( new Phrase( sindansya_skill_tasseido, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
	
			cell = new Cell( new Phrase( "�]���f�f�̕]��", font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
			
			if ( hyokasya_skill_tasseido == null ){
				hyokasya_skill_tasseido = "";
			}
			cell = new Cell( new Phrase( hyokasya_skill_tasseido, font ) );
			cell.setRowspan( 1 );
			cell.setColspan( 1 );
			table.addCell( cell );
	
			/* �h�L�������g�ɒǉ� */
			document.add( table );
			
		} catch (BadElementException e) {
			Log.error( login_no, "HJE-0017", e);
			throw (Exception)e;
		} catch (DocumentException e) {
			Log.error( login_no, "HJE-0017", e );
			throw (Exception)e;
		} catch (MalformedURLException e) {
			Log.error( login_no, "HJE-0017", e );
			throw (Exception)e;
		} catch (IOException e) {
			Log.error( login_no, "HJE-0017", e );
			throw (Exception)e;
		} catch ( Exception e ) {
			Log.error( login_no, "HJE-0017", e );
			throw e;
		} finally {
			/* �h�L�������g����� */
			if (document != null) {
				try {
					document.close();
				} catch (Exception e) {
					Log.error( login_no, "HJE-0017", e );
					throw e;
				}
			}
			if (pw != null) {
				try {
					pw.close();
				} catch (Exception e) {
					Log.error( login_no, "HJE-0017", e );
					throw e;
				}
			}
		}
	}
}


