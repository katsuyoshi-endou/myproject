/*
 * All Rights Reserved, Copyright (C) 2004,Hitachi System & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�Г�����@�\�j
 *
 * ���l�@�F
 *
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/21  01.00       �����@��F   �V�K�쐬 
 *   2005/10/26  01.01      THANHLVT      �C���|�[�g���ꂽ�p�b�P�[�W��u��������B
 *
 */
package jp.co.hisas.career.department.base.valuebean;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Map;
import javax.servlet.*;

import jp.co.hisas.career.department.offer.bean.PEB_KouboKibouAssessmentBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboKibouSyokusyuBean;
//import jp.co.hisas.hcdb.personalsite.util.log.Log;//2005/10/26_LYCE_R_THANHLVT
import jp.co.hisas.career.util.log.Log;//2005/10/26_LYCE_A_THANHLVT


/**
 *<PRE>
 *
 * �N���X��:
 *   PEY_KouboOubosyaBean �N���X
 *
 * �@�\����:
 *   ����_����҃e�[�u���̃f�[�^�ێ����s���B
 *
 *</PRE>
 */
public class PEY_KouboOubosyaBean extends PEY_MasterBean implements Serializable {
	private String kouboankenid			= null;
	private String simeino 				= null;
	private String sosikicode				= null;
	private String oubosyagrade			= null;
	private String oubosyarate				= null;
	private String kibougyomu				= null;
	private String siboudouki				= null;
	private String jikopr					= null;
	private String gouhistatus				= null;
	private String saiyostatus				= null;
	private String toiawasesyozoku			= null;
	private String toiawasesimei			= null;
	private String toiawasegaisen			= null;
	private String toiawasenaisen			= null;
	private String toiawasemail			= null;
	private String renrakujikou			= null;
	private ArrayList kouboKibouSyokusyuList = new ArrayList();
	private ArrayList KouboKibouAssessmentList = new ArrayList();

	/**
	 * �f�t�H���g�̃R���X�g���N�^
	 */
	public PEY_KouboOubosyaBean(  ) {
	}

	/**
	 * �f�t�H���g�̃R���X�g���N�^
	 */
	public PEY_KouboOubosyaBean( ServletRequest request ) {
		setKouboankenid(request.getParameter( "koubo_anken_id" ));
		setSimeino(request.getParameter( "simei_no" ));
		setSosikicode(request.getParameter( "sosiki_code" ));
		setKouboankenid(request.getParameter( "kouboankenid" ));
		setSimeino(request.getParameter( "simeino" ));
		setSosikicode(request.getParameter( "sosikicode" ));
		setOubosyagrade(request.getParameter( "oubosyagrade" ));
		setOubosyarate(request.getParameter( "oubosyarate" ));
		setKibougyomu(request.getParameter( "kibou_gyomu" ));
		setSiboudouki(request.getParameter( "sibou_douki" ));
		setJikopr(request.getParameter( "jiko_pr" ));
		setGouhistatus(request.getParameter( "gouhistatus" ));
		setSaiyostatus(request.getParameter( "saiyostatus" ));
		setToiawasesyozoku(request.getParameter( "toiawase_syozoku" ));
		setToiawasesimei(request.getParameter( "toiawase_simei" ));
		setToiawasegaisen(request.getParameter( "toiawase_gaisen" ));
		setToiawasenaisen(request.getParameter( "toiawase_naisen" ));
		setToiawasemail(request.getParameter( "toiawase_mail" ));
		setRenrakujikou(request.getParameter( "renraku_jikou" ));
	}
	
	
	/**
	 * ResultSet ����l���擾���Č���_�����ValueBean���쐬���܂��B
	 *
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param TableName ���m�点���̃e�[�u����
	 *
	 */
	public PEY_KouboOubosyaBean( ResultSet rs, String TableName )
		throws SQLException {
	
		super( rs, TableName );
	
		try {
			setKouboankenid    (rs.getString( getIdentifier(  ) +"KOUBO_ANKEN_ID" ));
			setSimeino         (rs.getString( getIdentifier(  ) +"SIMEI_NO" ));
			setSosikicode      (rs.getString( getIdentifier(  ) +"SOSIKI_CODE" ));
			setGouhistatus     (rs.getString( getIdentifier(  ) +"GOUHI_STATUS" ));
			setSaiyostatus     (rs.getString( getIdentifier(  ) +"SAIYO_STATUS" ));
			setOubosyagrade    (rs.getString( getIdentifier(  ) +"OUBOSYA_GRADE" ));
			setOubosyarate     (rs.getString( getIdentifier(  ) +"OUBOSYA_RATE" ));
			setKibougyomu      (rs.getString( getIdentifier(  ) +"KIBOU_GYOMU" ));
			setSiboudouki      (rs.getString( getIdentifier(  ) +"SIBOU_DOUKI" ));
			setJikopr          (rs.getString( getIdentifier(  ) +"JIKO_PR" ));
			setToiawasesyozoku (rs.getString( getIdentifier(  ) +"TOIAWASE_SYOZOKU" ));
			setToiawasesimei   (rs.getString( getIdentifier(  ) +"TOIAWASE_SIMEI" ));
			setToiawasegaisen  (rs.getString( getIdentifier(  ) +"TOIAWASE_GAISEN" ));
			setToiawasenaisen  (rs.getString( getIdentifier(  ) +"TOIAWASE_NAISEN" ));
			setToiawasemail    (rs.getString( getIdentifier(  ) +"TOIAWASE_MAIL" ));
			setRenrakujikou    (rs.getString( getIdentifier(  ) +"RENRAKU_JIKOU" ));

		} catch ( SQLException e ) {
			Log.error( "", "HJE-0001", e );
			throw e;
		}
	}

	/**
	 * <pre>
	 * ����_����҃e�[�u���̌��������𒊏o���܂��B
	 * �ȉ��̍��ڂ����������Ƃ��Ďg�p�ł��܂��B
	 * �E����Č�ID
	 * </pre>
	 *
	 * @return ���o���ꂽ��������
	 */
	public Map extractConditions(  ) {
		Map conditions = new LinkedHashMap(  );
		
		if ( ( getKouboankenid(  ) != null ) && !getKouboankenid(  ).equals( "" ) ) {
			conditions.put( "KOUBO_ANKEN_ID", getKouboankenid(  ) );
		}
		if ( ( getSimeino(  ) != null ) && !getSimeino(  ).equals( "" ) ) {
			conditions.put( "SIMEI_NO", getSimeino(  ) );
		}

		return conditions;
	}

	/**
	 * @param PEB_KouboKibouSyokusyuBean
	 * @return kouboKibouSyokusyuList
	 */
	public void addKouboKibouSyokusyuBean(PEB_KouboKibouSyokusyuBean bean) {
		kouboKibouSyokusyuList.add(bean);
	}

	/**
	 * @param PEB_KouboKibouAssessmentBean
	 * @return KouboKibouAssessmentList
	 */
	public void addKouboKibouAssessmentBean(PEB_KouboKibouAssessmentBean bean) {
		KouboKibouAssessmentList.add(bean);
	}

	/**
	 * @return gouhistatus
	 */
	public String getGouhistatus() {
		return gouhistatus;
	}

	/**
	 * @return jikopr
	 */
	public String getJikopr() {
		return jikopr;
	}

	/**
	 * @return kibougyomu
	 */
	public String getKibougyomu() {
		return kibougyomu;
	}

	/**
	 * @return kouboankenid
	 */
	public String getKouboankenid() {
		return kouboankenid;
	}

	/**
	 * @return oubosyagrade
	 */
	public String getOubosyagrade() {
		return oubosyagrade;
	}

	/**
	 * @return oubosyarate
	 */
	public String getOubosyarate() {
		return oubosyarate;
	}

	/**
	 * @return renrakujikou
	 */
	public String getRenrakujikou() {
		return renrakujikou;
	}

	/**
	 * @return saiyostatus
	 */
	public String getSaiyostatus() {
		return saiyostatus;
	}

	/**
	 * @return siboudouki
	 */
	public String getSiboudouki() {
		return siboudouki;
	}

	/**
	 * @return simeino
	 */ 
	public String getSimeino() {
		return simeino;
	}

	/**
	 * @return sosikicode
	 */
	public String getSosikicode() {
		return sosikicode;
	}

	/**
	 * @return toiawasegaisen
	 */
	public String getToiawasegaisen() {
		return toiawasegaisen;
	}

	/**
	 * @return toiawasemail
	 */
	public String getToiawasemail() {
		return toiawasemail;
	}

	/**
	 * @return toiawasenaisen
	 */
	public String getToiawasenaisen() {
		return toiawasenaisen;
	}

	/**
	 * @return toiawasesimei
	 */
	public String getToiawasesimei() {
		return toiawasesimei;
	}

	/**
	 * @return toiawasesyozoku
	 */
	public String getToiawasesyozoku() {
		return toiawasesyozoku;
	}

	/**
	 * @param string
	 */
	public void setGouhistatus(String string) {
		gouhistatus = string;
	}

	/**
	 * @param string
	 */
	public void setJikopr(String string) {
		jikopr = string;
	}

	/**
	 * @param string
	 */
	public void setKibougyomu(String string) {
		kibougyomu = string;
	}

	/**
	 * @param string
	 */
	public void setKouboankenid(String string) {
		kouboankenid = string;
	}

	/**
	 * @param string
	 */
	public void setOubosyagrade(String string) {
		oubosyagrade = string;
	}

	/**
	 * @param string
	 */
	public void setOubosyarate(String string) {
		oubosyarate = string;
	}

	/**
	 * @param string
	 */
	public void setRenrakujikou(String string) {
		renrakujikou = string;
	}

	/**
	 * @param string
	 */
	public void setSaiyostatus(String string) {
		saiyostatus = string;
	}

	/**
	 * @param string
	 */
	public void setSiboudouki(String string) {
		siboudouki = string;
	}

	/**
	 * @param string
	 */
	public void setSimeino(String string) {
		simeino = string;
	}

	/**
	 * @param string
	 */
	public void setSosikicode(String string) {
		sosikicode = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasegaisen(String string) {
		toiawasegaisen = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasemail(String string) {
		toiawasemail = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasenaisen(String string) {
		toiawasenaisen = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasesimei(String string) {
		toiawasesimei = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasesyozoku(String string) {
		toiawasesyozoku = string;
	}

}