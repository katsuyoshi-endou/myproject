/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�Г�����@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/25  01.00      ��u���@�N�T  �V�K�쐬
 */
package jp.co.hisas.career.department.offer.servlet;

import java.rmi.RemoteException;


import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.department.base.PEY_ServiceLocator;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaBean;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaAssessBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboAnkenOuboBean;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenOuboEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenOuboEJBHome;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.department.base.PEY_WarningException;


/**
 *<PRE>
 *
 * �T�v�F
 *   ����Č������ʏo�͗p�f�[�^����A���L�̃e�[�u���̑}���E�X�V���s�Ȃ��B
 *     (1)D03_����_����҃e�[�u��
 *     (2)D04_����_�����_�A�Z�X�����g���ʃe�[�u��
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 *
 *</PRE>
 */
public class PEB080_KouboAnkenOuboUpdateServlet extends PEY010_ControllerServlet {
	
    protected String execute( HttpServletRequest request, HttpServletResponse response,PEY_PersonalBean loginuser )
        throws  NamingException, CreateException, PEY_WarningException, RemoteException, PEY_WarningException {
        /*���\�b�h�g���[�X�o��*/
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );
        Log.performance( loginuser.getSimeiNo(  ), true, "" );

		PEB_KouboAnkenOuboBean ouboBean = new PEB_KouboAnkenOuboBean(); 

		PEY_KouboBean kouboBean = new PEY_KouboBean();
		kouboBean.setKouboankenid(request.getParameter("koubo_anken_id"));
		ouboBean.setKouboBean(kouboBean);
		
		PEY_KouboOubosyaBean oubosyaBean = new PEY_KouboOubosyaBean();
		oubosyaBean.setKouboankenid(request.getParameter("koubo_anken_id"));
		oubosyaBean.setSimeino(request.getParameter("simei_no"));
		oubosyaBean.setSosikicode(request.getParameter("sosiki_code"));
		oubosyaBean.setOubosyagrade(request.getParameter("oubosya_grade"));
		oubosyaBean.setOubosyarate(request.getParameter("oubosya_rate"));
		oubosyaBean.setKibougyomu(request.getParameter("kibou_gyomu"));
		oubosyaBean.setSiboudouki(request.getParameter("sibou_douki"));
		oubosyaBean.setJikopr(request.getParameter("jiko_pr"));
		oubosyaBean.setGouhistatus(request.getParameter("gouhi_status"));
		oubosyaBean.setSaiyostatus(request.getParameter("saiyo_status"));
		oubosyaBean.setToiawasesyozoku(request.getParameter("toiawase_syozoku"));
		oubosyaBean.setToiawasesimei(request.getParameter("toiawase_simei"));
		oubosyaBean.setToiawasegaisen(request.getParameter("toiawase_gaisen"));
		oubosyaBean.setToiawasenaisen(request.getParameter("toiawase_naisen"));
		oubosyaBean.setToiawasemail(request.getParameter("toiawase_mail"));
		oubosyaBean.setRenrakujikou(request.getParameter("renraku_jikou"));
		oubosyaBean.setTourokubi(request.getParameter("tourokubi"));
		oubosyaBean.setTourokujikoku(request.getParameter("tourokujikoku"));
		oubosyaBean.setTourokusya(request.getParameter("tourokusya"));
		oubosyaBean.setKousinbi(request.getParameter("kousinbi"));
		oubosyaBean.setKousinjikoku(request.getParameter("kousinjikoku"));
		oubosyaBean.setKousinsya(request.getParameter("kousinsya"));
		ouboBean.setKouboOubosyaBean(oubosyaBean);
		
		if(request.getParameter("seq_no1") != null && request.getParameter("seq_no1").equals("") != true){
			PEY_KouboOubosyaAssessBean  assessBean = new PEY_KouboOubosyaAssessBean();
			assessBean.setKouboankenid(request.getParameter("koubo_anken_id"));
			assessBean.setSimeino(request.getParameter("simei_no"));
			assessBean.setSeqno("1");
			assessBean.setSyokucode(request.getParameter("syoku_code1"));
			assessBean.setSenmoncode(request.getParameter("senmon_code1"));
			assessBean.setLevelcode(request.getParameter("level_code1"));
			assessBean.setJikosougoutdo(request.getParameter("jiko_sougou_t_do1"));
			assessBean.setHyokasyasougoutdo(request.getParameter("hyokasya_sougou_t_do1"));
			assessBean.setTourokubi(request.getParameter("tourokubi1"));
			assessBean.setTourokujikoku(request.getParameter("tourokujikoku1"));
			assessBean.setTourokusya(request.getParameter("tourokusya1"));
			assessBean.setKousinbi(request.getParameter("kousinbi1"));
			assessBean.setKousinjikoku(request.getParameter("kousinjikoku1"));
			assessBean.setKousinsya(request.getParameter("kousinsya1"));
			ouboBean.addKouboOubosyaAssessBean(assessBean);
		}

		if(request.getParameter("seq_no2") != null && request.getParameter("seq_no2").equals("") != true){
			PEY_KouboOubosyaAssessBean  assessBean = new PEY_KouboOubosyaAssessBean();
			assessBean.setKouboankenid(request.getParameter("koubo_anken_id"));
			assessBean.setSimeino(request.getParameter("simei_no"));
			assessBean.setSeqno("2");
			assessBean.setSyokucode(request.getParameter("syoku_code2"));
			assessBean.setSenmoncode(request.getParameter("senmon_code2"));
			assessBean.setLevelcode(request.getParameter("level_code2"));
			assessBean.setJikosougoutdo(request.getParameter("jiko_sougou_t_do2"));
			assessBean.setHyokasyasougoutdo(request.getParameter("hyokasya_sougou_t_do2"));
			assessBean.setTourokubi(request.getParameter("tourokubi2"));
			assessBean.setTourokujikoku(request.getParameter("tourokujikoku2"));
			assessBean.setTourokusya(request.getParameter("tourokusya2"));
			assessBean.setKousinbi(request.getParameter("kousinbi2"));
			assessBean.setKousinjikoku(request.getParameter("kousinjikoku2"));
			assessBean.setKousinsya(request.getParameter("kousinsya2"));
			ouboBean.addKouboOubosyaAssessBean(assessBean);
		}

		if(request.getParameter("seq_no3") != null && request.getParameter("seq_no3").equals("") != true){
			PEY_KouboOubosyaAssessBean  assessBean = new PEY_KouboOubosyaAssessBean();
			assessBean.setKouboankenid(request.getParameter("koubo_anken_id"));
			assessBean.setSimeino(request.getParameter("simei_no"));
			assessBean.setSeqno("3");
			assessBean.setSyokucode(request.getParameter("syoku_code3"));
			assessBean.setSenmoncode(request.getParameter("senmon_code3"));
			assessBean.setLevelcode(request.getParameter("level_code3"));
			assessBean.setJikosougoutdo(request.getParameter("jiko_sougou_t_do3"));
			assessBean.setHyokasyasougoutdo(request.getParameter("hyokasya_sougou_t_do3"));
			assessBean.setTourokubi(request.getParameter("tourokubi3"));
			assessBean.setTourokujikoku(request.getParameter("tourokujikoku3"));
			assessBean.setTourokusya(request.getParameter("tourokusya3"));
			assessBean.setKousinbi(request.getParameter("kousinbi3"));
			assessBean.setKousinjikoku(request.getParameter("kousinjikoku3"));
			assessBean.setKousinsya(request.getParameter("kousinsya3"));
			ouboBean.addKouboOubosyaAssessBean(assessBean);
		}

		PEY_ServiceLocator locator   = PEY_ServiceLocator.getInstance();
		PEB_KouboAnkenOuboEJBHome kouboAnkenOuboEJBHome = ( PEB_KouboAnkenOuboEJBHome )locator.getServiceLocation( "PEB_KouboAnkenOuboEJB",	PEB_KouboAnkenOuboEJBHome.class );
		PEB_KouboAnkenOuboEJB ouboEJB = kouboAnkenOuboEJBHome.create(  );
			
		ouboEJB.updateKouboAnkenOubo(ouboBean,loginuser);

		/*���\�b�h�g���[�X�o��*/
		Log.performance(loginuser.getSimeiNo(  ),false,"");
		Log.method(loginuser.getSimeiNo(  ),"OUT","");

		/* JSP�y�[�W���Ăяo�� */
		return getForwardPath();
    }
}
