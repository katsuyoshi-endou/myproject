/*
 * All Rights Reserved. Copyright (C) 2003, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�Г�����nHCDB�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/27  01.00       �y��         �V�K�쐬
 *   2005/11/08             QUANLA       sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */
package jp.co.hisas.career.department.offer.servlet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.rmi.RemoteException;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.ejb.*;
import javax.naming.*;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletException;
import javax.servlet.http.*;

import com.lowagie.text.DocumentException;

import jp.co.hisas.career.department.base.*;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.*;
import jp.co.hisas.career.department.offer.bean.PEB_OubosyaJyohoBean;
import jp.co.hisas.career.department.offer.ejb.*;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.pdf.PZE140_OubosyaJyohoPDF;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 *<PRE>
 * �N���X���F
 *   PEB055_OubosyaJyohoPdfServlet
 *
 * �@�\�����F
 *	����ҏ��Ɋւ���PDF���쐬����B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 *</PRE>
 */
public class PEB059_OubosyaJyohoPdfServlet extends PEY010_ControllerServlet {
	/**
	 * request������̓f�[�^���擾���A�c�a�Ƀf�[�^���������܂��B
	 */
	protected String execute(
		HttpServletRequest request,
		HttpServletResponse response,
		PEY_PersonalBean loginuser)
		throws Exception {

		/*���\�b�h�g���[�X�o��*/
		Log.method("", "IN", "");

		/* request ����A�l���擾 */
		String simeiNo = request.getParameter("simei_no");
		String kouboAnkenId =
			PZZ010_CharacterUtil.changeAnkenIdLength(
				request.getParameter("koubo_anken_id"));

		if (simeiNo == null || simeiNo.length() <= 0) {
			//redirectErrorView(response, loginuser);        //2005/11/08_LYCE_R_QUANLA
            redirectErrorView(request, response, loginuser); //2005/11/08_LYCE_A_QUANLA
            return null;
		}

		if (kouboAnkenId == null || kouboAnkenId.length() <= 0) {
            //redirectErrorView(response, loginuser);        //2005/11/08_LYCE_R_QUANLA
            redirectErrorView(request, response, loginuser); //2005/11/08_LYCE_A_QUANLA
			return null;
		}

		try {
			PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance();
			PEB_OubosyaJyohoEJBHome home =
				(PEB_OubosyaJyohoEJBHome) locator.getServiceLocation(
					"PEB_OubosyaJyohoEJB",
					PEB_OubosyaJyohoEJBHome.class);
			PEB_OubosyaJyohoEJB ejb = home.create();

			/* �f�[�^���擾���� */
			PEB_OubosyaJyohoBean koubooubosyaBean =
				ejb.getOubosyaJyohoInfo(kouboAnkenId, simeiNo);

			if (koubooubosyaBean == null) {
				//�Y���f�[�^�����B
				throw new PEY_WarningException();
			}

			/* �t�@�C���ǂݍ��ݗp�o�b�t�@ */
			byte[] buffer = new byte[4096];

			PZE140_OubosyaJyohoPDF pdfMaker = new PZE140_OubosyaJyohoPDF();

			/* contentType���o�� */
			response.setContentType( "application/pdf" );

			/* �t�@�C�����̑��M(attachment������inline�ɕύX����΃C�����C���\��) */
			response.setHeader( "Content-Disposition", "inline;" );
			String pdfFileName = makePdfFileName(loginuser);
			response.setHeader( "Content-Disposition", "attachment; filename=\"" + pdfFileName + "\"");


			ByteArrayOutputStream baos = new ByteArrayOutputStream(  );

			boolean pdfOutput = pdfMaker.makePDF(baos, koubooubosyaBean);

			if ( !pdfOutput ) {
                //redirectErrorView(response, loginuser);        //2005/11/08_LYCE_R_QUANLA
                redirectErrorView(request, response, loginuser); //2005/11/08_LYCE_A_QUANLA
			}
			ServletOutputStream out = response.getOutputStream(  );
			ByteArrayInputStream bais  = new ByteArrayInputStream( baos.toByteArray() );
			if ( bais != null ) {
				int size;

				while ( ( size = bais.read( buffer ) ) != -1 ) {
					out.write( buffer, 0, size );
				}

				bais.close(  );
			}
			out.close(  );
			response.flushBuffer(  );
			

			/*���\�b�h�g���[�X�o��*/
			Log.method("", "OUT", "");
			return null;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw e;
		} catch ( CreateException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} catch ( RemoteException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} catch ( IOException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0012", e );
			throw e;
		} catch ( DocumentException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} catch ( Exception e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		}

	}
	/**
	 * �G���[��ʂ�\������B
	 */
    //private void redirectErrorView(HttpServletResponse response, PEY_PersonalBean loginuser) { //2005/11/08_LYCE_R_QUANLA
    //2005/11/08_LYCE_A_QUANLA START
    private void redirectErrorView(
            HttpServletRequest request,
            HttpServletResponse response,
            PEY_PersonalBean loginuser)
    throws ServletException {
    //2005/11/08_LYCE_A_QUANLA END
		try {
			//response.sendRedirect("/" + HcdbDef.root + "/view/Error.jsp");	//2005/11/08_LYCE_R_QUANLA
			this.getServletConfig( ).getServletContext( ).getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
		} catch (IOException e) {
			Log.error(loginuser.getSimeiNo(), "HJE-0012", e);
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * PDF�t�@�C�������쐬����B
	 * @param userinfo
	 * @return PDF�t�@�C�����B
	 */
	private String makePdfFileName(PEY_PersonalBean userinfo) {
		StringBuffer buf = new StringBuffer();
		buf.append(userinfo.getSimeiNo());
		buf.append("_");
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		buf.append(df.format(Calendar.getInstance().getTime()));
		buf.append("_");
		buf.append("VEB055");
		buf.append(".pdf");
		return buf.toString();
	}

}
