/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�Г�����@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/20  01.00      ��u���@�N�T  �V�K�쐬
 *   2005/11/08             QUANLA       sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */
package jp.co.hisas.career.department.offer.servlet;

import java.io.IOException;
import java.rmi.RemoteException;


import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;

import jp.co.hisas.career.department.base.PEY_ServiceLocator;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaBean;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaAssessBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboAnkenOuboBean;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenOuboEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenOuboEJBHome;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 *<PRE>
 *
 * �T�v�F
 *   ����Č������ʏo�͗p�f�[�^���擾���A����Č������ʂɑJ�ڂ���B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 *
 *</PRE>
 */
public class PEB080_KouboAnkenOuboShowServlet extends PEY010_ControllerServlet {
	
    protected String execute(HttpServletRequest request, HttpServletResponse response,
        PEY_PersonalBean loginuser )
        throws Exception {
        	
        /*���\�b�h�g���[�X�o��*/
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );
        Log.performance( loginuser.getSimeiNo(  ), true, "" );

		//�p�����[�^�usearchFlg�v�̈Ӗ�
		//  1:�f�[�^��request���猟������B
		//  ��L�ȊO�܂��̓p�����[�^����:�f�[�^���f�[�^�x�[�X���猟������B
		String searchFlg = request.getParameter("searchFlg");
		
        try {
			PEB_KouboAnkenOuboBean ouboBean = null;

			if(searchFlg == null){
				ouboBean = editFromDatabase(request,response,loginuser);
			}else{
				if(searchFlg.equals("1") == true){
					ouboBean = editFromRequest(request,response,loginuser);
				}else{
					ouboBean = editFromDatabase(request,response,loginuser);
				}
			}

			if(ouboBean != null){
				request.setAttribute( "ouboBeans", ouboBean );
			}else{
                //redirectErrorView(response, loginuser);        //2005/11/08_LYCE_R_QUANLA
                redirectErrorView(request, response, loginuser); //2005/11/08_LYCE_A_QUANLA
				return null;
			}

			/*���\�b�h�g���[�X�o��*/
			Log.performance(loginuser.getSimeiNo(  ),false,"");
			Log.method(loginuser.getSimeiNo(  ),"OUT","");

			/* JSP�y�[�W���Ăяo�� */
			return getForwardPath();
			
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw e;
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        }
    }

	/**
	 * �f�[�^�x�[�X�������Č������ʏo�͗p�f�[�^��ҏW����B
	 */
	private PEB_KouboAnkenOuboBean editFromDatabase(HttpServletRequest request, HttpServletResponse response,PEY_PersonalBean loginuser )
		throws Exception {

		/*���\�b�h�g���[�X�o��*/
		Log.method( loginuser.getSimeiNo(  ), "IN", "" );

		String kouboAnkenId = request.getParameter("koubo_anken_id");
		String simeiNo = loginuser.getSimeiNo();

		if (kouboAnkenId == null || kouboAnkenId.length() <= 0) {
			return null;
		}

		try{
			PEY_ServiceLocator locator   = PEY_ServiceLocator.getInstance();
			PEB_KouboAnkenOuboEJBHome kouboAnkenOuboEJBHome = ( PEB_KouboAnkenOuboEJBHome )locator.getServiceLocation( "PEB_KouboAnkenOuboEJB",	PEB_KouboAnkenOuboEJBHome.class );
			PEB_KouboAnkenOuboEJB ouboEJB = kouboAnkenOuboEJBHome.create(  );
			
			PEB_KouboAnkenOuboBean oubo = ouboEJB.getKouboAnkenOubo(kouboAnkenId,simeiNo);

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
			
			return oubo;
		} catch ( NamingException e ) {
			throw e;
		} catch ( CreateException e ) {
			throw e;
		} catch ( RemoteException e ) {
			throw e;
		}
	}

	/**
	 * request�������Č������ʏo�͗p�f�[�^��ҏW����B
	 */
	private PEB_KouboAnkenOuboBean editFromRequest(HttpServletRequest request, HttpServletResponse response,PEY_PersonalBean loginuser ){
		/*���\�b�h�g���[�X�o��*/
		Log.method( loginuser.getSimeiNo(  ), "IN", "" );

		PEY_KouboBean kouboBean = null;
		PEY_KouboOubosyaBean  kouboOubosyaBean = null;
		PEY_KouboOubosyaAssessBean kouboOubosyaAssessBean = null;
		PEB_KouboAnkenOuboBean ouboBean = null;
		
		ouboBean = new PEB_KouboAnkenOuboBean();

		//����f�[�^���Z�b�g
		kouboBean = new PEY_KouboBean();
		kouboBean.setKouboankenid(request.getParameter("koubo_anken_id"));
		kouboBean.setKouboankenmei(request.getParameter("koubo_anken_mei"));
		ouboBean.setKouboBean(kouboBean);
		
		//���剞��҃f�[�^���Z�b�g
		kouboOubosyaBean = new PEY_KouboOubosyaBean();
		kouboOubosyaBean.setKouboankenid(request.getParameter("koubo_anken_id"));
		kouboOubosyaBean.setSimeino(request.getParameter("simei_no"));
		kouboOubosyaBean.setSosikicode(request.getParameter("sosiki_code"));
		kouboOubosyaBean.setOubosyagrade(request.getParameter("oubosya_grade"));
		kouboOubosyaBean.setOubosyarate(request.getParameter("oubosya_rate"));
		kouboOubosyaBean.setKibougyomu(request.getParameter("kibou_gyomu"));
		kouboOubosyaBean.setSiboudouki(request.getParameter("sibou_douki"));
		kouboOubosyaBean.setJikopr(request.getParameter("jiko_pr"));
		kouboOubosyaBean.setGouhistatus(request.getParameter("gouhi_status"));
		kouboOubosyaBean.setSaiyostatus(request.getParameter("saiyo_status"));
		kouboOubosyaBean.setToiawasesyozoku(request.getParameter("toiawase_syozoku"));
		kouboOubosyaBean.setToiawasesimei(request.getParameter("toiawase_simei"));
		kouboOubosyaBean.setToiawasegaisen(request.getParameter("toiawase_gaisen"));
		kouboOubosyaBean.setToiawasenaisen(request.getParameter("toiawase_naisen"));
		kouboOubosyaBean.setToiawasemail(request.getParameter("toiawase_mail"));
		kouboOubosyaBean.setRenrakujikou(request.getParameter("renraku_jikou"));
		kouboOubosyaBean.setTourokubi(request.getParameter("tourokubi"));
		kouboOubosyaBean.setTourokujikoku(request.getParameter("tourokujikoku"));
		kouboOubosyaBean.setTourokusya(request.getParameter("tourokusya"));
		kouboOubosyaBean.setKousinbi(request.getParameter("kousinbi"));
		kouboOubosyaBean.setKousinjikoku(request.getParameter("kousinjikoku"));
		kouboOubosyaBean.setKousinsya(request.getParameter("kousinsya"));
		ouboBean.setKouboOubosyaBean(kouboOubosyaBean);

		//���剞��҃A�Z�X�����g�f�[�^���Z�b�g
		//�A�Z�X�����g�������牺�L�̃p�����[�^���Z�b�g����邱�Ƃ�z�肵�Ă���
		//  syoku_code1�`3
		//  senmon_code1�`3
		//  level_code1�`3
		//  jiko_sougou_t_do1�`3
		//  hyokasya_sougou_t_do1�`3
		final String SYOKU_CODE = "syoku_code";
		final String SENMON_CODE = "senmon_code";
		final String LEVEL_CODE = "level_code";
		final String JIKO_T_DO = "jiko_sougou_t_do";
		final String HYOKA_T_DO = "hyokasya_sougou_t_do";
		final int ARRAY_MAX_PREFIX = 3;
		int seqNo = 0;
		
		for(int i = 1;i <= ARRAY_MAX_PREFIX;i++){
			if(request.getParameter(SYOKU_CODE + Integer.toString(i)) != null){
				if(request.getParameter(SYOKU_CODE + Integer.toString(i)).equals("") != true){
					kouboOubosyaAssessBean = new PEY_KouboOubosyaAssessBean();
					kouboOubosyaAssessBean.setKouboankenid(request.getParameter("koubo_anken_id"));
					kouboOubosyaAssessBean.setSimeino(request.getParameter("simei_no"));
					kouboOubosyaAssessBean.setSeqno(Integer.toString(++seqNo));
					kouboOubosyaAssessBean.setSyokucode(request.getParameter(SYOKU_CODE + Integer.toString(i)));
					kouboOubosyaAssessBean.setSenmoncode(request.getParameter(SENMON_CODE + Integer.toString(i)));
					kouboOubosyaAssessBean.setLevelcode(request.getParameter(LEVEL_CODE + Integer.toString(i)));
					kouboOubosyaAssessBean.setJikosougoutdo(request.getParameter(JIKO_T_DO + Integer.toString(i)));
					kouboOubosyaAssessBean.setHyokasyasougoutdo(request.getParameter(HYOKA_T_DO + Integer.toString(i)));
					ouboBean.addKouboOubosyaAssessBean(kouboOubosyaAssessBean);
				}
			}
		}

		/*���\�b�h�g���[�X�o��*/
		Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
		
		return ouboBean;
	}
    
    /**
     * �G���[��ʂ�\������B
     */
    //private void redirectErrorView(HttpServletResponse response, PEY_PersonalBean loginuser) { //2005/11/08_LYCE_R_QUANLA
    //2005/11/08_LYCE_A_QUANLA START
    private void redirectErrorView(
            HttpServletRequest request,
            HttpServletResponse response,
            PEY_PersonalBean loginuser)
    throws ServletException {
    //2005/11/08_LYCE_A_QUANLA END
        /*���\�b�h�g���[�X�o��*/
		Log.method( loginuser.getSimeiNo(  ), "IN", "" );

    	try {
			//response.sendRedirect( "/" + HcdbDef.root + "/view/Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
			this.getServletConfig( ).getServletContext( ).getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
    	}
    	catch (IOException e) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0012", e );
			throw new RuntimeException(e);
    	}
    }
}
