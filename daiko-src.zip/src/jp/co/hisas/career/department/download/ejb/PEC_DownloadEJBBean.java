/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F�A�Z�X�����g�_�E�����[�h
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t		�o�[�W����  ���O		 ���e
 *   2005/08/09			  ���H���@�G�F�@ �g�D�ꗗ�擾�p�ɐV�K�쐬
 *   2005/11/09	01.01	  THANHLVT       Change HITACHI_SAS_NYUSYA_NENGETU to NYUSYA_NENGETU
 */
package jp.co.hisas.career.department.download.ejb;

import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.rmi.*;
import java.sql.*;
import java.util.*;
import javax.ejb.*;
import javax.naming.*;

import jp.co.hisas.career.department.download.valuebean.*;
import jp.co.hisas.career.department.base.valuebean.*;
import jp.co.hisas.career.department.base.*;

/**
 *<PRE>
 *
 * �N���X���F
 *   PEC_DownloadEJBBean�N���X
 *
 * �@�\�����F
 *   �e��Ώۃ}�X�^����ꗗ���擾���܂��B
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PEC_TaisyoEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PEC_DownloadEJBBean implements SessionBean {
	private SessionContext context = null;


	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext( SessionContext context )
		throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 *
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate(  ) throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove(  ) throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate(  ) throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate(  ) throws EJBException, RemoteException {
	}


	/**
	 * �g�D�e�[�u������ꗗ���擾���܂��B
	 * �߂�l�͑g�D��񂪊i�[���ꂽ �g�D ValueBean �ł��B
	 *
	 * @param loginuser ���O�C�����[�U���
	 * @param kaiso �K�w�̍i������
	 * @return �Ώۑg�D���̈ꗗ
	 * @exception NamingException ���O�����Ɏ��s�����ꍇ
	 * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PEC_SosikiBean[] getSosiki( 
		PEY_PersonalBean loginuser,
		String kaiso 
		)
		throws NamingException, RemoteException {
		Connection con		= null;
		PreparedStatement ps  = null;
		PEC_SosikiBean sosiki = null;

		try {
			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			String sibori="";
			if(kaiso!=null){
				sibori=" WHERE kaisou='"+ kaiso +"'";
			}

			StringBuffer sql = new StringBuffer();
			
			sql.append("SELECT ")
			.append("rtrim(SOSIKI_CODE) as SOSIKI_CODE,")
			.append("rtrim(SOSIKI_MEI) as SOSIKI_MEI,")
			.append("BUSYO_RYAKUSYO_MEI,")
			.append("JOUI_SOSIKI_CODE,")
			.append("KAISOU,")
			.append("KAI_SOSIKI_UMU,")
			.append("SOSIKI_MEI_KANA,")
			.append("SOSIKI_MEI_EIJI ")
			.append("FROM ")
			.append(HcdbDef.sosikiTbl)
			.append(sibori)
			.append(" ORDER BY sosiki_code");


			/* �f�o�b�O���O */
			Log.debug( sql.toString(  ) );


			// �R�l�N�V�����擾
			PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
			con	 = locator.getDataSource(  ).getConnection(  );
			ps	  = con.prepareStatement( sql.toString(  ) );
			ResultSet rs = ps.executeQuery(  );
			


			Vector ret = new Vector(  );

			while ( rs.next(  ) ) {
				sosiki = new PEC_SosikiBean( rs, "" );
				ret.add( sosiki );
			}

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return ( PEC_SosikiBean[] )ret.toArray( new PEC_SosikiBean[0] );
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}


	/**
	 * �A�Z�X�����g�����擾���܂��B 
	 * �߂�l��PEC_DownloadCsvSougouBean��Vector�Ɋi�[�������̂ł��B
	 *
	 * @param loginuser ���O�C�����[�U���
	 * @param busyo_cd �i�肱�ݏ����ƂȂ镔���R�[�h�@NULL�̏ꍇ�͎w��Ȃ�
	 * @param taisyokikan�@�i�肱�ݏ����ƂȂ�A�Z�X�����g�f�f�̎��{�N�����@Null�̏ꍇ�͎w�薳��
	 * @return �A�Z�X�����g���̈ꗗ
	 * @exception NamingException ���O�����Ɏ��s�����ꍇ
	 * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public Vector getCsvSougou( 
		PEY_PersonalBean loginuser,
		String busyo_cd,
		String taisyokikan 
		)
		throws NamingException, RemoteException {

		Connection con		= null;
		PreparedStatement ps  = null;
		Statement stmt =null;
				
		PEC_DownloadCsvSougouBean csvData=null;

		Vector v_result= new Vector();
		
		try {
			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );


			String busyo_sql="";
			String taisyokikan_sql="";
			
			if(busyo_cd !=null && !"".equalsIgnoreCase(busyo_cd)){
				busyo_sql= " where SYOZOKU_CODE_4 = '" + busyo_cd +"' ";
			}
			if(taisyokikan !=null && !"".equalsIgnoreCase(taisyokikan)){
				taisyokikan_sql= " and P21.JISSI_NENGAPPI >= '" + taisyokikan + "' ";
			}

			StringBuffer sql = new StringBuffer();
			
			sql.append("SELECT ")
			.append("T01P21.SIMEI_NO,")
			.append("substr(T01P21.KANJI_SIMEI,2,length(T01P21.KANJI_SIMEI)) as KANJI_SIMEI,")
			.append("substr(T01P21.KANA_SIMEI,2,length(T01P21.KANA_SIMEI)) as KANA_SIMEI,")
			.append("T01P21.SOSIKI_CODE,")
			.append("substr(T01P21.BUSYO_RYAKUSYO_MEI,2,length(T01P21.BUSYO_RYAKUSYO_MEI)) as BUSYO_RYAKUSYO_MEI,")
			.append("substr(T01P21.YAKUSYOKU,2,length(T01P21.YAKUSYOKU)) as YAKUSYOKU,")
			.append("T01P21.SEINENGAPPI,")
			.append("substr(T01P21.HITACHI_SAS_NYUSYA_NENGETU,2,length(T01P21.HITACHI_SAS_NYUSYA_NENGETU)) as HITACHI_SAS_NYUSYA_NENGETU,")
			.append("T01P21.SYOZOKU_CODE_1,")
			.append("T01P21.SYOZOKU_CODE_2,")
			.append("T01P21.SYOZOKU_CODE_3,")
			.append("T01P21.SYOZOKU_CODE_4,")
			.append("T01P21.SYOZOKU_CODE_5,")
			.append("T01P21.SYOZOKU_CODE_6,")
			.append("T01P21.SYOZOKU_CODE_7,")
			.append("T01P21.SYOZOKU_CODE_8,")
			.append("T01P21.SYOZOKU_CODE_9,")
			.append("T01P21.SINDANSYA,")
			.append("T01P21.SYOKU_CODE,")
			.append("T01P21.SENMON_CODE,")
			.append("T01P21.LEVEL_CODE,")
			.append("T01P21.JISSI_KAISU,")
			.append("T01P21.JISSI_NENGAPPI,")
			.append("T01P21.GYOMU_KEIKEN_T_DO,")
			.append("T01P21.SKILL_T_DO,")
			.append("T01P21.SOUGOU_T_DO,")
			.append("T01P21.CAREER_CHALLENGE_KIKAN_MEI,")
			.append("T01P21.SYOKU_NAME,")
			.append("T01P21.SENMON_NAME,")
			.append("T01P21.LEVEL_NAME,")
			.append("P24.GYOMU_KEIKEN_T_DO as GYOMU_KEIKEN_T_DO_HYO,")
			.append("P24.SKILL_T_DO as SKILL_T_DO_HYO,")
			.append("P24.SOUGOU_T_DO as SOUGOU_T_DO_HYO ")
			.append("from ")
			.append("(select  ")
			.append("SINDANSYA,")
			.append("SYOKU_CODE,")
			.append("SENMON_CODE,")
			.append("LEVEL_CODE,")
			.append("JISSI_KAISU,")
			.append("JISSI_NENGAPPI,")
			.append("GYOMU_KEIKEN_T_DO,")
			.append("SKILL_T_DO,")
			.append("SOUGOU_T_DO,")
			.append("CAREER_CHALLENGE_KIKAN_MEI,")
			.append("SYOKU_NAME,")
			.append("SENMON_NAME,")
			.append("LEVEL_NAME,")
			.append("SIMEI_NO,")
			.append("KANJI_SIMEI,")
			.append("KANA_SIMEI,")
			.append("SOSIKI_CODE,")
			.append("BUSYO_RYAKUSYO_MEI,")
			.append("YAKUSYOKU,")
			.append("SEINENGAPPI,")
			.append("HITACHI_SAS_NYUSYA_NENGETU,")
			.append("SYOZOKU_CODE_1,")
			.append("SYOZOKU_CODE_2,")
			.append("SYOZOKU_CODE_3,")
			.append("SYOZOKU_CODE_4,")
			.append("SYOZOKU_CODE_5,")
			.append("SYOZOKU_CODE_6,")
			.append("SYOZOKU_CODE_7,")
			.append("SYOZOKU_CODE_8,")
			.append("SYOZOKU_CODE_9 ")
			.append("from P21_ASSESSMENT_SINDAN_TBL P21,")
			.append("( ")
			.append("select ")
			.append("SIMEI_NO,")
			.append("KANJI_SIMEI,")
			.append("KANA_SIMEI,")
			.append("SOSIKI_CODE,")
			.append("BUSYO_RYAKUSYO_MEI,")
			.append("YAKUSYOKU,")
			.append("SEINENGAPPI,")
//			.append("HITACHI_SAS_NYUSYA_NENGETU,") //2005/11/09_LYCE_R_THANHLVT
			.append("NYUSYA_NENGETU as HITACHI_SAS_NYUSYA_NENGETU,") //2005/11/09_LYCE_A_THANHLVT
			.append("SYOZOKU_CODE_1,")
			.append("SYOZOKU_CODE_2,")
			.append("SYOZOKU_CODE_3,")
			.append("SYOZOKU_CODE_4,")
			.append("SYOZOKU_CODE_5,")
			.append("SYOZOKU_CODE_6,")
			.append("SYOZOKU_CODE_7,")
			.append("SYOZOKU_CODE_8,")
			.append("SYOZOKU_CODE_9 ")
			.append(" from T01_PERSONAL_TBL ")
			.append(busyo_sql)
			.append(") T01 ")
			.append("where ")
			.append("T01.SIMEI_NO=P21.SINDANSYA ")
			.append(taisyokikan_sql)
			.append(") T01P21 ")
			.append("LEFT JOIN  P24_ASSESSMENT_HYOKA_TBL P24 ")
			.append("ON (")
			.append("T01P21.SINDANSYA=P24.SINDANSYA")
			.append(" and ")
			.append("T01P21.SYOKU_CODE=P24.SYOKU_CODE ")
			.append(" and ")
			.append("T01P21.SENMON_CODE=P24.SENMON_CODE")
			.append(" and ")
			.append("T01P21.LEVEL_CODE=P24.LEVEL_CODE")
			.append(" and ")
			.append(" T01P21.JISSI_KAISU=P24.JISSI_KAISU")
			.append(") ")
			.append("order by T01P21.SOSIKI_CODE,")
			.append("T01P21.SIMEI_NO,")
			.append("T01P21.SYOKU_CODE,")
			.append("T01P21.SENMON_CODE,")
			.append("T01P21.LEVEL_CODE,")
			.append("T01P21.JISSI_KAISU");
			
			/* �f�o�b�O���O */
			Log.debug("getCsvSougou:SQL=" +  sql.toString(  ) );

			// �R�l�N�V�����擾
			PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
			con	 = locator.getDataSource(  ).getConnection(  );

			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, 
												 ResultSet.CONCUR_UPDATABLE);

			ResultSet rs = stmt.executeQuery(sql.toString());

			int i_row=0;
			
			rs.last();
			
			int i_maxlength=rs.getRow();
			
			rs.beforeFirst();
			

			while ( rs.next(  ) ) {
				i_row++;
				
				csvData = new PEC_DownloadCsvSougouBean();
				csvData.setSindansya(rs.getString("SIMEI_NO"));
				csvData.setKanji_simei(rs.getString("KANJI_SIMEI"));
				csvData.setKana_simei(rs.getString("KANA_SIMEI"));
				csvData.setSosiki_code(rs.getString("SOSIKI_CODE"));
				csvData.setBusyo_ryakusyo_mei(rs.getString("BUSYO_RYAKUSYO_MEI"));
				csvData.setYakusyoku(rs.getString("YAKUSYOKU"));
				csvData.setSeinengappi(rs.getString("SEINENGAPPI"));
				csvData.setHitachi_sas_nyusya_nengetu(rs.getString("HITACHI_SAS_NYUSYA_NENGETU"));
				csvData.setSyozoku_code_1(rs.getString("SYOZOKU_CODE_1"));
				csvData.setSyozoku_code_2(rs.getString("SYOZOKU_CODE_2"));
				csvData.setSyozoku_code_3(rs.getString("SYOZOKU_CODE_3"));
				csvData.setSyozoku_code_4(rs.getString("SYOZOKU_CODE_4"));
				csvData.setSyozoku_code_5(rs.getString("SYOZOKU_CODE_5"));
				csvData.setSyozoku_code_6(rs.getString("SYOZOKU_CODE_6"));
				csvData.setSyozoku_code_7(rs.getString("SYOZOKU_CODE_7"));
				csvData.setSyozoku_code_8(rs.getString("SYOZOKU_CODE_8"));
				csvData.setSyozoku_code_9(rs.getString("SYOZOKU_CODE_9"));
				csvData.setSindansya(rs.getString("SINDANSYA"));
				csvData.setSyoku_code(rs.getString("SYOKU_CODE"));
				csvData.setSenmon_code(rs.getString("SENMON_CODE"));
				csvData.setLevel_code(rs.getString("LEVEL_CODE"));
				csvData.setJissi_kaisu(rs.getString("JISSI_KAISU"));
				csvData.setJissi_nengappi(rs.getString("JISSI_NENGAPPI"));
				csvData.setGyomu_keiken_t_do(rs.getString("GYOMU_KEIKEN_T_DO"));
				csvData.setSkill_t_do(rs.getString("SKILL_T_DO"));
				csvData.setSougou_t_do(rs.getString("SOUGOU_T_DO"));
				csvData.setCareer_challenge_kikan_mei(rs.getString("CAREER_CHALLENGE_KIKAN_MEI"));
				csvData.setSyoku_name(rs.getString("SYOKU_NAME"));
				csvData.setSenmon_name(rs.getString("SENMON_NAME"));
				csvData.setLevel_name(rs.getString("LEVEL_NAME"));
				csvData.setGyomu_keiken_t_do_hyo(rs.getString("GYOMU_KEIKEN_T_DO_HYO"));
				csvData.setSkill_t_do_hyo(rs.getString("SKILL_T_DO_HYO"));
				csvData.setSougou_t_do_hyo(rs.getString("SOUGOU_T_DO_HYO"));
				v_result.add( csvData );
			}

			/* �f�o�b�O���O */
			Log.debug("getCsvSougou:i_row=" +  new Integer(i_row).toString() );

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return v_result;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
			throw e;
		} finally {
			if ( stmt != null ) {
				try {
					stmt.close(  );
				} catch (Exception e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch (Exception e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * �A�Z�X�����g�����擾���܂��B 
	 * �߂�l��PEC_DownloadCsvGyomuBean��Vector�Ɋi�[�������̂ł��B
	 *
	 * @param loginuser ���O�C�����[�U���
	 * @param busyo_cd �i�肱�ݏ����ƂȂ镔���R�[�h�@NULL�̏ꍇ�͎w��Ȃ�
	 * @param taisyokikan�@�i�肱�ݏ����ƂȂ�A�Z�X�����g�f�f�̎��{�N�����@Null�̏ꍇ�͎w�薳��
	 * @return �A�Z�X�����g���̈ꗗ
	 * @exception NamingException ���O�����Ɏ��s�����ꍇ
	 * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public Vector getCsvGyomu( 
		PEY_PersonalBean loginuser,
		String busyo_cd,
		String taisyokikan 
		)
		throws NamingException, RemoteException {

		Connection con		= null;
		PreparedStatement ps  = null;
		Statement stmt =null;
				
		PEC_DownloadCsvGyomuBean csvData=null;

		Vector v_result= new Vector();
		
		try {
			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );


			String busyo_sql="";
			String taisyokikan_sql="";
			
			if(busyo_cd !=null && !"".equalsIgnoreCase(busyo_cd)){
				busyo_sql= " where SYOZOKU_CODE_4 = '" + busyo_cd +"' ";
			}
			if(taisyokikan !=null && !"".equalsIgnoreCase(taisyokikan)){
				taisyokikan_sql= " and P21.JISSI_NENGAPPI >= '" + taisyokikan + "' ";
			}

			StringBuffer sql = new StringBuffer();
			
			sql.append("SELECT ")
			.append("P22.SINDANSYA,")
			.append("P22.SYOKU_CODE,")
			.append("P22.SENMON_CODE,")
			.append("P22.LEVEL_CODE,")
			.append("P22.JISSI_KAISU,")
			.append("P22.TASSEIDO_KUBUN_CODE,")
			.append("P09.TASSEIDO_KUBUN,")
			.append("P22.TASSEIDO_SIHYO_CODE,")
			.append("P05.TASSEIDO_SIHYO,")
			.append("P22.KUBUN,")
			.append("P22.SENTAKU_FLG ")
			.append("FROM  P22_GYOMU_HYOKA_TBL P22,")
			.append("P09_C_TASEIDO_KUBUN_TBL P09,")
			.append("P05_C_TASEIDO_SIHYO_TBL P05,")
			.append("(SELECT ")
			.append("SINDANSYA,")
			.append("SYOKU_CODE,")
			.append("SENMON_CODE,")
			.append("LEVEL_CODE,")
			.append("JISSI_KAISU,")
			.append("JISSI_NENGAPPI,")
			.append("GYOMU_KEIKEN_T_DO,")
			.append("SKILL_T_DO,")
			.append("SOUGOU_T_DO,")
			.append("CAREER_CHALLENGE_KIKAN_MEI,")
			.append("SYOKU_NAME,")
			.append("SENMON_NAME,")
			.append("LEVEL_NAME,")
			.append("SIMEI_NO,")
			.append("KANJI_SIMEI,")
			.append("KANA_SIMEI,")
			.append("SOSIKI_CODE,")
			.append("BUSYO_RYAKUSYO_MEI,")
			.append("YAKUSYOKU,")
			.append("SEINENGAPPI,")
			.append("HITACHI_SAS_NYUSYA_NENGETU,")
			.append("SYOZOKU_CODE_1,")
			.append("SYOZOKU_CODE_2,")
			.append("SYOZOKU_CODE_3,")
			.append("SYOZOKU_CODE_4,")
			.append("SYOZOKU_CODE_5,")
			.append("SYOZOKU_CODE_6,")
			.append("SYOZOKU_CODE_7,")
			.append("SYOZOKU_CODE_8,")
			.append("SYOZOKU_CODE_9 ")
			.append("FROM P21_ASSESSMENT_SINDAN_TBL P21,")
			.append("(")
			.append("SELECT ")
			.append("SIMEI_NO,")
			.append("KANJI_SIMEI,")
			.append("KANA_SIMEI,")
			.append("SOSIKI_CODE,")
			.append("BUSYO_RYAKUSYO_MEI,")
			.append("YAKUSYOKU,")
			.append("SEINENGAPPI,")
//			.append("HITACHI_SAS_NYUSYA_NENGETU,") //2005/11/10_LYCE_R_THANHLVT
			.append("NYUSYA_NENGETU as HITACHI_SAS_NYUSYA_NENGETU,") //2005/11/10_LYCE_A_THANHLVT
			.append("SYOZOKU_CODE_1,")
			.append("SYOZOKU_CODE_2,")
			.append("SYOZOKU_CODE_3,")
			.append("SYOZOKU_CODE_4,")
			.append("SYOZOKU_CODE_5,")
			.append("SYOZOKU_CODE_6,")
			.append("SYOZOKU_CODE_7,")
			.append("SYOZOKU_CODE_8,")
			.append("SYOZOKU_CODE_9 ")
			.append("FROM T01_PERSONAL_TBL ")
			.append(busyo_sql)
			.append(") T01 ")
			.append("WHERE ")
			.append("T01.SIMEI_NO=P21.SINDANSYA")
			.append(taisyokikan_sql)
			.append(") T01P21 ")
			.append("WHERE ")
			.append("T01P21.SINDANSYA=P22.SINDANSYA")
			.append(" AND ")
			.append("T01P21.SYOKU_CODE=P22.SYOKU_CODE ")
			.append(" AND ")
			.append("T01P21.SENMON_CODE=P22.SENMON_CODE")
			.append(" AND ")
			.append("T01P21.LEVEL_CODE=P22.LEVEL_CODE")
			.append(" AND ")
			.append("T01P21.JISSI_KAISU=P22.JISSI_KAISU")
			.append(" AND ")
			.append("P22.TASSEIDO_KUBUN_CODE=P09.TASSEIDO_KUBUN_CODE")
			.append(" AND ")
			.append("P22.SYOKU_CODE=P05.SYOKU_CODE")
			.append(" AND ")
			.append("P22.SENMON_CODE=P05.SENMON_CODE")
			.append(" AND ")
			.append("P22.LEVEL_CODE=P05.LEVEL_CODE")
			.append(" AND ")
			.append("P22.TASSEIDO_SIHYO_CODE =P05.TASSEIDO_SIHYO_CODE ")
			.append("ORDER BY ")
			.append("P22.SINDANSYA,")
			.append("P22.SYOKU_CODE,")
			.append("P22.SENMON_CODE,")
			.append("P22.LEVEL_CODE,")
			.append("P22.JISSI_KAISU,")
			.append("P22.TASSEIDO_KUBUN_CODE,")
			.append("P22.TASSEIDO_SIHYO_CODE");
			
			/* �f�o�b�O���O */
			Log.debug("getCsvGyomu:SQL=" +  sql.toString(  ) );

			// �R�l�N�V�����擾
			PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
			con	 = locator.getDataSource(  ).getConnection(  );

			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, 
												 ResultSet.CONCUR_UPDATABLE);

			ResultSet rs = stmt.executeQuery(sql.toString());

			int i_row=0;
			
			rs.last();
			
			int i_maxlength=rs.getRow();
			
			rs.beforeFirst();
			

			while ( rs.next(  ) ) {
				i_row++;
				
				csvData = new PEC_DownloadCsvGyomuBean();
				csvData.setSindansya(rs.getString("SINDANSYA"));
				csvData.setSyoku_code(rs.getString("SYOKU_CODE"));
				csvData.setSenmon_code(rs.getString("SENMON_CODE"));
				csvData.setLevel_code(rs.getString("LEVEL_CODE"));
				csvData.setJissi_kaisu(rs.getString("JISSI_KAISU"));
				csvData.setTasseido_kubun_code(rs.getString("TASSEIDO_KUBUN_CODE"));
				csvData.setTasseido_kubun(rs.getString("TASSEIDO_KUBUN"));
				csvData.setTasseido_sihyo_code(rs.getString("TASSEIDO_SIHYO_CODE"));
				csvData.setTasseido_sihyo(rs.getString("TASSEIDO_SIHYO"));
				csvData.setKubun(rs.getString("KUBUN"));
				csvData.setSentaku_flg(rs.getString("SENTAKU_FLG"));


				v_result.add( csvData );
			}

			/* �f�o�b�O���O */
			Log.debug("getCsvGyomu:i_row=" +  new Integer(i_row).toString() );

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return v_result;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
			throw e;
		} finally {
			if ( stmt != null ) {
				try {
					stmt.close(  );
				} catch (Exception e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch (Exception e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * �A�Z�X�����g�����擾���܂��B 
	 * �߂�l��PEC_DownloadCsvGyomuBean��Vector�Ɋi�[�������̂ł��B
	 *
	 * @param loginuser ���O�C�����[�U���
	 * @param busyo_cd �i�肱�ݏ����ƂȂ镔���R�[�h�@NULL�̏ꍇ�͎w��Ȃ�
	 * @param taisyokikan�@�i�肱�ݏ����ƂȂ�A�Z�X�����g�f�f�̎��{�N�����@Null�̏ꍇ�͎w�薳��
	 * @return �A�Z�X�����g���̈ꗗ
	 * @exception NamingException ���O�����Ɏ��s�����ꍇ
	 * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public Vector getCsvSkill( 
		PEY_PersonalBean loginuser,
		String busyo_cd,
		String taisyokikan 
		)
		throws NamingException, RemoteException {

		Connection con		= null;
		PreparedStatement ps  = null;
		Statement stmt =null;
				
		PEC_DownloadCsvSkillBean csvData=null;

		Vector v_result= new Vector();
		
		try {
			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );


			String busyo_sql="";
			String taisyokikan_sql="";
			
			if(busyo_cd !=null && !"".equalsIgnoreCase(busyo_cd)){
				busyo_sql= " where SYOZOKU_CODE_4 = '" + busyo_cd +"' ";
			}
			if(taisyokikan !=null && !"".equalsIgnoreCase(taisyokikan)){
				taisyokikan_sql= " and P21.JISSI_NENGAPPI >= '" + taisyokikan + "' ";
			}

			StringBuffer sql = new StringBuffer();
			
			sql.append("SELECT ")
			.append("P23.SINDANSYA,")
			.append("P23.SYOKU_CODE,")
			.append("P23.SENMON_CODE,")
			.append("P23.LEVEL_CODE,")
			.append("P23.JISSI_KAISU,")
			.append("P23.SKILL_CODE,")
			.append("P03.SKILL_NAME,")
			.append("P23.KUBUN,")
			.append("P23.SCORE ")
			.append("FROM  P23_SKILL_HYOKA_TBL P23,")
			.append("P03_C_SKILL_KOMOKU_TBL P03,")
			.append("(SELECT  ")
			.append("SINDANSYA,")
			.append("SYOKU_CODE,")
			.append("SENMON_CODE,")
			.append("LEVEL_CODE,")
			.append("JISSI_KAISU,")
			.append("JISSI_NENGAPPI,")
			.append("GYOMU_KEIKEN_T_DO,")
			.append("SKILL_T_DO,")
			.append("SOUGOU_T_DO,")
			.append("CAREER_CHALLENGE_KIKAN_MEI,")
			.append("SYOKU_NAME,")
			.append("SENMON_NAME,")
			.append("LEVEL_NAME,")
			.append("SIMEI_NO,")
			.append("KANJI_SIMEI,")
			.append("KANA_SIMEI,")
			.append("SOSIKI_CODE,")
			.append("BUSYO_RYAKUSYO_MEI,")
			.append("YAKUSYOKU,")
			.append("SEINENGAPPI,")
			.append("HITACHI_SAS_NYUSYA_NENGETU,")
			.append("SYOZOKU_CODE_1,")
			.append("SYOZOKU_CODE_2,")
			.append("SYOZOKU_CODE_3,")
			.append("SYOZOKU_CODE_4,")
			.append("SYOZOKU_CODE_5,")
			.append("SYOZOKU_CODE_6,")
			.append("SYOZOKU_CODE_7,")
			.append("SYOZOKU_CODE_8,")
			.append("SYOZOKU_CODE_9 ")
			.append("FROM P21_ASSESSMENT_SINDAN_TBL P21,")
			.append("(")
			.append("SELECT ")
			.append("SIMEI_NO,")
			.append("KANJI_SIMEI,")
			.append("KANA_SIMEI,")
			.append("SOSIKI_CODE,")
			.append("BUSYO_RYAKUSYO_MEI,")
			.append("YAKUSYOKU,")
			.append("SEINENGAPPI,")
//			.append("HITACHI_SAS_NYUSYA_NENGETU,") //2005/11/10_LYCE_R_THANHLVT
			.append("NYUSYA_NENGETU as HITACHI_SAS_NYUSYA_NENGETU,") //2005/11/10_LYCE_A_THANHLVT
			.append("SYOZOKU_CODE_1,")
			.append("SYOZOKU_CODE_2,")
			.append("SYOZOKU_CODE_3,")
			.append("SYOZOKU_CODE_4,")
			.append("SYOZOKU_CODE_5,")
			.append("SYOZOKU_CODE_6,")
			.append("SYOZOKU_CODE_7,")
			.append("SYOZOKU_CODE_8,")
			.append("SYOZOKU_CODE_9 ")
			.append(" FROM T01_PERSONAL_TBL ")
			.append(busyo_sql)
			.append(") T01 ")
			.append("WHERE ")
			.append("T01.SIMEI_NO=P21.SINDANSYA")
			.append(taisyokikan_sql)
			.append(") T01P21 ")
			.append("WHERE ")
			.append("T01P21.SINDANSYA=P23.SINDANSYA")
			.append(" AND ")
			.append("T01P21.SYOKU_CODE=P23.SYOKU_CODE ")
			.append(" AND ")
			.append("T01P21.SENMON_CODE=P23.SENMON_CODE")
			.append(" AND ")
			.append("T01P21.LEVEL_CODE=P23.LEVEL_CODE")
			.append(" AND ")
			.append("T01P21.JISSI_KAISU=P23.JISSI_KAISU")
			.append(" AND ")
			.append("P23.SYOKU_CODE=P03.SYOKU_CODE ")
			.append(" AND ")
			.append("P23.SENMON_CODE=P03.SENMON_CODE")
			.append(" AND ")
			.append("P23.SKILL_CODE= P03.SKILL_CODE ")
			.append("ORDER BY ")
			.append("P23.SINDANSYA,")
			.append("P23.SYOKU_CODE,")
			.append("P23.SENMON_CODE,")
			.append("P23.LEVEL_CODE,")
			.append("P23.JISSI_KAISU,")
			.append("P23.SKILL_CODE");			
			/* �f�o�b�O���O */
			Log.debug("getCsvSkill:SQL=" +  sql.toString(  ) );

			// �R�l�N�V�����擾
			PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
			con	 = locator.getDataSource(  ).getConnection(  );

			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, 
												 ResultSet.CONCUR_UPDATABLE);

			ResultSet rs = stmt.executeQuery(sql.toString());

			int i_row=0;
			
			rs.last();
			
			int i_maxlength=rs.getRow();
			
			rs.beforeFirst();
			

			while ( rs.next(  ) ) {
				i_row++;
				
				csvData = new PEC_DownloadCsvSkillBean();
				csvData.setSindansya(rs.getString("SINDANSYA"));
				csvData.setSyoku_code(rs.getString("SYOKU_CODE"));
				csvData.setSenmon_code(rs.getString("SENMON_CODE"));
				csvData.setLevel_code(rs.getString("LEVEL_CODE"));
				csvData.setJissi_kaisu(rs.getString("JISSI_KAISU"));
				csvData.setSkill_code(rs.getString("SKILL_CODE"));
				csvData.setSkill_name(rs.getString("SKILL_NAME"));
				csvData.setKubun(rs.getString("KUBUN"));
				csvData.setScore(rs.getString("SCORE"));


				v_result.add( csvData );
			}

			/* �f�o�b�O���O */
			Log.debug("getCsvSkill:i_row=" +  new Integer(i_row).toString() );

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return v_result;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
			throw e;
		} finally {
			if ( stmt != null ) {
				try {
					stmt.close(  );
				} catch (Exception e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch (Exception e ) {
					// �������Ȃ�
				}
			}
		}
	}

}
