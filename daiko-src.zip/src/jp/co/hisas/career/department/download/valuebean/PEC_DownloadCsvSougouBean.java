/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�g�D�n �_�E�����[�h�@�\ �����p�̃f�[�^�i�[�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/08/11  03-00  ���H�� �G�F    �V�K�쐬
 */
package jp.co.hisas.career.department.download.valuebean;

import java.io.*;
/**
 * @author h-nerome
 *
 * ���̐������ꂽ�R�����g�̑}�������e���v���[�g��ύX���邽��
 * �E�B���h�E > �ݒ� > Java > �R�[�h���� > �R�[�h�ƃR�����g
 */
public class PEC_DownloadCsvSougouBean extends PEC_ValueBean implements Serializable {

	/** ����NO  �f�f�� */
	private String sindansya="";

	/** �����i�����j */
	private String kanji_simei="";

	/** �����i�J�i�j */
	private String kana_simei="";

	/** �g�D�R�[�h */
	private String sosiki_code="";

	/** �������̖� */
	private String busyo_ryakusyo_mei="";

	/** �����R�[�h�P */
	private String syozoku_code_1="";

	/** �����R�[�h�Q */
	private String syozoku_code_2="";

	/** �����R�[�h�R */
	private String syozoku_code_3="";

	/** �����R�[�h�S */
	private String syozoku_code_4="";

	/** �����R�[�h�T */
	private String syozoku_code_5="";

	/** �����R�[�h�U */
	private String syozoku_code_6="";

	/** �����R�[�h�V */
	private String syozoku_code_7="";

	/** �����R�[�h�W */
	private String syozoku_code_8="";

	/** �����R�[�h�X */
	private String syozoku_code_9="";

	/** �g�D�� */
	private String sosiki_mei="";

	/** ��E */
	private String yakusyoku="";

	/** �N�� */
	private String seinengappi="";

	/** SAS���ДN�� */
	private String hitachi_sas_nyusya_nengetu="";

	/** �E��R�[�h */
	private String syoku_code="";

	/** �E�� */
	private String syoku_name="";

	/** ��啪��R�[�h */
	private String senmon_code="";

	/** ��啪�� */
	private String senmon_name="";

	/** ���x���R�[�h */
	private String level_code="";

	/** ���x�� */
	private String level_name="";

	/** ���{�� */
	private String jissi_kaisu="";

	/** �Ɩ��o���B���x�i�{�l�j */
	private String gyomu_keiken_t_do="";

	/** �X�L���B���x�i�{�l�j */
	private String skill_t_do="";

	/** �����B���x�i�{�l�j */
	private String sougou_t_do="";

	/** �Ɩ��o���B���x�i�]���ҁj */
	private String gyomu_keiken_t_do_hyo="";

	/** �X�L���B���x�i�]���ҁj */
	private String skill_t_do_hyo="";

	/** �����B���x�i�]���ҁj */
	private String sougou_t_do_hyo="";

	/** ���{�N�����i�{�l�j */
	private String jissi_nengappi="";

	/** �L�����A�`�������W���� */
	private String career_challenge_kikan_mei="";



	/**
	 * �f�t�H���g�̃R���X�g���N�^�ł��B
	 */
	public PEC_DownloadCsvSougouBean() {
		super();
	}
    

	/**
	 * @return
	 */
	public String getBusyo_ryakusyo_mei() {
		return busyo_ryakusyo_mei;
	}

	/**
	 * @return
	 */
	public String getCareer_challenge_kikan_mei() {
		return career_challenge_kikan_mei;
	}

	/**
	 * @return
	 */
	public String getGyomu_keiken_t_do() {
		return gyomu_keiken_t_do;
	}

	/**
	 * @return
	 */
	public String getGyomu_keiken_t_do_hyo() {
		return gyomu_keiken_t_do_hyo;
	}

	/**
	 * @return
	 */
	public String getHitachi_sas_nyusya_nengetu() {
		return hitachi_sas_nyusya_nengetu;
	}

	/**
	 * @return
	 */
	public String getJissi_kaisu() {
		return jissi_kaisu;
	}

	/**
	 * @return
	 */
	public String getJissi_nengappi() {
		return jissi_nengappi;
	}

	/**
	 * @return
	 */
	public String getKana_simei() {
		return kana_simei;
	}

	/**
	 * @return
	 */
	public String getKanji_simei() {
		return kanji_simei;
	}

	/**
	 * @return
	 */
	public String getLevel_code() {
		return level_code;
	}

	/**
	 * @return
	 */
	public String getLevel_name() {
		return level_name;
	}

	/**
	 * @return
	 */
	public String getSeinengappi() {
		return seinengappi;
	}

	/**
	 * @return
	 */
	public String getSenmon_code() {
		return senmon_code;
	}

	/**
	 * @return
	 */
	public String getSenmon_name() {
		return senmon_name;
	}

	/**
	 * @return
	 */
	public String getSindansya() {
		return sindansya;
	}

	/**
	 * @return
	 */
	public String getSkill_t_do() {
		return skill_t_do;
	}

	/**
	 * @return
	 */
	public String getSkill_t_do_hyo() {
		return skill_t_do_hyo;
	}

	/**
	 * @return
	 */
	public String getSosiki_code() {
		return sosiki_code;
	}

	/**
	 * @return
	 */
	public String getSosiki_mei() {
		return sosiki_mei;
	}

	/**
	 * @return
	 */
	public String getSougou_t_do() {
		return sougou_t_do;
	}

	/**
	 * @return
	 */
	public String getSougou_t_do_hyo() {
		return sougou_t_do_hyo;
	}

	/**
	 * @return
	 */
	public String getSyoku_code() {
		return syoku_code;
	}

	/**
	 * @return
	 */
	public String getSyoku_name() {
		return syoku_name;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_1() {
		return syozoku_code_1;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_2() {
		return syozoku_code_2;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_3() {
		return syozoku_code_3;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_4() {
		return syozoku_code_4;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_5() {
		return syozoku_code_5;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_6() {
		return syozoku_code_6;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_7() {
		return syozoku_code_7;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_8() {
		return syozoku_code_8;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_9() {
		return syozoku_code_9;
	}

	/**
	 * @return
	 */
	public String getYakusyoku() {
		return yakusyoku;
	}

	/**
	 * @param string
	 */
	public void setBusyo_ryakusyo_mei(String string) {
		busyo_ryakusyo_mei = string;
	}

	/**
	 * @param string
	 */
	public void setCareer_challenge_kikan_mei(String string) {
		career_challenge_kikan_mei = string;
	}

	/**
	 * @param string
	 */
	public void setGyomu_keiken_t_do(String string) {
		gyomu_keiken_t_do = string;
	}

	/**
	 * @param string
	 */
	public void setGyomu_keiken_t_do_hyo(String string) {
		gyomu_keiken_t_do_hyo = string;
	}

	/**
	 * @param string
	 */
	public void setHitachi_sas_nyusya_nengetu(String string) {
		hitachi_sas_nyusya_nengetu = string;
	}

	/**
	 * @param string
	 */
	public void setJissi_kaisu(String string) {
		jissi_kaisu = string;
	}

	/**
	 * @param string
	 */
	public void setJissi_nengappi(String string) {
		jissi_nengappi = string;
	}

	/**
	 * @param string
	 */
	public void setKana_simei(String string) {
		kana_simei = string;
	}

	/**
	 * @param string
	 */
	public void setKanji_simei(String string) {
		kanji_simei = string;
	}

	/**
	 * @param string
	 */
	public void setLevel_code(String string) {
		level_code = string;
	}

	/**
	 * @param string
	 */
	public void setLevel_name(String string) {
		level_name = string;
	}

	/**
	 * @param string
	 */
	public void setSeinengappi(String string) {
		seinengappi = string;
	}

	/**
	 * @param string
	 */
	public void setSenmon_code(String string) {
		senmon_code = string;
	}

	/**
	 * @param string
	 */
	public void setSenmon_name(String string) {
		senmon_name = string;
	}

	/**
	 * @param string
	 */
	public void setSindansya(String string) {
		sindansya = string;
	}

	/**
	 * @param string
	 */
	public void setSkill_t_do(String string) {
		skill_t_do = string;
	}

	/**
	 * @param string
	 */
	public void setSkill_t_do_hyo(String string) {
		skill_t_do_hyo = string;
	}

	/**
	 * @param string
	 */
	public void setSosiki_code(String string) {
		sosiki_code = string;
	}

	/**
	 * @param string
	 */
	public void setSosiki_mei(String string) {
		sosiki_mei = string;
	}

	/**
	 * @param string
	 */
	public void setSougou_t_do(String string) {
		sougou_t_do = string;
	}

	/**
	 * @param string
	 */
	public void setSougou_t_do_hyo(String string) {
		sougou_t_do_hyo = string;
	}

	/**
	 * @param string
	 */
	public void setSyoku_code(String string) {
		syoku_code = string;
	}

	/**
	 * @param string
	 */
	public void setSyoku_name(String string) {
		syoku_name = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_1(String string) {
		syozoku_code_1 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_2(String string) {
		syozoku_code_2 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_3(String string) {
		syozoku_code_3 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_4(String string) {
		syozoku_code_4 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_5(String string) {
		syozoku_code_5 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_6(String string) {
		syozoku_code_6 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_7(String string) {
		syozoku_code_7 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_8(String string) {
		syozoku_code_8 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_9(String string) {
		syozoku_code_9 = string;
	}

	/**
	 * @param string
	 */
	public void setYakusyoku(String string) {
		yakusyoku = string;
	}

}
