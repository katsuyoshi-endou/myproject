/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 * 
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/12/28  01.00       ��� �ӎ�    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.*;
import javax.ejb.*;
import javax.naming.*;
import javax.servlet.http.*;
import javax.mail.internet.*;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.learning.base.ejb.*;

/**
 *<PRE>
 *
 * �N���X���F
 *   PCY321_ClassCyouseiIkkatuUketukeKanryoServlet �N���X
 *
 * �@�\�����F
 *   �N���X�����ꊇ��t�������s���܂��B
 *
 *</PRE>
 */
public class PCY321_ClassCyouseiIkkatuUketukeKanryoServlet extends PCY010_ControllerServlet {

    protected String execute(HttpServletRequest request, HttpServletResponse response, PCY_PersonalBean loginuser)
        throws NamingException, CreateException, RemoteException, PCY_WarningException {
        /* ���\�b�h�g���[�X */
        Log.method( loginuser.getSimeiNo(), "IN", "" );
        
        String count = request.getParameter( "mousikomisya" );
        int length = 0;

		if(count != null){
			length = Integer.valueOf(count).intValue();
		}

        if ( count != null ) {
			PCY_MousikomiJyokyoBean[]
                taisyosyaBeans = new PCY_MousikomiJyokyoBean[length];
            for ( int i = 0; i < length; i++ ) {
                taisyosyaBeans[i] = new PCY_MousikomiJyokyoBean();
                String index = Integer.toString(i);

                PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean();
                mousikomiBean.setKamokuCode(request.getParameter( "kamoku_code_" + index ));
                mousikomiBean.setClassCode(request.getParameter( "class_code_" + index ));
                mousikomiBean.getClassBean().setKousinbi(request.getParameter( "class_kousinbi_" + index ));
                mousikomiBean.getClassBean().setKousinjikoku(request.getParameter( "class_kousinjikoku_" + index ));
                mousikomiBean.setSimeiNo(request.getParameter( "simei_no_" + index ));
                mousikomiBean.setKousinbi( request.getParameter( "kousinbi_" + index ) );
                mousikomiBean.setKousinjikoku( request.getParameter( "kousinjikoku_" + index ) );
                mousikomiBean.setStatus("1");
                mousikomiBean.setUketsukeJyotai("2");

                taisyosyaBeans[i]= mousikomiBean;
            }

			PCY_ServiceLocator locator      = PCY_ServiceLocator.getInstance(  );
			PCY_MousikomiJyokyoEJBHome home = ( PCY_MousikomiJyokyoEJBHome )locator.getServiceLocation( "PCY_MousikomiJyokyoEJB",
					PCY_MousikomiJyokyoEJBHome.class );
			PCY_MousikomiJyokyoEJB ejb = home.create(  );

			Log.transaction( loginuser.getSimeiNo(  ), true, "" );
			int ret = ejb.doUpdateStatusAndUketukeIkkatu(taisyosyaBeans,loginuser);
			Log.transaction( loginuser.getSimeiNo(  ), false, "" );

			/* �N���X�̌���*/
			PCY_ClassEJBHome class_home = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
					PCY_ClassEJBHome.class );
			PCY_ClassEJB class_ejb = class_home.create(  );
			
			
			PCY_ClassBean[] kensaku_classBeans = new PCY_ClassBean[taisyosyaBeans.length];
			for(int i = 0; i < taisyosyaBeans.length; i++){
				PCY_ClassBean kensaku_classBean = new PCY_ClassBean();
				kensaku_classBean.setClassCode(taisyosyaBeans[i].getClassCode());
				kensaku_classBean.getKamokuBean().setKamokuCode(taisyosyaBeans[i].getKamokuCode());
				kensaku_classBeans[i] = kensaku_classBean;
			}
						
			PCY_ClassBean[] classBeans = class_ejb.doSelectByPrimaryKey(kensaku_classBeans,loginuser);
		
			/* Mail���� */
								String[] simei_no = new String[taisyosyaBeans.length];
			for ( int i = 0; i < simei_no.length; i++ ) {
				simei_no[i] = taisyosyaBeans[i].getSimeiNo(  );
			}
	
			PCY_PersonalEJBHome personalHome = ( PCY_PersonalEJBHome )locator.getServiceLocation( "PCY_PersonalEJB",
					PCY_PersonalEJBHome.class );
			PCY_PersonalEJB personalEjb = personalHome.create(  );    
			PCY_PersonalBean[] personalBeans = personalEjb.getPersonalInfo( simei_no, loginuser );

			int errorCount = 0;
			for(int t = 0; t < classBeans.length; t++){
				
	            if ( "1".equals( classBeans[t].getAnnaiMailKubun(  ) ) 
	                && "0".equals( classBeans[t].getKisyoIkkatsuFlg(  ) ) ) {
					/* �N���X�}�X�^�̈ē����[���敪���f�v�f�̏ꍇ�A���[���𑗐M���� */									
					try {
						/* ��t�����̏ꍇ */
						PCY_PersonalBean[] send_personalBeans = new PCY_PersonalBean[1];
						send_personalBeans[0] = personalBeans[t];
						PCY_KensyuMailSender.sendKensyuKanrisyaUketukeKanryo( send_personalBeans, classBeans[t],
							loginuser );
					} catch ( AddressException e ) {
						errorCount = 1;
					} catch ( Exception e ) {
						errorCount = 1;
					}
				}
			}
			if( errorCount != 0){
				request.setAttribute( "warningID", "WCC110" );
				throw new PCY_WarningException();
			}

        }

        /* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
        Log.performance( loginuser.getSimeiNo(), false, "" );
        Log.method( loginuser.getSimeiNo(), "OUT", "" );

        return getForwardPath();
    }

}
