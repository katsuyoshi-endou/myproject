/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/02/16  01.00       ���� ��F    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.valuebean;

import java.io.Serializable;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_KamokuBeanForDL �N���X
 *
 * �@�\�����F
 *   �_�E�����[�h�@�\�p�ɉȖڏ�����ێ�����ValueBean�ł��B
 *
 *</PRE>
 */
public class PCY_KamokuBeanForDL implements Serializable {
	private String kamokuCode   		= null;
	private String kamokuMei1   		= null;
	private String kamokuMei2   		= null;
	private String kamokuMei3   		= null;
	private String kamokuMei4   		= null;
    private String kamokuNaiyou 		= null;
	private String categoryCode1		= null;
	private String categoryCode2		= null;
	private String categoryCode3		= null;
	private String categoryCode4		= null;
	private String categoryCode5		= null;
	private String kamokuGroup			= null;
	private String kamokuSyuryoFlg		= null;
	private String kanrimotoCode		= null;
	private String yobi1				= null;
	private String yobi2				= null;
    private String jyukouJyoken 		= null;

    public PCY_KamokuBeanForDL( PCY_KamokuBean kamokuBean ) {
		kamokuCode       = kamokuBean.getKamokuCode(  );
		kamokuMei1       = kamokuBean.getKamokuMei1(  );
		kamokuMei2       = kamokuBean.getKamokuMei2(  );
		kamokuMei3       = kamokuBean.getKamokuMei3(  );
		kamokuMei4       = kamokuBean.getKamokuMei4(  );
        kamokuNaiyou     = kamokuBean.getKamokuNaiyou(  );
		categoryCode1    = kamokuBean.getCategoryCode1(  );
		categoryCode2    = kamokuBean.getCategoryCode2(  );
		categoryCode3    = kamokuBean.getCategoryCode3(  );
		categoryCode4    = kamokuBean.getCategoryCode4(  );
		categoryCode5    = kamokuBean.getCategoryCode5(  );
		jyukouJyoken     = kamokuBean.getJyukouJyoken(  );
		kamokuGroup      = kamokuBean.getKamokuGroup(  );
		kamokuSyuryoFlg  = kamokuBean.getKamokuSyuryoFlg(  );
		kanrimotoCode    = kamokuBean.getKanrimotoCode(  );
		yobi1	    	 = kamokuBean.getYobi1(  );
		yobi2	    	 = kamokuBean.getYobi2(  );
		jyukouJyoken	 = kamokuBean.getJyukouJyoken(  );
    }

    /**
     * @return
     */
    public String getJyukouJyoken(  ) {
        return jyukouJyoken;
    }

    /**
     * @param string
     */
    public void setJyukouJyoken( String string ) {
        jyukouJyoken = string;
    }
	/**
	 * @return
	 */
	public String getCategoryCode1() {
		return categoryCode1;
	}

	/**
	 * @return
	 */
	public String getCategoryCode2() {
		return categoryCode2;
	}

	/**
	 * @return
	 */
	public String getCategoryCode3() {
		return categoryCode3;
	}

	/**
	 * @return
	 */
	public String getCategoryCode4() {
		return categoryCode4;
	}

	/**
	 * @return
	 */
	public String getCategoryCode5() {
		return categoryCode5;
	}

	/**
	 * @return
	 */
	public String getKamokuGroup() {
		return kamokuGroup;
	}

	/**
	 * @return
	 */
	public String getKamokuMei1(  ) {
		return kamokuMei1;
	}

	/**
	 * @return
	 */
	public String getKamokuMei2() {
		return kamokuMei2;
	}

	/**
	 * @return
	 */
	public String getKamokuMei3() {
		return kamokuMei3;
	}

	/**
	 * @return
	 */
	public String getKamokuMei4() {
		return kamokuMei4;
	}

	/**
	 * @return
	 */
	public String getKamokuNaiyou(  ) {
		return kamokuNaiyou;
	}

	/**
	 * @return
	 */
	public String getKamokuCode(  ){
		return kamokuCode;
	}

	/**
	 * @return
	 */
	public String getKamokuSyuryoFlg() {
		return kamokuSyuryoFlg;
	}

	/**
	 * @return
	 */
	public String getKanrimotoCode() {
		return kanrimotoCode;
	}

	/**
	 * @return
	 */
	public String getYobi1() {
		return yobi1;
	}

	/**
	 * @return
	 */
	public String getYobi2() {
		return yobi2;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode1(String string) {
		categoryCode1 = string;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode2(String string) {
		categoryCode2 = string;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode3(String string) {
		categoryCode3 = string;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode4(String string) {
		categoryCode4 = string;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode5(String string) {
		categoryCode5 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuCode(String string) {
		kamokuCode = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuGroup(String string) {
		kamokuGroup = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuMei1(String string) {
		kamokuMei1 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuMei2(String string) {
		kamokuMei2 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuMei3(String string) {
		kamokuMei3 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuMei4(String string) {
		kamokuMei4 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuNaiyou(String string) {
		kamokuNaiyou = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuSyuryoFlg(String string) {
		kamokuSyuryoFlg = string;
	}

	/**
	 * @param string
	 */
	public void setKanrimotoCode(String string) {
		kanrimotoCode = string;
	}

	/**
	 * @param string
	 */
	public void setYobi1(String string) {
		yobi1 = string;
	}

	/**
	 * @param string
	 */
	public void setYobi2(String string) {
		yobi2 = string;
	}

}
