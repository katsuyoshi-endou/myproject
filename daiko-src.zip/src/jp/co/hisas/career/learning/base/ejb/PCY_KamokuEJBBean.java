/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/01/26  01.00       ���� �a��    �V�K�쐬
 *   2004/06/15              ���� ���V   �ȖڃO���[�vNULL�Ή�
 *   2004/06/15              ���� ���V   doSelect �Ȗږ��P��O����v�Ƃ���
 *   2004/06/20              ���� ���V   doSelect���\�b�h�@���������ɍ폜�t���O���ςɕύX
 *   2004/06/20              ���� ���V   doInsert���\�b�h�@SQLException�������@EJBException���X���[����悤�ɏC��
 *   2004/06/23              ���� ���V   �ȖڃR�[�h�d���o�^�@�x����ʑΉ�
 *   2004/06/24              ���� ���V   Cosminexus�ŃG���[���o�邽�߁ATypes��java.sql.Types�ɕύX
 *   2004/06/24              ���� ���V   �P���J����NULL�ɑΉ�
 *   2004/06/27              ���� ���V   �N���X���Ȃ��Ȗڍ폜�ɑΉ�
 *   2004/07/01              ���� ���V   doCount���\�b�h�ǉ�
 *   2004/07/02              ���� ���V   �Ȗڍ폜���C��
 *   2004/07/13              ���� ���V   �J���L�������}�b�v�폜�s�ǂ��C��
 *   2004/08/12              ���� ���V   doSelectByKanrenKyoiku���\�b�h�V�K�쐬�i�Г�Career@Net�Ή��j
 */
package jp.co.hisas.career.learning.base.ejb;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.rmi.*;

import java.sql.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_KamokuEJBBean�N���X
 *
 * �@�\�����F
 *   �Ȗڃ}�X�^�ւ̑�����s���܂��B
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PCY_KamokuEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PCY_KamokuEJBBean implements SessionBean {
    private SessionContext context = null;

	/* For SAS-S */
    /**
     * �֘A����������ɉȖڏ��̔z����擾���܂��B
     * @param kanrenBean �����L�[�ƂȂ�֘A�Ȗڏ��
     * @param loginuser
     * @return
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_KamokuBean[] doSelectByKanrenKyoiku( PCY_KanrenKyoikuKamokuBean kanrenBean,
        PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            HashMap map = new HashMap(  );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "SELECT " );
            sql.append( PCY_KamokuBean.getColumns( "KAMOKU" ) + "," );
            sql.append( PCY_KanrenKyoikuKamokuBean.getColumns( "KANREN" ) );
            sql.append( " FROM " );
            sql.append( HcdbDef.L01_TBL + " KAMOKU, " );
            sql.append( HcdbDef.p_kanren_kyoikuTbl + " KANREN " );
            sql.append( " WHERE KAMOKU.KAMOKU_CODE=KANREN.KAMOKU_CODE" );
            sql.append( " AND   KAMOKU.SAKUJYO_FLG='0' " );

            if ( kanrenBean.getKamokuCode(  ) != null ) {
                sql.append( " AND   KAMOKU.KAMOKU_CODE=? " );
            }

            if ( kanrenBean.getKamokuGroupCode(  ) != null ) {
                sql.append( " AND   KAMOKU.KAMOKU_GROUP=? " );
            }

            if ( kanrenBean.getSyokusyuCode(  ) != null ) {
                sql.append( " AND   KANREN.SYOKU_CODE=? " );
            }

            if ( kanrenBean.getSenmonCode(  ) != null ) {
                sql.append( " AND   KANREN.SENMON_CODE=? " );
            }

            if ( kanrenBean.getLevelCode(  ) != null ) {
                sql.append( " AND   KANREN.LEVEL_CODE=? " );
            }

            if ( kanrenBean.getSkillCode(  ) != null ) {
                sql.append( " AND   KANREN.SKILL_CODE=? " );
            }

            if ( kanrenBean.getKyoikuKubunCode(  ) != null ) {
                sql.append( " AND   KANREN.KYOIKU_KUBUN_CODE=? " );
            }

            ps = con.prepareStatement( sql.toString(  ) );

            int count = 1;

            if ( kanrenBean.getKamokuCode(  ) != null ) {
                ps.setString( count++, kanrenBean.getKamokuCode(  ) );
            }

            if ( kanrenBean.getKamokuGroupCode(  ) != null ) {
                ps.setString( count++, kanrenBean.getKamokuGroupCode(  ) );
            }

            if ( kanrenBean.getSyokusyuCode(  ) != null ) {
                ps.setString( count++, kanrenBean.getSyokusyuCode(  ) );
            }

            if ( kanrenBean.getSenmonCode(  ) != null ) {
                ps.setString( count++, kanrenBean.getSenmonCode(  ) );
            }

            if ( kanrenBean.getLevelCode(  ) != null ) {
                ps.setString( count++, kanrenBean.getLevelCode(  ) );
            }

            if ( kanrenBean.getSkillCode(  ) != null ) {
                ps.setString( count++, kanrenBean.getSkillCode(  ) );
            }

            if ( kanrenBean.getKyoikuKubunCode(  ) != null ) {
                ps.setString( count++, kanrenBean.getKyoikuKubunCode(  ) );
            }

            ResultSet rs = ps.executeQuery(  );

            while ( rs.next(  ) ) {
                PCY_KamokuBean kamokuBean = new PCY_KamokuBean( rs, "KAMOKU" );

                if ( map.containsKey( kamokuBean.getKamokuCode(  ) ) ) {
                    PCY_KamokuBean tmpKamokuBean = ( PCY_KamokuBean )map.get( kamokuBean
                            .getKamokuCode(  ) );
                    PCY_KanrenKyoikuKamokuBean[] kanren = new PCY_KanrenKyoikuKamokuBean[tmpKamokuBean
                        .getKanrenKamokuBeans(  ).length + 1];
                    kanren[kanren.length - 1] = new PCY_KanrenKyoikuKamokuBean( rs, "KANREN" );
                    tmpKamokuBean.setKanrenKamokuBeans( kanren );
                } else {
                    kamokuBean.setKanrenKamokuBeans( new PCY_KanrenKyoikuKamokuBean[] { new PCY_KanrenKyoikuKamokuBean( 
                                rs, "KANREN" ) } );
                }

                map.put( kamokuBean.getKamokuCode(  ), kamokuBean );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ( PCY_KamokuBean[] )map.values(  ).toArray( new PCY_KamokuBean[0] );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }
	/* For SAS-E */
    /**
     * �Ȗڃ}�X�^���v���C�}���[�L�[�Ō������Č��ʂ�Ԃ��܂��B
     * �������ʂ����������ꍇ�� null ��Ԃ��܂��B
     *
     * @param kamokuBean ��������
     * @param lock true�̏ꍇ���b�N����Afalse�̏ꍇ���b�N�Ȃ�
     * @param loginuser ���O�C�����[�U
     * @return ��������
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_KamokuBean doSelectByPrimaryKey( PCY_KamokuBean kamokuBean, boolean lock,
        PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            PCY_KamokuBean ret = null;
            String sql         = "SELECT * FROM " + HcdbDef.L01_TBL
                + " WHERE KAMOKU_CODE=? AND SAKUJYO_FLG='0'"
                + PCY_DBUtils.getInstance(  ).getLock( lock );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �������s
            ps = con.prepareStatement( sql );
            ps.setString( 1, kamokuBean.getKamokuCode(  ) );

            ResultSet rs = ps.executeQuery(  );

            if ( rs.next(  ) ) {
                ret = new PCY_KamokuBean( rs, null );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ret;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * <pre>
     * �Ȗڃ}�X�^���������Č��ʂ� PCY_KamokuBean �̔z��Ƃ��ĕԂ��܂��B
     * �������ʂ��Ȃ������ꍇ�́A��̔z���Ԃ��܂��B
     * �ȉ��̍��ڂ����������Ƃ��Ďg�p�ł��܂��B
     * �E�Ȗږ��P�i�O����v�j
     * �E�ȖڃR�[�h
     * �E�o�[�W�����Ǘ�
     * �E�ȖڃO���[�v
     * �E�J�e�S���R�[�h�P
     * �E�J�e�S���R�[�h�Q
     * �E�J�e�S���R�[�h�R
     * �E�J�e�S���R�[�h�S
     * </pre>
     *
     * @param kamokuBean ��������
     * @param loginuser ���O�C�����[�U
     * @return ��������
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_KamokuBean[] doSelect( PCY_KamokuBean kamokuBean, PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            Collection ret   = new ArrayList(  );
            StringBuffer sql = new StringBuffer( "SELECT * FROM " + HcdbDef.L01_TBL );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // ���������̍쐬
            Map conditions     = kamokuBean.extractConditions(  );
            StringBuffer where = new StringBuffer(  );

            for ( Iterator ite = conditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                Object column = ite.next(  );

                if ( column.equals( "KAMOKU_MEI1" ) ) {
                    //where.append( " AND " + column + " LIKE ?" );
                	where.append( " AND UPPER(" + column + ") LIKE UPPER(?)" ); //CHG#0301L-0103

                    /* �Ȗږ��͑O����v�̂��ߒl�Ɂ���t�^ */
                    conditions.put( column, ( String )conditions.get( column ) + "%" );
                } else {
                    where.append( " AND " + column + "=?" );
                }
            }

            /* �폜�t���O�����������Ƃ��Đݒ肷�� */
            if ( kamokuBean.getSakujyoFlg(  ) == null ) {
                where.append( " AND SAKUJYO_FLG='0'" );
            } else if ( !"".equals( kamokuBean.getSakujyoFlg(  ) ) ) {
                where.append( " AND SAKUJYO_FLG=?" );
            }

            sql.append( where.toString(  ).replaceFirst( "AND", "WHERE" ) );

            // �Ȗڃ}�X�^�\�[�g���̍쐬
            sql.append( " ORDER BY KAMOKU_CODE ASC" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            /* �f�o�b�O���O�o�� */
            Log.debug( sql.toString(  ) );

            // �������s
            ps = con.prepareStatement( sql.toString(  ) );

            int count = 1;

            for ( Iterator ite = conditions.keySet(  ).iterator(  ); ite.hasNext(  ); count++ ) {
                ps.setObject( count, conditions.get( ite.next(  ) ) );
            }

            /* �폜�t���O�����������Ƃ��Đݒ肷�� */
            if ( ( kamokuBean.getSakujyoFlg(  ) != null )
                && !"".equals( kamokuBean.getSakujyoFlg(  ) ) ) {
                ps.setString( count, kamokuBean.getSakujyoFlg(  ) );
            }

            ResultSet rs = ps.executeQuery(  );

            while ( rs.next(  ) ) {
                ret.add( new PCY_KamokuBean( rs, null ) );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ( PCY_KamokuBean[] )ret.toArray( new PCY_KamokuBean[0] );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �f�[�^�x�[�X�ɓo�^�ς݂̐���Ԃ��܂��B
     *
     * @param kamokuCodes
     * @param loginuser
     * @return
    * @ejb.interface-method
    * @ejb.transaction type="Required"
     */
    public int doCount( String[] kamokuCodes, PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            StringBuffer checkSql = new StringBuffer(  );
            checkSql.append( "SELECT COUNT(1) FROM " );
            checkSql.append( HcdbDef.L01_TBL );
            checkSql.append( " WHERE KAMOKU_CODE IN (" );

            String kamoku_codes_str = "";

            for ( int i = 0; i < kamokuCodes.length; i++ ) {
                kamoku_codes_str += ( ", '" + kamokuCodes[i] + "'" );
            }

            checkSql.append( kamoku_codes_str.replaceFirst( ",", "" ) );
            checkSql.append( ")" );

            //�f�o�b�O���O���o��
            Log.debug( checkSql.toString(  ) );

            ps = con.prepareStatement( checkSql.toString(  ) );

            ResultSet countCheck = ps.executeQuery(  );

            countCheck.next(  );

            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return Integer.parseInt( countCheck.getString( 1 ) );
        } catch ( NamingException e ) {
            throw new EJBException( e );
        } catch ( SQLException e ) {
            throw new EJBException( e );
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �Ȗڃ}�X�^���쐬���܂��B
     *
     * @param kamokuBeans �쐬���e
     * @param loginuser ���O�C�����[�U
     * @return �쐬����
     * @throws PCY_WarningException �C���T�[�g�� SQLException �����������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doInsert( PCY_KamokuBean[] kamokuBeans, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            String[] kamokuCodes = new String[kamokuBeans.length];

            for ( int i = 0; i < kamokuCodes.length; i++ ) {
                kamokuCodes[i] = kamokuBeans[i].getKamokuCode(  );
            }

            int countCheck = doCount( kamokuCodes, loginuser );

            /* �������ȖډȖڃR�[�h�����݂���Ȃ�Όx����ʂɑJ�ڂ��� */
            if ( countCheck != 0 ) {
                throw new PCY_WarningException( "WCC180" );
            }

            // �Ȗ�Bean���ȖڃR�[�h�Ń\�[�g
            Arrays.sort( kamokuBeans, new KamokuCodeComparator(  ) );

            // SQL�쐬
            StringBuffer sql = new StringBuffer(  );
            sql.append( "INSERT INTO " );
            sql.append( HcdbDef.L01_TBL );
            sql.append( " (" );
            sql.append( "    KAMOKU_CODE," );
            sql.append( "    KAMOKU_MEI1," );
            sql.append( "    KAMOKU_MEI2," );
            sql.append( "    KAMOKU_MEI3," );
            sql.append( "    KAMOKU_MEI4," );
            sql.append( "    VERSION_KANRI," );
            sql.append( "    KAMOKU_GROUP," );
            sql.append( "    CATEGORY_CODE1," );
            sql.append( "    CATEGORY_CODE2," );
            sql.append( "    CATEGORY_CODE3," );
            sql.append( "    CATEGORY_CODE4," );
            sql.append( "    CATEGORY_CODE5," );
            sql.append( "    KANRIMOTO_CODE," );
            sql.append( "    TANKA," );
            sql.append( "    KAMOKU_NAIYOU," );
            sql.append( "    JYUKOU_JYOKEN," );
            sql.append( "    YOBI1," );
            sql.append( "    YOBI2," );
            sql.append( "    SAKUJYO_FLG," );
            sql.append( "    TOUROKUBI," );
            sql.append( "    TOUROKUJIKOKU," );
            sql.append( "    TOUROKUSYA," );
            sql.append( "    KOUSINBI," );
            sql.append( "    KOUSINJIKOKU," );
            sql.append( "    KOUSINSYA )" );
            sql.append( "  VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?," );
            sql.append( "           ?, ?, ?, ?, ?, ?, ?, ?, ?, ?," );
            sql.append( "           ?, ?, ?, ?, ? )" );

            //�f�o�b�O���O���o��
            Log.debug( sql.toString(  ) );

            // �X�V���s
            ps = con.prepareStatement( sql.toString(  ) );

            int count = 0;

            for ( int i = 0; i < kamokuBeans.length; i++ ) {
                ps.setString( 1, kamokuBeans[i].getKamokuCode(  ) );
                ps.setString( 2, kamokuBeans[i].getKamokuMei1(  ) );
                ps.setString( 3, kamokuBeans[i].getKamokuMei2(  ) );
                ps.setString( 4, kamokuBeans[i].getKamokuMei3(  ) );
                ps.setString( 5, kamokuBeans[i].getKamokuMei4(  ) );
                ps.setString( 6, kamokuBeans[i].getVersionKanri(  ) );

                if ( ( kamokuBeans[i].getKamokuGroup(  ) == null )
                    || kamokuBeans[i].getKamokuGroup(  ).equals( "" ) ) {
                    ps.setNull( 7, java.sql.Types.CHAR );
                } else {
                    ps.setString( 7, kamokuBeans[i].getKamokuGroup(  ) );
                }

                ps.setString( 8, kamokuBeans[i].getCategoryCode1(  ) );
                ps.setString( 9, kamokuBeans[i].getCategoryCode2(  ) );
                ps.setString( 10, kamokuBeans[i].getCategoryCode3(  ) );
                ps.setString( 11, kamokuBeans[i].getCategoryCode4(  ) );
                ps.setString( 12, kamokuBeans[i].getCategoryCode5(  ) );
                ps.setString( 13, kamokuBeans[i].getKanrimotoCode(  ) );

                if ( ( kamokuBeans[i].getTanka(  ) == null )
                    || kamokuBeans[i].getTanka(  ).equals( "" ) ) {
                    ps.setNull( 14, java.sql.Types.INTEGER );
                } else {
                    ps.setInt( 14, kamokuBeans[i].getTanka(  ).intValue(  ) );
                }

                ps.setString( 15, kamokuBeans[i].getKamokuNaiyou(  ) );
                ps.setString( 16, kamokuBeans[i].getJyukouJyoken(  ) );
                ps.setString( 17, kamokuBeans[i].getYobi1(  ) );
                ps.setString( 18, kamokuBeans[i].getYobi2(  ) );
                ps.setString( 19, "0" );
                ps.setString( 20, PZZ010_CharacterUtil.GetDay(  ) );
                ps.setString( 21, PZZ010_CharacterUtil.GetTime(  ) );
                ps.setString( 22, loginuser.getSimeiNo(  ) );
                ps.setString( 23, "        " );
                ps.setString( 24, "      " );
                ps.setString( 25, "          " );
                count += ps.executeUpdate(  );

                // �֘A����Ȗڃ}�X�^�Ƀ��R�[�h�}��
                PCY_KanrenKyoikuKamokuBean[] kanrenBeans = kamokuBeans[i].getKanrenKamokuBeans(  );

                if ( ( kanrenBeans != null ) && ( kanrenBeans.length > 0 ) ) {
                    PCY_KanrenKyoikuKamokuEJBHome home = ( PCY_KanrenKyoikuKamokuEJBHome )locator
                        .getServiceLocation( "PCY_KanrenKyoikuKamokuEJB",
                            PCY_KanrenKyoikuKamokuEJBHome.class );
                    PCY_KanrenKyoikuKamokuEJB ejb = home.create(  );

                    ejb.doDeleteByKamokuCode( kamokuBeans[i].getKamokuCode(  ), loginuser );
					//�ǉ����鎞�Ɂ|�P����邩��@�{�P���Ă���
					for ( int j = 0; j < kanrenBeans.length; j++ ) {
						if( kanrenBeans[j].getLevelCode(  ) != null ) {
							kanrenBeans[j].setLevelCode( String.valueOf( Integer.parseInt( kanrenBeans[j].getLevelCode(  ) ) + 1 ));
						}
					}
                    ejb.doInsert( kanrenBeans, loginuser );
                }
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �v���C�}���[�L�[���L�[�Ƃ��ĉȖڃ}�X�^���X�V���܂��B
     *
     * @param kamokuBeans �X�V���e
     * @param loginuser ���O�C�����[�U
     * @return �X�V����
     * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdate( PCY_KamokuBean[] kamokuBeans, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �Ȗ�Bean���ȖڃR�[�h�Ń\�[�g
            Arrays.sort( kamokuBeans, new KamokuCodeComparator(  ) );

            // SQL�쐬
            StringBuffer sql = new StringBuffer(  );
            sql.append( "UPDATE " );
            sql.append( HcdbDef.L01_TBL );
            sql.append( "    SET KAMOKU_MEI1=?," );
            sql.append( "        KAMOKU_MEI2=?," );
            sql.append( "        KAMOKU_MEI3=?," );
            sql.append( "        KAMOKU_MEI4=?," );
            sql.append( "        VERSION_KANRI=?," );
            sql.append( "        KAMOKU_GROUP=?," );
            sql.append( "        CATEGORY_CODE1=?," );
            sql.append( "        CATEGORY_CODE2=?," );
            sql.append( "        CATEGORY_CODE3=?," );
            sql.append( "        CATEGORY_CODE4=?," );
            sql.append( "        CATEGORY_CODE5=?," );
            sql.append( "        KANRIMOTO_CODE=?," );
            sql.append( "        TANKA=?," );
            sql.append( "        KAMOKU_NAIYOU=?," );
            sql.append( "        JYUKOU_JYOKEN=?," );
            sql.append( "        YOBI1=?," );
            sql.append( "        YOBI2=?," );
            sql.append( "        KOUSINBI=?," );
            sql.append( "        KOUSINJIKOKU=?," );
            sql.append( "        KOUSINSYA=?" );
            sql.append( "  WHERE KAMOKU_CODE=?" );
            sql.append( "    AND SAKUJYO_FLG='0'" );
            sql.append( "    AND TOUROKUBI=?" );
            sql.append( "    AND TOUROKUJIKOKU=?" );
            sql.append( "    AND TOUROKUSYA=?" );
            sql.append( "    AND KOUSINBI=?" );
            sql.append( "    AND KOUSINJIKOKU=?" );
            sql.append( "    AND KOUSINSYA=?" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �X�V���s
            ps = con.prepareStatement( sql.toString(  ) );

            int count = 0;

            for ( int i = 0; i < kamokuBeans.length; i++ ) {
                ps.setString( 1, kamokuBeans[i].getKamokuMei1(  ) );
                ps.setString( 2, kamokuBeans[i].getKamokuMei2(  ) );
                ps.setString( 3, kamokuBeans[i].getKamokuMei3(  ) );
                ps.setString( 4, kamokuBeans[i].getKamokuMei4(  ) );
                ps.setString( 5, kamokuBeans[i].getVersionKanri(  ) );

                if ( ( kamokuBeans[i].getKamokuGroup(  ) == null )
                    || kamokuBeans[i].getKamokuGroup(  ).equals( "" ) ) {
                    ps.setNull( 6, java.sql.Types.CHAR );
                } else {
                    ps.setString( 6, kamokuBeans[i].getKamokuGroup(  ) );
                }

                ps.setString( 7, kamokuBeans[i].getCategoryCode1(  ) );
                ps.setString( 8, kamokuBeans[i].getCategoryCode2(  ) );
                ps.setString( 9, kamokuBeans[i].getCategoryCode3(  ) );
                ps.setString( 10, kamokuBeans[i].getCategoryCode4(  ) );
                ps.setString( 11, kamokuBeans[i].getCategoryCode5(  ) );
                ps.setString( 12, kamokuBeans[i].getKanrimotoCode(  ) );
                ps.setObject( 13, kamokuBeans[i].getTanka(  ) );
                ps.setString( 14, kamokuBeans[i].getKamokuNaiyou(  ) );
                ps.setString( 15, kamokuBeans[i].getJyukouJyoken(  ) );
                ps.setString( 16, kamokuBeans[i].getYobi1(  ) );
                ps.setString( 17, kamokuBeans[i].getYobi2(  ) );
                ps.setString( 18, PZZ010_CharacterUtil.GetDay(  ) );
                ps.setString( 19, PZZ010_CharacterUtil.GetTime(  ) );
                ps.setString( 20, loginuser.getSimeiNo(  ) );
                ps.setString( 21, kamokuBeans[i].getKamokuCode(  ) );
                ps.setString( 22, kamokuBeans[i].getTourokubi(  ) );
                ps.setString( 23, kamokuBeans[i].getTourokujikoku(  ) );
                ps.setString( 24, kamokuBeans[i].getTourokusya(  ) );
                ps.setString( 25, kamokuBeans[i].getKousinbi(  ) );
                ps.setString( 26, kamokuBeans[i].getKousinjikoku(  ) );
                ps.setString( 27, kamokuBeans[i].getKousinsya(  ) );
                count += ps.executeUpdate(  );

                // �֘A����Ȗڃ}�X�^�̃��R�[�h�X�V
                PCY_KanrenKyoikuKamokuBean[] kanrenBeans = kamokuBeans[i].getKanrenKamokuBeans(  );

                if ( kanrenBeans != null ) {
                    PCY_KanrenKyoikuKamokuEJBHome home = ( PCY_KanrenKyoikuKamokuEJBHome )locator
                        .getServiceLocation( "PCY_KanrenKyoikuKamokuEJB",
                            PCY_KanrenKyoikuKamokuEJBHome.class );
                    PCY_KanrenKyoikuKamokuEJB ejb = home.create(  );

                    ejb.doDeleteByKamokuCode( kamokuBeans[i].getKamokuCode(  ), loginuser );

					//�ǉ����鎞�Ɂ|�P����邩��@�{�P���Ă���
					for ( int j = 0; j < kanrenBeans.length; j++ ) {
						if( kanrenBeans[j].getLevelCode(  ) != null ) {
							kanrenBeans[j].setLevelCode( String.valueOf( Integer.parseInt( kanrenBeans[j].getLevelCode(  ) ) + 1 ));
						}
					}
                    ejb.doInsert( kanrenBeans, loginuser );
                }
            }

            if ( kamokuBeans.length != count ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �v���C�}���[�L�[���L�[�Ƃ��ĉȖڃ}�X�^���폜���܂��B
     *
     * @param kamokuBeans �폜����
     * @param loginuser ���O�C�����[�U
     * @return �폜����
     * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍ폜����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doDelete( PCY_KamokuBean[] kamokuBeans, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �Ȗ�Bean���ȖڃR�[�h�Ń\�[�g
            Arrays.sort( kamokuBeans, new KamokuCodeComparator(  ) );

            // SQL�쐬
            StringBuffer sql = new StringBuffer(  );
            sql.append( "UPDATE " );
            sql.append( HcdbDef.L01_TBL );
            sql.append( "    SET SAKUJYO_FLG='1'," );
            sql.append( "        KOUSINBI=?," );
            sql.append( "        KOUSINJIKOKU=?," );
            sql.append( "        KOUSINSYA=?" );
            sql.append( "  WHERE KAMOKU_CODE=?" );
            sql.append( "    AND SAKUJYO_FLG='0'" );
            sql.append( "    AND TOUROKUBI=?" );
            sql.append( "    AND TOUROKUJIKOKU=?" );
            sql.append( "    AND TOUROKUSYA=?" );
            sql.append( "    AND KOUSINBI=?" );
            sql.append( "    AND KOUSINJIKOKU=?" );
            sql.append( "    AND KOUSINSYA=?" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            PCY_ClassEJBHome classHome = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
                    PCY_ClassEJBHome.class );
            PCY_ClassEJB classEjb = classHome.create(  );

            // �������s
            ps = con.prepareStatement( sql.toString(  ) );

            int count = 0;

            for ( int i = 0; i < kamokuBeans.length; i++ ) {
                // �Ȗڃ}�X�^�̃��b�N
                this.doSelectByPrimaryKey( kamokuBeans[i], true, loginuser );

                // �N���X�}�X�^�̎擾
                PCY_ClassBean classBean = new PCY_ClassBean(  );
                classBean.getKamokuBean(  ).setKamokuCode( kamokuBeans[i].getKamokuCode(  ) );

                // �N���X�}�X�^�̍폜
                PCY_ClassBean[] classBeans = classEjb.doSelect( classBean, false, loginuser );

                if ( classBeans.length != 0 ) {
                    classEjb.doDelete( classBeans, loginuser );
                }

                // �Ȗڃ}�X�^�̍폜
                ps.setString( 1, PZZ010_CharacterUtil.GetDay(  ) );
                ps.setString( 2, PZZ010_CharacterUtil.GetTime(  ) );
                ps.setString( 3, loginuser.getSimeiNo(  ) );
                ps.setString( 4, kamokuBeans[i].getKamokuCode(  ) );
                ps.setString( 5, kamokuBeans[i].getTourokubi(  ) );
                ps.setString( 6, kamokuBeans[i].getTourokujikoku(  ) );
                ps.setString( 7, kamokuBeans[i].getTourokusya(  ) );
                ps.setString( 8, kamokuBeans[i].getKousinbi(  ) );
                ps.setString( 9, kamokuBeans[i].getKousinjikoku(  ) );
                ps.setString( 10, kamokuBeans[i].getKousinsya(  ) );
                count += ps.executeUpdate(  );

				// �֘A����Ȗڃ}�X�^�̃��R�[�h�폜
				PCY_KanrenKyoikuKamokuEJBHome home = ( PCY_KanrenKyoikuKamokuEJBHome )locator
						.getServiceLocation( "PCY_KanrenKyoikuKamokuEJB",
							PCY_KanrenKyoikuKamokuEJBHome.class );
					PCY_KanrenKyoikuKamokuEJB ejb = home.create(  );

				ejb.doDeleteByKamokuCode( kamokuBeans[i].getKamokuCode(  ), loginuser );


            }

            if ( kamokuBeans.length != count ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

	/**
	 * �Ȗڃ}�X�^���v���C�}���[�L�[�Ō������Č��ʂ�Ԃ��܂��B
	 * �������ʂ����������ꍇ�� null ��Ԃ��܂��B
	 * �폜�t���O�̔���͍s���Ă��܂���B
	 *
	 * @param kamokuBean ��������
	 * @param lock true�̏ꍇ���b�N����Afalse�̏ꍇ���b�N�Ȃ�
	 * @param loginuser ���O�C�����[�U
	 * @return ��������
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_KamokuBean doSelectByPKey( PCY_KamokuBean kamokuBean, boolean lock,
		PCY_PersonalBean loginuser ) {
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			PCY_KamokuBean ret = null;
			String sql         = "SELECT * FROM " + HcdbDef.L01_TBL
				+ " WHERE KAMOKU_CODE=? "
				+ PCY_DBUtils.getInstance(  ).getLock( lock );

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con     = locator.getDataSource(  ).getConnection(  );

			// �������s
			ps = con.prepareStatement( sql );
			ps.setString( 1, kamokuBean.getKamokuCode(  ) );

			ResultSet rs = ps.executeQuery(  );

			if ( rs.next(  ) ) {
				ret = new PCY_KamokuBean( rs, null );
			}

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return ret;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }

    private class KamokuCodeComparator implements Comparator {
        public int compare( Object o1, Object o2 ) {
            PCY_KamokuBean kamoku1 = ( PCY_KamokuBean )o1;
            PCY_KamokuBean kamoku2 = ( PCY_KamokuBean )o2;

            return kamoku1.getKamokuCode(  ).compareTo( kamoku2.getKamokuCode(  ) );
        }
    }
}
