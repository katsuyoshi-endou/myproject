/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O            ���e
 *   2005/12/03              �Β�  �[        �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.learning.base.PCY_ServiceLocator;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.bean.PCY_EnqueteBean;
import jp.co.hisas.career.learning.base.bean.PCY_EnqueteFileBean;
import jp.co.hisas.career.learning.base.ejb.PCY_EnqueteEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_EnqueteEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_EnqueteKaitouBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;


/**
 *<PRE>
 *
 * �N���X���F
 *   �A���P�[�g���̓T�[�u���b�g�N���X
 *
 * �@�\�����F
 *   ���C�̃A���P�[�g���͉�ʂɕ\����������擾���܂��B
 *
 *</PRE>
 */
public class PCY16b_EnqueteRegistServlet extends PCY010_ControllerServlet {
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PCY_PersonalBean loginuser )
        throws NamingException, CreateException, RemoteException, PCY_WarningException {
        /*���\�b�h�g���[�X�o��*/
        Log.method( "", "IN", "" );

        PCY_EnqueteKaitouBean kaitouBean = new PCY_EnqueteKaitouBean( request );

        //�񍐎�ʎ擾
        String houkokuType = request.getParameter("houkoku_type");
        //�񍐋敪�擾
        String houkoku = request.getParameter( "houkoku_kubun" );

        /* For SAS-S */
        String simei_no = request.getParameter( "simei_no" );

        if ( ( simei_no == null ) || "".equals( simei_no ) ) {
            simei_no = loginuser.getSimeiNo(  );
        }

        //�A���P�[�g���擾�A�ݒ�
        PCY_EnqueteBean enquete = new PCY_EnqueteBean(PCY_EnqueteFileBean.getInstance().getEnquete( houkoku ));
        enquete.setKaitouBean( kaitouBean );
        
        //�e�[�u������
        String tableName = "";
        boolean nullFlg = (houkokuType != null);
        //����񍐂̏ꍇ
        if (nullFlg && ( houkokuType.equals("0") || houkokuType.equals("1") )) {
        	tableName = HcdbDef.L81_TBL;
        }
        //�t�H���[�񍐂̏ꍇ
        else if (nullFlg && ( houkokuType.equals("2") || houkokuType.equals("3") )) {
        	tableName = HcdbDef.L82_TBL;
        }
        
        PCY_EnqueteKaitouBean kaitou = new PCY_EnqueteKaitouBean();
        kaitou.setKamokuCode( kaitouBean.getKamokuCode() );
        kaitou.setClassCode( kaitouBean.getClassCode() );
        kaitou.setSimeiNo( simei_no );
        kaitou.setTableNameSub(tableName);
        
        PCY_ServiceLocator locator      = PCY_ServiceLocator.getInstance(  );
        PCY_EnqueteEJBHome home = (PCY_EnqueteEJBHome)locator.getServiceLocation(
                "PCY_EnqueteEJB", PCY_EnqueteEJBHome.class );
        PCY_EnqueteEJB ejb = home.create();

        //�J�E���g
        enquete.setEnqCount( ejb.countEnqueteKaitou( kaitou, loginuser ) );

        //���N�G�X�g����󂯎�����l�ɉ񓚂̒l���Ȃ��ꍇ
        if ( enquete.getKaitouBean() == null || !enquete.getKaitouBean().isKaitouExist() ) {

	        //�擾
	        kaitou = ejb.getEnqueteKaitou( kaitou, loginuser );
	        
	        kaitou.setKamokuCode( kaitouBean.getKamokuCode() );
	        kaitou.setClassCode( kaitouBean.getClassCode() );
	        kaitou.setSimeiNo( simei_no );
	        
	        enquete.setKaitouBean( kaitou );
        }
        
        request.setAttribute( "enqueteBean", enquete );

        //�񍐎�ʐݒ�
        request.setAttribute("houkoku_type", houkokuType);
        //�񍐋敪�ݒ�
        request.setAttribute("houkoku_kubun", houkoku);
        
        /*���\�b�h�g���[�X�o��*/
        Log.method( "", "OUT", "" );

        return getForwardPath(  );
    }
}
