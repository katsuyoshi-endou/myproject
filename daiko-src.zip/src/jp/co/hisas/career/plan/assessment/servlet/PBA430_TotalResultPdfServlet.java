/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i���V�e�ACareer�v��n�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/04/01  01.00       �n�� ��q    �V�K�쐬  <C-PPE02-004>
 *   2004/09/21              �n�� ��q    �t�@�C�����C��  <B-PPE02-017>
 *   2004/09/22              �n�� ��q    ���������o��    <B-PPE02-019>
 *   2005/11/08              QUANLA        sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */

package jp.co.hisas.career.plan.assessment.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.property.*;
import jp.co.hisas.career.util.pdf.*;
import jp.co.hisas.career.base.userinfo.bean.*;
import jp.co.hisas.career.plan.base.bean.*;
import jp.co.hisas.career.plan.assessment.bean.*;


/**
 *<PRE>
 * �T�v:
 *   �u���E�U����̌����v�����󂯎��A�N���C�A���gBean�̌����������\�b�h���Ăяo���B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 *</PRE>
 */
public class PBA430_TotalResultPdfServlet extends HttpServlet {

    /** ServletContext�I�u�W�F�N�g */
    private ServletContext ctx = null;

    /** ���O�C��No */
    private String login_no    = null;

    /**
     * ServletContext�I�u�W�F�N�g���擾����B
     *
     * @param config   Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
     */
    public void init(ServletConfig config) {
        synchronized( this ) {
            if( ctx == null ) {
                ctx = config.getServletContext();
            }
        }
    }

    /**
     * �u���E�U����̌����v�����󂯎��A�N���C�A���gBean�̌����������\�b�h���Ăяo���B
     *
     * @param     request            �N���C�A���g�̃��N�G�X�g��\��HttpServletRequest�I�u�W�F�N�g
     * @param     response           Servlet ����̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
     * @exception IOException        ���o�͊֘A�����Ŕ��������O
     * @exception ServletException   Servlet �̐���ȏ������W����ꂽ�Ƃ��ɔ��������O
     */
    public void service( HttpServletRequest request, HttpServletResponse response )
    throws IOException, ServletException{
        try {

            /* session�X�R�[�v��Beans���擾���� */
            HttpSession session = request.getSession(false);
            if ( session == null ) {
                //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } else {

                // UserInfoBean�ďo
                UserInfoBean bean = (UserInfoBean)session.getAttribute( "userinfo" );
                login_no = bean.getLogin_no();

                // Log�o��
                Log.method     ( login_no, "IN", ""  );
                Log.performance( login_no, true, "" );

                /* ���͏��擾���� */
                // �O����`����
                // Announce
                String SenteItem1 = (String)ReadFile.announceMapData.get( "AZZ100" );
                String SenteItem2 = (String)ReadFile.announceMapData.get( "AZZ101" );
                String SenteItem3 = (String)ReadFile.announceMapData.get( "AZZ102" );
                // Parameter
                String labelItem1 = (String)ReadFile.paramMapData.get   ( "DZZ008" );
                String labelItem2 = (String)ReadFile.paramMapData.get   ( "DZZ009" );
                String labelItem3 = (String)ReadFile.paramMapData.get   ( "DZZ010" );
                String labelItem4 = (String)ReadFile.paramMapData.get   ( "DZZ143" );
                // �����p�̕ϐ��ɃZ�b�g
                String[] annoItem = {
                    SenteItem1, SenteItem2, SenteItem3
                };
                String[] paraItem = {
                    labelItem1,     labelItem2,
                    labelItem3,     labelItem4
                };

                // �F�w��
                String[] percentDef = {
                    Integer.toString( HcdbDef.value1 ),
                    Integer.toString( HcdbDef.value2 ),
                    Integer.toString( HcdbDef.value3 ),
                    Integer.toString( HcdbDef.value4 ),
                    Integer.toString( HcdbDef.value5 )
                };

                // �F�w��
                String[][] colorDef = {
                    HcdbDef.rgb1,
                    HcdbDef.rgb2,
                    HcdbDef.rgb3,
                    HcdbDef.rgb4,
                    HcdbDef.rgb5
                };


                // �W�v���ʎ擾
                String searchCnd  = PZZ010_CharacterUtil.strEncode ( ( String )request.getParameter( "H159_SearchCnd" ) );  // INS#P-PPE02-019-003
                String memberCnt  = ( String )session.getAttribute( "memberCnt"  );
                String matchTotal = ( String )session.getAttribute( "matchTotal" );
                PBA_AssessTotalBean[] assessTotalBeans = ( PBA_AssessTotalBean[] )session.getAttribute( "assessTotalBeans" );

                // PBY_SkillStandardBean�擾
                String[]   syoku_code  = PBY_SkillStandardBean.getSyokuCode();
                Vector     senmon_code = new Vector();
                String[][] level_code  = PBY_SkillStandardBean.getLevelList();

                String[][] syoku_list  = new String[syoku_code.length][2];

                // �W�v���ʂ�Index
                int ind1   = 0;
                // ��啪�쐔
                int senCnt = 0;

                // �E��R�[�h�A�E�햼�̂̃Z�b�g
                for ( int i = 0 ; i < syoku_code.length ; i++ ) {
                    syoku_list[i][0] = syoku_code[i];
                    syoku_list[i][1] = PBY_SkillStandardBean.getSyokuName( syoku_code[i] );
                    // ��啪��Bean�z��擾
                    Vector senmon    = PBY_SkillStandardBean.getSenmonBeanList( syoku_code[i] );
                    senCnt += senmon.size();
                    senmon_code.add( i, senmon );
                }

                String[][] senmon_list = new String[senCnt][3];
                String[][] level_list  = new String[senCnt * level_code.length][6];

                // ��啪��R�[�h�A��啪�얼�́A���x�����̃Z�b�g
                int ind2 = 0;
                int ind3 = 0;
                for ( int i = 0 ; i < syoku_code.length ; i++ ) {
                    Vector senmon_v = ( Vector )senmon_code.get( i );

                    for ( int j = 0 ; j < senmon_v.size() ; j++ ) {
                        PBY_SenmonBean senmon = ( PBY_SenmonBean )senmon_v.get( j );
                        senmon_list[ ind2 + j ][0] = syoku_code[i];
                        senmon_list[ ind2 + j ][1] = senmon.getSenmonCode();
                        senmon_list[ ind2 + j ][2] = senmon.getSenmonName();

                        // ���x��Bean�z��擾
                        Vector level_v = senmon.getLevelBean();
                        // ���x��Bean��Index
                        int ind4 = 0;

                        for ( int k = 0 ; k < level_code.length ; k++ ) {
                            String level_code_tmp = "";

                            if ( ind4 < level_v.size() ) {
                                PBY_LevelBean level = (PBY_LevelBean)level_v.get( ind4 );
                                level_code_tmp      = level.getLevelCode();
                            }

                            level_list[ ind3 + k ][0] = syoku_code[i];
                            level_list[ ind3 + k ][1] = senmon.getSenmonCode();
                            level_list[ ind3 + k ][2] = level_code[k][0];
                            level_list[ ind3 + k ][3] = level_code[k][1];

                            // ��M�җL���`�F�b�N
                            String matchPct = "";
                            String bColor   = "5";

                            // ��M�҂���
                            if ( ind1 < assessTotalBeans.length
                              && assessTotalBeans[ind1].getSyokuCode().equals ( syoku_code[i]          )
                              && assessTotalBeans[ind1].getSenmonCode().equals( senmon.getSenmonCode() )
                              && assessTotalBeans[ind1].getLevelCode().equals ( level_code[k][0]       ) ) {
                                matchPct = Integer.toString( assessTotalBeans[ind1].getPercentage() );
                                bColor   = assessTotalBeans[ind1].getColorNo();
                                ind1++;
                            }

                            // ��`���x���̑��ݗL���ɂ��A���l���Y�����x�����̕�������i�[
                            if ( level_code[k][0].equals( level_code_tmp ) ) {
                                level_list[ ind3 + k ][4] = matchPct;
                                level_list[ ind3 + k ][5] = bColor;
                                ind4++;
                            } else {
                                level_list[ ind3 + k ][4] = "����";
                                level_list[ ind3 + k ][5] = "5";
                            }
                        }
                        ind3 += level_code.length;
                    }
                    ind2 += senmon_v.size();
                }


                // �Ɩ�����
                // PDF�t�@�C����
                String pdf_name = login_no + "_"  // CHG#P-PPE02-017-001
                                + PZZ010_CharacterUtil.GetDay()
                                + PZZ010_CharacterUtil.GetTime()
                                + "_TotalReslut.pdf";

                // PDF�쐬
                PZE080_AssessTotalPDF pdf = new PZE080_AssessTotalPDF( login_no );

                // �o�͏��Z�b�g
                pdf.setSearchCnd ( searchCnd   );  // INS#P-PPE02-019-003
                pdf.setAnnounce  ( annoItem    );
                pdf.setParameter ( paraItem    );
                pdf.setPercentDef( percentDef  );
                pdf.setColorDef  ( colorDef    );
                pdf.setMemberCnt ( memberCnt   );
                pdf.setMatchTotal( matchTotal  );
                pdf.setSyokuList ( syoku_list  );
                pdf.setSenmonList( senmon_list );
                pdf.setLevelList ( level_list  );

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                pdf.executePDF( baos );

                ByteArrayInputStream bais  = new ByteArrayInputStream( baos.toByteArray() );

                request.setAttribute( "STREAM", bais );
                request.setAttribute( "H080_FileName", pdf_name );


                // DownLoad�̃_�C�A���O�{�b�N�X��\��
                RequestDispatcher rd = ctx.getRequestDispatcher( "/servlet/PYE010_FileDownloadServlet" );
                rd.forward( request , response );

                Log.performance( login_no , false, "" );
                Log.method( login_no ,"OUT" , "" );
    
            }

        } catch ( IllegalStateException e ) {
            Log.error( login_no ,"HJE-0010" ,e );
            //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( IOException e ) {
            Log.error( login_no ,"HJE-0012" ,e );
            //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( ServletException e ) {
            Log.error( login_no ,"HJE-0015" ,e );
            //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( Exception e ) {
            Log.error( login_no ,"HJE-0017" ,e );
            //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        }
    
    }
}

