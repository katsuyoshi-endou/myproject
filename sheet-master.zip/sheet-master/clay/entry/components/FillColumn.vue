<template>
  <el-table-column :prop="propStr" :label="label" :width="width">
    <template slot-scope="scope">
      <div class="cell-inner" @click="emitClick(scope)">
        {{ previewFill(scope.row) }}
      </div>
    </template>
  </el-table-column>
</template>

<script>
export default {
  props: ['seq', 'pulldown', 'label', 'width', 'mode'],
  computed: {
    colId() {
      return `col${this.seq}`;
    },
    propStr() {
      return `cols.${this.colId}.fill.content`;
    },
  },
  methods: {
    emitClick(scope) {
      let mode = this.mode || "text";
      if (this.pulldown) {
        mode = "pulldown";
      }
      this.$emit("click", scope, this.colId, this.label, mode, this.pulldown);
    },
    previewText(text, length) {
      let len = length;
      if (!text) return "";
      if (!len) len = 20;
      if (text.length <= len) return text;
      return text.slice && `${text.slice(0, len)}...`;
    },
    previewFill(row) {
      const col = row.cols[this.colId];
      const text = col && col.fill && col.fill.content;
      return this.previewText(text);
    },
  }
}
</script>
