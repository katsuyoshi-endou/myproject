import FillColumn from "../components/FillColumn.vue";
import ValidColumn from "../components/ValidColumn.vue";
import StatusColumn from "../components/StatusColumn.vue";

Vue.component("fill-column", FillColumn);
Vue.component("valid-column", ValidColumn);
Vue.component("status-column", StatusColumn);

/* eslint-disable-next-line */
function mountVue() {
  const dg = Debug("vue");
  /* eslint-disable-next-line no-unused-vars */
  const app = new Vue({
    el: "[data-vueid='VueSHBLK']",
    data() {
      return {
        ready: false,
        bulkContext: {
          pageState: {},
        },
        tableData: [],
        isTableLoading: true,
        liveOperationCd: "",
        argActor: "",
        argFlowptn: "",
        argStatus: "",
        argTargetAll: false,
        dynamicHeight: 300,
        isPickMode: false,
        isIncludeBehind: false,
        fillDialogVisible: false,
        searchDialogVisible: false,
        liveConditions: {},
        busy: false,
        lbl: {},
        fillEditor: {
          fill: {},
        },
        fillEditorContent: "",
        downloadDialog: {
          visible: false,
          loading: false,
        },
      };
    },
    computed: {
      operationMaster() {
        if (!this.bulkContext) return [];
        const activeList = _.filter(this.bulkContext.operationMaster, x => x.activeFlg === "1");
        const list = activeList.map(x => {
          const { operationCd, operationNm, lpadSort } = x;
          return { code: operationCd, label: operationNm, sort: lpadSort };
        });
        return list.sort((a, b) => {
          // LPAD_SORT desc
          if (a.lpadSort < b.lpadSort) return 1;
          if (a.lpadSort > b.lpadSort) return -1;
          return 0;
        });
      },
      showingTableData() {
        const sheetSet = this.tableData;
        if (!sheetSet) return [];
        const list = Object.keys(sheetSet).map(k => sheetSet[k]);
        const ps = this.bulkContext.pageState;
        const fr = ps.currentPageSize * (ps.currentPage - 1) + 1;
        const to = ps.currentPageSize * ps.currentPage;
        const targets = _.filter(list, x => fr <= x.wkIdx && x.wkIdx <= to);
        const sorted = targets.sort((a, b) => {
          if (Number(a.wkIdx) < Number(b.wkIdx)) return -1;
          if (Number(a.wkIdx) > Number(b.wkIdx)) return 1;
          return 0;
        });
        return sorted;
      },
      bulkActionList() {
        const actorCd = this.argActor;
        const flowPtn = this.argFlowptn;
        const statusCd = this.argStatus;
        if (!(actorCd && flowPtn && statusCd)) return [];
        return this.bulkContext.actionMaster
          .filter(a => a.ACTOR_CD === actorCd)
          .filter(a => a.FLOW_PTN === flowPtn)
          .filter(a => a.STATUS_CD === statusCd)
          .filter(a => a.ACTION_CD !== "STAY")
          .filter(a => a.ACTION_CD !== "DELETE")
          .sort((a, b) => {
            if (a.LPAD_SORT < b.LPAD_SORT) return -1;
            if (a.LPAD_SORT > b.LPAD_SORT) return 1;
            return 0;
          });
      },
      condFormCtgMaster() {
        if (!this.bulkContext) return [];
        const arr = this.bulkContext.formMaster;
        if (!arr) return [];
        const ctgMap = {};
        arr.forEach(x => {
          if (!ctgMap[x.FORM_CTG_CD]) {
            ctgMap[x.FORM_CTG_CD] = {
              code: x.FORM_CTG_CD,
              label: x.FORM_CTG_NM,
              sort: x.FORM_SORT,
            };
          }
        });
        const list = Object.keys(ctgMap).map(key => ctgMap[key]);
        const sorted = list.sort((a, b) => {
          if (a.sort < b.sort) return -1;
          if (a.sort > b.sort) return 1;
          return 0;
        });
        return sorted;
      },
      condFormMaster() {
        if (!this.bulkContext) return [];
        const arr = this.bulkContext.formMaster;
        if (!arr) return [];
        const list = arr.map(x => ({ code: x.FORM_CD, label: x.FORM_NM, sort: x.FORM_SORT }));
        const sorted = list.sort((a, b) => {
          if (a.sort < b.sort) return -1;
          if (a.sort > b.sort) return 1;
          return 0;
        });
        return sorted;
      },
      condStatusMaster() {
        if (!this.bulkContext) return [];
        const arr = this.bulkContext.statusMaster;
        if (!arr) return [];
        const list = arr.map(x => ({ code: x.STATUS_CD, label: x.STATUS_NM, sort: x.SEQ_NO }));
        const sorted = list.sort((a, b) => {
          if (a.sort < b.sort) return -1;
          if (a.sort > b.sort) return 1;
          return 0;
        });
        return sorted;
      },
      isReadyBulkAction() {
        return this.argActor && this.argFlowptn && this.argStatus;
      },
    },
    mounted() {
      this.applyDynamicHeight();
      let timer = false;
      $(window).resize(() => {
        if (timer) clearTimeout(timer);
        timer = setTimeout(this.applyDynamicHeight, 200);
      });

      this.isTableLoading = true;
      this.fetchBulkContext().then(() => {
        setTimeout(() => {
          this.loadTableData().then(() => {
            this.ready = true;
          });
        }, 500);
      });
    },
    methods: {
      applyDynamicHeight() {
        dg("applyDynamicHeight");
        const rf = this.$refs;
        if (!rf.VueSHBLK) return;
        const vv = rf.VueSHBLK.offsetHeight;
        const fh = this.isPickMode ? 98 : 0;
        this.dynamicHeight = vv - fh - 46 - 58 - 15 * 2;
      },
      fetchBulkContext() {
        return axios
          .get(`${App.root}/api/bulk/context`)
          .then(response => {
            const d = response.data;
            this.bulkContext = d;
            this.liveConditions = d.liveConditions;
            this.liveOperationCd = d.operationCd;
            Object.keys(d.uiLabelSet).forEach(key => {
              const id = key.replace("LSHBLK_UI.", "");
              this.lbl[id] = d.uiLabelSet[key];
            });
          })
          .catch(error => {
            this.notifyError(error.message);
          });
      },
      async fetchSheetList(wkIdxFrom, wkIdxTo) {
        dg("fetchSheetList[S]");
        this.isTableLoading = true;
        await new Promise(r => setTimeout(r, 500)); // for IE
        return axios
          .get(`${App.root}/api/bulk`, { params: { wkIdxFrom, wkIdxTo } })
          .then(response => {
            dg("fetchSheetList[E]", wkIdxFrom, wkIdxTo);
            this.mergeTableData(response.data);
            this.isTableLoading = false;
          })
          .catch(error => {
            this.notifyError(error.message);
          });
      },
      loadTableData() {
        const ps = this.bulkContext.pageState;
        const fr = ps.currentPageSize * (ps.currentPage - 1) + 1;
        const to = ps.currentPageSize * ps.currentPage;
        const frD = this.showingTableData.find(x => Number(x.wkIdx) === fr);
        const toD = this.showingTableData.find(x => Number(x.wkIdx) === to);
        if (frD && toD) {
          return Promise.resolve();
        }
        return this.fetchSheetList(fr, to);
      },
      mergeTableData(data) {
        const sheetSet = data.bulkSheetSet;
        Object.keys(sheetSet).forEach(sid => {
          Vue.set(this.tableData, sid, sheetSet[sid]);
        });
      },
      handleChangeOperation(afterOperationCd) {
        this.addSearchConditions("operationCd", afterOperationCd);
        window.pageSubmit("/servlet/CsBulkServlet", "INIT");
      },
      previewText(text, length) {
        let len = length;
        if (!text) return "";
        if (!len) len = 20;
        if (text.length <= len) return text;
        return text.slice && `${text.slice(0, len)}...`;
      },
      previewFill(col, length) {
        const text = col && col.fill && col.fill.content;
        return this.previewText(text, length);
      },
      transSingleSheet(row) {
        this.bulkContext.pageState.lastClickedSheetId = row.sheetId;
        this.savePageState();
        window.makeRequestParameter("sheetId", row.sheetId);
        window.pageSubmit("/servlet/CsSheetServlet", "INIT");
      },
      handleRowClick(row) {
        this.bulkContext.pageState.lastClickedSheetId = row.sheetId;
      },
      tableHeaderCellClassName(table) {
        if (table.column.type === "selection") {
          if (!(this.isPickMode && this.isReadyBulkAction)) {
            return "xx-header-column-checkbox-hidden";
          }
          if (this.isIncludeBehind) {
            return "xx-header-column-checkbox-hidden";
          }
        }
        return "";
      },
      rowClassName(table) {
        const classes = [];
        const r = table.row;
        // Checkbox column
        if (!this.isPickMode) {
          classes.push("xx-row-selectbox-hide");
        } else if (!this.isReadyBulkAction) {
          classes.push("xx-row-selectbox-hide");
        } else if (!this.isBulkTargetRow(r)) {
          classes.push("xx-row-selectbox-hide");
        }
        // Highlight last clicked row
        if (r.sheetId === this.bulkContext.pageState.lastClickedSheetId) {
          classes.push("xx-row-lastclicked");
        }
        return classes.join(" ");
      },
      cellClassName(table) {
        const prop = table.column.property;
        if (prop && prop.match(/cols\.col\d\d?/)) {
          const colId = prop.match(/cols\.(col\d\d?)/)[1];
          const cell = table.row.cols[colId];
          if (cell && cell.fill && cell.fill.editable) return "xx-cell-editable";
        }
        return "";
      },
      refreshOneSheet(wkIdx) {
        return axios
          .get(`${App.root}/api/bulk`, { params: { wkIdxFrom: wkIdx, wkIdxTo: wkIdx } })
          .then(response => {
            this.mergeTableData(response.data);
          })
          .catch(error => {
            this.notifyError(error.message);
          });
      },
      notifyError(message) {
        this.$notify.error({ title: "Error", message, duration: 0 });
      },
      handleArgsChange() {
        this.isIncludeBehind = false;
        this.$refs.bulkTable.clearSelection();
      },
      isBulkTargetRow(row) {
        const matchActor = row.bulkActorCd === this.argActor;
        const matchFlowptn = row.flowPtn === this.argFlowptn;
        const matchStatus = row.statusCd === this.argStatus;
        return matchActor && matchFlowptn && matchStatus;
      },
      columnSelectable(row) {
        return this.isBulkTargetRow(row) && !this.isIncludeBehind;
      },
      handleChangeIncludeBehind(checked) {
        if (checked) {
          this.$refs.bulkTable.tableData.forEach(row => {
            if (this.isBulkTargetRow(row)) {
              this.$refs.bulkTable.toggleRowSelection(row, true);
            }
          });
        }
      },
      onClickSheetAction(act) {
        const sheetList = this.$refs.bulkTable.selection.map(d => `${d.sheetId}#${d.exclusiveKey}`);
        const isTargetAll = this.isIncludeBehind;
        const data = {
          sheetList: isTargetAll ? [] : sheetList,
          actorCd: this.argActor,
          flowPtn: this.argFlowptn,
          statusCd: this.argStatus,
          actionCd: act.ACTION_CD,
          isTargetAll,
        };
        this.ready = false;
        window.showBlockingOverlay();
        axios
          .post(`${App.root}/api/bulk`, data)
          .then(() => {
            window.location.reload();
          })
          .catch(error => {
            this.notifyError(error.message);
          });
      },
      downloadFile() {
        this.downloadDialog.loading = true;
        window.pageTrans("/api/bulk/export", { scene: "CSV" }, true);
      },
      pageReload() {
        window.location.reload();
      },
      togglePickMode() {
        this.isPickMode = !this.isPickMode;
        this.applyDynamicHeight();
        this.applyPickArgsAuto();
      },
      applyPickArgsAuto() {
        const bc = this.bulkContext;
        if (bc.availableActorList.length === 1) {
          this.argActor = bc.availableActorList[0].value;
        }
        if (bc.availableStatusList.length === 1) {
          this.argStatus = bc.availableStatusList[0].statusCd;
        }
        if (bc.availableFlowptnList.length === 1) {
          this.argFlowptn = bc.availableFlowptnList[0].value;
        }
      },
      submitSearchConditions() {
        const data = {
          operationCd: this.bulkContext.operationCd,
          conditions: {
            statusCd: this.liveConditions.statusCd,
            bind: this.liveConditions.bind,
            formCtgCd: this.liveConditions.formCtgCd,
            formCd: this.liveConditions.formCd,
            deptNm: this.liveConditions.deptNm,
            stfNo: this.liveConditions.stfNo,
            stfNm: this.liveConditions.stfNm,
            stfKana: this.liveConditions.stfKana,
            clsANm: this.liveConditions.clsANm,
            clsBNm: this.liveConditions.clsBNm,
            clsCNm: this.liveConditions.clsCNm,
          },
        };
        this.ready = false;
        window.showBlockingOverlay();
        axios
          .put(`${App.root}/api/bulk`, data)
          .then(() => {
            window.pageSubmit("/servlet/CsBulkServlet", "RESTORE");
          })
          .catch(error => {
            this.notifyError(error.message);
          });
      },
      addSearchConditions(key, val) {
        // [Caution] No need to send blank value. No-Request parameter means not a condition.
        if (_.isEmpty(val)) return;
        window.makeRequestParameter(key, val);
      },
      handlePageSizeChange(newPageSize) {
        this.bulkContext.pageState.currentPageSize = newPageSize;
        this.loadTableData();
        this.savePageState();
      },
      handlePageChange(newPage) {
        this.bulkContext.pageState.currentPage = newPage;
        this.loadTableData();
        this.savePageState();
      },
      savePageState() {
        const ps = this.bulkContext.pageState;
        const data = {
          pageState: {
            currentPage: ps.currentPage,
            currentPageSize: ps.currentPageSize,
            lastClickedSheetId: ps.lastClickedSheetId,
          },
        };
        axios.put(`${App.root}/api/bulk/context`, data);
      },
      openFillEditor(scope, colId, label, mode, pdSetCd) {
        const { fill } = scope.row.cols[colId];
        this.fillDialogVisible = true;
        this.fillEditor = { fill: {} };
        const fe = this.fillEditor;
        fe.wkIdx = scope.row.wkIdx;
        fe.sheetId = scope.row.sheetId;
        fe.exclusiveKey = scope.row.exclusiveKey;
        fe.bulkActorCd = scope.row.bulkActorCd;
        fe.title = scope.row.ownPersonName;
        fe.fillLabel = label;
        fe.mode = mode;
        fe.fill = fill;
        fe.before = fill.content || "";
        this.fillEditorContent = fill.content || "";
        if (pdSetCd) {
          const pd = this.bulkContext.pulldownMaster[pdSetCd].sort((a, b) => {
            if (a.lpadSort < b.lpadSort) return -1;
            if (a.lpadSort > b.lpadSort) return 1;
            return 0;
          });
          fe.pulldown = pd;
        }
      },
      handleFillDialogClose(done) {
        let close = done;
        if (close instanceof Event) {
          close = () => {
            this.fillDialogVisible = false;
          };
        }
        if (this.fillEditorContent === this.fillEditor.before) {
          close();
        } else {
          this.$confirm(this.lbl.MODAL_FILL_MSG_DISMISS)
            .then(close)
            .catch(() => {});
        }
      },
      handleFillDialogConfirm() {
        const fe = this.fillEditor;
        const obj = {};
        obj[fe.fill.id] = this.fillEditorContent;
        const data = {
          sheetId: fe.sheetId,
          exclusiveKey: fe.exclusiveKey,
          actorCd: fe.bulkActorCd,
          fills: obj,
        };
        this.busy = true;
        axios
          .put(`${App.root}/api/sheet/fills`, data)
          .then(response => {
            if (response.data.errorExclusive) throw new Error(this.lbl.MODAL_FILL_MSG_EXCLUSIVE);
            setTimeout(() => {
              this.refreshOneSheet(fe.wkIdx).then(() => {
                this.busy = false;
                this.fillDialogVisible = false;
              });
            }, 800);
          })
          .catch(error => {
            this.notifyError(error.message);
            this.busy = false;
          });
      },
    },
  });
  window.vueapp = app;
}

window.mountVue = mountVue;
