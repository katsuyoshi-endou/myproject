package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dao.CsmExcelFillMapDao;
import jp.co.hisas.career.app.sheet.dao.VCstSheetInfoDao;
import jp.co.hisas.career.app.sheet.dto.CsmExcelFillMapDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetInfoDto;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.log.Log;

public class CsExcelUploadEvHdlr extends AbstractEventHandler<CsExcelUploadEvArg, CsExcelUploadEvRslt> {
	
	private String daoLoginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static CsExcelUploadEvRslt exec( CsExcelUploadEvArg arg ) throws CareerException {
		CsExcelUploadEvHdlr handler = new CsExcelUploadEvHdlr();
		return handler.call( arg );
	}
	
	public CsExcelUploadEvRslt call( CsExcelUploadEvArg arg ) throws CareerException {
		CsExcelUploadEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CsExcelUploadEvRslt execute( CsExcelUploadEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.daoLoginNo = arg.getLoginNo();
		
		CsExcelUploadEvRslt result = new CsExcelUploadEvRslt();
		
		if (SU.equals( arg.sharp, "GET" )) {
			VCstSheetInfoDto info = getSheetInfo( arg.sheetId );
			result.excelFillMapList = getExcelFillMapList( arg.party, info.getLayoutCd() );
		}
		
		return result;
	}
	
	private List<CsmExcelFillMapDto> getExcelFillMapList( String party, String layoutCd ) {
		CsmExcelFillMapDao dao = new CsmExcelFillMapDao( daoLoginNo );
		return dao.selectFillIds( party, layoutCd );
	}
	
	private VCstSheetInfoDto getSheetInfo( String sheetId ) throws CareerException {
		VCstSheetInfoDao dao = new VCstSheetInfoDao( daoLoginNo );
		return dao.select( sheetId );
	}
	
}
