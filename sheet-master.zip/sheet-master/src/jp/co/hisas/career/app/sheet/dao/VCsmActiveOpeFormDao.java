/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.VCsmActiveOpeFormDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class VCsmActiveOpeFormDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " PARTY as party,"
                     + " OPERATION_SORT as operationSort,"
                     + " OPERATION_CD as operationCd,"
                     + " OPERATION_NM as operationNm,"
                     + " FORM_GRP_CD as formGrpCd,"
                     + " FORM_GRP_NM as formGrpNm,"
                     + " FORM_CD as formCd,"
                     + " FORM_NM as formNm,"
                     + " FORM_SORT as formSort"
                     ;

    public VCsmActiveOpeFormDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public VCsmActiveOpeFormDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public List<VCsmActiveOpeFormDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] VCsmActiveOpeFormDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<VCsmActiveOpeFormDto> lst = new ArrayList<VCsmActiveOpeFormDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<VCsmActiveOpeFormDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] VCsmActiveOpeFormDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private VCsmActiveOpeFormDto transferRsToDto(ResultSet rs) throws SQLException {

        VCsmActiveOpeFormDto dto = new VCsmActiveOpeFormDto();
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setOperationSort(DaoUtil.convertNullToString(rs.getString("operationSort")));
        dto.setOperationCd(DaoUtil.convertNullToString(rs.getString("operationCd")));
        dto.setOperationNm(DaoUtil.convertNullToString(rs.getString("operationNm")));
        dto.setFormGrpCd(DaoUtil.convertNullToString(rs.getString("formGrpCd")));
        dto.setFormGrpNm(DaoUtil.convertNullToString(rs.getString("formGrpNm")));
        dto.setFormCd(DaoUtil.convertNullToString(rs.getString("formCd")));
        dto.setFormNm(DaoUtil.convertNullToString(rs.getString("formNm")));
        dto.setFormSort(DaoUtil.convertNullToString(rs.getString("formSort")));
        return dto;
    }

}

