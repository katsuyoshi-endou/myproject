package jp.co.hisas.career.app.sheet.api.mold;

import java.io.Serializable;

public class Fill implements Serializable {
	
	public String id;
	public String content;
	public boolean editable;
	
	public Fill(String fillId, boolean editable) {
		this.id = fillId;
		this.editable = editable;
	}
}
