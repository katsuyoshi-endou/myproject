package jp.co.hisas.career.app.sheet.deliver.sheet;

import jp.co.hisas.career.app.sheet.garage.SheetGarage;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class SheetEvHdlr extends AbstractEventHandler<SheetEvArg, SheetEvRslt> {
	
	public static SheetEvRslt exec( SheetEvArg arg ) throws CareerException {
		SheetEvHdlr handler = new SheetEvHdlr();
		return handler.call( arg );
	}
	
	public SheetEvRslt call( SheetEvArg arg ) throws CareerException {
		return this.callEjb( arg );
	}
	
	protected SheetEvRslt execute( SheetEvArg arg ) throws CareerException {
		arg.validateArg();
		String daoLoginNo = arg.getLoginNo();
		SheetEvRslt result = new SheetEvRslt();
		
		if (SU.equals( "GetOperation", arg.sharp )) {
			SheetGarage ggBP = new SheetGarage( daoLoginNo );
			result.operation = ggBP.getOperation( arg.party, arg.operationCd );
		}
		else if (SU.equals( "GetFirstOperation", arg.sharp )) {
			SheetGarage ggBP = new SheetGarage( daoLoginNo );
			result.operation = ggBP.getFirstOperation( arg.party );
		}
		else if (SU.equals( "GetFillIdList", arg.sharp )) {
			SheetGarage ggBP = new SheetGarage( daoLoginNo );
			result.fillIdList = ggBP.getFillIdList( arg.fillSetCd );
		}
		
		return result;
	}
	
}
