package jp.co.hisas.career.app.sheet.api.bulk;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class BulkEvHdlr extends AbstractEventHandler<BulkEvArg, BulkEvRslt> {
	
	public static BulkEvRslt exec( BulkEvArg arg ) throws CareerException {
		BulkEvHdlr handler = new BulkEvHdlr();
		return handler.call( arg );
	}
	
	public BulkEvRslt call( BulkEvArg arg ) throws CareerException {
		return this.callEjb( arg );
	}
	
	protected BulkEvRslt execute( BulkEvArg arg ) throws CareerException {
		arg.validateArg();
		String daoLoginNo = arg.getLoginNo();
		BulkEvRslt result = new BulkEvRslt();
		
		if (SU.equals( "GET", arg.sharp )) {
			
			BulkLogicGet logic = new BulkLogicGet( daoLoginNo );
			result = logic.main( arg.orderGET );
		}
		else if (SU.equals( "POST", arg.sharp )) {
			
			BulkLogicPost logic = new BulkLogicPost( daoLoginNo );
			result = logic.main( arg.orderPOST );
		}
		else if (SU.equals( "PUT", arg.sharp )) {
			
			BulkLogicPut logic = new BulkLogicPut( daoLoginNo );
			result = logic.main( arg.orderPUT );
		}
		
		return result;
	}
	
}
