package jp.co.hisas.career.app.sheet.util;

public class CsSessionKey {
	
	public static final String CS_SINGLE_SHEET = "CsSingleSheet";
	
	public static final String CS_SHEET_ID = "CsSheetId";
	
	public static final String CS_SHEET_TEMPLATE = "CsSheetTemplate";
	
	public static final String CS_SHEET_TEMPLATE_JS = "CsSheetTemplateJs";
	
	public static final String CS_SHEET_TEMPLATE_DIR = "CsSheetTemplateDir";
	
	public static final String CS_SHEET_TEMPLATE_CSPE = "CsSheetTemplateCspe";
	
	public static final String CS_VIEW_SHEET_ACTOR_CD = "CsViewSheetActorCd";
	
	public static final String CS_ACTOR_LIST = "CsRefererList";
	
	public static final String CS_HOLD_ACTOR_LIST = "CsHoldActorList";	
	
	public static final String CS_REFERER_LIST = "CsRefererList";
	
	public static final String CS_REFERER_MASTER_LIST = "CsRefererMaterList";
	
	public static final String CS_ACTIVE_OPE_FORM_LIST = "CsActiveOpeFormList";
	
	public static final String CS_PROGRESS = "CsProgress";
	
	public static final String PERSON_BELONG_LIST = "PersonBelongList";
	
	public static final String VHD012_SRCH_COND = "VHD012_SrchCond";
	
	public static final String VHD021_SRCH_COND = "VHD021_SrchCond";
	
	public static final String VHD022_SRCH_COND = "VHD022_SrchCond";
	
	public static final String VHD030_SRCH_COND = "VHD030_SrchCond";
	
	public static final String VHE020_SRCH_COND = "VHE020_SrchCond";
	
	public static final String VHG010_SRCH_COND = "VHG010_SrchCond";
	
	public static final String VHF010_SRCH_COND = "VHF010_SrchCond";
	
	public static final String VCST_SHEET_DTO_LIST = "VCstSheetDtoList";
	
	public static final String VCST_SHEET_SINGLE_DTO_LIST = "VCstSheetSingleDtoList";
	
	public static final String VHF010_APRV_GYOS_LIST = "VHF010_AprvGyosList";
	
	public static final String VHF010_APRV_SHOK_LIST = "VHF010_AprvShokList";
	
	public static final String CS_MULTI_SHEET = "CsMultiSheet";
	
	public static final String CS_MULTI_SHEET_XL = "CsMultiSheetXl";
	
	public static final String STAT_PROG_OPE_LIST = "StatProgOpeList";
	
	public static final String STAT_PROG_SECTION_MAP = "StatProgSectionMap";
	
	public static final String STAT_PROG_SHEET_COUNT_MAP = "StatProgSheetCountMap";
	
	public static final String STAT_PROG_SHEET_HOLD_MAP = "StatProgSheetHoldMap";
	
	public static final String GS2KEYS_DTO_LIST = "Gs2keysDtoList";
	
	public static final String VHG010_SRCH_OPTION_1 = "Vhg010SrchOption1";
	
	public static final String VHD021_SRCH_OPTION_1 = "Vhd021SrchOption1";
	
	public static final String VHD021_SRCH_OPTION_2 = "Vhd021SrchOption2";
	
	public static final String VHD021_SRCH_OPTION_3 = "Vhd021SrchOption3";
	
	public static final String VHD022_SRCH_OPTION_1 = "Vhd022SrchOption1";
	
	public static final String VHD022_SRCH_OPTION_2 = "Vhd022SrchOption2";
	
	public static final String VHE020_SRCH_OPTION_1 = "Vhe020SrchOption1";
	
	public static final String VHF010_SRCH_OPTION_1 = "Vhf010SrchOption1";
	
	public static final String VHF010_SRCH_OPTION_2 = "Vhf010SrchOption2";
	
	public static final String DBPIPE_TGT_TBL = "DBpipeTgtTbl";
	
	public static final String CS_RELATED_SHEET_ID = "CsRelatedSheetId";
	
	public static final String CS_RELATED_ACTOR_CD = "CsRelatedActorCd";
	
	public static final String CS_BULK_OPERATION_CD = "CsBulkOperationCd";

	public static final String CS_BULK_INST_CD = "CsBulkInstCd";

	public static final String CS_BULK_LIVE_CONDITIONS = "CsBulkConditions";
	
	public static final String CS_BULK_PAGE_STATE = "CsBulkPageState";
}
