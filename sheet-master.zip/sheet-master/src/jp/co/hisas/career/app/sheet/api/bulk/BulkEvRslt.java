package jp.co.hisas.career.app.sheet.api.bulk;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.ejb.AbstractEventResult;

public class BulkEvRslt extends AbstractEventResult {
	
	public Map<String, BulkSheet> bulkSheetSet;
	public List<Map<String, String>> colDefMap;
	public boolean hasInvalid;
	public boolean hasExclusiveError;
}
