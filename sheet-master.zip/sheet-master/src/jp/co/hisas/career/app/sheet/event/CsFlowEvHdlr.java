package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.bean.CsFlowPtnBean;
import jp.co.hisas.career.app.sheet.dao.VCsmFlowStatusDao;
import jp.co.hisas.career.app.sheet.dto.VCsmFlowStatusDto;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.ValueTextSortDao;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;
import jp.co.hisas.career.util.log.Log;

public class CsFlowEvHdlr extends AbstractEventHandler<CsFlowEvArg, CsFlowEvRslt> {
	
	private String daoLoginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static CsFlowEvRslt exec( CsFlowEvArg arg ) throws CareerException {
		CsFlowEvHdlr handler = new CsFlowEvHdlr();
		return handler.call( arg );
	}
	
	public CsFlowEvRslt call( CsFlowEvArg arg ) throws CareerException {
		CsFlowEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CsFlowEvRslt execute( CsFlowEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.daoLoginNo = arg.getLoginNo();
		
		CsFlowEvRslt result = new CsFlowEvRslt();
		
		if (SU.equals( arg.sharp, "GET_ALL_STATUS" )) {
			result.allStatuses = getAllStatuses( arg.flowCd );
		}
		else if (SU.equals( arg.sharp, "GET_ALL_FLOWPTN_INFO" )) {
			// flowptn list
			List<ValueTextSortDto> flowPtns = getFlowPtnList( arg.flowCd );
			
			// each flowptn status path
			Map<String, List<String>> pathMap = getFlowPtnPathList( arg.flowCd );
			
			// each flowptn main actors
			Map<String, List<String>> mainActorMap = getMainActorList( arg.flowCd );
			
			// make
			List<CsFlowPtnBean> flowPtnList = new ArrayList<CsFlowPtnBean>();
			for (ValueTextSortDto flowPtn : flowPtns) {
				CsFlowPtnBean bean = new CsFlowPtnBean();
				bean.code = flowPtn.getValue();
				bean.name = flowPtn.getText();
				bean.pathStatuses = pathMap.get( bean.code );
				bean.mainActors = mainActorMap.get( bean.code );
				flowPtnList.add( bean );
			}
			result.flowPtnList = flowPtnList;
		}
		
		return result;
	}
	
	private List<VCsmFlowStatusDto> getAllStatuses( String flowCd ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + VCsmFlowStatusDao.ALLCOLS );
		sql.append( "   from V_CSM_FLOW_STATUS " );
		sql.append( "  where FLOW_CD = ? " );
		sql.append( "  order by SEQ_NO " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( flowCd );
		
		VCsmFlowStatusDao dao = new VCsmFlowStatusDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<ValueTextSortDto> getFlowPtnList( String flowCd ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select FLOW_PTN as value, FLOW_PTN_NM as text, LPAD_SORT as sort " );
		sql.append( "   from CSM_FLOW_PTN " );
		sql.append( "  where FLOW_CD = ? " );
		sql.append( "  order by LPAD_SORT " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( flowCd );
		
		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private Map<String, List<String>> getFlowPtnPathList( String flowCd ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select FLOW_PTN as value, STATUS_CD as text, '' as sort " );
		sql.append( "   from CSM_FLOW_PTN_PATH " );
		sql.append( "  where FLOW_CD = ? " );
		sql.append( "  order by FLOW_PTN, STATUS_CD " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( flowCd );
		
		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		List<ValueTextSortDto> pathList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		
		// <FLOW_PTN, List<STATUS_CD>>
		Map<String, List<String>> pathMap = new HashMap<String, List<String>>();
		List<String> statusList = new ArrayList<String>();
		String lastPtn = null;
		/* value: FLOW_PTN  text: STATUS_CD */
		for (ValueTextSortDto dto : pathList) {
			String ptn = dto.getValue();
			if (!ptn.equals( lastPtn ) && lastPtn != null) {
				pathMap.put( lastPtn, statusList );
				statusList = new ArrayList<String>();
			}
			statusList.add( dto.getText() );
			lastPtn = ptn;
		}
		pathMap.put( lastPtn, statusList );
		return pathMap;
	}
	
	private Map<String, List<String>> getMainActorList( String flowCd ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select FLOW_PTN as value, MAIN_ACTOR_CD as text, '' as sort " );
		sql.append( "   from ( " );
		sql.append( "          select distinct pt.FLOW_PTN, fl.MAIN_ACTOR_CD " );
		sql.append( "            from CSM_FLOW_PTN_PATH pt " );
		sql.append( "                 inner join CSM_SHEET_FLOW fl " );
		sql.append( "                   on (fl.FLOW_CD = pt.FLOW_CD and fl.STATUS_CD = pt.STATUS_CD) " );
		sql.append( "           where pt.FLOW_CD = ? " );
		sql.append( "        ) " );
		sql.append( "  order by FLOW_PTN " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( flowCd );
		
		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		List<ValueTextSortDto> actorList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		
		// <FLOW_PTN, List<STATUS_CD>>
		Map<String, List<String>> actorMap = new HashMap<String, List<String>>();
		List<String> actCdList = new ArrayList<String>();
		String lastPtn = null;
		/* value: FLOW_PTN  text: MAIN_ACTOR_CD */
		for (ValueTextSortDto dto : actorList) {
			String ptn = dto.getValue();
			if (!ptn.equals( lastPtn ) && lastPtn != null) {
				actorMap.put( lastPtn, actCdList );
				actCdList = new ArrayList<String>();
			}
			actCdList.add( dto.getText() );
			lastPtn = ptn;
		}
		actorMap.put( lastPtn, actCdList );
		return actorMap;
	}
	
}
