/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.CsmSheetParamDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CsmSheetParamDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " PARAM_SET_CD as paramSetCd,"
                     + " PARAM_ID as paramId,"
                     + " PARAM_VALUE as paramValue"
                     ;

    public CsmSheetParamDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CsmSheetParamDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public List<CsmSheetParamDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CsmSheetParamDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CsmSheetParamDto> lst = new ArrayList<CsmSheetParamDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CsmSheetParamDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CsmSheetParamDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private CsmSheetParamDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmSheetParamDto dto = new CsmSheetParamDto();
        dto.setParamSetCd(DaoUtil.convertNullToString(rs.getString("paramSetCd")));
        dto.setParamId(DaoUtil.convertNullToString(rs.getString("paramId")));
        dto.setParamValue(DaoUtil.convertNullToString(rs.getString("paramValue")));
        return dto;
    }

    public List<CsmSheetParamDto> selectAll() {

        final String sql = "select " + ALLCOLS + " from CSM_SHEET_PARAM order by PARAM_SET_CD, PARAM_ID";
        Log.sql("[DaoMethod Call] CsmSheetParamDao.selectAll");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            List<CsmSheetParamDto> lst = new ArrayList<CsmSheetParamDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

