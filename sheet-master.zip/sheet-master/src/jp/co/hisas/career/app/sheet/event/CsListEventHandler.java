package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import jp.co.hisas.career.app.sheet.dao.CsmSheetFormGrpDao;
import jp.co.hisas.career.app.sheet.dao.VCstSheetListDao;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFormGrpDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetListDto;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.VPersonBelongUnionDao;
import jp.co.hisas.career.util.dao.useful.ValueTextSortDao;
import jp.co.hisas.career.util.dto.VPersonBelongUnionDto;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;
import jp.co.hisas.career.util.log.Log;

public class CsListEventHandler extends AbstractEventHandler<CsListEventArg, CsListEventResult> {
	
	private String loginNo;
	private String party;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static CsListEventResult exec( CsListEventArg arg ) throws CareerException {
		CsListEventHandler handler = new CsListEventHandler();
		return handler.call( arg );
	}
	
	public CsListEventResult call( CsListEventArg arg ) throws CareerException {
		CsListEventResult result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CsListEventResult execute( CsListEventArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		this.party = arg.party;
		
		CsListEventResult result = new CsListEventResult();
		
		try {
			
			if ("PREPARE".equals( arg.sharp )) {
				
				// 分類リストの取得
				List<ValueTextSortDto> divList = getDivList( arg );
				result.setDivList( divList );
				
				// 運用リストの取得
				List<ValueTextSortDto> opeList = getOpeList( arg );
				result.setOpeList( opeList );
				
			}
			else if ("INIT".equals( arg.sharp )) {
				
				List<VCstSheetListDto> singleDtoList = getHonninSheetList( arg.personId, arg.formGrps, arg.opeType );
				result.setSingleDtoList( singleDtoList );
			}
			else if ("CHANGE_OPERATION".equals( arg.sharp )) {
				
				// フローステータスリストの取得
				List<ValueTextSortDto> staList = null;
				if (!CsUtil.isBlank( arg.srchCondMap.get( "SrchCondOperationCd" ) )) {
					staList = getStatusList( arg );
				}
				result.staList = staList;
			}
			else if ("LIST_ON_ACTOR".equals( arg.sharp )) {
				
				// 分類リストの取得
				List<ValueTextSortDto> divList = getDivList( arg );
				result.setDivList( divList );
				
				// 運用リストの取得
				List<ValueTextSortDto> opeList = getOpeList( arg );
				result.setOpeList( opeList );
				
				// フローステータスリストの取得
				List<ValueTextSortDto> staList = null;
				if (!CsUtil.isBlank( arg.srchCondMap.get( "SrchCondOperationCd" ) )) {
					staList = getStatusList( arg );
				}
				result.staList = staList;
				
				List<VCstSheetListDto> singleDtoList = getSheetListOnActor( arg.personId, arg.formGrps, arg.srchCondMap );
				result.setSingleDtoList( singleDtoList );
			}
			else if ("LIST_ALL".equals( arg.sharp )) {
				
				// 運用リストの取得
				List<ValueTextSortDto> opeList = getOpeList( arg );
				result.setOpeList( opeList );
				
				List<VCstSheetListDto> singleDtoList = getAllSheetList( arg.formGrps, arg.statusCd, arg.srchCondMap );
				result.setSingleDtoList( singleDtoList );
			}
			else if ("MYLIST".equals( arg.sharp )) {
				
				List<VCstSheetListDto> singleDtoList = getHonninSheetList( arg.personId, arg.formGrps, arg.opeType );
				result.setSingleDtoList( singleDtoList );
			}
			
			return result;
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
	}
	
	private List<ValueTextSortDto> getDivList( CsListEventArg arg ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select PD_VALUE as value, PD_TEXT as text, LPAD_SORT as sort " );
		sql.append( "   from PULLDOWN_MASTER " );
		sql.append( "  where PD_SET_CD = 'ClsC' " );
		sql.append( "  order by LPAD_SORT " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		ValueTextSortDao dao = new ValueTextSortDao( this.loginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<ValueTextSortDto> getOpeList( CsListEventArg arg ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select OP.OPERATION_CD as value, OP.OPERATION_NM as text, OP.LPAD_SORT as sort " );
		sql.append( "   from CSM_SHEET_OPERATION OP " );
		sql.append( "          inner join CSM_SHEET_FORM_GRP FG " );
		sql.append( "            on (OP.PARTY = FG.PARTY and OP.OPERATION_CD = FG.OPERATION_CD) " );
		sql.append( "  where OP.OPEN_FLG = '1' " );
		if (!CsUtil.isBlank( arg.formGrps )) {
		sql.append( "    and FG.FORM_GRP_CD IN (" + arg.formGrps + ") " );
		}
		sql.append( "  order by OP.LPAD_SORT desc " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		ValueTextSortDao dao = new ValueTextSortDao( this.loginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<ValueTextSortDto> getStatusList( CsListEventArg arg ) throws Exception {
		
		String opeCd = arg.srchCondMap.get( "SrchCondOperationCd" );
		if (opeCd == null) { return null; }
		
		/* Dynamic SQL */
		StringBuilder gsql = new StringBuilder();
		gsql.append( " select" + CsmSheetFormGrpDao.ALLCOLS );
		gsql.append( "   from CSM_SHEET_FORM_GRP " );
		gsql.append( "  where PARTY = ? " );
		gsql.append( "    and OPERATION_CD = ? " );
		gsql.append( "  order by FORM_GRP_CD " );
		
		/* Parameter List */
		ArrayList<String> gParamList = new ArrayList<String>();
		gParamList.add( arg.party );
		gParamList.add( opeCd );
		
		CsmSheetFormGrpDao gDao = new CsmSheetFormGrpDao( this.loginNo );
		List<CsmSheetFormGrpDto> gDtoList = gDao.selectDynamic( DaoUtil.getPstmt( gsql, gParamList ) );
		CsmSheetFormGrpDto gDto = gDtoList.get( 0 );
		String formGrpCd = gDto.getFormGrpCd();
		if (formGrpCd == null) { return null; }
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select STATUS_CD as value, STATUS_NM as text, SEQ_NO as sort " );
		sql.append( "   from CSM_SHEET_FLOW " );
		sql.append( "  where FLOW_CD = ? " );
		sql.append( "  order by SEQ_NO " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		String flowCd = formGrpCd.replaceAll( "^grp-", "flw-" );
		paramList.add( flowCd );
		
		ValueTextSortDao dao = new ValueTextSortDao( this.loginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<VCstSheetListDto> getHonninSheetList( String personId, String formGrps, String opeType ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + CsUtil.addPrefixOnDaoAllCols( "V", VCstSheetListDao.ALLCOLS ) );
		sql.append( "   from V_CST_SHEET_LIST V " );
		if (SU.equals( opeType, "STAMP" )) {
			sql.append( "   inner join ( " );
			sql.append( "       select OPERATION_CD " );
			sql.append( "         from CSM_SHEET_OPERATION " );
			sql.append( "        where OPERATION_TYPE = 'STAMP' ) CSM " );
			sql.append( "           on CSM.OPERATION_CD = V.OPERATION_CD " );
		}
		sql.append( "  where V.PARTY = ? and V.OWN_GUID = ? " );
		
		if (formGrps != null) {
			sql.append( "   and V.FORM_GRP_CD in (" + formGrps + ") " );
		}
		sql.append( " order by V.OPERATION_SORT desc, V.SHEET_SORT " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.party );
		paramList.add( personId );
		
		VCstSheetListDao dao = new VCstSheetListDao( this.loginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<VCstSheetListDto> getSheetListOnActor( String personId, String formGrps, HashMap<String, String> srchCondMap ) throws Exception {
		
		String targetTable = "";
		String hold = "";
		if (srchCondMap != null) {
			if (srchCondAvailable( srchCondMap, "SrchCondStatus" )) {
				// ALL or ACTOR or HOLD
				String scStatus = srchCondMap.get( "SrchCondStatus" );
				if ("ALL".equals( scStatus )) {
					targetTable = "V_CST_SHEET_ACTOR_AND_REF";
				} else if ("ACTOR".equals( scStatus )) {
					targetTable = "CST_SHEET_ACTOR";
				} else if ("HOLD".equals( scStatus )) {
					targetTable = "CST_SHEET_ACTOR";
					hold = "and HOLD_PERSON_ID = '" + personId + "'";
				}
			}
		}
		if ("".equals( targetTable )) {
			targetTable = "V_CST_SHEET_ACTOR_AND_REF";
		}
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + VCstSheetListDao.ALLCOLS );
		sql.append( " from ( " );
		sql.append( "   select L.*, CP.PERSON_ID as COND_PERSON_ID, CP.PERSON_NAME as COND_PERSON_NAME " );
		sql.append( "     from V_CST_SHEET_LIST L " );
		sql.append( "          inner join (select distinct SHEET_ID from " + targetTable + " where PERSON_ID = ?) S " );		paramList.add( personId );
		sql.append( "            on (S.SHEET_ID = L.SHEET_ID and L.COMPANY_CD  = ? " + hold );						paramList.add( this.party );
		sql.append( "            and L.PERSON_ID <> ? ) " );														paramList.add( personId );
		sql.append( "          inner join CA_REGIST CP " );
		sql.append( "            on (CP.PERSON_ID = L.PERSON_ID) " );
		sql.append( "          inner join ( " );
		sql.append( "            select distinct PERSON_ID " );
		sql.append( "              from V_PERSON_BELONG " ); // 見えるデータで絞られるよう本務のみを対象としておく
		sql.append( "             where 1 = 1 " );
		if (srchCondMap != null) {
				
			if (srchCondAvailable( srchCondMap, "SrchCondShozoku" )) {
				sql.append( "   and DEPT_NM like ? " );
				paramList.add( "%" + srchCondMap.get( "SrchCondShozoku" ) + "%" );
			}
			if (srchCondAvailable( srchCondMap, "SrchCondMibun" )) {
				sql.append( "   and CLS_C_CD = ? " );
				paramList.add( srchCondMap.get( "SrchCondMibun" ) );
			}
		}
		sql.append( "          ) BEL on ( L.PERSON_ID = BEL.PERSON_ID ) " );
		sql.append( " ) " );
		sql.append( " where 1 = 1 " );
		
		if (formGrps != null) {
			sql.append( " and FORM_GRP_CD in (" + formGrps + ") " );
		}
		
		if (srchCondMap != null) {
			if (srchCondAvailable( srchCondMap, "SrchCondStatusCd" )) {
				sql.append( "   and STATUS_CD = ? " );
				paramList.add( srchCondMap.get( "SrchCondStatusCd" ) );
			}
			if (srchCondAvailable( srchCondMap, "SrchCondPersonId" )) {
				sql.append( "   and COND_PERSON_ID like ? " );
				paramList.add( "%" + srchCondMap.get( "SrchCondPersonId" ) + "%" );
			}
			if (srchCondAvailable( srchCondMap, "SrchCondPersonNm" )) {
				sql.append( "   and COND_PERSON_NAME like ? " );
				paramList.add( "%" + srchCondMap.get( "SrchCondPersonNm" ) + "%" );
			}
			if (srchCondAvailable( srchCondMap, "SrchCondOperationCd" )) {
				sql.append( "   and OPERATION_CD = ? " );
				paramList.add( srchCondMap.get( "SrchCondOperationCd" ) );
			}
		}
		sql.append( " order by OPERATION_SORT desc, SHEET_SORT, PERSON_ID " );
		
		VCstSheetListDao dao = new VCstSheetListDao( this.loginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<VCstSheetListDto> getAllSheetList( String formGrps, String statusCd, HashMap<String, String> srchCondMap ) throws Exception {
		
		StringBuilder sql;
		ArrayList<String> paramList;
		
		/* Dynamic SQL */
		sql = new StringBuilder();
		sql.append( " select" + VPersonBelongUnionDao.ALLCOLS );
		sql.append( "   from V_PERSON_BELONG_UNION" );
		sql.append( "  where STF_NO = ?" );
		
		/* Parameter List */
		paramList = new ArrayList<String>();
		paramList.add( this.loginNo );
		
		VPersonBelongUnionDao vdao = new VPersonBelongUnionDao( this.loginNo );
		List<VPersonBelongUnionDto> belList = vdao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		
		String deptWhere = "";
		if (belList.size() > 0) {
			String deptIn = this.convListToSqlInVal( belList );
			deptWhere = "and DEPT_CD IN (" + deptIn + ")";
		}
		
		/* Parameter List */
		paramList = new ArrayList<String>();
		
		/* Dynamic SQL */
		sql = new StringBuilder();
		sql.append( " select" + VCstSheetListDao.ALLCOLS );
		sql.append( " from ( " );
		sql.append( "   select L.*, ATTR.DEPT_NM, ATTR.HIERARCHY " );
		sql.append( "   from V_CST_SHEET_LIST L " );
		sql.append( "     inner join CST_SHEET_ATTR ATTR on (ATTR.SHEET_ID = L.SHEET_ID) " );
		if (formGrps != null) {
			sql.append( " where L.FORM_GRP_CD in (" + formGrps + ") " );
		}
		sql.append( " ) Z " );
		sql.append( " where PARTY  = ? " );															paramList.add( this.party );
		if (statusCd != null) {
			sql.append( " and STATUS_CD  = ? " );															paramList.add( statusCd );
		}
		if (srchCondMap != null) {
			if (srchCondAvailable( srchCondMap, "SrchCondOperationCd" )) {
				sql.append( "   and OPERATION_CD = ? " );
				paramList.add( srchCondMap.get( "SrchCondOperationCd" ) );
			}
			if (srchCondAvailable( srchCondMap, "SrchCondShozoku" )) {
				sql.append( "   and DEPT_NM like ? " );
				paramList.add( "%" + srchCondMap.get( "SrchCondShozoku" ) + "%" );
			}
			if (srchCondAvailable( srchCondMap, "SrchCondStatus" )) {
				// ALL or ACTOR or HOLD
				String scStatus = srchCondMap.get( "SrchCondStatus" );
				if ("ALL".equals( scStatus )) {
					sql.append( " and ( " );
					sql.append( "   HIERARCHY >= (select DEPT_HIER_RANK from CA_REGIST where PERSON_ID = ?) " );	paramList.add( this.loginNo );
					sql.append( " ) " );
				}
			}
		}
		sql.append( deptWhere );
		sql.append( " order by OPERATION_SORT desc, SHEET_SORT" );
		
		VCstSheetListDao dao = new VCstSheetListDao( this.loginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private boolean srchCondAvailable( HashMap<String, String> srchCondMap, String key ) {
		if (srchCondMap == null) {
			return false;
		}
		if (!srchCondMap.containsKey( key )) {
			return false;
		}
		String val = srchCondMap.get( key );
		if (val == null || "".equals( val )) {
			return false;
		}
		return true;
	}
	
	public String convListToSqlInVal( List<VPersonBelongUnionDto> inList ) {
		if (inList == null || inList.size() == 0) {
			return "''";
		}
		StringBuilder sql = new StringBuilder();
		for (int i=0; i<inList.size(); i++) {
			if (i==0) {
				sql.append( "'" + inList.get( i ).getDeptCd() + "'" );
			}
			else {
				sql.append( ",'" + inList.get( i ).getDeptCd() + "'" );
			}
		}
		return sql.toString();
	}
	
}
