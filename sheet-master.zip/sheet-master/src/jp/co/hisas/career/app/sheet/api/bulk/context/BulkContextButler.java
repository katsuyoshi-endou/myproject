package jp.co.hisas.career.app.sheet.api.bulk.context;

import jp.co.hisas.career.app.sheet.api.Butler;
import jp.co.hisas.career.app.sheet.deliver.DeliverOrder;
import jp.co.hisas.career.app.sheet.deliver.bulk.context.BulkContextGetDeliver;
import jp.co.hisas.career.app.sheet.deliver.bulk.context.BulkContextGetOrder;
import jp.co.hisas.career.app.sheet.deliver.bulk.context.BulkContextPutDeliver;
import jp.co.hisas.career.app.sheet.deliver.bulk.context.BulkContextPutOrder;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class BulkContextButler extends Butler {
	
	@Override
	public String takeGET( Tray tray ) throws CareerException {
		
		BulkContextGetOrder order = new BulkContextGetOrder( tray );
		order.operationCd = tray.getSessionAttr( CsSessionKey.CS_BULK_OPERATION_CD );
		
		BulkContextEvRslt rslt = BulkContextGetDeliver.go( tray, order );
		
		rslt.liveConditions = tray.getSessionAttr( CsSessionKey.CS_BULK_LIVE_CONDITIONS );
		rslt.pageState = tray.getSessionAttr( CsSessionKey.CS_BULK_PAGE_STATE );
		
		return SU.toJson( rslt );
	}
	
	@Override
	public String takePOST( Tray tray ) throws CareerException {
		return null;
	}
	
	@Override
	public String takePUT( Tray tray ) throws CareerException {
		BulkContextPutOrder order = DeliverOrder.fromJson( tray, BulkContextPutOrder.class );
		order.init( tray );
		BulkContextEvRslt rslt = BulkContextPutDeliver.go( tray, order );
		return SU.toJson( rslt );
	}
	
	@Override
	public String takeDELETE( Tray tray ) throws CareerException {
		return null;
	}
}
