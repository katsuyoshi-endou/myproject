/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CstSheetExclusiveDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " SHEET_ID as sheetId,"
                     + " EXCLUSIVE_KEY as exclusiveKey"
                     ;

    public CstSheetExclusiveDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CstSheetExclusiveDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public void insert(CstSheetExclusiveDto dto) {

        final String sql = "INSERT INTO CST_SHEET_EXCLUSIVE ("
                         + "SHEET_ID,"
                         + "EXCLUSIVE_KEY"
                         + ")VALUES(?,? )"
                         ;
        Log.sql("[DaoMethod Call] CstSheetExclusiveDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getSheetId());
            DaoUtil.setIntToPreparedStatement(pstmt, 2, dto.getExclusiveKey());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void update(CstSheetExclusiveDto dto) {

        final String sql = "UPDATE CST_SHEET_EXCLUSIVE SET "
                         + "EXCLUSIVE_KEY = ?"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CstSheetExclusiveDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setIntToPreparedStatement(pstmt, 1, dto.getExclusiveKey());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getSheetId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public CstSheetExclusiveDto select(String sheetId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CST_SHEET_EXCLUSIVE"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CstSheetExclusiveDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            rs = pstmt.executeQuery();
            CstSheetExclusiveDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    private CstSheetExclusiveDto transferRsToDto(ResultSet rs) throws SQLException {

        CstSheetExclusiveDto dto = new CstSheetExclusiveDto();
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setExclusiveKey(rs.getInt("exclusiveKey"));
        return dto;
    }

}

