/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CsmSheetLabelDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String labelSetCd;
    private String labelId;
    private String labelText;
    private String labelTextL2;
    private String labelTextL3;

    public String getLabelSetCd() {
        return labelSetCd;
    }

    public void setLabelSetCd(String labelSetCd) {
        this.labelSetCd = labelSetCd;
    }

    public String getLabelId() {
        return labelId;
    }

    public void setLabelId(String labelId) {
        this.labelId = labelId;
    }

    public String getLabelText() {
        return labelText;
    }

    public void setLabelText(String labelText) {
        this.labelText = labelText;
    }

    public String getLabelTextL2() {
        return labelTextL2;
    }

    public void setLabelTextL2(String labelTextL2) {
        this.labelTextL2 = labelTextL2;
    }

    public String getLabelTextL3() {
        return labelTextL3;
    }

    public void setLabelTextL3(String labelTextL3) {
        this.labelTextL3 = labelTextL3;
    }

}

