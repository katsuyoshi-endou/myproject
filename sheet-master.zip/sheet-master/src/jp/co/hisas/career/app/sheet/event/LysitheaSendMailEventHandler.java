package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.Map;

import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.MailInfoDao;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.CommonParameter;

public class LysitheaSendMailEventHandler extends AbstractEventHandler<LysitheaSendMailEventArg, LysitheaSendMailEventResult> {
	
	private String originGuid;
	private String daoLoginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static LysitheaSendMailEventResult exec( LysitheaSendMailEventArg arg ) throws CareerException {
		LysitheaSendMailEventHandler handler = new LysitheaSendMailEventHandler();
		return handler.call( arg );
	}
	
	public LysitheaSendMailEventResult call( LysitheaSendMailEventArg arg ) throws CareerException {
		LysitheaSendMailEventResult result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected LysitheaSendMailEventResult execute( LysitheaSendMailEventArg arg ) throws CareerException {
		
		arg.validateArg();
		this.originGuid = arg.getLoginNo();
		this.daoLoginNo = arg.getLoginNo();
		
		LysitheaSendMailEventResult result = new LysitheaSendMailEventResult();
		
		try {
			
			if ("SEND".equals( arg.sharp )) {
				
				String fromMailAddress = AU.getCareerProperty( "LYSITHEA_SENDMAIL_FROM" );
				String subject  = CsUtil.btb( CommonParameter.getValue( CommonParameter.BUNRUI_PLAN, "MailSubject_" + arg.mailTemplateId ) );
				String textBody = CsUtil.btb( CommonParameter.getValue( CommonParameter.BUNRUI_PLAN, "MailBody_"    + arg.mailTemplateId ) );
				
				for (Map.Entry<String, String> entry : arg.replaceMap.entrySet()) {
					String key = entry.getKey();
					String val = SU.ntb( entry.getValue() );
					// #{key} -> val
					textBody = textBody.replaceAll( "\\#\\{" + key + "\\}", val );
				}
				
				String sendTimestamp = CsUtil.getTimestamp( "yyyy/MM/dd HH:mm:ss" );
				
				/* Dynamic SQL */
				StringBuilder sql = new StringBuilder();
				sql.append( " insert into MAIL_INFO (SEND_NO, STATUS, FROM_ADDRESS, TO_ADDRESS, TITLE, BODY, ACTION_PERSON_ID, UPDATE_DATE) " );
				sql.append( " select (select nvl( MAX(SEND_NO), 0 ) + 1 from MAIL_INFO) as SEND_NO ");
				sql.append( "      , 0 as STATUS ");
				sql.append( "      , ? as FROM_ADDRESS ");
				sql.append( "      , ? as TO_ADDRESS ");
				sql.append( "      , ? as TITLE ");
				sql.append( "      , ? as BODY ");
				sql.append( "      , ? as ACTION_PERSON_ID ");
				sql.append( "      , to_date(?,'YYYY/MM/DD HH24:MI:SS') as UPDATE_DATE ");
				sql.append( "   from DUAL ");
				
				/* Parameter List */
				ArrayList<String> paramList = new ArrayList<String>();
				paramList.add( fromMailAddress );
				paramList.add( arg.toMailAddress );
				paramList.add( subject );
				paramList.add( textBody );
				paramList.add( this.originGuid );
				paramList.add( sendTimestamp );
				
				MailInfoDao dao = new MailInfoDao( daoLoginNo );
				dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
			}
			
			return result;
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
	}
	
}
