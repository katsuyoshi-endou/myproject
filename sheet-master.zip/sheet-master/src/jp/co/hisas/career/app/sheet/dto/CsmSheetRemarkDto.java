/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CsmSheetRemarkDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String rangeCd;
    private Integer rangeFr;
    private Integer rangeTo;
    private String remark;

    public String getRangeCd() {
        return rangeCd;
    }

    public void setRangeCd(String rangeCd) {
        this.rangeCd = rangeCd;
    }

    public Integer getRangeFr() {
        return rangeFr;
    }

    public void setRangeFr(Integer rangeFr) {
        this.rangeFr = rangeFr;
    }

    public Integer getRangeTo() {
        return rangeTo;
    }

    public void setRangeTo(Integer rangeTo) {
        this.rangeTo = rangeTo;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

}

