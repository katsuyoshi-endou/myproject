package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CstSheetActorDto;
import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;

@SuppressWarnings("serial")
public class CsActorEventArg extends AbstractEventArg {
	
	public String sharp = null;
	public String sheetId = null;
	public String actorCd = null;
	public String personId = null;
	public List<CstSheetActorDto> actorList = null;
	public String flowCd = null;
	public String flowptn = null;
	public String operatorGuid = null;
	
	public CsActorEventArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void setAll( String sharp, String sheetId, String actorCd, String personId ) {
		this.sharp = sharp;
		this.sheetId = sheetId;
		this.actorCd = actorCd;
		this.personId = personId;
	}
	
	public void validateArg() throws CareerException {
		if (this.sharp == null || "".equals( this.sharp.trim() )) {
			throw new CareerException( "Invalid Arg: sharp is null." );
		}
	}
	
}
