package jp.co.hisas.career.app.sheet.api.bulk.context;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.api.mold.BulkConditions;
import jp.co.hisas.career.app.sheet.api.mold.BulkPageState;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFlowDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetOperationDto;
import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.PulldownMasterDto;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

public class BulkContextEvRslt extends AbstractEventResult {
	
	public int hitCount;
	public Map<String, String> uiLabelSet;
	public String operationCd;
	public List<CsmSheetOperationDto> operationMaster;
	public Map<String, List<PulldownMasterDto>> pulldownMaster;
	public BulkConditions liveConditions;
	public BulkPageState pageState;
	public List<Map<String, String>> formMaster;
	public List<Map<String, String>> statusMaster;
	public List<ValueTextSortDto> availableActorList;
	public List<ValueTextSortDto> availableFlowptnList;
	public List<Map<String, String>> actionMaster;
	public List<CsmSheetFlowDto> availableStatusList;
}
