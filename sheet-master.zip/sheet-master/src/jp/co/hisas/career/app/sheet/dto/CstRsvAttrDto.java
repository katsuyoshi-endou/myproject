/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CstRsvAttrDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sheetId;
    private String ownPersonId;
    private String ownPersonName;
    private String sheetSort;
    private String term;
    private String deptCd;
    private String deptNm;
    private String fullDeptCd;
    private String fullDeptNm;
    private Integer hierarchy;
    private String bumadeDeptCd;
    private String bumadeDeptNm;
    private String searchDiv;
    private String clsACd;
    private String clsANm;
    private String clsBCd;
    private String clsBNm;
    private String clsCCd;
    private String clsCNm;
    private String clsDCd;
    private String clsDNm;
    private String clsECd;
    private String clsENm;
    private String clsFCd;
    private String clsFNm;
    private String clsGCd;
    private String clsGNm;
    private String clsHCd;
    private String clsHNm;
    private String clsICd;
    private String clsINm;
    private String clsJCd;
    private String clsJNm;

    public String getSheetId() {
        return sheetId;
    }

    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    public String getOwnPersonId() {
        return ownPersonId;
    }

    public void setOwnPersonId(String ownPersonId) {
        this.ownPersonId = ownPersonId;
    }

    public String getOwnPersonName() {
        return ownPersonName;
    }

    public void setOwnPersonName(String ownPersonName) {
        this.ownPersonName = ownPersonName;
    }

    public String getSheetSort() {
        return sheetSort;
    }

    public void setSheetSort(String sheetSort) {
        this.sheetSort = sheetSort;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public String getDeptCd() {
        return deptCd;
    }

    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    public String getDeptNm() {
        return deptNm;
    }

    public void setDeptNm(String deptNm) {
        this.deptNm = deptNm;
    }

    public String getFullDeptCd() {
        return fullDeptCd;
    }

    public void setFullDeptCd(String fullDeptCd) {
        this.fullDeptCd = fullDeptCd;
    }

    public String getFullDeptNm() {
        return fullDeptNm;
    }

    public void setFullDeptNm(String fullDeptNm) {
        this.fullDeptNm = fullDeptNm;
    }

    public Integer getHierarchy() {
        return hierarchy;
    }

    public void setHierarchy(Integer hierarchy) {
        this.hierarchy = hierarchy;
    }

    public String getBumadeDeptCd() {
        return bumadeDeptCd;
    }

    public void setBumadeDeptCd(String bumadeDeptCd) {
        this.bumadeDeptCd = bumadeDeptCd;
    }

    public String getBumadeDeptNm() {
        return bumadeDeptNm;
    }

    public void setBumadeDeptNm(String bumadeDeptNm) {
        this.bumadeDeptNm = bumadeDeptNm;
    }

    public String getSearchDiv() {
        return searchDiv;
    }

    public void setSearchDiv(String searchDiv) {
        this.searchDiv = searchDiv;
    }

    public String getClsACd() {
        return clsACd;
    }

    public void setClsACd(String clsACd) {
        this.clsACd = clsACd;
    }

    public String getClsANm() {
        return clsANm;
    }

    public void setClsANm(String clsANm) {
        this.clsANm = clsANm;
    }

    public String getClsBCd() {
        return clsBCd;
    }

    public void setClsBCd(String clsBCd) {
        this.clsBCd = clsBCd;
    }

    public String getClsBNm() {
        return clsBNm;
    }

    public void setClsBNm(String clsBNm) {
        this.clsBNm = clsBNm;
    }

    public String getClsCCd() {
        return clsCCd;
    }

    public void setClsCCd(String clsCCd) {
        this.clsCCd = clsCCd;
    }

    public String getClsCNm() {
        return clsCNm;
    }

    public void setClsCNm(String clsCNm) {
        this.clsCNm = clsCNm;
    }

    public String getClsDCd() {
        return clsDCd;
    }

    public void setClsDCd(String clsDCd) {
        this.clsDCd = clsDCd;
    }

    public String getClsDNm() {
        return clsDNm;
    }

    public void setClsDNm(String clsDNm) {
        this.clsDNm = clsDNm;
    }

    public String getClsECd() {
        return clsECd;
    }

    public void setClsECd(String clsECd) {
        this.clsECd = clsECd;
    }

    public String getClsENm() {
        return clsENm;
    }

    public void setClsENm(String clsENm) {
        this.clsENm = clsENm;
    }

    public String getClsFCd() {
        return clsFCd;
    }

    public void setClsFCd(String clsFCd) {
        this.clsFCd = clsFCd;
    }

    public String getClsFNm() {
        return clsFNm;
    }

    public void setClsFNm(String clsFNm) {
        this.clsFNm = clsFNm;
    }

    public String getClsGCd() {
        return clsGCd;
    }

    public void setClsGCd(String clsGCd) {
        this.clsGCd = clsGCd;
    }

    public String getClsGNm() {
        return clsGNm;
    }

    public void setClsGNm(String clsGNm) {
        this.clsGNm = clsGNm;
    }

    public String getClsHCd() {
        return clsHCd;
    }

    public void setClsHCd(String clsHCd) {
        this.clsHCd = clsHCd;
    }

    public String getClsHNm() {
        return clsHNm;
    }

    public void setClsHNm(String clsHNm) {
        this.clsHNm = clsHNm;
    }

    public String getClsICd() {
        return clsICd;
    }

    public void setClsICd(String clsICd) {
        this.clsICd = clsICd;
    }

    public String getClsINm() {
        return clsINm;
    }

    public void setClsINm(String clsINm) {
        this.clsINm = clsINm;
    }

    public String getClsJCd() {
        return clsJCd;
    }

    public void setClsJCd(String clsJCd) {
        this.clsJCd = clsJCd;
    }

    public String getClsJNm() {
        return clsJNm;
    }

    public void setClsJNm(String clsJNm) {
        this.clsJNm = clsJNm;
    }

}

