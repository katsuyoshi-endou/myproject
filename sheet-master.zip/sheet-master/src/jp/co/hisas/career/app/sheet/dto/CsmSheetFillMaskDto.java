/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CsmSheetFillMaskDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String maskCd;
    private String statusCd;
    private String actorCd;
    private String fillId;
    private String readOrWrite;

    public String getMaskCd() {
        return maskCd;
    }

    public void setMaskCd(String maskCd) {
        this.maskCd = maskCd;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    public String getActorCd() {
        return actorCd;
    }

    public void setActorCd(String actorCd) {
        this.actorCd = actorCd;
    }

    public String getFillId() {
        return fillId;
    }

    public void setFillId(String fillId) {
        this.fillId = fillId;
    }

    public String getReadOrWrite() {
        return readOrWrite;
    }

    public void setReadOrWrite(String readOrWrite) {
        this.readOrWrite = readOrWrite;
    }

}

