package jp.co.hisas.career.app.sheet.event;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;

@SuppressWarnings("serial")
public class CsProgressEventArg extends AbstractEventArg {
	
	public String sharp = null;
	public String sheetId = null;
	public String party = null;
	public String operationCd = null;
	public String formCode = null;
	public String guid = null;
	public String statusCode = null;
	public boolean isActiveOnly;
	public boolean isBindedOnly;
	public String opeType = null;
	
	public CsProgressEventArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void setAll( String sharp, String sheetId, String party, String operationCd, String formCode, String guid, String statusCode ) {
		this.sharp = sharp;
		this.sheetId = sheetId;
		this.party = party;
		this.operationCd = operationCd;
		this.formCode = formCode;
		this.guid = guid;
		this.statusCode = statusCode;
	}
	
	public void validateArg() throws CareerException {
		if (this.sharp == null || "".equals( this.sharp.trim() )) {
			throw new CareerException( "Invalid Arg: sharp is null." );
		}
	}
	
}
