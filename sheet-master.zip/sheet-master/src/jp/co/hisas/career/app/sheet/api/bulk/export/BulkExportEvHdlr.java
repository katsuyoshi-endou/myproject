package jp.co.hisas.career.app.sheet.api.bulk.export;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class BulkExportEvHdlr extends AbstractEventHandler<BulkExportEvArg, BulkExportEvRslt> {
	
	public static BulkExportEvRslt exec( BulkExportEvArg arg ) throws CareerException {
		BulkExportEvHdlr handler = new BulkExportEvHdlr();
		return handler.call( arg );
	}
	
	public BulkExportEvRslt call( BulkExportEvArg arg ) throws CareerException {
		return this.callEjb( arg );
	}
	
	protected BulkExportEvRslt execute( BulkExportEvArg arg ) throws CareerException {
		arg.validateArg();
		String daoLoginNo = arg.getLoginNo();
		BulkExportEvRslt result = new BulkExportEvRslt();
		
		if (SU.equals( "GET", arg.sharp )) {
			
			BulkExportLogicGet logic = new BulkExportLogicGet( daoLoginNo );
			result = logic.main( arg.orderGET );
		}
		
		return result;
	}
	
}
