package jp.co.hisas.career.app.sheet.servlet;

import jp.co.hisas.career.app.sheet.deliver.bulk.BulkPutDeliver;
import jp.co.hisas.career.app.sheet.deliver.bulk.BulkPutOrder;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.RedirectServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class CsBulkServlet extends RedirectServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "VSHBLK";
	private static final String FORWARD_PAGE = "/app/bulk/";
	
	public String serviceMain( Tray tray ) throws CareerException {
		
		if (SU.equals( tray.state, "INIT" )) {
			BulkPutOrder order = new BulkPutOrder( tray );
			order.operationCd = AU.getRequestValue( tray.request, "operationCd" );
			BulkPutDeliver.go( tray, order );
		}
		else if (SU.equals( tray.state, "RESTORE" )) {
			/* Keep CST_BULK_POOL */
		}
		
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, null, tray.state );
		
		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}
}
