/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CsxSheetStatusDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sheetId;
    private String flowCd;
    private String seqNo;
    private String statusCd;
    private String statusNm;
    private String mainActorCd;
    private String mainPersonId;
    private String mainPersonName;
    private String donePersonId;
    private String donePersonName;
    private String timestamp;

    public String getSheetId() {
        return sheetId;
    }

    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    public String getFlowCd() {
        return flowCd;
    }

    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    public String getStatusNm() {
        return statusNm;
    }

    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    public String getMainActorCd() {
        return mainActorCd;
    }

    public void setMainActorCd(String mainActorCd) {
        this.mainActorCd = mainActorCd;
    }

    public String getMainPersonId() {
        return mainPersonId;
    }

    public void setMainPersonId(String mainPersonId) {
        this.mainPersonId = mainPersonId;
    }

    public String getMainPersonName() {
        return mainPersonName;
    }

    public void setMainPersonName(String mainPersonName) {
        this.mainPersonName = mainPersonName;
    }

    public String getDonePersonId() {
        return donePersonId;
    }

    public void setDonePersonId(String donePersonId) {
        this.donePersonId = donePersonId;
    }

    public String getDonePersonName() {
        return donePersonName;
    }

    public void setDonePersonName(String donePersonName) {
        this.donePersonName = donePersonName;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

}

