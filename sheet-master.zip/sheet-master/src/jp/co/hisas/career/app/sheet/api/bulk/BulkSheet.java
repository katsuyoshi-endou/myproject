package jp.co.hisas.career.app.sheet.api.bulk;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;

public class BulkSheet implements Serializable {
	
	public String sheetId;
	public String ownPersonName;
	public String statusCd;
	public String statusNm;
	public String bulkActorCd;
	public Map<String, BulkSheetColumn> cols;
	public boolean isHold;
	public String flowPtn;
	public String exclusiveKey;
	public String wkIdx;
	public Set<String> invalidMsgList;
}
