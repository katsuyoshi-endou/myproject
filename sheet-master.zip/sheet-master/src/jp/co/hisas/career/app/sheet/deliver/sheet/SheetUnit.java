package jp.co.hisas.career.app.sheet.deliver.sheet;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.api.mold.Fill;
import jp.co.hisas.career.app.sheet.dto.CsmFillCheckDto;
import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.app.sheet.garage.ServiceUnit;
import jp.co.hisas.career.app.sheet.garage.SheetGarage;
import jp.co.hisas.career.util.SU;

public class SheetUnit extends ServiceUnit {
	
	public SheetUnit(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public boolean validateFills( String sheetId, String actorCd ) {
		SheetGarage ggSh = new SheetGarage( daoLoginNo );
		VCsInfoAttrDto ia = ggSh.getSheetInfoAttr( sheetId );
		
		/* {回答検証定義リスト}の取得 */
		List<Map<String, String>> fillValidateMaster = ggSh.getFillValidateMaster( ia.getFillSetCd() );
		
		/* {回答チェック定義リスト}の取得 */
		List<CsmFillCheckDto> fillCheckMaster = ggSh.getFillCheckMaster( ia.getFillSetCd(), ia.getStatusCd() );
		
		/* {マスク済シート回答}の取得 */
		Map<String, Fill> maskedFills = ggSh.getMaskedFillsForBulk( ia, actorCd );
		
		/* 検証状態のクリア */
		ggSh.clearFillInvalid( sheetId );
		
		/* {回答検証定義リスト}ループ */
		boolean isValidAllFills = execFillValidate( sheetId, fillValidateMaster, maskedFills );
		
		/* {回答チェック定義リスト}ループ */
		boolean isCheckOK = execFillCheck( sheetId, ia, fillCheckMaster, maskedFills );
		
		return isValidAllFills && isCheckOK;
	}
	
	private boolean execFillValidate( String sheetId, List<Map<String, String>> fillValidateMaster, Map<String, Fill> maskedFills ) {
		boolean isValidAllFills = true;
		SheetGarage ggSh = new SheetGarage( daoLoginNo );
		for (Map<String, String> fvRec : fillValidateMaster) {
			String fillId = fvRec.get( "FILL_ID" );
			Fill fill = maskedFills.get( fillId );
			if (SU.isBlank( fill.content )) {
				continue;
			}
			String regex = fvRec.get( "FORMAT_REGEX" );
			if (!SU.matches( fill.content, regex )) {
				isValidAllFills = false;
				String msgId = fvRec.get( "MSG_ID" );
				ggSh.addFillInvalid( sheetId, fillId, msgId );
			}
		}
		return isValidAllFills;
	}
	
	private boolean execFillCheck( String sheetId, VCsInfoAttrDto ia, List<CsmFillCheckDto> fillCheckMaster, Map<String, Fill> maskedFills ) {
		boolean isCheckOK = true;
		SheetGarage ggSh = new SheetGarage( daoLoginNo );
		for (CsmFillCheckDto check : fillCheckMaster) {
			boolean isError = false;
			
			Fill f = maskedFills.get( check.getFillId() );
			f = f != null ? f : new Fill( check.getFillId(), false );
			
			switch (check.getCheckMethod()) {
			case "Must":
				if (SU.isBlank( f.content )) {
					isError = true;
				}
				break;
			case "MustIfExist":
				String dependFillId = check.getArg1();
				Fill dependFill = maskedFills.get( dependFillId );
				if (SU.isNotBlank( dependFill.content ) && SU.isBlank( f.content )) {
					isError = true;
				}
				break;
			default:
				break;
			}
			
			if (isError) {
				isCheckOK = false;
				ggSh.addFillInvalid( sheetId, check.getFillId(), check.getMsgId() );
			}
		}
		return isCheckOK;
	}
	
}
