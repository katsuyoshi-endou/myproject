package jp.co.hisas.career.app.sheet.deliver.bulk;

import jp.co.hisas.career.app.sheet.deliver.DeliverOrder;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class BulkGetOrder extends DeliverOrder {
	
	public String operationCd;
	public String instCd;
	public int wkIdxFrom;
	public int wkIdxTo;
	
	public BulkGetOrder(Tray tray) {
		super( tray );
	}
	
	public void validate() throws CareerBusinessException {
		if (SU.isBlank( this.operationCd )) {
			throw new CareerBusinessException( CareerBusinessException.INVALID_ORDER );
		}
	}
}
