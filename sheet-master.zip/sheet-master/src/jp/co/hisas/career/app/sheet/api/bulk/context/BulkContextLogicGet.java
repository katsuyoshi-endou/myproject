package jp.co.hisas.career.app.sheet.api.bulk.context;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.deliver.bulk.context.BulkContextGetOrder;
import jp.co.hisas.career.app.sheet.dto.CsmSheetOperationDto;
import jp.co.hisas.career.app.sheet.garage.BulkContextGetGarage;
import jp.co.hisas.career.app.sheet.garage.BulkGetGarage;
import jp.co.hisas.career.app.sheet.garage.SheetGarage;
import jp.co.hisas.career.util.property.CommonLabel;

public class BulkContextLogicGet {
	
	private String daoLoginNo;
	
	public BulkContextLogicGet(String daoLoginNo) {
		this.daoLoginNo = daoLoginNo;
	}
	
	protected BulkContextEvRslt main( BulkContextGetOrder o ) {
		BulkContextEvRslt r = new BulkContextEvRslt();
		BulkGetGarage ggBG = new BulkGetGarage( daoLoginNo );
		BulkContextGetGarage ggBC = new BulkContextGetGarage( daoLoginNo );
		
		/* UI */
		r.hitCount = ggBG.getBulkPoolHitCount( o.sessionId );
		r.uiLabelSet = getUiLabelSet( o.party, o.langNo );
		r.operationCd = o.operationCd;
		r.operationMaster = getOperationMaster( o.party );
		r.pulldownMaster = ggBC.getPulldownMaster( o.party, o.operationCd );
		
		/* Condition Master */
		r.formMaster = getFormMasterWithLabel( o );
		r.statusMaster = getStatusMaster( o );
		
		/* Bulk Actions */
		r.availableActorList = ggBG.getAvailableActorList( o.sessionId, o.party, o.operationCd );
		r.availableFlowptnList = ggBG.getAvailableFlowptnList( o.sessionId, o.party, o.operationCd );
		r.availableStatusList = ggBG.getAvailableFlowStatusList( o.sessionId, o.party, o.operationCd );
		r.actionMaster = ggBG.getSheetActionMaster( o.party, o.operationCd );
		
		return r;
	}
	
	private Map<String, String> getUiLabelSet( String party, int langNo ) {
		return CommonLabel.getLabelsWithRegex( party, langNo, "LSHBLK_UI\\..*" );
	}
	
	private List<Map<String, String>> getStatusMaster( BulkContextGetOrder o ) {
		BulkContextGetGarage ggBC = new BulkContextGetGarage( daoLoginNo );
		List<Map<String, String>> statusMaster = ggBC.getStatusMaster( o.party, o.operationCd );
		return statusMaster;
	}
	
	private List<CsmSheetOperationDto> getOperationMaster( String party ) {
		SheetGarage ggSh = new SheetGarage( daoLoginNo );
		return ggSh.getOpenOperationMaster( party );
	}
	
	private List<Map<String, String>> getFormMasterWithLabel( BulkContextGetOrder o ) {
		BulkContextGetGarage ggBC = new BulkContextGetGarage( daoLoginNo );
		List<Map<String, String>> formMaster = ggBC.getFormMaster( o.party, o.operationCd );
		for (Map<String, String> record : formMaster) {
			/* LSHBLK_INST.<INST>.<CTG> */
			String labelId = record.get( "FORM_CTG_LABEL_ID" );
			String label = CommonLabel.getLabel( o.party, labelId, o.langNo );
			record.put( "FORM_CTG_NM", label );
			record.remove( "FORM_CTG_LABEL_ID" );
		}
		return formMaster;
	}
}
