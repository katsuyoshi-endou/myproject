package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dao.CstSheetActionLogDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetDao;
import jp.co.hisas.career.app.sheet.dto.CstSheetActionLogDto;
import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.app.sheet.garage.SheetGarage;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.OneColumnDao;
import jp.co.hisas.career.util.dao.useful.ValueTextSortDao;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;
import jp.co.hisas.career.util.log.Log;

public class CsFloodEvHdlr extends AbstractEventHandler<CsFloodEvArg, CsFloodEvRslt> {
	private String loginNo;
	
	public static CsFloodEvRslt exec( CsFloodEvArg arg ) throws CareerException {
		CsFloodEvHdlr handler = new CsFloodEvHdlr();
		return handler.call( arg );
	}
	
	public CsFloodEvRslt call( CsFloodEvArg arg ) throws CareerException {
		CsFloodEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		}
		else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CsFloodEvRslt execute( CsFloodEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		CsFloodEvRslt result = new CsFloodEvRslt();
		
		try {
			
			if (SU.equals( "PREPARE", arg.sharp )) {
				result.operationList = getOperationList( arg );
				String targetOperationCd = detectOperationCd( arg, result.operationList );
				String targetGrpCd = detectFormGrpCd( arg, targetOperationCd );
				result.statusList = getStatusList( arg, targetGrpCd );
				result.targetOperationCd = targetOperationCd;
			}
			else if (SU.equals( "SEARCH", arg.sharp )) {
				
				String targetSheetsNum = execSearch( arg );
				result.targetSheetsNum = targetSheetsNum;
			}
			else if (SU.equals( "CHANGE_OPERATION", arg.sharp )) {
				
			}
			else if (SU.matches( "CHANGE_STATUS", arg.sharp )) {
				List<String> sheetIdList = detectsheetIdList( arg );
				execRecordActionLog( arg, sheetIdList );
				execStatusBulkChange( arg );
			}
			return result;
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
	}
	
	private List<ValueTextSortDto> getOperationList( CsFloodEvArg arg ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select OPERATION_CD as value" );
		sql.append( "      , OPERATION_NM as text " );
		sql.append( "      , LPAD_SORT as sort " );
		sql.append( "   from CSM_SHEET_OPERATION " );
		sql.append( "  where PARTY = ? " );
		sql.append( "    and OPEN_FLG = '1' " );
		sql.append( "  order by LPAD_SORT desc " );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.party );
		
		ValueTextSortDao dao = new ValueTextSortDao( this.loginNo );
		List<ValueTextSortDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		return list;
	}
	
	private String detectOperationCd( CsFloodEvArg arg, List<ValueTextSortDto> operationList ) {
		String result = null;
		if (SU.isBlank( arg.slctedOperation )) {
			if (operationList.size() > 0) {
				result = operationList.get( 0 ).getValue();
			}
		}
		else {
			result = arg.slctedOperation;
		}
		return result;
	}
	
	private String detectFormGrpCd( CsFloodEvArg arg, String targetOperationCd ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select FORM_GRP_CD as text " );
		sql.append( "   from CSM_SHEET_FORM_GRP " );
		sql.append( "  where PARTY = ? " );
		sql.append( "    and OPERATION_CD = ? " );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.party );
		paramList.add( targetOperationCd );
		
		OneColumnDao dao = new OneColumnDao( this.loginNo );
		String targetGroupCd = dao.selectDynamicFirst( DaoUtil.getPstmt( sql, paramList ) );
		return targetGroupCd;
	}
	
	private List<ValueTextSortDto> getStatusList( CsFloodEvArg arg, String targetGrpCd ) {
		
		String flowCd = targetGrpCd.replaceAll( "^grp-", "flw-" );
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select STATUS_CD as value " );
		sql.append( "      , STATUS_NM as text " );
		sql.append( "      , SEQ_NO as sort " );
		sql.append( "   from CSM_SHEET_FLOW " );
		sql.append( "  where FLOW_CD = ? " );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( flowCd );
		
		ValueTextSortDao dao = new ValueTextSortDao( this.loginNo );
		List<ValueTextSortDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		
		return list;
	}
	
	public String execSearch( CsFloodEvArg arg ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select count(*) as text " );
		sql.append( "   from CST_SHEET " );
		sql.append( "  where PARTY = ? " );
		sql.append( "    and OPERATION_CD = ? " );
		sql.append( "    and STATUS_CD = ? " );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.party );
		paramList.add( arg.slctedOperation );
		paramList.add( arg.slctedStatus );
		OneColumnDao dao = new OneColumnDao( this.loginNo );
		
		return dao.selectDynamicFirst( DaoUtil.getPstmt( sql, paramList ) );
		
	}
	
	private List<String> detectsheetIdList( CsFloodEvArg arg ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select SHEET_ID as text " );
		sql.append( "   from CST_SHEET " );
		sql.append( "  where PARTY = ? " );
		sql.append( "    and OPERATION_CD = ? " );
		sql.append( "    and STATUS_CD = ? " );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.party );
		paramList.add( arg.slctedOperation );
		paramList.add( arg.beforeChangeStatus );
		OneColumnDao dao = new OneColumnDao( this.loginNo );
		
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		
	}
	
	private void execRecordActionLog( CsFloodEvArg arg, List<String> sheetIdList ) {
		SheetGarage ggSh = new SheetGarage( this.loginNo );
		
		for (String sheetID : sheetIdList) {
			VCsInfoAttrDto ia = ggSh.getSheetInfoAttr( sheetID );
			CstSheetActionLogDao dao = new CstSheetActionLogDao( this.loginNo );
			CstSheetActionLogDto dto = new CstSheetActionLogDto();
			dto.setTimestamp( CsUtil.getTimestamp() );
			dto.setSheetId( sheetID );
			dto.setFlowCd( ia.getFlowCd() );
			dto.setFlowPtn( ia.getFlowPtn() );
			dto.setStatusCd( arg.beforeChangeStatus );
			dto.setActorCd( arg.actorCd );
			dto.setLoginPersonId( arg.loginNo );
			dto.setActionCd( "BULKCHG" );
			dto.setAfterStatusCd( arg.afterChangeStatus );
			dto.setDelivMsg( arg.delivMsg );
			dao.insert( dto );
		}
	}
	
	private void execStatusBulkChange( CsFloodEvArg arg ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " update CST_SHEET " );
		sql.append( "    set STATUS_CD = ? " );
		sql.append( "  where PARTY = ? " );
		sql.append( "    and OPERATION_CD = ? " );
		sql.append( "    and STATUS_CD = ? " );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.afterChangeStatus );
		paramList.add( arg.party );
		paramList.add( arg.slctedOperation );
		paramList.add( arg.beforeChangeStatus );
		CstSheetDao dao = new CstSheetDao( this.loginNo );
		
		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
}
