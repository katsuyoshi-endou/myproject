package jp.co.hisas.career.app.sheet.garage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dao.CsmSheetFlowDao;
import jp.co.hisas.career.app.sheet.dao.CstBulkPoolDao;
import jp.co.hisas.career.app.sheet.dao.CstFillInvalidDao;
import jp.co.hisas.career.app.sheet.dao.extra.GeneralMapDao;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFlowDto;
import jp.co.hisas.career.app.sheet.dto.CstBulkPoolDto;
import jp.co.hisas.career.app.sheet.dto.CstFillInvalidDto;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.OneColumnDao;
import jp.co.hisas.career.util.dao.useful.ValueTextSortDao;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

public class BulkGetGarage extends Garage {
	
	public BulkGetGarage(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public CstBulkPoolDto getBulkPoolByPK( String sessionId, String sheetId ) {
		CstBulkPoolDao dao = new CstBulkPoolDao( daoLoginNo );
		return dao.select( sessionId, sheetId );
	}
	
	public int getBulkPoolHitCount( String sessionId ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select count('X') from CST_BULK_POOL where SESSION_ID = ? " );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( sessionId );
		
		CstBulkPoolDao dao = new CstBulkPoolDao( daoLoginNo );
		return dao.selectCountDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public void refreshBulkSheetExclusiveKey( String sessionId, int wkIdxFrom, int wkIdxTo ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " update CST_BULK_POOL bp" );
		sql.append( "    set EXC_KEY = (" );
		sql.append( "                    select nvl(ex.EXCLUSIVE_KEY, 0)" );
		sql.append( "                      from CST_BULK_POOL sub" );
		sql.append( "                           left outer join CST_SHEET_EXCLUSIVE ex" );
		sql.append( "                             on (ex.SHEET_ID = sub.SHEET_ID)" );
		sql.append( "                     where sub.SESSION_ID = ? " );
		sql.append( "                       and sub.SHEET_ID = bp.SHEET_ID" );
		sql.append( "                  )" );
		sql.append( "  where bp.SESSION_ID = ? " );
		sql.append( "    and bp.WK_IDX between ? and ? " );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( sessionId );
		paramList.add( sessionId );
		paramList.add( "" + wkIdxFrom );
		paramList.add( "" + wkIdxTo );
		
		CstBulkPoolDao dao = new CstBulkPoolDao( this.daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public List<String> fetchBulkPoolByTargetAll( String sessionId, String actorCd, String statusCd, String flowPtn ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select pl.SHEET_ID || '#' || nvl(pl.EXC_KEY, 0) as text" );
		sql.append( "   from CST_BULK_POOL pl" );
		sql.append( "        inner join CST_SHEET sh" );
		sql.append( "          on (sh.SHEET_ID = pl.SHEET_ID)" );
		sql.append( "  where pl.SESSION_ID = ? " );
		sql.append( "    and pl.ACTOR_CD = ? " );
		sql.append( "    and sh.STATUS_CD = ? " );
		sql.append( "    and sh.FLOW_PTN = ? " );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sessionId );
		paramList.add( actorCd );
		paramList.add( statusCd );
		paramList.add( flowPtn );
		
		OneColumnDao dao = new OneColumnDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public List<Map<String, String>> fetchBulkSheetList( String sessionId, String guid, int wkIdxFrom, int wkIdxTo ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select SHEET_ID, ACTOR_CD, EXC_KEY, WK_IDX " );
		sql.append( "   from CST_BULK_POOL " );
		sql.append( "  where SESSION_ID = ? and UPD_GUID = ? " );
		sql.append( "    and WK_IDX between ? and ? " );
		sql.append( "  order by WK_IDX " );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sessionId );
		paramList.add( guid );
		paramList.add( "" + wkIdxFrom );
		paramList.add( "" + wkIdxTo );
		
		String[] cols = { "SHEET_ID", "ACTOR_CD", "EXC_KEY", "WK_IDX" };
		
		GeneralMapDao dao = new GeneralMapDao( this.daoLoginNo );
		return dao.select( cols, DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public List<Map<String, String>> getBulkColumns( String instCd, String scene ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select SEQ_NO, COLUMN_ID " );
		sql.append( "   from CSM_BULK_COLUMN " );
		sql.append( "  where INST_CD = ? and SCENE = ? " );
		sql.append( "  order by SEQ_NO " );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( instCd );
		paramList.add( scene );
		
		String[] cols = { "SEQ_NO", "COLUMN_ID" };
		
		GeneralMapDao dao = new GeneralMapDao( this.daoLoginNo );
		return dao.select( cols, DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public Map<String, List<CstFillInvalidDto>> getFillInvalidList( String sessionId ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + SU.addPrefixOnDaoAllCols( "nv", CstFillInvalidDao.ALLCOLS ) );
		sql.append( "   from CST_FILL_INVALID nv" );
		sql.append( "        inner join (" );
		sql.append( "          select SHEET_ID" );
		sql.append( "            from CST_BULK_POOL" );
		sql.append( "           where SESSION_ID = ? " );
		sql.append( "        ) bp" );
		sql.append( "          on (bp.SHEET_ID = nv.SHEET_ID)" );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sessionId );
		
		CstFillInvalidDao dao = new CstFillInvalidDao( this.daoLoginNo );
		List<CstFillInvalidDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		Map<String, List<CstFillInvalidDto>> map = AU.toMap( list, "sheetId" );
		return map;
	}
	
	public List<ValueTextSortDto> getAvailableActorList( String sessionId, String party, String operationCd ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select fa.ACTOR_CD as value, fa.ACTOR_NM as text, fa.LPAD_SORT as sort" );
		sql.append( "   from V_CSM_FLOW_ACTOR fa" );
		sql.append( "        inner join (" );
		sql.append( "          select distinct ACTOR_CD" );
		sql.append( "            from CST_BULK_POOL pl" );
		sql.append( "           where SESSION_ID = ?" );
		sql.append( "        ) ac" );
		sql.append( "          on (fa.PARTY = ?" );
		sql.append( "          and fa.OPERATION_CD = ?" );
		sql.append( "          and fa.ACTOR_CD = ac.ACTOR_CD)" );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sessionId );
		paramList.add( party );
		paramList.add( operationCd );
		
		ValueTextSortDao dao = new ValueTextSortDao( this.daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public List<ValueTextSortDto> getAvailableFlowptnList( String sessionId, String party, String operationCd ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select fp.FLOW_PTN as value, fp.FLOW_PTN_NM as text, fp.LPAD_SORT as sort" );
		sql.append( "   from CSM_FLOW_PTN fp" );
		sql.append( "        inner join V_CSM_OPERATION_FLOW_MAP fl" );
		sql.append( "          on (fl.FLOW_CD = fp.FLOW_CD)" );
		sql.append( "        inner join (" );
		sql.append( "          select distinct FLOW_PTN" );
		sql.append( "            from CST_BULK_POOL bp" );
		sql.append( "                 inner join CST_SHEET sh" );
		sql.append( "                   on (sh.SHEET_ID = bp.SHEET_ID)" );
		sql.append( "           where SESSION_ID = ? " );
		sql.append( "        ) pl" );
		sql.append( "          on (pl.FLOW_PTN = fp.FLOW_PTN)" );
		sql.append( "  where fl.PARTY = ? " );
		sql.append( "    and fl.OPERATION_CD = ? " );
		sql.append( "  order by fp.LPAD_SORT" );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sessionId );
		paramList.add( party );
		paramList.add( operationCd );
		
		ValueTextSortDao dao = new ValueTextSortDao( this.daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public List<Map<String, String>> getSheetActionMaster( String party, String operationCd ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select FLOW_PTN, STATUS_CD, ACTOR_CD, LPAD_SORT, ACTION_CD, ACTION_NM " );
		sql.append( "   from CSM_SHEET_ACTION ac" );
		sql.append( "        inner join V_CSM_OPERATION_FLOW_MAP fl" );
		sql.append( "          on (fl.PARTY = ? " );
		sql.append( "          and fl.OPERATION_CD = ? " );
		sql.append( "          and fl.FLOW_CD = ac.FLOW_CD)" );
		sql.append( "  order by 1,2,3,4,5" );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( party );
		paramList.add( operationCd );
		
		String[] cols = { "FLOW_PTN", "STATUS_CD", "ACTOR_CD", "LPAD_SORT", "ACTION_CD", "ACTION_NM" };
		
		GeneralMapDao dao = new GeneralMapDao( this.daoLoginNo );
		return dao.select( cols, DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public List<CsmSheetFlowDto> getAvailableFlowStatusList( String sessionId, String party, String operationCd ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + SU.addPrefixOnDaoAllCols( "fm", CsmSheetFlowDao.ALLCOLS ) );
		sql.append( "   from CSM_SHEET_FLOW fm" );
		sql.append( "        inner join (" );
		sql.append( "          select FLOW_CD" );
		sql.append( "            from V_CSM_OPERATION_FLOW_MAP" );
		sql.append( "           where PARTY = ? " );
		sql.append( "             and OPERATION_CD = ? " );
		sql.append( "        ) fl" );
		sql.append( "          on (fl.FLOW_CD = fm.FLOW_CD)" );
		sql.append( "        inner join (" );
		sql.append( "          select distinct sh.STATUS_CD" );
		sql.append( "            from CST_BULK_POOL bp" );
		sql.append( "                 inner join CST_SHEET sh" );
		sql.append( "                   on (sh.SHEET_ID = bp.SHEET_ID)" );
		sql.append( "           where SESSION_ID = ? " );
		sql.append( "        ) fd" );
		sql.append( "          on (fd.STATUS_CD = fm.STATUS_CD)" );
		sql.append( "  order by fm.SEQ_NO" );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( party );
		paramList.add( operationCd );
		paramList.add( sessionId );
		
		CsmSheetFlowDao dao = new CsmSheetFlowDao( this.daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
}
