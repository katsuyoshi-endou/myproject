package jp.co.hisas.career.app.sheet.api.bulk.export;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.framework.def.AC;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.Log;

public class BulkExportAPI extends HttpServlet {
	
	protected ServletContext ctx = null;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	@Override
	public void doGet( HttpServletRequest req, HttpServletResponse res ) throws ServletException, IOException {
		try {
			Tray tray = new Tray( req, res );
			
			BulkExportButler butler = new BulkExportButler();
			butler.takeGET( tray );
			
			this.ctx.getRequestDispatcher( "/servlet/CsvDownloadServlet" ).forward( req, res );
			
		} catch (final Exception e) {
			Log.error( req, e );
			this.ctx.getRequestDispatcher( AC.ERROR_PAGE ).forward( req, res );
		}
	}
	
}
