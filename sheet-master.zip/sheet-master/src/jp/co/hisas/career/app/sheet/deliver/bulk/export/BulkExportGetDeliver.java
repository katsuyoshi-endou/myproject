package jp.co.hisas.career.app.sheet.deliver.bulk.export;

import jp.co.hisas.career.app.sheet.api.bulk.export.BulkExportEvArg;
import jp.co.hisas.career.app.sheet.api.bulk.export.BulkExportEvHdlr;
import jp.co.hisas.career.app.sheet.api.bulk.export.BulkExportEvRslt;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Tray;

public class BulkExportGetDeliver {
	
	public static BulkExportEvRslt go( Tray tray, BulkExportGetOrder order ) throws CareerException {
		order.validate();
		
		BulkExportEvArg arg = new BulkExportEvArg( tray.loginNo );
		arg.sharp = "GET";
		arg.orderGET = order;
		BulkExportEvRslt rslt = BulkExportEvHdlr.exec( arg );
		
		return rslt;
	}
	
}
