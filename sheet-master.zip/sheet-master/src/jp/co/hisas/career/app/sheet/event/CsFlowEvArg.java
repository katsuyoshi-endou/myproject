package jp.co.hisas.career.app.sheet.event;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.util.SU;

@SuppressWarnings("serial")
public class CsFlowEvArg extends AbstractEventArg {
	
	public String sharp = null;
	public String flowCd;
	
	public CsFlowEvArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		if (SU.isBlank( this.sharp )
		||	SU.isBlank( this.flowCd )
		) {
			throw new CareerException( "Invalid Arg: some arg is blank." );
		}
	}
	
}
