package jp.co.hisas.career.app.sheet.bean;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.CareerMenuBean;
import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.event.CsMultiEventArg;
import jp.co.hisas.career.app.sheet.event.CsMultiEventHandler;
import jp.co.hisas.career.app.sheet.event.CsMultiEventResult;
import jp.co.hisas.career.app.sheet.util.CsMultiSheet;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;

public class CsMultiSheetSearchBean {
	
	private String loginNo;
	private String operatorGuid;
	private HttpServletRequest request;
	private HttpSession session;
	
	public CsMultiSheetSearchBean(String loginNo, String operatorGuid) {
		this.loginNo = loginNo;
		this.operatorGuid = operatorGuid;
	}
	
	public void execMultiSheetSearch( String state, final HttpServletRequest req, String opeType ) throws CareerException {
		this.request = req;
		this.session = request.getSession( false );
		
		CareerMenuBean oneMenu = AU.getSessionAttr( session, AppSessionKey.CAREER_ONE_MENU );
		String party = oneMenu.party;
		String trans = oneMenu.menuTrans;
		
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( session, UserInfoBean.SESSION_KEY );
		this.operatorGuid = userInfo.getOperatorGuid();
		
		CsMultiSheet csMultiSheet = AU.getSessionAttr( session, CsSessionKey.CS_MULTI_SHEET );
		csMultiSheet = (csMultiSheet != null) ? csMultiSheet : new CsMultiSheet( loginNo, operatorGuid );
		
		/* Prepare */
		CsMultiEventResult preRslt = execEventPrepare( party, opeType );
		csMultiSheet.divList       = preRslt.divList;
		csMultiSheet.operationList = preRslt.opeList;
		
		if ("INIT".equals( state )) {
			csMultiSheet.gamenCondMap = makeSrchCondMap( party );
			// メニューから遷移時は先頭のオペレーションでデフォルト検索
			String latestOpeCd = null;
			if (csMultiSheet.operationList.size() > 0) {
				latestOpeCd = csMultiSheet.operationList.get( 0 ).getValue();
			}
			csMultiSheet.gamenCondMap.put( "operationCd", latestOpeCd );
		}
		else if ("SEARCH".equals( state )) {
			csMultiSheet.gamenCondMap = makeSrchCondMap( party );
		}
		else if ("CHANGE_OPERATION".equals( state )) {
			csMultiSheet.gamenCondMap = makeSrchCondMap( party );
			csMultiSheet.gamenCondMap.put( "search_phase", "before_search" );
			
			CsMultiEventResult searchResult = execEventChangeOperation( party, csMultiSheet.gamenCondMap );
			csMultiSheet.statusList = searchResult.staList;
			
			// 500件OVERメッセージOFF
			csMultiSheet.hitCnt = 0;
			return;
		}
		else if ("EXCEL_DL".equals( state )) {
			csMultiSheet.gamenCondMap.put( "search_limit", "UNLIMITED" );
		}
		else { // RESTORE STAY FORWARD BACKWARD
		}
		String operationCd  = csMultiSheet.gamenCondMap.get( "operationCd" );
		String formGrpCd    = csMultiSheet.gamenCondMap.get( "formGrpCd" );
		if (SU.isBlank( formGrpCd )) {
			formGrpCd = CsUtil.getOneFormGrpCd( loginNo, party, operationCd );
			csMultiSheet.gamenCondMap.put( "formGrpCd", formGrpCd );
		}
		String flowCd       = convertFormGrpCd2FlowCd( formGrpCd );
		String searchDiv    = csMultiSheet.gamenCondMap.get( "searchDiv" );
		String statusCd     = csMultiSheet.gamenCondMap.get( "statusCd" );
		
		if (!SU.matches( state, "INIT|SEARCH|CHANGE_OPERATION" )) {
			operationCd = csMultiSheet.gamenCondMap.get( "operationCd" );
			formGrpCd   = CsUtil.getOneFormGrpCd( loginNo, party, operationCd );
			statusCd    = csMultiSheet.gamenCondMap.get( "statusCd" );
		}
		
		// 自分がアクターに紐付けされているシートの一覧を取得 <<常に更新>>
		CsMultiEventResult searchResult = execEventSearch( party, operationCd, formGrpCd, statusCd, searchDiv, flowCd, csMultiSheet.gamenCondMap, trans, opeType );
		csMultiSheet.multiCsList   = searchResult.getSheetList();
		csMultiSheet.statusList    = searchResult.staList;
		csMultiSheet.hitCnt        = searchResult.hitCnt;
		
		if ("EXCEL_DL".equals( state )) {
			// 【検索後に実行】取得したシートIDリストを元にFILLを取得 ※[CST_SHEET_SRCH_RSLT]を参照している
			CsMultiEventResult listResult = execEventSheetFillData( party, operationCd, formGrpCd, statusCd );
			csMultiSheet.multiCsFillMap   = listResult.getMultiFillMap();
			csMultiSheet.multiFillMaskMap = listResult.getMultiFillMaskMap();
			
			/* CS_MULTI_SHEET (for Excel Download) */
			session.setAttribute( CsSessionKey.CS_MULTI_SHEET_XL, csMultiSheet );
		}
		else {
			/* CS_MULTI_SHEET */
			session.setAttribute( CsSessionKey.CS_MULTI_SHEET, csMultiSheet );
		}
	}
	
	private HashMap<String, String> makeSrchCondMap( String party ) {
		
		String operationCd = CsUtil.getRequestValue( request, "operationCd" );
		String operationNm = CsUtil.getCsmOperation( loginNo, party, operationCd ).getOperationNm();
		String formGrpCd   = CsUtil.getOneFormGrpCd( loginNo, party, operationCd );
		String formGrpNm   = CsUtil.getCsmFormGrp( loginNo, party, operationCd, formGrpCd ).getFormGrpNm();
		String flowCd      = convertFormGrpCd2FlowCd( formGrpCd );
		String formCtgCd   = CsUtil.getRequestValue( request, "formCtgCd" );
		String deptCd   = CsUtil.getRequestValue( request, "deptCd" );
		String companyCd   = CsUtil.getRequestValue( request, "companyCd" );
		String statusCd    = CsUtil.getRequestValue( request, "statusCd" );
		String statusNm    = CsUtil.getCsmFlow( loginNo, flowCd, statusCd ).getStatusNm();
		String retireFlg   = CsUtil.getRequestValue( request, "retireFlg" );
		String tab         = CsUtil.getMultiTab( loginNo, formGrpCd, formCtgCd, statusCd );
		String holdFilter  = CsUtil.getRequestValue( request, "holdFilter" );
		String clsBCd      = CsUtil.getRequestValue( request, "clsBCd" );
		if (SU.isBlank( holdFilter )) {
			holdFilter = "ACTOR";
		}
		
		HashMap<String, String> srchCondMap = new HashMap<String, String>();
		srchCondMap.put( "actorCd",      CsUtil.getRequestValue( request, "actorCd"      ) );
		srchCondMap.put( "clsHCd",       CsUtil.getRequestValue( request, "clsHCd"       ) );
		srchCondMap.put( "deptCd",       CsUtil.getRequestValue( request, "deptCd"       ) );
		srchCondMap.put( "deptNm",       CsUtil.getRequestValue( request, "deptNm"       ) );
		srchCondMap.put( "flowCd",       flowCd );
		srchCondMap.put( "formCtgCd",    formCtgCd );
		srchCondMap.put( "formGrpCd",    formGrpCd );
		srchCondMap.put( "formGrpNm",    formGrpNm );
		srchCondMap.put( "deptCd",       deptCd );
		srchCondMap.put( "companyCd",    companyCd );
		srchCondMap.put( "holdFilter",   holdFilter );
		srchCondMap.put( "operationCd",  operationCd );
		srchCondMap.put( "operationNm",  operationNm );
		srchCondMap.put( "personId",     CsUtil.getRequestValue( request, "personId"     ) );
		srchCondMap.put( "personNm",     CsUtil.getRequestValue( request, "personNm"     ) );
		srchCondMap.put( "searchDiv",    CsUtil.getRequestValue( request, "searchDiv"    ) );
		srchCondMap.put( "sort",         CsUtil.getRequestValue( request, "sort"         ) );
		srchCondMap.put( "sort", "sort1" );
		srchCondMap.put( "statusCd",     "" );
		srchCondMap.put( "statusCd",     CsUtil.getRequestValue( request, "statusCd"     ) );
		srchCondMap.put( "statusNm",     statusNm );
		srchCondMap.put( "retireFlg",    retireFlg );
		srchCondMap.put( "tab",          tab );
		srchCondMap.put( "clsBCd",       clsBCd );		
		return srchCondMap;
	}
	
	private String convertFormGrpCd2FlowCd( String formGrpCd ) {
		return SU.isNotBlank( formGrpCd ) ? "flw-" + CsUtil.extractWithRegex( formGrpCd, "grp-(.*)" ) : null;
	}
	
	private CsMultiEventResult execEventPrepare( String party, String opeType ) throws CareerException {
		CsMultiEventArg arg = new CsMultiEventArg( loginNo, operatorGuid );
		arg.sharp = "PREPARE";
		arg.party = party;
		arg.opeType = opeType;
		arg.srchCondMap = new HashMap<String, String>();
		return CsMultiEventHandler.exec( arg );
	}
	
	private CsMultiEventResult execEventChangeOperation( String party, HashMap<String, String> srchCondMap ) throws CareerException {
		CsMultiEventArg arg = new CsMultiEventArg( loginNo, operatorGuid );
		arg.sharp = "CHANGE_OPERATION";
		arg.party = party;
		arg.formGrps = null;
		arg.srchCondMap = srchCondMap; // needs operationCd
		return CsMultiEventHandler.exec( arg );
	}
	
	private CsMultiEventResult execEventSearch( String companyCd, String operationCd, String formGrpCd, String statusCd, String searchDiv, String flowCd, HashMap<String, String> srchCondMap, String trans, String opeType ) throws CareerException {
		CsMultiEventArg arg = new CsMultiEventArg( loginNo, operatorGuid );
		arg.setAll( "SEARCH", companyCd, operationCd, formGrpCd, statusCd, searchDiv, flowCd );
		arg.srchCondMap = srchCondMap;
		arg.trans = trans;
		arg.opeType = opeType;
		return CsMultiEventHandler.exec( arg );
	}
	
	private CsMultiEventResult execEventSheetFillData( String party, String operationCd, String formGrpCd, String statusCd ) throws CareerException {
		CsMultiEventArg arg = new CsMultiEventArg( loginNo, operatorGuid );
		arg.sharp = "FILL_DATA";
		arg.party = party;
		arg.operationCd = operationCd;
		arg.formGrpCd = formGrpCd;
		arg.statusCd = statusCd;
		return CsMultiEventHandler.exec( arg );
	}
	
//	private String chooseActorCd( String trans, String actorCd, String actorCdTaskPrimary, List<ValueTextSortDto> actorOptionList, boolean isForceAutoDetect ) {
//		String result = actorCd;
//		if (actorCd == null || isForceAutoDetect) {
//			actorCd = actorCdTaskPrimary;
//			if (CsUtil.isBlank( actorCd )) {
//				// プライマリがない、つまり残タスクシートがないステータスの場合はプルダウンの一番下
//				int maxIdx = actorOptionList.size() - 1;
//				actorCd = (actorOptionList.size() != 0) ? actorOptionList.get( maxIdx ).getValue() : "" ;
//			}
//			result = actorCd;
//		}
//		return result;
//	}
	
}
