package jp.co.hisas.career.app.sheet.clay;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.Log;

public class VueScriptClay extends HttpServlet {
	
	protected ServletContext ctx = null;
	private static final long serialVersionUID = 1L;
	
	public void init( ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	@Override
	public void service( HttpServletRequest req, HttpServletResponse res ) throws IOException, ServletException {
		try {
			Object userinfo = req.getSession( false ).getAttribute( "userinfo" );
			if (userinfo != null) {
				Tray tray = new Tray( req, res );
				AU.setReqAttr( tray.request, "tray", tray );
				String inst = AU.getRequestValue( tray.request, "inst" );
				res.setContentType( "text/javascript; charset=UTF-8" );
				res.getWriter().write( getClay( inst ) );
			}
			else {
				res.getWriter().write( "" );
			}
		} catch (Exception e) {
			Log.error( req, e );
		}
	}
	
	private static String getClay( String inst ) {
		try {
			String fullPath = AppDef.APP_DIR + "/clay/" + inst + "/" + "vue-script.bundle.js";
			String template = FileUtils.readFileToString( new File( fullPath ), "utf-8" );
			return template;
		} catch (IOException e) {
			Log.warn( e.getLocalizedMessage() );
			return null;
		}
	}
	
}
