package jp.co.hisas.career.app.sheet.deliver.bulk;

import java.util.List;

import jp.co.hisas.career.app.sheet.deliver.DeliverOrder;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class BulkPostOrder extends DeliverOrder {
	
	public String operationCd;
	public List<String> sheetList;
	public String actorCd;
	public String flowPtn;
	public String statusCd;
	public String actionCd;
	public boolean isTargetAll;
	
	public BulkPostOrder(Tray tray) {
		super( tray );
	}
	
	public void validate() throws CareerBusinessException {
		if (SU.isBlank( this.operationCd )) {
			throw new CareerBusinessException( CareerBusinessException.INVALID_ORDER );
		}
	}
}
