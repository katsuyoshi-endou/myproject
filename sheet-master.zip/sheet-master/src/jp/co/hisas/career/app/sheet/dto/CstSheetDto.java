/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CstSheetDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sheetId;
    private String party;
    private String operationCd;
    private String formCd;
    private String ownGuid;
    private String statusCd;
    private String flowPtn;

    public String getSheetId() {
        return sheetId;
    }

    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getOperationCd() {
        return operationCd;
    }

    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    public String getFormCd() {
        return formCd;
    }

    public void setFormCd(String formCd) {
        this.formCd = formCd;
    }

    public String getOwnGuid() {
        return ownGuid;
    }

    public void setOwnGuid(String ownGuid) {
        this.ownGuid = ownGuid;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    public String getFlowPtn() {
        return flowPtn;
    }

    public void setFlowPtn(String flowPtn) {
        this.flowPtn = flowPtn;
    }

}

