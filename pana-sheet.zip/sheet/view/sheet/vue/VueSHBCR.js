function mountVueSHBCR(vm, loginUser) {
  ES6Promise.polyfill();

  var app = new Vue({
    el: '#VueSHBCR',
    data: {
      vm: vm,
      loginUser: loginUser,
      lbl: App.LabelMap,
      checkedSheets: [],
      isBulkChecked: false
    },
    computed: {
      showingSheetList: function () {
        return this.vm._data.list;
      },
      showingLangList: function() {
        return this.vm._data.lang
      },
    },
    mounted: function () {
    },
    updated: function () {
    },
    methods: {
      toggleBulk: function() {
        if(!this.isBulkChecked){
          this.checkedSheets = [];
        } else {
          // 「未作成」ステータスのObject配列を作ってから、ownGuidの配列に格納
          var arry = _.filter( vm._data.list, function( sheet ){
            return sheet.sheetStatus === "99";
          });
          this.checkedSheets = _.pluck( arry, 'ownGuid' );
        }
      }
    }
  });

}
