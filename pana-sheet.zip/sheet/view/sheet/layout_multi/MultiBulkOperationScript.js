function execBulkOperSheetJQuery(vm) {

  /**
   ** Initialize
  **/
  /* 入力した検索条件の復元 */
  $( 'input[name="knskPersonId"]'    ).val( vm.jotaiMap.knskPersonId );
  $( 'input[name="knskDeptNm"]'      ).val( vm.jotaiMap.knskDeptNm );
  $( 'select[name="knskOperationCd"]' ).val( vm.jotaiMap.knskOperationCd );
  $( 'input[name="knskPersonNm"]'    ).val( vm.jotaiMap.knskPersonNm );
  $( 'select[name="knskCmpaCd"]'      ).val( vm.jotaiMap.knskCmpaCd );
  $( 'select[name="knskStatusCd"]'    ).val( vm.jotaiMap.knskStatusCd );

  if ( vm._data.list.length == 0 ) {
    $('.hideTgt').css('display', 'none');
  }

  /**
   ** Event
  **/

  $('.ope-board .whitebd input').keypress(function(e){
    // Enter Key
    if ((e.which && e.which == 13) || (e.keyCode && e.keyCode == 13)) {
      $( '#btnSEARCH' ).click();
    }
  });

  /**
   * 「検索」ボタン押下
   */
  $(document).on( 'click', '#btnSEARCH', function(){
    var operCd = $( "select[name='knskOperationCd']" ).val();
    if ( operCd === "" ) {
    	alert( vm.vlMap.LSHBLK_ALERT_01 );
    	return false;
    }
    
    pageSubmit('/servlet/BulkOperSheetServlet', 'SEARCH');
  });

  /**
   * 「評価シート」ドロップダウン変更
   */
  $('select[name="knskOperationCd"]').bind('change', function(){
    pageSubmit('/servlet/BulkOperSheetServlet', 'CHANGE_OPERATION');
  });

  /**
   * 「Excelダウンロード」ボタン押下
   */
  $(document).on('click', '#xldownload', function(e){
    e.preventDefault();

    var sqlprop = $(this).attr('data-sqlprop');
    if (sqlprop == '') {
      return false;
    }
    downloadXlsxFileWithSqlprop( vm.jotaiMap.operationCd, "", sqlprop );
  });
}

function downloadXlsxFileWithSqlprop(xlTemplatePrefix, xlTemplateId, sqlPropKey) {
  if (!chkTimeout()) { return false; }

  var operCd = $( "select[name='knskOperationCd']" ).val();
  if ( operCd === "" ) {
	  return false;
  }

  // "20xxT-evaluatee"の形式に
  var templatePrefix = operCd.substr( 0, 5 ) + "-evaluatee";
  
  document.F001.action = App.root + "/servlet/BulkOperSheetServlet";
  document.F001.state.value = "EXCEL_DL";
  makeRequestParameter( "xlTemplateType", 'SQLPROP' );
  makeRequestParameter( "xlTemplatePrefix", templatePrefix );
  makeRequestParameter( "xlTemplateId", "list" );
  makeRequestParameter( "sqlPropKey", sqlPropKey );
  document.F001.target = "_self";
  document.F001.submit();
  showBlockingOverlay();
}

function applyChangeActor( guid, operType ) {
  makeRequestParameter( "chgGuid", guid );

  pageSubmit( '/servlet/CsActorServlet', operType );
}

function applyChangeRefer( guid, operType ) {
  makeRequestParameter( "chgGuid", guid );

  pageSubmit( '/servlet/CsActorServlet', operType );
}
