/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSXシートステータス進捗 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsxSheetStatusProgressDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PARTY
     */
    private String party;
    /**
     * 運用コード
     */
    private String operationCd;
    /**
     * 書式グループコード
     */
    private String formGrpCd;
    /**
     * シーケンスNo
     */
    private String seqNo;
    /**
     * ステータスコード
     */
    private String statusCd;
    /**
     * ステータス名称
     */
    private String statusNm;
    /**
     * シートカウント
     */
    private Integer sheetCount;

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * 運用コードを取得する。
     * @return 運用コード
     */
    public String getOperationCd() {
        return operationCd;
    }

    /**
     * 運用コードを設定する。
     * @param operationCd 運用コード
     */
    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    /**
     * 書式グループコードを取得する。
     * @return 書式グループコード
     */
    public String getFormGrpCd() {
        return formGrpCd;
    }

    /**
     * 書式グループコードを設定する。
     * @param formGrpCd 書式グループコード
     */
    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    /**
     * シーケンスNoを取得する。
     * @return シーケンスNo
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * シーケンスNoを設定する。
     * @param seqNo シーケンスNo
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * ステータスコードを取得する。
     * @return ステータスコード
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * ステータスコードを設定する。
     * @param statusCd ステータスコード
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * ステータス名称を取得する。
     * @return ステータス名称
     */
    public String getStatusNm() {
        return statusNm;
    }

    /**
     * ステータス名称を設定する。
     * @param statusNm ステータス名称
     */
    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    /**
     * シートカウントを取得する。
     * @return シートカウント
     */
    public Integer getSheetCount() {
        return sheetCount;
    }

    /**
     * シートカウントを設定する。
     * @param sheetCount シートカウント
     */
    public void setSheetCount(Integer sheetCount) {
        this.sheetCount = sheetCount;
    }

}

