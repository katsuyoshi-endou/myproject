package jp.co.hisas.career.app.sheet.event;

import java.util.List;
import java.util.Set;

import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class MultiCheckJinikEvRslt extends AbstractEventResult {

	public Set<String> chkNgSheetIdSet;

}