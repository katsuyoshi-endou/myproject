/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CST_RSV_ACTOR Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CstRsvActorDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * SHEET_ID
     */
    private String sheetId;
    /**
     * A01_ACTOR_CD
     */
    private String a01ActorCd;
    /**
     * A01_PERSON_ID
     */
    private String a01PersonId;
    /**
     * A02_ACTOR_CD
     */
    private String a02ActorCd;
    /**
     * A02_PERSON_ID
     */
    private String a02PersonId;
    /**
     * A03_ACTOR_CD
     */
    private String a03ActorCd;
    /**
     * A03_PERSON_ID
     */
    private String a03PersonId;
    /**
     * A04_ACTOR_CD
     */
    private String a04ActorCd;
    /**
     * A04_PERSON_ID
     */
    private String a04PersonId;
    /**
     * A05_ACTOR_CD
     */
    private String a05ActorCd;
    /**
     * A05_PERSON_ID
     */
    private String a05PersonId;
    /**
     * A06_ACTOR_CD
     */
    private String a06ActorCd;
    /**
     * A06_PERSON_ID
     */
    private String a06PersonId;
    /**
     * A07_ACTOR_CD
     */
    private String a07ActorCd;
    /**
     * A07_PERSON_ID
     */
    private String a07PersonId;
    /**
     * A08_ACTOR_CD
     */
    private String a08ActorCd;
    /**
     * A08_PERSON_ID
     */
    private String a08PersonId;
    /**
     * A09_ACTOR_CD
     */
    private String a09ActorCd;
    /**
     * A09_PERSON_ID
     */
    private String a09PersonId;
    /**
     * A10_ACTOR_CD
     */
    private String a10ActorCd;
    /**
     * A10_PERSON_ID
     */
    private String a10PersonId;
    /**
     * A11_ACTOR_CD
     */
    private String a11ActorCd;
    /**
     * A11_PERSON_ID
     */
    private String a11PersonId;
    /**
     * A12_ACTOR_CD
     */
    private String a12ActorCd;
    /**
     * A12_PERSON_ID
     */
    private String a12PersonId;
    /**
     * A13_ACTOR_CD
     */
    private String a13ActorCd;
    /**
     * A13_PERSON_ID
     */
    private String a13PersonId;
    /**
     * A14_ACTOR_CD
     */
    private String a14ActorCd;
    /**
     * A14_PERSON_ID
     */
    private String a14PersonId;
    /**
     * A15_ACTOR_CD
     */
    private String a15ActorCd;
    /**
     * A15_PERSON_ID
     */
    private String a15PersonId;
    /**
     * R01_PERSON_ID
     */
    private String r01PersonId;
    /**
     * R02_PERSON_ID
     */
    private String r02PersonId;
    /**
     * R03_PERSON_ID
     */
    private String r03PersonId;
    /**
     * R04_PERSON_ID
     */
    private String r04PersonId;
    /**
     * R05_PERSON_ID
     */
    private String r05PersonId;
    /**
     * R06_PERSON_ID
     */
    private String r06PersonId;
    /**
     * R07_PERSON_ID
     */
    private String r07PersonId;
    /**
     * R08_PERSON_ID
     */
    private String r08PersonId;
    /**
     * R09_PERSON_ID
     */
    private String r09PersonId;
    /**
     * R10_PERSON_ID
     */
    private String r10PersonId;
    /**
     * R11_PERSON_ID
     */
    private String r11PersonId;
    /**
     * R12_PERSON_ID
     */
    private String r12PersonId;
    /**
     * R13_PERSON_ID
     */
    private String r13PersonId;
    /**
     * R14_PERSON_ID
     */
    private String r14PersonId;
    /**
     * R15_PERSON_ID
     */
    private String r15PersonId;

    /**
     * SHEET_IDを取得する。
     * @return SHEET_ID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * SHEET_IDを設定する。
     * @param sheetId SHEET_ID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * A01_ACTOR_CDを取得する。
     * @return A01_ACTOR_CD
     */
    public String getA01ActorCd() {
        return a01ActorCd;
    }

    /**
     * A01_ACTOR_CDを設定する。
     * @param a01ActorCd A01_ACTOR_CD
     */
    public void setA01ActorCd(String a01ActorCd) {
        this.a01ActorCd = a01ActorCd;
    }

    /**
     * A01_PERSON_IDを取得する。
     * @return A01_PERSON_ID
     */
    public String getA01PersonId() {
        return a01PersonId;
    }

    /**
     * A01_PERSON_IDを設定する。
     * @param a01PersonId A01_PERSON_ID
     */
    public void setA01PersonId(String a01PersonId) {
        this.a01PersonId = a01PersonId;
    }

    /**
     * A02_ACTOR_CDを取得する。
     * @return A02_ACTOR_CD
     */
    public String getA02ActorCd() {
        return a02ActorCd;
    }

    /**
     * A02_ACTOR_CDを設定する。
     * @param a02ActorCd A02_ACTOR_CD
     */
    public void setA02ActorCd(String a02ActorCd) {
        this.a02ActorCd = a02ActorCd;
    }

    /**
     * A02_PERSON_IDを取得する。
     * @return A02_PERSON_ID
     */
    public String getA02PersonId() {
        return a02PersonId;
    }

    /**
     * A02_PERSON_IDを設定する。
     * @param a02PersonId A02_PERSON_ID
     */
    public void setA02PersonId(String a02PersonId) {
        this.a02PersonId = a02PersonId;
    }

    /**
     * A03_ACTOR_CDを取得する。
     * @return A03_ACTOR_CD
     */
    public String getA03ActorCd() {
        return a03ActorCd;
    }

    /**
     * A03_ACTOR_CDを設定する。
     * @param a03ActorCd A03_ACTOR_CD
     */
    public void setA03ActorCd(String a03ActorCd) {
        this.a03ActorCd = a03ActorCd;
    }

    /**
     * A03_PERSON_IDを取得する。
     * @return A03_PERSON_ID
     */
    public String getA03PersonId() {
        return a03PersonId;
    }

    /**
     * A03_PERSON_IDを設定する。
     * @param a03PersonId A03_PERSON_ID
     */
    public void setA03PersonId(String a03PersonId) {
        this.a03PersonId = a03PersonId;
    }

    /**
     * A04_ACTOR_CDを取得する。
     * @return A04_ACTOR_CD
     */
    public String getA04ActorCd() {
        return a04ActorCd;
    }

    /**
     * A04_ACTOR_CDを設定する。
     * @param a04ActorCd A04_ACTOR_CD
     */
    public void setA04ActorCd(String a04ActorCd) {
        this.a04ActorCd = a04ActorCd;
    }

    /**
     * A04_PERSON_IDを取得する。
     * @return A04_PERSON_ID
     */
    public String getA04PersonId() {
        return a04PersonId;
    }

    /**
     * A04_PERSON_IDを設定する。
     * @param a04PersonId A04_PERSON_ID
     */
    public void setA04PersonId(String a04PersonId) {
        this.a04PersonId = a04PersonId;
    }

    /**
     * A05_ACTOR_CDを取得する。
     * @return A05_ACTOR_CD
     */
    public String getA05ActorCd() {
        return a05ActorCd;
    }

    /**
     * A05_ACTOR_CDを設定する。
     * @param a05ActorCd A05_ACTOR_CD
     */
    public void setA05ActorCd(String a05ActorCd) {
        this.a05ActorCd = a05ActorCd;
    }

    /**
     * A05_PERSON_IDを取得する。
     * @return A05_PERSON_ID
     */
    public String getA05PersonId() {
        return a05PersonId;
    }

    /**
     * A05_PERSON_IDを設定する。
     * @param a05PersonId A05_PERSON_ID
     */
    public void setA05PersonId(String a05PersonId) {
        this.a05PersonId = a05PersonId;
    }

    /**
     * A06_ACTOR_CDを取得する。
     * @return A06_ACTOR_CD
     */
    public String getA06ActorCd() {
        return a06ActorCd;
    }

    /**
     * A06_ACTOR_CDを設定する。
     * @param a06ActorCd A06_ACTOR_CD
     */
    public void setA06ActorCd(String a06ActorCd) {
        this.a06ActorCd = a06ActorCd;
    }

    /**
     * A06_PERSON_IDを取得する。
     * @return A06_PERSON_ID
     */
    public String getA06PersonId() {
        return a06PersonId;
    }

    /**
     * A06_PERSON_IDを設定する。
     * @param a06PersonId A06_PERSON_ID
     */
    public void setA06PersonId(String a06PersonId) {
        this.a06PersonId = a06PersonId;
    }

    /**
     * A07_ACTOR_CDを取得する。
     * @return A07_ACTOR_CD
     */
    public String getA07ActorCd() {
        return a07ActorCd;
    }

    /**
     * A07_ACTOR_CDを設定する。
     * @param a07ActorCd A07_ACTOR_CD
     */
    public void setA07ActorCd(String a07ActorCd) {
        this.a07ActorCd = a07ActorCd;
    }

    /**
     * A07_PERSON_IDを取得する。
     * @return A07_PERSON_ID
     */
    public String getA07PersonId() {
        return a07PersonId;
    }

    /**
     * A07_PERSON_IDを設定する。
     * @param a07PersonId A07_PERSON_ID
     */
    public void setA07PersonId(String a07PersonId) {
        this.a07PersonId = a07PersonId;
    }

    /**
     * A08_ACTOR_CDを取得する。
     * @return A08_ACTOR_CD
     */
    public String getA08ActorCd() {
        return a08ActorCd;
    }

    /**
     * A08_ACTOR_CDを設定する。
     * @param a08ActorCd A08_ACTOR_CD
     */
    public void setA08ActorCd(String a08ActorCd) {
        this.a08ActorCd = a08ActorCd;
    }

    /**
     * A08_PERSON_IDを取得する。
     * @return A08_PERSON_ID
     */
    public String getA08PersonId() {
        return a08PersonId;
    }

    /**
     * A08_PERSON_IDを設定する。
     * @param a08PersonId A08_PERSON_ID
     */
    public void setA08PersonId(String a08PersonId) {
        this.a08PersonId = a08PersonId;
    }

    /**
     * A09_ACTOR_CDを取得する。
     * @return A09_ACTOR_CD
     */
    public String getA09ActorCd() {
        return a09ActorCd;
    }

    /**
     * A09_ACTOR_CDを設定する。
     * @param a09ActorCd A09_ACTOR_CD
     */
    public void setA09ActorCd(String a09ActorCd) {
        this.a09ActorCd = a09ActorCd;
    }

    /**
     * A09_PERSON_IDを取得する。
     * @return A09_PERSON_ID
     */
    public String getA09PersonId() {
        return a09PersonId;
    }

    /**
     * A09_PERSON_IDを設定する。
     * @param a09PersonId A09_PERSON_ID
     */
    public void setA09PersonId(String a09PersonId) {
        this.a09PersonId = a09PersonId;
    }

    /**
     * A10_ACTOR_CDを取得する。
     * @return A10_ACTOR_CD
     */
    public String getA10ActorCd() {
        return a10ActorCd;
    }

    /**
     * A10_ACTOR_CDを設定する。
     * @param a10ActorCd A10_ACTOR_CD
     */
    public void setA10ActorCd(String a10ActorCd) {
        this.a10ActorCd = a10ActorCd;
    }

    /**
     * A10_PERSON_IDを取得する。
     * @return A10_PERSON_ID
     */
    public String getA10PersonId() {
        return a10PersonId;
    }

    /**
     * A10_PERSON_IDを設定する。
     * @param a10PersonId A10_PERSON_ID
     */
    public void setA10PersonId(String a10PersonId) {
        this.a10PersonId = a10PersonId;
    }

    /**
     * A11_ACTOR_CDを取得する。
     * @return A11_ACTOR_CD
     */
    public String getA11ActorCd() {
        return a11ActorCd;
    }

    /**
     * A11_ACTOR_CDを設定する。
     * @param a11ActorCd A11_ACTOR_CD
     */
    public void setA11ActorCd(String a11ActorCd) {
        this.a11ActorCd = a11ActorCd;
    }

    /**
     * A11_PERSON_IDを取得する。
     * @return A11_PERSON_ID
     */
    public String getA11PersonId() {
        return a11PersonId;
    }

    /**
     * A11_PERSON_IDを設定する。
     * @param a11PersonId A11_PERSON_ID
     */
    public void setA11PersonId(String a11PersonId) {
        this.a11PersonId = a11PersonId;
    }

    /**
     * A12_ACTOR_CDを取得する。
     * @return A12_ACTOR_CD
     */
    public String getA12ActorCd() {
        return a12ActorCd;
    }

    /**
     * A12_ACTOR_CDを設定する。
     * @param a12ActorCd A12_ACTOR_CD
     */
    public void setA12ActorCd(String a12ActorCd) {
        this.a12ActorCd = a12ActorCd;
    }

    /**
     * A12_PERSON_IDを取得する。
     * @return A12_PERSON_ID
     */
    public String getA12PersonId() {
        return a12PersonId;
    }

    /**
     * A12_PERSON_IDを設定する。
     * @param a12PersonId A12_PERSON_ID
     */
    public void setA12PersonId(String a12PersonId) {
        this.a12PersonId = a12PersonId;
    }

    /**
     * A13_ACTOR_CDを取得する。
     * @return A13_ACTOR_CD
     */
    public String getA13ActorCd() {
        return a13ActorCd;
    }

    /**
     * A13_ACTOR_CDを設定する。
     * @param a13ActorCd A13_ACTOR_CD
     */
    public void setA13ActorCd(String a13ActorCd) {
        this.a13ActorCd = a13ActorCd;
    }

    /**
     * A13_PERSON_IDを取得する。
     * @return A13_PERSON_ID
     */
    public String getA13PersonId() {
        return a13PersonId;
    }

    /**
     * A13_PERSON_IDを設定する。
     * @param a13PersonId A13_PERSON_ID
     */
    public void setA13PersonId(String a13PersonId) {
        this.a13PersonId = a13PersonId;
    }

    /**
     * A14_ACTOR_CDを取得する。
     * @return A14_ACTOR_CD
     */
    public String getA14ActorCd() {
        return a14ActorCd;
    }

    /**
     * A14_ACTOR_CDを設定する。
     * @param a14ActorCd A14_ACTOR_CD
     */
    public void setA14ActorCd(String a14ActorCd) {
        this.a14ActorCd = a14ActorCd;
    }

    /**
     * A14_PERSON_IDを取得する。
     * @return A14_PERSON_ID
     */
    public String getA14PersonId() {
        return a14PersonId;
    }

    /**
     * A14_PERSON_IDを設定する。
     * @param a14PersonId A14_PERSON_ID
     */
    public void setA14PersonId(String a14PersonId) {
        this.a14PersonId = a14PersonId;
    }

    /**
     * A15_ACTOR_CDを取得する。
     * @return A15_ACTOR_CD
     */
    public String getA15ActorCd() {
        return a15ActorCd;
    }

    /**
     * A15_ACTOR_CDを設定する。
     * @param a15ActorCd A15_ACTOR_CD
     */
    public void setA15ActorCd(String a15ActorCd) {
        this.a15ActorCd = a15ActorCd;
    }

    /**
     * A15_PERSON_IDを取得する。
     * @return A15_PERSON_ID
     */
    public String getA15PersonId() {
        return a15PersonId;
    }

    /**
     * A15_PERSON_IDを設定する。
     * @param a15PersonId A15_PERSON_ID
     */
    public void setA15PersonId(String a15PersonId) {
        this.a15PersonId = a15PersonId;
    }

    /**
     * R01_PERSON_IDを取得する。
     * @return R01_PERSON_ID
     */
    public String getR01PersonId() {
        return r01PersonId;
    }

    /**
     * R01_PERSON_IDを設定する。
     * @param r01PersonId R01_PERSON_ID
     */
    public void setR01PersonId(String r01PersonId) {
        this.r01PersonId = r01PersonId;
    }

    /**
     * R02_PERSON_IDを取得する。
     * @return R02_PERSON_ID
     */
    public String getR02PersonId() {
        return r02PersonId;
    }

    /**
     * R02_PERSON_IDを設定する。
     * @param r02PersonId R02_PERSON_ID
     */
    public void setR02PersonId(String r02PersonId) {
        this.r02PersonId = r02PersonId;
    }

    /**
     * R03_PERSON_IDを取得する。
     * @return R03_PERSON_ID
     */
    public String getR03PersonId() {
        return r03PersonId;
    }

    /**
     * R03_PERSON_IDを設定する。
     * @param r03PersonId R03_PERSON_ID
     */
    public void setR03PersonId(String r03PersonId) {
        this.r03PersonId = r03PersonId;
    }

    /**
     * R04_PERSON_IDを取得する。
     * @return R04_PERSON_ID
     */
    public String getR04PersonId() {
        return r04PersonId;
    }

    /**
     * R04_PERSON_IDを設定する。
     * @param r04PersonId R04_PERSON_ID
     */
    public void setR04PersonId(String r04PersonId) {
        this.r04PersonId = r04PersonId;
    }

    /**
     * R05_PERSON_IDを取得する。
     * @return R05_PERSON_ID
     */
    public String getR05PersonId() {
        return r05PersonId;
    }

    /**
     * R05_PERSON_IDを設定する。
     * @param r05PersonId R05_PERSON_ID
     */
    public void setR05PersonId(String r05PersonId) {
        this.r05PersonId = r05PersonId;
    }

    /**
     * R06_PERSON_IDを取得する。
     * @return R06_PERSON_ID
     */
    public String getR06PersonId() {
        return r06PersonId;
    }

    /**
     * R06_PERSON_IDを設定する。
     * @param r06PersonId R06_PERSON_ID
     */
    public void setR06PersonId(String r06PersonId) {
        this.r06PersonId = r06PersonId;
    }

    /**
     * R07_PERSON_IDを取得する。
     * @return R07_PERSON_ID
     */
    public String getR07PersonId() {
        return r07PersonId;
    }

    /**
     * R07_PERSON_IDを設定する。
     * @param r07PersonId R07_PERSON_ID
     */
    public void setR07PersonId(String r07PersonId) {
        this.r07PersonId = r07PersonId;
    }

    /**
     * R08_PERSON_IDを取得する。
     * @return R08_PERSON_ID
     */
    public String getR08PersonId() {
        return r08PersonId;
    }

    /**
     * R08_PERSON_IDを設定する。
     * @param r08PersonId R08_PERSON_ID
     */
    public void setR08PersonId(String r08PersonId) {
        this.r08PersonId = r08PersonId;
    }

    /**
     * R09_PERSON_IDを取得する。
     * @return R09_PERSON_ID
     */
    public String getR09PersonId() {
        return r09PersonId;
    }

    /**
     * R09_PERSON_IDを設定する。
     * @param r09PersonId R09_PERSON_ID
     */
    public void setR09PersonId(String r09PersonId) {
        this.r09PersonId = r09PersonId;
    }

    /**
     * R10_PERSON_IDを取得する。
     * @return R10_PERSON_ID
     */
    public String getR10PersonId() {
        return r10PersonId;
    }

    /**
     * R10_PERSON_IDを設定する。
     * @param r10PersonId R10_PERSON_ID
     */
    public void setR10PersonId(String r10PersonId) {
        this.r10PersonId = r10PersonId;
    }

    /**
     * R11_PERSON_IDを取得する。
     * @return R11_PERSON_ID
     */
    public String getR11PersonId() {
        return r11PersonId;
    }

    /**
     * R11_PERSON_IDを設定する。
     * @param r11PersonId R11_PERSON_ID
     */
    public void setR11PersonId(String r11PersonId) {
        this.r11PersonId = r11PersonId;
    }

    /**
     * R12_PERSON_IDを取得する。
     * @return R12_PERSON_ID
     */
    public String getR12PersonId() {
        return r12PersonId;
    }

    /**
     * R12_PERSON_IDを設定する。
     * @param r12PersonId R12_PERSON_ID
     */
    public void setR12PersonId(String r12PersonId) {
        this.r12PersonId = r12PersonId;
    }

    /**
     * R13_PERSON_IDを取得する。
     * @return R13_PERSON_ID
     */
    public String getR13PersonId() {
        return r13PersonId;
    }

    /**
     * R13_PERSON_IDを設定する。
     * @param r13PersonId R13_PERSON_ID
     */
    public void setR13PersonId(String r13PersonId) {
        this.r13PersonId = r13PersonId;
    }

    /**
     * R14_PERSON_IDを取得する。
     * @return R14_PERSON_ID
     */
    public String getR14PersonId() {
        return r14PersonId;
    }

    /**
     * R14_PERSON_IDを設定する。
     * @param r14PersonId R14_PERSON_ID
     */
    public void setR14PersonId(String r14PersonId) {
        this.r14PersonId = r14PersonId;
    }

    /**
     * R15_PERSON_IDを取得する。
     * @return R15_PERSON_ID
     */
    public String getR15PersonId() {
        return r15PersonId;
    }

    /**
     * R15_PERSON_IDを設定する。
     * @param r15PersonId R15_PERSON_ID
     */
    public void setR15PersonId(String r15PersonId) {
        this.r15PersonId = r15PersonId;
    }

}

