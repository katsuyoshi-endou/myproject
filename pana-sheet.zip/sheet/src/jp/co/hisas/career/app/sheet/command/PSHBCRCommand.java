package jp.co.hisas.career.app.sheet.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.framework.trans.StateTransitionEvent;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class PSHBCRCommand extends AbstractCommand {

	public static final String KINOU_ID = "VSHBCR";
	private HttpServletRequest request;
	@SuppressWarnings("unused")
	private HttpSession session;
	private String state;

	public PSHBCRCommand() {
		super( PSHBCRCommand.class, KINOU_ID, null );
	}


	public void init( StateTransitionEvent e ) {
		try {
			request = e.getRequest();
			session = request.getSession( false );
			/* Not Update Token While Single Sheet.
			CSRFTokenUtil.setNewTokenNo( request, e.getResponse() ); */
			state = request.getParameter( "state" );
			main();
		} catch (CareerException ex) {
			throw new CareerRuntimeException( ex );
		}
	}

	private void main() throws CareerException {
		/* 操作ログ */
		OutLogBean.outputLogSousa( request, KINOU_ID, state );
	}
}
