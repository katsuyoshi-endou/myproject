package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dao.BulkOperSheetListDao;
import jp.co.hisas.career.app.sheet.dao.CsmSheetActionDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetActorDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetExclusiveDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetFillDao;
import jp.co.hisas.career.app.sheet.dao.ZzBulkOperWkRsltDao;
import jp.co.hisas.career.app.sheet.dto.BulkOperSheetListDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetActionDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetFillDto;
import jp.co.hisas.career.app.sheet.garage.CsMultiSheetGarage;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.CommonLabel;

public class BulkOperSheetEventHandler extends AbstractEventHandler<BulkOperSheetEventArg, BulkOperSheetEventResult> {

	private String daoLoginNo;
	private String operatorGuid;
	private String sheetId;

	public static BulkOperSheetEventResult exec( BulkOperSheetEventArg arg ) throws CareerException {
		BulkOperSheetEventHandler handler = new BulkOperSheetEventHandler();
		return handler.call( arg );
	}

	@Override
	public BulkOperSheetEventResult call(BulkOperSheetEventArg arg) throws CareerException {
		BulkOperSheetEventResult result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}

	@Override
	protected BulkOperSheetEventResult execute(BulkOperSheetEventArg arg) throws CareerException {
		arg.validateArg();
		// Application Login User GUID (for dao logging)
		this.daoLoginNo = arg.getLoginNo();
		// [CAREER_GUID].[OPERATOR_FLG] (Proxied) GUID or equals login GUID
		this.operatorGuid = arg.operatorGuid;

		BulkOperSheetEventResult result = new BulkOperSheetEventResult();

		try {
			if ( SU.equals( arg.sharp, "PREPARE" )) {
				CsMultiSheetGarage garage = new CsMultiSheetGarage( daoLoginNo );
				
				// 分類リストの取得
				List<ValueTextSortDto> divList = garage.getDivList( operatorGuid, arg.party );
				result.divList = divList;
				
				// 運用リストの取得
				List<ValueTextSortDto> opeList = garage.getOpeList( operatorGuid, arg.party, arg.opeType  );
				result.opeList = opeList;
				
			} else if ( SU.equals( arg.sharp, "SEARCH" )) {
				CsMultiSheetGarage garage = new CsMultiSheetGarage( daoLoginNo );
				
				String operationCd = arg.srchCondMap.get( "operationCd" );
				// フローステータスリストの取得
				List<ValueTextSortDto> staList = new ArrayList<ValueTextSortDto>();
				if (!CsUtil.isBlank( operationCd )) {
					staList = garage.getStatusList( arg.party, operationCd );
				}
				result.statusList = staList;
				
				// [検索] 取扱可能な範囲すべてをワークに登録
				loadAllSheetSrchRslt( arg );
				
				// [検索] ワークから検索条件に従ってデータを削る
				reduceSheetSrchRslt( arg );
				
				// [検索] ワークに残ったシートデータを取得
				List<BulkOperSheetListDto> sheetList = getBulkOperSheetList( arg );
				result.hitCnt = sheetList.size();
				result.setSheetList( sheetList );
				
			} else if ( SU.matches( arg.sharp, "RESUME|AWAY" )) {
				
				this.sheetId = arg.sheetId;
				// 排他キーの比較と更新
				if ( !checkExclusiveKey( arg.exclusiveKey )) {
					result.setResultErrorMessage( CommonLabel.getLabel( "LSHBLK_MSG_EXCLUSIVE_ERR" ));
					return result;
				} else {
					updateExclusiveKey( arg.exclusiveKey );
				}
				
				// シートステータスの更新
				updateSheetStatus( arg );
				
			} else if ( SU.matches( arg.sharp, "CHANGE_OPERATION" )) {
				CsMultiSheetGarage garage = new CsMultiSheetGarage(arg.getLoginNo());

				// フローステータスリストの取得
				List<ValueTextSortDto> staList = new ArrayList<ValueTextSortDto>();
				String operationCd = arg.srchCondMap.get( "operationCd" );
				if (!CsUtil.isBlank( operationCd )) {
					staList = garage.getStatusList( arg.party, operationCd );
				}
				result.statusList = staList;

			} else if ( SU.equals( arg.sharp, "ACTOR_DEL" )) {

				this.sheetId = arg.sheetId;
				// 排他キーの比較と更新
				if ( !checkExclusiveKey( arg.exclusiveKey )) {
					result.setResultErrorMessage( CommonLabel.getLabel( "LSHBLK_MSG_EXCLUSIVE_ERR" ));
					return result;
				} else {
					updateExclusiveKey( arg.exclusiveKey );
				}

				// 評価者の削除
				updateActorCd( arg );
			}
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
		return result;
	}

	public void loadAllSheetSrchRslt( BulkOperSheetEventArg arg ) {
		//clear
		ZzBulkOperWkRsltDao dao = new ZzBulkOperWkRsltDao( daoLoginNo );
		dao.executeDynamic( "delete from ZZ_BULK_OPER_WK_RSLT where LOGIN_PERSON_ID = '" + this.daoLoginNo + "'" );

		// V_CST_SHEET_ACTOR_AND_REFと結合してデータを取得するときにインデックスを振るのでここでは、0をセット
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "insert into ZZ_BULK_OPER_WK_RSLT " );
		sql.append( "select ?, s.SHEET_ID, s.OWN_GUID, 0 " );
		sql.append( "  from cst_sheet s " );
		/* STAMP or CASCADE */
		sql.append( " inner join ( select * " );
		sql.append( "                from CSM_SHEET_OPERATION " );
		sql.append( "               where OPEN_FLG = '1' ) ope " );
		sql.append( " on ope.OPERATION_CD = s.OPERATION_CD " );
		if ( SU.equals( arg.opeType, "STAMP" ) ) {
			sql.append( " and ope.OPERATION_TYPE = 'STAMP' " );
		}
		else if ( SU.equals( arg.opeType, "CASCADE" ) ) {
			sql.append( " and ope.OPERATION_TYPE = 'CASCADE' " );
		}
		if ( SU.isNotBlank( arg.operationCd ) ) {
			sql.append( " and ope.OPERATION_CD = ? " );
		}

		sql.append( " where s.PARTY = ? " );
		sql.append( "   and exists ( " );
		sql.append( "         select 'X' from V_CST_SHEET_ACTOR_AND_REF a " );
		sql.append( "          where a.SHEET_ID = s.SHEET_ID and a.GUID = ? " );
		sql.append( "       ) " );

		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.daoLoginNo );
		if ( SU.isNotBlank( arg.operationCd ) ) {
			paramList.add( arg.operationCd );
		}
		paramList.add( arg.party );
		paramList.add( arg.operatorGuid );

		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}

	public void reduceSheetSrchRslt( BulkOperSheetEventArg arg ) {

		// 特定のアクター（owner/follow）による絞込
		reduceBySpecialActorfilter( arg );

		// シートに埋め込まれた情報に対する絞込 (CST_SHEET, CST_SHEET_ATTR)
		reduceBySheetEmbeddedInfo( arg );
	}

	private void reduceBySpecialActorfilter( BulkOperSheetEventArg arg ) {

		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "delete from ZZ_BULK_OPER_WK_RSLT wk " );
		sql.append( " where wk.LOGIN_PERSON_ID = ? " );
		sql.append( "   and not exists ( " );
		sql.append( "         select 'X' " );
		sql.append( "           from V_CST_SHEET_ACTOR_AND_REF a " );
		sql.append( "          where a.SHEET_ID = wk.SHEET_ID " );
		sql.append( "            and a.GUID     = ? " );
		sql.append( "            and a.ACTOR_CD <> 'ref-follow' " );
		if ( !( SU.equals( arg.opeType, "CASCADE" ) ) ) {
			sql.append( "            and a.ACTOR_CD <> 'act-owner' " );
		}
		sql.append( "       ) " );

		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.daoLoginNo );
		paramList.add( arg.operatorGuid );

		ZzBulkOperWkRsltDao dao = new ZzBulkOperWkRsltDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}

	private void reduceBySheetEmbeddedInfo( BulkOperSheetEventArg arg ) {

		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();

		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "delete from ZZ_BULK_OPER_WK_RSLT wk " );
		sql.append( " where LOGIN_PERSON_ID = ? " );	paramList.add( this.daoLoginNo );
		sql.append( "   and not exists ( " );
		sql.append( "         select 'X' " );
		sql.append( "           from V_CS_INFO_ATTR vcia " );
		sql.append( "          where vcia.SHEET_ID = wk.SHEET_ID " );
		if (CsUtil.srchCondAvailable( arg.srchCondMap, "personId" )) {
			sql.append( "        and vcia.STF_NO like ? " );
			paramList.add( "%" + arg.srchCondMap.get( "personId" ) + "%" );
		}
		if (CsUtil.srchCondAvailable( arg.srchCondMap, "personNm" )) {
			sql.append( "        and vcia.OWN_PERSON_KANA like ? " );
			paramList.add( arg.srchCondMap.get( "personNm" ) + "%" );
		}
		if (CsUtil.srchCondAvailable( arg.srchCondMap, "deptNm" )) {
			sql.append( "        and vcia.FULL_DEPT_NM like ? " ); // 2017.03 Panasonic Customize
			paramList.add( "%" + arg.srchCondMap.get( "deptNm" ) + "%" );
		}
		if (CsUtil.srchCondAvailable( arg.srchCondMap, "clsCCd" )) {
			sql.append( "        and vcia.CLS_C_CD = ? " ); // 2017.03 Panasonic Customize
			paramList.add( arg.srchCondMap.get( "clsCCd" ) );
		}
		if (!CsUtil.isBlank( arg.operationCd )) {
			sql.append( "        and vcia.OPERATION_CD = ? " );
			paramList.add( arg.operationCd );
		}
		if (!CsUtil.isBlank( arg.statusCd )) {
			sql.append( "        and vcia.STATUS_CD = ? " );
			paramList.add( arg.statusCd );
		}
		sql.append( "       ) " );

		ZzBulkOperWkRsltDao dao = new ZzBulkOperWkRsltDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}

	public List<BulkOperSheetListDto> getBulkOperSheetList( BulkOperSheetEventArg arg ) {

		boolean isUnlimited = SU.equals( arg.srchCondMap.get( "search_limit" ), "UNLIMITED" );

		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "SELECT ");
		sql.append( "    VCIA.SHEET_ID          AS SHEETID, ");
		sql.append( "    VCIA.OPERATION_NM      AS OPERATIONNM, ");
		sql.append( "    VCIA.OWN_PERSON_NAME   AS OWNPERONNAME, ");
		sql.append( "    VCIA.FULL_DEPT_NM      AS FULLDEPTNM, ");
		sql.append( "    VCIA.CMPA_CD           AS CMPACD, ");
		sql.append( "    VCIA.STATUS_NM         AS STATUSNM, ");
		sql.append( "    ACT_INF.ACTOR_1ST_NM   AS ACTOR1STNM, ");
		sql.append( "    ACT_INF.ACTOR_2ND_NM   AS ACTOR2NDNM, ");
		sql.append( "    ACT_INF.ACTOR_3RD_NM   AS ACTOR3RDNM, ");
		sql.append( "    ACT_INF.ACTOR_4TH_NM   AS ACTOR4THNM, ");
		sql.append( "    VCIA.EXCLUSIVE_KEY     AS EXCLUSIVEKEY, ");
		sql.append( "    ROW_NUMBER() OVER(ORDER BY VCIA.OPERATION_SORT DESC,VCIA.CMPA_CD,VCIA.SHEET_SORT) AS WKIDX ");
		sql.append( "FROM ZZ_BULK_OPER_WK_RSLT RSLT ");
		sql.append( "    LEFT JOIN V_CS_INFO_ATTR VCIA ON VCIA.SHEET_ID = RSLT.SHEET_ID ");
		sql.append( "    LEFT JOIN ");
		sql.append( "    ( ");
		sql.append( "        SELECT ");
		sql.append( "            VCSA.SHEET_ID, ");
		sql.append( "            MAX(CASE WHEN ACTOR_CD = 'act-1st' THEN VCSA.PERSON_NAME ELSE NULL END) AS ACTOR_1ST_NM, ");
		sql.append( "            MAX(CASE WHEN ACTOR_CD = 'act-2nd' THEN VCSA.PERSON_NAME ELSE NULL END) AS ACTOR_2ND_NM, ");
		sql.append( "            MAX(CASE WHEN ACTOR_CD = 'act-3rd' THEN VCSA.PERSON_NAME ELSE NULL END) AS ACTOR_3RD_NM, ");
		sql.append( "            MAX(CASE WHEN ACTOR_CD = 'act-4th' THEN VCSA.PERSON_NAME ELSE NULL END) AS ACTOR_4TH_NM ");
		sql.append( "        FROM ");
		sql.append( "            V_CST_SHEET_ACTOR_AND_REF VCSA ");
		sql.append( "        WHERE VCSA.ACT_OR_REF = 'ACT' ");
		sql.append( "        GROUP BY ");
		sql.append( "            VCSA.SHEET_ID ");
		sql.append( "     ) ACT_INF ON ACT_INF.SHEET_ID = RSLT.SHEET_ID ");
		sql.append( "WHERE RSLT.LOGIN_PERSON_ID = ? ");
		if (!isUnlimited) {
			sql.append( "AND ROWNUM <= 500 " );
		}
		sql.append( "ORDER BY ");
		sql.append( "    VCIA.CMPA_CD, ");
		sql.append( "    VCIA.FULL_DEPT_NM, ");
		sql.append( "    VCIA.OWN_GUID ");

		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.daoLoginNo );

		BulkOperSheetListDao dao = new BulkOperSheetListDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql.toString(), paramList ));
	}

	/**
	 * シートのステータスを更新する
	 *   更新条件に合致しない場合は、何もしない
	 *
	 * @param arg
	 */
	public void updateSheetStatus( BulkOperSheetEventArg arg ) {

		// ステータスの更新が可能か？
		if ( isUpdateStatus( arg )) {
			StringBuilder sql = new StringBuilder();
			sql.append( "UPDATE CST_SHEET ");

			if ( SU.matches( arg.sharp, "RESUME" )) {
				sql.append( " SET STATUS_CD = '00-New' ");
			} else if ( SU.matches( arg.sharp, "AWAY" )) {
				sql.append( " SET STATUS_CD = '99-End' ");
			}
			sql.append( " WHERE SHEET_ID = ? ");

			/* Parameter List */
			ArrayList<String> paramList = new ArrayList<String>();
			paramList.add( arg.sheetId );

			CstSheetDao dao = new CstSheetDao( arg.getLoginNo());
			dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ));
			
			// 変更理由を更新
			updateChangeStatusReason( arg );
		}
	}

	/**
	 * シートステータスの更新が可能かどうかチェックする
	 *
	 * @param arg
	 * @return TRUE : 更新可、FALSE : 更新不可
	 */
	private boolean isUpdateStatus( BulkOperSheetEventArg arg ) {

		StringBuilder sb = new StringBuilder();

		sb.append( "SELECT " );
		sb.append( "    CSA.FLOW_CD           AS FLOWCD, " );
		sb.append( "    CSA.FLOW_PTN          AS FLOWPTN, " );
		sb.append( "    CSA.STATUS_CD         AS STATUSCD, " );
		sb.append( "    CSA.ACTOR_CD          AS ACTORCD, " );
		sb.append( "    CSA.LPAD_SORT         AS LPADSORT, " );
		sb.append( "    CSA.ACTION_CD         AS ACTIONCD, " );
		sb.append( "    CSA.ACTION_NM         AS ACTIONNM, " );
		sb.append( "    CSA.AFTER_STATUS_CD   AS AFTERSTATUSCD, " );
		sb.append( "    CSA.CONFIRM_MSG       AS CONFIRMMSG, " );
		sb.append( "    CSA.RESULT_MSG        AS RESULTMSG, " );
		sb.append( "    CSA.MAIL_TEMPLATE     AS MAILTEMPLATE, " );
		sb.append( "    CSA.USE_DELIV_FLG     AS USEDELIVFLG " );
		sb.append( "FROM " );
		sb.append( "    CSM_SHEET_ACTION CSA " );
		sb.append( "    LEFT JOIN V_CST_SHEET_INFO VCSI ON VCSI.FLOW_CD = CSA.FLOW_CD " );
		sb.append( "        AND VCSI.STATUS_CD = CSA.STATUS_CD " );
		sb.append( "WHERE " );
		sb.append( "    VCSI.SHEET_ID = ? " );
		sb.append( "    AND CSA.ACTION_CD = ? " );
		
		if ( "RESUME".equals( arg.sharp )) {
			// "RESUME"は、対象に戻す以外のパターンもあるため、STATUS_CD = '99-End' かつAFTER_STATUS_CD = '00-New'となるものに絞る
			sb.append( "    AND CSA.AFTER_STATUS_CD = '00-New' " );
			sb.append( "    AND CSA.STATUS_CD = '99-End' " );
		}

		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.sheetId );
		paramList.add( arg.sharp );

		CsmSheetActionDao dao = new CsmSheetActionDao( arg.getLoginNo());
		List<CsmSheetActionDto> dto = dao.selectDynamic( DaoUtil.getPstmt( sb, paramList ));

		return dto.size() > 0 ? true : false;
	}

	/**
	 * ステータス更新理由（理由＆テキスト）を登録・更新する
	 *
	 * @param arg
	 */
	public void updateChangeStatusReason( BulkOperSheetEventArg arg ) {

		CstSheetFillDao dao = new CstSheetFillDao( arg.getLoginNo());
		CstSheetFillDto dto = dao.select( arg.sheetId, "change_status_reason" );

		if ( dto == null ) {
			for ( String fillId : arg.chgStatRiyuMap.keySet()) {
				CstSheetFillDto insDto = new CstSheetFillDto();
				insDto.setSheetId( arg.sheetId );
				insDto.setFillId( fillId );
				insDto.setFillContent( arg.chgStatRiyuMap.get( fillId ));
				dao.insert( insDto );
			}
		} else {
			for ( String fillId : arg.chgStatRiyuMap.keySet()) {
				CstSheetFillDto insDto = new CstSheetFillDto();
				insDto.setSheetId( arg.sheetId );
				insDto.setFillId( fillId );
				insDto.setFillContent( arg.chgStatRiyuMap.get( fillId ));
				dao.update( insDto );
			}
		}
	}

	/**
	 * シートID, アクターコードが一致する評価者を削除（NULLで更新）する
	 * ※条件に一致しないときは、何もしない
	 *
	 * @param arg
	 */
	public void updateActorCd( BulkOperSheetEventArg arg ) {

		CstSheetActorDao dao = new CstSheetActorDao( arg.getLoginNo());

		StringBuilder sql = new StringBuilder();
		sql.append("UPDATE CST_SHEET_ACTOR ");
		sql.append(" SET GUID = NULL, AUTO_FLG = '0' ");
		sql.append(" WHERE SHEET_ID = ? ");
		sql.append(" AND ACTOR_CD = ? ");

		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.sheetId );
		paramList.add( arg.actorCd );

		dao.executeDynamic(  DaoUtil.getPstmt( sql, paramList ));
	}

	private CstSheetExclusiveDto getExclusiveKeyFromDB() throws Exception {
		CstSheetExclusiveDao excDao = new CstSheetExclusiveDao( daoLoginNo );
		CstSheetExclusiveDto excDto = excDao.select( this.sheetId );
		if (excDto == null) {
			excDao = new CstSheetExclusiveDao( daoLoginNo );
			excDto = new CstSheetExclusiveDto();
			excDto.setSheetId( this.sheetId );
			excDto.setExclusiveKey( 0 );
			excDao.insert( excDto );
		}
		return excDto;
	}

	private boolean checkExclusiveKey( CstSheetExclusiveDto exclusiveKey ) throws Exception {
		CstSheetExclusiveDto excDtoDB  = getExclusiveKeyFromDB();
		CstSheetExclusiveDto excDtoSes = exclusiveKey;
		if (excDtoDB != null && excDtoSes != null) {
			String dbSId  = excDtoDB.getSheetId();
			String sesSId = excDtoSes.getSheetId();
			if (dbSId.equals( sesSId )) {
				Integer dbKey  = excDtoDB.getExclusiveKey();
				Integer sesKey = excDtoSes.getExclusiveKey();
				if (dbKey.equals( sesKey )){
					// Check OK
					return true;
				}
			}
		}
		return false;
	}

	private void updateExclusiveKey( CstSheetExclusiveDto exclusiveKey ) throws Exception {
		Integer key = exclusiveKey.getExclusiveKey();
		exclusiveKey.setExclusiveKey( key + 1 );
		CstSheetExclusiveDao excDao = new CstSheetExclusiveDao( daoLoginNo );
		excDao.update( exclusiveKey );
	}
}
