package jp.co.hisas.career.app.sheet.event;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dto.CsmSheetActionDto;
import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

@SuppressWarnings("serial")
public class MultiEditGymknEvRslt extends AbstractEventResult {

	public List<ValueTextSortDto> actorList;
	public List<CsSheetEventResult> sheetList;
	public List<CsmSheetActionDto> actionList;
	public Map<String, Map<String, String>> labelSetMap;
	
}