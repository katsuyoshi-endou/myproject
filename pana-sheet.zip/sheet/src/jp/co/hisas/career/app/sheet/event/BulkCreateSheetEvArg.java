package jp.co.hisas.career.app.sheet.event;

import java.util.HashMap;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;

public class BulkCreateSheetEvArg extends AbstractEventArg {

	public String sharp = null;

	public String operationCd = null;
	public String operatorGuid = null;
	public HashMap<String, String> srchCondMap = null;

	public String personId = null;
	public String deptNm = null;
	public String personNm = null;
	public String personNmKn = null;
	
	public String party = null;
	public String ownGuid = null;
	public String sheetStatus = null;

	public BulkCreateSheetEvArg( String loginNo ) throws CareerException {

		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}

		this.setLoginNo( loginNo );
	}

	public void validateArg() throws CareerException {
		if (this.sharp == null || "".equals( this.sharp.trim() )) {
			throw new CareerException( "Invalid Arg: state is null." );
		}
	}
}
