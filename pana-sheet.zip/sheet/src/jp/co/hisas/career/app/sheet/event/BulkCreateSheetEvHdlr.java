package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dao.CsmSheetOperationDao;
import jp.co.hisas.career.app.sheet.dao.ZzUncreatedWkDao;
import jp.co.hisas.career.app.sheet.dto.CsmSheetOperationDto;
import jp.co.hisas.career.app.sheet.dto.ZzUncreatedWkDto;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.ValueTextSortDao;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;
import jp.co.hisas.career.util.log.Log;

public class BulkCreateSheetEvHdlr extends AbstractEventHandler<BulkCreateSheetEvArg, BulkCreateSheetEvRslt> {

	private String daoLoginNo;

	public static BulkCreateSheetEvRslt exec( BulkCreateSheetEvArg arg ) throws CareerException {
		BulkCreateSheetEvHdlr handler = new BulkCreateSheetEvHdlr();
		return handler.call( arg );
	}

	@Override
	public BulkCreateSheetEvRslt call( BulkCreateSheetEvArg arg ) throws CareerException {
		BulkCreateSheetEvRslt result = null;

		Log.method( arg.getLoginNo(), "IN", "" );

		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );

		return result;
	}

	@Override
	protected BulkCreateSheetEvRslt execute( BulkCreateSheetEvArg arg ) throws CareerException {

		this.daoLoginNo = arg.getLoginNo();

		BulkCreateSheetEvRslt result = new BulkCreateSheetEvRslt();

		if ( SU.matches( arg.sharp, "SEARCH" )) {

			// ZZ_UNCREATED_WKのデータは新たに絞り込まない（未作成者一覧で取得したときのワークデータを使用する）
//			insertUnCreatedSheetWK( arg );

			// ワークから検索
			List<ZzUncreatedWkDto> list = getUncreatedSheetList( arg );

			result.setSheetList( list );

			// 作成対象言語リストの取得
			List<ValueTextSortDto> langList = getLanguageList( arg );
			result.setLangList( langList );

			// 評価シート名の取得
			CsmSheetOperationDao dao = new CsmSheetOperationDao( this.daoLoginNo );
			CsmSheetOperationDto dto = dao.select( arg.party, arg.operationCd );

			result.setOperationNm( dto.getOperationNm());

		} else if ( SU.matches( arg.sharp, "NEW_SHEET_RESULT" )) {
			setNewSheetCreateResult( arg );
		}
		return result;
	}

	private List<ZzUncreatedWkDto> getUncreatedSheetList( BulkCreateSheetEvArg arg ) {

		ZzUncreatedWkDao zuwDao = new ZzUncreatedWkDao( arg.getLoginNo());
		StringBuilder sql = new StringBuilder();
		// パラメータセット
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.getLoginNo());

		// 検索条件絞り込み
		sql.append( " SELECT " + ZzUncreatedWkDao.ALLCOLS );
		sql.append( " FROM ( " );
		sql.append( " SELECT " );
		sql.append( "  LOGIN_PERSON_ID AS LOGIN_PERSON_ID" );
		sql.append( " ,OPERATION_CD AS OPERATION_CD " );
		sql.append( " ,OWN_GUID AS OWN_GUID " );
		sql.append( " ,OWN_PERSON_NAME AS OWN_PERSON_NAME " );
		sql.append( " ,OWN_PERSON_NAME_KANA AS OWN_PERSON_NAME_KANA " );
		sql.append( " ,OWN_CMPA_CD AS OWN_CMPA_CD " );
		sql.append( " ,OWN_FULL_DEPT_NM AS OWN_FULL_DEPT_NM " );
		sql.append( " ,OWN_MAIL_ADDRESS AS OWN_MAIL_ADDRESS " );
		sql.append( " ,CASE WHEN SHEET_STATUS IS NULL THEN '99' ELSE SHEET_STATUS END AS SHEET_STATUS " );
		sql.append( " FROM ZZ_UNCREATED_WK " );
		sql.append( " WHERE LOGIN_PERSON_ID = ? " );
		// Global_ID
		if ( CsUtil.srchCondAvailable( arg.srchCondMap, "personId" )) {
			sql.append( " and OWN_GUID like ? " );
			paramList.add( "%" + arg.srchCondMap.get( "personId" ) + "%" );
		}
		// 所属
		if ( CsUtil.srchCondAvailable( arg.srchCondMap, "deptNm" )) {
			sql.append( " and OWN_FULL_DEPT_NM like ? " );
			paramList.add( "%" + arg.srchCondMap.get( "deptNm" ) + "%" );
		}
		// 氏名
		if ( CsUtil.srchCondAvailable( arg.srchCondMap, "personNm" )) {
			sql.append( " and OWN_PERSON_NAME like ? " );
			paramList.add( "%" + arg.srchCondMap.get( "personNm" ) + "%" );
		}
		// 氏名（カナ）
		if ( CsUtil.srchCondAvailable( arg.srchCondMap, "personNmKn" )) {
			sql.append( " and OWN_PERSON_NAME_KANA like ? " );
			paramList.add( "%" + arg.srchCondMap.get( "personNmKn" ) + "%" );
		}
		// ソート順指定
		sql.append( " order by OWN_CMPA_CD asc, OWN_FULL_DEPT_NM asc, OWN_GUID asc " );
		sql.append( " ) " );
		// 500のみ表示する
		sql.append( " where rownum < 501 " );

		return zuwDao.selectDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}

	private List<ValueTextSortDto> getLanguageList( BulkCreateSheetEvArg arg) {

		StringBuilder sql = new StringBuilder();

		sql.append( "SELECT " );
		sql.append( "    FORM_CD AS value, " );
		sql.append( "    LANG_NM AS text, " );
		sql.append( "    LANG_SORT AS sort " );
		sql.append( "FROM ZZ_CSM_SHEET_BULK_LANGUAGE " );
		sql.append( "WHERE OPERATION_CD = ? ");
		sql.append( "ORDER BY LANG_SORT" );

		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.operationCd );
		
		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );

		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ));
	}
	
	private void setNewSheetCreateResult( BulkCreateSheetEvArg arg ) {
		
		StringBuilder sb = new StringBuilder();
		
		sb.append( "UPDATE ZZ_UNCREATED_WK SET SHEET_STATUS = ? WHERE LOGIN_PERSON_ID = ? AND OPERATION_CD = ? AND OWN_GUID = ?" );

		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.sheetStatus );
		paramList.add( arg.getLoginNo());
		paramList.add( arg.operationCd );
		paramList.add( arg.ownGuid );
		
		ZzUncreatedWkDao dao = new ZzUncreatedWkDao( arg.getLoginNo());
		dao.executeDynamic( DaoUtil.getPstmt( sb, paramList ));
	}
}
