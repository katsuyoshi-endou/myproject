package jp.co.hisas.career.app.sheet.servlet;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Map;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.event.MultiEditJinikUploadEvArg;
import jp.co.hisas.career.app.sheet.event.MultiEditJinikUploadEvHdlr;
import jp.co.hisas.career.app.sheet.event.MultiEditJinikUploadEvRslt;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.FileUploadServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.CommonLabel;

public class MultiEditJinikUploadServlet extends FileUploadServlet {

	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "VSHJIN";
	private static final String FORWARD_PAGE = "/servlet/MultiEditJinikServlet";
	
	private static final String STR_UPLOAD_ENABLED = "アップロード可";
	private static final String STR_UPLOAD_DISABLED = "アップロード不可";
	private static final String READ_TARGET_SHEET_NAME = "人材育成計画";

	// アップロード可否の文字列がセットされているセルの位置（"B3"）
	private static final int UPLOAD_STATUS_ROW = 3;
	private static final int UPLOAD_STATUS_COLUMN = 1;

	@Override
	public String serviceMain( Tray tray ) throws Exception {
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( tray.session, UserInfoBean.SESSION_KEY );
		tray.operatorGuid = userInfo.getOperatorGuid();

		@SuppressWarnings("unchecked")
		Map<String, FileItem> paramMap = (Map<String, FileItem>)tray.request.getAttribute( "paramMap" );

		// ファイル名が文字化けするための対応（fileフィールドとは別にファイル名を保持するフィールドを設けて取得する）
		String uploadFileName = paramMap.get( "uploadFName" ).getString( "UTF-8" );
		MultiEditJinikUploadEvRslt result = reserveExcelUploadFile( tray, paramMap.get( "excelFile" ), uploadFileName );

		tray.request.setAttribute( CsSessionKey.VSHJIN_UPLOAD_RESULT_MSG, result.resultMsg );

		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, tray.state );

		// 「表示」ボタンを押下したときと同じ挙動にさせる（ STATE = 'SHOW'で呼び出さない ）
		tray.request.setAttribute( "state", "RELOAD" );

		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}

	private MultiEditJinikUploadEvRslt reserveExcelUploadFile( Tray tray, FileItem file, String updFileName ) throws  CareerException, IOException {

		MultiEditJinikUploadEvRslt result = new MultiEditJinikUploadEvRslt();

		InputStream fis = null;

		try {
			fis = file.getInputStream();

			XSSFWorkbook workbook = ( XSSFWorkbook )WorkbookFactory.create( fis );

			XSSFSheet sheet = workbook.getSheet( READ_TARGET_SHEET_NAME );
			if ( sheet == null ) {
				// アップロード可能なファイルの内容ではありません。
				result.resultMsg = CommonLabel.getLabel( "LSHJIN_MSG_CONTENT_FMT_ERR" );
				return result;
			}
			
			XSSFRow row = sheet.getRow( UPLOAD_STATUS_ROW );
			if ( row == null ) {
				// アップロード可能なファイルの内容ではありません。
				result.resultMsg = CommonLabel.getLabel( "LSHJIN_MSG_CONTENT_FMT_ERR" );
				return result;
			}

			try {
				String chkStatus = SU.nvl( getStringRangeValue( row.getCell( UPLOAD_STATUS_COLUMN )), "" );
				if ( SU.equals( chkStatus, STR_UPLOAD_ENABLED )) {
					execReserve( tray, file, updFileName );
					result.resultMsg = CommonLabel.getLabel( "LSHJIN_MSG_ACCEPT_FILE_RESERVE" );
				} else if ( SU.equals( chkStatus, STR_UPLOAD_DISABLED )) {
					result.resultMsg = CommonLabel.getLabel( "LSHJIN_MSG_DISMISS_FILE_RESERVE" );
				} else {
					result.resultMsg = CommonLabel.getLabel( "LSHJIN_MSG_FILE_FMT_ERR" );
				}
			} catch ( Exception e ) {
				// アップロード可能なファイルの内容ではありません。
				result.resultMsg = CommonLabel.getLabel( "LSHJIN_MSG_CONTENT_FMT_ERR" );
				return result;
			}
		} catch( Exception e ) {
			throw new CareerException( e.getMessage());
		} finally {
			fis.close();
		}
		return result;
	}

	private MultiEditJinikUploadEvRslt execReserve( Tray tray, FileItem file, String updFileName ) throws CareerException, UnsupportedEncodingException {

		MultiEditJinikUploadEvArg arg = new MultiEditJinikUploadEvArg( tray.loginNo );

		DiskFileItem diskFileItem = ( DiskFileItem )file;
		String absPath = diskFileItem.getStoreLocation().getAbsolutePath();
		File upload = new File( absPath );

		arg.sharp = "RESERVE";
		arg.rsvGuid = tray.loginNo;
		arg.rsvFileName= updFileName;
		arg.rsvFileContentType = file.getContentType();
		arg.rsvStatus = null;
		arg.uploadFile = upload;

		return MultiEditJinikUploadEvHdlr.exec( arg );
	}

	private static String getStringValue( XSSFCell cell ) {
		String ret = "";
		
		if (cell == null) {
			return ret;
		}
		switch (cell.getCellType()) {
		case XSSFCell.CELL_TYPE_NUMERIC:
			ret = Integer.toString( Integer.valueOf( (int)cell.getNumericCellValue() ) );
			break;
		case XSSFCell.CELL_TYPE_STRING:
			ret = cell.getStringCellValue();
			break;
		case XSSFCell.CELL_TYPE_BOOLEAN:
			ret = Boolean.toString( cell.getBooleanCellValue() );
			break;
		default:
		}

		return ret;
	}

	/**
	 * 結合セルから値を取得する
	 * （指定されたセルと結合している領域から実際に値の入力されているセルを見つけて取得する）
	 * 
	 * @param cell 結合セルの左上
	 * @return
	 */
	private static String getStringRangeValue( XSSFCell cell ) {
		int rowIndex = cell.getRowIndex();
		int columnIndex = cell.getColumnIndex();
		
		XSSFSheet sheet = cell.getSheet();
		int size = sheet.getNumMergedRegions();
		for ( int i= 0; i < size; i++ ) {
			CellRangeAddress range = sheet.getMergedRegion( i );
			if ( range.isInRange( rowIndex, columnIndex )) {
				XSSFCell firstCell = getCell( sheet, range.getFirstRow(), range.getFirstColumn());
				return getStringValue( firstCell );
			}
		}
		return null;
	}

	private static XSSFCell getCell( XSSFSheet sheet, int rowIndex, int columnIndex ) {
		XSSFRow row = sheet.getRow( rowIndex );
		if ( row != null ) {
			XSSFCell cell = row.getCell( columnIndex );
			return cell;
		}
		return null;
	}
}
