package jp.co.hisas.career.app.sheet.event;

import java.util.HashMap;

import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;

@SuppressWarnings("serial")
public class CsSheetEventArg extends AbstractEventArg {
	
	public String sharp = null;
	public String operatorGuid = null;
	public String mailSenderName;
	public String sheetId = null;
	public CstSheetExclusiveDto exclusiveKey = null;
	public HashMap<String, String> fillReqMap = null;
	public String actorCd = null;
	public String actionCd = null;
	public String delivMsg = null;
	public int mokPrgrsPage;
	public HashMap<String, String> optFillReqMap;
	
	public CsSheetEventArg(String loginNo, String operatorGuid) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		if (operatorGuid == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
		this.operatorGuid = operatorGuid;
	}
	
	public void setAll( String sharp, String sheetId, CstSheetExclusiveDto exclusiveKey, HashMap<String, String> fillReqMap, String actorCd, String actionCd ) {
		this.sharp = sharp;
		this.sheetId = sheetId;
		this.exclusiveKey = exclusiveKey;
		this.fillReqMap = fillReqMap;
		this.actorCd = actorCd;
		this.actionCd = actionCd;
	}
	
	public void validateArg() throws CareerException {
		if (this.sharp == null || "".equals( this.sharp.trim() )) {
			throw new CareerException( "Invalid Arg: state is null." );
		}
	}
	
}
