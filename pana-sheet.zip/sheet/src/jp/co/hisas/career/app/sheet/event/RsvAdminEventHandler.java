package jp.co.hisas.career.app.sheet.event;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.ConnDef;
import jp.co.hisas.career.util.log.Log;

public class RsvAdminEventHandler extends AbstractEventHandler<RsvAdminEventArg, RsvAdminEventResult> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static RsvAdminEventResult exec( RsvAdminEventArg arg ) throws CareerException {
		RsvAdminEventHandler handler = new RsvAdminEventHandler();
		return handler.call( arg );
	}
	
	public RsvAdminEventResult call( RsvAdminEventArg arg ) throws CareerException {
		RsvAdminEventResult result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected RsvAdminEventResult execute( RsvAdminEventArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		RsvAdminEventResult result = new RsvAdminEventResult();
		
		try {
			
			if ("CA_REGIST".equals( arg.sharp )) {
				
				result.exitCd = syncCareerPerson();
			}
			else if ("CJS_NINSYOU".equals( arg.sharp )) {
				
				result.exitCd = syncCjsNinsyou();
			}
			else if ("CAREER_MENU_PTN".equals( arg.sharp )) {
				
				result.exitCd = syncCareerMenuPtn();
			}
			
			result.resultMsg = arg.sharp + " の反映が完了しました。";
			
			return result;
			
		} catch (SQLException e) {
			throw new CareerSQLException( e );
		}
	}
	
	private int syncCareerPerson() throws SQLException {
		return execPlpkgFunction( "PLPKG_MIG_AP_CA_REGIST" );
	}
	
	private int syncCjsNinsyou() throws SQLException {
		return execPlpkgFunction( "PLPKG_MIG_AP_NINSYOU" );
	}
	
	private int syncCareerMenuPtn() throws SQLException {
		return execPlpkgFunction( "PLPKG_MIG_AP_MENU_PTN" );
	}
	
	/**
	 * FUNCTION名を指定してPLPKGを呼び出す。
	 * 引数 vRsvUser はログインユーザを自動でセットする。
	 * intでEXITCODEを受け取る。
	 * @param functionName
	 * @return exitCd
	 * @throws SQLException 
	 */
	private int execPlpkgFunction( String functionName ) throws SQLException {
		int exitCd = 0;
		CallableStatement cstmt = null;
		Connection conn = null;
		try {
			InitialContext ctx = new InitialContext();
			DataSource ds = (DataSource)ctx.lookup( ConnDef.DATASOURCE_NAME );
			conn = ds.getConnection();
			cstmt = conn.prepareCall( "{?=call " + functionName + ".MAIN(?,?)}" );
			cstmt.registerOutParameter( 1, java.sql.Types.INTEGER );
			cstmt.setString( 2, this.loginNo ); // Not 統合GUID, ExcelツールによるRSV登録のGUIDと一致させる
			cstmt.setString( 3, "VHA010" );
			cstmt.execute();
			exitCd = cstmt.getInt( 1 );
		} catch (NamingException e) {
			throw new CareerSQLException( e );
		} catch (SQLException e) {
			throw new CareerSQLException( e );
		} finally {
			cstmt.close();
			conn.close();
		}
		return exitCd;
	}
	
}
