package jp.co.hisas.career.app.sheet.garage;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dao.CsmSheetFormGrpDao;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFormGrpDto;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.ValueTextSortDao;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

public class CsMultiSheetGarage extends Garage {

	public CsMultiSheetGarage( String daoLoginNo ) {
		super(daoLoginNo);
	}

	/**
	 * シート検索画面などで使用する、「所属」リストを取得する
	 *
	 * @param operatorGuid 操作者GUID
	 * @param party PARTY
	 * @return <ValueTextSortDto>型のリスト
	 */
	public List<ValueTextSortDto> getDivList( String operatorGuid, String party ) {

		/* シート検索用。組織のシート検索では使用不可。*/
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select /*+ ORDERED */ distinct " );
		sql.append( "        cm.CLS_CD    as value " );
		sql.append( "      , cm.CLS_NM    as text " );
		sql.append( "      , cm.LPAD_SORT as sort " );
		sql.append( "   from CSM_SHEET_OPERATION ope " );
		sql.append( "        inner join CSM_SHEET_FORM form " );
		sql.append( "          on (form.PARTY = ope.PARTY AND form.OPERATION_CD = ope.OPERATION_CD) " );
		sql.append( "        inner join CSM_SHEET_ACTOR mact " );
		sql.append( "          on (mact.FLOW_CD = form.FLOW_CD AND mact.ACTOR_CD <> 'act-owner') " );
		sql.append( "        inner join CST_SHEET st " );
		sql.append( "          on (st.PARTY = ope.PARTY AND st.OPERATION_CD = ope.OPERATION_CD and st.FORM_CD = form.FORM_CD ) " );
		sql.append( "        inner join CST_SHEET_ATTR at " );
		sql.append( "          on (at.SHEET_ID = st.SHEET_ID ) " );
		sql.append( "        left outer join CST_SHEET_ACTOR act " );
		sql.append( "          on (act.SHEET_ID = st.SHEET_ID and act.ACTOR_CD = mact.ACTOR_CD and act.GUID = ?) " );
		sql.append( "        left outer join CST_SHEET_ACTOR_REF ref " );
		sql.append( "          on (ref.SHEET_ID = st.SHEET_ID and ref.ACTOR_CD = mact.ACTOR_CD and ref.GUID = ?) " );
		sql.append( "        inner join AR_SLC_CA_BELONG_CLS_MST cm " );
		sql.append( "          on (cm.SLC_ID = AT.SLC_ID and cm.CMPA_CD = at.CMPA_CD and cm.BEL_CLS = 'C' and cm.CLS_CD = at.CLS_C_CD) " );
		sql.append( "  where ope.PARTY = ? " );
		sql.append( "    and ope.OPERATION_TYPE = 'STAMP' " );
		sql.append( "    and ope.OPEN_FLG = '1' " );
		sql.append( "    and ( act.GUID is not null or ref.GUID is not null ) " );
		sql.append( "  order by cm.LPAD_SORT " );

		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( operatorGuid );
		paramList.add( operatorGuid );
		paramList.add( party );

		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}

	public List<ValueTextSortDto> getDivList( String party ) {
		
		
		return null;
	}
	
	/**
	 * シート検索画面などで使用する、「運用名称」リストを取得する
	 *
	 * @param operatorGuid 操作者GUID
	 * @param party PARTY
	 * @param opeType OPERATION TYPE
	 * @return <ValueTextSortDto>型のリスト
	 */
	public List<ValueTextSortDto> getOpeList( String operatorGuid, String party, String opeType ) {

		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select /*+ ORDERED */ distinct " );
		sql.append( "        ope.OPERATION_CD as value " );
		sql.append( "      , ope.OPERATION_NM as text " );
		sql.append( "      , ope.LPAD_SORT    as sort " );
		sql.append( "   from CSM_SHEET_OPERATION ope " );
		sql.append( "        inner join CSM_SHEET_FORM form " );
		sql.append( "          on (form.PARTY = ope.PARTY AND form.OPERATION_CD = ope.OPERATION_CD) " );
		sql.append( "        inner join CSM_SHEET_ACTOR mact " );
		sql.append( "          on (mact.FLOW_CD = form.FLOW_CD) " );
		sql.append( "        inner join CST_SHEET st " );
		sql.append( "          on (st.PARTY = ope.PARTY AND st.OPERATION_CD = ope.OPERATION_CD and st.FORM_CD = form.FORM_CD ) " );
		sql.append( "        inner join CST_SHEET_ATTR at " );
		sql.append( "          on (at.SHEET_ID = st.SHEET_ID ) " );
		sql.append( "        left outer join CST_SHEET_ACTOR act " );
		sql.append( "          on (act.SHEET_ID = st.SHEET_ID and act.ACTOR_CD = mact.ACTOR_CD and act.GUID = ?) " );
		sql.append( "        left outer join CST_SHEET_ACTOR_REF ref " );
		sql.append( "          on (ref.SHEET_ID = st.SHEET_ID and ref.ACTOR_CD = mact.ACTOR_CD and ref.GUID = ?) " );
		sql.append( "  where ope.PARTY = ? " );
		sql.append( "    and ope.OPERATION_TYPE = ? " );
		sql.append( "    and ope.OPEN_FLG = '1' " );
		sql.append( "    and ( act.GUID is not null or ref.GUID is not null ) " );
		if (!SU.equals( opeType, "CASCADE" )) {
		sql.append( "    and mact.ACTOR_CD <> 'act-owner' " );
		}
		sql.append( "  order by ope.LPAD_SORT desc " );

		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( operatorGuid );
		paramList.add( operatorGuid );
		paramList.add( party );
		paramList.add( opeType );

		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}

	/**
	 * シート検索画面などで使用する、「フローステータス」リストを取得する
	 *
	 * @param party PARTY
	 * @param operationCd 運用コード
	 * @return <ValueTextSortDto>型のリスト
	 */
	public List<ValueTextSortDto> getStatusList( String party, String operationCd ) {

		if ( SU.isEmpty( operationCd )) { return null; }

		/* Dynamic SQL */
		StringBuilder gsql = new StringBuilder();
		gsql.append( " select" + CsmSheetFormGrpDao.ALLCOLS );
		gsql.append( "   from CSM_SHEET_FORM_GRP " );
		gsql.append( "  where PARTY = ? " );
		gsql.append( "    and OPERATION_CD = ? " );
		gsql.append( "  order by FORM_GRP_CD " );

		/* Parameter List */
		ArrayList<String> gParamList = new ArrayList<String>();
		gParamList.add( party );
		gParamList.add( operationCd );

		CsmSheetFormGrpDao gDao = new CsmSheetFormGrpDao( daoLoginNo );
		List<CsmSheetFormGrpDto> gDtoList = gDao.selectDynamic( DaoUtil.getPstmt( gsql, gParamList ) );
		CsmSheetFormGrpDto gDto = gDtoList.get( 0 );
		String formGrpCd = gDto.getFormGrpCd();
		if (formGrpCd == null) { return null; }

		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select STATUS_CD as value, STATUS_NM as text, SEQ_NO as sort " );
		sql.append( "   from CSM_SHEET_FLOW " );
		sql.append( "  where FLOW_CD = ? " );
		sql.append( "  order by SEQ_NO " );

		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		String flowCd = formGrpCd.replaceAll( "^grp-", "flw-" );
		paramList.add( flowCd );

		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
}
