/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSMシート回答マスク Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetFillMaskDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * マスクコード
     */
    private String maskCd;
    /**
     * ステータスコード
     */
    private String statusCd;
    /**
     * アクターコード
     */
    private String actorCd;
    /**
     * 回答ID
     */
    private String fillId;
    /**
     * Read or Write
     */
    private String readOrWrite;

    /**
     * マスクコードを取得する。
     * @return マスクコード
     */
    public String getMaskCd() {
        return maskCd;
    }

    /**
     * マスクコードを設定する。
     * @param maskCd マスクコード
     */
    public void setMaskCd(String maskCd) {
        this.maskCd = maskCd;
    }

    /**
     * ステータスコードを取得する。
     * @return ステータスコード
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * ステータスコードを設定する。
     * @param statusCd ステータスコード
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * アクターコードを取得する。
     * @return アクターコード
     */
    public String getActorCd() {
        return actorCd;
    }

    /**
     * アクターコードを設定する。
     * @param actorCd アクターコード
     */
    public void setActorCd(String actorCd) {
        this.actorCd = actorCd;
    }

    /**
     * 回答IDを取得する。
     * @return 回答ID
     */
    public String getFillId() {
        return fillId;
    }

    /**
     * 回答IDを設定する。
     * @param fillId 回答ID
     */
    public void setFillId(String fillId) {
        this.fillId = fillId;
    }

    /**
     * Read or Writeを取得する。
     * @return Read or Write
     */
    public String getReadOrWrite() {
        return readOrWrite;
    }

    /**
     * Read or Writeを設定する。
     * @param readOrWrite Read or Write
     */
    public void setReadOrWrite(String readOrWrite) {
        this.readOrWrite = readOrWrite;
    }

}

