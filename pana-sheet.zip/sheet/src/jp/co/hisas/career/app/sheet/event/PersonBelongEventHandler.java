package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.VPersonBelongUnionExDao;
import jp.co.hisas.career.util.dto.VPersonBelongUnionExDto;
import jp.co.hisas.career.util.log.Log;

public class PersonBelongEventHandler extends AbstractEventHandler<PersonBelongEventArg, PersonBelongEventResult> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static PersonBelongEventResult exec( PersonBelongEventArg arg ) throws CareerException {
		PersonBelongEventHandler handler = new PersonBelongEventHandler();
		return handler.call( arg );
	}
	
	public PersonBelongEventResult call( PersonBelongEventArg arg ) throws CareerException {
		PersonBelongEventResult result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected PersonBelongEventResult execute( PersonBelongEventArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		PersonBelongEventResult result = new PersonBelongEventResult();
		
		try {
			
			if ("UNION".equals( arg.sharp )) {
				// UNION: 本務＋兼務
				List<VPersonBelongUnionExDto> belList = selectBelongsWithCond( arg );
				result.setBelList( belList );
			}
			
			return result;
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
	}
	
	private List<VPersonBelongUnionExDto> selectBelongsWithCond( PersonBelongEventArg arg ) throws Exception {
		
		HashMap<String, String> map = arg.srchCondMap;
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select rm.GUID, " + SU.addPrefixOnDaoAllCols( "pb", VPersonBelongUnionExDao.ALLCOLS ) );
		sql.append( "   from V_PERSON_BELONG_UNION pb ");
		sql.append( "        inner join CA_REGIST_MAIN rm ");
		sql.append( "          on (rm.CMPA_CD = pb.CMPA_CD and rm.STF_NO = pb.STF_NO) ");
		sql.append( "        inner join CA_PARTY_COMPANY pc ");
		sql.append( "          on (pc.CMPA_CD = pb.CMPA_CD and pc.PARTY = ?) ");	paramList.add( arg.party );
		sql.append( "  where 1 = 1 ");
		sql.append( "    and pb.CLS_E_CD <> '0' ");
		if (srchCondAvailable(map, "SrchCondPersonNm" )) {
			sql.append( "    and pb.PERSON_NAME like ? ");		paramList.add( "%" + map.get( "SrchCondPersonNm" ) + "%" );
		}
		if (srchCondAvailable(map, "SrchCondShozoku" )) {
			sql.append( "    and pb.DEPT_NM like ? ");			paramList.add( "%" + map.get( "SrchCondShozoku" ) + "%" );
		}
		if (srchCondAvailable(map, "SrchCondGlobalId" )) {
			sql.append( "    and pb.STF_NO like ? ");		paramList.add( "%" + map.get( "SrchCondGlobalId" ) + "%" );
		}
		sql.append( " order by BEL_SORT ");
		
		VPersonBelongUnionExDao dao = new VPersonBelongUnionExDao( this.loginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private boolean srchCondAvailable( HashMap<String, String> srchCondMap, String key ) {
		if (srchCondMap == null) {
			return false;
		}
		if (!srchCondMap.containsKey( key )) {
			return false;
		}
		String val = srchCondMap.get( key );
		if (val == null || "".equals( val )) {
			return false;
		}
		return true;
	}
}
