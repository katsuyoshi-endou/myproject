/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.ZzUncreatedWkDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * ZZ_UNCREATED_WK Data Access Object。
 * @author CareerDaoTool.xla
*/
public class ZzUncreatedWkDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " LOGIN_PERSON_ID as loginPersonId,"
                     + " OPERATION_CD as operationCd,"
                     + " OWN_GUID as ownGuid,"
                     + " OWN_PERSON_NAME as ownPersonName,"
                     + " OWN_PERSON_NAME_KANA as ownPersonNameKana,"
                     + " OWN_CMPA_CD as ownCmpaCd,"
                     + " OWN_FULL_DEPT_NM as ownFullDeptNm,"
                     + " OWN_MAIL_ADDRESS as ownMailAddress,"
                     + " SHEET_STATUS as sheetStatus"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public ZzUncreatedWkDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public ZzUncreatedWkDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * Insert文を実行する。
     * @param dto ZZ_UNCREATED_WKのデータ。
     */ 
    public void insert(ZzUncreatedWkDto dto) {

        final String sql = "INSERT INTO ZZ_UNCREATED_WK ("
                         + "LOGIN_PERSON_ID,"
                         + "OPERATION_CD,"
                         + "OWN_GUID,"
                         + "OWN_PERSON_NAME,"
                         + "OWN_PERSON_NAME_KANA,"
                         + "OWN_CMPA_CD,"
                         + "OWN_FULL_DEPT_NM,"
                         + "OWN_MAIL_ADDRESS"
                         + ")VALUES(?,?,?,?,?,?,?,? )"
                         ;
        Log.sql("【DaoMethod Call】 ZzUncreatedWkDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getLoginPersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getOperationCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getOwnGuid());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getOwnPersonName());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getOwnPersonNameKana());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getOwnCmpaCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getOwnFullDeptNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 8, dto.getOwnMailAddress());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してdelete文を実行する。
     * @param loginPersonId LOGIN_PERSON_ID
     * @param operationCd OPERATION_CD
     * @param ownGuid OWN_GUID
     */ 
    public void delete(String loginPersonId, String operationCd, String ownGuid) {

        final String sql = "DELETE FROM ZZ_UNCREATED_WK"
                         + " WHERE LOGIN_PERSON_ID = ?"
                         + " AND OPERATION_CD = ?"
                         + " AND OWN_GUID = ?"
                         ;
        Log.sql("【DaoMethod Call】 ZzUncreatedWkDao.delete");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, loginPersonId);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, operationCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, ownGuid);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally { 
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param loginPersonId LOGIN_PERSON_ID
     * @param operationCd OPERATION_CD
     * @param ownGuid OWN_GUID
     * @return ZzUncreatedWkDto ZZ_UNCREATED_WKのレコード型データ。
     */ 
    public ZzUncreatedWkDto select(String loginPersonId, String operationCd, String ownGuid) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM ZZ_UNCREATED_WK"
                         + " WHERE LOGIN_PERSON_ID = ?"
                         + " AND OPERATION_CD = ?"
                         + " AND OWN_GUID = ?"
                         ;
        Log.sql("【DaoMethod Call】 ZzUncreatedWkDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, loginPersonId);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, operationCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, ownGuid);
            rs = pstmt.executeQuery();
            ZzUncreatedWkDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<ZzUncreatedWkDto> ZZ_UNCREATED_WKのレコード型データのリスト。
     */ 
    public List<ZzUncreatedWkDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 ZzUncreatedWkDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<ZzUncreatedWkDto> lst = new ArrayList<ZzUncreatedWkDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<ZzUncreatedWkDto> ZZ_UNCREATED_WKのレコード型データのリスト。
     */ 
    public List<ZzUncreatedWkDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 ZzUncreatedWkDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * 動的SELECT COUNT 文を実行する。
     * @param pstmt PreparedStatement
     * @return レコード件数。
     */ 
    public int selectCountDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 ZzUncreatedWkDao.selectCountDynamic");
        ResultSet rs = null;
        int cnt = 0;
        try {
            rs = pstmt.executeQuery();
            if ( rs.next() ) {
                cnt = rs.getInt(1);
            }
            return cnt;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT COUNT 文を実行する。
     * @param sql SQL文
     * @return レコード件数。
     */ 
    public int selectCountDynamic(String sql) {

        Log.sql("【DaoMethod Call】 ZzUncreatedWkDao.selectCountDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectCountDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param pstmt PreparedStatement
     */ 
    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("【DaoMethod Call】 ZzUncreatedWkDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param sql SQL文
     */ 
    public void executeDynamic(String sql) {

        Log.sql("【DaoMethod Call】 ZzUncreatedWkDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private ZzUncreatedWkDto transferRsToDto(ResultSet rs) throws SQLException {

        ZzUncreatedWkDto dto = new ZzUncreatedWkDto();
        dto.setLoginPersonId(DaoUtil.convertNullToString(rs.getString("loginPersonId")));
        dto.setOperationCd(DaoUtil.convertNullToString(rs.getString("operationCd")));
        dto.setOwnGuid(DaoUtil.convertNullToString(rs.getString("ownGuid")));
        dto.setOwnPersonName(DaoUtil.convertNullToString(rs.getString("ownPersonName")));
        dto.setOwnPersonNameKana(DaoUtil.convertNullToString(rs.getString("ownPersonNameKana")));
        dto.setOwnCmpaCd(DaoUtil.convertNullToString(rs.getString("ownCmpaCd")));
        dto.setOwnFullDeptNm(DaoUtil.convertNullToString(rs.getString("ownFullDeptNm")));
        dto.setOwnMailAddress(DaoUtil.convertNullToString(rs.getString("ownMailAddress")));
        dto.setSheetStatus(DaoUtil.convertNullToString( rs.getString("sheetStatus")));
        return dto;
    }

    /**
     * ログイン人IDに紐付くデータを全て削除する
     * @param loginPersonId ログイン人ID
     */
    public void deleteByLoginPersonID(String loginPersonId) {

        final String sql = "delete from ZZ_UNCREATED_WK where LOGIN_PERSON_ID = ?";
        Log.sql("【DaoMethod Call】 ZzUncreatedWkDao.deleteByLoginPersonID");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, loginPersonId);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

}

