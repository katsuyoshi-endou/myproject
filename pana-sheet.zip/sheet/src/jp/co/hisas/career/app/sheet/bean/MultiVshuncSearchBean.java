package jp.co.hisas.career.app.sheet.bean;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.CareerMenuBean;
import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.event.MultiVshuncEventArg;
import jp.co.hisas.career.app.sheet.event.MultiVshuncEventHandler;
import jp.co.hisas.career.app.sheet.event.MultiVshuncEventResult;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.app.sheet.util.MultiVshuncSheet;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;

public class MultiVshuncSearchBean {

	private String loginNo;
	private String operatorGuid;
	private HttpServletRequest request;
	private HttpSession session;

	public MultiVshuncSearchBean(String loginNo, String operatorGuid) {
		this.loginNo = loginNo;
		this.operatorGuid = operatorGuid;
	}

	public void execMultiSheetSearch( String state, final HttpServletRequest req, String opeType ) throws CareerException {
		this.request = req;
		this.session = request.getSession( false );

		CareerMenuBean oneMenu = AU.getSessionAttr( session, AppSessionKey.CAREER_ONE_MENU );
		String party = oneMenu.party;
		String trans = oneMenu.menuTrans;
		

		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( session, UserInfoBean.SESSION_KEY );
		this.operatorGuid = userInfo.getOperatorGuid();

		// 画面表示情報
		MultiVshuncSheet multiSheet = AU.getSessionAttr( session, CsSessionKey.VSHUNC_SEARCH );
		multiSheet = (multiSheet != null) ? multiSheet : new MultiVshuncSheet( loginNo, operatorGuid );
		multiSheet.gamenCondMap = makeSrchCondMap( party );

		// 運用コード
		String operationCd  = CsUtil.getRequestValue( request, "operationCd" );
		multiSheet.gamenCondMap.put( "operationCd", operationCd );

		/* 初期表示リスト検索 */
		MultiVshuncEventResult preRslt = execEventPrepare( party, opeType, operationCd);
		
		// 運用名称セット
		multiSheet.operationNm = preRslt.getOperation().getOperationNm();
		
		if ("SEARCH".equals( state )) {
			multiSheet.gamenCondMap = makeSrchCondMap( party );

			MultiVshuncEventResult saerchRslt = execEventSearch( operationCd, party, multiSheet.gamenCondMap);
			
			// 一覧データセット
			multiSheet.uncreatedsheetList = saerchRslt.getUnCreatedList();
			// データ件数セット
			multiSheet.hitCnt = saerchRslt.hitCnt;

		}
		else if ("EXCEL_DL".equals( state )) {
			// ワークテーブルの作成
			execEventExcelDL( operationCd, party, multiSheet.gamenCondMap);
		}
		else {
			// 何もしない
		}
//		String operationCd  = multiSheet.gamenCondMap.get( "operationCd" );

		if (!SU.matches( state, "INIT|SEARCH|CHANGE_OPERATION" )) {
			operationCd = multiSheet.gamenCondMap.get( "operationCd" );
		}

		/* CS_MULTI_SHEET */
		session.setAttribute( CsSessionKey.VSHUNC_RESULT, multiSheet );

	}

	private HashMap<String, String> makeSrchCondMap( String party ) {

		String operationCd = CsUtil.getRequestValue( request, "operationCd" );
		String personId  = CsUtil.getRequestValue( request, "personId" );
		String deptNm  = CsUtil.getRequestValue( request, "deptNm" );
		String personNm  = CsUtil.getRequestValue( request, "personNm" );
		String personNmKn  = CsUtil.getRequestValue( request, "personNmKn" );
		
		
		HashMap<String, String> srchCondMap = new HashMap<String, String>();
		srchCondMap.put( "operationCd", operationCd );
		srchCondMap.put( "personId",    personId );
		srchCondMap.put( "deptNm",      deptNm );
		srchCondMap.put( "personNm",    personNm );
		srchCondMap.put( "personNmKn",  personNmKn );
		return srchCondMap;
	}

	private MultiVshuncEventResult execEventPrepare( String party, String opeType, String operationCd) throws CareerException {
		MultiVshuncEventArg arg = new MultiVshuncEventArg( loginNo, operatorGuid );
		arg.sharp = "PREPARE";
		arg.party = party;
		arg.opeType = opeType;
		arg.srchCondMap = new HashMap<String, String>();
		arg.operationCd = operationCd;
		return MultiVshuncEventHandler.exec( arg );
	}

	private MultiVshuncEventResult execEventSearch( String operationCd, String party, HashMap<String, String> srchCondMap ) throws CareerException {
		MultiVshuncEventArg arg = new MultiVshuncEventArg( loginNo, operatorGuid );
		arg.party = party;
		arg.setAll( "SEARCH", operationCd );
		arg.srchCondMap = srchCondMap;
		return MultiVshuncEventHandler.exec( arg );
	}

	private MultiVshuncEventResult execEventExcelDL( String operationCd, String party, HashMap<String, String> srchCondMap ) throws CareerException {
		MultiVshuncEventArg arg = new MultiVshuncEventArg( loginNo, operatorGuid );
		arg.party = party;
		arg.setAll( "EXCEL_DL", operationCd );
		arg.srchCondMap = srchCondMap;
		return MultiVshuncEventHandler.exec( arg );
	}

}
