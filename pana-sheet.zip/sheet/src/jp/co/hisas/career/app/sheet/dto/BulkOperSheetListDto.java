package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class BulkOperSheetListDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * SHEET_ID
     */
    private String sheetId;

    /**
     * OPERATION_NM
     */
    private String operationNm;

    /**
     * OWN_PERSON_NAME
     */
    private String ownPersonName;

    /**
     * FULL_DEPT_NM
     */
    private String fullDeptNm;

    /**
     * CMPA_CD
     */
    private String cmpaCd;

    /**
     * STATUS_NM
     */
    private String statusNm;

    /**
     * ACTOR_1ST_NM
     */
    private String actor1stNm;

    /**
     * ACTOR_2ND_NM
     */
    private String actor2ndNm;

    /**
     * ACTOR_3RD_NM
     */
    private String actor3rdNm;

    /**
     * ACTOR_4TH_NM
     */
    private String actor4thNm;

    /**
     * EXCLUSIVE_KEY
     */
    private String exclusiveKey;

    /**
     * WK_IDX
     */
    private Integer wkIdx;

	/**
     * SHEET_IDを取得する
     * @return
     */
    public String getSheetId() {
		return sheetId;
	}

    /**
     * SHEET_IDを設定する
     * @param sheetId
     */
	public void setSheetId(String sheetId) {
		this.sheetId = sheetId;
	}

	/**
     * OPERATION_NMを取得する
     * @return
     */
    public String getOperationNm() {
		return operationNm;
	}

    /**
     * OPERATION_NMを設定する
     * @param operationNm
     */
    public void setOperationNm(String operationNm) {
		this.operationNm = operationNm;
	}

    /**
     * OWN_PERSON_NAMEを取得する
     * @return
     */
	public String getOwnPersonName() {
		return ownPersonName;
	}

    /**
     * OWN_PERSON_NAMEを設定する
     * @param ownPersonName
     */
	public void setOwnPersonName(String ownPersonName) {
		this.ownPersonName = ownPersonName;
	}

    /**
     * FULL_DEPT_NMを取得する
     * @return
     */
	public String getFullDeptNm() {
		return fullDeptNm;
	}

    /**
     * FULL_DEPT_NMを設定する
     * @param fullDeptNm
     */
	public void setFullDeptNm(String fullDeptNm) {
		this.fullDeptNm = fullDeptNm;
	}

    /**
     * CMPA_CDを取得する
     * @return
     */
	public String getCmpaCd() {
		return cmpaCd;
	}

    /**
     * CMPA_CDを設定する
     * @param cmpaCd
     */
	public void setCmpaCd(String cmpaCd) {
		this.cmpaCd = cmpaCd;
	}

    /**
     * STATUS_NMを取得する
     * @return
     */
	public String getStatusNm() {
		return statusNm;
	}

    /**
     * STATUS_NMを設定する
     * @param statusNm
     */
	public void setStatusNm(String statusNm) {
		this.statusNm = statusNm;
	}

    /**
     * ACTOR_1ST_NMを取得する
     * @return
     */
	public String getActor1stNm() {
		return actor1stNm;
	}

    /**
     * ACTOR_1ST_NMを設定する
     * @param actor1stNm
     */
	public void setActor1stNm(String actor1stNm) {
		this.actor1stNm = actor1stNm;
	}

    /**
     * ACTOR_2ND_NMを取得する
     * @return
     */
	public String getActor2ndNm() {
		return actor2ndNm;
	}

    /**
     * ACTOR_2ND_NMを設定する
     * @param actor2ndNm
     */
	public void setActor2ndNm(String actor2ndNm) {
		this.actor2ndNm = actor2ndNm;
	}

    /**
     * ACTOR_3RD_NMを取得する
     * @return
     */
	public String getActor3rdNm() {
		return actor3rdNm;
	}

    /**
     * ACTOR_3RD_NMを設定する
     * @param actor3rdNm
     */
	public void setActor3rdNm(String actor3rdNm) {
		this.actor3rdNm = actor3rdNm;
	}

    /**
     * ACTOR_4TH_NMを取得する
     * @return
     */
	public String getActor4thNm() {
		return actor4thNm;
	}

    /**
     * ACTOR_4TH_NMを設定する
     * @param actor4thNm
     */
	public void setActor4thNm(String actor4thNm) {
		this.actor4thNm = actor4thNm;
	}

	/**
     * EXCLUSIVE_KEYを取得する
     * @return
     */
    public String getExclusiveKey() {
		return exclusiveKey;
	}

    /**
     * EXCLUSIVE_KEYを設定する
     * @param exclusiveKey
     */
	public void setExclusiveKey(String exclusiveKey) {
		this.exclusiveKey = exclusiveKey;
	}

	/**
     * WK_IDXを取得する
     * @return
     */
	public Integer getWkIdx() {
		return wkIdx;
	}

    /**
     * WK_IDXを設定する
     * @param wkIdx
     */
	public void setWkIdx(Integer wkIdx) {
		this.wkIdx = wkIdx;
	}
}
