package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dao.CstSheetDao;
import jp.co.hisas.career.app.sheet.dao.VCstSheetActorAndRefDao;
import jp.co.hisas.career.app.sheet.dto.CstSheetDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActorAndRefDto;
import jp.co.hisas.career.app.sheet.garage.GetActorListGarage;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.OneColumnDao;
import jp.co.hisas.career.util.log.Log;

public class CsSheetPastEvHdlr extends AbstractEventHandler<CsSheetPastEvArg, CsSheetPastEvRslt> {
	
	private String loginNo;
	
	public static CsSheetPastEvRslt exec( CsSheetPastEvArg arg ) throws CareerException {
		CsSheetPastEvHdlr handler = new CsSheetPastEvHdlr();
		return handler.call( arg );
	}
	
	public CsSheetPastEvRslt call( CsSheetPastEvArg arg ) throws CareerException {
		CsSheetPastEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		}
		else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CsSheetPastEvRslt execute( CsSheetPastEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		CsSheetPastEvRslt result = new CsSheetPastEvRslt();
		
		try {
			//過去シートID取得
			if (SU.equals( "PAST_SHEET_ID", arg.sharp )) {
				String relatedId = arg.relatedId;
				result.relatedSheetId = getRelatedSheetId(arg, relatedId);
				
			}
			//過去シート参照用アクターコードリスト取得
			else if ("PAST_ACTOR".equals( arg.sharp )) {
				GetActorListGarage galg = new GetActorListGarage( this.loginNo ); 
				List<VCstSheetActorAndRefDto> actorCdList = galg.getActorList( arg.sheetId, arg.operatorGuid );
				result.actorCdList = actorCdList;
			}
			//シート存在チェック
			else if ("SHEET_EXISTANCE".equals( arg.sharp )) {
				boolean sheetExists = sheetExistanceChk( arg.sheetId );
				if( sheetExists ) {
					result.sheetExistance = true;
				} else {
					result.sheetExistance = false;
				}
			}
			
			return result;
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
	}

	private boolean sheetExistanceChk( String sheetId ) {
		
		CstSheetDao dao = new CstSheetDao( this.loginNo );
		CstSheetDto dto = dao.select( sheetId );
		return (dto != null);
	}

	private String getRelatedSheetId( CsSheetPastEvArg arg, String relatedId ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select FILL_CONTENT as text " );
		sql.append( " from CST_SHEET_FILL " );
		sql.append( " where SHEET_ID = ? " );
		sql.append( "   and FILL_ID = ? " );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.sheetId );
		paramList.add( relatedId );
		
		OneColumnDao dao = new OneColumnDao( this.loginNo );
		String relatedSheetId = dao.selectDynamicFirst( DaoUtil.getPstmt( sql, paramList ) );
		return relatedSheetId;
		
	}


}
