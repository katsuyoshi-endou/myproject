/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSTシートリストビュー Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VCstSheetListDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * SHEET_ID
     */
    private String sheetId;
    /**
     * PARTY
     */
    private String party;
    /**
     * OPERATION_CD
     */
    private String operationCd;
    /**
     * OPERATION_NM
     */
    private String operationNm;
    /**
     * OPERATION_SORT
     */
    private String operationSort;
    /**
     * ACTIVE_FLG
     */
    private String activeFlg;
    /**
     * FORM_GRP_CD
     */
    private String formGrpCd;
    /**
     * FORM_GRP_NM
     */
    private String formGrpNm;
    /**
     * FORM_CD
     */
    private String formCd;
    /**
     * FORM_NM
     */
    private String formNm;
    /**
     * OWN_GUID
     */
    private String ownGuid;
    /**
     * PERSON_NAME
     */
    private String personName;
    /**
     * SHEET_SORT
     */
    private String sheetSort;
    /**
     * LIST_COL1
     */
    private String listCol1;
    /**
     * LIST_COL2
     */
    private String listCol2;
    /**
     * LIST_COL3
     */
    private String listCol3;
    /**
     * LIST_COL4
     */
    private String listCol4;
    /**
     * LIST_COL5
     */
    private String listCol5;
    /**
     * LIST_COL6
     */
    private String listCol6;
    /**
     * LIST_COL7
     */
    private String listCol7;
    /**
     * LIST_COL8
     */
    private String listCol8;
    /**
     * LIST_COL9
     */
    private String listCol9;
    /**
     * LIST_COL10
     */
    private String listCol10;
    /**
     * STATUS_CD
     */
    private String statusCd;
    /**
     * STATUS_NM
     */
    private String statusNm;
    /**
     * HOLD_GUID
     */
    private String holdGuid;
    /**
     * LATEST_TIMESTAMP
     */
    private String latestTimestamp;
    /**
     * DEPT_CD
     */
    private String deptCd;

    /**
     * SHEET_IDを取得する。
     * @return SHEET_ID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * SHEET_IDを設定する。
     * @param sheetId SHEET_ID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * OPERATION_CDを取得する。
     * @return OPERATION_CD
     */
    public String getOperationCd() {
        return operationCd;
    }

    /**
     * OPERATION_CDを設定する。
     * @param operationCd OPERATION_CD
     */
    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    /**
     * OPERATION_NMを取得する。
     * @return OPERATION_NM
     */
    public String getOperationNm() {
        return operationNm;
    }

    /**
     * OPERATION_NMを設定する。
     * @param operationNm OPERATION_NM
     */
    public void setOperationNm(String operationNm) {
        this.operationNm = operationNm;
    }

    /**
     * OPERATION_SORTを取得する。
     * @return OPERATION_SORT
     */
    public String getOperationSort() {
        return operationSort;
    }

    /**
     * OPERATION_SORTを設定する。
     * @param operationSort OPERATION_SORT
     */
    public void setOperationSort(String operationSort) {
        this.operationSort = operationSort;
    }

    /**
     * ACTIVE_FLGを取得する。
     * @return ACTIVE_FLG
     */
    public String getActiveFlg() {
        return activeFlg;
    }

    /**
     * ACTIVE_FLGを設定する。
     * @param activeFlg ACTIVE_FLG
     */
    public void setActiveFlg(String activeFlg) {
        this.activeFlg = activeFlg;
    }

    /**
     * FORM_GRP_CDを取得する。
     * @return FORM_GRP_CD
     */
    public String getFormGrpCd() {
        return formGrpCd;
    }

    /**
     * FORM_GRP_CDを設定する。
     * @param formGrpCd FORM_GRP_CD
     */
    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    /**
     * FORM_GRP_NMを取得する。
     * @return FORM_GRP_NM
     */
    public String getFormGrpNm() {
        return formGrpNm;
    }

    /**
     * FORM_GRP_NMを設定する。
     * @param formGrpNm FORM_GRP_NM
     */
    public void setFormGrpNm(String formGrpNm) {
        this.formGrpNm = formGrpNm;
    }

    /**
     * FORM_CDを取得する。
     * @return FORM_CD
     */
    public String getFormCd() {
        return formCd;
    }

    /**
     * FORM_CDを設定する。
     * @param formCd FORM_CD
     */
    public void setFormCd(String formCd) {
        this.formCd = formCd;
    }

    /**
     * FORM_NMを取得する。
     * @return FORM_NM
     */
    public String getFormNm() {
        return formNm;
    }

    /**
     * FORM_NMを設定する。
     * @param formNm FORM_NM
     */
    public void setFormNm(String formNm) {
        this.formNm = formNm;
    }

    /**
     * OWN_GUIDを取得する。
     * @return OWN_GUID
     */
    public String getOwnGuid() {
        return ownGuid;
    }

    /**
     * OWN_GUIDを設定する。
     * @param ownGuid OWN_GUID
     */
    public void setOwnGuid(String ownGuid) {
        this.ownGuid = ownGuid;
    }

    /**
     * PERSON_NAMEを取得する。
     * @return PERSON_NAME
     */
    public String getPersonName() {
        return personName;
    }

    /**
     * PERSON_NAMEを設定する。
     * @param personName PERSON_NAME
     */
    public void setPersonName(String personName) {
        this.personName = personName;
    }

    /**
     * SHEET_SORTを取得する。
     * @return SHEET_SORT
     */
    public String getSheetSort() {
        return sheetSort;
    }

    /**
     * SHEET_SORTを設定する。
     * @param sheetSort SHEET_SORT
     */
    public void setSheetSort(String sheetSort) {
        this.sheetSort = sheetSort;
    }

    /**
     * LIST_COL1を取得する。
     * @return LIST_COL1
     */
    public String getListCol1() {
        return listCol1;
    }

    /**
     * LIST_COL1を設定する。
     * @param listCol1 LIST_COL1
     */
    public void setListCol1(String listCol1) {
        this.listCol1 = listCol1;
    }

    /**
     * LIST_COL2を取得する。
     * @return LIST_COL2
     */
    public String getListCol2() {
        return listCol2;
    }

    /**
     * LIST_COL2を設定する。
     * @param listCol2 LIST_COL2
     */
    public void setListCol2(String listCol2) {
        this.listCol2 = listCol2;
    }

    /**
     * LIST_COL3を取得する。
     * @return LIST_COL3
     */
    public String getListCol3() {
        return listCol3;
    }

    /**
     * LIST_COL3を設定する。
     * @param listCol3 LIST_COL3
     */
    public void setListCol3(String listCol3) {
        this.listCol3 = listCol3;
    }

    /**
     * LIST_COL4を取得する。
     * @return LIST_COL4
     */
    public String getListCol4() {
        return listCol4;
    }

    /**
     * LIST_COL4を設定する。
     * @param listCol4 LIST_COL4
     */
    public void setListCol4(String listCol4) {
        this.listCol4 = listCol4;
    }

    /**
     * LIST_COL5を取得する。
     * @return LIST_COL5
     */
    public String getListCol5() {
        return listCol5;
    }

    /**
     * LIST_COL5を設定する。
     * @param listCol5 LIST_COL5
     */
    public void setListCol5(String listCol5) {
        this.listCol5 = listCol5;
    }

    /**
     * LIST_COL6を取得する。
     * @return LIST_COL6
     */
    public String getListCol6() {
        return listCol6;
    }

    /**
     * LIST_COL6を設定する。
     * @param listCol6 LIST_COL6
     */
    public void setListCol6(String listCol6) {
        this.listCol6 = listCol6;
    }

    /**
     * LIST_COL7を取得する。
     * @return LIST_COL7
     */
    public String getListCol7() {
        return listCol7;
    }

    /**
     * LIST_COL7を設定する。
     * @param listCol7 LIST_COL7
     */
    public void setListCol7(String listCol7) {
        this.listCol7 = listCol7;
    }

    /**
     * LIST_COL8を取得する。
     * @return LIST_COL8
     */
    public String getListCol8() {
        return listCol8;
    }

    /**
     * LIST_COL8を設定する。
     * @param listCol8 LIST_COL8
     */
    public void setListCol8(String listCol8) {
        this.listCol8 = listCol8;
    }

    /**
     * LIST_COL9を取得する。
     * @return LIST_COL9
     */
    public String getListCol9() {
        return listCol9;
    }

    /**
     * LIST_COL9を設定する。
     * @param listCol9 LIST_COL9
     */
    public void setListCol9(String listCol9) {
        this.listCol9 = listCol9;
    }

    /**
     * LIST_COL10を取得する。
     * @return LIST_COL10
     */
    public String getListCol10() {
        return listCol10;
    }

    /**
     * LIST_COL10を設定する。
     * @param listCol10 LIST_COL10
     */
    public void setListCol10(String listCol10) {
        this.listCol10 = listCol10;
    }

    /**
     * STATUS_CDを取得する。
     * @return STATUS_CD
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * STATUS_CDを設定する。
     * @param statusCd STATUS_CD
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * STATUS_NMを取得する。
     * @return STATUS_NM
     */
    public String getStatusNm() {
        return statusNm;
    }

    /**
     * STATUS_NMを設定する。
     * @param statusNm STATUS_NM
     */
    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    /**
     * HOLD_GUIDを取得する。
     * @return HOLD_GUID
     */
    public String getHoldGuid() {
        return holdGuid;
    }

    /**
     * HOLD_GUIDを設定する。
     * @param holdGuid HOLD_GUID
     */
    public void setHoldGuid(String holdGuid) {
        this.holdGuid = holdGuid;
    }

    /**
     * LATEST_TIMESTAMPを取得する。
     * @return LATEST_TIMESTAMP
     */
    public String getLatestTimestamp() {
        return latestTimestamp;
    }

    /**
     * LATEST_TIMESTAMPを設定する。
     * @param latestTimestamp LATEST_TIMESTAMP
     */
    public void setLatestTimestamp(String latestTimestamp) {
        this.latestTimestamp = latestTimestamp;
    }

    /**
     * DEPT_CDを取得する。
     * @return DEPT_CD
     */
    public String getDeptCd() {
        return deptCd;
    }

    /**
     * DEPT_CDを設定する。
     * @param deptCd DEPT_CD
     */
    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

}

