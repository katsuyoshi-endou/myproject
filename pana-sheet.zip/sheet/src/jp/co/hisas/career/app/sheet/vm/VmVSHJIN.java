package jp.co.hisas.career.app.sheet.vm;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.ViewModel;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.Tray;

public class VmVSHJIN extends ViewModel {
	
	public static String VMID = VmVSHJIN.class.getSimpleName();
	public Map<String, String> jotaiMap;
	
	public VmVSHJIN(Tray tray) throws CareerException {
		super( tray );
		this.prepareLabels();
		
	}
	
	private void prepareLabels() {
		List<String> l = new ArrayList<String>();
		l.add( "LSHJIN_TOOLTIP_KENSAKU_STATUS" );
		l.add( "LSHJIN_TOOLTIP_KENSAKU_ACTOR" );
		l.add( "LSHJIN_TOOLTIP_KENSAKU_YKSK" );
		l.add( "LSHJIN_TOOLTIP_KENSAKU_YKSKBNRI" );
		l.add( "LSHJIN_TOOLTIP_KENSAKU_ROTATION" );
		l.add( "LSHJIN_TOOLTIP_KENSAKU_KEIKANEN" );
		l.add( "LSHJIN_TOOLTIP_KENSAKU_IDOUKEIKAKUUMU" );
		l.add( "LSHJIN_TOOLTIP_KENSAKU_IDOUKEIKAKUNENDO" );
		l.add( "LSHJIN_TOOLTIP_KENSAKU_TAISHOKUYOTEI" );
		l.add( "LSHJIN_TOOLTIP_KENSAKU_SHOKUMU" );
		l.add( "LSHJIN_TOOLTIP_KENSAKU_JIGYOJO" );
		l.add( "LSHJIN_TOOLTIP_KENSAKU_KYOTEN" );
		l.add( "LSHJIN_TOOLTIP_ICHIRAN_BULK" );
		l.add( "LSHJIN_TOOLTIP_ICHIRAN_STATUS" );
		l.add( "LSHJIN_TOOLTIP_ICHIRAN_NAME" );
		l.add( "LSHJIN_TOOLTIP_ICHIRAN_DEPT" );
		l.add( "LSHJIN_TOOLTIP_ICHIRAN_YKSK" );
		l.add( "LSHJIN_TOOLTIP_ICHIRAN_YKSKBNRI" );
		l.add( "LSHJIN_TOOLTIP_ICHIRAN_SHAINKBN" );
		l.add( "LSHJIN_TOOLTIP_ICHIRAN_CHOTATSUWARIAI" );
		l.add( "LSHJIN_TOOLTIP_ICHIRAN_ROTATION" );
		l.add( "LSHJIN_TOOLTIP_ICHIRAN_GYOMUKAISI" );
		l.add( "LSHJIN_TOOLTIP_ICHIRAN_KEIKANEN" );
		l.add( "LSHJIN_TOOLTIP_ICHIRAN_IDOUKEIKAKUUMU" );
		l.add( "LSHJIN_TOOLTIP_ICHIRAN_IDOUKEIKAKUNENDO" );
		l.add( "LSHJIN_ACTOR" );
		l.add( "LSHJIN_ALERT_01" );
		l.add( "LSHJIN_ALERT_02" );
		l.add( "LSHJIN_ALERT_03" );
		l.add( "LSHJIN_BACK_BTN" );
		l.add( "LSHJIN_DISP_BTN" );
		l.add( "LSHJIN_EXCEL_BTN" );
		l.add( "LSHJIN_ICHIRAN_FULLDEPTNAME" );
		l.add( "LSHJIN_ICHIRAN_GYOMUKAISHI" );
		l.add( "LSHJIN_ICHIRAN_IDONEN_CHOKKIN" );
		l.add( "LSHJIN_ICHIRAN_IDOUMU" );
		l.add( "LSHJIN_ICHIRAN_IKKATSUCHK" );
		l.add( "LSHJIN_ICHIRAN_KEIKANEN" );
		l.add( "LSHJIN_ICHIRAN_NAME" );
		l.add( "LSHJIN_ICHIRAN_ROTATION" );
		l.add( "LSHJIN_ICHIRAN_SHAINKBN" );
		l.add( "LSHJIN_ICHIRAN_STATUS" );
		l.add( "LSHJIN_ICHIRAN_WARIAI" );
		l.add( "LSHJIN_ICHIRAN_YKSK" );
		l.add( "LSHJIN_ICHIRAN_YKSK_BNRI" );
		l.add( "LSHJIN_KENSAKU_BTN" );
		l.add( "LSHJIN_KENSAKU_IDONEN_CHOKKIN" );
		l.add( "LSHJIN_KENSAKU_IDOUMU" );
		l.add( "LSHJIN_KENSAKU_JIGYOJO" );
		l.add( "LSHJIN_KENSAKU_KEIKANEN" );
		l.add( "LSHJIN_KENSAKU_KYOTEN" );
		l.add( "LSHJIN_KENSAKU_ROTATION" );
		l.add( "LSHJIN_KENSAKU_SHOKUMU" );
		l.add( "LSHJIN_KENSAKU_TAISHOKU" );
		l.add( "LSHJIN_KENSAKU_YKSK" );
		l.add( "LSHJIN_KENSAKU_YKSK_BNRI" );
		l.add( "LSHJIN_OPERATION_SHEET" );
		l.add( "LSHJIN_ROJ_11" );
		l.add( "LSHJIN_ROJ_1TO5" );
		l.add( "LSHJIN_ROJ_5IJO" );
		l.add( "LSHJIN_ROJ_5MIMAN" );
		l.add( "LSHJIN_ROJ_6TO10" );
		l.add( "LSHJIN_ROJ_BUKACHOIGAI_01" );
		l.add( "LSHJIN_ROJ_BUKACHOIGAI_02" );
		l.add( "LSHJIN_ROJ_BUKACHO_01" );
		l.add( "LSHJIN_ROJ_BUKACHO_02" );
		l.add( "LSHJIN_ROJ_DOITSUKBN" );
		l.add( "LSHJIN_ROJ_NINZU" );
		l.add( "LSHJIN_ROJ_ROTATION" );
		l.add( "LSHJIN_ROJ_TAISHOKU" );
		l.add( "LSHJIN_ROJ_TOTAL" );
		l.add( "LSHJIN_ROJ_YKSKBNRI" );
		l.add( "LSHJIN_STATUS" );
		l.add( "LSHJIN_SHEET_INFO_FRESHNESS");
		l.add( "LSHJIN_TITLE" );
		l.add( "LSHJIN_REG_EXCEL_BTN" );
		l.add( "LSHJIN_EXCEL_MCR_BTN" );
		l.add( "LSHJIN_EXCEL_UP_BTN" );
		l.add( "LSHJIN_UPLOAD_TITLE" );
		l.add( "LSHJIN_UPLOAD_GUIDE" );
		l.add( "LSHJIN_UPLOAD_BTN" );
		registerCommonLabels( l );
	}
	
}
