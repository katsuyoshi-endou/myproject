/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.MktNotificationDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class MktNotificationDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " N10N_SEQ as n10nSeq,"
                     + " PARTY as party,"
                     + " GUID as guid,"
                     + " N10N_TEXT as n10nText,"
                     + " READ_FLG as readFlg,"
                     + " SENDER as sender,"
                     + " SENT_AT as sentAt"
                     ;

    public MktNotificationDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public MktNotificationDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public void insert(MktNotificationDto dto) {

        final String sql = "INSERT INTO MKT_NOTIFICATION ("
                         + "N10N_SEQ,"
                         + "PARTY,"
                         + "GUID,"
                         + "N10N_TEXT,"
                         + "READ_FLG,"
                         + "SENDER,"
                         + "SENT_AT"
                         + ")VALUES(?,?,?,?,?,?,? )"
                         ;
        Log.sql("[DaoMethod Call] MktNotificationDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setIntToPreparedStatement(pstmt, 1, dto.getN10nSeq());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getParty());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getGuid());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getN10nText());
            DaoUtil.setIntToPreparedStatement(pstmt, 5, dto.getReadFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getSender());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getSentAt());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void update(MktNotificationDto dto) {

        final String sql = "UPDATE MKT_NOTIFICATION SET "
                         + "PARTY = ?,"
                         + "GUID = ?,"
                         + "N10N_TEXT = ?,"
                         + "READ_FLG = ?,"
                         + "SENDER = ?,"
                         + "SENT_AT = ?"
                         + " WHERE N10N_SEQ = ?"
                         ;
        Log.sql("[DaoMethod Call] MktNotificationDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getParty());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getGuid());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getN10nText());
            DaoUtil.setIntToPreparedStatement(pstmt, 4, dto.getReadFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getSender());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getSentAt());
            DaoUtil.setIntToPreparedStatement(pstmt, 7, dto.getN10nSeq());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void delete(Integer n10nSeq) {

        final String sql = "DELETE FROM MKT_NOTIFICATION"
                         + " WHERE N10N_SEQ = ?"
                         ;
        Log.sql("[DaoMethod Call] MktNotificationDao.delete");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setIntToPreparedStatement(pstmt, 1, n10nSeq);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally { 
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public MktNotificationDto select(Integer n10nSeq) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM MKT_NOTIFICATION"
                         + " WHERE N10N_SEQ = ?"
                         ;
        Log.sql("[DaoMethod Call] MktNotificationDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setIntToPreparedStatement(pstmt, 1, n10nSeq);
            rs = pstmt.executeQuery();
            MktNotificationDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<MktNotificationDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] MktNotificationDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<MktNotificationDto> lst = new ArrayList<MktNotificationDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<MktNotificationDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] MktNotificationDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    public int selectCountDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] MktNotificationDao.selectCountDynamic");
        ResultSet rs = null;
        int cnt = 0;
        try {
            rs = pstmt.executeQuery();
            if ( rs.next() ) {
                cnt = rs.getInt(1);
            }
            return cnt;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public int selectCountDynamic(String sql) {

        Log.sql("[DaoMethod Call] MktNotificationDao.selectCountDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectCountDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("[DaoMethod Call] MktNotificationDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void executeDynamic(String sql) {

        Log.sql("[DaoMethod Call] MktNotificationDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    private MktNotificationDto transferRsToDto(ResultSet rs) throws SQLException {

        MktNotificationDto dto = new MktNotificationDto();
        dto.setN10nSeq(rs.getInt("n10nSeq"));
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setGuid(DaoUtil.convertNullToString(rs.getString("guid")));
        dto.setN10nText(DaoUtil.convertNullToString(rs.getString("n10nText")));
        dto.setReadFlg(rs.getInt("readFlg"));
        dto.setSender(DaoUtil.convertNullToString(rs.getString("sender")));
        dto.setSentAt(DaoUtil.convertNullToString(rs.getString("sentAt")));
        return dto;
    }

    public List<MktNotificationDto> selectUnreadN10ns(String party, String guid) {

        final String sql = "select " + ALLCOLS + " from MKT_NOTIFICATION where PARTY = ? and GUID = ? and READ_FLG = 0 order by SENT_AT desc";
        Log.sql("[DaoMethod Call] MktNotificationDao.selectUnreadN10ns");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, party);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, guid);
            rs = pstmt.executeQuery();
            List<MktNotificationDto> lst = new ArrayList<MktNotificationDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

