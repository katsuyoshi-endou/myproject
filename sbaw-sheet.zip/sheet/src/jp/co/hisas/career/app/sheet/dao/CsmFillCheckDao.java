/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.CsmFillCheckDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CsmFillCheckDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " FILL_SET_CD as fillSetCd,"
                     + " SEQ_NO as seqNo,"
                     + " FILL_ID as fillId,"
                     + " STATUS_CD as statusCd,"
                     + " CHECK_METHOD as checkMethod,"
                     + " ARG1 as arg1,"
                     + " MSG_ID as msgId"
                     ;

    public CsmFillCheckDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CsmFillCheckDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public CsmFillCheckDto select(String fillSetCd, String seqNo) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CSM_FILL_CHECK"
                         + " WHERE FILL_SET_CD = ?"
                         + " AND SEQ_NO = ?"
                         ;
        Log.sql("[DaoMethod Call] CsmFillCheckDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, fillSetCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, seqNo);
            rs = pstmt.executeQuery();
            CsmFillCheckDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CsmFillCheckDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CsmFillCheckDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CsmFillCheckDto> lst = new ArrayList<CsmFillCheckDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CsmFillCheckDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CsmFillCheckDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private CsmFillCheckDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmFillCheckDto dto = new CsmFillCheckDto();
        dto.setFillSetCd(DaoUtil.convertNullToString(rs.getString("fillSetCd")));
        dto.setSeqNo(DaoUtil.convertNullToString(rs.getString("seqNo")));
        dto.setFillId(DaoUtil.convertNullToString(rs.getString("fillId")));
        dto.setStatusCd(DaoUtil.convertNullToString(rs.getString("statusCd")));
        dto.setCheckMethod(DaoUtil.convertNullToString(rs.getString("checkMethod")));
        dto.setArg1(DaoUtil.convertNullToString(rs.getString("arg1")));
        dto.setMsgId(DaoUtil.convertNullToString(rs.getString("msgId")));
        return dto;
    }

}

