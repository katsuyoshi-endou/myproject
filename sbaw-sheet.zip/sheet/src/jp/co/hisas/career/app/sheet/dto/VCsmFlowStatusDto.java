/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class VCsmFlowStatusDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String flowCd;
    private String seqNo;
    private String statusCd;
    private String statusNm;
    private String statusGrpCd;
    private String statusGrpNm;
    private String mainActorCd;
    private String mainActorNm;
    private String related;

    public String getFlowCd() {
        return flowCd;
    }

    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    public String getStatusNm() {
        return statusNm;
    }

    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    public String getStatusGrpCd() {
        return statusGrpCd;
    }

    public void setStatusGrpCd(String statusGrpCd) {
        this.statusGrpCd = statusGrpCd;
    }

    public String getStatusGrpNm() {
        return statusGrpNm;
    }

    public void setStatusGrpNm(String statusGrpNm) {
        this.statusGrpNm = statusGrpNm;
    }

    public String getMainActorCd() {
        return mainActorCd;
    }

    public void setMainActorCd(String mainActorCd) {
        this.mainActorCd = mainActorCd;
    }

    public String getMainActorNm() {
        return mainActorNm;
    }

    public void setMainActorNm(String mainActorNm) {
        this.mainActorNm = mainActorNm;
    }

    public String getRelated() {
        return related;
    }

    public void setRelated(String related) {
        this.related = related;
    }

}

