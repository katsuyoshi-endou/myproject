package jp.co.hisas.career.app.sheet.util;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.hisas.career.app.sheet.deliver.sheet.SheetDeliver;
import jp.co.hisas.career.framework.exception.CareerException;

public final class CsFillIdCache {
	
	private ConcurrentHashMap<String, List<String>> cache = new ConcurrentHashMap<String, List<String>>();
	
	/**
	 * Singleton パターン - Wikipedia https://ja.wikipedia.org/wiki/Singleton_パターン
	 */
	private CsFillIdCache() {
	}
	
	private static class CsFillIdCacheHolder {
		private static final CsFillIdCache instance = new CsFillIdCache();
	}
	
	private static CsFillIdCache getInstance() {
		return CsFillIdCacheHolder.instance;
	}
	
	public static List<String> get( String fillSetCd ) {
		CsFillIdCache instance = CsFillIdCache.getInstance();
		return instance.getCacheData( fillSetCd );
	}
	
	private List<String> getCacheData( String fillSetCd ) {
		String key = fillSetCd;
		if (!cache.containsKey( key )) {
			addCache( key, fillSetCd );
		}
		return cache.get( key );
	}
	
	private void addCache( String key, String fillSetCd ) {
		String daoLoginNo = "Cache";
		List<String> fillMasterMap;
		try {
			fillMasterMap = SheetDeliver.getFillIdList( daoLoginNo, fillSetCd );
		} catch (CareerException e) {
			fillMasterMap = null;
		}
		cache.put( key, fillMasterMap );
	}
	
	public static void clearCache() {
		CsFillIdCache instance = CsFillIdCache.getInstance();
		instance.clearCacheData();
	}
	
	private void clearCacheData() {
		cache = new ConcurrentHashMap<String, List<String>>();
	}
	
}
