package jp.co.hisas.career.app.sheet.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.sheet.event.JkskGyomuBunruiEventArg;
import jp.co.hisas.career.app.sheet.event.JkskGyomuBunruiEventHandler;
import jp.co.hisas.career.app.sheet.event.JkskGyomuBunruiEventResult;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.framework.trans.StateTransitionEvent;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class PSHGYMCommand extends AbstractCommand {
	
	public static final String KINOU_ID = "VSHGYM";

	private Tray tray;
	private HttpServletRequest request;
	private HttpSession session;
	private String state;
	
	public PSHGYMCommand() {
		super(PSHGYMCommand.class, KINOU_ID, null);
	}
	
	public void init( StateTransitionEvent e ) {
		try {
			this.tray = new Tray( e );
			request = e.getRequest();
			session = request.getSession( false );
			/* Not Update Token While Single Sheet.
			CSRFTokenUtil.setNewTokenNo( request, e.getResponse() ); */
			state = request.getParameter( "state" );
			main();
		} catch (CareerException ex) {
			throw new CareerRuntimeException( ex );
		}
	}
	
	private void main() throws CareerException {
		
		if ("INIT".equals( state )) {
			execEventInit();
		}
		
		/* 操作ログ */
		OutLogBean.outputLogSousa( request, KINOU_ID, (String)AU.getSessionAttr( session, CsSessionKey.CS_SHEET_ID ), state );
	}
	
	private void execEventInit() throws CareerException {

		/* Set Args */
		JkskGyomuBunruiEventArg arg = new JkskGyomuBunruiEventArg( super.getLoginNo() );
		
		arg.sharp = "INIT";
		arg.party = tray.party;
		
		/* Execute Event */
		JkskGyomuBunruiEventResult result = JkskGyomuBunruiEventHandler.exec( arg );

		/* Return to session */
		session.setAttribute( CsSessionKey.JKSK_GYOMUB_RESULT, result );
	}
}
