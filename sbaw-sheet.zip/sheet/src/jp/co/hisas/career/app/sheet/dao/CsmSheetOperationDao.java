/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.CsmSheetOperationDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CsmSheetOperationDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " PARTY as party,"
                     + " OPERATION_CD as operationCd,"
                     + " OPERATION_NM as operationNm,"
                     + " OPERATION_TYPE as operationType,"
                     + " INST_CD as instCd,"
                     + " LPAD_SORT as lpadSort,"
                     + " OPEN_FLG as openFlg,"
                     + " ACTIVE_FLG as activeFlg"
                     ;

    public CsmSheetOperationDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CsmSheetOperationDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public void update(CsmSheetOperationDto dto) {

        final String sql = "UPDATE CSM_SHEET_OPERATION SET "
                         + "OPERATION_NM = ?,"
                         + "OPERATION_TYPE = ?,"
                         + "INST_CD = ?,"
                         + "LPAD_SORT = ?,"
                         + "OPEN_FLG = ?,"
                         + "ACTIVE_FLG = ?"
                         + " WHERE PARTY = ?"
                         + " AND OPERATION_CD = ?"
                         ;
        Log.sql("[DaoMethod Call] CsmSheetOperationDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getOperationNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getOperationType());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getInstCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getLpadSort());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getOpenFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getActiveFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getParty());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 8, dto.getOperationCd());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public CsmSheetOperationDto select(String party, String operationCd) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CSM_SHEET_OPERATION"
                         + " WHERE PARTY = ?"
                         + " AND OPERATION_CD = ?"
                         ;
        Log.sql("[DaoMethod Call] CsmSheetOperationDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, party);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, operationCd);
            rs = pstmt.executeQuery();
            CsmSheetOperationDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CsmSheetOperationDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CsmSheetOperationDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CsmSheetOperationDto> lst = new ArrayList<CsmSheetOperationDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CsmSheetOperationDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CsmSheetOperationDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private CsmSheetOperationDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmSheetOperationDto dto = new CsmSheetOperationDto();
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setOperationCd(DaoUtil.convertNullToString(rs.getString("operationCd")));
        dto.setOperationNm(DaoUtil.convertNullToString(rs.getString("operationNm")));
        dto.setOperationType(DaoUtil.convertNullToString(rs.getString("operationType")));
        dto.setInstCd(DaoUtil.convertNullToString(rs.getString("instCd")));
        dto.setLpadSort(DaoUtil.convertNullToString(rs.getString("lpadSort")));
        dto.setOpenFlg(DaoUtil.convertNullToString(rs.getString("openFlg")));
        dto.setActiveFlg(DaoUtil.convertNullToString(rs.getString("activeFlg")));
        return dto;
    }

}

