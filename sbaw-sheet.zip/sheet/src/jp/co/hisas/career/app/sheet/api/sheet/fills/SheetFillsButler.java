package jp.co.hisas.career.app.sheet.api.sheet.fills;

import jp.co.hisas.career.app.sheet.api.Butler;
import jp.co.hisas.career.app.sheet.deliver.DeliverOrder;
import jp.co.hisas.career.app.sheet.deliver.sheet.fills.SheetFillsPutDeliver;
import jp.co.hisas.career.app.sheet.deliver.sheet.fills.SheetFillsPutOrder;
import jp.co.hisas.career.app.sheet.deliver.sheet.fills.SheetFillsPutReply;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class SheetFillsButler extends Butler {
	
	@Override
	public String takeGET( Tray tray ) throws CareerException {
		return null;
	}
	
	@Override
	public String takePOST( Tray tray ) throws CareerException {
		return null;
	}
	
	@Override
	public String takePUT( Tray tray ) throws CareerException {
		SheetFillsPutOrder order = DeliverOrder.fromJson( tray, SheetFillsPutOrder.class );
		order.init( tray );
		order.validate();
		SheetFillsPutReply rep = SheetFillsPutDeliver.go( tray, order );
		return SU.toJson( rep );
	}
	
	@Override
	public String takeDELETE( Tray tray ) throws CareerException {
		return null;
	}
}
