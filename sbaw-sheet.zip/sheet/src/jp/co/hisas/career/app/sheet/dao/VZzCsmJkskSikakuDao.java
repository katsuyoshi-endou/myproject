/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.VZzCsmJkskSikakuDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class VZzCsmJkskSikakuDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " SIKAKU_CD as sikakuCd,"
                     + " SIKAKU_NM as sikakuNm,"
                     + " GNSK_COMP_CD as gnskCompCd"
                     ;

    public VZzCsmJkskSikakuDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public VZzCsmJkskSikakuDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public VZzCsmJkskSikakuDto select(String sikakuCd, String gnskCompCd) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM V_ZZ_CSM_JKSK_SIKAKU"
                         + " WHERE SIKAKU_CD = ?"
                         + " AND GNSK_COMP_CD = ?"
                         ;
        Log.sql("[DaoMethod Call] VZzCsmJkskSikakuDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sikakuCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, gnskCompCd);
            rs = pstmt.executeQuery();
            VZzCsmJkskSikakuDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<VZzCsmJkskSikakuDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] VZzCsmJkskSikakuDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<VZzCsmJkskSikakuDto> lst = new ArrayList<VZzCsmJkskSikakuDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<VZzCsmJkskSikakuDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] VZzCsmJkskSikakuDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("[DaoMethod Call] VZzCsmJkskSikakuDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void executeDynamic(String sql) {

        Log.sql("[DaoMethod Call] VZzCsmJkskSikakuDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    private VZzCsmJkskSikakuDto transferRsToDto(ResultSet rs) throws SQLException {

        VZzCsmJkskSikakuDto dto = new VZzCsmJkskSikakuDto();
        dto.setSikakuCd(DaoUtil.convertNullToString(rs.getString("sikakuCd")));
        dto.setSikakuNm(DaoUtil.convertNullToString(rs.getString("sikakuNm")));
        dto.setGnskCompCd(DaoUtil.convertNullToString(rs.getString("gnskCompCd")));
        return dto;
    }

}

