package jp.co.hisas.career.app.sheet.event;

import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class RsvAdminEventResult extends AbstractEventResult {

	public String resultMsg = null;
	public int exitCd;

}