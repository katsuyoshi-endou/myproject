package jp.co.hisas.career.app.sheet.api.bulk;

import java.io.Serializable;

import jp.co.hisas.career.app.sheet.api.mold.Fill;

public class BulkSheetColumn implements Serializable {
	
	public String text;
	public Fill fill;
}
