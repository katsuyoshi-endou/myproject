/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CstRsvActorDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sheetId;
    private String a01ActorCd;
    private String a01PersonId;
    private String a02ActorCd;
    private String a02PersonId;
    private String a03ActorCd;
    private String a03PersonId;
    private String a04ActorCd;
    private String a04PersonId;
    private String a05ActorCd;
    private String a05PersonId;
    private String a06ActorCd;
    private String a06PersonId;
    private String a07ActorCd;
    private String a07PersonId;
    private String a08ActorCd;
    private String a08PersonId;
    private String a09ActorCd;
    private String a09PersonId;
    private String a10ActorCd;
    private String a10PersonId;
    private String a11ActorCd;
    private String a11PersonId;
    private String a12ActorCd;
    private String a12PersonId;
    private String a13ActorCd;
    private String a13PersonId;
    private String a14ActorCd;
    private String a14PersonId;
    private String a15ActorCd;
    private String a15PersonId;
    private String r01PersonId;
    private String r02PersonId;
    private String r03PersonId;
    private String r04PersonId;
    private String r05PersonId;
    private String r06PersonId;
    private String r07PersonId;
    private String r08PersonId;
    private String r09PersonId;
    private String r10PersonId;
    private String r11PersonId;
    private String r12PersonId;
    private String r13PersonId;
    private String r14PersonId;
    private String r15PersonId;

    public String getSheetId() {
        return sheetId;
    }

    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    public String getA01ActorCd() {
        return a01ActorCd;
    }

    public void setA01ActorCd(String a01ActorCd) {
        this.a01ActorCd = a01ActorCd;
    }

    public String getA01PersonId() {
        return a01PersonId;
    }

    public void setA01PersonId(String a01PersonId) {
        this.a01PersonId = a01PersonId;
    }

    public String getA02ActorCd() {
        return a02ActorCd;
    }

    public void setA02ActorCd(String a02ActorCd) {
        this.a02ActorCd = a02ActorCd;
    }

    public String getA02PersonId() {
        return a02PersonId;
    }

    public void setA02PersonId(String a02PersonId) {
        this.a02PersonId = a02PersonId;
    }

    public String getA03ActorCd() {
        return a03ActorCd;
    }

    public void setA03ActorCd(String a03ActorCd) {
        this.a03ActorCd = a03ActorCd;
    }

    public String getA03PersonId() {
        return a03PersonId;
    }

    public void setA03PersonId(String a03PersonId) {
        this.a03PersonId = a03PersonId;
    }

    public String getA04ActorCd() {
        return a04ActorCd;
    }

    public void setA04ActorCd(String a04ActorCd) {
        this.a04ActorCd = a04ActorCd;
    }

    public String getA04PersonId() {
        return a04PersonId;
    }

    public void setA04PersonId(String a04PersonId) {
        this.a04PersonId = a04PersonId;
    }

    public String getA05ActorCd() {
        return a05ActorCd;
    }

    public void setA05ActorCd(String a05ActorCd) {
        this.a05ActorCd = a05ActorCd;
    }

    public String getA05PersonId() {
        return a05PersonId;
    }

    public void setA05PersonId(String a05PersonId) {
        this.a05PersonId = a05PersonId;
    }

    public String getA06ActorCd() {
        return a06ActorCd;
    }

    public void setA06ActorCd(String a06ActorCd) {
        this.a06ActorCd = a06ActorCd;
    }

    public String getA06PersonId() {
        return a06PersonId;
    }

    public void setA06PersonId(String a06PersonId) {
        this.a06PersonId = a06PersonId;
    }

    public String getA07ActorCd() {
        return a07ActorCd;
    }

    public void setA07ActorCd(String a07ActorCd) {
        this.a07ActorCd = a07ActorCd;
    }

    public String getA07PersonId() {
        return a07PersonId;
    }

    public void setA07PersonId(String a07PersonId) {
        this.a07PersonId = a07PersonId;
    }

    public String getA08ActorCd() {
        return a08ActorCd;
    }

    public void setA08ActorCd(String a08ActorCd) {
        this.a08ActorCd = a08ActorCd;
    }

    public String getA08PersonId() {
        return a08PersonId;
    }

    public void setA08PersonId(String a08PersonId) {
        this.a08PersonId = a08PersonId;
    }

    public String getA09ActorCd() {
        return a09ActorCd;
    }

    public void setA09ActorCd(String a09ActorCd) {
        this.a09ActorCd = a09ActorCd;
    }

    public String getA09PersonId() {
        return a09PersonId;
    }

    public void setA09PersonId(String a09PersonId) {
        this.a09PersonId = a09PersonId;
    }

    public String getA10ActorCd() {
        return a10ActorCd;
    }

    public void setA10ActorCd(String a10ActorCd) {
        this.a10ActorCd = a10ActorCd;
    }

    public String getA10PersonId() {
        return a10PersonId;
    }

    public void setA10PersonId(String a10PersonId) {
        this.a10PersonId = a10PersonId;
    }

    public String getA11ActorCd() {
        return a11ActorCd;
    }

    public void setA11ActorCd(String a11ActorCd) {
        this.a11ActorCd = a11ActorCd;
    }

    public String getA11PersonId() {
        return a11PersonId;
    }

    public void setA11PersonId(String a11PersonId) {
        this.a11PersonId = a11PersonId;
    }

    public String getA12ActorCd() {
        return a12ActorCd;
    }

    public void setA12ActorCd(String a12ActorCd) {
        this.a12ActorCd = a12ActorCd;
    }

    public String getA12PersonId() {
        return a12PersonId;
    }

    public void setA12PersonId(String a12PersonId) {
        this.a12PersonId = a12PersonId;
    }

    public String getA13ActorCd() {
        return a13ActorCd;
    }

    public void setA13ActorCd(String a13ActorCd) {
        this.a13ActorCd = a13ActorCd;
    }

    public String getA13PersonId() {
        return a13PersonId;
    }

    public void setA13PersonId(String a13PersonId) {
        this.a13PersonId = a13PersonId;
    }

    public String getA14ActorCd() {
        return a14ActorCd;
    }

    public void setA14ActorCd(String a14ActorCd) {
        this.a14ActorCd = a14ActorCd;
    }

    public String getA14PersonId() {
        return a14PersonId;
    }

    public void setA14PersonId(String a14PersonId) {
        this.a14PersonId = a14PersonId;
    }

    public String getA15ActorCd() {
        return a15ActorCd;
    }

    public void setA15ActorCd(String a15ActorCd) {
        this.a15ActorCd = a15ActorCd;
    }

    public String getA15PersonId() {
        return a15PersonId;
    }

    public void setA15PersonId(String a15PersonId) {
        this.a15PersonId = a15PersonId;
    }

    public String getR01PersonId() {
        return r01PersonId;
    }

    public void setR01PersonId(String r01PersonId) {
        this.r01PersonId = r01PersonId;
    }

    public String getR02PersonId() {
        return r02PersonId;
    }

    public void setR02PersonId(String r02PersonId) {
        this.r02PersonId = r02PersonId;
    }

    public String getR03PersonId() {
        return r03PersonId;
    }

    public void setR03PersonId(String r03PersonId) {
        this.r03PersonId = r03PersonId;
    }

    public String getR04PersonId() {
        return r04PersonId;
    }

    public void setR04PersonId(String r04PersonId) {
        this.r04PersonId = r04PersonId;
    }

    public String getR05PersonId() {
        return r05PersonId;
    }

    public void setR05PersonId(String r05PersonId) {
        this.r05PersonId = r05PersonId;
    }

    public String getR06PersonId() {
        return r06PersonId;
    }

    public void setR06PersonId(String r06PersonId) {
        this.r06PersonId = r06PersonId;
    }

    public String getR07PersonId() {
        return r07PersonId;
    }

    public void setR07PersonId(String r07PersonId) {
        this.r07PersonId = r07PersonId;
    }

    public String getR08PersonId() {
        return r08PersonId;
    }

    public void setR08PersonId(String r08PersonId) {
        this.r08PersonId = r08PersonId;
    }

    public String getR09PersonId() {
        return r09PersonId;
    }

    public void setR09PersonId(String r09PersonId) {
        this.r09PersonId = r09PersonId;
    }

    public String getR10PersonId() {
        return r10PersonId;
    }

    public void setR10PersonId(String r10PersonId) {
        this.r10PersonId = r10PersonId;
    }

    public String getR11PersonId() {
        return r11PersonId;
    }

    public void setR11PersonId(String r11PersonId) {
        this.r11PersonId = r11PersonId;
    }

    public String getR12PersonId() {
        return r12PersonId;
    }

    public void setR12PersonId(String r12PersonId) {
        this.r12PersonId = r12PersonId;
    }

    public String getR13PersonId() {
        return r13PersonId;
    }

    public void setR13PersonId(String r13PersonId) {
        this.r13PersonId = r13PersonId;
    }

    public String getR14PersonId() {
        return r14PersonId;
    }

    public void setR14PersonId(String r14PersonId) {
        this.r14PersonId = r14PersonId;
    }

    public String getR15PersonId() {
        return r15PersonId;
    }

    public void setR15PersonId(String r15PersonId) {
        this.r15PersonId = r15PersonId;
    }

}

