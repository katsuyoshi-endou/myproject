/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFillMaskDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CsmSheetFillMaskDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " MASK_CD as maskCd,"
                     + " STATUS_CD as statusCd,"
                     + " ACTOR_CD as actorCd,"
                     + " FILL_ID as fillId,"
                     + " READ_OR_WRITE as readOrWrite"
                     ;

    public CsmSheetFillMaskDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CsmSheetFillMaskDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public CsmSheetFillMaskDto select(String maskCd, String statusCd, String actorCd, String fillId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CSM_SHEET_FILL_MASK"
                         + " WHERE MASK_CD = ?"
                         + " AND STATUS_CD = ?"
                         + " AND ACTOR_CD = ?"
                         + " AND FILL_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CsmSheetFillMaskDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, maskCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, statusCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, actorCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, fillId);
            rs = pstmt.executeQuery();
            CsmSheetFillMaskDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CsmSheetFillMaskDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CsmSheetFillMaskDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CsmSheetFillMaskDto> lst = new ArrayList<CsmSheetFillMaskDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CsmSheetFillMaskDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CsmSheetFillMaskDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private CsmSheetFillMaskDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmSheetFillMaskDto dto = new CsmSheetFillMaskDto();
        dto.setMaskCd(DaoUtil.convertNullToString(rs.getString("maskCd")));
        dto.setStatusCd(DaoUtil.convertNullToString(rs.getString("statusCd")));
        dto.setActorCd(DaoUtil.convertNullToString(rs.getString("actorCd")));
        dto.setFillId(DaoUtil.convertNullToString(rs.getString("fillId")));
        dto.setReadOrWrite(DaoUtil.convertNullToString(rs.getString("readOrWrite")));
        return dto;
    }

    public List<CsmSheetFillMaskDto> selectFillMasks(String maskCd, String statusCd, String actorCd) {

        final String sql = "select MASK_CD as maskCd, STATUS_CD as statusCd, ACTOR_CD as actorCd, FILL_ID as fillId, READ_OR_WRITE as readOrWrite from CSM_SHEET_FILL_MASK where MASK_CD = ? and STATUS_CD = ? and ACTOR_CD = ?";
        Log.sql("[DaoMethod Call] CsmSheetFillMaskDao.selectFillMasks");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, maskCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, statusCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, actorCd);
            rs = pstmt.executeQuery();
            List<CsmSheetFillMaskDto> lst = new ArrayList<CsmSheetFillMaskDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

