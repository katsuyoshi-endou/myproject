package jp.co.hisas.career.app.sheet.api.bulk;

import jp.co.hisas.career.app.sheet.api.Butler;
import jp.co.hisas.career.app.sheet.deliver.DeliverOrder;
import jp.co.hisas.career.app.sheet.deliver.bulk.BulkGetDeliver;
import jp.co.hisas.career.app.sheet.deliver.bulk.BulkGetOrder;
import jp.co.hisas.career.app.sheet.deliver.bulk.BulkPostDeliver;
import jp.co.hisas.career.app.sheet.deliver.bulk.BulkPostOrder;
import jp.co.hisas.career.app.sheet.deliver.bulk.BulkPutDeliver;
import jp.co.hisas.career.app.sheet.deliver.bulk.BulkPutOrder;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class BulkButler extends Butler {
	
	@Override
	public String takeGET( Tray tray ) throws CareerException {
		BulkGetOrder order = new BulkGetOrder( tray );
		order.operationCd = tray.getSessionAttr( CsSessionKey.CS_BULK_OPERATION_CD );
		order.instCd = tray.getSessionAttr( CsSessionKey.CS_BULK_INST_CD );
		order.wkIdxFrom = SU.toInt( AU.getRequestValue( tray.request, "wkIdxFrom" ), 0 );
		order.wkIdxTo = SU.toInt( AU.getRequestValue( tray.request, "wkIdxTo" ), 0 );
		BulkEvRslt rslt = BulkGetDeliver.go( tray, order );
		return SU.toJson( rslt );
	}
	
	@Override
	public String takePOST( Tray tray ) throws CareerException {
		BulkPostOrder order = DeliverOrder.fromJson( tray, BulkPostOrder.class );
		order.init( tray );
		order.operationCd = tray.getSessionAttr( CsSessionKey.CS_BULK_OPERATION_CD );
		BulkEvRslt rslt = BulkPostDeliver.go( tray, order );
		
		if (rslt.hasInvalid) {
			String msg = AU.getCommonLabel( tray, "LSHBLK_MSG_INVALID_WARN" );
			tray.session.setAttribute( AppSessionKey.RESULT_MSG_WARN, msg );
		}
		if (rslt.hasExclusiveError) {
			String msg = AU.getCommonLabel( tray, "LSHBLK_MSG_EXCLUSIVE_ERROR" );
			tray.session.setAttribute( AppSessionKey.RESULT_MSG_ERROR, msg );
		}
		
		return SU.toJson( rslt );
	}
	
	@Override
	public String takePUT( Tray tray ) throws CareerException {
		BulkPutOrder order = DeliverOrder.fromJson( tray, BulkPutOrder.class );
		order.init( tray );
		order.prepare();
		BulkPutDeliver.go( tray, order );
		return null;
	}
	
	@Override
	public String takeDELETE( Tray tray ) throws CareerException {
		return null;
	}
}
