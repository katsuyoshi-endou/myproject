package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

@SuppressWarnings("serial")
public class CsFloodEvRslt extends AbstractEventResult {

	public String targetSheetsNum;
	public List<ValueTextSortDto> operationList;
	public List<ValueTextSortDto> statusList;
	public String targetOperationCd;

}