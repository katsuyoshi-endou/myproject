package jp.co.hisas.career.app.sheet.vm;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.ViewModel;
import jp.co.hisas.career.util.Tray;

public class VmVSHFSC extends ViewModel {
	
	public static String VMID = VmVSHFSC.class.getSimpleName();
	
	public VmVSHFSC(Tray tray) throws CareerException {
		super( tray );
	}
	
}
