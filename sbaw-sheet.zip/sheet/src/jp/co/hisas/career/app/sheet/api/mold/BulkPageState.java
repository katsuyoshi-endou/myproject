package jp.co.hisas.career.app.sheet.api.mold;

import java.io.Serializable;

public class BulkPageState implements Serializable {
	
	public int currentPage = 1;
	public int currentPageSize = 15;
	public String lastClickedSheetId = "";
}
