/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class VCsmFormCtgMultiTabDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String formGrpCd;
    private String formCtgCd;
    private String seqNo;
    private String statusCd;
    private String multiTab;

    public String getFormGrpCd() {
        return formGrpCd;
    }

    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    public String getFormCtgCd() {
        return formCtgCd;
    }

    public void setFormCtgCd(String formCtgCd) {
        this.formCtgCd = formCtgCd;
    }

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    public String getMultiTab() {
        return multiTab;
    }

    public void setMultiTab(String multiTab) {
        this.multiTab = multiTab;
    }

}

