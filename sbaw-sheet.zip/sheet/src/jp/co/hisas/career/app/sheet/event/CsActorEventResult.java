package jp.co.hisas.career.app.sheet.event;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dto.CsmSheetActorDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActorAndRefDto;
import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class CsActorEventResult extends AbstractEventResult {

	public String resultMessageId = null;
	private List<VCstSheetActorAndRefDto> actorList = null;
	private List<String> holdActorList = null;
	private Map<Integer, VCstSheetActorAndRefDto> refererMap = null;
	private List<CsmSheetActorDto> refererMasterList = null;
	public List<VCstSheetActorAndRefDto> actorCdList;

	public List<VCstSheetActorAndRefDto> getActorList() {
		return actorList;
	}

	public void setActorList( List<VCstSheetActorAndRefDto> actorList ) {
		this.actorList = actorList;
	}

	public Map<Integer, VCstSheetActorAndRefDto> getRefererMap() {
		return refererMap;
	}

	public void setRefererMap( Map<Integer, VCstSheetActorAndRefDto> refererMap ) {
		this.refererMap = refererMap;
	}

	public List<String> getHoldActorList() {
		return holdActorList;
	}

	public void setHoldActorList( List<String> holdActorList ) {
		this.holdActorList = holdActorList;
	}

	public List<CsmSheetActorDto> getRefererMasterList() {
		return refererMasterList;
	}

	public void setRefererMasterList( List<CsmSheetActorDto> refererMasterList ) {
		this.refererMasterList = refererMasterList;
	}

}