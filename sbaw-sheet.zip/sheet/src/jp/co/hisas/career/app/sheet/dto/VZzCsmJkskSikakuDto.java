/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class VZzCsmJkskSikakuDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sikakuCd;
    private String sikakuNm;
    private String gnskCompCd;

    public String getSikakuCd() {
        return sikakuCd;
    }

    public void setSikakuCd(String sikakuCd) {
        this.sikakuCd = sikakuCd;
    }

    public String getSikakuNm() {
        return sikakuNm;
    }

    public void setSikakuNm(String sikakuNm) {
        this.sikakuNm = sikakuNm;
    }

    public String getGnskCompCd() {
        return gnskCompCd;
    }

    public void setGnskCompCd(String gnskCompCd) {
        this.gnskCompCd = gnskCompCd;
    }

}

