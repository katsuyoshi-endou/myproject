package jp.co.hisas.career.app.sheet.servlet;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.framework.trans.NoTokenRedirectServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class AppFrontServlet extends NoTokenRedirectServlet {
	
	private static final long serialVersionUID = 1L;
	
	@Override
	public String serviceMain( Tray tray ) throws Exception {
		
		if(SU.equals( "HOME_REF_CMPA", tray.state )){
			String slctedParty = AU.getRequestValue( tray.request, "data-cmpa" );
			if(slctedParty != null && slctedParty.length() > 0){
				boolean flg = false;
				for(String checkParty : tray.userinfo.getPartyList()){
					if(slctedParty.equals(checkParty)){
						flg = true;
						break;
					}
				}
				
				if(flg){
					tray.userinfo.loadParty(slctedParty);
					tray.party = slctedParty;
					tray.session.setAttribute( UserInfoBean.SESSION_KEY, tray.userinfo );
				}
			}
		}
		
		return AppDef.HOME_JSP;
	}
	
}
