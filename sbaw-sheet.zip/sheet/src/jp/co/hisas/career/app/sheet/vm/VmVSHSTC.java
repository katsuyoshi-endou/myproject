package jp.co.hisas.career.app.sheet.vm;

import java.util.List;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.event.CsFloodEvArg;
import jp.co.hisas.career.app.sheet.event.CsFloodEvHdlr;
import jp.co.hisas.career.app.sheet.event.CsFloodEvRslt;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.ViewModel;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

public class VmVSHSTC extends ViewModel {
	
	public static String VMID = VmVSHSTC.class.getSimpleName();
	
	public List<ValueTextSortDto> operationList;
	public List<ValueTextSortDto> statusList;
	public String slctedOperation;
	public String slctedStatus;
	public String targetSheetsNum;
	public String operationNm;
	public String statusNm;
	public String afterChangeStatus;
	
	public VmVSHSTC(Tray tray) throws CareerException {
		super( tray );
		
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( tray.session, UserInfoBean.SESSION_KEY );
		tray.operatorGuid = userInfo.getOperatorGuid();
		
		String opeCd = AU.getRequestValue( tray.request, "operationCd" );
		String staCd = AU.getRequestValue( tray.request, "statusCd" );
		
		String newOpeCd = execStatePrepare( tray, opeCd );
		String sheetsNum = execStateSearch( tray, newOpeCd, staCd );
		
		this.slctedOperation = newOpeCd;
		this.slctedStatus = staCd;
		this.targetSheetsNum = sheetsNum;
		this.operationNm = AU.getRequestValue( tray.request, "operationNm" );
		this.statusNm = AU.getRequestValue( tray.request, "statusNm" );
		this.afterChangeStatus = AU.getRequestValue( tray.request, "afterChangeStatus" );
	}
	
	private String execStatePrepare( Tray tray, String opeCd ) throws CareerException {
		
		CsFloodEvArg arg = new CsFloodEvArg( tray.loginNo );
		arg.sharp = "PREPARE";
		arg.party = tray.party;
		arg.operatorGuid = tray.operatorGuid;
		arg.slctedOperation = opeCd;
		CsFloodEvRslt result = CsFloodEvHdlr.exec( arg );
		
		this.operationList = result.operationList;
		this.statusList = result.statusList;
		
		return result.targetOperationCd;
	}
	
	private String execStateSearch( Tray tray, String opeCd, String staCd ) throws CareerException {
		
		CsFloodEvArg arg = new CsFloodEvArg( tray.loginNo );
		arg.sharp = "SEARCH";
		arg.party = tray.party;
		arg.slctedOperation = opeCd;
		arg.slctedStatus = staCd;
		CsFloodEvRslt result = CsFloodEvHdlr.exec( arg );
		
		return result.targetSheetsNum;
	}
}
