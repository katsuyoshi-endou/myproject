package jp.co.hisas.career.app.sheet.deliver.bulk;

import jp.co.hisas.career.app.sheet.api.bulk.BulkEvArg;
import jp.co.hisas.career.app.sheet.api.bulk.BulkEvHdlr;
import jp.co.hisas.career.app.sheet.api.bulk.BulkEvRslt;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Tray;

public class BulkGetDeliver {
	
	public static BulkEvRslt go( Tray tray, BulkGetOrder order ) throws CareerException {
		order.validate();
		
		BulkEvArg arg = new BulkEvArg( tray.loginNo );
		arg.sharp = "GET";
		arg.orderGET = order;
		return BulkEvHdlr.exec( arg );
	}
}
