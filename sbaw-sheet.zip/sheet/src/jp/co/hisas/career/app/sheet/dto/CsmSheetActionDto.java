/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CsmSheetActionDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String flowCd;
    private String flowPtn;
    private String statusCd;
    private String actorCd;
    private String lpadSort;
    private String actionCd;
    private String actionNm;
    private String afterStatusCd;
    private String confirmMsg;
    private String resultMsg;
    private String mailTemplate;
    private String useDelivFlg;

    public String getFlowCd() {
        return flowCd;
    }

    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    public String getFlowPtn() {
        return flowPtn;
    }

    public void setFlowPtn(String flowPtn) {
        this.flowPtn = flowPtn;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    public String getActorCd() {
        return actorCd;
    }

    public void setActorCd(String actorCd) {
        this.actorCd = actorCd;
    }

    public String getLpadSort() {
        return lpadSort;
    }

    public void setLpadSort(String lpadSort) {
        this.lpadSort = lpadSort;
    }

    public String getActionCd() {
        return actionCd;
    }

    public void setActionCd(String actionCd) {
        this.actionCd = actionCd;
    }

    public String getActionNm() {
        return actionNm;
    }

    public void setActionNm(String actionNm) {
        this.actionNm = actionNm;
    }

    public String getAfterStatusCd() {
        return afterStatusCd;
    }

    public void setAfterStatusCd(String afterStatusCd) {
        this.afterStatusCd = afterStatusCd;
    }

    public String getConfirmMsg() {
        return confirmMsg;
    }

    public void setConfirmMsg(String confirmMsg) {
        this.confirmMsg = confirmMsg;
    }

    public String getResultMsg() {
        return resultMsg;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public String getMailTemplate() {
        return mailTemplate;
    }

    public void setMailTemplate(String mailTemplate) {
        this.mailTemplate = mailTemplate;
    }

    public String getUseDelivFlg() {
        return useDelivFlg;
    }

    public void setUseDelivFlg(String useDelivFlg) {
        this.useDelivFlg = useDelivFlg;
    }

}

