package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.VPersonBelongUnionDto;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

@SuppressWarnings("serial")
public class PersonBelongEventResult extends AbstractEventResult {

	private List<VPersonBelongUnionDto> belList = null;
	private List<ValueTextSortDto> cmpaNmList;

	public List<VPersonBelongUnionDto> getBelList() {
		return belList;
	}

	public void setBelList( List<VPersonBelongUnionDto> belList ) {
		this.belList = belList;
	}

	public List<ValueTextSortDto> getCmpaNmList() {
		return cmpaNmList;
	}

	public void setCmpaNmList( List<ValueTextSortDto> cmpaNmList ) {
		this.cmpaNmList = cmpaNmList;
	}

}