package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import jp.co.hisas.career.app.sheet.dao.ZzCsmJkskGyomubDao;
import jp.co.hisas.career.app.sheet.dto.ZzCsmJkskGyomubDto;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

public class JkskGyomuBunruiEventHandler extends AbstractEventHandler<JkskGyomuBunruiEventArg, JkskGyomuBunruiEventResult> {
	
	private String loginNo;

	public static JkskGyomuBunruiEventResult exec( JkskGyomuBunruiEventArg arg ) throws CareerException {
		JkskGyomuBunruiEventHandler handler = new JkskGyomuBunruiEventHandler();
		return handler.call( arg );
	}

	@Override
	public JkskGyomuBunruiEventResult call( JkskGyomuBunruiEventArg arg ) throws CareerException {
		JkskGyomuBunruiEventResult result = null;

		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );

		return result;
	}

	@Override
	protected JkskGyomuBunruiEventResult execute( JkskGyomuBunruiEventArg arg ) throws CareerException {
		arg.validateArg();
		this.loginNo = arg.getLoginNo();

		JkskGyomuBunruiEventResult result = new JkskGyomuBunruiEventResult();

		try {
			// 業務分類リストの取得
			result.setGyomubList( getGyomuBunruiList( arg ));
			
			// 職種
			result.setShokushuList( getShokushuNameList() );
			
			// 職種2
			result.setShokushu2Map( getShokushuName2Map());
			
			// 分類
			result.setBunruiMap( getBunruiMap());
			
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
		return result;
	}

	private List<ZzCsmJkskGyomubDto> getGyomuBunruiList( JkskGyomuBunruiEventArg arg ) {
		StringBuilder sql = new StringBuilder();
		sql.append( "SELECT " + ZzCsmJkskGyomubDao.ALLCOLS + " FROM ZZ_CSM_JKSK_GYOMUB " );
		sql.append( "WHERE PARTY = ? " );
		sql.append( "ORDER BY SORT" );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.party );

		ZzCsmJkskGyomubDao dao = new ZzCsmJkskGyomubDao( loginNo );
		List<ZzCsmJkskGyomubDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ));
		if ( list == null) {
			list = new ArrayList<ZzCsmJkskGyomubDto>();
		}
		return list;
	}

	private List<String> getShokushuNameList() {
		StringBuilder sb = new StringBuilder();

		sb.append( "SELECT " );
		sb.append( "    '' AS party, " );
		sb.append( "    MIN(SORT) AS sort, " );
		sb.append( "    SHOKUSHU_NM AS shokushuNm, " );
		sb.append( "    '' AS shokushuNm2,  " );
		sb.append( "    '' AS gyomuBunrui, " );
		sb.append( "    '' AS shokushuDesc " );
		sb.append( "FROM ZZ_CSM_JKSK_GYOMUB " ); 
		sb.append( "GROUP BY SHOKUSHU_NM " );
		sb.append( "ORDER BY SORT" );
		
		ZzCsmJkskGyomubDao dao = new ZzCsmJkskGyomubDao( loginNo );
		List<ZzCsmJkskGyomubDto> list = dao.selectDynamic( sb.toString());
		
		List<String> shokushuList = new ArrayList<String>();
		for ( ZzCsmJkskGyomubDto dto : list ) {
			shokushuList.add( dto.getShokushuNm());
		}
		return shokushuList;
	}

	private Map<String, List<String>> getShokushuName2Map() {
		Map<String, List<String>> map = new TreeMap<String, List<String>>();
		
		StringBuilder sb = new StringBuilder();

		sb.append( "SELECT " );
		sb.append( "    '' AS party, " );
		sb.append( "    MIN(SORT) AS sort, " );
		sb.append( "    SHOKUSHU_NM AS shokushuNm, " );
		sb.append( "    SHOKUSHU_NM_2 AS shokushuNm2,  " );
		sb.append( "    '' AS gyomuBunrui, " );
		sb.append( "    '' AS shokushuDesc " );
		sb.append( "FROM ZZ_CSM_JKSK_GYOMUB " ); 
		sb.append( "GROUP BY SHOKUSHU_NM, SHOKUSHU_NM_2 " );
		sb.append( "ORDER BY SHOKUSHU_NM, SHOKUSHU_NM_2" );
		
		ZzCsmJkskGyomubDao dao = new ZzCsmJkskGyomubDao( loginNo );
		List<ZzCsmJkskGyomubDto> list = dao.selectDynamic( sb.toString());
		
		String before = "";
		String current = "";
		List<String> data = null;
		for ( ZzCsmJkskGyomubDto dto : list ) {
			current = dto.getShokushuNm();

			if ( "".equals( before )) {
				data = new ArrayList<String>();
				data.add( dto.getShokushuNm2());
			} else {
				if ( before.equals( current )) {
					data.add( dto.getShokushuNm2());
				} else {
					map.put( before, data );
					
					data = new ArrayList<String>();
					
					data.add( dto.getShokushuNm2());
				}
			}
			before = current;
		}
		if (data.size() > 0 ) {
			map.put( current, data );
		}
		return map;
	}

	private Map<String, List<String>> getBunruiMap() {
		Map<String, List<String>> map = new TreeMap<String, List<String>>();
		
		StringBuilder sb = new StringBuilder();

		sb.append( "SELECT " );
		sb.append( "    '' AS party, " );
		sb.append( "    MIN(SORT) AS sort, " );
		sb.append( "    '' AS shokushuNm, " );
		sb.append( "    SHOKUSHU_NM_2 AS shokushuNm2, " );
		sb.append( "    GYOMU_BUNRUI AS gyomuBunrui,  " );
		sb.append( "    '' AS shokushuDesc " );
		sb.append( "FROM ZZ_CSM_JKSK_GYOMUB " ); 
		sb.append( "GROUP BY SHOKUSHU_NM_2, GYOMU_BUNRUI " );
		sb.append( "ORDER BY SHOKUSHU_NM_2, GYOMU_BUNRUI" );
		
		ZzCsmJkskGyomubDao dao = new ZzCsmJkskGyomubDao( loginNo );
		List<ZzCsmJkskGyomubDto> list = dao.selectDynamic( sb.toString());
		
		String before = "";
		String current = "";
		List<String> data = null;
		for ( ZzCsmJkskGyomubDto dto : list ) {
			current = dto.getShokushuNm2();

			if ( "".equals( before )) {
				data = new ArrayList<String>();
				data.add( dto.getGyomuBunrui());
			} else {
				if ( before.equals( current )) {
					data.add( dto.getGyomuBunrui());
				} else {
					map.put( before, data );
					
					data = new ArrayList<String>();
					
					data.add( dto.getGyomuBunrui());
				}
			}
			before = current;
		}
		if (data.size() > 0 ) {
			map.put( current, data );
		}
		return map;
	}
}
