package jp.co.hisas.career.app.sheet.vm;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.ViewModel;
import jp.co.hisas.career.util.Tray;

public class VmVSHHOM extends ViewModel {
	
	public static String VMID = VmVSHHOM.class.getSimpleName();
	
	public VmVSHHOM(Tray tray) throws CareerException {
		super( tray );
	}
	
}
