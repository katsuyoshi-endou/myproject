/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class VCsmOperationFlowDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String party;
    private String operationCd;
    private String operationNm;
    private String opeSort;
    private String activeFlg;
    private String formGrpCd;
    private String formGrpNm;
    private String statusGrpCd;
    private String statusGrpNm;
    private String seqNo;
    private String statusCd;
    private String statusNm;

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getOperationCd() {
        return operationCd;
    }

    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    public String getOperationNm() {
        return operationNm;
    }

    public void setOperationNm(String operationNm) {
        this.operationNm = operationNm;
    }

    public String getOpeSort() {
        return opeSort;
    }

    public void setOpeSort(String opeSort) {
        this.opeSort = opeSort;
    }

    public String getActiveFlg() {
        return activeFlg;
    }

    public void setActiveFlg(String activeFlg) {
        this.activeFlg = activeFlg;
    }

    public String getFormGrpCd() {
        return formGrpCd;
    }

    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    public String getFormGrpNm() {
        return formGrpNm;
    }

    public void setFormGrpNm(String formGrpNm) {
        this.formGrpNm = formGrpNm;
    }

    public String getStatusGrpCd() {
        return statusGrpCd;
    }

    public void setStatusGrpCd(String statusGrpCd) {
        this.statusGrpCd = statusGrpCd;
    }

    public String getStatusGrpNm() {
        return statusGrpNm;
    }

    public void setStatusGrpNm(String statusGrpNm) {
        this.statusGrpNm = statusGrpNm;
    }

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    public String getStatusNm() {
        return statusNm;
    }

    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

}

