package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.VPersonBelongUnionDao;
import jp.co.hisas.career.util.dao.useful.ValueTextSortDao;
import jp.co.hisas.career.util.dto.VPersonBelongUnionDto;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;
import jp.co.hisas.career.util.log.Log;

public class PersonBelongEventHandler extends AbstractEventHandler<PersonBelongEventArg, PersonBelongEventResult> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static PersonBelongEventResult exec( PersonBelongEventArg arg ) throws CareerException {
		PersonBelongEventHandler handler = new PersonBelongEventHandler();
		return handler.call( arg );
	}
	
	public PersonBelongEventResult call( PersonBelongEventArg arg ) throws CareerException {
		PersonBelongEventResult result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected PersonBelongEventResult execute( PersonBelongEventArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		PersonBelongEventResult result = new PersonBelongEventResult();
		
		try {
			
			if ("UNION".equals( arg.sharp )) {
				// UNION: 本務＋兼務
				List<VPersonBelongUnionDto> belList = selectBelongsWithCond( arg );
				result.setBelList( belList );
				
				// CMPA_NMリストを取得(V_PERSON_BELONG_UNIONに会社名称が存在しないため
				result.setCmpaNmList( getCmpaNmList() );
				
			}
			
			return result;
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
	}
	
	private List<ValueTextSortDto> getCmpaNmList() {
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select distinct CLS_CD as value, CLS_NM as text, LPAD_SORT as sort from BELONG_CLASS_MASTER ");
		sql.append( "   where BEL_CLS = 'H'  ");
		
		ValueTextSortDao dao = new ValueTextSortDao( this.loginNo );
		List<ValueTextSortDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		
		return list;
	
	}

	private List<VPersonBelongUnionDto> selectBelongsWithCond( PersonBelongEventArg arg ) throws Exception {
		
		HashMap<String, String> map = arg.srchCondMap;
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
//      20190827 性能対策用に修正済み
		sql.append( " select " + SU.addPrefixOnDaoAllCols( "TGT_PB", VPersonBelongUnionDao.ALLCOLS ) );
		sql.append( " FROM ( ");
		sql.append( "    SELECT row_number() OVER (ORDER BY PB.DEPT_CD ,PB.CLS_C_CD ,PB.STF_NO) AS RNUM ");
		sql.append( "          ,PB.CMPA_CD ");
		sql.append( "          ,PB.STF_NO ");
		sql.append( "          ,PB.PERSON_NAME ");
		sql.append( "          ,PB.HONMU_FLG ");
		sql.append( "          ,PB.BEL_SORT ");
		sql.append( "          ,PB.DEPT_CD ");
		sql.append( "          ,PB.DEPT_NM ");
		sql.append( "          ,PB.CLS_A_CD ");
		sql.append( "          ,PB.CLS_A_NM ");
		sql.append( "          ,PB.CLS_B_CD ");
		sql.append( "          ,PB.CLS_B_NM ");
		sql.append( "          ,PB.CLS_C_CD ");
		sql.append( "          ,PB.CLS_C_NM ");
		sql.append( "          ,PB.CLS_D_CD ");
		sql.append( "          ,PB.CLS_D_NM ");
		sql.append( "          ,PB.CLS_E_CD ");
		sql.append( "          ,PB.CLS_E_NM ");
		sql.append( "          ,PB.CLS_F_CD ");
		sql.append( "          ,PB.CLS_F_NM ");
		sql.append( "          ,PB.CLS_G_CD ");
		sql.append( "          ,PB.CLS_G_NM ");
		sql.append( "          ,PB.CLS_H_CD ");
		sql.append( "          ,PB.CLS_H_NM ");
		sql.append( "          ,PB.CLS_I_CD ");
		sql.append( "          ,PB.CLS_I_NM ");
		sql.append( "          ,PB.CLS_J_CD ");
		sql.append( "          ,PB.CLS_J_NM ");
		sql.append( "          ,PB.CLS_K_CD ");
		sql.append( "          ,PB.CLS_K_NM ");
		sql.append( "          ,PB.CLS_L_CD ");
		sql.append( "          ,PB.CLS_L_NM ");
		sql.append( "          ,PB.CLS_M_CD ");
		sql.append( "          ,PB.CLS_M_NM ");
		sql.append( "          ,PB.CLS_N_CD ");
		sql.append( "          ,PB.CLS_N_NM ");
		sql.append( "          ,PB.TXT_A ");
		sql.append( "          ,PB.TXT_B ");
		sql.append( "          ,PB.TXT_C ");
		sql.append( "          ,PB.TXT_D ");
		sql.append( "          ,PB.TXT_E ");
		sql.append( "          ,PB.TXT_F ");
		sql.append( "          ,PB.TXT_G ");
		sql.append( "          ,PB.TXT_H ");
		sql.append( "          ,PB.TXT_I ");
		sql.append( "          ,PB.TXT_J ");
		sql.append( "          ,PB.TXT_K ");
		sql.append( "          ,PB.TXT_L ");
		sql.append( "          ,PB.TXT_M ");
		sql.append( "          ,PB.TXT_N ");
		sql.append( "      FROM V_PERSON_BELONG_UNION PB ");
		sql.append( "     INNER JOIN CA_PARTY_COMPANY PC ON PC.CMPA_CD = PB.CMPA_CD ");
		sql.append( "     INNER JOIN CA_REGIST CR ON CR.CMPA_CD = PB.CMPA_CD AND CR.STF_NO = PB.STF_NO AND CR.REGIST_FLG = '1' ");
		sql.append( "    WHERE PB.CLS_A_CD IN ");
		sql.append( "    ( ");
		sql.append( "        SELECT PARAM_VALUE AS TGT_CLS_A_CD ");
		sql.append( "        FROM CCP_PARAM ");
		sql.append( "        WHERE PARAM_BUNRUI_NM = 'Plan' AND PARAM_ID LIKE 'searchActorRslt_tgt_clsACd%' ");
		sql.append( "    ) ");
		sql.append( "    AND PB.CMPA_CD NOT IN ");
		sql.append( "    ( ");
		sql.append( "        SELECT PARAM_VALUE ");
		sql.append( "        FROM CCP_PARAM ");
		sql.append( "        WHERE PARAM_BUNRUI_NM = 'Plan' AND PARAM_ID LIKE 'dummyCompanyCd%' ");
		sql.append( "    ) ");
		if (srchCondAvailable(map, "SrchCondPersonNm" )) {
			sql.append( "    and pb.PERSON_NAME like ? ");		paramList.add( "%" + map.get( "SrchCondPersonNm" ) + "%" );
		}
		if (srchCondAvailable(map, "SrchCondShozoku" )) {
			sql.append( "    and pb.DEPT_NM like ? ");			paramList.add( "%" + map.get( "SrchCondShozoku" ) + "%" );
		}
		if (srchCondAvailable(map, "SrchCondYakushoku" )) {
			sql.append( "    and pb.CLS_C_NM like ? ");		paramList.add( "%" + map.get( "SrchCondYakushoku" ) + "%" );
		}
		sql.append( " ) TGT_PB ");
		sql.append( " WHERE TGT_PB.RNUM <= 100 ");
		
		VPersonBelongUnionDao dao = new VPersonBelongUnionDao( this.loginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private boolean srchCondAvailable( HashMap<String, String> srchCondMap, String key ) {
		if (srchCondMap == null) {
			return false;
		}
		if (!srchCondMap.containsKey( key )) {
			return false;
		}
		String val = srchCondMap.get( key );
		if (val == null || "".equals( val )) {
			return false;
		}
		return true;
	}
}
