/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CsmSheetFormDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String party;
    private String operationCd;
    private String formGrpCd;
    private String formCtgCd;
    private String formCd;
    private String formNm;
    private String formSort;
    private String layoutCd;
    private String labelSetCd;
    private String paramSetCd;
    private String fillSetCd;
    private String maskCd;
    private String flowCd;
    private String multiFormFlg;

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getOperationCd() {
        return operationCd;
    }

    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    public String getFormGrpCd() {
        return formGrpCd;
    }

    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    public String getFormCtgCd() {
        return formCtgCd;
    }

    public void setFormCtgCd(String formCtgCd) {
        this.formCtgCd = formCtgCd;
    }

    public String getFormCd() {
        return formCd;
    }

    public void setFormCd(String formCd) {
        this.formCd = formCd;
    }

    public String getFormNm() {
        return formNm;
    }

    public void setFormNm(String formNm) {
        this.formNm = formNm;
    }

    public String getFormSort() {
        return formSort;
    }

    public void setFormSort(String formSort) {
        this.formSort = formSort;
    }

    public String getLayoutCd() {
        return layoutCd;
    }

    public void setLayoutCd(String layoutCd) {
        this.layoutCd = layoutCd;
    }

    public String getLabelSetCd() {
        return labelSetCd;
    }

    public void setLabelSetCd(String labelSetCd) {
        this.labelSetCd = labelSetCd;
    }

    public String getParamSetCd() {
        return paramSetCd;
    }

    public void setParamSetCd(String paramSetCd) {
        this.paramSetCd = paramSetCd;
    }

    public String getFillSetCd() {
        return fillSetCd;
    }

    public void setFillSetCd(String fillSetCd) {
        this.fillSetCd = fillSetCd;
    }

    public String getMaskCd() {
        return maskCd;
    }

    public void setMaskCd(String maskCd) {
        this.maskCd = maskCd;
    }

    public String getFlowCd() {
        return flowCd;
    }

    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    public String getMultiFormFlg() {
        return multiFormFlg;
    }

    public void setMultiFormFlg(String multiFormFlg) {
        this.multiFormFlg = multiFormFlg;
    }

}

