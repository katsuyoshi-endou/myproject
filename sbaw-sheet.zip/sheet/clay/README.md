# Lyca Clay

## 開発環境の構築

※ assets と同様

## テンプレートを追加するには

制度コード `inst-xxxx` に合わせて `entry/components/inst-xxxx` フォルダとその中身 `vue-template.html` を作成します。
`webpack.config.js` のうち `entry` と `plugins` のセクションをサンプルにならって書き加えます。

標準テンプレートで提供しているよりも高度な内容を
実現するには `entry/official/vue-script.js` を複製し、これを書き換えます。
その場合 `webpack.config.js` の `entry` セクションで参照先を複製したものに切り替えてください。

## ビルド

`npm-bundle.bat` を実行すると `dist` ディレクトリにビルドしたものが生成されます。
これらを `C:\Lysithea\Career\Sheet\clay` に配置します。

## 開発の流れ

- コマンド `npm run watch` を実行してソースコードの変更を検知し、自動でビルドが走るようにします。
- ソースコードを書き換えます。
- 自動ビルドが走ったことを確認し `dev-mirror.bat` を実行します。このとき、HTML はコンソールに反応がありませんが自動ビルドされています。
- 開発中のリポジトリフォルダから C:\Lysithea 配下にコピーされます。
- properties にてデバッグモードであれば、画面を再読込みしたときにキャッシュがリロードされます。
- Chrome DevTools 内で Ctrl + P で `vue-script.js` を開くとデバッグできます。
