<template>
  <el-table-column :label="label" :width="width">
    <template slot-scope="scope">
      <a type="button" class="sh-status-chip" :class="{ isHold: scope.row.isHold }" size="small"
        @click="emitClick(scope)"
      >
        {{ scope.row.statusNm }}
      </a>
    </template>
  </el-table-column>
</template>

<script>
export default {
  props: ['label', 'width'],
  computed: {
  },
  methods: {
    emitClick(scope) {
      this.$emit("click", scope.row);
    },
  }
}
</script>
