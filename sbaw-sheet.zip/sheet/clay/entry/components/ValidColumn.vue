<template>
  <el-table-column :label="label" class-name="xx-col-valid" width="50" align="center">
    <template slot-scope="scope">
      <el-popover v-if="scope.row.invalidMsgList.length > 0" placement="right" width="400" trigger="hover">
        <div class="xx-valid-messages">
          <p class="xx-valid-messages-item" v-for="(msg, idx) in scope.row.invalidMsgList" :key="idx">
            <i class="xx-valid-ng el-icon-warning"></i>
            <span>{{ msg }}</span>
          </p>
        </div>
        <span slot="reference">
          <i class="xx-valid-ng el-icon-warning" style="cursor:pointer;"></i>
        </span>
      </el-popover>
      <i v-else class="xx-valid-ok el-icon-success"></i>
    </template>
  </el-table-column>
</template>

<script>
export default {
  props: ['label'],
  computed: {
  },
  methods: {
  }
}
</script>
