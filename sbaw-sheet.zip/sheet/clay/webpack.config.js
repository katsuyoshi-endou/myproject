const path = require("path");
const CopyWebpackPlugin = require("copy-webpack-plugin");
const VueLoaderPlugin = require("vue-loader/lib/plugin");
const Autoprefixer = require("autoprefixer");

const cssLoader = {
  loader: "css-loader",
  options: {
    url: false,
    sourceMap: true,
    minimize: true,
    importLoaders: 2,
  },
};

const postcssLoader = {
  loader: "postcss-loader",
  options: {
    sourceMap: true,
    plugins: [
      Autoprefixer({
        grid: true,
        browsers: ["ie >= 11", "Chrome >= 53", "iOS >= 8", "Firefox >= 49", "Edge >= 14"],
      }),
    ],
  },
};

module.exports = {
  entry: {
    "inst-jksk/vue-script": ["babel-polyfill", "./entry/official/vue-script.js"],
    "inst-mkhy/vue-script": ["babel-polyfill", "./entry/official/vue-script.js"],
  },
  output: {
    path: `${__dirname}/dist`,
    filename: "[name].bundle.js",
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        use: [
          {
            loader: "babel-loader",
            options: {
              presets: [["env", { modules: false }]],
            },
          },
        ],
      },
      {
        test: /\.vue$/,
        loader: "vue-loader",
      },
      {
        test: /\.styl(us)?$/,
        include: path.resolve(__dirname, "entry/components"),
        use: ["style-loader", "vue-style-loader", cssLoader, postcssLoader, "stylus-loader"],
      },
    ],
  },
  plugins: [
    new VueLoaderPlugin(),
    new CopyWebpackPlugin([
      { from: "entry/inst-jksk/vue-template.html", to: "inst-jksk/vue-template.html" },
      { from: "entry/inst-mkhy/vue-template.html", to: "inst-mkhy/vue-template.html" },
    ]),
  ],
  resolve: {
    modules: [path.join(__dirname, "entry"), "node_modules"],
    extensions: [".js", ".vue"],
    alias: {
      vue$: "vue/dist/vue.esm.js",
    },
  },
  devtool: "source-map",
};
