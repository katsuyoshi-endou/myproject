Career Assets
=============

`assets`: 静的コンテンツを扱うためのフォルダ

## ビルドについて

このフォルダ内にて手動で操作することはありません。
ear ファイルを生成する場合に、間接的に `npm-bundle.bat` が呼ばれます。

## 構成の解説

### entry / components

`entry/components.js` が参照するコンポーネントを配置します。

### entry / scss

`entry/style.js` で読み込むスタイルシートを配置します。

### entry / vendor

`entry/vendor.js` で読み込む外部ベンダーライブラリを配置します。

### img

アプリ独自のCSSファイルが参照する画像を配置します。

### package.json

Node.js のパッケージ管理システム npm で扱うための情報です。  
これをもとに何をインストールするかが決定され、実行コマンドを提供します。  
`npm install` コマンドで必要なパッケージが `node_modules` フォルダにインストールされます。  
※インストール処理は `npm-bundle.bat` によって行われるので手打ちする必要はありません。

### webpack.config.js

__webpack__ というモジュールバンドラーを採用しており、その設定ファイルとなります。
この設定は基本的に変更する必要はありません。
（※もし改修の必要がある場合、まずは有識者に相談してください。）

webpack は「モダンなJavaScript記法を扱うことによるコード可読性、保守性、生産性の向上」、
「モジュール管理の実現」「バンドルによるリクエスト数の低減」「圧縮機能による通信負荷軽減」
などを目的として採用しています。

## 開発環境の構築

### [Visual Studio Code](https://code.visualstudio.com/)

- [ESLint - Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)
- [Prettier - Code formatter - Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)

### ESLint・Prettierのインストール

```bat
npm install -g eslint eslint-config-airbnb-base eslint-config-prettier eslint-plugin-import eslint-plugin-prettier prettier-eslint
```

#### VSCode 設定

```bat
  "prettier.eslintIntegration": true,
```

#### フォーマットの呼び出し方

<dl>
  <dt>Keyboard</dt>
  <dd><kbd>Shift</kbd>+<kbd>Alt</kbd>+<kbd>F</kbd></dd>
</dl>

<dl>
  <dt>Command Palette</dt>
  <dd>
    <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>P</kbd>
    Format Document
  </dd>
</dl>

### ホットデプロイ

HotDeploy-Assets.bat を実行すると、新たにビルドしたファイル群を Glassfish のデプロイディレクトリに直接配置し直します。
バッチ内部で development モードに切り替えているので、ブラウザ上でのデバッグがしやすくなります。
