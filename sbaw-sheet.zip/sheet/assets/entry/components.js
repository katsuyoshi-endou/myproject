import Vue from "vue";
import Vuex from "vuex";
import ElementUI from "element-ui";
import enLang from "element-ui/lib/locale/lang/en";
import "./scss/element-variables.scss";
import "element-ui/lib/theme-chalk/fonts/element-icons.ttf";
import "element-ui/lib/theme-chalk/fonts/element-icons.woff";

import HelloWorld from "./components/HelloWorld";
import ActionButtons from "./components/bulk/ActionButtons";

window.Vue = Vue;
window.Vuex = Vuex;

enLang.el.select.placeholder = "";
Vue.use(ElementUI, { locale: enLang });

Vue.component("hello-world", HelloWorld);
Vue.component("action-buttons", ActionButtons);
