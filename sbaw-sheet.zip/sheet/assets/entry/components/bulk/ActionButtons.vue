<template>
  <div class="cc-actionbuttons">
    <template v-for="act in actions">
      <button
        type="button"
        class="btn"
        :key="act.ACTION_CD"
        :data-qt="act.ACTION_CD"
        :class="theClass(act)"
        @click="handleClick(act)"
      >
        {{ act.ACTION_NM }}
      </button>
    </template>
  </div>
</template>

<script>
export default {
  props: ['actions'],
  computed: {
  },
  methods: {
    theClass: function(act) {
      return {
        'btn-primary': act.ACTION_CD.match(/FORWARD|SKIP/),
        'btn-big': act.ACTION_CD.match(/FORWARD|SKIP/),
        'btn-delete': act.ACTION_CD.match(/DELETE/),
      }
    },
    handleClick(act) {
      this.$emit('do', act);
    }
  }
}
</script>

<style lang="stylus" scoped>
.cc-actionbuttons 

  .btn
    margin 0 8px

</style>
