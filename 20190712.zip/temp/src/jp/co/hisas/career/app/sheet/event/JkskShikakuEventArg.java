package jp.co.hisas.career.app.sheet.event;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;

@SuppressWarnings("serial")
public class JkskShikakuEventArg extends AbstractEventArg {
	
	public String sharp = null;

	// 原籍会社コード
	public String clsHCode = null;
	
	// シートID
	public String sheetId = null;

	public JkskShikakuEventArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void setAll( String sharp, String code, String sheetId ) {
		this.sharp = sharp;
		this.clsHCode = code;
		this.sheetId = sheetId;
	}
	
	public void validateArg() throws CareerException {
		if (this.sharp == null || "".equals( this.sharp.trim() )) {
			throw new CareerException( "Invalid Arg: sharp is null." );
		}
	}
}
