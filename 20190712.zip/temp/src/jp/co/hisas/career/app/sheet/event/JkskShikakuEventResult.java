package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.ZzCsmJkskSikakuDto;
import jp.co.hisas.career.ejb.AbstractEventResult;

public class JkskShikakuEventResult extends AbstractEventResult {
	
	private List<ZzCsmJkskSikakuDto> sikakuList = null;

	public List<ZzCsmJkskSikakuDto> getSikakuList() {
		return sikakuList;
	}

	public void setSikakuList( List<ZzCsmJkskSikakuDto> list ) {
		this.sikakuList = list;
	}
}
