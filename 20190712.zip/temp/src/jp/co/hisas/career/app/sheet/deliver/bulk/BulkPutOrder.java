package jp.co.hisas.career.app.sheet.deliver.bulk;

import jp.co.hisas.career.app.sheet.api.mold.BulkConditions;
import jp.co.hisas.career.app.sheet.deliver.DeliverOrder;
import jp.co.hisas.career.util.Tray;

public class BulkPutOrder extends DeliverOrder {
	
	public String operationCd;
	public BulkConditions conditions = new BulkConditions();
	
	public BulkPutOrder(Tray tray) {
		super( tray );
	}
	
	public void prepare() {
		if (this.conditions == null) {
			this.conditions = new BulkConditions();
		}
	}
}
