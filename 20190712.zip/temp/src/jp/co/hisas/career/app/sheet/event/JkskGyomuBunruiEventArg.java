package jp.co.hisas.career.app.sheet.event;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;

public class JkskGyomuBunruiEventArg extends AbstractEventArg {
	public String sharp = null;

	public String party = null;
	
	public JkskGyomuBunruiEventArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void setAll( String sharp, String party ) {
		this.sharp = sharp;
		this.party = party;
	}
	
	public void validateArg() throws CareerException {
		if (this.sharp == null || "".equals( this.sharp.trim() )) {
			throw new CareerException( "Invalid Arg: sharp is null." );
		}
	}
}
