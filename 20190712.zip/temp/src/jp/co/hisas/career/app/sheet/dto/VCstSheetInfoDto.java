/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class VCstSheetInfoDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sheetId;
    private String party;
    private String operationCd;
    private String operationNm;
    private String operationType;
    private String operationSort;
    private String activeFlg;
    private String formGrpCd;
    private String formGrpNm;
    private String formCtgCd;
    private String formCd;
    private String formNm;
    private String ownGuid;
    private String layoutCd;
    private String labelSetCd;
    private String paramSetCd;
    private String fillSetCd;
    private String maskCd;
    private String multiFormFlg;
    private String flowCd;
    private String flowPtn;
    private String seqNo;
    private String statusCd;
    private String statusNm;
    private String mainActorCd;
    private String holdGuid;

    public String getSheetId() {
        return sheetId;
    }

    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getOperationCd() {
        return operationCd;
    }

    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    public String getOperationNm() {
        return operationNm;
    }

    public void setOperationNm(String operationNm) {
        this.operationNm = operationNm;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getOperationSort() {
        return operationSort;
    }

    public void setOperationSort(String operationSort) {
        this.operationSort = operationSort;
    }

    public String getActiveFlg() {
        return activeFlg;
    }

    public void setActiveFlg(String activeFlg) {
        this.activeFlg = activeFlg;
    }

    public String getFormGrpCd() {
        return formGrpCd;
    }

    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    public String getFormGrpNm() {
        return formGrpNm;
    }

    public void setFormGrpNm(String formGrpNm) {
        this.formGrpNm = formGrpNm;
    }

    public String getFormCtgCd() {
        return formCtgCd;
    }

    public void setFormCtgCd(String formCtgCd) {
        this.formCtgCd = formCtgCd;
    }

    public String getFormCd() {
        return formCd;
    }

    public void setFormCd(String formCd) {
        this.formCd = formCd;
    }

    public String getFormNm() {
        return formNm;
    }

    public void setFormNm(String formNm) {
        this.formNm = formNm;
    }

    public String getOwnGuid() {
        return ownGuid;
    }

    public void setOwnGuid(String ownGuid) {
        this.ownGuid = ownGuid;
    }

    public String getLayoutCd() {
        return layoutCd;
    }

    public void setLayoutCd(String layoutCd) {
        this.layoutCd = layoutCd;
    }

    public String getLabelSetCd() {
        return labelSetCd;
    }

    public void setLabelSetCd(String labelSetCd) {
        this.labelSetCd = labelSetCd;
    }

    public String getParamSetCd() {
        return paramSetCd;
    }

    public void setParamSetCd(String paramSetCd) {
        this.paramSetCd = paramSetCd;
    }

    public String getFillSetCd() {
        return fillSetCd;
    }

    public void setFillSetCd(String fillSetCd) {
        this.fillSetCd = fillSetCd;
    }

    public String getMaskCd() {
        return maskCd;
    }

    public void setMaskCd(String maskCd) {
        this.maskCd = maskCd;
    }

    public String getMultiFormFlg() {
        return multiFormFlg;
    }

    public void setMultiFormFlg(String multiFormFlg) {
        this.multiFormFlg = multiFormFlg;
    }

    public String getFlowCd() {
        return flowCd;
    }

    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    public String getFlowPtn() {
        return flowPtn;
    }

    public void setFlowPtn(String flowPtn) {
        this.flowPtn = flowPtn;
    }

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    public String getStatusNm() {
        return statusNm;
    }

    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    public String getMainActorCd() {
        return mainActorCd;
    }

    public void setMainActorCd(String mainActorCd) {
        this.mainActorCd = mainActorCd;
    }

    public String getHoldGuid() {
        return holdGuid;
    }

    public void setHoldGuid(String holdGuid) {
        this.holdGuid = holdGuid;
    }

}

