/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.VCsmOperationFlowDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class VCsmOperationFlowDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " PARTY as party,"
                     + " OPERATION_CD as operationCd,"
                     + " OPERATION_NM as operationNm,"
                     + " OPE_SORT as opeSort,"
                     + " ACTIVE_FLG as activeFlg,"
                     + " FORM_GRP_CD as formGrpCd,"
                     + " FORM_GRP_NM as formGrpNm,"
                     + " STATUS_GRP_CD as statusGrpCd,"
                     + " STATUS_GRP_NM as statusGrpNm,"
                     + " SEQ_NO as seqNo,"
                     + " STATUS_CD as statusCd,"
                     + " STATUS_NM as statusNm"
                     ;

    public VCsmOperationFlowDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public VCsmOperationFlowDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public VCsmOperationFlowDto select(String party, String operationCd, String formGrpCd, String seqNo) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM V_CSM_OPERATION_FLOW"
                         + " WHERE PARTY = ?"
                         + " AND OPERATION_CD = ?"
                         + " AND FORM_GRP_CD = ?"
                         + " AND SEQ_NO = ?"
                         ;
        Log.sql("[DaoMethod Call] VCsmOperationFlowDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, party);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, operationCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, formGrpCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, seqNo);
            rs = pstmt.executeQuery();
            VCsmOperationFlowDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<VCsmOperationFlowDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] VCsmOperationFlowDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<VCsmOperationFlowDto> lst = new ArrayList<VCsmOperationFlowDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<VCsmOperationFlowDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] VCsmOperationFlowDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private VCsmOperationFlowDto transferRsToDto(ResultSet rs) throws SQLException {

        VCsmOperationFlowDto dto = new VCsmOperationFlowDto();
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setOperationCd(DaoUtil.convertNullToString(rs.getString("operationCd")));
        dto.setOperationNm(DaoUtil.convertNullToString(rs.getString("operationNm")));
        dto.setOpeSort(DaoUtil.convertNullToString(rs.getString("opeSort")));
        dto.setActiveFlg(DaoUtil.convertNullToString(rs.getString("activeFlg")));
        dto.setFormGrpCd(DaoUtil.convertNullToString(rs.getString("formGrpCd")));
        dto.setFormGrpNm(DaoUtil.convertNullToString(rs.getString("formGrpNm")));
        dto.setStatusGrpCd(DaoUtil.convertNullToString(rs.getString("statusGrpCd")));
        dto.setStatusGrpNm(DaoUtil.convertNullToString(rs.getString("statusGrpNm")));
        dto.setSeqNo(DaoUtil.convertNullToString(rs.getString("seqNo")));
        dto.setStatusCd(DaoUtil.convertNullToString(rs.getString("statusCd")));
        dto.setStatusNm(DaoUtil.convertNullToString(rs.getString("statusNm")));
        return dto;
    }

    public List<VCsmOperationFlowDto> selectActiveFlowByParty(String party) {

        final String sql = "select " + ALLCOLS + " from V_CSM_OPERATION_FLOW where PARTY = ? and ACTIVE_FLG = '1' order by OPE_SORT desc, SEQ_NO";
        Log.sql("[DaoMethod Call] VCsmOperationFlowDao.selectActiveFlowByParty");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, party);
            rs = pstmt.executeQuery();
            List<VCsmOperationFlowDto> lst = new ArrayList<VCsmOperationFlowDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<VCsmOperationFlowDto> selectActiveFlowByPartyAndOpe(String party, String operationCd) {

        final String sql = "select " + ALLCOLS + " from V_CSM_OPERATION_FLOW where PARTY = ? and OPERATION_CD = ? and ACTIVE_FLG = '1' order by SEQ_NO";
        Log.sql("[DaoMethod Call] VCsmOperationFlowDao.selectActiveFlowByPartyAndOpe");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, party);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, operationCd);
            rs = pstmt.executeQuery();
            List<VCsmOperationFlowDto> lst = new ArrayList<VCsmOperationFlowDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

