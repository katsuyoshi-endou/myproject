/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class VCstSheetListDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sheetId;
    private String party;
    private String operationCd;
    private String operationNm;
    private String operationSort;
    private String activeFlg;
    private String formGrpCd;
    private String formGrpNm;
    private String formCd;
    private String formNm;
    private String ownGuid;
    private String personName;
    private String sheetSort;
    private String listCol1;
    private String listCol2;
    private String listCol3;
    private String listCol4;
    private String listCol5;
    private String listCol6;
    private String listCol7;
    private String listCol8;
    private String listCol9;
    private String listCol10;
    private String statusCd;
    private String statusNm;
    private String holdGuid;
    private String latestTimestamp;
    private String deptCd;

    public String getSheetId() {
        return sheetId;
    }

    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getOperationCd() {
        return operationCd;
    }

    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    public String getOperationNm() {
        return operationNm;
    }

    public void setOperationNm(String operationNm) {
        this.operationNm = operationNm;
    }

    public String getOperationSort() {
        return operationSort;
    }

    public void setOperationSort(String operationSort) {
        this.operationSort = operationSort;
    }

    public String getActiveFlg() {
        return activeFlg;
    }

    public void setActiveFlg(String activeFlg) {
        this.activeFlg = activeFlg;
    }

    public String getFormGrpCd() {
        return formGrpCd;
    }

    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    public String getFormGrpNm() {
        return formGrpNm;
    }

    public void setFormGrpNm(String formGrpNm) {
        this.formGrpNm = formGrpNm;
    }

    public String getFormCd() {
        return formCd;
    }

    public void setFormCd(String formCd) {
        this.formCd = formCd;
    }

    public String getFormNm() {
        return formNm;
    }

    public void setFormNm(String formNm) {
        this.formNm = formNm;
    }

    public String getOwnGuid() {
        return ownGuid;
    }

    public void setOwnGuid(String ownGuid) {
        this.ownGuid = ownGuid;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getSheetSort() {
        return sheetSort;
    }

    public void setSheetSort(String sheetSort) {
        this.sheetSort = sheetSort;
    }

    public String getListCol1() {
        return listCol1;
    }

    public void setListCol1(String listCol1) {
        this.listCol1 = listCol1;
    }

    public String getListCol2() {
        return listCol2;
    }

    public void setListCol2(String listCol2) {
        this.listCol2 = listCol2;
    }

    public String getListCol3() {
        return listCol3;
    }

    public void setListCol3(String listCol3) {
        this.listCol3 = listCol3;
    }

    public String getListCol4() {
        return listCol4;
    }

    public void setListCol4(String listCol4) {
        this.listCol4 = listCol4;
    }

    public String getListCol5() {
        return listCol5;
    }

    public void setListCol5(String listCol5) {
        this.listCol5 = listCol5;
    }

    public String getListCol6() {
        return listCol6;
    }

    public void setListCol6(String listCol6) {
        this.listCol6 = listCol6;
    }

    public String getListCol7() {
        return listCol7;
    }

    public void setListCol7(String listCol7) {
        this.listCol7 = listCol7;
    }

    public String getListCol8() {
        return listCol8;
    }

    public void setListCol8(String listCol8) {
        this.listCol8 = listCol8;
    }

    public String getListCol9() {
        return listCol9;
    }

    public void setListCol9(String listCol9) {
        this.listCol9 = listCol9;
    }

    public String getListCol10() {
        return listCol10;
    }

    public void setListCol10(String listCol10) {
        this.listCol10 = listCol10;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    public String getStatusNm() {
        return statusNm;
    }

    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    public String getHoldGuid() {
        return holdGuid;
    }

    public void setHoldGuid(String holdGuid) {
        this.holdGuid = holdGuid;
    }

    public String getLatestTimestamp() {
        return latestTimestamp;
    }

    public void setLatestTimestamp(String latestTimestamp) {
        this.latestTimestamp = latestTimestamp;
    }

    public String getDeptCd() {
        return deptCd;
    }

    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

}

