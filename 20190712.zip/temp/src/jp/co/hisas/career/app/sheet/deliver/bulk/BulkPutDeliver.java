package jp.co.hisas.career.app.sheet.deliver.bulk;

import jp.co.hisas.career.app.sheet.api.bulk.BulkEvArg;
import jp.co.hisas.career.app.sheet.api.bulk.BulkEvHdlr;
import jp.co.hisas.career.app.sheet.api.mold.BulkPageState;
import jp.co.hisas.career.app.sheet.deliver.sheet.SheetDeliver;
import jp.co.hisas.career.app.sheet.dto.CsmSheetOperationDto;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerSecurityException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class BulkPutDeliver {
	
	public static void go( Tray tray, BulkPutOrder order ) throws CareerException {
		
		String operationCd = getOperationCd( tray, order );
		String instCd = getInstCd( tray, operationCd );
		
		tray.session.setAttribute( CsSessionKey.CS_BULK_OPERATION_CD, operationCd );
		tray.session.setAttribute( CsSessionKey.CS_BULK_INST_CD, instCd );
		tray.session.setAttribute( CsSessionKey.CS_BULK_LIVE_CONDITIONS, order.conditions );
		tray.session.setAttribute( CsSessionKey.CS_BULK_PAGE_STATE, new BulkPageState() );
		
		BulkEvArg arg = new BulkEvArg( tray.loginNo );
		arg.sharp = "PUT";
		arg.orderPUT = order;
		BulkEvHdlr.exec( arg );
	}
	
	private static String getOperationCd( Tray tray, BulkPutOrder order ) throws CareerException {
		String operationCd = order.operationCd;
		if (SU.isBlank( operationCd )) {
			CsmSheetOperationDto dto = SheetDeliver.getFirstOperation( tray );
			operationCd = dto.getOperationCd();
		}
		return operationCd;
	}
	
	private static String getInstCd( Tray tray, String operationCd ) throws CareerException {
		CsmSheetOperationDto dto = SheetDeliver.getOperation( tray, operationCd );
		if (dto == null) {
			String msg = "InstCd is not found. Passed operationCd is '" + operationCd + "'.";
			throw new CareerSecurityException( msg );
		}
		return dto.getInstCd();
	}
	
}
