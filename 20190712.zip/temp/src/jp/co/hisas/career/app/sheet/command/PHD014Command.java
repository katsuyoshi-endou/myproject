package jp.co.hisas.career.app.sheet.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.sheet.event.CsActorEventArg;
import jp.co.hisas.career.app.sheet.event.CsActorEventHandler;
import jp.co.hisas.career.app.sheet.event.CsActorEventResult;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.framework.trans.StateTransitionEvent;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class PHD014Command extends AbstractCommand {
	
	public static final String KINOU_ID = "VHD014";
	private HttpServletRequest request;
	private HttpSession session;
	private String state;
	
	public PHD014Command() {
		super( PHD014Command.class, KINOU_ID, null );
	}
	
	public void init( StateTransitionEvent e ) {
		try {
			request = e.getRequest();
			session = request.getSession( false );
			/* Not Update Token While Single Sheet.
			CSRFTokenUtil.setNewTokenNo( request, e.getResponse() ); */
			state = request.getParameter( "state" );
			main();
		} catch (CareerException ex) {
			throw new CareerRuntimeException( ex );
		}
	}
	
	private void main() throws CareerException {
		
		if ("INIT".equals( state ) || "RESTORE".equals( state )) {
			execEventListAct();
		}
		else if ("CHG_ACT".equals( state ) || "DEL_ACT".equals( state )) {
			state = "INIT";
			execEventListAct();
		}
		
		/* 操作ログ */
		OutLogBean.outputLogSousa( request, KINOU_ID, (String)AU.getSessionAttr( session, CsSessionKey.CS_SHEET_ID ), state );
	}
	
	private void execEventListAct() throws CareerException {
		
		// set SheetID on Session.
		String sheetId = CsUtil.setSheetIdOnSession( request, session );
		
		/* Set Args */
		CsActorEventArg arg = new CsActorEventArg( super.getLoginNo() );
		arg.sharp = "LIST_ACT";
		arg.sheetId = sheetId;
		arg.actorCd = request.getParameter( "actorCd" );
		
		/* Execute Event */
		CsActorEventResult result = CsActorEventHandler.exec( arg );
		
		/* Return to session */
		session.setAttribute( CsSessionKey.CS_ACTOR_LIST, result.getActorList() );
		session.setAttribute( CsSessionKey.CS_HOLD_ACTOR_LIST, result.getHoldActorList() );		
	}
	
}