/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActionLogDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class VCstSheetActionLogDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " TIMESTAMP as timestamp,"
                     + " SHEET_ID as sheetId,"
                     + " PERSON_NAME as personName,"
                     + " ACTOR_NM as actorNm,"
                     + " STATUS_NM as statusNm,"
                     + " ACTION_CD as actionCd,"
                     + " ACTION_NM as actionNm,"
                     + " DELIV_MSG as delivMsg"
                     ;

    public VCstSheetActionLogDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public VCstSheetActionLogDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    private VCstSheetActionLogDto transferRsToDto(ResultSet rs) throws SQLException {

        VCstSheetActionLogDto dto = new VCstSheetActionLogDto();
        dto.setTimestamp(DaoUtil.convertNullToString(rs.getString("timestamp")));
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setPersonName(DaoUtil.convertNullToString(rs.getString("personName")));
        dto.setActorNm(DaoUtil.convertNullToString(rs.getString("actorNm")));
        dto.setStatusNm(DaoUtil.convertNullToString(rs.getString("statusNm")));
        dto.setActionCd(DaoUtil.convertNullToString(rs.getString("actionCd")));
        dto.setActionNm(DaoUtil.convertNullToString(rs.getString("actionNm")));
        dto.setDelivMsg(DaoUtil.convertNullToString(rs.getString("delivMsg")));
        return dto;
    }

    public List<VCstSheetActionLogDto> getActionLoglist(String sheetId) {

        final String sql = "select " + ALLCOLS + " from V_CST_SHEET_ACTION_LOG WHERE SHEET_ID = ? order by TIMESTAMP DESC";
        Log.sql("[DaoMethod Call] VCstSheetActionLogDao.getActionLoglist");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            rs = pstmt.executeQuery();
            List<VCstSheetActionLogDto> lst = new ArrayList<VCstSheetActionLogDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

