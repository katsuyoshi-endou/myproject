package jp.co.hisas.career.app.sheet.garage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.api.mold.Fill;
import jp.co.hisas.career.app.sheet.dao.CsmFillCheckDao;
import jp.co.hisas.career.app.sheet.dao.CsmSheetActionDao;
import jp.co.hisas.career.app.sheet.dao.CsmSheetOperationDao;
import jp.co.hisas.career.app.sheet.dao.CstFillInvalidDao;
import jp.co.hisas.career.app.sheet.dao.VCsInfoAttrDao;
import jp.co.hisas.career.app.sheet.dao.extra.GeneralMapDao;
import jp.co.hisas.career.app.sheet.dto.CsmFillCheckDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetActionDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetOperationDto;
import jp.co.hisas.career.app.sheet.dto.CstFillInvalidDto;
import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.app.sheet.event.CsSheetEventHandler;
import jp.co.hisas.career.app.sheet.util.CsFillIdCache;
import jp.co.hisas.career.app.sheet.util.CsFillMaskCache;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.OneColumnDao;

public class SheetGarage extends Garage {
	
	public SheetGarage(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public CsmSheetOperationDto getOperation( String party, String operationCd ) {
		CsmSheetOperationDao dao = new CsmSheetOperationDao( daoLoginNo );
		return dao.select( party, operationCd );
	}
	
	public CsmSheetOperationDto getFirstOperation( String party ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + CsmSheetOperationDao.ALLCOLS );
		sql.append( "   from ( " );
		sql.append( "          select * " );
		sql.append( "            from CSM_SHEET_OPERATION" );
		sql.append( "           where PARTY = ? " );
		sql.append( "             and OPEN_FLG = '1' " );
		sql.append( "           order by ACTIVE_FLG desc, LPAD_SORT desc " );
		sql.append( "        ) " );
		sql.append( "  where ROWNUM = 1 " );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( party );
		
		CsmSheetOperationDao dao = new CsmSheetOperationDao( daoLoginNo );
		List<CsmSheetOperationDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		return list.size() > 0 ? list.get( 0 ) : new CsmSheetOperationDto();
	}
	
	public List<CsmSheetOperationDto> getOpenOperationMaster( String party ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + CsmSheetOperationDao.ALLCOLS );
		sql.append( "   from CSM_SHEET_OPERATION" );
		sql.append( "  where OPEN_FLG = '1'" );
		sql.append( "    and PARTY = ? " );
		sql.append( "  order by LPAD_SORT desc, OPERATION_CD" );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( party );
		
		CsmSheetOperationDao dao = new CsmSheetOperationDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public VCsInfoAttrDto getSheetInfoAttr( String sheetId ) {
		VCsInfoAttrDao dao = new VCsInfoAttrDao( daoLoginNo );
		VCsInfoAttrDto dto = dao.select( sheetId );
		if (dto == null) {
			dto = new VCsInfoAttrDto();
		}
		return dto;
	}
	
	public boolean existsSheetAction( String party, String operationCd, String flowPtn, String statusCd, String actorCd, String actionCd ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + SU.addPrefixOnDaoAllCols( "ac", CsmSheetActionDao.ALLCOLS ) );
		sql.append( "   from CSM_SHEET_ACTION ac" );
		sql.append( "        inner join V_CSM_OPERATION_FLOW_MAP fl" );
		sql.append( "          on (fl.PARTY = ? " );
		sql.append( "          and fl.OPERATION_CD = ? " );
		sql.append( "          and fl.FLOW_CD = ac.FLOW_CD)" );
		sql.append( "  where ac.FLOW_PTN = ? " );
		sql.append( "    and ac.STATUS_CD = ? " );
		sql.append( "    and ac.ACTOR_CD = ? " );
		sql.append( "    and ac.ACTION_CD = ? " );
		sql.append( "  order by 1,2,3,4,5" );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( party );
		paramList.add( operationCd );
		paramList.add( flowPtn );
		paramList.add( statusCd );
		paramList.add( actorCd );
		paramList.add( actionCd );
		
		CsmSheetActionDao dao = new CsmSheetActionDao( daoLoginNo );
		List<CsmSheetActionDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		return list.size() == 1;
	}
	
	public List<Map<String, String>> getFillValidateMaster( String fillSetCd ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select fm.FILL_ID, fm.FILL_VALIDATE_ID, fv.FORMAT_REGEX, fv.MSG_ID" );
		sql.append( " from CSM_FILL_VALIDATE fv" );
		sql.append( "      inner join CSM_SHEET_FILL fm" );
		sql.append( "        on (fm.FILL_VALIDATE_ID = fv.FILL_VALIDATE_ID" );
		sql.append( "        and fm.FILL_SET_CD = ? )" );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( fillSetCd );
		
		String[] cols = { "FILL_ID", "FILL_VALIDATE_ID", "FORMAT_REGEX", "MSG_ID" };
		
		GeneralMapDao dao = new GeneralMapDao( this.daoLoginNo );
		return dao.select( cols, DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public List<CsmFillCheckDto> getFillCheckMaster( String fillSetCd, String statusCd ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + CsmFillCheckDao.ALLCOLS );
		sql.append( "   from CSM_FILL_CHECK" );
		sql.append( "  where FILL_SET_CD = ? " );
		sql.append( "    and STATUS_CD = ? " );
		sql.append( "  order by SEQ_NO" );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( fillSetCd );
		paramList.add( statusCd );
		
		CsmFillCheckDao dao = new CsmFillCheckDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public void addFillInvalid( String sheetId, String fillId, String msgId ) {
		CstFillInvalidDao dao = new CstFillInvalidDao( daoLoginNo );
		CstFillInvalidDto dto = dao.select( sheetId, fillId, msgId );
		if (dto == null) {
			dto = new CstFillInvalidDto();
			dto.setSheetId( sheetId );
			dto.setFillId( fillId );
			dto.setMsgId( msgId );
			dao.insert( dto );
		}
	}
	
	public void clearFillInvalid( String sheetId ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " delete from CST_FILL_INVALID where SHEET_ID = ? " );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		
		CstFillInvalidDao dao = new CstFillInvalidDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	/**
	 * For CsFillIdCache
	 */
	public List<String> getFillIdList( String fillSetCd ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select FILL_ID as text from CSM_SHEET_FILL where FILL_SET_CD = ? order by FILL_ID " );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( fillSetCd );
		
		OneColumnDao dao = new OneColumnDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public Map<String, Fill> getMaskedFillsForBulk( VCsInfoAttrDto ia, String trustedActorCd ) {
		
//		List<String> fillSet = getFillIdList( ia.getFillSetCd() );
		List<String> fillSet = CsFillIdCache.get( ia.getFillSetCd() );
		
		HashMap<String, String> rawFillMap = CsSheetEventHandler.getAllFillList( daoLoginNo, ia.getSheetId(), "" );
		/* Relatedシートは取扱しない・性能都合・for Bulk */
		// HashMap<String, String> relFillMap = CsSheetEventHandler.getAllRelFillList(
		// daoLoginNo, rawFillMap );
		// rawFillMap.putAll( relFillMap );
		
		String fillSetCd = ia.getFillSetCd();
		String maskCd = ia.getMaskCd();
		String statusCd = ia.getStatusCd();
		String actorCd = trustedActorCd; // After auto selected
		Map<String, String> fillMaskMap = CsFillMaskCache.get( fillSetCd, maskCd, statusCd, actorCd );
		
		Map<String, Fill> maskedFills = new HashMap<String, Fill>();
		for (String fillId : fillSet) {
			String fillContent = rawFillMap.get( fillId );
			String mode = fillMaskMap.get( fillId );
			if (SU.equals( mode, "read" ) || SU.equals( mode, "write" )) {
				Fill f = new Fill( fillId, SU.equals( mode, "write" ) );
				f.content = fillContent;
				maskedFills.put( fillId, f );
			}
		}
		
		return maskedFills;
	}
	
}
