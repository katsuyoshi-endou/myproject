package jp.co.hisas.career.app.sheet.util;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.sheet.dao.CsmSheetFlowDao;
import jp.co.hisas.career.app.sheet.dao.CsmSheetFormGrpDao;
import jp.co.hisas.career.app.sheet.dao.CsmSheetOperationDao;
import jp.co.hisas.career.app.sheet.dao.CsmSheetRemarkDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetActorDao;
import jp.co.hisas.career.app.sheet.dao.VCsmFormCtgMultiTabDao;
import jp.co.hisas.career.app.sheet.dao.VCstSheetActorAndRefDao;
import jp.co.hisas.career.app.sheet.dao.VCstSheetInfoDao;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFlowDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFormGrpDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetOperationDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetRemarkDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetActorDto;
import jp.co.hisas.career.app.sheet.dto.VCsmFormCtgMultiTabDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActorAndRefDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetInfoDto;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.VPersonBelongDao;
import jp.co.hisas.career.util.dao.useful.ValueTextSortDao;
import jp.co.hisas.career.util.dto.VPersonBelongDto;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

public class CsUtil {
	
	public static boolean isBlank( String str ) {
		if ( str == null ) {
			return true;
		} else if ("".equals( str.trim() )) {
			return true;
		}
		return false;
	}
	
	public static String nvl( String str, String strWhenNull ) {
		return (str == null) ? strWhenNull : str ;
	}
	
	public static String bvl( String str, String strWhenBlank ) {
		return (str == null || "".equals( str )) ? strWhenBlank : str ;
	}
	
	public static String ntb( String str ) {
		return nvl( str, "" );
	}
	
	public static String btb( String str ) {
		return bvl( str, "" );
	}
	
	public static String getTimestamp() {
		DateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
		return df.format(new Date(Calendar.getInstance().getTimeInMillis()));
	}
	
	public static String getTimestamp( String format ) {
		DateFormat df = new SimpleDateFormat( format );
		return df.format(new Date(Calendar.getInstance().getTimeInMillis()));
	}
	
	public static String toYYYYMMDD( String timestamp ) {
		// timestamp is 'yyyy/MM/dd HH:mm:ss.SSS'
		if (timestamp == null || timestamp.length() < 10) {
			return "";
		}
		return timestamp.substring( 0, 10 );
	}
	
	public static String getFillContent( HashMap<String, String> fillMap, HashMap<String, String> maskMap, String fillId ) {
		String fc = null;
		if (fillMap == null || maskMap == null || fillId == null) {
			return "";
		}
		if ( maskMap.containsKey( fillId ) ) {
			// read or write -> true
			fc = fillMap.get( fillId );
		}
		return (fc != null) ? fc : "" ;
	}
	
	public static String getNestFillContent( HashMap<String, String> fillMap, String fillId ) {
		String fc = null;
		if (fillMap == null || fillId == null) {
			return "";
		}
		// read or write -> true
		fc = fillMap.get( fillId );
		return (fc != null) ? fc : "" ;
	}
	
	public static String escapeForJS( String str ) {
		if (str != null) {
			// タグは消す
			str = str.replaceAll( "<(/?[\\w]*?)?[^>]*?>", "" );
			// ￥のエスケープ（最初に実施）
			str = str.replaceAll( "\\\\", "\\\\\\\\" );
			// シングルクオーテーションのエスケープ
			str = str.replaceAll( "'", "\\\\'" );
			// ダブルクオーテーションのエスケープ
			str = str.replaceAll( "\"", "\\\\\"" );
			// 改行文字のエスケープ
			str = str.replaceAll( "\r", "" );
			str = str.replaceAll( "\n", "\\\\n" );
		}
		return str;
	}
	
	public static String escapeForHTML( String str ) {
		if (str != null) {
			// タグは消す
			str = str.replaceAll( "<(/?[\\w]*?)?[^>]*?>", "" );
			// 改行文字のエスケープ
			str = str.replaceAll( "\r", "" );
			str = str.replaceAll( "\n", "<br>" );
			str = str.replaceAll( "\\\\n", "<br>" );
			// 実態参照のエスケープ
			str = str.replaceAll( "&", "&amp;" );
		}
		return str;
	}
	
	public static String restoreSrchCond( HashMap<String, String> srchCondMap, String name ) {
		return CsUtil.ntb( CsUtil.escapeForJS( srchCondMap.get( name ) ) );
	}
	
	public static BigDecimal blankToZero( String str ) {
		if (str == null || "".equals(str)) {
			return new BigDecimal( 0 );
		}
		else if (str.matches( "^[0-9]+(\\.[0-9]+)?$" )) {
			return new BigDecimal( str );
		}
		else {
			return new BigDecimal( 0 );
		}
	}
	
	public static BigDecimal floorHalf( BigDecimal num ) {
		BigDecimal result = new BigDecimal( 0 );
		String str = formatNum( num, 1 );
		if (str.matches( "^[0-9]+\\.[0-4]$" )) {
			// 小数点第一位が 0～4 → 0
			result = new BigDecimal( str.replaceAll( "\\.[0-4]$", ".0" ) );
		}
		else if (str.matches( "^[0-9]+\\.[5-9]$" )) {
			// 小数点第一位が 5～9 → 5
			result = new BigDecimal( str.replaceAll( "\\.[5-9]$", ".5" ) );
		}
		return result;
	}
	
	public static String formatNum( BigDecimal num, int keta ) {
		BigDecimal result;
		result = num.divide( new BigDecimal(1), keta, BigDecimal.ROUND_HALF_UP );
		return result.toString();
	}
	
	public static HashMap<String, String> extractMapWithKeyRegex( HashMap<String, String> targetMap, String regex ) {
		HashMap<String, String> result = new HashMap<String, String>();
		Pattern pattern = Pattern.compile( regex );
		Matcher matcher;
		for (Map.Entry<String, String> entry : targetMap.entrySet()) {
			matcher = pattern.matcher( entry.getKey() );
			if (matcher.find()) {
				result.put( entry.getKey(), entry.getValue() );
			}
		}
		return result;
	}
	
	public static String extractWithRegex( String target, String regex ) {
		String result = "";
		target = (target != null) ? target : "";
		Pattern pattern = Pattern.compile( regex );
		Matcher matcher = pattern.matcher( target );
		if (matcher.find()) {
			result = matcher.group(1);
		}
		return result;
	}
	
	public static ArrayList<String> toArrayList( String str ) {
		ArrayList<String> resultList = new ArrayList<String>();
		if (str == null || "".equals( str.trim() )) {
			return resultList;
		}
		String[] strArray = str.split( "," );
		for (int i = 0; i < strArray.length; i++) {
			if ("".equals( strArray[i].trim() )) {
				continue;
			}
			resultList.add( strArray[i].trim() );
		}
		return resultList;
	}
	
	public static String encodeRequestValue(final String val) throws UnsupportedEncodingException {
		return AU.encodeRequestValue( val );
	}
	
	public static String[] encodeRequestValue(final String[] vals) throws UnsupportedEncodingException {
		return AU.encodeRequestValue( vals );
	}
	
	public static String getRequestValue( final HttpServletRequest request, String requestParameter ) {
		return AU.getRequestValue( request, requestParameter );
	}
	
	public static HashMap<String, String> getRequestsWithRegex( final HttpServletRequest request, String regex ) {
		HashMap<String, String> fillReqMap = new HashMap<String, String>();
		
		Enumeration<?> e = request.getParameterNames();
		while (e.hasMoreElements()) {
			String key = (String)e.nextElement();
			if ( !key.matches( regex + ".*" ) ) {
				continue;
			}
			String val = getRequestValue( request, key );
			// regex 該当文字列を取り除いて返す
			key = key.replaceAll( regex, "" );
			fillReqMap.put( key, val );
		}
		
		return fillReqMap;
	}
	
	public static HashMap<String, String> getFillRequestsForMulti( final HttpServletRequest request, String sheetId ) {
		HashMap<String, String> fillReqMap = new HashMap<String, String>();
		
		Enumeration<?> e = request.getParameterNames();
		while (e.hasMoreElements()) {
			String key = (String)e.nextElement();
			if ( !key.matches( "^" + sheetId + "--Fill--.*" ) ) {
				continue;
			}
			String val = getRequestValue( request, key );
			// Fill-- を取り除いて返す
			key = key.replaceAll( "^" + sheetId + "--Fill--", "" );
			fillReqMap.put( key, val );
		}
		
		return fillReqMap;
	}
	
	public static String addPrefixOnDaoAllCols( String prefix, String daoAllCols ) {
		return SU.addPrefixOnDaoAllCols( prefix, daoAllCols );
	}
	
	public static String addPrefixOnDaoAllColsNonAS( String prefix, String daoAllCols ) {
		return SU.addPrefixOnDaoAllColsNonAS( prefix, daoAllCols );
	}
	
	public static String setSheetIdOnSession( HttpServletRequest request, HttpSession session ) {
		String sheetId = request.getParameter( "sheetId" );
		if (CsUtil.isBlank( sheetId )) {
			sheetId = AU.getSessionAttr( session, CsSessionKey.CS_SHEET_ID );
			if (CsUtil.isBlank( sheetId )) {
				session.setAttribute( AppSessionKey.RESULT_MSG_ERROR, "シートIDがnullです。" );
			}
		}
		session.setAttribute( CsSessionKey.CS_SHEET_ID, sheetId );
		return sheetId;
	}
	
	public static boolean srchCondAvailable( HashMap<String, String> srchCondMap, String key ) {
		if (srchCondMap == null) {
			return false;
		}
		if (!srchCondMap.containsKey( key )) {
			return false;
		}
		String val = srchCondMap.get( key );
		if (val == null || "".equals( val )) {
			return false;
		}
		return true;
	}
	
	public static CsmSheetOperationDto getCsmOperation( String loginNo, String companyCd, String operationCd ) {
		CsmSheetOperationDao dao = new CsmSheetOperationDao( loginNo );
		PZZ040_SQLUtility.createCachedConnection( loginNo );
		CsmSheetOperationDto dto = dao.select( companyCd, operationCd );
		PZZ040_SQLUtility.removeCachedConnection();
		return (dto != null) ? dto : new CsmSheetOperationDto();
	}
	
	public static CsmSheetFormGrpDto getCsmFormGrp( String loginNo, String companyCd, String operationCd, String formGrpCd ) {
		CsmSheetFormGrpDao dao = new CsmSheetFormGrpDao( loginNo );
		PZZ040_SQLUtility.createCachedConnection( loginNo );
		CsmSheetFormGrpDto dto = dao.select( companyCd, operationCd, formGrpCd );
		PZZ040_SQLUtility.removeCachedConnection();
		return (dto != null) ? dto : new CsmSheetFormGrpDto();
	}
	
	public static String getOneFormGrpCd( String loginNo, String party, String operationCd ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + CsmSheetFormGrpDao.ALLCOLS );
		sql.append( "   from CSM_SHEET_FORM_GRP " );
		sql.append( "  where PARTY = ? " );
		sql.append( "    and OPERATION_CD = ? " );
		sql.append( "   order by FORM_GRP_CD " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( party );
		paramList.add( operationCd );
		
		CsmSheetFormGrpDao dao = new CsmSheetFormGrpDao( loginNo );
		List<CsmSheetFormGrpDto> dtoList = null;
		PZZ040_SQLUtility.createCachedConnection( loginNo );
		dtoList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		PZZ040_SQLUtility.removeCachedConnection();
		CsmSheetFormGrpDto dto = (dtoList.size() != 0) ? dtoList.get( 0 ) : new CsmSheetFormGrpDto();
		return (dto != null) ? dto.getFormGrpCd() : "";
	}
	
	public static CsmSheetFlowDto getCsmFlow( String loginNo, String flowCd, String statusCd ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + CsmSheetFlowDao.ALLCOLS );
		sql.append( "   from CSM_SHEET_FLOW " );
		sql.append( "  where FLOW_CD = ? " );
		sql.append( "    and STATUS_CD = ? " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( flowCd );
		paramList.add( statusCd );
		
		CsmSheetFlowDao dao = new CsmSheetFlowDao( loginNo );
		CsmSheetFlowDto dto = null;
		
		PZZ040_SQLUtility.createCachedConnection( loginNo );
		List<CsmSheetFlowDto> dtoList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		PZZ040_SQLUtility.removeCachedConnection();
		if (dtoList.size() == 1) {
			dto = dtoList.get( 0 );
		} else {
			dto = new CsmSheetFlowDto();
		}
		
		return dto;
	}
	
	public static List<VCstSheetActorAndRefDto> getActorInfo( String loginNo, String sheetId, String actorCd ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + VCstSheetActorAndRefDao.ALLCOLS );
		sql.append( "   from V_CST_SHEET_ACTOR_AND_REF " );
		sql.append( "  where SHEET_ID = ? " );
		sql.append( "    and ACT_OR_REF = 'ACT' " );
		sql.append( "    and ACTOR_CD = ? " );
		sql.append( "  order by ACTOR_SORT " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		paramList.add( actorCd );
		
		VCstSheetActorAndRefDao dao = new VCstSheetActorAndRefDao( loginNo );
		List<VCstSheetActorAndRefDto> dtoList = null;
		PZZ040_SQLUtility.createCachedConnection( loginNo );
		dtoList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		PZZ040_SQLUtility.removeCachedConnection();
		
		return dtoList;
	}
	
	public static List<VCstSheetActorAndRefDto> getActorAndRefererAll( String loginNo, String sheetId ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + VCstSheetActorAndRefDao.ALLCOLS );
		sql.append( "   from V_CST_SHEET_ACTOR_AND_REF " );
		sql.append( "  where SHEET_ID = ? " );
		sql.append( "  order by ACTOR_SORT " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		
		VCstSheetActorAndRefDao dao = new VCstSheetActorAndRefDao( loginNo );
		List<VCstSheetActorAndRefDto> dtoList = null;
		PZZ040_SQLUtility.createCachedConnection( loginNo );
		dtoList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		PZZ040_SQLUtility.removeCachedConnection();
		
		return dtoList;
	}
	
	public static VPersonBelongDto getPersonBelong( String loginNo, String personId ) {
		PZZ040_SQLUtility.createCachedConnection( loginNo );
		VPersonBelongDao dao = new VPersonBelongDao( loginNo );
		VPersonBelongDto dto = dao.select( personId );
		PZZ040_SQLUtility.removeCachedConnection();
		return dto;
	}
	
	public static CsmSheetRemarkDto getRemarkByPoint( String loginNo, String rangeCd, int point ) {
		CsmSheetRemarkDao dao = new CsmSheetRemarkDao( loginNo );
		List<CsmSheetRemarkDto> list;
		CsmSheetRemarkDto result = null;
		try {
			PZZ040_SQLUtility.createCachedConnection( loginNo );
			list = dao.selectRemarkByPoint( rangeCd, point, point );
			if (list.size() > 0) {
				result = list.get( 0 );
			}
		} finally {
			PZZ040_SQLUtility.removeCachedConnection();
		}
		return result;
	}
	
	public static List<ValueTextSortDto> getBindedSheetDeptList( String loginNo, String party, String operationCd, String formGrpCd, String personId ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select distinct CIAU.DEPT_CD as value, CIAU.DEPT_NM as text, DEPT.LPAD_SORT as sort ");
		sql.append( "   from V_CS_INFO_ATTR CIAU " );
		sql.append( "        left outer join DEPT on (DEPT.DEPT_CD = CIAU.DEPT_CD) " );
		sql.append( "  where CIAU.PARTY = ? and CIAU.OPERATION_CD = ? and CIAU.FORM_GRP_CD = ? and CIAU.OWN_GUID <> ? " );
		sql.append( "    and exists ( " );
		sql.append( "      select ACT.SHEET_ID from V_CST_SHEET_ACTOR_AND_REF ACT " );
		sql.append( "       where ACT.SHEET_ID = CIAU.SHEET_ID and ACT.GUID = ? " );
		sql.append( "    ) " );
		sql.append( "  order by sort " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( party );
		paramList.add( operationCd );
		paramList.add( formGrpCd );
		paramList.add( personId );
		paramList.add( personId );
		
		ValueTextSortDao dao = new ValueTextSortDao( loginNo );
		List<ValueTextSortDto> resultList;
		PZZ040_SQLUtility.createCachedConnection( loginNo );
		resultList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		PZZ040_SQLUtility.removeCachedConnection();
		
		return resultList;
	}
	
	/**
	 * シートIDをもとに[V_CST_SHEET_INFO]からシート情報を取得する。
	 * @param loginNo (for DAO access)
	 */
	public static VCstSheetInfoDto getSheetInfoBySheetId( String loginNo, String sheetId ) {
		PZZ040_SQLUtility.createCachedConnection( loginNo );
		VCstSheetInfoDao dao = new VCstSheetInfoDao( loginNo );
		VCstSheetInfoDto dto = dao.select( sheetId );
		PZZ040_SQLUtility.removeCachedConnection();
		return dto;
	}
	
	/**
	 * 渡されたシートをログインユーザはどのアクターコードで参照するかを決定する
	 */
	public static String autoDetectActorCdForMulti( String operatorGuid, String sheetId ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + VCstSheetActorAndRefDao.ALLCOLS );
		sql.append( "   from V_CST_SHEET_ACTOR_AND_REF " );
		sql.append( "  where SHEET_ID = ? " );
		sql.append( "    and GUID = ? " );
		sql.append( "  order by ACTOR_SORT desc " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		paramList.add( operatorGuid );
		
		VCstSheetActorAndRefDao dao = new VCstSheetActorAndRefDao( operatorGuid );
		List<VCstSheetActorAndRefDto> resultList;
		PZZ040_SQLUtility.createCachedConnection( operatorGuid );
		resultList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		PZZ040_SQLUtility.removeCachedConnection();
		
		return resultList.get( 0 ).getActorCd();
	}
	
	public static HashMap<String, CstSheetActorDto> getBindedSheetMap( String loginNo, String party, String operationCd, String formGrpCd, String actorCd, String personId ) {
		
		HashMap<String, CstSheetActorDto> result = new HashMap<String, CstSheetActorDto>();
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select A.SHEET_ID as sheetId, A.ACTOR_CD as actorCd, A.GUID as guid, null as autoFlg " );
		sql.append( "   from V_CST_SHEET_ACTOR_AND_REF A " );
		sql.append( "        inner join V_CST_SHEET_INFO V " );
		sql.append( "          on (V.SHEET_ID = A.SHEET_ID and V.PARTY = ? and V.OPERATION_CD = ? and V.FORM_GRP_CD = ?) " );
		sql.append( " where A.ACTOR_CD = ? and A.GUID = ? " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( party );
		paramList.add( operationCd );
		paramList.add( formGrpCd );
		paramList.add( actorCd );
		paramList.add( personId );
		
		CstSheetActorDao dao = new CstSheetActorDao( loginNo );
		List<CstSheetActorDto> bindedList;
		PZZ040_SQLUtility.createCachedConnection( loginNo );
		bindedList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		PZZ040_SQLUtility.removeCachedConnection();
		if (bindedList != null) {
			for (CstSheetActorDto dto : bindedList) {
				result.put( dto.getSheetId(), dto );
			}
		}
		
		return result;
	}
	
	public static String getMultiTab( String loginNo, String formGrpCd, String formCtgCd, String statusCd ) {
		VCsmFormCtgMultiTabDao dao = new VCsmFormCtgMultiTabDao( loginNo );
		PZZ040_SQLUtility.createCachedConnection( loginNo );
		VCsmFormCtgMultiTabDto dto = dao.select( formGrpCd, formCtgCd, statusCd );
		PZZ040_SQLUtility.removeCachedConnection();
		String multiTab = (dto != null) ? dto.getMultiTab() : "";
		return multiTab;
	}
	
	/**
	 * Listがnullのときnewして返す。NullPointer予防。
	 */
	public static <T> List<T> nvList( List<T> list ) {
		if (list == null) {
			list = new ArrayList<T>();
		}
		return list;
	}
	
}
