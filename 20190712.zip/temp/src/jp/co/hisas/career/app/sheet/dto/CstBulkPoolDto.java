/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CstBulkPoolDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sessionId;
    private String sheetId;
    private String actorCd;
    private Integer excKey;
    private String updGuid;
    private Integer wkIdx;

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getSheetId() {
        return sheetId;
    }

    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    public String getActorCd() {
        return actorCd;
    }

    public void setActorCd(String actorCd) {
        this.actorCd = actorCd;
    }

    public Integer getExcKey() {
        return excKey;
    }

    public void setExcKey(Integer excKey) {
        this.excKey = excKey;
    }

    public String getUpdGuid() {
        return updGuid;
    }

    public void setUpdGuid(String updGuid) {
        this.updGuid = updGuid;
    }

    public Integer getWkIdx() {
        return wkIdx;
    }

    public void setWkIdx(Integer wkIdx) {
        this.wkIdx = wkIdx;
    }

}

