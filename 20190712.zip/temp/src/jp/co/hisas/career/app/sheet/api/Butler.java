package jp.co.hisas.career.app.sheet.api;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Tray;

public abstract class Butler {
	
	public abstract String takeGET( Tray tray ) throws CareerException;
	
	public abstract String takePOST( Tray tray ) throws CareerException;
	
	public abstract String takePUT( Tray tray ) throws CareerException;
	
	public abstract String takeDELETE( Tray tray ) throws CareerException;
	
}
