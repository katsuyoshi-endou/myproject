package jp.co.hisas.career.app.sheet.event;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dto.ZzCsmJkskGyomubDto;
import jp.co.hisas.career.ejb.AbstractEventResult;

public class JkskGyomuBunruiEventResult extends AbstractEventResult {

	// 業務分類リスト
	private List<ZzCsmJkskGyomubDto> gyomubList;

	// 「職種」リスト
	private List<String> shokushuList;
	// 「職種2」マップ
	private Map<String, List<String>> shokushu2Map;
	// 「分類」マップ
	private Map<String, List<String>> bunruiMap;

	public List<ZzCsmJkskGyomubDto> getGyomubList() {
		return gyomubList;
	}

	public void setGyomubList( List<ZzCsmJkskGyomubDto> list ) {
		this.gyomubList = list;
	}

	public List<String> getShokushuList() {
		return shokushuList;
	}

	public void setShokushuList( List<String> shokushuList ) {
		this.shokushuList = shokushuList;
	}

	public Map<String, List<String>> getShokushu2Map() {
		return shokushu2Map;
	}

	public void setShokushu2Map( Map<String, List<String>> shokushu2Map ) {
		this.shokushu2Map = shokushu2Map;
	}

	public Map<String, List<String>> getBunruiMap() {
		return bunruiMap;
	}

	public void setBunruiMap( Map<String, List<String>> bunruiMap ) {
		this.bunruiMap = bunruiMap;
	}
}
