/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class ZzCsmJkskSikakuDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sikakuCd;
    private String sikakuNm;
    private String gensCompCd;

    public String getSikakuCd() {
        return sikakuCd;
    }

    public void setSikakuCd(String sikakuCd) {
        this.sikakuCd = sikakuCd;
    }

    public String getSikakuNm() {
        return sikakuNm;
    }

    public void setSikakuNm(String sikakuNm) {
        this.sikakuNm = sikakuNm;
    }

    public String getGensCompCd() {
        return gensCompCd;
    }

    public void setGensCompCd(String gensCompCd) {
        this.gensCompCd = gensCompCd;
    }

}

