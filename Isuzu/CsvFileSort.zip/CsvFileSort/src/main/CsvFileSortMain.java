package main;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import main.bean.JvKenshuRenkeiInputBean;
import main.util.JvKenshuJukoRekiComparator;
import main.util.JvKenshuRenkeiUploadResult;
import main.util.JvKenshuRenkeiUtil;

public class CsvFileSortMain {

	public static void main(String[] args) {
		final String filePath = "D:\\output\\kenshu_reki.csv";

		FileInputStream fis = null;
		BufferedReader br = null;

		long start = System.currentTimeMillis();

		try {
			fis = new FileInputStream(filePath);

			JvKenshuRenkeiUploadResult result = new JvKenshuRenkeiUploadResult();

			ArrayList<JvKenshuRenkeiInputBean> beanList = new ArrayList<JvKenshuRenkeiInputBean>();

			br = new BufferedReader( new InputStreamReader(fis, Charset.forName("MS932")));
			int line = 1;
			String lineStr;
			while((lineStr = br.readLine()) != null) {
				if (line == 1) {
					// ヘッダー項目数のチェック
					if (!checkCsvHeaderCount( lineStr, 11)) {
						result.setUploadResult( false );
						result.setUploadMessage( "項目数が一致しません。" );
						break;
					}
				} else {
					List<String> lineData = JvKenshuRenkeiUtil.convStringListFromCSV(lineStr);

					if (!checkNeedValue(lineData)) {
						result.setUploadResult( false );

						result.setUploadMessage( "必須項目が未入力です。" );
						break;
					} else {
						JvKenshuRenkeiInputBean bean = getInputValueBean(lineData);
						beanList.add(bean);
					}
				}
				line++;
			}

			Collections.sort( beanList, new JvKenshuJukoRekiComparator());

			long end = System.currentTimeMillis();

			System.out.println("処理時間：" + (end - start) + "ms");

			System.exit(0);
		} catch(Exception e) {
			System.out.println(e.getMessage());
			System.exit(-1);
		} finally {
			try {
				br.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
				System.exit(-1);
			}
		}
	}

	private static boolean checkCsvHeaderCount(String chkStr, int maxColCount) {

		boolean ret = true;

		if ( chkStr == null || chkStr.length() == 0 ) {
			ret = true;
		} else {
			String[] header = chkStr.split( ",", 0 );
			if (header.length != maxColCount) {
				ret = false;
			}
		}
		return ret;
	}

	private static boolean checkNeedValue(List<String> list) {

		boolean ret = true;

		String cmpaCd = list.get(0);
		String stfNo = list.get(1);

		if ((cmpaCd == null || cmpaCd.length() == 0) || (stfNo == null || stfNo.length() == 0)) {
			ret = false;
		}
		return ret;
	}

	private static JvKenshuRenkeiInputBean getInputValueBean(List<String> val) {

		JvKenshuRenkeiInputBean bean = new JvKenshuRenkeiInputBean();

		// 会社コード
		bean.setCmpaCd( val.get( 0 ));
		// 従業員番号
		bean.setStfNo( val.get( 1 ));

		// カラム01-09
		bean.setColumn01( val.size() < 3  ? "" : val.get( 2 ));
		bean.setColumn02( val.size() < 4  ? "" : val.get( 3 ));
		bean.setColumn03( val.size() < 5  ? "" : val.get( 4 ));
		bean.setColumn04( val.size() < 6  ? "" : val.get( 5 ));
		bean.setColumn05( val.size() < 7  ? "" : val.get( 6 ));
		bean.setColumn06( val.size() < 8  ? "" : val.get( 7 ));
		bean.setColumn07( val.size() < 9  ? "" : val.get( 8 ));
		bean.setColumn08( val.size() < 10 ? "" : val.get( 9 ));
		bean.setColumn09( val.size() < 11 ? "" : val.get( 10 ));

		return bean;
	}
}
