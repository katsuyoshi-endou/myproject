package main.util;

import java.util.List;

import main.bean.JvKenshuRenkeiInputBean;

public class JvKenshuRenkeiUploadResult {

	private boolean uploadResult;

	private String uploadMessage;

	private List<JvKenshuRenkeiInputBean> kensRenkeiDataList;

	public JvKenshuRenkeiUploadResult() {
		uploadResult = true;
	}

	public boolean isUploadResult() {
		return uploadResult;
	}

	public void setUploadResult( boolean uploadResult ) {
		this.uploadResult = uploadResult;
	}

	public String getUploadMessage() {
		return uploadMessage;
	}

	public void setUploadMessage( String uploadMessage ) {
		this.uploadMessage = uploadMessage;
	}

	public List<JvKenshuRenkeiInputBean> getKensRenkeiDataList() {
		return kensRenkeiDataList;
	}

	public void setKensRenkeiDataList( List<JvKenshuRenkeiInputBean> kensRenkeiDataList ) {
		this.kensRenkeiDataList = kensRenkeiDataList;
	}
}
