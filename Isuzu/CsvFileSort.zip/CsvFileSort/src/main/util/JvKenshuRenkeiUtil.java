package main.util;

import java.util.ArrayList;
import java.util.List;

public class JvKenshuRenkeiUtil {

	public static List<String> convStringListFromCSV(String line) {
		char chr;
		StringBuilder sb = new StringBuilder();
		List<String> data = new ArrayList<String>();

		boolean doubleQuoteFlg = false;

		for (int i = 0; i < line.length(); i++) {
			chr = line.charAt( i );
			if (chr == ',' && !doubleQuoteFlg) {
				data.add(sb.toString());
				sb.delete( 0, sb.length());
			} else if (chr == ',' && doubleQuoteFlg) {
				sb.append( chr );
			} else if (chr == '\"') {
				doubleQuoteFlg = !doubleQuoteFlg;
			} else if (i == line.length() - 1) {
				data.add(sb.toString());
				sb.delete( 0, sb.length());
			} else {
				sb.append( chr );
			}

			if (i == line.length() - 1 && !doubleQuoteFlg) {
				data.add(sb.toString());
			}
		}
		return data;
	}
}
