package main.util;

import java.util.Comparator;

import main.bean.JvKenshuRenkeiInputBean;

public class JvKenshuJukoRekiComparator implements Comparator<JvKenshuRenkeiInputBean> {

	public int compare( JvKenshuRenkeiInputBean bean1, JvKenshuRenkeiInputBean bean2 ) {
		int nRet = bean1.getCmpaCd().compareTo( bean2.getCmpaCd());
		if (nRet == 0) {
			nRet = bean1.getStfNo().compareTo( bean2.getStfNo());
			if (nRet == 0) {
				nRet = bean2.getColumn03().compareTo( bean1.getColumn03());
				if (nRet == 0) {
					nRet = bean2.getColumn04().compareTo(bean1.getColumn04());
					if (nRet == 0) {
						return bean1.getColumn01().compareTo(bean2.getColumn01());
					} else {
						return nRet;
					}
				} else {
					return nRet;
				}
			} else {
				return nRet;
			}
		} else {
			return nRet;
		}
	}
}
