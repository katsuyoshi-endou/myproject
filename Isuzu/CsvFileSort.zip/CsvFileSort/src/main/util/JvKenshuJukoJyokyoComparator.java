package main.util;

import java.util.Comparator;

import main.bean.JvKenshuRenkeiInputBean;

public class JvKenshuJukoJyokyoComparator implements Comparator<JvKenshuRenkeiInputBean> {

	public int compare( JvKenshuRenkeiInputBean bean1, JvKenshuRenkeiInputBean bean2 ) {
		int nRet = bean1.getCmpaCd().compareTo( bean2.getCmpaCd());
		if (nRet == 0) {
			return  bean1.getStfNo().compareTo( bean2.getStfNo());
		} else {
			return nRet;
		}
	}

}
