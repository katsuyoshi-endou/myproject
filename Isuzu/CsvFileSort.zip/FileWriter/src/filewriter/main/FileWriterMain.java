package filewriter.main;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

public class FileWriterMain {

	public static void main(String[] args) {
		final int LOOP_CNT = 250000;
//		final int LOOP_CNT = 30;
		final String OUTPUT_FILE = "D:\\output\\kenshu_reki.csv";

		FileOutputStream fos = null;
		OutputStreamWriter osw = null;

		long start = System.currentTimeMillis();

		try {
			fos = new FileOutputStream(OUTPUT_FILE);
			osw = new OutputStreamWriter(fos, "SJIS");

			osw.write("会社コード,従業員番号,研修コード,研修名,受講開始年月日,受講終了年月日,受講結果,評価項目,研修項目,研修スコア,研修スコア（本人用）");
			osw.write("\r\n");

			for (int i = 0; i < LOOP_CNT; i++) {
				// 適当な従業員番号を生成
				int nRnd = (int)Math.rint(Math.random() * 999999);
				String stfNo = String.format("%06d", nRnd);

				String text = "\"ISZJ\",\"" + stfNo + "\",BC10024090\",\"新任課長ＧＬ研修（本研修）\",\"2017/03/15\",\"2017/03/31\",\"受講済(修了)\",\"-\",\"新任課長ＧＬに期待すること/部下育成/仕事の管理\",\"５５／１００点\",\"\"";

				osw.write(text);
				osw.write("\r\n");
			}
			long end = System.currentTimeMillis();

			System.out.println("処理時間：" + (end - start) + "ms");

		} catch(FileNotFoundException e) {
			System.out.println("File not found!");
			System.exit(-1);
		} catch(UnsupportedEncodingException e) {
			System.out.println("File encoding not supported!");
			System.exit(-1);
		} catch(IOException e) {
			System.out.println("I/O Error. detail : " + e.getMessage());
		} finally {
			try {
				if (osw != null) {
					osw.close();
				}

				if(fos != null) {
					fos.close();
				}

			} catch(IOException e) {
				System.out.println(e.getMessage());
				System.exit(-1);
			}
		}
	}

}
