package sample;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class QuartzSampleMain {
	
	public static void main( String[] args ) throws Exception {
		
		int interval = 5;
		
		SchedulerFactory schedFact = new StdSchedulerFactory();
		Scheduler sched = schedFact.getScheduler();
		sched.start();
		
		JobDetail job = JobBuilder.newJob( SampleJob.class )
				.withIdentity(  "testJob","g1" )
				.build();

		Trigger trigger = TriggerBuilder
				.newTrigger()
				.withIdentity( "testTrigger", "g1" )
				.startNow()
				.withSchedule(
						SimpleScheduleBuilder.simpleSchedule()
											.withIntervalInSeconds( interval )
											.repeatForever())
				.build();
		
		sched.scheduleJob( job, trigger );
	}
	
}
