window.document.onkeydown=PressKeyCheck;
window.document.onmousewheel=PressKeyCheck; 
window.document.onmousedown = shiftKeyCheck;

function PressKeyCheck(e){
var srcElement = window.event.srcElement;
// Ctrl + A
  if(window.event.ctrlKey==true && event.keyCode == 65) {
	return false;
  }

// Ctrl + D
  if(window.event.ctrlKey==true && event.keyCode == 68) {
	return false;
  }

// Ctrl + H
  if(window.event.ctrlKey==true && event.keyCode == 72) {
	return false;
  }

// Ctrl + I
  if(window.event.ctrlKey==true && event.keyCode == 73) {
	return false;
  }

// Ctrl + L
  if(window.event.ctrlKey==true && event.keyCode == 76) {
	return false;
  }

// Ctrl + N
  if(window.event.ctrlKey==true && event.keyCode == 78) {
	return false;
  }

// Ctrl + O
  if(window.event.ctrlKey==true && event.keyCode == 79) {
	event.keyCode=8;
	return false;
  }

// Ctrl + P
  if(window.event.ctrlKey==true && event.keyCode == 80) {
	event.keyCode=8;
	return false;
  }

// Ctrl + R
  if(window.event.ctrlKey==true && event.keyCode == 82) {
	return false;
  }

// Ctrl + W
  if(window.event.ctrlKey==true && event.keyCode == 87) {
	return false;
  }

// Ctrl + X
  if(window.event.ctrlKey==true && event.keyCode == 88) {
	return false;
  }

// Ctrl + F5
  if(window.event.ctrlKey==true && event.keyCode == 116) {
	return false;
  }

// Ctrl + Tab
  if(window.event.ctrlKey==true && event.keyCode == 9) {
	return false;
  }

//Ctrl + Shift + Tab
  if(window.event.ctrlKey==true && window.event.shiftKey==true && event.keyCode == 9) {
	return false;
  }

//Ctrl + Shift + R
  if(window.event.ctrlKey==true && window.event.shiftKey==true && event.keyCode == 82) {
	return false;
  }

// Alt + D
  if(window.event.altKey==true && event.keyCode == 68) {
	event.keyCode=39;
	return false;
  }

// Alt + ←
  if(window.event.altKey==true && event.keyCode == 37) {
	return false;
  }

// Alt + →
  if(window.event.altKey==true && event.keyCode == 39) {
	return false;
  }

// Alt + SPACE
  if(window.event.altKey==true && event.keyCode == 32) {
	event.keyCode=39;
	return false;
  }

// Alt + F4
  if(window.event.altKey==true && event.keyCode == 115) {
	event.keyCode=39;
	return false ;
  }

// Alt + HOME
  if(window.event.altKey==true && event.keyCode == 36) {
	event.keyCode=39;
	return false ;
  }

// Alt + Enter
  if(window.event.altKey==true && event.keyCode == 13) {
	event.keyCode=39;
	return false ;
  }

// F2
  if( event.keyCode == 113 ) {
	event.keyCode=8;
	return false ; 
  }

// F3
  if( event.keyCode == 114 ) {
	event.keyCode=8;
	return false ; 
  }

// F4
  if( event.keyCode == 115 ) {
	event.keyCode=8;
	return false ; 
  }

// F5
  if( event.keyCode == 116 ) {
	event.keyCode=8;
	return false ; 
  }

// F11
  if( event.keyCode == 122 ) {
	event.keyCode=8;
	return false ; 
  }

// BackSpace
  if( event.keyCode == 8 ) {

        //テキストボックス、パスワードボックスは許す 
        var elementTag = srcElement.tagName;
        if (elementTag == 'INPUT') {
            var elementType = srcElement.type;
            if ((elementType == 'text' || elementType == 'password' || elementType == "file") && srcElement.readOnly == false) {
                return true;
            }
        } else if (elementTag == 'TEXTAREA' && srcElement.readOnly == false) {
            return true;
        }

	return false ; 
  }
// ESC
  if( event.keyCode == 27 ) {
	return false ; 
  }
  
  //Enter
  if( event.keyCode == 13 ) {
        //テキストエリアは不許可 
        if (srcElement.tagName == 'TEXTAREA' && srcElement.className != 'AllowEnter' && srcElement.readOnly == false) {
            return false;
        }
	return true;
   }
       
//Shift
  if(window.event.shiftKey == true){
          //テキストエリアは許す 
          var elementTag = srcElement.tagName;
          if (elementTag == 'TEXTAREA' && srcElement.readOnly == false) {
              return true;
          } else if (elementTag == 'INPUT') {
              var elementType = srcElement.type;
              if ((elementType == 'text' || elementType == 'password' || elementType == 'file') && srcElement.readOnly == false) {
                  return true;
              }
          }
          return false;     
  }
}
 function shiftKeyCheck(){
    if(window.event.shiftKey == true && (event.button == 1 || event.button == 2)){
        alert(param_JS_023);
        return false;
    }
}
