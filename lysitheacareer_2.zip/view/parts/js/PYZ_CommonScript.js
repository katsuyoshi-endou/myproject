var App = {
	isJunctioned: function() {
		var root = document.location.pathname.match(/^(\/[\w]+)?\/career/)[0];
		return root !== "/career";
	},
	getJunctionRoot: function() {
		/*  /psroll/career  OR  /psroll_test/career  OR  /career  */
		var root = document.location.pathname.match(/^(\/[\w]+)?\/career/)[0];
		return root;
	},
	getJunctionedUrl: function(theUrl) {
		var root = document.location.pathname.match(/^(\/[\w]+)?\/career/)[0];
		return theUrl.replace("/career", root);
	},
	submit: function(formObj) {
		/* Auto Junction */
		var root = document.location.pathname.match(/^(\/[\w]+)?\/career/)[0];
		var newUrl = formObj.action.replace("/career", root);
		formObj.action = newUrl;
		formObj.submit();
	}
};

$(function() {
	
	initializeJunctionedView();
	
});

function initializeJunctionedView() {
	if (!App.isJunctioned()) {
		return false;
	}
	try {
		for (i=0; i<top.frames.length; i++) {
			fixButtonImagePath(top.frames[i].document.body);
		}
	} catch(e) {
	}
}

function fixButtonImagePath(framebody) {
	var jRoot = App.getJunctionRoot();
	$('input[style]', framebody).each(function(){
		var name = $(this).attr("name");
		var oldStyle = $(this).attr('style');
		var newStyle = oldStyle.replace('url(/career', "url("+jRoot);
		$(this).attr('style', newStyle);
	});
}

function changeColor(src){
	if(src.tagName=="TD"){
		src.style.background="99ccff";
		src.style.color="#bbddff";
	}
}

function reverseColor(src){
	if(src.tagName=="TD"){
		src.style.background="#bbddff";
		src.style.color="#bbddff";
	}
}

function clickColor(src){
	if(src.tagName=="TD"){
		src.style.background="#868686";
		src.style.color="#161666";
	}
}

/* 子ウィンドウのオブジェクト */
var child_window_object;

/* 子ウィンドウの座標 */
var subwindowX;
var subwindowY;

/* 子ウィンドウにサブミットするフォームオブジェクト */
var targetFormObject;

/* ターゲットとなるウィンドウ名 */
var targetWindowName;

function backMenu(url){
    if ( url!="" ) {
        document.F100.action = url;
    } else {
// DEL Career0402 2007/02/09 SHIMURA メインメニューのID変更 ->
//	    document.F100.action = "/career/view/base/menu/VYY_MenuMain.jsp";
// DEL Career0402 <-
// ADD Career0402 2007/02/09 SHIMURA メインメニューのID変更 ->
		document.F100.action = "/career/view/base/menu/VYY_MenuSiteMain.jsp";
// ADD Career0402 <-
	}
	document.F100.target = "_top";
	document.F100.method = "post";
// CHG 2017.03 Panasonic Junction
//  document.F100.submit();
    App.submit(document.F100);
// CHG 2017.03 Panasonic Junction
}

//ログアウト処理に遷移する
function logout(){
    document.F100.action = "/career/servlet/LogoutServlet";
    document.F100.target = "_top";
    document.F100.method = "post";
// CHG 2017.03 Panasonic Junction
//  document.F100.submit();
    App.submit(document.F100);
// CHG 2017.03 Panasonic Junction
}

/* ターゲットとなるウィンドウ名を指定する */
function setTargetWindowName ( windowName ) {
	targetWindowName = windowName;
}

//指定されたURLに遷移する。ターゲットはメインフレーム
function next(url){
	/* ターゲットとなるウィンドウ名の指定 */
	if ( targetWindowName == null ) {
		targetWindowName = "_top";
	}
	document.F001.action = url;
	document.F001.target = targetWindowName;
	document.F001.method = "post";
// CHG 2017.03 Panasonic Junction
//	document.F001.submit();
	App.submit(document.F001);
// CHG 2017.03 Panasonic Junction
}


function back(url){
	document.F001.action = url;
	document.F001.target = "_top";
	document.F001.method = "post";
// CHG 2017.03 Panasonic Junction
//	document.F001.submit();
	App.submit(document.F001);
// CHG 2017.03 Panasonic Junction
}

/* 表示するサブウィンドウ位置をセットする */
function setSubWindowPosition( x, y ) {
	subwindowX = x;
	subwindowY = y;
}

/* サブウィンドウにフォームオブジェクトを指定する */
function setSubWindowFormObject ( formObj ) {
	targetFormObject = formObj;
}

/* サブウィンドウを生成し、呼び出しもとのF001フォームオブジェクトをすべて非活性にする */
function SubWindow(url,width,height){
	var Style="scrollbars=no,resizable=yes,width=" + width + ",height=" + height;
	var subWindowObj = SubWindowOpen( url, Style );

	return subWindowObj;
}

/*
 * サブウィンドウを生成し、呼び出しもとのF001フォームオブジェクトをすべて非活性にする
 * スクロール付き
 */
function SubWindowScroll(url,width,height){
	var Style="scrollbars=yes,resizable=yes,width=" + width + ",height=" + height;
	var subWindowObj = SubWindowOpen( url, Style );

	return subWindowObj;
}

/* SubWindow , SubWindowScroll　から呼ばれる */
function SubWindowOpen( url, Style ) {
	var my_window_name = window.name;	//現在のウィンドウ名を取得
    if (self != top) {
        my_window_name = window.top.name;
    }
	
	var child_window_name ="";

	/* 子ウィンドウ名作成 */
	if ( my_window_name.indexOf("hcdb") != -1 ) {
		child_window_name = "sub_window1";
		
		/* 子ウィンドウの位置を計算 */
		if ( ( subwindowX == null ) || ( subwindowY == null ) ) {
			subwindowX = 50;
			subwindowY = 50;
		}
	} else {
		//最後の数字を取得
		var index = Number( my_window_name.substring( my_window_name.length-1, my_window_name.length ) );
		
		//数字を1加算
		index = index + Number(1);
		
		//ウィンドウ名の最後の数字を付与
		child_window_name = my_window_name.substring(0, my_window_name.length-1 ) + index;
		
		/* 子ウィンドウの位置を計算 */
		if ( ( subwindowX == null ) || ( subwindowY == null ) ) {
			subwindowX = eval(50 * index);
			subwindowY = eval(50 * index);
		}
	}
	
	/* 子ウィンドウの位置をセット */
	Style = Style.concat( ",top=" + subwindowY + ",left=" + subwindowX );
	
	/* 子ウィンドウを開く */
	var cUrl = App.getJunctionedUrl("/career/view/base/headerfooter/VYY_Dummy.jsp");
	child_window_object = window.open(cUrl, child_window_name,Style);
   
    /* 子ウィンドウ監視開始 */
	window.onfocus = ReverseButton;
	
	/* サブミットするフォームオブジェクトの指定 */
	if ( targetFormObject == null ) {
		targetFormObject = document.F001;
	}
    targetFormObject.action = url;
	targetFormObject.target = child_window_name;
	targetFormObject.method = "post";
// CHG 2017.03 Panasonic Junction
//	targetFormObject.submit();
	App.submit(targetFormObject);
// CHG 2017.03 Panasonic Junction
	
	/* iFrameの存在チェック */
    var lengthCheck = top.frames.length;
    for( var i = 0; i < top.frames.length; i++ ) {
        if (  top.frames[i].name.indexOf("ifram") != -1 ) {
            lengthCheck-- ;
        }
    }
	
	/* フォームオブジェクト無効化 */
	if ( lengthCheck != 0 ) {
		for ( var i = 0; i < top.frames.length; i++ ) {
			disabledAll( top.frames[i].F001, true );
			disabledAll( top.frames[i].F002, true );
			disabledAll( top.frames[i].F003, true );
			disabledAll( top.frames[i].form1, true );
			disabledAll( top.frames[i].list, true );
			disabledAll( top.frames[i].kengen, true );
			disabledAll( top.frames[i].personalAdd, true);
			disabledAll( top.frames[i].personal, true);
			disabledAll( top.frames[i].sikaku1, true);
			disabledAll( top.frames[i].sikakucode1, true);
			disabledAll( top.frames[i].sikaku3, true);
			disabledAll( top.frames[i].sikakucode3, true);
			disabledAll( top.frames[i].sikakucode4, true);
			disabledAll( top.frames[i].hyousyou1, true);
			disabledAll( top.frames[i].jouhou, true);
			disabledAll( top.frames[i].ikkatutuika, true);
			disabledAll( top.frames[i].ikkatukousin, true);
			disabledAll( top.frames[i].ikkatudownload, true);
			disabledAll( top.frames[i].osirasejyouho, true);
			disabledAll( top.frames[i].kisyoikkatu, true);
		}
	} else {
		disabledAll( top.document.F001, true );
		disabledAll( top.document.F002, true );
		disabledAll( top.document.F003, true );
		disabledAll( top.document.form1, true );
		disabledAll( top.document.list, true );
	    disabledAll( top.document.kengen, true );
		disabledAll( top.document.personalAdd, true);
		disabledAll( top.document.personal, true);
		disabledAll( top.document.sikaku1, true);
		disabledAll( top.document.sikakucode1, true);
		disabledAll( top.document.sikaku3, true);
		disabledAll( top.document.sikakucode3, true);
		disabledAll( top.document.sikakucode4, true);
		disabledAll( top.document.hyousyou1, true);
		disabledAll( top.document.jouhou, true);
		disabledAll( top.document.ikkatutuika, true);
		disabledAll( top.document.ikkatukousin, true);
		disabledAll( top.document.ikkatudownload, true);
		disabledAll( top.document.osirasejyouho, true);
		disabledAll( top.document.kisyoikkatu, true);
	}

	return child_window_object;
}

/* 子ウィンドウが閉じられたら、F001フォームオブジェクトを有効にする。 */
function ReverseButton() {
	if( win_closed(child_window_object) ) {
		/* iFrameの存在チェック */
        var lengthCheck = top.frames.length;
        for( var i = 0; i < top.frames.length; i++ ) {
            if (  top.frames[i].name.indexOf("ifram") != -1 ) {
                lengthCheck-- ;
            }
        }
        
		/* フォームオブジェクト無効化 */
		if ( lengthCheck != 0 ) {
			for ( var i = 0; i < top.frames.length; i++ ) {
				disabledAll( top.frames[i].F001, false );
				disabledAll( top.frames[i].F002, false );
				disabledAll( top.frames[i].F003, false );
				disabledAll( top.frames[i].form1, false );
				disabledAll( top.frames[i].list, false );
				disabledAll( top.frames[i].kengen, false );
			    disabledAll( top.frames[i].personalAdd, false);
			    disabledAll( top.frames[i].personal, false);
			    disabledAll( top.frames[i].sikaku1, false);
			    disabledAll( top.frames[i].sikakucode1, false);
			    disabledAll( top.frames[i].sikaku3, false);
			    disabledAll( top.frames[i].sikakucode3, false);
			    disabledAll( top.frames[i].sikakucode4, false);
			    disabledAll( top.frames[i].hyousyou1, false);
			    disabledAll( top.frames[i].jouhou, false);
				disabledAll( top.frames[i].ikkatutuika, false);
				disabledAll( top.frames[i].ikkatukousin, false);
				disabledAll( top.frames[i].ikkatudownload, false);
				disabledAll( top.frames[i].osirasejyouho, false);
				disabledAll( top.frames[i].kisyoikkatu, false);
			}
		} else {
			disabledAll( top.document.F001, false );
			disabledAll( top.document.F002, false );
			disabledAll( top.document.F003, false );
			disabledAll( top.document.form1, false );
			disabledAll( top.document.list, false );
			disabledAll( top.document.kengen, false );
		    disabledAll( top.document.personalAdd, false);
		    disabledAll( top.document.personal, false);
		    disabledAll( top.document.sikaku1, false);
		    disabledAll( top.document.sikakucode1, false);
		    disabledAll( top.document.sikaku3, false);
		    disabledAll( top.document.sikakucode3, false);
		    disabledAll( top.document.sikakucode4, false);
		    disabledAll( top.document.hyousyou1, false);
		    disabledAll( top.document.jouhou, false);
		    disabledAll( top.document.ikkatutuika, false);
		    disabledAll( top.document.ikkatukousin, false);
		    disabledAll( top.document.ikkatudownload, false);
		    disabledAll( top.document.osirasejyouho, false);
		    disabledAll( top.document.kisyoikkatu, false);
		}

        OnCloseChildWindow();
	}
}

/* 子ウィンドウが閉じられた場合に呼び出される関数（個別ページのオーバーロード用） */
function OnCloseChildWindow() {
}

/* 与えられた文字列のバイト数を返す。 */
function byte(s) {
    var r = 0;
    var lengths = s.length;
    for (var i = 0; i < lengths; i++) {
        var c = s.charCodeAt(i);
        if ( (c >= 0x0 && c < 0x81) || (c == 0xf8f0) || (c >= 0xff61 && c < 0xffa0) || (c >= 0xf8f1 && c < 0xf8f4)) {
            r += 1;
        } else {
            r += 2;
        }
    }
    return r;
}

/* 止文字のチェックを行う */
function htmlEncode(checkKomoku , checkString){
    if ( checkString.indexOf( ">" , 0 )  != -1 ) {
        alert(getParameter(param_JS_019, [checkKomoku]));
        return false;
    }
    if ( checkString.indexOf( "<" , 0 )  != -1) {
        alert(getParameter(param_JS_020, [checkKomoku]));
        
        return false;
    }
    if ( checkString.indexOf( "\"" , 0 )  != -1) {
        alert(getParameter(param_JS_021, [checkKomoku]));
        return false;
    }
    if ( checkString.indexOf( "&" , 0 )  != -1) {
        alert(getParameter(param_JS_022, [checkKomoku]));
        return false;   
    } else {
        return true;
    }
}

/* フレーム未対応メッセージ画面に遷移する */
function noframes(){
	location.href="/career/view/base/error/VYY_NoFrames.jsp";
}

/*
 * ウィンドウ名のチェックを行う。
 * hcdb、sub_windowが含まれない場合、エラー画面に遷移する。
 */
function windowNameCheck(){ 
    if ( parent.location.pathname.indexOf( "VYY_Error.jsp" ) == -1 ) {
    	var window_name = window.name;
        if (self != top) {
        	window_name = window.top.name;
    	}
		if ( ( window_name.indexOf("hcdb") == -1 ) 
          && ( window_name.indexOf("sub_window") == -1 ) ) {
            parent.location.href = "/career/view/base/error/VYY_Error.jsp";
        }
    }
}

/* ファイル名から、拡張子部分を取得 */
function getExtention( filename ) {
	var ext=filename.split('.');
	if (ext.length > 0 ) {
		return ext[ext.length-1].toLowerCase();
	}
	return "";
}

/*
 * 文字列と、配列をチェックし、同一のものがあれば１
 * なければ０を返す。
 */
function checkArrays( ext, ext_h) {
	for ( var i = 0; i < ext_h.length; i++ ) {
		if ( ext == ext_h[i] ) {
			return 1;
		}
	}
	return 0;
}

/* 指定されたフォームオブジェクトをすべて活性/非活性にする */
function disabledAll( objForm, flg ) {
	if (objForm != null ) {
		if (flg == "true") {
			objForm.blur();
		}

		var lengths = objForm.length;
		for(i=0;i<lengths;i++){
			if (objForm[i].type.toLowerCase() != "hidden") {
				if (flg == "true") {
            		objForm[i].blur();
            	}
			    objForm[i].disabled = flg;
			}
	    }
	}
}
function hikokai(){
  Style="scrollbars=yes,resizable=yes, width=500, height=300, top=230, left=250";
  new_win = window.open("/career/view/personal/base/error/Hikokai.jsp","sub_window",Style);//CHG#BPX-0301J-0477
}

// INS#P-PPE41-001-001-S(C)
function setMessage( objMsg, msg ) {
    if ( msg == "" || msg == "null" ) {
        objMsg.style.display = "none";
    } else {
        objMsg.style.display = "block";
        var posX = 40;
        var posY = 200;
        if ( event.pageX != undefined ) {
            posX = event.pageX;
            posY = event.pageY;
        } else if ( event.clientX != undefined ) {
            posX = document.body.scrollLeft + event.clientX;
            posY = document.body.scrollTop  + event.clientY;
        }
        objMsg.style.left = posX + 10;
        objMsg.style.top  = posY + 20;
    }
    objMsg.innerHTML = msg;
}
// INS#P-PPE41-001-001-E(C)
// INS#P-A300C6-024-002-S
/**
 * ステータスバーにURLを表示しない
 */
function noURL(){
    window.status = "";
    return true;
}
document.onmouseover = noURL;
document.onmouseout = noURL;

// INS#P-A300C6-024-002-E
// 2005/10/24_LYCE_A_BINHDQ START
/* 子画面を表示している状態で、親画面が遷移している場合、処理を中断させる。 */
function openerCheck(){
    if ( window.opener.parent.hcdb_down == undefined ) {
        alert( "メインウィンドウが他画面に遷移しているため、更新処理を中断します。キャンセルボタンをクリックし、当画面を閉じてください。" );
        return false;
    } else {
        return true;
    }
}
//INS#P-0202A-0001-001-E
// 2005/10/24_LYCE_A_BINHDQ END
function win_closed(winVar) {
    var ua = navigator.userAgent
    if( !!winVar ) {
        if( ( ua.indexOf('Gecko')!=-1 || ua.indexOf('MSIE 4')!=-1 ) && ua.indexOf('Win')!=-1 ) {
            return winVar.closed
        } else {
            return typeof winVar.document  != 'object';
        }
    } else {
        return true;
    }
}
//引数のフォームのelementの状態を再現するためのJavascriptを生成する
//text, select, radio, checkboxのみ対応
//hiddenを追加したい場合は別functionにしてください
function createFormControlScript(formObj) {
	if (formObj == null) {
		return "";
	}
	var formName = formObj.name;
	var elems = document.forms[formName].elements;
	var scriptStr = '';
	var radioNameArray = new Array();
	if (elems != null) {
		for (var i = 0; i < elems.length; i++) {
			var ele = elems[i];
			if (ele.type.toLowerCase() == 'text') { //テキストボックス
				if (ele.disabled) {
					scriptStr += 'document.' + formName + '.' + ele.name + '.disabled = true;\n';
				} else {
					scriptStr += 'document.' + formName + '.' + ele.name + '.disabled = false;\n';
					scriptStr += 'document.' + formName + '.' + ele.name + '.value = \'' + ele.value + '\';\n';
				}
			} else if (ele.type.toLowerCase() == 'select-one') { //プルダウン
				var point = 0;
				for (; point < ele.options.length; point++) {
					if (ele.options[point].selected) {
						break;
					}
				}
				if (ele.disabled) {
					scriptStr += 'document.' + formName + '.' + ele.name + '.disabled = true;\n';
				} else {
					scriptStr += 'document.' + formName + '.' + ele.name + '.disabled = false;\n';
					scriptStr += 'document.' + formName + '.' + ele.name + '.options[' + point + '].selected = true;\n';
				}
			} else if (ele.type.toLowerCase() == 'radio') {//ラジオボタン
				var tmpName = 'document.' + formName + '.' + ele.name;
				if ((tmp = scriptStr.indexOf(tmpName)) == -1) { //まだ同名要素が追加されていない場合のみ処理する
					if (ele.disabled) {
						scriptStr += 'document.' + formName + '.' + ele.name + '.disabled = true;\n';
					} else if (ele.checked) {
						scriptStr += 'document.' + formName + '.' + ele.name + '.disabled = false;\n';
						var arrayName = ele.name + 'Array';
						scriptStr += 'var ' + arrayName + ' = document.getElementsByName(\'' + ele.name + '\');\n';
						scriptStr += 'for (var count = 0; count < ' + arrayName + '.length; count++) { \n';
						scriptStr += '	var radioElement = ' + arrayName + '[count];\n';
						scriptStr += '	if (radioElement.value == ' + ele.value + ') {\n';
						scriptStr += '		radioElement.checked = true;\n';
						scriptStr += '	}\n';
						scriptStr += '}\n';
					}
				}
			} else if (ele.type.toLowerCase() == 'checkbox') { //チェックボックス
				if (ele.checked) {
					if (ele.disabled) {
						scriptStr += 'document.' + formName + '.' + ele.name + '.disabled = true;\n';
					} else {
						scriptStr += 'document.' + formName + '.' + ele.name + '.disabled = false;\n';
						scriptStr += 'document.' + formName + '.' + ele.name + '.checked = true;\n';
					}
				}
			}
		}
	}
	return scriptStr;
}

//ADD 2018/06/06 COMTURE 研修パラメータ化対応 START
//パラメータ―内の文字列置換を行う。
function getParameter(parameter, paramArray){
	
	for ( var i = 0 ; i < paramArray.length ; i++ ){
		parameter = parameter.replace(/\{\d\}/, paramArray[i]);
	}
	return parameter;
}
//ADD 2018/06/06 COMTURE 研修パラメータ化対応 END
