/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.learning.result;

/** �捞�Ɏg�p����S�Ẵ��b�Z�[�WID */
public final class ImportErrorID {
	private ImportErrorID() {
	}

	public static final String PARAM_ERROR = "BJK-0021-E";

	public static final String UPDATE_ERROR = "BJK-0022-E";

	public static final String DELETE_ERROR = "BJK-0023-E";

	public static final String IMPORT_LOG_NOT_FOUND = "BJK-1001-E";

	public static final String NO_IMPORT_DATA = "BJK-1002-E";

	public static final String RESULT_LOG_PATH_INVALID = "BJK-1011-E";

	public static final String UNRGST_LOG_PATH_INVALID = "BJK-1021-E";

	public static final String MODE_INVALID = "BJK-1031-E";

	public static final String UNRGST_DATA_IMP_FLG_INVALID = "BJK-1041-E";

	public static final String HAS_HEADER_FLG_INVALID = "BJK-1051-E";

	public static final String IMP_COL_NUM_INVALID = "BJK-1061-E";

	public static final String IMP_SIMEI_NO_COL_INVALID = "BJK-1071-E";

	public static final String IMP_KAMOKU_CODE_COL_INVALID = "BJK-1081-E";

	public static final String IMP_CLASS_CODE_COL_INVALID = "BJK-1091-E";

	public static final String IMP_SYURYO_HANTEI_COL_INVALID = "BJK-1101-E";

	public static final String IMP_SYUSSEKI_NISSU_COL_INVALID = "BJK-1111-E";

	public static final String IMP_TENSU_COL_INVALID = "BJK-1121-E";

	public static final String IMP_SEISEKI_COL_INVALID = "BJK-1131-E";

	public static final String IMP_SEISEKIBIKOU_COL_INVALID = "BJK-1141-E";

	public static final String IMP_COL_DUPLICATE_SETTING = "BJK-1151-E";

	public static final String LABEL_MISYU_INVALID = "BJK-1161-E";

	public static final String LABEL_NINTEI_INVALID = "BJK-1171-E";

	public static final String LABEL_SYURYO_INVALID = "BJK-1181-E";

	public static final String LABEL_DUPLICATE_SETTING = "BJK-1191-E";

	public static final String IMP_COL_NUM_UNMATCHED = "BJK-2001-E";

	public static final String PERSON_NOT_FOUND = "BJK-2011-E";

	public static final String KAMOKU_NOT_FOUND = "BJK-2021-E";

	public static final String CLASS_NOT_FOUND = "BJK-2031-E";

	public static final String SYURYO_HANTEI_INVALID = "BJK-2041-E";

	public static final String SYUSSEKI_NISSU_INVALID = "BJK-2051-E";

	public static final String SYUSSEKI_NISSU_SIZE_INVALID = "BJK-2052-E";

	public static final String TENSU_INVALID = "BJK-2061-E";

	public static final String TENSU_SIZE_INVALID = "BJK-2062-E";

	public static final String SEISEKI_INVALID = "BJK-2071-E";

	public static final String SEISEKI_SIZE_INVALID = "BJK-2072-E";

	public static final String SEISEKIBIKOU_INVALID = "BJK-2081-E";

	public static final String SEISEKIBIKOU_SIZE_INVALID = "BJK-2082-E";

	public static final String IMP_COL_NUM_UNMATCHED_AT_DEL = "BJK-3001-E";

	public static final String L51_RECORD_NOT_FOUND = "BJK-3011-E";

	public static final String UNEXPECTED_ERROR = "BJK-9999-E";

	public static final String L15_RECORD_NOT_FOUND_UNRGST_LOG = "BJK-5001-W";

	public static final String L15_STATUS_INVALID = "BJK-5011-W";

	public static final String UNRGST_DATA_EXISTS = "BJK-0011-W";

	public static final String FINISHED = "BJK-0001-I";

	public static final String FINISHED_AT_DELETE = "BJK-0002-I";

	public static final String FINISHED_EXISTS_WARNING = "BJK-0011-W";
}
