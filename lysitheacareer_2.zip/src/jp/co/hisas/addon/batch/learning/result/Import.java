/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.learning.result;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.sql.Connection;
import java.util.Date;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

import jp.co.hisas.addon.batch.util.BatchUtility;
import jp.co.hisas.addon.batch.util.ConsoleUtility;
import jp.co.hisas.addon.batch.util.FileUtility;
import jp.co.hisas.addon.batch.util.LoggerFactory;
import jp.co.hisas.addon.batch.util.TextWriter;
import jp.co.hisas.addon.batch.util.transaction.BatchTransactionManager;
import jp.co.hisas.addon.batch.util.transaction.Transaction;
import jp.co.hisas.career.util.log.Log;

import org.apache.log4j.Logger;

/**
 * ��u���ʎ捞�o�b�`���� ��u���ʎ捞�o�b�`�����͑S�Ă��̃N���X���o�R���čs���B ��v�Ȓ萔���������̃N���X��Static�t�B�[���h�ɒ�`����B
 */
public class Import {
	/** ���O�t�@�C�����̃^�C���X�^���v */
	private String fileTimeStamp;

	/** L51�e�[�u���̃Z�b�V�����ԍ��̃^�C���X�^���v */
	private String seqTimeStamp;

	/** �V�X�e�����t */
	private String sysdate;

	/** �V�X�e������ */
	private String systime;

	/** �捞���ʃ��O�o�͗p��Writer */
	private TextWriter resultLogWriter;

	/** ���o�^���O�o�͗p��Writer */
	private TextWriter unregisterdLogWriter;

	/** �`�F�b�N�ς݂̎捞�p�p�����[�^ */
	private ImportParameter param;

	/** CSV��DB�ɕۑ�����ۂ̃V�[�P���X */
	private long sessionSeq;

	/** ��荞��CSV�̃G���R�[�h �ʏ��MS932 */
	public static final String IMPORT_CHARSET_NAME = "MS932";

	/** ���[�U�[���ݒ肷�郂�[�h �X�V���[�h */
	public static final String MODE_UPDATE = "UPDATE";

	/** ���[�U�[���ݒ肷�郂�[�h �폜���[�h */
	public static final String MODE_DELETE = "DELETE";

	/** ���[�U�[���ݒ肷��t���O TRUE��\�� */
	public static final String FLG_TRUE = "1";

	/** ���[�U�[���ݒ肷��t���O FALSE��\�� */
	public static final String FLG_FALSE = "0";

	// �e�t�H�[�}�b�g
	public static final String FILE_TIMESTAMP_FORMAT = "yyyyMMddHHmmss";

	public static final String SEQ_TIMESTAMP_FORMAT = "yyyyMMddHHmmss";

	public static final String SYSDATE_FORMAT = "yyyyMMdd";

	public static final String SYSTIME_FORMAT = "HHmmss";

	public static final String SEQ_FORMAT = "{0}{1,number,0000}";

	public static final String RESULT_LOG_FILE_NAME = "jukoKekkaTorikomi_{0}.log";

	public static final String UNREGISTERD_LOG_FILE_NAME = "mitouroku_{0}.log";

	// �V�X�e���v���p�e�B�̃L�[
	public static final String KEY_INPUT_FILE_PATH = "INPUT_FILE_PATH";

	public static final String KEY_LOG_FILE_PATH1 = "LOG_FILE_PATH1";

	public static final String KEY_LOG_FILE_PATH2 = "LOG_FILE_PATH2";

	public static final String KEY_TOUROKU_MODE = "TOUROKU_MODE";

	public static final String KEY_MITOUROKU_TORIKOMI_FLG = "MITOUROKU_TORIKOMI_FLG";

	public static final String KEY_HEADER_FLG = "HEADER_FLG";

	public static final String KEY_INPUT_COLUMN_LENGTH = "INPUT_COLUMN_LENGTH";

	public static final String KEY_SIMEI_NO_NO = "SIMEI_NO_NO";

	public static final String KEY_KAMOKU_CODE_NO = "KAMOKU_CODE_NO";

	public static final String KEY_CLASS_CODE_NO = "CLASS_CODE_NO";

	public static final String KEY_SYURYO_HANTEI_NO = "SYURYO_HANTEI_NO";

	public static final String KEY_SYUSSEKI_NISSU_NO = "SYUSSEKI_NISSU_NO";

	public static final String KEY_TENSU_NO = "TENSU_NO";

	public static final String KEY_SEISEKI_NO = "SEISEKI_NO";

	public static final String KEY_SEISEKI_BIKOU_NO = "SEISEKI_BIKOU_NO";

	public static final String KEY_MISYU_STRING = "MISYU_STRING";

	public static final String KEY_SYURYO_STRING = "SYURYO_STRING";

	public static final String KEY_NINTEI_STRING = "NINTEI_STRING";

	// �e�����萔
	public static final int SYUSSEKI_NISSU_LENGTH = 5;

	public static final int TENSU_LENGTH = 4;

	public static final int SEISEKI_LENGTH = 10;

	public static final int SEISEKIBIKOU_LENGTH = 500;

	public static final int MISYU_FLG = 0;

	public static final int SYURYO_FLG = 1;

	public static final int NINTEI_FLG = 2;

	public static final Pattern INVALID_CHAR_PATTERN = Pattern.compile(".*[><\"&].*");

	public static final String CSV_HEADER_RESULT_LOG = "���b�Z�[�WID,�s��,�ȖڃR�[�h,�N���X�R�[�h,����No,�G���[���b�Z�[�W";

	public static final String CSV_HEADER_UNREGISTERD_LOG = "���b�Z�[�WID,�s��,�ȖڃR�[�h,�N���X�R�[�h,����No,���b�Z�[�W";

	private final Logger logger = Logger.getLogger(this.getClass());

	/** �o�b�`�����̃G���g���|�C���g */
	public static void main(final String[] args) {
		new Import().execute();
	}

	/** ������ */
	public Import() {
		try {
			final InputStream is = Import.class.getResourceAsStream("/jp/co/hisas/addon/batch/learning/result/consoleLogger.properties");

			final Properties p = new Properties();
			p.load(is);

			LoggerFactory.getInstance().initialize("jp.co.hisas.addon.batch.learning.result", p);
		} catch (final Exception e) {
			System.out.println(ImportErrorLog.getInstance(ImportErrorID.UNEXPECTED_ERROR).toString());
		}
	}

	/** �捞���� */
	public void execute() {
		try {
			final Map property = ConsoleUtility.getInstance().getSystemPropertiesMap();
			final ImportConfigManager icm = ImportConfigManager.getInstance();
			final String resultLogPath = (String) property.get(Import.KEY_LOG_FILE_PATH1);

			if (!FileUtility.getInstance().isExists(resultLogPath)) {
				this.logger.error(ImportErrorLog.getInstance(ImportErrorID.RESULT_LOG_PATH_INVALID).toString());
				return;
			}
			final Date date = new Date();
			this.fileTimeStamp = icm.getTimeStamp(date);
			this.seqTimeStamp = icm.getSeqTimeStamp(date);
			this.sysdate = icm.getSysDate(date);
			this.systime = icm.getSysTime(date);

			this.resultLogWriter = new TextWriter(icm.getResultLogPath(resultLogPath, this.fileTimeStamp), Import.IMPORT_CHARSET_NAME);
			this.resultLogWriter.writeln(Import.CSV_HEADER_RESULT_LOG);

			if (!icm.checkImportParameter(this, property)) {
				return;
			}

			this.unregisterdLogWriter = new TextWriter(icm.getUnregisterdLogPath((String) property.get(Import.KEY_LOG_FILE_PATH2), this.fileTimeStamp), Import.IMPORT_CHARSET_NAME);
			this.unregisterdLogWriter.writeln(Import.CSV_HEADER_UNREGISTERD_LOG);

			this.param = icm.createImportParameter(property);

			final BatchTransactionManager btm = BatchTransactionManager.getInstance();
			this.sessionSeq = ((Long) btm.execTransaction(new Transaction() {
				private Connection connection;

				public Serializable execute() {
					return new Long(BatchUtility.getInstance().getSessionSequence(this.connection));
				}

				public void setConnection(final Connection connection) {
					this.connection = connection;
				}

				public Connection getConnection() {
					return this.connection;
				}
			})).longValue();

			final ImportTransaction impTrans = new ImportTransaction();
			impTrans.setParam(this.param);
			impTrans.setCharsetName(Import.IMPORT_CHARSET_NAME);
			impTrans.setSessionSeq(this.sessionSeq);
			impTrans.setResultLogWriter(this.resultLogWriter);
			impTrans.setUnregisterdLogWriter(this.unregisterdLogWriter);
			impTrans.setSeqTimeStamp(this.seqTimeStamp);
			impTrans.setSysdate(this.sysdate);
			impTrans.setSystime(this.systime);
			final Serializable result = btm.execTransaction(impTrans);

		} catch (final Exception e) {
			Log.error(ImportErrorID.UNEXPECTED_ERROR, e);
		} finally {
			this.dispose();
		}
	}

	/** �㏈�� */
	public void dispose() {
		try {
			if (this.resultLogWriter != null) {
				this.resultLogWriter.dispose();
			}
		} catch (final IOException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				if (this.unregisterdLogWriter != null) {
					this.unregisterdLogWriter.dispose();
				}
			} catch (final IOException e) {
				throw new RuntimeException(e);
			}
		}
	}

	// Setter & Getter
	public String getFileTimeStamp() {
		return this.fileTimeStamp;
	}

	public TextWriter getResultLogWriter() {
		return this.resultLogWriter;
	}

	public void setFileTimeStamp(final String string) {
		this.fileTimeStamp = string;
	}

	public void setResultLogWriter(final TextWriter writer) {
		this.resultLogWriter = writer;
	}

	public ImportParameter getParam() {
		return this.param;
	}

	public void setParam(final ImportParameter parameter) {
		this.param = parameter;
	}

}
