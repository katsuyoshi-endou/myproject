/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.base.blob.ejb;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.rmi.RemoteException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ020_MakeSQLUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �T�v: DB�A�N�Z�X���s���A�e�R�[�h�̌����A�X�V�A�폜���s���A�X�e�[�g���XSessionBean�B �g�p���@: �����[�g�C���^�t�F�[�X����āA�N���C�A���gBean����Ăяo���B
 * 
 * </PRE>
 */
public class PYF_BlobDBAccessOracleEJBBean implements SessionBean {
	/** SessionContext�I�u�W�F�N�g */
	private SessionContext my_ssc = null;

	/**
	 * BLOB�^���C���T�[�g����
	 * @param login_no
	 * @param table
	 * @param column
	 * @param save
	 * @param blob
	 * @param primary_key
	 * @param primary_value
	 * @return �ǉ����R�[�h��
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public int InsertBLOB(final String login_no, final String table, final String[] column, final String[] save, final byte[] blob, final String[] primary_key, final String[] primary_value)
			throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		/* BLOB���܂ރ��R�[�h�̃C���T�[�g���s���B */
		final int count = this.InsertBlob(login_no, table, column, save, blob, primary_key, primary_value, "INSERT");

		Log.method(login_no, "OUT", "");

		return count;
	}

	/**
	 * BLOB�^���A�b�v�f�[�g����
	 * @param login_no
	 * @param table
	 * @param column
	 * @param save
	 * @param blob
	 * @param primary_key
	 * @param primary_value
	 * @return �X�V���R�[�h��
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public int UpdateBLOB(final String login_no, final String table, final String[] column, final String[] save, final byte[] blob, final String[] primary_key, final String[] primary_value)
			throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		/* BLOB���܂ރ��R�[�h�̃A�b�v�f�[�g���s���B */
		final int count = this.InsertBlob(login_no, table, column, save, blob, primary_key, primary_value, "UPDATE");

		Log.method(login_no, "OUT", "");

		return count;
	}

	/**
	 * BLOB�^���A�b�v�f�[�g����(PYF_ByteDataBean[]�ɂ���f�[�^�����ׂăA�b�v�f�[�g����)
	 * @param login_no
	 * @param table
	 * @param column
	 * @param save
	 * @param byteDataBeans
	 * @param primary_key
	 * @param primary_value
	 * @return �X�V���R�[�h��
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public int UpdateBLOB(final String login_no, final String table, final String[] column, final String[] save, final PYF_ByteDataBean[] byteDataBeans, final String[] primary_key,
			final String[] primary_value) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		int ret = 0;

		/* BLOB���܂ރ��R�[�h�̃A�b�v�f�[�g���s���B */
		for (int i = 0; i < byteDataBeans.length; i++) {
			final byte[] blob = byteDataBeans[i].getData();
			final String[] primaryValue = { primary_value[i] };

			final int count = this.InsertBlob(login_no, table, column, save, blob, primary_key, primaryValue, "UPDATE");
			ret += count;
		}
		Log.method(login_no, "OUT", "");

		return ret;
	}

	/**
	 * BLOB���Z���N�g����
	 * @param login_no
	 * @param table
	 * @param column
	 * @param load
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public byte[] SelectBLOB(final String login_no, final String table, final String blob_colum, final String[] primary_key, final String[] primary_value) throws SQLException, NamingException,
			Exception {
		Log.method(login_no, "IN", "");

		byte[] blob = null;

		blob = this.SelectBlob(login_no, table, blob_colum, primary_key, primary_value);

		Log.method(login_no, "IN", "");

		return blob;
	}

	/**
	 * BLOB���Z���N�g����(�����e�i���X�p)
	 * @param login_no
	 * @param table
	 * @param column
	 * @param load
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public byte[] SelectBLOB1(final String login_no, final String table, final String blob_colum, final String[] primary_key, final String[] primary_value) throws SQLException, NamingException {
		Log.method(login_no, "IN", "");

		byte[] blob = null;

		blob = this.SelectBlob1(login_no, table, blob_colum, primary_key, primary_value);

		Log.method(login_no, "IN", "");

		return blob;
	}

	/**
	 * OracleJDBC�p BLOB�C���T�[�g
	 * @param login_no
	 * @param table
	 * @param column
	 * @param save
	 * @param blob
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	private int InsertBlob(final String login_no, final String table, final String[] column, final String[] save, final byte[] blob, final String[] primary_key, final String[] primary_value,
			final String TYPE) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		/* �Ɩ����� */
		Connection dbConn = null;
		PreparedStatement stmt = null;
		final ResultSet rs = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			String sql = null;

			if (TYPE.equals("INSERT")) {
				sql = PZZ020_MakeSQLUtil.makeInsertSQL(login_no, table, column, save);
			} else if (TYPE.equals("UPDATE")) {
				sql = PZZ020_MakeSQLUtil.makeUpdateSQL(login_no, table, column, save, primary_key, primary_value);
			}

			sql = sql.replaceAll("BLOB_DATA", "?");

			/* �f�o�b�O���O���o�� */
			Log.debug(sql);

			stmt = dbConn.prepareStatement(sql);

			if (blob == null) {
				stmt.setNull(1, java.sql.Types.BLOB);
			} else {
				stmt.setBytes(1, blob);
			}

			final int num = stmt.executeUpdate();

			Log.method(login_no, "OUT", "");

			return num;
		} catch (final SQLException sqle) {
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * BLOB���Z���N�g����
	 * @param login_no
	 * @param table
	 * @param column
	 * @param load
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	private byte[] SelectBlob(final String login_no, final String table, final String blob_colum, final String[] primary_key, final String[] primary_value) throws SQLException, NamingException,
			Exception {
		Log.method(login_no, "IN", "");

		/* �Ɩ����� */
		Connection dbConn = null;
		Statement ostmt = null;
		ResultSet ors = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(login_no);
			ostmt = dbConn.createStatement();

			final String sql = this.makeSelectSQL(login_no, table, blob_colum, primary_key, primary_value);

			/* �f�o�b�O���O���o�� */
			Log.debug(sql);

			ors = ostmt.executeQuery(sql);

			byte[] result_byte = null;

			if (ors.next()) {
				final Blob myblob = ors.getBlob(blob_colum);

				if (myblob != null) {
					/* �擾�f�[�^��ByteArrayOutputStream�ɂ��� */
					final ByteArrayOutputStream baos = new ByteArrayOutputStream();
					final byte[] buffer = new byte[4096];
					final InputStream is = myblob.getBinaryStream();
					int size;

					while ((size = is.read(buffer)) != -1) {
						baos.write(buffer, 0, size);
					}

					baos.close();

					result_byte = baos.toByteArray();
				}
			}

			Log.method(login_no, "OUT", "");

			return result_byte;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, ostmt, ors);
		}
	}

	/**
	 * BLOB���Z���N�g����(�����e�i���X�p)
	 * @param login_no
	 * @param table
	 * @param column
	 * @param load
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws IOException
	 * @throws Exception
	 */
	private byte[] SelectBlob1(final String login_no, final String table, final String blob_colum, final String[] primary_key, final String[] primary_value) throws SQLException, NamingException {
		Log.method(login_no, "IN", "");

		/* �Ɩ����� */
		Connection dbConn = null;
		Statement ostmt = null;
		ResultSet ors = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(login_no);
			ostmt = dbConn.createStatement();

			final String sql = this.makeSelectSQL1(login_no, table, blob_colum, primary_key, primary_value);

			/* �f�o�b�O���O���o�� */
			Log.debug(sql);

			ors = ostmt.executeQuery(sql);

			byte[] result_byte = null;

			if (ors.next()) {
				final Blob myblob = ors.getBlob(blob_colum);

				if (myblob != null) {
					/* �擾�f�[�^��ByteArrayOutputStream�ɂ��� */
					final ByteArrayOutputStream baos = new ByteArrayOutputStream();
					final byte[] buffer = new byte[4096];
					final InputStream is = myblob.getBinaryStream();
					int size;

					while ((size = is.read(buffer)) != -1) {
						baos.write(buffer, 0, size);
					}

					baos.close();

					result_byte = baos.toByteArray();
				}
			}

			Log.method(login_no, "OUT", "");

			return result_byte;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final IOException ne) {
			Log.error(login_no, ne);
			throw new EJBException(ne);
		} finally {
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, ostmt, ors);
		}
	}

	/**
	 * �����œn���ꂽ�e�[�u�����A�J�����A�f�[�^�����ɃC���T�[�g�����쐬����
	 * @param simei_no �����ԍ�
	 * @param save ���͒l
	 * @exception SQLException SQL�G���[�����������ꍇ
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 */
	private String makeSelectSQL(final String login_no, final String table, final String blob_colum, final String[] primary_key, final String[] primary_value) throws Exception {
		Log.method(login_no, "IN", "");

		try {
			String sql = "SELECT " + blob_colum + " FROM " + table + " WHERE ";

			if (PZZ020_MakeSQLUtil.getColumnTypeCheck(primary_key[0]).equals("1")) {
				sql = sql + primary_key[0] + " = " + primary_value[0];
			} else {
				sql = sql + primary_key[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(primary_value[0]) + "'";
			}

			for (int i = 1; i < primary_key.length; i++) {
				if (PZZ020_MakeSQLUtil.getColumnTypeCheck(primary_key[i]).equals("1")) {
					sql = sql + " AND " + primary_key[i] + " = " + primary_value[i];
				} else {
					sql = sql + " AND " + primary_key[i] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(primary_value[i]) + "'";
				}
			}
			Log.method(login_no, "OUT", "");

			return sql;
		} catch (final Exception e) {
			Log.error(login_no, "HJE-0017", e);
			throw e;
		}
	}

	/**
	 * �����œn���ꂽ�e�[�u�����A�J�����A�f�[�^�����ɃC���T�[�g�����쐬����(�����e�i���X�p)
	 * @param simei_no �����ԍ�
	 * @param save ���͒l
	 * @exception SQLException SQL�G���[�����������ꍇ
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 */
	private String makeSelectSQL1(final String login_no, final String table, final String blob_colum, final String[] primary_key, final String[] primary_value) {
		Log.method(login_no, "IN", "");

		try {
			String value0 = null;
			value0 = primary_value[0];
			value0 = value0.replaceAll("&quot;", "\"");
			value0 = value0.replaceAll("&#39;", "\'");
			String value1 = null;
			value1 = primary_value[1];
			value1 = value1.replaceAll("&quot;", "\"");
			value1 = value1.replaceAll("&#39;", "\'");
			String sql = "SELECT " + blob_colum + " FROM " + table + " WHERE ";

			if (PZZ020_MakeSQLUtil.getColumnTypeCheck(primary_key[0]).equals("1")) {
				sql = sql + primary_key[0] + " = " + value0;
			} else {
				sql = sql + primary_key[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(value0) + "'";
			}

			sql = sql + " AND " + primary_key[1] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(value1) + "'";
			Log.method(login_no, "OUT", "");

			return sql;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw new EJBException(e);
		}
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException { /* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException { /* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException { /* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException { /* �������܂��� */
	}

	/**
	 * SessionContext�����擾����B
	 * @return SessionContext���
	 */
	public SessionContext getSessionContext() {
		return this.my_ssc;
	}

	/**
	 * EJB�R���e�i���Ǘ�����SessionContext����SessionBean�ɓn���BSessionBean�̍쐬���ɌĂяo�����B
	 * @param val SessionContext���
	 * @exception RemoteException
	 */
	public void setSessionContext(final SessionContext val) throws RemoteException {
		this.my_ssc = val;
	}
}
