/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.bean.PCY_KensyuKanriJohoBean;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F PCY110_ClassIchiranServlet �N���X �@�\�����F �N���X�̈ꗗ���擾���܂��B
 * 
 * </PRE>
 */
public class PCY320_ClassCyouseiIkkatuServlet extends PCY010_ControllerServlet {

	/**
	 * ���N�G�X�g���猟���������擾���A���������Ɉ�v����N���X�����擾���܂��B �N���X���̓��N�G�X�g(�������F"classBeans")�Ɋi�[���܂��B �N���X��񂪑��݂��Ȃ��ꍇ�A���N�G�X�g�ɂ͋�̔z�񂪊i�[����܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean )
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		PCY_ClassBean[] classBeans = null;
		PCY_KensyuKanriJohoBean[] ret = null;
		final List taisyosyaList = new ArrayList();

		String limitFlg = (String) request.getSession().getAttribute("limitFlgIkkatu");
		final String limitStr = (String) ReadFile.fileMapData.get(HcdbDef.vcc320_limit);
		final String initIkkatuFlg = request.getParameter("initIkkatuFlg");
		final int limit = Integer.valueOf(limitStr).intValue();
		PCY_ClassBean kensaku_class = new PCY_ClassBean(request);

		if (initIkkatuFlg != null && initIkkatuFlg.equals("false")) {
			limitFlg = "";
		}

		if (limitFlg == null || limitFlg.equals("") || limitFlg.length() <= 0) {
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PCY_ClassEJBHome home = (PCY_ClassEJBHome) fact.lookup(PCY_ClassEJBHome.class);
			final PCY_ClassEJB ejb = home.create();

			classBeans = ejb.doSelect(kensaku_class, false, loginuser);

			final PCY_MousikomiJyokyoEJBHome home1 = (PCY_MousikomiJyokyoEJBHome) fact.lookup(PCY_MousikomiJyokyoEJBHome.class);
			final PCY_MousikomiJyokyoEJB ejb1 = home1.create();

			for (int i = 0; i < classBeans.length; i++) {

				final String kamokuCode = classBeans[i].getKamokuBean().getKamokuCode();
				final String classCode = classBeans[i].getClassCode();
				PCY_KensyuKanriJohoBean[] taisyosyaBeans = null;
				PCY_KensyuKanriJohoBean[] mimousikomi_taisyosyaBeans = null;

				if ((kensaku_class.getMousikomiJyokyo() == null || kensaku_class.getMousikomiJyokyo().equals(""))
						&& (kensaku_class.getJyukoJyokyo() == null || kensaku_class.getJyukoJyokyo().equals(""))) {
					/* ���������ɐ\���󋵁A��u�󋵂��ݒ肳��Ă��Ȃ���΁A�S�e�[�u���iL15,L51,L94�j������ */
					taisyosyaBeans = ejb1.getListWithClass(kamokuCode, classCode, null, loginuser);

					mimousikomi_taisyosyaBeans = this.getMimousikomi(classBeans[i], loginuser);

					final ArrayList retArray = new ArrayList();
					for (int s = 0; s < mimousikomi_taisyosyaBeans.length; s++) {
						retArray.add(mimousikomi_taisyosyaBeans[s]);
					}
					for (int t = 0; t < taisyosyaBeans.length; t++) {
						retArray.add(taisyosyaBeans[t]);
					}

					taisyosyaBeans = (PCY_KensyuKanriJohoBean[]) retArray.toArray(new PCY_KensyuKanriJohoBean[0]);

				} else if (kensaku_class.getMousikomiJyokyo().equals("1") || kensaku_class.getMousikomiJyokyo().equals("2") || kensaku_class.getMousikomiJyokyo().equals("3")
						|| kensaku_class.getMousikomiJyokyo().equals("4") || kensaku_class.getMousikomiJyokyo().equals("5") || kensaku_class.getMousikomiJyokyo().equals("6")) {
					// ���������ɐ\���󋵁i����ς͏����j���ݒ肳��Ă���΁AL15�e�[�u��������

					taisyosyaBeans = ejb1.getListWithClassL15(kamokuCode, classCode, kensaku_class, null, loginuser);
				} else if (kensaku_class.getMousikomiJyokyo().equals("7")) {
					// ���������ɐ\���󋵁u����ρv���ݒ肳��Ă���΁AL94�e�[�u��������
					taisyosyaBeans = ejb1.getListWithClassL94(kamokuCode, classCode, kensaku_class, null, loginuser);
				} else if (kensaku_class.getJyukoJyokyo().equals("0") || kensaku_class.getJyukoJyokyo().equals("1") || kensaku_class.getJyukoJyokyo().equals("2")) {
					// ���������Ɏ�u�󋵁u�񍐑ҁv�A�u����ҁv���ݒ肳��Ă���΁AL15�e�[�u��������
					taisyosyaBeans = ejb1.getListWithClassL15(kamokuCode, classCode, kensaku_class, null, loginuser);
				} else if (kensaku_class.getJyukoJyokyo().equals("3") || kensaku_class.getJyukoJyokyo().equals("4")) {
					// ���������Ɏ�u�󋵁u���C���v�A�u�C���v���ݒ肳��Ă���΁AL51�e�[�u��������
					taisyosyaBeans = ejb1.getListWithClassL51(kamokuCode, classCode, kensaku_class, null, loginuser);
				} else if (kensaku_class.getMousikomiJyokyo().equals("0")) {
					taisyosyaBeans = this.getMimousikomi(classBeans[i], loginuser);
				}

				for (int t = 0; t < taisyosyaBeans.length; t++) {
					taisyosyaBeans[t].getMousikomiBean().getClassBean().getKamokuBean().setKamokuCode(classBeans[i].getKamokuBean().getKamokuCode());
					taisyosyaBeans[t].getMousikomiBean().getClassBean().getKamokuBean().setKamokuMei1(classBeans[i].getKamokuBean().getKamokuMei1());
					taisyosyaBeans[t].getMousikomiBean().getClassBean().setClassMei(classBeans[i].getClassMei());
					taisyosyaBeans[t].getMousikomiBean().getClassBean().setKousinbi(classBeans[i].getKousinbi());
					taisyosyaBeans[t].getMousikomiBean().getClassBean().setKousinjikoku(classBeans[i].getKousinjikoku());
					taisyosyaList.add(taisyosyaBeans[t]);
				}
			}
			ret = new PCY_KensyuKanriJohoBean[taisyosyaList.size()];
			ret = (PCY_KensyuKanriJohoBean[]) taisyosyaList.toArray(ret);

			if (taisyosyaList.size() > limit) {
				/* �S���f�[�^�ƌ����pClassBean��session�ɕۑ� */
				request.getSession().setAttribute("kensaku_class", kensaku_class);
				request.getSession().setAttribute("KensyuKanriJohoBeans", ret);
				request.getSession().setAttribute("limitMaxIkkatu", "true");
				request.getSession().setAttribute("limitFlgIkkatu", "true");

				final List ret_taisyosyaList = new ArrayList();
				for (int s = 0; s < limit; s++) {
					ret_taisyosyaList.add(taisyosyaList.get(s));
				}
				ret = new PCY_KensyuKanriJohoBean[limit];
				ret = (PCY_KensyuKanriJohoBean[]) ret_taisyosyaList.toArray(ret);

			}

		} else {
			/* session�ɕۑ����Ă���S�f�[�^���擾���Ԃ� */
			ret = (PCY_KensyuKanriJohoBean[]) request.getSession().getAttribute("KensyuKanriJohoBeans");
			kensaku_class = (PCY_ClassBean) request.getSession().getAttribute("kensaku_class");
			request.getSession().setAttribute("KensyuKanriJohoBeans", "");
			request.getSession().setAttribute("kensaku_class", "");
			request.getSession().setAttribute("limitMaxIkkatu", "false");
			request.getSession().setAttribute("limitFlgIkkatu", "");
		}

		request.setAttribute("classBean", kensaku_class);
		request.setAttribute("kensyukanriJohoBeans", ret);

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

	private PCY_KensyuKanriJohoBean[] getMimousikomi(final PCY_ClassBean classBean, final PCY_PersonalBean loginuser) throws RemoteException, NamingException, CreateException {
		ArrayList retKanri;
		try {
			/* �擾�����N���X���S�БΏۂ̏ꍇ�AL15,L51�ɐ\�����������̂��Y�� */
			/* �擾�����N���X����S�БΏۂ̏ꍇ�A�ΏێҐݒ肳��Ă���l��L15,L51�ɖ����ꍇ�ɊY�� */

			final PCY_MousikomiJyokyoBean kensaku_mousikomi = new PCY_MousikomiJyokyoBean();
			final PCY_KensyuRirekiBean kensaku_rireki = new PCY_KensyuRirekiBean();

			retKanri = new ArrayList();

			final EJBHomeFactory fact = EJBHomeFactory.getInstance();

			final PCY_MousikomiJyokyoEJBHome home_mousikomi = (PCY_MousikomiJyokyoEJBHome) fact.lookup(PCY_MousikomiJyokyoEJBHome.class);
			final PCY_MousikomiJyokyoEJB ejb_mousikomi = home_mousikomi.create();

			final PCY_TaisyoEJBHome home_taisyo = (PCY_TaisyoEJBHome) fact.lookup(PCY_TaisyoEJBHome.class);
			final PCY_TaisyoEJB ejb_taisyo = home_taisyo.create();

			// ��S�БΏۂ̏ꍇ�̂�L15��L51������
			// �S�БΏۂ̏ꍇ�́u���\���v�̌����͂ł��Ȃ�
			// �Ȃ��Ȃ�΁AL15�ɂ��Ȃ�L51�ɂ��Ȃ��̂ŁA�o�̓f�[�^���Ȃ��B�܂�A0���ɂȂ�
			if (classBean.getZensyaTaisyoFlg().equals("0")) {
				final PCY_TaisyosyaBean[] taisyo = ejb_taisyo.getAllTaisyosya(classBean, false, loginuser);
				for (int t = 0; t < taisyo.length; t++) {

					kensaku_mousikomi.setClassBean(taisyo[t].getClassBean());
					kensaku_mousikomi.setSimeiNo(taisyo[t].getSimeiNo());
					kensaku_rireki.setClassCode(taisyo[t].getClassBean().getClassCode());
					kensaku_rireki.setKamokuCode(taisyo[t].getClassBean().getKamokuBean().getKamokuCode());
					kensaku_rireki.setSimeiNo(taisyo[t].getSimeiNo());

					final PCY_MousikomiJyokyoBean[] mousikomiBeans = ejb_mousikomi.getList(kensaku_mousikomi, loginuser);
					final PCY_KensyuRirekiBean[] rirekiBeans = ejb_mousikomi.getListL51(kensaku_rireki, loginuser);
					if ((mousikomiBeans == null || mousikomiBeans.length == 0) && (rirekiBeans == null || rirekiBeans.length == 0)) {
						// L15�AL51���e�[�u���Ƀf�[�^���ꌏ��������΁A�f�[�^�ێ�
						final PCY_KensyuKanriJohoBean kanriBean = new PCY_KensyuKanriJohoBean();
						final PCY_MousikomiJyokyoBean mousikomi = new PCY_MousikomiJyokyoBean();
						mousikomi.setPersonalBean(taisyo[t].getPersonalBean());
						mousikomi.setMousikomijyokyo("0");
						kanriBean.setMousikomiBean(mousikomi);
						kanriBean.setTaisyousyaBean(taisyo[t]);
						retKanri.add(kanriBean);
					}
				}
			}
			return (PCY_KensyuKanriJohoBean[]) retKanri.toArray(new PCY_KensyuKanriJohoBean[0]);

		} catch (final RemoteException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		}
	}

}
