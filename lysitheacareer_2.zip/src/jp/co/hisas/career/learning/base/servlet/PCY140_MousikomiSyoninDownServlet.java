/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PCY140_MousikomiSyoninDownServlet �N���X �@�\�����F �\���󋵂̈ꗗ���擾���܂��B
 * 
 * </PRE>
 */
public class PCY140_MousikomiSyoninDownServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		// add 20060721
		final HttpSession session = request.getSession(false);
		final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
		final String login_no = bean.getLogin_no();
		final String simei_no = bean.getSimei_no();

		final PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_MousikomiJyokyoEJB ejb = home.create();

		// For Syanai-S
		final PCY_MousikomiJyokyoBean condBean = new PCY_MousikomiJyokyoBean(request);
		final PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = ejb.getListWithSyoninsya(loginuser.getSimeiNo(), condBean, loginuser);
		condBean.setStatus("all");

		final PCY_MousikomiJyokyoBean[] selOptions = ejb.getListWithSyoninsya(loginuser.getSimeiNo(), condBean, loginuser);

		final HashMap kamokuMap = new HashMap();

		float nissuu = 0;
		int total = 0;

		for (int i = 0; i < mousikomiJyokyoBeans.length; i++) {
			if (mousikomiJyokyoBeans[i].getClassBean().getNissuu() != null) {
				nissuu += mousikomiJyokyoBeans[i].getClassBean().getNissuu().floatValue();
			}

			if (mousikomiJyokyoBeans[i].getClassBean().getTanka() != null) { // CHG#2007/3/6 s-hiura
				total += mousikomiJyokyoBeans[i].getClassBean().getTanka().intValue(); // CHG#2007/3/6 s-hiura
			}
		}

		for (int i = 0; i < selOptions.length; i++) {
			if (!kamokuMap.containsValue(selOptions[i].getKamokuCode())) {
				kamokuMap.put("kamoku" + i, selOptions[i].getKamokuCode());
			}
		}

		/* ���샍�O�o�� */
		final String outLogStatus = request.getParameter("S001_status");
// MOD 2018/04/03 COMTURE VCB010_�\�����F�iPh2-3�j START
//		OutLogBean.sousaKojinJohoLog("LNG001", login_no, "", ("all".equals(outLogStatus) ? "�S��" : "0".equals(outLogStatus) ? "����" : "��") + "," + condBean.getClassBean().getKaisibi() + ","
		OutLogBean.sousaKojinJohoLog("LNG001", login_no, "", ("all".equals(outLogStatus) ? "�S��" : "0".equals(outLogStatus) ? "����" : "1".equals(outLogStatus) ? "��" : "���F�s�v") + "," + condBean.getClassBean().getKaisibi() + ","
// MOD 2018/04/03 COMTURE VCB010_�\�����F�iPh2-3�j END
				+ condBean.getClassBean().getSyuryobi() + "," + condBean.getPersonalBean().getSimeiNo() + "," + condBean.getClassBean().getKamokuBean().getKamokuCode());

		request.setAttribute("mousikomiJyokyoBeans", mousikomiJyokyoBeans);
		request.setAttribute("kamokuMap", kamokuMap);
		request.setAttribute("nissuu", Float.toString(nissuu));
		request.setAttribute("total", Integer.toString(total));
		request.setAttribute("selOpt", selOptions);

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
