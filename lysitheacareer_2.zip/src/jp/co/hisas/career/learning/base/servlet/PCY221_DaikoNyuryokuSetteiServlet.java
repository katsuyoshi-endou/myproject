/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_DaikoNyuryokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_DaikoNyuryokuEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PCY221_DaikoNyuryokuSetteiServlet �N���X �@�\�����F ��s���͓o�^���s���܂��B
 * 
 * </PRE>
 */
public class PCY221_DaikoNyuryokuSetteiServlet extends PCY010_ControllerServlet {
	/**
	 * ��s���͓o�^���s���܂��B
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, SQLException,
			RemoteException, PCY_WarningException {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final PCY_ClassBean classBean = new PCY_ClassBean(request);
		final PCY_TaisyosyaBean taisyosyaBean = new PCY_TaisyosyaBean(request);
		final String uketsuke_jyotai = request.getParameter("S001_uketsuke_jyotai");

		/* ��s���͏������Ăяo�� */
		final PCY_DaikoNyuryokuEJBHome daiko_home = (PCY_DaikoNyuryokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_DaikoNyuryokuEJBHome.class);
		final PCY_DaikoNyuryokuEJB daiko_ejb = daiko_home.create();

		try {
			Log.transaction(loginuser.getSimeiNo(), true, "");
			daiko_ejb.doDaikoNyuryoku(classBean, taisyosyaBean, loginuser, uketsuke_jyotai);
			Log.transaction(loginuser.getSimeiNo(), false, "");
		} catch (final PCY_WarningException e) {
			if ("WCC040".equals(e.getMessage())) {
				/* ���ɐ��ѓ��͑Ώێ҂ł��� */
				request.setAttribute("warningID", "WCC040");
			} else if ("WCC050".equals(e.getMessage())) {
				request.setAttribute("warningID", "WCC050");
			} else if ("WCC190".equals(e.getMessage())) {
				request.setAttribute("warningID", "WCC190");
			} else if ("WCC200".equals(e.getMessage())) {
				request.setAttribute("warningID", "WCC200");
			} else if ("WCC260".equals(e.getMessage())) {
				request.setAttribute("warningID", "WCC260");
			}

			throw e;
		}
		try {
			OutLogBean.sousaKojinJohoLog("VCC241", loginuser.getSimeiNo(), null, classBean.getKamokuBean().getKamokuCode() + "," + classBean.getClassCode());
		} catch (final Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
		}
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
