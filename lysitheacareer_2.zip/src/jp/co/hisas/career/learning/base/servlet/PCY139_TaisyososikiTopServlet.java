/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_SosikiBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY139_TaisyososikiTopServlet �N���X �@�\�����F �S�g�D�K�w�����擾���܂��B
 * 
 * </PRE>
 */
public class PCY139_TaisyososikiTopServlet extends PCY010_ControllerServlet {

	/**
	 * �S�g�D�K�w�����擾���܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		final PCY_TaisyoEJBHome home = (PCY_TaisyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_TaisyoEJBHome.class);
		final PCY_TaisyoEJB ejb = home.create();

		final PCY_SosikiBean[] sosikiBeans = ejb.getSosiki(loginuser);
		PCY_SosikiBean root = null;
		if (sosikiBeans.length != 0) {
			root = sosikiBeans[0];
			for (int i = 1; i < sosikiBeans.length; i++) {
				root.addKaiSosiki(sosikiBeans[i]);
			}
		}
		request.setAttribute("sosikiBean", root);

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

}
