/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.base.mail.util.MessageCreateHelper;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBeanForMail;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBeanForMail;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F PCY146_SyoninKakuninServlet �N���X �@�\�����F ���F�E���߂��E���F����m�F��ʂɕ\������������擾���܂��B
 * 
 * </PRE>
 */
public class PCY146_SyoninKakuninServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException, Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		/*
		 * �����t���O 1:���F 2:���߂� 3:���F��� 4:�\�����
		 */
		final String flg = request.getParameter("flg");

		final String[] check = request.getParameterValues("syonin");
		String kamokuCode = "";
		String classCode = "";
		String simeiNo = "";
		String status = "";
		String uketsuke = "";

		final PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_MousikomiJyokyoEJB ejb = home.create();

		final PCY_ClassEJBHome homeClass = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB ejbClass = homeClass.create();

		for (int i = 0; i < check.length; i++) {
			kamokuCode = request.getParameter("kamoku_code_" + check[i]);
			classCode = request.getParameter("class_code_" + check[i]);
			simeiNo = request.getParameter("simei_no_" + check[i]);
			status = request.getParameter("status_" + check[i]);
			uketsuke = request.getParameter("uketsuke_" + check[i]);

			/* �I���������R�[�h�̃N���X�����擾���� */
			PCY_ClassBean classBeanDummy = new PCY_ClassBean();
			classBeanDummy.getKamokuBean().setKamokuCode(kamokuCode);
			classBeanDummy.setClassCode(classCode);
			Log.transaction(loginuser.getSimeiNo(), true, "");

			final PCY_ClassBean classBean = ejbClass.doSelectByPrimaryKey(classBeanDummy, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");

			/* �I���������R�[�h�̏��(�\����)���擾���� */
			PCY_MousikomiJyokyoBean mousikomiJyokyoBean = new PCY_MousikomiJyokyoBean();
			mousikomiJyokyoBean.setKamokuCode(kamokuCode);
			mousikomiJyokyoBean.setClassCode(classCode);
			mousikomiJyokyoBean.setSimeiNo(simeiNo);
			mousikomiJyokyoBean.setStatus(status);

			Log.transaction(loginuser.getSimeiNo(), true, "");

			final PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = ejb.getList(mousikomiJyokyoBean, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");

			/* ���F����̏ꍇ */
			if (flg != null && flg.equals("3")) {
				/* ���F�s�v�̏ꍇ */
				if (classBean.getSyoninKubun().equals("0")) {
					request.setAttribute("warningID", "WCB010");
					throw new PCY_WarningException();
				}

				/* ���F�҂��̏ꍇ */
				if (status.equals("0")) {
					request.setAttribute("warningID", "WCB020");
					throw new PCY_WarningException();
				}

				/* ��t�敪��"�v"�̃N���X�̏ꍇ */
				if (classBean.getUketukeKubun().equals("1")) {
					if (Integer.parseInt(mousikomiJyokyoBeans[0].getStatus()) >= 2) {
						request.setAttribute("warningID", "WCB030");
						throw new PCY_WarningException();
					}

					/* �񍐋敪��"�v"�̃N���X�̏ꍇ */
				} else if (!classBean.getHoukokuKubun().equals("0")) {
					if (Integer.parseInt(mousikomiJyokyoBeans[0].getStatus()) == 3) {
						request.setAttribute("warningID", "WCB040");
						throw new PCY_WarningException();
					}
				}

				/* ���߂��̏ꍇ */
			} else if (flg != null && flg.equals("2")) {
				/* ���F�s�v�̏ꍇ */
				if (classBean.getSyoninKubun().equals("0")) {
					request.setAttribute("warningID", "WCB050");
					throw new PCY_WarningException();
				}

				/* ��t�敪��"�v"�̃N���X�̏ꍇ */
				if (classBean.getUketukeKubun().equals("1")) {
					/* �񍐑҂��A����҂��̏ꍇ */
					if (Integer.parseInt(mousikomiJyokyoBeans[0].getStatus()) >= 2) {
						request.setAttribute("warningID", "WCB060");
						throw new PCY_WarningException();
					}

					/* ��t�҂��̏ꍇ */
					if (Integer.parseInt(mousikomiJyokyoBeans[0].getStatus()) == 1) {
						request.setAttribute("warningID", "WCB070");
						throw new PCY_WarningException();
					}

					/* ��t�s�v�E�񍐋敪��"�v"�̃N���X�̏ꍇ */
				} else if (!classBean.getHoukokuKubun().equals("0")) {
					if (Integer.parseInt(mousikomiJyokyoBeans[0].getStatus()) == 3) {
						request.setAttribute("warningID", "WCB080");
						throw new PCY_WarningException();
					}
				}

				/* ���F�̏ꍇ */
			} else if (flg != null && flg.equals("1")) {
				/* ���F�s�v�̏ꍇ */
				if (classBean.getSyoninKubun().equals("0")) {
					request.setAttribute("warningID", "WCB090");
					throw new PCY_WarningException();
				}

				/* ���F�҂��łȂ� */
				if (!status.equals("0")) {
					request.setAttribute("warningID", "WCB100");
					throw new PCY_WarningException();
				}

				// �\������̏ꍇ
			} else if (flg != null && flg.equals("4")) {
				if (!status.equals("1")) {
					request.setAttribute("warningID", "WCB210");
					throw new PCY_WarningException();
				}
				if (!uketsuke.equals("2")) {
					request.setAttribute("warningID", "WCB220");
					throw new PCY_WarningException();
				}
			}

			classBeanDummy = null;
			mousikomiJyokyoBean = null;
		}

		Log.transaction(loginuser.getSimeiNo(), true, "");

		final PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = ejb.getListWithSyoninsya(loginuser.getSimeiNo(), new PCY_MousikomiJyokyoBean(), loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		final ArrayList list = new ArrayList();

		for (int i = 0; i < check.length; i++) {
			kamokuCode = request.getParameter("kamoku_code_" + check[i]);
			classCode = request.getParameter("class_code_" + check[i]);
			simeiNo = request.getParameter("simei_no_" + check[i]);

			for (int j = 0; j < mousikomiJyokyoBeans.length; j++) {
				if (mousikomiJyokyoBeans[j].getKamokuCode().equals(kamokuCode) && mousikomiJyokyoBeans[j].getClassCode().equals(classCode) && mousikomiJyokyoBeans[j].getSimeiNo().equals(simeiNo)) {
					list.add(i, mousikomiJyokyoBeans[j]);
				}
			}
		}

		final PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans2 = (PCY_MousikomiJyokyoBean[]) list.toArray(new PCY_MousikomiJyokyoBean[list.size()]);
		request.setAttribute("mousikomiJyokyoBeans", mousikomiJyokyoBeans2);

		// �I�����ꂽ�e���v���[�g�����擾����
		final String templateID = request.getParameter("mail_template");
		// ���͂��ꂽ�R�����g���擾����
		final String comment = request.getParameter("HTMLcomment");

		// ���[�����M���e���쐬����
		if (templateID != null && !templateID.equals("")) {
			final MessageCreateHelper helper = MessageCreateHelper.createInstance(templateID);
			helper.setParameter("class", new PCY_ClassBeanForMail(mousikomiJyokyoBeans2[0].getClassBean()));
			helper.setParameter("kamoku", new PCY_KamokuBeanForMail(mousikomiJyokyoBeans2[0].getClassBean().getKamokuBean()));
			helper.setParameter("announce", ReadFile.announceMapData.get("AZZ027"));
			helper.setParameter("honbun", comment);
			// ADD#2007/3/30 s-hiura start
			// �������̖����擾���APCY_PersonalBean���Z�b�g
			final PCY_PersonalBean personalBean = new PCY_PersonalBean();
			personalBean.setBusyoRyakusyoMei((String) ReadFile.paramMapData.get("DCA025"));
			personalBean.setKanjiSimei((String) ReadFile.paramMapData.get("DCA026"));
			helper.setParameter("personal", personalBean);
			// ADD#2007/3/30 s-hiura end
			final String mail_template_content = helper.getMessage();
			// �R�����g�̓��e���Z�b�g
			request.setAttribute("mail_template_content", mail_template_content);
		}

		/* ���\�b�h�g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
