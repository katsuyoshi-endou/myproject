/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY145_PCY145_SyoninTorikesiServlet �N���X �@�\�����F ���F����������s���܂��B
 * 
 * </PRE>
 */
public class PCY145_SyoninTorikesiServlet extends PCY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�E�p�t�H�[�}���X�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final String kamokuCode = request.getParameter("kamoku_code");
		final String classCode = request.getParameter("class_code");
		final String simeiNo = request.getParameter("simei_no");
		final String kousinbi = request.getParameter("kousinbi");
		final String kousinjikoku = request.getParameter("kousinjikoku");

		final PCY_ClassEJBHome homeClass = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB ejbClass = homeClass.create();
		final PCY_ClassBean classBeanDummy = new PCY_ClassBean();
		classBeanDummy.getKamokuBean().setKamokuCode(kamokuCode);
		classBeanDummy.setClassCode(classCode);

		Log.transaction(loginuser.getSimeiNo(), true, "");
		final PCY_ClassBean classBean = ejbClass.doSelectByPrimaryKey(classBeanDummy, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		final PCY_MousikomiJyokyoBean mousikomiJyokyoBean = new PCY_MousikomiJyokyoBean();
		mousikomiJyokyoBean.setClassBean(classBean);
		mousikomiJyokyoBean.setKamokuCode(kamokuCode);
		mousikomiJyokyoBean.setClassCode(classCode);
		mousikomiJyokyoBean.setSimeiNo(simeiNo);
		mousikomiJyokyoBean.setStatus("0");
		mousikomiJyokyoBean.setSyoninbi1(null);
		mousikomiJyokyoBean.setSyoninjikoku1(null);
		mousikomiJyokyoBean.setSyoninsya1(null);
		mousikomiJyokyoBean.setKousinbi(kousinbi);
		mousikomiJyokyoBean.setKousinjikoku(kousinjikoku);
		final PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = new PCY_MousikomiJyokyoBean[1];
		mousikomiJyokyoBeans[0] = mousikomiJyokyoBean;

		final PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_MousikomiJyokyoEJB ejb = home.create();

		Log.transaction(loginuser.getSimeiNo(), true, "");
		ejb.doUpdateStatus(mousikomiJyokyoBeans, loginuser, true);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		/* ���\�b�h�g���[�X�E�p�t�H�[�}���X�g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

}
