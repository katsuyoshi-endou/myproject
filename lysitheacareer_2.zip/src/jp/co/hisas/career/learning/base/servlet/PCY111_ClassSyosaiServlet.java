/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.bean.PCY_KensyuKanriJohoBean;
import jp.co.hisas.career.learning.base.ejb.PCY_CancelKikanEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_CancelKikanEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_JizenkadaiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_JizenkadaiEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_ReportSubmitKikanEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ReportSubmitKikanEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_CancelKikanBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_JizenkadaiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KurasuNinzuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ReportSubmitKikanBean;
import jp.co.hisas.career.personal.kyoiku.ejb.KyoikuEJB;
import jp.co.hisas.career.personal.kyoiku.ejb.KyoikuEJBHome;
import jp.co.hisas.career.util.log.Log;
//ADD 2017/05/10 COMTURE VCC091_�N���X�o�^ ���́iver.02-00�j START
//ADD 2017/05/10 COMTURE VCC091_�N���X�o�^ ���́iver.02-00�j END

/**
 * <PRE>
 * 
 * �N���X���F PCY111_ClassSyosaiServlet �N���X �@�\�����F �N���X�̈ꗗ���擾���܂��B
 * 
 * </PRE>
 */
public class PCY111_ClassSyosaiServlet extends PCY010_ControllerServlet {

	/**
	 * ���N�G�X�g����v���C�}���L�[���擾���A�N���X�����擾���܂��B �N���X���̓��N�G�X�g(�������F"classBean")�Ɋi�[���܂��B �N���X��񂪑��݂��Ȃ��ꍇ�A���N�G�X�g�ɂ� null ���i�[����܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean )
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException {

		int uketukemachiNinzu = 0;
		int uketukeChouseiChuNinzu = 0;
		int jyukomachiNinzu = 0;
		int torikesiSinseiNinzu = 0;
		int torikesiChouchuNinzu = 0;

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		// �N���X���擾
		final PCY_ClassEJBHome home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB ejb = home.create();
		final PCY_ClassBean classBean = ejb.doSelectByPrimaryKey(new PCY_ClassBean(request), loginuser);
		request.setAttribute("classBean", classBean);
// ADD 2017/05/10 COMTURE VCC091_�N���X�o�^ ���́iver.02-00�j START
		final PCY_JizenkadaiEJBHome jizenkadaihome = (PCY_JizenkadaiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_JizenkadaiEJBHome.class);
        final PCY_JizenkadaiEJB jizenkadaiejb = jizenkadaihome.create();
        PCY_JizenkadaiBean jizenkadaiBean = new PCY_JizenkadaiBean(request);
        jizenkadaiBean = jizenkadaiejb.doSelectByPrimaryKey(jizenkadaiBean, loginuser);
        request.setAttribute("jizenkadaiBean", jizenkadaiBean);
// ADD 2017/05/10 COMTURE VCC091_�N���X�o�^ ���́iver.02-00�j END
        
// ADD 2017/10/20 HISOL �\��������Ԓǉ��Ή� START
		final PCY_CancelKikanEJBHome cancelHome = (PCY_CancelKikanEJBHome)EJBHomeFactory.getInstance().lookup(PCY_CancelKikanEJBHome.class);
		final PCY_CancelKikanEJB cancelejb = cancelHome.create();
		PCY_CancelKikanBean cancelBean = new PCY_CancelKikanBean(request);
		cancelBean = cancelejb.doSelectByPrimaryKey(cancelBean, loginuser);
		request.setAttribute("cancelKikanBean", cancelBean);
// ADD 2017/10/20 HISOL �\��������Ԓǉ��Ή� END

// ADD 2018/12/03 COMTURE ���|�[�g��o���Ԓǉ��Ή� START
		final PCY_ReportSubmitKikanEJBHome reportSubmitKikanHome = (PCY_ReportSubmitKikanEJBHome)EJBHomeFactory.getInstance().lookup(PCY_ReportSubmitKikanEJBHome.class);
		final PCY_ReportSubmitKikanEJB reportSubmitKikanEjb = reportSubmitKikanHome.create();
		PCY_ReportSubmitKikanBean reportSubmitKikanBean = new PCY_ReportSubmitKikanBean(request);
		reportSubmitKikanBean = reportSubmitKikanEjb.doSelectByPrimaryKey(reportSubmitKikanBean, loginuser);
		request.setAttribute("reportSubmitKikanBean", reportSubmitKikanBean);
// ADD 2018/12/03 COMTURE ���|�[�g��o���Ԓǉ��Ή� END

		// ��u�Ґ��擾
		/* EJBObject�̎擾 */
		final PCY_MousikomiJyokyoEJBHome home1 = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_MousikomiJyokyoEJB ejb1 = home1.create();

		final String kamokuCode = request.getParameter("kamoku_code");
		final String classCode = request.getParameter("class_code");

		/* EJB�Ăяo�� */
		Log.transaction(loginuser.getSimeiNo(), true, "");

		final PCY_KensyuKanriJohoBean[] taisyosyaBeans = ejb1.getStatusListWithClass(kamokuCode, classCode, loginuser);

		for (int i = 0; i <= taisyosyaBeans.length - 1; i++) {
			final String uketukejyotai = taisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai();
			final String status = taisyosyaBeans[i].getMousikomiBean().getStatus();

			if (uketukejyotai == null) {
				/** �J�E���g���Ȃ� */
			} else if (uketukejyotai.equals("0") && status.equals("1")) {
				uketukemachiNinzu++;
			} else if (uketukejyotai.equals("1") && status.equals("1")) {
				uketukeChouseiChuNinzu++;
			} else if (uketukejyotai.equals("2") && status.equals("1")) {
				jyukomachiNinzu++;
			} else if (uketukejyotai.equals("3") && status.equals("1")) {
				torikesiSinseiNinzu++;
			} else if (uketukejyotai.equals("4") && status.equals("1")) {
				torikesiChouchuNinzu++;
			}
		}
		Log.debug("uketukemachiNinzu:" + uketukemachiNinzu);
		Log.debug("uketukeChouseiChuNinzu:" + uketukeChouseiChuNinzu);
		Log.debug("jyukomachiNinzu:" + jyukomachiNinzu);
		Log.debug("torikesiSinseiNinzu:" + torikesiSinseiNinzu);
		Log.debug("torikesiChouchuNinzu:" + torikesiChouchuNinzu);

		final PCY_KurasuNinzuBean kurasuNinzuBean = new PCY_KurasuNinzuBean();

		kurasuNinzuBean.setJyukomachiNinzu(Integer.toString(jyukomachiNinzu));
		kurasuNinzuBean.setTorikesiChoseichuNinzu(Integer.toString(torikesiChouchuNinzu));
		kurasuNinzuBean.setTorikesiSinseiNinzu(Integer.toString(torikesiSinseiNinzu));
		kurasuNinzuBean.setUketukeChouseiChuNinzu(Integer.toString(uketukeChouseiChuNinzu));
		kurasuNinzuBean.setUketukemachiNinzu(Integer.toString(uketukemachiNinzu));

// ADD 2018/12/18 COMTURE �N���X������ʂւ̎��уf�[�^�\�� START
		// ���C���l���A�C���l���A�u�t�l�����J�E���g����B
		PCY_KurasuNinzuBean syuryoHanteiL51Bean = new PCY_KurasuNinzuBean();
		syuryoHanteiL51Bean = ejb1.countSyuryoHanteiL51(kamokuCode, classCode, loginuser);
		
		// T05_���猤�C�����̎擾
		final KyoikuEJBHome kyoikuhome = (KyoikuEJBHome) EJBHomeFactory.getInstance().lookup(KyoikuEJBHome.class);
		final KyoikuEJB kyoikuEjb = kyoikuhome.create();
		PCY_KurasuNinzuBean syuryoHanteiT05Bean = new PCY_KurasuNinzuBean();
		
		try {
			syuryoHanteiT05Bean = kyoikuEjb.countSyuryoHanteiT05(kamokuCode, classBean.getClassMei(), classBean.getKaisibi(), loginuser);
		} catch (SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
		} catch (Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
		}
		
		kurasuNinzuBean.setMisyuryo(syuryoHanteiL51Bean.getMisyuryo() + syuryoHanteiT05Bean.getMisyuryo());
		kurasuNinzuBean.setSyuryo(syuryoHanteiL51Bean.getSyuryo() + syuryoHanteiT05Bean.getSyuryo());
		kurasuNinzuBean.setNintei(syuryoHanteiL51Bean.getNintei() + syuryoHanteiT05Bean.getNintei());
// ADD 2018/12/18 COMTURE �N���X������ʂւ̎��уf�[�^�\�� END

		request.setAttribute("kurasuNinzuBean", kurasuNinzuBean);

		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

}
