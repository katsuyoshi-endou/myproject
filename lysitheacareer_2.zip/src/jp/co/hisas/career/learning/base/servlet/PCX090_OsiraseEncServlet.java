/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/02/20  01.00      ��� �ӎ�    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;

/**
 * <PRE>
 * 
 * �N���X���F PCX090_OsiraseEncServlet �N���X �@�\�����F request����HTMLcontent�Atuutatu���擾���A�G���R�[�h���܂��B
 * 
 * </PRE>
 */
public class PCX090_OsiraseEncServlet extends PCY010_ControllerServlet {
	/**
	 * request����HTMLcontent�Atuutatu���擾���A�G���R�[�h���܂��B �E�e���v���[�gID �E�ȖڃR�[�h �E�N���X�R�[�h
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws Exception {

		/* request����l���擾���A�G���R�[�f�B���O���܂� */
		final String comment = request.getParameter("HTMLcomment");
		final String editNo = request.getParameter("editNo");
		final String[] edit_no = request.getParameterValues("editNo");
		final String page_add = request.getParameter("tuutatu_add");
		if (comment != null) {
// MOD 2017/12/13 COMTURE UTF-8�Ή� START
//			final String encComment = new String(comment.getBytes("iso-8859-1"), "Shift_JIS");
			final String encComment = new String(comment.getBytes("iso-8859-1"), "UTF-8");
// MOD 2017/12/13 COMTURE UTF-8�Ή� END
			request.setAttribute("HTMLcomment", encComment);
		}
		if (page_add != null) {
// MOD 2017/12/13 COMTURE UTF-8�Ή� START
//			final String encTuutatsu = new String(page_add.getBytes("iso-8859-1"), "Shift_JIS");
			final String encTuutatsu = new String(page_add.getBytes("iso-8859-1"), "UTF-8");
// MOD 2017/12/13 COMTURE UTF-8�Ή� END
			request.setAttribute("tuutatu_add", encTuutatsu);
		}

		if (editNo != null && !editNo.equals("")) {
			final String comment1 = request.getParameter("HTMLcomment_" + editNo.trim());
			if (comment1 != null) {
// MOD 2017/12/13 COMTURE UTF-8�Ή� START
//				final String encComment = new String(comment1.getBytes("iso-8859-1"), "Shift_JIS");
				final String encComment = new String(comment1.getBytes("iso-8859-1"), "UTF-8");
// MOD 2017/12/13 COMTURE UTF-8�Ή� END
				request.setAttribute("HTMLcomment_" + editNo.trim(), encComment);
			}
		}

		if (edit_no != null) {
			final String[] checked = request.getParameterValues("C001_osirase_check");
			if (checked != null) {
				for (int i = 0; i < checked.length; i++) {
					final int index = Integer.parseInt(checked[i].trim());
					final String comment2 = request.getParameter("HTMLcomment_" + edit_no[index].trim());
					if (comment2 != null) {
// MOD 2017/12/13 COMTURE UTF-8�Ή� START
//						final String encComment = new String(comment2.getBytes("iso-8859-1"), "Shift_JIS");
						final String encComment = new String(comment2.getBytes("iso-8859-1"), "UTF-8");
// MOD 2017/12/13 COMTURE UTF-8�Ή� END
						request.setAttribute("HTMLcomment_" + edit_no[index].trim(), encComment);
					}
					final String tuutatu = request.getParameter("tuutatu_" + edit_no[index].trim());
					if (tuutatu != null) {
// MOD 2017/12/13 COMTURE UTF-8�Ή� START
//						final String encPage = new String(tuutatu.getBytes("iso-8859-1"), "Shift_JIS");
						final String encPage = new String(tuutatu.getBytes("iso-8859-1"), "UTF-8");
// MOD 2017/12/13 COMTURE UTF-8�Ή� END
						request.setAttribute("tuutatu_" + edit_no[index].trim(), encPage);
					}
				}
			}
		}

		return this.getForwardPath();
	}
}
