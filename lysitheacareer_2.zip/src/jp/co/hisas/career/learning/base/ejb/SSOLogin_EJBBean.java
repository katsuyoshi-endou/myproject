// ADD 2016/03/01 COMTURE VCC410_��u�Ώێҏ����E��։Ȗڊm�F�iver.01-00�j START
package jp.co.hisas.career.learning.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F SSOLogin_EJBBean�N���X �@�\�����F �A�J�E���gID�̎擾���s���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="SSOLogin_EJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class SSOLogin_EJBBean implements SessionBean {
	private SessionContext context = null;
    /** SELECT����J�����B */
    public static final String ALLCOLS = ""
    									+ " GUID as guid,"
    									+ " ACCOUNT_ID as accountId,"
    									+ " LOGIN_DATETIME as loginDatetime,"
    									+ " LAST_OPERATION_DATETIME as lastOperationDatetime,"
    									+ " LOGOUT_REDIRECT_TARGET as logoutRedirectTarget,"
    									+ " TOKEN_FOR_XSRF_MEASURE as tokenForXsrfMeasure";
	/**
	 * �A�J�E���g���O�C�����e�[�u�����Q�Ƃ��A�A�J�E���gID���擾���܂��B
	 * @param guid ����������
	 * @return �A�J�E���gID
	 * @throws NamingException
	 * @throws RemoteException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public String getAccount(String guid) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			final StringBuffer sql = new StringBuffer();
			sql.append("SELECT " + ALLCOLS + "");
			sql.append("  FROM LYG_LOGIN");
			sql.append(" WHERE GUID = ?");

			// �R�l�N�V�����̎擾
			// ����ł悢�̂��s��
			con = PZZ040_SQLUtility.getConnection("");

			ps = con.prepareStatement(sql.toString());

			ps.setString(1, guid);

			rs = ps.executeQuery();

			final ArrayList ret = new ArrayList();

			while (rs.next()) {
				ret.add(rs.getString( "accountId" ));
			}
			return (String)ret.get( 0 );
		} catch (final NamingException e) {
			Log.error("", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error("", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error("", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection("", con, ps, rs);
		}
    }

	/**
	 * SessionContext��ݒ肵�܂��B
	 * @param context
	 * @throws javax.ejb.EJBException
	 * @throws java.rmi.RemoteException
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context)
			throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
// ADD 2016/03/01 COMTURE VCC410_��u�Ώێҏ����E��։Ȗڊm�F�iver.01-00�j END
}