/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_CodeEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_CodeEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_BaseCodeBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PCX051_DelMaintePulldownServlet �@�\�����F
 * 
 * </PRE>
 */
public class PCX051_DelMaintePulldownServlet extends PCY010_ControllerServlet {
	/**
	 * request ������͒l���擾���A�l�`�F�b�N���s������A ���X�g�ɑΉ�����c�a�̃f�[�^���폜���܂��B
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			UnsupportedEncodingException, PCY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		/* request ������͒l�擾���擾���A�l�̃`�F�b�N���s�� */
		final int del_list = Integer.parseInt(request.getParameter("del_list"));
		final String del_code = request.getParameter("del_code");
		final String name = request.getParameter("name");
		String[] save = { del_code, name };

		// null���󔒕����ɕϊ�
		save = PZZ010_CharacterUtil.normalizedStr(save);

		int checkCount = 0;

		PCY_KamokuEJBHome kamokuHome = null;
		PCY_KamokuEJB kamokuEjb = null;
		PCY_KamokuBean kamokuBean = null;
		PCY_ClassEJBHome classHome = null;
		PCY_ClassEJB classEjb = null;
		PCY_ClassBean classBean = null;

		switch (del_list) {
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:

			/* �Ȗڃ}�X�^�ɑ�����R�[�h */
			kamokuHome = (PCY_KamokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KamokuEJBHome.class);
			kamokuEjb = kamokuHome.create();

			/* ���͂��ꂽ�R�[�h���L�[�ɁA�Ȗڃ}�X�^���� */
			kamokuBean = new PCY_KamokuBean();

			break;

		case 6:
		case 7:
		case 8:

			/* �N���X�}�X�^�ɑ�����R�[�h */
			classHome = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
			classEjb = classHome.create();

			/* ���͂��ꂽ�R�[�h���L�[�ɁA�N���X�}�X�^���� */
			classBean = new PCY_ClassBean();

			break;
		case 9:

			/* �Ȗڃ}�X�^�ɑ�����R�[�h */
			kamokuHome = (PCY_KamokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KamokuEJBHome.class);
			kamokuEjb = kamokuHome.create();

			/* ���͂��ꂽ�R�[�h���L�[�ɁA�Ȗڃ}�X�^���� */
			kamokuBean = new PCY_KamokuBean();

			break;

		default:
			break;
		}

		/* �������s */
		switch (del_list) {
		case 0:
			kamokuBean.setCategoryCode1(del_code);
			checkCount = kamokuEjb.doSelect(kamokuBean, loginuser).length;

			break;

		case 1:
			kamokuBean.setCategoryCode2(del_code);
			checkCount = kamokuEjb.doSelect(kamokuBean, loginuser).length;

			break;

		case 2:
			kamokuBean.setCategoryCode3(del_code);
			checkCount = kamokuEjb.doSelect(kamokuBean, loginuser).length;

			break;

		case 3:
			kamokuBean.setCategoryCode4(del_code);
			checkCount = kamokuEjb.doSelect(kamokuBean, loginuser).length;

			break;

		case 4:
			kamokuBean.setCategoryCode5(del_code);
			checkCount = kamokuEjb.doSelect(kamokuBean, loginuser).length;

			break;

		case 5:
			kamokuBean.setKanrimotoCode(del_code);
			checkCount = kamokuEjb.doSelect(kamokuBean, loginuser).length;

			break;

		case 6:
			classBean.setChikuCode(del_code);
			checkCount = classEjb.doSelect(classBean, true, loginuser).length;

			break;

		case 7:
			classBean.setKyosituCode(del_code);
			checkCount = classEjb.doSelect(classBean, true, loginuser).length;

			break;

		case 8:
			classBean.setKousiCode(del_code);
			checkCount = classEjb.doSelect(classBean, true, loginuser).length;

			break;
		case 9:
			kamokuBean.setKamokuGroup(del_code);
			checkCount = kamokuEjb.doSelect(kamokuBean, loginuser).length;

			break;

		default:
			checkCount = -1;

			break;
		}

		/* ���ݎg�p���̃R�[�h�����݂���ꍇ�A�폜�ł��Ȃ� */
		if (checkCount != 0) {
			if (checkCount == -1) {
				request.setAttribute("warningID", "WCX040");
			} else {
				request.setAttribute("warningID", "WCX050");
			}

			throw new PCY_WarningException();
		}

		/* �擾�������͒l����APCY_BaseCodeBean �쐬 */
		final PCY_BaseCodeBean codeMasterBean = new PCY_BaseCodeBean();
		codeMasterBean.setCodeTableName(HcdbDef.LEARNING_PULLDOWNS[del_list][2]);
		codeMasterBean.setCode(del_code);
		codeMasterBean.setName(name);

		/* �폜���� */
		final PCY_CodeEJBHome home = (PCY_CodeEJBHome) EJBHomeFactory.getInstance().lookup(PCY_CodeEJBHome.class);
		final PCY_CodeEJB ejb = home.create();

		try {
			ejb.doDelete(codeMasterBean, loginuser);
		} catch (final PCY_WarningException e) {
			request.setAttribute("warningID", "WCX040");
			throw e;
		}

		/* PCY_CodeBean ���č쐬 */
		jp.co.hisas.career.learning.base.bean.PCY_CodeBean.getInstance().refreash();

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
