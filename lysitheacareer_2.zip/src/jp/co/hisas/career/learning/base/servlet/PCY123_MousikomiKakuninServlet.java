/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O            ���e
 *   2004/03/16  01.00       �ⓡ ������     �V�K�쐬
 *   2004/08/03              ����  ���V      �\���ς݁A���C�ςݓ���Ȗڃ`�F�b�N�Ή��i�Г�Career@Net�Ή��j
 *   2004/08/12              ����  ���V      �㗝�\���Ή��i�Г�Career@Net�Ή��j
 *   2006/02/03              ���Y  �T��      �\���ς݁A���C�ςݓ���Ȗڃ`�F�b�N�폜
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.bean.PCY_HonninKensyuJyohouBean;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_SyoninsyaBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F �\�����݃T�[�u���b�g�N���X �@�\�����F ���C�̐\���݊m�F���s���܂��B
 * 
 * </PRE>
 */
public class PCY123_MousikomiKakuninServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		final PCY_ClassBean classBean = new PCY_ClassBean(request);
		final PCY_HonninKensyuJyohouBean kensyuBean = new PCY_HonninKensyuJyohouBean();

		String simei_no = request.getParameter("simei_no");

		if (simei_no == null || "".equals(simei_no)) {
			simei_no = loginuser.getSimeiNo();
		}

		final PCY_PersonalBean personalBean = new PCY_PersonalBean();
		personalBean.setSimeiNo(simei_no);
		// CHG#2007/2/26 s-hiura start
		final PCY_ClassBean[] classBeans = new PCY_ClassBean[1];
		classBeans[0] = kensyuBean.doSelectMousikomi(classBean, personalBean, loginuser);

// 2009.09.25 Career04-05 BC0405-01-008 yoda START
        final boolean lock = false;
        final String[] simeiNo = new String[1];
        simeiNo[0] = simei_no;
        final PCY_SyoninsyaEJBHome home = (PCY_SyoninsyaEJBHome) EJBHomeFactory.getInstance().lookup(PCY_SyoninsyaEJBHome.class);
        final PCY_SyoninsyaEJB ejb = home.create();
        final PCY_PersonalEJBHome homePersonal = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
        final PCY_PersonalEJB ejbPersonal = homePersonal.create();

        Log.transaction(loginuser.getSimeiNo(), true, "");
        final PCY_SyoninsyaBean[] syoninsyaBeans = ejb.doSelect(simeiNo, lock, loginuser);
        Log.transaction(loginuser.getSimeiNo(), false, "");

        String syoninsya1 = "";
        String[] syoninsyaList = new String[syoninsyaBeans.length];
        /* ���F�҂��ݒ肳��Ă���ꍇ */
        if (syoninsyaBeans.length != 0) {
            syoninsya1 = syoninsyaBeans[0].getSyoninsya1();

            final String[] syoninsya = new String[1];
            syoninsya[0] = syoninsya1;

            Log.transaction(loginuser.getSimeiNo(), true, "");
            final PCY_PersonalBean[] personalBeans = ejbPersonal.getPersonalInfo(syoninsya, loginuser);
            Log.transaction(loginuser.getSimeiNo(), false, "");

            syoninsyaList = new String[6];
            if (syoninsya1 != null) {
                syoninsyaList[0] = personalBeans[0].getSimeiNo();
                syoninsyaList[1] = personalBeans[0].getKanjiSimei();
                syoninsyaList[2] = personalBeans[0].getKanaSimei();
                syoninsyaList[3] = personalBeans[0].getSosikiCode();
                syoninsyaList[4] = syoninsyaBeans[0].getKousinbi();
                syoninsyaList[5] = syoninsyaBeans[0].getKousinjikoku();
            }
        }
        request.setAttribute("syoninsyaList", syoninsyaList);
// 2009.09.25 Career04-05 BC0405-01-008 yoda END

		request.setAttribute("classBeans", classBeans);
		// CHG#2007/2/26 s-hiura end

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();
	}
}
