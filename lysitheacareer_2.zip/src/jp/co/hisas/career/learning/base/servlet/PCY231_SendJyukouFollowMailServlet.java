/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.mail.internet.AddressException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_KensyuMailSender;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PCY231_SendJyukouFollowMailServlet �N���X �@�\�����F
 * 
 * </PRE>
 */
public class PCY231_SendJyukouFollowMailServlet extends PCY010_ControllerServlet {
	/**
	 * �w�肳�ꂽ�e���v���[�g�̃��b�Z�[�W���쐬���܂��B �E�e���v���[�gID �E�ȖڃR�[�h �E�N���X�R�[�h
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws Exception {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		/* HTML�R�����g���擾���� */
		final String HTMLcomment = request.getParameter("HTMLcomment");

		/* �e�L�X�g�R�����g���擾���� */
		final String TEXTcomment = request.getParameter("TEXTcomment");

		/* �e���v���[�g���擾���� */
		final String templateID = request.getParameter("mail_template");

		/* ���M�Ώێ҂��擾���� */
		final String[] simei_no = request.getParameterValues("simei_no");
		final String[] index = request.getParameterValues("follow");

		final String[] kamoku_codes = new String[index.length];
		final String[] class_codes = new String[index.length];
		final PCY_ClassBean[] kensaku_classBeans = new PCY_ClassBean[index.length];

		for (int i = 0; i < index.length; i++) {
			final PCY_ClassBean kensaku_classBean = new PCY_ClassBean();
			kamoku_codes[i] = request.getParameter("kamoku_code_" + i);
			class_codes[i] = request.getParameter("class_code_" + i);
			kensaku_classBean.getKamokuBean().setKamokuCode(kamoku_codes[i]);
			kensaku_classBean.setClassCode(class_codes[i]);
			kensaku_classBeans[i] = kensaku_classBean;
		}
		/* �N���X���ڍׂ��擾 */
		final PCY_ClassEJBHome class_home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB class_ejb = class_home.create();

		Log.transaction(loginuser.getSimeiNo(), true, "");
		final PCY_ClassBean[] classBeans = class_ejb.doSelectByPrimaryKey(kensaku_classBeans, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		/* ���M����Ώێҏ����擾���� */
		/* PersonalEJB */
		final PCY_PersonalEJBHome personal_home = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
		final PCY_PersonalEJB personal_ejb = personal_home.create();
		Log.transaction(loginuser.getSimeiNo(), true, "");

		// �t�H���[���[���𑗐M����
		PCY_WarningException warn = null;
		try {
			for (int t = 0; t < index.length; t++) {
				try {
					final PCY_PersonalBean personalBean = personal_ejb.getPersonalInfo(simei_no[t], loginuser);
					final PCY_PersonalBean[] personalBeans = new PCY_PersonalBean[1];
					personalBeans[0] = personalBean;
					Log.transaction(loginuser.getSimeiNo(), false, "");
					PCY_KensyuMailSender.sendJyukoFollow(templateID, HTMLcomment, TEXTcomment, personalBeans, classBeans[t], loginuser);
				} catch (final PCY_WarningException e) {
					warn = e;
				}
			}
			if (warn != null) {
				throw warn;
			}
		} catch (final PCY_WarningException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			request.setAttribute("warningID", "WCC210");
			throw e;
		} catch (final AddressException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			request.setAttribute("warningID", "WCC220");
			throw new PCY_WarningException(e);
		} catch (final Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			request.setAttribute("warningID", "WCC220");
			throw new PCY_WarningException(e);
		}
		try {
			OutLogBean.sousaKojinJohoLog("VCC301", loginuser.getSimeiNo(), null, request.getParameter("kamoku_code_0") + "," + request.getParameter("class_code_0"));
		} catch (final Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
		}
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
