/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.base.sosiki.bean.SosikiBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_SyoninsyaBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PCY256_SearchPersonalInfoServlet �N���X �@�\�����F �����L�[�ƂȂ�p�[�\�i�������擾���������ʂ�Ԃ��܂��B
 * 
 * </PRE>
 */
public class PCY256_PersonalIchiranServlet extends PCY010_ControllerServlet {
	/**
	 * �����L�[�ƂȂ�p�[�\�i�������擾���������ʂ�Ԃ��܂��B �E�����ԍ� �E�������� �E�J�i���� �E�p�ꎁ�� �E�g�D�R�[�h�i�g�D�K�w���`�F�b�N���܂��B�j
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws Exception {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final PCY_PersonalBean kensakuPersnalBean = new PCY_PersonalBean();
		if (request.getParameter("simei_no") != null && !request.getParameter("simei_no").equals("")) {
			kensakuPersnalBean.setSimeiNo(request.getParameter("simei_no"));
		}

		if (request.getParameter("kanji_simei") != null && !request.getParameter("kanji_simei").equals("")) {
			kensakuPersnalBean.setKanjiSimei(request.getParameter("kanji_simei"));
		}

		if (request.getParameter("kana_simei") != null && !request.getParameter("kana_simei").equals("")) {
			kensakuPersnalBean.setKanaSimei(request.getParameter("kana_simei"));
		}

		if (request.getParameter("eigo_simei") != null && !request.getParameter("eigo_simei").equals("")) {
			kensakuPersnalBean.setEigoSimei(request.getParameter("eigo_simei"));
		}

		/* �g�D�R�[�h���擾���A�Ώۂ̑g�D�K�w�ɃZ�b�g���� */
		final String sosiki_kaiso_code = request.getParameter("sosiki_code");

		if (sosiki_kaiso_code != null && !sosiki_kaiso_code.equals("")) {
			final String[] sosiki_info = SosikiBean.getSosikiByCode(sosiki_kaiso_code, loginuser.getSimeiNo());

			if (sosiki_info[4].equals("1")) {
				kensakuPersnalBean.setSyozokuCode1(sosiki_kaiso_code);
			} else if (sosiki_info[4].equals("2")) {
				kensakuPersnalBean.setSyozokuCode2(sosiki_kaiso_code);
			} else if (sosiki_info[4].equals("3")) {
				kensakuPersnalBean.setSyozokuCode3(sosiki_kaiso_code);
			} else if (sosiki_info[4].equals("4")) {
				kensakuPersnalBean.setSyozokuCode4(sosiki_kaiso_code);
			} else if (sosiki_info[4].equals("5")) {
				kensakuPersnalBean.setSyozokuCode5(sosiki_kaiso_code);
			} else if (sosiki_info[4].equals("6")) {
				kensakuPersnalBean.setSyozokuCode6(sosiki_kaiso_code);
			} else if (sosiki_info[4].equals("7")) {
				kensakuPersnalBean.setSyozokuCode7(sosiki_kaiso_code);
			} else if (sosiki_info[4].equals("8")) {
				kensakuPersnalBean.setSyozokuCode8(sosiki_kaiso_code);
			} else if (sosiki_info[4].equals("9")) {
				kensakuPersnalBean.setSyozokuCode9(sosiki_kaiso_code);
			}
		}

		/* PersonalEJB */
		final PCY_PersonalEJBHome personal_home = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
		final PCY_PersonalEJB personal_ejb = personal_home.create();
		Log.transaction(loginuser.getSimeiNo(), true, "");

		final PCY_PersonalBean[] personalBeans = personal_ejb.doGensyokuSelect(kensakuPersnalBean, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");
		request.setAttribute("personalBeans", personalBeans);

		final PCY_SyoninsyaBean syoninsyaBean = new PCY_SyoninsyaBean(request);
		request.setAttribute("syoninsyaBean", syoninsyaBean);
		try {
			String simei = kensakuPersnalBean.getKanjiSimei();
			if (simei == null) {
				simei = "";
			}
			String kana = kensakuPersnalBean.getKanaSimei();
			if (kana == null) {
				kana = "";
			}
			String eigo = kensakuPersnalBean.getEigoSimei();
			if (eigo == null) {
				eigo = "";
			}
			String soshiki = kensakuPersnalBean.getSosikiCode();
			if (soshiki == null) {
				soshiki = "";
			}
			String kinouID = "";
			final String ken = request.getParameter("kensyusya");
			if (ken == null || "".equals(ken)) {
				kinouID = "VCA181";
			} else {
				kinouID = "VCC381";
			}
			OutLogBean.sousaKojinJohoLog(kinouID, loginuser.getSimeiNo(), null, kensakuPersnalBean.getSimeiNo() + "," + simei + "," + kana + "," + eigo + "," + soshiki);
		} catch (final Exception e) {
		}
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
