/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.base.sosiki.bean.SosikiBean;
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_BumonIkuseiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_BumonIkuseiEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_BumonIkuseiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY270_BumonIkuseiServlet �N���X �@�\�����F ����琬�e�[�u�����f�[�^���擾���܂��B
 * 
 * </PRE>
 */
public class PCY270_BumonIkuseiServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		/* BumonIkuseiEJB */
		final PCY_BumonIkuseiEJBHome bumonikusei_home = (PCY_BumonIkuseiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_BumonIkuseiEJBHome.class);
		final PCY_BumonIkuseiEJB bumonikusei_ejb = bumonikusei_home.create();
		final PCY_BumonIkuseiBean kensaku_bumonBean = new PCY_BumonIkuseiBean();

		/* UserInfoBean�̑g�D�R�[�h���擾����i���C���[�U�Ή��j */
		final UserInfoBean userinfo = (UserInfoBean) request.getSession().getAttribute("userinfo");
		final String sosiki_code = userinfo.getSosiki_code().trim();
		String bumonSosikiCode = SosikiBean.getSosikiCodeWithKaiso(sosiki_code, 4, loginuser.getSimeiNo());

		if (bumonSosikiCode == null) {
			bumonSosikiCode = sosiki_code;
		}

		request.setAttribute("bumonSosikiCode", bumonSosikiCode);

		kensaku_bumonBean.setSosikiCode(bumonSosikiCode);

		final PCY_BumonIkuseiBean bumonikuseiBean = bumonikusei_ejb.doSelect(kensaku_bumonBean, loginuser);

		request.setAttribute("bumonikuseiBean", bumonikuseiBean);

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
