/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_KanrenKyoikuKamokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KanrenKyoikuKamokuEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KanrenKyoikuKamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY105_CurriculumMapTourokuOpen �N���X �@�\�����F ���C���[�h�}�b�v�o�^��ʂŊ֘A���ډȖڂ̈ꗗ���J���܂��B
 * 
 * </PRE>
 */
public class PCY105_CurriculumMapTourokuOpenServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException, Exception {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		PCY_KanrenKyoikuKamokuBean[] kanrenBeans = null;
		final String kamokuCode = request.getParameter("kamoku_code");
		final PCY_KamokuBean reservedKamokuBean = (PCY_KamokuBean) request.getSession().getAttribute("reservedKamokuBean");

		if (reservedKamokuBean != null && kamokuCode.equals(reservedKamokuBean.getKamokuCode())) {
			/* �֘A���ډȖڂ��Z�b�V�����Ɋ��ɕێ����Ă����ꍇ */
			kanrenBeans = reservedKamokuBean.getKanrenKamokuBeans();
		} else {
			/* �֘A���ډȖڂ��Z�b�V�����ɕێ����Ă��Ȃ������ꍇ */

			/* �ȖڃR�[�h�d���`�F�b�N */
			if ("touroku".equals(request.getParameter("action"))) {
				/* PCY_KamokuEJB */
				final PCY_KamokuEJBHome kamoku_home = (PCY_KamokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KamokuEJBHome.class);
				final PCY_KamokuEJB kamoku_ejb = kamoku_home.create();

				if (kamoku_ejb.doCount(new String[] { kamokuCode }, loginuser) != 0) {
					request.setAttribute("warningID", "WCC180");
					throw new PCY_WarningException("WCC180");
				}
			}

			/* EJBObject�̎擾 */
			final PCY_KanrenKyoikuKamokuEJBHome home = (PCY_KanrenKyoikuKamokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KanrenKyoikuKamokuEJBHome.class);
			final PCY_KanrenKyoikuKamokuEJB ejb = home.create();

			final PCY_KamokuEJBHome komokuhome = (PCY_KamokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KamokuEJBHome.class);
			final PCY_KamokuEJB kamokuejb = komokuhome.create();

			final PCY_KamokuBean kensaku_kamokuBean = new PCY_KamokuBean(request);
			final PCY_KamokuBean[] kamokuBean = kamokuejb.doSelect(kensaku_kamokuBean, loginuser);

			/* EJB�Ăяo�� */
			request.getSession().setAttribute("kamokuBean", kamokuBean);

			Log.transaction(loginuser.getSimeiNo(), true, "");
			kanrenBeans = ejb.doSelectByKamokuCode(kamokuCode, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");
		}

		request.getSession().setAttribute("kanrenBeans", kanrenBeans);

		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
