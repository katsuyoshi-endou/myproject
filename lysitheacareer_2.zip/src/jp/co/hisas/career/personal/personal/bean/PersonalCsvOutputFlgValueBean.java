package jp.co.hisas.career.personal.personal.bean;

import jp.co.hisas.career.personal.util.CsvValueBean;

public class PersonalCsvOutputFlgValueBean extends CsvValueBean {
	/** ����NO �\���t���O */
	private String shimeiNo_output = null;

	/** �O���[�vNO �\���t���O */
	private String groupNo_output = null;

	/** �������� �\���t���O */
	private String shimeiKanji_output = null;

	/** �����J�i �\���t���O */
	private String shimeiKana_output = null;

	/** �����p�� �\���t���O */
	private String shimeiEiji_output = null;

	/** ���ДN���� �\���t���O */
	private String nyushaNengappi_output = null;

	/** ����PR �\���t���O */
	private String jikoPR_output = null;

	/** ���� �\���t���O */
	private String shozoku_output = null;

	/** ���� �\���t���O */
	private String busho_output = null;

	/** ��E �\���t���O */
	private String yakushoku_output = null;

	/** �O�� �\���t���O */
	private String gaisen_output = null;

	/** ���� �\���t���O */
	private String naisen_output = null;

	/** FAX �\���t���O */
	private String fax_output = null;

	/** MAIL �\���t���O */
	private String mail_output = null;

	/** �E�� �\���t���O */
	private String shokui_output = null;

	/** ���� �\���t���O */
	private String seibetsu_output = null;

	/** ���N���� �\���t���O */
	private String seinengappi_output = null;

	/** Job �\���t���O */
	private String job_output = null;

	/** Supervisor �\���t���O */
	private String supervisor_output = null;

	/** �A�Z�X�����g���� �\���t���O */
	private String assessment_output = null;

	public String getAssessment_output() {
		return assessment_output;
	}

	public void setAssessment_output(String assessment_output) {
		this.assessment_output = assessment_output;
	}

	public String getBusho_output() {
		return busho_output;
	}

	public void setBusho_output(String busho_output) {
		this.busho_output = busho_output;
	}

	public String getFax_output() {
		return fax_output;
	}

	public void setFax_output(String fax_output) {
		this.fax_output = fax_output;
	}

	public String getGaisen_output() {
		return gaisen_output;
	}

	public void setGaisen_output(String gaisen_output) {
		this.gaisen_output = gaisen_output;
	}

	public String getGroupNo_output() {
		return groupNo_output;
	}

	public void setGroupNo_output(String groupNo_output) {
		this.groupNo_output = groupNo_output;
	}

	public String getJikoPR_output() {
		return jikoPR_output;
	}

	public void setJikoPR_output(String jikoPR_output) {
		this.jikoPR_output = jikoPR_output;
	}

	public String getJob_output() {
		return job_output;
	}

	public void setJob_output(String job_output) {
		this.job_output = job_output;
	}

	public String getMail_output() {
		return mail_output;
	}

	public void setMail_output(String mail_output) {
		this.mail_output = mail_output;
	}

	public String getNaisen_output() {
		return naisen_output;
	}

	public void setNaisen_output(String naisen_output) {
		this.naisen_output = naisen_output;
	}

	public String getNyushaNengappi_output() {
		return nyushaNengappi_output;
	}

	public void setNyushaNengappi_output(String nyushaNengappi_output) {
		this.nyushaNengappi_output = nyushaNengappi_output;
	}

	public String getSeibetsu_output() {
		return seibetsu_output;
	}

	public void setSeibetsu_output(String seibetsu_output) {
		this.seibetsu_output = seibetsu_output;
	}

	public String getSeinengappi_output() {
		return seinengappi_output;
	}

	public void setSeinengappi_output(String seinengappi_output) {
		this.seinengappi_output = seinengappi_output;
	}

	public String getShimeiEiji_output() {
		return shimeiEiji_output;
	}

	public void setShimeiEiji_output(String shimeiEiji_output) {
		this.shimeiEiji_output = shimeiEiji_output;
	}

	public String getShimeiKana_output() {
		return shimeiKana_output;
	}

	public void setShimeiKana_output(String shimeiKana_output) {
		this.shimeiKana_output = shimeiKana_output;
	}

	public String getShimeiKanji_output() {
		return shimeiKanji_output;
	}

	public void setShimeiKanji_output(String shimeiKanji_output) {
		this.shimeiKanji_output = shimeiKanji_output;
	}

	public String getShimeiNo_output() {
		return shimeiNo_output;
	}

	public void setShimeiNo_output(String shimeiNo_output) {
		this.shimeiNo_output = shimeiNo_output;
	}

	public String getShokui_output() {
		return shokui_output;
	}

	public void setShokui_output(String shokui_output) {
		this.shokui_output = shokui_output;
	}

	public String getShozoku_output() {
		return shozoku_output;
	}

	public void setShozoku_output(String shozoku_output) {
		this.shozoku_output = shozoku_output;
	}

	public String getSupervisor_output() {
		return supervisor_output;
	}

	public void setSupervisor_output(String supervisor_output) {
		this.supervisor_output = supervisor_output;
	}

	public String getYakushoku_output() {
		return yakushoku_output;
	}

	public void setYakushoku_output(String yakushoku_output) {
		this.yakushoku_output = yakushoku_output;
	}


}
