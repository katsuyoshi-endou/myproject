package jp.co.hisas.career.personal.personal.bean;

public class PersonalCsvAssessmentValueBean {

	/** �E�� */
	private String shokushu = null;
	
	/** ��啪�� */
	private String senmonbunya  = null;
	
	/** ���x�� */
	private String level = null;
	
	/** �����B���x */
	private String sogoTasaeido = null;

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getSenmonbunya() {
		return senmonbunya;
	}

	public void setSenmonbunya(String senmonbunya) {
		this.senmonbunya = senmonbunya;
	}

	public String getShokushu() {
		return shokushu;
	}

	public void setShokushu(String shokushu) {
		this.shokushu = shokushu;
	}

	public String getSogoTasaeido() {
		return sogoTasaeido;
	}

	public void setSogoTasaeido(String sogoTasaeido) {
		this.sogoTasaeido = sogoTasaeido;
	}	
}
