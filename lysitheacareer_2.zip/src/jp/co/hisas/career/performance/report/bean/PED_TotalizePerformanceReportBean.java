/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.report.bean;

import java.util.ArrayList;
import java.util.HashMap;

import javax.naming.NamingException;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.performance.report.ejb.PED_TotalizePerformanceReportEJB;
import jp.co.hisas.career.performance.report.ejb.PED_TotalizePerformanceReportEJBHome;
import jp.co.hisas.career.performance.util.ejb.PED_StoredProcedureUtilityEJB;
import jp.co.hisas.career.performance.util.ejb.PED_StoredProcedureUtilityEJBHome;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �W�v�������C�����W�b�N
 * @author Kobayashi
 */
public class PED_TotalizePerformanceReportBean {

	/** �W�v����PL/SQL */
	private static final String SHUKEI_SQL = "{? = call PVE_TOTALIZE_REPORT.F_PVE_TOTALIZE_REPORT_MAIN(?)}";

	/** �W�v�������PL/SQL */
	private static final String SHUKEI_TORIKESHI_SQL = "{? = call PVE_TOTALIZE_TORIKESHI.F_PVE_TORIKESHI_MAIN(?)}";

	/** ���[�_�[�ݒ�PL/SQL */
	private static final String LEADER_SQL = "{? = call PVE_LEADER_SETTEI.F_PVE_LEADER_SETTEI_MAIN(?)}";

	/** �G���[�`�F�b�NPL/SQL */
	private static final String CHECK_SQL = "{? = call PVE_ERROR_CHECK.F_PVE_ERROR_CHECK_MAIN(?)}";

	/** �o�b�`������� */
	private static final String TYPE_LEADER = "Leader";

	private static final String TYPE_ERROR = "ErrorCheck";

	private static final String TYPE_SHUKEI = "Shukei";

	private static final String TYPE_TORIKESHI = "ShukeiTorikeshi";

	/** �o�b�`�Ǘ��X�e�[�^�X 1 : �J�n 0:�I�� */
	private static final String START_BATCH = "1";

	private static final String END_BATCH = "0";

	/**
	 * �������擾����
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @return List �����ꗗ
	 */
	public ArrayList getShozoku(final String loginNo, final String enqueteNo) throws NamingException, Exception {
		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_TotalizePerformanceReportEJBHome my_home = (PED_TotalizePerformanceReportEJBHome) EJBHomeFactory.getInstance().lookup(PED_TotalizePerformanceReportEJBHome.class);
		final PED_TotalizePerformanceReportEJB userSession = my_home.create();

		Log.transaction(loginNo, false, "");
		return userSession.getShozoku(loginNo, enqueteNo);

	}

	/**
	 * �g�D�R�[�h�Ń\�[�g
	 * @param loginNo ���O�C���ԍ�
	 * @param choiceSoshikiID �I�������g�DID
	 * @param euqueteNo �A���P�[�g�ԍ�
	 * @return
	 */
	public ArrayList getShozokuSort(final String loginNo, final ArrayList choiceSoshikiID, final String euqueteNo) throws NamingException, Exception {
		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_TotalizePerformanceReportEJBHome my_home = (PED_TotalizePerformanceReportEJBHome) EJBHomeFactory.getInstance().lookup(PED_TotalizePerformanceReportEJBHome.class);
		final PED_TotalizePerformanceReportEJB userSession = my_home.create();
		Log.transaction(loginNo, false, "");
		return userSession.getShozokuSort(loginNo, choiceSoshikiID, euqueteNo);
	}

	/**
	 * �A���P�[�g�ԍ����w�肵�āA��Ԏ擾
	 * @param loginNo ���O�C���ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @param sessionNo �Z�b�V�����ԍ�
	 * @return ���
	 */
	public HashMap getEnqueteStatus(final String loginNo, final String enqueteNo, final String sessionNo) throws NamingException, Exception {

		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_TotalizePerformanceReportEJBHome my_home = (PED_TotalizePerformanceReportEJBHome) EJBHomeFactory.getInstance().lookup(PED_TotalizePerformanceReportEJBHome.class);
		final PED_TotalizePerformanceReportEJB userSession = my_home.create();
		Log.transaction(loginNo, false, "");
		final HashMap map = userSession.getEnqueteStatus(loginNo, enqueteNo, sessionNo);
		// ���[�_�[�G���[CSV�o�͕\������

		String leaderStatus = "";
		if (((Boolean) map.get("preLeaderErrorFlg")).booleanValue()) {
			leaderStatus = ((Boolean) map.get("leaderErrorFlg")).booleanValue() ? (String) ReadFile.paramMapData.get("DED090") : (String) ReadFile.paramMapData.get("DED089");
		} else {
			leaderStatus = (String) ReadFile.paramMapData.get("DED088");
		}

		map.put("isErrorCheckCsv", new Boolean(((String) map.get("errorCheckStatusNo")).equals("1")));
		map.put("isLeaderErrorCsv", new Boolean(((Boolean) map.get("preLeaderErrorFlg")).booleanValue() && ((Boolean) map.get("leaderErrorFlg")).booleanValue()));
		map.put("isShukeiErrorCsv", new Boolean(((Boolean) map.get("preShukeiErrorFlg")).booleanValue() && ((Boolean) map.get("shukeiErrorFlg")).booleanValue()));
		map.put("leaderStatus", leaderStatus);
		return map;
	}

	/**
	 * �W�v���s
	 * @param loginNo ���O�C���ԍ�
	 * @param sesionNo �Z�b�V�����ԍ�
	 * @param paramList �p�����[�^���X�g
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @return ���
	 */
	public int executeShukei(final String loginNo, final String sessionNo, final ArrayList paramList, final String enqueteNo) throws NamingException, Exception {

		final String msgFileName = (String) ReadFile.fileMapData.get(HcdbDef.msgCode);

		// �����쐬
		/*
		 * ��s�ځFsessionNo,�p�t�H�[�}���X�]�[������̊�l,�g�D�U��΂�
		 */
		int size = paramList.size();
		if (size < 4) {
			size = 4;
		}
		final String[] args02 = new String[size];

		for (int i = 0; i < size; i++) {
			try {
				final HashMap map = (HashMap) paramList.get(i);
				args02[i] = (String) map.get("id");
			} catch (final Exception e) {
				args02[i] = "";
			}
		}
		final String[] args01 = new String[size];
		final String[] args03 = new String[size];
		final String[] args04 = new String[size];
		final String[] args05 = new String[size];
		final String[] args06 = new String[size];
		final String[] args07 = new String[size];
		final String[] args08 = new String[size];
		final String[] args09 = new String[size];
		final String[] args10 = new String[size];

		// args01
		args01[0] = enqueteNo;
		args01[1] = (String) ReadFile.fileMapData.get("PERFORMANCE_BNHIGH_Y");
		args01[2] = (String) ReadFile.fileMapData.get("PERFORMANCE_CNHIGH_X");
		for (int i = 3; i < args01.length; i++) {
			args01[i] = "";
		}
		// args03
		args03[0] = (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E005");
		args03[1] = (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E010");
		args03[2] = (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E060");
		args03[3] = (String) ReadFile.fileMapData.get("PERFORMANCE_BNLOW_Y");
		for (int i = 4; i < args03.length; i++) {
			args03[i] = "";
		}
		// args04
		args04[0] = (String) ReadFile.fileMapData.get("PERFORMANCE_WMZONE_A_X");
		args04[1] = (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E015");
		args04[2] = (String) ReadFile.fileMapData.get("PERFORMANCE_SIGN_FIG_AVG");
		args04[3] = (String) ReadFile.fileMapData.get("PERFORMANCE_CNLOW_X");
		for (int i = 4; i < args04.length; i++) {
			args04[i] = "";
		}

		// args05
		args05[0] = (String) ReadFile.fileMapData.get("PERFORMANCE_WMZONE_A_Y");
		args05[1] = (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E016");
		args05[2] = (String) ReadFile.fileMapData.get("PERFORMANCE_SIGN_FIG_STD");
		for (int i = 3; i < args05.length; i++) {
			args05[i] = "";
		}

		// args06
		args06[0] = (String) ReadFile.fileMapData.get("PERFORMANCE_WMZONE_B_X");
		args06[1] = (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E018");
		args06[2] = (String) ReadFile.fileMapData.get("PERFORMANCE_SIGN_FIG_SUM");
		for (int i = 3; i < args06.length; i++) {
			args06[i] = "";
		}

		// args07
		args07[0] = (String) ReadFile.fileMapData.get("PERFORMANCE_WMZONE_B_Y");
		args07[1] = (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E019");
		args07[2] = (String) ReadFile.fileMapData.get("PERFORMANCE_SIGN_FIG_RATIO");
		for (int i = 3; i < args07.length; i++) {
			args07[i] = "";
		}

		// args08
		args08[0] = (String) ReadFile.fileMapData.get("PERFORMANCE_WMZONE_D_X");
		args08[1] = (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E021");
		args08[2] = (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E011");
		for (int i = 3; i < args08.length; i++) {
			args08[i] = "";
		}

		// args09
		args09[0] = (String) ReadFile.fileMapData.get("PERFORMANCE_WMZONE_D_Y");
		args09[1] = (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E022");
		args09[2] = (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E012");
		for (int i = 3; i < args09.length; i++) {
			args09[i] = "";
		}

		// args10
		args10[0] = (String) ReadFile.fileMapData.get("PERFORMANCE_STD_SCATTERD");
		args10[1] = (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E013");
		args10[2] = (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E061");
		for (int i = 3; i < args10.length; i++) {
			args10[i] = "";
		}

		// �������X�g�Ɋi�[
		final ArrayList argsList = new ArrayList();

		argsList.add(args01);
		argsList.add(args02);
		argsList.add(args03);
		argsList.add(args04);
		argsList.add(args05);
		argsList.add(args06);
		argsList.add(args07);
		argsList.add(args08);
		argsList.add(args09);
		argsList.add(args10);
		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_StoredProcedureUtilityEJBHome my_home = (PED_StoredProcedureUtilityEJBHome) EJBHomeFactory.getInstance().lookup(PED_StoredProcedureUtilityEJBHome.class);
		final PED_StoredProcedureUtilityEJB userSessionTmp = my_home.create();

		final PED_TotalizePerformanceReportBeanThread thread = new PED_TotalizePerformanceReportBeanThread();
		PED_TotalizePerformanceReportBeanThread.execute(loginNo, sessionNo, argsList, enqueteNo, userSessionTmp, PED_TotalizePerformanceReportBean.SHUKEI_SQL,
				PED_TotalizePerformanceReportBean.TYPE_SHUKEI);
		Log.transaction(loginNo, false, "");
		return 0;
	}

	/**
	 * ���[�_�[�ݒ�
	 * @param loginNo ���O�C���ԍ�
	 * @param sesionNo �Z�b�V�����ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @return ����
	 */
	public int executeLeader(final String loginNo, final String sessionNo, final String enqueteNo, boolean auto) throws NamingException, Exception {

		final String msgFileName = (String) ReadFile.fileMapData.get(HcdbDef.msgCode);
		int autoCheck = 1;
		if (!auto) {
			autoCheck = 0;
		}
		// �����쐬
		final String[] args01 = new String[] { loginNo };
		final String[] args02 = new String[] { enqueteNo };
		final String[] args03 = new String[] { (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E005") };
		final String[] args04 = new String[] { (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E006") };
		final String[] args05 = new String[] { (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E007") };
		final String[] args06 = new String[] { (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E008") };
		final String[] args07 = new String[] { (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E009") };
		final String[] args08 = new String[] { String.valueOf(autoCheck) };
		final String[] args09 = new String[] { "" };
		final String[] args10 = new String[] { "" };

		// �������X�g�Ɋi�[
		final ArrayList argsList = new ArrayList();

		argsList.add(args01);
		argsList.add(args02);
		argsList.add(args03);
		argsList.add(args04);
		argsList.add(args05);
		argsList.add(args06);
		argsList.add(args07);
		argsList.add(args08);
		argsList.add(args09);
		argsList.add(args10);

		Log.transaction(loginNo, true, "");
		// EJB�擾
		final PED_StoredProcedureUtilityEJBHome my_home = (PED_StoredProcedureUtilityEJBHome) EJBHomeFactory.getInstance().lookup(PED_StoredProcedureUtilityEJBHome.class);
		final PED_StoredProcedureUtilityEJB userSessionTmp = my_home.create();

		final PED_TotalizePerformanceReportBeanThread thread = new PED_TotalizePerformanceReportBeanThread();
		PED_TotalizePerformanceReportBeanThread.execute(loginNo, sessionNo, argsList, enqueteNo, userSessionTmp, PED_TotalizePerformanceReportBean.LEADER_SQL,
				PED_TotalizePerformanceReportBean.TYPE_LEADER);
		Log.transaction(loginNo, false, "");
		return 0;
	}

	/**
	 * �G���[�`�F�b�N���s
	 * @param loginNo ���O�C���ԍ�
	 * @param sesionNo �Z�b�V�����ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @return ����
	 */
	public int executeErrorCheck(final String loginNo, final String sessionNo, final String enqueteNo) throws NamingException, Exception {

		final String msgFileName = (String) ReadFile.fileMapData.get(HcdbDef.msgCode);

		// �����쐬
		final String[] args01 = new String[] { loginNo };
		final String[] args02 = new String[] { enqueteNo };
		final String[] args03 = new String[] { (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E010") };
		final String[] args04 = new String[] { (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E011") };
		final String[] args05 = new String[] { (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E012") };
		final String[] args06 = new String[] { (String) ReadFile.getMsgMapData(msgFileName).get("CPM-VED150-E013") };
		final String[] args07 = new String[] { "" };
		final String[] args08 = new String[] { "" };
		final String[] args09 = new String[] { "" };
		final String[] args10 = new String[] { "" };

		// �������X�g�Ɋi�[
		final ArrayList argsList = new ArrayList();

		argsList.add(args01);
		argsList.add(args02);
		argsList.add(args03);
		argsList.add(args04);
		argsList.add(args05);
		argsList.add(args06);
		argsList.add(args07);
		argsList.add(args08);
		argsList.add(args09);
		argsList.add(args10);

		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_StoredProcedureUtilityEJBHome my_home = (PED_StoredProcedureUtilityEJBHome) EJBHomeFactory.getInstance().lookup(PED_StoredProcedureUtilityEJBHome.class);
		final PED_StoredProcedureUtilityEJB userSessionTmp = my_home.create();
		final PED_TotalizePerformanceReportBeanThread thread = new PED_TotalizePerformanceReportBeanThread();
		PED_TotalizePerformanceReportBeanThread.execute(loginNo, sessionNo, argsList, enqueteNo, userSessionTmp, PED_TotalizePerformanceReportBean.CHECK_SQL,
				PED_TotalizePerformanceReportBean.TYPE_ERROR);
		Log.transaction(loginNo, false, "");
		return 0;
	}

	/**
	 * �W�v������s
	 * @param loginNo ���O�C���ԍ�
	 * @param sesionNo �Z�b�V�����ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @return ����
	 */
	public int executeShukeiTorikeshi(final String loginNo, final String sessionNo, final String enqueteNo) throws NamingException, Exception {

		final String msgFileName = (String) ReadFile.fileMapData.get(HcdbDef.msgCode);

		// �����쐬
		final String[] args01 = new String[] { enqueteNo };
		final String[] args02 = new String[] { "" };
		final String[] args03 = new String[] { "" };
		final String[] args04 = new String[] { "" };
		final String[] args05 = new String[] { "" };
		final String[] args06 = new String[] { "" };
		final String[] args07 = new String[] { "" };
		final String[] args08 = new String[] { "" };
		final String[] args09 = new String[] { "" };
		final String[] args10 = new String[] { "" };

		// �������X�g�Ɋi�[
		final ArrayList argsList = new ArrayList();

		argsList.add(args01);
		argsList.add(args02);
		argsList.add(args03);
		argsList.add(args04);
		argsList.add(args05);
		argsList.add(args06);
		argsList.add(args07);
		argsList.add(args08);
		argsList.add(args09);
		argsList.add(args10);

		Log.transaction(loginNo, true, "");
		// EJB�擾
		final PED_StoredProcedureUtilityEJBHome my_home = (PED_StoredProcedureUtilityEJBHome) EJBHomeFactory.getInstance().lookup(PED_StoredProcedureUtilityEJBHome.class);
		final PED_StoredProcedureUtilityEJB userSessionTmp = my_home.create();

		final PED_TotalizePerformanceReportBeanThread thread = new PED_TotalizePerformanceReportBeanThread();
		PED_TotalizePerformanceReportBeanThread.execute(loginNo, sessionNo, argsList, enqueteNo, userSessionTmp, PED_TotalizePerformanceReportBean.SHUKEI_TORIKESHI_SQL,
				PED_TotalizePerformanceReportBean.TYPE_TORIKESHI);
		Log.transaction(loginNo, false, "");
		return 0;
	}

	/**
	 * PDF�쐬���s
	 * @param loginNo ���O�C���ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @param paramList �g�DID���X�g
	 * @throws NamingException
	 * @throws Exception
	 */
	public void makeReportPDF(final String loginNo, final String sessionNo, final String enqueteNo, final String enqueteNm, final ArrayList groupIDList, final String type) throws NamingException,
			Exception {

		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_TotalizePerformanceReportEJBHome my_home = (PED_TotalizePerformanceReportEJBHome) EJBHomeFactory.getInstance().lookup(PED_TotalizePerformanceReportEJBHome.class);
		final PED_TotalizePerformanceReportEJB userSessionTmp = my_home.create();

		final PED_TotalizePerformanceReportPDFThread thread = new PED_TotalizePerformanceReportPDFThread();

		PED_TotalizePerformanceReportPDFThread.execute(loginNo, sessionNo, enqueteNo, enqueteNm, groupIDList, userSessionTmp);
		Log.transaction(loginNo, false, "");
	}

	/**
	 * �o�b�`�������s���̃X�e�[�^�X�ύX
	 * @param loginNo ���O�C���ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @param type ���
	 * @throws NamingException
	 * @throws Exception
	 */
	public void createBatchStatusStart(final String loginNo, final String enqueteNo, final String type) throws NamingException, Exception {

		Log.transaction(loginNo, true, "");
		// EJB�擾
		final PED_TotalizePerformanceReportEJBHome my_home = (PED_TotalizePerformanceReportEJBHome) EJBHomeFactory.getInstance().lookup(PED_TotalizePerformanceReportEJBHome.class);
		final PED_TotalizePerformanceReportEJB userSession = my_home.create();

		Log.transaction(loginNo, false, "");
		userSession.createBatchStatus(loginNo, enqueteNo, type, PED_TotalizePerformanceReportBean.START_BATCH);
		Log.transaction(loginNo, false, "");
	}

	/**
	 * �o�b�`�����I�����̃X�e�[�^�X�ύX
	 * @param loginNo ���O�C���ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @param type ���
	 * @throws NamingException
	 * @throws Exception
	 */
	public void createBatchStatusEnd(final String loginNo, final String enqueteNo, final String type) throws NamingException, Exception {

		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_TotalizePerformanceReportEJBHome my_home = (PED_TotalizePerformanceReportEJBHome) EJBHomeFactory.getInstance().lookup(PED_TotalizePerformanceReportEJBHome.class);
		final PED_TotalizePerformanceReportEJB userSession = my_home.create();

		Log.transaction(loginNo, false, "");
		userSession.createBatchStatus(loginNo, enqueteNo, type, PED_TotalizePerformanceReportBean.END_BATCH);
		Log.transaction(loginNo, false, "");
	}

	/**
	 * �o�b�`���������s����Ă��邩�X�e�[�^�X�擾
	 * @param loginNo ���O�C���ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @param paramList �g�DID
	 * @throws NamingException
	 * @throws Exception
	 */
	public boolean isShukeiTorikesiDoing(final String loginNo, final String enqueteNo, final String paramList) throws NamingException, Exception {

		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_TotalizePerformanceReportEJBHome my_home = (PED_TotalizePerformanceReportEJBHome) EJBHomeFactory.getInstance().lookup(PED_TotalizePerformanceReportEJBHome.class);
		final PED_TotalizePerformanceReportEJB userSession = my_home.create();

		// �����s�̏ꍇfalse��Ԃ�
		if (!userSession.isBatchKanri(loginNo, enqueteNo, paramList)) {
			return false;
		}
		return true;

	}

	/**
	 * �o�b�`���������s����Ă��邩�X�e�[�^�X�擾
	 * @param loginNo ���O�C���ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @param type ���
	 * @throws NamingException
	 * @throws Exception
	 */
	public boolean isBatch(final String loginNo, final String enqueteNo, final String type) throws NamingException, Exception {

		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_TotalizePerformanceReportEJBHome my_home = (PED_TotalizePerformanceReportEJBHome) EJBHomeFactory.getInstance().lookup(PED_TotalizePerformanceReportEJBHome.class);
		final PED_TotalizePerformanceReportEJB userSession = my_home.create();
		Log.transaction(loginNo, false, "");

		final boolean isBatchLeader = userSession.isBatchKanri(loginNo, enqueteNo, type);

		return isBatchLeader;
	}

	/**
	 * �A���P�[�g�ԍ��ɕR�t���S�ẴX�e�[�^�X���擾
	 * @param loginNo ���O�C���ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @param type ���
	 * @throws NamingException
	 * @throws Exception
	 */
	public String isBatchAll(final String loginNo, final String enqueteNo, final String[] type) throws NamingException, Exception {

		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_TotalizePerformanceReportEJBHome my_home = (PED_TotalizePerformanceReportEJBHome) EJBHomeFactory.getInstance().lookup(PED_TotalizePerformanceReportEJBHome.class);
		final PED_TotalizePerformanceReportEJB userSession = my_home.create();
		Log.transaction(loginNo, false, "");
		final String isBatchLeader = userSession.isBatchKanriAll(loginNo, enqueteNo, type);

		return isBatchLeader;
	}

	/**
	 * ��O���̃o�b�`�Ǘ��e�[�u���폜
	 * @param loginNo ���O�C���ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @param type ���
	 * @throws NamingException
	 * @throws Exception
	 */
	public boolean delBatch(final String loginNo, final String enqueteNo, final String type) throws NamingException, Exception {

		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_TotalizePerformanceReportEJBHome my_home = (PED_TotalizePerformanceReportEJBHome) EJBHomeFactory.getInstance().lookup(PED_TotalizePerformanceReportEJBHome.class);
		final PED_TotalizePerformanceReportEJB userSession = my_home.create();

		Log.transaction(loginNo, false, "");
		final boolean isBatchLeader = userSession.delBatchKanri(loginNo, enqueteNo, type);

		return isBatchLeader;
	}

	/**
	 * ��ʂ��w�肵��CSV�_�E�����[�h�̕\�������l�����߂�
	 * @param loginNo ���O�C���ԍ�
	 * @param type ���
	 * @return boolean
	 */
	public boolean isBatchError(final String enqueteNo, final String loginNo, final String type, final String sessionID) throws NamingException, Exception {

		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_TotalizePerformanceReportEJBHome my_home = (PED_TotalizePerformanceReportEJBHome) EJBHomeFactory.getInstance().lookup(PED_TotalizePerformanceReportEJBHome.class);
		final PED_TotalizePerformanceReportEJB userSession = my_home.create();
		Log.transaction(loginNo, false, "");
		return userSession.isBatchError(enqueteNo, loginNo, type, sessionID);

	}

	/**
	 * �G���[CSV���_�E�����[�h����
	 * @param loginNo ���O�C���ԍ�
	 * @param sessionNo �Z�b�V����No
	 * @param types �_�E�����[�h�Ώ�
	 * @return
	 * @throws NamingException
	 * @throws Exception
	 */
	public String errorCsvDownload(final String enqueteNo, final String loginNo, final String sessionNo, final String[] types) throws NamingException, Exception {

		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_TotalizePerformanceReportEJBHome my_home = (PED_TotalizePerformanceReportEJBHome) EJBHomeFactory.getInstance().lookup(PED_TotalizePerformanceReportEJBHome.class);
		final PED_TotalizePerformanceReportEJB userSession = my_home.create();

		Log.transaction(loginNo, false, "");
		return userSession.errorCsvDownload(enqueteNo, loginNo, sessionNo, types);
	}

	/**
	 * �G���[CSV���폜����
	 * @param loginNo ���O�C���ԍ�
	 * @param sessionNo �Z�b�V����No
	 * @param types �폜�Ώ�
	 * @return
	 * @throws NamingException
	 * @throws Exception
	 */
	public void deleteTextOutput(final String loginNo, final String sessionNo, final String[] types) throws NamingException, Exception {

		Log.transaction(loginNo, true, "");

		// EJB�擾
		final PED_TotalizePerformanceReportEJBHome my_home = (PED_TotalizePerformanceReportEJBHome) EJBHomeFactory.getInstance().lookup(PED_TotalizePerformanceReportEJBHome.class);
		final PED_TotalizePerformanceReportEJB userSession = my_home.create();

		Log.transaction(loginNo, false, "");
		userSession.deleteTextOutput(null, loginNo, sessionNo, types);
	}

}
