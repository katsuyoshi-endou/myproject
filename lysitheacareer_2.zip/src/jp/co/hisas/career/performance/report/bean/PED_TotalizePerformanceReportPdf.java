/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.report.bean;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;

import jp.co.hisas.career.performance.report.bean.PED_ReportSoshikiValueBean.BusinessMind;
import jp.co.hisas.career.performance.report.bean.PED_ReportSoshikiValueBean.LeaderTraits;
import jp.co.hisas.career.performance.report.bean.PED_ReportSoshikiValueBean.MetaCompetency;
import jp.co.hisas.career.performance.report.bean.PED_ReportSoshikiValueBean.SoshikiManzoku;
import jp.co.hisas.career.performance.report.bean.PED_ReportSoshikiValueBean.TeamCondition;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.property.ReadFile;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.XYLineAnnotation;
import org.jfree.chart.annotations.XYTextAnnotation;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.axis.TickUnits;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.StandardXYItemLabelGenerator;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.TextAnchor;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.FontMapper;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class PED_TotalizePerformanceReportPdf {

	// �A���P�[�g���̃��x��
	private String msgDED005;

	// �Ώۑg�D���x��
	private String msgDED048;

	// �W�v�������x��
	private String msgDED049;

	// �W�v�l�����x��
	private String msgDED050;

	// �l���x��
	private String msgDZZ622;

	// ���|�[�g����(�`�[���R���f�B�V����)
	private String msgDED051;

	// ����A�]�[�����x��
	private String msgDED052;

	// ����B�]�[�����x��
	private String msgDED053;

	// ����C�]�[�����x��
	private String msgDED054;

	// ����D�]�[�����x��
	private String msgDED055;

	// ���|�[�g����(�r�W�l�X�}�C���h)
	private String msgDED071;

	// �����l�������x��
	private String msgDED072;

	// �����l���胉�x��
	private String msgDED073;

	// �����g�D���胉�x��
	private String msgDED074;

	// �����g�D�������x��
	private String msgDED075;

	// ���|�[�g����(���[�_�V�b�v)
	private String msgDED084;

	// �g�D�^�C�v�������x��
	private String msgDED056;

	// ���̃}�b�v�̌������x��
	private String msgDED057;

	// ���̃}�b�v�̌������x���e�L�X�g(�`�[���R���f�B�V����)
	private String msgAED025;

	// ���̃}�b�v�̌������x���e�L�X�g(�r�W�l�X�}�C���h)
	private String msgAED026;

	// ���̃}�b�v�̌������x���e�L�X�g(���[�_�V�b�v)
	private String msgAED027;

	// �v���b�g�̐������x��
	private String msgDED058;

	// �}�� ��P�K�w���x��
	private String msgDED059;

	// �}�� ��Q�K�w���x��
	private String msgDED060;

	// �}�� ��R�K�w���x��
	private String msgDED061;

	// �}�� ��S�K�w���x��
	private String msgDED062;

	// �}�� ��T�K�w���x��
	private String msgDED063;

	// �}�� ��U�K�w���x��
	private String msgDED064;

	// �c�����x���i�`�[���R���f�B�V�����j
	private String msgDED065;

	// �������x���i�`�[���R���f�B�V�����j
	private String msgDED066;

	// A�]�[�����x���i�`�[���R���f�B�V����,���[�_�����j
	private String msgDED067;

	// B�]�[�����x���i�`�[���R���f�B�V����,���[�_�����j
	private String msgDED068;

	// C�]�[�����x���i�`�[���R���f�B�V����,���[�_�����j
	private String msgDED069;

	// D�]�[�����x���i�`�[���R���f�B�V����,���[�_�����j
	private String msgDED070;

	// �o�����X
	private String msgDED181;

	// �r�W�l�X���i
	private String msgDED182;

	// �֌W�\�z
	private String msgDED183;

	// �j���[�g����
	private String msgDED184;

	// ���C
	private String msgDED185;

	// �o�����X �U�z�}
	private String msgDED186;

	// �r�W�l�X���i �U�z�}
	private String msgDED187;

	// �֌W�\�z �U�z�}
	private String msgDED188;

	// �j���[�g���� �U�z�}
	private String msgDED189;

	// ���C �U�z�}
	private String msgDED190;

	// �l���x��
	private String msgDED076;

	// �g�D���x��
	private String msgDED077;

	// ���胉�x��
	private String msgDED078;

	// �������x��
	private String msgDED079;

	// �l���胉�x��
	private String msgDED081;

	// �l�������x��
	private String msgDED080;

	// �g�D���胉�x��
	private String msgDED082;

	// �g�D�������x��
	private String msgDED083;

	// �c�����x���i���[�_�����j
	private String msgDED085;

	// �������x���i���[�_�����j
	private String msgDED086;

	// ���|�[�g���́i�g�D�����x�����j
	private String msgDED097;

	// �\�ɂ��ă��x��
	private String msgDED099;

	// �}�჉�x��
	private String msgDED100;

	// ���ɖ������x��
	private String msgDED101;

	// �������x��
	private String msgDED102;

	// �s�������x��
	private String msgDED103;

	// ���ɕs�������x��
	private String msgDED104;

	private String msgDED105;

	private String msgDED106;

	private String msgDED107;

	private String msgDED158;

	private String msgDED159;

	private String msgDED160;

	private String msgDED161;

	private String msgDED162;

	private String msgDED163;

	private String msgDED164;

	private String msgDED165;

	private String msgDED166;

	private String msgDED167;

	private String msgDED168;

	private String msgDED169;

	private String msgDED170;

	private String msgDED171;

	private String msgDED172;

	private String msgDED173;

	private String msgDED174;

	private String msgDED175;

	private String msgDED176;

	private String msgDED177;

	private String msgDED178;

	private String msgDED179;

	private String msgDED180;

	// �\�ɂ��ăe�L�X�g
	private String msgAED028;

	// �g�D�����x���� �啪�ރ��x�����X�g
	private final ArrayList msgSMListL = new ArrayList();

	// �g�D�����x���� �����ރ��x�����X�g
	private final ArrayList msgSMListS = new ArrayList();

	// �g�D�̃��^�R���s�e���V�[
	private String msgDED098;

	// �g�D�̃��^�R���s�e���V�[
	private String msgAED029;

	// ���^�R���s�e���V�[���ڐ����e�L�X�g
	private String msgAED030;

	private String msgAED031;

	private String msgAED032;

	private String msgAED033;

	private String msgAED034;

	private String msgAED035;

	private String msgAED036;

	private String msgAED037;

	private String msgAED038;

	private String msgAED039;

	private String msgAED040;

	private String msgAED041;

	private String msgAED042;

	private String msgAED043;

	private String msgAED044;

	private String msgAED045;

	// �]�[��A����
	private String wmzoneAX;

	// �]�[��A�c��
	private String wmzoneAY;

	// �]�[��B����
	private String wmzoneBX;

	// �]�[��B�c��
	private String wmzoneBY;

	// �]�[��D����
	private String wmzoneDX;

	// �]�[��D�c��
	private String wmzoneDY;

	// �`�[���R���f�B�V�����}�b�v�w�i�F
	private String bgColorCCMAP;

	// �r�W�l�X�}�C���h�}�b�v�w�i�F
	private String bgColorBMMAP;

	// ���[�_�����}�b�v�w�i�F
	private String bgColorRTMAP;

	// �`�[���R���f�B�V�����}�b�v�O���b�h�F
	private String gridColorCCMAP;

	// ���[�_�����}�b�v�O���b�h�F
	private String gridColorRTMAP;

	// �`�[���R���f�B�V�����}�b�v�f�[�^���ނP�F
	private String dataColor1CCMAP;

	// �`�[���R���f�B�V�����}�b�v�f�[�^���ނQ�F
	private String dataColor2CCMAP;

	// �`�[���R���f�B�V�����}�b�v�f�[�^���ނR�F
	private String dataColor3CCMAP;

	// �`�[���R���f�B�V�����}�b�v�f�[�^���ނS�F
	private String dataColor4CCMAP;

	// �r�W�l�X�}�C���h�}�b�v�f�[�^���ނP�F
	private String dataColor1BMMAP;

	// �r�W�l�X�}�C���h�}�b�v�f�[�^���ނQ�F
	private String dataColor2BMMAP;

	// �r�W�l�X�}�C���h�}�b�v�f�[�^���ނR�F
	private String dataColor3BMMAP;

	// �r�W�l�X�}�C���h�}�b�v�f�[�^���ނS�F
	private String dataColor4BMMAP;

	// �r�W�l�X�}�C���h�}�b�v�f�[�^�����F
	private String dataJikuColorBMMAP;

	// ���[�_�����}�b�v�f�[�^���ނP�F
	private String dataColor1RTMAP;

	// ���[�_�����}�b�v�f�[�^���ނQ�F
	private String dataColor2RTMAP;

	// ���[�_�����}�b�v�f�[�^���ނR�F
	private String dataColor3RTMAP;

	// ���[�_�����}�b�v�f�[�^���ނS�F
	private String dataColor4RTMAP;

	// ���[�_�����}�b�v�f�[�^���ނT�F
	private String dataColor5RTMAP;

	// �r�W�l�XHIGH�c��
	private String bizHighY;

	// �r�W�l�XLOW�c��
	private String bizLowY;

	// �֌WHIGH����
	private String relHighX;

	// �֌WLOW����
	private String relLowX;

	// ���[�_�����}�b�v�f�[�^�̈��
	private String lineColorRTMAP;

	// ��E��P�K�w�v���b�g�F
	private String plotColorLv1;

	// ��E��Q�K�w�v���b�g�F
	private String plotColorLv2;

	// ��E��R�K�w�v���b�g�F
	private String plotColorLv3;

	// ��E��S�K�w�v���b�g�F
	private String plotColorLv4;

	// ��E��T�K�w�v���b�g�F
	private String plotColorLv5;

	// ��E��U�K�w�v���b�g�F
	private String plotColorLv6;

	// ��E�K�w�}�ᕶ����F
	private String yakushokuHanreiColor;

	// �g�D�����x�����}��F ���ɖ���
	private Color SMHanreiColor1;

	// �g�D�����x�����}��F ����
	private Color SMHanreiColor2;

	// �g�D�����x�����}��F �s����
	private Color SMHanreiColor3;

	// �g�D�����x�����}��F ���ɕs����
	private Color SMHanreiColor4;

	// �g�D�����x���� ��Е��ϐF
	private Color SMKaishaAvgColor;

	// �g�D�����x���� �g�D���ϐF
	private Color SMSoshikiAvgColor;

	// �g�D�����x���� �K�w���F
	private Color SMKaisoNoneColor;

	// �g�D�����x���� ���ɕs�����ŏ��l
	private float SMHFumanMin;

	// �g�D�����x���� ���ɕs�����ő�l
	private float SMHFumanMax;

	// �g�D�����x���� �s���ŏ��l
	private float SMFumanMin;

	// �g�D�����x���� �s���ő�l
	private float SMFumanMax;

	// �g�D�����x���� �����ŏ��l
	private float SMManzokuMin;

	// �g�D�����x���� �����ő�l
	private float SMManzokuMax;

	// �g�D�����x���� ���ɖ����ŏ��l
	private float SMHManzokuMin;

	// �g�D�����x���� ���ɖ����ő�l
	private float SMHManzokuMax;

	// �g�D�����x���� �l�̌ܓ����ʒu
	private int SMScalePos;

	// �`�[���R���f�B�V�����}�b�v
	private final String CCMAP_PDF = "CCMAP_PDF";

	// �r�W�l�X�}�b�v
	private final String BMMAP_PDF = "BMMAP_PDF";

	// ���[�_�V�b�v����
	private final String RTMAP_PDF = "RTMAP_PDF";

	// �g�D�����x����
	private final String SM_PDF = "SM_PDF";

	// �g�D�̃��^�R���s�e���V�[
	private final String MC_PDF = "MC_PDF";

	// "%"�\��
	private final String PERCENT = "%";

	// PDF�o�͕ϐ�
	private Document document;

	private PdfWriter writer;

	// �A���P�[�g����
	private String enqueteNm;

	// �󔒃Z�������p������
	private final static String BLANK = null;

	// �O���t�̃O���b�h�̒P��
	private final static float UNIT = 1f;

	// �O���t�̃O���b�h�̌�
	private final static int UNIT_NUM = 6;

	// �O���t�o�[�̔w�i�F
	private Color BAR_BG_COLOR;

	// �O���t�ڐ�����̐F
	private Color GRAPH_MAJOR_COLOR;

	// �O���t�o�[�̍���
	private final static float BAR_HEIGHT = 27f;

	// �O���t�o�[��h��Ԃ��ێg�p����Z��
	private static PdfPCell FILL_CELL;

	// �O���t�o�[�̋󔒂̗̈�Ƃ��Ďg�p����Z��
	private static PdfPCell BLANK_CELL;

	/**
	 * �R���X�g���N�^
	 * @param document �h�L�������g�I�u�W�F�N�g
	 * @param writer writer�N���X
	 * @param enqueteNm �A���P�[�g����
	 */
	public PED_TotalizePerformanceReportPdf(final Document document, final PdfWriter writer, final String enqueteNm) {

		this.document = document;
		this.writer = writer;
		this.enqueteNm = enqueteNm;

		// parameter.properties
		this.msgDED005 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED005"));
		this.msgDED048 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED048"));
		this.msgDED049 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED049"));
		this.msgDED050 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED050"));
		this.msgDZZ622 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DZZ622"));
		this.msgDED051 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED051"));
		this.msgDED052 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED052"));
		this.msgDED053 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED053"));
		this.msgDED054 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED054"));
		this.msgDED055 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED055"));
		this.msgDED071 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED071"));
		this.msgDED072 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED072"));
		this.msgDED073 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED073"));
		this.msgDED074 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED074"));
		this.msgDED075 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED075"));
		this.msgDED084 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED084"));
		this.msgDED056 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED056"));
		this.msgDED057 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED057"));
		this.msgDED058 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED058"));
		this.msgDED059 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED059"));
		this.msgDED060 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED060"));
		this.msgDED061 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED061"));
		this.msgDED062 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED062"));
		this.msgDED063 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED063"));
		this.msgDED064 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED064"));
		this.msgDED065 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED065"));
		this.msgDED066 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED066"));
		this.msgDED067 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED067"));
		this.msgDED068 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED068"));
		this.msgDED069 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED069"));
		this.msgDED070 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED070"));
		this.msgDED076 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED076"));
		this.msgDED077 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED077"));
		this.msgDED078 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED078"));
		this.msgDED079 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED079"));
		this.msgDED081 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED081"));
		this.msgDED080 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED080"));
		this.msgDED082 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED082"));
		this.msgDED083 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED083"));
		this.msgDED085 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED085"));
		this.msgDED086 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED086"));

		this.msgDED097 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED097"));
		this.msgDED098 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED098"));
		this.msgDED099 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED099"));
		this.msgDED100 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED100"));
		this.msgDED101 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED101"));
		this.msgDED102 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED102"));
		this.msgDED103 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED103"));
		this.msgDED104 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED104"));
		this.msgDED105 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED105"));
		this.msgDED106 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED106"));
		this.msgDED107 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED107"));
		this.msgDED158 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED158"));
		this.msgDED159 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED159"));
		this.msgDED160 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED160"));
		this.msgDED161 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED161"));
		this.msgDED162 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED162"));
		this.msgDED163 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED163"));
		this.msgDED164 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED164"));
		this.msgDED165 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED165"));
		this.msgDED166 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED166"));
		this.msgDED167 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED167"));
		this.msgDED168 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED168"));
		this.msgDED169 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED169"));
		this.msgDED170 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED170"));
		this.msgDED171 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED171"));
		this.msgDED172 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED172"));
		this.msgDED173 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED173"));
		this.msgDED174 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED174"));
		this.msgDED175 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED175"));
		this.msgDED176 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED176"));
		this.msgDED177 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED177"));
		this.msgDED178 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED178"));
		this.msgDED179 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED179"));
		this.msgDED180 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED180"));

		this.msgDED181 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED181"));
		this.msgDED182 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED182"));
		this.msgDED183 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED183"));
		this.msgDED184 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED184"));
		this.msgDED185 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED185"));
		this.msgDED186 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED186"));
		this.msgDED187 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED187"));
		this.msgDED188 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED188"));
		this.msgDED189 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED189"));
		this.msgDED190 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DED190"));

		this.msgSMListL.add(ReadFile.paramMapData.get("DED108"));
		this.msgSMListL.add(ReadFile.paramMapData.get("DED109"));
		this.msgSMListL.add(ReadFile.paramMapData.get("DED110"));
		this.msgSMListL.add(ReadFile.paramMapData.get("DED111"));
		this.msgSMListL.add(ReadFile.paramMapData.get("DED112"));
		this.msgSMListL.add(ReadFile.paramMapData.get("DED113"));
		this.msgSMListL.add(ReadFile.paramMapData.get("DED114"));

		this.msgSMListS.add(ReadFile.paramMapData.get("DED115"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED116"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED117"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED118"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED119"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED120"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED121"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED122"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED123"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED124"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED125"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED126"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED127"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED128"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED129"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED130"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED131"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED132"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED133"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED134"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED135"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED136"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED137"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED138"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED139"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED140"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED141"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED142"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED143"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED144"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED145"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED146"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED147"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED148"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED149"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED150"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED151"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED152"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED153"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED154"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED155"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED156"));
		this.msgSMListS.add(ReadFile.paramMapData.get("DED157"));

		// announce.properties // <br>�����s�ɕϊ�
		this.msgAED025 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED025")).replaceAll("<br>", "\\\n");
		this.msgAED026 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED026")).replaceAll("<br>", "\\\n");
		this.msgAED027 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED027")).replaceAll("<br>", "\\\n");
		this.msgAED028 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED028")).replaceAll("<br>", "\\\n");
		this.msgAED029 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED029")).replaceAll("<br>", "\\\n");
		this.msgAED030 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED030")).replaceAll("<br>", "\\\n");
		this.msgAED031 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED031")).replaceAll("<br>", "\\\n");
		this.msgAED032 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED032")).replaceAll("<br>", "\\\n");
		this.msgAED033 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED033")).replaceAll("<br>", "\\\n");
		this.msgAED034 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED034")).replaceAll("<br>", "\\\n");
		this.msgAED035 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED035")).replaceAll("<br>", "\\\n");
		this.msgAED036 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED036")).replaceAll("<br>", "\\\n");
		this.msgAED037 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED037")).replaceAll("<br>", "\\\n");
		this.msgAED038 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED038")).replaceAll("<br>", "\\\n");
		this.msgAED039 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED039")).replaceAll("<br>", "\\\n");
		this.msgAED040 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED040")).replaceAll("<br>", "\\\n");
		this.msgAED041 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED041")).replaceAll("<br>", "\\\n");
		this.msgAED042 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED042")).replaceAll("<br>", "\\\n");
		this.msgAED043 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED043")).replaceAll("<br>", "\\\n");
		this.msgAED044 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED044")).replaceAll("<br>", "\\\n");
		this.msgAED045 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.announceMapData.get("AED045")).replaceAll("<br>", "\\\n");

		// career.properties
		this.wmzoneAX = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_WMZONE_A_X"));
		this.wmzoneAY = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_WMZONE_A_Y"));
		this.wmzoneBX = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_WMZONE_B_X"));
		this.wmzoneBY = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_WMZONE_B_Y"));
		this.wmzoneDX = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_WMZONE_D_X"));
		this.wmzoneDY = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_WMZONE_D_Y"));
		this.bgColorCCMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_BG_COLOR_CCMAP"));
		this.bgColorBMMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_BG_COLOR_BMMAP"));
		this.bgColorRTMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_BG_COLOR_RTMAP"));
		this.gridColorCCMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_GRID_COLOR_CCMAP"));
		this.gridColorRTMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_GRID_COLOR_RTMAP"));
		this.dataColor1CCMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_1_CCMAP"));
		this.dataColor2CCMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_2_CCMAP"));
		this.dataColor3CCMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_3_CCMAP"));
		this.dataColor4CCMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_4_CCMAP"));
		this.dataColor1BMMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_1_BMMAP"));
		this.dataColor2BMMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_2_BMMAP"));
		this.dataColor3BMMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_3_BMMAP"));
		this.dataColor4BMMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_4_BMMAP"));
		this.dataJikuColorBMMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_JIKU_COLOR_BMMAP"));
		this.dataColor1RTMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_1_RTMAP"));
		this.dataColor2RTMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_2_RTMAP"));
		this.dataColor3RTMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_3_RTMAP"));
		this.dataColor4RTMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_4_RTMAP"));
		this.dataColor5RTMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_5_RTMAP"));
		this.lineColorRTMAP = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_RYOIKI_COLOR_RTMAP"));
		this.plotColorLv1 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_PLOT_COLOR_LV1"));
		this.plotColorLv2 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_PLOT_COLOR_LV2"));
		this.plotColorLv3 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_PLOT_COLOR_LV3"));
		this.plotColorLv4 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_PLOT_COLOR_LV4"));
		this.plotColorLv5 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_PLOT_COLOR_LV5"));
		this.plotColorLv6 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_PLOT_COLOR_LV6"));
		this.yakushokuHanreiColor = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_YAKUSHOKU_HANREI_COLOR"));
		this.bizHighY = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_BNHIGH_Y"));
		this.bizLowY = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_BNLOW_Y"));
		this.relHighX = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_CNHIGH_X"));
		this.relLowX = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_CNLOW_X"));

		try {
			this.SMHanreiColor1 = new Color(Integer.decode(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_1_SM"))).intValue());
		} catch (final Exception e) {
			this.SMHanreiColor1 = Color.WHITE;
		}
		try {
			this.SMHanreiColor2 = new Color(Integer.decode(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_2_SM"))).intValue());
		} catch (final Exception e) {
			this.SMHanreiColor2 = Color.WHITE;
		}
		try {
			this.SMHanreiColor3 = new Color(Integer.decode(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_3_SM"))).intValue());
		} catch (final Exception e) {
			this.SMHanreiColor3 = Color.WHITE;
		}
		try {
			this.SMHanreiColor4 = new Color(Integer.decode(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_4_SM"))).intValue());
		} catch (final Exception e) {
			this.SMHanreiColor4 = Color.WHITE;
		}
		try {
			this.SMKaishaAvgColor = new Color(Integer.decode(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_5_SM"))).intValue());
		} catch (final Exception e) {
			this.SMKaishaAvgColor = Color.WHITE;
		}
		try {
			this.SMSoshikiAvgColor = new Color(Integer.decode(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_6_SM"))).intValue());
		} catch (final Exception e) {
			this.SMSoshikiAvgColor = Color.WHITE;
		}
		try {
			this.SMKaisoNoneColor = new Color(Integer.decode(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_7_SM"))).intValue());
		} catch (final Exception e) {
			this.SMKaisoNoneColor = Color.WHITE;
		}

		try {
			this.BAR_BG_COLOR = new Color(Integer.decode(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_2_MC"))).intValue());
		} catch (final Exception e) {
			this.BAR_BG_COLOR = new Color(0, 0, 80);
		}
		try {
			this.GRAPH_MAJOR_COLOR = new Color(Integer.decode(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_1_MC"))).intValue());
		} catch (final Exception e) {
			this.GRAPH_MAJOR_COLOR = Color.BLACK;
		}

		try {
			this.SMHFumanMin = Float.parseFloat(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_4_SM_START")));
		} catch (final Exception e) {
			this.SMHFumanMin = 1f;
		}
		try {
			this.SMHFumanMax = Float.parseFloat(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_4_SM_END")));
		} catch (final Exception e) {
			this.SMHFumanMax = 2f;
		}
		try {
			this.SMFumanMin = Float.parseFloat(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_3_SM_START")));
		} catch (final Exception e) {
			this.SMFumanMin = 2f;
		}
		try {
			this.SMFumanMax = Float.parseFloat(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_3_SM_END")));
		} catch (final Exception e) {
			this.SMFumanMax = 3f;
		}
		try {
			this.SMManzokuMin = Float.parseFloat(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_2_SM_START")));
		} catch (final Exception e) {
			this.SMManzokuMin = 3f;
		}
		try {
			this.SMManzokuMax = Float.parseFloat(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_2_SM_END")));
		} catch (final Exception e) {
			this.SMManzokuMax = 4f;
		}
		try {
			this.SMHManzokuMin = Float.parseFloat(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_1_SM_START")));
		} catch (final Exception e) {
			this.SMHManzokuMin = 4f;
		}
		try {
			this.SMHManzokuMax = Float.parseFloat(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DATA_COLOR_1_SM_END")));
		} catch (final Exception e) {
			this.SMHManzokuMax = 5f;
		}
		try {
			this.SMScalePos = Integer.parseInt(PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_SIGN_FIG_MANZOKUDO")));
		} catch (final Exception e) {
			this.SMScalePos = 1;
		}

	}

	/**
	 * PDF���쐬����N���X
	 * @param pdfFlg �쐬����PDF�̎��ʃL�[
	 * @param bean �쐬���e���i�[����Bean�N���X
	 * @throws IOException
	 * @throws DocumentException
	 * @throws Exception
	 */
	public void makePdf(final String pdfFlg, final PED_ReportSoshikiValueBean bean) throws DocumentException, IOException {

		// �t�H���g�̒�`
		final BaseFont bf = BaseFont.createFont("HeiseiKakuGo-W5", "UniJIS-UCS2-H", false);
		final Font font = new Font(bf, 12);

		// �e�[�u���̕`��
		PdfPTable table = new PdfPTable(8);

		table.setWidths(new float[] { 15, 12, 12, 12, 12, 12, 5, 19 });
		table.setWidthPercentage(100);

		PdfPCell cell = null;
		PdfPTable nested2 = null;

		TeamCondition tcBean = null;
		BusinessMind bmBean = null;
		LeaderTraits ltBean = null;
		SoshikiManzoku smBean = null;
		MetaCompetency mcBean = null;

		// �`�[���R���f�B�V�����}�b�v
		if (pdfFlg.equals(this.CCMAP_PDF)) {
			tcBean = bean.getTeamCondition();
		}
		// �r�W�l�X�}�C���h�}�b�v
		else if (pdfFlg.equals(this.BMMAP_PDF)) {
			bmBean = bean.getBusinessMind();
		}
		// ���[�_�V�b�v�}�b�v
		else if (pdfFlg.equals(this.RTMAP_PDF)) {
			ltBean = bean.getLeaderTraits();
		}
		// �g�D�����x����
		else if (pdfFlg.equals(this.SM_PDF)) {
			smBean = bean.getSoshikiManzoku();
		}
		// �g�D�̃��^�R���s�e���V�[
		else if (pdfFlg.equals(this.MC_PDF)) {
			mcBean = bean.getMetaCompetency();
		}

		// �A���P�[�g����
		final String enqueteNm = PZZ010_CharacterUtil.normalizedStr(this.enqueteNm);
		// �W�v����(�N����)
		final String shukeiNgp = PZZ010_CharacterUtil.ChangeYmd(PZZ010_CharacterUtil.GetDay());
		// �W�v����(����)
		final String shukeiTime = PZZ010_CharacterUtil.ChangeHm(PZZ010_CharacterUtil.GetTime());

		// ��s��
		// �A���P�[�g���̃��x��
		cell = new PdfPCell(this.output(this.msgDED005, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(cell);
		// �A���P�[�g����
		cell = new PdfPCell(this.output(enqueteNm, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_UNDEFINED);
		cell.setColspan(6);
		cell.setPadding(10f);
		table.addCell(cell);

		// �W�v�������x��
		nested2 = new PdfPTable(1);
		cell = new PdfPCell(this.output(this.msgDED049, new Font(bf, 10)));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested2.addCell(cell);
		// �W�v����
		cell = new PdfPCell(new Paragraph(shukeiNgp + " " + shukeiTime, new Font(bf, 10)));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested2.addCell(cell);
		table.getDefaultCell().setPadding(0f);
		table.addCell(nested2);
		table.getDefaultCell().setPadding(10f);

		// ��s��
		// �Ώۑg�D�R�[�h
		final String taishoSoshikiCd = PZZ010_CharacterUtil.normalizedStr(bean.getSoshikiCode());
		// �Ώۑg�D
		final String taishoSohiki = PZZ010_CharacterUtil.normalizedStr(bean.getSoshikiName());
		// �W�v�l��(Max)
		final String shukeiMaxCnt = PZZ010_CharacterUtil.normalizedStr(bean.getShukeiCount());
		// �W�v�l��
		String shukeiCnt = "";
		// �`�[���R���f�B�V�����}�b�v
		if (pdfFlg.equals(this.CCMAP_PDF)) {
			shukeiCnt = PZZ010_CharacterUtil.normalizedStr(tcBean.getSoshikiSu());
		}
		// �r�W�l�X�}�C���h�}�b�v
		else if (pdfFlg.equals(this.BMMAP_PDF)) {
			shukeiCnt = PZZ010_CharacterUtil.normalizedStr(bmBean.getSoshikiSu());
		}
		// ���[�_�V�b�v�}�b�v
		else if (pdfFlg.equals(this.RTMAP_PDF)) {
			shukeiCnt = PZZ010_CharacterUtil.normalizedStr(ltBean.getSoshikiSu());
		}
		// �g�D�����x����
		else if (this.SM_PDF.equals(pdfFlg)) {
			shukeiCnt = PZZ010_CharacterUtil.normalizedStr(smBean.getSosikiSu());
		}
		// �g�D�̃��^�R���s�e���V�[
		else if (this.MC_PDF.equals(pdfFlg)) {
			shukeiCnt = PZZ010_CharacterUtil.normalizedStr(mcBean.getSoshikiSu());
		}

		// �Ώۑg�D���x��
		cell = new PdfPCell(this.output(this.msgDED048, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(cell);
		// �Ώۑg�D
		cell = new PdfPCell(new Paragraph(taishoSoshikiCd + "\n" + taishoSohiki, font));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell.setColspan(6);
		cell.setPadding(10f);
		table.addCell(cell);
		nested2 = new PdfPTable(1);

		// �W�v�l�����x��
		cell = new PdfPCell(this.output(this.msgDED050, new Font(bf, 10)));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested2.addCell(cell);
		// �W�v�l��
		cell = new PdfPCell(new Paragraph(shukeiCnt + this.msgDZZ622 + " / " + shukeiMaxCnt + this.msgDZZ622, new Font(bf, 10)));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		nested2.addCell(cell);
		table.getDefaultCell().setPadding(0f);
		table.addCell(nested2);
		table.getDefaultCell().setPadding(10f);
		this.document.add(table);

		// �O�s��
		table = new PdfPTable(3);
		table.setWidthPercentage(100);
		table.setWidths(new float[] { 32, 38, 30 });

		final BaseFont boldf = BaseFont.createFont("HeiseiKakuGo-W5", "UniJIS-UCS2-H", false);
		final Font boldFont = new Font(boldf, 12, Font.BOLD);

		// �`�[���R���f�B�V�����}�b�v
		if (pdfFlg.equals(this.CCMAP_PDF)) {
			// ����A�]�[��%
			final String wariaiA = PZZ010_CharacterUtil.normalizedStr(tcBean.getTeamConditionZoneARate());
			// ����B�]�[��%
			final String wariaiB = PZZ010_CharacterUtil.normalizedStr(tcBean.getTeamConditionZoneBRate());
			// ����C�]�[��%
			final String wariaiC = PZZ010_CharacterUtil.normalizedStr(tcBean.getTeamConditionZoneCRate());
			// ����D�]�[��%
			final String wariaiD = PZZ010_CharacterUtil.normalizedStr(tcBean.getTeamConditionZoneDRate());
			// ����A�]�[���l��
			final String wariaiCntA = PZZ010_CharacterUtil.normalizedStr(tcBean.getTeamConditionZoneASu());
			// ����B�]�[���l��
			final String wariaiCntB = PZZ010_CharacterUtil.normalizedStr(tcBean.getTeamConditionZoneBSu());
			// ����C�]�[���l��
			final String wariaiCntC = PZZ010_CharacterUtil.normalizedStr(tcBean.getTeamConditionZoneCSu());
			// ����D�]�[���l��
			final String wariaiCntD = PZZ010_CharacterUtil.normalizedStr(tcBean.getTeamConditionZoneDSu());
			// �g�D�^�C�v
			final String sohikiType = PZZ010_CharacterUtil.normalizedStr(tcBean.getSoshikiType());

			// ���|�[�g����(�`�[���R���f�B�V����)
			cell = new PdfPCell(new Paragraph(this.msgDED051, boldFont));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);

			nested2 = new PdfPTable(4);
			nested2.setWidths(new float[] { 25, 25, 25, 25 });

			// ����A�]�[�����x��
			cell = new PdfPCell(new Paragraph(this.msgDED052, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// ����B�]�[�����x��
			cell = new PdfPCell(new Paragraph(this.msgDED053, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// ����C�]�[�����x��
			cell = new PdfPCell(new Paragraph(this.msgDED054, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// ����D�]�[�����x��
			cell = new PdfPCell(new Paragraph(this.msgDED055, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);

			// ����A�]�[��%
			cell = new PdfPCell(new Paragraph(wariaiA + this.PERCENT, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// ����B�]�[��%
			cell = new PdfPCell(new Paragraph(wariaiB + this.PERCENT, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// ����C�]�[��%
			cell = new PdfPCell(new Paragraph(wariaiC + this.PERCENT, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// ����D�]�[��%
			cell = new PdfPCell(new Paragraph(wariaiD + this.PERCENT, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);

			// ����A�]�[���l��
			cell = new PdfPCell(new Paragraph(wariaiCntA + this.msgDZZ622, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// ����B�]�[���l��
			cell = new PdfPCell(new Paragraph(wariaiCntB + this.msgDZZ622, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// ����C�]�[���l��
			cell = new PdfPCell(new Paragraph(wariaiCntC + this.msgDZZ622, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// ����D�]�[���l��
			cell = new PdfPCell(new Paragraph(wariaiCntD + this.msgDZZ622, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			table.getDefaultCell().setPadding(0f);
			table.addCell(nested2);

			// �g�D�^�C�v
			final BaseFont typef = BaseFont.createFont("HeiseiKakuGo-W5", "UniJIS-UCS2-H", false);
			final Font typeFont = new Font(typef, 15);
			cell = new PdfPCell(new Paragraph(sohikiType, typeFont));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);

			this.document.add(table);
		}
		// �r�W�l�X�}�C���h�}�b�v
		else if (pdfFlg.equals(this.BMMAP_PDF)) {
			// �����l����%
			final String wariaiKojinSeicho = PZZ010_CharacterUtil.normalizedStr(bmBean.getKojinSeichoTypeRate());
			// �����l����%
			final String wariaiKojinAntei = PZZ010_CharacterUtil.normalizedStr(bmBean.getKojinAnteiTypeRate());
			// �����g�D����%
			final String wariaiSoshikiAntei = PZZ010_CharacterUtil.normalizedStr(bmBean.getSoshikiAnteiTypeRate());
			// �����g�D����%
			final String wariaiSoshikiSeicho = PZZ010_CharacterUtil.normalizedStr(bmBean.getSoshikiSeichoTypeRate());
			// �����l�����l��
			final String wariaiKojinSeichoCnt = PZZ010_CharacterUtil.normalizedStr(bmBean.getKojinSeichoTypeSu());
			// �����l����l��
			final String wariaiKojinAnteiCnt = PZZ010_CharacterUtil.normalizedStr(bmBean.getKojinAnteiTypeSu());
			// �����g�D����l��
			final String wariaiSoshikiAnteiCnt = PZZ010_CharacterUtil.normalizedStr(bmBean.getSoshikiAnteiTypeSu());
			// �����g�D�����l��
			final String wariaiSoshikiSeichoCnt = PZZ010_CharacterUtil.normalizedStr(bmBean.getSoshikiSeichoTypeSu());
			// �g�D�^�C�v
			final String sohikiType = PZZ010_CharacterUtil.normalizedStr(bmBean.getSoshikiType());

			// ���|�[�g����(�r�W�l�X�}�C���h)
			cell = new PdfPCell(new Paragraph(this.msgDED071, boldFont));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);

			nested2 = new PdfPTable(4);
			nested2.setWidths(new float[] { 25, 25, 25, 25 });

			// �����l�������x��
			cell = new PdfPCell(new Paragraph(this.msgDED072, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����l���胉�x��
			cell = new PdfPCell(new Paragraph(this.msgDED073, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����g�D���胉�x��
			cell = new PdfPCell(new Paragraph(this.msgDED074, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����g�D�������x��
			cell = new PdfPCell(new Paragraph(this.msgDED075, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);

			// �����l����%
			cell = new PdfPCell(new Paragraph(wariaiKojinSeicho + this.PERCENT, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����l����%
			cell = new PdfPCell(new Paragraph(wariaiKojinAntei + this.PERCENT, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����g�D����%
			cell = new PdfPCell(new Paragraph(wariaiSoshikiAntei + this.PERCENT, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����g�D����%
			cell = new PdfPCell(new Paragraph(wariaiSoshikiSeicho + this.PERCENT, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);

			// �����l�����l��
			cell = new PdfPCell(new Paragraph(wariaiKojinSeichoCnt + this.msgDZZ622, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����l����l��
			cell = new PdfPCell(new Paragraph(wariaiKojinAnteiCnt + this.msgDZZ622, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����g�D����l��
			cell = new PdfPCell(new Paragraph(wariaiSoshikiAnteiCnt + this.msgDZZ622, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����g�D�����l��
			cell = new PdfPCell(new Paragraph(wariaiSoshikiSeichoCnt + this.msgDZZ622, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			table.getDefaultCell().setPadding(0f);
			table.addCell(nested2);

			// �g�D�^�C�v
			final BaseFont typef = BaseFont.createFont("HeiseiKakuGo-W5", "UniJIS-UCS2-H", false);
			final Font typeFont = new Font(typef, 15);
			cell = new PdfPCell(new Paragraph(sohikiType, typeFont));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);

			this.document.add(table);
		}
		// ���[�_�V�b�v�}�b�v
		else if (pdfFlg.equals(this.RTMAP_PDF)) {
			// �e�[�u�����ύX
			table.setWidths(new float[] { 32, 47.5f, 20.5f });

			// �����o�����X%
			final String wariaiA = PZZ010_CharacterUtil.normalizedStr(ltBean.getLeadershipZoneARate());
			// �����r�W�l�X���i%
			final String wariaiB = PZZ010_CharacterUtil.normalizedStr(ltBean.getLeadershipZoneBRate());
			// �����֌W�\�z%
			final String wariaiC = PZZ010_CharacterUtil.normalizedStr(ltBean.getLeadershipZoneCRate());
			// �����j���[�g�������x��%
			final String wariaiD = PZZ010_CharacterUtil.normalizedStr(ltBean.getLeadershipZoneDRate());
			// �������C���x��%
			final String wariaiE = PZZ010_CharacterUtil.normalizedStr(ltBean.getLeadershipZoneERate());
			// �����o�����X�l��
			final String wariaiCntA = PZZ010_CharacterUtil.normalizedStr(ltBean.getLeadershipZoneASu());
			// �����r�W�l�X���i�l��
			final String wariaiCntB = PZZ010_CharacterUtil.normalizedStr(ltBean.getLeadershipZoneBSu());
			// �����֌W�\�z�l��
			final String wariaiCntC = PZZ010_CharacterUtil.normalizedStr(ltBean.getLeadershipZoneCSu());
			// �����j���[�g�����l��
			final String wariaiCntD = PZZ010_CharacterUtil.normalizedStr(ltBean.getLeadershipZoneDSu());
			// �������C�l��
			final String wariaiCntE = PZZ010_CharacterUtil.normalizedStr(ltBean.getLeadershipZoneESu());
			// �g�D�^�C�v
			final String sohikiType = "";

			// ���|�[�g����(�`�[���R���f�B�V����)
			cell = new PdfPCell(new Paragraph(this.msgDED084, boldFont));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);

			nested2 = new PdfPTable(5);
			nested2.setWidths(new float[] { 20, 20, 20, 20, 20 });
			nested2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			nested2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);

			// �����o�����X���x��
			nested2.addCell(this.output(this.msgDED181, font));
			// �����r�W�l�X���i���x��
			nested2.addCell(this.output(this.msgDED182, font));
			// �����֌W�\�z���x��
			nested2.addCell(this.output(this.msgDED183, font));
			// �����j���[�g�������x��
			nested2.addCell(this.output(this.msgDED184, font));
			// �������C���x��
			nested2.addCell(this.output(this.msgDED185, font));

			// �����o�����X%
			cell = new PdfPCell(new Paragraph(wariaiA + this.PERCENT, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����r�W�l�X���i%
			cell = new PdfPCell(new Paragraph(wariaiB + this.PERCENT, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����֌W�\�z%
			cell = new PdfPCell(new Paragraph(wariaiC + this.PERCENT, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����j���[�g����%
			cell = new PdfPCell(new Paragraph(wariaiD + this.PERCENT, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �������C%
			cell = new PdfPCell(new Paragraph(wariaiE + this.PERCENT, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);

			// �����o�����X�l��
			cell = new PdfPCell(new Paragraph(wariaiCntA + this.msgDZZ622, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����r�W�l�X���i�l��
			cell = new PdfPCell(new Paragraph(wariaiCntB + this.msgDZZ622, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����֌W�\�z�l��
			cell = new PdfPCell(new Paragraph(wariaiCntC + this.msgDZZ622, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �����j���[�g�����l��
			cell = new PdfPCell(new Paragraph(wariaiCntD + this.msgDZZ622, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �������C�l��
			cell = new PdfPCell(new Paragraph(wariaiCntE + this.msgDZZ622, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			table.getDefaultCell().setPadding(0f);
			table.addCell(nested2);

			// �g�D�^�C�v
			final BaseFont typef = BaseFont.createFont("HeiseiKakuGo-W5", "UniJIS-UCS2-H", false);
			final Font typeFont = new Font(typef, 15);
			cell = new PdfPCell(new Paragraph(sohikiType, typeFont));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);

			this.document.add(table);
		}

		// �l�s��
		table = new PdfPTable(2);
		table.setWidthPercentage(100);

		table.getDefaultCell().setPadding(0f);
		table.setWidths(new float[] { 32, 68 });

		nested2 = new PdfPTable(1);

		// �`�[���R���f�B�V����
		if (pdfFlg.equals(this.CCMAP_PDF)) {
			// �g�D�^�C�v����
			final String soshikiTypeSetsumei = PZZ010_CharacterUtil.normalizedStr(tcBean.getSetsumei());

			// �g�D�^�C�v�������x��
			cell = new PdfPCell(new Paragraph(this.msgDED056, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �g�D�^�C�v����
			cell = new PdfPCell(new Paragraph(soshikiTypeSetsumei, font));
			cell.setVerticalAlignment(Element.ALIGN_TOP);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setMinimumHeight(135f);
			cell.setPadding(10f);
			nested2.addCell(cell);

			// ���̃}�b�v�̌������x��
			cell = new PdfPCell(new Paragraph(this.msgDED057, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// ���̃}�b�v�̌����e�L�X�g
			cell = new PdfPCell(new Paragraph(this.msgAED025, font));
			cell.setVerticalAlignment(Element.ALIGN_TOP);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setMinimumHeight(130f);
			cell.setPadding(10f);
			nested2.addCell(cell);
			table.addCell(nested2);
		}
		// �r�W�l�X�}�C���h
		else if (pdfFlg.equals(this.BMMAP_PDF)) {
			// �g�D�^�C�v����
			final String soshikiTypeSetsumei = PZZ010_CharacterUtil.normalizedStr(bmBean.getSetsumei());

			// �g�D�^�C�v�������x��
			cell = new PdfPCell(new Paragraph(this.msgDED056, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// �g�D�^�C�v����
			cell = new PdfPCell(new Paragraph(soshikiTypeSetsumei, font));
			cell.setVerticalAlignment(Element.ALIGN_TOP);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setMinimumHeight(135f);
			cell.setPadding(10f);
			nested2.addCell(cell);

			// ���̃}�b�v�̌������x��
			cell = new PdfPCell(new Paragraph(this.msgDED057, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// ���̃}�b�v�̌����e�L�X�g

			cell = new PdfPCell(new Paragraph(this.msgAED026, font));
			cell.setVerticalAlignment(Element.ALIGN_TOP);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setMinimumHeight(130f);
			cell.setPadding(10f);
			nested2.addCell(cell);
			table.addCell(nested2);
		}
		// ���[�_�V�b�v
		else if (pdfFlg.equals(this.RTMAP_PDF)) {

			// ��e�[�u��
			cell = new PdfPCell(new Paragraph("", font));
			cell.setMinimumHeight(145f);
			nested2.addCell(cell);

			// ���̃}�b�v�̌������x��
			cell = new PdfPCell(new Paragraph(this.msgDED057, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);
			// ���̃}�b�v�̌����e�L�X�g
			cell = new PdfPCell(new Paragraph(this.msgAED027, font));
			cell.setVerticalAlignment(Element.ALIGN_TOP);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setMinimumHeight(130f);
			cell.setPadding(10f);
			nested2.addCell(cell);
			table.addCell(nested2);
		}
		// �g�D�����x����
		else if (pdfFlg.equals(this.SM_PDF)) {
			// ���|�[�g����
			cell = new PdfPCell(this.output(this.msgDED097, boldFont));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setFixedHeight(55f);
			nested2.addCell(cell);

			// �\�ɂ��ă��x��
			cell = new PdfPCell(this.output(this.msgDED099, font));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			nested2.addCell(cell);

			cell = new PdfPCell(this.output(this.msgAED028, font));
			cell.setVerticalAlignment(Element.ALIGN_TOP);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setMinimumHeight(130f);
			cell.setPadding(10f);
			nested2.addCell(cell);

			// ��
			cell = new PdfPCell(this.str(""));
			cell.setMinimumHeight(200f);
			nested2.addCell(cell);

			// �ėp���x��
			cell = new PdfPCell(this.output(this.msgDED100, font));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			nested2.addCell(cell);

			nested2.getDefaultCell().setPadding(0f);
			final PdfPTable tmpTable = new PdfPTable(2);
			tmpTable.setWidths(new float[] { 3f, 7f });
			// ���ɖ���
			cell = new PdfPCell(this.str(""));
			cell.setBackgroundColor(this.SMHanreiColor1);
			tmpTable.addCell(cell);
			tmpTable.addCell(this.output(this.msgDED101, font));

			// ����
			cell = new PdfPCell(this.str(""));
			cell.setBackgroundColor(this.SMHanreiColor2);
			tmpTable.addCell(cell);
			tmpTable.addCell(this.output(this.msgDED102, font));

			// �s����
			cell = new PdfPCell(this.str(""));
			cell.setBackgroundColor(this.SMHanreiColor3);
			tmpTable.addCell(cell);
			tmpTable.addCell(this.output(this.msgDED103, font));

			// ���ɕs����
			cell = new PdfPCell(this.str(""));
			cell.setBackgroundColor(this.SMHanreiColor4);
			tmpTable.addCell(cell);
			tmpTable.addCell(this.output(this.msgDED104, font));

			nested2.addCell(tmpTable);
			table.addCell(nested2);

		}
		// �g�D�̃��^�R���s�e���V�[
		else if (pdfFlg.equals(this.MC_PDF)) {
			// ���|�[�g����
			cell = new PdfPCell(this.output(this.msgDED098, boldFont));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setFixedHeight(55f);
			nested2.addCell(cell);

			// �\�ɂ��ă��x��
			cell = new PdfPCell(this.output(this.msgDED158, font));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			nested2.addCell(cell);

			cell = new PdfPCell(this.output(this.msgAED029, font));
			cell.setVerticalAlignment(Element.ALIGN_TOP);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setMinimumHeight(130f);
			cell.setPadding(10f);
			nested2.addCell(cell);

			// ��
			// nested2.addCell(str(""));

			table.addCell(nested2);
		}

		if (!(pdfFlg.equals(this.SM_PDF) || pdfFlg.equals(this.MC_PDF))) {
			// �v���b�g�̐������x��
			cell = new PdfPCell(new Paragraph(this.msgDED058, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.addCell(cell);

			// ��P�K�w�}�����
			final String setsumei1 = PZZ010_CharacterUtil.normalizedStr(bean.getYakushoku1_hanrei());
			// ��Q�K�w�}�����
			final String setsumei2 = PZZ010_CharacterUtil.normalizedStr(bean.getYakushoku2_hanrei());
			// ��R�K�w�}�����
			final String setsumei3 = PZZ010_CharacterUtil.normalizedStr(bean.getYakushoku3_hanrei());
			// ��S�K�w�}�����
			final String setsumei4 = PZZ010_CharacterUtil.normalizedStr(bean.getYakushoku4_hanrei());
			// ��T�K�w�}�����
			final String setsumei5 = PZZ010_CharacterUtil.normalizedStr(bean.getYakushoku5_hanrei());
			// ��U�K�w�}�����
			final String setsumei6 = PZZ010_CharacterUtil.normalizedStr(bean.getYakushoku6_hanrei());

			// �}��
			// �K�w�P���x���̃t�H���g
			final Font kaisoFont1 = new Font(bf, 12);
			kaisoFont1.setColor(new Color(Integer.decode(this.plotColorLv1).intValue()));
			// �K�w�Q���x���̃t�H���g
			final Font kaisoFont2 = new Font(bf, 12);
			kaisoFont2.setColor(new Color(Integer.decode(this.plotColorLv2).intValue()));
			// �K�w�R���x���̃t�H���g
			final Font kaisoFont3 = new Font(bf, 12);
			kaisoFont3.setColor(new Color(Integer.decode(this.plotColorLv3).intValue()));
			// �K�w�S���x���̃t�H���g
			final Font kaisoFont4 = new Font(bf, 12);
			kaisoFont4.setColor(new Color(Integer.decode(this.plotColorLv4).intValue()));
			// �K�w�T���x���̃t�H���g
			final Font kaisoFont5 = new Font(bf, 12);
			kaisoFont5.setColor(new Color(Integer.decode(this.plotColorLv5).intValue()));
			// �K�w�U���x���̃t�H���g
			final Font kaisoFont6 = new Font(bf, 12);
			kaisoFont6.setColor(new Color(Integer.decode(this.plotColorLv6).intValue()));
			// �}��K�w���x���̃t�H���g
			final Font hanreiFont = new Font(bf, 12);
			hanreiFont.setColor(new Color(Integer.decode(this.yakushokuHanreiColor).intValue()));

			nested2.getDefaultCell().setPadding(0f);
			final PdfPTable nested3 = new PdfPTable(2);
			nested3.setWidths(new float[] { 80, 20 });
			// ��P�K�w�}�����
			cell = new PdfPCell(new Paragraph(setsumei1, hanreiFont));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(new Color(Integer.decode(this.plotColorLv1).intValue()));
			nested3.addCell(cell);
			// �}�� ��P�K�w���x��
			cell = new PdfPCell(new Paragraph(this.msgDED059, kaisoFont1));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested3.addCell(cell);
			// ��Q�K�w�}�����
			cell = new PdfPCell(new Paragraph(setsumei2, hanreiFont));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(new Color(Integer.decode(this.plotColorLv2).intValue()));
			nested3.addCell(cell);
			// �}�� ��Q�K�w���x��
			cell = new PdfPCell(new Paragraph(this.msgDED060, kaisoFont2));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested3.addCell(cell);
			// ��R�K�w�}�����
			cell = new PdfPCell(new Paragraph(setsumei3, hanreiFont));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(new Color(Integer.decode(this.plotColorLv3).intValue()));
			nested3.addCell(cell);
			// �}�� ��R�K�w���x��
			cell = new PdfPCell(new Paragraph(this.msgDED061, kaisoFont3));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested3.addCell(cell);
			// ��S�K�w�}�����
			cell = new PdfPCell(new Paragraph(setsumei4, hanreiFont));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(new Color(Integer.decode(this.plotColorLv4).intValue()));
			nested3.addCell(cell);
			// �}�� ��S�K�w���x��
			cell = new PdfPCell(new Paragraph(this.msgDED062, kaisoFont4));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested3.addCell(cell);
			// ��T�K�w�}�����
			cell = new PdfPCell(new Paragraph(setsumei5, hanreiFont));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(new Color(Integer.decode(this.plotColorLv5).intValue()));
			nested3.addCell(cell);
			// �}�� ��T�K�w���x��
			cell = new PdfPCell(new Paragraph(this.msgDED063, kaisoFont5));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested3.addCell(cell);
			// ��U�K�w�}�����
			cell = new PdfPCell(new Paragraph(setsumei6, hanreiFont));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(new Color(Integer.decode(this.plotColorLv6).intValue()));
			nested3.addCell(cell);
			// �}�� ��U�K�w���x��
			cell = new PdfPCell(new Paragraph(this.msgDED064, kaisoFont6));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			nested3.addCell(cell);

			nested2.addCell(nested3);
		}

		/** �����C�������� * */
		if (!(pdfFlg.equals(this.SM_PDF) || pdfFlg.equals(this.MC_PDF))) {
			nested2 = new PdfPTable(1);
			cell = new PdfPCell(new Paragraph("�O���t", font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setMinimumHeight(350f);
			nested2.addCell(cell);
			table.addCell(nested2);
			table.getDefaultCell().setPadding(10f);

			this.document.add(table);

			table = new PdfPTable(2);
			table.setWidths(new float[] { 30, 70 });

			// �`��̈�̊m��
			final PdfContentByte cb = this.writer.getDirectContent();
			cb.saveState();

			// �R���f�B�V�����}�b�v
			final Graphics2D g2d = cb.createGraphics(PageSize.A4.rotate().width(), PageSize.A4.rotate().height(), new JapaneseFontMapper(bf));

			// X,
			Rectangle2D r2d = null;

			// �`���[�g�ϐ�
			JFreeChart chart = null;
			// �O���t�ϐ�
			XYPlot plot = null;
			int bityosei = 0;
			final int bityoseiCnt = taishoSohiki.getBytes("Windows-31J").length / 87;
			bityosei += 10 * bityoseiCnt;
			// �`�[���R���f�B�V����
			if (pdfFlg.equals(this.CCMAP_PDF)) {
				r2d = new Rectangle2D.Double(280, 150 + bityosei, 545, 390);

				// �`���[�g�̍쐬
				chart = ChartFactory.createScatterPlot(null, this.msgDED066, this.msgDED065, new XYSeriesCollection(), PlotOrientation.VERTICAL, false, true, false);

				// �`���[�g�̐ݒ�
				chart.setBackgroundPaint(Color.white);

				// �O���t�̐ݒ�
				plot = (XYPlot) chart.getPlot();

				// �w�i�F�̐ݒ�
				plot.setBackgroundPaint(new Color(Integer.decode(this.bgColorCCMAP).intValue()));

				// �O���b�h�i�c�j�̐ݒ�
				plot.setDomainGridlinePaint(new Color(Integer.decode(this.gridColorCCMAP).intValue()));
				plot.setDomainGridlineStroke(new BasicStroke(0.1f));

				// �O���b�h�i���j�̐ݒ�
				plot.setRangeGridlinePaint(new Color(Integer.decode(this.gridColorCCMAP).intValue()));
				plot.setRangeGridlineStroke(new BasicStroke(0.1f));

				final XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) plot.getRenderer();

				renderer.setItemLabelsVisible(Boolean.TRUE);
				renderer.setItemLabelGenerator(new StandardXYItemLabelGenerator());

				// ���̐ݒ�
				// �c��
				final ValueAxis domainAxis = plot.getDomainAxis();
				domainAxis.setRange(-107, 107);
				domainAxis.setTickLabelsVisible(false);
				domainAxis.setAxisLineStroke(new BasicStroke(0.1f));
				domainAxis.setTickMarksVisible(false);
				final TickUnits domainUnits = new TickUnits();
				domainUnits.add(new NumberTickUnit(33.3f));
				domainAxis.setStandardTickUnits(domainUnits);

				// ����
				final ValueAxis rangeAxis = plot.getRangeAxis();
				rangeAxis.setRange(-107, 107);
				rangeAxis.setTickLabelsVisible(false);
				rangeAxis.setAxisLineStroke(new BasicStroke(0.1f));
				rangeAxis.setTickMarksVisible(false);
				final TickUnits rangeUnits = new TickUnits();
				rangeUnits.add(new NumberTickUnit(33.3f));
				rangeAxis.setStandardTickUnits(rangeUnits);

				// �A�m�e�[�V�����i���߁j�̐ݒ�
				// �]�[���`
				plot = this.makeZoneLine(plot, this.wmzoneAX, this.wmzoneAY, this.msgDED067, this.dataColor1CCMAP);
				// �]�[���a
				plot = this.makeZoneLine(plot, this.wmzoneBX, this.wmzoneBY, this.msgDED068, this.dataColor2CCMAP);
				// �]�[���b
				plot = this.makeZoneLine(plot, this.wmzoneDX, this.wmzoneDY, this.msgDED069, this.dataColor3CCMAP);
				// �]�[���c
				// �|�C���g�����W�ɕϊ�
				final double dy = 100 / 3. * (new Double(this.wmzoneDY).doubleValue() - 1);

				final int color = Integer.decode(this.dataColor4CCMAP).intValue();

				final XYTextAnnotation zoneTextAnnotation = new XYTextAnnotation(this.msgDED070, 93, dy + 2);
				zoneTextAnnotation.setTextAnchor(TextAnchor.BOTTOM_RIGHT);
				zoneTextAnnotation.setPaint(new Color(color));
				plot.addAnnotation(zoneTextAnnotation);

			}
			// �r�W�l�X�}�C���h�}�b�v
			else if (pdfFlg.equals(this.BMMAP_PDF)) {
				r2d = new Rectangle2D.Double(280, 150 + bityosei, 545, 390);
				// �`���[�g�̍쐬
				chart = ChartFactory.createScatterPlot(null, "", "", new XYSeriesCollection(), PlotOrientation.VERTICAL, false, true, false);

				// �`���[�g�̐ݒ�
				chart.setBackgroundPaint(Color.white);

				// �O���t�̐ݒ�
				plot = (XYPlot) chart.getPlot();

				// �w�i�F�̐ݒ�
				plot.setBackgroundPaint(new Color(Integer.decode(this.bgColorBMMAP).intValue()));

				// �O���b�h�i�c�j�̐ݒ�
				plot.setDomainGridlinesVisible(false);

				// �O���b�h�i���j�̐ݒ�
				plot.setRangeGridlinesVisible(false);

				final XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) plot.getRenderer();

				renderer.setItemLabelsVisible(Boolean.TRUE);
				renderer.setItemLabelGenerator(new StandardXYItemLabelGenerator());

				// ���̐ݒ�
				// �c��
				final ValueAxis domainAxis = plot.getDomainAxis();
				domainAxis.setRange(-107, 107);
				domainAxis.setTickLabelsVisible(false);
				domainAxis.setAxisLineStroke(new BasicStroke(0.1f));
				domainAxis.setTickMarksVisible(false);
				final TickUnits domainUnits = new TickUnits();
				domainUnits.add(new NumberTickUnit(33.3f));
				domainAxis.setStandardTickUnits(domainUnits);

				// ����
				final ValueAxis rangeAxis = plot.getRangeAxis();
				rangeAxis.setRange(-107, 107);
				rangeAxis.setTickLabelsVisible(false);
				rangeAxis.setAxisLineStroke(new BasicStroke(0.1f));
				rangeAxis.setTickMarksVisible(false);
				final TickUnits rangeUnits = new TickUnits();
				rangeUnits.add(new NumberTickUnit(33.3f));
				rangeAxis.setStandardTickUnits(rangeUnits);

				// �A�m�e�[�V�����i���߁j�̐ݒ�
				// ���F��ݒ�
				final int lineColor = Integer.decode(this.dataJikuColorBMMAP).intValue();
				// �l�����F��ݒ�
				final int dataColor1 = Integer.decode(this.dataColor1BMMAP).intValue();
				// �l����F��ݒ�
				final int dataColor2 = Integer.decode(this.dataColor2BMMAP).intValue();
				// �g�D����F��ݒ�
				final int dataColor3 = Integer.decode(this.dataColor3BMMAP).intValue();
				// �g�D�����F��ݒ�
				final int dataColor4 = Integer.decode(this.dataColor4BMMAP).intValue();

				// �c���쐬
				XYLineAnnotation zoneLineAnnotation = new XYLineAnnotation(0, -107, 0, 107, new BasicStroke(1f), new Color(lineColor));
				plot.addAnnotation(zoneLineAnnotation);
				// �����쐬
				zoneLineAnnotation = new XYLineAnnotation(-107, 0, 107, 0, new BasicStroke(1f), new Color(lineColor));
				plot.addAnnotation(zoneLineAnnotation);

				// ���x���ݒ�ϐ�
				XYTextAnnotation zoneTextAnnotation = null;

				// �l���x��
				zoneTextAnnotation = new XYTextAnnotation(this.msgDED076, 3, 95);
				zoneTextAnnotation.setTextAnchor(TextAnchor.CENTER_LEFT);
				zoneTextAnnotation.setPaint(new Color(lineColor));
				zoneTextAnnotation.setFont(new java.awt.Font(null, Font.BOLD, 15));
				plot.addAnnotation(zoneTextAnnotation);
				// �g�D���x��
				zoneTextAnnotation = new XYTextAnnotation(this.msgDED077, 3, -95);
				zoneTextAnnotation.setTextAnchor(TextAnchor.CENTER_LEFT);
				zoneTextAnnotation.setPaint(new Color(lineColor));
				zoneTextAnnotation.setFont(new java.awt.Font(null, Font.BOLD, 15));
				plot.addAnnotation(zoneTextAnnotation);
				// ���胉�x��
				zoneTextAnnotation = new XYTextAnnotation(this.msgDED078, -95, 5);
				zoneTextAnnotation.setTextAnchor(TextAnchor.CENTER_LEFT);
				zoneTextAnnotation.setPaint(new Color(lineColor));
				zoneTextAnnotation.setFont(new java.awt.Font(null, Font.BOLD, 15));
				plot.addAnnotation(zoneTextAnnotation);
				// �������x��
				zoneTextAnnotation = new XYTextAnnotation(this.msgDED079, 95, 5);
				zoneTextAnnotation.setTextAnchor(TextAnchor.CENTER_RIGHT);
				zoneTextAnnotation.setPaint(new Color(lineColor));
				zoneTextAnnotation.setFont(new java.awt.Font(null, Font.BOLD, 15));
				plot.addAnnotation(zoneTextAnnotation);

				// �l���胉�x��
				zoneTextAnnotation = new XYTextAnnotation(this.msgDED081, -95, 95);
				zoneTextAnnotation.setTextAnchor(TextAnchor.CENTER_LEFT);
				zoneTextAnnotation.setPaint(new Color(dataColor1));
				zoneTextAnnotation.setFont(new java.awt.Font(null, Font.NORMAL, 13));
				plot.addAnnotation(zoneTextAnnotation);
				// �l�������x��
				zoneTextAnnotation = new XYTextAnnotation(this.msgDED080, 95, 95);
				zoneTextAnnotation.setTextAnchor(TextAnchor.CENTER_RIGHT);
				zoneTextAnnotation.setPaint(new Color(dataColor2));
				zoneTextAnnotation.setFont(new java.awt.Font(null, Font.NORMAL, 13));
				plot.addAnnotation(zoneTextAnnotation);
				// �g�D���胉�x��
				zoneTextAnnotation = new XYTextAnnotation(this.msgDED082, -95, -95);
				zoneTextAnnotation.setTextAnchor(TextAnchor.CENTER_LEFT);
				zoneTextAnnotation.setPaint(new Color(dataColor3));
				zoneTextAnnotation.setFont(new java.awt.Font(null, Font.NORMAL, 13));
				plot.addAnnotation(zoneTextAnnotation);
				// �g�D�������x��
				zoneTextAnnotation = new XYTextAnnotation(this.msgDED083, 95, -95);
				zoneTextAnnotation.setTextAnchor(TextAnchor.CENTER_RIGHT);
				zoneTextAnnotation.setPaint(new Color(dataColor4));
				zoneTextAnnotation.setFont(new java.awt.Font(null, Font.NORMAL, 13));
				plot.addAnnotation(zoneTextAnnotation);
			}
			// ���[�_�V�b�v����
			else if (pdfFlg.equals(this.RTMAP_PDF)) {
				r2d = new Rectangle2D.Double(280, 150 + bityosei, 545, 380);
				// �`���[�g�̍쐬
				chart = ChartFactory.createScatterPlot(null, this.msgDED086, this.msgDED085, new XYSeriesCollection(), PlotOrientation.VERTICAL, false, true, false);

				// �`���[�g�̐ݒ�
				chart.setBackgroundPaint(Color.white);

				// �O���t�̐ݒ�
				plot = (XYPlot) chart.getPlot();

				// �w�i�F�̐ݒ�
				plot.setBackgroundPaint(new Color(Integer.decode(this.bgColorRTMAP).intValue()));

				// �O���b�h�i�c�j�̐ݒ�
				plot.setDomainGridlinePaint(new Color(Integer.decode(this.gridColorRTMAP).intValue()));
				plot.setDomainGridlineStroke(new BasicStroke(0.1f));

				// �O���b�h�i���j�̐ݒ�
				plot.setRangeGridlinePaint(new Color(Integer.decode(this.gridColorRTMAP).intValue()));
				plot.setRangeGridlineStroke(new BasicStroke(0.1f));

				final XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) plot.getRenderer();

				renderer.setItemLabelsVisible(Boolean.TRUE);
				renderer.setItemLabelGenerator(new StandardXYItemLabelGenerator());

				// ���̐ݒ�
				// �c��
				final ValueAxis domainAxis = plot.getDomainAxis();
				domainAxis.setRange(-107, 107);
				domainAxis.setTickLabelsVisible(false);
				domainAxis.setAxisLineStroke(new BasicStroke(0.1f));
				domainAxis.setTickMarksVisible(false);
				final TickUnits domainUnits = new TickUnits();
				domainUnits.add(new NumberTickUnit(33.3f));
				domainAxis.setStandardTickUnits(domainUnits);

				// ����
				final ValueAxis rangeAxis = plot.getRangeAxis();
				rangeAxis.setRange(-107, 107);
				rangeAxis.setTickLabelsVisible(false);
				rangeAxis.setAxisLineStroke(new BasicStroke(0.1f));
				rangeAxis.setTickMarksVisible(false);
				final TickUnits rangeUnits = new TickUnits();
				rangeUnits.add(new NumberTickUnit(33.3f));
				rangeAxis.setStandardTickUnits(rangeUnits);

				// �A�m�e�[�V�����i���߁j�̐ݒ�
				/*
				 * // �]�[���` plot = this.makeZoneLine(plot, this.wmzoneAX, this.wmzoneAY, this.msgDED067, this.dataColor1RTMAP); // �]�[���a plot = this.makeZoneLine(plot, this.wmzoneBX, this.wmzoneBY,
				 * this.msgDED068, this.dataColor2RTMAP); // �]�[���b plot = this.makeZoneLine(plot, this.wmzoneDX, this.wmzoneDY, this.msgDED069, this.dataColor3RTMAP); // �]�[���c // �|�C���g�����W�ɕϊ� final double
				 * dy = 100 / 3. * (new Double(this.wmzoneDY).doubleValue() - 1); final int color = Integer.decode(this.dataColor4RTMAP).intValue(); final XYTextAnnotation zoneTextAnnotation = new
				 * XYTextAnnotation(this.msgDED070, 93, dy + 2); zoneTextAnnotation.setTextAnchor(TextAnchor.BOTTOM_RIGHT); zoneTextAnnotation.setPaint(new Color(color));
				 * plot.addAnnotation(zoneTextAnnotation);
				 */
				plot = this.makeZoneLineRTMAP(plot);
			}

			// �l����List���擾
			final ArrayList shainBeanList = bean.getShainBeanList();

			// �ΏێЈ����ȉ����J��Ԃ����s
			for (int i = 0; i < shainBeanList.size(); i++) {

				// �l���̎擾
				final PED_ReportShainValueBean shainBean = (PED_ReportShainValueBean) shainBeanList.get(i);

				// �v���b�g���\�z
				// �v���b�g�ʒu���擾
				String plotX = "";
				String plotY = "";
				// �`�[���R���f�B�V�����}�b�v
				if (pdfFlg.equals(this.CCMAP_PDF)) {
					plotX = PZZ010_CharacterUtil.normalizedStr(shainBean.getWorkingMotivation());
					plotY = PZZ010_CharacterUtil.normalizedStr(shainBean.getChitekiNyoryoku());
				}
				// �r�W�l�X�}�C���h�}�b�v
				else if (pdfFlg.equals(this.BMMAP_PDF)) {
					plotX = PZZ010_CharacterUtil.normalizedStr(shainBean.getAnteiSeicho());
					plotY = PZZ010_CharacterUtil.normalizedStr(shainBean.getKojinSoshiki());
				}
				// ���[�_�V�b�v�}�b�v
				else if (pdfFlg.equals(this.RTMAP_PDF)) {
					plotX = PZZ010_CharacterUtil.normalizedStr(shainBean.getKankeiKochikuryoku());
					plotY = PZZ010_CharacterUtil.normalizedStr(shainBean.getBusinessSuishinryoku());
				}

				// �\�����x�����擾
				final String plotLabel = PZZ010_CharacterUtil.normalizedStr(shainBean.getPlotName());
				// �K�w���擾
				final String kaiso = PZZ010_CharacterUtil.normalizedStr(shainBean.getKaisou());

				// �\���`���ϐ�
				String plotType = "";
				// �\���F�ϐ�
				String plotColor = "";

				// �K�w���ɕ\�����e��ύX
				// ��P�K�w�������ꍇ
				if (kaiso.equals("1")) {
					plotType = this.msgDED059;
					plotColor = this.plotColorLv1;
				}
				// ��Q�K�w�������ꍇ
				else if (kaiso.equals("2")) {
					plotType = this.msgDED060;
					plotColor = this.plotColorLv2;
				}
				// ��R�K�w�������ꍇ
				else if (kaiso.equals("3")) {
					plotType = this.msgDED061;
					plotColor = this.plotColorLv3;
				}
				// ��S�K�w�������ꍇ
				else if (kaiso.equals("4")) {
					plotType = this.msgDED062;
					plotColor = this.plotColorLv4;
				}
				// ��T�K�w�������ꍇ
				else if (kaiso.equals("5")) {
					plotType = this.msgDED063;
					plotColor = this.plotColorLv5;
				}
				// ��U�K�w�������ꍇ
				else if (kaiso.equals("6")) {
					plotType = this.msgDED064;
					plotColor = this.plotColorLv6;
				}
				// �v���b�g�𐶐�
				plot = this.makePoint(plot, plotX, plotY, plotType, plotLabel, plotColor);
			}
			// �]�[���p�f�[�^�Z�b�g�Əc���̕R�t��
			plot.mapDatasetToDomainAxis(1, 0);

			// �`���[�g�`��
			chart.draw(g2d, r2d);

			g2d.dispose();
			cb.restoreState();
		}
		// �g�D�����x����
		else if (pdfFlg.equals(this.SM_PDF)) {

			// �O���[�v��
			final int groupNum = 7;

			// �O���[�v���Ƃ̏o�͍s��
			final int outputRows[] = { 5, 6, 13, 6, 6, 2, 5 };

			nested2 = new PdfPTable(10);
			nested2.setWidths(new float[] { 12, 20, 8, 8, 8, 8, 8, 8, 8, 8 });
			nested2.setWidthPercentage(90);
			nested2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			nested2.getDefaultCell().setPadding(0.25f);
			nested2.getDefaultCell().setBackgroundColor(new Color(255, 255, 255));
			// nested2.getDefaultCell().setBorderWidth(1.5f);
			PdfPTable tmpTable = null;

			// �w�b�_�i1�s�ځj
			cell = new PdfPCell(this.str(this.msgDED105));
			cell.setColspan(2);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setFixedHeight(13f);
			nested2.addCell(cell);

			nested2.addCell(this.str(this.msgDED106));
			nested2.addCell(this.str(this.msgDED107));

			nested2.addCell(this.str(bean.getYakushoku1_hanrei()));
			nested2.addCell(this.str(bean.getYakushoku2_hanrei()));
			nested2.addCell(this.str(bean.getYakushoku3_hanrei()));
			nested2.addCell(this.str(bean.getYakushoku4_hanrei()));
			nested2.addCell(this.str(bean.getYakushoku5_hanrei()));
			nested2.addCell(this.str(bean.getYakushoku6_hanrei()));

			// �g�[�^���s��
			int totalCnt = 0;

			// �s�̍���
			final float rowH = 10f;

			// 2�s�ڈȍ~
			for (int rowCnt = 0; rowCnt < groupNum; rowCnt++) {

				// �啪��
				nested2.addCell(this.str((String) this.msgSMListL.get(rowCnt)));

				for (int i = 0; i < 9; i++) {
					// �o�̓O���[�v�擾

					tmpTable = new PdfPTable(1);
					tmpTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					tmpTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
					tmpTable.getDefaultCell().setPadding(0f);
					tmpTable.getDefaultCell().setBorderWidth(0.01f);
					tmpTable.getDefaultCell().setFixedHeight(rowH);
					for (int j = 0; j < outputRows[rowCnt]; j++) {
						String kaishaAvg = (String) smBean.getKaishaAvg().get(totalCnt);
						try {
							// �l�̌ܓ�
							kaishaAvg = new BigDecimal(kaishaAvg).setScale(this.SMScalePos, BigDecimal.ROUND_HALF_UP).toString();
						} catch (final Exception e) {
						}
						if (i == 0) {
							// ������
							tmpTable.addCell(this.str((String) this.msgSMListS.get(totalCnt)));
						} else if (i == 1) {
							// ��Е���
							cell = new PdfPCell(this.str(kaishaAvg));
							cell.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell.setPadding(0f);
							cell.setBorderWidth(0.01f);
							cell.setBackgroundColor(this.SMKaishaAvgColor);
							cell.setFixedHeight(rowH);
							tmpTable.addCell(cell);
						} else if (i == 2) {
							// �g�D����
							final Font tmpFont = new Font(bf, 7);
							String score = (String) smBean.getSoshikiAvg().get(totalCnt);
							try {
								// �l�̌ܓ�
								score = new BigDecimal(score).setScale(this.SMScalePos, BigDecimal.ROUND_HALF_UP).toString();
								if (Float.parseFloat(score) < Float.parseFloat(kaishaAvg)) {// ��Е��ςƔ�r
									tmpFont.setColor(255, 0, 0);
								}
							} catch (final Exception e) {
							}
							cell = new PdfPCell(this.output(score, tmpFont));
							cell.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell.setPadding(0f);
							cell.setBorderWidth(0.01f);
							cell.setFixedHeight(rowH);
							cell.setBackgroundColor(this.SMSoshikiAvgColor);
							tmpTable.addCell(cell);
						} else {
							// �K�w�ʕ���
							String score = (String) ((ArrayList) smBean.getKaisoAvg().get(i - 3)).get(totalCnt);
							// �l�̌ܓ�
							try {
								score = new BigDecimal(score).setScale(this.SMScalePos, BigDecimal.ROUND_HALF_UP).toString();
							} catch (final Exception e) {
							}
							cell = new PdfPCell(this.str(score));
							cell.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell.setPadding(0f);
							cell.setBorderWidth(0.01f);
							cell.setFixedHeight(rowH);
							float tmp;
							try {
								tmp = Float.parseFloat(score);
							} catch (final Exception e) {
								tmp = 99f;
								cell.setBackgroundColor(this.SMKaisoNoneColor);
							}
							if (this.SMHFumanMin <= tmp && tmp < this.SMHFumanMax) {// ���ɕs����
								cell.setBackgroundColor(this.SMHanreiColor4);
							} else if (this.SMFumanMin <= tmp && tmp < this.SMFumanMax) {// �s����
								cell.setBackgroundColor(this.SMHanreiColor3);
							} else if (this.SMManzokuMin <= tmp && tmp < this.SMManzokuMax) {// ����
								cell.setBackgroundColor(this.SMHanreiColor2);
							} else if (this.SMHManzokuMin <= tmp && tmp <= this.SMHManzokuMax) {// ���ɖ���
								cell.setBackgroundColor(this.SMHanreiColor1);
							}
							tmpTable.addCell(cell);
						}
						totalCnt++;
					}
					totalCnt -= outputRows[rowCnt];
					nested2.addCell(tmpTable);
				}
				totalCnt += outputRows[rowCnt];

			}
			cell = new PdfPCell(nested2);
			// cell.setPaddingTop(10f);
			// cell.setPaddingLeft(10f);
			// cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			// cell.setVerticalAlignment(Element.ALIGN_BOTTOM);
			cell.setPadding(10f);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			table.addCell(cell);

		}
		// �g�D�̃��^�R���s�e���V�[
		else if (this.MC_PDF.equals(pdfFlg)) {

			// �e�평����
			PED_TotalizePerformanceReportPdf.FILL_CELL = new PdfPCell(new Paragraph(PED_TotalizePerformanceReportPdf.BLANK));
			PED_TotalizePerformanceReportPdf.FILL_CELL.setBackgroundColor(this.BAR_BG_COLOR);
			PED_TotalizePerformanceReportPdf.FILL_CELL.setBorderColorRight(this.GRAPH_MAJOR_COLOR);
			PED_TotalizePerformanceReportPdf.FILL_CELL.setBorderColorLeft(this.GRAPH_MAJOR_COLOR);
			PED_TotalizePerformanceReportPdf.FILL_CELL.setBorderColorTop(Color.BLACK);
			PED_TotalizePerformanceReportPdf.FILL_CELL.setBorderColorBottom(Color.BLACK);
			PED_TotalizePerformanceReportPdf.FILL_CELL.setBorderWidthRight(0.20f);
			PED_TotalizePerformanceReportPdf.FILL_CELL.setBorderWidthLeft(0.20f);
			PED_TotalizePerformanceReportPdf.FILL_CELL.setBorderWidthTop(0.25f);
			PED_TotalizePerformanceReportPdf.FILL_CELL.setBorderWidthBottom(0.25f);
			PED_TotalizePerformanceReportPdf.FILL_CELL.setPadding(0.25f);
			PED_TotalizePerformanceReportPdf.FILL_CELL.setFixedHeight(PED_TotalizePerformanceReportPdf.BAR_HEIGHT);
			PED_TotalizePerformanceReportPdf.BLANK_CELL = new PdfPCell(new Paragraph(PED_TotalizePerformanceReportPdf.BLANK));
			// BLANK_CELL.setBackgroundColor(Color.WHITE);
			PED_TotalizePerformanceReportPdf.BLANK_CELL.setFixedHeight(PED_TotalizePerformanceReportPdf.BAR_HEIGHT);
			PED_TotalizePerformanceReportPdf.BLANK_CELL.setBorderColorRight(this.GRAPH_MAJOR_COLOR);
			PED_TotalizePerformanceReportPdf.BLANK_CELL.setBorderColorLeft(this.GRAPH_MAJOR_COLOR);
			PED_TotalizePerformanceReportPdf.BLANK_CELL.setBorderColorTop(Color.BLACK);
			PED_TotalizePerformanceReportPdf.BLANK_CELL.setBorderColorBottom(Color.BLACK);
			PED_TotalizePerformanceReportPdf.BLANK_CELL.setBorderWidthTop(0f);
			PED_TotalizePerformanceReportPdf.BLANK_CELL.setBorderWidthBottom(0f);
			PED_TotalizePerformanceReportPdf.BLANK_CELL.setBorderWidthRight(0.20f);
			PED_TotalizePerformanceReportPdf.BLANK_CELL.setBorderWidthLeft(0.20f);
			PED_TotalizePerformanceReportPdf.BLANK_CELL.setPadding(0.25f);

			nested2 = new PdfPTable(4);
			nested2.setWidths(new float[] { 2f, 6f, 12f, 15f });
			nested2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			nested2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			nested2.getDefaultCell().setPadding(0f);

			cell = new PdfPCell(this.str2(this.msgDED159));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setMinimumHeight(20f);
			cell.setColspan(2);
			nested2.addCell(cell);
			nested2.addCell(this.str2(this.msgDED160));
			nested2.addCell(this.str2(this.msgDED161));

			/* ���ȓ��� */
			nested2.addCell(this.str2(this.vText(this.msgDED162)));

			// ���ڃ^�C�g�����x��
			PdfPTable tmpTable = new PdfPTable(1);
			tmpTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tmpTable.getDefaultCell().setFixedHeight(PED_TotalizePerformanceReportPdf.BAR_HEIGHT);
			tmpTable.addCell(this.str2(this.msgDED165));
			tmpTable.addCell(this.str2(this.msgDED166));
			tmpTable.addCell(this.str2(this.msgDED167));
			tmpTable.addCell(this.str2(this.msgDED168));
			tmpTable.addCell(this.str2(this.msgDED169));
			nested2.addCell(tmpTable);

			// �_�O���t
			tmpTable = new PdfPTable(1);
			tmpTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tmpTable.getDefaultCell().setFixedHeight(PED_TotalizePerformanceReportPdf.BAR_HEIGHT);
			tmpTable.getDefaultCell().setBorderWidthRight(0f);
			tmpTable.getDefaultCell().setBorderWidthBottom(0f);
			tmpTable.addCell(this.getCompetencyCell(mcBean.getTassei()));
			tmpTable.addCell(this.getCompetencyCell(mcBean.getSekkyokusei()));
			tmpTable.addCell(this.getCompetencyCell(mcBean.getPassion()));
			tmpTable.addCell(this.getCompetencyCell(mcBean.getSelfControl()));
			tmpTable.addCell(this.getCompetencyCell(mcBean.getJisin()));
			cell = new PdfPCell(tmpTable);
			cell.setBorderWidth(0f);
			nested2.addCell(cell);

			// ����
			tmpTable = new PdfPTable(1);
			tmpTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			tmpTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			tmpTable.getDefaultCell().setFixedHeight(PED_TotalizePerformanceReportPdf.BAR_HEIGHT);
			tmpTable.addCell(this.str2(this.msgAED030));
			tmpTable.addCell(this.str2(this.msgAED031));
			tmpTable.addCell(this.str2(this.msgAED032));
			tmpTable.addCell(this.str2(this.msgAED033));
			tmpTable.addCell(this.str2(this.msgAED034));
			nested2.addCell(tmpTable);

			/* �ΐl */
			nested2.addCell(this.str2(this.vText(this.msgDED163)));

			// ���ڃ^�C�g�����x��
			tmpTable = new PdfPTable(1);
			tmpTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tmpTable.getDefaultCell().setFixedHeight(PED_TotalizePerformanceReportPdf.BAR_HEIGHT);
			tmpTable.addCell(this.str2(this.msgDED170));
			tmpTable.addCell(this.str2(this.msgDED171));
			tmpTable.addCell(this.str2(this.msgDED172));
			tmpTable.addCell(this.str2(this.msgDED173));
			tmpTable.addCell(this.str2(this.msgDED174));
			nested2.addCell(tmpTable);

			// �_�O���t
			tmpTable = new PdfPTable(1);
			tmpTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tmpTable.getDefaultCell().setFixedHeight(PED_TotalizePerformanceReportPdf.BAR_HEIGHT);
			tmpTable.getDefaultCell().setBorderWidthRight(0f);
			tmpTable.getDefaultCell().setBorderWidthBottom(0f);
			tmpTable.addCell(this.getCompetencyCell(mcBean.getTaijinEikyoryoku()));
			tmpTable.addCell(this.getCompetencyCell(mcBean.getTeamWork()));
			tmpTable.addCell(this.getCompetencyCell(mcBean.getIkusei()));
			tmpTable.addCell(this.getCompetencyCell(mcBean.getTaijinRikai()));
			tmpTable.addCell(this.getCompetencyCell(mcBean.getKokensei()));
			cell = new PdfPCell(tmpTable);
			cell.setBorderWidth(0f);
			nested2.addCell(cell);

			// ����
			tmpTable = new PdfPTable(1);
			tmpTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			tmpTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			tmpTable.getDefaultCell().setFixedHeight(PED_TotalizePerformanceReportPdf.BAR_HEIGHT);
			tmpTable.addCell(this.str2(this.msgAED035));
			tmpTable.addCell(this.str2(this.msgAED036));
			tmpTable.addCell(this.str2(this.msgAED037));
			tmpTable.addCell(this.str2(this.msgAED038));
			tmpTable.addCell(this.str2(this.msgAED039));
			nested2.addCell(tmpTable);

			/* �C���e���W�F���X */
			nested2.addCell(this.str2(this.vText(this.msgDED164)));

			// ���ڃ^�C�g�����x��
			tmpTable = new PdfPTable(1);
			tmpTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tmpTable.getDefaultCell().setFixedHeight(PED_TotalizePerformanceReportPdf.BAR_HEIGHT);
			tmpTable.addCell(this.str2(this.msgDED175));
			tmpTable.addCell(this.str2(this.msgDED176));
			tmpTable.addCell(this.str2(this.msgDED177));
			tmpTable.addCell(this.str2(this.msgDED178));
			tmpTable.addCell(this.str2(this.msgDED179));
			tmpTable.addCell(this.str2(this.msgDED180));
			nested2.addCell(tmpTable);

			// �_�O���t
			tmpTable = new PdfPTable(1);
			tmpTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tmpTable.getDefaultCell().setFixedHeight(PED_TotalizePerformanceReportPdf.BAR_HEIGHT);
			tmpTable.addCell(this.getCompetencyCell(mcBean.getRiskTake()));
			tmpTable.addCell(this.getCompetencyCell(mcBean.getKadaiKotikuryoku()));
			tmpTable.addCell(this.getCompetencyCell(mcBean.getKetudanryoku()));
			tmpTable.addCell(this.getCompetencyCell(mcBean.getBunsekiryoku()));
			tmpTable.addCell(this.getCompetencyCell(mcBean.getJokyoTaiouryoku()));
			tmpTable.addCell(this.getCompetencyCell(mcBean.getJokyoRikairyoku()));
			cell = new PdfPCell();
			cell.setFixedHeight(0f);
			cell.setPadding(0f);
			tmpTable.addCell(cell);
			cell = new PdfPCell(tmpTable);
			cell.setBorderWidth(0f);
			nested2.addCell(cell);

			// ����
			tmpTable = new PdfPTable(1);
			tmpTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			tmpTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			tmpTable.getDefaultCell().setFixedHeight(PED_TotalizePerformanceReportPdf.BAR_HEIGHT);
			tmpTable.addCell(this.str2(this.msgAED040));
			tmpTable.addCell(this.str2(this.msgAED041));
			tmpTable.addCell(this.str2(this.msgAED042));
			tmpTable.addCell(this.str2(this.msgAED043));
			tmpTable.addCell(this.str2(this.msgAED044));
			tmpTable.addCell(this.str2(this.msgAED045));
			nested2.addCell(tmpTable);

			cell = new PdfPCell(nested2);
			cell.setPadding(5f);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			table.addCell(cell);
		}
		this.document.add(table);
	}

	public class JapaneseFontMapper implements FontMapper {
		private BaseFont basefont;

		public JapaneseFontMapper(final BaseFont font) {
			this.basefont = font;
		}

		public BaseFont awtToPdf(final java.awt.Font font) {
			return this.basefont;
		}

		public java.awt.Font pdfToAwt(final BaseFont font, final int size) {
			return new java.awt.Font("dialog", java.awt.Font.PLAIN, size);
		}
	}

	/**
	 * �]�[�����C���𐶐����郁�\�b�h
	 * @param plot �`�ʃN���X
	 * @param xPoint x���̃��C���ʒu
	 * @param yPoint y���̃��C���ʒu
	 * @param zoneLabel �]�[�����x��
	 * @param lineColor �]�[���F
	 * @return �]�[�����C����ǉ������`�ʃN���X
	 */
	private XYPlot makeZoneLine(final XYPlot plot, final String xPoint, final String yPoint, final String zoneLabel, final String lineColor) {

		// �|�C���g�����W�ɕϊ�
		final double x = 100 / 3. * new Double(xPoint).doubleValue();
		final double y = 100 / 3. * new Double(yPoint).doubleValue();

		final int color = Integer.decode(lineColor).intValue();

		// �c���쐬
		XYLineAnnotation zoneLineAnnotation = new XYLineAnnotation(x, 107, x, y, new BasicStroke(2f), new Color(color));
		plot.addAnnotation(zoneLineAnnotation);

		// �����쐬
		zoneLineAnnotation = new XYLineAnnotation(x, y, 107, y, new BasicStroke(2f), new Color(color));
		plot.addAnnotation(zoneLineAnnotation);

		final XYTextAnnotation zoneTextAnnotation = new XYTextAnnotation(zoneLabel, 93, y + 2);
		zoneTextAnnotation.setTextAnchor(TextAnchor.BOTTOM_RIGHT);
		zoneTextAnnotation.setPaint(new Color(color));

		plot.addAnnotation(zoneTextAnnotation);

		return plot;
	}

	/**
	 * ���[�_�[�����}�b�v�̗̈����`�悷��
	 * @param plot
	 * @return
	 */
	private XYPlot makeZoneLineRTMAP(final XYPlot plot) {

		// �̈��Color
		Color lineColor;
		try {
			lineColor = new Color(Integer.decode(this.lineColorRTMAP).intValue());
		} catch (final Exception e) {
			lineColor = Color.BLACK;
		}

		// �G���A�����F
		Color textColor1;
		try {
			textColor1 = new Color(Integer.decode(this.dataColor1RTMAP).intValue());
		} catch (final Exception e) {
			textColor1 = Color.BLACK;
		}
		Color textColor2;
		try {
			textColor2 = new Color(Integer.decode(this.dataColor2RTMAP).intValue());
		} catch (final Exception e) {
			textColor2 = Color.BLACK;
		}
		Color textColor3;
		try {
			textColor3 = new Color(Integer.decode(this.dataColor3RTMAP).intValue());
		} catch (final Exception e) {
			textColor3 = Color.BLACK;
		}
		Color textColor4;
		try {
			textColor4 = new Color(Integer.decode(this.dataColor4RTMAP).intValue());
		} catch (final Exception e) {
			textColor4 = Color.BLACK;
		}
		Color textColor5;
		try {
			textColor5 = new Color(Integer.decode(this.dataColor5RTMAP).intValue());
		} catch (final Exception e) {
			textColor5 = Color.BLACK;
		}

		/* �E���g */

		// �|�C���g�����W�ɕϊ�
		double tmpX;
		double tmpY;
		try {
			tmpX = new Double(this.relLowX).doubleValue();
		} catch (final Exception e) {
			tmpX = -1;
		}
		try {
			tmpY = new Double(this.bizHighY).doubleValue();
		} catch (final Exception e) {
			tmpY = 1;
		}
		double x = 100 / 3. * tmpX;
		double y = 100 / 3. * tmpY;
		// �c���`��
		XYLineAnnotation zoneLineAnnotation = new XYLineAnnotation(x, y, x, -107, new BasicStroke(2f), lineColor);
		plot.addAnnotation(zoneLineAnnotation);
		// �����`��
		zoneLineAnnotation = new XYLineAnnotation(x, y, 107, y, new BasicStroke(2f), lineColor);
		plot.addAnnotation(zoneLineAnnotation);

		/* ����g */

		// �|�C���g�����W�ɕϊ�
		try {
			tmpX = new Double(this.relHighX).doubleValue();
		} catch (final Exception e) {
			tmpX = 1;
		}
		try {
			tmpY = new Double(this.bizLowY).doubleValue();
		} catch (final Exception e) {
			tmpY = -1;
		}
		x = 100 / 3. * tmpX;
		y = 100 / 3. * tmpY;
		// �c���`��
		zoneLineAnnotation = new XYLineAnnotation(x, 107, x, y, new BasicStroke(2f), lineColor);
		plot.addAnnotation(zoneLineAnnotation);
		// �����`��
		zoneLineAnnotation = new XYLineAnnotation(-107, y, x, y, new BasicStroke(2f), lineColor);
		plot.addAnnotation(zoneLineAnnotation);

		// �o�����X
		XYTextAnnotation zoneTextAnnotation = new XYTextAnnotation(this.msgDED186, 100, 93);
		zoneTextAnnotation.setTextAnchor(TextAnchor.BOTTOM_RIGHT);
		zoneTextAnnotation.setFont(new java.awt.Font(null, Font.NORMAL, 13));
		zoneTextAnnotation.setPaint(textColor1);
		plot.addAnnotation(zoneTextAnnotation);
		// �r�W�l�X���i
		zoneTextAnnotation = new XYTextAnnotation(this.msgDED187, -100, 93);
		zoneTextAnnotation.setTextAnchor(TextAnchor.BOTTOM_LEFT);
		zoneTextAnnotation.setFont(new java.awt.Font(null, Font.NORMAL, 13));
		zoneTextAnnotation.setPaint(textColor2);
		// �֌W�\�z
		plot.addAnnotation(zoneTextAnnotation);
		zoneTextAnnotation = new XYTextAnnotation(this.msgDED188, 100, -100);
		zoneTextAnnotation.setTextAnchor(TextAnchor.BOTTOM_RIGHT);
		zoneTextAnnotation.setFont(new java.awt.Font(null, Font.NORMAL, 13));
		zoneTextAnnotation.setPaint(textColor3);
		// �j���[�g����
		plot.addAnnotation(zoneTextAnnotation);
		zoneTextAnnotation = new XYTextAnnotation(this.msgDED189, 0, 20);
		zoneTextAnnotation.setTextAnchor(TextAnchor.BOTTOM_CENTER);
		zoneTextAnnotation.setFont(new java.awt.Font(null, Font.NORMAL, 13));
		zoneTextAnnotation.setPaint(textColor4);
		plot.addAnnotation(zoneTextAnnotation);
		// ���C
		zoneTextAnnotation = new XYTextAnnotation(this.msgDED190, -100, -100);
		zoneTextAnnotation.setTextAnchor(TextAnchor.BOTTOM_LEFT);
		zoneTextAnnotation.setFont(new java.awt.Font(null, Font.NORMAL, 13));
		zoneTextAnnotation.setPaint(textColor5);
		plot.addAnnotation(zoneTextAnnotation);

		return plot;
	}

	/**
	 * �v���b�g�𐶐����郁�\�b�h
	 * @param XYPlot plot �`�ʃN���X
	 * @param String xPoint x���̈ʒu
	 * @param String yPoint y���̈ʒu
	 * @param String pointType �v���b�g�̌^
	 * @param String pointLabel �v���b�g���x��
	 * @param String pointColor �v���b�g�F
	 * @return �v���b�g��ǉ������`�ʃN���X
	 */
	private XYPlot makePoint(final XYPlot plot, final String plotX, final String plotY, final String plotType, final String plotLabel, final String plotColor) {

		// ���̃|�C���g���ݒ肳��Ă��Ȃ������ꍇ
		if (plotX == null || plotX.equals("") || plotY == null || plotY.equals("")) {
			return plot;
		}

		// �|�C���g�����W�ɕϊ�
		final double x = 100 / 3. * new Double(plotX).doubleValue();
		final double y = 100 / 3. * new Double(plotY).doubleValue();

		final int color = Integer.decode(plotColor).intValue();

		// �v���b�g�𐶐�����
		XYTextAnnotation zoneTextAnnotation = new XYTextAnnotation(plotType, x, y);
		zoneTextAnnotation.setTextAnchor(TextAnchor.CENTER);
		zoneTextAnnotation.setPaint(new Color(color));
		plot.addAnnotation(zoneTextAnnotation);

		// �v���b�g�̃��x�������݂���ꍇ
		if (plotLabel != null && !plotLabel.equals("")) {
			zoneTextAnnotation = new XYTextAnnotation(plotLabel, x, y + 1);
			zoneTextAnnotation.setTextAnchor(TextAnchor.BOTTOM_CENTER);
			zoneTextAnnotation.setPaint(new Color(color));
			plot.addAnnotation(zoneTextAnnotation);
		}

		return plot;
	}

	private Phrase str(final String str) throws DocumentException, IOException {
		return this.output(str, new Font(BaseFont.createFont("HeiseiKakuGo-W5", "UniJIS-UCS2-H", false), 7, Font.NORMAL));
	}

	private Phrase str2(final String str) throws DocumentException, IOException {
		return this.output(str, new Font(BaseFont.createFont("HeiseiKakuGo-W5", "UniJIS-UCS2-H", false), 10, Font.NORMAL));
	}

	private Phrase output(final String str, final Font font) {
		return new Phrase(str == null || "".equals(str) ? " " : str, font);
	}

	// ���l���O���t�o�[�ɕϊ�����
	private PdfPCell getCompetencyCell(float value) {
		final PdfPTable ret = new PdfPTable(PED_TotalizePerformanceReportPdf.UNIT_NUM);
		ret.getDefaultCell().setPadding(0f);
		ret.getDefaultCell().setBorderWidth(0f);
		ret.getDefaultCell().setMinimumHeight(PED_TotalizePerformanceReportPdf.BAR_HEIGHT);

		value += 3f;

		// UNIT������}�X�Ƃ���Cell�̏W���Ƃ��ăo�[���쐬����
		for (int i = 0; i < PED_TotalizePerformanceReportPdf.UNIT_NUM; ++i) {
			final float lBound = i * PED_TotalizePerformanceReportPdf.UNIT;
			final float uBound = (i + 1) * PED_TotalizePerformanceReportPdf.UNIT;

			// �}�X��h��Ԃ��Ȃ��ꍇ
			if (value < lBound) {
				ret.addCell(PED_TotalizePerformanceReportPdf.BLANK_CELL);
				// ���̃}�X�ɋ��E���܂܂��ꍇ
			} else if (lBound <= value && value < uBound) {
				final PdfPTable addTbl = new PdfPTable(new float[] {
						value % PED_TotalizePerformanceReportPdf.UNIT,
						PED_TotalizePerformanceReportPdf.UNIT - value % PED_TotalizePerformanceReportPdf.UNIT });
				addTbl.getDefaultCell().setPadding(0f);
				addTbl.getDefaultCell().setBorderWidth(0f);
				addTbl.addCell(PED_TotalizePerformanceReportPdf.FILL_CELL);
				addTbl.addCell(PED_TotalizePerformanceReportPdf.BLANK_CELL);
				ret.addCell(addTbl);
				// �}�X��S�ēh��Ԃ��ꍇ
			} else {
				ret.addCell(PED_TotalizePerformanceReportPdf.FILL_CELL);
			}
		}
		final PdfPCell cell = new PdfPCell(ret);
		cell.setBorderWidth(0f);
		cell.setPadding(0f);
		cell.setFixedHeight(PED_TotalizePerformanceReportPdf.BAR_HEIGHT);
		return cell;
	}

	/**
	 * ��������c�������ɕϊ�
	 * @param str
	 * @return
	 */
	private String vText(final String str) {

		String result = "";

		final String[] tmp = str.split("");

		result = tmp[0];
		for (int i = 1; i < tmp.length; i++) {
			result += "\n" + tmp[i];
		}

		return result;
	}
}
