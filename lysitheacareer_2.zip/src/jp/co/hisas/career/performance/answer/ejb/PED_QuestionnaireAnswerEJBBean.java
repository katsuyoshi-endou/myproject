/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.answer.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.performance.answer.bean.PED_QuestionnaireSelectionBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * �p�t�H�[�}���X�A���|�[�g�o�͂�DB�A�N�Z�X����
 * @author Shimura
 */
public class PED_QuestionnaireAnswerEJBBean implements SessionBean {

	private SessionContext context = null;

	/** Personal�e�[�u�� */
	private final String pTbl = HcdbDef.personalTbl;

	/** �A���P�[�g�񓚗p��ʂ�ID */
	private static final String ENQUETE_GAMEN_ID = "VED220";

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException {/* �������܂��� */
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * �f�[�^�x�[�X�������s���A���ʂ��i�[�����z������^�[������B
	 * @param login_no ���O�C��NO
	 * @return �������ʊi�[�z��
	 * @exception SQLException SQL�G���[�����������ꍇ
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 */
	public Object execute(final String login_no) throws SQLException, NamingException {
		Log.method(login_no, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* ��E�e�[�u�������� */
			/* ���R�[�h�������擾 */
			final String sql = "SELECT COUNT(*) AS cnt FROM " + this.pTbl + " WHERE SIMEI_NO=?";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, login_no);
			rs = pstmt.executeQuery();
			rs.next();
			final int tes = rs.getInt("cnt");
			Log.method(login_no, "OUT", "");
			return new Integer(tes);
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * �A���P�[�g�I����ʂ̕\�����e���擾
	 * @param logiNo ���O�I���ԍ�
	 * @return ArrayList �A���P�[�g�I����ʂ̓��e���擾����
	 */
	public ArrayList getSentakuLayout(final String loginNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �A���P�[�g�I���̓��e���i�[����ϐ�
			final ArrayList sentakuLayoutList = new ArrayList();

			// �A���P�[�g�}�X�^�̓��e���擾
			final String sql = "SELECT " + "ENQUETE." + HcdbDef.CPM_ENQUETE_COLUMNS[0] + " AS " + HcdbDef.CPM_ENQUETE_COLUMNS[0] + ", " + "ENQUETE." + HcdbDef.CPM_ENQUETE_COLUMNS[2] + " AS "
					+ HcdbDef.CPM_ENQUETE_COLUMNS[2] + ", " + "ENQUETE." + HcdbDef.CPM_ENQUETE_COLUMNS[3] + " AS " + HcdbDef.CPM_ENQUETE_COLUMNS[3] + ", " + "ENQUETE."
					+ HcdbDef.CPM_ENQUETE_COLUMNS[4] + " AS " + HcdbDef.CPM_ENQUETE_COLUMNS[4] + ", " + "ENQUETE." + HcdbDef.CPM_ENQUETE_COLUMNS[6] + " AS " + HcdbDef.CPM_ENQUETE_COLUMNS[6] + ", "
					+ "ENQUETE." + HcdbDef.CPM_ENQUETE_COLUMNS[5] + " AS " + HcdbDef.CPM_ENQUETE_COLUMNS[5] + ", " + "JOKYO." + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[2] + " AS "
					+ HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[2] + ", " + "JOKYO." + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[3] + " AS " + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[3] + ", " + "JOKYO."
					+ HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[4] + " AS " + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[4] + ", " + "STATUS." + HcdbDef.CPM_STATUS_COLUMNS[2] + " AS " + HcdbDef.CPM_STATUS_COLUMNS[2]
					+ " " + "FROM " + HcdbDef.CPM_ENQUETE_TBL + " ENQUETE, " + HcdbDef.CPS_ENQUETE_JOKYO_TBL + " JOKYO, " + "(" + "SELECT " + "* " + "FROM " + HcdbDef.CPM_STATUS_TBL + " " + "WHERE "
					+ HcdbDef.CPM_STATUS_COLUMNS[0] + "=? " + ") STATUS " + "WHERE " + "TRIM(JOKYO." + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[1] + ")=TRIM(?) " + "AND " + "JOKYO."
					+ HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[0] + "=" + "ENQUETE." + HcdbDef.CPM_ENQUETE_COLUMNS[0] + " " + "AND " + "ENQUETE." + HcdbDef.CPM_ENQUETE_COLUMNS[7] + " IN (?, ?) " + "AND "
					+ "JOKYO." + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[2] + "=" + "STATUS." + HcdbDef.CPM_STATUS_COLUMNS[1] + "(+) " + "ORDER BY " + "ENQUETE." + HcdbDef.CPM_ENQUETE_COLUMNS[4]
					+ " DESC, " + "ENQUETE." + HcdbDef.CPM_ENQUETE_COLUMNS[6] + " DESC, " + "ENQUETE." + HcdbDef.CPM_ENQUETE_COLUMNS[0];

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, "02");
			pstmt.setString(2, loginNo);
			pstmt.setString(3, "1");
			pstmt.setString(4, "2");
			rs = pstmt.executeQuery();

			// �A���P�[�g�}�X�^�̓��e�̊i�[
			while (rs.next()) {
				final String enqueteNo = rs.getString(HcdbDef.CPM_ENQUETE_COLUMNS[0]);
				final String enqueteNm = rs.getString(HcdbDef.CPM_ENQUETE_COLUMNS[2]);
				final String kaishiNgp = rs.getString(HcdbDef.CPM_ENQUETE_COLUMNS[3]);
				final String shuryoNgp = rs.getString(HcdbDef.CPM_ENQUETE_COLUMNS[4]);
				final String kaishiTime = rs.getString(HcdbDef.CPM_ENQUETE_COLUMNS[5]);
				final String shuryoTime = rs.getString(HcdbDef.CPM_ENQUETE_COLUMNS[6]);
				final String kaitoStatus = rs.getString(HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[2]);
				final String kaitoNgp = rs.getString(HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[3]);
				final String kaitoTime = rs.getString(HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[4]);
				final String statusNm = rs.getString(HcdbDef.CPM_STATUS_COLUMNS[2]);

				final PED_QuestionnaireSelectionBean selectionBean = new PED_QuestionnaireSelectionBean();

				selectionBean.setEnqueteNo(enqueteNo);
				selectionBean.setEnqueteNm(enqueteNm);
				selectionBean.setKaishiNgp(kaishiNgp);
				selectionBean.setShuryoNgp(shuryoNgp);
				selectionBean.setKaitoNgp(kaitoNgp);
				selectionBean.setKaitoTime(kaitoTime);
				selectionBean.setKaitoStatus(statusNm);
				selectionBean.setKaitoStatus2(kaitoStatus);
				selectionBean.setShuryoTime(shuryoTime);
				selectionBean.setKaishiTime(kaishiTime);
				sentakuLayoutList.add(selectionBean);
			}

			Log.method(loginNo, "OUT", "");
			return sentakuLayoutList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �A���P�[�g�}�X�^�̓��e���擾
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�gNO
	 * @return Map �A���P�[�g�}�X�^�̓��e���擾����
	 */
	public HashMap getEnqueteMaster(final String loginNo, final String enqueteNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �A���P�[�g�}�X�^�̓��e���i�[����ϐ�
			final HashMap enqueteMaster = new HashMap();

			// �A���P�[�g�}�X�^�̓��e���擾
			final String sql = "SELECT " + HcdbDef.CPM_ENQUETE_COLUMNS[2] + ", " + HcdbDef.CPM_ENQUETE_COLUMNS[10] + " " + "FROM " + HcdbDef.CPM_ENQUETE_TBL + " " + "WHERE "
					+ HcdbDef.CPM_ENQUETE_COLUMNS[0] + "=?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, enqueteNo);
			rs = pstmt.executeQuery();

			// �A���P�[�g�}�X�^�̓��e�̊i�[
			while (rs.next()) {
				final String enqueteName = rs.getString(HcdbDef.CPM_ENQUETE_COLUMNS[2]);
				final String enqueteComment = rs.getString(HcdbDef.CPM_ENQUETE_COLUMNS[10]);

				enqueteMaster.put(HcdbDef.CPM_ENQUETE_COLUMNS[2], enqueteName);
				enqueteMaster.put(HcdbDef.CPM_ENQUETE_COLUMNS[10], enqueteComment);
			}

			Log.method(loginNo, "OUT", "");
			return enqueteMaster;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �A���P�[�g�󋵂��擾
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�gNO
	 * @param viewPersonId �\���Ώۂ̐lID
	 * @return String �A���P�[�g�󋵂��擾����
	 */
	public String getEnqueteJokyo(final String loginNo, final String enqueteNo, final String viewPersonId) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �A���P�[�g�󋵂��i�[����ϐ�
			String status = "0";

			// �A���P�[�g�󋵂��擾
			final String sql = "SELECT " + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[2] + " " + "FROM " + HcdbDef.CPS_ENQUETE_JOKYO_TBL + " " + "WHERE " + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[0] + "=? AND "
					+ HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[1] + "=?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, enqueteNo);
			pstmt.setString(2, viewPersonId);
			rs = pstmt.executeQuery();

			// �A���P�[�g�󋵂̊i�[
			while (rs.next()) {
				status = rs.getString(HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[2]);
			}

			Log.method(loginNo, "OUT", "");
			return status;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * ����̑S�������擾
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�gNO
	 * @return int ����̑S�������擾����
	 */
	public int getCountEnqueteShitsumon(final String loginNo, final String enqueteNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// ����̑S�������i�[����ϐ�
			int totalEnquete = 0;

			// ����̑S�������擾
			final String sql = "SELECT " + "COUNT(*) AS cnt " + "FROM " + HcdbDef.CPM_ENQUETE_SHITSUMON_TBL + " " + "WHERE " + HcdbDef.CPM_ENQUETE_SHITSUMON_COLUMNS[0] + "=?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, enqueteNo);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				totalEnquete = rs.getInt("cnt");
			}

			Log.method(loginNo, "OUT", "");
			return totalEnquete;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �񓚍ς̌������擾
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�gNO
	 * @param viewPersonId �\���Ώۂ̐lID
	 * @return int �񓚍ς̑S�������擾����
	 */
	public int getCountEnqueteKaito(final String loginNo, final String enqueteNo, final String viewPersonId) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �񓚍ς̌������i�[����ϐ�
			int totalEnqueteKaito = 0;

			// �񓚍ς̃f�[�^��S�Ď擾����
			// �I�u�W�F�N�g�^�C�v��01�`05�ŉ񓚓��e��NULL�ȊO
			final String sql = "SELECT " + HcdbDef.CPS_ENQUETE_KAITO_TBL + "." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[3] + " AS " + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[3] + ", "
					+ HcdbDef.CPP_KOMOKU_SEIGYO_TBL + "." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[5] + " AS " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[5] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_TBL + "."
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[6] + " AS " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[6] + " " + "FROM " + HcdbDef.CPS_ENQUETE_KAITO_TBL + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_TBL + " "
					+ "WHERE " + HcdbDef.CPS_ENQUETE_KAITO_TBL + "." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[0] + " = ? " + "AND " + HcdbDef.CPS_ENQUETE_KAITO_TBL + "."
					+ HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[1] + " = ? " + "AND " + HcdbDef.CPS_ENQUETE_KAITO_TBL + "." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[0] + " = " + HcdbDef.CPP_KOMOKU_SEIGYO_TBL
					+ "." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[0] + " " + "AND " + HcdbDef.CPS_ENQUETE_KAITO_TBL + "." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[2] + " = " + HcdbDef.CPP_KOMOKU_SEIGYO_TBL
					+ "." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3] + " " + "AND " + HcdbDef.CPP_KOMOKU_SEIGYO_TBL + "." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[1] + " = ? " + "AND "
					+ HcdbDef.CPS_ENQUETE_KAITO_TBL + "." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[3] + " IS NOT NULL ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, enqueteNo);
			pstmt.setString(2, viewPersonId);
			pstmt.setString(3, PED_QuestionnaireAnswerEJBBean.ENQUETE_GAMEN_ID);
			rs = pstmt.executeQuery();

			// �I�u�W�F�N�g�^�C�v01�`04�p�̒l�ێ��ϐ�
			int value = 0;
			// �I�u�W�F�N�g�^�C�v01�`04�p�̃J�E���g�t���O
			boolean contFlg = true;

			// �񓚍σf�[�^���擾
			while (rs.next()) {
				// �񓚓��e�A�I�u�W�F�N�g�^�C�v�A�񓚐����擾
				final String kaitoNaiyo = rs.getString("KAITO_NAIYOU");
				final String objectType = rs.getString("OBJECT_TYPE");
				final String kaitoSu = rs.getString("KAITO_SU");

				contFlg = true;

				// NULL�`�F�b�N�K�v���m�F(�I�u�W�F�N�g)

				// �I�u�W�F�N�g�^�C�v��01�`04�������ꍇ
				if (objectType.equals("01") || objectType.equals("02") || objectType.equals("03") || objectType.equals("04")) {

					// �񓚓��e��ؽČ^�Ŏ擾
					final ArrayList kaitoList = this.getKaitoNaiyouList(objectType, kaitoNaiyo);

					// ���͒l��S�ă`�F�b�N
					for (int i = 0; i < kaitoList.size(); i++) {
						try {
							// �񓚓��e���擾
							value = new Integer((String) kaitoList.get(i)).intValue();

							// �񓚓��e��1�`�񓚐��̒l�ł͂Ȃ��ꍇ
							if (value < 1 || value > (new Integer(kaitoSu)).intValue()) {
								// �J�E���g�ΏۊO�Ƃ���
								contFlg = false;
								break;
							}
						} catch (final NumberFormatException nfe) {
							// �����^�ł͖����ꍇ�A�J�E���g�͂��Ȃ�
							contFlg = false;
							break;
						}
					}
					// �J�E���g�Ώۂ������ꍇ
					if (contFlg) {
						totalEnqueteKaito++;
					}
				}
				// ��L�ȊO�̏ꍇ
				else {
					totalEnqueteKaito++;
				}
			}

			Log.method(loginNo, "OUT", "");
			return totalEnqueteKaito;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �ŏI�񓚈ʒu�擾
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�gNO
	 * @param viewPersonId �\���Ώۂ̐lID
	 * @return int �ŏI�񓚈ʒu���擾����
	 */
	public int getLastEnqueteIchi(final String loginNo, final String enqueteNo, final String viewPersonId) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �ŏI�񓚈ʒu���i�[����ϐ�
			int maxHyoji = 0;

			// �ŏI�񓚈ʒu���擾
			final String sql = "SELECT " + "MAX(" + "KOMOKU." + "num" + ") AS max_hoji_junro " + "FROM " + HcdbDef.CPS_ENQUETE_KAITO_TBL + " KAITO, " + "(" + "SELECT " + "ROWNUM AS num, "
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[0] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[1] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[2] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3]
					+ ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[5] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[6] + ", "
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[7] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[8] + " " + "FROM " + "(" + "SELECT " + "* " + " FROM " + HcdbDef.CPP_KOMOKU_SEIGYO_TBL
					+ " WHERE " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[0] + "=? AND " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[1] + "=? " + " ORDER BY " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + ","
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3] + ")" + ") KOMOKU " + "WHERE " + "KAITO." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[1] + "=? AND " + "KAITO."
					+ HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[0] + "=" + "KOMOKU." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[0] + " AND " + "KAITO." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[2] + "=" + "KOMOKU."
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3] + " ORDER BY KOMOKU.hyoji_junjo, KOMOKU.KOMOKU_CODE";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, enqueteNo);
			pstmt.setString(2, PED_QuestionnaireAnswerEJBBean.ENQUETE_GAMEN_ID);
			pstmt.setString(3, viewPersonId);
			rs = pstmt.executeQuery();

			// �ŏI�񓚈ʒu���擾�o�����ꍇ
			if (rs.next()) {
				// �ŏI�񓚈ʒu���擾�o�����ꍇ
				if (rs.getBigDecimal("max_hoji_junro") != null) {
					maxHyoji = rs.getInt("max_hoji_junro");
				}
				// �ŏI�񓚈ʒu���擾�o���Ȃ������ꍇ
				else {
					maxHyoji = 1;
				}
			}
			// �ŏI�񓚈ʒu���擾�o���Ȃ������ꍇ
			else {
				maxHyoji = 1;
			}

			Log.method(loginNo, "OUT", "");
			return maxHyoji;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * ����e�[�u���̃T�C�Y���擾
	 * @param logiNo ���O�I���ԍ�
	 * @return HashMap �e�[�u���T�C�Y���擾
	 */
	public HashMap getTableSize(final String loginNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		final String performance = "Performance";
		final String noSize = "No_Size";
		final String questionSize = "Question_Size";
		final String kaitou_Size = "Kaitou_Size";

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �p�p�����[�^�̓��e���i�[����ϐ�
			final HashMap tableSize = new HashMap();

			// �ėp�p�����[�^���玿��e�[�u���̃T�C�Y���擾
			final String sql = "SELECT " + HcdbDef.CCP_PARAM_COLUMNS[1] + ", " + HcdbDef.CCP_PARAM_COLUMNS[2] + " " + "FROM " + HcdbDef.CCP_PARAM_TBL + " " + "WHERE " + HcdbDef.CCP_PARAM_COLUMNS[0]
					+ "=? AND " + HcdbDef.CCP_PARAM_COLUMNS[1] + " IN (?, ?, ?)";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, performance);
			pstmt.setString(2, noSize);
			pstmt.setString(3, questionSize);
			pstmt.setString(4, kaitou_Size);
			rs = pstmt.executeQuery();

			// �A���P�[�g�}�X�^�̓��e�̊i�[
			while (rs.next()) {
				final String sizeKey = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[1]);
				final String sizeValue = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);

				tableSize.put(sizeKey, sizeValue);
			}

			Log.method(loginNo, "OUT", "");
			return tableSize;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �񓚃��C�A�E�g���擾
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�gNO
	 * @param startHyoji �\���J�n�ʒu
	 * @param endHyoji �\���I���ʒu
	 * @return ArrayList �񓚂̃��C�A�E�g�����擾����
	 */
	public ArrayList getKaitoLayout(final String loginNo, final String enqueteNo, final int startHyoji, final int endHyoji) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		final ArrayList kaitoLayoutList = new ArrayList();

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �񓚃��C�A�E�g���̎擾
			final String sql = "SELECT num, enquete_no, gamen_komoku_id,komoku_cd,	hyoji_junjo, shitsumon_bunsho, object_type,	kaito_su, default_value FROM (SELECT " + "KOMOKU.num AS NUM, "
					+ "ENQUETE." + HcdbDef.CPM_ENQUETE_SHITSUMON_COLUMNS[0] + " AS " + HcdbDef.CPM_ENQUETE_SHITSUMON_COLUMNS[0] + ", " + "KOMOKU." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[2] + " AS "
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[2] + ", " + "ENQUETE." + HcdbDef.CPM_ENQUETE_SHITSUMON_COLUMNS[1] + " AS " + HcdbDef.CPM_ENQUETE_SHITSUMON_COLUMNS[1] + ", " + "KOMOKU."
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + " AS " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + ", " + "ENQUETE." + HcdbDef.CPM_ENQUETE_SHITSUMON_COLUMNS[2] + " AS "
					+ HcdbDef.CPM_ENQUETE_SHITSUMON_COLUMNS[2] + ", " + "KOMOKU." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[5] + " AS " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[5] + ", " + "KOMOKU."
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[6] + " AS " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[6] + ", " + "KOMOKU." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[7] + " AS "
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[7] + " " + " FROM " + HcdbDef.CPM_ENQUETE_SHITSUMON_TBL + " ENQUETE, " + "(" + "SELECT " + "ROWNUM AS num, "
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[0] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[1] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[2] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3]
					+ ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[5] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[6] + ", "
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[7] + " " + "FROM " + "(" + "SELECT " + "* " + " FROM " + HcdbDef.CPP_KOMOKU_SEIGYO_TBL + " WHERE " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[0]
					+ "=? AND " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[1] + "=? " + " ORDER BY " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3] + ")" + ") KOMOKU "
					+ " WHERE " + "ENQUETE." + HcdbDef.CPM_ENQUETE_SHITSUMON_COLUMNS[0] + "=" + "KOMOKU." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[0] + " AND " + "ENQUETE."
					+ HcdbDef.CPM_ENQUETE_SHITSUMON_COLUMNS[1] + "=" + "KOMOKU." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3] + " ORDER BY hyoji_junjo,komoku_code ) where num BETWEEN ? AND ?  ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, enqueteNo);
			pstmt.setString(2, PED_QuestionnaireAnswerEJBBean.ENQUETE_GAMEN_ID);
			pstmt.setString(3, new Integer(startHyoji).toString());
			pstmt.setString(4, new Integer(endHyoji).toString());
			rs = pstmt.executeQuery();

			// �񓚃��C�A�E�g���̊i�[
			while (rs.next()) {
				final String num = rs.getString("NUM");
				final String gamenKomokuId = rs.getString(HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[2]);
				final String komokuCd = rs.getString(HcdbDef.CPM_ENQUETE_SHITSUMON_COLUMNS[1]);
				final String hyojiJunjo = rs.getString(HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4]);
				final String shitsumonBunsho = rs.getString(HcdbDef.CPM_ENQUETE_SHITSUMON_COLUMNS[2]);
				final String objectType = rs.getString(HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[5]);
				String kaitoSu = rs.getString(HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[6]);
				final String defaultValue = rs.getString(HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[7]);

				// �񓚐���null�Ή�
				if (kaitoSu == null || kaitoSu.equals("")) {
					kaitoSu = "0";
				}

				final HashMap map = new HashMap();
				map.put("NUM", num);
				map.put(HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[1], gamenKomokuId);
				map.put(HcdbDef.CPM_ENQUETE_SHITSUMON_COLUMNS[1], komokuCd);
				map.put(HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4], hyojiJunjo);
				map.put(HcdbDef.CPM_ENQUETE_SHITSUMON_COLUMNS[2], shitsumonBunsho);
				map.put(HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[5], objectType);
				map.put(HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[6], kaitoSu);
				map.put(HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[7], defaultValue);
				kaitoLayoutList.add(map);
			}

			Log.method(loginNo, "OUT", "");
			return kaitoLayoutList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �\���Ώۂ̉񓚂��擾
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�gNO
	 * @param viewPersonId �\���Ώۂ̐lID
	 * @param maxHyoji �ŏI�񓚈ʒu
	 * @param startHyoji �\���J�n�ʒu
	 * @param endHyoji �\���I���ʒu
	 * @return HashMap �\���Ώۂ̉񓚂��擾����
	 */
	public HashMap getKaitoData(final String loginNo, final String enqueteNo, final String viewPersonId, final int maxHyoji, final int startHyoji, final int endHyoji) throws SQLException,
			NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		final HashMap kaitoDataMap = new HashMap();

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �\���Ώۂ̉񓚂��擾
			final String sql = "SELECT komoku_code, kaito_naiyou,num FROM (SELECT " + "KAITO." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[2] + " AS " + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[2] + ", " + "KAITO."
					+ HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[3] + " AS " + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[3] + " ,KOMOKU.NUM AS num " + " FROM " + HcdbDef.CPS_ENQUETE_KAITO_TBL + " KAITO, " + "("
					+ "SELECT " + "ROWNUM AS num, " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[0] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[1] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[2] + ", "
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[5] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[6]
					+ ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[7] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[8] + " " + "FROM " + "(" + "SELECT " + "* " + " FROM " + HcdbDef.CPP_KOMOKU_SEIGYO_TBL
					+ " WHERE " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[0] + "=? AND " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[1] + "=? " + " ORDER BY " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + ", "
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3] + ")" + ") KOMOKU " + " WHERE " + "KAITO." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[1] + "=? AND " + "KOMOKU."
					+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[0] + "=" + "KAITO." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[0] + " AND " + "KOMOKU." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3] + "=" + "KAITO."
					+ HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[2] + " ORDER BY KOMOKU.hyoji_junjo, KOMOKU.KOMOKU_CODE) " + " WHERE num" + " BETWEEN " + "?" + " AND " + "? ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, enqueteNo);
			pstmt.setString(2, PED_QuestionnaireAnswerEJBBean.ENQUETE_GAMEN_ID);
			pstmt.setString(3, viewPersonId);
			pstmt.setString(4, new Integer(startHyoji).toString());
			pstmt.setString(5, new Integer(endHyoji).toString());
			rs = pstmt.executeQuery();

			// �\���Ώۂ̉񓚂̊i�[
			while (rs.next()) {
				final String komokuCode = rs.getString(HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[2]);
				final String kaitoNaiyou = rs.getString(HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[3]);

				kaitoDataMap.put(komokuCode, kaitoNaiyou);
			}

			Log.method(loginNo, "OUT", "");
			return kaitoDataMap;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �\���Ώۂ̉񓚕����Ǘ����擾
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�gNO
	 * @param gamenKomokuId ��ʍ���ID
	 * @return ArrayList �\���Ώۂ̉񓚕����Ǘ����擾����
	 */
	public ArrayList getKaitoKanri(final String loginNo, final String enqueteNo, final String gamenKomokuId) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		final ArrayList kaitoMongonList = new ArrayList();

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �\���Ώۂ̉񓚕����Ǘ����擾
			final String sql = "SELECT " + HcdbDef.CPP_KAITO_KANRI_COLUMNS[4] + " " + " FROM " + HcdbDef.CPP_KAITO_KANRI_TBL + " WHERE " + HcdbDef.CPP_KAITO_KANRI_COLUMNS[0] + "=? AND "
					+ HcdbDef.CPP_KAITO_KANRI_COLUMNS[1] + "=? AND " + HcdbDef.CPP_KAITO_KANRI_COLUMNS[2] + "=? " + " ORDER BY " + HcdbDef.CPP_KAITO_KANRI_COLUMNS[3];

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, enqueteNo);
			pstmt.setString(2, PED_QuestionnaireAnswerEJBBean.ENQUETE_GAMEN_ID);
			pstmt.setString(3, gamenKomokuId);
			rs = pstmt.executeQuery();

			// �\���Ώۂ̉񓚕����Ǘ��̊i�[
			while (rs.next()) {
				final String kaitoMongon = rs.getString(HcdbDef.CPP_KAITO_KANRI_COLUMNS[4]);

				kaitoMongonList.add(kaitoMongon);
			}

			Log.method(loginNo, "OUT", "");
			return kaitoMongonList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �񓚓��e��o�^
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�gNO
	 * @param viewPersonId �\���Ώۂ̐lID
	 * @param saveValueList �X�V���e
	 * @param status �X�e�[�^�X
	 * @param sysdate �V�X�e�����t
	 * @param systime �V�X�e������
	 * @param kaitoJyokyo ���݂̉񓚏�
	 * @return int �����͍��ڂ�No
	 */
	public int saveKaitoData(final String loginNo, final String enqueteNo, final String viewPersonId, final ArrayList saveValueList, String status, final String sysdate, final String systime,
			final String kaitoJyokyo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		// �߂�l�p�ϐ���ݒ�
		int noKaito = 0;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �X�V�����ϐ�
			int count = 0;

			String sql = "";
			// ���񓚂Ȃ�񓚒��ɕύX
			if ("0".equals(kaitoJyokyo)) {
				sql = "UPDATE " + HcdbDef.CPS_ENQUETE_JOKYO_TBL + " " + "SET " + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[2] + "=?, " + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[3] + "=?, "
						+ HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[4] + "=? " + "WHERE " + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[0] + "=? AND " + "TRIM(" + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[1] + ")=TRIM(?)";
				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				pstmt.setString(1, "1");
				pstmt.setString(2, sysdate);
				pstmt.setString(3, systime);
				pstmt.setString(4, enqueteNo);
				pstmt.setString(5, viewPersonId);
				pstmt.executeUpdate();
				PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);

			}
			// �񓚏󋵂�������������񓚃f�[�^�̍X�V���s��Ȃ�
			if (!"2".equals(kaitoJyokyo)) {

				for (int i = 0; i < saveValueList.size(); i++) {
					// �񓚓��e���擾
					final String[] saveValue = (String[]) saveValueList.get(i);

					// �X�V�Ώۂ̃f�[�^���o�^�ς��`�F�b�N
					int updateFlg = 0;
					sql = "SELECT " + "COUNT(*) AS cnt " + "FROM " + HcdbDef.CPS_ENQUETE_KAITO_TBL + " " + "WHERE " + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[0] + "=? AND "
							+ HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[1] + "=? AND " + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[2] + "=?";

					pstmt = dbConn.prepareStatement(sql);
					pstmt.clearParameters();
					pstmt.setString(1, enqueteNo);
					pstmt.setString(2, viewPersonId);
					pstmt.setString(3, saveValue[0]);
					rs = pstmt.executeQuery();

					if (rs.next()) {
						updateFlg = rs.getInt("cnt");
					}
					PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
					// �o�^�ς������ꍇ
					if (updateFlg != 0) {
						sql = "UPDATE " + HcdbDef.CPS_ENQUETE_KAITO_TBL + " " + "SET " + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[3] + "=? " + "WHERE " + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[0] + "=? AND "
								+ "TRIM(" + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[1] + ")=TRIM(?) AND " + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[2] + "=?";
						pstmt = dbConn.prepareStatement(sql);
						pstmt.clearParameters();
						pstmt.setString(1, saveValue[1]);
						pstmt.setString(2, enqueteNo);
						pstmt.setString(3, viewPersonId);
						pstmt.setString(4, saveValue[0]);
					}
					// �o�^����Ă��Ȃ������ꍇ
					else {
						sql = "INSERT INTO " + HcdbDef.CPS_ENQUETE_KAITO_TBL + " " + "(" + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[0] + ", " + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[1] + ", "
								+ HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[2] + ", " + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[3] + " " + ") VALUES (" + "?, ?, ?, ?)";
						pstmt = dbConn.prepareStatement(sql);
						pstmt.clearParameters();
						pstmt.setString(1, enqueteNo);
						pstmt.setString(2, viewPersonId);
						pstmt.setString(3, saveValue[0]);
						pstmt.setString(4, saveValue[1]);
					}
					count += pstmt.executeUpdate();
					PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
				}
				PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
				// �A���P�[�g�����������ꍇ
				if (status.equals("2")) {
					// �K�{���ڂ����ׂĎ擾����
					sql = "SELECT " + "num, " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3] + ",  " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + " FROM " + "(" + "SELECT " + "ROWNUM AS num, "
							+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3] + ",  " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[8] + " FROM (" + "SELECT "
							+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3] + ",  " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[8] + " FROM "
							+ HcdbDef.CPP_KOMOKU_SEIGYO_TBL + " WHERE " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[0] + "=? AND " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[1] + "=? " + " ORDER BY "
							+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + ", " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3] + ") KOMOKU)SORT " + " WHERE " + "" + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[8]
							+ "=? ORDER BY " + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + "," + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3];

					pstmt = dbConn.prepareStatement(sql);
					pstmt.clearParameters();
					pstmt.setString(1, enqueteNo);
					pstmt.setString(2, PED_QuestionnaireAnswerEJBBean.ENQUETE_GAMEN_ID);
					pstmt.setString(3, "1");
					rs = pstmt.executeQuery();

					final ArrayList hissuList = new ArrayList();

					// �K�{���ڂ�No���i�[
					while (rs.next()) {
						final String hissuNo = new Integer(rs.getInt("num")).toString();
						final String hissuCode = rs.getString(HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3]);
						hissuList.add(new String[] { hissuCode, hissuNo });
					}
					PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
					// �񓚍��ڂ��擾
					sql = "SELECT " + "KAITO." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[2] + ", " + "KAITO." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[3] + ", " + "SEIGYO."
							+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[5] + ", " + "SEIGYO." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[6] + " " + "FROM " + HcdbDef.CPS_ENQUETE_KAITO_TBL + " KAITO, "
							+ HcdbDef.CPP_KOMOKU_SEIGYO_TBL + " SEIGYO " + " WHERE " + "KAITO." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[0] + " = ? " + "AND " + "KAITO."
							+ HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[1] + " = ? " + "AND " + "KAITO." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[0] + " = " + "SEIGYO." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[0]
							+ " " + "AND " + "KAITO." + HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[2] + " = " + "SEIGYO." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3] + " " + "ORDER BY " + "SEIGYO."
							+ HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[4] + "," + "SEIGYO." + HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[3];

					pstmt = dbConn.prepareStatement(sql);
					pstmt.clearParameters();
					pstmt.setString(1, enqueteNo);
					pstmt.setString(2, viewPersonId);
					rs = pstmt.executeQuery();

					final Map objectTypeMap = new HashMap();
					final Map naiyoMap = new HashMap();
					final Map kaitoSuMap = new HashMap();

					// �񓚍��ڂ��i�[
					while (rs.next()) {
						final String kaitoCode = rs.getString(HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[2]);
						final String naiyo = rs.getString(HcdbDef.CPS_ENQUETE_KAITO_COLUMNS[3]);
						final String objectType = rs.getString(HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[5]);
						final String kaitoSu = rs.getString(HcdbDef.CPP_KOMOKU_SEIGYO_COLUMNS[6]);

						// ����C���L�[�Ɋe�l���i�[
						objectTypeMap.put(kaitoCode, objectType);
						naiyoMap.put(kaitoCode, naiyo);
						kaitoSuMap.put(kaitoCode, kaitoSu);
					}

					// �K�{���ڂ��`�F�b�N����
					for (int hissuCnt = 0; hissuCnt < hissuList.size(); hissuCnt++) {
						final String[] hissuKomoku = (String[]) hissuList.get(hissuCnt);

						// �Y�����ڂ̓��e���擾
						final String naiyo = (String) naiyoMap.get(hissuKomoku[0]);

						// �K�{���ڂ��񓚂���Ă��Ȃ������ꍇ
						if (naiyo == null || naiyo.equals("")) {
							noKaito = (new Integer(hissuKomoku[1])).intValue();
							break;
						}

						// �K�{���ڂ��񓚂���Ă���ꍇ
						else {
							// �Y�����ڂ̃I�u�W�F�N�g�^�C�v���擾
							final String objectType = (String) objectTypeMap.get(hissuKomoku[0]);

							// ���񓚃`�F�b�NFLG
							boolean nokaitoFlg = false;

							// �I�u�W�F�N�g�^�C�v��01�`04�������ꍇ
							if (objectType.equals("01") || objectType.equals("02") || objectType.equals("03") || objectType.equals("04")) {

								// �Y�����ڂ̉񓚐����擾
								final String kaitoSu = (String) kaitoSuMap.get(hissuKomoku[0]);

								// �񓚓��e��ؽČ^�Ŏ擾
								final ArrayList valueList = this.getKaitoNaiyouList(objectType, naiyo);

								// �񓚓��e�i�[�ϐ�
								int value = 0;

								// ���͒l��S�ă`�F�b�N
								for (int i = 0; i < valueList.size(); i++) {
									try {
										// �񓚓��e���擾
										value = new Integer((String) valueList.get(i)).intValue();

										// �񓚓��e��1�`�񓚐��̒l�ł͂Ȃ��ꍇ
										if (value < 1 || value > (new Integer(kaitoSu)).intValue()) {
											// ���񓚂Ƃ���
											nokaitoFlg = true;
											break;
										}
									} catch (final NumberFormatException nfe) {
										// �����^�ł͖����ꍇ�A���񓚂Ƃ���
										nokaitoFlg = true;
										break;
									}
								}
								// �J�E���g�Ώۂ������ꍇ
								if (nokaitoFlg) {
									noKaito = (new Integer(hissuKomoku[1])).intValue();
									break;
								}
							}
						}

					}
					PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
					// �K�{���ڂŖ����͂���
					if (noKaito > 0) {
						status = "";
					}
				}
				PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
			}
			// �A���P�[�g�󋵂ւ̓o�^
			// �X�e�[�^�X����̏ꍇ�̓X�e�[�^�X��o�^���Ȃ�
			if (status.equals("")) {
				sql = "UPDATE " + HcdbDef.CPS_ENQUETE_JOKYO_TBL + " " + "SET " + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[3] + "=?, " + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[4] + "=? " + "WHERE "
						+ HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[0] + "=? AND " + "TRIM(" + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[1] + ")=TRIM(?)";
				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				pstmt.setString(1, sysdate);
				pstmt.setString(2, systime);
				pstmt.setString(3, enqueteNo);
				pstmt.setString(4, viewPersonId);
			}
			// �X�e�[�^�X����ł͂Ȃ��ꍇ�A�X�e�[�^�X�����킹�čX�V����
			else {
				sql = "UPDATE " + HcdbDef.CPS_ENQUETE_JOKYO_TBL + " " + "SET " + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[2] + "=?, " + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[3] + "=?, "
						+ HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[4] + "=? " + "WHERE " + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[0] + "=? AND " + "TRIM(" + HcdbDef.CPS_ENQUETE_JOKYO_COLUMNS[1] + ")=TRIM(?)";
				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				pstmt.setString(1, status);
				pstmt.setString(2, sysdate);
				pstmt.setString(3, systime);
				pstmt.setString(4, enqueteNo);
				pstmt.setString(5, viewPersonId);
			}
			pstmt.executeUpdate();

			Log.method(loginNo, "OUT", "");

			return noKaito;
		} catch (final SQLException sqle) {
			this.context.setRollbackOnly();
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			this.context.setRollbackOnly();
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �񓚓��e��","��؂��List�Ɋi�[�������̂�Ԃ�
	 * @param objectType �I�u�W�F�N�g�^�C�v
	 * @param value �񓚓��e
	 * @return ArrayList �񓚓��e��","��؂��List�Ɋi�[�������̂�Ԃ�
	 */
	private ArrayList getKaitoNaiyouList(final String objectType, String value) {

		// �߂�l�ϐ���ݒ�
		final ArrayList valueList = new ArrayList();

		if (value == null) {
			value = "";
		}

		// �I�u�W�F�N�g���`�F�b�N�{�b�N�X�������ꍇ
		if (objectType.equals("03") || objectType.equals("04")) {
			// ","��؂�Ŕz��𐶐�
			final String[] values = value.split(",");
			// ArrayList�Ɋi�[
			for (int i = 0; i < values.length; i++) {
				valueList.add(values[i]);
			}
		}
		// �I�u�W�F�N�g�^�C�v���`�F�b�N�{�b�N�X�ȊO�������ꍇ
		else {
			// �񓚓��e��߂�l�Ɋi�[
			valueList.add(value);
		}
		return valueList;
	}

}
