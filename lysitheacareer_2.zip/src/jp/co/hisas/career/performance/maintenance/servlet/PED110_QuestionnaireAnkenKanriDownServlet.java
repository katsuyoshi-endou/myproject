/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.performance.answer.bean.PED_QuestionnaireBean2;
import jp.co.hisas.career.performance.maintenance.bean.PED_QuestionnaireAnkenKanriBean;
import jp.co.hisas.career.performance.maintenance.bean.PED_QuestionnaireBean;
import jp.co.hisas.career.performance.maintenance.bean.PED_TaishoushaSetteiValueBean;
import jp.co.hisas.career.performance.report.bean.PED_TotalizePerformanceReportValueBean;
import jp.co.hisas.career.performance.util.bean.PED_PerformanceBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * �A���P�[�g�Č��Ǘ��������ʈꗗ
 * @author Torigoe
 */
public class PED110_QuestionnaireAnkenKanriDownServlet extends HttpServlet {

	/** �G���[�y�[�W */
	private static final String ERROR_PAGE = "/view/base/error/VYY_Error.jsp";

	/** �J�ڐ�y�[�W */
	private static final String SUCCESS_PAGE = "/view/performance/maintenance/VED110_QuestionnaireAnkenKanriDown.jsp";

	private ServletContext ctx = null;

	public static final String SEPARATOR = "\",\"";

	public static final String HEAD = "\"";

	private final String UNDER_BAR = "_";

	/** �񓚏�CSV�t�@�C���� */
	private final String FILE_NAME_KAITOJOKYO = "KaitouJokyo.csv";

	/** ���{��G���R�[�h */
	private final String JAPANESE_ENCODING = "Windows-31J";

	/** UNICODE�G���R�[�h */
	private final String UNICODE_ENCODING = "ISO-8859-1";

	public void init(final ServletConfig config) throws ServletException {
		super.init(config);

		// ���\�b�h�g���[�X�o��
		Log.method("", "IN", "");

		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
		// ���\�b�h�g���[�X�o��
		Log.method("", "OUT", "");
	}

	public void service(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {

		final HttpSession session = request.getSession(false);

		// �Z�b�V�����A�܂���userinfo���擾�ł��Ȃ��ꍇ�A�G���[�y�[�W�֑J��
		if (session == null || (UserInfoBean) session.getAttribute("userinfo") == null) {
			this.ctx.getRequestDispatcher(PED110_QuestionnaireAnkenKanriDownServlet.ERROR_PAGE).forward(request, response);
		} else {
			String loginNo = null;
			try {
				final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");
				Log.performance(loginNo, true, "");
				loginNo = userinfo.getLogin_no();
				// �A���P�[�gBean
				PED_PerformanceBean eBean = (PED_PerformanceBean) session.getAttribute(PED_PerformanceBean.SESSION_KEY);
				if (eBean == null) {
					eBean = new PED_PerformanceBean();
				}
				// �A���P�[�g��ʍ��ڊ֘ABean
				PED_QuestionnaireBean bean = eBean.getAnkenKanriBean();
				if (bean == null) {
					bean = new PED_QuestionnaireBean();
					eBean.setAnkenKanriBean(bean);
				}
				final PED_QuestionnaireAnkenKanriBean Qbean = new PED_QuestionnaireAnkenKanriBean(userinfo.getLogin_no());
				final String execMode = request.getParameter("execMode");
				String fwFlg = "false";
				String fwPage = PED110_QuestionnaireAnkenKanriDownServlet.SUCCESS_PAGE;
				if (execMode != null && execMode.equals("statusUpdate")) {
					// �A���P�[�g�X�e�[�^�X�̍X�V
					final String tmpf = request.getParameter("statusUpdateFlg");
					int uflg = 0;
					if (tmpf.equals("start")) {
						uflg = 1;
					} else if (tmpf.equals("stop")) {
						uflg = 2;
					}
					request.setAttribute("statusUpdateFlg", tmpf);
					final String result = Qbean.updateStatus(request.getParameter("no"), uflg);
					request.setAttribute("statResult", result);
				} else if (execMode != null && execMode.equals("forwardPage")) {
					// ��ʑJ��
					final HashMap pages = new HashMap();
					pages.put("VED120", "/servlet/PED120_AnkenTorokuKoshinServlet");
					pages.put("VED130", "/servlet/PED130_TaishoushaSetteiServlet");
					pages.put("VED140", "/servlet/PED140_SousinTaisyoSetteiServlet");
					pages.put("VED150", "/servlet/PED150_TotalizePerformanceReportServlet");
					pages.put("VED220", "/servlet/PED220_QuestionnaireAnswerServlet");

					final String no = request.getParameter("no");
					final String stat = Qbean.getStatus(no);
					final String fw = request.getParameter("pid");
					fwPage = "/view/performance/maintenance/VED110_QuestionnaireAnkenKanriFrame.jsp";
					if (fw.equals("VED120")) {
						if (stat.equals("2")) {
							fwPage = (String) pages.get(fw);
							fwFlg = "true";
						} else {
							fwFlg = "1";
						}
					}
					if (fw.equals("VED130")) {
						if (stat.equals("2")) {
							fwPage = (String) pages.get(fw);
							fwFlg = "true";
						} else {
							fwFlg = "2";
						}
						final PED_TaishoushaSetteiValueBean pBean = new PED_TaishoushaSetteiValueBean();
						eBean.setTaishoBean(pBean);
					}
					if (fw.equals("VED140")) {
						fwPage = (String) pages.get(fw);
						fwFlg = "true";
					}
					if (fw.equals("VED150")) {
						if (stat.equals("2") || stat.equals("3")) {
							fwPage = (String) pages.get(fw);
							fwFlg = "true";
						} else {
							fwFlg = "3";
						}

						PED_TotalizePerformanceReportValueBean pBean = null;
						pBean = eBean.getReportBean();
						if (pBean == null) {
							pBean = new PED_TotalizePerformanceReportValueBean();
						}
						pBean.setBatchStatus(PED_TotalizePerformanceReportValueBean.BATCH_STATUS);
						pBean.setInit(true);
						pBean.setChoiceSoshikiID(new ArrayList());
						eBean.setReportBean(pBean);
					}
					if (fw.equals("VED220")) {
						fwPage = (String) pages.get(fw);
						fwFlg = "true";
						final PED_QuestionnaireBean2 questionBean = new PED_QuestionnaireBean2();
						questionBean.setBeforePage("VED110");
						eBean.setPveQuestionnaireBean(questionBean);
					}
					if (fwFlg.equals("true")) {
						// ����ʂɈ����n���l���擾
						final ArrayList tmpArray = Qbean.searchQuestionnaire(no, "", new String[] {}, "", "");
						final String[] eInfo = (String[]) tmpArray.get(0);
						eBean.setEnqueteNo(eInfo[0]);
						eBean.setEnqueteNm(eInfo[1]);
						eBean.setEnqueteStatusName(eInfo[2]);
						eBean.setEnqueteStatus(eInfo[7]);
						bean.setResultFlg(null);
					} else {
						bean.setResultFlg(fwFlg);
					}
					// �A���P�[�gBean���Z�b�g
					session.setAttribute(PED_PerformanceBean.SESSION_KEY, eBean);
					// �Y��JSP�y�[�W�̃y�[�W���i�[
				} else if (execMode != null && execMode.equals("writeCSV")) {

					// �񓚏�CSV�o��
					final String enqueteNo = request.getParameter("no");
					// �A���P�[�g�����擾
					final String enqueteName = Qbean.getEnqueteName(enqueteNo);
					// CSV�̃f�[�^��ҏW
					final String[] dataarray = Qbean.getCSVData(enqueteNo);

					final StringBuffer sb = new StringBuffer();
					// �P�s��
					sb.append(PED110_QuestionnaireAnkenKanriDownServlet.HEAD + enqueteNo + PED110_QuestionnaireAnkenKanriDownServlet.SEPARATOR + enqueteName
							+ PED110_QuestionnaireAnkenKanriDownServlet.HEAD);
					sb.append(System.getProperty("line.separator"));
					// �Q�s��
					sb.append(PED110_QuestionnaireAnkenKanriDownServlet.HEAD + "����NO" + PED110_QuestionnaireAnkenKanriDownServlet.SEPARATOR + "��������"
							+ PED110_QuestionnaireAnkenKanriDownServlet.SEPARATOR + "�����R�[�h" + PED110_QuestionnaireAnkenKanriDownServlet.SEPARATOR + "������"
							+ PED110_QuestionnaireAnkenKanriDownServlet.SEPARATOR + "��E�R�[�h" + PED110_QuestionnaireAnkenKanriDownServlet.SEPARATOR + "��E��"
							+ PED110_QuestionnaireAnkenKanriDownServlet.SEPARATOR + "����" + PED110_QuestionnaireAnkenKanriDownServlet.SEPARATOR + "�O��"
							+ PED110_QuestionnaireAnkenKanriDownServlet.SEPARATOR + "MAIL" + PED110_QuestionnaireAnkenKanriDownServlet.SEPARATOR + "�񓚏�"
							+ PED110_QuestionnaireAnkenKanriDownServlet.SEPARATOR + "�ŏI�񓚓���" + PED110_QuestionnaireAnkenKanriDownServlet.HEAD);
					sb.append(System.getProperty("line.separator"));
					// �R�s�ڈȍ~
					for (int c = 0; c < dataarray.length; c++) {
						sb.append(dataarray[c]);
						sb.append(System.getProperty("line.separator"));
					}

					final String csvData = sb.toString();

					/* �G���[CSV�t�@�C�����o�� */
					final PrintWriter out = response.getWriter();
					response.setContentType("application/csv");

					// �V�X�e�����t���擾
					final String sysdate = PZZ010_CharacterUtil.GetDay();
					final String systime = PZZ010_CharacterUtil.GetTime();

					String filename = loginNo + this.UNDER_BAR + sysdate + systime + this.UNDER_BAR + this.FILE_NAME_KAITOJOKYO;

					/* �t�@�C������UNICODE�ɕϊ� */
					filename = new String(filename.getBytes(this.JAPANESE_ENCODING), this.UNICODE_ENCODING);
					response.setHeader("Content-Disposition", "attachment; filename=" + filename);

					/* ���e��UNICODE�ɕϊ� */
					final String str = new String(csvData.getBytes(this.JAPANESE_ENCODING), this.UNICODE_ENCODING);

					out.write(str);
					out.close();
					response.flushBuffer();

					return;

				} else if (request.getParameter("bunrui") != null) {
					// ���������̕ێ�
					bean.setNo(request.getParameter("no"));
					bean.setBunrui(request.getParameter("bunrui"));
					bean.setStatus(request.getParameterValues("status"));
					bean.setKikanKaisi(request.getParameter("kikan_kaisi"));
					bean.setKikanSyuryo(request.getParameter("kikan_shuryo"));

				}
				if (bean.getBunrui() != null && !bean.getBunrui().equals("")) {
					// ��������
					final String no = bean.getNo();
					final String bunrui = bean.getBunrui();
					final String status[] = bean.getStatus();
					final String kaisi = bean.getKikanKaisi();
					final String shuryo = bean.getKikanSyuryo();
					bean.setSearchResult(Qbean.searchQuestionnaire(no, bunrui, status, kaisi, shuryo));
				}

				// �Y��JSP�y�[�W�֑J��
				final RequestDispatcher rd = this.ctx.getRequestDispatcher(fwPage);
				rd.forward(request, response);
				Log.performance(loginNo, false, "");
			} catch (final Exception e) {
				Log.error(loginNo, e);
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			}
		}

	}

}
