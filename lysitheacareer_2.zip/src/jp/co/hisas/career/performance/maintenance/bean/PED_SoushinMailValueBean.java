/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.bean;

import java.io.Serializable;
import java.util.ArrayList;

public class PED_SoushinMailValueBean implements Serializable {

	/** ���� */
	private String subject;

	/** �����h�c */
	private String parameterID;

	/** �A���P�[�g�m�n */
	private String enqueteNo;

	/** �A���P�[�g���� */
	private String enqueteNm;

	/** �A���P�[�g��� */
	private String enqueteStatus;

	/** �J�n���t */
	private String startDate;

	/** �J�n���� */
	private String startTime;

	/** �I�����t */
	private String endDate;

	/** �I������ */
	private String endTime;

	/** �ǉ��R�����g */
	private String addComment;

	/** ���M�Ώێ҃��X�g */
	private ArrayList soushinPersonList;

	/** ���e */
	private String mailContent;

	/** ���b�Z�[�W */
	private String messageID;

	/** ���[�����M�G���[ */
	private boolean isError = false;

	/**
	 * @return isError ��߂��܂��B
	 */
	public boolean isError() {
		return this.isError;
	}

	/**
	 * @param isError �ݒ肷�� isError�B
	 */
	public void setError(final boolean isError) {
		this.isError = isError;
	}

	public String getMailContent() {
		return this.mailContent;
	}

	public void setMailContent(final String mailContent) {
		this.mailContent = mailContent;
	}

	public String getMessageID() {
		return this.messageID;
	}

	public void setMessageID(final String messageID) {
		this.messageID = messageID;
	}

	public String getEnqueteNo() {
		return this.enqueteNo;
	}

	public void setEnqueteNo(final String enqueteNo) {
		this.enqueteNo = enqueteNo;
	}

	public String getEnqueteStatus() {
		return this.enqueteStatus;
	}

	public void setEnqueteStatus(final String enqueteStatus) {
		this.enqueteStatus = enqueteStatus;
	}

	public String getParameterID() {
		return this.parameterID;
	}

	public void setParameterID(final String parameterID) {
		this.parameterID = parameterID;
	}

	public String getAddComment() {
		return this.addComment;
	}

	public void setAddComment(final String addComment) {
		this.addComment = addComment;
	}

	public String getEndDate() {
		return this.endDate;
	}

	public void setEndDate(final String endDate) {
		this.endDate = endDate;
	}

	public String getEndTime() {
		return this.endTime;
	}

	public void setEndTime(final String endTime) {
		this.endTime = endTime;
	}

	public String getEnqueteNm() {
		return this.enqueteNm;
	}

	public void setEnqueteNm(final String enqueteNm) {
		this.enqueteNm = enqueteNm;
	}

	public ArrayList getSoushinPersonList() {
		return this.soushinPersonList;
	}

	public void setSoushinPersonList(final ArrayList soushinPersonList) {
		this.soushinPersonList = soushinPersonList;
	}

	public String getStartDate() {
		return this.startDate;
	}

	public void setStartDate(final String startDate) {
		this.startDate = startDate;
	}

	public String getStartTime() {
		return this.startTime;
	}

	public void setStartTime(final String startTime) {
		this.startTime = startTime;
	}

	public String getSubject() {
		return this.subject;
	}

	public void setSubject(final String subject) {
		this.subject = subject;
	}
}