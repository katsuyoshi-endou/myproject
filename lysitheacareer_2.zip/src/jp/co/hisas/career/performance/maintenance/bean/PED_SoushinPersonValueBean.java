/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.bean;

import java.io.Serializable;

/**
 * ���M�lValueBean
 * @author �Β�
 */
public class PED_SoushinPersonValueBean implements Serializable {

	/** �I�� */
	private boolean sendFlg;

	/** �l�h�c */
	private String personID;

	/** �����m�n */
	private String shimeiNo;

	/** ���� */
	private String kanjiShimei;

	/** �g�D�R�[�h */
	private String soshiki;

	/** ��E�R�[�h */
	private String yakushoku;

	/** ��� */
	private String status;

	/** ���[�� */
	private String mail;

	public String getPersonID() {
		return this.personID;
	}

	public void setPersonID(final String personID) {
		this.personID = personID;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(final String status) {
		this.status = status;
	}

	public String getSoshiki() {
		return this.soshiki;
	}

	public void setSoshiki(final String soshiki) {
		this.soshiki = soshiki;
	}

	public String getYakushoku() {
		return this.yakushoku;
	}

	public void setYakushoku(final String yakushoku) {
		this.yakushoku = yakushoku;
	}

	public boolean isSendFlg() {
		return this.sendFlg;
	}

	public void setSendFlg(final boolean sendFlg) {
		this.sendFlg = sendFlg;
	}

	public String getMail() {
		return this.mail;
	}

	public void setMail(final String mail) {
		this.mail = mail;
	}

	public String getShimeiNo() {
		return this.shimeiNo;
	}

	public void setShimeiNo(final String shimeiNo) {
		this.shimeiNo = shimeiNo;
	}

	public String getKanjiShimei() {
		return this.kanjiShimei;
	}

	public void setKanjiShimei(final String kanjiShimei) {
		this.kanjiShimei = kanjiShimei;
	}
}