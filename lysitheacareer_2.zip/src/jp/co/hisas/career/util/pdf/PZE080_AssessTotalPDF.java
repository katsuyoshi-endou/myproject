/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i�v��nCareer@Net�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/09/07  01.00       �n�� ��q     �V�K�쐬  <C-PPE02-004>
 *   2004/09/22              �n�� ��q     �o�͕s���C��  <B-PPE02-019>
 *   2004/09/22              �n�� ��q     PDF�\������   <B-PPE02-020>
 * 
 */

package jp.co.hisas.career.util.pdf;

import java.awt.Color;
import java.awt.Point;
import java.io.IOException;
import java.io.OutputStream;

import jp.co.hisas.career.util.log.Log;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class PZE080_AssessTotalPDF {

	// ���O�C��No
	private String login_no;

	// PDF���
	String[] annoItem = null;

	String[] paraItem = null;

	String[] percentDef = null;

	String[][] colorDef = null;

	String memberCnt = null;

	String matchTotal = null;

	String[][] syoku_list = null;

	String[][] senmon_list = null;

	String[][] level_list = null;

	String searchCnd = null; // INS#P-PPE02-019-004

	/** ��啪��A���x���̃T�u�e�[�u���̗� */
	private static final float[] SENOMON_LEVEL_TABLE_COMMN_WIDTHS = { 45f, 35f };

	private static final float[] PDF_COLUMN_WIDTHS = { 20f, 80f };

	/**
	 * �R���X�g���N�^
	 * @param login_no
	 */
	public PZE080_AssessTotalPDF(final String login_no) {
		this.login_no = login_no;
	}

	/**
	 * �A�i�E���X������ݒ肷��B
	 * @param val
	 */
	public void setAnnounce(final String[] val) {
		this.annoItem = val;
	}

	/**
	 * �O����`���ڂ�ݒ肷��B
	 * @param val
	 */
	public void setParameter(final String[] val) {
		this.paraItem = val;
	}

	/**
	 * �F��`��ݒ肷��B
	 * @param val
	 */
	public void setPercentDef(final String[] val) {
		this.percentDef = val;
	}

	/**
	 * �F��`��ݒ肷��B
	 * @param val
	 */
	public void setColorDef(final String[][] val) {
		this.colorDef = val;
	}

	/**
	 * ��������ݒ肷��B
	 * @param val
	 */
	public void setMemberCnt(final String val) {
		this.memberCnt = val;
	}

	/**
	 * �W�v���ʐl����ݒ肷��B
	 * @param val
	 */
	public void setMatchTotal(final String val) {
		this.matchTotal = val;
	}

	/**
	 * �E�탊�X�g��ݒ肷��B
	 * @param val
	 */
	public void setSyokuList(final String[][] val) {
		this.syoku_list = val;
	}

	/**
	 * ��啪�샊�X�g��ݒ肷��B
	 * @param val
	 */
	public void setSenmonList(final String[][] val) {
		this.senmon_list = val;
	}

	/**
	 * ���x�����X�g��ݒ肷��B
	 * @param val
	 */
	public void setLevelList(final String[][] val) {
		this.level_list = val;
	}

	// INS#P-PPE02-019-004-S
	/**
	 * ����������ݒ肷��B
	 * @param val
	 */
	public void setSearchCnd(final String val) {
		this.searchCnd = val;
	}

	// INS#P-PPE02-019-004-E

	/**
	 * PDF���쐬����
	 * @return
	 */
	public void executePDF(final OutputStream ops) throws Exception {
		Log.method(this.login_no, "IN", "");

		// �f�t�H���g�e�[�u���̐ݒ�
		class MyTable extends Table {
			/**
			 * @param arg0
			 * @throws BadElementException
			 */
			public MyTable(final int arg0) throws BadElementException {
				super(arg0);
				this.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
				this.setDefaultVerticalAlignment(Element.ALIGN_MIDDLE);

				this.setPadding(1);
			}

			/**
			 * @param arg0
			 * @throws BadElementException
			 */
			public MyTable(final int arg0, final int arg1) throws BadElementException {
				super(arg0, arg1);
				this.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
				this.setDefaultVerticalAlignment(Element.ALIGN_MIDDLE);

				this.setPadding(1);
			}

		}

		// null�`�F�b�N
		if (this.annoItem == null) {
			throw new Exception("PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B");
		}
		if (this.paraItem == null) {
			throw new Exception("PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B");
		}
		if (this.percentDef == null) {
			throw new Exception("PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B");
		}
		if (this.colorDef == null) {
			throw new Exception("PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B");
		}
		if (this.memberCnt == null) {
			throw new Exception("PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B");
		}
		if (this.matchTotal == null) {
			throw new Exception("PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B");
		}
		if (this.syoku_list == null) {
			throw new Exception("PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B");
		}
		if (this.senmon_list == null) {
			throw new Exception("PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B");
		}
		if (this.level_list == null) {
			throw new Exception("PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B");
		}

		/*
		 * Document�I�u�W�F�N�g�̐��� A4�c�́ADocument document = new Document( PageSize.A4 ); A4���́ADocument document = new Document( PageSize.A4.rotate() );
		 */

		final Document document = new Document(PageSize.A4);
		PdfWriter pw = null;

		try {
			// PdfWriter�I�u�W�F�N�g�̐���
			pw = PdfWriter.getInstance(document, ops);
			pw.setCloseStream(true);

			// �w�i�F
			final Color backColor = Color.white;
			// ���F
			final Color borderColor = Color.black;
			// �F�w��p�ݒ�
			final Color CellColor1 = new Color(Integer.parseInt(this.colorDef[0][0]), Integer.parseInt(this.colorDef[0][1]), Integer.parseInt(this.colorDef[0][2]), 0);

			final Color CellColor2 = new Color(Integer.parseInt(this.colorDef[1][0]), Integer.parseInt(this.colorDef[1][1]), Integer.parseInt(this.colorDef[1][2]), 0);

			final Color CellColor3 = new Color(Integer.parseInt(this.colorDef[2][0]), Integer.parseInt(this.colorDef[2][1]), Integer.parseInt(this.colorDef[2][2]), 0);

			final Color CellColor4 = new Color(Integer.parseInt(this.colorDef[3][0]), Integer.parseInt(this.colorDef[3][1]), Integer.parseInt(this.colorDef[3][2]), 0);

			final Color CellColor5 = new Color(Integer.parseInt(this.colorDef[4][0]), Integer.parseInt(this.colorDef[4][1]), Integer.parseInt(this.colorDef[4][2]), 0);
			// ���v���\���p
			final Color backColorB = new Color(204, 204, 255);

			// �\�w�b�_�\���p
			final Color backColorT = new Color(39, 64, 139);

			// �h�L�������g��OPEN
			final HeaderFooter footer = new HeaderFooter(new Phrase("- "), new Phrase(" -"));
			footer.setBorderColor(backColor);
			footer.setAlignment(Element.ALIGN_CENTER);
			document.setFooter(footer);
			document.setMargins(18, 18, 30, 18); // CHG#P-PPE02-020-001
			document.open();

			// �t�H���g�̐ݒ�
			final float default_font_size = 9;
			final BaseFont bf = BaseFont.createFont("HeiseiMin-W3", "UniJIS-UCS2-HW-H", false);
			final Font font = new Font(bf, default_font_size);
			final Font font_white = new Font(bf, default_font_size);
			font_white.setColor(Color.white);
			// INS#P-PPE02-019-004-S
			final Font font_red = new Font(bf, default_font_size);
			font_red.setColor(Color.red);
			// INS#P-PPE02-019-004-E

			// �J�����̕�
			final int[] topBaseWidths = { 25, 75 };
			final int[] topLegWidths = { 50, 50 };
			final int[] topExpWidths = { 3, 20, 10, 10, 22, 10, 15 };

			Cell cell;

			// ���Top����
			// INS#P-PPE02-019-004-S
			final Table headTable = new MyTable(1);
			headTable.setWidth(100);
			headTable.setBorderColor(backColor);
			cell = new Cell(new Phrase("�� " + this.searchCnd, font_red));
			cell.setBorder(0);
			headTable.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
			headTable.addCell(cell);

			// document�ɔz�u
			document.add(headTable);
			// INS#P-PPE02-019-004-E

			final Table baseTable = new MyTable(2);
			baseTable.setWidth(100);
			baseTable.setWidths(topBaseWidths);
			baseTable.setBorderColor(backColor);

			// �}��\����
			final String range1 = this.percentDef[1] + "% �` " + this.percentDef[0] + "% : ";
			final String range2 = this.percentDef[2] + "% �` " + this.percentDef[1] + "% : ";
			final String range3 = this.percentDef[3] + "% �` " + this.percentDef[2] + "% : ";
			final String range4 = this.percentDef[4] + "% �` " + this.percentDef[3] + "% : ";
			final String range5 = "0% �` " + this.percentDef[4] + "% : ";

			final Table legendTable = new MyTable(2, 6);
			legendTable.setWidth(100);
			legendTable.setWidths(topLegWidths);
			legendTable.setBorderColor(backColor);

			// �}��
			Cell legCell = new Cell(new Phrase("<<�}��>>", font));
			legCell.setBorderColor(backColor);
			legendTable.setDefaultVerticalAlignment(Element.ALIGN_BOTTOM); // CHG#P-PPE02-020-001
			legendTable.setDefaultHorizontalAlignment(Element.ALIGN_CENTER); // �}��͒�����
			legendTable.addCell(legCell, new Point(0, 0));
			legendTable.setDefaultVerticalAlignment(Element.ALIGN_MIDDLE); // INS#P-PPE02-020-001
			legendTable.setDefaultHorizontalAlignment(Element.ALIGN_RIGHT); // ����ȊO�͉E��
			// 8%�`10%
			legCell = new Cell(new Phrase(range1, font));
			legCell.setBorderColor(backColor);
			legendTable.addCell(legCell, new Point(1, 0));
			// 6%�`8%
			legCell = new Cell(new Phrase(range2, font));
			legCell.setBorderColor(backColor);
			legendTable.addCell(legCell, new Point(2, 0));
			// 4%�`6%
			legCell = new Cell(new Phrase(range3, font));
			legCell.setBorderColor(backColor);
			legendTable.addCell(legCell, new Point(3, 0));
			// 2%�`4%
			legCell = new Cell(new Phrase(range4, font));
			legCell.setBorderColor(backColor);
			legendTable.addCell(legCell, new Point(4, 0));
			// 0%�`2%
			legCell = new Cell(new Phrase(range5, font));
			legCell.setBorderColor(backColor);
			legendTable.addCell(legCell, new Point(5, 0));

			// �}��̐F��\��
			// 8%�`10%
			legCell = new Cell(new Phrase("", font));
			legCell.setBorderColor(backColor);
			legCell.setBackgroundColor(CellColor1);
			legendTable.addCell(legCell, new Point(1, 1));
			// 6%�`8%
			legCell = new Cell(new Phrase("", font));
			legCell.setBorderColor(backColor);
			legCell.setBackgroundColor(CellColor2);
			legendTable.addCell(legCell, new Point(2, 1));
			// 4%�`6%
			legCell = new Cell(new Phrase("", font));
			legCell.setBorderColor(backColor);
			legCell.setBackgroundColor(CellColor3);
			legendTable.addCell(legCell, new Point(3, 1));
			// 2%�`4%
			legCell = new Cell(new Phrase("", font));
			legCell.setBorderColor(backColor);
			legCell.setBackgroundColor(CellColor4);
			legendTable.addCell(legCell, new Point(4, 1));
			// 0%�`2%
			legCell = new Cell(new Phrase("", font));
			legCell.setBorderColor(borderColor);
			legCell.setBackgroundColor(CellColor5);
			legendTable.addCell(legCell, new Point(5, 1));

			// �A�i�E���X�\����
			final Table expTable = new MyTable(7, 6);
			expTable.setWidth(90);
			expTable.setWidths(topExpWidths);
			expTable.setBorderColor(backColor);
			expTable.setPadding(0);

			// �A�i�E���X����
			expTable.setDefaultVerticalAlignment(Element.ALIGN_MIDDLE);
			expTable.setDefaultHorizontalAlignment(Element.ALIGN_RIGHT);
			Cell expCell = new Cell(new Phrase("��", font));
			expCell.setBorderColor(backColor);
			expTable.addCell(expCell, new Point(0, 0));
			expTable.addCell(expCell, new Point(1, 0));
			expCell = new Cell(new Phrase("", font));
			expCell.setBorderColor(backColor);
			expTable.addCell(expCell, new Point(5, 0));

			expTable.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
			expCell = new Cell(new Phrase(this.annoItem[0], font));
			expCell.setColspan(6);
			expCell.setBorderColor(backColor);
			expTable.addCell(expCell, new Point(0, 1));
			expCell = new Cell(new Phrase(this.annoItem[1], font));
			expCell.setColspan(6);
			expCell.setBorderColor(backColor);
			expTable.addCell(expCell, new Point(1, 1));
			expCell = new Cell(new Phrase(this.annoItem[2], font)); // CHG#P-PPE02-019-004 //CHG#BPX-0301J-1087
			expCell.setColspan(6);
			expCell.setBorderColor(backColor);
			expTable.addCell(expCell, new Point(5, 1));

			// �W�v���ʕ\��
			// ����(�E��)
			expTable.setDefaultHorizontalAlignment(Element.ALIGN_RIGHT);
			expCell = new Cell(new Phrase("�W�v���� : ", font));
			expCell.setColspan(2);
			expCell.setBorderColor(backColorB);
			expCell.setBackgroundColor(backColorB);
			expTable.addCell(expCell, new Point(3, 0));
			expCell = new Cell(new Phrase("�M" + this.paraItem[3] + "�l���v : ", font));
			expCell.setBorderColor(backColorB);
			expCell.setBackgroundColor(backColorB);
			expTable.addCell(expCell, new Point(3, 4));
			// ����(����)
			expTable.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
			// CHG#BPX-0301J-1121 -S
			expCell = new Cell(new Phrase("��", font));
			expCell.setBorderColor(backColorB);
			expCell.setBackgroundColor(backColorB);
			expTable.addCell(expCell, new Point(3, 3));
			expCell = new Cell(new Phrase("��", font));
			expCell.setBorderColor(backColorB);
			expCell.setBackgroundColor(backColorB);
			expTable.addCell(expCell, new Point(3, 6));
			// CHG#BPX-0301J-1121 -E
			// ��s
			expCell = new Cell(new Phrase("", font));
			expCell.setColspan(7);
			expCell.setBorderColor(backColorB);
			expCell.setBackgroundColor(backColorB);
			expTable.addCell(expCell, new Point(2, 0));
			expTable.addCell(expCell, new Point(4, 0));

			// �W�v�l
			// �Y���l��
			expTable.setDefaultHorizontalAlignment(Element.ALIGN_RIGHT);
			expCell = new Cell(new Phrase(this.matchTotal, font));
			expCell.setBorderColor(borderColor);
			expTable.addCell(expCell, new Point(3, 2));
			// �����l�����v
			expCell = new Cell(new Phrase(this.memberCnt, font));
			expCell.setBorderColor(borderColor);
			expTable.addCell(expCell, new Point(3, 5));

			final Cell nestCell1 = new Cell("");
			final Cell nestCell2 = new Cell("");
			nestCell1.add(legendTable);
			nestCell2.add(expTable);

			baseTable.addCell(nestCell1, new Point(0, 0));
			baseTable.addCell(nestCell2, new Point(0, 1));

			// document�ɔz�u
			document.add(baseTable);

			// �W�v���\��
			final int levelNum = this.level_list.length / this.senmon_list.length;
			final int[] sumWidths = new int[levelNum + 2];
			final int levelWidth = 38 / levelNum;

			sumWidths[0] = 17;
			sumWidths[1] = 45;
			for (int i = 0; i < levelNum; i++) {
				sumWidths[2 + i] = levelWidth;
			}

			PdfPCell pcell = null;
			// �w�b�_��
			final PdfPTable hdTable = new PdfPTable(PZE080_AssessTotalPDF.PDF_COLUMN_WIDTHS);
			hdTable.setHeaderRows(1);
			hdTable.setWidthPercentage(100);
			hdTable.setHorizontalAlignment(100);

			// Padding�f�t�H���g�l
			final float defaultPaddingTop = hdTable.getDefaultCell().getPaddingTop();
			final float defaultPaddingLeft = hdTable.getDefaultCell().getPaddingLeft();
			final float defaultPaddingRight = hdTable.getDefaultCell().getPaddingRight();
			final float defaultPaddingButtom = hdTable.getDefaultCell().getPaddingBottom();

			// �E��Header
			pcell = new PdfPCell(new Phrase(this.paraItem[0], font_white));
			pcell.setBackgroundColor(backColorT);
			pcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			hdTable.addCell(pcell);

			// ��啪��Header
			final PdfPTable headerSenmonLevelPTable = new PdfPTable(PZE080_AssessTotalPDF.SENOMON_LEVEL_TABLE_COMMN_WIDTHS);
			pcell = new PdfPCell(new Phrase(this.paraItem[1], font_white));
			pcell.setBackgroundColor(backColorT);
			pcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			headerSenmonLevelPTable.addCell(pcell);

			// ���x��Header
			final PdfPTable headerLevelPTable = new PdfPTable(1);
			pcell = new PdfPCell(new Phrase(this.paraItem[2], font_white));
			pcell.setBackgroundColor(backColorT);
			pcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			headerLevelPTable.addCell(pcell);

			final PdfPTable headerLevelVaulePTable = new PdfPTable(levelNum);
			for (int i = 0; i < levelNum; i++) {
				pcell = new PdfPCell(new Phrase(this.level_list[i][3], font_white));
				pcell.setBackgroundColor(backColorT);
				pcell.setHorizontalAlignment(Element.ALIGN_CENTER);
				pcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				headerLevelVaulePTable.addCell(pcell);
			}
			// �e���x�������x���ɒǉ�
			headerLevelPTable.getDefaultCell().setPadding(0f);
			headerLevelPTable.addCell(headerLevelVaulePTable);

			// ���x�����啪��E���x���e�[�u���ɒǉ�
			headerSenmonLevelPTable.getDefaultCell().setPadding(0f);
			headerSenmonLevelPTable.addCell(headerLevelPTable);

			// ��啪��E���x�����o�̓e�[�u���ɒǉ�
			hdTable.getDefaultCell().setPadding(0f);
			hdTable.addCell(headerSenmonLevelPTable);

			// Padding���f�t�H���g�l�ɖ߂�
			hdTable.getDefaultCell().setPaddingTop(defaultPaddingTop);
			hdTable.getDefaultCell().setPaddingLeft(defaultPaddingLeft);
			hdTable.getDefaultCell().setPaddingRight(defaultPaddingRight);
			hdTable.getDefaultCell().setPaddingBottom(defaultPaddingButtom);

			// �f�[�^��
			final Color dataBgColor = new Color(255, 255, 255);

			// �{��
			font.setColor(Color.black);

			/*
			 * �E��̐������s���쐬 ��啪��̐�������啪��̓���q�e�[�u���̍s���쐬 ��啪��̐��������x���̓���q�e�[�u�����쐬
			 */
			for (int i = 0; i < this.syoku_list.length; i++) {
				// �Ǝ햼
				pcell = new PdfPCell(new Phrase(this.syoku_list[i][1], font));
				pcell.setBackgroundColor(dataBgColor);
				pcell.setHorizontalAlignment(Element.ALIGN_CENTER);
				pcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				hdTable.addCell(pcell);

				final PdfPTable senmonLevelPTable = new PdfPTable(PZE080_AssessTotalPDF.SENOMON_LEVEL_TABLE_COMMN_WIDTHS);
				final int tempi = i;
				for (int j = 0; j < this.senmon_list.length; j++) {
					// ��啪��
					if (this.senmon_list[j][0].equals(this.syoku_list[i][0])) {

						// ��啪�얼
						pcell = new PdfPCell(new Phrase(this.senmon_list[j][2], font));
						pcell.setBackgroundColor(dataBgColor);
						pcell.setHorizontalAlignment(Element.ALIGN_CENTER);
						pcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
						senmonLevelPTable.addCell(pcell);

						// ���x��
						final PdfPTable dataLevelValuePTable = new PdfPTable(levelNum);

						for (int k = 0; k < levelNum; k++) {
							// ���x��
							pcell = new PdfPCell(new Phrase(this.level_list[levelNum * j + k][4], font));
							pcell.setHorizontalAlignment(Element.ALIGN_CENTER);
							pcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
							if (this.level_list[levelNum * j + k][5].equals("1")) {
								pcell = new PdfPCell(new Phrase(this.level_list[levelNum * j + k][4], font_white));
								pcell.setHorizontalAlignment(Element.ALIGN_CENTER);
								pcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
								pcell.setBackgroundColor(CellColor1);
							} else if (this.level_list[levelNum * j + k][5].equals("2")) {
								pcell.setBackgroundColor(CellColor2);
							} else if (this.level_list[levelNum * j + k][5].equals("3")) {
								pcell.setBackgroundColor(CellColor3);
							} else if (this.level_list[levelNum * j + k][5].equals("4")) {
								pcell.setBackgroundColor(CellColor4);
							} else if (this.level_list[levelNum * j + k][5].equals("5")) {
								pcell.setBackgroundColor(CellColor5);
							} else {
								pcell.setBackgroundColor(backColor);
							}
							dataLevelValuePTable.addCell(pcell);
						}
						senmonLevelPTable.getDefaultCell().setPadding(0);
						senmonLevelPTable.addCell(dataLevelValuePTable);
					}
				}

				if (tempi < i) {
					i--;
				}

				// ��啪��A���x���̒ǉ�
				hdTable.getDefaultCell().setPadding(0);
				hdTable.addCell(senmonLevelPTable);

				// Padding���f�t�H���g�l�ɖ߂�
				hdTable.getDefaultCell().setPaddingTop(defaultPaddingTop);
				hdTable.getDefaultCell().setPaddingLeft(defaultPaddingLeft);
				hdTable.getDefaultCell().setPaddingRight(defaultPaddingRight);
				hdTable.getDefaultCell().setPaddingBottom(defaultPaddingButtom);
			}

			// �h�L�������g�ɏo�̓e�[�u����ǉ�
			document.add(hdTable);

			final PdfPTable spTable = new PdfPTable(1);
			spTable.setWidthPercentage(100);
			pcell = new PdfPCell(new Phrase(" ", font));
			pcell.setBorder(0);
			spTable.addCell(pcell);
			document.add(spTable);

			final PdfPTable footTable = new PdfPTable(3);
			footTable.setWidthPercentage(100);
			final int[] footWidths = { 80, 5, 15 };
			footTable.setWidths(footWidths);

			pcell = new PdfPCell(new Phrase(" ", font));
			pcell.setBorder(0);
			footTable.addCell(pcell);

			pcell = new PdfPCell(new Phrase("����", font));
			pcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			pcell.setBorderColor(borderColor);
			footTable.setHorizontalAlignment(Element.ALIGN_CENTER);
			footTable.addCell(pcell);

			pcell = new PdfPCell(new Phrase(" : �Y�����x������", font));
			pcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			pcell.setBorder(0);
			pcell.setHorizontalAlignment(Element.ALIGN_LEFT);
			footTable.addCell(pcell);

			// document�ɔz�u
			document.add(footTable);

			Log.method(this.login_no, "OUT", "");

		} catch (final BadElementException e) {
			Log.error(this.login_no, "", e);
			throw e;
		} catch (final DocumentException e) {
			Log.error(this.login_no, "", e);
			throw e;
		} catch (final IOException e) {
			Log.error(this.login_no, "", e);
			throw e;
		} catch (final Exception e) {
			Log.error(this.login_no, "", e);
			throw e;
		} finally {
			// �h�L�������g�����
			if (document != null) {
				try {
					document.close();
				} catch (final Exception e) {
					Log.error(this.login_no, "", e);
					throw e;
				}
			}
			if (pw != null) {
				try {
					pw.close();
				} catch (final Exception e) {
					Log.error(this.login_no, "", e);
					throw e;
				}
			}
		}
	}
}
