/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */

package jp.co.hisas.career.util.pdf;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;

import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class PZE030_SindanKekkaPDF {
	/* �O��������ږ� */
	private final String pram_simei = (String) ReadFile.paramMapData.get("DZZ001");

	private final String pram_syozoku = (String) ReadFile.paramMapData.get("DZZ007");

	private final String pram_syokusyu = (String) ReadFile.paramMapData.get("DZZ008");

	private final String pram_senmon_bunya = (String) ReadFile.paramMapData.get("DZZ009");

	private final String pram_level = (String) ReadFile.paramMapData.get("DZZ010");

	private final String pram_skill = (String) ReadFile.paramMapData.get("DZZ012");

	private final String pram_score = (String) ReadFile.paramMapData.get("DZZ147");

	private final String pram_gyomu_tasseido = (String) ReadFile.paramMapData.get("DZZ205");

	private final String pram_skill_tasseido = (String) ReadFile.paramMapData.get("DZZ206");

	private final String pram_hyokasya_syozoku = (String) ReadFile.paramMapData.get("DZZ107");

	private final String pram_hyokasya_simei = (String) ReadFile.paramMapData.get("DZZ108");

	private final String pram_saisindan_comment = (String) ReadFile.announceMapData.get("AZZ023");

	/* �g�p�҃��O�C��NO */
	private String login_no;

	/* PDF��� */
	private String syoku_name;

	private String senmon_name;

	private String level_name;

	private String[][] tasseido_sihyo_list;

	private String[][] skill_list;

	/* �f�f�ҏ�� */
	private String sindansya_simei;

	private String sindansya_busyo;

	private String sindansya_sogo_tasseido;

	private String sindansya_gyomu_tasseido;

	private String[] sindansya_gyomu_kekka;

	private String sindansya_skill_tasseido;

	private String[] sindansya_skill_kekka;

	private String sindan_nengappi;

	/* �]���ҏ�� */
	private String hyokasya_simei;

	private String hyokasya_busyo;

	private String hyokasya_sogo_tasseido;

	private String hyokasya_comment;

	private String hyokasya_gyomu_tasseido;

	private String[] hyokasya_gyomu_kekka;

	private String hyokasya_skill_tasseido;

	private String[] hyokasya_skill_kekka;

	private String hyokasya_jissi_nengappi;

	/**
	 * �R���X�g���N�^
	 * @param login_no
	 */
	public PZE030_SindanKekkaPDF(final String login_no) {
		this.login_no = login_no;
	}

	/**
	 * �A�Z�X�����g�����i�[����
	 * @param filename
	 * @param syoku_name
	 * @param senmon_name
	 * @param level_name
	 * @param tasseido_sihyo_list
	 * @param skill_list
	 */
	public void setAssessmentValue(final String syoku_name, final String senmon_name, final String level_name, final String[][] tasseido_sihyo_list, final String[][] skill_list) {
		this.syoku_name = syoku_name;
		this.senmon_name = senmon_name;
		this.level_name = level_name;
		this.tasseido_sihyo_list = tasseido_sihyo_list;
		this.skill_list = skill_list;
	}

	/**
	 * �f�f�ҏ����i�[����
	 * @param sindansya_simei
	 * @param sindansya_busyo
	 * @param sindansya_sogo_tasseido
	 * @param sindansya_gyomu_tasseido
	 * @param sindansya_gyomu_kekka
	 * @param sindansya_skill_tasseido
	 * @param sindansya_skill_kekka
	 * @param sindan_nengappi
	 */
	public void setSindansyaValue(final String sindansya_simei, final String sindansya_busyo, final String sindansya_sogo_tasseido, final String sindansya_gyomu_tasseido,
			final String[] sindansya_gyomu_kekka, final String sindansya_skill_tasseido, final String[] sindansya_skill_kekka, final String sindan_nengappi) {
		this.sindansya_simei = sindansya_simei;
		this.sindansya_busyo = sindansya_busyo;
		if (sindansya_sogo_tasseido != null) {
			this.sindansya_sogo_tasseido = sindansya_sogo_tasseido + " %";
		}
		if (sindansya_gyomu_tasseido != null) {
			this.sindansya_gyomu_tasseido = sindansya_gyomu_tasseido + " %";
		}
		this.sindansya_gyomu_kekka = sindansya_gyomu_kekka;
		if (sindansya_skill_tasseido != null) {
			this.sindansya_skill_tasseido = sindansya_skill_tasseido + " %";
		}
		this.sindansya_skill_kekka = sindansya_skill_kekka;
		this.sindan_nengappi = PZZ010_CharacterUtil.ChangeYmd(sindan_nengappi);
	}

	/**
	 * �]���ҏ����i�[����
	 * @param hyokasya_simei
	 * @param hyokasya_busyo
	 * @param hyokasya_sogo_tasseido
	 * @param hyokasya_comment
	 * @param hyokasya_gyomu_tasseido
	 * @param hyokasya_gyomu_kekka
	 * @param hyokasya_skill_tasseido
	 * @param hyokasya_skill_kekka
	 * @param hyokasya_jissi_nengappi
	 */
	public void setHyokasyaValue(final String hyokasya_simei, final String hyokasya_busyo, final String hyokasya_sogo_tasseido, final String hyokasya_comment, final String hyokasya_gyomu_tasseido,
			final String[] hyokasya_gyomu_kekka, final String hyokasya_skill_tasseido, final String[] hyokasya_skill_kekka, final String hyokasya_jissi_nengappi) {
		this.hyokasya_simei = hyokasya_simei;
		this.hyokasya_busyo = hyokasya_busyo;
		if (hyokasya_sogo_tasseido != null) {
			this.hyokasya_sogo_tasseido = hyokasya_sogo_tasseido + " %";
		}
		this.hyokasya_comment = hyokasya_comment;
		if (hyokasya_gyomu_tasseido != null) {
			this.hyokasya_gyomu_tasseido = hyokasya_gyomu_tasseido + " %";
		}
		this.hyokasya_gyomu_kekka = hyokasya_gyomu_kekka;
		if (hyokasya_skill_tasseido != null) {
			this.hyokasya_skill_tasseido = hyokasya_skill_tasseido + " %";
		}
		this.hyokasya_skill_kekka = hyokasya_skill_kekka;
		this.hyokasya_jissi_nengappi = PZZ010_CharacterUtil.ChangeYmd(hyokasya_jissi_nengappi);
	}

	/**
	 * PDF���쐬����
	 * @return
	 */
	public void executePDF(final OutputStream ops, final BufferedImage radarchart) throws Exception {

		/* �f�t�H���g�̃e�[�u�����` */
		class MyTable extends Table {
			public MyTable(final int arg0) throws BadElementException {
				super(arg0);
				this.setDefaultHorizontalAlignment(Element.ALIGN_CENTER);
				this.setDefaultVerticalAlignment(Element.ALIGN_MIDDLE);
				this.setPadding(2);
			}
		}

		/* �f�o�b�O���O���o�� */
		Log.debug("syoku_name:" + this.syoku_name);
		Log.debug("senmon_name:" + this.senmon_name);
		Log.debug("level_name:" + this.level_name);
		Log.debug("tasseido_sihyo_list:" + this.tasseido_sihyo_list);
		Log.debug("skill_list:" + this.skill_list);
		Log.debug("sindansya_simei:" + this.sindansya_simei);
		Log.debug("sindansya_busyo:" + this.sindansya_busyo);
		Log.debug("sindansya_sogo_tasseido:" + this.sindansya_sogo_tasseido);
		Log.debug("sindansya_gyomu_tasseido:" + this.sindansya_gyomu_tasseido);
		Log.debug("sindansya_gyomu_kekka:" + this.sindansya_gyomu_kekka);
		Log.debug("sindansya_skill_tasseido:" + this.sindansya_skill_tasseido);
		Log.debug("sindansya_skill_kekka:" + this.sindansya_skill_kekka);
		Log.debug("sindan_nengappi:" + this.sindan_nengappi);
		Log.debug("hyokasya_simei:" + this.hyokasya_simei);
		Log.debug("hyokasya_busyo:" + this.hyokasya_busyo);
		Log.debug("hyokasya_sogo_tasseido:" + this.hyokasya_sogo_tasseido);
		Log.debug("hyokasya_comment:" + this.hyokasya_comment);
		Log.debug("hyokasya_gyomu_tasseido:" + this.hyokasya_gyomu_tasseido);
		Log.debug("hyokasya_gyomu_kekka:" + this.hyokasya_gyomu_kekka);
		Log.debug("hyokasya_skill_tasseido:" + this.hyokasya_skill_tasseido);
		Log.debug("hyokasya_skill_kekka:" + this.hyokasya_skill_kekka);
		Log.debug("hyokasya_jissi_nengappi:" + this.hyokasya_jissi_nengappi);

		/*
		 * Document�I�u�W�F�N�g�̐��� A4�c�́A Document document = new Document(PageSize.A4); A4���́ADocument document = new Document(PageSize.A4.rotate());
		 */
		final Document document = new Document(PageSize.A4);
		PdfWriter pw = null;

		try {
			/* PdfWriter�I�u�W�F�N�g�̐��� */
			pw = PdfWriter.getInstance(document, ops);
			pw.setCloseStream(true);

			/* �w�i�F */
			final Color BackColor = Color.white;

			/* �h�L�������g��OPEN */
			final HeaderFooter footer = new HeaderFooter(new Phrase("- "), new Phrase(" -"));
			footer.setBorderColor(BackColor);
			footer.setAlignment(Element.ALIGN_CENTER);
			document.setFooter(footer);
			document.open();

			/* �t�H���g�̐ݒ� */
			final float default_font_size = 10;
			final BaseFont bf = BaseFont.createFont("HeiseiMin-W3", "UniJIS-UCS2-HW-H", false);
			final Font font = new Font(bf, default_font_size);
			final Color default_color = font.color();

			/* �P�s�X�y�[�X�̒�` */
			// final Table space = new MyTable(1);
			// space.setBorderColor(BackColor);
			// space.addCell("");
			final Font fonts = new Font(bf, 1);
			final Paragraph space = new Paragraph(" ", fonts);

			/* ���ʃ��C���i�����]���A�Ɩ��o���]���A�X�L���]���j�̒��� */
			// final int KekkaLineSize = 100;
			final int[] KekkaLineSize = { 100 };

			final int TableWidth = 100;

			/* �R���e���c�̋L�q */
			MyTable table;
			Cell cell;
			PdfPCell cellpdf = null;

			/* �f�f�N������\�� */
			if (this.sindan_nengappi == null) {
				this.sindan_nengappi = "";
			}

			final PdfPTable pTablesindan_nengappi = new PdfPTable(2);
			final int[] sindan_nengappi_widths = { 70, 30 };
			pTablesindan_nengappi.setWidths(sindan_nengappi_widths);
			pTablesindan_nengappi.setWidthPercentage(TableWidth);

			cellpdf = new PdfPCell(new Phrase("�f�f�N����", font));
			cellpdf.setBorderColor(BackColor);
			cellpdf.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			pTablesindan_nengappi.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.sindan_nengappi, font));
			cellpdf.setBorderColor(BackColor);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			pTablesindan_nengappi.addCell(cellpdf);

			/* �h�L�������g�ɒǉ� */
			document.add(pTablesindan_nengappi);

			/* �f�f�ҏ�� */
			if (this.sindansya_busyo == null) {
				this.sindansya_busyo = "";
			}
			if (this.sindansya_simei == null) {
				this.sindansya_simei = "";
			}

			final PdfPTable pTablesindansya_info = new PdfPTable(5);
			final int[] sindansya_info_widths = { 10, 10, 35, 10, 35 };
			pTablesindansya_info.setWidths(sindansya_info_widths);
			pTablesindansya_info.setWidthPercentage(TableWidth);

			cellpdf = new PdfPCell(new Phrase("�f�f��", font));
			cellpdf.setBorderColor(default_color);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(1.1f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthLeft(1.1f);
			cellpdf.setBorderWidthRight(0.5f);
			pTablesindansya_info.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.pram_syozoku, font));
			cellpdf.setBorderColor(default_color);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(1.1f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthRight(0.5f);
			pTablesindansya_info.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.sindansya_busyo, font));
			cellpdf.setBorderColor(default_color);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(1.1f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthRight(0.5f);
			pTablesindansya_info.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.pram_simei, font));
			cellpdf.setBorderColor(default_color);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(1.1f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthRight(0.5f);
			pTablesindansya_info.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.sindansya_simei, font));
			cellpdf.setBorderColor(default_color);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(1.1f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthRight(1.1f);
			pTablesindansya_info.addCell(cellpdf);

			/* �h�L�������g�ɒǉ� */
			document.add(pTablesindansya_info);

			/* �X�y�[�X�}�� */
			// document.add(space);
			final PdfPTable pTabeSpace = new PdfPTable(1);
			cellpdf = new PdfPCell(new Phrase(" ", font));
			cellpdf.setBorderColor(BackColor);
			cellpdf.setBorderWidth(0);
			pTabeSpace.addCell(cellpdf);

			/* �h�L�������g�ɒǉ� */
			document.add(pTabeSpace);

			/* �E��E��啪��E���x�� */
			final PdfPTable pTableassessment_info = new PdfPTable(6);
			final int[] assessment_info_widths = { 10, 25, 15, 25, 10, 15 };
			pTableassessment_info.setWidths(assessment_info_widths);
			pTableassessment_info.setWidthPercentage(TableWidth);

			cellpdf = new PdfPCell(new Phrase(this.pram_syokusyu, font));
			cellpdf.setBorderColor(default_color);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(1.1f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthLeft(1.1f);
			cellpdf.setBorderWidthRight(0.5f);
			pTableassessment_info.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.syoku_name, font));
			cellpdf.setBorderColor(default_color);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(1.1f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthRight(0.5f);
			pTableassessment_info.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.pram_senmon_bunya, font));
			cellpdf.setBorderColor(default_color);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(1.1f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthRight(0.5f);
			pTableassessment_info.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.senmon_name, font));
			cellpdf.setBorderColor(default_color);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(1.1f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthRight(0.5f);
			pTableassessment_info.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.pram_level, font));
			cellpdf.setBorderColor(default_color);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(1.1f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthRight(0.5f);
			pTableassessment_info.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.level_name, font));
			cellpdf.setBorderColor(default_color);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(1.1f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthRight(1.1f);
			pTableassessment_info.addCell(cellpdf);

			/* �h�L�������g�ɒǉ� */
			document.add(pTableassessment_info);

			/* �X�y�[�X�}�� */
			// document.add(space);
			final PdfPTable pTabeSpace1 = new PdfPTable(1);
			cellpdf = new PdfPCell(new Phrase(" ", font));
			cellpdf.setBorderColor(BackColor);
			cellpdf.setBorderWidth(0);
			pTabeSpace1.addCell(cellpdf);

			/* �h�L�������g�ɒǉ� */
			document.add(pTabeSpace1);

			/* �T�D�����]�� */
			font.setColor(BackColor);
			final PdfPTable pTablesogo = new PdfPTable(1);
			pTablesogo.setWidths(KekkaLineSize);
			pTablesogo.setWidthPercentage(TableWidth);

			cellpdf = new PdfPCell(new Phrase("�P�D�����]��", font));
			cellpdf.setBorderColor(BackColor);
			cellpdf.setHorizontalAlignment(Element.ALIGN_LEFT);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBackgroundColor(new Color(0x27, 0x40, 0x8B));
			pTablesogo.addCell(cellpdf);

			/* �h�L�������g�ɒǉ� */
			document.add(pTablesogo);

			document.add(space);

			font.setColor(default_color);

			/* �����]�� */
			table = new MyTable(7);
			final int[] sogo_kekka_widths = { 15, 8, 17, 8, 17, 15, 20 };
			table.setWidths(sogo_kekka_widths);
			table.setWidth(TableWidth);

			cell = new Cell(new Phrase("�����B���x", font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(2);
			cell.setColspan(1);
			table.addCell(cell);

			cell = new Cell(new Phrase("�f�f�Җ{�l�̕]��", font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(2);
			table.addCell(cell);

			if (this.sindansya_sogo_tasseido == null) {
				this.sindansya_sogo_tasseido = "";
			}
			cell = new Cell(new Phrase(this.sindansya_sogo_tasseido, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(2);
			table.addCell(cell);

			font.setSize(7);
			cell = new Cell(new Phrase(this.pram_saisindan_comment, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			font.setSize(default_font_size);
			cell.setVerticalAlignment(Element.ALIGN_TOP);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setRowspan(2);
			cell.setColspan(2);
			table.addCell(cell);

			cell = new Cell(new Phrase("�]���f�f�̕]��", font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(2);
			table.addCell(cell);

			if (this.hyokasya_sogo_tasseido == null) {
				this.hyokasya_sogo_tasseido = "";
			}
			cell = new Cell(new Phrase(this.hyokasya_sogo_tasseido, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(2);
			table.addCell(cell);

			cell = new Cell(new Phrase("�]���f�f��\n�R�����g", font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(2);
			cell.setColspan(1);
			table.addCell(cell);

			if (this.hyokasya_comment == null) {
				this.hyokasya_comment = "";
			}
			cell = new Cell(new Phrase(this.hyokasya_comment, font));
			cell.setVerticalAlignment(Element.ALIGN_TOP);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setRowspan(2);
			cell.setColspan(6);
			table.addCell(cell);

			cell = new Cell(new Phrase("�]����", font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			cell = new Cell(new Phrase(this.pram_hyokasya_syozoku, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			if (this.hyokasya_busyo == null) {
				this.hyokasya_busyo = "";
			}
			cell = new Cell(new Phrase(this.hyokasya_busyo, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			cell = new Cell(new Phrase(this.pram_hyokasya_simei, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			if (this.hyokasya_simei == null) {
				this.hyokasya_simei = "";
			}
			cell = new Cell(new Phrase(this.hyokasya_simei, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			cell = new Cell(new Phrase("�]�����{��", font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			if (this.hyokasya_jissi_nengappi == null) {
				this.hyokasya_jissi_nengappi = "";
			}
			cell = new Cell(new Phrase(this.hyokasya_jissi_nengappi, font));
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			/* �h�L�������g�ɒǉ� */
			document.add(table);

			/* �X�y�[�X�}�� */
			// document.add(space);
			final PdfPTable pTabeSpace2 = new PdfPTable(1);
			cellpdf = new PdfPCell(new Phrase(" ", font));
			cellpdf.setBorderColor(BackColor);
			cellpdf.setBorderWidth(0);
			pTabeSpace2.addCell(cellpdf);

			/* �h�L�������g�ɒǉ� */
			document.add(pTabeSpace2);

			/* �U�D�Ɩ��o���]�� */
			font.setColor(BackColor);
			final PdfPTable pTablegyoumu = new PdfPTable(1);
			pTablegyoumu.setWidths(KekkaLineSize);
			pTablegyoumu.setWidthPercentage(TableWidth);

			cellpdf = new PdfPCell(new Phrase("�Q�D�Ɩ��o���]��", font));
			cellpdf.setBorderColor(BackColor);
			cellpdf.setHorizontalAlignment(Element.ALIGN_LEFT);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBackgroundColor(new Color(0x27, 0x40, 0x8B));
			pTablegyoumu.addCell(cellpdf);

			/* �h�L�������g�ɒǉ� */
			document.add(pTablegyoumu);

			document.add(space);

			font.setColor(default_color);

			final PdfPTable pTablegyomu_head = new PdfPTable(3);
			final int[] gyomu_head_widths = { 84, 8, 8 };
			pTablegyomu_head.setWidths(gyomu_head_widths);
			pTablegyomu_head.setWidthPercentage(TableWidth);

			cellpdf = new PdfPCell(new Phrase("����", font));
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(0.5f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthLeft(1.1f);
			cellpdf.setBorderWidthRight(0.5f);
			pTablegyomu_head.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase("�f�f�Җ{�l�̑I��", font));
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(0.5f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthRight(0.5f);
			pTablegyomu_head.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase("�]���f�f�̑I��", font));
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBorderWidthBottom(0.5f);
			cellpdf.setBorderWidthTop(1.1f);
			cellpdf.setBorderWidthRight(1.1f);
			pTablegyomu_head.addCell(cellpdf);

			document.add(pTablegyomu_head);

			for (int i = 0; i < this.tasseido_sihyo_list.length; i++) {
				final PdfPTable pTablegyomu_kekka = new PdfPTable(3);
				final int[] gyomu_kekka_widths = { 84, 8, 8 };
				pTablegyomu_kekka.setWidths(gyomu_kekka_widths);
				pTablegyomu_kekka.setWidthPercentage(TableWidth);

				cellpdf = new PdfPCell(new Phrase(this.tasseido_sihyo_list[i][2], font));
				cellpdf.setColspan(3);
				cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
				cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cellpdf.setBackgroundColor(new Color(0x99, 0xCC, 0xFF));
				cellpdf.setBorderWidth(0);
				cellpdf.setBorderWidthBottom(0.5f);
				cellpdf.setBorderWidthLeft(1.1f);
				cellpdf.setBorderWidthRight(1.1f);
				pTablegyomu_kekka.addCell(cellpdf);

				document.add(pTablegyomu_kekka);

				/* �\�� */
				while (true) {
					String sindansya_gyomu = "";
					String hyokasya_gyomu = "";

					/* �f�f�� �B���x�w�W�I���`�F�b�N */
					if (this.sindansya_gyomu_kekka != null && this.sindansya_gyomu_kekka.length != 0) {
						if (this.sindansya_gyomu_kekka[i].equals("1")) {
							sindansya_gyomu = "��";
						} else {
							sindansya_gyomu = "�~";
						}
					}

					/* �]���� �B���x�w�W�I���`�F�b�N */
					if (this.hyokasya_gyomu_kekka != null && this.hyokasya_gyomu_kekka.length != 0) {
						if (this.hyokasya_gyomu_kekka[i].equals("1")) {
							hyokasya_gyomu = "��";
						} else {
							hyokasya_gyomu = "�~";
						}
					}

					final PdfPTable pTablegyomu_kekka_naiyou = new PdfPTable(3);
					final int[] gyomu_kekka_naiyou_widths = { 84, 8, 8 };
					pTablegyomu_kekka_naiyou.setWidths(gyomu_kekka_naiyou_widths);
					pTablegyomu_kekka_naiyou.setWidthPercentage(TableWidth);

					cellpdf = new PdfPCell(new Phrase(this.tasseido_sihyo_list[i][3], font));
					cellpdf.setHorizontalAlignment(Element.ALIGN_LEFT);
					cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cellpdf.setBackgroundColor(BackColor);
					cellpdf.setBorderWidth(0);
					if (i == this.tasseido_sihyo_list.length - 1) {
						cellpdf.setBorderWidthBottom(1.1f);
					} else {
						cellpdf.setBorderWidthBottom(0.5f);
					}
					cellpdf.setBorderWidthLeft(1.1f);
					cellpdf.setBorderWidthRight(0.5f);
					pTablegyomu_kekka_naiyou.addCell(cellpdf);

					cellpdf = new PdfPCell(new Phrase(sindansya_gyomu, font));
					cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
					cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cellpdf.setBackgroundColor(BackColor);
					cellpdf.setBorderWidth(0);
					if (i == this.tasseido_sihyo_list.length - 1) {
						cellpdf.setBorderWidthBottom(1.1f);
					} else {
						cellpdf.setBorderWidthBottom(0.5f);
					}
					cellpdf.setBorderWidthRight(0.5f);
					pTablegyomu_kekka_naiyou.addCell(cellpdf);

					cellpdf = new PdfPCell(new Phrase(hyokasya_gyomu, font));
					cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
					cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cellpdf.setBackgroundColor(BackColor);
					cellpdf.setBorderWidth(0);
					if (i == this.tasseido_sihyo_list.length - 1) {
						cellpdf.setBorderWidthBottom(1.1f);
					} else {
						cellpdf.setBorderWidthBottom(0.5f);
					}
					cellpdf.setBorderWidthRight(1.1f);
					pTablegyomu_kekka_naiyou.addCell(cellpdf);
					pTablegyomu_kekka_naiyou.addCell(cellpdf);

					document.add(pTablegyomu_kekka_naiyou);

					/* ���[�v�I������ */
					if (i + 1 == this.tasseido_sihyo_list.length) {
						break;
					} else if (!this.tasseido_sihyo_list[i][0].equals(this.tasseido_sihyo_list[i + 1][0])) {
						break;
					}
					i++;
				}
			}

			document.add(space);

			/* �Ɩ��o���B���x */
			table = new MyTable(5);
			final int[] gyomu_tasseido_widths = { 20, 20, 20, 20, 20 };
			table.setWidths(gyomu_tasseido_widths);
			table.setWidth(TableWidth);

			cell = new Cell(new Phrase(this.pram_gyomu_tasseido, font));
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			cell = new Cell(new Phrase("�f�f�Җ{�l�̕]��", font));
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			if (this.sindansya_gyomu_tasseido == null) {
				this.sindansya_gyomu_tasseido = "";
			}
			cell = new Cell(new Phrase(this.sindansya_gyomu_tasseido, font));
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			cell = new Cell(new Phrase("�]���f�f�̕]��", font));
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			if (this.hyokasya_gyomu_tasseido == null) {
				this.hyokasya_gyomu_tasseido = "";
			}
			cell = new Cell(new Phrase(this.hyokasya_gyomu_tasseido, font));
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			/* �h�L�������g�ɒǉ� */
			document.add(table);

			/* ���y�[�W */
			document.newPage();

			/* �V�D�X�L���]�� */
			font.setColor(BackColor);
			final PdfPTable pTableskill = new PdfPTable(1);
			pTableskill.setWidths(KekkaLineSize);
			pTableskill.setWidthPercentage(TableWidth);

			cellpdf = new PdfPCell(new Phrase("�R�D" + this.pram_skill + "�]��", font));
			cellpdf.setBorderColor(BackColor);
			cellpdf.setHorizontalAlignment(Element.ALIGN_LEFT);
			cellpdf.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cellpdf.setBorderWidth(0);
			cellpdf.setBackgroundColor(new Color(0x27, 0x40, 0x8B));
			pTableskill.addCell(cellpdf);

			/* �h�L�������g�ɒǉ� */
			document.add(pTableskill);

			document.add(space);

			font.setColor(default_color);

			/* �O�g */
			table = new MyTable(2);
			final int[] skill_waku_widths = { 60, 40 };
			table.setWidths(skill_waku_widths);
			table.setWidth(TableWidth);

			/* ���[�_�`���[�g�} */

			/* �O�g�ɒǉ� */
			table.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
			table.setDefaultVerticalAlignment(Element.ALIGN_TOP);

			if (radarchart == null) {
				final String png = "";
				table.addCell(new Cell(png));
			} else {
				final Iterator ite = ImageIO.getImageWritersByFormatName("png");
				final ImageWriter writer = (ImageWriter) ite.next();
				final ByteArrayOutputStream baos = new ByteArrayOutputStream();
				final ImageOutputStream ios = ImageIO.createImageOutputStream(baos);
				writer.setOutput(ios);
				writer.write(radarchart);
				final Image img_png = Image.getInstance(baos.toByteArray());
				table.addCell(new Cell(img_png));
			}

			table.setDefaultHorizontalAlignment(Element.ALIGN_CENTER);
			table.setDefaultVerticalAlignment(Element.ALIGN_MIDDLE);

			/* �X�L���f�f���� */
			final Table table1 = new MyTable(3);
			final int[] skill_sindan_widths = { 60, 20, 20 };
			table1.setWidths(skill_sindan_widths);

			cell = new Cell(new Phrase(this.pram_skill, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table1.addCell(cell);
			cell = new Cell(new Phrase("�f�f�Җ{�l��" + this.pram_score, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table1.addCell(cell);
			cell = new Cell(new Phrase("�]���f�f��" + this.pram_score, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table1.addCell(cell);

			table1.endHeaders();

			for (int i = 0; i < this.skill_list.length; i++) {
				/* �f�f�Ґf�f��� */
				String sindansya_score = "";
				if (this.sindansya_skill_kekka != null && this.sindansya_skill_kekka.length != 0) {
					sindansya_score = this.sindansya_skill_kekka[i];
				}

				/* �]���Ґf�f��� */
				String hyoukasya_score = "";
				if (this.hyokasya_skill_kekka != null && this.hyokasya_skill_kekka.length != 0) {
					hyoukasya_score = this.hyokasya_skill_kekka[i];
				}

				/* �X�L������ */
				cell = new Cell(new Phrase(this.skill_list[i][1], font));
				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell.setRowspan(1);
				cell.setColspan(1);
				table1.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
				table1.addCell(cell);
				table1.setDefaultHorizontalAlignment(Element.ALIGN_CENTER);

				/* �f�f�҃X�L���f�f�I������ */
				cell = new Cell(new Phrase(sindansya_score, font));
				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell.setRowspan(1);
				cell.setColspan(1);
				table1.addCell(cell);

				/* �]���҃X�L���f�f�I������ */
				cell = new Cell(new Phrase(hyoukasya_score, font));
				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell.setRowspan(1);
				cell.setColspan(1);
				table1.addCell(cell);
			}

			table.insertTable(table1);

			/* �h�L�������g�ɒǉ� */
			document.add(table);
			table = null;

			/* �X�y�[�X��}�� */
			document.add(space);

			/* �X�L���B���x */
			table = new MyTable(5);
			final int[] skill_tasseido_widths = { 20, 20, 20, 20, 20 };
			table.setWidths(skill_tasseido_widths);
			table.setWidth(TableWidth);

			cell = new Cell(new Phrase(this.pram_skill_tasseido, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			cell = new Cell(new Phrase("�f�f�Җ{�l�̕]��", font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			if (this.sindansya_skill_tasseido == null) {
				this.sindansya_skill_tasseido = "";
			}
			cell = new Cell(new Phrase(this.sindansya_skill_tasseido, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			cell = new Cell(new Phrase("�]���f�f�̕]��", font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			if (this.hyokasya_skill_tasseido == null) {
				this.hyokasya_skill_tasseido = "";
			}
			cell = new Cell(new Phrase(this.hyokasya_skill_tasseido, font));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setRowspan(1);
			cell.setColspan(1);
			table.addCell(cell);

			/* �h�L�������g�ɒǉ� */
			document.add(table);

		} catch (final BadElementException e) {
			Log.error(this.login_no, e);
			throw e;
		} catch (final DocumentException e) {
			Log.error(this.login_no, e);
			throw e;
		} catch (final MalformedURLException e) {
			Log.error(this.login_no, e);
			throw e;
		} catch (final IOException e) {
			Log.error(this.login_no, e);
			throw e;
		} catch (final Exception e) {
			Log.error(this.login_no, e);
			throw e;
		} finally {
			/* �h�L�������g����� */
			if (document != null) {
				try {
					document.close();
				} catch (final Exception e) {
					Log.error(this.login_no, e);
					throw e;
				}
			}
			if (pw != null) {
				try {
					pw.close();
				} catch (final Exception e) {
					Log.error(this.login_no, e);
					throw e;
				}
			}
		}
	}
}
