/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.search.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ejb.CreateException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ020_MakeSQLUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �T�v: DB�A�N�Z�X���s���A�L�����A�`�������W���̌������s���A�X�e�[�g���XSessionBean�B �g�p���@: �����[�g�C���^�t�F�[�X����āA�N���C�A���gBean����Ăяo���B
 * 
 * </PRE>
 */
public class PBE_SearchChallengeEJBBean implements SessionBean {

	/** SessionContext�I�u�W�F�N�g */
	private SessionContext my_ssc = null;

	/** �p�[�\�i���v���t�@�C���e�[�u�� */
	private static final String T01tbl = HcdbDef.personalTbl + " t01";

	/** ��E�}�X�^�e�[�u�� */
	private static final String T15tbl = HcdbDef.yakusyokuTbl + " t15";

	/** �L�����A�`�������W�e�[�u�� */
	private static final String P31tbl = HcdbDef.p_career_challengeTbl + " p31";

	/**
	 * �f�[�^�x�[�X����Ώۃ��R�[�h�̌������J�E���g���A���^�[������B
	 * @param login_no ���O�C��No
	 * @param search_kbn �������@ 1:�i���󋵂��猟������A2:�\�͊J���v�悩�猟������A3:�Ј������猟������
	 * @param search_cnd ��������
	 * @return ��������
	 * @exception SQLException SQL�G���[�����������ꍇ
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 */
	public int countChallenge(final String login_no, final String search_kbn, final String[] search_cnd) throws RemoteException, SQLException, NamingException {
		// MethodLog�o��
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* SQL�X�e�[�g�����g�̔��s */
			// �����擾
			final int engName = Integer.parseInt(search_cnd[0]);
			final int jinRyaku = Integer.parseInt(search_cnd[1]);
			final int yakuMaster = Integer.parseInt(search_cnd[2]);
			final int busyoPos = Integer.parseInt(search_cnd[3]);
			String kikan = "%";
			String kbn = "%";
			String syoriflg = "%";
			String syoninflg = "%";
			String kaihatuplan = "";
			String umu = "";
			String simeino = "";
			String simeikanji = "_";
			String simeikana = "_";
			String simeieiji = "_";
			String buryakusyo = "";

			int unionFlg = 0;

			if (search_kbn.equals("1")) { // �i���󋵂��猟������
				kikan = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[4]);
				kbn = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[5]);
				syoriflg = "";
				syoninflg = "";

				for (int i = 0; i < HcdbDef.sinchoku.length; i++) {
					if (HcdbDef.sinchoku[i][0].equals(search_cnd[6])) {
						syoriflg = HcdbDef.sinchoku[i][2];
						syoninflg = HcdbDef.sinchoku[i][3];
					}
				}

				buryakusyo = search_cnd[7];

				if (search_cnd[6].equals("1")) {
					unionFlg = 1;
				}

			} else if (search_kbn.equals("2")) { // �\�͊J���v�悩�猟������
				kikan = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[4]);
				kbn = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[5]);
				kaihatuplan = search_cnd[6];
				umu = search_cnd[7];
				buryakusyo = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[8]);

			} else if (search_kbn.equals("3")) {// �Ј������猟������
				simeino = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[4]);
				simeikanji = "_" + PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[5]);
				simeikana = "_" + PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[6]);
				simeieiji = "_" + PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[7]);
				buryakusyo = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[8]);
			}

			String whr_p31 = "";
			if (search_kbn.equals("2") && !kaihatuplan.equals("")) {
				String cond = "";
				String cond2 = "";
				whr_p31 = " AND ";
				if (umu.equals("1")) {
					cond = " IS NOT NULL";
					cond2 = " OR ";
				} else {
					cond = " IS NULL";
					cond2 = " AND ";
				}
				if (kaihatuplan.equals("1")) {
					whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[0] + cond;
				} else if (kaihatuplan.equals("2")) {
					whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[1] + cond;
				} else if (kaihatuplan.equals("3")) {
					whr_p31 = whr_p31 + "( " + "p31." + HcdbDef.p31_searchchallenge_whr_column[2] + cond;
					for (int i = 3; i < 7; i++) {
						whr_p31 = whr_p31 + cond2 + "p31." + HcdbDef.p31_searchchallenge_whr_column[i] + cond;
					}
					whr_p31 = whr_p31 + " ) ";
				} else if (kaihatuplan.equals("4")) {
					whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[7] + cond;
				} else if (kaihatuplan.equals("5")) {
					whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[8] + cond;
				} else if (kaihatuplan.equals("6")) {
					whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[9] + cond;
				} else if (kaihatuplan.equals("7")) {
					whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[10] + cond;
				}
			}

			final String[] t01_whr = { simeino.concat("%"), simeikanji.trim().concat("%"), simeikana.trim().concat("%"), buryakusyo.trim() };

			final String[] t01_whr_eng = { simeino.concat("%"), simeikanji.trim().concat("%"), simeikana.trim().concat("%"), simeieiji.trim().concat("%"), buryakusyo.trim() };

			String sql = "SELECT COUNT( * ) c" + " FROM " + PBE_SearchChallengeEJBBean.T01tbl + " , " + PBE_SearchChallengeEJBBean.P31tbl;
			if (yakuMaster == 1) {
				sql = sql + " , " + PBE_SearchChallengeEJBBean.T15tbl;
			}

			String whr_stm = "";
			String whr_stm2 = "";
			sql = sql + " WHERE " + "t01." + HcdbDef.t01_searchchallenge_column[0] + " = p31." + HcdbDef.p31_searchchallenge_column[0] + " AND ";
			whr_stm = "p31." + HcdbDef.p31_searchchallenge_column[1] + " LIKE '" + kikan + "' ESCAPE '#'" + " AND p31." + HcdbDef.p31_searchchallenge_column[3] + " LIKE '" + kbn + "' ESCAPE '#'";
			sql = sql + whr_stm + " AND p31." + HcdbDef.p31_searchchallenge_column[4] + " LIKE '" + syoriflg + "'" + " AND p31." + HcdbDef.p31_searchchallenge_column[5] + " LIKE '" + syoninflg + "'"
					+ whr_p31;

			int ind;

			if (engName == 0 || engName == 1 && simeieiji.trim().equals("_")) {
				// �p��������\�����Ȃ� or �p��������\������A���p�������̎w��Ȃ�
				for (ind = 0; ind < t01_whr.length - 1; ind++) {
					whr_stm2 = whr_stm2 + " AND t01." + HcdbDef.t01_searchchallenge_column[ind] + " LIKE '" + t01_whr[ind] + "' ESCAPE '#'";
				}
				if (!buryakusyo.trim().equals("")) {
					whr_stm2 = whr_stm2 + " AND t01." + HcdbDef.t01_search_syozoku[busyoPos - 1] + " LIKE '" + t01_whr[ind] + "' ESCAPE '#'";
				}
			} else {
				// �p��������\������
				for (ind = 0; ind < t01_whr_eng.length - 1; ind++) {
					whr_stm2 = whr_stm2 + " AND t01." + HcdbDef.t01_searchchallenge_eng_column[ind] + " LIKE '" + t01_whr_eng[ind] + "' ESCAPE '#'";
				}
				if (!buryakusyo.trim().equals("")) {
					whr_stm2 = whr_stm2 + " AND t01." + HcdbDef.t01_search_syozoku[busyoPos - 1] + " LIKE '" + t01_whr_eng[ind] + "' ESCAPE '#'";
				}
			}

			whr_stm2 = whr_stm2 + " AND t01." + HcdbDef.t01_honmu_cnd + " AND t01." + HcdbDef.t01_taisyoku_cnd;

			if (yakuMaster == 1) {
				whr_stm2 = whr_stm2 + " AND t15." + HcdbDef.yakusyoku_code + " = t01." + HcdbDef.yakusyoku_code;
			}

			sql = sql + whr_stm2;

			if (unionFlg == 1) {
				sql = "SELECT SUM ( c ) FROM ( ( " + sql + ") " + " UNION ALL" + "( SELECT COUNT( * ) c" + " FROM " + PBE_SearchChallengeEJBBean.T01tbl + " LEFT OUTER JOIN "
						+ PBE_SearchChallengeEJBBean.P31tbl + " ON (T01." + HcdbDef.p31_search_jinmei[0] + " = P31." + HcdbDef.p31_hyoji_column[0] + " AND " + whr_stm + ")";
				if (yakuMaster == 1) {
					sql = sql + " , " + PBE_SearchChallengeEJBBean.T15tbl;
				}
				sql = sql + " WHERE " + " P31." + HcdbDef.p31_hyoji_column[0] + " IS NULL " + whr_stm2 + " ))";
			}

			Log.debug("countChallengeSQL:" + sql);
			// SQL�ݒ�
			stmt = dbConn.createStatement();
			// SQL���s
			rs = stmt.executeQuery(sql);
			rs.next();

			//
			final int count_challenge = rs.getInt(1);

			Log.debug("countChallenge:" + count_challenge);

			Log.method(login_no, "OUT", "");
			return count_challenge;

		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �f�[�^�x�[�X�������s���A���ʂ��i�[�����z������^�[������B
	 * @param login_no ���O�C��No
	 * @param search_kbn �������@
	 * @param search_cnd ��������
	 * @param count �������ʌ���
	 * @return �������ʔz��
	 * @exception SQLException SQL�G���[�����������ꍇ
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 */
	public String[][] searchChallenge(final String login_no, final String search_kbn, final String[] search_cnd, final int count) throws RemoteException, SQLException, NamingException {
		// MethodLog�o��
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* SQL�X�e�[�g�����g�̔��s */
			// �����擾
			final int engName = Integer.parseInt(search_cnd[0]);
			final int jinRyaku = Integer.parseInt(search_cnd[1]);
			final int yakuMaster = Integer.parseInt(search_cnd[2]);
			final int busyoPos = Integer.parseInt(search_cnd[3]);
			String kikan = "%";
			String kbn = "%";
			String syoriflg = "%";
			String syoninflg = "%";
			String kaihatuplan = "";
			String umu = "";
			String simeino = "";
			String simeikanji = "_";
			String simeikana = "_";
			String simeieiji = "_";
			String buryakusyo = "";

			int unionFlg = 0;

			if (search_kbn.equals("1")) {
				kikan = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[4]);
				kbn = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[5]);
				syoriflg = "";
				syoninflg = "";

				for (int i = 0; i < HcdbDef.sinchoku.length; i++) {
					if (HcdbDef.sinchoku[i][0].equals(search_cnd[6])) {
						syoriflg = HcdbDef.sinchoku[i][2];
						syoninflg = HcdbDef.sinchoku[i][3];
					}
				}

				buryakusyo = search_cnd[7];

				if (search_cnd[6].equals("1")) {
					unionFlg = 1;
				}

			} else if (search_kbn.equals("2")) {
				kikan = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[4]);
				kbn = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[5]);
				kaihatuplan = search_cnd[6];
				umu = search_cnd[7];
				buryakusyo = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[8]);
			} else if (search_kbn.equals("3")) {
				simeino = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[4]);
				simeikanji = "_" + PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[5]);
				simeikana = "_" + PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[6]);
				simeieiji = "_" + PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[7]);
				buryakusyo = PZZ020_MakeSQLUtil.sanitizeSQLLikeData(search_cnd[8]);
			}

			String whr_p31 = "";
			if (search_kbn.equals("2") && !kaihatuplan.equals("")) {
				String cond = "";
				String cond2 = "";
				whr_p31 = " AND ";
				if (umu.equals("1")) {
					cond = " IS NOT NULL";
					cond2 = " OR ";
				} else {
					cond = " IS NULL";
					cond2 = " AND ";
				}
				if (kaihatuplan.equals("1")) {
					whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[0] + cond;
				} else if (kaihatuplan.equals("2")) {
					whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[1] + cond;
				} else if (kaihatuplan.equals("3")) {
					whr_p31 = whr_p31 + "( " + "p31." + HcdbDef.p31_searchchallenge_whr_column[2] + cond;
					for (int i = 3; i < 7; i++) {
						whr_p31 = whr_p31 + cond2 + "p31." + HcdbDef.p31_searchchallenge_whr_column[i] + cond;
					}
					whr_p31 = whr_p31 + " ) ";
				} else if (kaihatuplan.equals("4")) {
					whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[7] + cond;
				} else if (kaihatuplan.equals("5")) {
					whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[8] + cond;
				} else if (kaihatuplan.equals("6")) {
					whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[9] + cond;
				} else if (kaihatuplan.equals("7")) {
					whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[10] + cond;
				}
			}

			final String[] t01_whr = { simeino.concat("%"), simeikanji.trim().concat("%"), simeikana.trim().concat("%"), buryakusyo.trim() };

			final String[] t01_whr_eng = { simeino.concat("%"), simeikanji.trim().concat("%"), simeikana.trim().concat("%"), simeieiji.trim().concat("%"), buryakusyo.trim() };

			// select�̗�
			final int colnum = HcdbDef.t01_searchchallenge_column.length + HcdbDef.p31_searchchallenge_column.length - 1 + engName;

			final String[] selcol = new String[colnum];

			int selind = 0;
			if (jinRyaku == 1 && engName == 0) {
				selind = 0;
				for (int i = 0; i < HcdbDef.t01_searchchallenge_column.length; i++) {
					selcol[selind] = "t01." + HcdbDef.t01_searchchallenge_column[i];
					selind++;
				}
			} else if (jinRyaku == 1 && engName == 1) {
				selind = 0;
				for (int i = 0; i < HcdbDef.t01_searchchallenge_eng_column.length; i++) {
					selcol[selind] = "t01." + HcdbDef.t01_searchchallenge_eng_column[i];
					selind++;
				}
			} else if (jinRyaku == 2 && engName == 0) {
				selind = 0;
				for (int i = 0; i < HcdbDef.t01_searchchallenge_yaku_column.length; i++) {
					if (i == HcdbDef.jinryaku_pos && yakuMaster == 1) {
						selcol[selind] = "t15." + HcdbDef.t01_searchchallenge_yaku_column[i];
					} else {
						selcol[selind] = "t01." + HcdbDef.t01_searchchallenge_yaku_column[i];
					}
					selind++;
				}
			} else if (jinRyaku == 2 && engName == 1) {
				selind = 0;
				for (int i = 0; i < HcdbDef.t01_searchchallenge_yaku_eng_column.length; i++) {
					if (i == HcdbDef.jinryaku_eng_pos && yakuMaster == 1) {
						selcol[selind] = "t15." + HcdbDef.t01_searchchallenge_yaku_eng_column[i];
					} else {
						selcol[selind] = "t01." + HcdbDef.t01_searchchallenge_yaku_eng_column[i];
					}
					selind++;
				}
			}

			for (int i = 1; i < HcdbDef.p31_searchchallenge_column.length; i++) {
				selcol[selind] = "p31." + HcdbDef.p31_searchchallenge_column[i];
				selind++;
			}

			String sql = "SELECT " + selcol[0];

			sql = sql + ", " + selcol[1] + ", " + selcol[2] + ", " + selcol[3] + ", " + selcol[4] + ", " + selcol[5];
			if (engName == 1) {
				sql += ", " + selcol[6] + ", " + selcol[7] + " as KIKAN_MEI2, " + selcol[8] + ", " + selcol[9] + ", " + selcol[10] + ", " + selcol[11] + ", " + selcol[12];
			} else {
				sql += ", " + selcol[6] + " as KIKAN_MEI2, " + selcol[7] + ", " + selcol[8] + ", " + selcol[9] + ", " + selcol[10] + ", " + selcol[11];
			}

			// ����NO�����̂Ƃ���Seigyo_No���\�[�g�ɉ�����B
			if (search_kbn.equals("3")) {
				sql = sql + ", " + "p33.seigyo_no";
			}

			sql = sql + " FROM " + PBE_SearchChallengeEJBBean.T01tbl + " , " + PBE_SearchChallengeEJBBean.P31tbl;
			if (yakuMaster == 1) {
				sql = sql + " , " + PBE_SearchChallengeEJBBean.T15tbl;
			}
			// ����NO�����̂Ƃ��͂o33��from�ɉ�����B
			if (search_kbn.equals("3")) {
				sql = sql + ", " + "P33_CAREER_CHALLENGE_KIKAN_TBL p33 ";
			}

			String whr_stm = "";
			String whr_stm2 = "";
			sql = sql + " WHERE " + "t01." + HcdbDef.t01_searchchallenge_column[0] + " = p31." + HcdbDef.p31_searchchallenge_column[0] + " AND ";
			whr_stm = "p31." + HcdbDef.p31_searchchallenge_column[1] + " LIKE '" + kikan + "' ESCAPE '#'" + " AND p31." + HcdbDef.p31_searchchallenge_column[3] + " LIKE '" + kbn + "'";
			sql = sql + whr_stm + " AND p31." + HcdbDef.p31_searchchallenge_column[4] + " LIKE '" + syoriflg + "'" + " AND p31." + HcdbDef.p31_searchchallenge_column[5] + " LIKE '" + syoninflg + "'"
					+ whr_p31;

			int ind;

			if (engName == 0 || engName == 1 && simeieiji.trim().equals("_")) {
				// �p��������\�����Ȃ� or �p��������\������A���p�������̎w��Ȃ�
				for (ind = 0; ind < t01_whr.length - 1; ind++) {
					whr_stm2 = whr_stm2 + " AND t01." + HcdbDef.t01_searchchallenge_column[ind] + " LIKE '" + t01_whr[ind] + "' ESCAPE '#'";
				}
				if (!buryakusyo.trim().equals("")) {
					whr_stm2 = whr_stm2 + " AND t01." + HcdbDef.t01_search_syozoku[busyoPos - 1] + " LIKE '" + t01_whr[ind] + "' ESCAPE '#'";
				}
			} else {
				// �p��������\������
				for (ind = 0; ind < t01_whr_eng.length - 1; ind++) {
					whr_stm2 = whr_stm2 + " AND t01." + HcdbDef.t01_searchchallenge_eng_column[ind] + " LIKE '" + t01_whr_eng[ind] + "' ESCAPE '#'";
				}
				if (!buryakusyo.trim().equals("")) {
					whr_stm2 = whr_stm2 + " AND t01." + HcdbDef.t01_search_syozoku[busyoPos - 1] + " LIKE '" + t01_whr_eng[ind] + "' ESCAPE '#'";
				}
			}

			whr_stm2 = whr_stm2 + " AND t01." + HcdbDef.t01_honmu_cnd + " AND t01." + HcdbDef.t01_taisyoku_cnd;

			if (yakuMaster == 1) {
				whr_stm2 = whr_stm2 + " AND t15." + HcdbDef.yakusyoku_code + " = t01." + HcdbDef.yakusyoku_code;
			}

			sql = sql + whr_stm2;

			// ����NO�����̂Ƃ���P33�e�[�u���ƌ������A����NO���擾����B
			if (search_kbn.equals("3")) {
				sql = sql + " AND (" + " (P31.KUBUN = '2' AND P31.KIKAN_MEI = P33.JISSEKI_KIKAN_MEI )" + " OR (P31.KUBUN = '1' AND P31.KIKAN_MEI = P33.KEIKAKU_KIKAN_MEI ))";
			}

			if (unionFlg == 1) {
				sql = "( " + sql + " )" + " UNION ALL" + "( SELECT " + selcol[0];
				int newind;
				for (newind = 1; newind < selcol.length - 7; newind++) {
					sql = sql + ", " + selcol[newind];
				}
				sql = sql + ", '" + kikan + "' " + selcol[newind].substring(4) + ", '" + kikan + "' " + "KIKAN_MEI2" + ", '" + kbn + "' " + selcol[newind + 2].substring(4) + ", '' "
						+ selcol[newind + 3].substring(4) + ", '' " + selcol[newind + 4].substring(4) + ", '' " + selcol[newind + 5].substring(4) + ", '' " + selcol[newind + 6].substring(4)
						+ " FROM " + PBE_SearchChallengeEJBBean.T01tbl + " LEFT OUTER JOIN " + PBE_SearchChallengeEJBBean.P31tbl + " ON (T01." + HcdbDef.p31_search_jinmei[0] + " = P31."
						+ HcdbDef.p31_hyoji_column[0] + " AND " + whr_stm + ")";

				if (yakuMaster == 1) {
					sql = sql + " , " + PBE_SearchChallengeEJBBean.T15tbl;
				}
				sql = sql + " WHERE " + " P31." + HcdbDef.p31_hyoji_column[0] + " IS NULL " + whr_stm2 + " ) ";
			}

			// ����NO�����̂Ƃ���P33�e�[�u���ƌ������A����NO���擾����B
			if (search_kbn.equals("3")) {
				sql = sql + " ORDER BY SOSIKI_CODE,SIMEI_NO,SEIGYO_NO DESC,KUBUN";
			} else {
				sql = sql + " ORDER BY SOSIKI_CODE,SIMEI_NO,KIKAN_MEI2";
			}

			// �G���n���X�Ή�

			Log.debug("searchChallengeSQL:" + sql);
			stmt = dbConn.createStatement();
			rs = stmt.executeQuery(sql);

			final String[][] challengeList = new String[count][colnum];

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			int index = 0;
			while (rs.next()) {
				for (int i = 0; i < colnum; i++) {
					if (rs.getString(selcol[i].substring(4)) == null) {
						challengeList[index][i] = "";
					} else {
						challengeList[index][i] = rs.getString(selcol[i].substring(4));
					}
				}
				index++;
			}
			// MethodLog�o��
			Log.method(login_no, "OUT", "");

			return challengeList;
		} catch (final SQLException sqle) {
			throw sqle;
		} catch (final NamingException ne) {
			throw ne;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * SessionContext�����擾����B
	 * @return SessionContext���
	 */
	public SessionContext getSessionContext() {
		return this.my_ssc;
	}

	/**
	 * EJB�R���e�i���Ǘ�����SessionContext����SessionBean�ɓn���BSessionBean�̍쐬���ɌĂяo�����B
	 * @param val SessionContext���
	 * @exception RemoteException
	 */
	public void setSessionContext(final SessionContext val) throws RemoteException {
		this.my_ssc = val;
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException {/* �������܂��� */
	}

}
