/*
 * All Rights Reserved, Copyright (C) 2004,Hitachi System & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�Г�����@�\�j
 *
 * ���l�@�F
 *
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/24  01.00      ���� ��         �V�K�쐬
 *
 */

package jp.co.hisas.career.department.offer.bean;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaAssessBean;

/**
 * <PRE>
 * 
 * �N���X��: PEB_KouboKibouAssessmentBean �N���X �@�\����: �Г�����Č��̐E��f�[�^�A�]�������B���x��ێ�����B
 * 
 * </PRE>
 */
public class PEB_KouboAssessmentRirekiBean extends PEY_KouboOubosyaAssessBean implements Serializable {

	private String KouboAnkenId = null;

	private int seqNo = 0;

	private String syokuName = null;

	private String senmonName = null;

	private String levelName = null;

	private String levelCode = null;

	private int jikosougou = 0;

	private int hyokasyasougou = 0;

	public PEB_KouboAssessmentRirekiBean(final ResultSet rs) throws SQLException {

		this.setSyokucode(rs.getString(this.getIdentifier() + "SYOKU_CODE"));
		this.setSenmoncode(rs.getString(this.getIdentifier() + "SENMON_CODE"));
		this.setLevelcode(rs.getString(this.getIdentifier() + "LEVEL_CODE"));
		this.setSyokuName(rs.getString(this.getIdentifier() + "SYOKU_NAME"));
		this.setSenmonName(rs.getString(this.getIdentifier() + "SENMON_NAME"));
		this.setLevelName(rs.getString(this.getIdentifier() + "LEVEL_NAME"));
	}

	/**
	 * @return
	 */
	public String getKouboAnkenId() {
		return this.KouboAnkenId;
	}

	/**
	 * @return
	 */
	public String getLevelCode() {
		return this.levelCode;
	}

	/**
	 * @return
	 */
	public String getSenmonName() {
		return this.senmonName;
	}

	/**
	 * @return
	 */
	public int getSeqNo() {
		return this.seqNo;
	}

	/**
	 * @return
	 */
	public String getSyokuName() {
		return this.syokuName;
	}

	/**
	 * @param string
	 */
	public void setKouboAnkenId(final String string) {
		this.KouboAnkenId = string;
	}

	/**
	 * @param string
	 */
	public void setLevelCode(final String string) {
		this.levelCode = string;
	}

	/**
	 * @param string
	 */
	public void setSenmonName(final String string) {
		this.senmonName = string;
	}

	/**
	 * @param i
	 */
	public void setSeqNo(final int i) {
		this.seqNo = i;
	}

	/**
	 * @param string
	 */
	public void setSyokuName(final String string) {
		this.syokuName = string;
	}

	/**
	 * @return
	 */
	public int getHyokasyasougou() {
		return this.hyokasyasougou;
	}

	/**
	 * @return
	 */
	public int getJikosougou() {
		return this.jikosougou;
	}

	/**
	 * @param i
	 */
	public void setHyokasyasougou(final int i) {
		this.hyokasyasougou = i;
	}

	/**
	 * @param i
	 */
	public void setJikosougou(final int i) {
		this.jikosougou = i;
	}

	/**
	 * @return
	 */
	public String getLevelName() {
		return this.levelName;
	}

	/**
	 * @param string
	 */
	public void setLevelName(final String string) {
		this.levelName = string;
	}

}
