/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboAnkenBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboExtBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboKibouSyokusyuBean;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenSakuseiEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenSakuseiEJBHome;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PEB040_KouboAnkenSakuseiServlet.java �@�\�����F �i�l���j�R�����ʐݒ�ɂ��c�a�̃f�[�^���X�V���܂��B
 * 
 * </PRE>
 */

public class PEB040_KouboAnkenSakuseiServlet extends PEY010_ControllerServlet {

	/**
	 * request������̓f�[�^�i�R�����ʁA�A�������j ���擾���A�c�a�Ƀf�[�^���i�[���܂��B �i�[���SO1_KOUBO_TBL�e�[�u��
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PEY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		/* request ����A�l���擾 */
		final String kouboId = request.getParameter("koubo_anken_id");
		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEB_KouboAnkenSakuseiEJBHome kouboAnkenSakkuseiEJBHome = (PEB_KouboAnkenSakuseiEJBHome) fact.lookup(PEB_KouboAnkenSakuseiEJBHome.class);
		final PEB_KouboAnkenSakuseiEJB kouboSakuseiEJB = kouboAnkenSakkuseiEJBHome.create();
		final PEB_KouboAnkenBean ankenBean = this.setKouboBean(request, loginuser);

		try {
			if (kouboId == null || kouboId.equals("") || kouboId.length() == 0) {
				kouboSakuseiEJB.doInsert(ankenBean, loginuser);

			} else {
				kouboSakuseiEJB.doUpdate(ankenBean, loginuser);
			}
		} catch (final PEY_WarningException e) {
			request.setAttribute("warningID", "WEB044");
			throw e;
		}

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

	private PEB_KouboAnkenBean setKouboBean(final HttpServletRequest request, final PEY_PersonalBean loginuser) {

		final PEB_KouboAnkenBean kouboAnkenData = new PEB_KouboAnkenBean();
		final PEB_KouboExtBean kouboAnken = new PEB_KouboExtBean();

		kouboAnken.setKouboankenid(PZZ010_CharacterUtil.normalizedStr(request.getParameter("koubo_anken_id")));
		kouboAnken.setJigyobumei(PZZ010_CharacterUtil.normalizedStr(request.getParameter("jigyobu_mei")));
		kouboAnken.setJigyoubutyomei(PZZ010_CharacterUtil.normalizedStr(request.getParameter("jigyobutyo_mei")));
		kouboAnken.setSosikicode(PZZ010_CharacterUtil.normalizedStr(request.getParameter("sosiki_code")));
		kouboAnken.setSimeino(PZZ010_CharacterUtil.normalizedStr(request.getParameter("simei_no")));
		kouboAnken.setKouboankenmei(PZZ010_CharacterUtil.normalizedStr(request.getParameter("koubo_anken_mei")));
		kouboAnken.setAnkengaiyo(PZZ010_CharacterUtil.normalizedStr(request.getParameter("anken_gaiyo")));

		if (request.getParameter("bosyu_ninzu") == null || request.getParameter("bosyu_ninzu").equals("") || request.getParameter("bosyu_ninzu").length() == 0) {
			kouboAnken.setBosyuninzu(new Integer(0));
		} else {
			kouboAnken.setBosyuninzu(Integer.valueOf(request.getParameter("bosyu_ninzu")));
		}

		kouboAnken.setIdoukiboujiki(PZZ010_CharacterUtil.normalizedStr(request.getParameter("idou_kibou_jiki")));
		kouboAnken.setKibousyokusyuSonota(PZZ010_CharacterUtil.normalizedStr(request.getParameter("kibou_syokusyu_sonota")));
		kouboAnken.setKitaiyakuwaributyo(PZZ010_CharacterUtil.normalizedStr(request.getParameter("kitai_yakuwari_butyo")));
		kouboAnken.setKitaiyakuwarisyuningisi(PZZ010_CharacterUtil.normalizedStr(request.getParameter("kitai_yakuwari_syuningisi")));
		kouboAnken.setKitaiyakuwarigisi(PZZ010_CharacterUtil.normalizedStr(request.getParameter("kitai_yakuwari_gisi")));
		kouboAnken.setKitaiyakuwariippan(PZZ010_CharacterUtil.normalizedStr(request.getParameter("kitai_yakuwari_ippan")));
		kouboAnken.setSyozokukinmuti(PZZ010_CharacterUtil.normalizedStr(request.getParameter("syozoku_kinmuti")));
		kouboAnken.setGyomunaiyo(PZZ010_CharacterUtil.normalizedStr(request.getParameter("gyomu_naiyo")));
		kouboAnken.setJobgrade(PZZ010_CharacterUtil.normalizedStr(request.getParameter("job_grade")));
		kouboAnken.setSyokumurireki(PZZ010_CharacterUtil.normalizedStr(request.getParameter("syokumu_rireki")));
		kouboAnken.setOubosyayoukensonota(PZZ010_CharacterUtil.normalizedStr(request.getParameter("oubosya_youken_sonota")));
		kouboAnken.setKoubopr(PZZ010_CharacterUtil.normalizedStr(request.getParameter("koubo_pr")));
		kouboAnken.setSinseiriyu(PZZ010_CharacterUtil.normalizedStr(request.getParameter("sinsei_riyu")));
		kouboAnken.setSyoristatus(PZZ010_CharacterUtil.normalizedStr(request.getParameter("syori_status")));
		kouboAnken.setKousinbi(PZZ010_CharacterUtil.normalizedStr(request.getParameter("kousinbi")));
		kouboAnken.setKousinjikoku(PZZ010_CharacterUtil.normalizedStr(request.getParameter("kousinjikoku")));

		for (int i = 0; i < 3; i++) {
			final PEB_KouboKibouSyokusyuBean syokuBean = new PEB_KouboKibouSyokusyuBean();
			final int no = i + 1;
			syokuBean.setKouboAnkenId(PZZ010_CharacterUtil.normalizedStr(request.getParameter("koubo_anken_id")));
			syokuBean.setSyokuCode(PZZ010_CharacterUtil.normalizedStr(request.getParameter("syokusyu_code" + no)));
			syokuBean.setSenmonCode(PZZ010_CharacterUtil.normalizedStr(request.getParameter("senmon_code" + no)));
			syokuBean.setLevelCode(PZZ010_CharacterUtil.normalizedStr(request.getParameter("level_code" + no)));
			syokuBean.setKousinbi(PZZ010_CharacterUtil.normalizedStr(request.getParameter("kousinbi" + no)));
			syokuBean.setKousinjikoku(PZZ010_CharacterUtil.normalizedStr(request.getParameter("kousinjikoku" + no)));
			syokuBean.setSeqNo(no);

			kouboAnkenData.addKouboKibouSyokusyuBean(syokuBean);
		}

		kouboAnkenData.setKouboBean(kouboAnken);

		return kouboAnkenData;

	}
}
