/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.ejb.PEB_NijiShinsaGouhiSetteiEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_NijiShinsaGouhiSetteiEJBHome;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F IchijiShinsaGouhiSetteiServlet �@�\�����F �񎟐R�����ېݒ�F�c�a�̃f�[�^���X�V���܂��B
 * 
 * </PRE>
 */

public class PEB052_NijiShinsaGouhiSetteiServlet extends PEY010_ControllerServlet {

	/**
	 * request������̓f�[�^���擾���A�c�a�Ƀf�[�^���i�[���܂��B �i�[���D03_KOUBO_OUBOSYA_TBL�e�[�u��
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PEY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		/* request ����A�l���擾 */
		final String koubo_anken_id = request.getParameter("koubo_anken_id");
		final String simei_no = request.getParameter("simei_no");
		final String gouhi_status = request.getParameter("gouhi_status_g");
		final String shozoku_t = request.getParameter("shozoku_t_txt");
		final String shimei_t = request.getParameter("shimei_t_txt");
		final String gaisen = request.getParameter("gaisen_txt");
		final String naisen = request.getParameter("naisen_txt");
		final String mail = request.getParameter("mail_txt");
		final String renraku_jikou = request.getParameter("renraku_jikou_txt");
		final String kousinbi = request.getParameter("kousinbi");
		final String kousinjikoku = request.getParameter("kousinjikoku");

		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEB_NijiShinsaGouhiSetteiEJBHome home = (PEB_NijiShinsaGouhiSetteiEJBHome) fact.lookup(PEB_NijiShinsaGouhiSetteiEJBHome.class);
		final PEB_NijiShinsaGouhiSetteiEJB ejb = home.create();

		final PEY_KouboOubosyaBean koubooubosyaBean = new PEY_KouboOubosyaBean();
		koubooubosyaBean.setKouboankenid(koubo_anken_id);
		koubooubosyaBean.setSimeino(simei_no);
		koubooubosyaBean.setGouhistatus(gouhi_status);
		koubooubosyaBean.setToiawasesyozoku(shozoku_t);
		koubooubosyaBean.setToiawasesimei(shimei_t);
		koubooubosyaBean.setToiawasegaisen(gaisen);
		koubooubosyaBean.setToiawasenaisen(naisen);
		koubooubosyaBean.setToiawasemail(mail);
		koubooubosyaBean.setRenrakujikou(renraku_jikou);
		koubooubosyaBean.setKousinbi(kousinbi);
		koubooubosyaBean.setKousinjikoku(kousinjikoku);

		/* �X�V���s */
		final int count = ejb.doUpdate(koubooubosyaBean, loginuser);

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

}
