/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboOubosyaExtBean;
import jp.co.hisas.career.department.offer.bean.PEB_OubosyaJyohoBean;
import jp.co.hisas.career.department.offer.ejb.PEB_SuccessOrFailureEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_SuccessOrFailureEJBHome;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PEB050_SuccessOrFailureProcessingServlet �@�\�����F ���ۏ�����ʗp �u���E�U���瑗�M���ꂽ�l���󂯎��A�N���C�A���gBean�̌��剞��ҏ�񃁃\�b�h���Ăяo���B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PEB050_SuccessOrFailureProcessingServlet extends PEY010_ControllerServlet {
	/**
	 * request������̓f�[�^���擾���A�c�a�Ƀf�[�^���������܂��B
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			Exception {

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		final HttpSession session = request.getSession(false);
		final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");

		/* request ����A�l���擾 */
		final String koubo_anken_id = PZZ010_CharacterUtil.changeAnkenIdLength(request.getParameter("koubo_anken_id"));
		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEB_SuccessOrFailureEJBHome home = (PEB_SuccessOrFailureEJBHome) fact.lookup(PEB_SuccessOrFailureEJBHome.class);
		final PEB_SuccessOrFailureEJB ejb = home.create();

		/* �f�[�^���擾���� */
		final PEB_OubosyaJyohoBean[] koubooubosyaBeans = ejb.getGouhi(koubo_anken_id);
		request.setAttribute("koubooubosyaBean", koubooubosyaBeans);
		request.setAttribute("koubo_anken_id", koubo_anken_id);
		String koubo_anken_mei = "";
		if (koubooubosyaBeans != null && koubooubosyaBeans.length > 0) {
			final PEB_KouboOubosyaExtBean KouboOubosyaExtBean = koubooubosyaBeans[0].getKouboOubosya();
			if (KouboOubosyaExtBean != null) {
				koubo_anken_mei = KouboOubosyaExtBean.getAnkenmei();
			}
		}
		OutLogBean.sousaKojinJohoLog("VEB050", userinfo.getLogin_no(), "", koubo_anken_id);
		request.setAttribute("koubo_anken_mei", koubo_anken_mei);

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");
		return this.getForwardPath();
	}
}
