/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboAnkenBean;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenEJBHome;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.pdf.PZE130_KouboAnkenPDF;

/**
 * <PRE>
 * 
 * �T�v�F �Г�����Č���PDF�쐬���s���B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PEB079_KouboAnkenHyojiPdfServlet extends PEY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final String[] kouboAnkenId = request.getParameterValues("koubo_anken_id");

		if (kouboAnkenId[0] == null || kouboAnkenId[0].length() <= 0) {
			this.redirectErrorView(request, response, loginuser);
			return null;
		}
		try {

			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PEB_KouboAnkenEJBHome kouboAnkenEJBHome = (PEB_KouboAnkenEJBHome) fact.lookup(PEB_KouboAnkenEJBHome.class);
			final PEB_KouboAnkenEJB kouboAnkenEJB = kouboAnkenEJBHome.create();

			final PEB_KouboAnkenBean pdfData = kouboAnkenEJB.getKouboAnkenInfo(kouboAnkenId[0]);

			if (pdfData == null) {
				// �Y���f�[�^�����B
				throw new PEY_WarningException();
			}

			/* �t�@�C���ǂݍ��ݗp�o�b�t�@ */
			final byte[] buffer = new byte[4096];

			/* �t�@�C�����e�̏o�� */

			/* PDF�쐬 */
			final PZE130_KouboAnkenPDF pdf = new PZE130_KouboAnkenPDF();

			/* contentType���o�� */
			response.setContentType("application/pdf");

			/* �t�@�C�����̑��M(attachment������inline�ɕύX����΃C�����C���\��) */
			response.setHeader("Content-Disposition", "inline;");
			final String pdfFileName = this.makePdfFileName(loginuser);
			response.setHeader("Content-Disposition", "attachment; filename=\"" + pdfFileName + "\"");

			final ByteArrayOutputStream baos = new ByteArrayOutputStream();
			boolean pdfOutput;

			if (request.getParameter("hide_flg") != null && request.getParameter("hide_flg").equals("1")) {
				pdfOutput = pdf.makePdf(baos, PZE130_KouboAnkenPDF.KOUBO_ANKEN_SYOUSAI_OUBOSYA, null, loginuser, pdfData);
			} else {
				pdfOutput = pdf.makePdf(baos, PZE130_KouboAnkenPDF.KOUBO_ANKEN_SYOUSAI, null, loginuser, pdfData);
			}

			if (!pdfOutput) {
				this.redirectErrorView(request, response, loginuser);
			}
			final ServletOutputStream out = response.getOutputStream();
			final ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
			if (bais != null) {
				int size;

				while ((size = bais.read(buffer)) != -1) {
					out.write(buffer, 0, size);
				}

				bais.close();
			}

			out.close();
			response.flushBuffer();

			Log.performance(loginuser.getSimeiNo(), false, "");

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return null;
		} catch (final Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		}
	}

	/**
	 * �G���[��ʂ�\������B
	 */
	private void redirectErrorView(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws ServletException {
		try {
			this.getServletConfig().getServletContext().getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		} catch (final IOException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * PDF�t�@�C�������쐬����B
	 * @param userinfo
	 * @return PDF�t�@�C�����B
	 */
	private String makePdfFileName(final PEY_PersonalBean userinfo) {
		final StringBuffer buf = new StringBuffer();
		buf.append(userinfo.getSimeiNo());
		buf.append("_");
		final SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		buf.append(df.format(Calendar.getInstance().getTime()));
		buf.append("_");
		buf.append("VEB070");
		buf.append(".pdf");
		return buf.toString();
	}

}
