/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.learning.result;

import java.io.File;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import jp.co.hisas.addon.batch.util.FileUtility;
import jp.co.hisas.addon.batch.util.TextChecker;
import jp.co.hisas.addon.batch.util.TextWriter;

import org.apache.log4j.Logger;

/**
 * �捞�p�ݒ�̊Ǘ� �V�X�e���v���p�e�B����K�v�ȃf�[�^�����o������ �Ó������`�F�b�N�����肷��
 */
public class ImportConfigManager {

	private static final ImportConfigManager singleton = new ImportConfigManager();

	public static ImportConfigManager getInstance() {
		return ImportConfigManager.singleton;
	}

	// �e��^�C���X�^���v�̎擾
	public String getTimeStamp(final Date date) {
		final DateFormat df = new SimpleDateFormat(Import.FILE_TIMESTAMP_FORMAT);
		return df.format(date);
	}

	public String getSeqTimeStamp(final Date date) {
		final DateFormat df = new SimpleDateFormat(Import.SEQ_TIMESTAMP_FORMAT);
		return df.format(date);
	}

	public String getSysDate(final Date date) {
		final DateFormat df = new SimpleDateFormat(Import.SYSDATE_FORMAT);
		return df.format(date);
	}

	public String getSysTime(final Date date) {
		final DateFormat df = new SimpleDateFormat(Import.SYSTIME_FORMAT);
		return df.format(date);
	}

	// �e�탍�O�t�@�C���̃p�X�𐶐�����
	public String getResultLogPath(final String fileDir, final String timeStamp) {
		return fileDir + File.separator + MessageFormat.format(Import.RESULT_LOG_FILE_NAME, new Object[] { timeStamp });
	}

	public String getUnregisterdLogPath(final String fileDir, final String timeStamp) {
		return fileDir + File.separator + MessageFormat.format(Import.UNREGISTERD_LOG_FILE_NAME, new Object[] { timeStamp });
	}

	private final Logger logger = Logger.getLogger(this.getClass());

	/** �n���ꂽMap�Ɏw�肳�ꂽ��荞�ݗp�p�����[�^���G���[�`�F�b�N���� */
	public boolean checkImportParameter(final Import imp, final Map parameterMap) {

		final FileUtility fUtil = FileUtility.getInstance();

		final String inputFilePath = (String) parameterMap.get(Import.KEY_INPUT_FILE_PATH);
		final String resultLogPath = (String) parameterMap.get(Import.KEY_LOG_FILE_PATH1);
		final String unregisteredLogPath = (String) parameterMap.get(Import.KEY_LOG_FILE_PATH2);
		final String mode = (String) parameterMap.get(Import.KEY_TOUROKU_MODE);
		final String unregisterdDataImport = (String) parameterMap.get(Import.KEY_MITOUROKU_TORIKOMI_FLG);
		final String hasHeader = (String) parameterMap.get(Import.KEY_HEADER_FLG);
		final String csvColumnLength = (String) parameterMap.get(Import.KEY_INPUT_COLUMN_LENGTH);
		final String csvColSimeiNo = (String) parameterMap.get(Import.KEY_SIMEI_NO_NO);
		final String csvColKamokuCode = (String) parameterMap.get(Import.KEY_KAMOKU_CODE_NO);
		final String csvColClassCode = (String) parameterMap.get(Import.KEY_CLASS_CODE_NO);
		final String csvColSyuryoHantei = (String) parameterMap.get(Import.KEY_SYURYO_HANTEI_NO);
		final String csvColSyussekiNissu = (String) parameterMap.get(Import.KEY_SYUSSEKI_NISSU_NO);
		final String csvColTensu = (String) parameterMap.get(Import.KEY_TENSU_NO);
		final String csvColSeiseki = (String) parameterMap.get(Import.KEY_SEISEKI_NO);
		final String csvColSeisekibikou = (String) parameterMap.get(Import.KEY_SEISEKI_BIKOU_NO);
		final String labelMisyu = (String) parameterMap.get(Import.KEY_MISYU_STRING);
		final String labelSyuryo = (String) parameterMap.get(Import.KEY_SYURYO_STRING);
		final String labelNintei = (String) parameterMap.get(Import.KEY_NINTEI_STRING);

		final TextWriter resultLogwritelnr = imp.getResultLogWriter();

		boolean hasError = false;
		if (!fUtil.isExists(inputFilePath)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.IMPORT_LOG_NOT_FOUND).toCSV());
			hasError = true;
		}

		if (!fUtil.isExists(unregisteredLogPath)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.UNRGST_LOG_PATH_INVALID).toCSV());
			hasError = true;
		}

		if (mode == null || !(mode.equals(Import.MODE_UPDATE) || mode.equals(Import.MODE_DELETE))) {

			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.MODE_INVALID).toCSV());
			hasError = true;
		}

		if (unregisterdDataImport == null || !(unregisterdDataImport.equals(Import.FLG_TRUE) || unregisterdDataImport.equals(Import.FLG_FALSE))) {

			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.UNRGST_DATA_IMP_FLG_INVALID).toCSV());
			hasError = true;
		}

		if (hasHeader == null || !(hasHeader.equals(Import.FLG_TRUE) || hasHeader.equals(Import.FLG_FALSE))) {

			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.HAS_HEADER_FLG_INVALID).toCSV());
			hasError = true;
		}

		if (TextChecker.getInstance().isInteger(csvColumnLength)) {
			if (this.toNumber(csvColumnLength).compareTo(new BigDecimal(1)) == -1) {
				// checkCsvColLength < 1
				resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.IMP_COL_NUM_INVALID).toCSV());
				return false;
			}
		}

		final BigDecimal rangeCheckFrom = new BigDecimal(1);
		final BigDecimal rangeCheckTo = this.toNumber(csvColumnLength);
		if (!this.rangeCheck(csvColSimeiNo, rangeCheckFrom, rangeCheckTo)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.IMP_SIMEI_NO_COL_INVALID).toCSV());
			hasError = true;
		}

		if (!this.rangeCheck(csvColKamokuCode, rangeCheckFrom, rangeCheckTo)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.IMP_KAMOKU_CODE_COL_INVALID).toCSV());
			hasError = true;
		}

		if (!this.rangeCheck(csvColClassCode, rangeCheckFrom, rangeCheckTo)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.IMP_CLASS_CODE_COL_INVALID).toCSV());
			hasError = true;
		}

		if (!this.rangeCheck(csvColSyuryoHantei, rangeCheckFrom, rangeCheckTo)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.IMP_SYURYO_HANTEI_COL_INVALID).toCSV());
			hasError = true;
		}

		if (!this.rangeCheck(csvColSyussekiNissu, rangeCheckFrom, rangeCheckTo)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.IMP_SYUSSEKI_NISSU_COL_INVALID).toCSV());
			hasError = true;
		}

		if (!this.rangeCheck(csvColTensu, rangeCheckFrom, rangeCheckTo)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.IMP_TENSU_COL_INVALID).toCSV());
			hasError = true;
		}

		if (!this.rangeCheck(csvColSeiseki, rangeCheckFrom, rangeCheckTo)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.IMP_SEISEKI_COL_INVALID).toCSV());
			hasError = true;
		}

		if (!this.rangeCheck(csvColSeisekibikou, rangeCheckFrom, rangeCheckTo)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.IMP_SEISEKIBIKOU_COL_INVALID).toCSV());
			hasError = true;
		}

		final CharSequence[] csvCol = new CharSequence[] { csvColSimeiNo, csvColKamokuCode, csvColClassCode, csvColSyuryoHantei, csvColSyussekiNissu, csvColTensu, csvColSeiseki, csvColSeisekibikou };

		if (TextChecker.getInstance().hasDuplicate(csvCol)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.IMP_COL_DUPLICATE_SETTING).toCSV());
			hasError = true;
		}

		if (this.isNull(labelMisyu)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.LABEL_MISYU_INVALID).toCSV());
			hasError = true;
		}

		if (this.isNull(labelSyuryo)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.LABEL_SYURYO_INVALID).toCSV());
			hasError = true;
		}

		if (this.isNull(labelNintei)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.LABEL_NINTEI_INVALID).toCSV());
			hasError = true;
		}

		final CharSequence[] label = new CharSequence[] { labelMisyu, labelSyuryo, labelNintei };

		if (TextChecker.getInstance().hasDuplicate(label)) {
			resultLogwritelnr.writeln(ImportErrorLog.getInstance(ImportErrorID.LABEL_DUPLICATE_SETTING).toCSV());
			hasError = true;
		}
		return !hasError;
	}

	/**
	 * �G���[�`�F�b�N�ς݂̃v���p�e�B����ImportParameter�̃C���X�^���X�𐶐����� �o�b�`��������̃v���p�e�B�̎Q�Ƃ͂��̃C���X�^���X�o�R�ōs��
	 */
	public ImportParameter createImportParameter(final Map parameterMap) {

		final ImportParameter ret = new ImportParameter();
		ret.setCsvColumnLength(this.toLong(parameterMap.get(Import.KEY_INPUT_COLUMN_LENGTH)));
		ret.setCsvColClassCode(this.toLong(parameterMap.get(Import.KEY_CLASS_CODE_NO)));
		ret.setCsvColKamokuCode(this.toLong(parameterMap.get(Import.KEY_KAMOKU_CODE_NO)));
		ret.setCsvColSeiseki(this.toLong(parameterMap.get(Import.KEY_SEISEKI_NO)));
		ret.setCsvColSeisekibikou(this.toLong(parameterMap.get(Import.KEY_SEISEKI_BIKOU_NO)));
		ret.setCsvColSimeiNo(this.toLong(parameterMap.get(Import.KEY_SIMEI_NO_NO)));
		ret.setCsvColSyuryoHantei(this.toLong(parameterMap.get(Import.KEY_SYURYO_HANTEI_NO)));
		ret.setCsvColSyussekiNissu(this.toLong(parameterMap.get(Import.KEY_SYUSSEKI_NISSU_NO)));
		ret.setCsvColTensu(this.toLong(parameterMap.get(Import.KEY_TENSU_NO)));
		ret.setHasHeader(this.toBoolean(parameterMap.get(Import.KEY_HEADER_FLG)));
		ret.setInputFilePath((String) parameterMap.get(Import.KEY_INPUT_FILE_PATH));
		ret.setLabelMisyu((String) parameterMap.get(Import.KEY_MISYU_STRING));
		ret.setLabelNintei((String) parameterMap.get(Import.KEY_NINTEI_STRING));
		ret.setLabelSyuryo((String) parameterMap.get(Import.KEY_SYURYO_STRING));
		ret.setMode(this.toUpdateMode(parameterMap.get(Import.KEY_TOUROKU_MODE)));
		ret.setResultLogPath((String) parameterMap.get(Import.KEY_LOG_FILE_PATH1));
		ret.setUnregisterdDataImport(this.toBoolean(parameterMap.get(Import.KEY_MITOUROKU_TORIKOMI_FLG)));
		ret.setUnregisteredLogPath((String) parameterMap.get(Import.KEY_LOG_FILE_PATH2));
		return ret;
	}

	// ���������̌^ �ւ̕ϊ��e��
	private BigDecimal toNumber(final String str) {
		return new BigDecimal(str);
	}

	private long toLong(final Object str) {
		return new Long((String) str).longValue();
	}

	private boolean toBoolean(final Object str) {
		return ((String) str).equals(Import.FLG_FALSE) ? false : true;
	}

	private boolean isNull(final String str) {
		return str == null || str.equals("");
	}

	private int toUpdateMode(final Object str) {
		return ((String) str).equals(Import.MODE_UPDATE) ? ImportParameter.UPDATE : ImportParameter.DELETE;
	}

	/** �͈̓`�F�b�N */
	public boolean rangeCheck(final String checkStr, final BigDecimal from, final BigDecimal to) {

		if (!TextChecker.getInstance().isInteger(checkStr)) {
			return false;
		}
		final BigDecimal check = this.toNumber(checkStr);
		// from <= check <= to
		return from.compareTo(check) != 1 && check.compareTo(to) != 1;
	}

}
