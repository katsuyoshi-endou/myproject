/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.learning.result;

import java.io.Serializable;

/** ��u���ʎ捞�o�b�`�̃p�����[�^�[ */
public class ImportParameter implements Serializable {
	/** �ǉ��E�X�V���[�h */
	public final static int UPDATE = 0;

	/** �폜���[�h */
	public final static int DELETE = 1;

	/** �󌱌��ʎ捞�t�@�C���̃p�X */
	private String inputFilePath;

	/** ��u���ʎ捞���O�t�@�C���̃p�X */
	private String resultLogPath;

	/** ���o�^���O�t�@�C���̃p�X */
	private String unregisteredLogPath;

	/** �o�^���[�h */
	private int mode;

	/** ���o�^�捞�t���O */
	private boolean unregisterdDataImport;

	/** �w�b�_�s�t���O */
	private boolean hasHeader;

	/** ��u���ʎ捞�t�@�C���̗� */
	private long csvColumnLength;

	/** ����NO�̗� */
	private long csvColSimeiNo;

	/** �ȖڃR�[�h�̗� */
	private long csvColKamokuCode;

	/** �N���X�R�[�h�̗� */
	private long csvColClassCode;

	/** �C������̗� */
	private long csvColSyuryoHantei;

	/** �o�ȓ����̗� */
	private long csvColSyussekiNissu;

	/** �_���̗� */
	private long csvColTensu;

	/** ���т̗� */
	private long csvColSeiseki;

	/** ���є��l�̗� */
	private long csvColSeisekibikou;

	/** �u���C�v�̕����� */
	private String labelMisyu;

	/** �u�C���v�̕����� */
	private String labelSyuryo;

	/** �u�F��v�̕����� */
	private String labelNintei;

	// Setter & Getter
	public long getCsvColumnLength() {
		return this.csvColumnLength;
	}

	public long getCsvColClassCode() {
		return this.csvColClassCode;
	}

	public long getCsvColKamokuCode() {
		return this.csvColKamokuCode;
	}

	public long getCsvColSeiseki() {
		return this.csvColSeiseki;
	}

	public long getCsvColSeisekibikou() {
		return this.csvColSeisekibikou;
	}

	public long getCsvColSimeiNo() {
		return this.csvColSimeiNo;
	}

	public long getCsvColSyuryoHantei() {
		return this.csvColSyuryoHantei;
	}

	public long getCsvColSyussekiNissu() {
		return this.csvColSyussekiNissu;
	}

	public long getCsvColTensu() {
		return this.csvColTensu;
	}

	public boolean hasHeader() {
		return this.hasHeader;
	}

	public String getInputFilePath() {
		return this.inputFilePath;
	}

	public String getLabelMisyu() {
		return this.labelMisyu;
	}

	public String getLabelNintei() {
		return this.labelNintei;
	}

	public String getLabelSyuryo() {
		return this.labelSyuryo;
	}

	public int getMode() {
		return this.mode;
	}

	public String getResultLogPath() {
		return this.resultLogPath;
	}

	public boolean isUnregisterdDataImport() {
		return this.unregisterdDataImport;
	}

	public String getUnregisteredLogPath() {
		return this.unregisteredLogPath;
	}

	public void setCsvColumnLength(final long l) {
		this.csvColumnLength = l;
	}

	public void setCsvColClassCode(final long l) {
		this.csvColClassCode = l;
	}

	public void setCsvColKamokuCode(final long l) {
		this.csvColKamokuCode = l;
	}

	public void setCsvColSeiseki(final long l) {
		this.csvColSeiseki = l;
	}

	public void setCsvColSeisekibikou(final long l) {
		this.csvColSeisekibikou = l;
	}

	public void setCsvColSimeiNo(final long l) {
		this.csvColSimeiNo = l;
	}

	public void setCsvColSyuryoHantei(final long l) {
		this.csvColSyuryoHantei = l;
	}

	public void setCsvColSyussekiNissu(final long l) {
		this.csvColSyussekiNissu = l;
	}

	public void setCsvColTensu(final long l) {
		this.csvColTensu = l;
	}

	public void setHasHeader(final boolean b) {
		this.hasHeader = b;
	}

	public void setInputFilePath(final String string) {
		this.inputFilePath = string;
	}

	public void setLabelMisyu(final String string) {
		this.labelMisyu = string;
	}

	public void setLabelNintei(final String string) {
		this.labelNintei = string;
	}

	public void setLabelSyuryo(final String string) {
		this.labelSyuryo = string;
	}

	public void setMode(final int i) {
		this.mode = i;
	}

	public void setResultLogPath(final String string) {
		this.resultLogPath = string;
	}

	public void setUnregisterdDataImport(final boolean b) {
		this.unregisterdDataImport = b;
	}

	public void setUnregisteredLogPath(final String string) {
		this.unregisteredLogPath = string;
	}

}
