package jp.co.hisas.addon.batch.learning.trainingEntry.main;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.addon.batch.learning.trainingEntry.valuebean.PCY_TrainingEntryStatusBean;

/**
 * <PRE>
 * 
 * ���͉�А\����t�N���X
 * 
 * </PRE>
 *
 */
public class PartnerTrainingEntryBatch {

	/**
	 * �v���O�������s�Ԋu�i���j
	 */
	private final static String DEAULT_RUN_INTERVAL = "5";
	
	private Connection conn = null;
	
	public static void main( String[] args ) {
		try {
			Map<String, String> propMap = getSystemProperties();
			
			// �o�b�`���s�p�v���p�e�B�̎擾
			long interval = Long.parseLong( propMap.get( "RUN_INTERVAL" ), 10 );
			String batCtrlFilePath = propMap.get( "CTRL_FILE_PATH" );
		
			final PartnerTrainingEntryBatch batch = new PartnerTrainingEntryBatch();

			// �o�b�`��~�t�@�C�����L��΁A�폜
			File f = new File(batCtrlFilePath);
			if (f.exists()) {
				f.delete();
			}
		
			while (true) {
				batch.execute();
			
				File ctrlFile = new File(batCtrlFilePath);
				if (ctrlFile.exists()) {
					break;
				}
				Thread.sleep( interval );
			}
			System.exit( 0 );

		} catch( Exception e) {
			System.exit( -1 );
		}
	}
	
	/**
	 * �\����t���������s����
	 */
	private void execute() {
		
	}

	/**
	 * �o�b�`�N�����̃v���O�����������擾����
	 * 
	 * @return �����}�b�v���
	 */
	private static Map<String, String> getSystemProperties() {
		HashMap<String, String> propMap = new HashMap<String, String>();
		
		propMap.put( "RUN_INTERVAL", System.getProperty( "run_interval", DEAULT_RUN_INTERVAL ).trim());
		propMap.put( "CTRL_FILE_PATH", System.getProperty( "ctrl_file_path", "" ).trim());
		
		return propMap;
	}

	private List<PCY_TrainingEntryStatusBean> getTargetEntryList() {

		ArrayList<PCY_TrainingEntryStatusBean> list = new ArrayList<PCY_TrainingEntryStatusBean>();

		StringBuffer sb = new StringBuffer();
		
		sb.append( "SELECT ");
		sb.append( "    PROC_GRP_NO,");
		sb.append( "    PROC_ORDER,");
		sb.append( "    PROC_CLASS,");
		sb.append( "    PROC_RESULT,");
		sb.append( "    KAMOKU_CODE,");
		sb.append( "    CLASS_CODE,");
		sb.append( "    SIMEI_NO,");
		sb.append( "    MOUSIKOMISYA,");
		sb.append( "    JYUKOUBI,");
		sb.append( "    UPDATE_DATE  ");
		sb.append( "FROM ZZ_PARTNER_ENTRY_WK ");
		sb.append( "WHERE PROC_GRP_NO = ");
		sb.append( "(");
		sb.append( "    SELECT PROC_GRP_NO FROM");
		sb.append( "    (");
		sb.append( "        SELECT"); 
		sb.append( "            PS.PROC_GRP_NO PROC_GRP_NO,");
		sb.append( "            WK.UPDATE_DATE UPDATE_DATE,");
		sb.append( "            ROW_NUMBER() OVER (ORDER BY WK.UPDATE_DATE) ORDER_INDEX");
		sb.append( "        FROM ZZ_PARTNER_ENTRY_STATUS PS");
		sb.append( "            LEFT JOIN ZZ_PARTNER_ENTRY_WK WK ON PS.PROC_GRP_NO = WK.PROC_GRP_NO");
		sb.append( "        WHERE PS.STATUS = '0'");
		sb.append( "    )");
		sb.append( "    WHERE ORDER_INDEX = 1");
		sb.append( ")");
		sb.append( "ORDER BY PROC_ORDER");
		
		PreparedStatement ps = null;
		
		ResultSet rs = null;
		
		try {
			String sql = sb.toString();
			
			ps = conn.prepareStatement( sql );
			
			rs = ps.executeQuery();
			
			while (rs.next()) {
				PCY_TrainingEntryStatusBean bean = new PCY_TrainingEntryStatusBean();
				
				bean.setProcGroupNo( rs.getString("PROC_GRP_NO"));
			}
		}
		
		
		return list;
	}
}
