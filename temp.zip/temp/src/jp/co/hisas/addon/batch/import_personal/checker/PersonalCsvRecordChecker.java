/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.import_personal.checker;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;

import javax.naming.NamingException;

import jp.co.hisas.addon.batch.import_personal.dao.KokaiTeigiDao;
import jp.co.hisas.addon.batch.import_personal.dao.LevelDao;
import jp.co.hisas.addon.batch.import_personal.dao.PersonalDAO;
import jp.co.hisas.addon.batch.import_personal.dao.SenmobunyaDao;
import jp.co.hisas.addon.batch.import_personal.dao.SoshikiDAO;
import jp.co.hisas.addon.batch.import_personal.dao.SyokuiDao;
import jp.co.hisas.addon.batch.import_personal.dao.SyokusyuDao;
import jp.co.hisas.addon.batch.import_personal.dao.YakusyokuDao;
import jp.co.hisas.addon.batch.import_personal.ejb.ImportPersonalEJBBean;
import jp.co.hisas.addon.batch.import_personal.exception.BatchFailedException;
import jp.co.hisas.addon.batch.import_personal.exception.WrongArgumentException;
import jp.co.hisas.addon.batch.import_personal.man.MessageManager;
import jp.co.hisas.addon.batch.import_personal.record.PersonalRecord;
import jp.co.hisas.addon.batch.import_personal.util.CheckUtils;
import jp.co.hisas.addon.batch.import_personal.vo.BatchResultVO;
import jp.co.hisas.addon.batch.import_personal.vo.PersonalCsvVO;
import jp.co.hisas.addon.batch.import_personal.vo.PersonalCsvVOList;
import jp.co.hisas.addon.batch.import_personal.vo.TorikomiLog;
import jp.co.hisas.career.learning.base.PCY_ServiceLocator;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F PersonalCsvRecordChecker�N���X �@�\�����F CSV���R�[�h�̃f�[�^�ɑ΂���`�F�b�N���s��
 * 
 * </PRE>
 */
public final class PersonalCsvRecordChecker {

	/* ����ō��̒����y�эŏ��̒��� */
	/** ����NO�ő包�� */
	private final static int SIMEI_NO_MAXLENGTH = 20;

	/** ����NO�ŏ����� */
	private final static int SIMEI_NO_MINLENGTH = 1;

	/** �p�X���[�h�ő包�� */
	private final static int PASSWORD_MAXLENGTH = Integer.parseInt(ReadFile.fileMapData.get("PASSWORD_MAX_LENGTH").toString());

	/** �p�X���[�h�ŏ����� */
	private final static int PASSWORD_MINLENGTH = Integer.parseInt(ReadFile.fileMapData.get("PASSWORD_MIN_LENGTH").toString());

	/** ���������ő包�� */
	private final static int KANJI_SIMEI_MAXLENGTH = 20;

	/** ���������ŏ����� */
	private final static int KANJI_SIMEI_MINLENGTH = 1;

	/** �J�i�����i�S�p�j�ő包�� */
	private final static int KANA_SIMEI_MAXLENGTH = 40;

	/** �J�i�����i�S�p�j�ŏ����� */
	private final static int KANA_SIMEI_MINLENGTH = 1;

	/** �����i�p���j�ő包�� */
	private final static int EIJI_SIMEI_MAXLENGTH = 40;

	/** �����i�p���j�ŏ����� */
	private final static int EIJI_SIMEI_MINLENGTH = 1;

	/** �E�ʃR�[�h�ő包�� */
	private final static int SYOKUI_CODE_MAXLENGTH = 20;

	/** �g�D�R�[�h�ő包�� */
	private final static int SOSIKI_CODE_MAXLENGTH = 20;

	/** �A��������ő包�� */
	private final static int NAISEN_MAXLENGTH = 20;

	/** �A����O���ő包�� */
	private final static int GAISEN_MAXLENGTH = 20;

	/** FAX�ԍ��ő包�� */
	private final static int FAX_NO_MAXLENGTH = 20;

	/** Mail�ő包�� */
	private final static int MAIL_MAXLENGTH = 50;

	/** ����PR�ő包�� */
	private final static int JIKO_PR_MAXLENGTH = 600;

	/** �O���[�vID�ő包�� */
	private final static int YOBI1_MAXLENGTH = 30;

	/** Job�i���{��j�ő包�� */
	private final static int YOBI2_MAXLENGTH = 30;

	/** Job�i�p��j�ő包�� */
	private final static int YOBI3_MAXLENGTH = 30;

	/** Supervisor�i���{��j�ő包�� */
	private final static int YOBI4_MAXLENGTH = 30;

	/** Supervisor�i�p��j�ő包�� */
	private final static int YOBI5_MAXLENGTH = 30;

	/** �E��R�[�h�P�ő包�� */
	private final static int SYOKU_CODE1_MAXLENGTH = 4;

	/** �E��R�[�h�Q�ő包�� */
	private final static int SYOKU_CODE2_MAXLENGTH = 4;

	/** �E��R�[�h�R�ő包�� */
	private final static int SYOKU_CODE3_MAXLENGTH = 4;

	/** ��啪��R�[�h�P�ő包�� */
	private final static int SENMON_CODE1_MAXLENGTH = 4;

	/** ��啪��R�[�h�Q�ő包�� */
	private final static int SENMON_CODE2_MAXLENGTH = 4;

	/** ��啪��R�[�h�R�ő包�� */
	private final static int SENMON_CODE3_MAXLENGTH = 4;

	/** ���x���R�[�h�P�ő包�� */
	private final static int LEVEL_CODE1_MAXLENGTH = 1;

	/** ���x���R�[�h�Q�ő包�� */
	private final static int LEVEL_CODE2_MAXLENGTH = 1;

	/** ���x���R�[�h�R�ő包�� */
	private final static int LEVEL_CODE3_MAXLENGTH = 1;

	/** �ő包�� */
	// �G���[���b�Z�[�W�R�[�h��`
	/** ����NO�G���[�P */
	private static final String SIMEI_NO_ERROR_CODE1 = "HJE-2011";

	/** ����NO�G���[�Q */
	private static final String SIMEI_NO_ERROR_CODE2 = "HJE-2012";

	/** ����NO�G���[�R */
	private static final String SIMEI_NO_ERROR_CODE3 = "HJE-2013";

	/** �p�X���[�h�G���[�P */
	private static final String PASSWORD_ERROR_CODE1 = "HJE-2021";

	/** �p�X���[�h�G���[�Q */
	private static final String PASSWORD_ERROR_CODE2 = "HJE-2022";

	/** �p�X���[�h�G���[�R */
	private static final String PASSWORD_ERROR_CODE3 = "HJE-2023";

	/** �{���^�����t���O�G���[�P */
	private static final String HONMU_FLG_ERROR_CODE1 = "HJE-2031";

	/** �{���^�����t���O�G���[�Q */
	private static final String HONMU_FLG_ERROR_CODE2 = "HJE-2032";

	/** �{���^�����t���O�G���[�R */
	private static final String HONMU_FLG_ERROR_CODE3 = "HJE-2033";

	/** �{���^�����t���O�G���[�S */
	private static final String HONMU_FLG_ERROR_CODE4 = "HJE-2034";

	/** �{���^�����t���O�G���[�T */
	private static final String HONMU_FLG_ERROR_CODE5 = "HJE-2035";

	/** ���������G���[�P */
	private static final String KANJI_SIMEI_ERROR_CODE1 = "HJE-2041";

	/** ���������G���[�Q */
	private static final String KANJI_SIMEI_ERROR_CODE2 = "HJE-2042";

	/** ���������G���[�Q */
	private static final String KANJI_SIMEI_ERROR_CODE3 = "HJE-2043";

	/** �J�i�����i�S�p�j�G���[�P */
	private static final String KANA_SIMEI_ERROR_CODE1 = "HJE-2051";

	/** �J�i�����i�S�p�j�G���[�Q */
	private static final String KANA_SIMEI_ERROR_CODE2 = "HJE-2052";

	/** �J�i�����i�S�p�j�G���[�Q */
	private static final String KANA_SIMEI_ERROR_CODE3 = "HJE-2053";

	/** �����i�p���j�G���[1 */
	private static final String EIJI_SIMEI_ERROR_CODE1 = "HJE-2061";

	/** �����i�p���j�G���[2 */
	private static final String EIJI_SIMEI_ERROR_CODE2 = "HJE-2062";

	/** ���ʃG���[�P */
	private static final String SEIBETU_ERROR_CODE1 = "HJE-2071";

	/** ���ʃG���[�Q */
	private static final String SEIBETU_ERROR_CODE2 = "HJE-2072";

	/** ���N�����G���[�P */
	private static final String SEINENGAPPI_ERROR_CODE1 = "HJE-2081";

	/** ���N�����G���[�Q */
	private static final String SEINENGAPPI_ERROR_CODE2 = "HJE-2082";

	/** ���ДN���G���[�P */
	private static final String NYUSYA_NENGETU_ERROR_CODE1 = "HJE-2091";

	/** ���ДN���G���[�Q */
	private static final String NYUSYA_NENGETU_ERROR_CODE2 = "HJE-2092";

	/** ���E�ސE�t���O�G���[�P */
	private static final String GENSYOKU_TAISYOKU_FLG_ERROR_CODE1 = "HJE-2101";

	/** ���E�ސE�t���O�G���[�Q */
	private static final String GENSYOKU_TAISYOKU_FLG_ERROR_CODE2 = "HJE-2102";

	/** �ސE�N�����G���[�P */
	private static final String TAISYOKU_NENGAPPI_ERROR_CODE1 = "HJE-2111";

	/** �ސE�N�����G���[�Q */
	private static final String TAISYOKU_NENGAPPI_ERROR_CODE2 = "HJE-2112";

	/** �ސE�N�����G���[�R */
	private static final String TAISYOKU_NENGAPPI_ERROR_CODE3 = "HJE-2113";

	/** �����R�[�h�G���[�P */
	private static final String KENGEN_CODE_ERROR_CODE1 = "HJE-2121";

	/** �����R�[�h�G���[�Q */
	private static final String KENGEN_CODE_ERROR_CODE2 = "HJE-2122";

	/** ��E�R�[�h�G���[�P */
	private static final String YAKUSYOKU_CODE_ERROR_CODE1 = "HJE-2131";

	/** ��E�R�[�h�G���[�Q */
	private static final String YAKUSYOKU_CODE_ERROR_CODE2 = "HJE-2132";

	/** �E�ʃR�[�h�G���[�P */
	private static final String SYOKUI_CODE_ERROR_CODE1 = "HJE-2141";

	/** �E�ʃR�[�h�G���[�Q */
	private static final String SYOKUI_CODE_ERROR_CODE2 = "HJE-2142";

	/** �E�ʃR�[�h�G���[�R */
	private static final String SYOKUI_CODE_ERROR_CODE3 = "HJE-2143";

	/** �g�D�R�[�h�G���[�P */
	private static final String SOSIKI_CODE_ERROR_CODE1 = "HJE-2151";

	/** �g�D�R�[�h�G���[�Q */
	private static final String SOSIKI_CODE_ERROR_CODE2 = "HJE-2152";

	/** �g�D�R�[�h�G���[�R */
	private static final String SOSIKI_CODE_ERROR_CODE3 = "HJE-2153";

	/** �A��������G���[ */
	private static final String NAISEN_ERROR_CODE = "HJE-2161";

	/** �A����O���G���[ */
	private static final String GAISEN_ERROR_CODE = "HJE-2162";

	/** FAX�ԍ��G���[ */
	private static final String FAX_NO_ERROR_CODE = "HJE-2163";

	/** Mail�G���[�P */
	private static final String MAIL_ERROR_CODE1 = "HJE-2164";

	/** Mail�G���[�Q */
	private static final String MAIL_ERROR_CODE2 = "HJE-2165";

	/** ����PR�G���[ */
	private static final String JIKO_PR_ERROR_CODE = "HJE-2166";

	/** �O���[�vID�G���[ */
	private static final String YOBI1_ERROR_CODE = "HJE-2171";

	/** �O���[�vID�G���[ */
	private static final String YOBI2_ERROR_CODE = "HJE-2172";

	/** �O���[�vID�G���[ */
	private static final String YOBI3_ERROR_CODE = "HJE-2173";

	/** �O���[�vID�G���[ */
	private static final String YOBI4_ERROR_CODE = "HJE-2174";

	/** �O���[�vID�G���[ */
	private static final String YOBI5_ERROR_CODE = "HJE-2175";

	/** �E��R�[�h�P�G���[�P */
	private static final String SYOKU_CODE1_ERROR_CODE1 = "HJE-2201";

	/** �E��R�[�h�P�G���[�Q */
	private static final String SYOKU_CODE1_ERROR_CODE2 = "HJE-2202";

	/** ��啪��R�[�h�P�G���[�P */
	private static final String SENMON_CODE1_ERROR_CODE1 = "HJE-2211";

	/** ��啪��R�[�h�P�G���[�Q */
	private static final String SENMON_CODE1_ERROR_CODE2 = "HJE-2212";

	/** ���x���R�[�h�P�G���[�P */
	private static final String LEVEL_CODE1_ERROR_CODE1 = "HJE-2221";

	/** ���x���R�[�h�P�G���[�Q */
	private static final String LEVEL_CODE1_ERROR_CODE2 = "HJE-2222";

	/** �����B���x�P�G���[�P */
	private static final String SOUGOU_T_DO1_ERROR_CODE1 = "HJE-2231";

	/** �����B���x�P�G���[�Q */
	private static final String SOUGOU_T_DO1_ERROR_CODE2 = "HJE-2232";

	/** �E��R�[�h�Q�G���[�P */
	private static final String SYOKU_CODE2_ERROR_CODE1 = "HJE-2201";

	/** �E��R�[�h�Q�G���[�Q */
	private static final String SYOKU_CODE2_ERROR_CODE2 = "HJE-2202";

	/** ��啪��R�[�h�Q�G���[�P */
	private static final String SENMON_CODE2_ERROR_CODE1 = "HJE-2211";

	/** ��啪��R�[�h�Q�G���[�Q */
	private static final String SENMON_CODE2_ERROR_CODE2 = "HJE-2212";

	/** ���x���R�[�h�Q�G���[�P */
	private static final String LEVEL_CODE2_ERROR_CODE1 = "HJE-2221";

	/** ���x���R�[�h�Q�G���[�Q */
	private static final String LEVEL_CODE2_ERROR_CODE2 = "HJE-2222";

	/** �����B���x�Q�G���[�P */
	private static final String SOUGOU_T_DO2_ERROR_CODE1 = "HJE-2231";

	/** �����B���x�Q�G���[�Q */
	private static final String SOUGOU_T_DO2_ERROR_CODE2 = "HJE-2232";

	/** �E��R�[�h�R�G���[�P */
	private static final String SYOKU_CODE3_ERROR_CODE1 = "HJE-2201";

	/** �E��R�[�h�R�G���[�Q */
	private static final String SYOKU_CODE3_ERROR_CODE2 = "HJE-2202";

	/** ��啪��R�[�h�R�G���[�P */
	private static final String SENMON_CODE3_ERROR_CODE1 = "HJE-2211";

	/** ��啪��R�[�h�R�G���[�Q */
	private static final String SENMON_CODE3_ERROR_CODE2 = "HJE-2212";

	/** ���x���R�[�h�R�G���[�P */
	private static final String LEVEL_CODE3_ERROR_CODE1 = "HJE-2221";

	/** ���x���R�[�h�R�G���[�Q */
	private static final String LEVEL_CODE3_ERROR_CODE2 = "HJE-2222";

	/** �����B���x�R�G���[�P */
	private static final String SOUGOU_T_DO3_ERROR_CODE1 = "HJE-2231";

	/** �����B���x�R�G���[�Q */
	private static final String SOUGOU_T_DO3_ERROR_CODE2 = "HJE-2232";

	/** �X�L���Z�b�g�����e�i���X�t���O�G���[�P */
	private static final String SKILL_MAINTE_FLG_ERROR_CODE1 = "HJE-2301";

	/** �X�L���Z�b�g�����e�i���X�t���O�G���[�Q */
	private static final String SKILL_MAINTE_FLG_ERROR_CODE2 = "HJE-2302";

	/** �֘A�Ɩ��o�^�\�t���O�G���[�P */
	private static final String KANREN_GYOMU_TOUROKU_FLG_ERROR_CODE1 = "HJE-2311";

	/** �֘A�Ɩ��o�^�\�t���O�G���[�Q */
	private static final String KANREN_GYOMU_TOUROKU_FLG_ERROR_CODE2 = "HJE-2312";

	/** �p�[�\�i���v���t�@�C�������e�i���X�t���O�G���[�P */
	private static final String PERSONAL_MAINTE_FLG_ERROR_CODE1 = "HJE-2321";

	/** �p�[�\�i���v���t�@�C�������e�i���X�t���O�G���[�Q */
	private static final String PERSONAL_MAINTE_FLG_ERROR_CODE2 = "HJE-2322";

	/** ���i�c�a�����e�t���O�G���[�P */
	private static final String SIKAKU_MAINTE_FLG_ERROR_CODE1 = "HJE-2331";

	/** ���i�c�a�����e�t���O�G���[�Q */
	private static final String SIKAKU_MAINTE_FLG_ERROR_CODE2 = "HJE-2332";

	/** ���C�Ǘ��҃t���O�G���[�P */
	private static final String KENPO_MAINTE_FLG_ERROR_CODE1 = "HJE-2341";

	/** ���C�Ǘ��҃t���O�G���[�Q */
	private static final String KENPO_MAINTE_FLG_ERROR_CODE2 = "HJE-2342";

	/** ���O�C�����m�点��񃁃��e�t���O�G���[�P */
	private static final String LOGIN_OSIRASE_MAINTE_FLG_ERROR_CODE1 = "HJE-2351";

	/** ���O�C�����m�点��񃁃��e�t���O�G���[�Q */
	private static final String LOGIN_OSIRASE_MAINTE_FLG_ERROR_CODE2 = "HJE-2352";

	/** ���v�E���͏�񌟍������G���[�P */
	private static final String TOKEI_BUNSEKI_KENGEN_ERROR_CODE1 = "HJE-2381";

	/** ���v�E���͏�񌟍������G���[�Q */
	private static final String TOKEI_BUNSEKI_KENGEN_ERROR_CODE2 = "HJE-2382";

	/** ���v�E���͏�񌟍������G���[�R */
	private static final String TOKEI_BUNSEKI_KENGEN_ERROR_CODE3 = "HJE-2383";

	/** ���v�E���͏�񌟍������G���[�S */
	private static final String TOKEI_BUNSEKI_KENGEN_ERROR_CODE4 = "HJE-2384";

	/** ���v�E���͏�񌟍������G���[5 */
	private static final String TOKEI_BUNSEKI_KENGEN_ERROR_CODE5 = "HJE-2385";

	/** �ސE�Ҍ��������t���O�G���[�P */
	private static final String TAISYOKUSYA_KENSAKU_KENGEN_FLG_ERROR_CODE1 = "HJE-2361";

	/** �ސE�Ҍ��������t���O�G���[�Q */
	private static final String TAISYOKUSYA_KENSAKU_KENGEN_FLG_ERROR_CODE2 = "HJE-2362";

	/** ����J���������t���O�G���[�P */
	private static final String HIKOUKAI_KENSAKU_KENGEN_FLG_ERROR_CODE1 = "HJE-2371";

	/** ����J���������t���O�G���[�Q */
	private static final String HIKOUKAI_KENSAKU_KENGEN_FLG_ERROR_CODE2 = "HJE-2372";

	private static final String HONMU_FLG1 = "1";

	/** �o�b�`�G���[���e�i�[ */
	private BatchResultVO brl = null;

	/** �G���[���e�E���R�[�h���e �i�[ */
	private HashMap hm = null;

	private int csvRecordCount = 0;

	private PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();

	/**
	 * �R���X�g���N�^
	 */
	public PersonalCsvRecordChecker() {
		this.brl = new BatchResultVO();
		this.hm = new HashMap();
		this.csvRecordCount = 0;
		this.locator = PCY_ServiceLocator.getInstance();
	}

	/**
	 * CSV�̓��e�̃`�F�b�N���s���BOK�̏ꍇ�́A������s���p�[�\�i�����R�[�h��߂��B
	 * @param personalCsvVO PersonalCsvVO CSV�̓��e(ValueObject)
	 * @param personalInfo
	 * @return HashMap �G���[���e�E���R�[�h���e
	 * @exception NamingException �l�[�~���O��O�B
	 * @exception WrongArgumentException �����ُ�B
	 * @exception SQLException DB�֘A��O�B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �o�b�`���s��O�B
	 */
	public HashMap check(final PersonalCsvVO personalCsvVO, final HashMap personalInfo) throws NamingException, WrongArgumentException, SQLException, FileNotFoundException, IOException,
			BatchFailedException {

		Log.method("", "IN", "");

		final PersonalDAO personalDAO = new PersonalDAO(this.locator.getDataSource());

		final PersonalRecord personalRecord = new PersonalRecord();
		this.csvRecordCount = personalCsvVO.getCsvRecordCount();

		boolean isUpdate = false;

		personalRecord.setSimei_no(personalCsvVO.getSimei_no());
		personalRecord.setPassword(personalCsvVO.getPassword());
		personalRecord.setHonmu_flg(personalCsvVO.getHonmu_flg());
		personalRecord.setKanji_simei(personalCsvVO.getKanji_simei());
		personalRecord.setKana_simei(personalCsvVO.getKana_simei());
		personalRecord.setEiji_simei(personalCsvVO.getEiji_simei());
		personalRecord.setSeibetu(personalCsvVO.getSeibetu());
		personalRecord.setSeinengappi(personalCsvVO.getSeinengappi());
		personalRecord.setNyusya_nengetu(personalCsvVO.getNyusya_nengetu());
		personalRecord.setGensyoku_taisyoku_flg(personalCsvVO.getGensyoku_taisyoku_flg());
		personalRecord.setTaisyoku_nengappi(personalCsvVO.getTaisyoku_nengappi());
		personalRecord.setKengen_code(personalCsvVO.getKengen_code());
		personalRecord.setYakusyoku_code(personalCsvVO.getYakusyoku_code());
		personalRecord.setSyokui_code(personalCsvVO.getSyokui_code());
		personalRecord.setSosiki_code(personalCsvVO.getSosiki_code());
		personalRecord.setNaisen(personalCsvVO.getNaisen());
		personalRecord.setGaisen(personalCsvVO.getGaisen());
		personalRecord.setFax_no(personalCsvVO.getFax_no());
		personalRecord.setMail(personalCsvVO.getMail());
		personalRecord.setJiko_pr(personalCsvVO.getJiko_pr());
		personalRecord.setYobi1(personalCsvVO.getYobi1());
		personalRecord.setYobi2(personalCsvVO.getYobi2());
		personalRecord.setYobi3(personalCsvVO.getYobi3());
		personalRecord.setYobi4(personalCsvVO.getYobi4());
		personalRecord.setYobi5(personalCsvVO.getYobi5());
		personalRecord.setSyoku_code1(personalCsvVO.getSyoku_code1());
		personalRecord.setSenmon_code1(personalCsvVO.getSenmon_code1());
		personalRecord.setLevel_code1(personalCsvVO.getLevel_code1());
		personalRecord.setSougou_t_do1(personalCsvVO.getSougou_t_do1());
		personalRecord.setSyoku_code2(personalCsvVO.getSyoku_code2());
		personalRecord.setSenmon_code2(personalCsvVO.getSenmon_code2());
		personalRecord.setLevel_code2(personalCsvVO.getLevel_code2());
		personalRecord.setSougou_t_do2(personalCsvVO.getSougou_t_do2());
		personalRecord.setSyoku_code3(personalCsvVO.getSyoku_code3());
		personalRecord.setSenmon_code3(personalCsvVO.getSenmon_code3());
		personalRecord.setLevel_code3(personalCsvVO.getLevel_code3());
		personalRecord.setSougou_t_do3(personalCsvVO.getSougou_t_do3());
		personalRecord.setSkill_mainte_flg(personalCsvVO.getSkill_mainte_flg());
		personalRecord.setKanren_gyomu_touroku_flg(personalCsvVO.getKanren_gyomu_touroku_flg());
		personalRecord.setPersonal_mainte_flg(personalCsvVO.getPersonal_mainte_flg());
		personalRecord.setSikaku_mainte_flg(personalCsvVO.getSikaku_mainte_flg());
		personalRecord.setKenpo_mainte_flg(personalCsvVO.getKenpo_mainte_flg());
		personalRecord.setLogin_osirase_mainte_flg(personalCsvVO.getLogin_osirase_mainte_flg());
		personalRecord.setTokei_bunseki_kengen(personalCsvVO.getTokei_bunseki_kengen());
		personalRecord.setTaisyokusya_kensaku_kengen_flg(personalCsvVO.getTaisyokusya_kensaku_kengen_flg());
		personalRecord.setHikoukai_kensaku_kengen_flg(personalCsvVO.getHikoukai_kensaku_kengen_flg());

		if (this.checkSimeiNo(personalRecord.getSimei_no(), PersonalCsvRecordChecker.SIMEI_NO_MINLENGTH, PersonalCsvRecordChecker.SIMEI_NO_MAXLENGTH)) {
			if (personalDAO.isExist(personalRecord.getSimei_no()) && "1".equals(personalRecord.getHonmu_flg())) {
				this.hm.put("action", new Integer(PersonalCsvVO.UPDATE_PERSONAL));
				isUpdate = true;
			} else {
				this.hm.put("action", new Integer(PersonalCsvVO.ADD_PERSONAL));
				isUpdate = false;
			}
		}

		this.checkPassword(personalRecord.getPassword(), PersonalCsvRecordChecker.PASSWORD_MINLENGTH, PersonalCsvRecordChecker.PASSWORD_MAXLENGTH);
		this.checkHonmu_flg(personalRecord);
		this.checkKanji_simei(personalRecord.getKanji_simei(), PersonalCsvRecordChecker.KANJI_SIMEI_MINLENGTH, PersonalCsvRecordChecker.KANJI_SIMEI_MAXLENGTH);
		this.checkKana_simei(personalRecord.getKana_simei(), PersonalCsvRecordChecker.KANA_SIMEI_MINLENGTH, PersonalCsvRecordChecker.KANA_SIMEI_MAXLENGTH);
		this.checkEiji_simei(personalRecord.getEiji_simei(), PersonalCsvRecordChecker.EIJI_SIMEI_MINLENGTH, PersonalCsvRecordChecker.EIJI_SIMEI_MAXLENGTH);
		this.checkSeibetu(personalRecord.getSeibetu());
		this.checkSeinengappi(personalRecord.getSeinengappi());
		this.checkNyusya_nengetu(personalRecord.getNyusya_nengetu());
		this.checkGensyoku_taisyoku_flg(personalRecord.getGensyoku_taisyoku_flg());
		this.checkTaisyoku_nengappi(personalRecord.getTaisyoku_nengappi(), personalRecord.getGensyoku_taisyoku_flg());
		this.checkKengen_code(personalRecord.getKengen_code());
		this.checkYakusyoku_code(personalRecord.getYakusyoku_code());
		this.checkSyokui_code(personalRecord.getSyokui_code(), PersonalCsvRecordChecker.SYOKUI_CODE_MAXLENGTH);
		this.checkSosiki_code(personalRecord.getSosiki_code(), PersonalCsvRecordChecker.SOSIKI_CODE_MAXLENGTH);
		this.checkNaisen(personalRecord.getNaisen(), PersonalCsvRecordChecker.NAISEN_MAXLENGTH);
		this.checkGaisen(personalRecord.getGaisen(), PersonalCsvRecordChecker.GAISEN_MAXLENGTH);
		this.checkFax_no(personalRecord.getFax_no(), PersonalCsvRecordChecker.FAX_NO_MAXLENGTH);
		this.checkMail(personalRecord.getMail(), PersonalCsvRecordChecker.MAIL_MAXLENGTH);
		this.checkJiko_pr(personalRecord.getJiko_pr(), PersonalCsvRecordChecker.JIKO_PR_MAXLENGTH);
		this.checkYobi1(personalRecord.getYobi1(), PersonalCsvRecordChecker.YOBI1_MAXLENGTH);
		this.checkYobi2(personalRecord.getYobi2(), PersonalCsvRecordChecker.YOBI2_MAXLENGTH);
		this.checkYobi3(personalRecord.getYobi3(), PersonalCsvRecordChecker.YOBI3_MAXLENGTH);
		this.checkYobi4(personalRecord.getYobi4(), PersonalCsvRecordChecker.YOBI4_MAXLENGTH);
		this.checkYobi5(personalRecord.getYobi5(), PersonalCsvRecordChecker.YOBI5_MAXLENGTH);
		this.checkSyoku_code1(personalRecord.getSyoku_code1(), PersonalCsvRecordChecker.SYOKU_CODE1_MAXLENGTH);
		this.checkSenmon_code1(personalRecord.getSenmon_code1(), personalRecord.getSyoku_code1(), PersonalCsvRecordChecker.SENMON_CODE1_MAXLENGTH);
		this.checkLevel_code1(personalRecord.getLevel_code1(), personalRecord.getSyoku_code1(), personalRecord.getSenmon_code1(), PersonalCsvRecordChecker.LEVEL_CODE1_MAXLENGTH);
		this.checkSougou_t_do1(personalRecord.getSougou_t_do1(), personalRecord.getSyoku_code1(), personalRecord.getSenmon_code1(), personalRecord.getLevel_code1());
		this.checkSyoku_code2(personalRecord.getSyoku_code2(), PersonalCsvRecordChecker.SYOKU_CODE2_MAXLENGTH);
		this.checkSenmon_code2(personalRecord.getSenmon_code2(), personalRecord.getSyoku_code2(), PersonalCsvRecordChecker.SENMON_CODE2_MAXLENGTH);
		this.checkLevel_code2(personalRecord.getLevel_code2(), personalRecord.getSyoku_code2(), personalRecord.getSenmon_code2(), PersonalCsvRecordChecker.LEVEL_CODE2_MAXLENGTH);
		this.checkSougou_t_do2(personalRecord.getSougou_t_do2(), personalRecord.getSyoku_code2(), personalRecord.getSenmon_code2(), personalRecord.getLevel_code2());

		this.checkSyoku_code3(personalRecord.getSyoku_code3(), PersonalCsvRecordChecker.SYOKU_CODE3_MAXLENGTH);
		this.checkSenmon_code3(personalRecord.getSenmon_code3(), personalRecord.getSyoku_code3(), PersonalCsvRecordChecker.SENMON_CODE3_MAXLENGTH);
		this.checkLevel_code3(personalRecord.getLevel_code3(), personalRecord.getSyoku_code3(), personalRecord.getSenmon_code3(), PersonalCsvRecordChecker.LEVEL_CODE3_MAXLENGTH);
		this.checkSougou_t_do3(personalRecord.getSougou_t_do3(), personalRecord.getSyoku_code3(), personalRecord.getSenmon_code3(), personalRecord.getLevel_code3());
		this.checkSkill_mainte_flg(isUpdate, personalRecord.getSkill_mainte_flg());
		this.checkKanren_gyomu_touroku_flg(isUpdate, personalRecord.getKanren_gyomu_touroku_flg());
		this.checkPersonal_mainte_flg(isUpdate, personalRecord.getPersonal_mainte_flg());
		this.checkSikaku_mainte_flg(isUpdate, personalRecord.getSikaku_mainte_flg());
		this.checkKenpo_mainte_flg(isUpdate, personalRecord.getKenpo_mainte_flg());
		this.checkLogin_osirase_mainte_flg(isUpdate, personalRecord.getLogin_osirase_mainte_flg());
		this.checkTaisyokusya_kensaku_kengen_flg(isUpdate, personalRecord.getTaisyokusya_kensaku_kengen_flg());
		this.checkHikoukai_kensaku_kengen_flg(isUpdate, personalRecord.getHikoukai_kensaku_kengen_flg());
		this.checkTokei_bunseki_kengen(isUpdate, personalRecord.getTokei_bunseki_kengen());

		if (personalInfo.get(new Integer(this.csvRecordCount)) != null) {
			this.hm.put("record", null);
		} else {
			this.hm.put("record", personalRecord);
		}

		this.hm.put("error", this.brl);
		Log.method("", "OUT", "");
		return this.hm;
	}

	/**
	 * ����NO�`�F�b�N
	 * @param simeiNo ����NO
	 * @param minLength �ŏ��s���B
	 * @param maxLength �ő�s���B
	 * @return true: OK, false : �G���[�B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private boolean checkSimeiNo(final String simeiNo, final int minLength, final int maxLength) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(simeiNo)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.SIMEI_NO_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SIMEI_NO_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return false;
		}

		if (!CheckUtils.isByteSizeUnder(simeiNo, maxLength) || !CheckUtils.isByteSizeOver(simeiNo, minLength)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.SIMEI_NO_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SIMEI_NO_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return false;
		}

		if (!CheckUtils.isAlphabetOrNumeric(simeiNo)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.SIMEI_NO_ERROR_CODE3);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SIMEI_NO_ERROR_CODE3));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return false;
		}

		Log.method("", "OUT", "");

		return true;
	}

	/**
	 * �p�X���[�h�`�F�b�N
	 * @param password �p�X���[�h
	 * @param minLength �ŏ��s���B
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkPassword(final String password, final int minLength, final int maxLength) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(password)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.PASSWORD_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.PASSWORD_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!CheckUtils.isByteSizeUnder(password, maxLength) || !CheckUtils.isByteSizeOver(password, minLength)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.PASSWORD_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.PASSWORD_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!CheckUtils.isAlphabetOrNumeric(password)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.PASSWORD_ERROR_CODE3);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.PASSWORD_ERROR_CODE3));
			this.brl.addTorikomiLog(tkl);
		}

		Log.method("", "OUT", "");
	}

	/**
	 * �{���^�����t���O�`�F�b�N
	 * @param honmuFlg �{���^�����t���O
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 * @throws NamingException �l�[�~���O��O�B
	 * @throws IOException IO��O�B
	 */
	private void checkHonmu_flg(final PersonalRecord personalRecord) throws BatchFailedException, NamingException, FileNotFoundException, IOException {
		Log.method("", "IN", "");

		final PersonalDAO personalDAO = new PersonalDAO(this.locator.getDataSource());
		final String honmuFlg = personalRecord.getHonmu_flg();

		if (!CheckUtils.isNotNull(honmuFlg)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.HONMU_FLG_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.HONMU_FLG_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!"1".equals(honmuFlg) && !"2".equals(honmuFlg)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.HONMU_FLG_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.HONMU_FLG_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		boolean isSimeiNoExist = false;

		boolean isSosikiExist = false;

		try {
			final PersonalRecord record = personalDAO.lookupWithHonmuFlg(personalRecord.getSimei_no(), "1");

			if (record == null) {
				isSimeiNoExist = false;
				isSosikiExist = false;
			} else {
				isSimeiNoExist = true;
				if (personalRecord.getSosiki_code().equals(record.getSosiki_code())) {
					isSosikiExist = true;
				} else {
					isSosikiExist = false;
				}

			}
		} catch (final Exception e) {
			isSimeiNoExist = false;
			isSosikiExist = false;
		}

		if ("2".equals(honmuFlg) && !isSimeiNoExist) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.HONMU_FLG_ERROR_CODE3);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.HONMU_FLG_ERROR_CODE3));
			this.brl.addTorikomiLog(tkl);
		}

		if ("2".equals(honmuFlg) && isSosikiExist) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.HONMU_FLG_ERROR_CODE5);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.HONMU_FLG_ERROR_CODE5));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");
	}

	/**
	 * ���������`�F�b�N
	 * @param kanjiSimei ��������
	 * @param minLength �ŏ��s���B
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkKanji_simei(final String kanjiSimei, final int minLength, final int maxLength) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(kanjiSimei)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.KANJI_SIMEI_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.KANJI_SIMEI_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!CheckUtils.isByteSizeUnder(kanjiSimei, maxLength) || !CheckUtils.isByteSizeOver(kanjiSimei, minLength)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.KANJI_SIMEI_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.KANJI_SIMEI_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}

		if (!CheckUtils.isNotIncludeNGWord(kanjiSimei)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.KANJI_SIMEI_ERROR_CODE3);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.KANJI_SIMEI_ERROR_CODE3));
			this.brl.addTorikomiLog(tkl);
		}

		Log.method("", "OUT", "");
	}

	/**
	 * �J�i�����i�S�p�j�`�F�b�N
	 * @param kanaSimei �J�i�����i�S�p�j
	 * @param minLength �ŏ��s���B
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkKana_simei(final String kanaSimei, final int minLength, final int maxLength) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(kanaSimei)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.KANA_SIMEI_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.KANA_SIMEI_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!CheckUtils.isByteSizeUnder(kanaSimei, maxLength) || !CheckUtils.isByteSizeOver(kanaSimei, minLength)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.KANA_SIMEI_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.KANA_SIMEI_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}

		if (!CheckUtils.isNotIncludeNGWord(kanaSimei)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.KANA_SIMEI_ERROR_CODE3);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.KANA_SIMEI_ERROR_CODE3));
			this.brl.addTorikomiLog(tkl);
		}

		Log.method("", "OUT", "");
	}

	/**
	 * �����i�p���j�`�F�b�N
	 * @param eijiSimei �����i�p���j
	 * @param minLength �ŏ��s���B
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkEiji_simei(final String eijiSimei, final int minLength, final int maxLength) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(eijiSimei)) {
			Log.method("", "OUT", "");
			return;
		}

		if (!CheckUtils.isByteSizeUnder(eijiSimei, maxLength) || !CheckUtils.isByteSizeOver(eijiSimei, minLength)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.EIJI_SIMEI_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.EIJI_SIMEI_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
		}

		if (!CheckUtils.isNotIncludeNGWord(eijiSimei)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.EIJI_SIMEI_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.EIJI_SIMEI_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}

		Log.method("", "OUT", "");
	}

	/**
	 * ���ʃ`�F�b�N
	 * @param seibetu ����
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkSeibetu(final String seibetu) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(seibetu)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.SEIBETU_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SEIBETU_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!"1".equals(seibetu) && !"2".equals(seibetu)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.SEIBETU_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SEIBETU_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");

	}

	/**
	 * ���N�����`�F�b�N
	 * @param seinengappi ���N����
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkSeinengappi(final String seinengappi) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(seinengappi)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.SEINENGAPPI_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SEINENGAPPI_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!CheckUtils.isYYYYMMDDFormat(seinengappi)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.SEINENGAPPI_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SEINENGAPPI_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");

	}

	/**
	 * �����O���[�v���ДN���`�F�b�N
	 * @param nyusyaNengetu �����O���[�v���ДN��
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkNyusya_nengetu(final String nyusyaNengetu) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(nyusyaNengetu)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.NYUSYA_NENGETU_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.NYUSYA_NENGETU_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!CheckUtils.isYYYYMMDDFormat(nyusyaNengetu)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.NYUSYA_NENGETU_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.NYUSYA_NENGETU_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");
	}

	/**
	 * ���E�ސE�t���O�`�F�b�N
	 * @param gensyokuTaisyokuFlg ���E�ސE�t���O
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkGensyoku_taisyoku_flg(final String gensyokuTaisyokuFlg) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(gensyokuTaisyokuFlg)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.GENSYOKU_TAISYOKU_FLG_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.GENSYOKU_TAISYOKU_FLG_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!"1".equals(gensyokuTaisyokuFlg) && !"2".equals(gensyokuTaisyokuFlg)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.GENSYOKU_TAISYOKU_FLG_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.GENSYOKU_TAISYOKU_FLG_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");

	}

	/**
	 * �ސE�N�����`�F�b�N
	 * @param taisyokuNengappi �ސE�N����
	 * @param gensyokuTaisyokuFlg
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkTaisyoku_nengappi(final String taisyokuNengappi, final String gensyokuTaisyokuFlg) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(taisyokuNengappi)) {
			if (!CheckUtils.isYYYYMMDDFormat(taisyokuNengappi)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.TAISYOKU_NENGAPPI_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.TAISYOKU_NENGAPPI_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}
			if ("1".equals(gensyokuTaisyokuFlg)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.TAISYOKU_NENGAPPI_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.TAISYOKU_NENGAPPI_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

		} else {
			if ("2".equals(gensyokuTaisyokuFlg)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.TAISYOKU_NENGAPPI_ERROR_CODE3);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.TAISYOKU_NENGAPPI_ERROR_CODE3));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

		}
		Log.method("", "OUT", "");
	}

	/**
	 * �����R�[�h�`�F�b�N
	 * @param kengenCode �����R�[�h
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception WrongArgumentException �����ُ�B
	 * @exception IOException IO��O�B
	 * @exception SQLException DB�֘A��O�B
	 * @exception NamingException �l�[�~���O��O�B
	 */
	private void checkKengen_code(final String kengenCode) throws FileNotFoundException, WrongArgumentException, IOException, SQLException, NamingException {
		Log.method("", "IN", "");

		final KokaiTeigiDao kokaiTeigiDao = new KokaiTeigiDao(this.locator.getDataSource());

		if (!CheckUtils.isNotNull(kengenCode)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.KENGEN_CODE_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.KENGEN_CODE_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}
		if (!kokaiTeigiDao.isExistInternal(kengenCode)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.KENGEN_CODE_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.KENGEN_CODE_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");
	}

	/**
	 * ��E�R�[�h�`�F�b�N
	 * @param yakusyokuCode ��E�R�[�h
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception WrongArgumentException �����ُ�B
	 * @exception IOException IO��O�B
	 * @exception SQLException DB�֘A��O�B
	 * @exception NamingException �l�[�~���O��O�B
	 */
	private void checkYakusyoku_code(final String yakusyokuCode) throws FileNotFoundException, WrongArgumentException, IOException, SQLException, NamingException {
		Log.method("", "IN", "");

		final YakusyokuDao yakusyokuDao = new YakusyokuDao(this.locator.getDataSource());

		if (!CheckUtils.isNotNull(yakusyokuCode)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.YAKUSYOKU_CODE_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.YAKUSYOKU_CODE_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}
		if (!yakusyokuDao.isExist(yakusyokuCode)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.YAKUSYOKU_CODE_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.YAKUSYOKU_CODE_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");
	}

	/**
	 * �E�ʃR�[�h�`�F�b�N
	 * @param syokuiCode �E�ʃR�[�h
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception WrongArgumentException �����ُ�B
	 * @exception IOException IO��O�B
	 * @exception SQLException DB�֘A��O�B
	 * @exception NamingException �l�[�~���O��O�B
	 */
	private void checkSyokui_code(final String syokuiCode, final int maxLength) throws FileNotFoundException, WrongArgumentException, IOException, SQLException, NamingException {
		Log.method("", "IN", "");

		final SyokuiDao syokuiDao = new SyokuiDao(this.locator.getDataSource());

		if (CheckUtils.isNotNull(syokuiCode)) {
			if (!CheckUtils.isByteSizeUnder(syokuiCode, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SYOKUI_CODE_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SYOKUI_CODE_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

			if (!syokuiDao.isExist(syokuiCode)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SYOKUI_CODE_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SYOKUI_CODE_ERROR_CODE2));

				this.brl.addTorikomiLog(tkl);
			}
		}

		if (!CheckUtils.isNotNull(syokuiCode)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.SYOKUI_CODE_ERROR_CODE3);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SYOKUI_CODE_ERROR_CODE3));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		Log.method("", "OUT", "");
	}

	/**
	 * �g�D�R�[�h�`�F�b�N
	 * @param sosikiCode �g�D�R�[�h
	 * @param maxLength �ő�s���B
	 * @exception NamingException �l�[�~���O��O�B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception WrongArgumentException �����ُ�B
	 * @exception IOException IO��O�B
	 * @exception SQLException DB�֘A��O�B
	 */
	private void checkSosiki_code(final String sosikiCode, final int maxLength) throws NamingException, FileNotFoundException, WrongArgumentException, IOException, SQLException {
		Log.method("", "IN", "");

		final SoshikiDAO soshikiDAO = new SoshikiDAO(this.locator.getDataSource());

		if (CheckUtils.isNotNull(sosikiCode)) {
			if (!CheckUtils.isByteSizeUnder(sosikiCode, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SOSIKI_CODE_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SOSIKI_CODE_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

			if (!soshikiDAO.isExist(sosikiCode)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SOSIKI_CODE_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SOSIKI_CODE_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * �A��������`�F�b�N
	 * @param naisen �A�������
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 */
	private void checkNaisen(final String naisen, final int maxLength) throws FileNotFoundException, IOException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(naisen)) {
			if (!CheckUtils.isByteSizeUnder(naisen, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.NAISEN_ERROR_CODE);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.NAISEN_ERROR_CODE));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * �A����O���`�F�b�N
	 * @param gaisen �A����O��
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 */
	private void checkGaisen(final String gaisen, final int maxLength) throws FileNotFoundException, IOException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(gaisen)) {
			if (!CheckUtils.isByteSizeUnder(gaisen, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.GAISEN_ERROR_CODE);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.GAISEN_ERROR_CODE));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * FAX�ԍ��`�F�b�N
	 * @param faxNo FAX�ԍ�
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 */
	private void checkFax_no(final String faxNo, final int maxLength) throws FileNotFoundException, IOException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(faxNo)) {
			if (!CheckUtils.isByteSizeUnder(faxNo, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.FAX_NO_ERROR_CODE);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.FAX_NO_ERROR_CODE));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * Mail�`�F�b�N
	 * @param mail Mail
	 * @param maxLength
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 */
	private void checkMail(final String mail, final int maxLength) throws FileNotFoundException, IOException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(mail)) {
			if (!CheckUtils.isByteSizeUnder(mail, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.MAIL_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.MAIL_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
			}
			if (CheckUtils.hasSpace(mail)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.MAIL_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.MAIL_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * ����PR�`�F�b�N
	 * @param jikoPr ����PR
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 */
	private void checkJiko_pr(final String jikoPr, final int maxLength) throws FileNotFoundException, IOException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(jikoPr)) {
			if (!CheckUtils.isByteSizeUnder(jikoPr, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.JIKO_PR_ERROR_CODE);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.JIKO_PR_ERROR_CODE));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * �O���[�vID�`�F�b�N
	 * @param yobi1 �O���[�vID
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 */
	private void checkYobi1(final String yobi1, final int maxLength) throws FileNotFoundException, IOException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(yobi1)) {
			if (!CheckUtils.isByteSizeUnder(yobi1, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.YOBI1_ERROR_CODE);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.YOBI1_ERROR_CODE));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * Job�i���{��j�`�F�b�N
	 * @param yobi2 Job�i���{��j
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 */
	private void checkYobi2(final String yobi2, final int maxLength) throws FileNotFoundException, IOException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(yobi2)) {
			if (!CheckUtils.isByteSizeUnder(yobi2, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.YOBI2_ERROR_CODE);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.YOBI2_ERROR_CODE));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * Job�i�p��j�`�F�b�N
	 * @param yobi3 Job�i�p��j
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 */
	private void checkYobi3(final String yobi3, final int maxLength) throws FileNotFoundException, IOException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(yobi3)) {
			if (!CheckUtils.isByteSizeUnder(yobi3, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.YOBI3_ERROR_CODE);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.YOBI3_ERROR_CODE));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * Supervisor�i���{��j�`�F�b�N
	 * @param yobi4 Supervisor�i���{��j
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 */
	private void checkYobi4(final String yobi4, final int maxLength) throws FileNotFoundException, IOException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(yobi4)) {
			if (!CheckUtils.isByteSizeUnder(yobi4, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.YOBI4_ERROR_CODE);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.YOBI4_ERROR_CODE));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * Supervisor�i�p��j�`�F�b�N
	 * @param yobi5 Supervisor�i�p��j
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 */
	private void checkYobi5(final String yobi5, final int maxLength) throws FileNotFoundException, IOException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(yobi5)) {
			if (!CheckUtils.isByteSizeUnder(yobi5, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.YOBI5_ERROR_CODE);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.YOBI5_ERROR_CODE));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * �E��R�[�h�P�`�F�b�N
	 * @param syokuCode1 �E��R�[�h�P
	 * @param maxLength �ő�s���B
	 * @exception NamingException �l�[�~���O��O�B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception WrongArgumentException �����ُ�B
	 * @exception IOException IO��O�B
	 * @exception SQLException DB�֘A��O�B
	 */
	private void checkSyoku_code1(final String syokuCode1, final int maxLength) throws NamingException, FileNotFoundException, WrongArgumentException, IOException, SQLException {
		Log.method("", "IN", "");

		final SyokusyuDao syokusyuDao = new SyokusyuDao(this.locator.getDataSource());

		if (CheckUtils.isNotNull(syokuCode1)) {
			if (!CheckUtils.isByteSizeUnder(syokuCode1, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SYOKU_CODE1_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SYOKU_CODE1_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

			if (!syokusyuDao.isExist(syokuCode1)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SYOKU_CODE1_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SYOKU_CODE1_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * ��啪��R�[�h�P�`�F�b�N
	 * @param senmonCode1 ��啪��R�[�h�P
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception WrongArgumentException �����ُ�B
	 * @exception IOException IO��O�B
	 * @exception SQLException DB�֘A��O�B
	 * @exception NamingException �l�[�~���O��O�B
	 */
	private void checkSenmon_code1(final String senmonCode1, final String syokuCode1, final int maxLength) throws FileNotFoundException, WrongArgumentException, IOException, SQLException,
			NamingException {
		Log.method("", "IN", "");

		final SenmobunyaDao senmobunyaDao = new SenmobunyaDao(this.locator.getDataSource());

		if (CheckUtils.isNotNull(senmonCode1)) {
			if (!CheckUtils.isByteSizeUnder(senmonCode1, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SENMON_CODE1_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SENMON_CODE1_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

			if (!senmobunyaDao.isExistBySenmonCode(syokuCode1, senmonCode1)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SENMON_CODE1_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SENMON_CODE1_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * ���x���R�[�h�P�`�F�b�N
	 * @param levelCode1 ���x���R�[�h�P
	 * @param maxLength �ő�s���B
	 * @exception NamingException �l�[�~���O��O�B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception WrongArgumentException �����ُ�B
	 * @exception IOException IO��O�B
	 * @exception SQLException DB�֘A��O�B
	 */
	private void checkLevel_code1(final String levelCode1, final String syokuCode, final String senmonCode, final int maxLength) throws NamingException, FileNotFoundException, WrongArgumentException,
			IOException, SQLException {
		Log.method("", "IN", "");

		final LevelDao levelDao = new LevelDao(this.locator.getDataSource());

		if (CheckUtils.isNotNull(levelCode1)) {
			if (!CheckUtils.isByteSizeUnder(levelCode1, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.LEVEL_CODE1_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.LEVEL_CODE1_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

			if (!levelDao.isExistByLevelCode(syokuCode, senmonCode, levelCode1)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.LEVEL_CODE1_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.LEVEL_CODE1_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * �����B���x�P�`�F�b�N
	 * @param sougouTDo1 �����B���x�P
	 * @param syokuCode1 �E��R�[�h�P
	 * @param senmonCode1 ��啪��R�[�h�P
	 * @param levelCode1 ���x���R�[�h�P
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 */
	private void checkSougou_t_do1(final String sougouTDo1, final String syokuCode1, final String senmonCode1, final String levelCode1) throws FileNotFoundException, IOException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(sougouTDo1)) {
			if (!CheckUtils.isPercent(sougouTDo1)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SOUGOU_T_DO1_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SOUGOU_T_DO1_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

			if (!CheckUtils.isNotNull(syokuCode1) || !CheckUtils.isNotNull(senmonCode1) || !CheckUtils.isNotNull(levelCode1)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SOUGOU_T_DO1_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SOUGOU_T_DO1_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

		}
		if (!CheckUtils.isNotNull(sougouTDo1)) {
			if (CheckUtils.isNotNull(syokuCode1) || CheckUtils.isNotNull(senmonCode1) || CheckUtils.isNotNull(levelCode1)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SOUGOU_T_DO1_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SOUGOU_T_DO1_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
			}

		}

		Log.method("", "OUT", "");

	}

	/**
	 * �E��R�[�h�Q�`�F�b�N
	 * @param syokuCode2 �E��R�[�h�Q
	 * @param maxLength �ő�s���B
	 * @exception NamingException �l�[�~���O��O�B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception WrongArgumentException �����ُ�B
	 * @exception IOException IO��O�B
	 * @exception SQLException DB�֘A��O�B
	 */
	private void checkSyoku_code2(final String syokuCode2, final int maxLength) throws NamingException, FileNotFoundException, WrongArgumentException, IOException, SQLException {
		Log.method("", "IN", "");

		final SyokusyuDao syokusyuDao = new SyokusyuDao(this.locator.getDataSource());

		if (CheckUtils.isNotNull(syokuCode2)) {
			if (!CheckUtils.isByteSizeUnder(syokuCode2, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SYOKU_CODE2_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SYOKU_CODE2_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

			if (!syokusyuDao.isExist(syokuCode2)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SYOKU_CODE2_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SYOKU_CODE2_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * ��啪��R�[�h�Q�`�F�b�N
	 * @param senmonCode2 ��啪��R�[�h�Q
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception WrongArgumentException �����ُ�B
	 * @exception IOException IO��O�B
	 * @exception SQLException DB�֘A��O�B
	 * @exception NamingException �l�[�~���O��O�B
	 */
	private void checkSenmon_code2(final String senmonCode2, final String syokuCode2, final int maxLength) throws FileNotFoundException, WrongArgumentException, IOException, SQLException,
			NamingException {
		Log.method("", "IN", "");

		final SenmobunyaDao senmobunyaDao = new SenmobunyaDao(this.locator.getDataSource());

		if (CheckUtils.isNotNull(senmonCode2)) {
			if (!CheckUtils.isByteSizeUnder(senmonCode2, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SENMON_CODE2_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SENMON_CODE2_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

			if (!senmobunyaDao.isExistBySenmonCode(syokuCode2, senmonCode2)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SENMON_CODE2_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SENMON_CODE2_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * ���x���R�[�h�Q�`�F�b�N
	 * @param levelCode2 ���x���R�[�h�Q
	 * @param maxLength �ő�s���B
	 * @exception NamingException �l�[�~���O��O�B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception WrongArgumentException �����ُ�B
	 * @exception IOException IO��O�B
	 * @exception SQLException DB�֘A��O�B
	 */
	private void checkLevel_code2(final String levelCode2, final String syokuCode, final String senmonCode, final int maxLength) throws NamingException, FileNotFoundException, WrongArgumentException,
			IOException, SQLException {
		Log.method("", "IN", "");

		final LevelDao levelDao = new LevelDao(this.locator.getDataSource());

		if (CheckUtils.isNotNull(levelCode2)) {
			if (!CheckUtils.isByteSizeUnder(levelCode2, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.LEVEL_CODE2_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.LEVEL_CODE2_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

			if (!levelDao.isExistByLevelCode(syokuCode, senmonCode, levelCode2)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.LEVEL_CODE2_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.LEVEL_CODE2_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * �����B���x�Q�`�F�b�N
	 * @param sougouTDo2 �����B���x�Q
	 * @param syokuCode2 �E��R�[�h�Q
	 * @param senmonCode2 ��啪��R�[�h�Q
	 * @param levelCode2 ���x���R�[�h�Q
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 */
	private void checkSougou_t_do2(final String sougouTDo2, final String syokuCode2, final String senmonCode2, final String levelCode2) throws FileNotFoundException, IOException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(sougouTDo2)) {
			if (!CheckUtils.isPercent(sougouTDo2)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SOUGOU_T_DO2_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SOUGOU_T_DO2_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}
			if (!CheckUtils.isNotNull(syokuCode2) || !CheckUtils.isNotNull(senmonCode2) || !CheckUtils.isNotNull(levelCode2)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SOUGOU_T_DO2_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SOUGOU_T_DO2_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}
		}
		if (!CheckUtils.isNotNull(sougouTDo2)) {
			if (CheckUtils.isNotNull(syokuCode2) || CheckUtils.isNotNull(senmonCode2) || CheckUtils.isNotNull(levelCode2)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SOUGOU_T_DO2_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SOUGOU_T_DO2_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
			}

		}

		Log.method("", "OUT", "");

	}

	/**
	 * �E��R�[�h�R�`�F�b�N
	 * @param syokuCode3 �E��R�[�h�R
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception WrongArgumentException �����ُ�B
	 * @exception IOException IO��O�B
	 * @exception SQLException DB�֘A��O�B
	 * @exception NamingException �l�[�~���O��O�B
	 */
	private void checkSyoku_code3(final String syokuCode3, final int maxLength) throws FileNotFoundException, WrongArgumentException, IOException, SQLException, NamingException {
		Log.method("", "IN", "");

		final SyokusyuDao syokusyuDao = new SyokusyuDao(this.locator.getDataSource());

		if (CheckUtils.isNotNull(syokuCode3)) {
			if (!CheckUtils.isByteSizeUnder(syokuCode3, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SYOKU_CODE3_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SYOKU_CODE3_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

			if (!syokusyuDao.isExist(syokuCode3)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SYOKU_CODE3_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SYOKU_CODE3_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * ��啪��R�[�h�R�`�F�b�N
	 * @param senmonCode3 ��啪��R�[�h�R
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception WrongArgumentException �����ُ�B
	 * @exception IOException IO��O�B
	 * @exception SQLException DB�֘A��O�B
	 * @exception NamingException �l�[�~���O��O�B
	 */
	private void checkSenmon_code3(final String senmonCode3, final String syokuCode3, final int maxLength) throws FileNotFoundException, WrongArgumentException, IOException, SQLException,
			NamingException {
		Log.method("", "IN", "");

		final SenmobunyaDao senmobunyaDao = new SenmobunyaDao(this.locator.getDataSource());

		if (CheckUtils.isNotNull(senmonCode3)) {
			if (!CheckUtils.isByteSizeUnder(senmonCode3, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SENMON_CODE3_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SENMON_CODE3_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

			if (!senmobunyaDao.isExistBySenmonCode(syokuCode3, senmonCode3)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SENMON_CODE3_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SENMON_CODE3_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * ���x���R�[�h�R�`�F�b�N
	 * @param levelCode3 ���x���R�[�h�R
	 * @param maxLength �ő�s���B
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception WrongArgumentException �����ُ�B
	 * @exception IOException IO��O�B
	 * @exception SQLException DB�֘A��O�B
	 * @exception NamingException �l�[�~���O��O�B
	 */
	private void checkLevel_code3(final String levelCode3, final String syokuCode, final String senmonCode, final int maxLength) throws FileNotFoundException, WrongArgumentException, IOException,
			SQLException, NamingException {
		Log.method("", "IN", "");

		final LevelDao levelDao = new LevelDao(this.locator.getDataSource());

		if (CheckUtils.isNotNull(levelCode3)) {
			if (!CheckUtils.isByteSizeUnder(levelCode3, maxLength)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.LEVEL_CODE3_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.LEVEL_CODE3_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}

			if (!levelDao.isExistByLevelCode(syokuCode, senmonCode, levelCode3)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.LEVEL_CODE3_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.LEVEL_CODE3_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
			}
		}
		Log.method("", "OUT", "");
	}

	/**
	 * �����B���x�R�`�F�b�N
	 * @param sougouTDo3 �����B���x�R
	 * @param syokuCode3 �E��R�[�h�R
	 * @param senmonCode3 ��啪��R�[�h�R
	 * @param levelCode3 ���x���R�[�h�R
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 */
	private void checkSougou_t_do3(final String sougouTDo3, final String syokuCode3, final String senmonCode3, final String levelCode3) throws FileNotFoundException, IOException {
		Log.method("", "IN", "");

		if (CheckUtils.isNotNull(sougouTDo3)) {
			if (!CheckUtils.isPercent(sougouTDo3)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SOUGOU_T_DO3_ERROR_CODE1);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SOUGOU_T_DO3_ERROR_CODE1));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}
			if (!CheckUtils.isNotNull(syokuCode3) || !CheckUtils.isNotNull(senmonCode3) || !CheckUtils.isNotNull(levelCode3)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SOUGOU_T_DO3_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SOUGOU_T_DO3_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
				return;
			}
		}
		if (!CheckUtils.isNotNull(sougouTDo3)) {
			if (CheckUtils.isNotNull(syokuCode3) || CheckUtils.isNotNull(senmonCode3) || CheckUtils.isNotNull(levelCode3)) {
				final TorikomiLog tkl = new TorikomiLog();
				tkl.setLineNo(this.csvRecordCount);
				tkl.setMsgID(PersonalCsvRecordChecker.SOUGOU_T_DO3_ERROR_CODE2);
				tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SOUGOU_T_DO3_ERROR_CODE2));
				this.brl.addTorikomiLog(tkl);
				Log.method("", "OUT", "");
			}

		}

		Log.method("", "OUT", "");

	}

	/**
	 * �X�L���Z�b�g�����e�i���X�t���O�`�F�b�N
	 * @param skillMainteFlg �X�L���Z�b�g�����e�i���X�t���O
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkSkill_mainte_flg(final boolean allowNull, final String skillMainteFlg) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(skillMainteFlg)) {
			if (allowNull) {
				Log.method("", "OUT", "");
				return;
			}
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.SKILL_MAINTE_FLG_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SKILL_MAINTE_FLG_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!"0".equals(skillMainteFlg) && !"1".equals(skillMainteFlg)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.SKILL_MAINTE_FLG_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SKILL_MAINTE_FLG_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");

	}

	/**
	 * �֘A�Ɩ��o�^�\�t���O�`�F�b�N
	 * @param kanrenGyomuTourokuFlg �֘A�Ɩ��o�^�\�t���O
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkKanren_gyomu_touroku_flg(final boolean allowNull, final String kanrenGyomuTourokuFlg) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(kanrenGyomuTourokuFlg)) {
			if (allowNull) {
				Log.method("", "OUT", "");
				return;
			}
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.KANREN_GYOMU_TOUROKU_FLG_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.KANREN_GYOMU_TOUROKU_FLG_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!"0".equals(kanrenGyomuTourokuFlg) && !"1".equals(kanrenGyomuTourokuFlg)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.KANREN_GYOMU_TOUROKU_FLG_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.KANREN_GYOMU_TOUROKU_FLG_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");

	}

	/**
	 * �p�[�\�i���v���t�@�C�������e�i���X�t���O�`�F�b�N
	 * @param personalMainteFlg �p�[�\�i���v���t�@�C�������e�i���X�t���O
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkPersonal_mainte_flg(final boolean allowNull, final String personalMainteFlg) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(personalMainteFlg)) {
			if (allowNull) {
				Log.method("", "OUT", "");
				return;
			}
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.PERSONAL_MAINTE_FLG_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.PERSONAL_MAINTE_FLG_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!"0".equals(personalMainteFlg) && !"1".equals(personalMainteFlg)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.PERSONAL_MAINTE_FLG_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.PERSONAL_MAINTE_FLG_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");

	}

	/**
	 * ���i�c�a�����e�t���O�`�F�b�N
	 * @param sikakuMainteFlg ���i�c�a�����e�t���O
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkSikaku_mainte_flg(final boolean allowNull, final String sikakuMainteFlg) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(sikakuMainteFlg)) {
			if (allowNull) {
				Log.method("", "OUT", "");
				return;
			}
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.SIKAKU_MAINTE_FLG_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SIKAKU_MAINTE_FLG_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!"0".equals(sikakuMainteFlg) && !"1".equals(sikakuMainteFlg)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.SIKAKU_MAINTE_FLG_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SIKAKU_MAINTE_FLG_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");

	}

	/**
	 * ���C�Ǘ��҃t���O�`�F�b�N
	 * @param kenpoMainteFlg ���C�Ǘ��҃t���O
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkKenpo_mainte_flg(final boolean allowNull, final String kenpoMainteFlg) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(kenpoMainteFlg)) {
			if (allowNull) {
				Log.method("", "OUT", "");
				return;
			}
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.KENPO_MAINTE_FLG_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.KENPO_MAINTE_FLG_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!"0".equals(kenpoMainteFlg) && !"1".equals(kenpoMainteFlg)) {

			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.KENPO_MAINTE_FLG_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.KENPO_MAINTE_FLG_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");

	}

	/**
	 * ���O�C�����m�点��񃁃��e�t���O�`�F�b�N
	 * @param loginOsiraseMainteFlg ���O�C�����m�点��񃁃��e�t���O
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkLogin_osirase_mainte_flg(final boolean allowNull, final String loginOsiraseMainteFlg) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(loginOsiraseMainteFlg)) {
			if (allowNull) {
				Log.method("", "OUT", "");
				return;
			}
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.LOGIN_OSIRASE_MAINTE_FLG_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.LOGIN_OSIRASE_MAINTE_FLG_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!"0".equals(loginOsiraseMainteFlg) && !"1".equals(loginOsiraseMainteFlg)) {

			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.LOGIN_OSIRASE_MAINTE_FLG_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.LOGIN_OSIRASE_MAINTE_FLG_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");

	}

	/**
	 * ���v�E���͏�񌟍������`�F�b�N
	 * @param tokeiBunsekiKengen ���v�E���͏�񌟍�����
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkTokei_bunseki_kengen(final boolean allowNull, final String tokeiBunsekiKengen) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(tokeiBunsekiKengen)) {
			if (allowNull) {
				Log.method("", "OUT", "");
				return;
			}
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.TOKEI_BUNSEKI_KENGEN_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.TOKEI_BUNSEKI_KENGEN_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (tokeiBunsekiKengen.length() < 1 || tokeiBunsekiKengen.charAt(0) != '0' && tokeiBunsekiKengen.charAt(0) != '1') {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.TOKEI_BUNSEKI_KENGEN_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.TOKEI_BUNSEKI_KENGEN_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}

		if (tokeiBunsekiKengen.length() < 2 || tokeiBunsekiKengen.charAt(1) != '0' && tokeiBunsekiKengen.charAt(1) != '1') {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.TOKEI_BUNSEKI_KENGEN_ERROR_CODE3);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.TOKEI_BUNSEKI_KENGEN_ERROR_CODE3));
			this.brl.addTorikomiLog(tkl);
		}

		if (tokeiBunsekiKengen.length() < 3 || tokeiBunsekiKengen.charAt(2) != '0' && tokeiBunsekiKengen.charAt(2) != '1') {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.TOKEI_BUNSEKI_KENGEN_ERROR_CODE4);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.TOKEI_BUNSEKI_KENGEN_ERROR_CODE4));
			this.brl.addTorikomiLog(tkl);
		}

		if (tokeiBunsekiKengen.length() != 20) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.TOKEI_BUNSEKI_KENGEN_ERROR_CODE5);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.TOKEI_BUNSEKI_KENGEN_ERROR_CODE5));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");

	}

	/**
	 * ����J���������t���O�`�F�b�N
	 * @param taisyokusyaKensakuKengenFlg ����J���������t���O
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkTaisyokusya_kensaku_kengen_flg(final boolean allowNull, final String taisyokusyaKensakuKengenFlg) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(taisyokusyaKensakuKengenFlg)) {
			if (allowNull) {
				Log.method("", "OUT", "");
				return;
			}
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.TAISYOKUSYA_KENSAKU_KENGEN_FLG_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.TAISYOKUSYA_KENSAKU_KENGEN_FLG_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!"0".equals(taisyokusyaKensakuKengenFlg) && !"1".equals(taisyokusyaKensakuKengenFlg)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.TAISYOKUSYA_KENSAKU_KENGEN_FLG_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.TAISYOKUSYA_KENSAKU_KENGEN_FLG_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");

	}

	/**
	 * �ސE�Ҍ��������t���O�`�F�b�N
	 * @param hikoukaiKensakuKengenFlg �ސE�Ҍ��������t���O
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
	 */
	private void checkHikoukai_kensaku_kengen_flg(final boolean allowNull, final String hikoukaiKensakuKengenFlg) throws FileNotFoundException, IOException, BatchFailedException {
		Log.method("", "IN", "");

		if (!CheckUtils.isNotNull(hikoukaiKensakuKengenFlg)) {
			if (allowNull) {
				Log.method("", "OUT", "");
				return;
			}
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.HIKOUKAI_KENSAKU_KENGEN_FLG_ERROR_CODE1);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.HIKOUKAI_KENSAKU_KENGEN_FLG_ERROR_CODE1));
			this.brl.addTorikomiLog(tkl);
			Log.method("", "OUT", "");
			return;
		}

		if (!"0".equals(hikoukaiKensakuKengenFlg) && !"1".equals(hikoukaiKensakuKengenFlg)) {
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(this.csvRecordCount);
			tkl.setMsgID(PersonalCsvRecordChecker.HIKOUKAI_KENSAKU_KENGEN_FLG_ERROR_CODE2);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.HIKOUKAI_KENSAKU_KENGEN_FLG_ERROR_CODE2));
			this.brl.addTorikomiLog(tkl);
		}
		Log.method("", "OUT", "");

	}

	/**
	 * �{���Ƒg�D���d���ɂȂ邩�ǂ����m�F����B
	 * @param csvVOList
	 * @return result
	 * @throws IOException IO��O�B
	 * @throws FileNotFoundException ���\�[�X�ُ�
	 */
	public HashMap checkInputData(final PersonalCsvVOList csvVOList) throws FileNotFoundException, IOException {
		final HashMap result = new HashMap();
		final HashMap errorData = new HashMap();
		final HashMap errorHonmuFlg = new HashMap();
		final HashMap errorSosikiCode = new HashMap();
		final HashMap personal = new HashMap();
		final HashMap simeiNoDup = new HashMap();
		final BatchResultVO resultVO = new BatchResultVO();
		final Iterator ite = csvVOList.iterator();

		String honmuFlg = null;
		String simeiNo = null;
		String sosikiCode = null;
		Integer csvCount = null;

		while (ite.hasNext()) {
			final PersonalCsvVO csvData = (PersonalCsvVO) ite.next();
			csvCount = new Integer(csvData.getCsvRecordCount());

			honmuFlg = csvData.getHonmu_flg();
			simeiNo = csvData.getSimei_no();
			sosikiCode = csvData.getSosiki_code();

			if (PersonalCsvRecordChecker.HONMU_FLG1.equals(honmuFlg)) {
				final Integer dupSimeiNo = (Integer) simeiNoDup.put(simeiNo, csvCount);
				if (dupSimeiNo != null) {

					errorData.put(dupSimeiNo, "err");
					errorData.put(csvCount, "err");
					errorHonmuFlg.put(dupSimeiNo, PersonalCsvRecordChecker.HONMU_FLG_ERROR_CODE4);
					errorHonmuFlg.put(csvCount, PersonalCsvRecordChecker.HONMU_FLG_ERROR_CODE4);
				}
			}

			if (!"".equals(sosikiCode)) {
				HashMap sosikiDup = (HashMap) personal.get(simeiNo);
				if (sosikiDup == null) {
					sosikiDup = new HashMap();
					sosikiDup.put(sosikiCode, csvCount);
					personal.put(simeiNo, sosikiDup);
				} else {
					final Integer dupSosikiCode = (Integer) sosikiDup.put(sosikiCode, csvCount);
					if (dupSosikiCode != null) {
						errorData.put(dupSosikiCode, "err");
						errorData.put(csvCount, "err");
						errorSosikiCode.put(dupSosikiCode, PersonalCsvRecordChecker.SOSIKI_CODE_ERROR_CODE3);
						errorSosikiCode.put(csvCount, PersonalCsvRecordChecker.SOSIKI_CODE_ERROR_CODE3);
					}
				}
			}
		}

		this.checkSosikiDuplicate(errorSosikiCode, resultVO);
		this.checkSimeiNoDuplicate(errorHonmuFlg, resultVO);

		result.put(ImportPersonalEJBBean.ERROR_LINE, errorData);
		result.put(ImportPersonalEJBBean.ERROR_MSG, resultVO);
		return result;
	}

	/**
	 * �����g�D���ɓ����Ј��������̋Ɩ��������ǂ����m�F����B
	 * @param dupSosikiCode
	 * @param resultVO
	 * @throws IOException IO��O�B
	 * @throws FileNotFoundException ���\�[�X�ُ�
	 */
	private void checkSosikiDuplicate(final HashMap errorSosikiCode, final BatchResultVO resultVO) throws FileNotFoundException, IOException {
		final Iterator iterator = errorSosikiCode.keySet().iterator();
		while (iterator.hasNext()) {
			final Integer dupSosikiCode = (Integer) iterator.next();
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(dupSosikiCode.intValue());
			tkl.setMsgID(PersonalCsvRecordChecker.SOSIKI_CODE_ERROR_CODE3);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.SOSIKI_CODE_ERROR_CODE3));
			resultVO.addTorikomiLog(tkl);
		}
	}

	/**
	 * �����Ј���2�̖{���������ǂ����m�F����B
	 * @param dupSimeiNo
	 * @param resultVO
	 * @throws IOException IO��O�B
	 * @throws FileNotFoundException ���\�[�X�ُ�
	 */
	private void checkSimeiNoDuplicate(final HashMap errorHonmuFlg, final BatchResultVO resultVO) throws FileNotFoundException, IOException {

		final Iterator iterator = errorHonmuFlg.keySet().iterator();
		while (iterator.hasNext()) {
			final Integer dupSimeiNo = (Integer) iterator.next();
			final TorikomiLog tkl = new TorikomiLog();
			tkl.setLineNo(dupSimeiNo.intValue());
			tkl.setMsgID(PersonalCsvRecordChecker.HONMU_FLG_ERROR_CODE4);
			tkl.setErrorMessage(MessageManager.getMessage(PersonalCsvRecordChecker.HONMU_FLG_ERROR_CODE4));
			resultVO.addTorikomiLog(tkl);
		}
	}

}