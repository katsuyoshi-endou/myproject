/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g��  : ���V�e�A�iCareer�j
 *
 *
 * ���l : �p�[�\�i���e�[�u���ւ̃A�N�Z�X�N���X�B
 *
 * ���� :
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/10/31  1.00    TUANTT     �V�K�쐬
 *
 */
package jp.co.hisas.addon.batch.import_personal.dao;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.naming.NamingException;
import javax.sql.DataSource;

import jp.co.hisas.addon.batch.import_personal.exception.WrongArgumentException;
import jp.co.hisas.addon.batch.import_personal.record.PersonalRecord;
import jp.co.hisas.addon.batch.import_personal.record.Record;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PersonalDAO�N���X �@�\�����F �p�[�\�i���e�[�u���ւ̃A�N�Z�X��S������r�[���N���X�B
 * 
 * </PRE>
 */
public class PersonalDAO extends BaseDAO {

	/** �N���X�h�c */
	private static final String CLASS_ID = "Personal";

	/**
	 * �f�[�^�\�[�X����ݒ肵�āA�I�u�W�F�N�g���\�z����R���X�g���N�^�B
	 * @param dataSourceName String �f�[�^�\�[�X�B
	 * @exception NamingException �l�[�~���O��O�B
	 */
	public PersonalDAO(final String dataSourceName) throws NamingException {
		super(dataSourceName);
	}

	/**
	 * �f�[�^�\�[�X��ݒ肵�āA�I�u�W�F�N�g���\�z����R���X�g���N�^�B
	 * @param ds DataSource �f�[�^�\�[�X�B
	 */
	public PersonalDAO(final DataSource ds) {
		super(ds);
	}

	/**
	 * �w��̃p�[�\�i������߂��B
	 * @param shimeiNo String �����ԍ��B
	 * @return PersonalRecord �����ԍ��̊Y������p�[�\�i�����B �Y������p�[�\�i����񂪂Ȃ��ꍇ�́Anull��߂��B
	 * @exception WrongArgumentException �����G���[�B
	 * @exception IOException IO��O�B
	 * @exception SQLException SQL��O�B
	 */
	public PersonalRecord lookup(final String shimeiNo) throws WrongArgumentException, IOException, SQLException {

		Log.method("", "IN", "");

		// �����`�F�b�N
		if (shimeiNo == null) {
			final WrongArgumentException e = new WrongArgumentException(this.getClass().getName() + "#lookup() shimeiNo is Null.");
			throw e;
		}

		final Vector vec = new Vector();
		vec.add(shimeiNo);
		final PersonalRecord rtnValue = (PersonalRecord) super.lookup(vec);
		Log.method("", "OUT", "");
		return rtnValue;
	}

	/**
	 * �w��̃p�[�\�i���v���t�@�C����񂪑��݂��邩�𔻒f����B ���݂���ꍇ�́Atrue, ���݂��Ȃ��ꍇ�́Afalse��߂��B
	 * @param shimeiNo String ����NO
	 * @return boolean �Y������p�[�\�i���v���t�@�C��������ꍇ�́Atrue, �Ȃ��ꍇ�́Afalse ��߂��B
	 * @exception WrongArgumentException �����G���[�B
	 * @exception IOException IO��O�B
	 * @exception SQLException SQL��O�B
	 */
	public boolean isExist(final String shimeiNo) throws WrongArgumentException, IOException, SQLException {

		Log.method("", "IN", "");
		// �����`�F�b�N
		if (shimeiNo == null) {
			final WrongArgumentException e = new WrongArgumentException(this.getClass().getName() + "#isExist() shimeiNo is Null.");
			throw e;
		}

		// ���݂��Ȃ��ꍇ�́Afalse
		if (this.lookup(shimeiNo) == null) {
			Log.method("", "OUT", "");
			return false;
		}
		Log.method("", "OUT", "");
		return true;
	}

	/**
	 * �w��̃p�[�\�i���v���t�@�C������V�K�쐬����B
	 * @param personalRecord �p�[�\�i���v���t�@�C�����
	 * @exception WrongArgumentException �����G���[�B
	 * @exception IOException IO��O�B
	 * @exception SQLException SQL��O�B
	 */
	public void create(final PersonalRecord personalRecord) throws WrongArgumentException, IOException, SQLException {
		Log.method("", "IN", "");
		// NotNull�����̃`�F�b�N
		if (!personalRecord.isRequiredNotNull()) {

			final WrongArgumentException e = new WrongArgumentException(this.getClass().getName() + "#create() PersonalRecord data is Null.");
			throw e;
		}

		final Vector data = personalRecord.createAddVector();
		super.create(data);
		if ("1".equals(personalRecord.getHonmu_flg())) {
			final Vector data2 = personalRecord.createNinsyouDataVector();
			super.updateNinsyou(data2);
		}
		Log.method("", "OUT", "");
	}

	/**
	 * �w��̃p�[�\�i���v���t�@�C������V�K�쐬����B
	 * @param personalRecord �p�[�\�i���v���t�@�C�����
	 * @exception WrongArgumentException �����G���[�B
	 * @exception IOException IO��O�B
	 * @exception SQLException SQL��O�B
	 */
	public void create2(final PersonalRecord personalRecord) throws WrongArgumentException, IOException, SQLException {
		Log.method("", "IN", "");
		// NotNull�����̃`�F�b�N
		if (!personalRecord.isRequiredNotNull()) {

			final WrongArgumentException e = new WrongArgumentException(this.getClass().getName() + "#create() PersonalRecord data is Null.");
			throw e;
		}

		final Vector data = personalRecord.createAddVector();
		super.create(data);
		Log.method("", "OUT", "");
	}

	/**
	 * �w��̃p�[�\�i���v���t�@�C�������X�V����B
	 * @param personalRecord �X�V����p�[�\�i���v���t�@�C�����
	 * @exception WrongArgumentException �����G���[�B
	 * @exception IOException IO��O�B
	 * @exception SQLException SQL��O�B
	 */
	public void update(final PersonalRecord personalRecord) throws WrongArgumentException, IOException, SQLException {
		Log.method("", "IN", "");
		// NotNull�����̃`�F�b�N
		if (!personalRecord.isRequiredNotNull()) {

			final WrongArgumentException e = new WrongArgumentException(this.getClass().getName() + "#update() PersonalRecord data is Null.");
			throw e;
		}

		final Vector data = personalRecord.createUpdateVector();
		super.update(data);

		Log.method("", "OUT", "");
	}

	/**
	 * �w��̃p�[�\�i���v���t�@�C�������폜����B
	 * @param simeiNo String ����NO
	 * @param honmuFlg String �{���^�����t���O
	 * @exception WrongArgumentException �����G���[�B
	 * @exception IOException IO��O�B
	 * @exception SQLException SQL��O�B
	 */
	public void remove(final String simeiNo, final String honmuFlg) throws IOException, SQLException, WrongArgumentException {
		Log.method("", "IN", "");

		// sql lookup�̃L�[
		final String key = "removewithhonmuflg";
		if (simeiNo == null || honmuFlg == null) {
			final WrongArgumentException e = new WrongArgumentException(this.getClass().getName() + "#remove() simeiNo or honmuFlg is Null");
			throw e;
		}

		final Vector vec = new Vector();
		vec.add(simeiNo);
		vec.add(honmuFlg);

		this.removeAny(key, vec);

		Log.method("", "OUT", "");

	}

	/**
	 * �P�����̃f�[�^�����R�[�h�I�u�W�F�N�g�ɕϊ�����B
	 * @param rs ResultSet ���ʃZ�b�g�B
	 * @return Record ���R�[�h�B���Ԃ́A�p�[�\�i�����R�[�h�B
	 * @exception SQLException SQL��O�B SQL��O�B
	 */
	protected Record editResultSet(final ResultSet rs) throws SQLException {
		Log.method("", "IN", "");
		final PersonalRecord pr = new PersonalRecord();

		pr.setSimei_no(rs.getString("simei_no"));
		pr.setPassword(rs.getString("password"));
		pr.setHonmu_flg(rs.getString("honmu_flg"));
		pr.setSimei_no_flg(rs.getString("simei_no_flg"));
		pr.setKanji_simei(rs.getString("kanji_simei"));
		pr.setKana_simei(rs.getString("kana_simei"));
		if (rs.getString("eiji_simei") != null) {
			pr.setEiji_simei(rs.getString("eiji_simei"));
		}
		pr.setSeibetu(rs.getString("seibetu"));
		pr.setSeinengappi(rs.getString("seinengappi"));
		if (rs.getString("group_nyusya_nengetu") != null) {
			pr.setGroup_nyusya_nengetu(rs.getString("group_nyusya_nengetu"));
		}
		pr.setNyusya_nengetu(rs.getString("nyusya_nengetu"));
		if (rs.getString("sosiki_code") != null) {
			pr.setSosiki_code(rs.getString("sosiki_code"));
		}
		pr.setYakusyoku_code(rs.getString("yakusyoku_code"));
		if (rs.getString("syokui_code") != null) {
			pr.setSyokui_code(rs.getString("syokui_code"));
		}
		if (rs.getString("naisen") != null) {
			pr.setNaisen(rs.getString("naisen"));
		}
		if (rs.getString("gaisen") != null) {
			pr.setGaisen(rs.getString("gaisen"));
		}
		if (rs.getString("fax_no") != null) {
			pr.setFax_no(rs.getString("fax_no"));
		}
		if (rs.getString("mail") != null) {
			pr.setMail(rs.getString("mail"));
		}
		if (rs.getString("jiko_pr") != null) {
			pr.setJiko_pr(rs.getString("jiko_pr"));
		}
		pr.setGensyoku_taisyoku_flg(rs.getString("gensyoku_taisyoku_flg"));
		if (rs.getString("taisyoku_nengappi") != null) {
			pr.setTaisyoku_nengappi(rs.getString("taisyoku_nengappi"));
		}
		pr.setKengen_code(rs.getString("kengen_code"));
		if (rs.getString("syozoku_code_1") != null) {
			pr.setSyozoku_code_1(rs.getString("syozoku_code_1"));
		}
		if (rs.getString("syozoku_code_2") != null) {
			pr.setSyozoku_code_2(rs.getString("syozoku_code_2"));
		}
		if (rs.getString("syozoku_code_3") != null) {
			pr.setSyozoku_code_3(rs.getString("syozoku_code_3"));
		}
		if (rs.getString("syozoku_code_4") != null) {
			pr.setSyozoku_code_4(rs.getString("syozoku_code_4"));
		}
		if (rs.getString("syozoku_code_5") != null) {
			pr.setSyozoku_code_5(rs.getString("syozoku_code_5"));
		}
		if (rs.getString("syozoku_code_6") != null) {
			pr.setSyozoku_code_6(rs.getString("syozoku_code_6"));
		}
		if (rs.getString("syozoku_code_7") != null) {
			pr.setSyozoku_code_7(rs.getString("syozoku_code_7"));
		}
		if (rs.getString("syozoku_code_8") != null) {
			pr.setSyozoku_code_8(rs.getString("syozoku_code_8"));
		}
		if (rs.getString("syozoku_code_9") != null) {
			pr.setSyozoku_code_9(rs.getString("syozoku_code_9"));
		}
		if (rs.getString("syoku_code1") != null) {
			pr.setSyoku_code1(rs.getString("syoku_code1"));
		}
		if (rs.getString("senmon_code1") != null) {
			pr.setSenmon_code1(rs.getString("senmon_code1"));
		}
		if (rs.getString("level_code1") != null) {
			pr.setLevel_code1(rs.getString("level_code1"));
		}
		if (rs.getString("sougou_t_do1") != null) {
			pr.setSougou_t_do1(rs.getString("sougou_t_do1"));
		}
		if (rs.getString("syoku_code2") != null) {
			pr.setSyoku_code2(rs.getString("syoku_code2"));
		}
		if (rs.getString("senmon_code2") != null) {
			pr.setSenmon_code2(rs.getString("senmon_code2"));
		}
		if (rs.getString("level_code2") != null) {
			pr.setLevel_code2(rs.getString("level_code2"));
		}
		if (rs.getString("sougou_t_do2") != null) {
			pr.setSougou_t_do2(rs.getString("sougou_t_do2"));
		}
		if (rs.getString("syoku_code3") != null) {
			pr.setSyoku_code3(rs.getString("syoku_code3"));
		}
		if (rs.getString("senmon_code3") != null) {
			pr.setSenmon_code3(rs.getString("senmon_code3"));
		}
		if (rs.getString("level_code3") != null) {
			pr.setLevel_code3(rs.getString("level_code3"));
		}
		if (rs.getString("sougou_t_do3") != null) {
			pr.setSougou_t_do3(rs.getString("sougou_t_do3"));
		}
		pr.setAssessment_kokai_flg(rs.getString("assessment_kokai_flg"));
		pr.setKao_kokai_flg(rs.getString("kao_kokai_flg"));
		pr.setSkill_kokai_flg(rs.getString("skill_kokai_flg"));
		pr.setSyokumu_kokai_flg(rs.getString("syokumu_kokai_flg"));
		pr.setKyoiku_kokai_flg(rs.getString("kyoiku_kokai_flg"));
		pr.setSikaku_kokai_flg(rs.getString("sikaku_kokai_flg"));
		pr.setHyosyo_kokai_flg(rs.getString("hyosyo_kokai_flg"));
		pr.setRonbun_kokai_flg(rs.getString("ronbun_kokai_flg"));
		pr.setSyagai_kokai_flg(rs.getString("syagai_kokai_flg"));
		pr.setGakureki_kokai_flg(rs.getString("gakureki_kokai_flg"));
		pr.setSyanaireki_kokai_flg(rs.getString("syanaireki_kokai_flg"));
		pr.setZensyokureki_kokai_flg(rs.getString("zensyokureki_kokai_flg"));
		pr.setSosiki_kokai_flg(rs.getString("sosiki_kokai_flg"));
		pr.setYakusyoku_kokai_flg(rs.getString("yakusyoku_kokai_flg"));
		pr.setSyokui_kokai_flg(rs.getString("syokui_kokai_flg"));
		pr.setSkill_mainte_flg(rs.getString("skill_mainte_flg"));
		pr.setKanren_gyomu_touroku_flg(rs.getString("kanren_gyomu_touroku_flg"));
		pr.setPersonal_mainte_flg(rs.getString("personal_mainte_flg"));
		pr.setSosiki_mainte_flg(rs.getString("sosiki_mainte_flg"));
		pr.setKyoiku_mainte_flg(rs.getString("kyoiku_mainte_flg"));
		pr.setRonbun_mainte_flg(rs.getString("ronbun_mainte_flg"));
		pr.setSikaku_mainte_flg(rs.getString("sikaku_mainte_flg"));
		pr.setHyosyo_mainte_flg(rs.getString("hyosyo_mainte_flg"));
		pr.setSyagai_ronbun_mainte_flg(rs.getString("syagai_ronbun_mainte_flg"));
		pr.setKenpo_mainte_flg(rs.getString("kenpo_mainte_flg"));
		pr.setSyagai_mainte_flg(rs.getString("syagai_mainte_flg"));
		pr.setLogin_osirase_mainte_flg(rs.getString("login_osirase_mainte_flg"));
		pr.setTokei_bunseki_kengen(rs.getString("tokei_bunseki_kengen"));
		pr.setTaisyokusya_kensaku_kengen_flg(rs.getString("taisyokusya_kensaku_kengen_flg"));
		pr.setHikoukai_kensaku_kengen_flg(rs.getString("hikoukai_kensaku_kengen_flg"));
		if (rs.getString("gamen_kokai_flg_yobi1") != null) {
			pr.setGamen_kokai_flg_yobi1(rs.getString("gamen_kokai_flg_yobi1"));
		}
		if (rs.getString("gamen_kokai_flg_yobi2") != null) {
			pr.setGamen_kokai_flg_yobi2(rs.getString("gamen_kokai_flg_yobi2"));
		}
		if (rs.getString("gamen_kokai_flg_yobi3") != null) {
			pr.setGamen_kokai_flg_yobi3(rs.getString("gamen_kokai_flg_yobi3"));
		}
		if (rs.getString("gamen_kokai_flg_yobi4") != null) {
			pr.setGamen_kokai_flg_yobi4(rs.getString("gamen_kokai_flg_yobi4"));
		}
		if (rs.getString("gamen_kokai_flg_yobi5") != null) {
			pr.setGamen_kokai_flg_yobi5(rs.getString("gamen_kokai_flg_yobi5"));
		}
		if (rs.getString("gamen_kokai_flg_yobi6") != null) {
			pr.setGamen_kokai_flg_yobi6(rs.getString("gamen_kokai_flg_yobi6"));
		}
		if (rs.getString("gamen_kokai_flg_yobi7") != null) {
			pr.setGamen_kokai_flg_yobi7(rs.getString("gamen_kokai_flg_yobi7"));
		}
		if (rs.getString("gamen_kokai_flg_yobi8") != null) {
			pr.setGamen_kokai_flg_yobi8(rs.getString("gamen_kokai_flg_yobi8"));
		}
		if (rs.getString("gamen_kokai_flg_yobi9") != null) {
			pr.setGamen_kokai_flg_yobi9(rs.getString("gamen_kokai_flg_yobi9"));
		}
		if (rs.getString("gamen_kokai_flg_yobi10") != null) {
			pr.setGamen_kokai_flg_yobi10(rs.getString("gamen_kokai_flg_yobi10"));
		}
		if (rs.getString("gamen_kokai_flg_yobi11") != null) {
			pr.setGamen_kokai_flg_yobi11(rs.getString("gamen_kokai_flg_yobi11"));
		}
		if (rs.getString("gamen_kokai_flg_yobi12") != null) {
			pr.setGamen_kokai_flg_yobi12(rs.getString("gamen_kokai_flg_yobi12"));
		}
		if (rs.getString("mainte_flg_yobi1") != null) {
			pr.setMainte_flg_yobi1(rs.getString("mainte_flg_yobi1"));
		}
		if (rs.getString("yobi1") != null) {
			pr.setYobi1(rs.getString("yobi1"));
		}
		if (rs.getString("yobi2") != null) {
			pr.setYobi2(rs.getString("yobi2"));
		}
		if (rs.getString("yobi3") != null) {
			pr.setYobi3(rs.getString("yobi3"));
		}
		if (rs.getString("yobi4") != null) {
			pr.setYobi4(rs.getString("yobi4"));
		}
		if (rs.getString("yobi5") != null) {
			pr.setYobi5(rs.getString("yobi5"));
		}
		if (rs.getString("yobi6") != null) {
			pr.setYobi6(rs.getString("yobi6"));
		}
		if (rs.getString("yobi7") != null) {
			pr.setYobi7(rs.getString("yobi7"));
		}
		if (rs.getString("yobi8") != null) {
			pr.setYobi8(rs.getString("yobi8"));
		}
		if (rs.getString("yobi9") != null) {
			pr.setYobi9(rs.getString("yobi9"));
		}
		if (rs.getString("yobi10") != null) {
			pr.setYobi10(rs.getString("yobi10"));
		}
		if (rs.getString("yakusyoku") != null) {
			pr.setYakusyoku(rs.getString("yakusyoku"));
		}
		if (rs.getString("yobi_ryoiki") != null) {
			pr.setYobi_ryoiki(rs.getString("yobi_ryoiki"));
		}
		if (rs.getString("kaigai_kokai_flg") != null) {
			pr.setKaigai_kokai_flg(rs.getString("kaigai_kokai_flg"));
		}
		if (rs.getString("kaigai_mainte_flg") != null) {
			pr.setKaigai_mainte_flg(rs.getString("kaigai_mainte_flg"));
		}
		if (rs.getString("jinmei_ryakusyo") != null) {
			pr.setJinmei_ryakusyo(rs.getString("jinmei_ryakusyo"));
		}
		if (rs.getString("busyo_ryakusyo_mei") != null) {
			pr.setBusyo_ryakusyo_mei(rs.getString("busyo_ryakusyo_mei"));
		}
		if (rs.getString("gakureki_gakko_mei") != null) {
			pr.setGakureki_gakko_mei(rs.getString("gakureki_gakko_mei"));
		}
		if (rs.getString("gakureki_gakubu_mei") != null) {
			pr.setGakureki_gakubu_mei(rs.getString("gakureki_gakubu_mei"));
		}
		if (rs.getString("gakureki_gakka_mei") != null) {
			pr.setGakureki_gakka_mei(rs.getString("gakureki_gakka_mei"));
		}
		if (rs.getString("gakureki_sotugyo_nengetu") != null) {
			pr.setGakureki_sotugyo_nengetu(rs.getString("gakureki_sotugyo_nengetu"));
		}
		if (rs.getString("syanaibin") != null) {
			pr.setSyanaibin(rs.getString("syanaibin"));
		}

		Log.method("", "OUT", "");
		return pr;
	}

	/**
	 * �N���X�h�c���擾����B
	 * @return String �N���X�h�c�B
	 */
	protected String getClassId() {
		return PersonalDAO.CLASS_ID;
	}

	/**
	 * �w��̃p�[�\�i������߂��B
	 * @param simeiNo ����NO�B
	 * @param honmuFlg �{���^�����t���O�B
	 * @return �Y������p�[�\�i���v���t�@�C�����B �Y������p�[�\�i���v���t�@�C�����Ȃ��ꍇ�́Anull��߂��B
	 * @exception SQLException SQL��O�B
	 * @exception IOException IO��O�B
	 */
	public PersonalRecord lookupWithHonmuFlg(final String simeiNo, final String honmuFlg) throws IOException, SQLException {
		Log.method("", "IN", "");

		final String key = "lookupwithhonmuflg";
		final Vector vec = new Vector();
		vec.add(simeiNo);
		vec.add(honmuFlg);

		final Vector rtnValues = super.lookupAny(key, vec);
		Log.method("", "OUT", "");

		if (rtnValues.size() < 1) {
			return null;
		}

		return (PersonalRecord) rtnValues.get(0);
	}
}