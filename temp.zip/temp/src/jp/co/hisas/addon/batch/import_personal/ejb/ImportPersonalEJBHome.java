/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.import_personal.ejb;

/**
 * Home interface for ImportPersonalEJB.
 * @xdoclet-generated at 2005/11/07
 */
public interface ImportPersonalEJBHome extends javax.ejb.EJBHome {
	public static final String COMP_NAME = "java:comp/env/ejb/ImportPersonalEJB";

	public static final String JNDI_NAME = "ImportPersonalEJB";

	public jp.co.hisas.addon.batch.import_personal.ejb.ImportPersonalEJB create() throws javax.ejb.CreateException, java.rmi.RemoteException;

}
