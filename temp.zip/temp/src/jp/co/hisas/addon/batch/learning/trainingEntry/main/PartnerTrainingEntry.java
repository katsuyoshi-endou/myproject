package jp.co.hisas.addon.batch.learning.trainingEntry.main;

public class PartnerTrainingEntry {
	
	public static void main( String[] args ) {
		
	}
	
}
