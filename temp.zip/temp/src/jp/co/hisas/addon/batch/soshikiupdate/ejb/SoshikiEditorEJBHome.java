/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.soshikiupdate.ejb;

/**
 * Home interface for SoshikiEditorEJB.
 * @xdoclet-generated at 2005/11/07
 */
public interface SoshikiEditorEJBHome extends javax.ejb.EJBHome {
	public static final String COMP_NAME = "java:comp/env/ejb/SoshikiEditorEJB";

	public static final String JNDI_NAME = "SoshikiEditorEJB";

	public jp.co.hisas.addon.batch.soshikiupdate.ejb.SoshikiEditorEJB create() throws javax.ejb.CreateException, java.rmi.RemoteException;

}
