/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�g�D�o�b�`�@�\�j
 *
 * ���l�@�F
 *   EJB��T01_PERSONAL_TBL�Ƀp�[�\�i���v���t�@�C�����C���|�[�g����B
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/10/30  01.00    TUANTT    �V�K�쐬
 */
package jp.co.hisas.addon.batch.import_personal.ejb;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.addon.batch.import_personal.checker.PersonalCsvRecordChecker;
import jp.co.hisas.addon.batch.import_personal.dao.PersonalDAO;
import jp.co.hisas.addon.batch.import_personal.dao.SoshikiDAO;
import jp.co.hisas.addon.batch.import_personal.dao.YakusyokuDao;
import jp.co.hisas.addon.batch.import_personal.exception.BatchFailedException;
import jp.co.hisas.addon.batch.import_personal.exception.WrongArgumentException;
import jp.co.hisas.addon.batch.import_personal.record.PersonalRecord;
import jp.co.hisas.addon.batch.import_personal.record.SoshikiRecord;
import jp.co.hisas.addon.batch.import_personal.record.YakusyokuRecord;
import jp.co.hisas.addon.batch.import_personal.vo.BatchResultVO;
import jp.co.hisas.addon.batch.import_personal.vo.PersonalCsvVO;
import jp.co.hisas.addon.batch.import_personal.vo.PersonalCsvVOList;
import jp.co.hisas.addon.batch.import_personal.vo.TorikomiLog;
import jp.co.hisas.career.learning.base.PCY_ServiceLocator;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F ImportPersonalEJBBean�N���X �@�\�����F EJB��T01_PERSONAL_TBL�Ƀp�[�\�i���v���t�@�C�����C���|�[�g����B
 * @ejb.bean name="ImportPersonalEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 * 
 * </PRE>
 */
public class ImportPersonalEJBBean implements SessionBean {

	public static final String ERROR_LINE = "errLine";

	public static final String ERROR_MSG = "errMsg";

	/** �ŏ�ʑg�D�̑g�D�R�[�h */
	private static final String rootSosikiCode = "0";

	/** 1�̑g�D�ɂ������ő�̏�ʑg�D�� */
	private static final int MAX_UPPERORG_COUNT = 9;

	/** 1�̃t���O�̌����i�����j */
	private static final int FLAG_LENGTH = 1;

	/** �{�� */
	private static final String HONMU_FLAG1 = "1";

	/** ���� */
	private static final String HONMU_FLAG2 = "2";

	/** �󔒕����� */
	private static final String BLANK_STRING = "";

	/** T01_PERSONAL_TBL����폜���ꂽ�Ј���honmu_flg=2�̃��R�[�h�������t���O */
	private static final String DELETED_FLG = "1";

	private SessionContext context = null;

	/**
	 * CSV�t�@�C������擾����p�[�\�i���v���t�@�C���̃f�[�^��T01_PERSONAL_TBL�ɃC���|�[�g����B
	 * @throws NamingException �l�[�~���O��O�B
	 * @throws WrongArgumentException �����G���[�B
	 * @throws SQLException SQL��O�B
	 * @throws IOException IO��O�B
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public BatchResultVO execute(final PersonalCsvVOList csvVOList) throws NamingException, WrongArgumentException, SQLException, IOException {

		ReadFile.refreshFile();

		final PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();

		final Iterator ite = csvVOList.iterator();

		final ArrayList errorList = new ArrayList();

		final Map deleteRecord = new HashMap();

		final PersonalCsvRecordChecker checker = new PersonalCsvRecordChecker();

		final HashMap result = checker.checkInputData(csvVOList);
		final HashMap personalInfo = (HashMap) result.get(ImportPersonalEJBBean.ERROR_LINE);

		final BatchResultVO resultVO = (BatchResultVO) result.get(ImportPersonalEJBBean.ERROR_MSG);
		final Iterator iterator = resultVO.getTorikomiLogs();

		while (iterator.hasNext()) {
			errorList.add(iterator.next());
		}

		// �f�[�^������
		try {
			final PersonalDAO personalDAO = new PersonalDAO(locator.getDataSource());
			while (ite.hasNext()) {

				final PersonalCsvVO csvData = (PersonalCsvVO) ite.next();

				try {
					this.editRecord(csvData, personalDAO, deleteRecord, personalInfo);
				} catch (final BatchFailedException e) {

					final BatchResultVO rltVo = e.getResult();
					final Iterator rltite = rltVo.getTorikomiLogs();

					while (rltite.hasNext()) {
						errorList.add(rltite.next());
					}
				}
			}
			if (errorList.size() != 0) {
				final BatchResultVO brVo = new BatchResultVO();
				for (int i = 0; i < errorList.size(); i++) {
					brVo.addTorikomiLog((TorikomiLog) errorList.get(i));
				}
				final BatchFailedException e = new BatchFailedException(brVo);
				throw e;
			}
		} catch (final FileNotFoundException e) {
			Log.error("", "", e);
			this.context.setRollbackOnly();
			throw e;
		} catch (final NamingException e) {
			Log.error("", "", e);
			this.context.setRollbackOnly();
			throw e;
		} catch (final WrongArgumentException e) {
			Log.error("", "", e);
			this.context.setRollbackOnly();
			throw e;
		} catch (final SQLException e) {
			Log.error("", "", e);
			this.context.setRollbackOnly();
			throw e;
		} catch (final IOException e) {
			Log.error("", "", e);
			this.context.setRollbackOnly();
			throw e;
		} catch (final BatchFailedException e) {
			return e.getResult();
		}
		return new BatchResultVO();
	}

	/**
	 * CSV�t�@�C����1�s�̃f�[�^����p�[�\�i���v���t�@�C�����R�[�h��1���쐬����B
	 * @param personalCsvVO ���̓f�[�^�B
	 * @param personalInfo
	 * @return HashMap �m�F�����f�[�^�y�уG���[�i�G���[������ꍇ�j���܂ށB
	 * @throws FileNotFoundException
	 * @exception NamingException �l�[�~���O��O�B
	 * @exception WrongArgumentException �����G���[�B
	 * @exception SQLException SQL��O�B
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �o�b�`���s��O�B
	 */
	private HashMap createRecord(final PersonalCsvVO personalCsvVO, final HashMap personalInfo) throws FileNotFoundException, NamingException, WrongArgumentException, SQLException, IOException,
			BatchFailedException {
		final PersonalCsvRecordChecker checker = new PersonalCsvRecordChecker();
		final HashMap result = checker.check(personalCsvVO, personalInfo);
		return result;

	}

	/**
	 * �f�[�^�x�[�X�Ƀ��R�[�h��ǉ�����B
	 * @param personalRecord PersonalRecord
	 * @param personalDAO PersonalDAO
	 * @exception NamingException �l�[�~���O��O�B
	 * @exception SQLException SQL��O�B
	 * @exception IOException IO��O�B
	 * @exception WrongArgumentException �����G���[�B
	 */
	private void addRecord(final PersonalRecord personalRecord, final PersonalDAO personalDAO) throws NamingException, WrongArgumentException, IOException, SQLException {

		final PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
		final SoshikiDAO soshikiDAO = new SoshikiDAO(locator.getDataSource());
		this.autoSettingValue(personalRecord);
		this.setDefaultValue(personalRecord);
		this.updateSyozokuCode(personalRecord, soshikiDAO);
		this.setPublicFlag(personalRecord);
		personalDAO.create(personalRecord);
	}

	/**
	 * �f�[�^�x�[�X�Ƀ��R�[�h��ǉ�����B
	 * @param personalRecord PersonalRecord
	 * @param personalDAO PersonalDAO
	 * @exception NamingException �l�[�~���O��O�B
	 * @exception SQLException SQL��O�B
	 * @exception IOException IO��O�B
	 * @exception WrongArgumentException �����G���[�B
	 */
	private void addRecord2(final PersonalRecord personalRecord, final PersonalDAO personalDAO) throws NamingException, WrongArgumentException, IOException, SQLException {

		final PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
		final SoshikiDAO soshikiDAO = new SoshikiDAO(locator.getDataSource());
		this.autoSettingValue(personalRecord);
		this.setDefaultValue(personalRecord);
		this.updateSyozokuCode(personalRecord, soshikiDAO);
		this.setPublicFlag(personalRecord);
		personalDAO.create2(personalRecord);
	}

	/**
	 * �f�[�^�x�[�X���烌�R�[�h���폜����B
	 * @param personalRecord PersonalRecord
	 * @param personalDAO PersonalDAO
	 * @exception WrongArgumentException �����G���[�B
	 * @exception SQLException SQL��O�B
	 * @exception IOException IO��O�B
	 */
	private void deleteRecord(final PersonalRecord personalRecord, final PersonalDAO personalDAO) throws IOException, SQLException, WrongArgumentException {
		final String simeiNo = personalRecord.getSimei_no();
		final String honmuFlg = ImportPersonalEJBBean.HONMU_FLAG2;
		personalDAO.remove(simeiNo, honmuFlg);
	}

	/**
	 * �f�[�^�x�[�X�Ƀ��R�[�h��ǉ��E�X�V����B
	 * @param personalRecord PersonalRecord
	 * @param personalDAO PersonalDAO
	 * @exception NamingException �l�[�~���O��O�B
	 * @exception SQLException SQL��O�B
	 * @exception IOException IO��O�B
	 * @exception WrongArgumentException �����G���[�B
	 */
	private void updateRecord(final PersonalRecord personalRecord, final PersonalDAO personalDAO) throws NamingException, WrongArgumentException, IOException, SQLException {
		final PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
		final SoshikiDAO soshikiDAO = new SoshikiDAO(locator.getDataSource());
		final String honmuFlg = personalRecord.getHonmu_flg();
		final String simeiNo = personalRecord.getSimei_no();
		if (ImportPersonalEJBBean.HONMU_FLAG2.equals(honmuFlg)) {
			this.addRecord(personalRecord, personalDAO);
			return;
		}
		if (ImportPersonalEJBBean.HONMU_FLAG1.equals(honmuFlg)) {

			final PersonalRecord existRecord = personalDAO.lookupWithHonmuFlg(simeiNo, honmuFlg);

			if (existRecord == null) {
				this.addRecord2(personalRecord, personalDAO);
				return;
			}
			this.autoSettingValue(personalRecord);
			this.setDefaultValue(existRecord);
			this.setUpdateValue(personalRecord, existRecord);
			this.updateSyozokuCode(existRecord, soshikiDAO);
			personalDAO.update(existRecord);
		}
	}

	/**
	 * �f�[�^�x�[�X�Ƀ��R�[�h��ǉ��E�X�V����B
	 * @param personalCsvVO
	 * @param personalDAO
	 * @param deleteRecord
	 * @param personalInfo
	 * @exception FileNotFoundException ���\�[�X�ُ�
	 * @exception NamingException �l�[�~���O��O�B
	 * @exception WrongArgumentException �����G���[�B
	 * @exception SQLException SQL��O�B
	 * @exception IOException IO��O�B
	 * @exception BatchFailedException �o�b�`���s��O�B
	 */
	private void editRecord(final PersonalCsvVO personalCsvVO, final PersonalDAO personalDAO, final Map deleteRecord, final HashMap personalInfo) throws FileNotFoundException, NamingException,
			WrongArgumentException, SQLException, IOException, BatchFailedException {

		final HashMap result = this.createRecord(personalCsvVO, personalInfo);

		final BatchResultVO resultVO = (BatchResultVO) result.get("error");

		if (resultVO.getTorikomiLogSize() > 0) {
			throw new BatchFailedException(resultVO);
		}

		final PersonalRecord personalRecord = (PersonalRecord) result.get("record");
		if (personalRecord == null) {
			return;
		}

		final Integer action = (Integer) result.get("action");

		final String flag = (String) deleteRecord.get(personalRecord.getSimei_no());

		if (!ImportPersonalEJBBean.DELETED_FLG.equals(flag)) {
			this.deleteRecord(personalRecord, personalDAO);
			deleteRecord.put(personalRecord.getSimei_no(), ImportPersonalEJBBean.DELETED_FLG);
		}

		if (action.equals(new Integer(PersonalCsvVO.ADD_PERSONAL))) {
			this.addRecord(personalRecord, personalDAO);
		} else if (action.equals(new Integer(PersonalCsvVO.UPDATE_PERSONAL))) {
			this.updateRecord(personalRecord, personalDAO);
		}

	}

	/**
	 * �f�t�H���g�l��ݒ肷��B
	 * @param personalRecord PersonalRecord
	 * @throws NamingException �l�[�~���O��O�B
	 * @throws WrongArgumentException �����G���[�B
	 * @throws IOException IO��O�B
	 * @throws SQLException
	 */
	private void setDefaultValue(final PersonalRecord personalRecord) throws NamingException, WrongArgumentException, IOException, SQLException {

		personalRecord.setSosiki_mainte_flg("0");
		personalRecord.setKyoiku_mainte_flg("0");
		personalRecord.setRonbun_mainte_flg("0");
		personalRecord.setHyosyo_mainte_flg("0");
		personalRecord.setSyagai_ronbun_mainte_flg("0");
		personalRecord.setSyagai_mainte_flg("0");

		personalRecord.setGamen_kokai_flg_yobi1(null);
		personalRecord.setGamen_kokai_flg_yobi2(null);
		personalRecord.setGamen_kokai_flg_yobi3(null);
		personalRecord.setGamen_kokai_flg_yobi4(null);
		personalRecord.setGamen_kokai_flg_yobi5(null);
		personalRecord.setGamen_kokai_flg_yobi6(null);
		personalRecord.setGamen_kokai_flg_yobi7(null);
		personalRecord.setGamen_kokai_flg_yobi8(null);
		personalRecord.setGamen_kokai_flg_yobi9(null);
		personalRecord.setGamen_kokai_flg_yobi10(null);
		personalRecord.setGamen_kokai_flg_yobi11(null);
		personalRecord.setGamen_kokai_flg_yobi12(null);
		personalRecord.setMainte_flg_yobi1(null);
		personalRecord.setYobi6(null);
		personalRecord.setYobi7(null);
		personalRecord.setYobi8(null);
		personalRecord.setYobi9(null);
		personalRecord.setYobi10(null);
		personalRecord.setYobi_ryoiki(null);
		personalRecord.setKaigai_mainte_flg(null);
		personalRecord.setJinmei_ryakusyo(null);
		personalRecord.setGakureki_gakko_mei(null);
		personalRecord.setGakureki_gakubu_mei(null);
		personalRecord.setGakureki_gakka_mei(null);
		personalRecord.setGakureki_sotugyo_nengetu(null);

	}

	/**
	 * @param personalRecord
	 * @throws NamingException �l�[�~���O��O�B
	 * @throws WrongArgumentException �����G���[�B
	 * @throws IOException IO��O�B
	 * @throws SQLException SQL��O�B
	 */
	private void autoSettingValue(final PersonalRecord personalRecord) throws NamingException, WrongArgumentException, IOException, SQLException {

		final String yakusyoku = this.getYakusyoku(personalRecord.getYakusyoku_code());
		personalRecord.setYakusyoku(yakusyoku);

		if (personalRecord.getSosiki_code() != null && personalRecord.getSosiki_code().length() > 0) {
			final String busyo_ryakusyo_mei = this.getBusyo_ryakusyo_mei(personalRecord.getSosiki_code());
			personalRecord.setBusyo_ryakusyo_mei(busyo_ryakusyo_mei);
		} else {
			personalRecord.setBusyo_ryakusyo_mei(ImportPersonalEJBBean.BLANK_STRING);
		}

	}

	/**
	 * @param yakusyokuCode
	 * @return
	 * @throws NamingException �l�[�~���O��O�B
	 * @throws WrongArgumentException �����G���[�B
	 * @throws IOException IO��O�B
	 * @throws SQLException SQL��O�B
	 */
	private String getYakusyoku(final String yakusyokuCode) throws NamingException, WrongArgumentException, IOException, SQLException {
		final PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
		final YakusyokuDao yakusyokuDao = new YakusyokuDao(locator.getDataSource());
		final YakusyokuRecord record = yakusyokuDao.lookup(yakusyokuCode);
		if (record == null) {
			return new String("null");
		}
		return record.getYakusyoku();
	}

	/**
	 * @param sosikiCode
	 * @return
	 * @throws NamingException
	 * @throws WrongArgumentException �����G���[�B
	 * @throws IOException IO��O�B
	 * @throws SQLException SQL��O�B
	 */
	private String getBusyo_ryakusyo_mei(final String sosikiCode) throws NamingException, WrongArgumentException, IOException, SQLException {
		final PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
		final SoshikiDAO soshikiDAO = new SoshikiDAO(locator.getDataSource());
		final SoshikiRecord soshikiRecord = soshikiDAO.lookup(sosikiCode);
		if (soshikiRecord == null) {
			return new String("null");
		}
		return soshikiRecord.getBusyo_ryakusyo_mei();
	}

	/**
	 * �V�K�ǉ�����ꍇ�Ɍ��J�E����J�t���O�̃f�t�H���g�l��ݒ肷��B
	 * @param personalRecord PersonalRecord
	 */
	private void setPublicFlag(final PersonalRecord personalRecord) throws NamingException, WrongArgumentException, IOException, SQLException {

		String publicFlag = null;

		publicFlag = this.getDefaultFlag("HOGO2");
		personalRecord.setSimei_no_flg(publicFlag.concat(personalRecord.getSimei_no()));

		publicFlag = this.getDefaultFlag("HOGO4");
		personalRecord.setKanji_simei(publicFlag.concat(personalRecord.getKanji_simei()));

		publicFlag = this.getDefaultFlag("HOGO5");
		personalRecord.setKana_simei(publicFlag.concat(personalRecord.getKana_simei()));

		publicFlag = this.getDefaultFlag("HOGO6");
		personalRecord.setEiji_simei(publicFlag.concat(personalRecord.getEiji_simei()));

		publicFlag = this.getDefaultFlag("HOGO10");
		personalRecord.setSeibetu(publicFlag.concat(personalRecord.getSeibetu()));

		publicFlag = this.getDefaultFlag("HOGO11");
		personalRecord.setSeinengappi(publicFlag.concat(personalRecord.getSeinengappi()));

		publicFlag = this.getDefaultFlag("HOGO12");
		personalRecord.setNyusya_nengetu(publicFlag.concat(personalRecord.getNyusya_nengetu()));

		publicFlag = this.getDefaultFlag("HOGO13");
		personalRecord.setJiko_pr(publicFlag.concat(personalRecord.getJiko_pr()));

		publicFlag = this.getDefaultFlag("HOGO3");
		personalRecord.setYobi1(publicFlag.concat(personalRecord.getYobi1()));

		publicFlag = this.getDefaultFlag("HOGO14");
		personalRecord.setYobi2(publicFlag.concat(personalRecord.getYobi2()));

		publicFlag = this.getDefaultFlag("HOGO14");
		personalRecord.setYobi3(publicFlag.concat(personalRecord.getYobi3()));

		publicFlag = this.getDefaultFlag("HOGO15");
		personalRecord.setYobi4(publicFlag.concat(personalRecord.getYobi4()));

		publicFlag = this.getDefaultFlag("HOGO15");
		personalRecord.setYobi5(publicFlag.concat(personalRecord.getYobi5()));

		publicFlag = this.getDefaultFlag("HOGO8");
		personalRecord.setYakusyoku(publicFlag.concat(personalRecord.getYakusyoku()));

		publicFlag = this.getDefaultFlag("HOGO7");
		personalRecord.setBusyo_ryakusyo_mei(publicFlag.concat(personalRecord.getBusyo_ryakusyo_mei()));

		personalRecord.setAssessment_kokai_flg(this.getDefaultFlag("HOGO16"));
		personalRecord.setKao_kokai_flg(this.getDefaultFlag("HOGO1"));
		personalRecord.setSkill_kokai_flg(this.getDefaultFlag("HOGO20"));
		personalRecord.setSyokumu_kokai_flg(this.getDefaultFlag("HOGO21"));
		personalRecord.setKyoiku_kokai_flg(this.getDefaultFlag("HOGO22"));
		personalRecord.setSikaku_kokai_flg(this.getDefaultFlag("HOGO23"));
		personalRecord.setHyosyo_kokai_flg(this.getDefaultFlag("HOGO24"));
		personalRecord.setRonbun_kokai_flg(this.getDefaultFlag("HOGO25"));
		personalRecord.setSyagai_kokai_flg(this.getDefaultFlag("HOGO26"));
		personalRecord.setGakureki_kokai_flg(this.getDefaultFlag("HOGO17"));
		personalRecord.setSyanaireki_kokai_flg(this.getDefaultFlag("HOGO18"));
		personalRecord.setZensyokureki_kokai_flg(this.getDefaultFlag("HOGO19"));
		personalRecord.setSosiki_kokai_flg(this.getDefaultFlag("HOGO7"));
		personalRecord.setYakusyoku_kokai_flg(this.getDefaultFlag("HOGO8"));
		personalRecord.setSyokui_kokai_flg(this.getDefaultFlag("HOGO9"));
		personalRecord.setKaigai_kokai_flg(this.getDefaultFlag("HOGO27")); // Add 03-00-/B
	}

	/**
	 * ���R�[�h���X�V����ꍇ�Ɋe�t�B�[���h���X�V����B
	 * @param personalRecord
	 * @param existRecord
	 */
	private void setUpdateValue(final PersonalRecord personalRecord, final PersonalRecord existRecord) {
		String oldValue = null;
		String flag = null;

		// �K�{�łȂ��t�B�[���h���X�V����B
		existRecord.setTaisyoku_nengappi(personalRecord.getTaisyoku_nengappi());
		existRecord.setSyokui_code(personalRecord.getSyokui_code());
		existRecord.setSosiki_code(personalRecord.getSosiki_code());

		// �f�[�^��null�A0�����ȊO�̏ꍇ�ɍX�V����
		if (personalRecord.getNaisen() != null && personalRecord.getNaisen().length() > 0) {
			existRecord.setNaisen(personalRecord.getNaisen());
		}
		if (personalRecord.getGaisen() != null && personalRecord.getGaisen().length() > 0) {
			existRecord.setGaisen(personalRecord.getGaisen());
		}
		if (personalRecord.getFax_no() != null && personalRecord.getFax_no().length() > 0) {
			existRecord.setFax_no(personalRecord.getFax_no());
		}
		if (personalRecord.getMail() != null && personalRecord.getMail().length() > 0) {
			existRecord.setMail(personalRecord.getMail());
		}
		if (personalRecord.getSyoku_code1() != null && personalRecord.getSyoku_code1().length() > 0) {
			existRecord.setSyoku_code1(personalRecord.getSyoku_code1());
		}
		if (personalRecord.getSenmon_code1() != null && personalRecord.getSenmon_code1().length() > 0) {
			existRecord.setSenmon_code1(personalRecord.getSenmon_code1());
		}
		if (personalRecord.getLevel_code1() != null && personalRecord.getLevel_code1().length() > 0) {
			existRecord.setLevel_code1(personalRecord.getLevel_code1());
		}
		if (personalRecord.getSougou_t_do1() != null && personalRecord.getSougou_t_do1().length() > 0) {
			existRecord.setSougou_t_do1(personalRecord.getSougou_t_do1());
		}
		if (personalRecord.getSyoku_code2() != null && personalRecord.getSyoku_code2().length() > 0) {
			existRecord.setSyoku_code2(personalRecord.getSyoku_code2());
		}
		if (personalRecord.getSenmon_code2() != null && personalRecord.getSenmon_code2().length() > 0) {
			existRecord.setSenmon_code2(personalRecord.getSenmon_code2());
		}
		if (personalRecord.getLevel_code2() != null && personalRecord.getLevel_code2().length() > 0) {
			existRecord.setLevel_code2(personalRecord.getLevel_code2());
		}
		if (personalRecord.getSougou_t_do2() != null && personalRecord.getSougou_t_do2().length() > 0) {
			existRecord.setSougou_t_do2(personalRecord.getSougou_t_do2());
		}
		if (personalRecord.getSyoku_code3() != null && personalRecord.getSyoku_code3().length() > 0) {
			existRecord.setSyoku_code3(personalRecord.getSyoku_code3());
		}
		if (personalRecord.getSenmon_code3() != null && personalRecord.getSenmon_code3().length() > 0) {
			existRecord.setSenmon_code3(personalRecord.getSenmon_code3());
		}
		if (personalRecord.getLevel_code3() != null && personalRecord.getLevel_code3().length() > 0) {
			existRecord.setLevel_code3(personalRecord.getLevel_code3());
		}
		if (personalRecord.getSougou_t_do3() != null && personalRecord.getSougou_t_do3().length() > 0) {
			existRecord.setSougou_t_do3(personalRecord.getSougou_t_do3());
		}

		// ��荞�񂾒l���g�p�A�l�Ȃ��̂Ƃ��ADB�ݒ�ς̒l���g�p
		if (personalRecord.getSkill_mainte_flg() != null && !ImportPersonalEJBBean.BLANK_STRING.equals(personalRecord.getSkill_mainte_flg())) {
			existRecord.setSkill_mainte_flg(personalRecord.getSkill_mainte_flg());
		}
		if (personalRecord.getKanren_gyomu_touroku_flg() != null && !ImportPersonalEJBBean.BLANK_STRING.equals(personalRecord.getKanren_gyomu_touroku_flg())) {
			existRecord.setKanren_gyomu_touroku_flg(personalRecord.getKanren_gyomu_touroku_flg());
		}
		if (personalRecord.getPersonal_mainte_flg() != null && !ImportPersonalEJBBean.BLANK_STRING.equals(personalRecord.getPersonal_mainte_flg())) {
			existRecord.setPersonal_mainte_flg(personalRecord.getPersonal_mainte_flg());
		}
		if (personalRecord.getSikaku_mainte_flg() != null && !ImportPersonalEJBBean.BLANK_STRING.equals(personalRecord.getSikaku_mainte_flg())) {
			existRecord.setSikaku_mainte_flg(personalRecord.getSikaku_mainte_flg());
		}
		if (personalRecord.getKenpo_mainte_flg() != null && !ImportPersonalEJBBean.BLANK_STRING.equals(personalRecord.getKenpo_mainte_flg())) {
			existRecord.setKenpo_mainte_flg(personalRecord.getKenpo_mainte_flg());
		}
		if (personalRecord.getLogin_osirase_mainte_flg() != null && !ImportPersonalEJBBean.BLANK_STRING.equals(personalRecord.getLogin_osirase_mainte_flg())) {
			existRecord.setLogin_osirase_mainte_flg(personalRecord.getLogin_osirase_mainte_flg());
		}
		if (personalRecord.getTokei_bunseki_kengen() != null && !ImportPersonalEJBBean.BLANK_STRING.equals(personalRecord.getTokei_bunseki_kengen())) {
			existRecord.setTokei_bunseki_kengen(personalRecord.getTokei_bunseki_kengen());
		}
		if (personalRecord.getTaisyokusya_kensaku_kengen_flg() != null && !ImportPersonalEJBBean.BLANK_STRING.equals(personalRecord.getTaisyokusya_kensaku_kengen_flg())) {
			existRecord.setTaisyokusya_kensaku_kengen_flg(personalRecord.getTaisyokusya_kensaku_kengen_flg());
		}
		if (personalRecord.getHikoukai_kensaku_kengen_flg() != null && !ImportPersonalEJBBean.BLANK_STRING.equals(personalRecord.getHikoukai_kensaku_kengen_flg())) {
			existRecord.setHikoukai_kensaku_kengen_flg(personalRecord.getHikoukai_kensaku_kengen_flg());
		}

		// �K�{�̃t�B�[���h���X�V���āA�t���O��ݒ肵�Ȃ��B
		existRecord.setPassword(personalRecord.getPassword());
		existRecord.setHonmu_flg(personalRecord.getHonmu_flg());
		existRecord.setGensyoku_taisyoku_flg(personalRecord.getGensyoku_taisyoku_flg());
		existRecord.setKengen_code(personalRecord.getKengen_code());
		existRecord.setYakusyoku_code(personalRecord.getYakusyoku_code());

		// �K�{�̃t�B�[���h���X�V���āA�t���O��ݒ肷��B
		oldValue = existRecord.getKanji_simei();
		flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		existRecord.setKanji_simei(flag.concat(personalRecord.getKanji_simei()));

		oldValue = existRecord.getKana_simei();
		flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		existRecord.setKana_simei(flag.concat(personalRecord.getKana_simei()));

		oldValue = existRecord.getSeibetu();
		flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		existRecord.setSeibetu(flag.concat(personalRecord.getSeibetu()));

		oldValue = existRecord.getSeinengappi();
		flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		existRecord.setSeinengappi(flag.concat(personalRecord.getSeinengappi()));

		oldValue = existRecord.getNyusya_nengetu();
		flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		existRecord.setNyusya_nengetu(flag.concat(personalRecord.getNyusya_nengetu()));

		oldValue = existRecord.getYakusyoku();
		flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		existRecord.setYakusyoku(flag.concat(personalRecord.getYakusyoku()));

		// �K�{�łȂ��t�B�[���h���X�V���āA�t���O��ݒ肷��B
		flag = this.getDefaultFlag("HOGO6");
		oldValue = existRecord.getEiji_simei();
		if (oldValue != null && oldValue.length() > 0) {
			flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		}
		existRecord.setEiji_simei(flag.concat(personalRecord.getEiji_simei()));

		flag = this.getDefaultFlag("HOGO13");
		oldValue = existRecord.getJiko_pr();
		if (oldValue != null && oldValue.length() > 0) {
			flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		}
		if (personalRecord.getJiko_pr() != null && personalRecord.getJiko_pr().length() > 0) {
			existRecord.setJiko_pr(flag.concat(personalRecord.getJiko_pr()));
		}

		flag = this.getDefaultFlag("HOGO3");
		oldValue = existRecord.getYobi1();
		if (oldValue != null && oldValue.length() > 0) {
			flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		}
		existRecord.setYobi1(flag.concat(personalRecord.getYobi1()));

		flag = this.getDefaultFlag("HOGO14");
		oldValue = existRecord.getYobi2();
		if (oldValue != null && oldValue.length() > 0) {
			flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		}
		existRecord.setYobi2(flag.concat(personalRecord.getYobi2()));

		flag = this.getDefaultFlag("HOGO14");
		oldValue = existRecord.getYobi3();
		if (oldValue != null && oldValue.length() > 0) {
			flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		}
		existRecord.setYobi3(flag.concat(personalRecord.getYobi3()));

		flag = this.getDefaultFlag("HOGO15");

		oldValue = existRecord.getYobi4();
		if (oldValue != null && oldValue.length() > 0) {
			flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		}
		existRecord.setYobi4(flag.concat(personalRecord.getYobi4()));

		flag = this.getDefaultFlag("HOGO15");
		oldValue = existRecord.getYobi5();
		if (oldValue != null && oldValue.length() > 0) {
			flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		}
		existRecord.setYobi5(flag.concat(personalRecord.getYobi5()));

		flag = this.getDefaultFlag("HOGO7");
		oldValue = existRecord.getBusyo_ryakusyo_mei();
		if (oldValue != null && oldValue.length() > 0) {
			flag = oldValue.substring(0, ImportPersonalEJBBean.FLAG_LENGTH);
		}
		existRecord.setBusyo_ryakusyo_mei(flag.concat(personalRecord.getBusyo_ryakusyo_mei()));

	}

	/**
	 * ��ʑg�D�̈ꗗ��S�Ď擾����B
	 * @param sosikiCode
	 * @param soshikiDAO
	 * @return �S�Ă̏�ʑg�D�ꗗ
	 * @exception WrongArgumentException �����G���[�B
	 * @exception IOException IO��O�B
	 * @exception SQLException SQL��O�B
	 */
	private Vector getAllUpperSoshiki(final String sosikiCode, final SoshikiDAO soshikiDAO) throws WrongArgumentException, IOException, SQLException {
		final Vector result = new Vector();
		SoshikiRecord record;
		String upperCode = new String(sosikiCode);

		while (!ImportPersonalEJBBean.rootSosikiCode.equals(upperCode) && result.size() <= ImportPersonalEJBBean.MAX_UPPERORG_COUNT) {

			record = soshikiDAO.lookup(upperCode);
			if (record == null) {
				break;
			}
			result.add(record);
			upperCode = record.getJoui_sosiki_code();
		}

		return result;
	}

	/**
	 * �����R�[�h�̎����ݒ�
	 * @param personalRecord
	 * @param soshikiDAO
	 * @exception WrongArgumentException �����G���[�B
	 * @exception IOException IO��O�B
	 * @exception SQLException SQL��O�B
	 */
	private void updateSyozokuCode(final PersonalRecord personalRecord, final SoshikiDAO soshikiDAO) throws WrongArgumentException, IOException, SQLException {
		final String sosikiCode = personalRecord.getSosiki_code();

		// INS#BPX-0301J-1032 -S
		// �����R�[�h�͖��񏉊��l��ݒ�
		for (int i = 1; i <= 9; i++) { // CHG#BPX-0301J-1033
			this.setSyozokuCode(i, personalRecord, ImportPersonalEJBBean.BLANK_STRING);
		}
		// INS#BPX-0301J-1032 -E

		if (sosikiCode == null) {
			return;
		}

		final SoshikiRecord soshikiRecord = soshikiDAO.lookup(sosikiCode);
		if (soshikiRecord == null) {
			return;
		}
		final String sosikiClass = soshikiRecord.getKaisou();

		int sosikiClassValue = 0;

		try {
			sosikiClassValue = Integer.parseInt(sosikiClass);
		} catch (final NumberFormatException e) {
			return;
		}

		final HashMap map = new HashMap();

		final Iterator ite = this.getAllUpperSoshiki(sosikiCode, soshikiDAO).iterator();

		while (ite.hasNext()) {
			final SoshikiRecord upperSoshikiRecord = (SoshikiRecord) ite.next();
			final String kaisou = upperSoshikiRecord.getKaisou();
			final String syozokuCode = upperSoshikiRecord.getSosiki_code().trim();
			map.put(kaisou, syozokuCode);
		}

		try {
			sosikiClassValue = Integer.parseInt(sosikiClass);
		} catch (final NumberFormatException e) {
			return;
		}

		// DEL#BPX-0301J-1032

		for (int i = 1; i < sosikiClassValue; i++) {
			final String kaisou = String.valueOf(i);
			if (map.get(kaisou) != null) {
				this.setSyozokuCode(i, personalRecord, (String) map.get(kaisou));
			}
		}
		this.setSyozokuCode(sosikiClassValue, personalRecord, sosikiCode);
	}

	/**
	 * �����R�[�h��1�`�X�ɐݒ肷��B
	 * @param index
	 * @param personalRecord
	 * @param sosikiCode
	 */
	private void setSyozokuCode(final int index, final PersonalRecord personalRecord, final String sosikiCode) {
		switch (index) {
		case 1:
			personalRecord.setSyozoku_code_1(sosikiCode);
			break;
		case 2:
			personalRecord.setSyozoku_code_2(sosikiCode);
			break;
		case 3:
			personalRecord.setSyozoku_code_3(sosikiCode);
			break;
		case 4:
			personalRecord.setSyozoku_code_4(sosikiCode);
			break;
		case 5:
			personalRecord.setSyozoku_code_5(sosikiCode);
			break;
		case 6:
			personalRecord.setSyozoku_code_6(sosikiCode);
			break;
		case 7:
			personalRecord.setSyozoku_code_7(sosikiCode);
			break;
		case 8:
			personalRecord.setSyozoku_code_8(sosikiCode);
			break;
		case 9:
			personalRecord.setSyozoku_code_9(sosikiCode);
			break;
		}
	}

	/**
	 * �f�t�H���g���J�E����J�t���O���擾����B
	 * @param key ���B
	 * @return �f�t�H���g���J�E����J�t���O�B
	 */
	private String getDefaultFlag(final String key) {
		String flag = (String) ReadFile.fileMapData.get(key);
		if (flag == null) {
			flag = new String();
		}
		return flag;
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @exception CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}

}
