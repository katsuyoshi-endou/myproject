/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.learning.kensyurekiiko;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;

import jp.co.hisas.addon.batch.learning.kensyurekiiko.bean.L51Bean;
import jp.co.hisas.addon.batch.learning.util.BatchUtil;
import jp.co.hisas.addon.batch.learning.util.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �T�v: L51�e�[�u������T05�e�[�u���փf�[�^���ړ����邽�߂̃N���X �g�p���@: �{�N���X��bat�t�@�C������Ăяo�����B
 */
public class MoveTrainingHistoryBatch {
	Date beginMoveDay = null;

	boolean seisekiHenkanFlg = false;

	static String T05_TABLE = "T05_KYOIKU_TBL";

	static String L51_TABLE = "L51_KYOIKU_TBL";

	static String KAISIBI_COLUMN = "KAISIBI";

	private static final String NORMAL_WIDTH_NUMERIC_PATTERN = "[-]?+[0-9]++";

	static public void main(final String[] args) {

		final MoveTrainingHistoryBatch instance = new MoveTrainingHistoryBatch();

		if (!instance.checkParameter()) {
			return;
		}
		instance.doMoveData();
	}

	/**
	 * �S�Ă̓��̓p�����[�^�����؂���B
	 * @return true:�S�Ẵp�����[�^���L���̏ꍇ�Atrue��Ԃ��B ����ȊO�̏ꍇ�Afalse��Ԃ��B
	 */
	private boolean checkParameter() {
		final String idoHousiki = System.getProperty("idoHousiki").trim();
		final String idoKisanTuki = System.getProperty("idoKisanTuki").trim();
		final String idoKisanHi = System.getProperty("idoKisanHi").trim();
		final String logPath = System.getProperty("logFilePath").trim();
		final String seisekiHenkanFlg = System.getProperty("seisekiHenkanFlg").trim();

		final File f = new File(logPath);
		if (!f.exists() || !f.isDirectory() || !f.isAbsolute()) {
			ReadFile.refreshFile();
			final String msgFileName = (String) ReadFile.fileMapData.get(HcdbDef.msgCode);
			final HashMap _msgMapData = ReadFile.getMsgMapData(msgFileName);
			final String messagePCG0126 = (String) _msgMapData.get("PCG-0126");
			System.out.println(messagePCG0126);
			return false;
		} else {
			try {
				// ���O������������B
				Log.init("kensyurekiiko", logPath);
			} catch (final FileNotFoundException e1) {
				ReadFile.refreshFile();
				final String msgFileName = (String) ReadFile.fileMapData.get(HcdbDef.msgCode);
				final HashMap _msgMapData = ReadFile.getMsgMapData(msgFileName);
				final String messagePCG0126 = (String) _msgMapData.get("PCG-0126");
				System.out.println(messagePCG0126);
				return false;
			}
		}

		int temp;
		if ("1".equals(idoHousiki)) {
			try {
				temp = Integer.parseInt(idoKisanTuki);
				if (!idoKisanTuki.matches(MoveTrainingHistoryBatch.NORMAL_WIDTH_NUMERIC_PATTERN)) {
					Log.message("PCG-0102", true);
					return false;
				}
			} catch (final NumberFormatException e) {
				Log.message("PCG-0102", true);
				return false;
			}
			if (temp <= 0) {
				Log.message("PCG-0103", true);
				return false;
			}

			if (temp >= 1000) {
				Log.message("PCG-0104", true);
				return false;
			}

			final Calendar cal = new GregorianCalendar();
			cal.add(Calendar.MONTH, -temp + 1);
			cal.set(Calendar.DAY_OF_MONTH, 1);
			this.beginMoveDay = cal.getTime();

		} else if ("2".equals(idoHousiki)) {

			try {
				temp = Integer.parseInt(idoKisanHi);
				if (!idoKisanHi.matches(MoveTrainingHistoryBatch.NORMAL_WIDTH_NUMERIC_PATTERN)) {
					Log.message("PCG-0105", true);
					return false;
				}
			} catch (final NumberFormatException e) {
				Log.message("PCG-0105", true);
				return false;
			}
			if (temp <= -1) {
				Log.message("PCG-0106", true);
				return false;
			}

			if (temp >= 10000) {
				Log.message("PCG-0107", true);
				return false;
			}

			final Calendar cal = new GregorianCalendar();
			cal.add(Calendar.DAY_OF_MONTH, -temp + 1);
			this.beginMoveDay = cal.getTime();
		} else {
			Log.message("PCG-0124", true);
			return false;
		}

		if ("1".equals(seisekiHenkanFlg)) {
			this.seisekiHenkanFlg = true;
		} else if ("0".equals(seisekiHenkanFlg)) {
			this.seisekiHenkanFlg = false;
		} else {
			Log.message("PCG-0125", true);
			return false;
		}

		return true;
	}

	/**
	 * �J�n�����w����ȑO�̃��R�[�h��L51�e�[�u������擾����B
	 * @param toDate:�w���
	 * @return:�Ԃ��ꂽ���R�[�h���i�[����List
	 */
	private List queryL51Records(final Connection conn, final Date toDate) {
		// 2006/06/16 Takagi Add Sta
		final String kanrimoto_code = System.getProperty("kanrimoto_code").trim();
		String kanrimoto_Sql;

		if (!"".equals(kanrimoto_code)) {
			kanrimoto_Sql = " AND trim(KANRIMOTO_CODE) = ? ";
		} else {
			kanrimoto_Sql = "";
		}
		// 2006/06/16 Takagi Add End

		final String sql = "SELECT seq_no,simei_no,kamoku_code,kamoku_mei1,kamoku_mei2,kamoku_mei3," + "kamoku_mei4,kamoku_group_mei,category_mei1,category_mei2,"
				+ "category_mei3,category_mei4,category_mei5,kanrimoto_mei," + "tanka,nissuu," +"class_mei,kaisibi,syuryobi,report_filename,report_content_type,"
				+ "houkoku,seiseki,syuryo_hantei,honnin_syusei_flg,kokai_flg,tensu," + "tourokubi,tourokujikoku,tourokusya,kousinbi,kousinjikoku,kousinsya" + " FROM "
				+ MoveTrainingHistoryBatch.L51_TABLE + " WHERE to_date(" + MoveTrainingHistoryBatch.KAISIBI_COLUMN + ",'YYYYmmDD')" + "<?" + kanrimoto_Sql;

		PreparedStatement ps = null;
		ResultSet rs = null;
		final List resultList = new ArrayList();
		try {
			ps = conn.prepareStatement(sql);
			final java.sql.Date date = new java.sql.Date(toDate.getTime());
			ps.setDate(1, date);

			// 2006/06/16 Takagi Add Sta
			if (!"".equals(kanrimoto_code)) {
				ps.setString(2, kanrimoto_code);
			}
			// 2006/06/16 Takagi Add End
			rs = ps.executeQuery();
			while (rs.next()) {
				final L51Bean l51Bean = new L51Bean(rs);
				resultList.add(l51Bean);
			}
			BatchUtil.closeConnection(null, null, rs);
		} catch (final SQLException e) {
			Log.messagePCG0109("0", e);
			e.printStackTrace();
		}
		return resultList;
	}

	/**
	 * L51�e�[�u���̃��R�[�h��T05�e�[�u���̐��т��v�Z����B
	 * @param bean
	 * @return ���т�\���镶����
	 */
	private String getT05Seisiki(final L51Bean bean) {
		if (!this.seisekiHenkanFlg) {
			return bean.getSeiseki();
		} else {
			if (bean.getTensu() == null) {
				return "Z";
			}
			try {
				final long tensu = Long.parseLong(bean.getTensu());
				if (tensu >= Long.parseLong(System.getProperty("henkanTensuMax1").trim())) {
					return "A";
				} else if (tensu >= Long.parseLong(System.getProperty("henkanTensuMax2").trim())) {
					return "B";
				} else if (tensu >= Long.parseLong(System.getProperty("henkanTensuMax3").trim())) {
					return "C";
				} else {
					return "Z";
				}
			} catch (final NumberFormatException e) {
				return "Z";
			}
		}
	}

	/**
	 * L51�e�[�u���̂P���̃��R�[�h��T05�e�[�u���ɑ}������B
	 * @param ps:�f�[�^��}�����邽�߂�PreparedStatement
	 * @param bean:T05�e�[�u���ɑ}�����邽�߂�L51�r�[��
	 */
	private void insertL51BeanToT05(final PreparedStatement ps, final L51Bean bean) throws SQLException {

		ps.setString(1, bean.getSimei_no());
		ps.setString(2, bean.getKamoku_code());
		ps.setString(3, bean.getKamoku_mei1());
		ps.setString(4, bean.getKamoku_mei2());
		ps.setString(5, bean.getKamoku_mei3());
		ps.setString(6, bean.getKamoku_mei4());
		ps.setString(7, bean.getKamoku_group_mei());
		ps.setString(8, bean.getCategory_mei1());
		ps.setString(9, bean.getCategory_mei2());
		ps.setString(10, bean.getCategory_mei3());
		ps.setString(11, bean.getCategory_mei4());
		ps.setString(12, bean.getCategory_mei5());
		ps.setString(13, bean.getKanrimoto_mei());
		ps.setString(14, bean.getClass_mei());
		ps.setString(15, bean.getKaisibi());
		ps.setString(16, bean.getSyuryobi());
		ps.setString(17, bean.getReport_filename());
		ps.setString(18, bean.getReport_content_type());
		ps.setBlob(19, bean.getHoukoku());
		ps.setString(20, this.getT05Seisiki(bean));
		ps.setString(21, bean.getSyuryo_hantei());
		ps.setString(22, "0");
		ps.setString(23, "0");
		ps.setString(24, bean.getTanka());
		ps.setString(25, bean.getNissuu());
		ps.setString(26, bean.getSeq_no());
		ps.executeUpdate();
	}

	/**
	 * L51�e�[�u���̃��R�[�h���P���폜����B
	 * @param ps:�폜�̂��߂�PreparedStatement
	 * @param bean:�폜�̂��߂�L51�̃��R�[�h
	 */
	private void deleteFromL51(final PreparedStatement ps, final L51Bean bean) throws SQLException {
		ps.setString(1, bean.getSeq_no());
		ps.executeUpdate();
	}

	/**
	 * �{���\�b�h��L45�e�[�u������T05�e�[�u���Ƀf�[�^�� �ړ�����Ƃ����o�b�`�̎�ȃW���u�����s����B
	 */
	private void doMoveData() {

		final String misyuryoIdoFlg = System.getProperty("misyuryoIdoFlg").trim();
		final String sqlDelete = "DELETE FROM " + MoveTrainingHistoryBatch.L51_TABLE + " WHERE SEQ_NO =?";
		final String sqlInsert = "INSERT INTO " + MoveTrainingHistoryBatch.T05_TABLE + " (" + "simei_no," + "kamoku_code," + "kamoku_mei1," + "kamoku_mei2," + "kamoku_mei3," + "kamoku_mei4,"
				+ "kamoku_group_mei," + "category_mei1," + "category_mei2," + "category_mei3," + "category_mei4," + "category_mei5," + "kanrimoto_mei," + "class_mei," + "kaisibi," + "syuryobi,"
				+ "report_filename," + "report_content_type," + "houkoku," + "seiseki," + "syuryo_hantei," + "honnin_syusei_flg," + "kokai_flg," + "tanka," + "nissuu," + "seq_no"
				+ ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		Connection conn = null;
		List L51Records = null;

		try {
			conn = BatchUtil.getConnection();
			L51Records = this.queryL51Records(conn, this.beginMoveDay);
		} catch (final Exception e) {
			Log.messagePCG0109("0", e);
		} finally {
			BatchUtil.closeConnection(conn);
		}

		// �f�[�^�x�[�X�ւ̐ڑ����Q�쐬����B���ꂼ��̐ڑ��͍폜�y�ё}���Ɏg�p����B

		Connection insertConn = null;
		Connection deleteConn = null;
		try {

			insertConn = BatchUtil.getConnection();
			final PreparedStatement insertStatement = insertConn.prepareStatement(sqlInsert);

			deleteConn = BatchUtil.getConnection();
			final PreparedStatement deleteStatement = deleteConn.prepareStatement(sqlDelete);

			insertConn.setAutoCommit(false);
			deleteConn.setAutoCommit(false);

			for (int i = 0; i < L51Records.size(); i++) {
				final L51Bean bean = (L51Bean) L51Records.get(i);
				/* ���C���ړ��t���O���O�̏ꍇ�A�u���C�v�͈ړ����Ȃ� */
				if (!("0".equals(misyuryoIdoFlg) && "0".equals(bean.getSyuryo_hantei()))) {
					// T05�e�[�u���Ƀf�[�^��}������B
					try {
						this.insertL51BeanToT05(insertStatement, bean);
					} catch (final SQLException e) {
						Log.messagePCG0109(bean.getSeq_no(), e);
						BatchUtil.rollbackConnection(conn);
						continue;
					}
				}
				// L51�e�[�u���̃f�[�^���폜����B
				try {
					this.deleteFromL51(deleteStatement, bean);
				} catch (final SQLException e) {
					Log.messagePCG0109(bean.getSeq_no(), e);
					BatchUtil.rollbackConnection(conn);
					BatchUtil.rollbackConnection(deleteConn);
					continue;
				}

				BatchUtil.commitConnection(insertConn);
				BatchUtil.commitConnection(deleteConn);
			}
			Log.message("PCG-0108", true);
		} catch (final Exception e) {
			Log.messagePCG0109("", e);
		} finally {
			BatchUtil.closeConnection(insertConn);
			BatchUtil.closeConnection(deleteConn);
		}
	}

}
