package jp.co.hisas.addon.batch.learning.trainingEntry.ejb;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

/**
 * <PRE>
 * 
 * �N���X���FPCY_PartnerTrainingEntryDaoEJBBean�N���X
 * �@�\�����F���͉�Ќ����̌��C�\���������s��
 * 
 * </PRE>
 * 
 * @ejb.bean name="PCY_PartnerTrainingEntryDaoEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_PartnerTrainingEntryDaoEJBBean implements SessionBean {
	private SessionContext context = null;
	
	/**
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public void execute() throws SQLException, NamingException, RemoteException {
		
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {

	}
}
