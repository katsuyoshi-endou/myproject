/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.batch.learning.sendfollowmail.ejb;

/**
 * Home interface for PCY_FollowMailSenderEJB.
 * @xdoclet-generated at 2004/06/16
 */
public interface PCY_FollowMailSenderEJBHome extends javax.ejb.EJBHome {
	public static final String COMP_NAME = "java:comp/env/ejb/PCY_FollowMailSenderEJB";

	public static final String JNDI_NAME = "PCY_FollowMailSenderEJB";

	public jp.co.hisas.career.batch.learning.sendfollowmail.ejb.PCY_FollowMailSenderEJB create() throws javax.ejb.CreateException, java.rmi.RemoteException;

}
