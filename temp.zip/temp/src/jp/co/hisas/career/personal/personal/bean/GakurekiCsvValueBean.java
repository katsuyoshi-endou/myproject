package jp.co.hisas.career.personal.personal.bean;

import jp.co.hisas.career.personal.util.CsvValueBean;

/**
 * �w��CSV�̏o�͓��e�i�P���R�[�h���j��ێ�����
 *
 */
public class GakurekiCsvValueBean extends CsvValueBean {

	/** ����NO */
	private String shimeiNo = null;

	/** ���� */
	private String shimei = null;

	/** ������ */
	private String busyo = null;

	/** �w�Z�� */
	private String gakkoName = null;

	/** �w���� */
	private String gakubuName = null;

	/** �w�Ȗ� */
	private String gakkaName = null;

	/** �w�� */
	private String gakui = null;

	/** �擾/���ƔN�� */
	private String sotsugyoNengetsu = null;

	/** ���l */
	private String biko = null;
	
	/** ����J */
	private String hikokai = null;

	public String getBiko() {
		return biko;
	}

	public void setBiko(String biko) {
		this.biko = biko;
	}

	public String getBusyo() {
		return busyo;
	}

	public void setBusyo(String busyo) {
		this.busyo = busyo;
	}

	public String getGakkaName() {
		return gakkaName;
	}

	public void setGakkaName(String gakkaName) {
		this.gakkaName = gakkaName;
	}

	public String getGakkoName() {
		return gakkoName;
	}

	public void setGakkoName(String gakkoName) {
		this.gakkoName = gakkoName;
	}

	public String getGakubuName() {
		return gakubuName;
	}

	public void setGakubuName(String gakubuName) {
		this.gakubuName = gakubuName;
	}

	public String getGakui() {
		return gakui;
	}

	public void setGakui(String gakui) {
		this.gakui = gakui;
	}

	public String getShimei() {
		return shimei;
	}

	public void setShimei(String shimei) {
		this.shimei = shimei;
	}

	public String getShimeiNo() {
		return shimeiNo;
	}

	public void setShimeiNo(String shimeiNo) {
		this.shimeiNo = shimeiNo;
	}

	public String getSotsugyoNengetsu() {
		return sotsugyoNengetsu;
	}

	public void setSotsugyoNengetsu(String sotsugyoNengetsu) {
		this.sotsugyoNengetsu = sotsugyoNengetsu;
	}

	public String getHikokai() {
		return hikokai;
	}

	public void setHikokai(String hikokai) {
		this.hikokai = hikokai;
	}


}
