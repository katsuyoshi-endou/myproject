package jp.co.hisas.career.personal.personal.bean;

import jp.co.hisas.career.personal.util.CsvValueBean;

/**
 * �O�E��CSV�̏o�͓��e�i�P���R�[�h���j��ێ�����
 *
 */
public class ZenshokurekiCsvValueBean extends CsvValueBean {
	/** ����NO */
	private String shimeiNo = null;

	/** ���� */
	private String shimei = null;

	/** ������ */
	private String busyo = null;

	/** �J�n�� */
	private String kaishiBi = null;

	/** �I���� */
	private String shuryoBi = null;

	/** ��Ж� */
	private String kaisya = null;

	/** �Ǝ� */
	private String gyoshu = null;

	/** �E��P */
	private String shokushu1 = null;

	/** �E��Q */
	private String shokushu2 = null;

	/** �E��R */
	private String shokushu3 = null;

	/** ���l */
	private String biko = null;

	/** ����J */
	private String hikokai = null;

	public String getBiko() {
		return biko;
	}

	public void setBiko(String biko) {
		this.biko = biko;
	}

	public String getBusyo() {
		return busyo;
	}

	public void setBusyo(String busyo) {
		this.busyo = busyo;
	}

	public String getGyoshu() {
		return gyoshu;
	}

	public void setGyoshu(String gyoshu) {
		this.gyoshu = gyoshu;
	}

	public String getHikokai() {
		return hikokai;
	}

	public void setHikokai(String hikokai) {
		this.hikokai = hikokai;
	}

	public String getKaishiBi() {
		return kaishiBi;
	}

	public void setKaishiBi(String kaishiBi) {
		this.kaishiBi = kaishiBi;
	}

	public String getKaisya() {
		return kaisya;
	}

	public void setKaisya(String kaisya) {
		this.kaisya = kaisya;
	}

	public String getShimei() {
		return shimei;
	}

	public void setShimei(String shimei) {
		this.shimei = shimei;
	}

	public String getShimeiNo() {
		return shimeiNo;
	}

	public void setShimeiNo(String shimeiNo) {
		this.shimeiNo = shimeiNo;
	}

	public String getShokushu1() {
		return shokushu1;
	}

	public void setShokushu1(String shokushu1) {
		this.shokushu1 = shokushu1;
	}

	public String getShokushu2() {
		return shokushu2;
	}

	public void setShokushu2(String shokushu2) {
		this.shokushu2 = shokushu2;
	}

	public String getShokushu3() {
		return shokushu3;
	}

	public void setShokushu3(String shokushu3) {
		this.shokushu3 = shokushu3;
	}

	public String getShuryoBi() {
		return shuryoBi;
	}

	public void setShuryoBi(String shuryoBi) {
		this.shuryoBi = shuryoBi;
	}
	
}
