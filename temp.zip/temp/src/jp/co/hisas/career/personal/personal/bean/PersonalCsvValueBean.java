package jp.co.hisas.career.personal.personal.bean;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.personal.util.CsvValueBean;

/**
 * �p�[�\�i��CSV�̏o�͓��e�i�P���R�[�h���j��ێ�����
 *
 */
public class PersonalCsvValueBean extends CsvValueBean {

	/** ����NO */
	private String shimeiNo = null;

	/** �O���[�vNO */
	private String groupNo = null;

	/** �����i�����j */
	private String kanjiShimei = null;

	/** �����i�J�i�j */
	private String kanaShimei = null;

	/** �����i�p���j */
	private String eijiShimei = null;

	/** ���ДN���� */
	private String nyushaNengappi = null;

	/** ����PR */
	private String jikoPR = null;

	/** ���� */
	private String shozoku = null;

	/** ���� */
	private String busho = null;

	/** ��E */
	private String yakushoku = null;

	/** �O�� */
	private String gaisen = null;

	/** ���� */
	private String naisen = null;

	/** FAX */
	private String fax = null;

	/** MAIL */
	private String mail = null;

	/** �E�� */
	private String shokui = null;

	/** ���� */
	private String seibetsu = null;

	/** ���N���� */
	private String seinengappi = null;

	/** Job */
	private String job = null;

	/** Supervisor */
	private String supervisor = null;

	/** �A�Z�X�����g���ʃ��X�g */
	private List assessmentList = null;

	/** ����J */
	private String hikokai = null;
	
	public PersonalCsvValueBean(){
		this.assessmentList = new ArrayList();
	}

	public String getBusho() {
		return busho;
	}

	public void setBusho(String busho) {
		this.busho = busho;
	}

	public String getEijiShimei() {
		return eijiShimei;
	}

	public void setEijiShimei(String eijiShimei) {
		this.eijiShimei = eijiShimei;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getGaisen() {
		return gaisen;
	}

	public void setGaisen(String gaisen) {
		this.gaisen = gaisen;
	}

	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	public String getHikokai() {
		return hikokai;
	}

	public void setHikokai(String hikokai) {
		this.hikokai = hikokai;
	}

	public String getJikoPR() {
		return jikoPR;
	}

	public void setJikoPR(String jikoPR) {
		this.jikoPR = jikoPR;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getKanaShimei() {
		return kanaShimei;
	}

	public void setKanaShimei(String kanaShimei) {
		this.kanaShimei = kanaShimei;
	}

	public String getKanjiShimei() {
		return kanjiShimei;
	}

	public void setKanjiShimei(String kanjiShimei) {
		this.kanjiShimei = kanjiShimei;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getNaisen() {
		return naisen;
	}

	public void setNaisen(String naisen) {
		this.naisen = naisen;
	}

	public String getNyushaNengappi() {
		return nyushaNengappi;
	}

	public void setNyushaNengappi(String nyushaNengappi) {
		this.nyushaNengappi = nyushaNengappi;
	}

	public String getSeibetsu() {
		return seibetsu;
	}

	public void setSeibetsu(String seibetsu) {
		this.seibetsu = seibetsu;
	}

	public String getSeinengappi() {
		return seinengappi;
	}

	public void setSeinengappi(String seinengappi) {
		this.seinengappi = seinengappi;
	}

	public String getShimeiNo() {
		return shimeiNo;
	}

	public void setShimeiNo(String shimeiNo) {
		this.shimeiNo = shimeiNo;
	}

	public String getShokui() {
		return shokui;
	}

	public void setShokui(String shokui) {
		this.shokui = shokui;
	}

	public String getShozoku() {
		return shozoku;
	}

	public void setShozoku(String shozoku) {
		this.shozoku = shozoku;
	}

	public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}

	public String getYakushoku() {
		return yakushoku;
	}

	public void setYakushoku(String yakushoku) {
		this.yakushoku = yakushoku;
	}

	public List getAssessmentList() {
		return assessmentList;
	}

	public void addAssessment(PersonalCsvAssessmentValueBean assessment) {
		this.assessmentList.add(assessment);
	}

	public void setAssessmentList(List assessmentList) {
		this.assessmentList = assessmentList;
	}
	
	
}
