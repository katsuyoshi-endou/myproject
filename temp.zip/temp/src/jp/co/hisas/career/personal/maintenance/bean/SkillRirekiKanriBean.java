/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.personal.maintenance.bean;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.naming.NamingException;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.performance.util.ejb.PED_StoredProcedureUtilityEJB;
import jp.co.hisas.career.performance.util.ejb.PED_StoredProcedureUtilityEJBHome;
import jp.co.hisas.career.util.property.CommonParameter;

/**
 * �X�L�������Ǘ��̃N���X
 */
public class SkillRirekiKanriBean {

	public static final String SHORI_SYUBETSU = "P01";

	/** PL/SQL�L�b�N */
	private static final String SQL_SAVE = "{? = call PEX_SKILLRIREKI_KANRI.F_SKILLRIREKI_HOZON(?)}";

	private static final String SQL_DELETE = "{? = call PEX_SKILLRIREKI_KANRI.F_SKILLRIREKI_SAKUJO(?)}";

	public int skillkanriexecute(final String loginNo, final String tmpSessionNo, final String flg) throws NamingException, ClassCastException, Exception {
		final String tmpLoginNo = loginNo;
		String tmpSQL = "";
		if (flg.equals("1")) {
			tmpSQL = SkillRirekiKanriBean.SQL_SAVE;
		} else {
			tmpSQL = SkillRirekiKanriBean.SQL_DELETE;
		}
		// EJBHome�̎擾
		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PED_StoredProcedureUtilityEJBHome my_home = (PED_StoredProcedureUtilityEJBHome) fact.lookup(PED_StoredProcedureUtilityEJBHome.class);
		/* EJBObject�̎擾 */
		final PED_StoredProcedureUtilityEJB tmpUserSession = my_home.create();
		final Date date = new Date();
		final DateFormat df_date = new SimpleDateFormat("yyyyMMddHHmmssS");
		final String date2 = df_date.format(date);
		final DateFormat df_date2 = new SimpleDateFormat("yyyyMMdd");
		final String date3 = df_date2.format(date);
		final String data4 = CommonParameter.getValue(CommonParameter.BUNRUI_BASE,"Skillsinventory_default_Group_Code");
		int errorNo = 1;

		// �����쐬
		final String[] args01 = new String[] { date2 };
		final String[] args02 = new String[] { date3 };
		final String[] args03 = new String[] { data4 };
		final String[] args04 = new String[] { "" };
		final String[] args05 = new String[] { "" };
		final String[] args06 = new String[] { "" };
		final String[] args07 = new String[] { "" };
		final String[] args08 = new String[] { "" };
		final String[] args09 = new String[] { "" };
		final String[] args10 = new String[] { "" };

		errorNo = tmpUserSession.execStoredProcedure(tmpSQL, args01, args02, args03, args04, args05, args06, args07, args08, args09, args10, tmpLoginNo, tmpSessionNo);
		return errorNo;
	}
}
