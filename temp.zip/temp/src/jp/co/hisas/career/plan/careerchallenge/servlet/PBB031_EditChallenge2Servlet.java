/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.careerchallenge.servlet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.code.bean.CodeBean;
import jp.co.hisas.career.base.menu.bean.MenuSeigyoBean;
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.plan.base.bean.PBY_SkillStandardBean;
import jp.co.hisas.career.plan.careerchallenge.bean.PBB_CareerChallenge;
import jp.co.hisas.career.plan.careerchallenge.bean.PBB_ChallengeBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.pdf.PZE070_ChallengePDF;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �T�v: �u���E�U���瑗�M���ꂽ�l���󂯎��A�N���C�A���gBean�̋@���ی�ݒ菈�����\�b�h���Ăяo���B �g�p���@: JSP����Ăяo���B �u�L�����A�`�������W���s���v����J�ڂ����u�L�����A�`�������W�v�����(VBB020)�v��ʂ���̍X�V�������s���B
 * 
 * </PRE>
 */
public class PBB031_EditChallenge2Servlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U���瑗�M���ꂽ�l���󂯎��A�N���C�A���gBean�̋@���ی�ݒ菈�����\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
	 * @param response Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet�̐���ȏ������W����ꂽ���ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = "";
		
		try {
			final String result = HcdbDef.result;
			final String plan = HcdbDef.plan;

			final HttpSession session = request.getSession(false);

			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
				login_no = bean.getLogin_no();
				/* bean�Ăяo�� */
				PBB_ChallengeBean challengebean = (PBB_ChallengeBean) session.getAttribute("challenge");
				final MenuSeigyoBean menuSeigyoBean = (MenuSeigyoBean) session.getAttribute("menuSeigyo");

				if (challengebean == null) {
					challengebean = new PBB_ChallengeBean(login_no);
					session.setAttribute("challenge", challengebean);

				}
				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				/* WWW�u���E�U������͒l���󂯎�� */
				final String kubun = request.getParameter("H015_Kubun");

				final String[] save_plan = new String[38]; // 2007/01/04 yoshida edit
				final String[] save_result = new String[38];

				if (kubun.equals(plan)) {
					/* �v����o�^�� */
					final String[][] sikakuargs = CodeBean.getSikaku();

					if (request.getParameter("H002_SyokuCode").equals("DUMMY")) {
						save_plan[0] = "";
					} else {
						save_plan[0] = request.getParameter("H002_SyokuCode");
					}
					if (request.getParameter("H004_SenmonCode").equals("DUMMY")) {
						save_plan[1] = "";
					} else {
						save_plan[1] = request.getParameter("H004_SenmonCode");
					}
					if (request.getParameter("H006_LevelCode").equals("DUMMY")) {
						save_plan[2] = "";
					} else {
						save_plan[2] = request.getParameter("H006_LevelCode");
					}
					save_plan[3] = PZZ010_CharacterUtil.strEncode(request.getParameter("A001_Gyomu"));
					save_plan[4] = PZZ010_CharacterUtil.strEncode(request.getParameter("A002_Kyoiku"));
					if (request.getParameter("S006_Sikaku1").equals("-1")) {
						save_plan[5] = "";
					} else {
						save_plan[5] = sikakuargs[Integer.parseInt(request.getParameter("S006_Sikaku1"))][0];
					}
					if (request.getParameter("S009_SikakuCode1").equals("-1")) {
						save_plan[6] = "";
					} else {
						save_plan[6] = request.getParameter("S009_SikakuCode1");
					}
					save_plan[7] = PZZ010_CharacterUtil.strEncode(request.getParameter("T005_Tokuten1"));
					save_plan[19] = PZZ010_CharacterUtil.strEncode(request.getParameter("H033_Sikaku_meisyo1"));
					save_plan[20] = PZZ010_CharacterUtil.strEncode(request.getParameter("H036_Level_mei1"));

					if (request.getParameter("S007_Sikaku2").equals("-1")) {
						save_plan[8] = "";
					} else {
						save_plan[8] = sikakuargs[Integer.parseInt(request.getParameter("S007_Sikaku2"))][0];
					}
					if (request.getParameter("S010_SikakuCode2").equals("-1")) {
						save_plan[9] = "";
					} else {
						save_plan[9] = request.getParameter("S010_SikakuCode2");
					}
					save_plan[10] = PZZ010_CharacterUtil.strEncode(request.getParameter("T006_Tokuten2"));
					save_plan[21] = PZZ010_CharacterUtil.strEncode(request.getParameter("H034_Sikaku_meisyo2"));
					save_plan[22] = PZZ010_CharacterUtil.strEncode(request.getParameter("H037_Level_mei2"));

					if (request.getParameter("S008_Sikaku3").equals("-1")) {
						save_plan[11] = "";
					} else {
						save_plan[11] = sikakuargs[Integer.parseInt(request.getParameter("S008_Sikaku3"))][0];
					}
					if (request.getParameter("S011_SikakuCode3").equals("-1")) {
						save_plan[12] = "";
					} else {
						save_plan[12] = request.getParameter("S011_SikakuCode3");
					}
					save_plan[13] = PZZ010_CharacterUtil.strEncode(request.getParameter("T007_Tokuten3"));
					save_plan[23] = PZZ010_CharacterUtil.strEncode(request.getParameter("H035_Sikaku_meisyo3"));
					save_plan[24] = PZZ010_CharacterUtil.strEncode(request.getParameter("H038_Level_mei3"));

					save_plan[14] = PZZ010_CharacterUtil.strEncode(request.getParameter("A003_Keihatu"));
					save_plan[15] = PZZ010_CharacterUtil.strEncode(request.getParameter("A004_Ido"));
					save_plan[16] = PZZ010_CharacterUtil.strEncode(request.getParameter("A005_Tuiki"));
					save_plan[17] = PZZ010_CharacterUtil.GetDay();
					save_plan[18] = PZZ010_CharacterUtil.GetTime();
					save_plan[25] = HcdbDef.flg1;
					save_plan[26] = HcdbDef.flg0;
					save_plan[27] = "";
					save_plan[28] = "";
					save_plan[29] = "BLOB_DATA";
					save_plan[30] = "";
					save_plan[31] = "";

					/* 2007/01/04 yoshida add start */
					if (request.getParameter("H002_SyokuCode2") == null || request.getParameter("H002_SyokuCode2").equals("DUMMY")) {
						save_plan[32] = "";
					} else {
						save_plan[32] = request.getParameter("H002_SyokuCode2");
					}
					if (request.getParameter("H004_SenmonCode2") == null || request.getParameter("H004_SenmonCode2").equals("DUMMY")) {
						save_plan[33] = "";
					} else {
						save_plan[33] = request.getParameter("H004_SenmonCode2");
					}
					if (request.getParameter("H006_LevelCode2") == null || request.getParameter("H006_LevelCode2").equals("DUMMY")) {
						save_plan[34] = "";
					} else {
						save_plan[34] = request.getParameter("H006_LevelCode2");
					}
					if (request.getParameter("H002_SyokuCode3") == null || request.getParameter("H002_SyokuCode3").equals("DUMMY")) {
						save_plan[35] = "";
					} else {
						save_plan[35] = request.getParameter("H002_SyokuCode3");
					}
					if (request.getParameter("H004_SenmonCode3") == null || request.getParameter("H004_SenmonCode3").equals("DUMMY")) {
						save_plan[36] = "";
					} else {
						save_plan[36] = request.getParameter("H004_SenmonCode3");
					}
					if (request.getParameter("H006_LevelCode3") == null || request.getParameter("H006_LevelCode3").equals("DUMMY")) {
						save_plan[37] = "";
					} else {
						save_plan[37] = request.getParameter("H006_LevelCode3");
					}
					/* 2007/01/04 yoshida add end */

					/* ���эX�V�̏ꍇ */
				} else if (kubun.equals(result)) {

					save_result[0] = PZZ010_CharacterUtil.strEncode(request.getParameter("A001_Gyomu"));
					save_result[1] = PZZ010_CharacterUtil.strEncode(request.getParameter("A002_Kyoiku"));
					save_result[2] = PZZ010_CharacterUtil.strEncode(request.getParameter("A003_Keihatu"));
					save_result[3] = PZZ010_CharacterUtil.strEncode(request.getParameter("A004_Ido"));
					save_result[4] = PZZ010_CharacterUtil.strEncode(request.getParameter("A005_Tuiki"));
					save_result[5] = PZZ010_CharacterUtil.GetDay();
					save_result[6] = PZZ010_CharacterUtil.GetTime();
					save_result[7] = HcdbDef.flg1;
					save_result[8] = HcdbDef.flg0;
					save_result[9] = "";
					save_result[10] = "";
					save_result[11] = "BLOB_DATA";
					save_result[12] = "";
					save_result[13] = "";

					if (request.getParameter("H002_SyokuCode2") == null || request.getParameter("H002_SyokuCode2").equals("DUMMY")) {
						save_result[32] = "";
					} else {
						save_result[32] = request.getParameter("H002_SyokuCode2");
					}
					if (request.getParameter("H004_SenmonCode2") == null || request.getParameter("H004_SenmonCode2").equals("DUMMY")) {
						save_result[33] = "";
					} else {
						save_result[33] = request.getParameter("H004_SenmonCode2");
					}
					if (request.getParameter("H006_LevelCode2") == null || request.getParameter("H006_LevelCode2").equals("DUMMY")) {
						save_result[34] = "";
					} else {
						save_result[34] = request.getParameter("H006_LevelCode2");
					}
					if (request.getParameter("H002_SyokuCode3") == null || request.getParameter("H002_SyokuCode3").equals("DUMMY")) {
						save_result[35] = "";
					} else {
						save_result[35] = request.getParameter("H002_SyokuCode3");
					}
					if (request.getParameter("H004_SenmonCode3") == null || request.getParameter("H004_SenmonCode3").equals("DUMMY")) {
						save_result[36] = "";
					} else {
						save_result[36] = request.getParameter("H004_SenmonCode3");
					}
					if (request.getParameter("H006_LevelCode3") == null || request.getParameter("H006_LevelCode3").equals("DUMMY")) {
						save_result[37] = "";
					} else {
						save_result[37] = request.getParameter("H006_LevelCode3");
					}

				}

				/* PDF�쐬 */
				final PZE070_ChallengePDF pdf = new PZE070_ChallengePDF(login_no);

				/* ��ر���ݼގ����ް� */
				final PBB_CareerChallenge challengeResult = new PBB_CareerChallenge();

				/* ��ر���ݼތv���ް� */
				PBB_CareerChallenge challengePlan = null;
				if (kubun.equals(plan)) {
					challengePlan = challengebean.getCareerChallengePlan();
				} else if (kubun.equals(result)) {
					challengePlan = challengebean.getPreCareerChallengePlan();
				}
				/* �E�����e���ް� */
				final String[][] syokumuData = challengebean.getSyokumuData();

				/* ���i�ް� */
				final String[][] sikakuData = challengebean.getSikakuData();

				/* �E��R�[�h */
				String syokusyuCode = "";

				/* ��啪��R�[�h */
				String senmonCode = "";

				/* ���x���R�[�h */
				String levelCode = "";

				/* PDF���ږ��̎擾 */
				final String[] outDefItem = challengebean.getoutDefPDF2(challengebean.getEdit_Nen(), challengebean.getEdit_Kubun());

				/* �v��̏ꍇ */
				if (request.getParameter("H015_Kubun").equals("1")) {

					syokusyuCode = save_plan[0];
					senmonCode = save_plan[1];
					levelCode = save_plan[2];

					/* �E�� */
					if (!syokusyuCode.equals("")) {
						challengePlan.setMokuhyoSyokuName(PBY_SkillStandardBean.getSyokuName(syokusyuCode));
					}
					if (!save_plan[32].equals("")) {
						challengePlan.setMokuhyoSyokuName2(PBY_SkillStandardBean.getSyokuName(save_plan[32]));
					}
					if (!save_plan[35].equals("")) {
						challengePlan.setMokuhyoSyokuName3(PBY_SkillStandardBean.getSyokuName(save_plan[35]));
					}

					/* ��啪�� */
					if (!senmonCode.equals("")) {
						challengePlan.setMokuhyoSenmonName(PBY_SkillStandardBean.getSenmonName(syokusyuCode, senmonCode));
					}
					if (!save_plan[33].equals("")) {
						challengePlan.setMokuhyoSenmonName2(PBY_SkillStandardBean.getSenmonName(save_plan[32], save_plan[33]));
					}
					if (!save_plan[36].equals("")) {
						challengePlan.setMokuhyoSenmonName3(PBY_SkillStandardBean.getSenmonName(save_plan[35], save_plan[36]));
					}

					/* ���x�� */
					if (!levelCode.equals("")) {
						challengePlan.setMokuhyoLevelName(PBY_SkillStandardBean.getLevelName(syokusyuCode, senmonCode, levelCode));
					}
					if (!save_plan[34].equals("")) {
						challengePlan.setMokuhyoLevelName2(PBY_SkillStandardBean.getLevelName(save_plan[32], save_plan[33], save_plan[34]));
					}
					if (!save_plan[37].equals("")) {
						challengePlan.setMokuhyoLevelName3(PBY_SkillStandardBean.getLevelName(save_plan[35], save_plan[36], save_plan[37]));
					}

					challengePlan.setGyomuKeiken(save_plan[3]); // �Ɩ��o��
					challengePlan.setKyoikuZyukou(save_plan[4]); // �����u
					challengePlan.setSikakuTokuten1(save_plan[7]); // ���_�P
					challengePlan.setSikakuTokuten2(save_plan[10]); // ���_�Q
					challengePlan.setSikakuTokuten3(save_plan[13]); // ���_�R
					challengePlan.setJikoKeihatu(save_plan[14]); // ���Ȍ[��
					challengePlan.setIdoKibo(save_plan[15]); // �ٓ��Ɋւ����]
					challengePlan.setTuikiJiko(save_plan[16]); // �ǋL����
					challengePlan.setJissiNengappi(save_plan[17]); // �쐬��
					challengePlan.setSikakuMeisyo1(save_plan[19]); // ���i���̂P
					challengePlan.setSikakuLevelMei1(save_plan[20]); // ���i���x���P
					challengePlan.setSikakuMeisyo2(save_plan[21]); // ���i���̂Q
					challengePlan.setSikakuLevelMei2(save_plan[22]); // ���i���x���Q
					challengePlan.setSikakuMeisyo3(save_plan[23]); // ���i���̂R
					challengePlan.setSikakuLevelMei3(save_plan[24]); // ���i���x���R
					// �f�f�ҍ쐬���ɃN���A����f�[�^
					challengePlan.setZyouComment("");
					challengePlan.setSyoninsya("");
					challengePlan.setSyoninsyaKanjiSimei("");
					challengePlan.setSyoninsyaBusyoRyakusyoMei("");
					challengePlan.setSyoninNengappi("");
					challengePlan.setSyoninJikoku("");
					/* ���Z�b�g */
					pdf.setChallengeValue(outDefItem, request.getParameter("H015_Kubun"), challengePlan, challengeResult);
					pdf.setKikanmei(challengebean.getEdit_Nen());
					pdf.setSikakuValue(sikakuData);
					pdf.setSyokumuValue(syokumuData);
					pdf.setAssessmentValue(challengebean.getAssessmentSindan(), challengebean.getAssessmentHyoka());
					pdf.setAssessment2Value(challengebean.getAssessmentSindan2(), challengebean.getAssessmentHyoka2());
					pdf.setAssessment3Value(challengebean.getAssessmentSindan3(), challengebean.getAssessmentHyoka3());
					pdf.setPreChallenge(challengebean.getPreCareerChallengePlan());
					final ByteArrayOutputStream baos = new ByteArrayOutputStream();
					pdf.executePDF(baos);

					/* �X�V���\�b�h�Ăяo�� */
					challengebean.EditChallenge(save_plan, kubun, baos.toByteArray());

					/* ���эX�V�̏ꍇ */
				} else if (kubun.equals(result)) {

					challengeResult.setGyomuKeiken(save_result[0]);
					challengeResult.setKyoikuZyukou(save_result[1]);
					challengeResult.setJikoKeihatu(save_result[2]);
					challengeResult.setIdoKibo(save_result[3]);
					challengeResult.setTuikiJiko(save_result[4]);
					// �f�f�ҍ쐬���ɃN���A����f�[�^
					challengeResult.setZyouComment("");
					challengeResult.setSyoninsya("");
					challengeResult.setSyoninsyaKanjiSimei("");
					challengeResult.setSyoninsyaBusyoRyakusyoMei("");
					challengeResult.setSyoninNengappi("");
					challengeResult.setSyoninJikoku("");

					challengeResult.setSindansyaKanjiSimei(challengebean.getResultData()[43]);
					challengeResult.setSindansyaBusyoRyakusyoMei(challengebean.getResultData()[44]);

					if (sikakuData != null && sikakuData.length >= 1) {
						challengeResult.setSikakuMeisyo1(sikakuData[0][1]);
						challengeResult.setSikakuLevelMei1(sikakuData[0][2]);
						challengeResult.setSikakuTokuten1(sikakuData[0][3]);
						if (sikakuData != null && sikakuData.length >= 2) {
							challengeResult.setSikakuMeisyo2(sikakuData[1][1]);
							challengeResult.setSikakuLevelMei2(sikakuData[1][2]);
							challengeResult.setSikakuTokuten2(sikakuData[1][3]);
							if (sikakuData != null && sikakuData.length >= 3) {
								challengeResult.setSikakuMeisyo3(sikakuData[2][1]);
								challengeResult.setSikakuLevelMei3(sikakuData[2][2]);
								challengeResult.setSikakuTokuten3(sikakuData[2][3]);
							}
						}
					}

					/* ���Z�b�g */
					pdf.setChallengeValue(outDefItem, request.getParameter("H015_Kubun"), challengePlan, challengeResult);
					pdf.setKikanmei(challengebean.getEdit_Nen());
					pdf.setSikakuValue(sikakuData);
					pdf.setSyokumuValue(syokumuData);
					pdf.setAssessmentValue(challengebean.getAssessmentSindan(), challengebean.getAssessmentHyoka());
					pdf.setAssessment2Value(challengebean.getAssessmentSindan2(), challengebean.getAssessmentHyoka2());
					pdf.setAssessment3Value(challengebean.getAssessmentSindan3(), challengebean.getAssessmentHyoka3());
					pdf.setPreChallenge(challengebean.getPreCareerChallengePlan());
					final ByteArrayOutputStream baos = new ByteArrayOutputStream();
					pdf.executePDF(baos);

					/* �X�V���\�b�h�Ăяo�� */
					challengebean.EditChallenge(save_result, kubun, baos.toByteArray());
				}

				/* �Z�b�V�����E�I�u�W�F�N�g���i�[������Bean�̃C���X�^���X���i�[���� */
				session.setAttribute("challenge", challengebean);

				/* ���݂̃��j���[�ɂ��J�ڐ��ݒ� */
				String next_url = "";
				final String gamenLinkID = menuSeigyoBean.getTargetGamenLinkId(); // ���ݕ\�����̃��j���[�̉��ID���擾
				if (gamenLinkID.equalsIgnoreCase("DZZ901") || gamenLinkID.equalsIgnoreCase("DZZ902")) {
					// �L�����A�`�������W���{���̏ꍇ
					next_url = "/servlet/PBB010_CareerChallengeHanteiServlet";
				} else {
					// ����ȊO�̑J��(�L�����A�`�������W��������̑J��)
					next_url = "/view/plan/careerchallenge/VBB060_SelectHistoryMain.jsp";
				}

				Log.debug("next_url:" + next_url);
				final RequestDispatcher rd = this.ctx.getRequestDispatcher(next_url);

				rd.forward(request, response);
				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}
}
