/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */

package jp.co.hisas.career.plan.assessment.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJB;
import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJBHome;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.util.common.PZZ020_MakeSQLUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �T�v: DB�A�N�Z�X���s���A�e�R�[�h�̌����A�X�V�A�폜���s���A�X�e�[�g���XSessionBean�B �g�p���@: �����[�g�C���^�t�F�[�X����āA�N���C�A���gBean����Ăяo���B
 * 
 * </PRE>
 */
public class PBA_AssessmentEJBBean implements SessionBean {

	/** SessionContext�I�u�W�F�N�g */
	private SessionContext my_ssc = null;

	/** �z��ԍ� */
	private int index;

	/** �X�L�����ڃe�[�u�� */
	private static final String tbl03 = HcdbDef.p_skill_komokuTbl;

	/** �B���x�w�W�e�[�u���� */
	private static final String tbl05 = HcdbDef.p_tasseidoTbl;

	/** �X�L���n�B�x�e�[�u���� */
	private static final String tbl06 = HcdbDef.p_skill_jyukutatuTbl;

	/** �B���x�敪�e�[�u�� */
	private static final String tbl09 = HcdbDef.p_tasseido_kubunTbl;

	/** �B���x�敪�ڍ׃e�[�u�� */
	private static final String tbl11 = HcdbDef.p_tasseido_kubun_syosaiTbl;

	/** �A�Z�X�����g�f�f�e�[�u�� */
	private static final String tbl21 = HcdbDef.p_assessment_sindanTbl;

	/** �Ɩ��o���f�f�]���e�[�u�� */
	private static final String tbl22 = HcdbDef.p_gyomu_hyokaTbl;

	/** �X�L���f�f�]���e�[�u�� */
	private static final String tbl23 = HcdbDef.p_skill_hyokaTbl;

	/** �A�Z�X�����g�]���e�[�u�� */
	private static final String tbl24 = HcdbDef.p_assessment_hyokaTbl;

	/** �A�Z�X�����g�]���e�[�u�� */
	private static final String tbl31 = HcdbDef.p_career_challengeTbl;

	/**
	 * �w��̔N�A���̃L�����A�`�������W�v��̗L�����`�F�b�N���A�v�悪����΁A�E��E��啪��E���x����Ԃ��B
	 * @param login_no
	 * @param sindansya_no
	 * @param nen
	 * @param ki
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String[] SearchCareerChallenge(final String login_no, final String sindansya_no, final String nen, final String ki) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* �A�Z�X�����g�����̎w��N�x�L�����A�`�������W�K�p�����̏�Ԃ��擾 */
			String career_challenge_saved = this.getCareerChallengeAssessmentSindanFlg(login_no, sindansya_no, nen, ki);

			/* �����ɑ��݂��Ȃ� */
			if (career_challenge_saved == null) {
				career_challenge_saved = "0";
			}
			/* ���Ɏ��s�ς݂ł��� */
			/* �����߂��ł͂Ȃ� */
			if (!career_challenge_saved.equals("0") && !career_challenge_saved.equals(HcdbDef.flg9)) { // CHG#P-PPE02-004-001
				return new String[0];
			}

			String sql = "SELECT COUNT(" + HcdbDef.p31_column[0] + ") FROM " + PBA_AssessmentEJBBean.tbl31 + " WHERE " + HcdbDef.p31_column[0] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(sindansya_no) + "'" + " AND   " + HcdbDef.p31_column[1] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(nen) + "'" + " AND   "
					+ HcdbDef.p31_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(ki) + "'" + " AND   " + HcdbDef.p31_column[3] + " = '1'" + " AND   " + HcdbDef.p31_column[37] + " = '3'"
					+ " AND   " + HcdbDef.p31_column[38] + " = '1'";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			final String career_challenge_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

			/* �w��̃L�����A�`�������W�v�悪���邩 */
			if (career_challenge_line.equals("0")) {
				return null;
			}

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT " + HcdbDef.ASSESSMENT_CAREERCHARENGE_CHECK_COLUMN[0];
			for (int i = 1; i < HcdbDef.ASSESSMENT_CAREERCHARENGE_CHECK_COLUMN.length; i++) {
				sql = sql + "," + HcdbDef.ASSESSMENT_CAREERCHARENGE_CHECK_COLUMN[i];
			}
			sql = sql + " FROM " + PBA_AssessmentEJBBean.tbl31 + " WHERE " + HcdbDef.p31_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(sindansya_no) + "'" + " AND   "
					+ HcdbDef.p31_column[1] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(nen) + "'" + " AND   " + HcdbDef.p31_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(ki) + "'"
					+ " AND   " + HcdbDef.p31_column[3] + " = '1'" + " AND   " + HcdbDef.p31_column[37] + " = '3'" + " AND   " + HcdbDef.p31_column[38] + " = '1'";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			final String[] career_callenge = new String[HcdbDef.ASSESSMENT_CAREERCHARENGE_CHECK_COLUMN.length];
			while (rs.next()) {
				if (rs.getString(HcdbDef.ASSESSMENT_CAREERCHARENGE_CHECK_COLUMN[0]) != null) {
					for (int i = 0; i < HcdbDef.ASSESSMENT_CAREERCHARENGE_CHECK_COLUMN.length; i++) {
						career_callenge[i] = rs.getString(HcdbDef.ASSESSMENT_CAREERCHARENGE_CHECK_COLUMN[i]);
					}
				}
			}

			Log.method(login_no, "OUT", "");
			return career_callenge;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �w�肳�ꂽ�f�f�҂̏���L�����A�`�������W���Ó��ł��邩�`�F�b�N����
	 * @param login_no
	 * @param sindansya_no
	 * @param nendo
	 * @param ki
	 * @return �f�f�\�O �f�f�s�\�P
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String CheckFirstCareerChallenge(final String login_no, final String sindansya_no, final String nendo, final String ki) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");
		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);
			/* �L�����A�`�������W�������`�F�b�N */
			String sql = "SELECT COUNT(" + HcdbDef.p31_column[0] + ") FROM " + PBA_AssessmentEJBBean.tbl31 + " WHERE " + HcdbDef.p31_column[0] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(sindansya_no) + "'";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			final String career_challenge_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

			/* �A�Z�X�����g�������`�F�b�N */
			sql = "SELECT COUNT(" + HcdbDef.p21_column[0] + ") FROM " + PBA_AssessmentEJBBean.tbl21 + " WHERE " + HcdbDef.p21_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(sindansya_no)
					+ "'" + " AND   " + HcdbDef.p21_column[10] + " = '1'" + " AND NOT (" + HcdbDef.p21_column[11] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(nendo) + "'" + " AND   "
					+ HcdbDef.p21_column[12] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(ki) + "')";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			final String assessment_rireki_line = rs.getString(1).trim();

			/* �A�Z�X�����g�����̐\���t���O���擾 */
			String sindan_flg = this.getCareerChallengeAssessmentSindanFlg(login_no, sindansya_no, nendo, ki);

			/* �A�Z�X�����g�����ɂȂ������ꍇ�A�O�Ƃ��� */
			if (sindan_flg == null) {
				sindan_flg = "0";
			}

			String result;
			if (!assessment_rireki_line.equals("0")) {
				/* ���ɑ��̔N�x�ł͂��߂ẴL�����A�`�������W���s�ς� */
				result = "3";
			} else if (career_challenge_line.equals("0") && sindan_flg.equals("0")) {
				/* �f�f�J�n�\ */
				result = "0";
			} else if (career_challenge_line.equals("0") && sindan_flg.equals("9")) {
				/* ���߂����R�[�h */
				result = "9";
			} else if (career_challenge_line.equals("0")) {
				/* ���ɐ\�����̂��ߐf�f�J�n�s�� */
				result = "1";
			} else {
				/* �L�����A�`�������W�ς� */
				result = "2";
			}

			Log.method(login_no, "OUT", "");
			return result;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �w�肳�ꂽ�E��E��啪��E���x���̑O��������擾����B
	 * @param login_no
	 * @param syoku_code
	 * @param senmon_code
	 * @param level_code
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String[][] SearchZenteiJouken(final String login_no, final String syoku_code, final String senmon_code, final String level_code) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* ���R�[�h�����擾 */
			/* �O��t���O�̂����B���x�敪�����߂� */
			final String sql2 = "SELECT " + HcdbDef.p09_column[0] + " FROM " + PBA_AssessmentEJBBean.tbl09 + " WHERE " + HcdbDef.p09_column[2] + " = '1'";

			String sql = "SELECT COUNT(P05." + HcdbDef.p05_column[0] + ")" + " FROM " + PBA_AssessmentEJBBean.tbl05 + " P05, " + PBA_AssessmentEJBBean.tbl11 + " P11" + " WHERE P05."
					+ HcdbDef.p05_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "'  AND P05." + HcdbDef.p05_column[1] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "'  AND P05." + HcdbDef.p05_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(level_code) + "'  AND P05."
					+ HcdbDef.p05_column[0] + " = P11." + HcdbDef.p11_column[0] + "   AND P05." + HcdbDef.p05_column[1] + " = P11." + HcdbDef.p11_column[1] + "   AND P05." + HcdbDef.p05_column[2]
					+ " = P11." + HcdbDef.p11_column[2] + "   AND P05." + HcdbDef.p05_column[3] + " = P11." + HcdbDef.p11_column[3] + "   AND P05." + HcdbDef.p05_column[3] + " in ( " + sql2 + " )";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			final String zentei_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

			/* �O�������0���̏ꍇnull��Ԃ� */
			if (zentei_line.equals("0")) {
				return null;
			}

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT " + HcdbDef.ASSESSMENT_ZENTEI_COLUMN[0];
			for (int i = 1; i < HcdbDef.ASSESSMENT_ZENTEI_COLUMN.length; i++) {
				sql = sql + ", " + HcdbDef.ASSESSMENT_ZENTEI_COLUMN[i];
			}
			sql = sql + " FROM " + PBA_AssessmentEJBBean.tbl05 + " P05, " + PBA_AssessmentEJBBean.tbl11 + " P11" + " WHERE P05." + HcdbDef.p05_column[0] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "'  AND P05." + HcdbDef.p05_column[1] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "'  AND P05."
					+ HcdbDef.p05_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(level_code) + "'  AND P05." + HcdbDef.p05_column[0] + " = P11." + HcdbDef.p11_column[0] + "   AND P05."
					+ HcdbDef.p05_column[1] + " = P11." + HcdbDef.p11_column[1] + "   AND P05." + HcdbDef.p05_column[2] + " = P11." + HcdbDef.p11_column[2] + "   AND P05." + HcdbDef.p05_column[3]
					+ " = P11." + HcdbDef.p11_column[3] + "   AND P05." + HcdbDef.p05_column[3] + " in ( " + sql2 + " )" + " ORDER BY P05." + HcdbDef.p05_column[3] + " ASC, P05."
					+ HcdbDef.p05_column[4] + " ASC";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			final String[][] zentei_jyoken = new String[Integer.parseInt(zentei_line)][HcdbDef.ASSESSMENT_ZENTEI_COLUMN.length];
			this.index = 0;
			while (rs.next()) {
				if (rs.getString(1) != null) {
					for (int i = 0; i < HcdbDef.ASSESSMENT_ZENTEI_COLUMN.length; i++) {
						zentei_jyoken[this.index][i] = rs.getString(i + 1);
					}
				}
				this.index++;
			}

			Log.method(login_no, "OUT", "");
			return zentei_jyoken;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �w�肳�ꂽ�E��E��啪��E���x���̒B���x�w�W��Ԃ�
	 * @param login_no
	 * @param syoku_code
	 * @param senmon_code
	 * @param level_code
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String[][] SearchTasseidoSihyo(final String login_no, final String syoku_code, final String senmon_code, final String level_code) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* ���x���}�X�^�e�[�u�������� */
			/* ���R�[�h�����擾 */
			String sql = "SELECT COUNT(" + HcdbDef.GYOMUSINDAN_COLUMN[0] + ") FROM " + PBA_AssessmentEJBBean.tbl05 + " P05, " + PBA_AssessmentEJBBean.tbl09 + " P09, " + PBA_AssessmentEJBBean.tbl11
					+ " P11 " + " WHERE P05." + HcdbDef.p05_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "'  AND P05." + HcdbDef.p05_column[1] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "'  AND P05." + HcdbDef.p05_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(level_code) + "'  AND P09."
					+ HcdbDef.p09_column[2] + " = '0'" + "   AND P05." + HcdbDef.p05_column[3] + " = P09." + HcdbDef.p09_column[0] + "   AND P05." + HcdbDef.p05_column[0] + " = P11."
					+ HcdbDef.p11_column[0] + "   AND P05." + HcdbDef.p05_column[1] + " = P11." + HcdbDef.p11_column[1] + "   AND P05." + HcdbDef.p05_column[2] + " = P11." + HcdbDef.p11_column[2]
					+ "   AND P05." + HcdbDef.p05_column[3] + " = P11." + HcdbDef.p11_column[3];

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			final String tasseido_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

			/* �Ɩ��o���f�f�ݖ₪0���̏ꍇnull��Ԃ� */
			if (tasseido_line.equals("0")) {
				return null;
			}

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT " + HcdbDef.GYOMUSINDAN_COLUMN[0];
			for (int i = 1; i < HcdbDef.GYOMUSINDAN_COLUMN.length; i++) {
				sql = sql + "," + HcdbDef.GYOMUSINDAN_COLUMN[i];
			}
			sql = sql + " FROM " + PBA_AssessmentEJBBean.tbl05 + " P05, " + PBA_AssessmentEJBBean.tbl09 + " P09, " + PBA_AssessmentEJBBean.tbl11 + " P11 " + " WHERE P05." + HcdbDef.p05_column[0]
					+ " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "'  AND P05." + HcdbDef.p05_column[1] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "'  AND P05."
					+ HcdbDef.p05_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(level_code) + "'  AND P09." + HcdbDef.p09_column[2] + " = '0'" + "   AND P05." + HcdbDef.p05_column[3]
					+ " = P09." + HcdbDef.p09_column[0] + "   AND P05." + HcdbDef.p05_column[0] + " = P11." + HcdbDef.p11_column[0] + "   AND P05." + HcdbDef.p05_column[1] + " = P11."
					+ HcdbDef.p11_column[1] + "   AND P05." + HcdbDef.p05_column[2] + " = P11." + HcdbDef.p11_column[2] + "   AND P05." + HcdbDef.p05_column[3] + " = P11." + HcdbDef.p11_column[3]
					+ " ORDER BY P05." + HcdbDef.p05_column[3] + " ASC, P05." + HcdbDef.p05_column[4] + " ASC";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			final String[][] tasseido = new String[Integer.parseInt(tasseido_line)][HcdbDef.GYOMUSINDAN_COLUMN.length];
			this.index = 0;
			while (rs.next()) {
				if (rs.getString(1) != null) {
					for (int i = 0; i < HcdbDef.GYOMUSINDAN_COLUMN.length; i++) {
						tasseido[this.index][i] = rs.getString(i + 1);
					}
				}
				this.index++;
			}

			Log.method(login_no, "OUT", "");
			return tasseido;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �w�肳�ꂽ�E��E��啪��E���x���̃X�L���n�B�x���擾
	 * @param login_no
	 * @param syoku_code
	 * @param senmon_code
	 * @param level_code
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String[][] SearchSkillJyukutatudo(final String login_no, final String syoku_code, final String senmon_code, final String level_code) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* ���R�[�h�����擾 */
			String sql = "SELECT COUNT(P06." + HcdbDef.p06_column[0] + ") FROM " + PBA_AssessmentEJBBean.tbl06 + " P06, " + PBA_AssessmentEJBBean.tbl03 + " P03 " + " WHERE P06."
					+ HcdbDef.p06_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "'  AND P06." + HcdbDef.p06_column[1] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "'  AND P06." + HcdbDef.p06_column[3] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(level_code) + "'  AND P03."
					+ HcdbDef.p03_column[0] + " = P06." + HcdbDef.p06_column[0] + "   AND P03." + HcdbDef.p03_column[1] + " = P06." + HcdbDef.p06_column[1] + "   AND P03." + HcdbDef.p03_column[2]
					+ " = P06." + HcdbDef.p06_column[2];

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			final String jyukutatu_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

			/* �X�L���f�f�ݖ₪0���̏ꍇnull��Ԃ� */
			if (jyukutatu_line.equals("0")) {
				return null;
			}

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT " + HcdbDef.SKILLSINDAN_COLUMN[0];
			for (int i = 1; i < HcdbDef.SKILLSINDAN_COLUMN.length; i++) {
				sql = sql + "," + HcdbDef.SKILLSINDAN_COLUMN[i];
			}
			sql = sql + " FROM " + PBA_AssessmentEJBBean.tbl06 + " P06, " + PBA_AssessmentEJBBean.tbl03 + " P03 " + " WHERE P06." + HcdbDef.p06_column[0] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "'  AND P06." + HcdbDef.p06_column[1] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "'  AND P06."
					+ HcdbDef.p06_column[3] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(level_code) + "'  AND P03." + HcdbDef.p03_column[0] + " = P06." + HcdbDef.p06_column[0] + "   AND P03."
					+ HcdbDef.p03_column[1] + " = P06." + HcdbDef.p06_column[1] + "   AND P03." + HcdbDef.p03_column[2] + " = P06." + HcdbDef.p06_column[2] + "  ORDER BY " + HcdbDef.p06_column[2]
					+ " ASC";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			final String[][] skill = new String[Integer.parseInt(jyukutatu_line)][HcdbDef.SKILLSINDAN_COLUMN.length];
			this.index = 0;
			while (rs.next()) {
				if (rs.getString(1) != null) {
					for (int i = 0; i < HcdbDef.SKILLSINDAN_COLUMN.length; i++) {
						skill[this.index][i] = rs.getString(i + 1);
					}
				}
				this.index++;
			}

			Log.method(login_no, "OUT", "");
			return skill;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �w�肳�ꂽ�E��A��啪��A���x���̃A�Z�X�����g�񐔂�Ԃ��B
	 * @param login_no
	 * @param sindansya_no
	 * @param syoku_code
	 * @param senmon_code
	 * @param level_code
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String SearchAssessmentJissiKaisu(final String login_no, final String sindansya_no, final String syoku_code, final String senmon_code, final String level_code) throws SQLException,
			NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* ���x���}�X�^�e�[�u�������� */
			/* ���R�[�h�����擾 */
			final String sql = "SELECT MAX(" + HcdbDef.p21_column[4] + ") FROM " + PBA_AssessmentEJBBean.tbl21 + " WHERE " + HcdbDef.p21_column[0] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(sindansya_no) + "'  AND " + HcdbDef.p21_column[1] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "'  AND "
					+ HcdbDef.p21_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "'  AND " + HcdbDef.p21_column[3] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(level_code)
					+ "'";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			String jissi_kaisu = rs.getString(1);

			if (jissi_kaisu == null) {
				jissi_kaisu = "0";
			}

			Log.method(login_no, "OUT", "");
			return jissi_kaisu;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �A�Z�X�����g�f�f���ʂ��C���T�[�g����
	 * @param login_no
	 * @param p21_save
	 * @param p21_primary_value
	 * @param p21_pdf
	 * @param p22_save
	 * @param p23_save
	 * @return �㒷���F�t���O
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String AddAssessmentSindanKekka(final String login_no, final String[] p21_save, final String[] p21_primary_value, final byte[] p21_pdf, final String[][] p22_save, final String[][] p23_save)
			throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String zyou_syonin_flg = null;
		try {
			boolean check = true;

			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* �L�����A�`�������W�K�p�A�Z�X�����g�̏ꍇ */
			if (p21_save[10].equals("1")) {
				check = false;

				/* �L�����A�`�������W�e�[�u���󋵂����� */
				String sql = "SELECT " + HcdbDef.p31_column[37] + ", " + HcdbDef.p31_column[38] + " FROM " + PBA_AssessmentEJBBean.tbl31 + " WHERE " + HcdbDef.p31_column[0] + " = '"
						+ PZZ020_MakeSQLUtil.sanitizeSQLData(p21_save[0]) + "'" + " AND   " + HcdbDef.p31_column[1] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(p21_save[11]) + "'" + " AND   "
						+ HcdbDef.p31_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(p21_save[12]) + "'" + " AND   " + HcdbDef.p31_column[3] + " = '1'";
				stmt = dbConn.createStatement();

				/* �f�o�b�O���O�̏o�� */
				Log.debug(sql);

				rs = stmt.executeQuery(sql);

				if (rs.next()) {
					/* �����󋵃t���O�擾 */
					final String syori_zyou_flg = rs.getString(HcdbDef.p31_column[37]);

					/* �㒷���F�t���O�擾 */
					zyou_syonin_flg = rs.getString(HcdbDef.p31_column[38]);
				}

				// ��SQL���s�̂��߂Ɉ�xclose
				PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

				/* ���߂ẴL�����A�`�������W�K�p ���́A�㒷���F��������������i�[���� */
				// 20050811�L�����A�`�������W�v��f�[�^�������F�ł��A�Z�X�����g���\�ɂ���
				/*
				 * �A�Z�X�����g��������\���������s���Ă��Ȃ��ꍇ�A�����̃A�Z�X�����g���ʂ����폜����
				 */
				final String sindan_flg = this.getCareerChallengeAssessmentSindanFlg(login_no, p21_save[0], p21_save[11], p21_save[12]);

				/*
				 * �A�Z�X�����g�����ɂȂ� ���́A�\���O�̏�Ԃ̏ꍇ �O��f�f���ʂ��폜����
				 */
				if (sindan_flg == null || sindan_flg.equals("0")) {
					/* �폜�����ݒ� */
					sql = "SELECT syoku_code,senmon_code,level_code,jissi_kaisu " + "FROM P21_assessment_sindan_tbl " + "WHERE sindansya = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(p21_save[0]) + "'"
							+ " AND syoku_code = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(p21_save[1]) + "'" + " AND senmon_code = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(p21_save[2]) + "'"
							+ " AND level_code = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(p21_save[3]) + "'" + " AND career_challenge_flg = '1'" + " AND career_challenge_kikan_mei = '"
							+ PZZ020_MakeSQLUtil.sanitizeSQLData(p21_save[11]) + "'";

					stmt = dbConn.createStatement();

					/* �f�o�b�O���O�̏o�� */
					Log.debug(sql);

					rs = stmt.executeQuery(sql);

					String delete_syoku = null;
					String delete_senmon = null;
					String delete_level = null;
					String delete_jissi = null;

					if (rs.next()) {
						/* �X�V�N�x�A���̊����E��擾 */
						delete_syoku = rs.getString(HcdbDef.p21_column[1]);

						/* �X�V�N�x�A���̊�����啪��擾 */
						delete_senmon = rs.getString(HcdbDef.p21_column[2]);

						/* �X�V�N�x�A���̊������x���擾 */
						delete_level = rs.getString(HcdbDef.p21_column[3]);

						/* �X�V�N�x�A���̊������{�񐔎擾 */
						delete_jissi = rs.getString(HcdbDef.p21_column[4]);
					}

					// ��SQL���s�̂��߂Ɉ�xclose
					PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

					/* �f�f���ʂ����݂���Ȃ�΍폜���� */
					if (delete_syoku != null) {
						/* �����f�f���ʂ��폜 */

						// PBA_SearchPersonEJB
						final PBA_SearchPersonEJBHome delete_home = (PBA_SearchPersonEJBHome) EJBHomeFactory.getInstance().lookup(PBA_SearchPersonEJBHome.class);
						final PBA_SearchPersonEJB delete_userSession = delete_home.create();

						/* �폜���\�b�h���s */
						final String[] syoku_array = { delete_syoku };
						final String[] senmon_array = { delete_senmon };
						final String[] level_array = { delete_level };
						final String[] jissi_array = { delete_jissi };
						final String[] hyokasya_array = { "" };

						/* �f�o�b�O���O���o�� */
						Log.debug("�O��f�f�F" + "�E��" + delete_syoku + "��啪��" + delete_senmon + "���x��" + delete_level + "���{��" + delete_jissi + "���폜");

						delete_userSession.deleteHistory(login_no, p21_save[0], syoku_array, senmon_array, level_array, jissi_array, hyokasya_array, 1);
					}
				}
				check = true;
			}

			if (check) {
				// DB��ʂ��ƂɎ擾����EJB��ؑւ��Ď擾
				final PYF_BlobDBAccessEJBHome blob_home = (PYF_BlobDBAccessEJBHome) EJBHomeFactory.getInstance().lookup(PYF_BlobDBAccessEJBHome.class);
				final PYF_BlobDBAccessEJB blob_userSession = blob_home.create();

				/* �A�Z�X�����g�f�f�e�[�u���C���T�[�g */
				// P21_�A�Z�X�����g�f�f�̃J�����ύX�ɔ���Insert�����̏C��
				int idx = 0;
				int cnt = 0;
				final int size = HcdbDef.p21_column.length - 1;
				final String[] p21_clum = new String[size];
				final String[] p21_data = new String[size];
				for (idx = 0; idx <= size; idx++) {
					// career_challenge_kikan_mei�̏d���΍�(HcdbDef.p21_column���Q��)
					if (idx == 12) {
						continue;
					}
					p21_clum[cnt] = HcdbDef.p21_column[idx];
					p21_data[cnt] = p21_save[idx];
					cnt++;
				}
				blob_userSession.InsertBLOB(login_no, HcdbDef.p_assessment_sindanTbl, p21_clum, p21_data, p21_pdf, HcdbDef.p21_PrimaryKey, p21_primary_value);

				/* �Ɩ��f�f�o���C���T�[�g */
				this.AddGyomuSindanKekka(login_no, p22_save);

				/* �X�L���f�f�o���C���T�[�g */
				this.AddSkillSindanKekka(login_no, p23_save);
			}

			Log.method(login_no, "OUT", "");
			return zyou_syonin_flg;
		} catch (final SQLException e) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, "HJE-0001", e);
			throw e;
		} catch (final NamingException ne) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �A�Z�X�����g�]�����ʂ��i�[����
	 * @param login_no
	 * @param del_key
	 * @param p24_save
	 * @param p24_pdf
	 * @param p24_primary_values
	 * @param p22_save
	 * @param p23_save
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public void UpdateAssessmentHyokaKekka(final String login_no, final String[] del_key, final String[] p24_save, final byte[] p24_pdf, final String[] p24_primary_values, final String[][] p22_save,
			final String[][] p23_save) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");
		try {
			/* �f�f�t���O���������łȂ��ꍇ */
			if (del_key != null) {
				this.DeleteGyomuSkillKekka(login_no, del_key);
			}
			// EJBHome
			final PYF_BlobDBAccessEJBHome blob_home = (PYF_BlobDBAccessEJBHome) EJBHomeFactory.getInstance().lookup(PYF_BlobDBAccessEJBHome.class);
			final PYF_BlobDBAccessEJB blob_userSession = blob_home.create();

			/* �A�Z�X�����g�]���e�[�u���A�b�v�f�[�g */
			blob_userSession.UpdateBLOB(login_no, HcdbDef.p_assessment_hyokaTbl, HcdbDef.UPDATE_HYOKASINDAN_COLUMN, p24_save, p24_pdf, HcdbDef.p24_PrimaryKey, p24_primary_values);

			/* �Ɩ��f�f�o���C���T�[�g */
			this.AddGyomuSindanKekka(login_no, p22_save);

			/* �X�L���f�f�o���C���T�[�g */
			this.AddSkillSindanKekka(login_no, p23_save);

			Log.method(login_no, "OUT", "");
		} catch (final SQLException sqle) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, e);
			throw e;
		}
	}

	/**
	 * �Ɩ��o���f�f�]���e�[�u���ɃC���T�[�g����
	 * @param login_no
	 * @param save
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	private void AddGyomuSindanKekka(final String login_no, final String[][] save) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");
		Connection dbConn = null;
		Statement stmt = null;
		try {

			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			for (int i = 0; i < save.length; i++) {
				/* �C���T�[�g���̍쐬 */
				final String sql = PZZ020_MakeSQLUtil.makeInsertSQL(login_no, PBA_AssessmentEJBBean.tbl22, HcdbDef.p22_column, save[i]);

				stmt = dbConn.createStatement();

				/* �f�o�b�O���O�̏o�� */
				Log.debug(sql);

				stmt.executeUpdate(sql);
			}
			Log.method(login_no, "OUT", "");
		} catch (final SQLException sqle) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, null);
		}
	}

	/**
	 * �X�L���f�f�]���e�[�u���ɃC���T�[�g����
	 * @param login_no
	 * @param save
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	private void AddSkillSindanKekka(final String login_no, final String[][] save) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");
		Connection dbConn = null;
		Statement stmt = null;
		try {

			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			for (int i = 0; i < save.length; i++) {
				/* �C���T�[�g���̍쐬 */
				final String sql = PZZ020_MakeSQLUtil.makeInsertSQL(login_no, PBA_AssessmentEJBBean.tbl23, HcdbDef.p23_column, save[i]);

				stmt = dbConn.createStatement();

				/* �f�o�b�O���O�̏o�� */
				Log.debug(sql);

				stmt.executeUpdate(sql);
			}
			Log.method(login_no, "OUT", "");
		} catch (final SQLException sqle) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, null);
		}
	}

	/**
	 * �]���Ώێ҂̏����擾
	 * @param login_no
	 * @param sindansya
	 * @param syoku_code
	 * @param senmon_code
	 * @param level_code
	 * @param jissi_kaisu
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String[] SearchSindansyaSindanKekka(final String login_no, final String sindansya, final String syoku_code, final String senmon_code, final String level_code, final String jissi_kaisu)
			throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* ���R�[�h�����擾 */
			String sql = "SELECT COUNT(P21." + HcdbDef.p21_column[0] + ") FROM " + PBA_AssessmentEJBBean.tbl21 + " P21, " + PBA_AssessmentEJBBean.tbl24 + " P24 " + " WHERE P21."
					+ HcdbDef.p21_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(sindansya) + "'  AND P21." + HcdbDef.p21_column[1] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code)
					+ "'  AND P21." + HcdbDef.p21_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "'  AND P21." + HcdbDef.p21_column[3] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(level_code) + "'  AND P21." + HcdbDef.p21_column[4] + " = " + jissi_kaisu + "   AND P21." + HcdbDef.p21_column[0] + " = P24."
					+ HcdbDef.p24_column[0] + "   AND P21." + HcdbDef.p21_column[1] + " = P24." + HcdbDef.p24_column[1] + "   AND P21." + HcdbDef.p21_column[2] + " = P24." + HcdbDef.p24_column[2]
					+ "   AND P21." + HcdbDef.p21_column[3] + " = P24." + HcdbDef.p24_column[3] + "   AND P21." + HcdbDef.p21_column[4] + " = P24." + HcdbDef.p24_column[4];

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			final String sindan_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

			/* �擾�ł��Ȃ�������null��Ԃ� */
			if (sindan_line.equals("0")) {
				return null;
			}

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT " + HcdbDef.SINDANSYA_INFO_COLUMN[0];
			for (int i = 1; i < HcdbDef.SINDANSYA_INFO_COLUMN.length; i++) {
				sql = sql + "," + HcdbDef.SINDANSYA_INFO_COLUMN[i];
			}
			sql = sql + " FROM " + PBA_AssessmentEJBBean.tbl21 + " P21, " + PBA_AssessmentEJBBean.tbl24 + " P24 " + " WHERE P21." + HcdbDef.p21_column[0] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(sindansya) + "'  AND P21." + HcdbDef.p21_column[1] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "'  AND P21."
					+ HcdbDef.p21_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "'  AND P21." + HcdbDef.p21_column[3] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(level_code) + "'  AND P21." + HcdbDef.p21_column[4] + " =  " + jissi_kaisu + "   AND P21." + HcdbDef.p21_column[0] + " = P24."
					+ HcdbDef.p24_column[0] + "   AND P21." + HcdbDef.p21_column[1] + " = P24." + HcdbDef.p24_column[1] + "   AND P21." + HcdbDef.p21_column[2] + " = P24." + HcdbDef.p24_column[2]
					+ "   AND P21." + HcdbDef.p21_column[3] + " = P24." + HcdbDef.p24_column[3] + "   AND P21." + HcdbDef.p21_column[4] + " = P24." + HcdbDef.p24_column[4];

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			final String[] sindan = new String[HcdbDef.SINDANSYA_INFO_COLUMN.length];
			this.index = 0;
			while (rs.next()) {
				if (rs.getString(1) != null) {
					for (int i = 0; i < HcdbDef.SINDANSYA_INFO_COLUMN.length; i++) {
						sindan[i] = rs.getString(i + 1);
					}
				}
			}

			Log.method(login_no, "OUT", "");
			return sindan;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �f�f�҂̖��\���̃A�Z�X�����g�����擾����B
	 * @param login_no ���O�C��No
	 * @param sindansya �f�f��
	 * @param syoku_code �E��R�[�h
	 * @param senmon_code ��啪��R�[�h
	 * @param level_code ���x���R�[�h
	 * @param jissi_kaisu ���{��
	 * @return �A�Z�X�����g���
	 * @exception SQLException SQL�G���[�����������ꍇ
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 * @exception Exception ���̑��G���[
	 */
	public String[] SearchSindansyaSindanKekka2(final String login_no, final String sindansya, final String syoku_code, final String senmon_code, final String level_code, final String jissi_kaisu)
			throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* ���R�[�h�����擾 */
			String sql = "SELECT COUNT(P21." + HcdbDef.p21_column[0] + ") FROM " + PBA_AssessmentEJBBean.tbl21 + " P21 LEFT OUTER JOIN " + PBA_AssessmentEJBBean.tbl24 + " P24 ON (" + "       P21."
					+ HcdbDef.p21_column[0] + " = P24." + HcdbDef.p24_column[0] + "   AND P21." + HcdbDef.p21_column[1] + " = P24." + HcdbDef.p24_column[1] + "   AND P21." + HcdbDef.p21_column[2]
					+ " = P24." + HcdbDef.p24_column[2] + "   AND P21." + HcdbDef.p21_column[3] + " = P24." + HcdbDef.p24_column[3] + "   AND P21." + HcdbDef.p21_column[4] + " = P24."
					+ HcdbDef.p24_column[4] + " ) " + " WHERE P21." + HcdbDef.p21_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(sindansya) + "'  AND P21." + HcdbDef.p21_column[1] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "'  AND P21." + HcdbDef.p21_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "'  AND P21."
					+ HcdbDef.p21_column[3] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(level_code) + "'  AND P21." + HcdbDef.p21_column[4] + " = " + jissi_kaisu;

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			final String sindan_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

			/* �擾�ł��Ȃ�������null��Ԃ� */
			if (sindan_line.equals("0")) {
				return null;
			}

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT " + HcdbDef.SINDANSYA_INFO_COLUMN[0];
			for (int i = 1; i < HcdbDef.SINDANSYA_INFO_COLUMN.length; i++) {
				sql = sql + "," + HcdbDef.SINDANSYA_INFO_COLUMN[i];
			}
			sql = sql + " FROM " + PBA_AssessmentEJBBean.tbl21 + " P21 LEFT OUTER JOIN " + PBA_AssessmentEJBBean.tbl24 + " P24 ON (" + "       P21." + HcdbDef.p21_column[0] + " = P24."
					+ HcdbDef.p24_column[0] + "   AND P21." + HcdbDef.p21_column[1] + " = P24." + HcdbDef.p24_column[1] + "   AND P21." + HcdbDef.p21_column[2] + " = P24." + HcdbDef.p24_column[2]
					+ "   AND P21." + HcdbDef.p21_column[3] + " = P24." + HcdbDef.p24_column[3] + "   AND P21." + HcdbDef.p21_column[4] + " = P24." + HcdbDef.p24_column[4] + " ) " + " WHERE P21."
					+ HcdbDef.p21_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(sindansya) + "'  AND P21." + HcdbDef.p21_column[1] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code)
					+ "'  AND P21." + HcdbDef.p21_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "'  AND P21." + HcdbDef.p21_column[3] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(level_code) + "'  AND P21." + HcdbDef.p21_column[4] + " = " + jissi_kaisu;

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			final String[] sindan = new String[HcdbDef.SINDANSYA_INFO_COLUMN.length];
			this.index = 0;
			while (rs.next()) {
				if (rs.getString(1) != null) {
					for (int i = 0; i < HcdbDef.SINDANSYA_INFO_COLUMN.length; i++) {
						sindan[i] = rs.getString(i + 1);
					}
				}
			}

			Log.method(login_no, "OUT", "");
			return sindan;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �]�����g�p �f�f�҂̋Ɩ��o���f�f���ʂ̎擾
	 * @param login_no
	 * @param search_key
	 * @param search_value
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String[] SearchGyomuSindanKekka(final String login_no, final String[] search_key, final String[] search_value) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* ���R�[�h�����擾 */
			String sql = "SELECT COUNT(" + HcdbDef.p22_column[0] + ") FROM " + PBA_AssessmentEJBBean.tbl22;

			/* WHERE�� */
			String where_ku = " WHERE ";
			if (PZZ020_MakeSQLUtil.getColumnTypeCheck(search_key[0]).equals("1")) {
				where_ku = where_ku + search_key[0] + " = " + search_value[0];
			} else {
				where_ku = where_ku + search_key[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(search_value[0]) + "'";
			}

			for (int i = 1; i < search_key.length; i++) {
				if (PZZ020_MakeSQLUtil.getColumnTypeCheck(search_key[i]).equals("1")) {
					where_ku = where_ku + " AND " + search_key[i] + " = " + search_value[i];
				} else {
					where_ku = where_ku + " AND " + search_key[i] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(search_value[i]) + "'";
				}
			}
			/* WHERE��̌��� */
			sql = sql + where_ku;

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			final String gyomu_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT " + HcdbDef.p22_column[9] + " FROM " + PBA_AssessmentEJBBean.tbl22;

			/* WHERE��̌��� */
			sql = sql + where_ku;

			/* ORDER BY��̌��� */
			sql = sql + "  ORDER BY " + HcdbDef.p22_column[7] + " ASC, " + HcdbDef.p22_column[8] + " ASC";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			final String[] gyomu_sindan = new String[Integer.parseInt(gyomu_line)];
			this.index = 0;
			while (rs.next()) {
				if (rs.getString(HcdbDef.p22_column[9]) != null) {
					gyomu_sindan[this.index] = rs.getString(HcdbDef.p22_column[9]);
				}
				this.index++;
			}

			Log.method(login_no, "OUT", "");
			return gyomu_sindan;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �f�f�҂̃X�L���f�f�ݖ⌋�ʂ̎擾
	 * @param login_no
	 * @param search_key
	 * @param search_value
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String[] SearchSkillSindanKekka(final String login_no, final String[] search_key, final String[] search_value) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* ���R�[�h�����擾 */
			String sql = "SELECT COUNT(" + HcdbDef.p23_column[0] + ") FROM " + PBA_AssessmentEJBBean.tbl23;

			/* WHERE�� */
			String where_ku = " WHERE ";
			if (PZZ020_MakeSQLUtil.getColumnTypeCheck(search_key[0]).equals("1")) {
				where_ku = where_ku + search_key[0] + " = " + search_value[0];
			} else {
				where_ku = where_ku + search_key[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(search_value[0]) + "'";
			}

			for (int i = 1; i < search_key.length; i++) {
				if (PZZ020_MakeSQLUtil.getColumnTypeCheck(search_key[i]).equals("1")) {
					where_ku = where_ku + " AND " + search_key[i] + " = " + search_value[i];
				} else {
					where_ku = where_ku + " AND " + search_key[i] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(search_value[i]) + "'";
				}
			}

			/* WHERE��̌��� */
			sql = sql + where_ku;

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			final String skill_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT " + HcdbDef.p23_column[8] + " FROM " + PBA_AssessmentEJBBean.tbl23;

			/* WHERE��̌��� */
			sql = sql + where_ku;

			/* ORDER BY��̌��� */
			sql = sql + "  ORDER BY " + HcdbDef.p23_column[7] + " ASC";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			final String[] skill_sindan = new String[Integer.parseInt(skill_line)];
			this.index = 0;
			while (rs.next()) {
				if (rs.getString(HcdbDef.p23_column[8]) != null) {
					skill_sindan[this.index] = rs.getString(HcdbDef.p23_column[8]);
				}
				this.index++;
			}

			Log.method(login_no, "OUT", "");
			return skill_sindan;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �w�肳�ꂽ���̃A�Z�X�����g�����̐f�f�\���t���O���Q�Ƃ���
	 * @param login_no
	 * @param sindansya_no
	 * @param nendo
	 * @param ki
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	private String getCareerChallengeAssessmentSindanFlg(final String login_no, final String sindansya_no, final String nendo, final String ki) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");
		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* �A�Z�X�����g�������`�F�b�N */
			String sql = "SELECT COUNT(" + HcdbDef.p24_column[9] + ") FROM " + PBA_AssessmentEJBBean.tbl21 + " P21," + PBA_AssessmentEJBBean.tbl24 + " P24" + " WHERE P21." + HcdbDef.p21_column[0]
					+ " = P24." + HcdbDef.p24_column[0] + " AND   P21." + HcdbDef.p21_column[1] + " = P24." + HcdbDef.p24_column[1] + " AND   P21." + HcdbDef.p21_column[2] + " = P24."
					+ HcdbDef.p24_column[2] + " AND   P21." + HcdbDef.p21_column[3] + " = P24." + HcdbDef.p24_column[3] + " AND   P21." + HcdbDef.p21_column[4] + " = P24." + HcdbDef.p24_column[4]
					+ " AND   P21." + HcdbDef.p21_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(sindansya_no) + "'" + " AND   P21." + HcdbDef.p21_column[10] + " = '1'" + " AND   P21."
					+ HcdbDef.p21_column[11] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(nendo) + "'" + " AND   P21." + HcdbDef.p21_column[12] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(ki)
					+ "'";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			final String sindan_flg_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

			/* �A�Z�X�����g�����ɂ���L�����A�`�������W�K�p�̐\����Ԃ��`�F�b�N */
			String sindan_flg = null;
			if (!sindan_flg_line.equals("0")) {
				sql = "SELECT " + HcdbDef.p24_column[9] + " FROM " + PBA_AssessmentEJBBean.tbl21 + " P21," + PBA_AssessmentEJBBean.tbl24 + " P24" + " WHERE P21." + HcdbDef.p21_column[0] + " = P24."
						+ HcdbDef.p24_column[0] + " AND   P21." + HcdbDef.p21_column[1] + " = P24." + HcdbDef.p24_column[1] + " AND   P21." + HcdbDef.p21_column[2] + " = P24." + HcdbDef.p24_column[2]
						+ " AND   P21." + HcdbDef.p21_column[3] + " = P24." + HcdbDef.p24_column[3] + " AND   P21." + HcdbDef.p21_column[4] + " = P24." + HcdbDef.p24_column[4] + " AND   P21."
						+ HcdbDef.p21_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(sindansya_no) + "'" + " AND   P21." + HcdbDef.p21_column[10] + " = '1'" + " AND   P21."
						+ HcdbDef.p21_column[11] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(nendo) + "'" + " AND   P21." + HcdbDef.p21_column[12] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(ki)
						+ "'";

				stmt = dbConn.createStatement();

				/* �f�o�b�O���O�̏o�� */
				Log.debug(sql);

				rs = stmt.executeQuery(sql);

				rs.next();
				sindan_flg = rs.getString(1).trim();
			}

			Log.method(login_no, "OUT", "");
			return sindan_flg;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �Ɩ��o���f�f���ʁA�X�L���f�f���ʂ��폜����B
	 * @param login_no
	 * @param del
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	private void DeleteGyomuSkillKekka(final String login_no, final String[] del) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");
		Connection dbConn = null;
		Statement stmt = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* �Ɩ��o���f�f�f�[�^delete���쐬 */
			String sql = PZZ020_MakeSQLUtil.makeDeleteSQL(login_no, PBA_AssessmentEJBBean.tbl22, HcdbDef.DELETE_GYOMU_SKILL_KEKKA_COLUMN, del);

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			stmt.executeUpdate(sql);

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, null);

			/* �X�L���f�f�f�[�^delete���쐬 */
			sql = PZZ020_MakeSQLUtil.makeDeleteSQL(login_no, PBA_AssessmentEJBBean.tbl23, HcdbDef.DELETE_GYOMU_SKILL_KEKKA_COLUMN, del);

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			stmt.executeUpdate(sql);

			Log.method(login_no, "OUT", "");
		} catch (final SQLException sqle) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			/* ���[���o�b�N���s�� */
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, null);
		}
	}

	/**
	 * �A�Z�X�����g�f�f�̍X�V���s���B
	 * @param login_no
	 * @param p21_save
	 * @param p21_primary_value
	 * @param p21_pdf
	 * @param p22_save
	 * @param p23_save
	 * @param upd_hyokasya
	 * @return �㒷���F�t���O
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */

	public String UpdAssessmentSindanKekka(final String login_no, final String[] p21_save, final String[] p21_primary_value, final byte[] p21_pdf, final String[][] p22_save,
			final String[][] p23_save, final String upd_hyokasya) throws SQLException, NamingException, Exception {

		// ���O�o��
		Log.method(login_no, "IN", "");

		try {
			// �Ώۃ��R�[�h�폜
			// PBA_SearchPersonEJB
			final PBA_SearchPersonEJBHome del_home = (PBA_SearchPersonEJBHome) EJBHomeFactory.getInstance().lookup(PBA_SearchPersonEJBHome.class);
			final PBA_SearchPersonEJB del_userSession = del_home.create();

			// �폜�����̃Z�b�g
			final String[] syoku_array = { p21_save[1] };
			final String[] senmon_array = { p21_save[2] };
			final String[] level_array = { p21_save[3] };
			final String[] jissi_array = { p21_save[4] };
			final String[] hyokasya_array = { upd_hyokasya };

			// �f�o�b�O���O���o��
			Log.debug("�O��f�f�F" + "�E��" + p21_save[1] + "��啪��" + p21_save[2] + "���x��" + p21_save[3] + "���{��" + p21_save[4] + "�]����" + upd_hyokasya + "���폜");

			int return_code_del = 0;
			String zyou_syonin_flg = "";
			return_code_del = del_userSession.deleteHistory(login_no, p21_save[0], syoku_array, senmon_array, level_array, jissi_array, hyokasya_array, 1);

			// �폜�G���[
			if (return_code_del == 0) {
				return "-1";
			}

			// Insert����
			zyou_syonin_flg = this.AddAssessmentSindanKekka(login_no, p21_save, p21_primary_value, p21_pdf, p22_save, p23_save);

			Log.method(login_no, "OUT", "");

			return zyou_syonin_flg;

		} catch (final SQLException e) {
			// Rollback
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, e);
			throw e;
		} catch (final NamingException e) {
			// Rollback
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, e);
			throw e;
		} catch (final Exception e) {
			// Rollback
			this.my_ssc.setRollbackOnly();
			Log.error(login_no, e);
			throw e;
		}
	}

	/**
	 * �w�肳�ꂽ���̃A�Z�X�����g���������Q�Ƃ���
	 * @param login_no
	 * @param sindansya_no
	 * @param nendo
	 * @param ki
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String[] getDataForChallenge(final String login_no, final String sindansya_no, final String nendo, final String ki) throws SQLException, NamingException, Exception {
		// Log�o��
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			// �A�Z�X�����g�����̑��݃`�F�b�N
			String sql = "SELECT COUNT( * ) FROM " + PBA_AssessmentEJBBean.tbl21 + " P21," + PBA_AssessmentEJBBean.tbl24 + " P24" + " WHERE P21." + HcdbDef.p21_column[0] + " = P24."
					+ HcdbDef.p24_column[0] + " AND   P21." + HcdbDef.p21_column[1] + " = P24." + HcdbDef.p24_column[1] + " AND   P21." + HcdbDef.p21_column[2] + " = P24." + HcdbDef.p24_column[2]
					+ " AND   P21." + HcdbDef.p21_column[3] + " = P24." + HcdbDef.p24_column[3] + " AND   P21." + HcdbDef.p21_column[4] + " = P24." + HcdbDef.p24_column[4] + " AND   P21."
					+ HcdbDef.p21_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(sindansya_no) + "'" + " AND   P21." + HcdbDef.p21_column[10] + " = '1'" + " AND   P21."
					+ HcdbDef.p21_column[11] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(nendo) + "'" + " AND   P21." + HcdbDef.p21_column[12] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(ki)
					+ "'";

			stmt = dbConn.createStatement();

			// �f�o�b�O���O�̏o��
			Log.debug(sql.toUpperCase());

			rs = stmt.executeQuery(sql.toUpperCase());

			rs.next();
			final int count = rs.getInt(1);

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

			// �A�Z�X�����g�����̐f�f�t���O�A���{�񐔁A�]���ҏ����擾����
			String[] assessData = null;
			if (count != 0) {
				assessData = new String[3];
				sql = "SELECT " + "P24." + HcdbDef.p24_column[9] + ", " + "P24." + HcdbDef.p24_column[4] + ", " + "P24." + HcdbDef.p24_column[5] + " FROM " + PBA_AssessmentEJBBean.tbl21 + " P21,"
						+ PBA_AssessmentEJBBean.tbl24 + " P24" + " WHERE P21." + HcdbDef.p21_column[0] + " = P24." + HcdbDef.p24_column[0] + " AND   P21." + HcdbDef.p21_column[1] + " = P24."
						+ HcdbDef.p24_column[1] + " AND   P21." + HcdbDef.p21_column[2] + " = P24." + HcdbDef.p24_column[2] + " AND   P21." + HcdbDef.p21_column[3] + " = P24." + HcdbDef.p24_column[3]
						+ " AND   P21." + HcdbDef.p21_column[4] + " = P24." + HcdbDef.p24_column[4] + " AND   P21." + HcdbDef.p21_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(sindansya_no)
						+ "'" + " AND   P21." + HcdbDef.p21_column[10] + " = '1'" + " AND   P21." + HcdbDef.p21_column[11] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(nendo) + "'" + " AND   P21."
						+ HcdbDef.p21_column[12] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(ki) + "'";

				stmt = dbConn.createStatement();

				// �f�o�b�O���O�̏o��
				Log.debug(sql.toUpperCase());

				rs = stmt.executeQuery(sql.toUpperCase());

				rs.next();
				for (int i = 0; i < 3; i++) {
					assessData[i] = rs.getString(i + 1).trim();
				}
			}

			Log.method(login_no, "OUT", "");
			return assessData;

		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �X�R�A�K�C�h���Q�Ƃ���
	 * @param login_no
	 * @param syoku_code
	 * @param senmon_code
	 * @param level_code
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String SearchScoreGaido(final String login_no, final String syoku_code, final String senmon_code, final String level_code) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			dbConn = PZZ040_SQLUtility.getConnection(login_no);
			/* ���R�[�h�����擾 */
			String sql = "SELECT COUNT(LEVEL_CODE) FROM CKM_SCORE_KYOTU WHERE LEVEL_CODE = ?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.setString(1, level_code);

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = pstmt.executeQuery();
			rs.next();
			final String zentei_cnt = rs.getString(1);

			PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);

			/* 0���̏ꍇ��Null�Ԃ� */
			if (zentei_cnt.equals("0")) {
				return null;
			}

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT GAIDO_SETUMEI FROM CKM_SCORE_KYOTU  WHERE LEVEL_CODE = ?";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.setString(1, level_code);

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = pstmt.executeQuery();
			rs.next();
			String scoregaido = null;
			scoregaido = rs.getString(1);

			Log.method(login_no, "OUT", "");
			return scoregaido;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * �X�R�A���Q�Ƃ���
	 * @param login_no
	 * @param sindansyaid
	 * @param syoku_code
	 * @param senmon_code
	 * @param level_code
	 * @param skill_list
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public ArrayList SearchSkillsScore(final String login_no, final String sindansyaid, final String syoku_code, final String senmon_code, final String level_code, final String[][] skill_list, final ArrayList groupCodeAll)
			throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;

		final ArrayList skillList = new ArrayList();

		try {

			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			String[] userGroup = (String[])groupCodeAll.get(0);

			// ��ٽ޲�����غ��ނɕR�Â��ް����Q��
			for (int i = 0; i < skill_list.length; i++) {
				
				//�ݖ�ɕR�t���X�L���Y�C���x���g���̃X�L�����X�g
				final ArrayList SetumonList = new ArrayList();
				
				sql = "SELECT COUNT(LEAF.SKILL_CODE) "
					+ "FROM "
					+ "( "
					+ " SELECT * "
					+ " FROM ( "
					+ "  SELECT MAIN.SKILL_CODE, MAIN.SKILL_MEI, MAIN.KAI_SKILL_UMU, NVL(GROUP_CODE,'')GROUP_CODE, MAIN.KAISOU, JOUI_SKILLCODE "
					+ "  FROM T40_C_SKILL_YOSO_TBL MAIN "
					+ "  WHERE GROUP_CODE = ? "
					+ "   OR EXISTS "
					+ "    (SELECT * FROM T40_C_SKILL_YOSO_TBL DEF WHERE DEF.GROUP_CODE = ? AND MAIN.GROUP_CODE = DEF.GROUP_CODE AND MAIN.SKILL_CODE = DEF.SKILL_CODE "
					+ "     AND NOT EXISTS (SELECT * FROM T40_C_SKILL_YOSO_TBL BUMON WHERE BUMON.GROUP_CODE = ? AND DEF.SKILL_CODE = BUMON.SKILL_CODE) "
					+ "    ) "
					+ " ) "
					+ " START WITH KAISOU = '1' "
					+ " CONNECT BY PRIOR SKILL_CODE = JOUI_SKILLCODE AND PRIOR KAI_SKILL_UMU = '1' "
					+ " ORDER SIBLINGS BY SKILL_CODE "
					+ ")LEAF "
					+ ", CJM_SKILLSINVENTORY_GROUP GRP "
					+ ", (SELECT * FROM CKG_SKILLSINVENTORY_KANREN WHERE SYOKU_CODE = ? AND SENMON_CODE = ? AND SKILL_CODE = ? AND LEVEL_CODE = ? AND GROUP_CODE IN (?,?)) SKILL "
					+ "WHERE LEAF.GROUP_CODE = GRP.GROUP_CODE "
					+ " AND LEAF.SKILL_CODE = SKILL.SKILLS_INVENTORY_CODE "
					+ " AND LEAF.GROUP_CODE = SKILL.GROUP_CODE ";
				pstmt = dbConn.prepareStatement(sql);
				int paramCnt = 1;
				/* ���R�[�h�����擾 */
				pstmt.setString(paramCnt++, userGroup[0]);
				pstmt.setString(paramCnt++, (String)groupCodeAll.get(1));
				pstmt.setString(paramCnt++, userGroup[0]);
				pstmt.setString(paramCnt++, syoku_code);
				pstmt.setString(paramCnt++, senmon_code);
				pstmt.setString(paramCnt++, skill_list[i][0]);
				pstmt.setString(paramCnt++, level_code);
				pstmt.setString(paramCnt++, userGroup[0]);
				pstmt.setString(paramCnt++, (String)groupCodeAll.get(1));
				rs = pstmt.executeQuery();
				/* �f�o�b�O���O�̏o�� */
				Log.debug(sql);

				rs.next();
				String zentei_cnt = rs.getString(1);

				PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);

				final String[] tmp = new String[2];
				if (zentei_cnt.equals("0")) {
					tmp[0] = "1";
					tmp[1] = "1";
				} else {
					sql = "SELECT LEAF.SKILL_CODE, LEAF.SKILL_MEI, LEAF.KAI_SKILL_UMU, NVL(LEAF.GROUP_CODE,'')GROUP_CODE, GRP.KANRI_MEISYO, CASE WHEN SKILL.OMOMI IS NULL then 1 WHEN SKILL.OMOMI = 0 then 1 ELSE SKILL.OMOMI END OMOMI "
						+ "FROM "
						+ "( "
						+ " SELECT * "
						+ " FROM ( "
						+ "  SELECT MAIN.SKILL_CODE, MAIN.SKILL_MEI, MAIN.KAI_SKILL_UMU, NVL(GROUP_CODE,'')GROUP_CODE, MAIN.KAISOU, JOUI_SKILLCODE "
						+ "  FROM T40_C_SKILL_YOSO_TBL MAIN "
						+ "  WHERE GROUP_CODE = ? "
						+ "   OR EXISTS "
						+ "    (SELECT * FROM T40_C_SKILL_YOSO_TBL DEF WHERE DEF.GROUP_CODE = ? AND MAIN.GROUP_CODE = DEF.GROUP_CODE AND MAIN.SKILL_CODE = DEF.SKILL_CODE "
						+ "     AND NOT EXISTS (SELECT * FROM T40_C_SKILL_YOSO_TBL BUMON WHERE BUMON.GROUP_CODE = ? AND DEF.SKILL_CODE = BUMON.SKILL_CODE) "
						+ "    ) "
						+ " ) "
						+ " START WITH KAISOU = '1' "
						+ " CONNECT BY PRIOR SKILL_CODE = JOUI_SKILLCODE AND PRIOR KAI_SKILL_UMU = '1' "
						+ " ORDER SIBLINGS BY SKILL_CODE "
						+ ")LEAF "
						+ ", CJM_SKILLSINVENTORY_GROUP GRP "
						+ ", (SELECT * FROM CKG_SKILLSINVENTORY_KANREN WHERE SYOKU_CODE = ? AND SENMON_CODE = ? AND SKILL_CODE = ? AND LEVEL_CODE = ? AND GROUP_CODE IN (?,?)) SKILL "
						+ "WHERE LEAF.GROUP_CODE = GRP.GROUP_CODE "
						+ " AND LEAF.SKILL_CODE = SKILL.SKILLS_INVENTORY_CODE "
						+ " AND LEAF.GROUP_CODE = SKILL.GROUP_CODE ";
					pstmt = dbConn.prepareStatement(sql);
					int paramCnt2 = 1;
					/* ���R�[�h�����擾 */
					pstmt.setString(paramCnt2++, userGroup[0]);
					pstmt.setString(paramCnt2++, (String)groupCodeAll.get(1));
					pstmt.setString(paramCnt2++, userGroup[0]);
					pstmt.setString(paramCnt2++, syoku_code);
					pstmt.setString(paramCnt2++, senmon_code);
					pstmt.setString(paramCnt2++, skill_list[i][0]);
					pstmt.setString(paramCnt2++, level_code);
					pstmt.setString(paramCnt2++, userGroup[0]);
					pstmt.setString(paramCnt2++, (String)groupCodeAll.get(1));
					rs = pstmt.executeQuery();
					/* �f�o�b�O���O�̏o�� */
					Log.debug(sql);

					String[] tmp2 = new String[8];
					while (rs.next()) {
						tmp2 = new String[8];
						tmp2[0] = rs.getString(1);
						tmp2[1] = rs.getString(2);
						tmp2[2] = rs.getString(3);
						tmp2[3] = rs.getString(4);
						tmp2[4] = rs.getString(5);
						tmp2[7] = String.valueOf(rs.getDouble(6));
						SetumonList.add(tmp2);
					}
					
					PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);

					int omomiCnt = 1;
					// �d�݂𓥂܂��ăX�R�A���v�Z����
					double score_s_lvl = 0;
					double score_s_omm = 0;
					double score_h_lvl = 0;
					double score_h_omm = 0;
					// �X�L���Y�C���x���g���̑I��l(�f�f�ҁA�]����)���擾����
					for (int cnt = 0; cnt < SetumonList.size(); cnt++) {
						final String[] skillcd = (String[]) SetumonList.get(cnt);

						sql = "SELECT COUNT(CJS.SKILL_CODE) FROM CJS_SKILLSINVENTORY CJS WHERE CJS.SKILL_CODE = ? AND CJS.SHINDANSYA_ID = ? AND CJS.GROUP_CODE = ?";
						pstmt = dbConn.prepareStatement(sql);
						pstmt.setString(1, skillcd[0]);
						pstmt.setString(2, sindansyaid);
						pstmt.setString(3, skillcd[3]);
						rs = pstmt.executeQuery();
						rs.next();
						zentei_cnt = rs.getString(1).trim();

						PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);
						
						if (zentei_cnt.equals("0")) {
							skillcd[5] = (String) ReadFile.paramMapData.get("DBY004");
							skillcd[6] = (String) ReadFile.paramMapData.get("DBY004");
						} else {
							sql = "SELECT NVL(CJS.SHINDANSYA_LEVEL,''), NVL(CJS.hYOKASYA_LEVEL ,'') "
								+ " FROM CJS_SKILLSINVENTORY CJS WHERE CJS.SKILL_CODE = ? AND CJS.SHINDANSYA_ID = ? AND CJS.GROUP_CODE = ?";
							pstmt = dbConn.prepareStatement(sql);
							pstmt.setString(1, skillcd[0]);
							pstmt.setString(2, sindansyaid);
							pstmt.setString(3, skillcd[3]);
							rs = pstmt.executeQuery();

							while (rs.next()) {
								// �f�f��
								if (rs.getString(1) != null) {
									score_s_lvl += Double.valueOf(rs.getString(1)).doubleValue() * Double.valueOf(skillcd[7]).doubleValue();
									score_s_omm += Double.valueOf(skillcd[7]).doubleValue() * 5;
								}

								// �]����
								if (rs.getString(2) != null) {
									score_h_lvl += Double.valueOf(rs.getString(2)).doubleValue() * Double.valueOf(skillcd[7]).doubleValue();
									score_h_omm += Double.valueOf(skillcd[7]).doubleValue() * 5;
								}

								skillcd[5] = rs.getString(1);
								skillcd[6] = rs.getString(2);
								omomiCnt++;
							}
							
							PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);

						}
						//�X�L���Y�C���x���g���O���[�v�R�[�h���g�p���̃O���[�v�R�[�h�ɒu��������B
						//����ȍ~�A�X�L���Y�C���x���g���ݖ₲�Ƃ̃O���[�v����ʂ������Ȃ���
						skillcd[3] = userGroup[0];
						skillcd[4] = userGroup[1];
					}

					// �v�Z�J�n
					tmp[0] = "1";
					tmp[1] = "1";

					if (score_s_lvl != 0 && score_s_omm != 0) {
						tmp[0] = String.valueOf(score_s_lvl / score_s_omm * 5);
					}

					if (score_h_lvl != 0 && score_h_omm != 0) {
						tmp[1] = String.valueOf(score_h_lvl / score_h_omm * 5);
					}
				}
				skillList.add(tmp);
				PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);
			}
			Log.method(login_no, "OUT", "");
			return skillList;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * �f�f�ґg�D�R�[�h���Q�Ƃ���
	 * @param login_no
	 * @param sindansyaid
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public ArrayList SearchSindanSosiki(final String login_no, final String sindansyaid) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		final ArrayList sindansyaList = new ArrayList();
		try {
			dbConn = PZZ040_SQLUtility.getConnection(login_no);
			/* ���R�[�h�����擾 */
			String sql = "SELECT COUNT(SOSIKI_CODE) FROM T01_PERSONAL_TBL WHERE SIMEI_NO = ? ";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.setString(1, sindansyaid);

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = pstmt.executeQuery();
			rs.next();
			final String zentei_cnt = rs.getString(1);
			PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);
			/* 0���̏ꍇ��Null�Ԃ� */
			if (zentei_cnt.equals("0")) {
				return null;
			}

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT SOSIKI_CODE,YAKUSYOKU_CODE,SYOKUI_CODE FROM T01_PERSONAL_TBL WHERE SIMEI_NO = ? AND HONMU_FLG = '1' AND GENSYOKU_TAISYOKU_FLG = '1'";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.setString(1, sindansyaid);

			rs = pstmt.executeQuery();
			rs.next();

			final String[] tmp = new String[3];
			tmp[0] = rs.getString(1);
			tmp[1] = rs.getString(2);
			tmp[2] = rs.getString(3);
			sindansyaList.add(tmp);

			Log.method(login_no, "OUT", "");
			return sindansyaList;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, pstmt, rs);
		}
	}

	// -- 20061227 K.takagi Add End --

	/**
	 * �w��̔N�A���̃L�����A�`�������W�v��̗L�����`�F�b�N���A�v�悪����΁A�E��E��啪��E���x����Ԃ��B
	 * @param login_no
	 * @param sindansya_no
	 * @param nen
	 * @param ki
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String[] SearchCareerChallengePassAll(final String login_no, final String sindansya_no, final String nen, final String ki, final String syokucode, final String senmoncode,
			final String levelcode, final String jissi_kaisu) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* �A�Z�X�����g�����̎w��N�x�L�����A�`�������W�K�p�����̏�Ԃ��擾 */
			String career_challenge_saved = this.getCareerChallengeAssessmentSindanFlgPassAll(login_no, sindansya_no, nen, ki, syokucode, senmoncode, levelcode, jissi_kaisu);

			/* �����ɑ��݂��Ȃ� */
			if (career_challenge_saved == null) {
				career_challenge_saved = "0";
			}
			/* ���Ɏ��s�ς݂ł��� */
			/* �����߂��ł͂Ȃ� */
			if (!career_challenge_saved.equals("0") && !career_challenge_saved.equals(HcdbDef.flg9)) { // CHG#P-PPE02-004-001
				return new String[0];
			}
			String sql = "SELECT COUNT(" + HcdbDef.p31_column[0] + ") FROM " + PBA_AssessmentEJBBean.tbl31 + " WHERE " + HcdbDef.p31_column[0] + " = ? AND " + HcdbDef.p31_column[1] + " = ? AND "
					+ HcdbDef.p31_column[2] + " = ? AND " + HcdbDef.p31_column[3] + " = '1'" + " AND   " + HcdbDef.p31_column[37] + " = '3'" + " AND " + HcdbDef.p31_column[38] + " = '1' ";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.setString(1, sindansya_no);
			pstmt.setString(2, nen);
			pstmt.setString(3, ki);

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = pstmt.executeQuery();
			rs.next();
			final String career_challenge_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);

			/* �w��̃L�����A�`�������W�v�悪���邩 */
			if (career_challenge_line.equals("0")) {
				return null;
			}

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT MOKUHYO_SYOKU, MOKUHYO_SENMON, MOKUHYO_LEVEL_CODE, MOKUHYO_SYOKU_2, MOKUHYO_SENMON_2, MOKUHYO_LEVEL_CODE_2, "
					+ "MOKUHYO_SYOKU_3, MOKUHYO_SENMON_3, MOKUHYO_LEVEL_CODE_3 FROM " + PBA_AssessmentEJBBean.tbl31 + " WHERE " + HcdbDef.p31_column[0] + " = ? AND " + HcdbDef.p31_column[1]
					+ " = ? AND " + HcdbDef.p31_column[2] + " = ? AND " + HcdbDef.p31_column[3] + " = '1'" + " AND   " + HcdbDef.p31_column[37] + " = '3'" + " AND " + HcdbDef.p31_column[38]
					+ " = '1' ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.setString(1, sindansya_no);
			pstmt.setString(2, nen);
			pstmt.setString(3, ki);
			rs = pstmt.executeQuery();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			/* �Y���f�[�^���擾 */
			final String[] career_callenge = new String[3];
			while (rs.next()) {
				if (rs.getString(1) != null) {
					if (syokucode.equals(rs.getString(1)) && senmoncode.equals(rs.getString(2)) && levelcode.equals(rs.getString(3))) {
						career_callenge[0] = rs.getString(1);
						career_callenge[1] = rs.getString(2);
						career_callenge[2] = rs.getString(3);
					}
				}
				if (rs.getString(3) != null) {
					if (syokucode.equals(rs.getString(4)) && senmoncode.equals(rs.getString(5)) && levelcode.equals(rs.getString(6))) {
						career_callenge[0] = rs.getString(4);
						career_callenge[1] = rs.getString(5);
						career_callenge[2] = rs.getString(6);
					}
				}
				if (rs.getString(7) != null) {
					if (syokucode.equals(rs.getString(7)) && senmoncode.equals(rs.getString(8)) && levelcode.equals(rs.getString(9))) {
						career_callenge[0] = rs.getString(7);
						career_callenge[1] = rs.getString(8);
						career_callenge[2] = rs.getString(9);
					}
				}
			}

			Log.method(login_no, "OUT", "");
			return career_callenge;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * �w�肳�ꂽ���̃A�Z�X�����g�����̐f�f�\���t���O���Q�Ƃ���
	 * @param login_no
	 * @param sindansya_no
	 * @param nendo
	 * @param ki
	 * @param syokucode
	 * @param senmoncode
	 * @param levelcode
	 * @param jissi_kaisu
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	private String getCareerChallengeAssessmentSindanFlgPassAll(final String login_no, final String sindansya_no, final String nen, final String ki, final String syokucode, final String senmoncode,
			final String levelcode, final String jissikaisu) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* �A�Z�X�����g�������`�F�b�N */
			String sql = "SELECT COUNT(" + HcdbDef.p24_column[9] + ") FROM " + PBA_AssessmentEJBBean.tbl21 + " P21," + PBA_AssessmentEJBBean.tbl24 + " P24" + " WHERE P21." + HcdbDef.p21_column[0]
					+ " = P24." + HcdbDef.p24_column[0] + " AND   P21." + HcdbDef.p21_column[1] + " = P24." + HcdbDef.p24_column[1] + " AND   P21." + HcdbDef.p21_column[2] + " = P24."
					+ HcdbDef.p24_column[2] + " AND   P21." + HcdbDef.p21_column[3] + " = P24." + HcdbDef.p24_column[3] + " AND   P21." + HcdbDef.p21_column[4] + " = P24." + HcdbDef.p24_column[4]
					+ " AND   P21." + HcdbDef.p21_column[0] + " = ? AND   P21." + HcdbDef.p21_column[10] + " = '1'" + " AND   P21." + HcdbDef.p21_column[11] + " = ? AND P21." + HcdbDef.p21_column[12]
					+ " = ?" + " AND P21." + HcdbDef.p21_column[1] + " = ? AND P21." + HcdbDef.p21_column[2] + " = ? " + " AND P21." + HcdbDef.p21_column[3] + " = ? AND P21." + HcdbDef.p21_column[4]
					+ " = ? ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.setString(1, sindansya_no);
			pstmt.setString(2, nen);
			pstmt.setString(3, ki);
			pstmt.setString(4, syokucode);
			pstmt.setString(5, senmoncode);
			pstmt.setString(6, levelcode);
			pstmt.setString(7, jissikaisu);

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = pstmt.executeQuery();

			rs.next();
			final String sindan_flg_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);

			/* �A�Z�X�����g�����ɂ���L�����A�`�������W�K�p�̐\����Ԃ��`�F�b�N */
			String sindan_flg = null;
			if (!sindan_flg_line.equals("0")) {
				sql = "SELECT " + HcdbDef.p24_column[9] + " FROM " + PBA_AssessmentEJBBean.tbl21 + " P21," + PBA_AssessmentEJBBean.tbl24 + " P24" + " WHERE P21." + HcdbDef.p21_column[0] + " = P24."
						+ HcdbDef.p24_column[0] + " AND   P21." + HcdbDef.p21_column[1] + " = P24." + HcdbDef.p24_column[1] + " AND   P21." + HcdbDef.p21_column[2] + " = P24." + HcdbDef.p24_column[2]
						+ " AND   P21." + HcdbDef.p21_column[3] + " = P24." + HcdbDef.p24_column[3] + " AND   P21." + HcdbDef.p21_column[4] + " = P24." + HcdbDef.p24_column[4] + " AND   P21."
						+ HcdbDef.p21_column[0] + " = ? AND P21." + HcdbDef.p21_column[10] + " = '1'" + " AND   P21." + HcdbDef.p21_column[11] + " = ? AND P21." + HcdbDef.p21_column[12] + " = ? "
						+ " AND P21." + HcdbDef.p21_column[1] + " = ? AND P21." + HcdbDef.p21_column[2] + " = ? " + " AND P21." + HcdbDef.p21_column[3] + " = ? AND P21." + HcdbDef.p21_column[4]
						+ " = ? ";

				pstmt = dbConn.prepareStatement(sql);
				pstmt.setString(1, sindansya_no);
				pstmt.setString(2, nen);
				pstmt.setString(3, ki);
				pstmt.setString(4, syokucode);
				pstmt.setString(5, senmoncode);
				pstmt.setString(6, levelcode);
				pstmt.setString(7, jissikaisu);

				/* �f�o�b�O���O�̏o�� */
				Log.debug(sql);

				rs = pstmt.executeQuery();
				rs.next();
				sindan_flg = rs.getString(1).trim();
			}

			Log.method(login_no, "OUT", "");
			return sindan_flg;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException {/* �������܂��� */
	}

	/**
	 * SessionContext�����擾����B
	 * @return SessionContext���
	 */
	public SessionContext getSessionContext() {
		return this.my_ssc;
	}

	/**
	 * EJB�R���e�i���Ǘ�����SessionContext����SessionBean�ɓn���BSessionBean�̍쐬���ɌĂяo�����B
	 * @param val SessionContext���
	 * @exception RemoteException
	 */
	public void setSessionContext(final SessionContext val) throws RemoteException {
		this.my_ssc = val;
	}
}
