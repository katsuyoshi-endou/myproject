/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.careernavi.servlet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.plan.base.bean.PBY_SkillStandardBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.pdf.PZE060_CareerNaviSkillPDF;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �T�v: �u���E�U����̌����v�����󂯎��A�N���C�A���gBean�̌����������\�b�h���Ăяo���B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PBC150_DownloadSkillNaviServlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U����̌����v�����󂯎��A�N���C�A���gBean�̌����������\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequest�I�u�W�F�N�g
	 * @param response Servlet ����̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet �̐���ȏ������W����ꂽ�Ƃ��ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = "";
		
		try {
			/* session�X�R�[�v��Beans���擾���� */
			final HttpSession session = request.getSession(false);
			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {

				// UserInfoBean�ďo
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
				login_no = bean.getLogin_no();

				// Log�o��
				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				// �O����`����
				final String SenteItem1 = (String) ReadFile.announceMapData.get("AZZ009");
				final String SenteItem2 = (String) ReadFile.announceMapData.get("AZZ010");
				final String SenteItem3 = (String) ReadFile.announceMapData.get("AZZ011");
				final String labelItem1 = (String) ReadFile.paramMapData.get("DZZ001");
				final String labelItem2 = (String) ReadFile.paramMapData.get("DZZ007");
				final String labelItem3 = (String) ReadFile.paramMapData.get("DZZ008");
				final String labelItem4 = (String) ReadFile.paramMapData.get("DZZ009");
				final String labelItem5 = (String) ReadFile.paramMapData.get("DZZ010");
				final String labelItem6 = (String) ReadFile.paramMapData.get("DZZ011");
				final String labelItem7 = (String) ReadFile.paramMapData.get("DZZ012");
				final String labelItem8 = (String) ReadFile.paramMapData.get("DZZ142");

				final String[] outDefItem = { labelItem3, labelItem4, labelItem5, labelItem7, labelItem6, SenteItem1, SenteItem2, SenteItem3, labelItem8, labelItem2, labelItem1 };

				// ���p������
				final String syokusyu_code = request.getParameter("H001_syokusyu_code");
				final String senmon_code = request.getParameter("H002_senmon_code");
				final String level_code = request.getParameter("H005_reberu_code");
				final String[] skill_code = request.getParameterValues("H041_SkillCode");
				final String[] skill_name = request.getParameterValues("H091_SkillName");
				final String[] skill_deg = request.getParameterValues("H111_SkillDeg");
				final String[] simei_kanji = request.getParameterValues("H020_SimeiKanji");
				final String[] busyo = request.getParameterValues("H022_Busyo");
				final String[] last_uptime = request.getParameterValues("H105_LastUpTime");
				final String[] gyomukeiken = request.getParameterValues("A008_SkillNavi");
				final String[] updateneeds = request.getParameterValues("C003_Update");

				// ���̍��ڎ擾
				final String syokusyu_name = PBY_SkillStandardBean.getSyokuName(syokusyu_code);
				final String senmon_name = PBY_SkillStandardBean.getSenmonName(syokusyu_code, senmon_code);
				final String level_name = PBY_SkillStandardBean.getLevelName(syokusyu_code, senmon_code, level_code);

				final String[] outNameItem = { syokusyu_name, senmon_name, level_name };

				int cnt;

				if (skill_code == null) {
					cnt = 0;
				} else {
					cnt = skill_code.length;
				}

				String[][] outputItem;
				int index = 0;
				outputItem = new String[cnt][7];

				for (int i = 0; i < cnt; i++) {

					String updatekbn = "";
					if (updateneeds == null || index >= updateneeds.length || !updateneeds[index].equals(Integer.toString(i))) {
						updatekbn = "�X�V���e��\n��ۑ�";
					} else {
						updatekbn = "�X�V���e��\n�ۑ�";
						index++;
					}

					outputItem[i][0] = skill_name[i];
					outputItem[i][1] = skill_deg[i];
					outputItem[i][2] = gyomukeiken[i];
					outputItem[i][3] = updatekbn;
					outputItem[i][4] = busyo[i];
					outputItem[i][5] = simei_kanji[i];
					outputItem[i][6] = last_uptime[i];
				}

				/* PDF�t�@�C���� */
				final String pdf_name = login_no + PZZ010_CharacterUtil.GetDay() + PZZ010_CharacterUtil.GetTime() + "_NavigationSkill.pdf";

				/* PDF�쐬 */
				final PZE060_CareerNaviSkillPDF pdf = new PZE060_CareerNaviSkillPDF(login_no);

				pdf.setSkillNavi(outDefItem, outputItem, outNameItem);

				final ByteArrayOutputStream baos = new ByteArrayOutputStream();
				pdf.executePDF(baos);
				final ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());

				request.setAttribute("STREAM", bais);
				request.setAttribute("H080_FileName", pdf_name);

				/* JSP�y�[�W���Ăяo�� */
				final RequestDispatcher rd = this.ctx.getRequestDispatcher("/servlet/PYE010_FileDownloadServlet");
				rd.forward(request, response);

				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}

	}
}
