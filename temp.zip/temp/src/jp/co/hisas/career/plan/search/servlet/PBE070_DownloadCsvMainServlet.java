/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.search.servlet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.plan.search.bean.PBE_DownloadCallBean;
import jp.co.hisas.career.plan.search.bean.PBE_DownloadCsvSkillBean;
import jp.co.hisas.career.util.common.PZZ050_FileUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �A�Z�X�����g���ʈꗗCSV�f�[�^�̏o�͂��s��
 */
public class PBE070_DownloadCsvMainServlet extends PEY010_ControllerServlet {
	private final String errorPage = "/view/base/error/VYY_Error.jsp";

	/** ���O�C��NO */
	private final String login_no = "";

	/** CSV�̈͂����� */
	private final String s_enclose = "\"";

	/** CSV�̋�؂蕶�� */
	private final String s_separate = ",";

	/** CSV�̉��s���� */
	private final String s_kaigyo = HcdbDef.CSV_LINE_FEED_CODE;

	/** �������ʂ���ϊ�����CSV���i�[����z�� */
	private String[] aryCsv;

	/** �o��CSV��� */
	private String csvType = "";

	/** �Z�b�V���� */
	private HttpSession session = null;

	/** �Z�b�V��������擾�����g�D�����i�[����n�b�V���e�[�u�� */
	private Hashtable h_sosiki = null;

	/** �g�D���̂��߂̃Z�p���[�g������ */
	private String s_separator = "";

	/** �V�X�e���p�����[�^�F[�A�Z�X�����g�o�͑Ώۑg�D�K�w���]�擾�L�[ */
	private static final String CSV_KAISO_MAX = (String) ReadFile.fileMapData.get("CSV_OUTPUT_SOSIKI_KAISO_MAX");

	/** �V�X�e���p�����[�^�F[�A�Z�X�����g�o�͑Ώۑg�D�K�w����]�擾�L�[ */
	private static final String CSV_KAISO_MIN = (String) ReadFile.fileMapData.get("CSV_OUTPUT_SOSIKI_KAISO_MIN");

	/**
	 * �u���E�U����̌����v�����󂯎��A�N���C�A���gBean�̌����������\�b�h���Ăяo���B �i�������p�̃v���_�E�����j���[���쐬���邽�߂Ƀ}�X�^����������B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequest�I�u�W�F�N�g
	 * @param response Servlet ����̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet �̐���ȏ������W����ꂽ�Ƃ��ɔ��������O
	 */
	protected synchronized String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws Exception {

		final String login_no = loginuser.getSimeiNo();

		try {
			/* session�X�R�[�v��Beans���擾���� */
			this.session = request.getSession(false);
			this.h_sosiki = (Hashtable) this.session.getAttribute("sosikiBeans");
			final UserInfoBean userinfo = (UserInfoBean) this.session.getAttribute("userinfo");

			final Object obj = ReadFile.fileMapData.get(HcdbDef.SOSIKI_SEPARATOR);
			if (obj != null) {
				this.s_separator = (String) obj;
			}

			final String csv_mode = request.getParameter("csv_mode");
			Log.debug("csv_mode=" + csv_mode);
			if (this.session == null || csv_mode == null) {
				return this.errorPage;
			} else {
				/* ���\�b�h�g���[�X�o�� */
				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				// �������[�h���擾
				// �i���������擾
				final String busyo_cd = request.getParameter("busyo_cd");
				Log.debug("busyo_cd=" + busyo_cd);
				final String taisyokikan = request.getParameter("taisyokikan");
				Log.debug("taisyokikan=" + taisyokikan);

				/* �������ʂ�CSV�`���̕�����ɕϊ����������i�[�����z����擾����B */

				final PBE_DownloadCallBean ejb = new PBE_DownloadCallBean();

				if ("sougou".equalsIgnoreCase(csv_mode)) {
					// �����o�̓{�^���������̏���

					Log.debug("ejb.getCsvSougou:START");

					final Vector v_result = ejb.getCsvSougou(loginuser, busyo_cd, taisyokikan);
					Log.debug("ejb.getCsvSougou:END");

					this.arraySougouToCsv(v_result);

				} else if ("gyoumu".equalsIgnoreCase(csv_mode)) {
					// �����o�̓{�^���������̏���

					Log.debug("ejb.getCsvGyomu:START");

					final Vector v_result = ejb.getCsvGyomu(loginuser, busyo_cd, taisyokikan);
					Log.debug("ejb.getCsvGyomu:END");

					this.arrayGyomuToCsv(v_result);

				} else if ("skill".equalsIgnoreCase(csv_mode)) {
					// �����o�̓{�^���������̏���

					Log.debug("ejb.getCsvSkill:START");

					final Vector v_result = ejb.getCsvSkill(loginuser, busyo_cd, taisyokikan);
					Log.debug("ejb.getCsvSkill:END");

					this.arraySkillToCsv(v_result);

				} else {
					return this.errorPage;
				}

				/* CSV�t�@�C�����o�͂��� */
				final ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ByteArrayInputStream bais;
				byte[] add = null;

				final String next_url = "/servlet/PYE010_FileDownloadServlet";
				/*
				 * CSV�̔z����o�C�g�X�g���[���ɏ������ށBnull�`�F�b�N���s���Ă���̂� �����B���x���ō��̃A�Z�X�����g���ʂ݂̂��o�͂���ꍇ�� �������ʌ��� count �����ACVS�z��̂ق����s�������Ȃ��\�������邽�߁B
				 */
				for (int i = 0; i < this.aryCsv.length && this.aryCsv[i] != null; i++) {
					add = this.aryCsv[i].getBytes();
					baos.write(add);
				}
				baos.close();
				bais = new ByteArrayInputStream(baos.toByteArray());

				/* ���샍�O�o�� */
				final String userLoginNo = userinfo.getLogin_no();
				final String userSimeiNo = userinfo.getSimei_no();
				OutLogBean.sousaKojinJohoLog("SMG001", userLoginNo, userSimeiNo, ("����:" + busyo_cd + " �Ώۊ���:" + taisyokikan));

				request.setAttribute("STREAM", bais);
				request.setAttribute("H080_FileName", PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_ASSESSMENT_LIST_CSV, new String[] { login_no, this.csvType }));

				/* ���\�b�h�g���[�X�o�� */
				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
				return next_url;
			}
		} catch (final IllegalStateException e) {
			Log.error(login_no, e);
			return this.errorPage;
		} catch (final IOException e) {
			Log.error(login_no, e);
			return this.errorPage;
		} catch (final Exception e) {
			Log.error(login_no, e);
			return this.errorPage;

		}
	}

	/**
	 * �����o�͗p �������ʔz���CSV�`���̕�����ɕϊ�����
	 * @param load[][] �������ʔz��
	 */
	private void arraySougouToCsv(final Vector v_result) throws Exception {
		try {
			Log.method(this.login_no, "IN", "");

			this.csvType = "Sougou";
			final String headerLabel01 = (String) ReadFile.paramMapData.get("DACSV001");
			final String headerLabel02 = (String) ReadFile.paramMapData.get("DACSV002");
			final String headerLabel21 = (String) ReadFile.paramMapData.get("DCSV019");
			final String headerLabel22 = (String) ReadFile.paramMapData.get("DCSV020");
			final String headerLabel23 = (String) ReadFile.paramMapData.get("DACSV003");
			final String headerLabel24 = (String) ReadFile.paramMapData.get("DACSV004");
			final String headerLabel25 = (String) ReadFile.paramMapData.get("DACSV005");
			final String headerLabel26 = (String) ReadFile.paramMapData.get("DACSV006");
			final String headerLabel27 = (String) ReadFile.paramMapData.get("DACSV007");
			final String headerLabel28 = (String) ReadFile.paramMapData.get("DACSV008");
			final String headerLabel29 = (String) ReadFile.paramMapData.get("DACSV009");
			final String headerLabel30 = (String) ReadFile.paramMapData.get("DACSV010");
			final String headerLabel31 = (String) ReadFile.paramMapData.get("DACSV011");
			final String headerLabel32 = (String) ReadFile.paramMapData.get("DACSV012");
			final String headerLabel33 = (String) ReadFile.paramMapData.get("DACSV013");
			final String headerLabel34 = (String) ReadFile.paramMapData.get("DACSV014");
			final String headerLabel35 = (String) ReadFile.paramMapData.get("DACSV015");
			final String headerLabel36 = (String) ReadFile.paramMapData.get("DACSV016");
			final String headerLabel37 = (String) ReadFile.paramMapData.get("DACSV017");
			final String headerLabel38 = (String) ReadFile.paramMapData.get("DACSV018");
			final String headerLabel39 = (String) ReadFile.paramMapData.get("DACSV019");
			final String headerLabel40 = (String) ReadFile.paramMapData.get("DACSV020");

			String s_header = this.makeCsvData(headerLabel01) + this.s_separate + this.makeCsvData(headerLabel02) + this.s_separate;
			for (int i = 1; i < 10; i++) {
				if (Integer.parseInt(PBE070_DownloadCsvMainServlet.CSV_KAISO_MAX) < i || Integer.parseInt(PBE070_DownloadCsvMainServlet.CSV_KAISO_MIN) > i) {
					// �擾������ʑg�D���p�����[�^�͈̔͊O�ł���Ζ���
					continue;
				}
				final int num1 = i * 2 - 1;
				final int num2 = i * 2;
				s_header += this.makeCsvData((String) ReadFile.paramMapData.get("DCSV0" + (num1 < 10 ? "0" : "") + String.valueOf(num1))) + this.s_separate;
				s_header += this.makeCsvData((String) ReadFile.paramMapData.get("DCSV0" + (num2 < 10 ? "0" : "") + String.valueOf(num2))) + this.s_separate;
			}
			s_header += this.makeCsvData(headerLabel21) + this.s_separate + this.makeCsvData(headerLabel22) + this.s_separate + this.makeCsvData(headerLabel23) + this.s_separate
					+ this.makeCsvData(headerLabel24) + this.s_separate + this.makeCsvData(headerLabel25) + this.s_separate + this.makeCsvData(headerLabel26) + this.s_separate
					+ this.makeCsvData(headerLabel27) + this.s_separate + this.makeCsvData(headerLabel28) + this.s_separate + this.makeCsvData(headerLabel29) + this.s_separate
					+ this.makeCsvData(headerLabel30) + this.s_separate + this.makeCsvData(headerLabel31) + this.s_separate + this.makeCsvData(headerLabel32) + this.s_separate
					+ this.makeCsvData(headerLabel33) + this.s_separate + this.makeCsvData(headerLabel34) + this.s_separate + this.makeCsvData(headerLabel35) + this.s_separate
					+ this.makeCsvData(headerLabel36) + this.s_separate + this.makeCsvData(headerLabel37) + this.s_separate + this.makeCsvData(headerLabel38) + this.s_separate
					+ this.makeCsvData(headerLabel39) + this.s_separate + this.makeCsvData(headerLabel40) + this.s_kaigyo;

			this.aryCsv = new String[v_result.size() + 1];

			this.aryCsv[0] = s_header;

			StringBuffer s_dumy;
			HashMap s_sougou;

			for (int no = 0; no < v_result.size(); no++) {
				s_dumy = new StringBuffer();
				s_sougou = (HashMap) v_result.elementAt(no);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Sindansya")))// ����NO
						.append(this.s_separate);

				if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("1")) {
					// ��������
					s_dumy.append(this.makeCsvData((String) s_sougou.get("Kanji_simei")));
				} else if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("2")) {
					// ��������
					s_dumy.append(this.makeCsvData((String) s_sougou.get("Kana_simei")));
				} else if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("3")) {
					// ��������
					s_dumy.append(this.makeCsvData((String) s_sougou.get("Eiji_simei")));
				}

				s_dumy.append(this.s_separate);
				for (int j = 1; j < 10; j++) {
					if (Integer.parseInt(PBE070_DownloadCsvMainServlet.CSV_KAISO_MAX) < j || Integer.parseInt(PBE070_DownloadCsvMainServlet.CSV_KAISO_MIN) > j) {
						// �擾������ʑg�D���p�����[�^�͈̔͊O�ł���Ζ���
						continue;
					}
					s_dumy.append(this.makeCsvData((String) s_sougou.get("Syozoku_code_" + j))).append(this.s_separate);
					s_dumy.append(this.makeCsvData((String) s_sougou.get("Syozoku_name_" + j))).append(this.s_separate);
				}
				s_dumy.append(this.makeCsvData((String) s_sougou.get("Yakusyoku_code"))).append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Yakusyoku_name"))).append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Syoku_code")))// �E��R�[�h
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Syoku_name")))// �E��
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Senmon_code")))// ��啪��R�[�h
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Senmon_name")))// ��啪��
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Level_code")))// ���x���R�[�h
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Level_name")))// ���x����
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Jissi_kaisu")))// ���{��
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Jissi_nengappi"))).append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Gyomu_keiken_t_do")))// �Ɩ��o���B���x �{�l
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Skill_t_do")))// �X�L���B���x �{�l
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Sougou_t_do")))// �����B���x �{�l
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Hyokasya"))).append(this.s_separate);

				if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("1")) {
					// ��������
					s_dumy.append(this.makeCsvData((String) s_sougou.get("KanjiSimeiHyo")));
				} else if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("2")) {
					// ��������
					s_dumy.append(this.makeCsvData((String) s_sougou.get("KanaSimeiHyo")));
				} else if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("3")) {
					// ��������
					s_dumy.append(this.makeCsvData((String) s_sougou.get("EijiSimeiHyo")));
				}

				s_dumy.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("HyokaNengappi")))// ���{�N����
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Gyomu_keiken_t_do_hyo")))// �Ɩ��o���B���x �]����
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Skill_t_do_hyo")))// �X�L���B���x �]����
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Sougou_t_do_hyo")))// �����B���x �]����
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Career_challenge_kikan_mei")))// �L�����A�`�������W����
						.append(this.s_kaigyo);

				this.aryCsv[no + 1] = s_dumy.toString();

			}

			Log.method(this.login_no, "OUT", "");
		} catch (final Exception e) {
			Log.error(this.login_no, e);
			throw e;
		}

	}

	/**
	 * �Ɩ��o�͗p �������ʔz���CSV�`���̕�����ɕϊ�����
	 * @param load[][] �������ʔz��
	 */
	private void arrayGyomuToCsv(final Vector v_result) throws Exception {
		try {
			Log.method(this.login_no, "IN", "");

			this.csvType = "Gyomu";

			final String headerLabel01 = (String) ReadFile.paramMapData.get("DACSV001");
			final String headerLabel02 = (String) ReadFile.paramMapData.get("DACSV002");
			final String headerLabel03 = (String) ReadFile.paramMapData.get("DACSV003");
			final String headerLabel04 = (String) ReadFile.paramMapData.get("DACSV004");
			final String headerLabel05 = (String) ReadFile.paramMapData.get("DACSV005");
			final String headerLabel06 = (String) ReadFile.paramMapData.get("DACSV006");
			final String headerLabel07 = (String) ReadFile.paramMapData.get("DACSV007");
			final String headerLabel08 = (String) ReadFile.paramMapData.get("DACSV008");
			final String headerLabel09 = (String) ReadFile.paramMapData.get("DACSV009");
			final String headerLabel10 = (String) ReadFile.paramMapData.get("DACSV021");
			final String headerLabel11 = (String) ReadFile.paramMapData.get("DACSV022");
			final String headerLabel12 = (String) ReadFile.paramMapData.get("DACSV023");
			final String headerLabel13 = (String) ReadFile.paramMapData.get("DACSV024");
			final String headerLabel14 = (String) ReadFile.paramMapData.get("DACSV025");
			final String headerLabel15 = (String) ReadFile.paramMapData.get("DACSV026");
			final String headerLabel16 = (String) ReadFile.paramMapData.get("DACSV014");
			final String headerLabel17 = (String) ReadFile.paramMapData.get("DACSV015");

			final String s_header = this.makeCsvData(headerLabel01) + this.s_separate + this.makeCsvData(headerLabel02) + this.s_separate + this.makeCsvData(headerLabel03) + this.s_separate
					+ this.makeCsvData(headerLabel04) + this.s_separate + this.makeCsvData(headerLabel05) + this.s_separate + this.makeCsvData(headerLabel06) + this.s_separate
					+ this.makeCsvData(headerLabel07) + this.s_separate + this.makeCsvData(headerLabel08) + this.s_separate + this.makeCsvData(headerLabel09) + this.s_separate
					+ this.makeCsvData(headerLabel10) + this.s_separate + this.makeCsvData(headerLabel11) + this.s_separate + this.makeCsvData(headerLabel12) + this.s_separate
					+ this.makeCsvData(headerLabel13) + this.s_separate + this.makeCsvData(headerLabel14) + this.s_separate + this.makeCsvData(headerLabel15) + this.s_separate
					+ this.makeCsvData(headerLabel16) + this.s_separate + this.makeCsvData(headerLabel17) + this.s_kaigyo;

			this.aryCsv = new String[v_result.size() + 1];

			this.aryCsv[0] = s_header;

			StringBuffer s_dumy;
			HashMap s_sougou;

			for (int no = 0; no < v_result.size(); no++) {
				s_dumy = new StringBuffer();
				s_sougou = (HashMap) v_result.elementAt(no);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Sindansya")))// ����NO
						.append(this.s_separate);

				if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("1")) {
					// ��������
					s_dumy.append(this.makeCsvData((String) s_sougou.get("SindansyaKanjiSimei")));
				} else if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("2")) {
					// ��������
					s_dumy.append(this.makeCsvData((String) s_sougou.get("SindansyaKanaSimei")));
				} else if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("3")) {
					// ��������
					s_dumy.append(this.makeCsvData((String) s_sougou.get("SindansyaEijiSimei")));
				}

				s_dumy.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Syoku_code")))// �E��R�[�h
						.append(this.s_separate);
				s_dumy.append(this.makeCsvData((String) s_sougou.get("SyokuName")))// �E�햼
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Senmon_code")))// ��啪��R�[�h
						.append(this.s_separate);
				s_dumy.append(this.makeCsvData((String) s_sougou.get("SenmonName")))// ��啪�얼
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Level_code")))// ���x���R�[�h
						.append(this.s_separate);
				s_dumy.append(this.makeCsvData((String) s_sougou.get("LevelName")))// ���x����
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Jissi_kaisu")))// ���{��
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Tasseido_kubun_code")))// �Ɩ��B���x�敪�R�[�h
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Tasseido_kubun")))// �Ɩ��B���x�敪
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Tasseido_sihyo_code")))// �Ɩ��B���x�w�W�R�[�h
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Tasseido_sihyo")))// �Ɩ��B���x�w�W
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData((String) s_sougou.get("SentakuFlgSindansya")))// �I���t���O(�{�l)
						.append(this.s_separate);
				s_dumy.append(this.makeCsvData((String) s_sougou.get("SentakuFlgHyokasya"))).append(this.s_separate);// �I���t���O(�]����)

				s_dumy.append(this.makeCsvData((String) s_sougou.get("Hyokasya"))).append(this.s_separate);

				if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("1")) {
					// ��������
					s_dumy.append(this.makeCsvData((String) s_sougou.get("HyokasyaKanjiSimei")));
				} else if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("2")) {
					// ��������
					s_dumy.append(this.makeCsvData((String) s_sougou.get("HyokasyaKanaSimei")));
				} else if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("3")) {
					// ��������
					s_dumy.append(this.makeCsvData((String) s_sougou.get("HyokasyaEijiSimei")));
				}

				s_dumy.append(this.s_kaigyo);

				this.aryCsv[no + 1] = s_dumy.toString();

			}

			Log.method(this.login_no, "OUT", "");
		} catch (final Exception e) {
			Log.error(this.login_no, e);
			throw e;
		}

	}

	/**
	 * �X�L���o�͗p �������ʔz���CSV�`���̕�����ɕϊ�����
	 * @param load[][] �������ʔz��
	 */
	private void arraySkillToCsv(final Vector v_result) throws Exception {
		try {
			Log.method(this.login_no, "IN", "");

			this.csvType = "Skill";

			final String headerLabel01 = (String) ReadFile.paramMapData.get("DACSV001");
			final String headerLabel02 = (String) ReadFile.paramMapData.get("DACSV002");
			final String headerLabel03 = (String) ReadFile.paramMapData.get("DACSV003");
			final String headerLabel04 = (String) ReadFile.paramMapData.get("DACSV004");
			final String headerLabel05 = (String) ReadFile.paramMapData.get("DACSV005");
			final String headerLabel06 = (String) ReadFile.paramMapData.get("DACSV006");
			final String headerLabel07 = (String) ReadFile.paramMapData.get("DACSV007");
			final String headerLabel08 = (String) ReadFile.paramMapData.get("DACSV008");
			final String headerLabel09 = (String) ReadFile.paramMapData.get("DACSV009");
			final String headerLabel10 = (String) ReadFile.paramMapData.get("DACSV027");
			final String headerLabel11 = (String) ReadFile.paramMapData.get("DACSV028");
			final String headerLabel12 = (String) ReadFile.paramMapData.get("DACSV029");
			final String headerLabel13 = (String) ReadFile.paramMapData.get("DACSV030");
			final String headerLabel14 = (String) ReadFile.paramMapData.get("DACSV014");
			final String headerLabel15 = (String) ReadFile.paramMapData.get("DACSV015");

			final String s_header = this.makeCsvData(headerLabel01) + this.s_separate + this.makeCsvData(headerLabel02) + this.s_separate + this.makeCsvData(headerLabel03) + this.s_separate
					+ this.makeCsvData(headerLabel04) + this.s_separate + this.makeCsvData(headerLabel05) + this.s_separate + this.makeCsvData(headerLabel06) + this.s_separate
					+ this.makeCsvData(headerLabel07) + this.s_separate + this.makeCsvData(headerLabel08) + this.s_separate + this.makeCsvData(headerLabel09) + this.s_separate
					+ this.makeCsvData(headerLabel10) + this.s_separate + this.makeCsvData(headerLabel11) + this.s_separate + this.makeCsvData(headerLabel12) + this.s_separate
					+ this.makeCsvData(headerLabel13) + this.s_separate + this.makeCsvData(headerLabel14) + this.s_separate + this.makeCsvData(headerLabel15) + this.s_kaigyo;

			this.aryCsv = new String[v_result.size() + 1];

			this.aryCsv[0] = s_header;

			StringBuffer s_dumy;
			PBE_DownloadCsvSkillBean s_sougou;

			for (int no = 0; no < v_result.size(); no++) {
				s_dumy = new StringBuffer();
				s_sougou = (PBE_DownloadCsvSkillBean) v_result.elementAt(no);

				s_dumy.append(this.makeCsvData(s_sougou.getSindansya()))// ����NO
						.append(this.s_separate);

				if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("1")) {
					// ��������
					s_dumy.append(this.makeCsvData(s_sougou.getSindansyaKanjiSimei()));
				} else if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("2")) {
					// ��������
					s_dumy.append(this.makeCsvData(s_sougou.getSindansyaKanaSimei()));
				} else if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("3")) {
					// ��������
					s_dumy.append(this.makeCsvData(s_sougou.getSindansyaEijiSimei()));
				}

				s_dumy.append(this.s_separate);

				s_dumy.append(this.makeCsvData(s_sougou.getSyoku_code()))// �E��R�[�h
						.append(this.s_separate);
				s_dumy.append(this.makeCsvData(s_sougou.getSyokuName()))// �E�햼
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData(s_sougou.getSenmon_code()))// ��啪��R�[�h
						.append(this.s_separate);
				s_dumy.append(this.makeCsvData(s_sougou.getSenmonName()))// ��啪�얼
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData(s_sougou.getLevel_code()))// ���x���R�[�h
						.append(this.s_separate);
				s_dumy.append(this.makeCsvData(s_sougou.getLevelName()))// ���x����
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData(s_sougou.getJissi_kaisu()))// ���{��
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData(s_sougou.getSkill_code()))// �X�L���R�[�h
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData(s_sougou.getSkill_name()))// �X�L������
						.append(this.s_separate);

				s_dumy.append(this.makeCsvData(s_sougou.getScore()))// �X�R�A(�{�l)
						.append(this.s_separate);
				s_dumy.append(this.makeCsvData(s_sougou.getScoreHyokasya()))// �X�R�A(�]����)
						.append(this.s_separate);
				s_dumy.append(this.makeCsvData(s_sougou.getHyokasya())).append(this.s_separate);

				if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("1")) {
					// ��������
					s_dumy.append(this.makeCsvData(s_sougou.getHyokasyaKanjiSimei()));
				} else if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("2")) {
					// ��������
					s_dumy.append(this.makeCsvData(s_sougou.getHyokasyaKanaSimei()));
				} else if (ReadFile.fileMapData.get("CSV_OUTPUTNAME_TYPE").equals("3")) {
					// ��������
					s_dumy.append(this.makeCsvData(s_sougou.getHyokasyaEijiSimei()));
				}

				s_dumy.append(this.s_kaigyo);

				this.aryCsv[no + 1] = s_dumy.toString();

			}

			Log.method(this.login_no, "OUT", "");
		} catch (final Exception e) {
			Log.error(this.login_no, e);
			throw e;
		}

	}

	/**
	 * �f�[�^��CSV��`�̃_�u���N�H�[�e�[�V�����ň͂�
	 * @param input �ϊ��Ώۂ̕�����
	 * @return ���R�[�h��
	 */
	private String makeCsvData(final String input) {
		if (input != null) {
			return this.s_enclose + input + this.s_enclose;
		} else {
			return this.s_enclose + this.s_enclose;
		}
	}

}
