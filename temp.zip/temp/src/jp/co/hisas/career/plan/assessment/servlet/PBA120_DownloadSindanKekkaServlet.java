/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.assessment.servlet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.plan.assessment.bean.PBA_AssessmentBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ050_FileUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.pdf.PZE030_SindanKekkaPDF;

/**
 * �A�Z�X�����g�f�f���ʂ�PDF���o�͂���
 */
public class PBA120_DownloadSindanKekkaServlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U����̌����v�����󂯎��A�N���C�A���gBean�̌����������\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequest�I�u�W�F�N�g
	 * @param response Servlet ����̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet �̐���ȏ������W����ꂽ�Ƃ��ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = null;
		try {
			/* session�X�R�[�v��Beans���擾���� */
			final HttpSession session = request.getSession(false);
			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");
				login_no = userinfo.getLogin_no();
				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				final PBA_AssessmentBean asesuBean = (PBA_AssessmentBean) session.getAttribute("asesuBean");

				/* �A�Z�X�����g�����擾 */
				final String syoku_name = asesuBean.getSyokuName();
				final String senmon_name = asesuBean.getSenmonName();
				final String level_name = asesuBean.getLevelName();
				final String[][] tasseido_sihyo_list = asesuBean.getTasseidoSihyoList();
				final String[][] skill_list = asesuBean.getSkillJyukutatudo();

				/* �f�f�ҏ����擾 */
				final String sindansya_simei = asesuBean.getSindansyaInfo()[1];
				final String sindansya_busyo = asesuBean.getSindansyaInfo()[2];
				final String sindansya_sogo_tasseido = asesuBean.getSindansyaSogoTasseido();
				final String sindansya_gyomu_tasseido = asesuBean.getSindansyaGyomuTasseido();
				final String[] sindansya_gyomu_kekka = asesuBean.getSindansyaGyomuSindanKekka();
				final String sindansya_skill_tasseido = asesuBean.getSindansyaSkillTasseido();
				final String[] sindansya_skill_kekka = asesuBean.getSindansyaSkillSindanKekka();
				final String sindan_nengappi = asesuBean.getSindansyaJissiNengappiJikoku()[0];

				/* �]���ҏ����擾 */
				final String hyokasya_simei = asesuBean.getHyokasyaInfo()[1];
				final String hyokasya_busyo = asesuBean.getHyokasyaInfo()[2];
				final String hyokasya_sogo_tasseido = asesuBean.getHyokasyaSogoTasseido();
				final String hyokasya_comment = PZZ010_CharacterUtil.strEncode(request.getParameter("A006_Hyoka"));
				final String hyokasya_gyomu_tasseido = asesuBean.getHyokasyaGyomuTasseido();
				final String[] hyokasya_gyomu_kekka = asesuBean.getHyokasyaGyomuSindanKekka();
				final String hyokasya_skill_tasseido = asesuBean.getHyokasyaSkillTasseido();
				final String[] hyokasya_skill_kekka = asesuBean.getHyokasyaSkillSindanKekka();
				final String hyokasya_jissi_nengappi = asesuBean.getHyokasyaJissiNengappiJikoku()[0];

				/* PDF�t�@�C�����쐬 */
				/* PDF�t�@�C���� */
				String pdf_name;
				if (asesuBean.assessment_flg == 0) {
					final String[] nen_jikoku = asesuBean.getSindansyaJissiNengappiJikoku();
					// �f�f�Ҏ���No���擾
					final String sindansya_simei_no = PZZ010_CharacterUtil.normalizedStr(asesuBean.getSindansyaInfo()[0]);
					pdf_name = PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_ASSESSMENT_SHINDANJI_PDF, new String[] { sindansya_simei_no, nen_jikoku[0] + nen_jikoku[1] });
				} else {
					final String[] nen_jikoku = asesuBean.getHyokasyaJissiNengappiJikoku();
					// �]���Ҏ���No���擾
					final String hyokasya_simei_no = PZZ010_CharacterUtil.normalizedStr(asesuBean.getHyokasyaInfo()[0]);
					pdf_name = PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_ASSESSMENT_HYOKAJI_PDF, new String[] { hyokasya_simei_no, nen_jikoku[0] + nen_jikoku[1] });
				}
				/* PDF�쐬 */
				final PZE030_SindanKekkaPDF pdf = new PZE030_SindanKekkaPDF(login_no);
				pdf.setAssessmentValue(syoku_name, senmon_name, level_name, tasseido_sihyo_list, skill_list);
				pdf.setSindansyaValue(sindansya_simei, sindansya_busyo, sindansya_sogo_tasseido, sindansya_gyomu_tasseido, sindansya_gyomu_kekka, sindansya_skill_tasseido, sindansya_skill_kekka,
						sindan_nengappi);
				pdf.setHyokasyaValue(hyokasya_simei, hyokasya_busyo, hyokasya_sogo_tasseido, hyokasya_comment, hyokasya_gyomu_tasseido, hyokasya_gyomu_kekka, hyokasya_skill_tasseido,
						hyokasya_skill_kekka, hyokasya_jissi_nengappi);

				final ByteArrayOutputStream baos = new ByteArrayOutputStream();
				pdf.executePDF(baos, asesuBean.getRadarChart());
				final ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());

				request.setAttribute("STREAM", bais);
				request.setAttribute("H080_FileName", pdf_name);
				final String next_url = "/servlet/PYE010_FileDownloadServlet";

				/* JSP�y�[�W���Ăяo�� */
				final RequestDispatcher rd = this.ctx.getRequestDispatcher(next_url);
				rd.forward(request, response);

				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}
}
