/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.careerchallenge.servlet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.code.bean.CodeBean;
import jp.co.hisas.career.base.menu.bean.MenuSeigyoBean;
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.plan.base.bean.PBY_SkillStandardBean;
import jp.co.hisas.career.plan.careerchallenge.bean.PBB_CareerChallenge;
import jp.co.hisas.career.plan.careerchallenge.bean.PBB_ChallengeBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.pdf.PZE070_ChallengePDF;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * �L�����A�`�������W��������DB�ւ̃f�[�^�C���T�[�g��PDF�쐬���s��
 */
public class PBB020_AddChallenge2Servlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U���瑗�M���ꂽ�l���󂯎��A�N���C�A���gBean�̋@���ی�ݒ菈�����\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
	 * @param response Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet�̐���ȏ������W����ꂽ���ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = "";
		
		try {

			final String result = HcdbDef.result;
			final String plan = HcdbDef.plan;

			final HttpSession session = request.getSession(false);

			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				/* bean�Ăяo�� */
				PBB_ChallengeBean challengebean = (PBB_ChallengeBean) session.getAttribute("challenge");
				final MenuSeigyoBean menuSeigyoBean = (MenuSeigyoBean) session.getAttribute("menuSeigyo");
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
				login_no = bean.getLogin_no();

				if (challengebean == null) {
					challengebean = new PBB_ChallengeBean(login_no);
					session.setAttribute("challenge", challengebean);
				}
				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				String kanji = bean.getKanji_Login();
				kanji = kanji.substring(1);

				String busyo = bean.getBusyo_Login();
				busyo = busyo.substring(1);

				/* WWW�u���E�U������͒l���󂯎�� */
				/* ���͂��ꂽ�l���i�[����z����쐬 */
				final String[] save = new String[65];
				save[0] = login_no;
				save[1] = PZZ010_CharacterUtil.strEncode(request.getParameter("H007_Nen")); // nendo = kikan_mei
				save[2] = PZZ010_CharacterUtil.strEncode(request.getParameter("H007_Ki")); // ki = kikan_mei
				save[3] = request.getParameter("H015_Kubun");
				if (request.getParameter("H002_SyokuCode").equals("DUMMY")) {
					save[4] = "";
				} else {
					save[4] = request.getParameter("H002_SyokuCode");
				}
				if (request.getParameter("H004_SenmonCode").equals("DUMMY")) {
					save[5] = "";
				} else {
					save[5] = request.getParameter("H004_SenmonCode");
				}
				if (request.getParameter("H006_LevelCode").equals("DUMMY")) {
					save[6] = "";
				} else {
					save[6] = request.getParameter("H006_LevelCode");
				}

				save[7] = PZZ010_CharacterUtil.strEncode(request.getParameter("A001_Gyomu"));
				save[8] = PZZ010_CharacterUtil.strEncode(request.getParameter("A002_Kyoiku"));

				final String[][] sikakuargs = CodeBean.getSikaku();
				/* �v����o�^�� */
				if (request.getParameter("H015_Kubun").equals(plan)) {
					if (request.getParameter("S006_Sikaku1").equals("-1")) {
						save[9] = "";
					} else {
						save[9] = sikakuargs[Integer.parseInt(request.getParameter("S006_Sikaku1"))][0];
					}
					if (request.getParameter("S009_SikakuCode1").equals("-1")) {
						save[10] = "";
					} else {
						save[10] = request.getParameter("S009_SikakuCode1");
					}
					save[11] = PZZ010_CharacterUtil.strEncode(request.getParameter("T005_Tokuten1"));
					save[47] = PZZ010_CharacterUtil.strEncode(request.getParameter("H033_Sikaku_meisyo1"));
					save[48] = PZZ010_CharacterUtil.strEncode(request.getParameter("H036_Level_mei1"));

					if (request.getParameter("S007_Sikaku2").equals("-1")) {
						save[12] = "";
					} else {
						save[12] = sikakuargs[Integer.parseInt(request.getParameter("S007_Sikaku2"))][0];
					}
					if (request.getParameter("S010_SikakuCode2").equals("-1")) {
						save[13] = "";
					} else {
						save[13] = request.getParameter("S010_SikakuCode2");
					}
					save[14] = PZZ010_CharacterUtil.strEncode(request.getParameter("T006_Tokuten2"));
					save[49] = PZZ010_CharacterUtil.strEncode(request.getParameter("H034_Sikaku_meisyo2"));
					save[50] = PZZ010_CharacterUtil.strEncode(request.getParameter("H037_Level_mei2"));

					if (request.getParameter("S008_Sikaku3").equals("-1")) {
						save[15] = "";
					} else {
						save[15] = sikakuargs[Integer.parseInt(request.getParameter("S008_Sikaku3"))][0];
					}
					if (request.getParameter("S011_SikakuCode3").equals("-1")) {
						save[16] = "";
					} else {
						save[16] = request.getParameter("S011_SikakuCode3");
					}
					save[17] = PZZ010_CharacterUtil.strEncode(request.getParameter("T007_Tokuten3"));
					save[51] = PZZ010_CharacterUtil.strEncode(request.getParameter("H035_Sikaku_meisyo3"));
					save[52] = PZZ010_CharacterUtil.strEncode(request.getParameter("H038_Level_mei3"));

				}

				if (request.getParameter("H015_Kubun").equals(result)) {
					/* bean�ɓ����Ă��鎑�i����z��Ɋi�[���� */
					final String[][] sikakuData = challengebean.getSikakuData();
					if (sikakuData != null) {
						if (sikakuData.length <= 3) {
							for (int i = 0; i < sikakuData.length; i++) {
								/* ���i���̃R�[�h */
								save[9 + i * 3] = sikakuData[i][5];
								/* ���i�R�[�h */
								save[10 + i * 3] = sikakuData[i][0];
								save[47 + i * 2] = sikakuData[i][1];
								save[48 + i * 2] = sikakuData[i][2];
								save[11 + i * 3] = sikakuData[i][3];
							}
						} else {
							for (int i = 0; i < 3; i++) {
								/* ���i���̃R�[�h */
								save[9 + i * 3] = sikakuData[i][5];
								/* ���i�R�[�h */
								save[10 + i * 3] = sikakuData[i][0];
								save[47 + i * 2] = sikakuData[i][1];
								save[48 + i * 2] = sikakuData[i][2];
								save[11 + i * 3] = sikakuData[i][3];
							}
						}
					} else {
						for (int i = 0; i < 5; i++) {
							/* ���i���̃R�[�h */
							save[9 + i * 3] = "";
							/* ���i�R�[�h */
							save[10 + i * 3] = "";
							save[47 + i * 2] = "";
							save[48 + i * 2] = "";
							save[11 + i * 3] = "";
						}
					}
				}

				save[18] = "";
				save[19] = "";
				save[20] = "";
				save[21] = "";
				save[22] = "";
				save[23] = "";

				save[53] = "";
				save[54] = "";
				save[55] = "";
				save[56] = "";

				save[24] = PZZ010_CharacterUtil.strEncode(request.getParameter("A003_Keihatu"));
				save[25] = PZZ010_CharacterUtil.strEncode(request.getParameter("A004_Ido"));
				save[26] = "";
				save[27] = "";
				save[28] = "";
				save[29] = "";
				save[30] = "";
				save[31] = "";
				save[32] = "";
				save[33] = "";
				save[34] = PZZ010_CharacterUtil.strEncode(request.getParameter("A005_Tuiki"));
				save[35] = PZZ010_CharacterUtil.strEncode(request.getParameter("A006_Jyou"));
				save[36] = "          ";
				save[37] = HcdbDef.flg1;
				save[38] = HcdbDef.flg0;
				save[39] = PZZ010_CharacterUtil.GetDay();
				save[40] = PZZ010_CharacterUtil.GetTime();
				save[41] = "";
				save[42] = "";
				save[43] = kanji;
				save[44] = busyo;
				save[45] = "";
				save[46] = "";
				save[57] = "BLOB_DATA";
				save[58] = "";
				/* 2007/01/04 yoshida add start */
				if (request.getParameter("H002_SyokuCode2") == null || request.getParameter("H002_SyokuCode2").equals("DUMMY")) {
					save[59] = "";
				} else {
					save[59] = request.getParameter("H002_SyokuCode2");
				}
				if (request.getParameter("H004_SenmonCode2") == null || request.getParameter("H004_SenmonCode2").equals("DUMMY")) {
					save[60] = "";
				} else {
					save[60] = request.getParameter("H004_SenmonCode2");
				}
				if (request.getParameter("H006_LevelCode2") == null || request.getParameter("H006_LevelCode2").equals("DUMMY")) {
					save[61] = "";
				} else {
					save[61] = request.getParameter("H006_LevelCode2");
				}
				if (request.getParameter("H002_SyokuCode3") == null || request.getParameter("H002_SyokuCode3").equals("DUMMY")) {
					save[62] = "";
				} else {
					save[62] = request.getParameter("H002_SyokuCode3");
				}
				if (request.getParameter("H004_SenmonCode3") == null || request.getParameter("H004_SenmonCode3").equals("DUMMY")) {
					save[63] = "";
				} else {
					save[63] = request.getParameter("H004_SenmonCode3");
				}
				if (request.getParameter("H006_LevelCode3") == null || request.getParameter("H006_LevelCode3").equals("DUMMY")) {
					save[64] = "";
				} else {
					save[64] = request.getParameter("H006_LevelCode3");
				}
				/* 2007/01/04 yoshida add start */

				/* PDF�쐬 */
				final PZE070_ChallengePDF pdf = new PZE070_ChallengePDF(login_no);

				/* PDF���ږ��̎擾 */
				final String[] outDefItem = challengebean.getoutDefPDF2(save[1], save[3]);

				/* ��ر���ݼގ����ް� */
				final PBB_CareerChallenge challengeResult = new PBB_CareerChallenge(); /* 2007/01/09 yoshida edit */

				/* ��ر���ݼތv���ް� */
				PBB_CareerChallenge challengePlan = new PBB_CareerChallenge(); /* 2007/01/09 yoshida edit */

				/* �E�����e���ް� */
				final String[][] syokumuData = challengebean.getSyokumuData();

				/* �v��̏ꍇ */
				if (request.getParameter("H015_Kubun").equals("1")) {
					/* 2007/01/09 yoshida edit start */
					/* �f�f�� */
					challengePlan.setSindansyaBusyoRyakusyoMei(save[44]);
					challengePlan.setSindansya(save[0]);
					challengePlan.setSindansyaKanjiSimei(save[43]);
					challengePlan.setJissiNengappi(save[39]);
					/* ���F�� */
					challengePlan.setSyoninsyaBusyoRyakusyoMei(save[46]);
					challengePlan.setSyoninsya(save[36]);
					challengePlan.setSyoninsyaKanjiSimei(save[45]);
					challengePlan.setSyoninNengappi(save[41]);
					/* �����ڕW */
					challengePlan.setMokuhyoSyokuCode(save[4]);
					challengePlan.setMokuhyoSenmonCode(save[5]);
					challengePlan.setMokuhyoLevelCode(save[6]);
					challengePlan.setMokuhyoSyokuCode2(save[59]);
					challengePlan.setMokuhyoSenmonCode2(save[60]);
					challengePlan.setMokuhyoLevelCode2(save[61]);
					challengePlan.setMokuhyoSyokuCode3(save[62]);
					challengePlan.setMokuhyoSenmonCode3(save[63]);
					challengePlan.setMokuhyoLevelCode3(save[64]);
					/* �Ɩ��o�� */
					challengePlan.setGyomuKeiken(save[7]);
					/* �����u */
					challengePlan.setKyoikuZyukou(save[8]);
					/* �擾���i */
					challengePlan.setSikakuMeisyo1(save[47]);
					challengePlan.setSikakuLevelMei1(save[48]);
					challengePlan.setSikakuTokuten1(save[11]);
					challengePlan.setSikakuMeisyo2(save[49]);
					challengePlan.setSikakuLevelMei2(save[50]);
					challengePlan.setSikakuTokuten2(save[14]);
					challengePlan.setSikakuMeisyo3(save[51]);
					challengePlan.setSikakuLevelMei3(save[52]);
					challengePlan.setSikakuTokuten3(save[17]);

					/* 2007/01/09 yoshida edit end */

					challengePlan.setJikoKeihatu(save[24]);
					challengePlan.setIdoKibo(save[25]);
					challengePlan.setTuikiJiko(save[34]);

					/* ���т̏ꍇ */
				} else {
					/* �O���Ԍv������擾 */
					challengePlan = challengebean.getPreCareerChallengePlan(); /* 2007/01/09 yoshida edit */
				}

				/* �E��R�[�h */
				String syokusyuCode = "";
				syokusyuCode = save[4];

				/* ��啪��R�[�h */
				String senmonCode = "";
				senmonCode = save[5];

				/* ���x���R�[�h */
				String levelCode = "";
				levelCode = save[6];

				/* �E�� */
				if (!syokusyuCode.equals("")) {
					challengePlan.setMokuhyoSyokuName(PBY_SkillStandardBean.getSyokuName(syokusyuCode)); /* 2007/01/09 yoshida edit */
				}

				/* ��啪�� */
				if (!senmonCode.equals("")) {
					challengePlan.setMokuhyoSenmonName(PBY_SkillStandardBean.getSenmonName(syokusyuCode, senmonCode)); /* 2007/01/09 yoshida edit */
				}

				/* ���x�� */
				if (!levelCode.equals("")) {
					challengePlan.setMokuhyoLevelName(PBY_SkillStandardBean.getLevelName(syokusyuCode, senmonCode, levelCode)); /* 2007/01/09 yoshida edit */
				}
				/* 2007/01/09 yoshida add start */
				if (!save[59].equals("")) {
					challengePlan.setMokuhyoSyokuName2(PBY_SkillStandardBean.getSyokuName(save[59]));
				}
				if (!save[60].equals("")) {
					challengePlan.setMokuhyoSenmonName2(PBY_SkillStandardBean.getSenmonName(save[59], save[60]));
				}
				if (!save[61].equals("")) {
					challengePlan.setMokuhyoLevelName2(PBY_SkillStandardBean.getLevelName(save[59], save[60], save[61]));
				}
				if (!save[62].equals("")) {
					challengePlan.setMokuhyoSyokuName3(PBY_SkillStandardBean.getSyokuName(save[62]));
				}
				if (!save[63].equals("")) {
					challengePlan.setMokuhyoSenmonName3(PBY_SkillStandardBean.getSenmonName(save[62], save[63]));
				}
				if (!save[64].equals("")) {
					challengePlan.setMokuhyoLevelName3(PBY_SkillStandardBean.getLevelName(save[62], save[63], save[64]));
				}
				/* 2007/01/09 yoshida add end */
				/* �v��PDF�쐬 */
				if (request.getParameter("H015_Kubun").equals("1")) {

					/* �v�掞�͎��я��̕\���͂��Ȃ����ߋ󕶎����Z�b�g���� */
					/* 2007/01/09 yoshida edit start */
					challengeResult.setGyomuKeiken("");
					challengeResult.setKyoikuZyukou("");
					challengeResult.setJikoKeihatu("");
					challengeResult.setIdoKibo("");
					challengeResult.setTuikiJiko("");
					challengeResult.setZyouComment("");
					/* 2007/01/09 yoshida edit end */

					/* ���i�ް� */
					final String[][] sikakuData = challengebean.getSikakuData();

					/* ���Z�b�g */
					pdf.setChallengeValue(outDefItem, request.getParameter("H015_Kubun"), challengePlan, challengeResult); /* 2007/01/09 yoshida edit */
					pdf.setKikanmei(save[1]);
					pdf.setSikakuValue(sikakuData);
					pdf.setSyokumuValue(syokumuData);
					pdf.setAssessmentValue(challengebean.getAssessmentSindan(), challengebean.getAssessmentHyoka()); /* 2007/01/09 yoshida edit */
					pdf.setAssessment2Value(challengebean.getAssessmentSindan2(), challengebean.getAssessmentHyoka2()); /* 2007/01/09 yoshida edit */
					pdf.setAssessment3Value(challengebean.getAssessmentSindan3(), challengebean.getAssessmentHyoka3()); /* 2007/01/09 yoshida edit */
					pdf.setPreChallenge(challengebean.getPreCareerChallengePlan()); /* 2007/01/09 yoshida add */
					final ByteArrayOutputStream baos = new ByteArrayOutputStream();
					pdf.executePDF(baos);

					/* �v����͎��������T�[�x�C�������ɃR�~�b�g���� */
					final String[] moral = challengebean.getAddMoral();
					moral[0] = save[0];
					moral[1] = save[1];
					moral[2] = save[2];
					moral[29] = save[39];
					moral[30] = save[40];
					moral[31] = save[43];
					moral[32] = save[44];

					/* �ēxbean�ɃZ�b�g���� */
					challengebean.AddChallengePlan(moral, save, baos.toByteArray());

					/* ����PDF�쐬 */
				} else {

					challengeResult.setGyomuKeiken(save[7]);
					challengeResult.setKyoikuZyukou(save[8]);
					challengeResult.setJikoKeihatu(save[24]);
					challengeResult.setIdoKibo(save[25]);
					challengeResult.setTuikiJiko(save[34]);
					challengeResult.setZyouComment(save[35]);
					challengeResult.setSyoninsya(""); // �쐬���͏��F���͑��݂��Ȃ�
					challengeResult.setSyoninNengappi("");
					challengeResult.setSindansyaKanjiSimei(challengebean.getResultData()[43]);
					challengeResult.setSindansyaBusyoRyakusyoMei(challengebean.getResultData()[44]);
					challengeResult.setSyoninsyaKanjiSimei("");
					challengeResult.setSyoninsyaBusyoRyakusyoMei("");
					challengeResult.setSikakuMeisyo1(save[47]);
					challengeResult.setSikakuLevelMei1(save[48]);
					challengeResult.setSikakuTokuten1(save[11]);
					challengeResult.setSikakuMeisyo2(save[49]);
					challengeResult.setSikakuLevelMei2(save[50]);
					challengeResult.setSikakuTokuten2(save[14]);
					challengeResult.setSikakuMeisyo3(save[51]);
					challengeResult.setSikakuLevelMei3(save[52]);
					challengeResult.setSikakuTokuten3(save[17]);

					/* ���Z�b�g */
					pdf.setChallengeValue(outDefItem, request.getParameter("H015_Kubun"), challengePlan, challengeResult);
					pdf.setKikanmei(save[1]);
					pdf.setChallengePlan(challengePlan);
					pdf.setAssessmentValue(challengebean.getAssessmentSindan(), challengebean.getAssessmentHyoka());
					pdf.setAssessment2Value(challengebean.getAssessmentSindan2(), challengebean.getAssessmentHyoka2());
					pdf.setAssessment3Value(challengebean.getAssessmentSindan3(), challengebean.getAssessmentHyoka3());
					pdf.setPreChallenge(challengebean.getPreCareerChallengePlan());

					final ByteArrayOutputStream baos = new ByteArrayOutputStream();
					pdf.executePDF(baos);

					/* �o�^���\�b�h�Ăяo�� */
					challengebean.AddChallengeResult(save, baos.toByteArray());
				}

				/* ���݂̃��j���[�ɂ��J�ڐ��ݒ� */
				String next_url = "";
				final String gamenLinkID = menuSeigyoBean.getTargetGamenLinkId(); // ���ݕ\�����̃��j���[�̉��ID���擾
				if (gamenLinkID.equalsIgnoreCase("DZZ901") || gamenLinkID.equalsIgnoreCase("DZZ902")) {
					// �L�����A�`�������W���{���̏ꍇ
					next_url = "/servlet/PBB010_CareerChallengeHanteiServlet";
				} else {
					// ����ȊO�̑J��(�L�����A�`�������W��������̑J��)
					next_url = "/view/plan/careerchallenge/VBB060_SelectHistoryMain.jsp";
				}
				Log.debug("next_url:" + next_url);
				final RequestDispatcher rd = this.ctx.getRequestDispatcher(next_url);
				rd.forward(request, response);
				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}
}
