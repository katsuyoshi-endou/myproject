/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�g�D�n �_�E�����[�h�@�\ �����p�̃f�[�^�i�[�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/08/11  03-00  ���H�� �G�F    �V�K�쐬
 */
package jp.co.hisas.career.plan.search.bean;

import java.io.Serializable;

/**
 * @author h-nerome ���̐������ꂽ�R�����g�̑}�������e���v���[�g��ύX���邽�� �E�B���h�E > �ݒ� > Java > �R�[�h���� > �R�[�h�ƃR�����g
 */
public class PBE_DownloadCsvSougouBean extends PBE_ValueBean implements Serializable {

	/** ����NO �f�f�� */
	private String sindansya = "";

	/** �����i�����j */
	private String kanji_simei = "";

	/** �����i�J�i�j */
	private String kana_simei = "";

	/** ����(�p��) */
	private String eiji_simei = "";

	/** ����NO �]���� */
	private String hyokasya = "";

	/** �����i�����j */
	private String kanji_simei_hyo = "";

	/** �����i�J�i�j */
	private String kana_simei_hyo = "";

	/** ����(�p��) */
	private String eiji_simei_hyo = "";

	/** �g�D�R�[�h */
	private String sosiki_code = "";

	/** �������̖� */
	private String busyo_ryakusyo_mei = "";

	/** �����R�[�h�P */
	private String syozoku_code_1 = "";

	/** �����R�[�h�Q */
	private String syozoku_code_2 = "";

	/** �����R�[�h�R */
	private String syozoku_code_3 = "";

	/** �����R�[�h�S */
	private String syozoku_code_4 = "";

	/** �����R�[�h�T */
	private String syozoku_code_5 = "";

	/** �����R�[�h�U */
	private String syozoku_code_6 = "";

	/** �����R�[�h�V */
	private String syozoku_code_7 = "";

	/** �����R�[�h�W */
	private String syozoku_code_8 = "";

	/** �����R�[�h�X */
	private String syozoku_code_9 = "";

	/** �������̂P */
	private String syozoku_name_1 = "";

	/** �������̂Q */
	private String syozoku_name_2 = "";

	/** �������̂R */
	private String syozoku_name_3 = "";

	/** �������̂S */
	private String syozoku_name_4 = "";

	/** �������̂T */
	private String syozoku_name_5 = "";

	/** �������̂U */
	private String syozoku_name_6 = "";

	/** �������̂V */
	private String syozoku_name_7 = "";

	/** �������̂W */
	private String syozoku_name_8 = "";

	/** �������̂X */
	private String syozoku_name_9 = "";

	/** �g�D�� */
	private String sosiki_mei = "";

	/** ��E�R�[�h */
	private String yakusyoku_code = "";

	/** ��E�� */
	private String yakusyoku_name = "";

	/** �N�� */
	private String seinengappi = "";

	/** SAS���ДN�� */
	private String hitachi_sas_nyusya_nengetu = "";

	/** �E��R�[�h */
	private String syoku_code = "";

	/** �E�� */
	private String syoku_name = "";

	/** ��啪��R�[�h */
	private String senmon_code = "";

	/** ��啪�� */
	private String senmon_name = "";

	/** ���x���R�[�h */
	private String level_code = "";

	/** ���x�� */
	private String level_name = "";

	/** ���{�� */
	private String jissi_kaisu = "";

	/** �Ɩ��o���B���x�i�{�l�j */
	private String gyomu_keiken_t_do = "";

	/** �X�L���B���x�i�{�l�j */
	private String skill_t_do = "";

	/** �����B���x�i�{�l�j */
	private String sougou_t_do = "";

	/** �Ɩ��o���B���x�i�]���ҁj */
	private String gyomu_keiken_t_do_hyo = "";

	/** �X�L���B���x�i�]���ҁj */
	private String skill_t_do_hyo = "";

	/** �����B���x�i�]���ҁj */
	private String sougou_t_do_hyo = "";

	/** ���{�N�����i�{�l�j */
	private String jissi_nengappi = "";

	/** �]���N���� */
	private String hyoka_nengappi = "";

	/** �L�����A�`�������W���� */
	private String career_challenge_kikan_mei = "";

	/**
	 * �f�t�H���g�̃R���X�g���N�^�ł��B
	 */
	public PBE_DownloadCsvSougouBean() {
		super();
	}

	/**
	 * @return
	 */
	public String getBusyo_ryakusyo_mei() {
		return this.busyo_ryakusyo_mei;
	}

	/**
	 * @return
	 */
	public String getCareer_challenge_kikan_mei() {
		return this.career_challenge_kikan_mei;
	}

	/**
	 * @return
	 */
	public String getGyomu_keiken_t_do() {
		return this.gyomu_keiken_t_do;
	}

	/**
	 * @return
	 */
	public String getGyomu_keiken_t_do_hyo() {
		return this.gyomu_keiken_t_do_hyo;
	}

	/**
	 * @return
	 */
	public String getHitachi_sas_nyusya_nengetu() {
		return this.hitachi_sas_nyusya_nengetu;
	}

	/**
	 * @return
	 */
	public String getJissi_kaisu() {
		return this.jissi_kaisu;
	}

	/**
	 * @return
	 */
	public String getJissi_nengappi() {
		return this.jissi_nengappi;
	}

	/**
	 * @return
	 */
	public String getKana_simei() {
		return this.kana_simei;
	}

	/**
	 * @return
	 */
	public String getKanji_simei() {
		return this.kanji_simei;
	}

	/**
	 * @return
	 */
	public String getEiji_simei() {
		return this.eiji_simei;
	}

	/**
	 * @return
	 */
	public String getHyokasya() {
		return this.hyokasya;
	}

	/**
	 * @return
	 */
	public String getKanjiSimeiHyo() {
		return this.kanji_simei_hyo;
	}

	/**
	 * @return
	 */
	public String getKanaSimeiHyo() {
		return this.kana_simei_hyo;
	}

	/**
	 * @return
	 */
	public String getEijiSimeiHyo() {
		return this.eiji_simei_hyo;
	}

	/**
	 * @return
	 */
	public String getLevel_code() {
		return this.level_code;
	}

	/**
	 * @return
	 */
	public String getLevel_name() {
		return this.level_name;
	}

	/**
	 * @return
	 */
	public String getSeinengappi() {
		return this.seinengappi;
	}

	/**
	 * @return
	 */
	public String getSenmon_code() {
		return this.senmon_code;
	}

	/**
	 * @return
	 */
	public String getSenmon_name() {
		return this.senmon_name;
	}

	/**
	 * @return
	 */
	public String getSindansya() {
		return this.sindansya;
	}

	/**
	 * @return
	 */
	public String getSkill_t_do() {
		return this.skill_t_do;
	}

	/**
	 * @return
	 */
	public String getSkill_t_do_hyo() {
		return this.skill_t_do_hyo;
	}

	/**
	 * @return
	 */
	public String getSosiki_code() {
		return this.sosiki_code;
	}

	/**
	 * @return
	 */
	public String getSosiki_mei() {
		return this.sosiki_mei;
	}

	/**
	 * @return
	 */
	public String getSougou_t_do() {
		return this.sougou_t_do;
	}

	/**
	 * @return
	 */
	public String getSougou_t_do_hyo() {
		return this.sougou_t_do_hyo;
	}

	/**
	 * @return
	 */
	public String getSyoku_code() {
		return this.syoku_code;
	}

	/**
	 * @return
	 */
	public String getSyoku_name() {
		return this.syoku_name;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_1() {
		return this.syozoku_code_1;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_2() {
		return this.syozoku_code_2;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_3() {
		return this.syozoku_code_3;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_4() {
		return this.syozoku_code_4;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_5() {
		return this.syozoku_code_5;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_6() {
		return this.syozoku_code_6;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_7() {
		return this.syozoku_code_7;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_8() {
		return this.syozoku_code_8;
	}

	/**
	 * @return
	 */
	public String getSyozoku_code_9() {
		return this.syozoku_code_9;
	}

	/**
	 * @return
	 */
	public String getSyozoku_name_1() {
		return this.syozoku_name_1;
	}

	/**
	 * @return
	 */
	public String getSyozoku_name_2() {
		return this.syozoku_name_2;
	}

	/**
	 * @return
	 */
	public String getSyozoku_name_3() {
		return this.syozoku_name_3;
	}

	/**
	 * @return
	 */
	public String getSyozoku_name_4() {
		return this.syozoku_name_4;
	}

	/**
	 * @return
	 */
	public String getSyozoku_name_5() {
		return this.syozoku_name_5;
	}

	/**
	 * @return
	 */
	public String getSyozoku_name_6() {
		return this.syozoku_name_6;
	}

	/**
	 * @return
	 */
	public String getSyozoku_name_7() {
		return this.syozoku_name_7;
	}

	/**
	 * @return
	 */
	public String getSyozoku_name_8() {
		return this.syozoku_name_8;
	}

	/**
	 * @return
	 */
	public String getSyozoku_name_9() {
		return this.syozoku_name_9;
	}

	/**
	 * @return
	 */
	public String getYakusyoku_code() {
		return this.yakusyoku_code;
	}

	/**
	 * @return
	 */
	public String getYakusyoku_name() {
		return this.yakusyoku_name;
	}

	/**
	 * @param string
	 */
	public void setBusyo_ryakusyo_mei(final String string) {
		this.busyo_ryakusyo_mei = string;
	}

	/**
	 * @param string
	 */
	public void setCareer_challenge_kikan_mei(final String string) {
		this.career_challenge_kikan_mei = string;
	}

	/**
	 * @param string
	 */
	public void setGyomu_keiken_t_do(final String string) {
		this.gyomu_keiken_t_do = string;
	}

	/**
	 * @param string
	 */
	public void setGyomu_keiken_t_do_hyo(final String string) {
		this.gyomu_keiken_t_do_hyo = string;
	}

	/**
	 * @param string
	 */
	public void setHitachi_sas_nyusya_nengetu(final String string) {
		this.hitachi_sas_nyusya_nengetu = string;
	}

	/**
	 * @param string
	 */
	public void setJissi_kaisu(final String string) {
		this.jissi_kaisu = string;
	}

	/**
	 * @param string
	 */
	public void setJissi_nengappi(final String string) {
		this.jissi_nengappi = string;
	}

	/**
	 * @param string
	 */
	public void setKana_simei(final String string) {
		this.kana_simei = string;
	}

	/**
	 * @param string
	 */
	public void setKanji_simei(final String string) {
		this.kanji_simei = string;
	}

	/**
	 * @param string
	 */
	public void setEiji_simei(final String string) {
		this.eiji_simei = string;
	}

	/**
	 * @param string
	 */
	public void setHyokasya(final String string) {
		this.hyokasya = string;
	}

	/**
	 * @param string
	 */
	public void setKanjiSimeiHyo(final String string) {
		this.kanji_simei_hyo = string;
	}

	/**
	 * @param string
	 */
	public void setKanaSimeiHyo(final String string) {
		this.kana_simei_hyo = string;
	}

	/**
	 * @param string
	 */
	public void setEijiSimeiHyo(final String string) {
		this.eiji_simei_hyo = string;
	}

	/**
	 * @param string
	 */
	public void setLevel_code(final String string) {
		this.level_code = string;
	}

	/**
	 * @param string
	 */
	public void setLevel_name(final String string) {
		this.level_name = string;
	}

	/**
	 * @param string
	 */
	public void setSeinengappi(final String string) {
		this.seinengappi = string;
	}

	/**
	 * @param string
	 */
	public void setSenmon_code(final String string) {
		this.senmon_code = string;
	}

	/**
	 * @param string
	 */
	public void setSenmon_name(final String string) {
		this.senmon_name = string;
	}

	/**
	 * @param string
	 */
	public void setSindansya(final String string) {
		this.sindansya = string;
	}

	/**
	 * @param string
	 */
	public void setSkill_t_do(final String string) {
		this.skill_t_do = string;
	}

	/**
	 * @param string
	 */
	public void setSkill_t_do_hyo(final String string) {
		this.skill_t_do_hyo = string;
	}

	/**
	 * @param string
	 */
	public void setSosiki_code(final String string) {
		this.sosiki_code = string;
	}

	/**
	 * @param string
	 */
	public void setSosiki_mei(final String string) {
		this.sosiki_mei = string;
	}

	/**
	 * @param string
	 */
	public void setSougou_t_do(final String string) {
		this.sougou_t_do = string;
	}

	/**
	 * @param string
	 */
	public void setSougou_t_do_hyo(final String string) {
		this.sougou_t_do_hyo = string;
	}

	/**
	 * @param string
	 */
	public void setSyoku_code(final String string) {
		this.syoku_code = string;
	}

	/**
	 * @param string
	 */
	public void setSyoku_name(final String string) {
		this.syoku_name = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_1(final String string) {
		this.syozoku_code_1 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_2(final String string) {
		this.syozoku_code_2 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_3(final String string) {
		this.syozoku_code_3 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_4(final String string) {
		this.syozoku_code_4 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_5(final String string) {
		this.syozoku_code_5 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_6(final String string) {
		this.syozoku_code_6 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_7(final String string) {
		this.syozoku_code_7 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_8(final String string) {
		this.syozoku_code_8 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_code_9(final String string) {
		this.syozoku_code_9 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_name_1(final String string) {
		this.syozoku_name_1 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_name_2(final String string) {
		this.syozoku_name_2 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_name_3(final String string) {
		this.syozoku_name_3 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_name_4(final String string) {
		this.syozoku_name_4 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_name_5(final String string) {
		this.syozoku_name_5 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_name_6(final String string) {
		this.syozoku_name_6 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_name_7(final String string) {
		this.syozoku_name_7 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_name_8(final String string) {
		this.syozoku_name_8 = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku_name_9(final String string) {
		this.syozoku_name_9 = string;
	}

	/**
	 * @param string
	 */
	public void setYakusyoku_code(final String string) {
		this.yakusyoku_code = string;
	}

	/**
	 * @param string
	 */
	public void setYakusyoku_name(final String string) {
		this.yakusyoku_name = string;
	}

	/**
	 * @return
	 */
	public String getHyokaNengappi() {
		return this.hyoka_nengappi;
	}

	/**
	 * @param string
	 */
	public void setHyokaNengappi(final String string) {
		this.hyoka_nengappi = string;
	}

}
