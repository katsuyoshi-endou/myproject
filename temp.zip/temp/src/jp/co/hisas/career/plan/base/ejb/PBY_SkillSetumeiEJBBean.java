/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ020_MakeSQLUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �T�v: DB�A�N�Z�X���s���A�e�R�[�h�̌����A�X�V�A�폜���s���A�X�e�[�g���XSessionBean�B �g�p���@: �����[�g�C���^�t�F�[�X����āA�N���C�A���gBean����Ăяo���B
 * 
 * </PRE>
 */
public class PBY_SkillSetumeiEJBBean implements SessionBean {
	/** SessionContext�I�u�W�F�N�g */
	private SessionContext my_ssc = null;

	/** �z��ԍ� */
	private int index;

	/** �E��}�X�^ */
	private static final String tbl01 = HcdbDef.p_syokusyuTbl;

	/** ��啪��}�X�^ */
	private static final String tbl02 = HcdbDef.p_senmonTbl;

	/** �X�L�����ڃ}�X�^ */
	private static final String tbl03 = HcdbDef.p_skill_komokuTbl;

	/** �B���x�w�W�e�[�u�� */
	private static final String tbl05 = HcdbDef.p_tasseidoTbl;

	/** �B���x�敪�e�[�u�� */
	private static final String tbl09 = HcdbDef.p_tasseido_kubunTbl;

	/** �B���x�敪�ڍ׃e�[�u�� */
	private static final String tbl11 = HcdbDef.p_tasseido_kubun_syosaiTbl;

	/** �X�L���Y�C���x���g���̐ڑ������� */
	private static final String SKILL_JOIN = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DBG028"));

	/**
	 * �w�肳�ꂽ�E��̖������擾
	 * @param syoku_code
	 * @return ����
	 * @throws SQLException
	 * @throws NamingException
	 */
	public String[] SearchSyokusyuYakuwari(final String login_no, final String syoku_code) throws SQLException, NamingException {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* SQL�X�e�[�g�����g�̔��s */
			String sql = "SELECT " + HcdbDef.SYOKUSYU_YAKUWARI_COLUMN[0];
			for (int i = 1; i < HcdbDef.SYOKUSYU_YAKUWARI_COLUMN.length; i++) {
				sql = sql + "," + HcdbDef.SYOKUSYU_YAKUWARI_COLUMN[i];
			}
			sql = sql + " FROM " + PBY_SkillSetumeiEJBBean.tbl01 + " WHERE " + HcdbDef.p01_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "'";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			final String[] yakuwari = new String[HcdbDef.SYOKUSYU_YAKUWARI_COLUMN.length];
			while (rs.next()) {
				if (rs.getString(HcdbDef.SYOKUSYU_YAKUWARI_COLUMN[0]) != null) {
					for (int i = 0; i < HcdbDef.SYOKUSYU_YAKUWARI_COLUMN.length; i++) {
						yakuwari[i] = rs.getString(HcdbDef.SYOKUSYU_YAKUWARI_COLUMN[i]);
					}
				}
			}

			stmt.close();
			rs.close();
			Log.method(login_no, "OUT", "");
			return yakuwari;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �w��E��̐�啪��������X�g��Ԃ�
	 * @param syoku_code
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 */
	public String[][] SearchSenmonYakuwariList(final String login_no, final String syoku_code) throws SQLException, NamingException {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* ���R�[�h�����擾 */
			String sql = "SELECT COUNT(" + HcdbDef.p02_column[0] + ") FROM " + PBY_SkillSetumeiEJBBean.tbl02 + " WHERE " + HcdbDef.p02_column[0] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "'";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			final String senmon_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT " + HcdbDef.SENMON_YAKUWARI_COLUMN[0];
			for (int i = 1; i < HcdbDef.SENMON_YAKUWARI_COLUMN.length; i++) {
				sql = sql + "," + HcdbDef.SENMON_YAKUWARI_COLUMN[i];
			}
			sql = sql + " FROM " + PBY_SkillSetumeiEJBBean.tbl02 + " WHERE " + HcdbDef.p02_column[0] + " = '" + syoku_code + "' ORDER BY " + HcdbDef.p02_column[1] + " ASC";

			stmt = dbConn.createStatement();
			rs = stmt.executeQuery(sql);

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			final String[][] yakuwari = new String[Integer.parseInt(senmon_line)][HcdbDef.SENMON_YAKUWARI_COLUMN.length];
			this.index = 0;
			while (rs.next()) {
				if (rs.getString(HcdbDef.SENMON_YAKUWARI_COLUMN[0]) != null) {
					for (int i = 0; i < HcdbDef.SENMON_YAKUWARI_COLUMN.length; i++) {
						yakuwari[this.index][i] = rs.getString(HcdbDef.SENMON_YAKUWARI_COLUMN[i]);
					}
				}
				this.index++;
			}

			Log.method(login_no, "OUT", "");
			return yakuwari;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �w�肳�ꂽ�E��E��啪��E���x���̐������擾����
	 * @param syoku_code
	 * @param senmon_code
	 * @param level_code
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 */
	public String[][] SearchTasseidoSihyoSetumei(final String login_no, final String syoku_code, final String senmon_code, final String level_code) throws SQLException, NamingException {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* ���R�[�h�����擾 */
			String sql = "SELECT COUNT(P05." + HcdbDef.p05_column[0] + ") FROM " + PBY_SkillSetumeiEJBBean.tbl05 + " P05, " + PBY_SkillSetumeiEJBBean.tbl09 + " P09, " + PBY_SkillSetumeiEJBBean.tbl11
					+ " P11 " + " WHERE P05." + HcdbDef.p05_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "'  AND P05." + HcdbDef.p05_column[1] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "'  AND P05." + HcdbDef.p05_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(level_code) + "'  AND P05."
					+ HcdbDef.p05_column[3] + " = P09." + HcdbDef.p09_column[0] + "   AND P05." + HcdbDef.p05_column[0] + " = P11." + HcdbDef.p11_column[0] + "   AND P05." + HcdbDef.p05_column[1]
					+ " = P11." + HcdbDef.p11_column[1] + "   AND P05." + HcdbDef.p05_column[2] + " = P11." + HcdbDef.p11_column[2] + "   AND P05." + HcdbDef.p05_column[3] + " = P11."
					+ HcdbDef.p11_column[3];

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);
			rs.next();
			final String tasseido_line = rs.getString(1).trim();

			// ��SQL���s�̂��߂Ɉ�xclose
			PZZ040_SQLUtility.closeConnection(login_no, null, stmt, rs);

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT " + HcdbDef.LEVEL_SETUMEI_COLOMN[0];
			for (int i = 1; i < HcdbDef.LEVEL_SETUMEI_COLOMN.length; i++) {
				sql = sql + "," + HcdbDef.LEVEL_SETUMEI_COLOMN[i];
			}
			sql = sql + " FROM " + PBY_SkillSetumeiEJBBean.tbl05 + " P05, " + PBY_SkillSetumeiEJBBean.tbl09 + " P09, " + PBY_SkillSetumeiEJBBean.tbl11 + " P11 " + " WHERE P05."
					+ HcdbDef.p05_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "'  AND P05." + HcdbDef.p05_column[1] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "'  AND P05." + HcdbDef.p05_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(level_code) + "'  AND P05."
					+ HcdbDef.p05_column[3] + " = P09." + HcdbDef.p09_column[0] + "   AND P05." + HcdbDef.p05_column[0] + " = P11." + HcdbDef.p11_column[0] + "   AND P05." + HcdbDef.p05_column[1]
					+ " = P11." + HcdbDef.p11_column[1] + "   AND P05." + HcdbDef.p05_column[2] + " = P11." + HcdbDef.p11_column[2] + "   AND P05." + HcdbDef.p05_column[3] + " = P11."
					+ HcdbDef.p11_column[3] + " ORDER BY P05." + HcdbDef.p05_column[3] + " ASC, P05." + HcdbDef.p05_column[4] + " ASC";

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			final String[][] setumei = new String[Integer.parseInt(tasseido_line)][HcdbDef.LEVEL_SETUMEI_COLOMN.length];
			this.index = 0;
			while (rs.next()) {
				if (rs.getString(1) != null) {
					for (int i = 0; i < HcdbDef.LEVEL_SETUMEI_COLOMN.length; i++) {
						setumei[this.index][i] = rs.getString(i + 1);
					}
				}
				this.index++;
			}
			Log.method(login_no, "OUT", "");
			return setumei;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	/**
	 * �m�����ڂ�Ԃ�
	 * @param login_no
	 * @param syoku_code
	 * @param senmon_code
	 * @param skill_code
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 */
	public String[] SearchTisikiKomuku(final String login_no, final String syoku_code, final String senmon_code, final String skill_code) throws SQLException, NamingException {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// DB�R�l�N�V�����ڑ�
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* SQL�X�e�[�g�����g�̔��s */
			String sql = "SELECT " + HcdbDef.TISIKI_KOMOKU_COLUMN[0];
			for (int i = 1; i < HcdbDef.TISIKI_KOMOKU_COLUMN.length; i++) {
				sql = sql + "," + HcdbDef.TISIKI_KOMOKU_COLUMN[i];
			}
			sql = sql + " FROM " + PBY_SkillSetumeiEJBBean.tbl01 + " P01, " + PBY_SkillSetumeiEJBBean.tbl02 + " P02, " + PBY_SkillSetumeiEJBBean.tbl03 + " P03" + " WHERE P01." + HcdbDef.p01_column[0]
					+ " = P02." + HcdbDef.p02_column[0] + "  AND  P02." + HcdbDef.p02_column[1] + " = P03." + HcdbDef.p03_column[1] + "  AND  P01." + HcdbDef.p01_column[0] + " = P03."
					+ HcdbDef.p03_column[0] + "  AND  P03." + HcdbDef.p03_column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(syoku_code) + "' AND  P03." + HcdbDef.p03_column[1] + " = '"
					+ PZZ020_MakeSQLUtil.sanitizeSQLData(senmon_code) + "' AND  P03." + HcdbDef.p03_column[2] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(skill_code) + "'";

			Log.debug(sql);

			stmt = dbConn.createStatement();

			/* �f�o�b�O���O�̏o�� */
			Log.debug(sql);

			rs = stmt.executeQuery(sql);

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			final String[] tisiki = new String[HcdbDef.TISIKI_KOMOKU_COLUMN.length];
			while (rs.next()) {
				if (rs.getString(1) != null) {
					for (int i = 0; i < HcdbDef.TISIKI_KOMOKU_COLUMN.length; i++) {
						tisiki[i] = rs.getString(i + 1);
					}
				}
			}

			Log.method(login_no, "OUT", "");
			return tisiki;
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, stmt, rs);
		}
	}

	// --- 20070117 K.takagi Add ---
	/**
	 * �����`��Ԃ�
	 * @param login_no
	 * @param syoku_code
	 * @param senmon_code
	 * @param skill_code
	 * @param level_code
	 * @param sosiki_code
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 */
	public String SearchBumonTeigiInfo(final String login_no, final String syoku_code, final String senmon_code, final String skill_code, final String level_code, final String sosiki_code)
			throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			dbConn = PZZ040_SQLUtility.getConnection(login_no);
			/* ���R�[�h�����擾 */
			String sql = "SELECT COUNT(sosiki_code) FROM T19_SOSIKI_TBL  START WITH  sosiki_code = ? CONNECT BY PRIOR joui_sosiki_code=sosiki_code ORDER SIBLINGS BY sosiki_code DESC";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.setString(1, sosiki_code);

			rs = pstmt.executeQuery();
			rs.next();
			String zentei_cnt = rs.getString(1);

			PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);

			/* 0���̏ꍇ��Null�Ԃ� */
			if (zentei_cnt.equals("0")) {
				return null;
			}

			/* SQL�X�e�[�g�����g�̔��s */
			sql = "SELECT sosiki_code FROM T19_SOSIKI_TBL  START WITH  sosiki_code = ? CONNECT BY PRIOR joui_sosiki_code=sosiki_code ORDER SIBLINGS BY sosiki_code DESC";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.setString(1, sosiki_code);
			rs = pstmt.executeQuery();

			/* �������ʂ��e���ڂ��ƂɎ擾 */
			final String[] sosiki = new String[Integer.parseInt(zentei_cnt)];
			this.index = 0;
			while (rs.next()) {
				sosiki[this.index] = rs.getString(1);
				this.index++;
			}
			PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);

			// �����`�擾
			String bumon_teigi = null;
			for (int i = 0; i < sosiki.length; i++) {
				sql = "SELECT COUNT(SOSIKI_CODE) FROM CKG_SKILL_JYUKUTATUDO_SETSUMON WHERE SOSIKI_CODE = ? AND SYOKU_CODE = ? AND SENMON_CODE = ? AND LEVEL_CODE = ? AND SKILL_CODE = ?";
				pstmt = dbConn.prepareStatement(sql);
				pstmt.setString(1, sosiki[i]);
				pstmt.setString(2, syoku_code);
				pstmt.setString(3, senmon_code);
				pstmt.setString(4, level_code);
				pstmt.setString(5, skill_code);

				rs = pstmt.executeQuery();
				rs.next();
				zentei_cnt = rs.getString(1).trim();

				PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);
				if (!zentei_cnt.equals("0")) {
					sql = "SELECT JUKUTATSUDO_SETSUMON FROM CKG_SKILL_JYUKUTATUDO_SETSUMON WHERE SOSIKI_CODE = ? AND SYOKU_CODE = ? AND SENMON_CODE = ? AND LEVEL_CODE = ? AND SKILL_CODE = ?";
					pstmt = dbConn.prepareStatement(sql);
					pstmt.setString(1, sosiki[i]);
					pstmt.setString(2, syoku_code);
					pstmt.setString(3, senmon_code);
					pstmt.setString(4, level_code);
					pstmt.setString(5, skill_code);

					rs = pstmt.executeQuery();
					rs.next();
					bumon_teigi = rs.getString(1).trim();
					break;
				}
			}

			Log.method(login_no, "OUT", "");
			return bumon_teigi;

		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, pstmt, rs);
		}
	}

	// --- 20070117 K.takagi Add ---
	/**
	 * �X�L���Y�C���x���g���ݖ�A�X�L���Y�C���x���g���̑I��l���擾����
	 * @param login_no
	 * @param syoku_code
	 * @param senmon_code
	 * @param skill_code
	 * @param level_code
	 * @param shindansya_id
	 * @param groupCode 0�F���[�U�g�p�̃O���[�v�R�[�h 1:�f�t�H���g�O���[�v�R�[�h
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public ArrayList SearchSkillSetumon(final String login_no, final String syoku_code, final String senmon_code, final String skill_code, final String level_code, final String shindansya_id,
			final ArrayList groupCodeAll) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;

		final ArrayList SetumonList = new ArrayList();

		// �p�����[�^�`�F�b�N
		if (shindansya_id == null || groupCodeAll == null) {
			return SetumonList;
		}

		try {
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			String[] userGroup = (String[])groupCodeAll.get(0);

			sql = "SELECT COUNT(LEAF.SKILL_CODE) "
				+ "FROM "
				+ "( "
				+ " SELECT * "
				+ " FROM ( "
				+ "  SELECT MAIN.SKILL_CODE, MAIN.SKILL_MEI, MAIN.KAI_SKILL_UMU, NVL(GROUP_CODE,'')GROUP_CODE, MAIN.KAISOU, JOUI_SKILLCODE "
				+ "  FROM T40_C_SKILL_YOSO_TBL MAIN "
				+ "  WHERE GROUP_CODE = ? "
				+ "   OR EXISTS "
				+ "    (SELECT * FROM T40_C_SKILL_YOSO_TBL DEF WHERE DEF.GROUP_CODE = ? AND MAIN.GROUP_CODE = DEF.GROUP_CODE AND MAIN.SKILL_CODE = DEF.SKILL_CODE "
				+ "     AND NOT EXISTS (SELECT * FROM T40_C_SKILL_YOSO_TBL BUMON WHERE BUMON.GROUP_CODE = ? AND DEF.SKILL_CODE = BUMON.SKILL_CODE) "
				+ "    ) "
				+ " ) "
				+ " START WITH KAISOU = '1' "
				+ " CONNECT BY PRIOR SKILL_CODE = JOUI_SKILLCODE AND PRIOR KAI_SKILL_UMU = '1' "
				+ " ORDER SIBLINGS BY SKILL_CODE "
				+ ")LEAF "
				+ ", CJM_SKILLSINVENTORY_GROUP GRP "
				+ ", (SELECT * FROM CKG_SKILLSINVENTORY_KANREN WHERE SYOKU_CODE = ? AND SENMON_CODE = ? AND SKILL_CODE = ? AND LEVEL_CODE = ? AND GROUP_CODE IN (?,?)) SKILL "
				+ "WHERE LEAF.GROUP_CODE = GRP.GROUP_CODE "
				+ " AND LEAF.SKILL_CODE = SKILL.SKILLS_INVENTORY_CODE "
				+ " AND LEAF.GROUP_CODE = SKILL.GROUP_CODE ";

			pstmt = dbConn.prepareStatement(sql);
			int paramCnt = 1;
			pstmt.setString(paramCnt++, userGroup[0]);
			pstmt.setString(paramCnt++, (String)groupCodeAll.get(1));
			pstmt.setString(paramCnt++, userGroup[0]);
			pstmt.setString(paramCnt++, syoku_code);
			pstmt.setString(paramCnt++, senmon_code);
			pstmt.setString(paramCnt++, skill_code);
			pstmt.setString(paramCnt++, level_code);
			pstmt.setString(paramCnt++, userGroup[0]);
			pstmt.setString(paramCnt++, (String)groupCodeAll.get(1));

			rs = pstmt.executeQuery();
			rs.next();
			String zentei_cnt = rs.getString(1).trim();

			PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);

			/* 0���̏ꍇ��Null�Ԃ� */
			if (zentei_cnt.equals("0")) {
				return SetumonList;
			}

			sql = "SELECT LEAF.SKILL_CODE, LEAF.SKILL_MEI, LEAF.KAI_SKILL_UMU, NVL(LEAF.GROUP_CODE,'')GROUP_CODE, GRP.KANRI_MEISYO "
				+ "FROM "
				+ "( "
				+ " SELECT * "
				+ " FROM ( "
				+ "  SELECT MAIN.SKILL_CODE, MAIN.SKILL_MEI, MAIN.KAI_SKILL_UMU, NVL(GROUP_CODE,'')GROUP_CODE, MAIN.KAISOU, JOUI_SKILLCODE "
				+ "  FROM T40_C_SKILL_YOSO_TBL MAIN "
				+ "  WHERE GROUP_CODE = ? "
				+ "   OR EXISTS "
				+ "    (SELECT * FROM T40_C_SKILL_YOSO_TBL DEF WHERE DEF.GROUP_CODE = ? AND MAIN.GROUP_CODE = DEF.GROUP_CODE AND MAIN.SKILL_CODE = DEF.SKILL_CODE "
				+ "     AND NOT EXISTS (SELECT * FROM T40_C_SKILL_YOSO_TBL BUMON WHERE BUMON.GROUP_CODE = ? AND DEF.SKILL_CODE = BUMON.SKILL_CODE) "
				+ "    ) "
				+ " ) "
				+ " START WITH KAISOU = '1' "
				+ " CONNECT BY PRIOR SKILL_CODE = JOUI_SKILLCODE AND PRIOR KAI_SKILL_UMU = '1' "
				+ " ORDER SIBLINGS BY SKILL_CODE "
				+ ")LEAF "
				+ ", CJM_SKILLSINVENTORY_GROUP GRP "
				+ ", (SELECT * FROM CKG_SKILLSINVENTORY_KANREN WHERE SYOKU_CODE = ? AND SENMON_CODE = ? AND SKILL_CODE = ? AND LEVEL_CODE = ? AND GROUP_CODE IN (?,?)) SKILL "
				+ "WHERE LEAF.GROUP_CODE = GRP.GROUP_CODE "
				+ " AND LEAF.SKILL_CODE = SKILL.SKILLS_INVENTORY_CODE "
				+ " AND LEAF.GROUP_CODE = SKILL.GROUP_CODE ";

			pstmt = dbConn.prepareStatement(sql);
			paramCnt = 1;
			pstmt.setString(paramCnt++, userGroup[0]);
			pstmt.setString(paramCnt++, (String)groupCodeAll.get(1));
			pstmt.setString(paramCnt++, userGroup[0]);
			pstmt.setString(paramCnt++, syoku_code);
			pstmt.setString(paramCnt++, senmon_code);
			pstmt.setString(paramCnt++, skill_code);
			pstmt.setString(paramCnt++, level_code);
			pstmt.setString(paramCnt++, userGroup[0]);
			pstmt.setString(paramCnt++, (String)groupCodeAll.get(1));

			rs = pstmt.executeQuery();

			String[] tmp = new String[7];
			while (rs.next()) {
				tmp = new String[7];
				tmp[0] = rs.getString(1);
				tmp[1] = rs.getString(2);
				tmp[2] = rs.getString(3);
				tmp[3] = rs.getString(4);
				tmp[4] = rs.getString(5);
				SetumonList.add(tmp);
			}

			PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);

			// �X�L���Y�C���x���g���̑I��l(�f�f�ҁA�]����)���擾����
			for (int i = 0; i < SetumonList.size(); i++) {
				final String[] skillcd = (String[]) SetumonList.get(i);

				sql = "SELECT COUNT(CJS.SKILL_CODE) FROM CJS_SKILLSINVENTORY CJS WHERE CJS.SKILL_CODE = ? AND CJS.SHINDANSYA_ID = ? AND CJS.GROUP_CODE = ?";
				pstmt = dbConn.prepareStatement(sql);
				pstmt.setString(1, skillcd[0]);
				pstmt.setString(2, shindansya_id);
				pstmt.setString(3, skillcd[3]);
				rs = pstmt.executeQuery();
				rs.next();
				zentei_cnt = rs.getString(1).trim();

				PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);
				
				if (zentei_cnt.equals("0")) {
					skillcd[5] = (String) ReadFile.paramMapData.get("DBY004");
					skillcd[6] = (String) ReadFile.paramMapData.get("DBY004");
				} else {
					sql = "SELECT NVL(CJS.SHINDANSYA_LEVEL,'" + (String) ReadFile.paramMapData.get("DBY004") + "'), NVL(CJS.hYOKASYA_LEVEL ,'" + (String) ReadFile.paramMapData.get("DBY004")
							+ "') FROM CJS_SKILLSINVENTORY CJS WHERE CJS.SKILL_CODE = ? AND CJS.SHINDANSYA_ID = ? AND CJS.GROUP_CODE = ?";
					pstmt = dbConn.prepareStatement(sql);
					pstmt.setString(1, skillcd[0]);
					pstmt.setString(2, shindansya_id);
					pstmt.setString(3, skillcd[3]);
					rs = pstmt.executeQuery();
					rs.next();

					skillcd[5] = rs.getString(1);
					skillcd[6] = rs.getString(2);
					
					PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);
				}

				//�X�L���Y�C���x���g���O���[�v�R�[�h���g�p���̃O���[�v�R�[�h�ɒu��������B
				//����ȍ~�A�X�L���Y�C���x���g���ݖ₲�Ƃ̃O���[�v����ʂ������Ȃ���
				skillcd[3] = userGroup[0];
				skillcd[4] = userGroup[1];
			}

			Log.method(login_no, "OUT", "");
			return SetumonList;

		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, pstmt, rs);
		}
	}

	// --- 20070117 K.takagi Add ---
	/**
	 * �ݖ�̃X�L���K�w���擾����
	 * @param setumon
	 * @param groupCode 0�F���[�U�g�p�̃O���[�v�R�[�h 1:�f�t�H���g�O���[�v�R�[�h
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public ArrayList SearchSkillkaisou(final String login_no, final ArrayList setumon, final ArrayList groupCode) throws SQLException, NamingException, Exception {
		Log.method(login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;

		final ArrayList skillList = new ArrayList();
		try {

			if (setumon == null) {
				return skillList;
			}
			
			String[] userGroup = (String[])groupCode.get(0);


			dbConn = PZZ040_SQLUtility.getConnection(login_no);
			String bkchkcode = "";
			String chkcode = "";
			int doukaisou = 0;

			for (int i = 0; i < setumon.size(); i++) {
				final String[] skillcode = (String[]) setumon.get(i);
				sql = " SELECT COUNT(*) "
					+ " FROM ( "
					+ "  SELECT MAIN.SKILL_CODE, MAIN.SKILL_MEI, MAIN.KAI_SKILL_UMU, NVL(GROUP_CODE,'')GROUP_CODE, MAIN.KAISOU, JOUI_SKILLCODE "
					+ "  FROM T40_C_SKILL_YOSO_TBL MAIN "
					+ "  WHERE GROUP_CODE = ? "
					+ "   OR EXISTS "
					+ "    (SELECT * FROM T40_C_SKILL_YOSO_TBL DEF WHERE DEF.GROUP_CODE = ? AND MAIN.GROUP_CODE = DEF.GROUP_CODE AND MAIN.SKILL_CODE = DEF.SKILL_CODE "
					+ "     AND NOT EXISTS (SELECT * FROM T40_C_SKILL_YOSO_TBL BUMON WHERE BUMON.GROUP_CODE = ? AND DEF.SKILL_CODE = BUMON.SKILL_CODE) "
					+ "    ) "
					+ " ) "
					+ " START WITH SKILL_CODE = ? "
					+ " CONNECT BY PRIOR JOUI_SKILLCODE = SKILL_CODE AND PRIOR KAISOU > '1' "
					+ " ORDER SIBLINGS BY SKILL_CODE ";

				pstmt = dbConn.prepareStatement(sql);
				pstmt.setString(1, userGroup[0]);
				pstmt.setString(2, (String)groupCode.get(1));
				pstmt.setString(3, userGroup[0]);
				pstmt.setString(4, skillcode[0]);
				rs = pstmt.executeQuery();
				rs.next();
				final String zentei_cnt = rs.getString(1).trim();

				PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);

				/* 0���̏ꍇ��Null�Ԃ� */
				if (zentei_cnt.equals("0")) {
					return skillList;
				}

				/* SQL�X�e�[�g�����g�̔��s */
				sql = " SELECT SKILL_CODE, SKILL_MEI, KAI_SKILL_UMU "
					+ " FROM ( "
					+ "  SELECT MAIN.SKILL_CODE, MAIN.SKILL_MEI, MAIN.KAI_SKILL_UMU, NVL(GROUP_CODE,'')GROUP_CODE, MAIN.KAISOU, JOUI_SKILLCODE "
					+ "  FROM T40_C_SKILL_YOSO_TBL MAIN "
					+ "  WHERE GROUP_CODE = ? "
					+ "   OR EXISTS "
					+ "    (SELECT * FROM T40_C_SKILL_YOSO_TBL DEF WHERE DEF.GROUP_CODE = ? AND MAIN.GROUP_CODE = DEF.GROUP_CODE AND MAIN.SKILL_CODE = DEF.SKILL_CODE "
					+ "     AND NOT EXISTS (SELECT * FROM T40_C_SKILL_YOSO_TBL BUMON WHERE BUMON.GROUP_CODE = ? AND DEF.SKILL_CODE = BUMON.SKILL_CODE) "
					+ "    ) "
					+ " ) "
					+ " START WITH SKILL_CODE = ? "
					+ " CONNECT BY PRIOR JOUI_SKILLCODE = SKILL_CODE AND PRIOR KAISOU > '1' "
					+ " ORDER BY KAISOU ASC ";

				pstmt = dbConn.prepareStatement(sql);
				pstmt.setString(1, userGroup[0]);
				pstmt.setString(2, (String)groupCode.get(1));
				pstmt.setString(3, userGroup[0]);
				pstmt.setString(4, skillcode[0]);

				rs = pstmt.executeQuery();

				final ArrayList skillList1 = new ArrayList();
				String[] tmp = new String[3];
				while (rs.next()) {
					tmp = new String[3];
					tmp[0] = rs.getString(1);
					tmp[1] = rs.getString(2);
					tmp[2] = rs.getString(3);
					skillList1.add(tmp);
				}

				chkcode = "";
				tmp = new String[Integer.parseInt(zentei_cnt) + 1];
				int idx = 0;
				for (int j = 0, num = skillList1.size(); j < num; j++) {
					idx++;
					final String[] kaisou = (String[]) skillList1.get(j);

					if (kaisou[2].trim().equals("0")) {
						if (chkcode.equals(bkchkcode)) { // ���K�w�̏ꍇ�Adoukaisou������
							tmp[0] = String.valueOf(doukaisou);
						} else {
							doukaisou += 1;
							tmp[0] = String.valueOf(doukaisou);
						}
						skillList.add(tmp);
						bkchkcode = chkcode;
					} else {
						if (j == num - 2) {
							tmp[idx] = "<FONT color=\"#0000FF\">" + kaisou[1] + "</FONT>";
							chkcode = chkcode + kaisou[0];
						} else {
							tmp[idx] = kaisou[1] + PBY_SkillSetumeiEJBBean.SKILL_JOIN;
							chkcode = chkcode + kaisou[0];
						}
					}
				}
				// ����SQL���s�̂��߂�pstmt�Ars���g���̂ň�xclose
				PZZ040_SQLUtility.closeConnection(login_no, null, pstmt, rs);
			}

			Log.method(login_no, "OUT", "");
			return skillList;

		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException {/* �������܂��� */
	}

	/**
	 * SessionContext�����擾����B
	 * @return SessionContext���
	 */
	public SessionContext getSessionContext() {
		return this.my_ssc;
	}

	/**
	 * EJB�R���e�i���Ǘ�����SessionContext����SessionBean�ɓn���BSessionBean�̍쐬���ɌĂяo�����B
	 * @param val SessionContext���
	 * @exception RemoteException
	 */
	public void setSessionContext(final SessionContext val) throws RemoteException {
		this.my_ssc = val;
	}

}
