/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboKanriBean;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboMenuEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboMenuEJBHome;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PEB030_KouboMenuServlet �N���X �@�\�����F ����e�[�u�����f�[�^���擾����
 * 
 * </PRE>
 */
public class PEB030_KouboMenuServlet extends PEY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException {

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEB_KouboMenuEJBHome home = (PEB_KouboMenuEJBHome) fact.lookup(PEB_KouboMenuEJBHome.class);
		final PEB_KouboMenuEJB ejb = home.create();

		/* �����������i�[���� */
		final PEB_KouboKanriBean kensaku_kouboBeans = new PEB_KouboKanriBean(request);

		/* �f�[�^���擾���� */
		final PEB_KouboKanriBean[] kouboBeans = ejb.doSelect(kensaku_kouboBeans, loginuser);

		request.setAttribute("kouboBeans", kouboBeans);

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();
	}
}
