/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.bean;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletRequest;

import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X��: PEB_OuboKanriBean �N���X �@�\����: ����Ǘ��ꗗ�f�[�^�̕ێ����s���B
 * 
 * </PRE>
 */
public class PEB_OuboKanriBean extends PEY_KouboBean implements Serializable {
	private String gouhistatus = null;

	private String oubosyakousinbi = null;

	private String oubosyakousinjikoku = null;

	private String oubosyasyozoku = null;

	private String oubosyasimei = null;

	private String oubosyagaisen = null;

	private String oubosyanaisen = null;

	private String oubosyamail = null;

	private String oubosyarenrakujikou = null;

	/**
	 * �f�t�H���g�̃R���X�g���N�^
	 */
	public PEB_OuboKanriBean() {
		super();
	}

	/**
	 * Request ����l���擾���ĉ���Ǘ�ValueBean���쐬���܂��B
	 * @param request �Ăь���ʂŐݒ肵�����N�G�X�g
	 */
	public PEB_OuboKanriBean(final ServletRequest request) {
		super(request);

		this.setGouhistatus(request.getParameter("gouhi_status"));
		this.setOubosyakousinbi(request.getParameter("kousinbi"));
		this.setOubosyakousinjikoku(request.getParameter("kousinjikoku"));
	}

	/**
	 * ResultSet ����l���擾���ĉ���Ǘ�ValueBean���쐬���܂��B
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param TableName �e�[�u����
	 */
	public PEB_OuboKanriBean(final ResultSet rs, final String TableName) throws SQLException {
		super(rs, TableName);

		try {
			this.setGouhistatus(rs.getString(this.getIdentifier() + "GOUHI_STATUS"));
			this.setOubosyakousinbi(rs.getString(this.getIdentifier() + "OUBOSYA_KOUSINBI"));
			this.setOubosyakousinjikoku(rs.getString(this.getIdentifier() + "OUBOSYA_KOUSINJIKOKU"));
			this.setOubosyasyozoku(rs.getString(this.getIdentifier() + "OUBOSYA_TOIAWASE_SYOZOKU"));
			this.setOubosyasimei(rs.getString(this.getIdentifier() + "OUBOSYA_TOIAWASE_SIMEI"));
			this.setOubosyagaisen(rs.getString(this.getIdentifier() + "OUBOSYA_TOIAWASE_GAISEN"));
			this.setOubosyanaisen(rs.getString(this.getIdentifier() + "OUBOSYA_TOIAWASE_NAISEN"));
			this.setOubosyamail(rs.getString(this.getIdentifier() + "OUBOSYA_TOIAWASE_MAIL"));
			this.setOubosyarenrakujikou(rs.getString(this.getIdentifier() + "OUBOSYA_RENRAKU_JIKOU"));
		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		}
	}

	/**
	 * @return
	 */
	public String getGouhistatus() {
		return this.gouhistatus;
	}

	/**
	 * @return
	 */
	public String getOubosyakousinbi() {
		return this.oubosyakousinbi;
	}

	/**
	 * @return
	 */
	public String getOubosyakousinjikoku() {
		return this.oubosyakousinjikoku;
	}

	/**
	 * @param string
	 */
	public void setGouhistatus(final String gouhistatus) {
		this.gouhistatus = gouhistatus;
	}

	/**
	 * @param string
	 */
	public void setOubosyakousinbi(final String oubosyakousinbi) {
		this.oubosyakousinbi = oubosyakousinbi;
	}

	/**
	 * @param string
	 */
	public void setOubosyakousinjikoku(final String oubosyakousinjikoku) {
		this.oubosyakousinjikoku = oubosyakousinjikoku;
	}

	/**
	 * @return
	 */
	public String getOubosyagaisen() {
		return this.oubosyagaisen;
	}

	/**
	 * @return
	 */
	public String getOubosyamail() {
		return this.oubosyamail;
	}

	/**
	 * @return
	 */
	public String getOubosyanaisen() {
		return this.oubosyanaisen;
	}

	/**
	 * @return
	 */
	public String getOubosyarenrakujikou() {
		return this.oubosyarenrakujikou;
	}

	/**
	 * @return
	 */
	public String getOubosyasimei() {
		return this.oubosyasimei;
	}

	/**
	 * @return
	 */
	public String getOubosyasyozoku() {
		return this.oubosyasyozoku;
	}

	/**
	 * @param string
	 */
	public void setOubosyagaisen(final String oubosyagaisen) {
		this.oubosyagaisen = oubosyagaisen;
	}

	/**
	 * @param string
	 */
	public void setOubosyamail(final String oubosyamail) {
		this.oubosyamail = oubosyamail;
	}

	/**
	 * @param string
	 */
	public void setOubosyanaisen(final String oubosyanaisen) {
		this.oubosyanaisen = oubosyanaisen;
	}

	/**
	 * @param string
	 */
	public void setOubosyarenrakujikou(final String oubosyarenrakujikou) {
		this.oubosyarenrakujikou = oubosyarenrakujikou;
	}

	/**
	 * @param string
	 */
	public void setOubosyasimei(final String oubosyasimei) {
		this.oubosyasimei = oubosyasimei;
	}

	/**
	 * @param string
	 */
	public void setOubosyasyozoku(final String oubosyasyozoku) {
		this.oubosyasyozoku = oubosyasyozoku;
	}
}
