/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.rmi.RemoteException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_OuboKanriBean;
import jp.co.hisas.career.department.offer.ejb.PEB_OuboKanriEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_OuboKanriEJBHome;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PEB060_OuboKanriHensyuuCheckServlet�N���X �@�\�����F �����񂪍쐬�\�����`�F�b�N����B
 * 
 * </PRE>
 */
public class PEB060_OuboKanriHensyuuCheckServlet extends PEY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws RemoteException, Exception {
		/* ���\�b�h�g���[�X�E�p�t�H�[�}���X�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEB_OuboKanriEJBHome home = (PEB_OuboKanriEJBHome) fact.lookup(PEB_OuboKanriEJBHome.class);

		final PEB_OuboKanriEJB ejb = home.create();

		/* �����������i�[���� */
		final PEB_OuboKanriBean kensaku_sakuseicheckBean = new PEB_OuboKanriBean(request);

		/* �f�[�^���擾���� */
		final PEB_OuboKanriBean[] koubosyuryoucheckBeans = ejb.doSelect(kensaku_sakuseicheckBean, loginuser, "KouboSyuryouCheck");

		if (koubosyuryoucheckBeans.length != 0) {
			request.setAttribute("warningID", "WEB045");
			throw new PEY_WarningException();
		}

		/* �f�[�^���擾���� */
		final PEY_KouboOubosyaBean[] mioubocheckBeans = ejb.doSelectStatus(kensaku_sakuseicheckBean, loginuser, "SakuseiMiouboCheck");

		if (mioubocheckBeans.length != 0) {
			/* �f�[�^���擾���� */
			final PEY_KouboOubosyaBean[] statuscheckBeans = ejb.doSelectStatus(kensaku_sakuseicheckBean, loginuser, "SakuseiStatusCheck");

			if (statuscheckBeans.length == 0) {
				request.setAttribute("warningID", "WEB024");
				throw new PEY_WarningException();
			}
		}

		/* ���\�b�h�g���[�X�E�p�t�H�[�}���X�g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
