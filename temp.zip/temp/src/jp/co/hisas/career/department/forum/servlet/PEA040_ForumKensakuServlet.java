/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.forum.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.forum.ejb.PEA_ForumEJB;
import jp.co.hisas.career.department.forum.ejb.PEA_ForumEJBHome;
import jp.co.hisas.career.department.forum.valuebean.PEA_ForumBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PEA040_ForumKensakuServlet �@�\�����F �t�H�[�����̌������ʂ��擾����B
 * 
 * </PRE>
 */
public class PEA040_ForumKensakuServlet extends PEY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws NamingException, CreateException, PEY_WarningException,
			RemoteException, PEY_WarningException {

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEA_ForumEJBHome home = (PEA_ForumEJBHome) fact.lookup(PEA_ForumEJBHome.class);
		final PEA_ForumEJB ejb = home.create();

		/* ���������̐ݒ� */
		final PEA_ForumBean search_ForumBean = new PEA_ForumBean(request);

		// �t�H�[�����J�ݏ�����ʗp�����������Z�b�g
		final String servletPath = request.getServletPath();
		if (servletPath.indexOf("/servlet/PEA040") != -1) {
			search_ForumBean.setNotKeep("true");
		}

		/* �X�e�[�^�X���擾���� */
		Log.transaction(loginuser.getSimeiNo(), true, "");
		final PEA_ForumBean[] forumBeans = ejb.forumKensaku(search_ForumBean, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		request.setAttribute("forumBeans", forumBeans);
		if (forumBeans != null && forumBeans.length != 0) {
			request.setAttribute("forumBean", forumBeans[0]);
		}

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();

	}
}
