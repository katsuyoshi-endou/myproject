/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboAnkenBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboExtBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboKibouSyokusyuBean;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenEJBHome;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �T�v�F �Г�����Č��̃f�[�^���擾����B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PEB040_CreateKouboDownServlet extends PEY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		PEB_KouboAnkenBean kouboAnkenData = null;
		final String kouboAnkenId = request.getParameter("koubo_anken_id");
		final String searchFlg = request.getParameter("searchFlg");

		if (searchFlg == null || searchFlg.length() <= 0) {
			if (kouboAnkenId == null || kouboAnkenId.length() <= 0) { // �V�K�쐬��
				kouboAnkenData = new PEB_KouboAnkenBean();
			} else {// ����Č��C����
				try {
					final EJBHomeFactory fact = EJBHomeFactory.getInstance();
					final PEB_KouboAnkenEJBHome kouboAnkenEJBHome = (PEB_KouboAnkenEJBHome) fact.lookup(PEB_KouboAnkenEJBHome.class);
					final PEB_KouboAnkenEJB kouboAnkenEJB = kouboAnkenEJBHome.create();
					kouboAnkenData = kouboAnkenEJB.getKouboAnkenInfo(kouboAnkenId);
				} catch (final NamingException e) {
					Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
					throw e;
				} catch (final CreateException e) {
					Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
					throw e;
				} catch (final RemoteException e) {
					Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
					throw e;
				} catch (final Exception e) {
					Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
					throw e;
				}
			}
		} else {// �ēǂݍ��ݎ�
			kouboAnkenData = new PEB_KouboAnkenBean();
			final PEB_KouboExtBean kouboAnken = new PEB_KouboExtBean();
			kouboAnken.setKouboankenid(request.getParameter("koubo_anken_id"));
			kouboAnken.setJigyobumei(request.getParameter("jigyobu_mei"));
			kouboAnken.setJigyoubutyomei(request.getParameter("jigyobutyo_mei"));
			kouboAnken.setSosikicode(request.getParameter("sosiki_code"));
			kouboAnken.setSimeino(request.getParameter("simei_no"));
			kouboAnken.setKouboankenmei(request.getParameter("koubo_anken_mei"));
			kouboAnken.setAnkengaiyo(request.getParameter("anken_gaiyo"));
			if (request.getParameter("bosyu_ninzu") == null || request.getParameter("bosyu_ninzu").equals("") || request.getParameter("bosyu_ninzu").length() == 0) {
				kouboAnken.setBosyuninzu(null);
			} else {
				try {
					final Integer boshu = Integer.valueOf(request.getParameter("bosyu_ninzu"));
					kouboAnken.setBosyuninzu(boshu);
				} catch (final Exception ex) {// �ĕ\�����ɕ�W�l���ɕs���Ȓl�����͂���Ă���ꍇ��null��ݒ肷��
					kouboAnken.setBosyuninzu(null);
				}
			}
			kouboAnken.setIdoukiboujiki(request.getParameter("idou_kibou_jiki"));
			kouboAnken.setKibousyokusyuSonota(request.getParameter("kibou_syokusyu_sonota"));
			kouboAnken.setKitaiyakuwaributyo(request.getParameter("kitai_yakuwari_butyo"));
			kouboAnken.setKitaiyakuwarisyuningisi(request.getParameter("kitai_yakuwari_syuningisi"));
			kouboAnken.setKitaiyakuwarigisi(request.getParameter("kitai_yakuwari_gisi"));
			kouboAnken.setKitaiyakuwariippan(request.getParameter("kitai_yakuwari_ippan"));
			kouboAnken.setSyozokukinmuti(request.getParameter("syozoku_kinmuti"));
			kouboAnken.setGyomunaiyo(request.getParameter("gyomu_naiyo"));
			kouboAnken.setJobgrade(request.getParameter("job_grade"));
			kouboAnken.setSyokumurireki(request.getParameter("syokumu_rireki"));
			kouboAnken.setOubosyayoukensonota(request.getParameter("oubosya_youken_sonota"));
			kouboAnken.setKoubopr(request.getParameter("koubo_pr"));
			kouboAnken.setSinseiriyu(request.getParameter("sinsei_riyu"));
			kouboAnken.setSyoristatus(request.getParameter("syori_status"));
			kouboAnken.setKousinbi(request.getParameter("kousinbi"));
			kouboAnken.setKousinjikoku(request.getParameter("kousinjikoku"));
			kouboAnken.setKinyusyaBusyomei(request.getParameter("kinyusyabusyomei"));
			kouboAnken.setKinyusyaSimei(request.getParameter("kinyusyasimei"));

			for (int i = 0; i < 3; i++) {
				final PEB_KouboKibouSyokusyuBean syokuBean = new PEB_KouboKibouSyokusyuBean();
				final int no = i + 1;
				syokuBean.setSyokuCode(request.getParameter("syokusyu_code" + no));
				syokuBean.setSenmonCode(request.getParameter("senmon_code" + no));
				syokuBean.setLevelCode(request.getParameter("level_code" + no));
				syokuBean.setKousinbi(request.getParameter("kousinbi" + no));
				syokuBean.setKousinjikoku(request.getParameter("kousinjikoku" + no));
				kouboAnkenData.addKouboKibouSyokusyuBean(syokuBean);
			}

			kouboAnkenData.setKouboBean(kouboAnken);

		}
		request.setAttribute("kouboAnkenBean", kouboAnkenData);
		Log.performance(loginuser.getSimeiNo(), false, "");

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");
		return this.getForwardPath();
	}

}
