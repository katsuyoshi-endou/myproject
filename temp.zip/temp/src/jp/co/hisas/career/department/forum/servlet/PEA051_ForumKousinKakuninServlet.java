/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.forum.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.forum.valuebean.PEA_ForumBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PEA051_ForumKousinKakuninServlet �@�\�����F �t�H�[�������̍X�V���e���m�F����B
 * 
 * </PRE>
 */
public class PEA051_ForumKousinKakuninServlet extends PEY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws NamingException, CreateException, PEY_WarningException,
			RemoteException, PEY_WarningException {

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		/* �X�V���e�̐ݒ� */
		final PEA_ForumBean update_ForumBean = new PEA_ForumBean(request);

		request.setAttribute("forumBean", update_ForumBean);

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();

	}
}
