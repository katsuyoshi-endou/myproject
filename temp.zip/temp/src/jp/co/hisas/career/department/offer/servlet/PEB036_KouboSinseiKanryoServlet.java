/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.rmi.RemoteException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboMenuEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboMenuEJBHome;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PEB036_KouboSinseiKanryoServlet �N���X �@�\�����F ����e�[�u�����A���������擾���� �ɕύX����
 * 
 * </PRE>
 */
public class PEB036_KouboSinseiKanryoServlet extends PEY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws RemoteException, PEY_WarningException, Exception {

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEB_KouboMenuEJBHome home = (PEB_KouboMenuEJBHome) fact.lookup(PEB_KouboMenuEJBHome.class);
		final PEB_KouboMenuEJB ejb = home.create();

		/* �X�V����l��ValueBean�ɐݒ� */
		final PEY_KouboBean search_kouboBeans = new PEY_KouboBean(request);

		/* �f�[�^���擾���� */
		final PEY_KouboBean[] kouboBeans = ejb.doSelect(search_kouboBeans, loginuser);

		request.setAttribute("kouboBeans", kouboBeans);

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		request.setAttribute("warningID", "WCX010");

		return this.getForwardPath();
	}
}
