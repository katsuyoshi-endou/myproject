/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboKanriBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ020_MakeSQLUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PEB_KouboMenuEJB �N���X �@�\�����F ����e�[�u���ւ̑�����s���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="PEB_KouboMenuEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PEB_KouboMenuEJBBean implements SessionBean {

	/**
	 * ����e�[�u���������ɂ����f�[�^�̌������擾
	 * @param kouboBean ��������
	 * @param loginuser ���O�C�����[�U
	 * @return �擾����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doSelectCnt(final PEB_KouboKanriBean kouboBean, final PEY_PersonalBean loginuser) {

		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final StringBuffer sql = new StringBuffer();
			sql.append(" SELECT COUNT( * ) ");
			sql.append(" FROM " + HcdbDef.D01_TBL);
			sql.append(" WHERE SIMEI_NO 		= '" + PZZ020_MakeSQLUtil.sanitizeSQLData(loginuser.getSimeiNo()) + "'");
			sql.append("   AND KOUBO_ANKEN_ID	= '" + PZZ020_MakeSQLUtil.sanitizeSQLData(kouboBean.getKouboankenid()) + "'");
			sql.append("   AND KOUSINBI		= '" + PZZ020_MakeSQLUtil.sanitizeSQLData(kouboBean.getKousinbi()) + "'");
			sql.append("   AND KOUSINJIKOKU	= '" + PZZ020_MakeSQLUtil.sanitizeSQLData(kouboBean.getKousinjikoku()) + "'");

			// �f�o�b�O�̏o��
			Log.debug(sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			stmt = con.createStatement();
			rs = stmt.executeQuery(sql.toString());
			rs.next();
			final int count = rs.getInt(1);

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;

		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, stmt, rs);
		}
	}

	/**
	 * ����e�[�u�����f�[�^�擾���Ԃ��܂��B
	 * @param kouboBean ��������
	 * @param loginuser ���O�C�����[�U
	 * @return PEY_KouboBean[] �擾����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public String doSelectStatus(final PEY_KouboBean kouboBean, final PEY_PersonalBean loginuser) {

		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final StringBuffer sql = new StringBuffer();
			sql.append(" SELECT SYORI_STATUS ");
			sql.append(" FROM " + HcdbDef.D01_TBL);
			sql.append(" WHERE SIMEI_NO = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(loginuser.getSimeiNo()) + "'");
			sql.append("   AND KOUBO_ANKEN_ID = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(kouboBean.getKouboankenid()) + "'");

			// �f�o�b�O�̏o��
			Log.debug(sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			stmt = con.createStatement();
			rs = stmt.executeQuery(sql.toString());
			rs.next();
			final String status = rs.getString("SYORI_STATUS");

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return status;

		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, stmt, rs);
		}
	}

	/**
	 * ����e�[�u�����f�[�^�擾���Ԃ��܂��B
	 * @param kouboBean ��������
	 * @param loginuser ���O�C�����[�U
	 * @return PEY_KouboBean[] �擾����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PEY_KouboBean[] doSelect(final PEY_KouboBean kouboBean, final PEY_PersonalBean loginuser) {

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// ���������̍쐬
			final Map conditions = kouboBean.extractConditions();

			PEY_KouboBean[] kouboBeans = null;
			final StringBuffer sql = new StringBuffer();

			sql.append("SELECT * ");
			sql.append(" FROM " + HcdbDef.D01_TBL);

			final StringBuffer where = new StringBuffer();

			for (final Iterator ite = conditions.keySet().iterator(); ite.hasNext();) {
				final Object column = ite.next();
				where.append(" AND " + column + "=?");
			}

			sql.append(where.toString().replaceFirst("AND", "WHERE"));
			sql.append(" AND " + HcdbDef.D01_TBL + ".SYORI_STATUS NOT IN ( '" + HcdbDef.D01_SAKUJYO + "' ) ");

			// �f�o�b�O�̏o��
			Log.debug(sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");
			// �������s
			ps = con.prepareStatement(sql.toString());

			final List kouboBeanList = new ArrayList();

			int count = 1;
			for (final Iterator ite = conditions.keySet().iterator(); ite.hasNext(); count++) {
				final Object key = ite.next();
				Log.debug(Integer.toString(count) + ":" + key + ":" + conditions.get(key));
				ps.setObject(count, conditions.get(key));
			}

			rs = ps.executeQuery();

			while (rs.next()) {
				kouboBeanList.add(new PEY_KouboBean(rs, null));
			}

			kouboBeans = new PEY_KouboBean[kouboBeanList.size()];
			kouboBeanList.toArray(kouboBeans);

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");
			return kouboBeans;

		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * ����������f�[�^�擾���Ԃ��܂��B ( ��ꗗ�f�[�^ )
	 * @param kouboBean ��������
	 * @param loginuser ���O�C�����[�U
	 * @return PEB_KouboKanriBean[] �擾����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PEB_KouboKanriBean[] doSelect(final PEB_KouboKanriBean kouboBean, final PEY_PersonalBean loginuser) {

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// ���������̍쐬
			final Map conditions = kouboBean.extractConditions();

			PEB_KouboKanriBean[] kouboBeans = null;
			final StringBuffer sql = new StringBuffer();

			sql.append(" SELECT DISTINCT " + HcdbDef.D01_TBL + ".*, ");
			sql.append(HcdbDef.D03_TBL + ".KOUBO_ANKEN_ID AS OUBO_UMU");
			sql.append(" FROM " + HcdbDef.D01_TBL + ",");
			sql.append(" ( SELECT * FROM " + HcdbDef.D03_TBL);
			sql.append(" 		WHERE GOUHI_STATUS NOT IN ( '" + HcdbDef.D03_SAKUSEIZUMI + "' ) ) " + HcdbDef.D03_TBL);
			sql.append(" WHERE " + HcdbDef.D01_TBL + ".SIMEI_NO = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(loginuser.getSimeiNo()) + "'");
			sql.append("   AND " + HcdbDef.D01_TBL + ".KOUBO_ANKEN_ID = " + HcdbDef.D03_TBL + ".KOUBO_ANKEN_ID(+)");
			sql.append("   AND " + HcdbDef.D01_TBL + ".SYORI_STATUS NOT IN ( " + HcdbDef.D01_SAKUJYO + ")");

			// ����e�[�u���\�[�g���̍쐬
			sql.append("  ORDER BY " + HcdbDef.D01_TBL + ".TOUROKUBI DESC, " + HcdbDef.D01_TBL + ".TOUROKUJIKOKU DESC");

			// �f�o�b�O�̏o��
			Log.debug(sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �������s
			ps = con.prepareStatement(sql.toString());

			final List kouboBeanList = new ArrayList();

			int count = 1;
			for (final Iterator ite = conditions.keySet().iterator(); ite.hasNext(); count++) {
				final Object key = ite.next();
				Log.debug(Integer.toString(count) + ":" + key + ":" + conditions.get(key));
				ps.setObject(count, conditions.get(key));
			}

			rs = ps.executeQuery();

			while (rs.next()) {
				kouboBeanList.add(new PEB_KouboKanriBean(rs, null));
			}

			kouboBeans = new PEB_KouboKanriBean[kouboBeanList.size()];
			kouboBeanList.toArray(kouboBeans);

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return (PEB_KouboKanriBean[]) kouboBeanList.toArray(new PEB_KouboKanriBean[0]);

		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * �i�l���j�R���\���O�̃f�[�^�`�F�b�N���s�� �K�{���ڂɃf�[�^���ݒ肳��Ă��邩?
	 * @param oubokanriBean ��������
	 * @param loginuser ���O�C�����[�U
	 * @return �擾����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doJinsouSinsaDataChk(final PEB_KouboKanriBean oubokanriBean, final PEY_PersonalBean loginuser) throws Exception, PEY_WarningException {

		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		final String simei_no = loginuser.getSimeiNo();
		final String koubo_anken_id = oubokanriBean.getKouboankenid();

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final StringBuffer sql = new StringBuffer();
			sql.append("SELECT COUNT(KOUBO_ANKEN_ID) ");
			sql.append(" FROM " + HcdbDef.D01_TBL);
			sql.append(" WHERE KOUBO_ANKEN_ID 	= '" + PZZ020_MakeSQLUtil.sanitizeSQLData(koubo_anken_id) + "'");
			sql.append("  AND SIMEI_NO		  	= '" + PZZ020_MakeSQLUtil.sanitizeSQLData(simei_no) + "'");
			sql.append("  AND KOUBO_ANKEN_MEI	IS NOT NULL");
			sql.append("  AND JIGYOBU_MEI		IS NOT NULL");
			sql.append("  AND JIGYOBUTYO_MEI	IS NOT NULL");
			sql.append("  AND ANKEN_GAIYO		IS NOT NULL");
			sql.append("  AND BOSYU_NINZU		IS NOT NULL");
			sql.append("  AND IDOU_KIBOU_JIKI	IS NOT NULL");
			sql.append("  AND SYOZOKU_KINMUTI	IS NOT NULL");
			sql.append("  AND (	KITAI_YAKUWARI_BUTYO 	  IS NOT NULL");
			sql.append("	    OR	KITAI_YAKUWARI_SYUNINGISI IS NOT NULL");
			sql.append("		OR	KITAI_YAKUWARI_GISI		  IS NOT NULL");
			sql.append("		OR	KITAI_YAKUWARI_IPPAN	  IS NOT NULL) ");
			sql.append("  AND GYOMU_NAIYO				IS NOT NULL");
			sql.append("  AND JOB_GRADE				IS NOT NULL");
			sql.append("  AND SYOKUMU_RIREKI 			IS NOT NULL");
			sql.append("  AND OUBOSYA_YOUKEN_SONOTA	IS NOT NULL");
			sql.append("  AND KOUBO_PR					IS NOT NULL");
			sql.append("  AND SINSEI_RIYU				IS NOT NULL");

			// �f�o�b�O�̏o��
			Log.debug(sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			stmt = con.createStatement();
			rs = stmt.executeQuery(sql.toString());
			rs.next();
			final int count = rs.getInt(1);
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			// �Y��������Ԃ�
			return count;

		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, stmt, rs);
		}
	}

	/**
	 * �v���C�}���[�L�[���L�[�Ƃ��Đ\���󋵃e�[�u�����X�V���܂��B
	 * @param kouboBean �X�V�f�[�^
	 * @param loginuser ���O�C�����[�U
	 * @return �X�V����
	 * @throws PEY_WarningException �ꗗ�\������X�V����܂ł̊Ԃɑ��ōX�V����Ă����ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public void doUpdate(final PEB_KouboKanriBean kouboBean, final PEY_PersonalBean loginuser) throws PEY_WarningException {
		Connection con = null;
		Statement stmt = null;

		final String kousinbi = PZZ010_CharacterUtil.GetDay();
		final String kousinjikoku = PZZ010_CharacterUtil.GetTime();

		if (this.doSelectCnt(kouboBean, loginuser) == 0) {
			/* �r������`�F�b�N�G���[���� */
			throw new PEY_WarningException("WCB080");
		}

		try {

			final StringBuffer sql = new StringBuffer();

			sql.append("UPDATE ");
			sql.append(HcdbDef.D01_TBL);

			// �i�l��)�R���\�� ( �X�e�[�^�X : �쐬�ς� �� �R������ )
			if (kouboBean.getSyoristatus().equals(HcdbDef.D01_SAKUSEIZUMI)) {

				sql.append("    SET SYORI_STATUS		 = " + HcdbDef.D01_SINSATYU + ",");
				sql.append("    	 JIGYOBUTYO_SYONINBI =" + PZZ020_MakeSQLUtil.sanitizeSQLData(kouboBean.getJigyobutyoSyoninbi()));

				// �o�c��c�����쐬 ( �X�e�[�^�X : �i �l�� �j���R���ς�( ���i ) �� �o�c��c�R������ )
			} else if (kouboBean.getSyoristatus().equals(HcdbDef.D01_SINSA_GOUKAKU)) {

				sql.append("    SET SYORI_STATUS		 = " + HcdbDef.D01_KEIEIKAIGI_SINSATYU + ",");
				sql.append("    	 KEIEI_KAIGIBI 		 =" + PZZ020_MakeSQLUtil.sanitizeSQLData(kouboBean.getKeieikaigibi()));

				// ����Č������J���� ( �X�e�[�^�X : �i �l�� �j�R���ς� ( ���J ) �� ���咆�� )
			} else if (kouboBean.getSyoristatus().equals(HcdbDef.D01_KEIEIKAIGI_SINSATYU)) {

				sql.append("    SET SYORI_STATUS		 = " + HcdbDef.D01_KOUBOTYU + ",");
				sql.append("    	 KOUKAIBI 			 =" + PZZ020_MakeSQLUtil.sanitizeSQLData(kouboBean.getKoukaibi()));

				// ����Č����폜���� ( �X�e�[�^�X : )
			} else if (kouboBean.getSyoristatus().equals(HcdbDef.D01_SAKUJYO)) {

				sql.append("    SET SYORI_STATUS		 = " + HcdbDef.D01_SAKUJYO);

				// ����Č����I������ ( �X�e�[�^�X : )
			} else if (kouboBean.getSyoristatus().equals(HcdbDef.D01_KOUBO_SYURYO)) {

				sql.append("    SET SYORI_STATUS		 = " + HcdbDef.D01_KOUBO_SYURYO);
			}

			sql.append(",    	 KOUSINBI 		 ='" + PZZ020_MakeSQLUtil.sanitizeSQLData(kousinbi) + "'");
			sql.append(",    	 KOUSINJIKOKU	 ='" + PZZ020_MakeSQLUtil.sanitizeSQLData(kousinjikoku) + "'");
			sql.append(",    	 KOUSINSYA		 ='" + PZZ020_MakeSQLUtil.sanitizeSQLData(loginuser.getSimeiNo()) + "'");
			sql.append("  WHERE SIMEI_NO 		= '" + PZZ020_MakeSQLUtil.sanitizeSQLData(loginuser.getSimeiNo()) + "'");
			sql.append("    AND KOUBO_ANKEN_ID = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(kouboBean.getKouboankenid()) + "'");

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �X�V���s
			stmt = con.createStatement();
			stmt.executeUpdate(sql.toString());

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, stmt, null);
		}
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
}
