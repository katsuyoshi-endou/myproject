/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJBException;
import javax.naming.NamingException;

import jp.co.hisas.career.department.offer.bean.PEB_KouboOubosyaExtBean;
import jp.co.hisas.career.department.offer.bean.PEB_OubosyaJyohoBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PEB_GouhiDao �@�\�����F �w�肳�ꂽ����Č�ID�ɊY�����鍇�ۏ������p�̃f�[�^�𒊏o����B
 * 
 * </PRE>
 */
public class PEB_GouhiDao {

	/** ����_����҃e�[�u�����f�[�^���o����ׂ�SQL */
	private static String KOUBO_SELECT_SQL = null;

	static {

		/** �₢���킹SQL���쐬 */
		final StringBuffer buf = new StringBuffer();
		buf.append("SELECT ");
		for (int i = 0; i < HcdbDef.s03_column.length; ++i) {
			if (i > 0) {
				buf.append(", ");
			}
			buf.append("A." + HcdbDef.s03_column[i] + " as " + HcdbDef.s03_column[i]);
		}
		buf.append(", substr(B.kanji_simei ,2 ) as kanji_simei");
		buf.append(", B.busyo_ryakusyo_mei as busyo_ryakusyo_mei");
		buf.append(", C.KOUBO_ANKEN_MEI as KOUBO_ANKEN_MEI");
		buf.append(" FROM ");
		buf.append(HcdbDef.D03_TBL + " A");
		buf.append(", " + HcdbDef.personalTbl + " B");
		buf.append(", " + HcdbDef.D01_TBL + " C");
		buf.append(" WHERE A.KOUBO_ANKEN_ID=CAST(? AS CHAR(10))");
		buf.append(" AND A.SIMEI_NO = B.SIMEI_NO(+)");
		buf.append(" AND TRIM(A.SOSIKI_CODE) = B.SOSIKI_CODE(+)");
		buf.append(" AND A.GOUHI_STATUS != " + HcdbDef.D03_SAKUSEIZUMI);
		buf.append(" AND A.KOUBO_ANKEN_ID = C.KOUBO_ANKEN_ID(+)");
		buf.append("  ORDER BY A.SOSIKI_CODE ASC , A.SIMEI_NO ASC ");
		PEB_GouhiDao.KOUBO_SELECT_SQL = buf.toString();
	}

	/**
	 * �R���X�g���N�^�B
	 */
	public PEB_GouhiDao() {
	}

	/**
	 * ������f�[�^�̎擾�B
	 * @param koubo_anken_id ���o�ΏۂƂ������Č�ID
	 * @return PEB_OubosyaJyohoBean ������f�[�^�B
	 */
	public PEB_OubosyaJyohoBean[] doSelect(final String koubo_anken_id) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		PEB_KouboOubosyaExtBean koubooubosyaBean = null;

		try {
			con = PZZ040_SQLUtility.getConnection("");
			ps = con.prepareStatement(PEB_GouhiDao.KOUBO_SELECT_SQL);
			ps.setString(1, koubo_anken_id);
			rs = ps.executeQuery();

			final List koubooubosyaBeanList = new ArrayList();
			while (rs.next()) {
				koubooubosyaBean = new PEB_KouboOubosyaExtBean(rs, null);
				final PEB_OubosyaJyohoBean OubosyaJyohoBean = new PEB_OubosyaJyohoBean();
				OubosyaJyohoBean.setkouboOubosyaBean(koubooubosyaBean);
				koubooubosyaBeanList.add(OubosyaJyohoBean);
			}

			PEB_OubosyaJyohoBean[] KouboOubosyaBeans = new PEB_OubosyaJyohoBean[koubooubosyaBeanList.size()];
			KouboOubosyaBeans = (PEB_OubosyaJyohoBean[]) koubooubosyaBeanList.toArray(KouboOubosyaBeans);

			return KouboOubosyaBeans;

		} catch (final SQLException e) {
			Log.error("", e);
			throw new EJBException(e);
		} catch (final NamingException e) {
			Log.error("", e);
			throw new EJBException(e);
		} finally {
			PZZ040_SQLUtility.closeConnection("", con, ps, rs);
		}

	}
}
