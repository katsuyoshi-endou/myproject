/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.forum.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.forum.ejb.PEA_ToukouEJB;
import jp.co.hisas.career.department.forum.ejb.PEA_ToukouEJBHome;
import jp.co.hisas.career.department.forum.valuebean.PEA_ToukouSearchBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F PEA140_KijiKensakuKekkaServlet �@�\�����F �L�����������̐�����s���B
 * 
 * </PRE>
 */
public class PEA140_KijiKensakuKekkaServlet extends PEY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws NamingException, CreateException, PEY_WarningException,
			RemoteException, PEY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		/* �P��ʂɕ\������b�萔�̏�� */
		final String searchSize = (String) ReadFile.fileMapData.get("FORUM_KENSAKU_MAX");
		final String forumPage = (String) ReadFile.fileMapData.get("FORUM_KENSAKU_PAGE");
		final String forumIndex = (String) ReadFile.fileMapData.get("FORUM_KENSAKU_INDEX");

		String forumId = request.getParameter("forum_id");
		String searchKey = request.getParameter("search_key");
		final String searchTarget = request.getParameter("search_target");
		final String pageNo = request.getParameter("page_no");
		final String kensakuPageStart = request.getParameter("page_start_no");
		final HttpSession session = request.getSession();

		if (pageNo != null && pageNo.trim().length() > 0) {
			// pageNo������ꍇ�͌������s��Ȃ��B
			Log.method("", "OUT", "");

			return this.getForwardPath();
		}

		searchKey = searchKey.replaceAll("&quot;", "\"");
		final KeywordParser parser = new KeywordParser(searchKey);
		final String[] keyword = parser.parse();

		if (keyword == null || keyword.length <= 0) {
			session.setAttribute("toukouSearchBeans", new PEA_ToukouSearchBean[0]);
			Log.method("", "OUT", "");

			return this.getForwardPath();
		}

		if (searchTarget == null || searchTarget.trim().length() <= 0 || "all".equals(searchTarget.toLowerCase())) {
			forumId = null;
		}

		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEA_ToukouEJBHome home = (PEA_ToukouEJBHome) fact.lookup(PEA_ToukouEJBHome.class);

		/* EJBObject�̎擾 */
		final PEA_ToukouEJB ejb = home.create();

		final PEA_ToukouSearchBean[] result = ejb.doSelect(forumId, keyword, loginuser);

		session.setAttribute("toukouSearchBeans", this.chkMaxResult(result, searchSize));

		session.setAttribute("forum_kensaku_max", searchSize);
		session.setAttribute("forum_page", forumPage);
		session.setAttribute("forum_index", forumIndex);

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();
	}

	/**
	 * �������ʍő匏���`�F�b�N ���t�@�C���ɓo�^���Ă��錏�������͍폜���ĉ�ʕ\���B �������A���t�@�C�����l�����Ȃ������ꍇ�ő�P�O�O�O���ɂĊm�F����B
	 * @param result ��������
	 * @param size �ő�\������
	 * @return ��ʕ\�����s��PEA_ToukouSearchBean
	 */
	private PEA_ToukouSearchBean[] chkMaxResult(final PEA_ToukouSearchBean[] result, final String size) {

		int i = 1000;

		try {
			i = size == null || size.equals("") ? 1000 : Integer.parseInt(size);
		} catch (final Exception e) {
		}

		i = i > result.length ? result.length : i;

		final PEA_ToukouSearchBean[] rtnResult = new PEA_ToukouSearchBean[i];

		for (int cnt = 0; cnt < i; cnt++) {
			rtnResult[cnt] = result[cnt];
		}

		return rtnResult;
	}
}

/**
 * KeywordParser<br />
 * �L�[���[�h�̉�͂��s���B
 * @version 1.0
 * @since 1.0
 */
class KeywordParser {
	private String keyword = null;

	private int parsePosition = 0;

	private final ArrayList keywordList = new ArrayList();

	/**
	 * �R���X�g���N�^�B
	 * @param keyword ��͑Ώۂ̕�����B
	 */
	public KeywordParser(final String keyword) {
		this.keyword = keyword;
	}

	/**
	 * ��͂��s���B<br />
	 * @return ��͌��ʂ̕�����̔z��B
	 */
	public String[] parse() {
		// �_�u���N�H�[�e�[�V�����̐����`�F�b�N����B
		this.chkDoubleQuoteCount();

		for (this.parsePosition = 0; this.parsePosition < this.keyword.length(); ++this.parsePosition) {
			final char c = this.keyword.charAt(this.parsePosition);

			if (this.isDoubleQuote(c)) {
				this.parseDoubleQuote();
			} else if (this.isSepareteString(c) || this.isIgnoreString(c)) {
				continue;
			} else {
				this.parseNormalWord();
			}
		}
		// �d������L�[���[�h���폜
		final ArrayList conpactList = new ArrayList();
		for (int i = 0; i < this.keywordList.size(); ++i) {
			final String k = (String) this.keywordList.get(i);
			if (!conpactList.contains(k)) {
				conpactList.add(k);
			}
		}

		final String[] keyword = new String[conpactList.size()];
		return (String[]) conpactList.toArray(keyword);
	}

	/**
	 * ����"��������܂ł��P�̃L�[���[�h�Ƃ��Đ؂�o���ǉ�����B
	 */
	private void parseDoubleQuote() {
		final int saveParsePosition = this.parsePosition;
		this.parsePosition++;

		final StringBuffer buf = new StringBuffer();
		boolean breakFlg = false;

		for (int i = this.parsePosition; i < this.keyword.length(); ++i) {
			final char c = this.keyword.charAt(i);

			if (this.isDoubleQuote(c)) {
				if (buf.length() > 0) {
					this.keywordList.add(buf.toString());
				}

				this.parsePosition = i;
				breakFlg = true;

				break;
			}

			if (this.isIgnoreString(c)) {
				continue;
			} else {
				buf.append(c);
			}
		}

		if (!breakFlg) {
			this.parsePosition = saveParsePosition + 1;
			this.parseNormalWord();
		}
	}

	/**
	 * �X�y�[�X���邢��"��������܂ł�1�̃L�[���[�h�Ƃ��Đ؂�o���ǉ�����B
	 */
	private void parseNormalWord() {
		final StringBuffer buf = new StringBuffer();
		boolean breakFlg = false;

		for (int i = this.parsePosition; i < this.keyword.length(); ++i) {
			final char c = this.keyword.charAt(i);

			if (this.isDoubleQuote(c)) {
				boolean findNextQuote = false;
				boolean separatorBreak = false;
				final StringBuffer buf2 = new StringBuffer();
				int j = 0;

				for (j = i + 1; j < this.keyword.length(); ++j) {
					final char cc = this.keyword.charAt(j);

					if (this.isSepareteString(cc)) {
						separatorBreak = true;

						break;
					} else if (this.isDoubleQuote(cc)) {
						findNextQuote = true;
					} else {
						buf2.append(cc);
					}
				}

				if (findNextQuote) {
					if (buf.length() > 0) {
						this.keywordList.add(buf.toString());
					}

					this.parsePosition = i;
					breakFlg = true;

					break;
				} else if (!separatorBreak) {
					if (buf.length() > 0) {
						this.keywordList.add(buf.toString());
					}

					breakFlg = true;
					this.parsePosition = j;

					break;
				} else {
					if (buf.length() > 0) {
						this.keywordList.add(buf.toString());
					}

					this.parsePosition = i - 1; // ����̃p�[�X��"���܂߂�
					breakFlg = true;

					break;
				}
			} else if (this.isSepareteString(c)) {
				if (buf.length() > 0) {
					this.keywordList.add(buf.toString());
				}

				this.parsePosition = i;
				breakFlg = true;

				break;
			} else if (this.isIgnoreString(c)) {
				continue;
			} else {
				buf.append(c);
			}
		}

		if (!breakFlg) {
			if (buf.length() > 0) {
				this.keywordList.add(buf.toString());
			}

			this.parsePosition = this.keyword.length();
		}
	}

	/**
	 * �_�u���N�H�[�e�[�V�����̐����`�F�b�N���A��̏ꍇ �Ō�̃_�u���N�H�[�e�[�V��������菜�� *
	 */
	private void chkDoubleQuoteCount() {
		String tmp = this.keyword;
		int cnt = 0;

		while (true) {
			final int i = tmp.indexOf("\"");

			if (i >= 0) {
				cnt++;
				tmp = tmp.substring(i + 1, tmp.length());
			} else {
				break;
			}
		}

		if (cnt % 2 != 0) {
			// ��܂�ł���ꍇ
			final int i = this.keyword.lastIndexOf("\"");
			this.keyword = this.keyword.substring(0, i) + this.keyword.substring(i + 1);
		}
	}

	private boolean isDoubleQuote(final char c) {
		return c == '"' || c == '�h';
	}

	private boolean isSepareteString(final char c) {
		return c == ' ' || c == '�@';
	}

	private boolean isIgnoreString(final char c) {
		return c == '<' || c == '<' || c == '>' || c == '&';
	}
}
