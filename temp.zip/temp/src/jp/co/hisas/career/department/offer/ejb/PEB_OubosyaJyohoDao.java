/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ejb.EJBException;
import javax.naming.NamingException;

import jp.co.hisas.career.department.offer.bean.PEB_KouboKibouAssessmentBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboOubosyaExtBean;
import jp.co.hisas.career.department.offer.bean.PEB_OubosyaJyohoBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PEB_OubosyaJyohoDao �@�\�����F �w�肳�ꂽ����Č�ID�ɊY�����鉞����쐬�p�̃f�[�^�𒊏o����B
 * 
 * </PRE>
 */
public class PEB_OubosyaJyohoDao {
	/** ����_����҃e�[�u�����f�[�^���o����ׂ�SQL */
	private static String KOUBO_SELECT_SQL = null;

	static {

		/** �₢���킹SQL���쐬 */
		final StringBuffer buf = new StringBuffer();
		buf.append("SELECT ");
		for (int i = 0; i < HcdbDef.s03_column.length; ++i) {
			if (i > 0) {
				buf.append(", ");
			}
			buf.append("A." + HcdbDef.s03_column[i] + " as " + HcdbDef.s03_column[i]);
		}
		buf.append(", substr(B.kanji_simei ,2 ) as kanji_simei");
		buf.append(", B.busyo_ryakusyo_mei as busyo_ryakusyo_mei");
		buf.append(", C.KOUBO_ANKEN_MEI as KOUBO_ANKEN_MEI");
		buf.append(" FROM ");
		buf.append(HcdbDef.D03_TBL + " A");
		buf.append(", " + HcdbDef.personalTbl + " B");
		buf.append(", " + HcdbDef.D01_TBL + " C");
		buf.append(" WHERE A.KOUBO_ANKEN_ID=CAST(? AS CHAR(10))");
		buf.append(" AND A.SIMEI_NO=CAST(? AS CHAR(20))");
		buf.append(" AND A.SIMEI_NO = B.SIMEI_NO(+)");
		buf.append(" AND A.KOUBO_ANKEN_ID = C.KOUBO_ANKEN_ID(+)");
		PEB_OubosyaJyohoDao.KOUBO_SELECT_SQL = buf.toString();
	}

	/** ����_�����_�A�Z�X�����g���ʂ��f�[�^���o����ׂ�SQL */
	private static final String KOUBO_OUBOSYA_ASSESS_SQL = "SELECT " + "A.KOUBO_ANKEN_ID AS KOUBO_ANKEN_ID" + ", A.SIMEI_NO AS SIMEI_NO" + ", A.SEQ_NO AS SEQ_NO" + ", B.SYOKU_CODE AS SYOKU_CODE"
			+ ", B.SYOKU_NAME AS SYOKU_NAME" + ", C.SENMON_CODE AS SENMON_CODE" + ", C.SENMON_NAME AS SENMON_NAME" + ", D.LEVEL_CODE AS LEVEL_CODE" + ", D.LEVEL_NAME AS LEVEL_NAME"
			+ ", A.JIKO_SOUGOU_T_DO AS JIKO_SOUGOU_T_DO" + ", A.HYOKASYA_SOUGOU_T_DO AS HYOKASYA_SOUGOU_T_DO" + " FROM " + HcdbDef.D04_TBL + " A" + ", " + HcdbDef.p_syokusyuTbl + " B" + ", "
			+ HcdbDef.p_senmonTbl + " C" + ", " + HcdbDef.p_level_nameTbl + " D" + " WHERE " + " A.KOUBO_ANKEN_ID=CAST(? AS CHAR(10))" + " AND A.SIMEI_NO=CAST(? AS CHAR(20))"
			+ " AND A.SYOKU_CODE = B.SYOKU_CODE(+)" + " AND A.SYOKU_CODE = C.SYOKU_CODE(+)" + " AND A.SENMON_CODE = C.SENMON_CODE(+)" + " AND A.LEVEL_CODE = D.LEVEL_CODE(+)" + " ORDER BY SEQ_NO ASC";

	/**
	 * �R���X�g���N�^�B
	 * @param dataSource
	 */
	public PEB_OubosyaJyohoDao() {
	}

	/**
	 * ������f�[�^�̎擾�B
	 * @param koubo_anken_id ����Č�ID
	 * @param simei_no ����No
	 * @return ������f�[�^�B
	 */
	public PEB_OubosyaJyohoBean doSelect(final String koubo_anken_id, final String simei_no) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		PEB_KouboOubosyaExtBean koubooubosyaBean = null;
		final PEB_OubosyaJyohoBean OubosyaJyohoBean = new PEB_OubosyaJyohoBean();

		try {
			con = PZZ040_SQLUtility.getConnection("");
			ps = con.prepareStatement(PEB_OubosyaJyohoDao.KOUBO_SELECT_SQL);
			ps.setString(1, koubo_anken_id);
			ps.setString(2, simei_no);
			rs = ps.executeQuery();

			if (rs.next()) {
				koubooubosyaBean = new PEB_KouboOubosyaExtBean(rs, null);
				OubosyaJyohoBean.setkouboOubosyaBean(koubooubosyaBean);
				this.selectKibouAssessment(koubo_anken_id, simei_no, OubosyaJyohoBean);
			}

			return OubosyaJyohoBean;

		} catch (final SQLException e) {
			Log.error("", e);
			throw new EJBException(e);
		} catch (final NamingException e) {
			Log.error("", e);
			throw new EJBException(e);
		} finally {
			PZZ040_SQLUtility.closeConnection("", con, ps, rs);
		}

	}

	/**
	 * �w�肳�ꂽ����Č�ID�ɊY�������]�E���Ԃ��B
	 * @param koubo_anken_id ����Č�ID
	 * @param simeiNo ����NO
	 * @param koubooubosyaBean ���剞���Bean
	 */
	private void selectKibouAssessment(final String koubo_anken_id, final String simeiNo, final PEB_OubosyaJyohoBean koubooubosyaBean) throws SQLException, NamingException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = PZZ040_SQLUtility.getConnection("");
			ps = con.prepareStatement(PEB_OubosyaJyohoDao.KOUBO_OUBOSYA_ASSESS_SQL);
			ps.setString(1, koubo_anken_id);
			ps.setString(2, simeiNo);
			rs = ps.executeQuery();
			while (rs.next()) {
				final PEB_KouboKibouAssessmentBean ks = new PEB_KouboKibouAssessmentBean(rs);
				koubooubosyaBean.addKouboKibouAssessmentBean(ks);
			}
		} finally {
			PZZ040_SQLUtility.closeConnection("", con, ps, rs);
		}

	}

}
