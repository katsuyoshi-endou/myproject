/*
 * All Rights Reserved. Copyright (C) 2003,2007 Hitachi Systems & Services, Ltd.
 */

package jp.co.hisas.career.util.pdf;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;

import jp.co.hisas.career.plan.careerchallenge.bean.PBB_AssessmentHyoka;
import jp.co.hisas.career.plan.careerchallenge.bean.PBB_AssessmentSindan;
import jp.co.hisas.career.plan.careerchallenge.bean.PBB_CareerChallenge;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

/**
 * �L�����A�`�������W�V�[�g �v��Ǝ��т̃V�[�g���o�͂���
 */
public class PZE070_ChallengePDF {

	/** ���O�C��No(���O�o�͈ȊO�̗p�r�Ȃ� */
	private String login_no;

	/**
	 * �O���L�����A�`�������W��� �A�Z�X�����g���ʕ\ �O���i�����j�ڕW �E��A��啪��A���x����
	 */
	private PBB_CareerChallenge preChallenge = new PBB_CareerChallenge();

	/**
	 * �A�Z�X�����g�f�f��� �A�Z�X�����g���ʕ\ ���ȕ]����
	 */
	private PBB_AssessmentSindan assessmentSindan = new PBB_AssessmentSindan();

	/**
	 * �A�Z�X�����g�]����� �A�Z�X�����g���ʕ\ �]���ҕ]�����A�]���җ�
	 */
	private PBB_AssessmentHyoka assessmentHyoka = new PBB_AssessmentHyoka();

	/**
	 * �A�Z�X�����g�f�f���Q �A�Z�X�����g���ʕ\ �L�����A�p�X�Q�̎��ȕ]����
	 */
	private PBB_AssessmentSindan assessmentSindan2 = new PBB_AssessmentSindan();

	/**
	 * �A�Z�X�����g�]�����Q �A�Z�X�����g���ʕ\ �L�����A�p�X�Q�̕]���ҕ]�����A�]���җ�
	 */
	private PBB_AssessmentHyoka assessmentHyoka2 = new PBB_AssessmentHyoka();

	/**
	 * �A�Z�X�����g�f�f���R �A�Z�X�����g���ʕ\ �L�����A�p�X�R�̎��ȕ]����
	 */
	private PBB_AssessmentSindan assessmentSindan3 = new PBB_AssessmentSindan();

	/**
	 * �A�Z�X�����g�]�����R �A�Z�X�����g���ʕ\ �L�����A�p�X�R�̕]���ҕ]�����A�]���җ�
	 */
	private PBB_AssessmentHyoka assessmentHyoka3 = new PBB_AssessmentHyoka();

	/**
	 * �L�����A�`�������W�v����
	 */
	private PBB_CareerChallenge challengePlan = new PBB_CareerChallenge();

	/**
	 * �L�����A�`�������W���я��
	 */
	private PBB_CareerChallenge challengeResult = new PBB_CareerChallenge();

	private String[][] outSikakuItem;

	private String[][] outSyokumuItem;

	/**
	 * �o�͂���V�[�g�̋敪 ���̒l��1�Ȃ�Όv��V�[�g���o�� 1�łȂ���Ύ��уV�[�g���o�͂���
	 */
	private String kubun;

	/**
	 * �^�C�g�����̊��Ԗ���
	 */
	private String kikanmei;

	/**
	 * �L�����A�p�X�̐�
	 */
	private final String careerPathNum = (String) ReadFile.fileMapData.get("CAREERPATH_NUM");

	/**
	 * �L�����A�`�������W�v������擾����
	 * @param String[] outDefItem ���x���z��
	 * @param String kubun �敪
	 * @param String[] outplanItem �v����z��
	 * @param String[] outresultItem ���я��z��
	 */
	public void setChallengeValue(final String[] outDefItem, final String kubun, final String[] outplanItem, final String[] outresultItem) {
		Log.method(this.login_no, "IN", "");

		this.kubun = kubun;

		/* �f�f�� */
		this.challengePlan.setSindansyaBusyoRyakusyoMei(outplanItem[44]);
		this.challengePlan.setSindansya(outplanItem[0]);
		this.challengePlan.setSindansyaKanjiSimei(outplanItem[43]);
		this.challengePlan.setJissiNengappi(outplanItem[39]);
		/* ���F�� */
		this.challengePlan.setSyoninsyaBusyoRyakusyoMei(outplanItem[46]);
		this.challengePlan.setSyoninsya(outplanItem[36]);
		this.challengePlan.setSyoninsyaKanjiSimei(outplanItem[45]);
		this.challengePlan.setSyoninNengappi(outplanItem[41]);
		/* �ڕW */
		this.challengePlan.setMokuhyoSyokuName(outplanItem[4]);
		this.challengePlan.setMokuhyoSenmonName(outplanItem[5]);
		this.challengePlan.setMokuhyoLevelName(outplanItem[6]);
		/* �Ɩ��o�� */
		this.challengePlan.setGyomuKeiken(outplanItem[7]);
		/* �����u */
		this.challengePlan.setKyoikuZyukou(outplanItem[8]);
		/* �擾���i */
		this.challengePlan.setSikakuMeisyo1(outplanItem[47]);
		this.challengePlan.setSikakuLevelMei1(outplanItem[48]);
		this.challengePlan.setSikakuTokuten1(outplanItem[11]);
		this.challengePlan.setSikakuMeisyo2(outplanItem[49]);
		this.challengePlan.setSikakuLevelMei2(outplanItem[50]);
		this.challengePlan.setSikakuTokuten2(outplanItem[14]);
		this.challengePlan.setSikakuMeisyo3(outplanItem[51]);
		this.challengePlan.setSikakuLevelMei3(outplanItem[52]);
		this.challengePlan.setSikakuTokuten3(outplanItem[17]);
		/* ���Ȍ[�� */
		this.challengePlan.setJikoKeihatu(outplanItem[24]);
		/* �ٓ��Ɋւ����] */
		this.challengePlan.setIdoKibo(outplanItem[25]);
		/* �ǋL���� */
		this.challengePlan.setTuikiJiko(outplanItem[34]);
		/* �㒷�R�����g */
		this.challengePlan.setZyouComment(outplanItem[35]);

		/* ���F�� */
		this.challengeResult.setSyoninsyaBusyoRyakusyoMei(outresultItem[46]);
		this.challengeResult.setSyoninsya(outresultItem[36]);
		this.challengeResult.setSyoninsyaKanjiSimei(outresultItem[45]);
		this.challengeResult.setSyoninNengappi(outresultItem[41]);
		/* �Ɩ��o�� */
		this.challengeResult.setGyomuKeiken(outresultItem[7]);
		/* �����u */
		this.challengeResult.setKyoikuZyukou(outresultItem[8]);
		/* �擾���i */
		this.challengeResult.setSikakuMeisyo1(outresultItem[47]);
		this.challengeResult.setSikakuLevelMei1(outresultItem[48]);
		this.challengeResult.setSikakuTokuten1(outresultItem[11]);
		this.challengeResult.setSikakuMeisyo2(outresultItem[49]);
		this.challengeResult.setSikakuLevelMei2(outresultItem[50]);
		this.challengeResult.setSikakuTokuten2(outresultItem[14]);
		this.challengeResult.setSikakuMeisyo3(outresultItem[51]);
		this.challengeResult.setSikakuLevelMei3(outresultItem[52]);
		this.challengeResult.setSikakuTokuten3(outresultItem[17]);
		/* ���Ȍ[�� */
		this.challengeResult.setJikoKeihatu(outresultItem[24]);
		/* �ٓ��Ɋւ����] */
		this.challengeResult.setIdoKibo(outresultItem[25]);
		/* �ǋL���� */
		this.challengeResult.setTuikiJiko(outresultItem[34]);
		/* �㒷�R�����g */
		this.challengeResult.setZyouComment(outresultItem[35]);

		Log.method(this.login_no, "OUT", "");
	}

	/**
	 * �L�����A�`�������W�v������擾����
	 * @param outDefItem ���x���Ȃ̂Ŗ����p�ɂ���
	 * @param kubun 1�F�v��A2�F����
	 * @param PBB_CareerChallenge �v����
	 * @param PBB_CareerChallenge ���я��
	 */
	public void setChallengeValue(final String[] outDefItem, final String kubun, final PBB_CareerChallenge challengePlan, final PBB_CareerChallenge challengeResult) {
		Log.method(this.login_no, "IN", "");

		this.kubun = kubun;
		this.challengePlan = challengePlan;
		this.challengeResult = challengeResult;

		Log.method(this.login_no, "OUT", "");
	}

	/**
	 * �A�Z�X�����g�f�f���ʁA�]�����ʂ��擾����
	 * @param outsindanItem
	 * @param outhyokaItem
	 */
	public void setAssessmentValue(final String[] outsindanItem, final String[] outhyokaItem) {
		Log.method(this.login_no, "IN", "");

		this.assessmentSindan.setSougouTasseido(outsindanItem[2]);
		this.assessmentSindan.setGyomuKeikenTasseido(outsindanItem[0]);
		this.assessmentSindan.setSkillTasseido(outsindanItem[1]);

		this.assessmentHyoka.setSougouTasseido(outhyokaItem[3]);
		this.assessmentHyoka.setGyomuKeikenTasseido(outhyokaItem[1]);
		this.assessmentHyoka.setSkillTasseido(outhyokaItem[2]);
		this.assessmentHyoka.setHyokasyaBusyoRyakusyoMei(outhyokaItem[5]);
		this.assessmentHyoka.setHyokasyaKanjiSimei(outhyokaItem[4]);

		Log.method(this.login_no, "OUT", "");
	}

	/**
	 * �A�Z�X�����g�f�f���ʁA�]�����ʂ��擾����
	 * @param PBB_AssessmentSindan
	 * @param PBB_AssessmentHyoka
	 */
	public void setAssessmentValue(final PBB_AssessmentSindan sindan, final PBB_AssessmentHyoka hyoka) {
		Log.method(this.login_no, "IN", "");

		this.assessmentSindan = sindan;
		this.assessmentHyoka = hyoka;

		Log.method(this.login_no, "OUT", "");
	}

	/**
	 * �A�Z�X�����g�f�f���ʁA�]�����ʂ��i�[����B
	 * @param PBB_AssessmentSindan
	 * @param PBB_AssessmentHyoka
	 */
	public void setAssessment2Value(final PBB_AssessmentSindan sindan, final PBB_AssessmentHyoka hyoka) {
		Log.method(this.login_no, "IN", "");

		this.assessmentSindan2 = sindan;
		this.assessmentHyoka2 = hyoka;

		Log.method(this.login_no, "IN", "");
	}

	/**
	 * �A�Z�X�����g�f�f���ʁA�]�����ʂ��i�[����B
	 * @param PBB_AssessmentSindan
	 * @param PBB_AssessmentHyoka
	 */
	public void setAssessment3Value(final PBB_AssessmentSindan sindan, final PBB_AssessmentHyoka hyoka) {
		Log.method(this.login_no, "IN", "");

		this.assessmentSindan3 = sindan;
		this.assessmentHyoka3 = hyoka;

		Log.method(this.login_no, "IN", "");
	}

	/**
	 * �L�����A�`�������W���Ԗ����i�[����B�i�^�C�g���ɕ\�L����B�j
	 * @param String �^�C�g���̃L�����A�`�������W���Ԗ�
	 */
	public void setKikanmei(final String kikanmei) {
		this.kikanmei = kikanmei;
	}

	/**
	 * ���i�����擾����
	 * @param outsikakuItem
	 */
	public void setSikakuValue(final String[][] outsikakuItem) {
		Log.method(this.login_no, "IN", "");

		this.outSikakuItem = outsikakuItem;

		Log.method(this.login_no, "OUT", "");
	}

	/**
	 * �E�����e�������擾����
	 * @param outsyokumuItem
	 */
	public void setSyokumuValue(final String[][] outsyokumuItem) {
		Log.method(this.login_no, "IN", "");

		this.outSyokumuItem = outsyokumuItem;

		Log.method(this.login_no, "OUT", "");
	}

	/* ���ږ� */

	private String hyoka_syozoku = "";

	private String hyoka_simeino = "";

	private String hyoka_simei = "";

	private String hyoka_jissi = "";

	private String sikakumeisyoTop1 = "";

	private String sikakulevelTop1 = "";

	private String sikakutokutenTop1 = "";

	private String sikakusyutokuhiTop1 = "";

	private String sikakumeisyoTop2 = "";

	private String sikakulevelTop2 = "";

	private String sikakutokutenTop2 = "";

	private String sikakusyutokuhiTop2 = "";

	private String sikakumeisyoTop3 = "";

	private String sikakulevelTop3 = "";

	private String sikakutokutenTop3 = "";

	private String sikakusyutokuhiTop3 = "";

	private String sikakumeisyoDown1 = "";

	private String sikakulevelDown1 = "";

	private String sikakutokutenDown1 = "";

	private String sikakusyutokuhiDown1 = "";

	private String sikakumeisyoDown2 = "";

	private String sikakulevelDown2 = "";

	private String sikakutokutenDown2 = "";

	private String sikakusyutokuhiDown2 = "";

	private String sikakumeisyoDown3 = "";

	private String sikakulevelDown3 = "";

	private String sikakutokutenDown3 = "";

	private String sikakusyutokuhiDown3 = "";

	/**
	 * �O���ڕW�i�v�掞�j�^�����ڕW�i���ю��j���Z�b�g����B
	 * @param PBB_CareerChallenge
	 */
	public void setPreChallenge(final PBB_CareerChallenge challenge) {
		this.preChallenge = challenge;
	}

	/**
	 * �����L�����A�`�������W�v������Z�b�g����B
	 * @param PBB_CareerChallenge
	 */
	public void setChallengePlan(final PBB_CareerChallenge challenge) {
		this.challengePlan = challenge;
	}

	/**
	 * �����L�����A�`�������W���я����Z�b�g����B
	 * @param PBB_CareerChallenge
	 */
	public void setChallengeResult(final PBB_CareerChallenge challenge) {
		this.challengeResult = challenge;
	}

	/**
	 * �R���X�g���N�^
	 * @param login_no
	 */
	public PZE070_ChallengePDF(final String login_no) {
		this.login_no = login_no;
	}

	/**
	 * PDF���쐬����
	 * @return
	 */
	public void executePDF(final OutputStream ops) throws Exception {
		Log.method(this.login_no, "IN", "");

		/* �v��̏ꍇ */
		if ("1".equals(this.kubun)) {
			this.hyoka_syozoku = this.challengePlan.getSyoninsyaBusyoRyakusyoMei();
			this.hyoka_simeino = this.challengePlan.getSyoninsya();
			this.hyoka_simei = this.challengePlan.getSyoninsyaKanjiSimei();
			this.hyoka_jissi = this.challengePlan.getSyoninNengappi();

			/* �ۗL���i */
			if (this.outSikakuItem.length >= 1) {
				this.sikakumeisyoTop1 = this.outSikakuItem[0][1];
				this.sikakulevelTop1 = this.outSikakuItem[0][2];
				this.sikakutokutenTop1 = this.outSikakuItem[0][3];
				this.sikakusyutokuhiTop1 = PZZ010_CharacterUtil.ChangeYm(this.outSikakuItem[0][4]);
			} else {
				this.sikakumeisyoTop1 = "����";
				this.sikakulevelTop1 = "";
				this.sikakutokutenTop1 = "";
				this.sikakusyutokuhiTop1 = "";
			}
			if (this.outSikakuItem.length >= 2) {
				this.sikakumeisyoTop2 = this.outSikakuItem[1][1];
				this.sikakulevelTop2 = this.outSikakuItem[1][2];
				this.sikakutokutenTop2 = this.outSikakuItem[1][3];
				this.sikakusyutokuhiTop2 = PZZ010_CharacterUtil.ChangeYm(this.outSikakuItem[1][4]);
			} else {
				this.sikakumeisyoTop2 = "";
				this.sikakulevelTop2 = "";
				this.sikakutokutenTop2 = "";
				this.sikakusyutokuhiTop2 = "";
			}
			if (this.outSikakuItem.length >= 3) {
				this.sikakumeisyoTop3 = this.outSikakuItem[2][1];
				this.sikakulevelTop3 = this.outSikakuItem[2][2];
				this.sikakutokutenTop3 = this.outSikakuItem[2][3];
				this.sikakusyutokuhiTop3 = PZZ010_CharacterUtil.ChangeYm(this.outSikakuItem[2][4]);
			} else {
				this.sikakumeisyoTop3 = "";
				this.sikakulevelTop3 = "";
				this.sikakutokutenTop3 = "";
				this.sikakusyutokuhiTop3 = "";
			}
			/* �v�掑�i */
			this.sikakumeisyoDown1 = this.challengePlan.getSikakuMeisyo1();
			this.sikakulevelDown1 = this.challengePlan.getSikakuLevelMei1();
			this.sikakutokutenDown1 = this.challengePlan.getSikakuTokuten1();
			this.sikakumeisyoDown2 = this.challengePlan.getSikakuMeisyo2();
			this.sikakulevelDown2 = this.challengePlan.getSikakuLevelMei2();
			this.sikakutokutenDown2 = this.challengePlan.getSikakuTokuten2();
			this.sikakumeisyoDown3 = this.challengePlan.getSikakuMeisyo3();
			this.sikakulevelDown3 = this.challengePlan.getSikakuLevelMei3();
			this.sikakutokutenDown3 = this.challengePlan.getSikakuTokuten3();

			/* ���т̏ꍇ */
		} else {
			/* 2007/01/09 yoshida edit start */
			this.hyoka_syozoku = this.challengeResult.getSyoninsyaBusyoRyakusyoMei();
			this.hyoka_simeino = this.challengeResult.getSyoninsya();
			this.hyoka_simei = this.challengeResult.getSyoninsyaKanjiSimei();
			this.hyoka_jissi = this.challengeResult.getSyoninNengappi();

			/* �v�掑�i */
			this.sikakumeisyoTop1 = this.challengePlan.getSikakuMeisyo1();
			this.sikakulevelTop1 = this.challengePlan.getSikakuLevelMei1();
			this.sikakutokutenTop1 = this.challengePlan.getSikakuTokuten1();
			this.sikakumeisyoTop2 = this.challengePlan.getSikakuMeisyo2();
			this.sikakulevelTop2 = this.challengePlan.getSikakuLevelMei2();
			this.sikakutokutenTop2 = this.challengePlan.getSikakuTokuten2();
			this.sikakumeisyoTop3 = this.challengePlan.getSikakuMeisyo3();
			this.sikakulevelTop3 = this.challengePlan.getSikakuLevelMei3();
			this.sikakutokutenTop3 = this.challengePlan.getSikakuTokuten3();

			/* ���� */
			this.sikakumeisyoDown1 = this.challengeResult.getSikakuMeisyo1();
			this.sikakulevelDown1 = this.challengeResult.getSikakuLevelMei1();
			this.sikakutokutenDown1 = this.challengeResult.getSikakuTokuten1();
			this.sikakumeisyoDown2 = this.challengeResult.getSikakuMeisyo2();
			this.sikakulevelDown2 = this.challengeResult.getSikakuLevelMei2();
			this.sikakutokutenDown2 = this.challengeResult.getSikakuTokuten2();
			this.sikakumeisyoDown3 = this.challengeResult.getSikakuMeisyo3();
			this.sikakulevelDown3 = this.challengeResult.getSikakuLevelMei3();
			this.sikakutokutenDown3 = this.challengeResult.getSikakuTokuten3();

			if (this.outSikakuItem != null && this.outSikakuItem.length >= 1) {
				this.sikakusyutokuhiDown1 = PZZ010_CharacterUtil.ChangeYm(this.outSikakuItem[0][4]);
			}
			if (this.outSikakuItem != null && this.outSikakuItem.length >= 2) {
				this.sikakusyutokuhiDown2 = PZZ010_CharacterUtil.ChangeYm(this.outSikakuItem[1][4]);
			}
			if (this.outSikakuItem != null && this.outSikakuItem.length >= 3) {
				this.sikakusyutokuhiDown3 = PZZ010_CharacterUtil.ChangeYm(this.outSikakuItem[2][4]);
			}

			if ((this.sikakumeisyoDown1 == null || this.sikakumeisyoDown1.equals("")) && (this.sikakumeisyoDown2 == null || this.sikakumeisyoDown2.equals(""))
					&& (this.sikakumeisyoDown3 == null || this.sikakumeisyoDown3.equals(""))) {
				this.sikakumeisyoDown1 = "����";
			}

		}

		/*
		 * Document�I�u�W�F�N�g�̐��� A3���́ADocument document = new Document(PageSize.A3.rotate());
		 */
		final Document document = new Document(PageSize.A3.rotate());

		// �}�[�W���w��
		final float lm = 18;
		document.setMargins(lm, lm, lm, lm);

		/* PdfWriter�I�u�W�F�N�g */
		PdfWriter writer = null;

		try {

			// PdfWriter�I�u�W�F�N�g�̐���
			writer = PdfWriter.getInstance(document, ops);
			writer.setCloseStream(true);

			// �]��
			final float gutter = 20;
			// �i�g��
			final int numColumns = 2;
			// ����
			final float fullWidth = document.right() - document.left();
			// �i��
			final float columnWidth = (fullWidth - (numColumns - 1) * gutter) / numColumns;

			// �g�p�t�H���g��ݒ肷��
			final BaseFont bf = BaseFont.createFont("HeiseiMin-W3", "UniJIS-UCS2-HW-H", false);
			/* �f�[�^�A�A�i�E���X�o�͗p�t�H���g�i�T�C�Y�ŏ��j */
			final Font font9 = new Font(bf, 8); /* CHG BQUP1-002 h-aida 2007/04/12 */
			/* �ʒk���p�t�H���g�i�T�C�Y�ŏ��A�����t���j */
			final Font font9line = new Font(bf, 8, Font.UNDERLINE); /* CHG BQUP1-002 h-aida 2007/04/12 */
			/* ADD BQUP1-002 h-aida 2007/04/12 START */
			/* �\�͊J���v��Ǝ��� �e���ڃ^�C�g���p�t�H���g�i�Z�����łQ�������Ƃɉ��s�����T�C�Y�j */
			final Font fontNrkKhtKomoku = new Font(bf, 9);
			/* ADD BQUP1-002 h-aida 2007/04/12 END */
			final Font font12 = new Font(bf, 12);
			final Font font14 = new Font(bf, 14);

			final Color silver = new Color(0xC0, 0xC0, 0xC0); // silver=��F
			final Color blue = new Color(204, 204, 255); // blue=�F
			final Color white = new Color(255, 255, 255); // white=��

			// �h�L�������g���J��
			document.open();
			// �L�����o�X���擾
			final PdfContentByte cb = writer.getDirectContent();

			// ���݂̈ʒu���擾����
			float currentY = document.top();

			currentY -= 25;

			/* �y�^�C�g���z */
			PdfPTable Table = new PdfPTable(1);
			Table.getDefaultCell().setBorderWidth(1);
			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase(PZZ010_CharacterUtil.normalizedStr(this.kikanmei) + (String) ReadFile.paramMapData.get("DBB032"), font14));
			} else {
				Table.addCell(new Phrase(PZZ010_CharacterUtil.normalizedStr(this.kikanmei) + (String) ReadFile.paramMapData.get("DBB078"), font14));
			}
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left(), currentY, cb);

			/* �y�A�Z�X�����g���ʁz */
			Table = new PdfPTable(1);
			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB036"), font12));
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left(), currentY - 10, cb);

			/* �y�A�Z�X�����g���ʃe�[�u���z */
			/* CAREERPATH_NUM����e�[�u���񐔂𓾂� */
			int tableColumns = 3;
			if ("2".equals(this.careerPathNum)) {
				tableColumns = 4;
			} else if ("3".equals(this.careerPathNum)) {
				tableColumns = 5;
			}
			/* �e�[�u���e��̕���ݒ� */
			final int[] widthsMultiGoal = new int[tableColumns];
			if ("2".equals(this.careerPathNum)) {
				widthsMultiGoal[0] = 15;
				widthsMultiGoal[1] = 15;
				widthsMultiGoal[2] = 35;
				widthsMultiGoal[3] = 35;
			} else if ("3".equals(this.careerPathNum)) {
				widthsMultiGoal[0] = 11;
				widthsMultiGoal[1] = 11;
				widthsMultiGoal[2] = 26;
				widthsMultiGoal[3] = 26;
				widthsMultiGoal[4] = 26;
			} else {
				widthsMultiGoal[0] = 23;
				widthsMultiGoal[1] = 23;
				widthsMultiGoal[2] = 54;
			}
			/* ���l�f�[�^�̕������� */
			final int numberTypeFormat = Element.ALIGN_CENTER;

			Table = new PdfPTable(tableColumns);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.setWidths(widthsMultiGoal);

			PdfPCell cell = new PdfPCell(new Phrase("", font9)); // ��
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.BOTTOM);
			cell.setFixedHeight(10);
			Table.addCell(cell);
			cell.setBorder(Rectangle.TOP | Rectangle.RIGHT | Rectangle.BOTTOM);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB037"), font9)); // �L�����A�p�X�P
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(silver);
			Table.addCell(cell);
			if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB038"), font9)); // �L�����A�p�X�Q
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setBackgroundColor(silver);
				Table.addCell(cell);
			}
			if ("3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB039"), font9)); // �L�����A�p�X�R
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setBackgroundColor(silver);
				Table.addCell(cell);
			}

			/* �ڕW */
			if ("1".equals(this.kubun)) {
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB010"), font9)); // �O���ڕW
			} else {
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB040"), font9)); // �����ڕW
			}
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setFixedHeight(20);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ008"), font9)); // �E��
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(blue);
			Table.addCell(cell);
			Table.addCell(new Phrase(this.preChallenge.getMokuhyoSyokuName(), font9));
			if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
				Table.addCell(new Phrase(this.preChallenge.getMokuhyoSyokuName2(), font9));
			}
			if ("3".equals(this.careerPathNum)) {
				Table.addCell(new Phrase(this.preChallenge.getMokuhyoSyokuName3(), font9));
			}

			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
			cell.setFixedHeight(20);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ009"), font9)); // ��啪��
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(blue);
			Table.addCell(cell);
			Table.addCell(new Phrase(this.preChallenge.getMokuhyoSenmonName(), font9));
			if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
				Table.addCell(new Phrase(this.preChallenge.getMokuhyoSenmonName2(), font9));
			}
			if ("3".equals(this.careerPathNum)) {
				Table.addCell(new Phrase(this.preChallenge.getMokuhyoSenmonName3(), font9));
			}

			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT | Rectangle.BOTTOM);
			cell.setFixedHeight(10);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ010"), font9)); // ���x��
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(blue);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase(this.preChallenge.getMokuhyoLevelName(), font9));
			cell.setHorizontalAlignment(numberTypeFormat);
			Table.addCell(cell);
			if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(this.preChallenge.getMokuhyoLevelName2(), font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}
			if ("3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(this.preChallenge.getMokuhyoLevelName3(), font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}

			/* ���ȕ]�� */
			String sougou1 = "";
			String gyomu1 = "";
			String skill1 = "";
			String sougou2 = "";
			String gyomu2 = "";
			String skill2 = "";
			String sougou3 = "";
			String gyomu3 = "";
			String skill3 = "";

			/* �L�����A�p�X�P�ݒ�ς� */
			if (this.assessmentSindan != null) {
				if (this.assessmentSindan.getSougouTasseido() != null && !this.assessmentSindan.getSougouTasseido().equals("")) {
					sougou1 = this.assessmentSindan.getSougouTasseido() + "%";
				}
				if (this.assessmentSindan.getGyomuKeikenTasseido() != null && !this.assessmentSindan.getGyomuKeikenTasseido().equals("")) {
					gyomu1 = this.assessmentSindan.getGyomuKeikenTasseido() + "%";
				}
				if (this.assessmentSindan.getSkillTasseido() != null && !this.assessmentSindan.getSkillTasseido().equals("")) {
					skill1 = this.assessmentSindan.getSkillTasseido() + "%";
				}
			}

			/* �L�����A�p�X�Q�ݒ�ς� */
			if (this.assessmentSindan2 != null) {
				if (this.assessmentSindan2.getSougouTasseido() != null && !this.assessmentSindan2.getSougouTasseido().equals("")) {
					sougou2 = this.assessmentSindan2.getSougouTasseido() + "%";
				}
				if (this.assessmentSindan2.getGyomuKeikenTasseido() != null && !this.assessmentSindan2.getGyomuKeikenTasseido().equals("")) {
					gyomu2 = this.assessmentSindan2.getGyomuKeikenTasseido() + "%";
				}
				if (this.assessmentSindan2.getSkillTasseido() != null && !this.assessmentSindan2.getSkillTasseido().equals("")) {
					skill2 = this.assessmentSindan2.getSkillTasseido() + "%";
				}
			}

			/* �L�����A�p�X�R�ݒ�ς� */
			if (this.assessmentSindan3 != null) {
				if (this.assessmentSindan3.getSougouTasseido() != null && !this.assessmentSindan3.getSougouTasseido().equals("")) {
					sougou3 = this.assessmentSindan3.getSougouTasseido() + "%";
				}
				if (this.assessmentSindan3.getGyomuKeikenTasseido() != null && !this.assessmentSindan3.getGyomuKeikenTasseido().equals("")) {
					gyomu3 = this.assessmentSindan3.getGyomuKeikenTasseido() + "%";
				}
				if (this.assessmentSindan3.getSkillTasseido() != null && !this.assessmentSindan3.getSkillTasseido().equals("")) {
					skill3 = this.assessmentSindan3.getSkillTasseido() + "%";
				}
			}

			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB013"), font9)); // ���ȕ]��
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setFixedHeight(10);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB012"), font9)); // �����B���x
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(blue);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase(sougou1, font9));
			cell.setHorizontalAlignment(numberTypeFormat);
			Table.addCell(cell);
			if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(sougou2, font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}
			if ("3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(sougou3, font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}

			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
			cell.setFixedHeight(10);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ011"), font9)); // �Ɩ��o��
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(blue);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase(gyomu1, font9));
			cell.setHorizontalAlignment(numberTypeFormat);
			Table.addCell(cell);
			if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(gyomu2, font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}
			if ("3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(gyomu3, font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}

			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT | Rectangle.BOTTOM);
			cell.setFixedHeight(10);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ206"), font9)); // �X�L���B���x
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(blue);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase(skill1, font9));
			cell.setHorizontalAlignment(numberTypeFormat);
			Table.addCell(cell);
			if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(skill2, font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}
			if ("3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(skill3, font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}

			/* �]���ҕ]�� */
			String hyokaSougou1 = "";
			String hyokaGyomu1 = "";
			String hyokaSkill1 = "";
			String hyokaSougou2 = "";
			String hyokaGyomu2 = "";
			String hyokaSkill2 = "";
			String hyokaSougou3 = "";
			String hyokaGyomu3 = "";
			String hyokaSkill3 = "";

			if (this.assessmentHyoka != null) {
				if (this.assessmentHyoka.getSougouTasseido() != null && !this.assessmentHyoka.getSougouTasseido().equals("")) {
					hyokaSougou1 = this.assessmentHyoka.getSougouTasseido() + "%";
				}
				if (this.assessmentHyoka.getGyomuKeikenTasseido() != null && !this.assessmentHyoka.getGyomuKeikenTasseido().equals("")) {
					hyokaGyomu1 = this.assessmentHyoka.getGyomuKeikenTasseido() + "%";
				}
				if (this.assessmentHyoka.getSkillTasseido() != null && !this.assessmentHyoka.getSkillTasseido().equals("")) {
					hyokaSkill1 = this.assessmentHyoka.getSkillTasseido() + "%";
				}
			}
			if (this.assessmentHyoka2 != null) {
				if (this.assessmentHyoka2.getSougouTasseido() != null && !this.assessmentHyoka2.getSougouTasseido().equals("")) {
					hyokaSougou2 = this.assessmentHyoka2.getSougouTasseido() + "%";
				}
				if (this.assessmentHyoka2.getGyomuKeikenTasseido() != null && !this.assessmentHyoka2.getGyomuKeikenTasseido().equals("")) {
					hyokaGyomu2 = this.assessmentHyoka2.getGyomuKeikenTasseido() + "%";
				}
				if (this.assessmentHyoka2.getSkillTasseido() != null && !this.assessmentHyoka2.getSkillTasseido().equals("")) {
					hyokaSkill2 = this.assessmentHyoka2.getSkillTasseido() + "%";
				}
			}
			if (this.assessmentHyoka3 != null) {
				if (this.assessmentHyoka3.getSougouTasseido() != null && !this.assessmentHyoka3.getSougouTasseido().equals("")) {
					hyokaSougou3 = this.assessmentHyoka3.getSougouTasseido() + "%";
				}
				if (this.assessmentHyoka3.getGyomuKeikenTasseido() != null && !this.assessmentHyoka3.getGyomuKeikenTasseido().equals("")) {
					hyokaGyomu3 = this.assessmentHyoka3.getGyomuKeikenTasseido() + "%";
				}
				if (this.assessmentHyoka3.getSkillTasseido() != null && !this.assessmentHyoka3.getSkillTasseido().equals("")) {
					hyokaSkill3 = this.assessmentHyoka3.getSkillTasseido() + "%";
				}
			}

			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB014"), font9)); // �]���ҕ]��
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setFixedHeight(10);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB012"), font9)); // �����B���x
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(blue);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase(hyokaSougou1, font9));
			cell.setHorizontalAlignment(numberTypeFormat);
			Table.addCell(cell);
			if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(hyokaSougou2, font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}
			if ("3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(hyokaSougou3, font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}

			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
			cell.setFixedHeight(10);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ011"), font9)); // �Ɩ��o��
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(blue);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase(hyokaGyomu1, font9));
			cell.setHorizontalAlignment(numberTypeFormat);
			Table.addCell(cell);
			if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(hyokaGyomu2, font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}
			if ("3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(hyokaGyomu3, font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}

			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT | Rectangle.BOTTOM);
			cell.setFixedHeight(10);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ206"), font9)); // �X�L���B���x
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(blue);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase(hyokaSkill1, font9));
			cell.setHorizontalAlignment(numberTypeFormat);
			Table.addCell(cell);
			if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(hyokaSkill2, font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}
			if ("3".equals(this.careerPathNum)) {
				cell = new PdfPCell(new Phrase(hyokaSkill3, font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
			}

			/* �]���� */
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB015"), font9)); // �]����
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setFixedHeight(10);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ007"), font9)); // ����
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(blue);
			Table.addCell(cell);
			Table.addCell(new Phrase(this.assessmentHyoka.getHyokasyaBusyoRyakusyoMei(), font9));
			if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
				Table.addCell(new Phrase(this.assessmentHyoka2.getHyokasyaBusyoRyakusyoMei(), font9));
			}
			if ("3".equals(this.careerPathNum)) {
				Table.addCell(new Phrase(this.assessmentHyoka3.getHyokasyaBusyoRyakusyoMei(), font9));
			}

			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT | Rectangle.BOTTOM);
			cell.setFixedHeight(10);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ001"), font9)); // ����
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(blue);
			Table.addCell(cell);
			Table.addCell(new Phrase(this.assessmentHyoka.getHyokasyaKanjiSimei(), font9));
			if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
				Table.addCell(new Phrase(this.assessmentHyoka2.getHyokasyaKanjiSimei(), font9));
			}
			if ("3".equals(this.careerPathNum)) {
				Table.addCell(new Phrase(this.assessmentHyoka3.getHyokasyaKanjiSimei(), font9));
			}

			/* �v�掞 */
			if ("1".equals(this.kubun)) {
				/* �����ڕW */
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB040"), font9)); // �����ڕW
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setBackgroundColor(silver);
				cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
				cell.setFixedHeight(20);
				Table.addCell(cell);
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ008"), font9)); // �E��
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setBackgroundColor(blue);
				Table.addCell(cell);
				Table.addCell(new Phrase(this.challengePlan.getMokuhyoSyokuName(), font9));
				if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
					Table.addCell(new Phrase(this.challengePlan.getMokuhyoSyokuName2(), font9));
				}
				if ("3".equals(this.careerPathNum)) {
					Table.addCell(new Phrase(this.challengePlan.getMokuhyoSyokuName3(), font9));
				}

				cell = new PdfPCell(new Phrase("", font9));
				cell.setBackgroundColor(silver);
				cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
				cell.setFixedHeight(20);
				Table.addCell(cell);
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ009"), font9)); // ��啪��
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setBackgroundColor(blue);
				Table.addCell(cell);
				Table.addCell(new Phrase(this.challengePlan.getMokuhyoSenmonName(), font9));
				if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
					Table.addCell(new Phrase(this.challengePlan.getMokuhyoSenmonName2(), font9));
				}
				if ("3".equals(this.careerPathNum)) {
					Table.addCell(new Phrase(this.challengePlan.getMokuhyoSenmonName3(), font9));
				}

				cell = new PdfPCell(new Phrase("", font9));
				cell.setBackgroundColor(silver);
				cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT | Rectangle.BOTTOM);
				cell.setFixedHeight(10);
				Table.addCell(cell);
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ010"), font9)); // ���x��
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setBackgroundColor(blue);
				Table.addCell(cell);
				cell = new PdfPCell(new Phrase(this.challengePlan.getMokuhyoLevelName(), font9));
				cell.setHorizontalAlignment(numberTypeFormat);
				Table.addCell(cell);
				if ("2".equals(this.careerPathNum) || "3".equals(this.careerPathNum)) {
					cell = new PdfPCell(new Phrase(this.challengePlan.getMokuhyoLevelName2(), font9));
					cell.setHorizontalAlignment(numberTypeFormat);
					Table.addCell(cell);
				}
				if ("3".equals(this.careerPathNum)) {
					cell = new PdfPCell(new Phrase(this.challengePlan.getMokuhyoLevelName3(), font9));
					cell.setHorizontalAlignment(numberTypeFormat);
					Table.addCell(cell);
				}
			}

			if ("2".equals(this.careerPathNum)) {
				/* �L�����A�p�X���Q�̎���74% */
				Table.setTotalWidth(columnWidth * 75 / 100);
			} else if ("3".equals(this.careerPathNum)) {
				/* �L�����A�p�X���R�̎���100% */
				Table.setTotalWidth(columnWidth);
			} else {
				/* �L�����A�p�X���P�̎�48% */
				Table.setTotalWidth(columnWidth * 49 / 100);
			}

			currentY = Table.writeSelectedRows(0, -1, document.left(), currentY - 10, cb);

			/* �敪=�v��̎��\������ */
			if ("1".equals(this.kubun)) {

				/* �y���ݏ]�����Ă���Ɩ��e�[�u�� �z */
				Table = new PdfPTable(1);
				Table.getDefaultCell().setPaddingTop(0);
				Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				/* �y�^�C�g�� �z */
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB041"), font12));
				Table.setTotalWidth(columnWidth);

				currentY = Table.writeSelectedRows(0, -1, document.left(), currentY - 10, cb);

				/* �y�v���W�F�N�g���z */
				Table = new PdfPTable(4);
				final int[] widths2 = { 30, 25, 30, 15 };
				Table.setWidths(widths2);
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ122"), font9));
				cell.setBackgroundColor(silver);
				cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(2);
				Table.addCell(cell);
				/* �y�ڋq�� �z */
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ056"), font9));
				cell.setBackgroundColor(silver);
				cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				Table.addCell(cell);
				/* �y�]���J�n�N���z */
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ221"), font9));
				cell.setBackgroundColor(silver);
				cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				Table.addCell(cell);

				/* �y�f�[�^���z */
				/* 3���ȏ�̎� */
				if (this.outSyokumuItem.length >= 3) {
					for (int i = 0; i < 3; i++) {
						/* �y�v���W�F�N�g���z */
						Table.setWidths(widths2);
						cell = new PdfPCell(new Phrase(this.outSyokumuItem[i][0], font9));
						cell.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell.setFixedHeight(20);
						cell.setColspan(2);
						Table.addCell(cell);
						/* �y�ڋq���z */
						cell = new PdfPCell(new Phrase(this.outSyokumuItem[i][1], font9));
						cell.setHorizontalAlignment(Element.ALIGN_CENTER);
						Table.addCell(cell);
						/* �y�]���J�n�N���z */
						cell = new PdfPCell(new Phrase(PZZ010_CharacterUtil.ChangeYm(this.outSyokumuItem[i][2]), font9));
						cell.setHorizontalAlignment(Element.ALIGN_CENTER);
						Table.addCell(cell);
						Table.setTotalWidth(columnWidth);
					}
					/* 3�������̎� */
				} else {

					for (int i = 0; i < this.outSyokumuItem.length; i++) {
						/* �y�v���W�F�N�g���z */
						Table.setWidths(widths2);
						cell = new PdfPCell(new Phrase(this.outSyokumuItem[i][0], font9));
						cell.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell.setFixedHeight(20);
						cell.setColspan(2);
						Table.addCell(cell);
						/* �y�ڋq���z */
						cell = new PdfPCell(new Phrase(this.outSyokumuItem[i][1], font9));
						cell.setHorizontalAlignment(Element.ALIGN_CENTER);
						Table.addCell(cell);
						/* �y�]���J�n�N���z */
						cell = new PdfPCell(new Phrase(PZZ010_CharacterUtil.ChangeYm(this.outSyokumuItem[i][2]), font9));
						cell.setHorizontalAlignment(Element.ALIGN_CENTER);
						Table.addCell(cell);
						Table.setTotalWidth(columnWidth);
					}

					/* �y��z */
					for (int i = 0; i < 3 - this.outSyokumuItem.length; i++) {
						/* �y�v���W�F�N�g���z */
						Table.setWidths(widths2);
						/* 0���̎��A"����"�̕������\�� */
						if (this.outSyokumuItem.length == 0 && i == 0) {
							cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB042"), font9));
						} else {
							cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get(""), font9));
						}
						cell.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell.setFixedHeight(20);
						cell.setColspan(2);
						Table.addCell(cell);
						/* �y�ڋq���z */
						cell = new PdfPCell(new Phrase("", font9));
						cell.setHorizontalAlignment(Element.ALIGN_CENTER);
						Table.addCell(cell);
						/* �y�]���J�n�N���z */
						cell = new PdfPCell(new Phrase("", font9));
						cell.setHorizontalAlignment(Element.ALIGN_CENTER);
						Table.addCell(cell);
						Table.setTotalWidth(columnWidth);
					}
				}
				currentY = Table.writeSelectedRows(0, -1, document.left(), currentY - 10, cb);

				/* �y���ӎ����z */
				String abb006GyomuSetumeiAnnounce = (String) ReadFile.announceMapData.get("ABB006");
				if (abb006GyomuSetumeiAnnounce != null) {
					abb006GyomuSetumeiAnnounce = abb006GyomuSetumeiAnnounce.replaceAll("\\Q" + "{0}" + "\\E", PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DZZ177")));
					abb006GyomuSetumeiAnnounce = abb006GyomuSetumeiAnnounce.replaceAll("\\Q" + "{1}" + "\\E", PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DZZ124")));
					abb006GyomuSetumeiAnnounce = abb006GyomuSetumeiAnnounce.replaceAll("\\Q" + "{2}" + "\\E", PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DZZ121")));
					abb006GyomuSetumeiAnnounce = abb006GyomuSetumeiAnnounce.replaceAll("\\Q" + "{3}" + "\\E", PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DZZ221")));
				} else {
					abb006GyomuSetumeiAnnounce = "";
				}

				Table = new PdfPTable(1);
				Table.getDefaultCell().setPaddingTop(0);
				Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				Table.addCell(new Phrase(abb006GyomuSetumeiAnnounce, font9));
				Table.setTotalWidth(columnWidth);

				currentY = Table.writeSelectedRows(0, -1, document.left(), currentY - 10, cb);

				/* �敪�����т̏ꍇ�͉����\�����Ȃ� */
			} else {
				currentY -= 45; // �󔒂̊Ԋu���w��
			}

			/* �y�\�͊J���v��Ǝ��сz */
			Table = new PdfPTable(1);
			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			/* �y�^�C�g���z */
			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB043"), font12));
			} else {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB063"), font12));
			}
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left(), currentY - 10, cb);

			/* �y�Ɩ��o���e�[�u���z */
			Table = new PdfPTable(3);
			final int[] widths3 = { 5, 5, 90 };
			Table.setWidths(widths3);
			/* �y�Ɩ��o���z */
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ011"), fontNrkKhtKomoku)); /* CHG BQUP1-002 h-aida 2007/04/12 */
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);

			/* �v�掞�͐^�� */
			if ("1".equals(this.kubun)) {
				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				/* ���ю��͉� */
			} else {
				cell.setVerticalAlignment(Element.ALIGN_BOTTOM);
			}
			Table.addCell(cell);

			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setFixedHeight(75);

			/* �y�v��z */
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.getDefaultCell().setBackgroundColor(blue);
			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB044"), font9));
			} else {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB079"), font9));
			}
			cell.setBackgroundColor(white);
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			Table.getDefaultCell().setBackgroundColor(white);

			/* �y�v��f�[�^�z */
			Table.addCell(new Phrase(this.challengePlan.getGyomuKeiken(), font9));

			/* �v�掞�̏ꍇ */
			if ("1".equals(this.kubun)) {
				Table.getDefaultCell().setFixedHeight(0);
			}
			/* �y��z */
			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT);

			Table.addCell(cell);
			/* �y���сz */
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.getDefaultCell().setBackgroundColor(blue);
			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB045"), font9));
			} else {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB080"), font9));
			}
			Table.getDefaultCell().setBackgroundColor(white);

			/* �y���уf�[�^�z */
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			Table.addCell(new Phrase(this.challengeResult.getGyomuKeiken(), font9));
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left(), currentY - 10, cb);

			/* �y�����u�e�[�u���z */
			Table = new PdfPTable(3);
			Table.setWidths(widths3);
			/* �y�����u�z */
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ114"), fontNrkKhtKomoku)); /* CHG BQUP1-002 h-aida 2007/04/12 */
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table.addCell(cell);

			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setFixedHeight(30);
			Table.getDefaultCell().setBackgroundColor(blue);
			/* �y�v��z */
			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB046"), font9));
			} else {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB081"), font9));
			}
			Table.getDefaultCell().setBackgroundColor(white);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			/* �y�����u�f�[�^ �z */
			Table.addCell(new Phrase(this.challengePlan.getKyoikuZyukou(), font9));

			/* �v�掞�̏ꍇ */
			if ("1".equals(this.kubun)) {
				Table.getDefaultCell().setFixedHeight(0);
			}

			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT);
			Table.addCell(cell);
			/* �y���сz */
			Table.getDefaultCell().setBackgroundColor(blue);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB047"), font9));
			} else {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB082"), font9));
			}
			/* �y�f�[�^�z */
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			Table.getDefaultCell().setBackgroundColor(white);
			Table.addCell(new Phrase(this.challengeResult.getKyoikuZyukou(), font9));
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left(), currentY - 10, cb);

			/* �y�擾���i�z */
			Table = new PdfPTable(6);
			final int[] widths5 = { 5, 5, 30, 40, 10, 10 };
			Table.setWidths(widths5);
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);
			cell.setBackgroundColor(blue);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);

			/* �y���i���́A���x���A���_���o���z */
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.getDefaultCell().setBackgroundColor(silver);
			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DZZ085"), font9));
			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DZZ128"), font9));
			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DZZ087"), font9));
			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DZZ086"), font9));
			Table.setTotalWidth(columnWidth);
			Table.getDefaultCell().setBackgroundColor(white);

			// 2�s��
			Table.setWidths(widths5);
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);
			cell.setBackgroundColor(blue);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);

			/* �y���i���́A���x���A���_�z */
			Table.getDefaultCell().setFixedHeight(25);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(new Phrase(this.sikakumeisyoTop1, font9));
			Table.addCell(new Phrase(this.sikakulevelTop1, font9));
			Table.addCell(new Phrase(this.sikakutokutenTop1, font9));
			Table.addCell(new Phrase(this.sikakusyutokuhiTop1, font9));

			Table.setTotalWidth(columnWidth);

			// 3�s��
			Table.setWidths(widths5);
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);
			if ("1".equals(this.kubun)) {
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB048"), font9));
			} else {
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB083"), font9));
			}
			cell.setBackgroundColor(blue);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);

			/* �y���i���́A���x���A���_���o���z */
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(new Phrase(this.sikakumeisyoTop2, font9));
			Table.addCell(new Phrase(this.sikakulevelTop2, font9));
			Table.addCell(new Phrase(this.sikakutokutenTop2, font9));
			Table.addCell(new Phrase(this.sikakusyutokuhiTop2, font9));

			Table.setTotalWidth(columnWidth);

			// 4�s��
			Table.setWidths(widths5);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ116"), fontNrkKhtKomoku)); /* CHG BQUP1-002 h-aida 2007/04/12 */
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(blue);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);

			/* �y���i���́A���x���A���_���o���z */
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(new Phrase(this.sikakumeisyoTop3, font9));
			Table.addCell(new Phrase(this.sikakulevelTop3, font9));
			Table.addCell(new Phrase(this.sikakutokutenTop3, font9));
			Table.addCell(new Phrase(this.sikakusyutokuhiTop3, font9));

			Table.setTotalWidth(columnWidth);

			// 5�s�ځy�v��z���y���сz
			Table.setWidths(widths5);
			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(blue);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);

			/* �y���i���́A���x���A���_�f�[�^�z */
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(new Phrase(this.sikakumeisyoDown1, font9));
			Table.addCell(new Phrase(this.sikakulevelDown1, font9));
			Table.addCell(new Phrase(this.sikakutokutenDown1, font9));
			Table.addCell(new Phrase(this.sikakusyutokuhiDown1, font9));

			Table.setTotalWidth(columnWidth);

			// 6�s��
			Table.setWidths(widths5);
			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);
			if ("1".equals(this.kubun)) {
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB049"), font9));
			} else {
				cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB084"), font9));
			}
			cell.setBackgroundColor(blue);
			cell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);

			/* �y���i���́A���x���A���_�f�[�^�z */
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(new Phrase(this.sikakumeisyoDown2, font9));
			Table.addCell(new Phrase(this.sikakulevelDown2, font9));
			Table.addCell(new Phrase(this.sikakutokutenDown2, font9));
			Table.addCell(new Phrase(this.sikakusyutokuhiDown2, font9));

			Table.setTotalWidth(columnWidth);

			// 7�s��
			Table.setWidths(widths5);
			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);
			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(blue);
			cell.setBorder(Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(cell);

			/* �y���i���́A���x���A���_�f�[�^�z */
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.addCell(new Phrase(this.sikakumeisyoDown3, font9));
			Table.addCell(new Phrase(this.sikakulevelDown3, font9));
			Table.addCell(new Phrase(this.sikakutokutenDown3, font9));
			Table.addCell(new Phrase(this.sikakusyutokuhiDown3, font9));
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left(), currentY - 10, cb);

			/* �敪=�v��̎��\������ */
			if ("1".equals(this.kubun)) {
				/* �y���ӎ����z */
				String abb007SikakuSetumeiAnnounce = (String) ReadFile.announceMapData.get("ABB007");
				if (abb007SikakuSetumeiAnnounce != null) {
					abb007SikakuSetumeiAnnounce = abb007SikakuSetumeiAnnounce.replaceAll("\\Q" + "{0}" + "\\E", PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DZZ086")));
				} else {
					abb007SikakuSetumeiAnnounce = "";
				}
				Table = new PdfPTable(1);
				Table.getDefaultCell().setPaddingTop(0);
				Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

				Table.addCell(new Phrase(abb007SikakuSetumeiAnnounce, font9));
				Table.setTotalWidth(columnWidth);

				currentY = Table.writeSelectedRows(0, -1, document.left(), currentY - 10, cb);
			}

			/* �y���F�ҁz */
			Table = new PdfPTable(5);
			final int[] widths6 = { 8, 35, 15, 23, 19 };
			Table.setWidths(widths6);

			cell.setBackgroundColor(white);
			cell.setBorder(Rectangle.RIGHT);
			Table.addCell(cell);

			Table.getDefaultCell().setFixedHeight(25);
			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DZZ007") + "�F" + PZZ010_CharacterUtil.normalizedStr(this.challengePlan.getSindansyaBusyoRyakusyoMei()), font9));
			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DZZ002") + "�F" + PZZ010_CharacterUtil.normalizedStr(this.challengePlan.getSindansya()), font9));
			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DZZ001") + "�F" + PZZ010_CharacterUtil.normalizedStr(this.challengePlan.getSindansyaKanjiSimei()), font9));
			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB033") + "�F" + PZZ010_CharacterUtil.ChangeYmd(this.challengePlan.getJissiNengappi()), font9));

			Table.setTotalWidth(columnWidth);

			Table.setWidths(widths6);

			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DBB099") + "�F", font9));
			cell.setBorder(Rectangle.RIGHT);
			Table.addCell(cell);

			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DZZ007") + "�F" + PZZ010_CharacterUtil.normalizedStr(this.hyoka_syozoku), font9));
			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DZZ002") + "�F" + PZZ010_CharacterUtil.normalizedStr(this.hyoka_simeino), font9));
			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DZZ001") + "�F" + PZZ010_CharacterUtil.normalizedStr(this.hyoka_simei), font9));
			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB034") + "�F" + PZZ010_CharacterUtil.ChangeYmd(this.hyoka_jissi), font9));

			Table.setTotalWidth(columnWidth);
			currentY = Table.writeSelectedRows(0, -1, document.left() + columnWidth + gutter, document.top() - 25, cb);

			currentY -= 4;

			/* �y�ʒk���z */
			String abb005MendanbiAnnounce = (String) ReadFile.announceMapData.get("ABB005");
			if (abb005MendanbiAnnounce != null) {
				abb005MendanbiAnnounce = abb005MendanbiAnnounce.replaceAll("\\Q" + "{0}" + "\\E", PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DZZ007")));
				abb005MendanbiAnnounce = abb005MendanbiAnnounce.replaceAll("\\Q" + "{1}" + "\\E", PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DZZ001")));
			} else {
				abb005MendanbiAnnounce = "";
			}

			Table = new PdfPTable(2);
			final int[] widths7 = { 8, 92 };
			Table.setWidths(widths7);
			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB035") + "�F", font9));
			Table.addCell(new Phrase(abb005MendanbiAnnounce, font9line));
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left() + columnWidth + gutter, currentY - 5, cb);

			/* �y���Ȍ[���z */
			Table = new PdfPTable(3);
			Table.setWidths(widths3);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ117"), fontNrkKhtKomoku)); /* CHG BQUP1-002 h-aida 2007/04/12 */
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_BOTTOM);

			Table.addCell(cell);
			Table.getDefaultCell().setFixedHeight(50);
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.getDefaultCell().setBackgroundColor(blue);

			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB050"), font9));
			} else {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB085"), font9));
			}
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			Table.getDefaultCell().setBackgroundColor(white);
			Table.getDefaultCell().setPaddingTop(0);
			Table.addCell(new Phrase(this.challengePlan.getJikoKeihatu(), font9));

			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT);

			Table.addCell(cell);
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.getDefaultCell().setBackgroundColor(blue);

			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB051"), font9));
			} else {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB086"), font9));
			}
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			Table.getDefaultCell().setBackgroundColor(white);
			Table.addCell(new Phrase(this.challengeResult.getJikoKeihatu(), font9));

			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left() + columnWidth + gutter, currentY - 10, cb);
			currentY -= 4;

			/* �y�ٓ��Ɋւ����]�z */
			Table = new PdfPTable(3);
			Table.setWidths(widths3);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ118"), fontNrkKhtKomoku)); /* CHG BQUP1-002 h-aida 2007/04/12 */
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_BOTTOM);

			Table.addCell(cell);
			Table.getDefaultCell().setFixedHeight(50);
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.getDefaultCell().setBackgroundColor(blue);

			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB052"), font9));
			} else {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB087"), font9));
			}
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			Table.getDefaultCell().setBackgroundColor(white);
			Table.getDefaultCell().setPaddingTop(0);
			Table.addCell(new Phrase(this.challengePlan.getIdoKibo(), font9));

			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT);

			Table.addCell(cell);
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.getDefaultCell().setBackgroundColor(blue);

			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB053"), font9));
			} else {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB088"), font9));
			}
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			Table.getDefaultCell().setBackgroundColor(white);
			Table.addCell(new Phrase(this.challengeResult.getIdoKibo(), font9));

			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left() + columnWidth + gutter, currentY - 10, cb);
			currentY -= 4;

			/* �y�ǋL�����z */
			Table = new PdfPTable(3);
			Table.setWidths(widths3);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ119"), fontNrkKhtKomoku)); /* CHG BQUP1-002 h-aida 2007/04/12 */
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_BOTTOM);

			Table.addCell(cell);
			Table.getDefaultCell().setFixedHeight(50);
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.getDefaultCell().setBackgroundColor(blue);

			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB054"), font9));
			} else {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB089"), font9));
			}
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			Table.getDefaultCell().setBackgroundColor(white);
			Table.getDefaultCell().setPaddingTop(0);
			Table.addCell(new Phrase(this.challengePlan.getTuikiJiko(), font9));

			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT);

			Table.addCell(cell);
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.getDefaultCell().setBackgroundColor(blue);

			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB055"), font9));
			} else {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB090"), font9));
			}
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			Table.getDefaultCell().setBackgroundColor(white);
			Table.addCell(new Phrase(this.challengeResult.getTuikiJiko(), font9));

			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left() + columnWidth + gutter, currentY - 10, cb);
			currentY -= 4;

			/* �y�㒷�R�����g�z */
			Table = new PdfPTable(3);
			Table.setWidths(widths3);
			cell = new PdfPCell(new Phrase((String) ReadFile.paramMapData.get("DZZ120"), fontNrkKhtKomoku)); /* CHG BQUP1-002 h-aida 2007/04/12 */
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_BOTTOM);

			Table.addCell(cell);
			Table.getDefaultCell().setFixedHeight(50);
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.getDefaultCell().setBackgroundColor(blue);

			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB056"), font9));
			} else {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB091"), font9));
			}
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			Table.getDefaultCell().setBackgroundColor(white);
			Table.getDefaultCell().setPaddingTop(0);
			Table.addCell(new Phrase(this.challengePlan.getZyouComment(), font9));

			cell = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder(Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT);

			Table.addCell(cell);
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table.getDefaultCell().setBackgroundColor(blue);

			if ("1".equals(this.kubun)) {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB057"), font9));
			} else {
				Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB092"), font9));
			}
			Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			Table.getDefaultCell().setBackgroundColor(white);
			Table.addCell(new Phrase(this.challengeResult.getZyouComment(), font9));

			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left() + columnWidth + gutter, currentY - 10, cb);
			currentY -= 4;

			// �ʒk���`
			Table = new PdfPTable(1);

			Table.getDefaultCell().setFixedHeight(155);
			Table.addCell(new Phrase((String) ReadFile.paramMapData.get("DBB058"), font9));
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left() + columnWidth + gutter, currentY - 10, cb);

			// ���ӎ���
			Table = new PdfPTable(1);
			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			Table.addCell(new Phrase((String) ReadFile.announceMapData.get("ABB008"), font9));
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left() + columnWidth + gutter, currentY - 10, cb);

			Table = new PdfPTable(1);
			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			Table.addCell(new Phrase((String) ReadFile.announceMapData.get("ABB009"), font9));
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left() + columnWidth + gutter, currentY - 2, cb);

			document.close();
			Log.method(this.login_no, "OUT", "");

		} catch (final BadElementException e) {
			throw e;
		} catch (final DocumentException e) {
			throw e;
		} catch (final IOException e) {
			throw e;
		} catch (final Exception e) {
			throw e;
		} finally {
			/* �h�L�������g����� */
			if (document != null) {
				try {
					document.close();
				} catch (final Exception e) {
					Log.error("", e);
					throw e;
				}
			}
			try {
			} catch (final Exception e) {
				Log.error("", e);
				throw e;
			}
		}
	}
}
