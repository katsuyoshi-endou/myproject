/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.report.bean;

import java.io.ByteArrayOutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import jp.co.hisas.career.performance.report.ejb.PED_TotalizePerformanceReportEJB;
import jp.co.hisas.career.performance.util.bean.PED_BatchExclusiveLogic;
import jp.co.hisas.career.util.common.ExclusiveManager;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfWriter;

/**
 * �W�v�����ʂ���Ă΂��A�ŗL�̃X���b�h���� �u���|�[�g�쐬�v�������ɌĂ΂��
 */
public class PED_TotalizePerformanceReportPDFThread extends Thread {

	/** ���O�C��NO */
	private static String loginNo;

	/** �A���P�[�gNO */
	private static String enqueteNo;

	/** �A���P�[�g���� */
	private static String enqueteNm;

	/** �g�D�h�c���X�g */
	private static ArrayList groupIDList;

	/** �Z�b�V����ID */
	private static String sessionId;

	/** EJBBean */
	private static PED_TotalizePerformanceReportEJB userSession;

	/** �`�[���R���f�B�V�����}�b�v */
	private final static String CCMAP_PDF = "CCMAP_PDF";

	/** �r�W�l�X�}�b�v */
	private final static String BMMAP_PDF = "BMMAP_PDF";

	/** ���[�_�V�b�v���� */
	private final static String RTMAP_PDF = "RTMAP_PDF";

	/** �g�D�����x���� */
	private final static String SM_PDF = "SM_PDF";

	/** �g�D�̃��^�R���s�e���V�[ */
	private final static String MC_PDF = "MC_PDF";

	/** ��1�K�w�}����� */
	private final static String YAKUSHOKU1_HANREI = "Yakushoku1_Hanrei";

	/** ��2�K�w�}����� */
	private final static String YAKUSHOKU2_HANREI = "Yakushoku2_Hanrei";

	/** ��3�K�w�}����� */
	private final static String YAKUSHOKU3_HANREI = "Yakushoku3_Hanrei";

	/** ��4�K�w�}����� */
	private final static String YAKUSHOKU4_HANREI = "Yakushoku4_Hanrei";

	/** ��5�K�w�}����� */
	private final static String YAKUSHOKU5_HANREI = "Yakushoku5_Hanrei";

	/** ��6�K�w�}����� */
	private final static String YAKUSHOKU6_HANREI = "Yakushoku6_Hanrei";

	/** ���O���b�Z�[�W�i�[�N���X */
	private static ArrayList logMsgList = null;

	/** �Z�b�V�����P�ʂŏ�Ԃ�ێ�����}�b�v */
	private static final Map jotaiMap = Collections.synchronizedMap(new HashMap());

	/** �Z�b�V�����P�ʂŏ�Ԃ�ێ������O�}�b�v */
	private static final Map exceMap = Collections.synchronizedMap(new HashMap());

	/** �Z�b�V�����P�ʂŏ�Ԃ�ێ����郍�O�}�b�v */
	private static final Map logMsgMap = Collections.synchronizedMap(new HashMap());

	/** �Z�b�V�����P�ʂŏ�Ԃ�ێ����郍�O�}�b�v �ǉ�PDF�i���^�R���s�e���V�[�j�p */
	private static final Map logMsgMap2 = Collections.synchronizedMap(new HashMap());

	/** �o�b�`������� */
	private static final String TYPE_REPORT = "Report";

	/**
	 * �R���X�g���N�^
	 */
	public PED_TotalizePerformanceReportPDFThread() {

	}

	/**
	 * �X���b�h���C������.
	 * @param args
	 */
	public static void main(final String[] args) {

		final String tmpSessionId = PED_TotalizePerformanceReportPDFThread.sessionId;
		final String tmpLoginNo = PED_TotalizePerformanceReportPDFThread.loginNo;
		final String tmpEnqueteNo = PED_TotalizePerformanceReportPDFThread.enqueteNo;
		final ArrayList tmpGroupIDList = PED_TotalizePerformanceReportPDFThread.groupIDList;
		final String tmpEnqueteNm = PED_TotalizePerformanceReportPDFThread.enqueteNm;
		final PED_TotalizePerformanceReportEJB tmpUserSession = PED_TotalizePerformanceReportPDFThread.userSession;
		String val = "0";
		try {
			// ��O����F�Ώۑg�D0��
			if (tmpGroupIDList != null && tmpGroupIDList.size() > 0) {
				// �G���[���O������
				PED_TotalizePerformanceReportPDFThread.logMsgMap.put(tmpSessionId, new ArrayList());
				PED_TotalizePerformanceReportPDFThread.logMsgMap2.put(tmpSessionId, new ArrayList());

				final ArrayList paramIDList = new ArrayList();
				paramIDList.add(PED_TotalizePerformanceReportPDFThread.YAKUSHOKU1_HANREI);
				paramIDList.add(PED_TotalizePerformanceReportPDFThread.YAKUSHOKU2_HANREI);
				paramIDList.add(PED_TotalizePerformanceReportPDFThread.YAKUSHOKU3_HANREI);
				paramIDList.add(PED_TotalizePerformanceReportPDFThread.YAKUSHOKU4_HANREI);
				paramIDList.add(PED_TotalizePerformanceReportPDFThread.YAKUSHOKU5_HANREI);
				paramIDList.add(PED_TotalizePerformanceReportPDFThread.YAKUSHOKU6_HANREI);

				// �ėp�p�����[�^���l���擾
				final HashMap paramMap = tmpUserSession.getGeneralParameter(tmpLoginNo, paramIDList);

				// �o�c�e�\���f�[�^�i�[�p
				HashMap grpMap = new HashMap();
				final HashMap outputFlg = tmpUserSession.getPdfOutputFlg(tmpLoginNo, tmpEnqueteNo);
				try {
					if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[12]))) {
						// �`�[���R���f�B�V�����}�b�v�̕\���f�[�^�擾
						grpMap = tmpUserSession.getConditionMapData(tmpLoginNo, tmpEnqueteNo, tmpGroupIDList, grpMap);
					}
				} catch (final SQLException e) {
				}
				// �r�W�l�X�}�C���h�}�b�v�̕\���f�[�^�擾
				try {
					if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[13]))) {
						grpMap = tmpUserSession.getBusinessMindMap(tmpLoginNo, tmpEnqueteNo, tmpGroupIDList, grpMap);
					}
				} catch (final SQLException e) {
				}
				// ���[�_�[�V�b�v�����}�b�v�̕\���f�[�^�擾
				try {
					if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[14]))) {
						grpMap = tmpUserSession.getLeadershipTraitsMap(tmpLoginNo, tmpEnqueteNo, tmpGroupIDList, grpMap);
					}
				} catch (final SQLException e) {
				}
				// �g�D�����x�����̕\���f�[�^�擾
				try {
					if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[15]))) {
						grpMap = tmpUserSession.getSoshikiManzoku(tmpLoginNo, tmpEnqueteNo, tmpGroupIDList, grpMap);
					}
				} catch (final SQLException e) {
				}
				// ���^�R���s�e���V�[�̕\���f�[�^�擾
				try {
					if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[16]))) {
						grpMap = tmpUserSession.getMetaCompetency(tmpLoginNo, tmpEnqueteNo, tmpGroupIDList, grpMap, tmpSessionId);
					}
				} catch (final SQLException e) {
				}
				// �\���Ώێ҃f�[�^�̎擾
				try {
					grpMap = tmpUserSession.getOutputPerson(tmpLoginNo, tmpEnqueteNo, tmpGroupIDList, grpMap, tmpSessionId, outputFlg);
				} catch (final SQLException e) {
				}

				// �g�D�R�[�h���L�[�ɂ����o�c�e�i�[�p�̃}�b�v
				final HashMap pdfGroupMap = new HashMap();

				// �o�c�e�̍쐬���s��
				final Iterator grpIte = grpMap.keySet().iterator();
				while (grpIte.hasNext()) {
					final String grpIDKey = (String) grpIte.next();

					PED_ReportSoshikiValueBean soshikiBean = new PED_ReportSoshikiValueBean();
					if (grpMap.containsKey(grpIDKey)) {
						soshikiBean = (PED_ReportSoshikiValueBean) grpMap.get(grpIDKey);
					}
					// �K�w�}��̐ݒ�
					soshikiBean.setYakushoku1_hanrei((String) paramMap.get(PED_TotalizePerformanceReportPDFThread.YAKUSHOKU1_HANREI));
					soshikiBean.setYakushoku2_hanrei((String) paramMap.get(PED_TotalizePerformanceReportPDFThread.YAKUSHOKU2_HANREI));
					soshikiBean.setYakushoku3_hanrei((String) paramMap.get(PED_TotalizePerformanceReportPDFThread.YAKUSHOKU3_HANREI));
					soshikiBean.setYakushoku4_hanrei((String) paramMap.get(PED_TotalizePerformanceReportPDFThread.YAKUSHOKU4_HANREI));
					soshikiBean.setYakushoku5_hanrei((String) paramMap.get(PED_TotalizePerformanceReportPDFThread.YAKUSHOKU5_HANREI));
					soshikiBean.setYakushoku6_hanrei((String) paramMap.get(PED_TotalizePerformanceReportPDFThread.YAKUSHOKU6_HANREI));

					// PDF�̊i�[�̈�
					final Document document = new Document(PageSize.A4.rotate(), 10, 10, 10, 10);

					PdfWriter writer;

					final ByteArrayOutputStream baos = new ByteArrayOutputStream();
					writer = PdfWriter.getInstance(document, baos);

					boolean newPageflg = false;

					document.open();
					final PED_TotalizePerformanceReportPdf pdf = new PED_TotalizePerformanceReportPdf(document, writer, tmpEnqueteNm);
					if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[12]))) {
						pdf.makePdf(PED_TotalizePerformanceReportPDFThread.CCMAP_PDF, soshikiBean);
						newPageflg = true;
					}
					if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[13]))) {
						if (newPageflg) {
							document.newPage();
						}
						pdf.makePdf(PED_TotalizePerformanceReportPDFThread.BMMAP_PDF, soshikiBean);
						newPageflg = true;
					}
					if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[14]))) {
						if (newPageflg) {
							document.newPage();
						}
						pdf.makePdf(PED_TotalizePerformanceReportPDFThread.RTMAP_PDF, soshikiBean);
						newPageflg = true;
					}
					if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[15]))) {
						if (newPageflg) {
							document.newPage();
						}
						pdf.makePdf(PED_TotalizePerformanceReportPDFThread.SM_PDF, soshikiBean);
						newPageflg = true;
					}
					if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[16]))) {
						if (newPageflg) {
							document.newPage();
						}
						pdf.makePdf(PED_TotalizePerformanceReportPDFThread.MC_PDF, soshikiBean);
					}
					document.close();

					// PDF��DB�o�^
					tmpUserSession.insertReportPDF(tmpLoginNo, tmpEnqueteNo, tmpSessionId, baos.toByteArray(), soshikiBean.getSoshikiCode());
					// �g�D�R�[�h���L�[�ɂ��Ċi�[
					document.close();
					baos.close();
					writer.close();
				}

				// ���O�o��

				// �ǉ�PDF�i���^�R���s�e���V�[�j�̃��O������
				final ArrayList correctionLogList = (ArrayList) PED_TotalizePerformanceReportPDFThread.logMsgMap.get(tmpSessionId);
				final ArrayList correctionLogList2 = (ArrayList) PED_TotalizePerformanceReportPDFThread.logMsgMap2.get(tmpSessionId);

				final HashMap groupMsgIDMap = new HashMap();
				final ArrayList correctionLogList3 = new ArrayList();
				for (int i = 0, num = correctionLogList2.size(); i < num; i++) {
					final String[] tmp = (String[]) correctionLogList2.get(i);
					if (!groupMsgIDMap.containsKey(tmp[1] + tmp[2])) {
						correctionLogList3.add(tmp);
						groupMsgIDMap.put(tmp[1] + tmp[2], tmp[1] + tmp[2]);
					}
				}

				for (int i = 0; correctionLogList3 != null && i < correctionLogList3.size(); i++) {
					correctionLogList.add(correctionLogList3.get(i));
				}

				tmpUserSession.insertPDFLog(tmpLoginNo, tmpEnqueteNo, tmpSessionId, correctionLogList);
				// �擾�����I��

			}
		} catch (final SQLException e) {
			Log.error(PED_TotalizePerformanceReportPDFThread.loginNo, "HJE-0001", e);
			PED_TotalizePerformanceReportPDFThread.jotaiMap.put(tmpSessionId, "0");
		} catch (final Exception ex) {
			Log.error(PED_TotalizePerformanceReportPDFThread.loginNo, "HJE-0017", ex);
			PED_TotalizePerformanceReportPDFThread.jotaiMap.put(tmpSessionId, "-1");
			val = "2";
		} finally {
			try {
				// �擾�����I��
				ExclusiveManager.getInstance().releaseExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY);
				tmpUserSession.createBatchStatus(tmpLoginNo, tmpEnqueteNo, PED_TotalizePerformanceReportPDFThread.TYPE_REPORT, val);
				PED_TotalizePerformanceReportPDFThread.jotaiMap.put(tmpSessionId, "0");
			} catch (final Exception e) {
				Log.error(PED_TotalizePerformanceReportPDFThread.loginNo, "HJE-0001", e);
			}
		}
	}

	/**
	 * �Ď����J�n����
	 * @param loginNo
	 * @param sessionId
	 * @param enqueteNo
	 * @param enqueteNm
	 * @param groupIDList
	 * @param userSession
	 */
	public static void execute(final String loginNo, final String sessionId, final String enqueteNo, final String enqueteNm, final ArrayList groupIDList,
			final PED_TotalizePerformanceReportEJB userSession) {

		PED_TotalizePerformanceReportPDFThread.userSession = userSession;
		PED_TotalizePerformanceReportPDFThread.loginNo = loginNo;
		PED_TotalizePerformanceReportPDFThread.enqueteNo = enqueteNo;
		PED_TotalizePerformanceReportPDFThread.enqueteNm = enqueteNm;
		PED_TotalizePerformanceReportPDFThread.groupIDList = groupIDList;
		PED_TotalizePerformanceReportPDFThread.sessionId = sessionId;
		PED_TotalizePerformanceReportPDFThread.logMsgList = (ArrayList) PED_TotalizePerformanceReportPDFThread.logMsgMap.get(sessionId);
		final Thread t = new PED_TotalizePerformanceReportPDFThread();
		t.start();
	}

	public void run() {
		PED_TotalizePerformanceReportPDFThread.main(null);
	}

	public static Exception getExMap(final String sessionId) {
		return (Exception) PED_TotalizePerformanceReportPDFThread.exceMap.get(sessionId);
	}

	public static void setEx(final Exception ex) {
	}

	public static String getJotaiFlg(final String sessionNo) {
		return (String) PED_TotalizePerformanceReportPDFThread.jotaiMap.get(sessionNo);
	}

	public static void setJotaiFlg(final String sessionNo, final String jotaiFlg) {
		PED_TotalizePerformanceReportPDFThread.jotaiMap.put(sessionNo, jotaiFlg);
	}

	public static void removeJotaiFlg(final String sessionNo) {
		PED_TotalizePerformanceReportPDFThread.jotaiMap.remove(sessionNo);
	}

	public static void removeException(final String sessionNo) {
		PED_TotalizePerformanceReportPDFThread.exceMap.remove(sessionNo);
	}

	public static ArrayList getLogMsgList(final String sessionId) {
		return (ArrayList) PED_TotalizePerformanceReportPDFThread.logMsgMap.get(sessionId);
	}

	public static void setLogMsgList(final String sessionId, final ArrayList logMsgList) {
		PED_TotalizePerformanceReportPDFThread.logMsgMap.put(sessionId, logMsgList);
	}

	public static ArrayList getLogMsgList2(final String sessionId) {
		return (ArrayList) PED_TotalizePerformanceReportPDFThread.logMsgMap2.get(sessionId);
	}

	public static void setLogMsgList2(final String sessionid, final ArrayList logMsgList) {
		PED_TotalizePerformanceReportPDFThread.logMsgMap2.put(PED_TotalizePerformanceReportPDFThread.sessionId, logMsgList);
	}

}
