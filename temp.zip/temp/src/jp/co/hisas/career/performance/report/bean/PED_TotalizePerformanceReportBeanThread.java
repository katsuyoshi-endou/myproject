/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.report.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import jp.co.hisas.career.performance.util.bean.PED_BatchExclusiveLogic;
import jp.co.hisas.career.performance.util.ejb.PED_StoredProcedureUtilityEJB;
import jp.co.hisas.career.util.common.ExclusiveManager;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �W�v�����ʂ���Ă΂��A�ŗL�̃X���b�h����
 */
public class PED_TotalizePerformanceReportBeanThread extends Thread {

	/** ���O�I���ԍ� */
	private static String loginNo;

	/** �Z�b�V�����ԍ� */
	private static String sessionNo;

	/** �A���P�[�g�ԍ� */
	private static String enqueteNo;

	/** ���� */
	private static ArrayList argsList;

	/** EJB�I�u�W�F�N�g */
	private static PED_StoredProcedureUtilityEJB userSession;

	/** �L�b�N����PL/SQL */
	private static String sql;

	/** �Z�b�V�����P�ʂŏ�Ԃ�ێ�����}�b�v */
	private static final Map jotaiMap = Collections.synchronizedMap(new HashMap());

	/** �o�b�`�󋵊Ǘ���� */
	private static String shubetsu = null;

	public static void main(final String[] args) {

		final String tmpLoginNo = PED_TotalizePerformanceReportBeanThread.loginNo;
		final String tmpSessionNo = PED_TotalizePerformanceReportBeanThread.sessionNo;
		final String tmpEnqueteNo = PED_TotalizePerformanceReportBeanThread.enqueteNo;
		final String tmpSQL = PED_TotalizePerformanceReportBeanThread.sql;
		final String tmpShubetsu = PED_TotalizePerformanceReportBeanThread.shubetsu;
		final PED_StoredProcedureUtilityEJB tmpUserSession = PED_TotalizePerformanceReportBeanThread.userSession;
		int errorNo = 1;
		String val = "0";
		try {

			final String msgFileName = (String) ReadFile.fileMapData.get(HcdbDef.msgCode);

			// �����쐬 �S�Ă̔z��̗v�f���𓝈ꂳ���邱��
			final String[] args01 = (String[]) PED_TotalizePerformanceReportBeanThread.argsList.get(0);
			final String[] args02 = (String[]) PED_TotalizePerformanceReportBeanThread.argsList.get(1);
			final String[] args03 = (String[]) PED_TotalizePerformanceReportBeanThread.argsList.get(2);
			final String[] args04 = (String[]) PED_TotalizePerformanceReportBeanThread.argsList.get(3);
			final String[] args05 = (String[]) PED_TotalizePerformanceReportBeanThread.argsList.get(4);
			final String[] args06 = (String[]) PED_TotalizePerformanceReportBeanThread.argsList.get(5);
			final String[] args07 = (String[]) PED_TotalizePerformanceReportBeanThread.argsList.get(6);
			final String[] args08 = (String[]) PED_TotalizePerformanceReportBeanThread.argsList.get(7);
			final String[] args09 = (String[]) PED_TotalizePerformanceReportBeanThread.argsList.get(8);
			final String[] args10 = (String[]) PED_TotalizePerformanceReportBeanThread.argsList.get(9);

			errorNo = tmpUserSession.execStoredProcedure(tmpSQL, args01, args02, args03, args04, args05, args06, args07, args08, args09, args10, tmpLoginNo, tmpSessionNo);
			if (errorNo == -1) {
				val = "2";
			}
			tmpUserSession.createBatchStatus(tmpLoginNo, tmpEnqueteNo, tmpShubetsu, val);
			PED_TotalizePerformanceReportBeanThread.jotaiMap.put(tmpSessionNo, String.valueOf(errorNo));
			PED_TotalizePerformanceReportBeanThread.loginNo = null;
			PED_TotalizePerformanceReportBeanThread.enqueteNo = null;
			PED_TotalizePerformanceReportBeanThread.sessionNo = null;
			PED_TotalizePerformanceReportBeanThread.argsList = new ArrayList();
		} catch (final Exception e) {
			Log.error(PED_TotalizePerformanceReportBeanThread.loginNo, "HJE-0001", e);
			PED_TotalizePerformanceReportBeanThread.jotaiMap.put(tmpSessionNo, String.valueOf(errorNo));
			PED_TotalizePerformanceReportBeanThread.loginNo = null;
			PED_TotalizePerformanceReportBeanThread.enqueteNo = null;
			PED_TotalizePerformanceReportBeanThread.sessionNo = null;
			PED_TotalizePerformanceReportBeanThread.argsList = new ArrayList();
		} finally {
			try {
				ExclusiveManager.getInstance().releaseExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY);
			} catch (final Exception e) {
				Log.error(PED_TotalizePerformanceReportBeanThread.loginNo, "HJE-0001", e);
			}
		}
	}

	public void run() {
		PED_TotalizePerformanceReportBeanThread.main(null);
	}

	/** �Ď����J�n���� */
	public static void execute(final String tmpLoginNo, final String tmpSessionNo, final ArrayList args, final String tmpEnqueteNo, final PED_StoredProcedureUtilityEJB tmpUuserSession,
			final String tmpSql, final String tmpShubetsu) {
		PED_TotalizePerformanceReportBeanThread.loginNo = tmpLoginNo;
		PED_TotalizePerformanceReportBeanThread.sessionNo = tmpSessionNo;
		PED_TotalizePerformanceReportBeanThread.argsList = new ArrayList(args);
		PED_TotalizePerformanceReportBeanThread.enqueteNo = tmpEnqueteNo;
		PED_TotalizePerformanceReportBeanThread.userSession = tmpUuserSession;
		PED_TotalizePerformanceReportBeanThread.shubetsu = tmpShubetsu;
		PED_TotalizePerformanceReportBeanThread.sql = tmpSql;
		final Thread t = new PED_TotalizePerformanceReportBeanThread();
		t.start();
	}

	/**
	 * @return userSession ��߂��܂��B
	 */
	public static PED_StoredProcedureUtilityEJB getUserSession() {
		return PED_TotalizePerformanceReportBeanThread.userSession;
	}

	/**
	 * @param userSession �ݒ肷�� userSession�B
	 */
	public static void setUserSession(final PED_StoredProcedureUtilityEJB userSession) {
		PED_TotalizePerformanceReportBeanThread.userSession = userSession;
	}

	public static void removeJotaiFlg(final String sessionNo) {
		PED_TotalizePerformanceReportBeanThread.jotaiMap.remove(sessionNo);
	}

	public static String getJotaiFlg(final String sessionNo) {
		return (String) PED_TotalizePerformanceReportBeanThread.jotaiMap.get(sessionNo);
	}

	public static void setJotaiFlg(final String sessionNo, final String flg) {
		PED_TotalizePerformanceReportBeanThread.jotaiMap.put(sessionNo, flg);
	}
}
