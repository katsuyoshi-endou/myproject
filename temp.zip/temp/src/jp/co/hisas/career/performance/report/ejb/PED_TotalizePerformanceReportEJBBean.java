/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.report.ejb;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.performance.report.bean.PED_ReportShainValueBean;
import jp.co.hisas.career.performance.report.bean.PED_ReportSoshikiValueBean;
import jp.co.hisas.career.performance.report.bean.PED_TotalizePerformanceReportPDFThread;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �p�t�H�[�}���X�A���|�[�g�o�͂�DB�A�N�Z�X����
 * @author Kobayashi
 */
public class PED_TotalizePerformanceReportEJBBean implements SessionBean {

	/** SessionContext�I�u�W�F�N�g */
	private final SessionContext sesContext = null;

	/** Personal�e�[�u�� */
	private final String pTbl = HcdbDef.personalTbl;

	/** PRT_START���擾���邽�߂̕��� */
	private static final String PRT_START_BUNRUI = "Performance";

	/** PRT_START���擾���邽�߂�ID */
	private static final String PRT_START_ID = "Report_Output_Start";

	/** PRT_END���擾���邽�߂̕��� */
	private static final String PRT_END_BUNRUI = "Performance";

	/** PRT_END���擾���邽�߂�ID */
	private static final String PRT_END_ID = "Report_Output_End";

	/** PRT_START(��������) */
	private static final String PRT_START_ID_GROUP = "Report_GroupName_Start";

	/** PRT_START(��������) */
	private static final String PRT_END_ID_GROUP = "Report_GroupName_End";

	/** �p�����[�^���ށF�p�t�H�[�}���X */
	private final String PARAM_BUNRUI_NM = "Performance";

	/** �v���b�g�K�w */
	private final String PLOT_KAISO = "Prot_Kaiso";

	/** �����o�͊K�w */
	private final String SHIMEI_OUTPUT_KAISO = "Shimei_Output_Kaiso";

	/** �{���g�D */
	private final String HONMU_SOSHIKI = "HonmuSoshiki";

	/** �����g�D */
	private final String KENMU_SOSHIKI = "KenmuSoshiki";

	/** �{����E */
	private final String HONMU_YAKUSHOKU = "HonmuYakushoku";

	/** ������E */
	private final String KENMU_YAKUSHOKU = "KenmuYakushoku";

	/** �󔒃X�y�[�X */
	private static final String SPACE = "&nbsp;";

	/** �����̖����ɕt�����镶���� */
	private static final String SHOZOKU_END_STR1 = "*";

	private static final String SHOZOKU_END_STR2 = "��";

	private static final String SHOZOKU_END_STR3 = "��";

	/** �_�E�����[�h���[�N�^�C�v(�W�v) */
	private static final String TYPE_SHUKEI = "P13";

	/** �_�E�����[�h���[�N�^�C�v(���[�_�[�ݒ�) */
	private static final String TYPE_LEADER = "P11";

	/** �_�E�����[�h���[�N�^�C�v(���|�[�g�쐬) */
	private static final String TYPE_REPORT = "P15";

	/** �_�E�����[�h���[�N�^�C�v(�\�[�g�p) */
	private static final String TYPE_TMP = "51P";

	/** ���|�[�g��� */
	private final String REPORT_TYPE_WORD = "���|�[�g���:";

	/** �`�[���R���f�B�V�����}�b�v */
	private final String CM_WORD = "�`�[���R���f�B�V�����}�b�v";

	/** �r�W�l�X�}�C���h�}�b�v */
	private final String BM_WORD = "�r�W�l�X�}�C���h�}�b�v";

	/** ���[�_�V�b�v�����}�b�v */
	private final String RT_WORD = "���[�_�V�b�v�����}�b�v";

	/** ���W */
	private final String POINT_WORD = "���W:";

	/** �␳���O���X�g */
	private ArrayList CorrectionLog = new ArrayList();

	/** �d���`�F�b�N��l */

	/** �l��NULL�̏ꍇ�ɑ������l(�ʏ�W�v�ł͂��肦�Ȃ��l���i�[) */
	private final int NULL_EXCE_VALUE = 9999;

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException {/* �������܂��� */
	}

	public void setSessionContext(final SessionContext arg0) throws EJBException, RemoteException {/* �������܂��� */
	}

	/**
	 * �f�[�^�x�[�X�������s���A���ʂ��i�[�����z������^�[������B
	 * @param login_no ���O�C��NO
	 * @return �������ʊi�[�z��
	 * @exception SQLException SQL�G���[�����������ꍇ
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 */
	public Object execute(final String login_no) throws SQLException, NamingException {
		Log.method(login_no, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			dbConn = PZZ040_SQLUtility.getConnection(login_no);

			/* ��E�e�[�u�������� */
			/* ���R�[�h�������擾 */
			final String sql = "SELECT COUNT(*) AS cnt FROM " + this.pTbl + " WHERE SIMEI_NO=?";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, login_no);
			rs = pstmt.executeQuery();
			rs.next();
			final int tes = rs.getInt("cnt");
			Log.method(login_no, "OUT", "");
			return new Integer(tes);
		} catch (final SQLException sqle) {
			Log.error(login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * �����ꗗ�擾
	 * @param loginNo ����NO
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @return �����ꗗ
	 */
	public ArrayList getShozoku(final String loginNo, final String enqueteNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		final ArrayList soshikiList = new ArrayList();

		// PRT_START
		int prtStart = 0;
		// PRT_END
		int prtEnd = 0;
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// PRT_START�̎擾
			String sql = "SELECT " + HcdbDef.CCP_PARAM_COLUMNS[2] + " FROM " + HcdbDef.CCP_PARAM_TBL + " WHERE " + HcdbDef.CCP_PARAM_COLUMNS[0] + "=? AND " + HcdbDef.CCP_PARAM_COLUMNS[1] + "=?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, PED_TotalizePerformanceReportEJBBean.PRT_START_BUNRUI);
			pstmt.setString(2, PED_TotalizePerformanceReportEJBBean.PRT_START_ID);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				final String tmp = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
				if (tmp != null) {
					prtStart = new Integer(tmp.trim()).intValue();
				}
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
			// PRT_END�̎擾
			sql = "SELECT " + HcdbDef.CCP_PARAM_COLUMNS[2] + " FROM " + HcdbDef.CCP_PARAM_TBL + " WHERE " + HcdbDef.CCP_PARAM_COLUMNS[0] + "=? AND " + HcdbDef.CCP_PARAM_COLUMNS[1] + "=?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, PED_TotalizePerformanceReportEJBBean.PRT_END_BUNRUI);
			pstmt.setString(2, PED_TotalizePerformanceReportEJBBean.PRT_END_ID);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				final String tmp = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
				prtEnd = new Integer(tmp.trim()).intValue();
			}
			// ��U�J��
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			// �����K�w�擾����
			sql = "SELECT " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[6] + ", " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[3] + ", " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[2] + ", "
					+ HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[1] + " FROM ( SELECT * FROM " + HcdbDef.CPM_ENQUETE_SOSHIKI_TBL + " WHERE " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[0] + "=?) "
					+ " START WITH  " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[6] + " = '0'  " + " CONNECT BY PRIOR " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[2] + "="
					+ HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[5] + " ORDER SIBLINGS BY " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[2] + " ASC";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, enqueteNo);
			rs = pstmt.executeQuery();
			// ���|�[�g�o�͑Ώ�
			String record = null;
			while (rs.next()) {
				final String name = rs.getString(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[3]);
				final int kaiso = rs.getInt(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[6]);
				final String id = rs.getString(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[1]);
				final String code = rs.getString(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[2]);
				// �W�v�ς݂��`�F�b�N
				sql = "SELECT  cncnt+bmcnt+rtcnt+smcnt+mccnt cnt, rpcnt" + " FROM (" + "	SELECT COUNT(*) AS cncnt FROM " + HcdbDef.CPG_SOSHIKI_SUM_CONDITION_TBL + "	WHERE "
						+ HcdbDef.CPG_SOSHIKI_SUM_BUS_MIND_COLUMNS[0] + "=? AND " + HcdbDef.CPG_SOSHIKI_SUM_BUS_MIND_COLUMNS[1] + "=? " + " )," + "(" + "	SELECT COUNT(*) AS bmcnt FROM "
						+ HcdbDef.CPG_SOSHIKI_SUM_CONDITION_TBL + "	WHERE " + HcdbDef.CPG_SOSHIKI_SUM_CONDITION_COLUMNS[0] + "=? AND " + HcdbDef.CPG_SOSHIKI_SUM_CONDITION_COLUMNS[1] + "=? " + "), "
						+ "( " + "	SELECT COUNT(*) AS rtcnt FROM " + HcdbDef.CPG_SOSHIKI_SUM_LDR_TRAITS_TBL + "	WHERE " + HcdbDef.CPG_SOSHIKI_SUM_LDR_TRAITS_COLUMNS[0] + "=? AND "
						+ HcdbDef.CPG_SOSHIKI_SUM_LDR_TRAITS_COLUMNS[1] + "=? " + ")," + "( " + "	SELECT COUNT(*) AS rpcnt FROM " + HcdbDef.CPG_SOSHIKI_REPORT_TBL + "	WHERE "
						+ HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[0] + "=? AND " + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1] + "=? " + ")" + ",( SELECT COUNT(*) AS smcnt FROM " + HcdbDef.CPG_SOSHIKI_MANZOKU
						+ " WHERE " + HcdbDef.CPG_SOSHIKI_MANZOKU_COLUMNS[0] + " = ? AND " + HcdbDef.CPG_SOSHIKI_MANZOKU_COLUMNS[1] + " = ?)" + ",( SELECT COUNT(*) AS mccnt FROM "
						+ HcdbDef.CPG_SOSHIKI_METACONPITENCY + " WHERE " + HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[0] + " = ? AND " + HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[1] + " = ?)";

				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				pstmt.setString(1, enqueteNo);
				pstmt.setString(2, id);
				pstmt.setString(3, enqueteNo);
				pstmt.setString(4, id);
				pstmt.setString(5, enqueteNo);
				pstmt.setString(6, id);
				pstmt.setString(7, enqueteNo);
				pstmt.setString(8, code);
				pstmt.setString(9, enqueteNo);
				pstmt.setString(10, id);
				pstmt.setString(11, enqueteNo);
				pstmt.setString(12, id);
				rs2 = pstmt.executeQuery();
				boolean isShukeiZumi = false;
				boolean isReportZumi = false;

				if (rs2.next()) {

					final String cnt = rs2.getString("cnt");
					final String rpcnt = rs2.getString("rpcnt");

					isShukeiZumi = false;
					// ���|�[�g�쐬�ς�
					if (new Integer(rpcnt).intValue() > 0) {
						isReportZumi = true;
					}
					// �����ꂩ�Ƀ��R�[�h�����݂���ꍇ(�W�v�ς�)
					if (new Integer(cnt).intValue() > 0) {
						isShukeiZumi = true;
					}

				}
				String tmpSpace = "";
				for (int j = 0; j < kaiso - 1; j++) {
					tmpSpace += PED_TotalizePerformanceReportEJBBean.SPACE;
				}
				if (isReportZumi) {
					record = tmpSpace + name + PED_TotalizePerformanceReportEJBBean.SHOZOKU_END_STR3;
				} else if (prtStart <= kaiso && kaiso <= prtEnd && !isShukeiZumi) {
					record = tmpSpace + name + PED_TotalizePerformanceReportEJBBean.SHOZOKU_END_STR1;
				} else if (isShukeiZumi && !isReportZumi) {
					record = tmpSpace + name + PED_TotalizePerformanceReportEJBBean.SHOZOKU_END_STR2;
				} else {
					record = tmpSpace + name;
				}
				final HashMap map = new HashMap();
				map.put("id", id);
				map.put("name", record);
				soshikiList.add(map);
				PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs2);
			}

			Log.method(loginNo, "OUT", "");
			return soshikiList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, null, null, rs2);
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �g�D�R�[�h�Ń\�[�g
	 * @param loginNo ���O�C���ԍ�
	 * @param �I�������g�DID
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @return �g�D�R�[�h�Ń\�[�g���ꂽ�g�DID
	 */
	public ArrayList getShozokuSort(final String loginNo, final ArrayList choiceSoshikiID, final String enqueteNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		final ArrayList soshikiList = new ArrayList();

		// PRT_START
		int prtStart = 0;
		// PRT_END
		int prtEnd = 0;
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// PRT_START�̎擾
			String sql = "SELECT " + HcdbDef.CCP_PARAM_COLUMNS[2] + " FROM " + HcdbDef.CCP_PARAM_TBL + " WHERE " + HcdbDef.CCP_PARAM_COLUMNS[0] + "=? AND " + HcdbDef.CCP_PARAM_COLUMNS[1] + "=?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, PED_TotalizePerformanceReportEJBBean.PRT_START_BUNRUI);
			pstmt.setString(2, PED_TotalizePerformanceReportEJBBean.PRT_START_ID);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				final String tmp = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
				if (tmp != null) {
					prtStart = new Integer(tmp.trim()).intValue();
				}
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
			// PRT_END�̎擾
			sql = "SELECT " + HcdbDef.CCP_PARAM_COLUMNS[2] + " FROM " + HcdbDef.CCP_PARAM_TBL + " WHERE " + HcdbDef.CCP_PARAM_COLUMNS[0] + "=? AND " + HcdbDef.CCP_PARAM_COLUMNS[1] + "=?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, PED_TotalizePerformanceReportEJBBean.PRT_END_BUNRUI);
			pstmt.setString(2, PED_TotalizePerformanceReportEJBBean.PRT_END_ID);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				final String tmp = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
				prtEnd = new Integer(tmp.trim()).intValue();
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			sql = "SELECT " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[1] + "," + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[3] + "," + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[6] + " FROM "
					+ HcdbDef.CPM_ENQUETE_SOSHIKI_TBL + " WHERE " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[0] + " =? AND " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[1] + " IN( ";
			if (choiceSoshikiID.size() > 0) {

				sql += "?";
				for (int i = 1, num = choiceSoshikiID.size(); i < num; i++) {
					sql += ",?";
				}
				sql += ") ORDER BY " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[2] + " ASC";

				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				pstmt.setString(1, enqueteNo);
				for (int i = 0, num = choiceSoshikiID.size(); i < num; i++) {
					pstmt.setString(i + 2, (String) choiceSoshikiID.get(i));
				}
				rs = pstmt.executeQuery();
				while (rs.next()) {

					final String tmp = rs.getString(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[1]);
					final String name = rs.getString(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[3]);
					final int kaiso = rs.getInt(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[6]);

					if (prtStart <= kaiso && kaiso <= prtEnd) {
						final HashMap map = new HashMap();
						map.put("id", tmp);
						map.put("name", name);
						soshikiList.add(map);
					}
				}
			}

			Log.method(loginNo, "OUT", "");
			return soshikiList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �A���P�[�g�ԍ����w�肵�āA��Ԏ擾
	 * @param loginNo ���O�C���ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @param sessionNo �Z�b�V�����ԍ�
	 * @return ���
	 */
	public HashMap getEnqueteStatus(final String loginNo, final String enqueteNo, final String sessionNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			final HashMap map = new HashMap();
			String sql = "SELECT " + HcdbDef.CPM_ENQUETE_TBL + "." + HcdbDef.CPM_ENQUETE_COLUMNS[0] + " No, " + HcdbDef.CPM_ENQUETE_TBL + "." + HcdbDef.CPM_ENQUETE_COLUMNS[7] + " StatusNo, "
					+ HcdbDef.CPM_STATUS_TBL + "1." + HcdbDef.CPM_STATUS_COLUMNS[2] + " StatusName," + HcdbDef.CPM_ENQUETE_TBL + "." + HcdbDef.CPM_ENQUETE_COLUMNS[11] + " ShukeiChkStatusNo, "
					+ HcdbDef.CPM_STATUS_TBL + "2." + HcdbDef.CPM_STATUS_COLUMNS[2] + " ShukeiChkStatusName" + " FROM " + HcdbDef.CPM_ENQUETE_TBL + "," + " (SELECT * FROM " + HcdbDef.CPM_STATUS_TBL
					+ " WHERE " + HcdbDef.CPM_STATUS_COLUMNS[0] + " = ?) " + HcdbDef.CPM_STATUS_TBL + "1," + " (SELECT * FROM " + HcdbDef.CPM_STATUS_TBL + " WHERE " + HcdbDef.CPM_STATUS_COLUMNS[0]
					+ " = ?) " + HcdbDef.CPM_STATUS_TBL + "2" + " WHERE " + HcdbDef.CPM_ENQUETE_TBL + "." + HcdbDef.CPM_ENQUETE_COLUMNS[0] + " = ?" + " AND " + HcdbDef.CPM_STATUS_TBL + "1."
					+ HcdbDef.CPM_STATUS_COLUMNS[1] + " = " + HcdbDef.CPM_ENQUETE_TBL + "." + HcdbDef.CPM_ENQUETE_COLUMNS[7] + " AND " + HcdbDef.CPM_STATUS_TBL + "2." + HcdbDef.CPM_STATUS_COLUMNS[1]
					+ " = " + HcdbDef.CPM_ENQUETE_TBL + "." + HcdbDef.CPM_ENQUETE_COLUMNS[11];

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, "01");
			pstmt.setString(2, "03");
			pstmt.setString(3, enqueteNo);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				final String eNo = rs.getString("No");
				final String eStatusNo = rs.getString("StatusNo");
				final String eStatusName = rs.getString("StatusName");
				final String eShukeiChkStatusNo = rs.getString("ShukeiChkStatusNo");
				final String eShukeiChkStatusName = rs.getString("ShukeiChkStatusName");

				map.put("enqueteNo", eNo);
				map.put("shukeiStatus", eStatusName);
				map.put("errorCheckStatus", eShukeiChkStatusName);
				map.put("errorCheckStatusNo", eShukeiChkStatusNo);

				rs.close();
				pstmt.close();
				sql = "SELECT COUNT(*)CNT FROM " + HcdbDef.CPM_ENQUETE_LEADER_TBL + " WHERE " + HcdbDef.CPM_ENQUETE_LEADER_COLUMNS[0] + " = ?";
				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				pstmt.setString(1, enqueteNo);
				rs = pstmt.executeQuery();
				rs.next();
				final String lCnt = rs.getString("CNT");
				if (!lCnt.equals("0")) {
					map.put("preLeaderErrorFlg", new Boolean(true));
					map.put("leaderErrorFlg", new Boolean(this.isBatchError(enqueteNo, loginNo, PED_TotalizePerformanceReportEJBBean.TYPE_LEADER, sessionNo)));
				} else {
					map.put("preLeaderErrorFlg", new Boolean(false));
				}

				// �W�v�G���[�`�F�b�N
				if (eStatusNo.equals("3") || eStatusNo.equals("4")) {
					map.put("preShukeiErrorFlg", new Boolean(true));
					map.put("shukeiErrorFlg", new Boolean(this.isBatchError(enqueteNo, loginNo, PED_TotalizePerformanceReportEJBBean.TYPE_SHUKEI, sessionNo)));
				} else {
					map.put("preShukeiErrorFlg", new Boolean(false));
				}

			}

			Log.method(loginNo, "OUT", "");
			return map;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * ��ʂ��w�肵��CSV�_�E�����[�h�̕\�������l�����߂�
	 * @param loginNo ���O�C���ԍ�
	 * @param type ���
	 * @return boolean
	 */
	public boolean isBatchError(final String enqueteNo, final String loginNo, final String type, final String sessionID) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			final String sql = "SELECT COUNT(*) AS cnt " + " FROM " + HcdbDef.CPP_TEXT_OUTPUT_TBL + " WHERE " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[0] + "=? AND " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[1]
					+ "=? AND " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[4] + "=?";

			/* DB�ڑ��I�u�W�F�N�g�̊l�� */
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();

			/* �p�����[�^��ݒ� */
			pstmt.setString(1, sessionID);
			pstmt.setString(2, type);
			pstmt.setString(3, enqueteNo);
			/* SQL�R�}���h�����s */
			rs = pstmt.executeQuery();

			int cnt = 0;
			if (rs.next()) {
				cnt = rs.getInt("cnt");
			}
			if (cnt != 0) {
				return true;
			}

			Log.method(loginNo, "OUT", "");
			return false;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �`�[���R���f�B�V�����}�b�v�o�c�e�̕\���f�[�^���擾����
	 * @param loginNo ���O�C���ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @param groupID �g�D�h�c
	 * @return �`�[���R���f�B�V�����}�b�v�o�c�e�\���f�[�^
	 */
	public HashMap getConditionMapData(final String loginNo, final String enqueteNo, final ArrayList groupIDList, final HashMap grpMap) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �擾ID��
			String groupIDps = "";
			for (int pCnt = 0; pCnt < groupIDList.size(); pCnt++) {
				if (pCnt != 0) {
					groupIDps += ", ";
				}
				groupIDps += "?";
			}

			// �ėp�p�����[�^�擾SQL
			String sql = " SELECT ";
			for (int colCnt = 0; colCnt < HcdbDef.CPG_SOSHIKI_SUM_CONDITION_COLUMNS.length; colCnt++) {
				sql += "CM." + HcdbDef.CPG_SOSHIKI_SUM_CONDITION_COLUMNS[colCnt];
				sql += ", ";
			}
			sql += "TYPE." + HcdbDef.CPM_TEAM_COND_SOSHIKI_TYPE_COLUMNS[4];
			sql += " FROM ";
			sql += HcdbDef.CPG_SOSHIKI_SUM_CONDITION_TBL + " CM , ";
			sql += HcdbDef.CPM_TEAM_COND_SOSHIKI_TYPE_TBL + " TYPE ";
			sql += " WHERE ";
			sql += "CM." + HcdbDef.CPG_SOSHIKI_SUM_CONDITION_COLUMNS[0] + " = ? ";
			sql += " AND ";
			sql += "CM." + HcdbDef.CPG_SOSHIKI_SUM_CONDITION_COLUMNS[1] + " IN (" + groupIDps + ") ";
			sql += " AND ";
			sql += "CM." + HcdbDef.CPG_SOSHIKI_SUM_CONDITION_COLUMNS[16] + " = " + "TYPE." + HcdbDef.CPM_TEAM_COND_SOSHIKI_TYPE_COLUMNS[3] + "(+)";

			// �Z�b�g�ʒu
			int setCnt = 1;

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			// �A���P�[�g�ԍ�
			pstmt.setString(setCnt, enqueteNo);
			setCnt++;
			for (int pCnt = 0; pCnt < groupIDList.size(); pCnt++) {
				// �g�D�h�c
				final HashMap groupMap = (HashMap) groupIDList.get(pCnt);
				final String groupIDKey = (String) groupMap.get("id");
				pstmt.setString(setCnt, groupIDKey);
				setCnt++;
			}

			rs = pstmt.executeQuery();
			while (rs.next()) {
				// ����
				final ArrayList resultList = new ArrayList();

				for (int colCnt = 0; colCnt < HcdbDef.CPG_SOSHIKI_SUM_CONDITION_COLUMNS.length; colCnt++) {
					// ������Ŏ擾
					String resultStr = rs.getString(HcdbDef.CPG_SOSHIKI_SUM_CONDITION_COLUMNS[colCnt]);
					resultStr = resultStr != null ? resultStr : "";

					resultList.add(resultStr);
				}
				{
					// ������Ŏ擾
					String resultStr = rs.getString(HcdbDef.CPM_TEAM_COND_SOSHIKI_TYPE_COLUMNS[4]);
					resultStr = resultStr != null ? resultStr : "";

					resultList.add(resultStr);
				}

				// �z��ɕϊ�
				final String[] groupData = (String[]) resultList.toArray(new String[0]);

				PED_ReportSoshikiValueBean soshikiBean = new PED_ReportSoshikiValueBean();
				if (grpMap.containsKey(groupData[1])) {
					soshikiBean = (PED_ReportSoshikiValueBean) grpMap.get(groupData[1]);
				}

				// ���̃Z�b�g
				soshikiBean.getTeamCondition().setLeaderAvgChitekinoryoku(groupData[2]);
				soshikiBean.getTeamCondition().setLeaderAvgWorkingmotivation(groupData[3]);
				soshikiBean.getTeamCondition().setLeaderSu(groupData[4]);
				soshikiBean.getTeamCondition().setLeaderAvgPerformance(groupData[5]);
				soshikiBean.getTeamCondition().setMemberAvgChitekinoryoku(groupData[6]);
				soshikiBean.getTeamCondition().setMemberAvgWorkingMotivation(groupData[7]);
				soshikiBean.getTeamCondition().setMemberSu(groupData[8]);
				soshikiBean.getTeamCondition().setMemberAvgPerformance(groupData[9]);
				soshikiBean.getTeamCondition().setSoshikiAvgChitekinoryoku(groupData[10]);
				soshikiBean.getTeamCondition().setSoshikiHyojunChitekinoryoku(groupData[11]);
				soshikiBean.getTeamCondition().setSoshikiAvgWorkingMotivation(groupData[12]);
				soshikiBean.getTeamCondition().setSoshikiHyojunWorkingMtv(groupData[13]);
				soshikiBean.getTeamCondition().setSoshikiSu(groupData[14]);
				soshikiBean.getTeamCondition().setSoshikiSanpu(groupData[15]);
				soshikiBean.getTeamCondition().setSoshikiType(groupData[16]);
				soshikiBean.getTeamCondition().setTeamConditionZoneARate(!groupData[17].equals("") ? groupData[17] : "0");
				soshikiBean.getTeamCondition().setTeamConditionZoneASu(!groupData[18].equals("") ? groupData[18] : "0");
				soshikiBean.getTeamCondition().setTeamConditionZoneBRate(!groupData[19].equals("") ? groupData[19] : "0");
				soshikiBean.getTeamCondition().setTeamConditionZoneBSu(!groupData[20].equals("") ? groupData[20] : "0");
				soshikiBean.getTeamCondition().setTeamConditionZoneCRate(!groupData[21].equals("") ? groupData[21] : "0");
				soshikiBean.getTeamCondition().setTeamConditionZoneCSu(!groupData[22].equals("") ? groupData[22] : "0");
				soshikiBean.getTeamCondition().setTeamConditionZoneDRate(!groupData[23].equals("") ? groupData[23] : "0");
				soshikiBean.getTeamCondition().setTeamConditionZoneDSu(!groupData[24].equals("") ? groupData[24] : "0");
				soshikiBean.getTeamCondition().setSetsumei(groupData[25]);

				// �g�D�h�c���L�[�Ɋi�[
				grpMap.put(groupData[1], soshikiBean);
			}

			Log.method(loginNo, "OUT", "");
			return grpMap;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �r�W�l�X�}�C���h�}�b�v�o�c�e�̕\���f�[�^���擾����
	 * @param loginNo ���O�C���ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @param groupID �g�D�h�c
	 * @return �r�W�l�X�}�C���h�}�b�v�o�c�e�\���f�[�^
	 */
	public HashMap getBusinessMindMap(final String loginNo, final String enqueteNo, final ArrayList groupIDList, final HashMap grpMap) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �擾ID��
			String groupIDps = "";
			for (int pCnt = 0; pCnt < groupIDList.size(); pCnt++) {
				if (pCnt != 0) {
					groupIDps += ", ";
				}
				groupIDps += "?";
			}

			// �ėp�p�����[�^�擾SQL
			String sql = " SELECT ";
			for (int colCnt = 0; colCnt < HcdbDef.CPG_SOSHIKI_SUM_BUS_MIND_COLUMNS.length; colCnt++) {
				sql += "BM." + HcdbDef.CPG_SOSHIKI_SUM_BUS_MIND_COLUMNS[colCnt];
				sql += ", ";
			}
			sql += "TYPE." + HcdbDef.CPM_BUS_MIND_SOSHIKI_TYPE_COLUMNS[2];
			sql += " FROM ";
			sql += HcdbDef.CPG_SOSHIKI_SUM_BUS_MIND_TBL + " BM , ";
			sql += HcdbDef.CPM_BUS_MIND_SOSHIKI_TYPE_TBL + " TYPE ";
			sql += " WHERE ";
			sql += "BM." + HcdbDef.CPG_SOSHIKI_SUM_BUS_MIND_COLUMNS[0] + " = ? ";
			sql += " AND ";
			sql += "BM." + HcdbDef.CPG_SOSHIKI_SUM_BUS_MIND_COLUMNS[1] + " IN (" + groupIDps + ") ";
			sql += " AND ";
			sql += "BM." + HcdbDef.CPG_SOSHIKI_SUM_BUS_MIND_COLUMNS[10] + " = " + "TYPE." + HcdbDef.CPM_BUS_MIND_SOSHIKI_TYPE_COLUMNS[1] + "(+)";

			// �Z�b�g�ʒu
			int setCnt = 1;

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			// �A���P�[�g�ԍ�
			pstmt.setString(setCnt, enqueteNo);
			setCnt++;
			for (int pCnt = 0; pCnt < groupIDList.size(); pCnt++) {
				// �g�D�h�c
				final HashMap groupMap = (HashMap) groupIDList.get(pCnt);
				final String groupIDKey = (String) groupMap.get("id");
				pstmt.setString(setCnt, groupIDKey);
				setCnt++;
			}

			rs = pstmt.executeQuery();
			while (rs.next()) {
				// ����
				final ArrayList resultList = new ArrayList();

				for (int colCnt = 0; colCnt < HcdbDef.CPG_SOSHIKI_SUM_BUS_MIND_COLUMNS.length; colCnt++) {
					// ������Ŏ擾
					String resultStr = rs.getString(HcdbDef.CPG_SOSHIKI_SUM_BUS_MIND_COLUMNS[colCnt]);
					resultStr = resultStr != null ? resultStr : "";

					resultList.add(resultStr);
				}
				{
					// ������Ŏ擾
					String resultStr = rs.getString(HcdbDef.CPM_BUS_MIND_SOSHIKI_TYPE_COLUMNS[2]);
					resultStr = resultStr != null ? resultStr : "";

					resultList.add(resultStr);
				}

				// �z��ɕϊ�
				final String[] groupData = (String[]) resultList.toArray(new String[0]);

				PED_ReportSoshikiValueBean soshikiBean = new PED_ReportSoshikiValueBean();
				if (grpMap.containsKey(groupData[1])) {
					soshikiBean = (PED_ReportSoshikiValueBean) grpMap.get(groupData[1]);
				}

				// ���̃Z�b�g
				soshikiBean.getBusinessMind().setKojinSeichoTypeRate(!groupData[2].equals("") ? groupData[2] : "0");
				soshikiBean.getBusinessMind().setKojinSeichoTypeSu(!groupData[3].equals("") ? groupData[3] : "0");
				soshikiBean.getBusinessMind().setKojinAnteiTypeRate(!groupData[4].equals("") ? groupData[4] : "0");
				soshikiBean.getBusinessMind().setKojinAnteiTypeSu(!groupData[5].equals("") ? groupData[5] : "0");
				soshikiBean.getBusinessMind().setSoshikiSeichoTypeRate(!groupData[6].equals("") ? groupData[6] : "0");
				soshikiBean.getBusinessMind().setSoshikiSeichoTypeSu(!groupData[7].equals("") ? groupData[7] : "0");
				soshikiBean.getBusinessMind().setSoshikiAnteiTypeRate(!groupData[8].equals("") ? groupData[8] : "0");
				soshikiBean.getBusinessMind().setSoshikiAnteiTypeSu(!groupData[9].equals("") ? groupData[9] : "0");
				soshikiBean.getBusinessMind().setSoshikiType(!groupData[10].equals("") ? groupData[10] : "0");
				soshikiBean.getBusinessMind().setSoshikiSu(!groupData[11].equals("") ? groupData[11] : "0");
				soshikiBean.getBusinessMind().setSetsumei(groupData[12]);

				// �g�D�h�c���L�[�Ɋi�[
				grpMap.put(groupData[1], soshikiBean);
			}

			Log.method(loginNo, "OUT", "");
			return grpMap;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * ���[�_�[�V�b�v�����o�c�e�̕\���f�[�^���擾����
	 * @param loginNo ���O�C���ԍ�
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @param groupID �g�D�h�c
	 * @return ���[�_�[�V�b�v�����o�c�e�\���f�[�^
	 */
	public HashMap getLeadershipTraitsMap(final String loginNo, final String enqueteNo, final ArrayList groupIDList, final HashMap grpMap) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �擾ID��
			String groupIDps = "";
			for (int pCnt = 0; pCnt < groupIDList.size(); pCnt++) {
				if (pCnt != 0) {
					groupIDps += ", ";
				}
				groupIDps += "?";
			}

			// �ėp�p�����[�^�擾SQL
			String sql = " SELECT ";
			for (int colCnt = 0; colCnt < HcdbDef.CPG_SOSHIKI_SUM_LDR_TRAITS_COLUMNS.length; colCnt++) {
				sql += HcdbDef.CPG_SOSHIKI_SUM_LDR_TRAITS_COLUMNS[colCnt];
				if (colCnt < HcdbDef.CPG_SOSHIKI_SUM_LDR_TRAITS_COLUMNS.length - 1) {
					sql += ",";
				}
				sql += " ";
			}
			sql += " FROM ";
			sql += HcdbDef.CPG_SOSHIKI_SUM_LDR_TRAITS_TBL + " ";
			sql += " WHERE ";
			sql += HcdbDef.CPG_SOSHIKI_SUM_LDR_TRAITS_COLUMNS[0] + " = ? ";
			sql += " AND ";
			sql += HcdbDef.CPG_SOSHIKI_SUM_LDR_TRAITS_COLUMNS[1] + " IN (" + groupIDps + ") ";

			// �Z�b�g�ʒu
			int setCnt = 1;

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			// �A���P�[�g�ԍ�
			pstmt.setString(setCnt, enqueteNo);
			setCnt++;
			for (int pCnt = 0; pCnt < groupIDList.size(); pCnt++) {
				// �g�D�h�c
				final HashMap groupMap = (HashMap) groupIDList.get(pCnt);
				final String groupIDKey = (String) groupMap.get("id");
				pstmt.setString(setCnt, groupIDKey);
				setCnt++;
			}

			rs = pstmt.executeQuery();
			while (rs.next()) {
				// ����
				final ArrayList resultList = new ArrayList();

				for (int colCnt = 0; colCnt < HcdbDef.CPG_SOSHIKI_SUM_LDR_TRAITS_COLUMNS.length; colCnt++) {
					// ������Ŏ擾
					String resultStr = rs.getString(HcdbDef.CPG_SOSHIKI_SUM_LDR_TRAITS_COLUMNS[colCnt]);
					resultStr = resultStr != null ? resultStr : "";

					resultList.add(resultStr);
				}

				// �z��ɕϊ�
				final String[] groupData = (String[]) resultList.toArray(new String[0]);

				PED_ReportSoshikiValueBean soshikiBean = new PED_ReportSoshikiValueBean();
				if (grpMap.containsKey(groupData[1])) {
					soshikiBean = (PED_ReportSoshikiValueBean) grpMap.get(groupData[1]);
				}

				// ���̃Z�b�g
				soshikiBean.getLeaderTraits().setLeadershipZoneARate(!"".equals(groupData[2]) ? groupData[2] : "0");
				soshikiBean.getLeaderTraits().setLeadershipZoneASu(!"".equals(groupData[3]) ? groupData[3] : "0");
				soshikiBean.getLeaderTraits().setLeadershipZoneBRate(!"".equals(groupData[4]) ? groupData[4] : "0");
				soshikiBean.getLeaderTraits().setLeadershipZoneBSu(!"".equals(groupData[5]) ? groupData[5] : "0");
				soshikiBean.getLeaderTraits().setLeadershipZoneCRate(!"".equals(groupData[6]) ? groupData[6] : "0");
				soshikiBean.getLeaderTraits().setLeadershipZoneCSu(!"".equals(groupData[7]) ? groupData[7] : "0");
				soshikiBean.getLeaderTraits().setLeadershipZoneDRate(!"".equals(groupData[8]) ? groupData[8] : "0");
				soshikiBean.getLeaderTraits().setLeadershipZoneDSu(!"".equals(groupData[9]) ? groupData[9] : "0");
				soshikiBean.getLeaderTraits().setLeadershipZoneERate(!"".equals(groupData[10]) ? groupData[10] : "0");
				soshikiBean.getLeaderTraits().setLeadershipZoneESu(!"".equals(groupData[11]) ? groupData[11] : "0");
				soshikiBean.getLeaderTraits().setSoshikiSu(!"".equals(groupData[12]) ? groupData[12] : "0");

				// �g�D�h�c���L�[�Ɋi�[
				grpMap.put(groupData[1], soshikiBean);

			}

			Log.method(loginNo, "OUT", "");
			return grpMap;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �g�D�����x����PDF�̕\���f�[�^���擾����
	 * @param loginNo
	 * @param enquete_no
	 * @param groupIDList
	 * @param grpMap
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 */
	public HashMap getSoshikiManzoku(final String loginNo, final String enquete_no, final ArrayList groupIDList, final HashMap grpMap) throws SQLException, NamingException {
		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �擾ID��
			String groupIDps = "";
			for (int pCnt = 0; pCnt < groupIDList.size(); pCnt++) {
				if (pCnt != 0) {
					groupIDps += ", ";
				}
				groupIDps += "?";
			}

			// ��Е��ώ擾
			final ArrayList kaishaAvg = new ArrayList();

			String sql = "SELECT * " + " FROM " + HcdbDef.CPG_KAISYA_HEIKIN + " WHERE " + HcdbDef.CPG_KAISHA_HEIKIN_COLUMNS[0] + " = ? ";
			pstmt = dbConn.prepareStatement(sql);

			pstmt.setString(1, enquete_no);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				for (int i = 13; i < HcdbDef.CPG_KAISHA_HEIKIN_COLUMNS.length; i++) {
					kaishaAvg.add(rs.getString(HcdbDef.CPG_KAISHA_HEIKIN_COLUMNS[i]));
				}
			}

			/* close */
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			// �g�D�i�ʁj���ώ擾
			sql = "SELECT * " + " FROM " + HcdbDef.CPG_SOSHIKI_MANZOKU + " WHERE " + HcdbDef.CPG_SOSHIKI_MANZOKU_COLUMNS[0] + " = ? AND " + HcdbDef.CPG_SOSHIKI_MANZOKU_COLUMNS[1] + " IN ("
					+ groupIDps + ") " + " ORDER BY " + HcdbDef.CPG_SOSHIKI_MANZOKU_COLUMNS[1] + "," + HcdbDef.CPG_SOSHIKI_MANZOKU_COLUMNS[2];

			pstmt = dbConn.prepareStatement(sql);
			/** �Z�b�g�ʒu */
			int setCnt = 1;
			pstmt.setString(setCnt, enquete_no);
			setCnt++;
			for (int pCnt = 0; pCnt < groupIDList.size(); pCnt++) {
				// �g�D�h�c
				final HashMap groupMap = (HashMap) groupIDList.get(pCnt);
				final String groupIDKey = (String) groupMap.get("id");
				pstmt.setString(setCnt, groupIDKey);
				setCnt++;
			}
			rs = pstmt.executeQuery();

			while (rs.next()) {
				final int kaiso = rs.getInt(HcdbDef.CPG_SOSHIKI_MANZOKU_COLUMNS[2]);
				final String grpID = rs.getString(HcdbDef.CPG_SOSHIKI_MANZOKU_COLUMNS[1]);

				PED_ReportSoshikiValueBean soshikiBean = new PED_ReportSoshikiValueBean();
				if (grpMap.containsKey(grpID)) {
					soshikiBean = (PED_ReportSoshikiValueBean) grpMap.get(grpID);
				}
				final ArrayList soshikiAvg = new ArrayList();
				for (int i = 3; i < HcdbDef.CPG_SOSHIKI_MANZOKU_COLUMNS.length; i++) {
					soshikiAvg.add(rs.getString(HcdbDef.CPG_SOSHIKI_MANZOKU_COLUMNS[i]));
				}
				switch (kaiso) {
				case 0:
					soshikiBean.getSoshikiManzoku().setSoshikiAvg(soshikiAvg);
					soshikiBean.getSoshikiManzoku().setSosikiSu((String) soshikiAvg.get(soshikiAvg.size() - 1));
					break;
				case 1:
					soshikiBean.getSoshikiManzoku().setKaiso1Avg(soshikiAvg);
					break;
				case 2:
					soshikiBean.getSoshikiManzoku().setKaiso2Avg(soshikiAvg);
					break;
				case 3:
					soshikiBean.getSoshikiManzoku().setKaiso3Avg(soshikiAvg);
					break;
				case 4:
					soshikiBean.getSoshikiManzoku().setKaiso4Avg(soshikiAvg);
					break;
				case 5:
					soshikiBean.getSoshikiManzoku().setKaiso5Avg(soshikiAvg);
					break;
				case 6:
					soshikiBean.getSoshikiManzoku().setKaiso6Avg(soshikiAvg);
					break;
				}
				soshikiBean.getSoshikiManzoku().setKaishaAvg(kaishaAvg);
				grpMap.put(grpID, soshikiBean);
			}

			return grpMap;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �g�D�̃��^�R���s�e���V�[
	 * @param loginNo
	 * @param enquete_no
	 * @param groupIDList
	 * @param grpMap
	 * @param sessionId
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 */
	public HashMap getMetaCompetency(final String loginNo, final String enquete_no, final ArrayList groupIDList, final HashMap grpMap, final String sessionId) throws SQLException, NamingException {
		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		this.CorrectionLog = new ArrayList();

		try {

			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �擾ID��
			String groupIDps = "";
			for (int pCnt = 0; pCnt < groupIDList.size(); pCnt++) {
				if (pCnt != 0) {
					groupIDps += ", ";
				}
				groupIDps += "?";
			}

			final String sql = "SELECT * " + " FROM " + HcdbDef.CPG_SOSHIKI_METACONPITENCY + " WHERE " + HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[0] + " = ? " + " AND "
					+ HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[1] + " IN (" + groupIDps + ")" + " ORDER BY " + HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[1];

			pstmt = dbConn.prepareStatement(sql);
			/** �Z�b�g�ʒu */
			int setCnt = 1;
			pstmt.setString(setCnt, enquete_no);
			setCnt++;
			for (int pCnt = 0; pCnt < groupIDList.size(); pCnt++) {
				// �g�D�h�c
				final HashMap groupMap = (HashMap) groupIDList.get(pCnt);
				final String groupIDKey = (String) groupMap.get("id");
				pstmt.setString(setCnt, groupIDKey);
				setCnt++;
			}
			rs = pstmt.executeQuery();

			while (rs.next()) {
				final String grpID = rs.getString(HcdbDef.CPG_SOSHIKI_MANZOKU_COLUMNS[1]);

				PED_ReportSoshikiValueBean soshikiBean = new PED_ReportSoshikiValueBean();
				if (grpMap.containsKey(grpID)) {
					soshikiBean = (PED_ReportSoshikiValueBean) grpMap.get(grpID);
				}
				soshikiBean.getMetaCompetency().setSoshikiSu(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[18]));
				// �e�l��␳���i�[
				soshikiBean.getMetaCompetency().setTassei(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[2]), "CPM-VED150-E044", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[2]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setSekkyokusei(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[3]), "CPM-VED150-E045", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[3]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setPassion(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[4]), "CPM-VED150-E046", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[4]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setSelfControl(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[5]), "CPM-VED150-E047", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[5]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setJisin(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[6]), "CPM-VED150-E048", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[6]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setTaijinEikyoryoku(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[7]), "CPM-VED150-E049", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[7]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setTeamWork(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[8]), "CPM-VED150-E050", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[8]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setIkusei(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[9]), "CPM-VED150-E051", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[9]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setTaijinRikai(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[10]), "CPM-VED150-E052", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[10]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setKokensei(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[11]), "CPM-VED150-E053", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[11]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setRiskTake(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[12]), "CPM-VED150-E054", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[12]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setKadaiKotikuryoku(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[13]), "CPM-VED150-E055", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[13]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setKetudanryoku(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[14]), "CPM-VED150-E056", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[14]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setBunsekiryoku(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[15]), "CPM-VED150-E057", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[15]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setJokyoTaiouryoku(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[16]), "CPM-VED150-E058", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[16]) }, enquete_no, loginNo));
				soshikiBean.getMetaCompetency().setJokyoRikairyoku(
						this.valueCorrection(rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[17]), "CPM-VED150-E059", new String[] {
								grpID,
								"",
								rs.getString(HcdbDef.CPG_SOSHIKI_METACONPITENCY_COLUMNS[17]) }, enquete_no, loginNo));
				grpMap.put(grpID, soshikiBean);
			}
			PED_TotalizePerformanceReportPDFThread.setLogMsgList2(sessionId, this.CorrectionLog);
			return grpMap;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * PDF�o�̓t���O�𓾂� �L�[�F�J������
	 * @param loginNo
	 * @param enquete_no
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 */
	public HashMap getPdfOutputFlg(final String loginNo, final String enquete_no) throws SQLException, NamingException {
		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		final HashMap result = new HashMap();

		try {

			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			final String sql = "SELECT * FROM " + HcdbDef.CPM_ENQUETE_TBL + " WHERE " + HcdbDef.CPM_ENQUETE_COLUMNS[0] + " = ?";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.setString(1, enquete_no);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				result.put(HcdbDef.CPM_ENQUETE_COLUMNS[12], rs.getString(HcdbDef.CPM_ENQUETE_COLUMNS[12]));
				result.put(HcdbDef.CPM_ENQUETE_COLUMNS[13], rs.getString(HcdbDef.CPM_ENQUETE_COLUMNS[13]));
				result.put(HcdbDef.CPM_ENQUETE_COLUMNS[14], rs.getString(HcdbDef.CPM_ENQUETE_COLUMNS[14]));
				result.put(HcdbDef.CPM_ENQUETE_COLUMNS[15], rs.getString(HcdbDef.CPM_ENQUETE_COLUMNS[15]));
				result.put(HcdbDef.CPM_ENQUETE_COLUMNS[16], rs.getString(HcdbDef.CPM_ENQUETE_COLUMNS[16]));
			}
			return result;

		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * 3�ȏ��3�ɁA-3�ȉ���-3�ɕ␳���ĕԂ��B
	 * @param value
	 * @param msgID
	 * @param args
	 * @param enquteNo
	 * @param loginNo
	 * @param sessionId
	 * @return
	 * @throws NamingException
	 * @throws SQLException
	 */
	private float valueCorrection(final String value, final String msgID, final String[] args, final String enquteNo, final String loginNo) throws SQLException, NamingException {
		float retValue = 0f;
		try {
			retValue = Float.parseFloat(value);
		} catch (final Exception e) {
			retValue = -3f;
		}
		final float bValue = retValue;
		// �␳
		if (retValue > 3f) {
			retValue = 3f;
		} else if (retValue < -3f) {
			retValue = -3f;
		}
		if (retValue != bValue) {
			final HashMap msgMap = ReadFile.getMsgMapData((String) ReadFile.fileMapData.get(HcdbDef.msgCode));
			String message = "\"" + msgID + "\",\"" + (String) msgMap.get(msgID) + "\"";
			// ���O�o��
			for (int i = 0; i < args.length; i++) {
				message = message.replaceAll("\\{" + i + "\\}", args[i]);
			}
			this.CorrectionLog.add(new String[] { message, msgID, args[0], args[1] });
		}

		return retValue;
	}

	/**
	 * �L�[���w�肵�ăp�����[�^���擾����
	 * @param loginNo ���O�I���ԍ�
	 * @param paramMap �����̃L�[
	 * @return �p�����[�^
	 */
	public HashMap getGeneralParameter(final String loginNo, final ArrayList paramIDList) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		// ���ʊi�[�p�}�b�v
		final HashMap result = new HashMap();

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �擾ID��
			String paramIDps = "";
			for (int pCnt = 0; pCnt < paramIDList.size(); pCnt++) {
				if (pCnt != 0) {
					paramIDps += ", ";
				}
				paramIDps += "?";
			}

			// �ėp�p�����[�^�擾SQL
			String sql = " SELECT ";
			sql += HcdbDef.CCP_PARAM_COLUMNS[1] + ", ";
			sql += HcdbDef.CCP_PARAM_COLUMNS[2] + " ";
			sql += " FROM ";
			sql += HcdbDef.CCP_PARAM_TBL + " ";
			sql += " WHERE ";
			sql += HcdbDef.CCP_PARAM_COLUMNS[0] + " = ? ";
			sql += " AND ";
			sql += HcdbDef.CCP_PARAM_COLUMNS[1] + " IN (" + paramIDps + ") ";

			// �Z�b�g�ʒu
			int setCnt = 1;

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			// �p�����[�^����
			pstmt.setString(setCnt, this.PARAM_BUNRUI_NM);
			setCnt++;
			for (int pCnt = 0; pCnt < paramIDList.size(); pCnt++) {
				// �p�����[�^ID
				final String paramIDKey = (String) paramIDList.get(pCnt);
				pstmt.setString(setCnt, paramIDKey);
				setCnt++;
			}

			rs = pstmt.executeQuery();
			while (rs.next()) {
				// �p�����[�^�h�c
				String paramID = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[1]);
				paramID = paramID != null ? paramID : "";
				// �p�����[�^�l
				String paramValue = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
				paramValue = paramValue != null ? paramValue : "";

				// �i�[
				result.put(paramID, paramValue);
			}

			Log.method(loginNo, "OUT", "");
			return result;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �o�͑Ώێ҂��擾����
	 * @param loginNo
	 * @param enqueteNo
	 * @param groupIDList
	 * @return
	 */
	public HashMap getOutputPerson(final String loginNo, final String enqueteNo, final ArrayList groupIDList, final HashMap grpMap, final String sessionID, final HashMap outputFlg)
			throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		// ��E�K�w�J�n
		final String shimeiOutputStart = "1";
		// �g�D��؂蕶��
		String sosikiSeparator = "";
		Object obj = ReadFile.fileMapData.get(HcdbDef.SOSIKI_SEPARATOR);
		if (obj != null) {
			sosikiSeparator = (String) obj;
		}

		// ���b�Z�[�W�i�[�p�ϐ�
		final ArrayList msgList = new ArrayList();

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);
			final HashMap mapE023 = new HashMap();
			final HashMap mapE024 = new HashMap();
			final HashMap mapE025 = new HashMap();
			final HashMap mapE026 = new HashMap();
			final HashMap mapE027 = new HashMap();
			final HashMap mapE028 = new HashMap();
			final HashMap mapI001Team = new HashMap();
			final HashMap mapI001Bus = new HashMap();
			final HashMap mapI001Lead = new HashMap();
			for (int grCnt = 0; grCnt < groupIDList.size(); grCnt++) {

				// �g�D�h�c
				final HashMap groupMap = (HashMap) groupIDList.get(grCnt);
				final String groupIDkey = (String) groupMap.get("id");
				if (grpMap.containsKey(groupIDkey)) {

					// �Ώۑg�D�̊K�w�擾�r�p�k
					String sql = " SELECT " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[2] + ", " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[6] + " " + " FROM " + HcdbDef.CPM_ENQUETE_SOSHIKI_TBL + " "
							+ " WHERE " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[0] + " = ? " + " AND " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[1] + " = ? ";

					pstmt = dbConn.prepareStatement(sql);
					pstmt.clearParameters();
					pstmt.setString(1, enqueteNo);
					pstmt.setString(2, groupIDkey);
					rs = pstmt.executeQuery();

					// �Ώۂ̊K�w���擾
					String soshikiCode = null;
					String kaisou = null;
					if (rs.next()) {
						// �g�D�R�[�h
						soshikiCode = rs.getString(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[2]);
						soshikiCode = soshikiCode != null ? soshikiCode : "";
						// �K�w
						kaisou = rs.getString(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[6]);
						kaisou = kaisou != null ? kaisou : "";
					}
					// �J��
					PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
					// �v���b�g�K�w�擾�r�p�k
					sql = " SELECT " + HcdbDef.CCP_PARAM_COLUMNS[2] + " FROM " + HcdbDef.CCP_PARAM_TBL + " WHERE " + HcdbDef.CCP_PARAM_COLUMNS[0] + " = ? " + " AND " + HcdbDef.CCP_PARAM_COLUMNS[1]
							+ " = ? ";

					pstmt = dbConn.prepareStatement(sql);
					pstmt.clearParameters();
					pstmt.setString(1, this.PARAM_BUNRUI_NM);
					pstmt.setString(2, this.PLOT_KAISO + String.valueOf(Integer.parseInt(kaisou) + 1));
					rs = pstmt.executeQuery();

					// �Ώۂ̊K�w���擾
					String plotKaiso = null;
					if (rs.next()) {
						// �K�w
						plotKaiso = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
						plotKaiso = plotKaiso != null ? plotKaiso : "";

						if (!plotKaiso.equals("")) {
							plotKaiso = String.valueOf(Integer.parseInt(plotKaiso));
						}
					}
					// �J��
					PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
					// �����o�͊K�w�擾�r�p�k
					// ���̂܂�

					pstmt = dbConn.prepareStatement(sql);
					pstmt.clearParameters();
					pstmt.setString(1, this.PARAM_BUNRUI_NM);
					pstmt.setString(2, this.SHIMEI_OUTPUT_KAISO + String.valueOf(Integer.parseInt(kaisou) + 1));
					rs = pstmt.executeQuery();

					// �Ώۂ̊K�w���擾
					String shimeiOutputKaiso = null;
					if (rs.next()) {
						// �K�w
						shimeiOutputKaiso = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
						shimeiOutputKaiso = shimeiOutputKaiso != null ? shimeiOutputKaiso : "";

						if (!shimeiOutputKaiso.equals("")) {
							shimeiOutputKaiso = String.valueOf(Integer.parseInt(shimeiOutputKaiso));
						}
					}
					// �J��
					PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
					// �W�v�l���擾�r�p�k
					sql = " SELECT COUNT(*) AS CNT " + " FROM " + HcdbDef.CPS_SHAIN_SHUKEI_TBL + " WHERE " + HcdbDef.CPS_SHAIN_SHUKEI_COLUMNS[0] + " = ? ";

					pstmt = dbConn.prepareStatement(sql);
					pstmt.clearParameters();
					// �p�����[�^����
					pstmt.setString(1, enqueteNo);

					rs = pstmt.executeQuery();

					int cnt = 0;
					if (rs.next()) {
						// �J�E���g
						cnt = rs.getInt("CNT");
					}
					// �J��
					PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
					final ArrayList plotSoshiki = new ArrayList();

					// �Ώۑg�D�擾����
					// PRT_START
					int prtStart = 0;
					// PRT_END
					int prtEnd = 0;

					// PRT_START�̎擾
					sql = "SELECT " + HcdbDef.CCP_PARAM_COLUMNS[2] + " FROM " + HcdbDef.CCP_PARAM_TBL + " WHERE " + HcdbDef.CCP_PARAM_COLUMNS[0] + "=? AND " + HcdbDef.CCP_PARAM_COLUMNS[1] + "=?";

					pstmt = dbConn.prepareStatement(sql);
					pstmt.clearParameters();
					pstmt.setString(1, PED_TotalizePerformanceReportEJBBean.PRT_START_BUNRUI);
					pstmt.setString(2, PED_TotalizePerformanceReportEJBBean.PRT_START_ID_GROUP);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						final String tmp = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
						if (tmp != null) {
							prtStart = new Integer(tmp.trim()).intValue();
						}
					}
					// �J��
					PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
					// PRT_END�̎擾
					sql = "SELECT " + HcdbDef.CCP_PARAM_COLUMNS[2] + " FROM " + HcdbDef.CCP_PARAM_TBL + " WHERE " + HcdbDef.CCP_PARAM_COLUMNS[0] + "=? AND " + HcdbDef.CCP_PARAM_COLUMNS[1] + "=?";

					pstmt = dbConn.prepareStatement(sql);
					pstmt.clearParameters();
					pstmt.setString(1, PED_TotalizePerformanceReportEJBBean.PRT_START_BUNRUI);
					pstmt.setString(2, PED_TotalizePerformanceReportEJBBean.PRT_END_ID_GROUP);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						final String tmp = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
						prtEnd = new Integer(tmp.trim()).intValue();
					}
					PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

					String soshikiNm = "";
					sql = " SELECT " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[1] + ", " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[2] + ", " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[3] + ", "
							+ HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[5] + ", " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[6] + " FROM " + HcdbDef.CPM_ENQUETE_SOSHIKI_TBL + " " + "WHERE "
							+ HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[0] + "=? AND " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[1] + "=?";
					pstmt = dbConn.prepareStatement(sql);
					pstmt.clearParameters();
					pstmt.setString(1, enqueteNo);
					pstmt.setString(2, groupIDkey);
					rs = pstmt.executeQuery();

					if (rs.next()) {
						// �K�w���w��͈͊O�Ȃ�Ώۑg�D�̂�
						plotSoshiki.add(groupIDkey);
						final String jouiSoshikiCode = rs.getString(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[5]);
						soshikiNm = rs.getString(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[3]);
						boolean isEnd = true;
						String tmpSoshikiCode = jouiSoshikiCode;
						// ��U�J��
						PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
						while (isEnd) {
							sql = " SELECT " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[1] + ", " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[2] + ", " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[3] + ", "
									+ HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[5] + ", " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[6] + " FROM " + HcdbDef.CPM_ENQUETE_SOSHIKI_TBL + " " + "WHERE "
									+ HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[0] + "=? AND " + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[2] + "=? AND " + "TO_NUMBER(" + HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[6]
									+ ") BETWEEN ? AND ? ";
							pstmt = dbConn.prepareStatement(sql);
							pstmt.clearParameters();
							pstmt.setString(1, enqueteNo);
							pstmt.setString(2, tmpSoshikiCode);
							pstmt.setInt(3, prtStart);
							pstmt.setInt(4, prtEnd);
							rs = pstmt.executeQuery();
							if (rs.next()) {
								plotSoshiki.add(rs.getString(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[1]));
								tmpSoshikiCode = rs.getString(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[5]);
								final String tmpSoshikiNm = rs.getString(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[3]);
								soshikiNm = tmpSoshikiNm + sosikiSeparator + soshikiNm;
								if ("0".equals(rs.getString(HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS[6]))) {
									isEnd = false;
								}

							} else {
								isEnd = false;
							}
							PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
						}

					}

					// �g�D�u��������
					String setValue = "";
					for (int vCnt = 0; vCnt < plotSoshiki.size(); vCnt++) {
						if (vCnt != 0) {
							setValue += ", ";
						}
						setValue += "?";
					}

					// �ΏێҎ擾�p�r�p�k
					sql = " SELECT " + " A.ENQUETE_NO AS enquete_no, " + " A.PERSON_ID AS person_id," + " A.POST_ID AS post_id, " + " A.KAISOU AS kaisou," + " A.PLOT_NAME AS plot_name,"
							+ " A.YAKUSYOKU_CODE AS yakusyoku_code," + " B.MASTER_ID AS master_id, " + " B.ZOKUSEI_ID AS zokusei_id, " + " B.CHITEKINORYOKU AS chitekinoryoku, "
							+ " B.WORKING_MOTIVATION AS working_motivation, " + " B.PERFORMANCE AS performance, " + " B.KOJIN_SOSHIKI AS kojin_soshiki, " + " B.ANTEI_SEICHO AS antei_seicho, "
							+ " B.BUSINESS_SUISHINRYOKU AS business_suishinryoku, " + " B.KANKEIKOCHIKURYOKU AS kankeikochikuryoku, " + " B.BUSINESS_STYLE AS business_style, "
							+ " B.LEADERSHIP_ZONE AS leadership_zone " + " FROM ( " + " 	SELECT    " + " 		YAKUSHOKU.ENQUETE_NO AS ENQUETE_NO, " + " 	YAKUSHOKU.PERSON_ID AS PERSON_ID,   "
							+ "  	CPM_ENQUETE_YAKUSHOKU.POST_ID AS POST_ID,   " + "  	CPM_ENQUETE_YAKUSHOKU.KAISOU AS KAISOU,    " + "  	CPM_ENQUETE_YAKUSHOKU.YAKUSYOKU_CODE AS YAKUSYOKU_CODE,   "
							+ "  	CPM_ENQUETE_SHAIN.PLOT_NAME AS  PLOT_NAME  " + " 	FROM (   " + " 	SELECT  " + " 		CPM_ENQUETE_SHAIN_ZOKUSEI.PERSON_ID,  	 "
							+ " 		CPM_ENQUETE_SHAIN_ZOKUSEI.MASTER_ID,  	 " + " 		CPM_ENQUETE_SHAIN_ZOKUSEI.ENQUETE_NO   " + " 	FROM (  	 " + " 		SELECT   		 " + " 			ENQUETE_NO,  "
							+ " 			PERSON_ID, " + " 			MASTER_ID, " + " 			ZOKUSEI_ID " + " 		FROM ( " + " 			SELECT  "
							+ " 				CASE WHEN ZOKUSEI_ID = ? THEN (?) ELSE REPLACE(ZOKUSEI_ID, ?,?) END AS ZOKUSEI_ID, " + " 				PERSON_ID, " + " 				ENQUETE_NO, " + " 				MASTER_ID  " + " 			FROM "
							+ " 				CPM_ENQUETE_SHAIN_ZOKUSEI " + " 			WHERE " + " 				MASTER_ID IN( " + " 					SELECT  GROUP_ID  FROM (   "
							+ " 						SELECT 	*  FROM  	CPM_ENQUETE_SOSHIKI  WHERE ENQUETE_NO = ? AND    KAISOU BETWEEN ? AND ? "
							+ " 					) START WITH SOSIKI_CODE = ? CONNECT BY PRIOR GROUP_ID = JOUI_SOSIKI_CODE  " + " 				)  AND  " + " 				ENQUETE_NO = ? " + " 		) A  	 "
							+ " 	) A ,CPM_ENQUETE_SHAIN_ZOKUSEI   " + " 	WHERE  	 " + " 		CPM_ENQUETE_SHAIN_ZOKUSEI.PERSON_ID =  A.PERSON_ID AND "
							+ " 		CPM_ENQUETE_SHAIN_ZOKUSEI.ENQUETE_NO = A.ENQUETE_NO AND " + " 		CPM_ENQUETE_SHAIN_ZOKUSEI.ZOKUSEI_ID = A.ZOKUSEI_ID   "
							+ " ) YAKUSHOKU, CPM_ENQUETE_YAKUSHOKU,CPM_ENQUETE_SHAIN   " + " WHERE  " + " 	CPM_ENQUETE_YAKUSHOKU.POST_ID = YAKUSHOKU.MASTER_ID AND  "
							+ " 	CPM_ENQUETE_YAKUSHOKU.ENQUETE_NO = YAKUSHOKU.ENQUETE_NO  AND " + " 	YAKUSHOKU.PERSON_ID = CPM_ENQUETE_SHAIN.PERSON_ID  AND "
							+ " 	YAKUSHOKU.ENQUETE_NO = CPM_ENQUETE_SHAIN.ENQUETE_NO" + " ) A, ( " + " 	SELECT " + " 		DISTINCT " + " 		A.PERSON_ID, " + " 		A.ENQUETE_NO, " + " 		A.MASTER_ID, "
							+ " 		A.ZOKUSEI_ID, " + " 		CPS_SHAIN_SHUKEI.CHITEKINORYOKU, " + " 		CPS_SHAIN_SHUKEI.WORKING_MOTIVATION, " + " 		CPS_SHAIN_SHUKEI.PERFORMANCE, "
							+ " 		CPS_SHAIN_SHUKEI.KOJIN_SOSHIKI, " + " 		CPS_SHAIN_SHUKEI.ANTEI_SEICHO, " + " 		CPS_SHAIN_SHUKEI.BUSINESS_SUISHINRYOKU, " + " 		CPS_SHAIN_SHUKEI.KANKEIKOCHIKURYOKU, "
							+ " 		CPS_SHAIN_SHUKEI.BUSINESS_STYLE, " + " 		CPS_SHAIN_SHUKEI.LEADERSHIP_ZONE " + " 	FROM ( " + " 		SELECT " + " 			DISTINCT   " + " 			ENQUETE_NO, " + " 			PERSON_ID, "
							+ " 			MASTER_ID, " + " 			ZOKUSEI_ID  " + " 		FROM  " + " 			CPM_ENQUETE_SHAIN_ZOKUSEI " + " 		WHERE " + " 			ENQUETE_NO = ? AND "
							+ " 			(ZOKUSEI_ID = ? OR ZOKUSEI_ID LIKE ? )    AND      " + " 			MASTER_ID IN (   " + " 		    SELECT  GROUP_ID  FROM (   "
							+ " 		        SELECT *  FROM CPM_ENQUETE_SOSHIKI  WHERE ENQUETE_NO = ? AND    KAISOU BETWEEN ? AND ? "
							+ " 		    	) START WITH SOSIKI_CODE = ? CONNECT BY PRIOR GROUP_ID = JOUI_SOSIKI_CODE  " + " 			)  " + " 		) A, CPS_SHAIN_SHUKEI " + " 	WHERE "
							+ " 		CPS_SHAIN_SHUKEI.ENQUETE_NO = A.ENQUETE_NO AND " + " 		CPS_SHAIN_SHUKEI.PERSON_ID = A.PERSON_ID " + " ) B " + " WHERE " + " A.PERSON_ID = B.PERSON_ID AND "
							+ " A.ENQUETE_NO = B.ENQUETE_NO ";

					int setCnt = 1;

					pstmt = dbConn.prepareStatement(sql);
					pstmt.clearParameters();

					pstmt.setString(setCnt, this.HONMU_SOSHIKI);
					setCnt++;
					pstmt.setString(setCnt, this.HONMU_YAKUSHOKU);
					setCnt++;
					pstmt.setString(setCnt, this.KENMU_SOSHIKI);
					setCnt++;
					pstmt.setString(setCnt, this.KENMU_YAKUSHOKU);
					setCnt++;
					pstmt.setString(setCnt, enqueteNo);
					setCnt++;
					pstmt.setString(setCnt, kaisou);
					setCnt++;
					pstmt.setString(setCnt, plotKaiso);
					setCnt++;

					pstmt.setString(setCnt, groupIDkey);
					setCnt++;
					pstmt.setString(setCnt, enqueteNo);
					setCnt++;
					pstmt.setString(setCnt, enqueteNo);
					setCnt++;
					pstmt.setString(setCnt, this.HONMU_SOSHIKI);
					setCnt++;
					pstmt.setString(setCnt, this.KENMU_SOSHIKI + "%");
					setCnt++;
					pstmt.setString(setCnt, enqueteNo);
					setCnt++;
					pstmt.setString(setCnt, kaisou);
					setCnt++;
					pstmt.setString(setCnt, plotKaiso);
					setCnt++;
					pstmt.setString(setCnt, groupIDkey);
					setCnt++;
					rs = pstmt.executeQuery();

					final ArrayList shainList = new ArrayList();
					final HashMap targetMap = new HashMap();
					final HashMap targetKenmuMap = new HashMap();
					final HashMap targetBeanMap = new HashMap();
					while (rs.next()) {
						// �l�h�c
						final String personId = rs.getString(HcdbDef.CPM_ENQUETE_SHAIN_COLUMNS[1]);
						final String zokuseiId = rs.getString(HcdbDef.CPM_ENQUETE_SHAIN_ZOKUSEI_COLUMNS[2]);
						final String masterId = rs.getString(HcdbDef.CPM_ENQUETE_SHAIN_ZOKUSEI_COLUMNS[3]);

						// �Y���g�D�̃f�[�^�Ȃ�D��I�Ɋi�[
						if (!groupIDkey.equals(masterId)) {
							targetBeanMap.put(personId, this.addShain(rs, shimeiOutputStart, shimeiOutputKaiso));
							targetMap.put(personId, zokuseiId);
						} else {
							// ���ɊY���g�D�̃f�[�^���擾���Ă���Ȃ牽�����Ȃ�
							if (!targetMap.containsKey(personId)) {
								// �{���Ȃ�D��I�Ɋi�[
								if (this.HONMU_SOSHIKI.equals(zokuseiId)) {
									targetMap.put(personId, zokuseiId);
									targetBeanMap.put(personId, this.addShain(rs, shimeiOutputStart, shimeiOutputKaiso));
								}
								// �����̏ꍇ�ԍ��̏���
								else {
									// �f�[�^���i�[����Ă��Ȃ��ꍇ�A�V�K�i�[
									if (!targetKenmuMap.containsKey(personId)) {
										targetKenmuMap.put(personId, zokuseiId);
										shainList.add(this.addShain(rs, shimeiOutputStart, shimeiOutputKaiso));
									} else {
										final String addZokuseiID = (String) targetKenmuMap.get(personId);
										final int targetNum = new Integer(addZokuseiID.replaceAll(this.KENMU_SOSHIKI, "")).intValue();
										final int num = new Integer(zokuseiId.replaceAll(this.KENMU_SOSHIKI, "")).intValue();
										if (targetNum > num) {
											targetKenmuMap.put(personId, zokuseiId);
											targetBeanMap.put(personId, this.addShain(rs, shimeiOutputStart, shimeiOutputKaiso));
										}
									}
								}
							}
						}
					}
					final Iterator it = targetBeanMap.keySet().iterator();
					while (it.hasNext()) {
						obj = it.next();
						shainList.add(targetBeanMap.get(obj));

					}

					// �J��
					PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
					final HashMap msgMap = ReadFile.getMsgMapData((String) ReadFile.fileMapData.get(HcdbDef.msgCode));

					for (int i = 0; i < shainList.size(); i++) {
						// �i�[���b�Z�[�W
						String message = "";
						final PED_ReportShainValueBean baseBean = (PED_ReportShainValueBean) shainList.get(i);

						// �lID
						final String personId = PZZ010_CharacterUtil.normalizedStr(baseBean.getPersonID());

						// 3�ȏ��3�ɕ␳
						// �m�I�\�͔����x
						String chitekiNyoryoku = PZZ010_CharacterUtil.normalizedStr(baseBean.getChitekiNyoryoku());
						if (!chitekiNyoryoku.equals("") && Double.parseDouble(chitekiNyoryoku) > 3) {
							baseBean.setChitekiNyoryoku("3");

							message = "\"CPM-VED150-E023\",";
							// ���b�Z�[�W���擾
							message += "\"" + (String) msgMap.get("CPM-VED150-E023") + "\"";
							// ���b�Z�[�W�̉ϕ������i�[
							message = message.replaceAll("\\{0\\}", soshikiCode);
							message = message.replaceAll("\\{1\\}", personId);
							message = message.replaceAll("\\{2\\}", chitekiNyoryoku);

							if (!mapE023.containsKey(personId)) {
								mapE023.put(personId, personId);
								msgList.add(new String[] { message, "CPM-VED150-E023", soshikiCode, personId });
							}
						}
						// ���[�L���O���`�x�[�V����
						String workingMotivation = PZZ010_CharacterUtil.normalizedStr(baseBean.getWorkingMotivation());
						if (!workingMotivation.equals("") && Double.parseDouble(workingMotivation) > 3) {
							baseBean.setWorkingMotivation("3");

							message = "\"CPM-VED150-E024\",";
							// ���b�Z�[�W���擾
							message += "\"" + (String) msgMap.get("CPM-VED150-E024") + "\"";
							// ���b�Z�[�W�̉ϕ������i�[
							message = message.replaceAll("\\{0\\}", soshikiCode);
							message = message.replaceAll("\\{1\\}", personId);
							message = message.replaceAll("\\{2\\}", workingMotivation);

							if (!mapE024.containsKey(personId)) {
								mapE024.put(personId, personId);
								msgList.add(new String[] { message, "CPM-VED150-E024", soshikiCode, personId });
							}
						}
						// �l�g�D
						String kojinSoshiki = PZZ010_CharacterUtil.normalizedStr(baseBean.getKojinSoshiki());
						if (!kojinSoshiki.equals("") && Double.parseDouble(kojinSoshiki) > 3) {
							baseBean.setKojinSoshiki("3");

							message = "\"CPM-VED150-E025\",";
							// ���b�Z�[�W���擾
							message += "\"" + (String) msgMap.get("CPM-VED150-E025") + "\"";
							// ���b�Z�[�W�̉ϕ������i�[
							message = message.replaceAll("\\{0\\}", soshikiCode);
							message = message.replaceAll("\\{1\\}", personId);
							message = message.replaceAll("\\{2\\}", kojinSoshiki);

							if (!mapE025.containsKey(personId)) {
								mapE025.put(personId, personId);
								msgList.add(new String[] { message, "CPM-VED150-E025", soshikiCode, personId });
							}
						}
						// ���萬��
						String anteiSeicho = PZZ010_CharacterUtil.normalizedStr(baseBean.getAnteiSeicho());
						if (!anteiSeicho.equals("") && Double.parseDouble(anteiSeicho) > 3) {
							baseBean.setAnteiSeicho("3");

							message = "\"CPM-VED150-E026\",";
							// ���b�Z�[�W���擾
							message += "\"" + (String) msgMap.get("CPM-VED150-E026") + "\"";
							// ���b�Z�[�W�̉ϕ������i�[
							message = message.replaceAll("\\{0\\}", soshikiCode);
							message = message.replaceAll("\\{1\\}", personId);
							message = message.replaceAll("\\{2\\}", anteiSeicho);

							if (!mapE026.containsKey(personId)) {
								mapE026.put(personId, personId);
								msgList.add(new String[] { message, "CPM-VED150-E026", soshikiCode, personId });
							}
						}
						// �r�W�l�X���i��
						String businessSuishinryoku = PZZ010_CharacterUtil.normalizedStr(baseBean.getBusinessSuishinryoku());
						if (!businessSuishinryoku.equals("") && Double.parseDouble(businessSuishinryoku) > 3) {
							baseBean.setBusinessSuishinryoku("3");

							message = "\"CPM-VED150-E027\",";
							// ���b�Z�[�W���擾
							message += "\"" + (String) msgMap.get("CPM-VED150-E027") + "\"";
							// ���b�Z�[�W�̉ϕ������i�[
							message = message.replaceAll("\\{0\\}", soshikiCode);
							message = message.replaceAll("\\{1\\}", personId);
							message = message.replaceAll("\\{2\\}", businessSuishinryoku);

							if (!mapE027.containsKey(personId)) {
								mapE027.put(personId, personId);
								msgList.add(new String[] { message, "CPM-VED150-E027", soshikiCode, personId });
							}
						}
						// �֌W�\�z��
						String kankeiKochikuryoku = PZZ010_CharacterUtil.normalizedStr(baseBean.getKankeiKochikuryoku());
						if (!kankeiKochikuryoku.equals("") && Double.parseDouble(kankeiKochikuryoku) > 3) {
							baseBean.setKankeiKochikuryoku("3");

							message = "\"CPM-VED150-E028\",";
							// ���b�Z�[�W���擾
							message += "\"" + (String) msgMap.get("CPM-VED150-E028") + "\"";
							// ���b�Z�[�W�̉ϕ������i�[
							message = message.replaceAll("\\{0\\}", soshikiCode);
							message = message.replaceAll("\\{1\\}", personId);
							message = message.replaceAll("\\{2\\}", kankeiKochikuryoku);

							if (!mapE028.containsKey(personId)) {
								mapE028.put(personId, personId);
								msgList.add(new String[] { message, "CPM-VED150-E028", soshikiCode, personId });
							}
						}

						// -3������-3�ɕ␳
						// �m�I�\�͔����x
						chitekiNyoryoku = PZZ010_CharacterUtil.normalizedStr(baseBean.getChitekiNyoryoku());
						if (!chitekiNyoryoku.equals("") && Double.parseDouble(chitekiNyoryoku) < -3) {
							baseBean.setChitekiNyoryoku("-3");

							message = "\"CPM-VED150-E023\",";
							// ���b�Z�[�W���擾
							message += "\"" + (String) msgMap.get("CPM-VED150-E023") + "\"";
							// ���b�Z�[�W�̉ϕ������i�[
							message = message.replaceAll("\\{0\\}", soshikiCode);
							message = message.replaceAll("\\{1\\}", personId);
							message = message.replaceAll("\\{2\\}", chitekiNyoryoku);

							if (!mapE023.containsKey(personId)) {
								mapE023.put(personId, personId);
								msgList.add(new String[] { message, "CPM-VED150-E023", soshikiCode, personId });
							}
						}
						// ���[�L���O���`�x�[�V����
						workingMotivation = PZZ010_CharacterUtil.normalizedStr(baseBean.getWorkingMotivation());
						if (!workingMotivation.equals("") && Double.parseDouble(workingMotivation) < -3) {
							baseBean.setWorkingMotivation("-3");

							message = "\"CPM-VED150-E024\",";
							// ���b�Z�[�W���擾
							message += "\"" + (String) msgMap.get("CPM-VED150-E024") + "\"";
							// ���b�Z�[�W�̉ϕ������i�[
							message = message.replaceAll("\\{0\\}", soshikiCode);
							message = message.replaceAll("\\{1\\}", personId);
							message = message.replaceAll("\\{2\\}", workingMotivation);

							if (!mapE024.containsKey(personId)) {
								mapE024.put(personId, personId);
								msgList.add(new String[] { message, "CPM-VED150-E024", soshikiCode, personId });
							}
						}
						// �l�g�D
						kojinSoshiki = PZZ010_CharacterUtil.normalizedStr(baseBean.getKojinSoshiki());
						if (!kojinSoshiki.equals("") && Double.parseDouble(kojinSoshiki) < -3) {
							baseBean.setKojinSoshiki("-3");

							message = "\"CPM-VED150-E025\",";
							// ���b�Z�[�W���擾
							message += "\"" + (String) msgMap.get("CPM-VED150-E025") + "\"";
							// ���b�Z�[�W�̉ϕ������i�[
							message = message.replaceAll("\\{0\\}", soshikiCode);
							message = message.replaceAll("\\{1\\}", personId);
							message = message.replaceAll("\\{2\\}", kojinSoshiki);

							if (!mapE025.containsKey(personId)) {
								mapE025.put(personId, personId);
								msgList.add(new String[] { message, "CPM-VED150-E025", soshikiCode, personId });
							}
						}
						// ���萬��
						anteiSeicho = PZZ010_CharacterUtil.normalizedStr(baseBean.getAnteiSeicho());
						if (!anteiSeicho.equals("") && Double.parseDouble(anteiSeicho) < -3) {
							baseBean.setAnteiSeicho("-3");

							message = "\"CPM-VED150-E026\",";
							// ���b�Z�[�W���擾
							message += "\"" + (String) msgMap.get("CPM-VED150-E026") + "\"";
							// ���b�Z�[�W�̉ϕ������i�[
							message = message.replaceAll("\\{0\\}", soshikiCode);
							message = message.replaceAll("\\{1\\}", personId);
							message = message.replaceAll("\\{2\\}", anteiSeicho);

							if (!mapE026.containsKey(personId)) {
								mapE026.put(personId, personId);
								msgList.add(new String[] { message, "CPM-VED150-E026", soshikiCode, personId });
							}
						}
						// �r�W�l�X���i��
						businessSuishinryoku = PZZ010_CharacterUtil.normalizedStr(baseBean.getBusinessSuishinryoku());
						if (!businessSuishinryoku.equals("") && Double.parseDouble(businessSuishinryoku) < -3) {
							baseBean.setBusinessSuishinryoku("-3");

							message = "\"CPM-VED150-E027\",";
							// ���b�Z�[�W���擾
							message += "\"" + (String) msgMap.get("CPM-VED150-E027") + "\"";
							// ���b�Z�[�W�̉ϕ������i�[
							message = message.replaceAll("\\{0\\}", soshikiCode);
							message = message.replaceAll("\\{1\\}", personId);
							message = message.replaceAll("\\{2\\}", businessSuishinryoku);

							if (!mapE027.containsKey(personId)) {
								mapE027.put(personId, personId);
								msgList.add(new String[] { message, "CPM-VED150-E027", soshikiCode, personId });
							}
						}
						// �֌W�\�z��
						kankeiKochikuryoku = PZZ010_CharacterUtil.normalizedStr(baseBean.getKankeiKochikuryoku());
						if (!kankeiKochikuryoku.equals("") && Double.parseDouble(kankeiKochikuryoku) < -3) {
							baseBean.setKankeiKochikuryoku("-3");

							message = "\"CPM-VED150-E028\",";
							// ���b�Z�[�W���擾
							message += "\"" + (String) msgMap.get("CPM-VED150-E028") + "\"";
							// ���b�Z�[�W�̉ϕ������i�[
							message = message.replaceAll("\\{0\\}", soshikiCode);
							message = message.replaceAll("\\{1\\}", personId);
							message = message.replaceAll("\\{2\\}", kankeiKochikuryoku);

							if (!mapE028.containsKey(personId)) {
								mapE028.put(personId, personId);
								msgList.add(new String[] { message, "CPM-VED150-E028", soshikiCode, personId });
							}
						}
						// �C���������e���i�[
						shainList.set(i, baseBean);
					}
					for (int i = 0; i < shainList.size(); i++) {
						// �i�[���b�Z�[�W
						String message = "";
						// �v���b�g��񃁃b�Z�[�W
						String plotMsg = "";

						final PED_ReportShainValueBean baseBean = (PED_ReportShainValueBean) shainList.get(i);

						// �lID
						final String personId = PZZ010_CharacterUtil.normalizedStr(baseBean.getPersonID());
						// ���̏o�͑ΏۂȂ�d���`�F�b�N
						final String plotName = baseBean.getPlotName();

						if (!"".equals(plotName)) {

							String chitekiNyoryoku = "";
							String workingMotivation = "";
							String kojinSoshiki = "";
							String anteiSeicho = "";
							String businessSuishinryoku = "";
							String kankeiKochikuryoku = "";

							int chitekiNyoryokuVal = 0;
							int workingMotivationVal = 0;
							int kojinSoshikiVal = 0;
							int anteiSeichoVal = 0;
							int businessSuishinryokuVal = 0;
							int kankeiKochikuryokuVal = 0;

							// career.properties
							final String baseVal = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.fileMapData.get("PERFORMANCE_DUP_AREA_UNIT"));

							if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[12]))) {// �`�[���R���f�B�V�����}�b�v
								try {
									chitekiNyoryoku = baseBean.getChitekiNyoryoku();
									chitekiNyoryokuVal = new BigDecimal(chitekiNyoryoku).divide(new BigDecimal(baseVal), BigDecimal.ROUND_HALF_DOWN).intValue();
									workingMotivation = baseBean.getWorkingMotivation();
									workingMotivationVal = new BigDecimal(workingMotivation).divide(new BigDecimal(baseVal), BigDecimal.ROUND_HALF_DOWN).intValue();
								} catch (final NullPointerException e) {
									// �ǂ��炩�̒l��NULL��������`�F�b�N�ΏۊO�Ƃ���
									chitekiNyoryokuVal = this.NULL_EXCE_VALUE;
								}
							}
							if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[13]))) {// �r�W�l�X�}�C���h�}�b�v
								try {
									kojinSoshiki = baseBean.getKojinSoshiki();
									kojinSoshikiVal = new BigDecimal(kojinSoshiki).divide(new BigDecimal(baseVal), BigDecimal.ROUND_HALF_DOWN).intValue();
									anteiSeicho = baseBean.getAnteiSeicho();
									anteiSeichoVal = new BigDecimal(anteiSeicho).divide(new BigDecimal(baseVal), BigDecimal.ROUND_HALF_DOWN).intValue();
								} catch (final NullPointerException e) {
									// �ǂ��炩�̒l��NULL��������`�F�b�N�ΏۊO�Ƃ���
									kojinSoshikiVal = this.NULL_EXCE_VALUE;
								}
							}
							if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[14]))) {// ���[�_�[�V�b�v�����}�b�v
								try {
									businessSuishinryoku = baseBean.getBusinessSuishinryoku();
									businessSuishinryokuVal = new BigDecimal(businessSuishinryoku).divide(new BigDecimal(baseVal), BigDecimal.ROUND_HALF_DOWN).intValue();
									kankeiKochikuryoku = baseBean.getKankeiKochikuryoku();
									kankeiKochikuryokuVal = new BigDecimal(kankeiKochikuryoku).divide(new BigDecimal(baseVal), BigDecimal.ROUND_HALF_DOWN).intValue();
								} catch (final NullPointerException e) {
									// �ǂ��炩�̒l��NULL��������`�F�b�N�ΏۊO�Ƃ���
									businessSuishinryokuVal = this.NULL_EXCE_VALUE;
								}
							}

							// ������W�`�F�b�N
							for (int j = 0; j < shainList.size(); j++) {
								if (i != j) {
									// ��r�ΏƂ��擾
									final PED_ReportShainValueBean targetBean = (PED_ReportShainValueBean) shainList.get(j);

									final String targetPlotName = targetBean.getPlotName();
									if (!"".equals(targetPlotName) && !baseBean.getPersonID().equals(targetBean.getPersonID())) {

										if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[12]))) {// �`�[���R���f�B�V�����}�b�v
											try {
												// �m�I�\�͔����x
												final int tChitekiNyoryoku = new BigDecimal(targetBean.getChitekiNyoryoku()).divide(new BigDecimal(baseVal), BigDecimal.ROUND_HALF_DOWN).intValue();
												// ���[�L���O���`�x�[�V����
												final int tWorkingMotivation = new BigDecimal(targetBean.getWorkingMotivation()).divide(new BigDecimal(baseVal), BigDecimal.ROUND_HALF_DOWN).intValue();
												// �m�I�\�͔����x:���[�L���O���`�x�[�V����
												if (chitekiNyoryokuVal == tChitekiNyoryoku && workingMotivationVal == tWorkingMotivation) {
													// �v���b�g���
													plotMsg = this.REPORT_TYPE_WORD + this.CM_WORD + "\",\"" + this.POINT_WORD + new Double(workingMotivation) + "\",\"" + new Double(chitekiNyoryoku)
															+ "\"";

													message = "\"CPM-VED150-I001\",";
													// ���b�Z�[�W���擾
													message += "\"" + (String) msgMap.get("CPM-VED150-I001");
													// ���b�Z�[�W�̉ϕ������i�[
													message = message.replaceAll("\\{0\\}", soshikiCode);
													message = message.replaceAll("\\{1\\}", personId);
													message = message.replaceAll("\\{2\\}", plotMsg);
													if (!mapI001Team.containsKey(personId)) {
														mapI001Team.put(personId, personId);
														msgList.add(new String[] { message, "CPM-VED150-I001", soshikiCode, personId });
													}
												}
											} catch (final NullPointerException e) {
												// �������Ȃ�
											}
										}
										if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[13]))) {// �r�W�l�X�}�C���h�}�b�v
											try {
												// �l�g�D
												final int tKojinSoshiki = new BigDecimal(targetBean.getKojinSoshiki()).divide(new BigDecimal(baseVal), BigDecimal.ROUND_HALF_DOWN).intValue();
												// ���萬��
												final int tAnteiSeicho = new BigDecimal(targetBean.getAnteiSeicho()).divide(new BigDecimal(baseVal), BigDecimal.ROUND_HALF_DOWN).intValue();
												// �l�g�D:���萬��
												if (kojinSoshikiVal == tKojinSoshiki && anteiSeichoVal == tAnteiSeicho) {
													// �v���b�g���
													plotMsg = this.REPORT_TYPE_WORD + this.BM_WORD + "\",\"" + this.POINT_WORD + new Double(anteiSeicho) + "\",\"" + new Double(kojinSoshiki);

													message = "\"CPM-VED150-I001\",";
													// ���b�Z�[�W���擾
													message += "\"" + (String) msgMap.get("CPM-VED150-I001") + "\"";
													// ���b�Z�[�W�̉ϕ������i�[
													message = message.replaceAll("\\{0\\}", soshikiCode);
													message = message.replaceAll("\\{1\\}", personId);
													message = message.replaceAll("\\{2\\}", plotMsg);
													if (!mapI001Bus.containsKey(personId)) {
														mapI001Bus.put(personId, personId);
														msgList.add(new String[] { message, "CPM-VED150-I001", soshikiCode, personId });
													}
												}
											} catch (final NullPointerException e) {
												// �������Ȃ�
											}
										}
										if ("1".equals(outputFlg.get(HcdbDef.CPM_ENQUETE_COLUMNS[14]))) {// ���[�_�[�V�b�v�����}�b�v
											try {
												// �r�W�l�X���i��
												final int tBusinessSuishinryoku = new BigDecimal(targetBean.getBusinessSuishinryoku()).divide(new BigDecimal(baseVal), BigDecimal.ROUND_HALF_DOWN)
														.intValue();
												// �֌W�\�z��
												final int tKankeiKochikuryoku = new BigDecimal(targetBean.getKankeiKochikuryoku()).divide(new BigDecimal(baseVal), BigDecimal.ROUND_HALF_DOWN)
														.intValue();
												// �r�W�l�X���i��:�֌W�\�z��
												if (businessSuishinryokuVal == tBusinessSuishinryoku && kankeiKochikuryokuVal == tKankeiKochikuryoku) {
													// �v���b�g���
													plotMsg = this.REPORT_TYPE_WORD + this.RT_WORD + "\",\"" + this.POINT_WORD + new Double(kankeiKochikuryoku) + "\",\""
															+ new Double(businessSuishinryoku);

													message = "\"CPM-VED150-I001\",";
													// ���b�Z�[�W���擾
													message += "\"" + (String) msgMap.get("CPM-VED150-I001") + "\"";
													// ���b�Z�[�W�̉ϕ������i�[
													message = message.replaceAll("\\{0\\}", soshikiCode);
													message = message.replaceAll("\\{1\\}", personId);
													message = message.replaceAll("\\{2\\}", plotMsg);
													if (!mapI001Lead.containsKey(personId)) {
														mapI001Lead.put(personId, personId);
														msgList.add(new String[] { message, "CPM-VED150-I001", soshikiCode, personId });
													}
												}
											} catch (final NullPointerException e) {
												// �������Ȃ�
											}
										}
									}
								}
							}
						}
					}

					PED_ReportSoshikiValueBean soshikiBean = new PED_ReportSoshikiValueBean();
					if (grpMap.containsKey(groupIDkey)) {
						soshikiBean = (PED_ReportSoshikiValueBean) grpMap.get(groupIDkey);
					}

					soshikiBean.setGroupID(groupIDkey);
					soshikiBean.setShukeiCount(String.valueOf(cnt));
					soshikiBean.setShainBeanList(shainList);
					soshikiBean.setSoshikiName(soshikiNm);
					soshikiBean.setSoshikiCode(soshikiCode);

					// �g�D�h�c���L�[�Ɋi�[
					if (grpMap.containsKey(groupIDkey)) {
						grpMap.put(groupIDkey, soshikiBean);
					}
				}
			}

			PED_TotalizePerformanceReportPDFThread.setLogMsgList(sessionID, msgList);

			Log.method(loginNo, "OUT", "");
			return grpMap;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * DB�̌��ʂ���Ј������擾����
	 * @param shimeiOutputKaiso
	 * @param shimeiOutputStart
	 */
	private PED_ReportShainValueBean addShain(final ResultSet rs, final String shimeiOutputStart, final String shimeiOutputKaiso) throws SQLException {
		// �l�h�c
		final String personId = rs.getString(HcdbDef.CPM_ENQUETE_SHAIN_COLUMNS[1]);
		// �v���b�g�p����
		String plotName = rs.getString(HcdbDef.CPM_ENQUETE_SHAIN_COLUMNS[4]);
		// �m�I�\�͔����x
		final String chitekiNoryoku = rs.getString(HcdbDef.CPS_SHAIN_SHUKEI_COLUMNS[2]);
		// ���[�L���O���`�x�[�V����
		final String workingMotivation = rs.getString(HcdbDef.CPS_SHAIN_SHUKEI_COLUMNS[3]);
		// �p�t�H�[�}���X�]�[��
		final String performance = rs.getString(HcdbDef.CPS_SHAIN_SHUKEI_COLUMNS[4]);
		// �l�g�D
		final String kojinSoshiki = rs.getString(HcdbDef.CPS_SHAIN_SHUKEI_COLUMNS[5]);
		// ���萬��
		final String anteiSeicho = rs.getString(HcdbDef.CPS_SHAIN_SHUKEI_COLUMNS[6]);
		// �r�W�l�X���i��
		final String businessSuishinryoku = rs.getString(HcdbDef.CPS_SHAIN_SHUKEI_COLUMNS[7]);
		// �֌W�\�z��
		final String kankeiKochikuryoku = rs.getString(HcdbDef.CPS_SHAIN_SHUKEI_COLUMNS[8]);
		// �r�W�l�X�X�^�C���]�[��
		final String businessStyle = rs.getString(HcdbDef.CPS_SHAIN_SHUKEI_COLUMNS[9]);
		// ���[�_�[�V�b�v�]�[��
		final String leadershipZone = rs.getString(HcdbDef.CPS_SHAIN_SHUKEI_COLUMNS[10]);
		// ��E�h�c
		final String postId = rs.getString(HcdbDef.CPM_ENQUETE_YAKUSHOKU_COLUMNS[1]);
		// �K�w�i��E�j
		final String yakushokuKaisou = rs.getString(HcdbDef.CPM_ENQUETE_YAKUSHOKU_COLUMNS[4]);

		// ���ꏈ��
		final int kaisouStart = Integer.parseInt(shimeiOutputStart);
		final int kaisouEnd = Integer.parseInt(shimeiOutputKaiso);
		final int getKaisou = Integer.parseInt(yakushokuKaisou);
		// �����o�͑ΏۂłȂ���΋󕶎����擾����
		if (kaisouStart > getKaisou || getKaisou > kaisouEnd) {
			plotName = "";
		}
		// ���|�[�g�o�͑Ώێ�Bean�֊i�[
		final PED_ReportShainValueBean bean = new PED_ReportShainValueBean();
		bean.setPersonID(personId);
		bean.setPlotName(plotName);
		bean.setChitekiNyoryoku(chitekiNoryoku);
		bean.setWorkingMotivation(workingMotivation);
		bean.setPerformance(performance);
		bean.setKojinSoshiki(kojinSoshiki);
		bean.setAnteiSeicho(anteiSeicho);
		bean.setBusinessSuishinryoku(businessSuishinryoku);
		bean.setKankeiKochikuryoku(kankeiKochikuryoku);
		bean.setBusinessStyle(businessStyle);
		bean.setLeadershipZone(leadershipZone);
		bean.setPostID(postId);
		bean.setKaisou(String.valueOf(Integer.parseInt(yakushokuKaisou)));

		return bean;
	}

	/**
	 * PDF�쐬�����O��o�^����
	 * @param loginNo
	 * @param enqueteNo
	 * @param sessionId
	 * @param logMsgList
	 */
	public void insertPDFLog(final String loginNo, final String enqueteNo, final String sessionId, final ArrayList logMsgList) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		final ResultSet rs = null;

		String sql = "";

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �e�L�X�g�o�̓e�[�u���̓��e���폜����
			this.deleteTextOutput(enqueteNo, loginNo, sessionId, new String[] { PED_TotalizePerformanceReportEJBBean.TYPE_REPORT, PED_TotalizePerformanceReportEJBBean.TYPE_SHUKEI });

			if (logMsgList != null && logMsgList.size() > 0) {
				for (int i = 0; i < logMsgList.size(); i++) {
					/* SQL�R�}���h */
					sql = "INSERT INTO " + HcdbDef.CPP_TEXT_OUTPUT_TBL + " " + "(" + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[0] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[1] + ", "
							+ HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[2] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[3] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[4] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[5]
							+ ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[6] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[7] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[8] + ", "
							+ HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[9] + " " + ") VALUES(" + "?, " + // 1.SESSION_ID
							"?, " + // 2.TYPE
							"?, " + // 3.SEQ_NO
							"?, " + // 4.TEXT
							"?, " + // 5.YOBI1
							"?, " + // 6.YOBI2
							"?, " + // 7.YOBI3
							"?, " + // 8.YOBI4
							"?,?)"; // 9.YOBI5

					/* SQL�R�}���h��ݒ� */
					pstmt = dbConn.prepareStatement(sql);
					pstmt.clearParameters();

					/* �p�����^�[��ݒ� */
					pstmt.setString(1, sessionId);
					pstmt.setString(2, PED_TotalizePerformanceReportEJBBean.TYPE_TMP);
					pstmt.setInt(3, i);
					pstmt.setString(4, ((String[]) logMsgList.get(i))[0]);
					pstmt.setString(5, enqueteNo);
					pstmt.setString(6, ((String[]) logMsgList.get(i))[1]);
					pstmt.setString(7, ((String[]) logMsgList.get(i))[3]);
					pstmt.setString(8, ((String[]) logMsgList.get(i))[2]);
					pstmt.setString(9, "");
					pstmt.setString(10, "");
					/* SQL�R�}���h�����s */
					pstmt.executeUpdate();
					PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
				}
				// �\�[�g
				sql = "INSERT INTO " + HcdbDef.CPP_TEXT_OUTPUT_TBL + " SELECT " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[0] + ", " + " TYPE " + ", " + "ROWNUM" + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[3]
						+ ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[5] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[6] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[7] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[8]
						+ ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[9] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[4] + " FROM (" + " SELECT " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[0] + ", " + " ? "
						+ " AS TYPE, " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[2] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[3] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[5] + ", "
						+ HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[6] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[7] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[8] + ", " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[9] + ", "
						+ HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[4] + " FROM " + HcdbDef.CPP_TEXT_OUTPUT_TBL + " WHERE " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[0] + "=? AND " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[1]
						+ "=? AND " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[4] + "=? ORDER BY " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[5] + "," + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[6] + ","
						+ HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[7] + ")";
				/* SQL�R�}���h��ݒ� */
				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();

				/* �p�����^�[��ݒ� */
				pstmt.setString(1, PED_TotalizePerformanceReportEJBBean.TYPE_REPORT);
				pstmt.setString(2, sessionId);
				pstmt.setString(3, PED_TotalizePerformanceReportEJBBean.TYPE_TMP);
				pstmt.setString(4, enqueteNo);

				/* SQL�R�}���h�����s */
				pstmt.executeUpdate();
				PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);

				// �\�[�g�p�f�[�^�폜
				sql = "DELETE FROM " + HcdbDef.CPP_TEXT_OUTPUT_TBL + " WHERE " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[0] + "=? AND " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[1] + "=? AND "
						+ HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[4] + "=?";

				/* SQL�R�}���h��ݒ� */
				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();

				/* �p�����^�[��ݒ� */
				pstmt.setString(1, sessionId);
				pstmt.setString(2, PED_TotalizePerformanceReportEJBBean.TYPE_TMP);
				pstmt.setString(3, enqueteNo);

				/* SQL�R�}���h�����s */
				pstmt.executeUpdate();
				PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);

			}

			Log.method(loginNo, "OUT", "");
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} catch (final Exception e) {
			this.sesContext.setRollbackOnly();
			Log.error(loginNo, "", e);
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * ���|�[�g�o�c�e��o�^�A�X�V����
	 * @param loginNo
	 * @param enqueteNo
	 * @param sessionId
	 * @param pdfGroupMap
	 * @param logMsgList
	 */
	public void insertReportPDF(final String loginNo, final String enqueteNo, final String sessionId, final byte[] bs, final String soshikiCode) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "";

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �J�E���g�r�p�k
			sql = " SELECT COUNT(*) AS CNT " + " FROM " + HcdbDef.CPG_SOSHIKI_REPORT_TBL + " WHERE " + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[0] + " = ? " + " AND "
					+ HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1] + " = ? ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			// �p�����[�^����
			pstmt.setString(1, enqueteNo);
			pstmt.setString(2, soshikiCode);

			rs = pstmt.executeQuery();

			int cnt = 0;
			if (rs.next()) {
				// �J�E���g
				cnt = rs.getInt("CNT");
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
			// �f�[�^�����݂��Ȃ�
			if (cnt == 0) {
				// �o�c�e�o�^�r�p�k
				sql = " INSERT INTO " + HcdbDef.CPG_SOSHIKI_REPORT_TBL + " ( " + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[0] + ", " + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1] + ", "
						+ HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[2] + " ) VALUES (" + " ?, ?, ? " + " ) ";

				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				// �A���P�[�g�ԍ�
				pstmt.setString(1, enqueteNo);
				// �g�D�R�[�h
				pstmt.setString(2, soshikiCode);
				// �o�c�e�f�[�^
				if (bs == null) {
					pstmt.setNull(3, java.sql.Types.BLOB);
				} else {
					pstmt.setBytes(3, bs);
				}

				pstmt.executeUpdate();
			}
			// �f�[�^�����݂���
			else {
				// �o�c�e�X�V�r�p�k
				sql = " UPDATE " + HcdbDef.CPG_SOSHIKI_REPORT_TBL + " SET " + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[2] + " = ? " + " WHERE " + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[0] + " = ? " + " AND "
						+ HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1] + " = ? ";

				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();

				// �o�c�e�f�[�^
				if (bs == null) {
					pstmt.setNull(1, java.sql.Types.BLOB);
				} else {
					pstmt.setBytes(1, bs);
				}
				// �A���P�[�g�ԍ�
				pstmt.setString(2, enqueteNo);
				// �g�D�R�[�h
				pstmt.setString(3, soshikiCode);

				pstmt.executeUpdate();
			}

			Log.method(loginNo, "OUT", "");
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} catch (final Exception e) {
			this.sesContext.setRollbackOnly();
			Log.error(loginNo, "", e);
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * [�o�b�`�����󋵊Ǘ��F�X�e�[�^�X]���擾����
	 * @param loginNo
	 * @param enqueteNo
	 * @param type ���
	 * @return
	 */
	public boolean isBatchKanri(final String loginNo, final String enqueteNo, final String type) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";

		try {

			sql = "SELECT " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[3] + " FROM " + HcdbDef.CCP_BATCH_SHORI_KANRI_TBL + " WHERE " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[0] + "=? AND "
					+ HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[2] + "=? ";

			/* DB�ڑ��I�u�W�F�N�g�̊l�� */
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();

			/* �p�����[�^��ݒ� */
			pstmt.setString(1, enqueteNo);
			pstmt.setString(2, type);

			/* SQL�R�}���h�����s */
			rs = pstmt.executeQuery();

			/* �܂��������Ă��Ȃ� */
			if (!rs.next()) {
				return false;
			}

			/* �f�[�^���擾 */
			final int status = rs.getInt(HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[3]);

			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
			/* �������I�������A������Ԃ��폜 */
			if (status == 0) {
				sql = "DELETE FROM " + HcdbDef.CCP_BATCH_SHORI_KANRI_TBL + " WHERE " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[0] + "=? AND " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[1] + "=?";
				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();

				/* �p�����^�[��ݒ� */
				pstmt.setString(1, loginNo);
				pstmt.setString(2, enqueteNo);

				/* SQL�R�}���h�����s */
				pstmt.execute();
			}

			Log.method(loginNo, "OUT", "");
			if (status == 0) {
				return false;
			}
			return true;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * [�o�b�`�����󋵊Ǘ��F�X�e�[�^�X]���擾����
	 * @param loginNo
	 * @param enqueteNo
	 * @param type ���
	 * @return
	 */
	public String isBatchKanriAll(final String loginNo, final String enqueteNo, final String[] type) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";

		try {

			sql = "SELECT " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[3] + ", " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[2] + " " + " FROM " + HcdbDef.CCP_BATCH_SHORI_KANRI_TBL + " WHERE "
					+ HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[0] + "=? AND  ";
			sql += "  " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[2] + " IN (?";
			for (int i = 1, num = type.length; i < num; i++) {
				sql += ",?";
			}
			sql += " )";

			/* DB�ڑ��I�u�W�F�N�g�̊l�� */
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();

			/* �p�����[�^��ݒ� */
			pstmt.setString(1, enqueteNo);
			for (int i = 0, num = type.length; i < num; i++) {
				pstmt.setString(2 + i, type[i]);
			}
			/* SQL�R�}���h�����s */
			rs = pstmt.executeQuery();

			// �ُ펞�̒l���i�[����Ă���ꍇ
			while (rs.next()) {
				final String status = rs.getString(HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[3]);
				if ("2".equals(status)) {
					return rs.getString(HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[2]);
				}
			}

			return null;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * [�o�b�`�����󋵊Ǘ��F�X�e�[�^�X]���폜����
	 * @param loginNo
	 * @param enqueteNo
	 * @param type ���
	 * @return
	 */
	public boolean delBatchKanri(final String loginNo, final String enqueteNo, final String type) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		final ResultSet rs = null;
		String sql = "";

		try {

			sql = "DELETE FROM " + HcdbDef.CCP_BATCH_SHORI_KANRI_TBL + " WHERE " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[0] + "=? AND " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[1] + "=? AND "
					+ HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[2] + "=? ";

			/* DB�ڑ��I�u�W�F�N�g�̊l�� */
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();

			/* �p�����[�^��ݒ� */
			pstmt.setString(1, enqueteNo);
			pstmt.setString(2, loginNo);
			pstmt.setString(3, type);

			/* SQL�R�}���h�����s */
			pstmt.execute();

			return true;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}

	}

	/**
	 * /** [�o�b�`�����󋵊Ǘ��F�X�e�[�^�X]��ǉ�����
	 * @param loginNo
	 * @param enqueteNo
	 * @param type ���
	 * @param val
	 * @return
	 */
	public void createBatchStatus(final String loginNo, final String enqueteNo, final String type, final String val) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		final ResultSet rs = null;
		String sql = "";

		try {

			// �e�[�u�������b�N
			// �����̃X���b�h����Ă΂�邽�߁A������h��
			try {
				dbConn = PZZ040_SQLUtility.getConnection(loginNo);
				pstmt = dbConn.prepareStatement(MessageFormat.format("LOCK TABLE {0} IN EXCLUSIVE MODE", new Object[] { HcdbDef.CCP_BATCH_SHORI_KANRI_TBL }));
				pstmt.execute();
			} finally {
				pstmt.close();
			}

			/* DB�ڑ��I�u�W�F�N�g�̊l�� */

			sql = "DELETE FROM " + HcdbDef.CCP_BATCH_SHORI_KANRI_TBL + " WHERE " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[0] + "=? AND " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[2] + "=? ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();

			/* �p�����[�^��ݒ� */
			pstmt.setString(1, enqueteNo);
			pstmt.setString(2, type);
			/* SQL�R�}���h�����s */
			pstmt.execute();

			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
			/* SQL�R�}���h */
			sql = "INSERT INTO  " + HcdbDef.CCP_BATCH_SHORI_KANRI_TBL + " ( " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[0] + "," + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[1] + ","
					+ HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[2] + ", " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[3] + ", " + HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[4] + ", "
					+ HcdbDef.CCP_BATCH_SHORI_KANRI_COLUMNS[5] + ") VALUES (?,?,?,?,?,?)";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();

			/* �p�����[�^��ݒ� */
			pstmt.setString(1, enqueteNo);
			pstmt.setString(2, loginNo);
			pstmt.setString(3, type);
			pstmt.setString(4, val);

			pstmt.setString(5, PZZ010_CharacterUtil.GetDay());
			pstmt.setString(6, PZZ010_CharacterUtil.GetTime());
			/* SQL�R�}���h�����s */
			final int result = pstmt.executeUpdate();

			Log.method(loginNo, "OUT", "");
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}

	}

	/**
	 * �G���[CSV���_�E�����[�h����
	 * @param enqueteNo �A���P�[�g�ԍ�
	 * @param loginNo ���O�C���ԍ�
	 * @param sessionNo �Z�b�V����No
	 * @param types �_�E�����[�h�Ώ�
	 * @return
	 */
	public String errorCsvDownload(final String enqueteNo, final String loginNo, final String sessionNo, final String[] types) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "";

		try {
			sql = "SELECT " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[3] + " " + " FROM " + HcdbDef.CPP_TEXT_OUTPUT_TBL + " " + " WHERE " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[0] + "=? AND "
					+ HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[4] + "=?";

			if (types != null && types.length != 0) {
				sql += " AND " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[1] + " IN (";
				for (int i = 0; i < types.length; i++) {
					if (i != 0) {
						sql += ",";
					}
					sql += " ?";
				}
				sql += " ) ";
			}
			sql += " ORDER BY " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[2];

			/* DB�ڑ��I�u�W�F�N�g�̊l�� */
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();

			/* �p�����[�^��ݒ� */
			pstmt.setString(1, sessionNo);
			pstmt.setString(2, enqueteNo);
			if (types != null && types.length != 0) {
				for (int j = 0; j < types.length; j++) {
					pstmt.setString(j + 3, types[j]);
				}
			}

			/* SQL�R�}���h�����s */
			rs = pstmt.executeQuery();

			// CSV�Ń_�E�����[�h����f�[�^
			String csvStr = "";

			int cnt = 0;
			while (rs.next()) {
				// �o�̓e�L�X�g���擾
				String text = rs.getString(HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[3]);
				text = text != null ? text : "";

				// ��s�ڈȊO�͉��s�R�[�h��ǉ�
				if (cnt != 0) {
					csvStr += System.getProperty("line.separator");
				}

				// �i�[
				csvStr += text;
				cnt++;
			}

			Log.method(loginNo, "OUT", "");

			return csvStr;

		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �G���[CSV���폜����
	 * @param enqueteNo
	 * @param loginNo ���O�C���ԍ�
	 * @param sessionNo �Z�b�V����No
	 * @param types �폜�Ώ�
	 * @return
	 */
	public void deleteTextOutput(final String enqueteNo, final String loginNo, final String sessionNo, final String[] types) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		final ResultSet rs = null;

		String sql = "";

		try {
			sql = "DELETE FROM " + HcdbDef.CPP_TEXT_OUTPUT_TBL + " " + " WHERE " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[0] + "=?";
			if (enqueteNo != null) {
				sql += " AND " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[4] + "=?";
			}

			if (types != null && types.length != 0) {
				sql += " AND " + HcdbDef.CPP_TEXT_OUTPUT_COLUMNS[1] + " IN (";
				for (int i = 0; i < types.length; i++) {
					if (i != 0) {
						sql += ",";
					}
					sql += " ?";
				}
				sql += " ) ";
			}

			/* DB�ڑ��I�u�W�F�N�g�̊l�� */
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();

			/* �p�����[�^��ݒ� */
			pstmt.setString(1, sessionNo);
			if (enqueteNo != null) {
				pstmt.setString(2, enqueteNo);
			}
			if (types != null && types.length != 0) {
				for (int j = 0; j < types.length; j++) {
					if (enqueteNo != null) {
						pstmt.setString(j + 3, types[j]);
					} else {
						pstmt.setString(j + 2, types[j]);
					}
				}
			}

			/* SQL�R�}���h�����s */
			pstmt.executeUpdate();

			Log.method(loginNo, "OUT", "");

		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}
}
