/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.answer.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * �A���P�[�g��Bean�N���X
 * @author Shimura
 */
public class PED_QuestionnaireBean2 implements Serializable {

	// �A���P�[�g�R�����g
	private String enqueteComment = null;

	// ����̑S����
	private int totalEnquete = 0;

	// �񓚍ς̌���
	private int totalEnqueteKaito = 0;

	// �ŏI�񓚈ʒu�擾
	private int maxHyoji = 0;

	// �񓚓��e���i�[����ϐ�
	private ArrayList pveEnqueteKaitoKomokuBeanList = null;

	// �\���J�n�ʒu
	private int startHyoji = 0;

	// �\���I���ʒu
	private int endHyoji = 0;

	// ��ʂ�����̍ő�\������
	private int maxHyojiCnt = 0;

	// �y�[�W�ԍ�
	private int pageNo = 0;

	// �J�ڑO�y�[�W
	private String beforePage = null;

	// �G���[ID
	private String errorId = null;

	// �G���[���b�Z�[�W�Ɋi�[����ϕ�����
	private String kahen = null;

	// �e�[�u���T�C�Y
	private HashMap tableSize = null;

	public int getMaxHyojiCnt() {
		return this.maxHyojiCnt;
	}

	public void setMaxHyojiCnt(final int maxHyojiCnt) {
		this.maxHyojiCnt = maxHyojiCnt;
	}

	public int getPageNo() {
		return this.pageNo;
	}

	public void setPageNo(final int pageNo) {
		this.pageNo = pageNo;
	}

	public int getEndHyoji() {
		return this.endHyoji;
	}

	public void setEndHyoji(final int endHyoji) {
		this.endHyoji = endHyoji;
	}

	public int getStartHyoji() {
		return this.startHyoji;
	}

	public void setStartHyoji(final int startHyoji) {
		this.startHyoji = startHyoji;
	}

	/**
	 * �R���X�g���N�^
	 */
	public PED_QuestionnaireBean2() {
		this.pveEnqueteKaitoKomokuBeanList = new ArrayList();
	}

	public int getMaxHyoji() {
		return this.maxHyoji;
	}

	public void setMaxHyoji(final int maxHyoji) {
		this.maxHyoji = maxHyoji;
	}

	public int getTotalEnquete() {
		return this.totalEnquete;
	}

	public void setTotalEnquete(final int totalEnquete) {
		this.totalEnquete = totalEnquete;
	}

	public int getTotalEnqueteKaito() {
		return this.totalEnqueteKaito;
	}

	public void setTotalEnqueteKaito(final int totalEnqueteKaito) {
		this.totalEnqueteKaito = totalEnqueteKaito;
	}

	public ArrayList getPveEnqueteKaitoKomokuBeanList() {
		return this.pveEnqueteKaitoKomokuBeanList;
	}

	public void setPveEnqueteKaitoKomokuBeanList(final ArrayList pveEnqueteKaitoKomokuBeanList) {
		this.pveEnqueteKaitoKomokuBeanList = pveEnqueteKaitoKomokuBeanList;
	}

	public String getEnqueteComment() {
		return this.enqueteComment;
	}

	public void setEnqueteComment(final String enqueteComment) {
		this.enqueteComment = enqueteComment;
	}

	public String getBeforePage() {
		return this.beforePage;
	}

	public void setBeforePage(final String beforePage) {
		this.beforePage = beforePage;
	}

	public String getErrorId() {
		return this.errorId;
	}

	public void setErrorId(final String errorId) {
		this.errorId = errorId;
	}

	public HashMap getTableSize() {
		return this.tableSize;
	}

	public void setTableSize(final HashMap tableSize) {
		this.tableSize = tableSize;
	}

	public String getKahen() {
		return this.kahen;
	}

	public void setKahen(final String kahen) {
		this.kahen = kahen;
	}

}
