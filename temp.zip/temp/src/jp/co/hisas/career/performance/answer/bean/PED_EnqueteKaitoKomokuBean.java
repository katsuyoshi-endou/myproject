/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.answer.bean;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * �A���P�[�g��Bean�N���X
 * @author Shimura
 */
public class PED_EnqueteKaitoKomokuBean implements Serializable {

	// ��ʍ���ID
	private String gamenKomokuId = null;

	// ���ڃR�[�h
	private String komokuCode = null;

	// �\��No
	private int hyojiNo = 0;

	// �I�u�W�F�N�g�^�C�v
	private String objectType = null;

	// �񓚐�
	private int kaitoSu = 0;

	// �񓚓��e
	private ArrayList kaitoNaiyouList = null;

	private String kaitoNaiyou = null;

	// ���╶��
	private String shitsumonBunsho = null;

	// �񓚕���
	private ArrayList kaitoMongonList = null;

	public PED_EnqueteKaitoKomokuBean() {
		this.kaitoNaiyouList = new ArrayList();
		this.kaitoMongonList = new ArrayList();
	}

	public String getGamenKomokuId() {
		return this.gamenKomokuId;
	}

	public void setGamenKomokuId(final String gamenKomokuId) {
		this.gamenKomokuId = gamenKomokuId;
	}

	public ArrayList getKaitoMongonList() {
		return this.kaitoMongonList;
	}

	public void setKaitoMongonList(final ArrayList kaitoMongonList) {
		this.kaitoMongonList = kaitoMongonList;
	}

	public ArrayList getKaitoNaiyouList() {
		return this.kaitoNaiyouList;
	}

	public void setKaitoNaiyouList(final ArrayList kaitoNaiyouList) {
		this.kaitoNaiyouList = kaitoNaiyouList;
	}

	public int getKaitoSu() {
		return this.kaitoSu;
	}

	public void setKaitoSu(final int kaitoSu) {
		this.kaitoSu = kaitoSu;
	}

	public String getKomokuCode() {
		return this.komokuCode;
	}

	public void setKomokuCode(final String komokuCode) {
		this.komokuCode = komokuCode;
	}

	public String getObjectType() {
		return this.objectType;
	}

	public void setObjectType(final String objectType) {
		this.objectType = objectType;
	}

	public int getHyojiNo() {
		return this.hyojiNo;
	}

	public void setHyojiNo(final int hyojiNo) {
		this.hyojiNo = hyojiNo;
	}

	public String getShitsumonBunsho() {
		return this.shitsumonBunsho;
	}

	public void setShitsumonBunsho(final String shitsumonBunsho) {
		this.shitsumonBunsho = shitsumonBunsho;
	}

	public String getKaitoNaiyou() {
		return this.kaitoNaiyou;
	}

	public void setKaitoNaiyou(final String kaitoNaiyou) {
		this.kaitoNaiyou = kaitoNaiyou;
	}

}
