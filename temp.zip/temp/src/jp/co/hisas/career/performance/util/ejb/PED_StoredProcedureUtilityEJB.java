/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.util.ejb;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.ejb.EJBObject;
import javax.naming.NamingException;

public interface PED_StoredProcedureUtilityEJB extends EJBObject {

	public int execStoredProcedure(String sqlId, String[] arg01, String[] arg02, String[] arg03, String[] arg04, String[] arg05, String[] arg06, String[] arg07, String[] arg08, String[] arg09,
			String[] arg10, String loginNo, String sessionNo) throws RemoteException, SQLException, NamingException;

	/**
	 * [�o�b�`�����󋵊Ǘ��F�X�e�[�^�X]��ǉ�����
	 * @param loginNo
	 * @param enqueteNo
	 * @param type ���
	 * @return
	 */
	public void createBatchStatus(String loginNo, String enqueteNo, String type, String val) throws RemoteException, SQLException, NamingException;
}
