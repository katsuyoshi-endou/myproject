/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.answer.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.performance.answer.bean.PED_QuestionnaireAnswerBean;
import jp.co.hisas.career.performance.answer.bean.PED_QuestionnaireBean2;
import jp.co.hisas.career.performance.answer.bean.PED_QuestionnaireSelectionBean;
import jp.co.hisas.career.performance.maintenance.bean.PED_QuestionnaireAnkenKanriBean;
import jp.co.hisas.career.performance.util.bean.PED_PerformanceBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * VED110�T�[�u���b�g
 * @author Shimura
 */
public class PED210_QuestionnaireSelectionServlet extends HttpServlet {

	/** �G���[�y�[�W */
	private static final String ERROR_PAGE = "/view/base/error/VYY_Error.jsp";

	/** �J�ڐ�y�[�W */
	private static final String SUCCESS_PAGE = "/view/performance/answer/PVE210_Sentaku.jsp";

	private static final String FORWARD_PAGE = "/servlet/PED220_QuestionnaireAnswerServlet";

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/** �A�N�V������ێ����邽�߂̃L�[ */
	private static final String ACTION_KEY = "pve210_actionKey";

	/** [OK]�{�^���������̃A�N�V�����l */
	private static final String ACTION_OK = "action_ok";

	/**
	 * �������������s���B
	 * @param config
	 * @throws javax.servlet.ServletException
	 * @see javax.servlet.Servlet#init(javax.servlet.ServletConfig)
	 */
	public void init(final ServletConfig config) throws ServletException {
		super.init(config);

		// ���\�b�h�g���[�X�o��
		Log.method("", "IN", "");

		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
		// ���\�b�h�g���[�X�o��
		Log.method("", "OUT", "");
	}

	/**
	 * �u���E�U����̌����v�����󂯎��A�{�N���X�̎��s���\�b�h���Ăяo���܂��B
	 * @param request ���N�G�X�g
	 * @param response ���X�|���X
	 * @throws ServletException �T�[�u���b�g��O
	 * @throws IOException ���o�͗�O
	 * @see javax.servlet.http.HttpServlet#service( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse )
	 */
	protected void service(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {

		String login_no = null;

		String dispatcher = "";

		try {

			// ���[�U�̃A�N�V�������擾
			final String action = request.getParameter(PED210_QuestionnaireSelectionServlet.ACTION_KEY);

			/* session�X�R�[�v��Beans���擾���� */
			final HttpSession session = request.getSession(false);
			if (session == null) {
				this.ctx.getRequestDispatcher(PED210_QuestionnaireSelectionServlet.ERROR_PAGE).forward(request, response);
			} else {
				final UserInfoBean userinfobean = (UserInfoBean) session.getAttribute("userinfo");
				/* ���\�b�h�g���[�X�o�� */
				login_no = userinfobean.getLogin_no();
				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				// �Z�b�V���������擾
				PED_PerformanceBean sessionBean = (PED_PerformanceBean) session.getAttribute(PED_PerformanceBean.SESSION_KEY);

				final PED_QuestionnaireAnswerBean bean = new PED_QuestionnaireAnswerBean();
				final PED_QuestionnaireAnkenKanriBean qbean = new PED_QuestionnaireAnkenKanriBean(userinfobean.getLogin_no());

				String stat = "";
				final String value = PZZ010_CharacterUtil.changeQuotation(PZZ010_CharacterUtil.strEncode(request.getParameter("selectRadio")));

				PED_QuestionnaireSelectionBean selectionBean = null;

				if (!value.equals("")) {
					final int selectNo = new Integer(value).intValue();

					final ArrayList selectionBeanList = sessionBean.getQuestionnaireSelectionBeanList();

					selectionBean = (PED_QuestionnaireSelectionBean) selectionBeanList.get(selectNo);

					stat = qbean.getStatus(selectionBean.getEnqueteNo());
				}// <-

				// ��ʕ`�掞
				if (action == null) {
					sessionBean = new PED_PerformanceBean();
					final ArrayList sentakuList = bean.getSentakuLayout(login_no);
					sessionBean.setQuestionnaireSelectionBeanList(sentakuList);

					sessionBean.setalertMsgFlg(stat);
					// �񓚂̃��C�A�E�g���擾
					dispatcher = PED210_QuestionnaireSelectionServlet.SUCCESS_PAGE;
				}
				// [�n�j]�{�^��������
				else if (action.equals(PED210_QuestionnaireSelectionServlet.ACTION_OK)) {

					sessionBean.setViewPersonId(login_no);
					sessionBean.setEnqueteNo(selectionBean.getEnqueteNo());
					sessionBean.setEnqueteNm(selectionBean.getEnqueteNm());
					sessionBean.setQuestionnaireSelectionBeanList(null);
					final PED_QuestionnaireBean2 questionBean = new PED_QuestionnaireBean2();
					questionBean.setBeforePage("VED210");
					sessionBean.setPveQuestionnaireBean(questionBean);
					dispatcher = PED210_QuestionnaireSelectionServlet.FORWARD_PAGE;
					if (!"1".equals(stat)) {
						sessionBean = new PED_PerformanceBean();
						final ArrayList sentakuList = bean.getSentakuLayout(login_no);
						sessionBean.setQuestionnaireSelectionBeanList(sentakuList);

						sessionBean.setalertMsgFlg(stat);
						// �񓚂̃��C�A�E�g���擾
						dispatcher = PED210_QuestionnaireSelectionServlet.SUCCESS_PAGE;
						sessionBean.setJotaiErrorMsg((String) ReadFile.messageMapData.get("CPM-VED210-E001"));

					}
				}

				sessionBean.setalertMsgFlg(stat);

				/* �Z�b�V�����E�I�u�W�F�N�g���i�[������Bean�̃C���X�^���X���i�[���� */
				session.setAttribute(PED_PerformanceBean.SESSION_KEY, sessionBean);
				/* JSP�y�[�W���Ăяo�� */
				final RequestDispatcher rd = this.ctx.getRequestDispatcher(dispatcher);
				rd.forward(request, response);
				/* ���\�b�h�g���[�X�o�� */
				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher(PED210_QuestionnaireSelectionServlet.ERROR_PAGE).forward(request, response);
		}
	}
}
