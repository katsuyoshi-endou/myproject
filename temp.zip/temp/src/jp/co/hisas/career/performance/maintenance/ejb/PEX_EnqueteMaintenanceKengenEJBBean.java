/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

public class PEX_EnqueteMaintenanceKengenEJBBean implements SessionBean {

	private String login_no = "";

	/** �������p�Ǘ��e�[�u�� */
	private static final String kengenTbl = HcdbDef.kengenRiyouKanriTbl;

	/** �������p�Ǘ��e�[�u�� ����ID�J���� */
	private static final String kengenIdClm = "KENGEN_ID";

	/** �������p�Ǘ��e�[�u�� ����NO�J���� */
	private static final String simeiNoClm = "SIMEI_NO";

	/** �J�����F�������� */
	private static final String KANJI_SIMEI = "KANJI_SIMEI";

	/** �J�����F�g�D���� */
	private static final String SOSIKI_MEI = "BUSYO_RYAKUSYO_MEI";

	/** �J�����F�g�D�R�[�h */
	private static final String SOSIKI_CODE = "SOSIKI_CODE";

	/** �J�����F���E�ސE�t���O */
	private static final String GENSYOKU_TAISYOKU_FLG = "GENSYOKU_TAISYOKU_FLG";

	/** �������p�Ǘ��e�[�u�� �����I�v�V����ID�J���� */
	private static final String kengenOptionIdClm = "KENGEN_OPTION_ID";

	private static final int kengenTsuika = 0;

	private static final int kengenSakujo = 1;

	private static final int kengenKoshin = 2;

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}

	public void setSessionContext(final SessionContext arg0) throws EJBException, RemoteException {/* �������܂��� */
	}

	public void PED_AnkenTorokuKoshinBean(final String login_no) {
		this.login_no = login_no;
	}

	/**
	 * �������p�Ǘ��e�[�u������w�肵���Ј��ԍ��ƌ����������R�[�h���擾����
	 * @param simei_no
	 * @param kengenId
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 */
	public ArrayList getEnqueteMaintenanceKengenRecord(final String simei_no, final String kengenId) throws SQLException, NamingException {
		Log.method(this.login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);

			// �������R�[�h�擾SQL
			final String sql = "SELECT " + PEX_EnqueteMaintenanceKengenEJBBean.kengenIdClm + "," + PEX_EnqueteMaintenanceKengenEJBBean.simeiNoClm + ","
					+ PEX_EnqueteMaintenanceKengenEJBBean.kengenOptionIdClm + " FROM " + PEX_EnqueteMaintenanceKengenEJBBean.kengenTbl + " WHERE " + PEX_EnqueteMaintenanceKengenEJBBean.simeiNoClm
					+ " = ? AND " + PEX_EnqueteMaintenanceKengenEJBBean.kengenIdClm + " = ?";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, simei_no);
			pstmt.setString(2, kengenId);
			rs = pstmt.executeQuery();

			final ArrayList record = new ArrayList();

			// �擾���R�[�h���i�[
			while (rs.next()) {
				final String tmp[] = new String[3];
				tmp[0] = rs.getString(PEX_EnqueteMaintenanceKengenEJBBean.kengenIdClm);
				tmp[1] = rs.getString(PEX_EnqueteMaintenanceKengenEJBBean.simeiNoClm);
				tmp[2] = rs.getString(PEX_EnqueteMaintenanceKengenEJBBean.kengenOptionIdClm);
				record.add(tmp);
			}
			Log.method(this.login_no, "OUT", "");
			return record;
		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * �A���P�[�g�����e�i���X�������폜�E�ǉ�����
	 * @param simei_no �����ΏێЈ�NO
	 * @param kengenId ����ID
	 * @param opFlg �����t���O 0:�����ǉ� 1:�����폜
	 * @return int �����s��
	 * @throws SQLException
	 * @throws NamingException
	 */
	public int setEnqueteMaintenanceKengen(final String simei_no, final String kengenId, final int opFlg) throws SQLException, NamingException {
		Log.method(this.login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;

		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);

			String sql = "";

			if (opFlg == PEX_EnqueteMaintenanceKengenEJBBean.kengenSakujo) {
				// �����폜SQL
				sql = "DELETE FROM " + PEX_EnqueteMaintenanceKengenEJBBean.kengenTbl + " WHERE " + PEX_EnqueteMaintenanceKengenEJBBean.simeiNoClm + " = ? AND "
						+ PEX_EnqueteMaintenanceKengenEJBBean.kengenIdClm + " = ?";
				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				pstmt.setString(1, simei_no);
				pstmt.setString(2, kengenId);

			} else if (opFlg == PEX_EnqueteMaintenanceKengenEJBBean.kengenTsuika) {
				// �����ǉ�SQL
				sql = "INSERT INTO " + PEX_EnqueteMaintenanceKengenEJBBean.kengenTbl + "(" + PEX_EnqueteMaintenanceKengenEJBBean.simeiNoClm + "," + PEX_EnqueteMaintenanceKengenEJBBean.kengenIdClm
						+ ")" + " VALUES(?,?)";
				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				pstmt.setString(1, simei_no);
				pstmt.setString(2, kengenId);

			} else if (opFlg == PEX_EnqueteMaintenanceKengenEJBBean.kengenKoshin) {
				// �����X�VSQL
				sql = "UPDATE " + PEX_EnqueteMaintenanceKengenEJBBean.kengenTbl + " SET " + PEX_EnqueteMaintenanceKengenEJBBean.simeiNoClm + " = ?, " + PEX_EnqueteMaintenanceKengenEJBBean.kengenIdClm
						+ " = ?, " + PEX_EnqueteMaintenanceKengenEJBBean.kengenOptionIdClm + " = null" + " WHERE " + PEX_EnqueteMaintenanceKengenEJBBean.simeiNoClm + " = ?" + " AND "
						+ PEX_EnqueteMaintenanceKengenEJBBean.kengenIdClm + " = ?";
				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				pstmt.setString(1, simei_no);
				pstmt.setString(2, kengenId);
				pstmt.setString(3, simei_no);
				pstmt.setString(4, kengenId);

			}
			Log.method(this.login_no, "OUT", "");
			return pstmt.executeUpdate();

		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, null);
		}
	}

	/**
	 * �����t�^�ΏێЈ��������E�擾����
	 * @param targetShainNo �ΏۂƂ���Ј��̎���NO
	 * @param taisyokusyaKengen �ސE�ҎQ�ƌ���
	 * @return �Ј����n�b�V���}�b�v SIMEI,SOSIKI_MEI
	 */
	public HashMap getSyainInfo(final String targetShainNo, final String taisyokusyaKengen) throws SQLException, NamingException {
		Log.method(this.login_no, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);

			String sql = "";
			sql = "SELECT  trim(" + PEX_EnqueteMaintenanceKengenEJBBean.simeiNoClm + ")" + PEX_EnqueteMaintenanceKengenEJBBean.simeiNoClm + ", SUBSTR("
					+ PEX_EnqueteMaintenanceKengenEJBBean.KANJI_SIMEI + ",2)" + PEX_EnqueteMaintenanceKengenEJBBean.KANJI_SIMEI + ", sosiki." + PEX_EnqueteMaintenanceKengenEJBBean.SOSIKI_MEI
					+ " FROM " + HcdbDef.personalTbl + " personal," + HcdbDef.sosikiTbl + " sosiki " + " WHERE personal." + PEX_EnqueteMaintenanceKengenEJBBean.SOSIKI_CODE + " = sosiki."
					+ PEX_EnqueteMaintenanceKengenEJBBean.SOSIKI_CODE + " AND personal.HONMU_FLG = " + HcdbDef.HONMU + " AND " + PEX_EnqueteMaintenanceKengenEJBBean.simeiNoClm + " = ?";
			if (!taisyokusyaKengen.equals("1")) {
				sql += " AND " + PEX_EnqueteMaintenanceKengenEJBBean.GENSYOKU_TAISYOKU_FLG + " = '1' ";
			}

			pstmt = dbConn.prepareStatement(sql);
			pstmt.setString(1, targetShainNo);
			rs = pstmt.executeQuery();
			final HashMap syainInfo = new HashMap();
			while (rs.next()) {
				syainInfo.put("SIMEI_NO", rs.getString(1));
				syainInfo.put("KANJI_SIMEI", rs.getString(2));
				syainInfo.put("SOSIKI_MEI", rs.getString(3));
			}
			return syainInfo;

		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, null);
		}
	}

}
