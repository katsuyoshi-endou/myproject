/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.mail.internet.AddressException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_KensyuMailSender;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PCY321_ClassCyouseiIkkatuUketukeKanryoServlet �N���X �@�\�����F �N���X�����ꊇ��t�������s���܂��B
 * 
 * </PRE>
 */
public class PCY321_ClassCyouseiIkkatuUketukeKanryoServlet extends PCY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		final String count = request.getParameter("mousikomisya");
		int length = 0;

		if (count != null) {
			length = Integer.valueOf(count).intValue();
		}

		if (count != null) {
			final PCY_MousikomiJyokyoBean[] taisyosyaBeans = new PCY_MousikomiJyokyoBean[length];
			for (int i = 0; i < length; i++) {
				taisyosyaBeans[i] = new PCY_MousikomiJyokyoBean();
				final String index = Integer.toString(i);

				final PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean();
				mousikomiBean.setKamokuCode(request.getParameter("kamoku_code_" + index));
				mousikomiBean.setClassCode(request.getParameter("class_code_" + index));
				mousikomiBean.getClassBean().setKousinbi(request.getParameter("class_kousinbi_" + index));
				mousikomiBean.getClassBean().setKousinjikoku(request.getParameter("class_kousinjikoku_" + index));
				mousikomiBean.setSimeiNo(request.getParameter("simei_no_" + index));
				mousikomiBean.setKousinbi(request.getParameter("kousinbi_" + index));
				mousikomiBean.setKousinjikoku(request.getParameter("kousinjikoku_" + index));
				mousikomiBean.setStatus("1");
				mousikomiBean.setUketsukeJyotai("2");

				taisyosyaBeans[i] = mousikomiBean;
			}

			final PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
			final PCY_MousikomiJyokyoEJB ejb = home.create();

			Log.transaction(loginuser.getSimeiNo(), true, "");
			final int ret = ejb.doUpdateStatusAndUketukeIkkatu(taisyosyaBeans, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");

			/* �N���X�̌��� */
			final PCY_ClassEJBHome class_home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
			final PCY_ClassEJB class_ejb = class_home.create();

			final PCY_ClassBean[] kensaku_classBeans = new PCY_ClassBean[taisyosyaBeans.length];
			for (int i = 0; i < taisyosyaBeans.length; i++) {
				final PCY_ClassBean kensaku_classBean = new PCY_ClassBean();
				kensaku_classBean.setClassCode(taisyosyaBeans[i].getClassCode());
				kensaku_classBean.getKamokuBean().setKamokuCode(taisyosyaBeans[i].getKamokuCode());
				kensaku_classBeans[i] = kensaku_classBean;
			}

			final PCY_ClassBean[] classBeans = class_ejb.doSelectByPrimaryKey(kensaku_classBeans, loginuser);

			/* Mail���� */
			final String[] simei_no = new String[taisyosyaBeans.length];
			for (int i = 0; i < simei_no.length; i++) {
				simei_no[i] = taisyosyaBeans[i].getSimeiNo();
			}

			final PCY_PersonalEJBHome personalHome = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
			final PCY_PersonalEJB personalEjb = personalHome.create();
			final PCY_PersonalBean[] personalBeans = personalEjb.getPersonalInfo(simei_no, loginuser);

			int errorCount = 0;
			for (int t = 0; t < classBeans.length; t++) {

				if ("1".equals(classBeans[t].getAnnaiMailKubun()) && "0".equals(classBeans[t].getKisyoIkkatsuFlg())) {
					/* �N���X�}�X�^�̈ē����[���敪���f�v�f�̏ꍇ�A���[���𑗐M���� */
					try {
						/* ��t�����̏ꍇ */
						final PCY_PersonalBean[] send_personalBeans = new PCY_PersonalBean[1];
						send_personalBeans[0] = personalBeans[t];
						PCY_KensyuMailSender.sendKensyuKanrisyaUketukeKanryo(send_personalBeans, classBeans[t], loginuser);
					} catch (final AddressException e) {
						errorCount = 1;
					} catch (final Exception e) {
						errorCount = 1;
					}
				}
			}
			if (errorCount != 0) {
				request.setAttribute("warningID", "WCC110");
				throw new PCY_WarningException();
			}

		}
		try {
			OutLogBean.sousaKojinJohoLog("VCC303", loginuser.getSimeiNo(), null, request.getParameter("kamoku_code_0") + "," + request.getParameter("class_code_0"));
		} catch (final Exception e) {
		}
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

}
