/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.mail.internet.AddressException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_KensyuMailSender;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY142_SasimodosiServlet �N���X �@�\�����F ���F�ҍ��߂��������s���B
 * 
 * </PRE>
 */
public class PCY142_SasimodosiServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws CreateException, NamingException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		final PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_MousikomiJyokyoEJB ejb = home.create();
		final PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean(request);

		// �ȖځA�N���X���擾�p
		final PCY_ClassEJBHome classhome = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB classejb = classhome.create();

		final String[] simei_no = mousikomiBean.getSimeiNoArray();
		final String[] kamoku_code = mousikomiBean.getKamokuCodeArray();
		final String[] class_code = mousikomiBean.getClassCodeArray();
		final String[] kousinbi = request.getParameterValues("kousinbi");
		final String[] kousinjikoku = request.getParameterValues("kousinjikoku");

		final PCY_MousikomiJyokyoBean[] mousikomiBeans = new PCY_MousikomiJyokyoBean[simei_no.length];
		final PCY_ClassBean[] classBeancnd = new PCY_ClassBean[simei_no.length];
		PCY_ClassBean[] classBean;

		for (int i = 0; i < simei_no.length; i++) {
			PCY_KamokuBean kamokuBeancnd = new PCY_KamokuBean();
			kamokuBeancnd.setKamokuCode(kamoku_code[i]);

			classBeancnd[i] = new PCY_ClassBean();
			classBeancnd[i].setKamokuBean(kamokuBeancnd);
			classBeancnd[i].setClassCode(class_code[i]);
			kamokuBeancnd = null;
		}
		// �ȖځA�N���X���擾
		Log.transaction(loginuser.getSimeiNo(), true, "");
		classBean = classejb.doSelectByPrimaryKey(classBeancnd, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");
		// �}�X�^�ɑ��݂��Ȃ��ȖځA�N���X���܂܂�Ă���ꍇ
		if (classBean == null || classBean.length != simei_no.length) {
			throw new PCY_WarningException();
		}

		for (int i = 0; i < simei_no.length; i++) {
			// �C���X�^���X����
			mousikomiBeans[i] = new PCY_MousikomiJyokyoBean();
			// �K�v�ȏ����Z�b�g
			mousikomiBeans[i].setSimeiNo(simei_no[i]);
			mousikomiBeans[i].setClassBean(classBean[i]);
			mousikomiBeans[i].setKousinbi(kousinbi[i]);
			mousikomiBeans[i].setKousinjikoku(kousinjikoku[i]);
		}

		Log.transaction(loginuser.getSimeiNo(), true, "");
		ejb.doCancel(mousikomiBeans, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		/* �����߂����I�������A���߂����[���𑗐M���� */

		/* �N���X�����擾 */
		/* PersonalEJB */
		final PCY_PersonalEJBHome personal_home = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
		final PCY_PersonalEJB personal_ejb = personal_home.create();
		final PCY_PersonalBean[] personalBeans = personal_ejb.getPersonalInfo(mousikomiBean.getSimeiNoArray(), loginuser);

		/* �N���X�����擾 */
		/* ClassEJB */
		final PCY_ClassEJBHome class_home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB class_ejb = class_home.create();
		final PCY_ClassBean[] kensakuClassBeans = new PCY_ClassBean[mousikomiBean.getKamokuCodeArray().length];

		// HTML�R�����g���擾
		final String HTMLcomment = request.getParameter("HTMLcomment");
		// �e�L�X�g�R�����g���擾
		final String TEXTcomment = request.getParameter("TEXTcomment");

		for (int i = 0; i < kensakuClassBeans.length; i++) {
			kensakuClassBeans[i] = new PCY_ClassBean();
			kensakuClassBeans[i].getKamokuBean().setKamokuCode(mousikomiBean.getKamokuCodeArray()[i]);
			kensakuClassBeans[i].setClassCode(mousikomiBean.getClassCodeArray()[i]);
		}

		final PCY_ClassBean[] classBeans = class_ejb.doSelectByPrimaryKey(kensakuClassBeans, loginuser);

		try {
			/* ���C�҂Ƀ��[���𑗐M���� */
			PCY_KensyuMailSender.sendSyoninsyaSasimodosi(personalBeans, classBeans, HTMLcomment, TEXTcomment, loginuser); // For Syanai
		} catch (final AddressException e) {
			request.setAttribute("warningID", "WCB110");
			throw new PCY_WarningException(e);
		} catch (final Exception e) {
			request.setAttribute("warningID", "WCB110");
			throw new PCY_WarningException(e);
		}

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
