/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_KensyuRirekiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KensyuRirekiEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PCY242_NinteiTourokuSetteiServlet �N���X �@�\�����F �F��o�^�ݒ���s���܂��B
 * 
 * </PRE>
 */
public class PCY242_NinteiTourokuSetteiServlet extends PCY010_ControllerServlet {
	/**
	 * �F��o�^�ݒ���s���܂��B �E�����ԍ� �E�ȖڃR�[�h �E�N���X�R�[�h
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		final String simeNo = request.getParameter("simei_no");
		final String kamokuCode = request.getParameter("kamoku_code");
		final String classCode = request.getParameter("class_code");

		/* KensyuRirekiEJB */
		final PCY_KensyuRirekiEJBHome kensyuRireki_home = (PCY_KensyuRirekiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KensyuRirekiEJBHome.class);
		final PCY_KensyuRirekiEJB kensyuRireki_ejb = kensyuRireki_home.create();

		Log.transaction(loginuser.getSimeiNo(), true, "");
		kensyuRireki_ejb.doInsertNinteiTouroku(kamokuCode, classCode, simeNo, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");
		try {
			OutLogBean.sousaKojinJohoLog("VCC182", loginuser.getSimeiNo(), null, request.getParameter("kamoku_code") + "," + request.getParameter("class_code"));
		} catch (final Exception e) {
		}
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
