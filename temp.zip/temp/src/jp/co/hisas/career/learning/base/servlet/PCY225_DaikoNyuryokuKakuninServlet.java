package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaExBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY225_DaikoNyuryokuKakuninServlet �N���X �@�\�����F ��s���͓o�^���s���܂��B
 * 
 * </PRE>
 */
public class PCY225_DaikoNyuryokuKakuninServlet extends PCY010_ControllerServlet {
	/**
	 * ��s���͓o�^���s���܂��B
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, SQLException,
			RemoteException, PCY_WarningException {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		// ���p����EJB�𐶐�
		final PCY_ClassEJBHome class_home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_PersonalEJBHome personal_home = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
		final PCY_ClassEJB class_ejb = class_home.create();
		final PCY_PersonalEJB personal_ejb = personal_home.create();
		
		PCY_ClassBean classBean = new PCY_ClassBean(request);
		classBean = class_ejb.doSelectByPrimaryKey(classBean, loginuser);
		
		final String uketsuke_jyotai = request.getParameter("S001_uketsuke_jyotai");
		final String[] checked = request.getParameterValues("C002_check");

		PCY_TaisyosyaExBean[] taisyosyaBeans = new PCY_TaisyosyaExBean[checked.length];
		for (int i = 0; i < checked.length; i++) {
			final String index = checked[i];

			taisyosyaBeans[i] = new PCY_TaisyosyaExBean();
			
			String simeiNo = request.getParameter("H003_simei_no_" + index);
			taisyosyaBeans[i].setPersonalBean(personal_ejb.getGensyokuPersonalInfo(simeiNo, loginuser));
			taisyosyaBeans[i].setTaisyoKubun(request.getParameter("H004_taisyo_kubun_" + index));
			taisyosyaBeans[i].setMousikomiJyokyo(request.getParameter("H005_mousikomiJyokyo_" + index));
			taisyosyaBeans[i].setJyukoJyokyo(request.getParameter("H006_jyukoJyokyo_" + index));
		}
		
		request.setAttribute("uketsuke_jyotai", uketsuke_jyotai);
		request.setAttribute("taisyosyaBeans", taisyosyaBeans);
		request.setAttribute("classBean", classBean);
		
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
