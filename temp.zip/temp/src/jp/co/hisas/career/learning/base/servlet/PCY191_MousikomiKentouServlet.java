/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 * 
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/01/27  01.00       ���� �a��    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY191_MousikomiKentouServlet �N���X �@�\�����F �N���X�̈ꗗ���擾���܂��B
 * 
 * </PRE>
 */
public class PCY191_MousikomiKentouServlet extends PCY010_ControllerServlet {

	/**
	 * �\�����������{���܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean )
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {

		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.transaction(loginuser.getSimeiNo(), true, "");

		// �N���X���擾
		final PCY_ClassEJBHome home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB ejb = home.create();

		Log.performance(loginuser.getSimeiNo(), true, "");
		final PCY_ClassBean classBean = ejb.doSelectByPrimaryKey(new PCY_ClassBean(request), loginuser);
		Log.performance(loginuser.getSimeiNo(), false, "");

		final HttpSession session = request.getSession();
		// �Z�b�V���������ɐ\���������s���Ă���N���X���擾
		ArrayList mousikomiKentouList = (ArrayList) session.getAttribute("mousikomiKentouList");
		// �\���������s���Ă��Ȃ��ꍇ
		if (mousikomiKentouList == null) {
			mousikomiKentouList = new ArrayList();
		}

		mousikomiKentouList.add(classBean);
		final PCY_ClassBean[] mousikomiKentouBeans = (PCY_ClassBean[]) mousikomiKentouList.toArray(new PCY_ClassBean[0]);
		final ArrayList newList = new ArrayList();
		// �\�[�g
		Arrays.sort(mousikomiKentouBeans, new MousikomiKentouComparator());
		for (int i = 0; i < mousikomiKentouBeans.length; i++) {
			newList.add(mousikomiKentouBeans[i]);
		}
		session.setAttribute("mousikomiKentouList", newList);

		Log.transaction(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

	/**
	 * �ȖڃO���[�v���A�ȖڃR�[�h�A�J�n���A�I�������L�[�Ƀ\�[�g���܂��B
	 */
	private class MousikomiKentouComparator implements Comparator {
		public int compare(final Object o1, final Object o2) {
			final PCY_ClassBean class1 = (PCY_ClassBean) o1;
			final PCY_ClassBean class2 = (PCY_ClassBean) o2;

			if ((class1.getKamokuBean().getKamokuGroup() != null) && (class2.getKamokuBean().getKamokuGroup() != null)) {
				if (class1.getKamokuBean().getKamokuGroup().equals(class2.getKamokuBean().getKamokuGroup())) {
					if (class1.getKamokuBean().getKamokuCode().equals(class2.getKamokuBean().getKamokuCode())) {
						if (class1.getKaisibi().equals(class2.getKaisibi())) {
							return class1.getSyuryobi().compareTo(class2.getSyuryobi());
						}
						return class1.getKaisibi().compareTo(class2.getKaisibi());
					}
					return class1.getKamokuBean().getKamokuCode().compareTo(class2.getKamokuBean().getKamokuCode());
				}
				return class1.getKamokuBean().getKamokuGroup().compareTo(class2.getKamokuBean().getKamokuGroup());
			} else if ((class1.getKamokuBean().getKamokuGroup() != null) && (class2.getKamokuBean().getKamokuGroup() == null)) {
				return -1;
			} else if ((class1.getKamokuBean().getKamokuGroup() == null) && (class2.getKamokuBean().getKamokuGroup() != null)) {
				return 1;
			} else {
				if (class1.getKamokuBean().getKamokuCode().equals(class2.getKamokuBean().getKamokuCode())) {
					if (class1.getKaisibi().equals(class2.getKaisibi())) {
						return class1.getSyuryobi().compareTo(class2.getSyuryobi());
					}
					return class1.getKaisibi().compareTo(class2.getKaisibi());
				}
				return class1.getKamokuBean().getKamokuCode().compareTo(class2.getKamokuBean().getKamokuCode());
			}
		}

	}
}
