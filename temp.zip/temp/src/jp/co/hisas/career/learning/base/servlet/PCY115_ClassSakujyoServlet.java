/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY115_ClassSakujyoServlet �N���X �@�\�����F �N���X�̈ꗗ���擾���܂��B
 * 
 * </PRE>
 */
public class PCY115_ClassSakujyoServlet extends PCY010_ControllerServlet {
	/**
	 * ���N�G�X�g����v���C�}���L�[���擾���A�Ȗڏ����폜���܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean )
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		final PCY_ClassEJBHome home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB ejb = home.create();
		final Collection classBeans = new ArrayList();
		final String[] classCodeList = request.getParameterValues("class_code");
		final String[] tourokubiList = request.getParameterValues("tourokubi");
		final String[] tourokujikokuList = request.getParameterValues("tourokujikoku");
		final String[] tourokusyaList = request.getParameterValues("tourokusya");
		final String[] kousinbiList = request.getParameterValues("kousinbi");
		final String[] kousinjikokuList = request.getParameterValues("kousinjikoku");
		final String[] kousinsyaList = request.getParameterValues("kousinsya");
		final String[] kaisaijyotaiList = request.getParameterValues("kaisai_jyotai");

		for (int i = 0; i < classCodeList.length; i++) {
			final PCY_ClassBean classBean = new PCY_ClassBean(request);
			classBean.setClassCode(classCodeList[i]);
			classBean.setTourokubi(tourokubiList[i]);
			classBean.setTourokujikoku(tourokujikokuList[i]);
			classBean.setTourokusya(tourokusyaList[i]);
			classBean.setKousinbi(kousinbiList[i]);
			classBean.setKousinjikoku(kousinjikokuList[i]);
			classBean.setKousinsya(kousinsyaList[i]);
			classBean.setKaisaiJyotai(kaisaijyotaiList[i]);
			classBeans.add(classBean);
		}

		try {
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doDelete((PCY_ClassBean[]) classBeans.toArray(new PCY_ClassBean[0]), loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");
		} catch (final PCY_WarningException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			/* ���C�����e�[�u���ɍ폜�Ώۂ̃N���X�����݂���ꍇ */
			if (e.getMessage().equals("WCC010")) {
				request.setAttribute("warningID", "WCC010");
				throw e;
			} else if (e.getMessage().equals("WCC080")) {
				request.setAttribute("warningID", "WCC080");
				throw e;
			}
		}

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
