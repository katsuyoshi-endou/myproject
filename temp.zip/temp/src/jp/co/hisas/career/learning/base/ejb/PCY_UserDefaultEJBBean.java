/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.valuebean.PCY_DefaultBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * �N���X���F PCY_UserDefaultEJBBean�N���X �@�\�����F ���[�U�[�f�t�H���g�ւ̑�����s���܂��B
 * @ejb.bean name="PCY_UserDefaultEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_UserDefaultEJBBean implements SessionBean {
	private SessionContext context = null;

	/** L56_���[�U�f�t�H���g�Ƀf�[�^��ǉ�����SQL */
	private static final String INSERT_L56_SQL = "INSERT INTO L56_USER_DEFAULT_TBL (SIMEI_NO, GAMEN_ID, KOUMOKU_ID, DEFAULT_VALUE) VALUES (?, ?, ?, ?)";

	/**
	 * �����ԍ����烆�[�U�[�f�t�H���g���擾���܂��B
	 * @param simei_no �����ԍ�
	 * @param loginuser ���O�C�����[�U�̎����ԍ�
	 * @return ���C�ҏ��ꗗ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_DefaultBean[] doSelect(final String simei_no, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final StringBuffer sql = new StringBuffer();
			sql.append(" SELECT ");
			sql.append(" SIMEI_NO , ");
			sql.append(" GAMEN_ID , ");
			sql.append(" KOUMOKU_ID , ");
			sql.append(" DEFAULT_VALUE ");
			sql.append(" FROM ");
			sql.append(HcdbDef.L56_TBL);
			sql.append(" WHERE SIMEI_NO=? ");
			sql.append(" ORDER BY GAMEN_ID DESC, KOUMOKU_ID DESC");

			/* �f�o�b�O���O */
			Log.debug(sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");
			// SQL�ݒ�
			ps = con.prepareStatement(sql.toString());

			/* �����������Z�b�g���� */
			ps.setString(1, simei_no);

			/* ���擾 */
			rs = ps.executeQuery();

			final ArrayList ret = new ArrayList();

			while (rs.next()) {
				final PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setSimeiNo(rs.getString("SIMEI_NO"));
				UserDefaultBean.setGamenId(rs.getString("GAMEN_ID"));
				UserDefaultBean.setKoumokuId(rs.getString("KOUMOKU_ID"));
				UserDefaultBean.setDefaultValue(rs.getString("DEFAULT_VALUE"));
				ret.add(UserDefaultBean);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return (PCY_DefaultBean[]) ret.toArray(new PCY_DefaultBean[0]);
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * ���[�U�[�f�t�H���g�e�[�u���̒ǉ����s�Ȃ��B
	 * @param userDefaultBeans �ǉ����
	 * @param loginuser ���O�C�����[�U���
	 * @return �ǉ�����
	 * @exception NamingException ���O�����Ɏ��s�����ꍇ
	 * @exception SQLException
	 * @exception PCY_WarningException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doInsert(final PCY_DefaultBean[] userDefaultBeans, final PCY_PersonalBean loginuser) throws NamingException, SQLException, PCY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			int count = 0;

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");
			// SQL�ݒ�
			ps = con.prepareStatement(PCY_UserDefaultEJBBean.INSERT_L56_SQL);
			for (int i = 0; i < userDefaultBeans.length; i++) {
				/* �f�o�b�O���O */
				Log.debug(PCY_UserDefaultEJBBean.INSERT_L56_SQL);

				// SQL���s
				ps.setString(1, userDefaultBeans[i].getSimeiNo());
				ps.setString(2, userDefaultBeans[i].getGamenId());
				ps.setString(3, userDefaultBeans[i].getKoumokuId());
				ps.setString(4, userDefaultBeans[i].getDefaultValue());

				count += ps.executeUpdate();

				if (count == 0) {
					this.context.setRollbackOnly();
					throw new PCY_WarningException("�ǉ��\�萔�ƁA�ǉ������������܂���ł����B");
				}

				// ���\�b�h�g���[�X�o��
				Log.method(loginuser.getSimeiNo(), "OUT", "");
			}

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			this.context.setRollbackOnly();
			throw e;
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			this.context.setRollbackOnly();
			throw e;
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			this.context.setRollbackOnly();
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * ���[�U�[�f�t�H���g�e�[�u�����폜���܂��B
	 * @param simeiNo ����No
	 * @param loginuser ���O�C�����[�U���
	 * @return �폜����
	 * @exception NamingException ���O�����Ɏ��s�����ꍇ
	 * @exception SQLException
	 * @exception PCY_WarningException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doDelete(final String simeiNo, final PCY_PersonalBean loginuser) throws NamingException, SQLException, PCY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			int count = 0;

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// SQL�쐬
			final StringBuffer sql = new StringBuffer();
			sql.append("DELETE ");
			sql.append(HcdbDef.L56_TBL);
			sql.append(" WHERE ");
			sql.append(" SIMEI_NO=? ");

			/* �f�o�b�O���O */
			Log.debug(sql.toString());

			ps = con.prepareStatement(sql.toString());
			ps.setString(1, simeiNo);

			count += ps.executeUpdate();

			if (count == 0) {
				this.context.setRollbackOnly();
				throw new PCY_WarningException("�폜�\�萔�ƁA�폜�����������܂���ł����B");
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			this.context.setRollbackOnly();
			throw e;
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			this.context.setRollbackOnly();
			throw e;
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			this.context.setRollbackOnly();
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * ���ID���̏������[�U�[�f�t�H���g�e�[�u�����擾���A PCY_DefaultBean�Ɋi�[���ĕԂ��܂��B
	 * @param simeiNo ����No
	 * @param gamenID ���ID
	 * @param loginuser ���O�C�����[�U���
	 * @return �폜����
	 * @exception NamingException ���O�����Ɏ��s�����ꍇ
	 * @exception SQLException
	 * @exception PCY_WarningException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_DefaultBean doGetData(final String simeiNo, final String gamenID, final PCY_PersonalBean loginuser) throws NamingException, RemoteException, CreateException, PCY_WarningException {
		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// EJBHome�Ǘ��N���X�̎擾
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();

			final PCY_UserDefaultEJBHome home = (PCY_UserDefaultEJBHome) fact.lookup(PCY_UserDefaultEJBHome.class);
			final PCY_UserDefaultEJB ejb = home.create();

			final PCY_DefaultBean defaultBean = new PCY_DefaultBean();

			// �w�胆�[�U�[�̏����擾
			final PCY_DefaultBean[] userDefaults = ejb.doSelect(simeiNo, loginuser);

			for (int i = 0; i < userDefaults.length; i++) {
				defaultBean.setSimeiNo(simeiNo);
				// ���C�Ǘ����
				if (userDefaults[i].getGamenId().trim().equals("VCC010")) {
					defaultBean.setGamenId("VCC010");
					// ���{�`��
					if (userDefaults[i].getKoumokuId().trim().equals("1")) {
						defaultBean.setCategoryCode1(userDefaults[i].getDefaultValue());
					}
					// ����^�Վ�
					if (userDefaults[i].getKoumokuId().trim().equals("2")) {
						defaultBean.setCategoryCode2(userDefaults[i].getDefaultValue());
					}
					// �\�[�g
					if (userDefaults[i].getKoumokuId().trim().equals("3")) {
						defaultBean.setSort(userDefaults[i].getDefaultValue());
					}
					// �Ȗڕ��ނR
					if (userDefaults[i].getKoumokuId().trim().equals("4")) {
						defaultBean.setCategoryCode3(userDefaults[i].getDefaultValue());
					}
					// �n��
					if (userDefaults[i].getKoumokuId().trim().equals("5")) {
						defaultBean.setChikuCode(userDefaults[i].getDefaultValue());
					}
					// �Ǘ���
					if (userDefaults[i].getKoumokuId().trim().equals("6")) {
						defaultBean.setKanrimotoCode(userDefaults[i].getDefaultValue());
					}
					// �����ꊇ
					if (userDefaults[i].getKoumokuId().trim().equals("7")) {
						defaultBean.setKisyoIkkatsuFlg(userDefaults[i].getDefaultValue());
					}
				}
				// ���ѓ���
				if (userDefaults[i].getGamenId().equals("VCC070")) {
					defaultBean.setGamenId("VCC070");
					// ��_
					if (userDefaults[i].getKoumokuId().trim().equals("1")) {
						defaultBean.setKijyunten(userDefaults[i].getDefaultValue());
					}
					// �C������
					if (userDefaults[i].getKoumokuId().trim().equals("2")) {
						defaultBean.setSyuryoHantei(userDefaults[i].getDefaultValue());
					}
				}
				// �Ȗړo�^
				if (userDefaults[i].getGamenId().equals("VCC080")) {
					defaultBean.setGamenId("VCC080");
					// �Ǘ���
					if (userDefaults[i].getKoumokuId().trim().equals("1")) {
						defaultBean.setKamokuKanrimotoCode(userDefaults[i].getDefaultValue());
					}
					// ���{�`��
					if (userDefaults[i].getKoumokuId().trim().equals("2")) {
						defaultBean.setKamokuCategoryCode1(userDefaults[i].getDefaultValue());
					}
					// ����^�Վ�
					if (userDefaults[i].getKoumokuId().trim().equals("3")) {
						defaultBean.setKamokuCategoryCode2(userDefaults[i].getDefaultValue());
					}
					// �Ȗڕ��ނR
					if (userDefaults[i].getKoumokuId().trim().equals("4")) {
						defaultBean.setKamokuCategoryCode3(userDefaults[i].getDefaultValue());
					}
				}
				// �N���X�o�^
				if (userDefaults[i].getGamenId().equals("VCC090")) {
					defaultBean.setGamenId("VCC090");
					// �N���X�R�[�h
					if (userDefaults[i].getKoumokuId().trim().equals("1")) {
						defaultBean.setClassClassCode(userDefaults[i].getDefaultValue());
					}
					// �\���敪
					if (userDefaults[i].getKoumokuId().trim().equals("2")) {
						defaultBean.setClassMousikomiKubun(userDefaults[i].getDefaultValue());
					}
					// ���F�敪
					if (userDefaults[i].getKoumokuId().trim().equals("3")) {
						defaultBean.setClassSyoninKubun(userDefaults[i].getDefaultValue());
					}
					// ��t�敪
					if (userDefaults[i].getKoumokuId().trim().equals("4")) {
						defaultBean.setClassUketukeKubun(userDefaults[i].getDefaultValue());
					}
					// �񍐋敪
					if (userDefaults[i].getKoumokuId().trim().equals("5")) {
						defaultBean.setClassHoukokuKubun(userDefaults[i].getDefaultValue());
					}
					// ����敪
					if (userDefaults[i].getKoumokuId().trim().equals("6")) {
						defaultBean.setClassHanteiKubun(userDefaults[i].getDefaultValue());
					}
					// �����ꊇ
					if (userDefaults[i].getKoumokuId().trim().equals("7")) {
						defaultBean.setClassKisyoIkkatsuFlg(userDefaults[i].getDefaultValue());
					}
					// �S��
					if (userDefaults[i].getKoumokuId().trim().equals("8")) {
						defaultBean.setClassZensyaTaisyoFlg(userDefaults[i].getDefaultValue());
					}
					// ����
					if (userDefaults[i].getKoumokuId().trim().equals("9")) {
						defaultBean.setClassMansekiFlg(userDefaults[i].getDefaultValue());
					}
					// �n��
					if (userDefaults[i].getKoumokuId().trim().equals("10")) {
						defaultBean.setClassChikuCode(userDefaults[i].getDefaultValue());
					}
					// �u�t
					if (userDefaults[i].getKoumokuId().trim().equals("11")) {
						defaultBean.setClassKousiCode(userDefaults[i].getDefaultValue());
					}
					// ����
					if (userDefaults[i].getKoumokuId().trim().equals("12")) {
						defaultBean.setClassKyosituCode(userDefaults[i].getDefaultValue());
					}
					// �ē����[��
					if (userDefaults[i].getKoumokuId().trim().equals("13")) {
						defaultBean.setClassAnnaiMailKubun(userDefaults[i].getDefaultValue());
					}
					// �t�H���[���[��
					if (userDefaults[i].getKoumokuId().trim().equals("14")) {
						defaultBean.setClassFollowMailKubun(userDefaults[i].getDefaultValue());
					}
				}
			}
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return defaultBean;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RemoteException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		}
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
}
