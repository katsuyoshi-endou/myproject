/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_KensyuRirekiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KensyuRirekiEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F ���C���X�V�T�[�u���b�g�N���X �@�\�����F ���C���i�����j�̍X�V���s���܂��B
 * 
 * </PRE>
 */
public class PCY128_KensyuJyohouKousinServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		final PCY_KensyuRirekiBean rirekiBean = new PCY_KensyuRirekiBean(request);
		rirekiBean.setSimeiNo(loginuser.getSimeiNo());

		final PCY_KensyuRirekiBean[] rirekiBeans = new PCY_KensyuRirekiBean[1];
		rirekiBeans[0] = rirekiBean;

		// EJB�擾
		final PCY_KensyuRirekiEJBHome home = (PCY_KensyuRirekiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KensyuRirekiEJBHome.class);
		final PCY_KensyuRirekiEJB ejb = home.create();

		ejb.doUpdate(rirekiBeans, loginuser);

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();
	}
}
