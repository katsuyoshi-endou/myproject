/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.VelocityHelper;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassCyouseiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassCyouseiEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassCyouseiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �T�v: �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A �N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PCY340_CSVOutputServlet extends PCY010_ControllerServlet {

	/**
	 * �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
	 * @param response Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet�̐���ȏ������W����ꂽ���ɔ��������O
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) {

		try {

			/* ���O�C�����[�U�̎����ԍ��擾 */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			/* request �������擾 */
			final PCY_ClassCyouseiBean classCyousei = new PCY_ClassCyouseiBean();
			final String[] checked = request.getParameterValues("C001_class_cyousei");

			// EJBHome�Ǘ��N���X�̎擾
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PCY_ClassCyouseiEJBHome home = (PCY_ClassCyouseiEJBHome) fact.lookup(PCY_ClassCyouseiEJBHome.class);
			final PCY_ClassCyouseiEJB ejb = home.create();

			final List list = new ArrayList();

			for (int i = 0; i < checked.length; i++) {
				final String index = checked[i];
				classCyousei.setSyoribi(request.getParameter("H001_syoribi_" + index));
				classCyousei.setSyorijikoku(request.getParameter("H002_syorijikoku_" + index));
				classCyousei.setSyorisya(request.getParameter("H003_syorisya_" + index));
				classCyousei.setSyoriFlg(request.getParameter("H004_soriFlg_" + index));

				/* ���� */
				final PCY_ClassCyouseiBean[] classCoseiBeans1 = ejb.doSelect(classCyousei, loginuser);

				/* �_�E�����[�h�񐔍X�V */
				ejb.doUpdate(classCoseiBeans1, loginuser);

				for (int t = 0; t < classCoseiBeans1.length; t++) {
					list.add(classCoseiBeans1[t]);
				}

			}

			PCY_ClassCyouseiBean[] classCoseiBeans = new PCY_ClassCyouseiBean[list.size()];
			classCoseiBeans = (PCY_ClassCyouseiBean[]) list.toArray(classCoseiBeans);

			/* �_�E�����[�h�t�@�C�����擾 */
			final String csvFileName = HcdbDef.CLASSCYOSEIRIREKI_CSV_FILENAME;
			final String fileName = PZZ010_CharacterUtil.getDayTime() + "_" + csvFileName + ".csv";

			final Vector lines = new Vector();
			for (int i = 0; i < classCoseiBeans.length; i++) {
				final Vector columns = new Vector();
				/* �l���擾 */
				columns.add(classCoseiBeans[i].getSyoribi());
				columns.add(classCoseiBeans[i].getSyorijikoku());
				columns.add(classCoseiBeans[i].getSyorisya());
				columns.add(classCoseiBeans[i].getSyoriFlg());
				columns.add(classCoseiBeans[i].getDlKaisu().toString());
				columns.add(classCoseiBeans[i].getKamokuCode());
				columns.add(classCoseiBeans[i].getClassCode());
				columns.add(classCoseiBeans[i].getSimeiNo());
				columns.add(classCoseiBeans[i].getBeforeStatus());
				columns.add(classCoseiBeans[i].getBeforeUketsukeJyotai());
				columns.add(classCoseiBeans[i].getAfterStatus());
				columns.add(classCoseiBeans[i].getAfterUketukeJyotai());
				columns.add(classCoseiBeans[i].getMousikomibi());
				columns.add(classCoseiBeans[i].getMousikomijikoku());
				columns.add(classCoseiBeans[i].getMousikomisya());
				columns.add(classCoseiBeans[i].getSyoninbi1());
				columns.add(classCoseiBeans[i].getSyoninjikoku1());
				columns.add(classCoseiBeans[i].getSyoninsya1());
				columns.add(classCoseiBeans[i].getSyoninbi2());
				columns.add(classCoseiBeans[i].getSyoninjikoku2());
				columns.add(classCoseiBeans[i].getSyoninsya2());
				columns.add(classCoseiBeans[i].getUketukebi());
				columns.add(classCoseiBeans[i].getUketukejikoku());
				columns.add(classCoseiBeans[i].getUketukesya());
				lines.add(columns);
			}

			/* �w�b�_�������� */
			final VelocityHelper vh = new VelocityHelper("VCC340");
			vh.setParameter("lines", lines);
			final Writer w = vh.getWriter();
			final ByteArrayInputStream bais = new ByteArrayInputStream(w.toString().getBytes());
			request.setAttribute("H080_FileName", fileName);
			request.setAttribute("H081_ContentType", HcdbDef.CONTENT_TYPE);
			request.setAttribute("STREAM", bais);

			Log.performance(loginuser.getSimeiNo(), false, "");
			Log.method(loginuser.getSimeiNo(), "OUT", "");
		} catch (final IOException e) {
			Log.error("", e);
		} catch (final Exception e) {
			Log.error("", e);
		}

		return this.getForwardPath();
	}
}