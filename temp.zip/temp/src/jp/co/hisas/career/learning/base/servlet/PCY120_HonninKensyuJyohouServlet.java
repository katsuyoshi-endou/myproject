/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.bean.PCY_HonninKensyuJyohouBean;
import jp.co.hisas.career.learning.base.ejb.PCY_HonninKensyuJyohouEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_HonninKensyuJyohouEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuJouhouBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_SearchKeyBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F �{�l���C���T�[�u���b�g�N���X �@�\�����F �{�l���C�����������A���C���̈ꗗ�\�����s���B
 * 
 * </PRE>
 */
public class PCY120_HonninKensyuJyohouServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		/* �����������i�[���� */
		final PCY_SearchKeyBean searchKey = new PCY_SearchKeyBean(request);

		/* �ȖڃR�[�h�J���}��؂��z��ɂ��� */
		if (searchKey.getKamokuCodes() != null && searchKey.getKamokuCodes().length == 1) {
			final String kamokuCodesLineTemp = searchKey.getKamokuCodes()[0];
			final String[] kamokuCodesTemp = kamokuCodesLineTemp.split(",");

			for (int i = 0; i < kamokuCodesTemp.length; i++) {
				kamokuCodesTemp[i] = kamokuCodesTemp[i].trim();
			}

			searchKey.setKamokuCodes(kamokuCodesTemp);
		}
		/* ���x���R�[�h���P���Z���� */
		if (searchKey.getLevelCode() != null && !searchKey.getLevelCode().equals("")) {
			searchKey.setLevelCode(String.valueOf(Integer.parseInt(searchKey.getLevelCode()) - 1));
		}

		/* �{�l�܂��́A�Q�Ƃ��m�F���� */
		searchKey.setJyukouJyokyo(request.getParameter("jyukou_jyokyo"));
		final String simei_no = request.getParameter("simei_no");

		if (simei_no == null || simei_no.equals("")) {
			// �����̎���NO�����������ɃZ�b�g
			searchKey.setSimeiNo(loginuser.getSimeiNo());
		} else {
			searchKey.setSimeiNo(simei_no);
		}

		// EJBHome�̎擾
		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PCY_HonninKensyuJyohouEJBHome home = (PCY_HonninKensyuJyohouEJBHome) fact.lookup(PCY_HonninKensyuJyohouEJBHome.class);
		/* EJBObject�̎擾 */
		final PCY_HonninKensyuJyohouEJB ejb = home.create();

		/* EJB�Ăяo��Bean�̃C���X�^���X���� */
		final PCY_HonninKensyuJyohouBean kensyuJyohou = new PCY_HonninKensyuJyohouBean();

		/* ���[�U��� */
		final PCY_KensyuJouhouBean[] tempKensyuJouhouBeans = ejb.getKensakuKamokuList(searchKey, loginuser);

		final ArrayList kensyuJouhouBeanList = new ArrayList();
		final HashMap kamokuCodeMap = new HashMap();
		// �N���X�P�ʂ̏����ȖڒP�ʂɂ���
		for (int i = 0; i < tempKensyuJouhouBeans.length; i++) {
			// �Ȗڂ��i�[����Ă��Ȃ��ꍇ�A���X�g�ɒǉ�
			if (kamokuCodeMap.get(tempKensyuJouhouBeans[i].getKamokuCode()) == null) {
				kensyuJouhouBeanList.add(tempKensyuJouhouBeans[i]);
				kamokuCodeMap.put(tempKensyuJouhouBeans[i].getKamokuCode(), tempKensyuJouhouBeans[i].getKamokuCode());
			}
		}
		final PCY_KensyuJouhouBean[] kensyuJouhouBeans = new PCY_KensyuJouhouBean[kensyuJouhouBeanList.size()];
		kensyuJouhouBeanList.toArray(kensyuJouhouBeans);
		// �\�[�g
		Arrays.sort(kensyuJouhouBeans, new KensyuJouhouBeanComparator());

		request.setAttribute("kensyuJouhouBeans", kensyuJouhouBeans);

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();
	}

	/**
	 * �ȖڃO���[�v���A�Ȗڕ��ނP�A�Ȗڕ��ނQ�A�ȖڃR�[�h���L�[�Ƀ\�[�g���܂��B
	 */
	private class KensyuJouhouBeanComparator implements Comparator {
		public int compare(final Object o1, final Object o2) {
			final PCY_KensyuJouhouBean kamoku1 = (PCY_KensyuJouhouBean) o1;
			final PCY_KensyuJouhouBean kamoku2 = (PCY_KensyuJouhouBean) o2;

			if (PZZ010_CharacterUtil.normalizedStr(kamoku1.getClassBean().getKamokuBean().getKamokuGroup()).equals(
					PZZ010_CharacterUtil.normalizedStr(kamoku2.getClassBean().getKamokuBean().getKamokuGroup()))) {
				if (PZZ010_CharacterUtil.normalizedStr(kamoku1.getCategoryCode1()).equals(PZZ010_CharacterUtil.normalizedStr(kamoku2.getCategoryCode1()))) {
					if (PZZ010_CharacterUtil.normalizedStr(kamoku1.getCategoryCode2()).equals(PZZ010_CharacterUtil.normalizedStr(kamoku2.getCategoryCode2()))) {
						return PZZ010_CharacterUtil.normalizedStr(kamoku1.getKamokuCode()).compareTo(PZZ010_CharacterUtil.normalizedStr(kamoku2.getKamokuCode()));
					}
					return PZZ010_CharacterUtil.normalizedStr(kamoku1.getCategoryCode2()).compareTo(PZZ010_CharacterUtil.normalizedStr(kamoku2.getCategoryCode2()));
				}
				return PZZ010_CharacterUtil.normalizedStr(kamoku1.getCategoryCode1()).compareTo(PZZ010_CharacterUtil.normalizedStr(kamoku2.getCategoryCode1()));
			}
			return PZZ010_CharacterUtil.normalizedStr(kamoku1.getClassBean().getKamokuBean().getKamokuGroup()).compareTo(
					PZZ010_CharacterUtil.normalizedStr(kamoku2.getClassBean().getKamokuBean().getKamokuGroup()));
		}
	}
}
