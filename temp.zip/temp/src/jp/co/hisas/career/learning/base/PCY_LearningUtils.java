package jp.co.hisas.career.learning.base;


public class PCY_LearningUtils {
	
	private static final char DELIMITER_S = '[';
	private static final char DELIMITER_E = ']';
	
	private static final String ANCHOR_TAG_FORMAT = "<a target=\"_blank\" href=\"{0}\">{0}</a>";
	
	public static String convUrlToAnchor( String target ) {

		int index = 0;
		String url = "";
		String noUrl = "";
		boolean found = false;
		
		if (target == null || "".equals(target)) {
			return "";
		}
		
		while( index < target.length()) {
			if( found ) {
				if( index == target.length() - 1 ) {
					url += target.charAt( index );
					break;
				}
				if( target.charAt( index ) == DELIMITER_E && target.charAt(index + 1 ) == DELIMITER_E ) {
					index += 2;
					found = false;
					noUrl += ANCHOR_TAG_FORMAT.replace( "{0}", url );
					url = "";
					continue;
				} else {
					url += target.charAt( index );
				}
			} else {
				if( index == target.length() - 1 ) {
					noUrl += target.charAt( index );
					break;
				}
				if( target.charAt( index ) == DELIMITER_S && target.charAt(index + 1 ) == DELIMITER_S ) {
					index += 2;
					found = true;
					continue;
				} else {
					noUrl += target.charAt( index );
				}
			}
			index++;
		}
		
		if( url != "" || url.length() != 0 ) {
			noUrl += ( DELIMITER_S + DELIMITER_S + url );
		}
		return replaceCrLfToBr( noUrl );
	}

	private static String replaceCrLfToBr( String str ) {
		if (str == null || str.equals("")) {
			return "<BR>";
		}
		if (str.indexOf("\r\n") != -1) {
			// \r\n��<BR>�ɕϊ����ĕԂ�
			return str.replaceAll("\r\n","<BR>");
		} else if(str.indexOf("\n") != -1) {
			// \n��<BR>�ɕϊ����ĕԂ�
			return str.replaceAll("\n","<BR>");
		}
		return str;
	}
}
