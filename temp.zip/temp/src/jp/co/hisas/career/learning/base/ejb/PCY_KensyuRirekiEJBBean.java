/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJB;
import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJBHome;
import jp.co.hisas.career.base.blob.ejb.PYF_ByteDataBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_EsNinsyoRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PCY_KensyuRirekiEJBBean�N���X �@�\�����F ���猤�C�����̎擾�A�i�[�A�X�V���s���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="PCY_KensyuRirekiEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_KensyuRirekiEJBBean implements SessionBean {
	private SessionContext context = null;

	/**
	 * �F��ȖڂƂ��ă��R�[�h��ǉ����܂��B
	 * @param kamoku_code �ȖڃR�[�h
	 * @param class_code �N���X�R�[�h
	 * @param simei_no �F��o�^�Ώێ҂̎����ԍ�
	 * @param loginuser ���[�U���
	 * @return �F�茏���i�P�Œ�j
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doInsertNinteiTouroku(final String kamoku_code, final String class_code, final String simei_no, final PCY_PersonalBean loginuser) throws NamingException, CreateException,
			RemoteException, PCY_WarningException {
		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final EJBHomeFactory fact = EJBHomeFactory.getInstance();

			/* �F�肷��N���X�����擾 */
			/* ClassEJB�j */
			final PCY_ClassEJBHome class_home = (PCY_ClassEJBHome) fact.lookup(PCY_ClassEJBHome.class);
			final PCY_ClassEJB class_ejb = class_home.create();

			final PCY_ClassBean kensaku_classBean = new PCY_ClassBean();
			kensaku_classBean.getKamokuBean().setKamokuCode(kamoku_code);
			kensaku_classBean.setClassCode(class_code);

			final PCY_ClassBean[] classBeans = class_ejb.doSelect(kensaku_classBean, true, loginuser);

			if (classBeans.length != 1) {
				this.context.setRollbackOnly();
				new PCY_WarningException();
			}

			/* �Ώېݒ�����擾 */
			/* TaisyoEJB */
			final PCY_TaisyoEJBHome taisyo_home = (PCY_TaisyoEJBHome) fact.lookup(PCY_TaisyoEJBHome.class);
			final PCY_TaisyoEJB taisyo_ejb = taisyo_home.create();

			String taisyoKubun = taisyo_ejb.getTaisyoKubun(kamoku_code, class_code, simei_no, loginuser);

			/* �Ώۋ敪���ݒ肳��Ă��Ȃ� */
			if (taisyoKubun == null || taisyoKubun.equals("2")) {
				taisyoKubun = "1";
			}

			/* �Ώێ҂̃p�[�\�i�������擾 */
			/* PersonalEJB */
			final PCY_PersonalEJBHome personal_home = (PCY_PersonalEJBHome) fact.lookup(PCY_PersonalEJBHome.class);
			final PCY_PersonalEJB personal_ejb = personal_home.create();

			final PCY_PersonalBean personalBean = personal_ejb.getPersonalInfo(simei_no, loginuser);

			/* �ǉ����錤�C���������쐬 */
			final PCY_KensyuRirekiBean insert_rirekiBean = new PCY_KensyuRirekiBean(classBeans[0].getKamokuBean(), classBeans[0], new PCY_MousikomiJyokyoBean());

			/* �Ώۋ敪���Z�b�g */
			insert_rirekiBean.setTaisyoKubun(taisyoKubun);

			/* �����ԍ����Z�b�g */
			insert_rirekiBean.setSimeiNo(simei_no);

			/* ��u���ɃN���X�I���̍ŏI�����Z�b�g */
			insert_rirekiBean.setJyukoubi(classBeans[0].getSyuryobi());

			/* �I������ɔF����Z�b�g */
			insert_rirekiBean.setSyuryoHantei("2");

			/* �{�l�C���t���O���Z�b�g */
			insert_rirekiBean.setHonninSyuseiFlg("0");

			/* ���J�t���O���Z�b�g */
			insert_rirekiBean.setKokaiFlg(personalBean.getKensyuRirekiKokaiFlg());

			/* ����ǉ����s���B */
			final int count = this.doInsert(new PCY_KensyuRirekiBean[] { insert_rirekiBean }, loginuser);

			if (count != 1) {
				this.context.setRollbackOnly();
				throw new PCY_WarningException("����ǉ��ł��܂���ł����B");
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			this.context.setRollbackOnly();
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final CreateException e) {
			this.context.setRollbackOnly();
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RemoteException e) {
			this.context.setRollbackOnly();
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final PCY_WarningException e) {
			this.context.setRollbackOnly();
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		}
	}

	/**
	 * �ȖڔF��Ƃ��ă��R�[�h��ǉ����܂��B
	 * @param kamoku_code �ȖڃR�[�h
	 * @param simei_no �F��o�^�Ώێ҂̎����ԍ�
	 * @param loginuser ���[�U���
	 * @return �F�茏���i�P�Œ�j
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doInsertKamokuNinteiTouroku(final String kamoku_code, final String simei_no, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final EJBHomeFactory fact = EJBHomeFactory.getInstance();

			/* �F�肷��Ȗڏ����擾 */
			/* ClassEJB�j */
			final PCY_KamokuEJBHome kamoku_home = (PCY_KamokuEJBHome) fact.lookup(PCY_KamokuEJBHome.class);
			final PCY_KamokuEJB kamoku_ejb = kamoku_home.create();

			final PCY_KamokuBean kensaku_KamokuBean = new PCY_KamokuBean();
			kensaku_KamokuBean.setKamokuCode(kamoku_code);

			final PCY_KamokuBean kamokuBean = kamoku_ejb.doSelectByPrimaryKey(kensaku_KamokuBean, true, loginuser);

			if (kamokuBean == null) {
				this.context.setRollbackOnly();
				new PCY_WarningException();
			}

			/* �ǉ����錤�C���������쐬 */
			final PCY_KensyuRirekiBean insert_rirekiBean = new PCY_KensyuRirekiBean(kamokuBean, new PCY_ClassBean(), new PCY_MousikomiJyokyoBean());

			/* �����ԍ����Z�b�g */
			insert_rirekiBean.setSimeiNo(simei_no);

			/* �J�n�����Z�b�g */
			insert_rirekiBean.setKaisibi(PZZ010_CharacterUtil.GetDay());

			/* �I�������Z�b�g */
			insert_rirekiBean.setSyuryobi(PZZ010_CharacterUtil.GetDay());

			/* �����ꊇ�t���O���Z�b�g */
			insert_rirekiBean.setKisyoIkkatsuFlg("0");

			/* �S�БΏۃt���O���Z�b�g */
			insert_rirekiBean.setZensyaTaisyoFlg("0");

			/* �����t���O���Z�b�g */
			insert_rirekiBean.setSeikyuFlg("0");

			/* �C������ɔF����Z�b�g */
			insert_rirekiBean.setSyuryoHantei("2");

			/* �{�l�C���t���O���Z�b�g */
			insert_rirekiBean.setHonninSyuseiFlg("0");

			/* ���J�t���O���Z�b�g */
			insert_rirekiBean.setKokaiFlg("6");

			/* ����ǉ����s���B */
			final int count = this.doInsert(new PCY_KensyuRirekiBean[] { insert_rirekiBean }, loginuser);

			if (count != 1) {
				this.context.setRollbackOnly();
				throw new PCY_WarningException("����ǉ��ł��܂���ł����B");
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			this.context.setRollbackOnly();
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final CreateException e) {
			this.context.setRollbackOnly();
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RemoteException e) {
			this.context.setRollbackOnly();
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final PCY_WarningException e) {
			this.context.setRollbackOnly();
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		}
	}

	/**
	 * �_�E�����[�h�X�V�����X�V����B �X�V���A�X�V�����A�X�V�҂͍X�V���Ȃ��B WHERE���PrimaryKey���w�肵�Ă��邽�߁A�Ώۃ��R�[�h��1���R�[�h�̂݁B
	 * @param rirekiBean
	 * @param loginuser
	 * @return
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdateDownLoadInfo(final PCY_KensyuRirekiBean rirekiBean, final PCY_PersonalBean loginuser) throws PCY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			final StringBuffer sql = new StringBuffer();
			sql.append("UPDATE ");
			sql.append(HcdbDef.L51_TBL);
			sql.append("   SET DOWNLOADBI=?");
			sql.append(",      DOWNLOADJIKOKU=?");
			sql.append(",      DOWNLOADSYA=?");
			sql.append("  WHERE SIMEI_NO=?");
			sql.append("    AND KAMOKU_CODE=?");
			sql.append("    AND CLASS_CODE=?");

			/* �f�o�b�O���O�o�� */
			Log.debug(sql.toString());

			ps = con.prepareStatement(sql.toString());

			ps.setString(1, rirekiBean.getDownloadbi());
			ps.setString(2, rirekiBean.getDownloadjikoku());
			ps.setString(3, rirekiBean.getDownloadsya());
			ps.setString(4, rirekiBean.getSimeiNo());
			ps.setString(5, rirekiBean.getKamokuCode());
			ps.setString(6, rirekiBean.getClassCode());

			final int count = ps.executeUpdate();

			if (count != 1) {
				this.context.setRollbackOnly();
				throw new PCY_WarningException();
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * ���猤�C���Ƀ��R�[�h��ǉ����܂��B
	 * @param rirekiBeans ���猤�C�����
	 * @param loginuser ���O�C�����[�U���
	 * @exception CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 * @exception RemoteException �����[�g�Ăяo���Ɏ��s�����ꍇ
	 * @throws PCY_WarningException �����������قȂ�ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doInsert(final PCY_KensyuRirekiBean[] rirekiBeans, final PCY_PersonalBean loginuser) throws PCY_WarningException, RemoteException, CreateException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO ");
			sql.append(HcdbDef.L51_TBL);
			sql.append(" (");
			sql.append("seq_no,");
			sql.append("simei_no,");
			sql.append("kamoku_code,");
			sql.append("kamoku_mei1,");
			sql.append("kamoku_mei2,");
			sql.append("kamoku_mei3,");
			sql.append("kamoku_mei4,");
			sql.append("version_kanri,");
			sql.append("kamoku_group,");
			sql.append("kamoku_group_mei,");
			sql.append("category_code1,");
			sql.append("category_mei1,");
			sql.append("category_code2,");
			sql.append("category_mei2,");
			sql.append("category_code3,");
			sql.append("category_mei3,");
			sql.append("category_code4,");
			sql.append("category_mei4,");
			sql.append("category_code5,");
			sql.append("category_mei5,");
			sql.append("kanrimoto_code,");
			sql.append("kanrimoto_mei,");
			sql.append("tanka,");
			sql.append("kamoku_naiyou,");
			sql.append("jyukou_jyoken,");
			sql.append("yobi1,");
			sql.append("yobi2,");
			sql.append("class_code,");
			sql.append("class_mei,");
			sql.append("nissuu,");
			sql.append("kaisibi,");
			sql.append("syuryobi,");
			sql.append("kaisaijikan,");
			sql.append("kaisijikoku,");
			sql.append("syuryojikoku,");
			sql.append("mousikomi_kaisibi,");
			sql.append("mousikomi_syuryobi,");
			sql.append("jyukou_kigen,");
			sql.append("chiku_code,");
			sql.append("chiku_mei,");
			sql.append("kyositu_code,");
			sql.append("kyositu_mei,");
			sql.append("teiin,");
			sql.append("kaisai_saisyo_ninzuu,");
			sql.append("kousi_code,");
			sql.append("kousi_mei,");
			sql.append("kisyo_ikkatsu_flg,");
			sql.append("zensya_taisyo_flg,"); /* INS#P-ALC01-030-003 */
			sql.append("mousikomi_kubun,");
			sql.append("syonin_kubun,");
			sql.append("uketuke_kubun,");
			sql.append("houkoku_kubun,");
			sql.append("ninsyo_kubun,");
			sql.append("hantei_kubun,");
			sql.append("kaisai_jyotai,");
			sql.append("annai_mail_kubun,");
			sql.append("follow_mail_kubun,");
			sql.append("follow_mail_nissuu1,");
			sql.append("follow_mail_nissuu2,");
			sql.append("bikou,");
			sql.append("taisyo_kubun,");
			sql.append("jyukoubi,");
			sql.append("report_filename,");
			sql.append("report_content_type,");
			sql.append("houkoku,");
			sql.append("tensu,");
			sql.append("syusseki_nissuu,");
			sql.append("seiseki,");
			sql.append("syuryo_hantei,");
			sql.append("mousikomibi,");
			sql.append("mousikomijikoku,");
			sql.append("mousikomisya,");
			sql.append("syoninbi1,");
			sql.append("syoninjikoku1,");
			sql.append("syoninsya1,");
			sql.append("syoninbi2,");
			sql.append("syoninjikoku2,");
			sql.append("syoninsya2,");
			sql.append("uketukebi,");
			sql.append("uketukejikoku,");
			sql.append("uketukesya,");
			sql.append("houkokubi,");
			sql.append("houkokujikoku,");
			sql.append("houkokusya,");
			sql.append("seikyu_flg,");
			sql.append("ninsyobi,");
			sql.append("ninsyojikoku,");
			sql.append("downloadbi,");
			sql.append("downloadjikoku,");
			sql.append("downloadsya,");
			sql.append("hanteibi,");
			sql.append("hanteijikoku,");
			sql.append("hanteisya,");
			sql.append("honnin_syusei_flg,");
			sql.append("kokai_flg,");
			sql.append("tourokubi,");
			sql.append("tourokujikoku,");
			sql.append("tourokusya,");
			sql.append("kousinbi,");
			sql.append("kousinjikoku,");
			sql.append("kousinsya,");
			sql.append("seiseki_bikou");
			sql.append(" ) VALUES ( ");
			sql.append("?,?,?,?,?,?,?,?,?,?,");
			sql.append("?,?,?,?,?,?,?,?,?,?,");
			sql.append("?,?,?,?,?,?,?,?,?,?,");
			sql.append("?,?,?,?,?,?,?,?,?,?,");
			sql.append("?,?,?,?,?,?,?,?,?,?,");
			sql.append("?,?,?,?,?,?,?,?,?,?,");
			sql.append("?,?,?,?,?,?,?,?,?,?,");
			sql.append("?,?,?,?,?,?,?,?,?,?,");
			sql.append("?,?,?,?,?,?,?,?,?,?,");
			sql.append("?,?,?,?,?,?,?,?,?,?,?,?)");

			Log.debug(sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			final EJBHomeFactory fact = EJBHomeFactory.getInstance();

			// EJB�Ăяo��
			final PCY_CounterEJBHome counterHome = (PCY_CounterEJBHome) fact.lookup(PCY_CounterEJBHome.class);
			final PCY_CounterEJB counterEjb = counterHome.create();
			final String[] seqNo = counterEjb.countKyoikuKensyuRekiCodes(rirekiBeans.length);

			// �t�@�C��(BLOB�^)��DB�Ɋi�[����EJB�Ăяo��
			// JNDI���̃��b�N�A�b�v
			final PYF_BlobDBAccessEJBHome blobHome = (PYF_BlobDBAccessEJBHome) fact.lookup(PYF_BlobDBAccessEJBHome.class);

			// EJBObject�̎擾
			final PYF_BlobDBAccessEJB blobEjb = blobHome.create();

			final ArrayList blob_kensyuRirekiBeansList = new ArrayList();

			int count = 0;

			for (int i = 0; i < rirekiBeans.length; i++) {
				ps = con.prepareStatement(sql.toString());

				// �V�[�P���X�ԍ��Ō���
				final PCY_KensyuRirekiBean key = new PCY_KensyuRirekiBean();
				key.setSeqNo(seqNo[i]);

				final PCY_KensyuRirekiBean ret = this.doSelectByPrimaryKey(key, loginuser);

				// pk���d��������x��
				if (ret != null) {
					this.context.setRollbackOnly();
					throw new PCY_WarningException();
				}

				/* For SAS-S �J�����ǉ��̂���parameterIndex���ύX */
				ps.setString(1, seqNo[i]);
				ps.setString(2, rirekiBeans[i].getSimeiNo());
				ps.setString(3, rirekiBeans[i].getKamokuCode());
				ps.setString(4, rirekiBeans[i].getKamokuMei1());
				ps.setString(5, rirekiBeans[i].getKamokuMei2());
				ps.setString(6, rirekiBeans[i].getKamokuMei3());
				ps.setString(7, rirekiBeans[i].getKamokuMei4());
				ps.setString(8, rirekiBeans[i].getVersionKanri());
				ps.setString(9, rirekiBeans[i].getKamokuGroup());
				ps.setString(10, rirekiBeans[i].getKamokuGroupMei());
				ps.setString(11, rirekiBeans[i].getCategoryCode1());
				ps.setString(12, rirekiBeans[i].getCategoryMei1());
				ps.setString(13, rirekiBeans[i].getCategoryCode2());
				ps.setString(14, rirekiBeans[i].getCategoryMei2());
				ps.setString(15, rirekiBeans[i].getCategoryCode3());
				ps.setString(16, rirekiBeans[i].getCategoryMei3());
				ps.setString(17, rirekiBeans[i].getCategoryCode4());
				ps.setString(18, rirekiBeans[i].getCategoryMei4());
				ps.setString(19, rirekiBeans[i].getCategoryCode5());
				ps.setString(20, rirekiBeans[i].getCategoryMei5());
				ps.setString(21, rirekiBeans[i].getKanrimotoCode());
				ps.setString(22, rirekiBeans[i].getKanrimotoMei());

				if (rirekiBeans[i].getTanka() != null) {
					ps.setInt(23, rirekiBeans[i].getTanka().intValue());
				} else {
					ps.setNull(23, java.sql.Types.INTEGER);
				}

				ps.setString(24, rirekiBeans[i].getKamokuNaiyou());
				ps.setString(25, rirekiBeans[i].getJyukouJyoken());
				ps.setString(26, rirekiBeans[i].getYobi1());
				ps.setString(27, rirekiBeans[i].getYobi2());
				ps.setString(28, rirekiBeans[i].getClassCode());
				ps.setString(29, rirekiBeans[i].getClassMei());

				if (rirekiBeans[i].getNissuu() != null) {
					ps.setFloat(30, rirekiBeans[i].getNissuu().floatValue());
				} else {
					ps.setNull(30, java.sql.Types.FLOAT);
				}

				ps.setString(31, rirekiBeans[i].getKaisibi());
				ps.setString(32, rirekiBeans[i].getSyuryobi());
				ps.setString(33, rirekiBeans[i].getKaisaijikan());
				ps.setString(34, rirekiBeans[i].getKaisijikoku());
				ps.setString(35, rirekiBeans[i].getSyuryojikoku());
				ps.setString(36, rirekiBeans[i].getMousikomiKaisibi());
				ps.setString(37, rirekiBeans[i].getMousikomiSyuryobi());
				ps.setString(38, rirekiBeans[i].getJyukouKigen());
				ps.setString(39, rirekiBeans[i].getChikuCode());
				ps.setString(40, rirekiBeans[i].getChikuMei());
				ps.setString(41, rirekiBeans[i].getKyosituCode());
				ps.setString(42, rirekiBeans[i].getKyosituMei());

				if (rirekiBeans[i].getTeiin() != null) {
					ps.setInt(43, rirekiBeans[i].getTeiin().intValue());
				} else {
					ps.setNull(43, java.sql.Types.INTEGER);
				}

				if (rirekiBeans[i].getKaisaiSaisyoNinzuu() != null) {
					ps.setInt(44, rirekiBeans[i].getKaisaiSaisyoNinzuu().intValue());
				} else {
					ps.setNull(44, java.sql.Types.INTEGER);
				}

				ps.setString(45, rirekiBeans[i].getKousiCode());
				ps.setString(46, rirekiBeans[i].getKousiMei());
				ps.setString(47, rirekiBeans[i].getKisyoIkkatsuFlg());
				ps.setString(48, rirekiBeans[i].getZensyaTaisyoFlg());
				ps.setString(49, rirekiBeans[i].getMousikomiKubun());
				ps.setString(50, rirekiBeans[i].getSyoninKubun());
				ps.setString(51, rirekiBeans[i].getUketukeKubun());
				ps.setString(52, rirekiBeans[i].getHoukokuKubun());
				ps.setString(53, rirekiBeans[i].getNinsyoKubun());
				ps.setString(54, rirekiBeans[i].getHanteiKubun());
				ps.setString(55, rirekiBeans[i].getKaisaiJyotai());
				ps.setString(56, rirekiBeans[i].getAnnaiMailKubun());
				ps.setString(57, rirekiBeans[i].getFollowMailKubun());

				if (rirekiBeans[i].getFollowMailNissuu1() != null) {
					ps.setInt(58, rirekiBeans[i].getFollowMailNissuu1().intValue());
				} else {
					ps.setNull(58, java.sql.Types.INTEGER);
				}

				if (rirekiBeans[i].getFollowMailNissuu2() != null) {
					ps.setInt(59, rirekiBeans[i].getFollowMailNissuu2().intValue());
				} else {
					ps.setNull(59, java.sql.Types.INTEGER);
				}

				ps.setString(60, rirekiBeans[i].getBikou());
				ps.setString(61, rirekiBeans[i].getTaisyoKubun());
				ps.setString(62, rirekiBeans[i].getJyukoubi());
				ps.setString(63, rirekiBeans[i].getReportFilename());
				ps.setString(64, rirekiBeans[i].getReportContentType());

				/* �񍐏��l��NULL����� PYF_BlobDBAccessEJB�ɂđ������ */
				ps.setNull(65, java.sql.Types.BLOB);

				if (rirekiBeans[i].getTensu() != null) {
					ps.setInt(66, rirekiBeans[i].getTensu().intValue());
				} else {
					ps.setNull(66, java.sql.Types.INTEGER);
				}

				if (rirekiBeans[i].getSyussekiNissuu() != null) {
					ps.setFloat(67, rirekiBeans[i].getSyussekiNissuu().floatValue());
				} else {
					ps.setNull(67, java.sql.Types.FLOAT);
				}

				ps.setString(68, rirekiBeans[i].getSeiseki());
				ps.setString(69, rirekiBeans[i].getSyuryoHantei());
				ps.setString(70, rirekiBeans[i].getMousikomibi());
				ps.setString(71, rirekiBeans[i].getMousikomijikoku());
				ps.setString(72, rirekiBeans[i].getMousikomisya());
				ps.setString(73, rirekiBeans[i].getSyoninbi1());
				ps.setString(74, rirekiBeans[i].getSyoninjikoku1());
				ps.setString(75, rirekiBeans[i].getSyoninsya1());
				ps.setString(76, rirekiBeans[i].getSyoninbi2());
				ps.setString(77, rirekiBeans[i].getSyoninjikoku2());
				ps.setString(78, rirekiBeans[i].getSyoninsya2());
				ps.setString(79, rirekiBeans[i].getUketukebi());
				ps.setString(80, rirekiBeans[i].getUketukejikoku());
				ps.setString(81, rirekiBeans[i].getUketukesya());
				ps.setString(82, rirekiBeans[i].getHoukokubi());
				ps.setString(83, rirekiBeans[i].getHoukokujikoku());
				ps.setString(84, rirekiBeans[i].getHoukokusya());
				ps.setString(85, rirekiBeans[i].getSeikyuFlg() != null ? rirekiBeans[i].getSeikyuFlg() : "0");
				ps.setString(86, rirekiBeans[i].getNinsyobi());
				ps.setString(87, rirekiBeans[i].getNinsyojikoku());
				ps.setString(88, rirekiBeans[i].getDownloadbi());
				ps.setString(89, rirekiBeans[i].getDownloadjikoku());
				ps.setString(90, rirekiBeans[i].getDownloadsya());
				ps.setString(91, rirekiBeans[i].getHanteibi());
				ps.setString(92, rirekiBeans[i].getHanteijikoku());
				ps.setString(93, rirekiBeans[i].getHanteisya());
				ps.setString(94, rirekiBeans[i].getHonninSyuseiFlg());
				ps.setString(95, rirekiBeans[i].getKokaiFlg());
				ps.setString(96, PZZ010_CharacterUtil.GetDay());
				ps.setString(97, PZZ010_CharacterUtil.GetTime());
				ps.setString(98, loginuser.getSimeiNo());
				ps.setString(99, "        ");
				ps.setString(100, "      ");
				ps.setString(101, "          ");
				ps.setString(102, rirekiBeans[i].getSeisekiBikou());

				final int result = ps.executeUpdate();
				PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", null, ps, null);
				count += result;

				// ���猤�C���̃C���T�[�g�ɐ����A���A�񍐂����݂���ꍇ�͊i�[���s��
				if (result == 1 && rirekiBeans[i].getHoukokuKubun() != null) {
					/* �i�[���邽�߂̃f�[�^��ێ��i���ۂɃf�[�^�ێ���for���̊O�ōs�Ȃ��j */
					rirekiBeans[i].setSeqNo(seqNo[i]);
					blob_kensyuRirekiBeansList.add(rirekiBeans[i]);
				}
			}

			if (count != rirekiBeans.length) {
				this.context.setRollbackOnly();
				throw new PCY_WarningException();
			}

			/* BLOB�^�̃f�[�^�i�񍐁j�̊i�[���s�Ȃ� */
			final PCY_KensyuRirekiBean[] blob_kensyuRirekiBeans = (PCY_KensyuRirekiBean[]) blob_kensyuRirekiBeansList.toArray(new PCY_KensyuRirekiBean[0]);

			final String[] keyValue = new String[blob_kensyuRirekiBeans.length];
			final PYF_ByteDataBean[] byteDataBeans = new PYF_ByteDataBean[blob_kensyuRirekiBeans.length];
			for (int i = 0; i < blob_kensyuRirekiBeans.length; i++) {
				final PYF_ByteDataBean byteDataBean = new PYF_ByteDataBean();
				byteDataBean.setData(blob_kensyuRirekiBeans[i].getHoukoku());
				byteDataBeans[i] = byteDataBean;
				keyValue[i] = blob_kensyuRirekiBeans[i].getSeqNo();
			}

			/* �J�����Z�b�g */
			final String[] columns = { "HOUKOKU" };

			// �}���l�Z�b�g
			final String[] values = { "BLOB_DATA" };

			// �L�[
			final String[] primaryKey = { "SEQ_NO" };

			// �o�C�i���f�[�^ (��U�AString�̔z��Ɋi�[����)
			blobEjb.UpdateBLOB(loginuser.getSimeiNo(), HcdbDef.L51_TBL, columns, values, byteDataBeans, primaryKey, keyValue);

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RemoteException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * ���猤�C���̃��R�[�h���X�V���܂��B
	 * @param rirekiBeans ���猤�C�����
	 * @param loginuser ���O�C�����[�U���
	 * @return �X�V����
	 * @throws PCY_WarningException �����������قȂ�ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdate(final PCY_KensyuRirekiBean[] rirekiBeans, final PCY_PersonalBean loginuser) throws PCY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			int count = 0;

			for (int i = 0; i < rirekiBeans.length; i++) {
				final StringBuffer sql = new StringBuffer();
				sql.append("UPDATE ");
				sql.append(HcdbDef.L51_TBL); /* For SAS */

				final Map kensyuRirekiConditions = rirekiBeans[i].extractConditions();

				if (kensyuRirekiConditions.size() > 0) {
					sql.append(" SET");

					for (final Iterator ite = kensyuRirekiConditions.keySet().iterator(); ite.hasNext();) {
						final Object column = ite.next();
						sql.append(" " + column.toString() + "=?,");
					}
				}

				sql.append("KOUSINBI=?,");
				sql.append("KOUSINJIKOKU=?,");
				sql.append("KOUSINSYA=?");
				sql.append(" WHERE SEQ_NO=?");
				sql.append(" AND KOUSINBI=?");
				sql.append(" AND KOUSINJIKOKU=?");

				Log.debug(sql.toString());
				ps = con.prepareStatement(sql.toString());

				int j = 1;

				if (kensyuRirekiConditions.size() > 0) {
					for (final Iterator ite = kensyuRirekiConditions.keySet().iterator(); ite.hasNext(); j++) {
						final Object key = ite.next();

						Log.debug(Integer.toString(j) + ":" + key + ":" + kensyuRirekiConditions.get(key));
						ps.setObject(j, kensyuRirekiConditions.get(key));
					}
				}

				ps.setString(j++, PZZ010_CharacterUtil.GetDay());
				ps.setString(j++, PZZ010_CharacterUtil.GetTime());
				ps.setString(j++, loginuser.getSimeiNo());
				ps.setString(j++, rirekiBeans[i].getSeqNo());
				ps.setString(j++, rirekiBeans[i].getKousinbi());
				ps.setString(j++, rirekiBeans[i].getKousinjikoku());
				count += ps.executeUpdate();
				PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", null, ps, null);
			}

			if (count != rirekiBeans.length) {
				this.context.setRollbackOnly();
				throw new PCY_WarningException();
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * ���C�����̍폜���s���B �p�����[�^��rirekiBean�ɃZ�b�g���Ă���l���폜�����ƂȂ�B �폜�����͕K�v�Ȃ��̂����L�q���Ă���܂���̂ŁA�����X�V���Ă��������B
	 * @param rirekiBean
	 * @param loginuser
	 * @return �폜����
	 * @throws PCY_WarningException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doDelete(final PCY_KensyuRirekiBean[] rirekiBeans, final PCY_PersonalBean loginuser) throws PCY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			/* �폜�����J�E���^�[ */
			int count = 0;

			for (int i = 0; i < rirekiBeans.length; i++) {
				final StringBuffer sql = new StringBuffer();
				final StringBuffer where = new StringBuffer();
				sql.append("DELETE FROM ");
				sql.append(HcdbDef.L51_TBL);

				/* �폜�����J���� �����ǉ��� �ǉ����͉��L�폜�����l�̒ǉ����K�{ */
				if (rirekiBeans[i].getSimeiNo() != null) {
					where.append(" AND SIMEI_NO=?");
				}

				if (rirekiBeans[i].getKamokuCode() != null) {
					where.append(" AND KAMOKU_CODE=?");
				}

				if (rirekiBeans[i].getClassCode() != null) {
					where.append(" AND CLASS_CODE=?");
				} else {// �ȖڔF������Ŏg�p�B�ȖڔF�肳�ꂽ�f�[�^���폜�B
					where.append(" AND CLASS_CODE IS NULL");
				}
				if (rirekiBeans[i].getSyuryoHantei() != null && !rirekiBeans[i].getSyuryoHantei().equals("")) {
					where.append(" AND SYURYO_HANTEI = ? ");
				}
				sql.append(where.toString().replaceFirst("AND", "WHERE"));

				/* SQL���O�o�� */
				Log.debug(sql.toString());

				ps = con.prepareStatement(sql.toString());

				int j = 1;

				/* �폜�����l ��L�̃J�����Ɠ����ŋL�q���邱�� */
				if (rirekiBeans[i].getSimeiNo() != null) {
					ps.setString(j++, rirekiBeans[i].getSimeiNo());
				}

				if (rirekiBeans[i].getKamokuCode() != null) {
					ps.setString(j++, rirekiBeans[i].getKamokuCode());
				}

				if (rirekiBeans[i].getClassCode() != null) {
					ps.setString(j++, rirekiBeans[i].getClassCode());
				}

				if (rirekiBeans[i].getSyuryoHantei() != null && !rirekiBeans[i].getSyuryoHantei().equals("")) {
					ps.setString(j++, rirekiBeans[i].getSyuryoHantei());
				}

				/* DELETE�����s */
				count += ps.executeUpdate();

				PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", null, ps, null);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * ���猤�C���̃��R�[�h���폜���܂��B
	 * @param rirekiBeans ���猤�C�����
	 * @param loginuser ���O�C�����[�U���
	 * @throws PCY_WarningException �����������قȂ�ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public void doDeleteByPrimaryKey(final PCY_KensyuRirekiBean[] rirekiBeans, final PCY_PersonalBean loginuser) throws PCY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			final StringBuffer sql = new StringBuffer();
			sql.append("DELETE FROM ");
			sql.append(HcdbDef.L51_TBL);
			sql.append(" WHERE SEQ_NO=?");
			sql.append(" AND KOUSINBI=?");
			sql.append(" AND KOUSINJIKOKU=?");
			ps = con.prepareStatement(sql.toString());

			int count = 0;

			for (int i = 0; i < rirekiBeans.length; i++) {
				ps.setString(1, rirekiBeans[i].getSeqNo());
				ps.setString(2, rirekiBeans[i].getKousinbi());
				ps.setString(3, rirekiBeans[i].getKousinjikoku());
				count += ps.executeUpdate();
			}

			if (count != rirekiBeans.length) {
				this.context.setRollbackOnly();
				throw new PCY_WarningException();
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * ���猤�C������C�����肪�u���C�v�ȊO�̗��������擾���APCY_KensyuRirekiBean �Ɋi�[���܂��B �������̈ꗗ��Ԃ��܂��B
	 * @param rirekiBean ���猤�C�����
	 * @param loginuser ���O�C�����[�U���
	 * @return ���猤�C���ꗗ
	 * @throws NamingException
	 * @throws RemoteException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_KensyuRirekiBean[] getSyuryo(final PCY_KensyuRirekiBean rirekiBean, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final StringBuffer sql = new StringBuffer();
			sql.append("SELECT * FROM ");
			sql.append(HcdbDef.L51_TBL);
			sql.append("    WHERE SIMEI_NO=?");
			sql.append("      AND KAMOKU_CODE=?");
			sql.append("      AND NOT SYURYO_HANTEI='0'");

			// �R�l�N�V�����̎擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			ps = con.prepareStatement(sql.toString());

			ps.setString(1, rirekiBean.getSimeiNo());
			ps.setString(2, rirekiBean.getKamokuCode());

			rs = ps.executeQuery();

			final ArrayList ret = new ArrayList();

			while (rs.next()) {
				ret.add(new PCY_KensyuRirekiBean(rs, null));
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return (PCY_KensyuRirekiBean[]) ret.toArray(new PCY_KensyuRirekiBean[0]);
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * ���猤�C�����痚�������擾���APCY_KensyuRirekiBean �Ɋi�[���܂��B �������̈ꗗ��Ԃ��܂��B
	 * @param rirekiBeans ���猤�C�����
	 * @param loginuser ���O�C�����[�U���
	 * @return ���猤�C���ꗗ
	 * @throws NamingException
	 * @throws RemoteException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_KensyuRirekiBean[] getList(final PCY_KensyuRirekiBean[] rirekiBeans, final PCY_PersonalBean loginuser) throws EJBException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			final ArrayList ret = new ArrayList();

			for (int i = 0; i < rirekiBeans.length; i++) {
				final StringBuffer sql = new StringBuffer();
				sql.append("SELECT * FROM ");
				sql.append(HcdbDef.L51_TBL);

				// ���猤�C��DB���������̍쐬
				final Map rirekiConditions = rirekiBeans[i].extractConditions();

				if (rirekiConditions.size() > 0) {
					int j = 1;
					sql.append(" WHERE");

					for (final Iterator ite = rirekiConditions.keySet().iterator(); ite.hasNext(); j++) {
						final Object column = ite.next();

						sql.append(" " + column.toString() + "=?");

						if (j < rirekiConditions.size()) {
							sql.append(" AND");
						}
					}
				}

				/* SQL�f�o�b�OLog���o�� */
				Log.debug(sql.toString());

				ps = con.prepareStatement(sql.toString());

				int k = 1;

				for (final Iterator ite = rirekiConditions.keySet().iterator(); ite.hasNext(); k++) {
					final Object key = ite.next();
					if (key.equals("SIMEI_NO")) {
						final String SimeiNo = (String) rirekiConditions.get(key);
						rirekiConditions.put(key, SimeiNo);
					}

					Log.debug(Integer.toString(k) + ":" + key + ":" + rirekiConditions.get(key));
					ps.setObject(k, rirekiConditions.get(key));
				}

				rs = ps.executeQuery();
				

				while (rs.next()) {
					ret.add(new PCY_KensyuRirekiBean(rs, null));
				}
				
				PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", null, ps, rs);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return (PCY_KensyuRirekiBean[]) ret.toArray(new PCY_KensyuRirekiBean[0]);
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * ���猤�C��������͂��ꂽ�����Ɉ�v���闚�������擾���APCY_KensyuRirekiBean �Ɋi�[���܂��B �������̈ꗗ��Ԃ��܂��B
	 * @param rirekiBean ���猤�C�����
	 * @param loginuser ���O�C�����[�U���
	 * @return ���猤�C���ꗗ
	 * @throws NamingException
	 * @throws RemoteException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_KensyuRirekiBean doSelectByPrimaryKey(final PCY_KensyuRirekiBean rirekiBean, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		PCY_KensyuRirekiBean ret = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			ps = con.prepareStatement("SELECT " + PCY_KensyuRirekiBean.getColumns("rireki") + " FROM " + HcdbDef.L51_TBL + " rireki " + " WHERE SEQ_NO=?"); /* For SAS INS#P-ALC01-022-002 */

			ps.setString(1, rirekiBean.getSeqNo());

			rs = ps.executeQuery();

			while (rs.next()) {
				ret = new PCY_KensyuRirekiBean(rs, "rireki");
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return ret;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * ���猤�C���̍X�V�y��ES�F�ؗ����̊i�[�i�F�؋敪���v�̃N���X�̂݁j���s���܂��B
	 * @param rirekiBean ���猤�C�����
	 * @param ninsyoBean ES�F�ؗ������
	 * @param loginuser ���O�C�����[�U���
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 * @throws RemoteException EJB�Ăяo���Ɏ��s�����ꍇ
	 * @throws PCY_WarningException �����������قȂ�ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public void doUpdateWithEsNinsyo(final PCY_KensyuRirekiBean rirekiBean, final PCY_EsNinsyoRirekiBean ninsyoBean, final PCY_PersonalBean loginuser) throws RemoteException, CreateException,
			PCY_WarningException {
		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final EJBHomeFactory fact = EJBHomeFactory.getInstance();

			/* ���猤�C���̍X�V */
			this.doUpdate(new PCY_KensyuRirekiBean[] { rirekiBean }, loginuser);

			/* ES�F�ؗv�̏ꍇ�ɂ�ES�F�ؗ������i�[���� */
			if (rirekiBean.getNinsyoKubun().equals("1")) {
				/* PCY_EsNinsyoRirekiEJB */
				final PCY_EsNinsyoRirekiEJBHome ninsyoHome = (PCY_EsNinsyoRirekiEJBHome) fact.lookup(PCY_EsNinsyoRirekiEJBHome.class);
				final PCY_EsNinsyoRirekiEJB ninsyoEjb = ninsyoHome.create();

				/* ES�F�ؗ����̊i�[ */
				ninsyoEjb.doInsert(new PCY_EsNinsyoRirekiBean[] { ninsyoBean }, loginuser);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final CreateException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RemoteException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		}
	}

	/**
	 * SessionContext��ݒ肵�܂��B
	 * @param context
	 * @throws javax.ejb.EJBException
	 * @throws java.rmi.RemoteException
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
}
