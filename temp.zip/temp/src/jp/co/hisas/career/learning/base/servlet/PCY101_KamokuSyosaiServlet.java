/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.TreeMap;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_KanrenKyoikuKamokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KanrenKyoikuKamokuEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_KensyuRirekiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KensyuRirekiEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KanrenKyoikuKamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY101_KamokuSyosaiServlet �N���X �@�\�����F ���s���B
 * 
 * </PRE>
 */
public class PCY101_KamokuSyosaiServlet extends PCY010_ControllerServlet {
	/**
	 * ���N�G�X�g����v���C�}���L�[���擾���A�Ȗڏ����擾���܂��B �Ȗڏ��̓��N�G�X�g(�������F"kamokuBean")�Ɋi�[���܂��B �Ȗڏ�񂪑��݂��Ȃ��ꍇ�A���N�G�X�g�ɂ� null ���i�[����܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean )
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		final PCY_KamokuEJBHome home = (PCY_KamokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KamokuEJBHome.class);
		final PCY_KamokuEJB ejb = home.create();
		final PCY_KamokuBean kamokuBean = ejb.doSelectByPrimaryKey(new PCY_KamokuBean(request), false, loginuser);
		// DEL#2007/3/14 s-hiura
		if ("1".equals(request.getParameter("kanren_syokusyu_syutoku"))) {
			final PCY_KanrenKyoikuKamokuEJBHome kanren_home = (PCY_KanrenKyoikuKamokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KanrenKyoikuKamokuEJBHome.class);
			final PCY_KanrenKyoikuKamokuEJB kanren_ejb = kanren_home.create();

			final PCY_KanrenKyoikuKamokuBean[] kanrenBeans = kanren_ejb.doSelectByKamokuCode(kamokuBean.getKamokuCode(), loginuser);
			final TreeMap kanrenList = new TreeMap();

			for (int i = 0; i < kanrenBeans.length; i++) {
				final StringBuffer key = new StringBuffer();
				key.append(kanrenBeans[i].getSyokusyuCode() + ",");
				key.append(kanrenBeans[i].getSenmonCode() + ",");
				key.append(kanrenBeans[i].getLevelCode());

				if (!kanrenList.containsKey(key.toString())) {
					kanrenList.put(key.toString(), kanrenBeans[i]);
				}
			}

			kamokuBean.setKanrenKamokuBeans((PCY_KanrenKyoikuKamokuBean[]) kanrenList.values().toArray(new PCY_KanrenKyoikuKamokuBean[0]));
		}

		final String gamenID = request.getParameter("gamen_id");
		if (gamenID != null && !gamenID.equals("") && gamenID.equals("VCC080")) {

			final PCY_KamokuBean checkkamokuBean = ejb.doSelectByPKey(new PCY_KamokuBean(request), false, loginuser);

			final String kamokuCode = request.getParameter("kamoku_code");
			if (kamokuCode != null && !kamokuCode.equals("")) {
				if (checkkamokuBean == null) {
					// ���͂��ꂽ�ȖڃR�[�h�����݂��Ȃ��ꍇ
					request.setAttribute("err_id", "VCC270");
				} else if (checkkamokuBean.getSakujyoFlg().equals("1")) {
					// ���͂��ꂽ�ȖڃR�[�h���폜�ς݂̉Ȗڂ̏ꍇ
					request.setAttribute("err_id", "VCC271");
				}
			}
		}

		// ADD#2007/2/20 s-hiura start
		// CHG#2007/3/14 s-hiura start
		if (kamokuBean != null) {
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PCY_MousikomiJyokyoEJBHome mousikomi_home = (PCY_MousikomiJyokyoEJBHome) fact.lookup(PCY_MousikomiJyokyoEJBHome.class);
			final PCY_MousikomiJyokyoEJB mousikomi_ejb = mousikomi_home.create();

			final PCY_MousikomiJyokyoBean kensaku_mousikomiBean = new PCY_MousikomiJyokyoBean();
			kensaku_mousikomiBean.setKamokuCode(kamokuBean.getKamokuCode());
			if (request.getParameter("simei_no") != null) {
				kensaku_mousikomiBean.setSimeiNo(request.getParameter("simei_no"));
			} else {
				kensaku_mousikomiBean.setSimeiNo(loginuser.getSimeiNo());
			}

			final PCY_MousikomiJyokyoBean[] mousikomiBeans = mousikomi_ejb.getList(kensaku_mousikomiBean, loginuser);

			final PCY_KensyuRirekiBean kensyuRirekiBean = new PCY_KensyuRirekiBean();
			kensyuRirekiBean.setKamokuCode(kamokuBean.getKamokuCode());
			kensyuRirekiBean.setSimeiNo(loginuser.getSimeiNo());

			final PCY_KensyuRirekiEJBHome rirekiHome = (PCY_KensyuRirekiEJBHome) fact.lookup(PCY_KensyuRirekiEJBHome.class);
			final PCY_KensyuRirekiEJB rirekiEJB = rirekiHome.create();
			final PCY_KensyuRirekiBean[] rireki = rirekiEJB.getSyuryo(kensyuRirekiBean, loginuser);
			// ����Ȗڂ�L15��L51�ɑ��݂���ꍇ
			if (rireki.length > 0 || mousikomiBeans.length > 0) {
				kamokuBean.setKamokuSyuryoFlg("1");
			}
		}
		// CHG#2007/3/14 s-hiura end
		// ADD#2007/2/20 s-hiura end
		request.setAttribute("kamokuBean", kamokuBean);

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
