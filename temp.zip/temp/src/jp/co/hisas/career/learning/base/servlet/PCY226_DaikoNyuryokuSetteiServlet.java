package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_DaikoNyuryokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_DaikoNyuryokuEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PCY226_DaikoNyuryokuSetteiServlet �N���X �@�\�����F ��s���͓o�^���s���܂��B
 * 
 * </PRE>
 */
public class PCY226_DaikoNyuryokuSetteiServlet extends PCY010_ControllerServlet {
	/**
	 * ��s���͓o�^���s���܂��B
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, SQLException,
			RemoteException, PCY_WarningException {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

// MOD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V START
//		final PCY_ClassBean classBean = new PCY_ClassBean(request);
		PCY_ClassBean classBean = new PCY_ClassBean(request);
// MOD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V END
		final String uketsuke_jyotai = request.getParameter("H003_uketsuke_jyotai");
		final String[] simei_no = request.getParameterValues("H004_simei_no");
		final String[] taisyo_kubun = request.getParameterValues("H005_taisyo_kubun");

		PCY_TaisyosyaBean[] taisyosyaBeans = new PCY_TaisyosyaBean[simei_no.length];
		for (int i = 0; i < simei_no.length; i++) {
			taisyosyaBeans[i] = new PCY_TaisyosyaBean();
			taisyosyaBeans[i].setSimeiNo(simei_no[i]);
			taisyosyaBeans[i].setTaisyoKubun(taisyo_kubun[i]);
			taisyosyaBeans[i].setClassBean(classBean);
		}
		
		/* ��s���͏������Ăяo�� */
		final PCY_DaikoNyuryokuEJBHome daiko_home = (PCY_DaikoNyuryokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_DaikoNyuryokuEJBHome.class);
		final PCY_DaikoNyuryokuEJB daiko_ejb = daiko_home.create();

		try {
			Log.transaction(loginuser.getSimeiNo(), true, "");
			daiko_ejb.doDaikoNyuryoku(classBean, taisyosyaBeans, loginuser, uketsuke_jyotai);
			Log.transaction(loginuser.getSimeiNo(), false, "");
		} catch (final PCY_WarningException e) {
			if ("WCC040".equals(e.getMessage())) {
				/* ���ɐ��ѓ��͑Ώێ҂ł��� */
				request.setAttribute("warningID", "WCC040");
			} else if ("WCC050".equals(e.getMessage())) {
				request.setAttribute("warningID", "WCC050");
			} else if ("WCC190".equals(e.getMessage())) {
				request.setAttribute("warningID", "WCC190");
			} else if ("WCC200".equals(e.getMessage())) {
				request.setAttribute("warningID", "WCC200");
			} else if ("WCC260".equals(e.getMessage())) {
				request.setAttribute("warningID", "WCC260");
			}

			throw e;
		}
// ADD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V START
        final PCY_ClassEJBHome class_home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
        final PCY_ClassEJB class_ejb = class_home.create();
        classBean = class_ejb.doSelectByPrimaryKey(classBean, loginuser);
        
// ADD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V END
		try {
			OutLogBean.sousaKojinJohoLog("VCC252", loginuser.getSimeiNo(), null, classBean.getKamokuBean().getKamokuCode() + "," + classBean.getClassCode());
		} catch (final Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
		}
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
