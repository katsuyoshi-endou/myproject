/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_BumonIkuseiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_BumonIkuseiEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_BumonIkuseiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY272_BumonIkuseiKousinServlet �N���X �@�\�����F ����琬�e�[�u���ւ�update�������s���܂��B
 * 
 * </PRE>
 */
public class PCY272_BumonIkuseiKousinServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws RemoteException, SQLException, Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		/* BumonIkuseiEJB */
		final PCY_BumonIkuseiEJBHome bumonikusei_home = (PCY_BumonIkuseiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_BumonIkuseiEJBHome.class);
		final PCY_BumonIkuseiEJB bumonikusei_ejb = bumonikusei_home.create();

		Log.transaction(loginuser.getSimeiNo(), true, "");

		/* UserInfoBean�̑g�D�R�[�h���擾����i���C���[�U�Ή��j */
		final String bumonSosikiCode = request.getParameter("sosiki_code");
		final PCY_BumonIkuseiBean update_bumonBean = new PCY_BumonIkuseiBean();

		update_bumonBean.setSosikiCode(bumonSosikiCode);
		update_bumonBean.setIkuseiHousin(request.getParameter("H002_HTMLcomment").getBytes());
		update_bumonBean.setKousinbi(request.getParameter("H004_kousinbi"));
		update_bumonBean.setKousinjikoku(request.getParameter("H005_kousinjikoku"));

		final int count = bumonikusei_ejb.doUpdate(update_bumonBean, loginuser);

		Log.transaction(loginuser.getSimeiNo(), false, "");

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
