/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.talent.dto;

import java.io.Serializable;

public class JvProfTabSectListtypeDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sectId;
    private Integer colNo;
    private String classes;
    private String width;
    private String headerLabelId;
    private String headerStyle;
    private String subHeaderLabelId;
    private String dataParamId;
    private String dataStyle;

    public String getSectId() {
        return sectId;
    }

    public void setSectId(String sectId) {
        this.sectId = sectId;
    }

    public Integer getColNo() {
        return colNo;
    }

    public void setColNo(Integer colNo) {
        this.colNo = colNo;
    }

    public String getClasses() {
        return classes;
    }

    public void setClasses(String classes) {
        this.classes = classes;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getHeaderLabelId() {
        return headerLabelId;
    }

    public void setHeaderLabelId(String headerLabelId) {
        this.headerLabelId = headerLabelId;
    }

    public String getHeaderStyle() {
        return headerStyle;
    }

    public void setHeaderStyle(String headerStyle) {
        this.headerStyle = headerStyle;
    }

    public String getSubHeaderLabelId() {
        return subHeaderLabelId;
    }

    public void setSubHeaderLabelId(String subHeaderLabelId) {
        this.subHeaderLabelId = subHeaderLabelId;
    }

    public String getDataParamId() {
        return dataParamId;
    }

    public void setDataParamId(String dataParamId) {
        this.dataParamId = dataParamId;
    }

    public String getDataStyle() {
        return dataStyle;
    }

    public void setDataStyle(String dataStyle) {
        this.dataStyle = dataStyle;
    }

}

