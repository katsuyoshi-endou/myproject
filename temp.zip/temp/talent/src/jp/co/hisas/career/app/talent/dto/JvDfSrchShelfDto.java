/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.talent.dto;

import java.io.Serializable;

public class JvDfSrchShelfDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String pzId;
    private String hrzTbl;
    private String hrzCol;
    private String numberSrchFlg;

    public String getPzId() {
        return pzId;
    }

    public void setPzId(String pzId) {
        this.pzId = pzId;
    }

    public String getHrzTbl() {
        return hrzTbl;
    }

    public void setHrzTbl(String hrzTbl) {
        this.hrzTbl = hrzTbl;
    }

    public String getHrzCol() {
        return hrzCol;
    }

    public void setHrzCol(String hrzCol) {
        this.hrzCol = hrzCol;
    }

    public String getNumberSrchFlg() {
        return numberSrchFlg;
    }

    public void setNumberSrchFlg(String numberSrchFlg) {
        this.numberSrchFlg = numberSrchFlg;
    }

}

