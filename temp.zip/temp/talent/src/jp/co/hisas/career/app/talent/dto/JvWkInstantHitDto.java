/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.talent.dto;

import java.io.Serializable;

public class JvWkInstantHitDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sessionId;
    private String guid;
    private Integer querySeq;
    private String query;
    private String tgtCmpaCd;
    private String tgtStfNo;
    private String pzId;
    private String pzVal;

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public Integer getQuerySeq() {
        return querySeq;
    }

    public void setQuerySeq(Integer querySeq) {
        this.querySeq = querySeq;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getTgtCmpaCd() {
        return tgtCmpaCd;
    }

    public void setTgtCmpaCd(String tgtCmpaCd) {
        this.tgtCmpaCd = tgtCmpaCd;
    }

    public String getTgtStfNo() {
        return tgtStfNo;
    }

    public void setTgtStfNo(String tgtStfNo) {
        this.tgtStfNo = tgtStfNo;
    }

    public String getPzId() {
        return pzId;
    }

    public void setPzId(String pzId) {
        this.pzId = pzId;
    }

    public String getPzVal() {
        return pzVal;
    }

    public void setPzVal(String pzVal) {
        this.pzVal = pzVal;
    }

}

