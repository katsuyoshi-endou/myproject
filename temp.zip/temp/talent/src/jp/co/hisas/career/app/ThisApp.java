package jp.co.hisas.career.app;

/**
 * For AppDef.java
 */
public class ThisApp {

	public static String APP_ID = "Talent";

	/**
	 * Context root
	 * - build.properties
	 * - application.xml
	 * - web.xml
	 */
	public static String CTX_ROOT = "talent";

	public static String HOME_JSP = "/view/talent/VTLHOM.jsp";

}
