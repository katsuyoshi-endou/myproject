/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.talent.dto;

import java.io.Serializable;

public class JvTrMyfoldLogDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String mysrchId;
    private Integer mysrchNm;
    private String sharedFlg;
    private String bindOnlyFlg;
    private String madeBy;
    private String madeAt;

    public String getMysrchId() {
        return mysrchId;
    }

    public void setMysrchId(String mysrchId) {
        this.mysrchId = mysrchId;
    }

    public Integer getMysrchNm() {
        return mysrchNm;
    }

    public void setMysrchNm(Integer mysrchNm) {
        this.mysrchNm = mysrchNm;
    }

    public String getSharedFlg() {
        return sharedFlg;
    }

    public void setSharedFlg(String sharedFlg) {
        this.sharedFlg = sharedFlg;
    }

    public String getBindOnlyFlg() {
        return bindOnlyFlg;
    }

    public void setBindOnlyFlg(String bindOnlyFlg) {
        this.bindOnlyFlg = bindOnlyFlg;
    }

    public String getMadeBy() {
        return madeBy;
    }

    public void setMadeBy(String madeBy) {
        this.madeBy = madeBy;
    }

    public String getMadeAt() {
        return madeAt;
    }

    public void setMadeAt(String madeAt) {
        this.madeAt = madeAt;
    }

}

