package jp.co.hisas.career.app.talent.api.shareptc;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class SharePtcEvRslt extends AbstractEventResult {

	public List<Map<String, String>> ptcList;
	
}
