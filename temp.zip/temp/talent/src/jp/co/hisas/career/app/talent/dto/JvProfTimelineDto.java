/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.talent.dto;

import java.io.Serializable;

public class JvProfTimelineDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String cmpaCd;
    private String stfNo;
    private Integer seqNo;
    private String tlDate;
    private String tlPtnCd;
    private String title;
    private String note;

    public String getCmpaCd() {
        return cmpaCd;
    }

    public void setCmpaCd(String cmpaCd) {
        this.cmpaCd = cmpaCd;
    }

    public String getStfNo() {
        return stfNo;
    }

    public void setStfNo(String stfNo) {
        this.stfNo = stfNo;
    }

    public Integer getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }

    public String getTlDate() {
        return tlDate;
    }

    public void setTlDate(String tlDate) {
        this.tlDate = tlDate;
    }

    public String getTlPtnCd() {
        return tlPtnCd;
    }

    public void setTlPtnCd(String tlPtnCd) {
        this.tlPtnCd = tlPtnCd;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

}

