/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.talent.dto;

import java.io.Serializable;

public class VPzTcValueDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String personId;
    private String kenmuNo;
    private String personZokuseiId;
    private Integer rowNo;
    private String personZokuseiValue;
    private String updatePersonId;
    private String updateFunction;
    private String updateDate;
    private String updateTime;

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public String getKenmuNo() {
        return kenmuNo;
    }

    public void setKenmuNo(String kenmuNo) {
        this.kenmuNo = kenmuNo;
    }

    public String getPersonZokuseiId() {
        return personZokuseiId;
    }

    public void setPersonZokuseiId(String personZokuseiId) {
        this.personZokuseiId = personZokuseiId;
    }

    public Integer getRowNo() {
        return rowNo;
    }

    public void setRowNo(Integer rowNo) {
        this.rowNo = rowNo;
    }

    public String getPersonZokuseiValue() {
        return personZokuseiValue;
    }

    public void setPersonZokuseiValue(String personZokuseiValue) {
        this.personZokuseiValue = personZokuseiValue;
    }

    public String getUpdatePersonId() {
        return updatePersonId;
    }

    public void setUpdatePersonId(String updatePersonId) {
        this.updatePersonId = updatePersonId;
    }

    public String getUpdateFunction() {
        return updateFunction;
    }

    public void setUpdateFunction(String updateFunction) {
        this.updateFunction = updateFunction;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

}

