package jp.co.hisas.career.app.talent.api.history.search;

import java.util.Set;

import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class HistorySearchEvRslt extends AbstractEventResult {

	public Set<String> logs;
	
}
