/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.talent.dto;

import java.io.Serializable;

public class JvTrMyfoldTalentDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String myfoldId;
    private String tgtCmpaCd;
    private String tgtStfNo;

    public String getMyfoldId() {
        return myfoldId;
    }

    public void setMyfoldId(String myfoldId) {
        this.myfoldId = myfoldId;
    }

    public String getTgtCmpaCd() {
        return tgtCmpaCd;
    }

    public void setTgtCmpaCd(String tgtCmpaCd) {
        this.tgtCmpaCd = tgtCmpaCd;
    }

    public String getTgtStfNo() {
        return tgtStfNo;
    }

    public void setTgtStfNo(String tgtStfNo) {
        this.tgtStfNo = tgtStfNo;
    }

}

