/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.talent.dto;

import java.io.Serializable;

public class JvDfQuickAllDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String pzId;
    private String requiredFmt;
    private Integer priority;

    public String getPzId() {
        return pzId;
    }

    public void setPzId(String pzId) {
        this.pzId = pzId;
    }

    public String getRequiredFmt() {
        return requiredFmt;
    }

    public void setRequiredFmt(String requiredFmt) {
        this.requiredFmt = requiredFmt;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

}

