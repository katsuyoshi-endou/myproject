package jp.co.hisas.career.app.talent.mold;

import java.io.Serializable;

public class TimelineMold implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	public int seqNo;
	public String date;
	public String ptnCd;
	public String icon;
	public String color;
	public String label;
	public String title;
	public String note;
	
}
