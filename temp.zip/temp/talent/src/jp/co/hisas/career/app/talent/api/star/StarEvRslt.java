package jp.co.hisas.career.app.talent.api.star;

import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class StarEvRslt extends AbstractEventResult {
	
}
