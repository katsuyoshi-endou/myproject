/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.talent.dto;

import java.io.Serializable;

public class JvDfTimelinePtnDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String tlPtnCd;
    private String icon;
    private String color;
    private String label;

    public String getTlPtnCd() {
        return tlPtnCd;
    }

    public void setTlPtnCd(String tlPtnCd) {
        this.tlPtnCd = tlPtnCd;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

}

