require 'yaml'

db = YAML.load_file('database.yml')

# print
db["user"].each do |u|
  usr = u[1].slice /^\w+/
  puts "Writing... #{usr}"
  `sqlplus #{u[1]}@#{db["database"]} @object_summary.sql #{usr}`
end

# trim
db["user"].each do |u|
  usr = u[1].slice /^\w+/
  r = File.open("result/#{usr}.tsv").read
  r.gsub!(/ +$/, '')
  open("result/#{usr}.tsv", "w") do |f|
    f.write(r)
  end
end

# delete
begin
  File.unlink "result/merge.tsv"
rescue
end

# merge
db["user"].each do |u|
  usr = u[1].slice /^\w+/
  open("result/merge.tsv", "a") do |f|
    r = File.open("result/#{usr}.tsv").read
    f.write(r)
  end
end
