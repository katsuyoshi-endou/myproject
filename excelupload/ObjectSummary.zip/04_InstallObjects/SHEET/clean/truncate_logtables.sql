truncate table CJS_LOG_SOUSA
/
truncate table CST_SHEET_ACTION_LOG
/
truncate table CST_SHEET_SRCH_RSLT
/
truncate table JV_SRCH_COND_HIST
/
truncate table JV_SRCH_COND_HIST_DTL_LGC
/
truncate table JV_SRCH_COND_HIST_DTL_MLT
/
truncate table JV_SRCH_COND_HIST_DTL_SGL
/
truncate table JV_SRCH_PCUP
/
truncate table JV_SRCH_RSLT_WK
/
truncate table MAIL_INFO
/
