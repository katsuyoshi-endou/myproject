truncate table UP_BATCH_TRACE_LOG
/
