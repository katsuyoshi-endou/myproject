create or replace synonym `UserArchive`.UP_DF_CORE_DATE for `UserUpstream`.UP_DF_CORE_DATE
/
grant all on `UserUpstream`.UP_DF_CORE_DATE to `UserArchive` with grant option
/
create or replace synonym `UserCareer`.UP_DF_CORE_DATE for `UserUpstream`.UP_DF_CORE_DATE
/
grant all on `UserUpstream`.UP_DF_CORE_DATE to `UserCareer` with grant option
/
create or replace synonym `UserAdmin`.UP_DF_CORE_DATE for `UserUpstream`.UP_DF_CORE_DATE
/
grant all on `UserUpstream`.UP_DF_CORE_DATE to `UserAdmin` with grant option
/
