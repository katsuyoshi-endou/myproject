create or replace synonym `UserSheet`.PLPKG_CA_COMMON for `UserUpstream`.PLPKG_CA_COMMON
/
grant all on `UserUpstream`.PLPKG_CA_COMMON to `UserSheet` with grant option
/
create or replace synonym `UserSheet`.BATCH_WEB_DEL_SHEET for `UserUpstream`.BATCH_WEB_DEL_SHEET
/
grant all on `UserUpstream`.BATCH_WEB_DEL_SHEET to `UserSheet` with grant option
/
create or replace synonym `UserSheet`.BATCH_WEB_NEW_SHEET for `UserUpstream`.BATCH_WEB_NEW_SHEET
/
grant all on `UserUpstream`.BATCH_WEB_NEW_SHEET to `UserSheet` with grant option
/
