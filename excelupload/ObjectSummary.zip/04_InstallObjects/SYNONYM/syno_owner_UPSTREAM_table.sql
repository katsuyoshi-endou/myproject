create or replace synonym `UserArchive`.UP_DF_CS_DSTRBT_PTN for `UserUpstream`.UP_DF_CS_DSTRBT_PTN
/
grant all on `UserUpstream`.UP_DF_CS_DSTRBT_PTN to `UserArchive` with grant option
/
create or replace synonym `UserTalent`.UP_DF_JV_HRZ_TO_VRT for `UserUpstream`.UP_DF_JV_HRZ_TO_VRT
/
grant all on `UserUpstream`.UP_DF_JV_HRZ_TO_VRT to `UserTalent` with grant option
/
create or replace synonym `UserAdmin`.UP_DF_CS_ACTOR_OPT for `UserUpstream`.UP_DF_CS_ACTOR_OPT
/
grant all on `UserUpstream`.UP_DF_CS_ACTOR_OPT to `UserAdmin` with grant option
/
create or replace synonym `UserAdmin`.UP_DF_JV_BIND_DEPT_OPT for `UserUpstream`.UP_DF_JV_BIND_DEPT_OPT
/
grant all on `UserUpstream`.UP_DF_JV_BIND_DEPT_OPT to `UserAdmin` with grant option
/

