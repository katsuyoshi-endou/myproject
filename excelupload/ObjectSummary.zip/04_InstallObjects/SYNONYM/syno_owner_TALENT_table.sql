create or replace synonym `UserUpstream`.JV_PROF_PHOTO for `UserTalent`.JV_PROF_PHOTO
/
grant all on `UserTalent`.JV_PROF_PHOTO to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_ROLE_MASTER for `UserTalent`.JV_ROLE_MASTER
/
grant all on `UserTalent`.JV_ROLE_MASTER to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_SRCH_BIND for `UserTalent`.JV_SRCH_BIND
/
grant all on `UserTalent`.JV_SRCH_BIND to `UserUpstream` with grant option
/


create or replace synonym `UserUpstream`.JV_HRZ_01_BX for `UserTalent`.JV_HRZ_01_BX
/
grant all on `UserTalent`.JV_HRZ_01_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_01_LT for `UserTalent`.JV_HRZ_01_LT
/
grant all on `UserTalent`.JV_HRZ_01_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_02_BX for `UserTalent`.JV_HRZ_02_BX
/
grant all on `UserTalent`.JV_HRZ_02_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_02_LT for `UserTalent`.JV_HRZ_02_LT
/
grant all on `UserTalent`.JV_HRZ_02_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_03_BX for `UserTalent`.JV_HRZ_03_BX
/
grant all on `UserTalent`.JV_HRZ_03_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_03_LT for `UserTalent`.JV_HRZ_03_LT
/
grant all on `UserTalent`.JV_HRZ_03_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_04_BX for `UserTalent`.JV_HRZ_04_BX
/
grant all on `UserTalent`.JV_HRZ_04_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_04_LT for `UserTalent`.JV_HRZ_04_LT
/
grant all on `UserTalent`.JV_HRZ_04_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_05_BX for `UserTalent`.JV_HRZ_05_BX
/
grant all on `UserTalent`.JV_HRZ_05_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_05_LT for `UserTalent`.JV_HRZ_05_LT
/
grant all on `UserTalent`.JV_HRZ_05_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_06_BX for `UserTalent`.JV_HRZ_06_BX
/
grant all on `UserTalent`.JV_HRZ_06_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_06_LT for `UserTalent`.JV_HRZ_06_LT
/
grant all on `UserTalent`.JV_HRZ_06_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_07_BX for `UserTalent`.JV_HRZ_07_BX
/
grant all on `UserTalent`.JV_HRZ_07_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_07_LT for `UserTalent`.JV_HRZ_07_LT
/
grant all on `UserTalent`.JV_HRZ_07_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_08_BX for `UserTalent`.JV_HRZ_08_BX
/
grant all on `UserTalent`.JV_HRZ_08_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_08_LT for `UserTalent`.JV_HRZ_08_LT
/
grant all on `UserTalent`.JV_HRZ_08_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_09_BX for `UserTalent`.JV_HRZ_09_BX
/
grant all on `UserTalent`.JV_HRZ_09_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_09_LT for `UserTalent`.JV_HRZ_09_LT
/
grant all on `UserTalent`.JV_HRZ_09_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_10_BX for `UserTalent`.JV_HRZ_10_BX
/
grant all on `UserTalent`.JV_HRZ_10_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_10_LT for `UserTalent`.JV_HRZ_10_LT
/
grant all on `UserTalent`.JV_HRZ_10_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_11_BX for `UserTalent`.JV_HRZ_11_BX
/
grant all on `UserTalent`.JV_HRZ_11_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_11_LT for `UserTalent`.JV_HRZ_11_LT
/
grant all on `UserTalent`.JV_HRZ_11_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_12_BX for `UserTalent`.JV_HRZ_12_BX
/
grant all on `UserTalent`.JV_HRZ_12_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_12_LT for `UserTalent`.JV_HRZ_12_LT
/
grant all on `UserTalent`.JV_HRZ_12_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_13_BX for `UserTalent`.JV_HRZ_13_BX
/
grant all on `UserTalent`.JV_HRZ_13_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_13_LT for `UserTalent`.JV_HRZ_13_LT
/
grant all on `UserTalent`.JV_HRZ_13_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_14_BX for `UserTalent`.JV_HRZ_14_BX
/
grant all on `UserTalent`.JV_HRZ_14_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_14_LT for `UserTalent`.JV_HRZ_14_LT
/
grant all on `UserTalent`.JV_HRZ_14_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_15_BX for `UserTalent`.JV_HRZ_15_BX
/
grant all on `UserTalent`.JV_HRZ_15_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_15_LT for `UserTalent`.JV_HRZ_15_LT
/
grant all on `UserTalent`.JV_HRZ_15_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_16_BX for `UserTalent`.JV_HRZ_16_BX
/
grant all on `UserTalent`.JV_HRZ_16_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_16_LT for `UserTalent`.JV_HRZ_16_LT
/
grant all on `UserTalent`.JV_HRZ_16_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_17_BX for `UserTalent`.JV_HRZ_17_BX
/
grant all on `UserTalent`.JV_HRZ_17_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_17_LT for `UserTalent`.JV_HRZ_17_LT
/
grant all on `UserTalent`.JV_HRZ_17_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_18_BX for `UserTalent`.JV_HRZ_18_BX
/
grant all on `UserTalent`.JV_HRZ_18_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_18_LT for `UserTalent`.JV_HRZ_18_LT
/
grant all on `UserTalent`.JV_HRZ_18_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_19_BX for `UserTalent`.JV_HRZ_19_BX
/
grant all on `UserTalent`.JV_HRZ_19_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_19_LT for `UserTalent`.JV_HRZ_19_LT
/
grant all on `UserTalent`.JV_HRZ_19_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_20_BX for `UserTalent`.JV_HRZ_20_BX
/
grant all on `UserTalent`.JV_HRZ_20_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_20_LT for `UserTalent`.JV_HRZ_20_LT
/
grant all on `UserTalent`.JV_HRZ_20_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_21_BX for `UserTalent`.JV_HRZ_21_BX
/
grant all on `UserTalent`.JV_HRZ_21_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_21_LT for `UserTalent`.JV_HRZ_21_LT
/
grant all on `UserTalent`.JV_HRZ_21_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_22_BX for `UserTalent`.JV_HRZ_22_BX
/
grant all on `UserTalent`.JV_HRZ_22_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_22_LT for `UserTalent`.JV_HRZ_22_LT
/
grant all on `UserTalent`.JV_HRZ_22_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_23_BX for `UserTalent`.JV_HRZ_23_BX
/
grant all on `UserTalent`.JV_HRZ_23_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_23_LT for `UserTalent`.JV_HRZ_23_LT
/
grant all on `UserTalent`.JV_HRZ_23_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_24_BX for `UserTalent`.JV_HRZ_24_BX
/
grant all on `UserTalent`.JV_HRZ_24_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_24_LT for `UserTalent`.JV_HRZ_24_LT
/
grant all on `UserTalent`.JV_HRZ_24_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_25_BX for `UserTalent`.JV_HRZ_25_BX
/
grant all on `UserTalent`.JV_HRZ_25_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_25_LT for `UserTalent`.JV_HRZ_25_LT
/
grant all on `UserTalent`.JV_HRZ_25_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_26_BX for `UserTalent`.JV_HRZ_26_BX
/
grant all on `UserTalent`.JV_HRZ_26_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_26_LT for `UserTalent`.JV_HRZ_26_LT
/
grant all on `UserTalent`.JV_HRZ_26_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_27_BX for `UserTalent`.JV_HRZ_27_BX
/
grant all on `UserTalent`.JV_HRZ_27_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_27_LT for `UserTalent`.JV_HRZ_27_LT
/
grant all on `UserTalent`.JV_HRZ_27_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_28_BX for `UserTalent`.JV_HRZ_28_BX
/
grant all on `UserTalent`.JV_HRZ_28_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_28_LT for `UserTalent`.JV_HRZ_28_LT
/
grant all on `UserTalent`.JV_HRZ_28_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_29_BX for `UserTalent`.JV_HRZ_29_BX
/
grant all on `UserTalent`.JV_HRZ_29_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_29_LT for `UserTalent`.JV_HRZ_29_LT
/
grant all on `UserTalent`.JV_HRZ_29_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_30_BX for `UserTalent`.JV_HRZ_30_BX
/
grant all on `UserTalent`.JV_HRZ_30_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_HRZ_30_LT for `UserTalent`.JV_HRZ_30_LT
/
grant all on `UserTalent`.JV_HRZ_30_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_01_BX for `UserTalent`.JV_VRT_01_BX
/
grant all on `UserTalent`.JV_VRT_01_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_01_LT for `UserTalent`.JV_VRT_01_LT
/
grant all on `UserTalent`.JV_VRT_01_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_02_BX for `UserTalent`.JV_VRT_02_BX
/
grant all on `UserTalent`.JV_VRT_02_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_02_LT for `UserTalent`.JV_VRT_02_LT
/
grant all on `UserTalent`.JV_VRT_02_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_03_BX for `UserTalent`.JV_VRT_03_BX
/
grant all on `UserTalent`.JV_VRT_03_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_03_LT for `UserTalent`.JV_VRT_03_LT
/
grant all on `UserTalent`.JV_VRT_03_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_04_BX for `UserTalent`.JV_VRT_04_BX
/
grant all on `UserTalent`.JV_VRT_04_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_04_LT for `UserTalent`.JV_VRT_04_LT
/
grant all on `UserTalent`.JV_VRT_04_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_05_BX for `UserTalent`.JV_VRT_05_BX
/
grant all on `UserTalent`.JV_VRT_05_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_05_LT for `UserTalent`.JV_VRT_05_LT
/
grant all on `UserTalent`.JV_VRT_05_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_06_BX for `UserTalent`.JV_VRT_06_BX
/
grant all on `UserTalent`.JV_VRT_06_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_06_LT for `UserTalent`.JV_VRT_06_LT
/
grant all on `UserTalent`.JV_VRT_06_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_07_BX for `UserTalent`.JV_VRT_07_BX
/
grant all on `UserTalent`.JV_VRT_07_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_07_LT for `UserTalent`.JV_VRT_07_LT
/
grant all on `UserTalent`.JV_VRT_07_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_08_BX for `UserTalent`.JV_VRT_08_BX
/
grant all on `UserTalent`.JV_VRT_08_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_08_LT for `UserTalent`.JV_VRT_08_LT
/
grant all on `UserTalent`.JV_VRT_08_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_09_BX for `UserTalent`.JV_VRT_09_BX
/
grant all on `UserTalent`.JV_VRT_09_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_09_LT for `UserTalent`.JV_VRT_09_LT
/
grant all on `UserTalent`.JV_VRT_09_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_10_BX for `UserTalent`.JV_VRT_10_BX
/
grant all on `UserTalent`.JV_VRT_10_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_10_LT for `UserTalent`.JV_VRT_10_LT
/
grant all on `UserTalent`.JV_VRT_10_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_11_BX for `UserTalent`.JV_VRT_11_BX
/
grant all on `UserTalent`.JV_VRT_11_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_11_LT for `UserTalent`.JV_VRT_11_LT
/
grant all on `UserTalent`.JV_VRT_11_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_12_BX for `UserTalent`.JV_VRT_12_BX
/
grant all on `UserTalent`.JV_VRT_12_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_12_LT for `UserTalent`.JV_VRT_12_LT
/
grant all on `UserTalent`.JV_VRT_12_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_13_BX for `UserTalent`.JV_VRT_13_BX
/
grant all on `UserTalent`.JV_VRT_13_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_13_LT for `UserTalent`.JV_VRT_13_LT
/
grant all on `UserTalent`.JV_VRT_13_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_14_BX for `UserTalent`.JV_VRT_14_BX
/
grant all on `UserTalent`.JV_VRT_14_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_14_LT for `UserTalent`.JV_VRT_14_LT
/
grant all on `UserTalent`.JV_VRT_14_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_15_BX for `UserTalent`.JV_VRT_15_BX
/
grant all on `UserTalent`.JV_VRT_15_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_15_LT for `UserTalent`.JV_VRT_15_LT
/
grant all on `UserTalent`.JV_VRT_15_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_16_BX for `UserTalent`.JV_VRT_16_BX
/
grant all on `UserTalent`.JV_VRT_16_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_16_LT for `UserTalent`.JV_VRT_16_LT
/
grant all on `UserTalent`.JV_VRT_16_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_17_BX for `UserTalent`.JV_VRT_17_BX
/
grant all on `UserTalent`.JV_VRT_17_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_17_LT for `UserTalent`.JV_VRT_17_LT
/
grant all on `UserTalent`.JV_VRT_17_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_18_BX for `UserTalent`.JV_VRT_18_BX
/
grant all on `UserTalent`.JV_VRT_18_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_18_LT for `UserTalent`.JV_VRT_18_LT
/
grant all on `UserTalent`.JV_VRT_18_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_19_BX for `UserTalent`.JV_VRT_19_BX
/
grant all on `UserTalent`.JV_VRT_19_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_19_LT for `UserTalent`.JV_VRT_19_LT
/
grant all on `UserTalent`.JV_VRT_19_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_20_BX for `UserTalent`.JV_VRT_20_BX
/
grant all on `UserTalent`.JV_VRT_20_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_20_LT for `UserTalent`.JV_VRT_20_LT
/
grant all on `UserTalent`.JV_VRT_20_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_21_BX for `UserTalent`.JV_VRT_21_BX
/
grant all on `UserTalent`.JV_VRT_21_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_21_LT for `UserTalent`.JV_VRT_21_LT
/
grant all on `UserTalent`.JV_VRT_21_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_22_BX for `UserTalent`.JV_VRT_22_BX
/
grant all on `UserTalent`.JV_VRT_22_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_22_LT for `UserTalent`.JV_VRT_22_LT
/
grant all on `UserTalent`.JV_VRT_22_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_23_BX for `UserTalent`.JV_VRT_23_BX
/
grant all on `UserTalent`.JV_VRT_23_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_23_LT for `UserTalent`.JV_VRT_23_LT
/
grant all on `UserTalent`.JV_VRT_23_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_24_BX for `UserTalent`.JV_VRT_24_BX
/
grant all on `UserTalent`.JV_VRT_24_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_24_LT for `UserTalent`.JV_VRT_24_LT
/
grant all on `UserTalent`.JV_VRT_24_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_25_BX for `UserTalent`.JV_VRT_25_BX
/
grant all on `UserTalent`.JV_VRT_25_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_25_LT for `UserTalent`.JV_VRT_25_LT
/
grant all on `UserTalent`.JV_VRT_25_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_26_BX for `UserTalent`.JV_VRT_26_BX
/
grant all on `UserTalent`.JV_VRT_26_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_26_LT for `UserTalent`.JV_VRT_26_LT
/
grant all on `UserTalent`.JV_VRT_26_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_27_BX for `UserTalent`.JV_VRT_27_BX
/
grant all on `UserTalent`.JV_VRT_27_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_27_LT for `UserTalent`.JV_VRT_27_LT
/
grant all on `UserTalent`.JV_VRT_27_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_28_BX for `UserTalent`.JV_VRT_28_BX
/
grant all on `UserTalent`.JV_VRT_28_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_28_LT for `UserTalent`.JV_VRT_28_LT
/
grant all on `UserTalent`.JV_VRT_28_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_29_BX for `UserTalent`.JV_VRT_29_BX
/
grant all on `UserTalent`.JV_VRT_29_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_29_LT for `UserTalent`.JV_VRT_29_LT
/
grant all on `UserTalent`.JV_VRT_29_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_30_BX for `UserTalent`.JV_VRT_30_BX
/
grant all on `UserTalent`.JV_VRT_30_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_30_LT for `UserTalent`.JV_VRT_30_LT
/
grant all on `UserTalent`.JV_VRT_30_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_NUMBER_BX for `UserTalent`.JV_VRT_NUMBER_BX
/
grant all on `UserTalent`.JV_VRT_NUMBER_BX to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_VRT_NUMBER_LT for `UserTalent`.JV_VRT_NUMBER_LT
/
grant all on `UserTalent`.JV_VRT_NUMBER_LT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_SRCH_COLS_PTN_X for `UserTalent`.JV_SRCH_COLS_PTN_X
/
grant all on `UserTalent`.JV_SRCH_COLS_PTN_X to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_SRCH_COLS_PTN_A for `UserTalent`.JV_SRCH_COLS_PTN_A
/
grant all on `UserTalent`.JV_SRCH_COLS_PTN_A to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_SRCH_COLS_PTN_B for `UserTalent`.JV_SRCH_COLS_PTN_B
/
grant all on `UserTalent`.JV_SRCH_COLS_PTN_B to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_SRCH_COLS_PTN_C for `UserTalent`.JV_SRCH_COLS_PTN_C
/
grant all on `UserTalent`.JV_SRCH_COLS_PTN_C to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_SRCH_COLS_PTN_D for `UserTalent`.JV_SRCH_COLS_PTN_D
/
grant all on `UserTalent`.JV_SRCH_COLS_PTN_D to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_SRCH_COLS_PTN_E for `UserTalent`.JV_SRCH_COLS_PTN_E
/
grant all on `UserTalent`.JV_SRCH_COLS_PTN_E to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_SRCH_COLS_PTN_F for `UserTalent`.JV_SRCH_COLS_PTN_F
/
grant all on `UserTalent`.JV_SRCH_COLS_PTN_F to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_SRCH_COLS_PTN_G for `UserTalent`.JV_SRCH_COLS_PTN_G
/
grant all on `UserTalent`.JV_SRCH_COLS_PTN_G to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_SRCH_COLS_PTN_H for `UserTalent`.JV_SRCH_COLS_PTN_H
/
grant all on `UserTalent`.JV_SRCH_COLS_PTN_H to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_SRCH_COLS_PTN_I for `UserTalent`.JV_SRCH_COLS_PTN_I
/
grant all on `UserTalent`.JV_SRCH_COLS_PTN_I to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.JV_SRCH_COLS_PTN_J for `UserTalent`.JV_SRCH_COLS_PTN_J
/
grant all on `UserTalent`.JV_SRCH_COLS_PTN_J to `UserUpstream` with grant option
/
