create or replace synonym `UserSheet`.LYG_LOGIN for `UserPortal`.LYG_LOGIN
/
grant all on `UserPortal`.LYG_LOGIN to `UserSheet` with grant option
/
create or replace synonym `UserAdmin`.LYG_LOGIN for `UserPortal`.LYG_LOGIN
/
grant all on `UserPortal`.LYG_LOGIN to `UserAdmin` with grant option
/
create or replace synonym `UserTalent`.LYG_LOGIN for `UserPortal`.LYG_LOGIN
/
grant all on `UserPortal`.LYG_LOGIN to `UserTalent` with grant option
/
create or replace synonym `UserGraph`.LYG_LOGIN for `UserPortal`.LYG_LOGIN
/
grant all on `UserPortal`.LYG_LOGIN to `UserGraph` with grant option
/
create or replace synonym `UserGraph`.LYG_ACCOUNT_PROPERTY for `UserPortal`.LYG_ACCOUNT_PROPERTY
/
grant all on `UserPortal`.LYG_ACCOUNT_PROPERTY to `UserGraph` with grant option
/
create or replace synonym `UserUpstream`.LYG_ACCOUNT for `UserPortal`.LYG_ACCOUNT
/
grant all on `UserPortal`.LYG_ACCOUNT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.LYG_CERT for `UserPortal`.LYG_CERT
/
grant all on `UserPortal`.LYG_CERT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.LYG_ACCOUNT_ROLE for `UserPortal`.LYG_ACCOUNT_ROLE
/
grant all on `UserPortal`.LYG_ACCOUNT_ROLE to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.LYP_ACCOUNT_PARTY for `UserPortal`.LYP_ACCOUNT_PARTY
/
grant all on `UserPortal`.LYP_ACCOUNT_PARTY to `UserUpstream` with grant option
/





