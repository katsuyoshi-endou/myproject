create or replace synonym `UserArchive`.CSM_SHEET_OPERATION for `UserSheet`.CSM_SHEET_OPERATION
/
grant all on `UserSheet`.CSM_SHEET_OPERATION to `UserArchive` with grant option
/
create or replace synonym `UserUpstream`.CSM_SHEET_OPERATION for `UserSheet`.CSM_SHEET_OPERATION
/
grant all on `UserSheet`.CSM_SHEET_OPERATION to `UserUpstream` with grant option
/
create or replace synonym `UserAdmin`.CSM_SHEET_OPERATION for `UserSheet`.CSM_SHEET_OPERATION
/
grant all on `UserSheet`.CSM_SHEET_OPERATION to `UserAdmin` with grant option
/
create or replace synonym `UserUpstream`.CS_RSV_DEL_SHEET for `UserSheet`.CS_RSV_DEL_SHEET
/
grant all on `UserSheet`.CS_RSV_DEL_SHEET to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.CS_RSV_FILL for `UserSheet`.CS_RSV_FILL
/
grant all on `UserSheet`.CS_RSV_FILL to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.CS_RSV_ACTOR for `UserSheet`.CS_RSV_ACTOR
/
grant all on `UserSheet`.CS_RSV_ACTOR to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.CS_RSV_ATTR for `UserSheet`.CS_RSV_ATTR
/
grant all on `UserSheet`.CS_RSV_ATTR to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.CS_RSV_DSTRBT for `UserSheet`.CS_RSV_DSTRBT
/
grant all on `UserSheet`.CS_RSV_DSTRBT to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.CST_SHEET for `UserSheet`.CST_SHEET
/
grant all on `UserSheet`.CST_SHEET to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.CST_SHEET_ATTR for `UserSheet`.CST_SHEET_ATTR
/
grant all on `UserSheet`.CST_SHEET_ATTR to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.CST_SHEET_ACTOR for `UserSheet`.CST_SHEET_ACTOR
/
grant all on `UserSheet`.CST_SHEET_ACTOR to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.CST_SHEET_FILL for `UserSheet`.CST_SHEET_FILL
/
grant all on `UserSheet`.CST_SHEET_FILL to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.CST_SHEET_ACTOR_REF for `UserSheet`.CST_SHEET_ACTOR_REF
/
grant all on `UserSheet`.CST_SHEET_ACTOR_REF to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.CST_SHEET_ACTION_LOG for `UserSheet`.CST_SHEET_ACTION_LOG
/
grant all on `UserSheet`.CST_SHEET_ACTION_LOG to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.CST_SHEET_EXCLUSIVE for `UserSheet`.CST_SHEET_EXCLUSIVE
/
grant all on `UserSheet`.CST_SHEET_EXCLUSIVE to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.CSM_SHEET_FORM for `UserSheet`.CSM_SHEET_FORM
/
grant all on `UserSheet`.CSM_SHEET_FORM to `UserUpstream` with grant option
/
create or replace synonym `UserUpstream`.CSM_SHEET_ACTOR for `UserSheet`.CSM_SHEET_ACTOR
/
grant all on `UserSheet`.CSM_SHEET_ACTOR to `UserUpstream` with grant option
/
create or replace synonym `UserAdmin`.CSM_SHEET_LABEL for `UserSheet`.CSM_SHEET_LABEL
/
grant all on `UserSheet`.CSM_SHEET_LABEL to `UserAdmin` with grant option
/


