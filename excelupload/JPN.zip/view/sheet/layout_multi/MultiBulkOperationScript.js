function execBulkOperSheetJQuery(vm) {

  /**
   ** Initialize
  **/
  /* 入力した検索条件の復元 */
  $( 'select[name="knskPersonId"]'    ).val( vm.jotaiMap.knskPersonId );
  $( 'select[name="knskDeptNm"]'      ).val( vm.jotaiMap.knskDeptNm );
  $( 'select[name="knskOperationCd"]' ).val( vm.jotaiMap.knskOperationCd );
  $( 'select[name="knskPersonNm"]'    ).val( vm.jotaiMap.knskPersonNm );
  $( 'select[name="knskCmpaCd"]'      ).val( vm.jotaiMap.knskCmpaCd );
  $( 'select[name="knskStatusCd"]'    ).val( vm.jotaiMap.knskStatusCd );


  /**
   ** Event
  **/

  /**
   * 「検索」ボタン押下
   */
  $(document).on( 'click', '#btnSEARCH', function(){
    pageSubmit('/servlet/BulkOperSheetServlet', 'SEARCH');
  });

  /**
   * 「評価シート」ドロップダウン変更
   */
  $('select[name="knskOperationCd"]').bind('change', function(){
    $('.hideTgt').css('display', 'none');
    $('.hideTgtCnt').text('');

    pageSubmit('/servlet/BulkOperSheetServlet', 'CHANGE_OPERATION');
  });

  /**
   * 「会社」、「ステータス」ドロップダウン変更
   */
  $(document).on('change', '.hideTrg', function(e){
    $('.hideTgt').css('display', 'none');
    $('.hideTgtCnt').text('');
  });

  /**
   * 「（ステータス変更）対象外へ」ボタン押下
   */
  $(document).on( 'click', '#btn_SKIP', function(){
    openStausChangeModal();

//    document.F001.chg_status_type.value = 'SKIP';
//    pageSubmit('/servlet/BulkOperSheetServlet', 'CHG_STATUS');
  });

  /**
   * 「Excelダウンロード」ボタン押下
   */
  $(document).on('click', '#xldownload', function(e){
    e.preventDefault();
//    var xlTemplate = $(this).attr('data-xltemplate');
//    if (xlTemplate == '') {
//      return false;
//    }
    var sqlprop = $(this).attr('data-sqlprop');
    if (sqlprop == '') {
      return false;
    }
    downloadXlsxFileWithSqlprop( vm.jotaiMap.operationCd, "", sqlprop );
  });
}

function downloadXlsxFileWithSqlprop(xlTemplatePrefix, xlTemplateId, sqlPropKey) {
  if (!chkTimeout()) { return false; }
  document.F001.action = App.root + "/servlet/BulkOperSheetServlet";
  document.F001.state.value = "EXCEL_DL";
  makeRequestParameter( "xlTemplateType", 'SQLPROP' );
  makeRequestParameter( "xlTemplatePrefix", "evaluatee" );
  makeRequestParameter( "xlTemplateId", "list" );
  makeRequestParameter( "sqlPropKey", sqlPropKey );
  document.F001.target = "_self";
  document.F001.submit();
  showBlockingOverlay();
}

function applyChangeActor( actorCd, chgGuid ) {
	pageSubmit( '/view/CsActorServlet', 'CHG_ALL_ACT' );
}
