/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSMシートレイアウト Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetLayoutDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PARTY
     */
    private String party;
    /**
     * レイアウトコード
     */
    private String layoutCd;
    /**
     * バージョン
     */
    private String version;
    /**
     * テンプレートファイル
     */
    private String templateFile;

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * レイアウトコードを取得する。
     * @return レイアウトコード
     */
    public String getLayoutCd() {
        return layoutCd;
    }

    /**
     * レイアウトコードを設定する。
     * @param layoutCd レイアウトコード
     */
    public void setLayoutCd(String layoutCd) {
        this.layoutCd = layoutCd;
    }

    /**
     * バージョンを取得する。
     * @return バージョン
     */
    public String getVersion() {
        return version;
    }

    /**
     * バージョンを設定する。
     * @param version バージョン
     */
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * テンプレートファイルを取得する。
     * @return テンプレートファイル
     */
    public String getTemplateFile() {
        return templateFile;
    }

    /**
     * テンプレートファイルを設定する。
     * @param templateFile テンプレートファイル
     */
    public void setTemplateFile(String templateFile) {
        this.templateFile = templateFile;
    }

}

