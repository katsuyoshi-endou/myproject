package jp.co.hisas.career.app.sheet.event;

import jp.co.hisas.career.ejb.AbstractEventResult;

public class MultiEditJinikUploadEvRslt extends AbstractEventResult {

	public String resultMsg = null;
}
