/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSMシート運用 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetOperationDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PARTY
     */
    private String party;
    /**
     * OPERATION_CD
     */
    private String operationCd;
    /**
     * OPERATION_NM
     */
    private String operationNm;
    /**
     * OPERATION_TYPE
     */
    private String operationType;
    /**
     * LPAD_SORT
     */
    private String lpadSort;
    /**
     * OPEN_FLG
     */
    private String openFlg;
    /**
     * ACTIVE_FLG
     */
    private String activeFlg;

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * OPERATION_CDを取得する。
     * @return OPERATION_CD
     */
    public String getOperationCd() {
        return operationCd;
    }

    /**
     * OPERATION_CDを設定する。
     * @param operationCd OPERATION_CD
     */
    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    /**
     * OPERATION_NMを取得する。
     * @return OPERATION_NM
     */
    public String getOperationNm() {
        return operationNm;
    }

    /**
     * OPERATION_NMを設定する。
     * @param operationNm OPERATION_NM
     */
    public void setOperationNm(String operationNm) {
        this.operationNm = operationNm;
    }

    /**
     * OPERATION_TYPEを取得する。
     * @return OPERATION_TYPE
     */
    public String getOperationType() {
        return operationType;
    }

    /**
     * OPERATION_TYPEを設定する。
     * @param operationType OPERATION_TYPE
     */
    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    /**
     * LPAD_SORTを取得する。
     * @return LPAD_SORT
     */
    public String getLpadSort() {
        return lpadSort;
    }

    /**
     * LPAD_SORTを設定する。
     * @param lpadSort LPAD_SORT
     */
    public void setLpadSort(String lpadSort) {
        this.lpadSort = lpadSort;
    }

    /**
     * OPEN_FLGを取得する。
     * @return OPEN_FLG
     */
    public String getOpenFlg() {
        return openFlg;
    }

    /**
     * OPEN_FLGを設定する。
     * @param openFlg OPEN_FLG
     */
    public void setOpenFlg(String openFlg) {
        this.openFlg = openFlg;
    }

    /**
     * ACTIVE_FLGを取得する。
     * @return ACTIVE_FLG
     */
    public String getActiveFlg() {
        return activeFlg;
    }

    /**
     * ACTIVE_FLGを設定する。
     * @param activeFlg ACTIVE_FLG
     */
    public void setActiveFlg(String activeFlg) {
        this.activeFlg = activeFlg;
    }

}

