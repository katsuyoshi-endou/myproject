package jp.co.hisas.career.app.sheet.command;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.common.event.CareerMenuEvArg;
import jp.co.hisas.career.app.common.event.CareerMenuEvHdlr;
import jp.co.hisas.career.app.common.event.CareerMenuEvRslt;
import jp.co.hisas.career.app.common.event.UserInfoEvArg;
import jp.co.hisas.career.app.common.event.UserInfoEvHdlr;
import jp.co.hisas.career.app.common.event.UserInfoEvRslt;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.framework.trans.StateTransitionEvent;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class PME010Command extends AbstractCommand {
	
	public static final String KINOU_ID = "VME010";
	private HttpServletRequest request;
	private HttpSession session;
	private String state;
	
	public PME010Command() {
		super( PME010Command.class, KINOU_ID, null );
	}
	
	public void init( StateTransitionEvent e ) {
		try {
			request = e.getRequest();
			session = request.getSession( false );
			CSRFTokenUtil.setNewTokenNo( request, e.getResponse() );
			state = request.getParameter( "state" );
			main();
		} catch (CareerException ex) {
			throw new CareerRuntimeException( ex );
		}
	}
	
	public void main() throws CareerException {
		
		// Clear All Session Attributes
		clearAllSessionAttributes();
		
		// Initialize UserInfo
		updateUserInfo();
		
		// 状態にかかわらず常に同じ処理を行う
		execEventInit();
		
		// Get External HTML
		getExternalHtml();
		
		/* 操作ログ */
		OutLogBean.outputLogSousa( request, KINOU_ID, null, state );
	}
	
	private void updateUserInfo() throws CareerException {
		
		/* Set Args */
		UserInfoEvArg arg = new UserInfoEvArg( super.getLoginNo() );
		arg.sharp = "INIT";
		arg.guid = super.getLoginNo();
		
		/* Execute Event */
		UserInfoEvRslt result = UserInfoEvHdlr.exec( arg );
		
		/* Update UserInfo */
		UserInfoBean userInfo = (UserInfoBean)session.getAttribute( UserInfoBean.SESSION_KEY );
		userInfo.setKanjiSimei( result.careerGuidDto.getGunm() );
		String operatorFlg = result.careerGuidDto.getOperatorFlg();
		userInfo.isOperator = "1".equals( operatorFlg );
		String operatorGuid = (userInfo.isOperator) ? AU.getCareerProperty( "OPERATOR_GUID" ) : super.getLoginNo();
		userInfo.setOperatorGuid( operatorGuid );
		
		/* Return to session */
		session.setAttribute( UserInfoBean.SESSION_KEY, userInfo );
	}
	
	private void getExternalHtml() {
		String exHtml = AU.getSessionAttr( session, "MENU_EXTERNAL_HTML" );
		if (SU.isNotBlank( exHtml )) {
			return;
		}
		String menuPtn = AU.getSessionAttr( session, AppSessionKey.CAREER_MENU_PTN );
		try {
			String filePath = AppDef.APP_DIR + "/htmltemplate/Menu_" + menuPtn + ".html";
			String str = FileUtils.readFileToString( new File( filePath ) );
			session.setAttribute( "MENU_EXTERNAL_HTML", str );
		} catch (IOException e) {
		}
	}
	
	
	private void execEventInit() throws CareerException {
		
		String menuGrp = "mg-" + AU.getParty( session );
		session.setAttribute( AppSessionKey.CAREER_MENU_GRP, menuGrp );
		
		/* Set Args */
		CareerMenuEvArg arg = new CareerMenuEvArg( super.getLoginNo() );
		arg.sharp = "INIT";
		arg.menuGrp = AU.getSessionAttr( session, AppSessionKey.CAREER_MENU_GRP );
		arg.guid = super.getLoginNo();
		
		/* Execute Event */
		CareerMenuEvRslt result = CareerMenuEvHdlr.exec( arg );
		
		/* Return to session */
		session.setAttribute( AppSessionKey.CAREER_MENU_LIST, result.careerMenuList );
		session.setAttribute( AppSessionKey.CAREER_MENU_PTN, result.careerMenuPtn );
		session.setAttribute( AppSessionKey.BASE_ROLE_ID, result.baseRoleId );
		session.setAttribute( AppSessionKey.PLAN_ROLE_ID, result.planRoleId );
	}
	
	private void clearAllSessionAttributes() {
		/* Application */
		removeSessionAttr( AppSessionKey.class.getDeclaredFields() );
		/* CareerSheet */
		removeSessionAttr( CsSessionKey.class.getDeclaredFields() );
	}
	
	private void removeSessionAttr( Field[] fields ) {
		for (Field field : fields) {
			try {
				String sessionKey = (String)field.get( field.getName() );
				session.removeAttribute( sessionKey );
			} catch (IllegalArgumentException e) {
			} catch (IllegalAccessException e) {
			}
		}
	}
	
}
