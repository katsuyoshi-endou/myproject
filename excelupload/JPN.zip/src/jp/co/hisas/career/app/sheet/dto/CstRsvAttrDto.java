/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CST_RSV_ATTR Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CstRsvAttrDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * シートID
     */
    private String sheetId;
    /**
     * 所有者人ID
     */
    private String ownPersonId;
    /**
     * 所有者氏名
     */
    private String ownPersonName;
    /**
     * シートソート
     */
    private String sheetSort;
    /**
     * 期間
     */
    private String term;
    /**
     * 部署コード
     */
    private String deptCd;
    /**
     * 部署名称
     */
    private String deptNm;
    /**
     * 連結部署コード
     */
    private String fullDeptCd;
    /**
     * 連結部署名称
     */
    private String fullDeptNm;
    /**
     * 階層
     */
    private Integer hierarchy;
    /**
     * 部までの部署コード
     */
    private String bumadeDeptCd;
    /**
     * 部までの部署名称
     */
    private String bumadeDeptNm;
    /**
     * 検索区分
     */
    private String searchDiv;
    /**
     * クラスＡコード
     */
    private String clsACd;
    /**
     * クラスＡ名称
     */
    private String clsANm;
    /**
     * クラスＢコード
     */
    private String clsBCd;
    /**
     * クラスＢ名称
     */
    private String clsBNm;
    /**
     * クラスＣコード
     */
    private String clsCCd;
    /**
     * クラスＣ名称
     */
    private String clsCNm;
    /**
     * クラスＤコード
     */
    private String clsDCd;
    /**
     * クラスＤ名称
     */
    private String clsDNm;
    /**
     * クラスＥコード
     */
    private String clsECd;
    /**
     * クラスＥ名称
     */
    private String clsENm;
    /**
     * クラスＦコード
     */
    private String clsFCd;
    /**
     * クラスＦ名称
     */
    private String clsFNm;
    /**
     * クラスＧコード
     */
    private String clsGCd;
    /**
     * クラスＧ名称
     */
    private String clsGNm;
    /**
     * クラスＨコード
     */
    private String clsHCd;
    /**
     * クラスＨ名称
     */
    private String clsHNm;
    /**
     * クラスＩコード
     */
    private String clsICd;
    /**
     * クラスＩ名称
     */
    private String clsINm;
    /**
     * クラスＪコード
     */
    private String clsJCd;
    /**
     * クラスＪ名称
     */
    private String clsJNm;

    /**
     * シートIDを取得する。
     * @return シートID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * シートIDを設定する。
     * @param sheetId シートID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * 所有者人IDを取得する。
     * @return 所有者人ID
     */
    public String getOwnPersonId() {
        return ownPersonId;
    }

    /**
     * 所有者人IDを設定する。
     * @param ownPersonId 所有者人ID
     */
    public void setOwnPersonId(String ownPersonId) {
        this.ownPersonId = ownPersonId;
    }

    /**
     * 所有者氏名を取得する。
     * @return 所有者氏名
     */
    public String getOwnPersonName() {
        return ownPersonName;
    }

    /**
     * 所有者氏名を設定する。
     * @param ownPersonName 所有者氏名
     */
    public void setOwnPersonName(String ownPersonName) {
        this.ownPersonName = ownPersonName;
    }

    /**
     * シートソートを取得する。
     * @return シートソート
     */
    public String getSheetSort() {
        return sheetSort;
    }

    /**
     * シートソートを設定する。
     * @param sheetSort シートソート
     */
    public void setSheetSort(String sheetSort) {
        this.sheetSort = sheetSort;
    }

    /**
     * 期間を取得する。
     * @return 期間
     */
    public String getTerm() {
        return term;
    }

    /**
     * 期間を設定する。
     * @param term 期間
     */
    public void setTerm(String term) {
        this.term = term;
    }

    /**
     * 部署コードを取得する。
     * @return 部署コード
     */
    public String getDeptCd() {
        return deptCd;
    }

    /**
     * 部署コードを設定する。
     * @param deptCd 部署コード
     */
    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    /**
     * 部署名称を取得する。
     * @return 部署名称
     */
    public String getDeptNm() {
        return deptNm;
    }

    /**
     * 部署名称を設定する。
     * @param deptNm 部署名称
     */
    public void setDeptNm(String deptNm) {
        this.deptNm = deptNm;
    }

    /**
     * 連結部署コードを取得する。
     * @return 連結部署コード
     */
    public String getFullDeptCd() {
        return fullDeptCd;
    }

    /**
     * 連結部署コードを設定する。
     * @param fullDeptCd 連結部署コード
     */
    public void setFullDeptCd(String fullDeptCd) {
        this.fullDeptCd = fullDeptCd;
    }

    /**
     * 連結部署名称を取得する。
     * @return 連結部署名称
     */
    public String getFullDeptNm() {
        return fullDeptNm;
    }

    /**
     * 連結部署名称を設定する。
     * @param fullDeptNm 連結部署名称
     */
    public void setFullDeptNm(String fullDeptNm) {
        this.fullDeptNm = fullDeptNm;
    }

    /**
     * 階層を取得する。
     * @return 階層
     */
    public Integer getHierarchy() {
        return hierarchy;
    }

    /**
     * 階層を設定する。
     * @param hierarchy 階層
     */
    public void setHierarchy(Integer hierarchy) {
        this.hierarchy = hierarchy;
    }

    /**
     * 部までの部署コードを取得する。
     * @return 部までの部署コード
     */
    public String getBumadeDeptCd() {
        return bumadeDeptCd;
    }

    /**
     * 部までの部署コードを設定する。
     * @param bumadeDeptCd 部までの部署コード
     */
    public void setBumadeDeptCd(String bumadeDeptCd) {
        this.bumadeDeptCd = bumadeDeptCd;
    }

    /**
     * 部までの部署名称を取得する。
     * @return 部までの部署名称
     */
    public String getBumadeDeptNm() {
        return bumadeDeptNm;
    }

    /**
     * 部までの部署名称を設定する。
     * @param bumadeDeptNm 部までの部署名称
     */
    public void setBumadeDeptNm(String bumadeDeptNm) {
        this.bumadeDeptNm = bumadeDeptNm;
    }

    /**
     * 検索区分を取得する。
     * @return 検索区分
     */
    public String getSearchDiv() {
        return searchDiv;
    }

    /**
     * 検索区分を設定する。
     * @param searchDiv 検索区分
     */
    public void setSearchDiv(String searchDiv) {
        this.searchDiv = searchDiv;
    }

    /**
     * クラスＡコードを取得する。
     * @return クラスＡコード
     */
    public String getClsACd() {
        return clsACd;
    }

    /**
     * クラスＡコードを設定する。
     * @param clsACd クラスＡコード
     */
    public void setClsACd(String clsACd) {
        this.clsACd = clsACd;
    }

    /**
     * クラスＡ名称を取得する。
     * @return クラスＡ名称
     */
    public String getClsANm() {
        return clsANm;
    }

    /**
     * クラスＡ名称を設定する。
     * @param clsANm クラスＡ名称
     */
    public void setClsANm(String clsANm) {
        this.clsANm = clsANm;
    }

    /**
     * クラスＢコードを取得する。
     * @return クラスＢコード
     */
    public String getClsBCd() {
        return clsBCd;
    }

    /**
     * クラスＢコードを設定する。
     * @param clsBCd クラスＢコード
     */
    public void setClsBCd(String clsBCd) {
        this.clsBCd = clsBCd;
    }

    /**
     * クラスＢ名称を取得する。
     * @return クラスＢ名称
     */
    public String getClsBNm() {
        return clsBNm;
    }

    /**
     * クラスＢ名称を設定する。
     * @param clsBNm クラスＢ名称
     */
    public void setClsBNm(String clsBNm) {
        this.clsBNm = clsBNm;
    }

    /**
     * クラスＣコードを取得する。
     * @return クラスＣコード
     */
    public String getClsCCd() {
        return clsCCd;
    }

    /**
     * クラスＣコードを設定する。
     * @param clsCCd クラスＣコード
     */
    public void setClsCCd(String clsCCd) {
        this.clsCCd = clsCCd;
    }

    /**
     * クラスＣ名称を取得する。
     * @return クラスＣ名称
     */
    public String getClsCNm() {
        return clsCNm;
    }

    /**
     * クラスＣ名称を設定する。
     * @param clsCNm クラスＣ名称
     */
    public void setClsCNm(String clsCNm) {
        this.clsCNm = clsCNm;
    }

    /**
     * クラスＤコードを取得する。
     * @return クラスＤコード
     */
    public String getClsDCd() {
        return clsDCd;
    }

    /**
     * クラスＤコードを設定する。
     * @param clsDCd クラスＤコード
     */
    public void setClsDCd(String clsDCd) {
        this.clsDCd = clsDCd;
    }

    /**
     * クラスＤ名称を取得する。
     * @return クラスＤ名称
     */
    public String getClsDNm() {
        return clsDNm;
    }

    /**
     * クラスＤ名称を設定する。
     * @param clsDNm クラスＤ名称
     */
    public void setClsDNm(String clsDNm) {
        this.clsDNm = clsDNm;
    }

    /**
     * クラスＥコードを取得する。
     * @return クラスＥコード
     */
    public String getClsECd() {
        return clsECd;
    }

    /**
     * クラスＥコードを設定する。
     * @param clsECd クラスＥコード
     */
    public void setClsECd(String clsECd) {
        this.clsECd = clsECd;
    }

    /**
     * クラスＥ名称を取得する。
     * @return クラスＥ名称
     */
    public String getClsENm() {
        return clsENm;
    }

    /**
     * クラスＥ名称を設定する。
     * @param clsENm クラスＥ名称
     */
    public void setClsENm(String clsENm) {
        this.clsENm = clsENm;
    }

    /**
     * クラスＦコードを取得する。
     * @return クラスＦコード
     */
    public String getClsFCd() {
        return clsFCd;
    }

    /**
     * クラスＦコードを設定する。
     * @param clsFCd クラスＦコード
     */
    public void setClsFCd(String clsFCd) {
        this.clsFCd = clsFCd;
    }

    /**
     * クラスＦ名称を取得する。
     * @return クラスＦ名称
     */
    public String getClsFNm() {
        return clsFNm;
    }

    /**
     * クラスＦ名称を設定する。
     * @param clsFNm クラスＦ名称
     */
    public void setClsFNm(String clsFNm) {
        this.clsFNm = clsFNm;
    }

    /**
     * クラスＧコードを取得する。
     * @return クラスＧコード
     */
    public String getClsGCd() {
        return clsGCd;
    }

    /**
     * クラスＧコードを設定する。
     * @param clsGCd クラスＧコード
     */
    public void setClsGCd(String clsGCd) {
        this.clsGCd = clsGCd;
    }

    /**
     * クラスＧ名称を取得する。
     * @return クラスＧ名称
     */
    public String getClsGNm() {
        return clsGNm;
    }

    /**
     * クラスＧ名称を設定する。
     * @param clsGNm クラスＧ名称
     */
    public void setClsGNm(String clsGNm) {
        this.clsGNm = clsGNm;
    }

    /**
     * クラスＨコードを取得する。
     * @return クラスＨコード
     */
    public String getClsHCd() {
        return clsHCd;
    }

    /**
     * クラスＨコードを設定する。
     * @param clsHCd クラスＨコード
     */
    public void setClsHCd(String clsHCd) {
        this.clsHCd = clsHCd;
    }

    /**
     * クラスＨ名称を取得する。
     * @return クラスＨ名称
     */
    public String getClsHNm() {
        return clsHNm;
    }

    /**
     * クラスＨ名称を設定する。
     * @param clsHNm クラスＨ名称
     */
    public void setClsHNm(String clsHNm) {
        this.clsHNm = clsHNm;
    }

    /**
     * クラスＩコードを取得する。
     * @return クラスＩコード
     */
    public String getClsICd() {
        return clsICd;
    }

    /**
     * クラスＩコードを設定する。
     * @param clsICd クラスＩコード
     */
    public void setClsICd(String clsICd) {
        this.clsICd = clsICd;
    }

    /**
     * クラスＩ名称を取得する。
     * @return クラスＩ名称
     */
    public String getClsINm() {
        return clsINm;
    }

    /**
     * クラスＩ名称を設定する。
     * @param clsINm クラスＩ名称
     */
    public void setClsINm(String clsINm) {
        this.clsINm = clsINm;
    }

    /**
     * クラスＪコードを取得する。
     * @return クラスＪコード
     */
    public String getClsJCd() {
        return clsJCd;
    }

    /**
     * クラスＪコードを設定する。
     * @param clsJCd クラスＪコード
     */
    public void setClsJCd(String clsJCd) {
        this.clsJCd = clsJCd;
    }

    /**
     * クラスＪ名称を取得する。
     * @return クラスＪ名称
     */
    public String getClsJNm() {
        return clsJNm;
    }

    /**
     * クラスＪ名称を設定する。
     * @param clsJNm クラスＪ名称
     */
    public void setClsJNm(String clsJNm) {
        this.clsJNm = clsJNm;
    }

}

