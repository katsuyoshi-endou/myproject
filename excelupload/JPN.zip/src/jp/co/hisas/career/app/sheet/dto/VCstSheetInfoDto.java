/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * V_CSTシート情報 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VCstSheetInfoDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * シートID
     */
    private String sheetId;
    /**
     * PARTY
     */
    private String party;
    /**
     * 運用コード
     */
    private String operationCd;
    /**
     * 運用名称
     */
    private String operationNm;
    /**
     * 運用タイプ
     */
    private String operationType;
    /**
     * 運用ソート
     */
    private String operationSort;
    /**
     * アクティブフラグ
     */
    private String activeFlg;
    /**
     * 書式グループコード
     */
    private String formGrpCd;
    /**
     * 書式グループ名称
     */
    private String formGrpNm;
    /**
     * 書式カテゴリコード
     */
    private String formCtgCd;
    /**
     * 書式コード
     */
    private String formCd;
    /**
     * 書式名称
     */
    private String formNm;
    /**
     * 所有者GUID
     */
    private String ownGuid;
    /**
     * レイアウトコード
     */
    private String layoutCd;
    /**
     * ラベルセットコード
     */
    private String labelSetCd;
    /**
     * パラメータセットコード
     */
    private String paramSetCd;
    /**
     * 回答セットコード
     */
    private String fillSetCd;
    /**
     * マスクコード
     */
    private String maskCd;
    /**
     * 複数シート作成許可
     */
    private String multiFormFlg;
    /**
     * フローコード
     */
    private String flowCd;
    /**
     * フローパターン
     */
    private String flowPtn;
    /**
     * シーケンスNo
     */
    private String seqNo;
    /**
     * ステータスコード
     */
    private String statusCd;
    /**
     * ステータス名称
     */
    private String statusNm;
    /**
     * メインアクターコード
     */
    private String mainActorCd;
    /**
     * シート所持GUID
     */
    private String holdGuid;

    /**
     * シートIDを取得する。
     * @return シートID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * シートIDを設定する。
     * @param sheetId シートID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * 運用コードを取得する。
     * @return 運用コード
     */
    public String getOperationCd() {
        return operationCd;
    }

    /**
     * 運用コードを設定する。
     * @param operationCd 運用コード
     */
    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    /**
     * 運用名称を取得する。
     * @return 運用名称
     */
    public String getOperationNm() {
        return operationNm;
    }

    /**
     * 運用名称を設定する。
     * @param operationNm 運用名称
     */
    public void setOperationNm(String operationNm) {
        this.operationNm = operationNm;
    }

    /**
     * 運用タイプを取得する。
     * @return 運用タイプ
     */
    public String getOperationType() {
        return operationType;
    }

    /**
     * 運用タイプを設定する。
     * @param operationType 運用タイプ
     */
    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    /**
     * 運用ソートを取得する。
     * @return 運用ソート
     */
    public String getOperationSort() {
        return operationSort;
    }

    /**
     * 運用ソートを設定する。
     * @param operationSort 運用ソート
     */
    public void setOperationSort(String operationSort) {
        this.operationSort = operationSort;
    }

    /**
     * アクティブフラグを取得する。
     * @return アクティブフラグ
     */
    public String getActiveFlg() {
        return activeFlg;
    }

    /**
     * アクティブフラグを設定する。
     * @param activeFlg アクティブフラグ
     */
    public void setActiveFlg(String activeFlg) {
        this.activeFlg = activeFlg;
    }

    /**
     * 書式グループコードを取得する。
     * @return 書式グループコード
     */
    public String getFormGrpCd() {
        return formGrpCd;
    }

    /**
     * 書式グループコードを設定する。
     * @param formGrpCd 書式グループコード
     */
    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    /**
     * 書式グループ名称を取得する。
     * @return 書式グループ名称
     */
    public String getFormGrpNm() {
        return formGrpNm;
    }

    /**
     * 書式グループ名称を設定する。
     * @param formGrpNm 書式グループ名称
     */
    public void setFormGrpNm(String formGrpNm) {
        this.formGrpNm = formGrpNm;
    }

    /**
     * 書式カテゴリコードを取得する。
     * @return 書式カテゴリコード
     */
    public String getFormCtgCd() {
        return formCtgCd;
    }

    /**
     * 書式カテゴリコードを設定する。
     * @param formCtgCd 書式カテゴリコード
     */
    public void setFormCtgCd(String formCtgCd) {
        this.formCtgCd = formCtgCd;
    }

    /**
     * 書式コードを取得する。
     * @return 書式コード
     */
    public String getFormCd() {
        return formCd;
    }

    /**
     * 書式コードを設定する。
     * @param formCd 書式コード
     */
    public void setFormCd(String formCd) {
        this.formCd = formCd;
    }

    /**
     * 書式名称を取得する。
     * @return 書式名称
     */
    public String getFormNm() {
        return formNm;
    }

    /**
     * 書式名称を設定する。
     * @param formNm 書式名称
     */
    public void setFormNm(String formNm) {
        this.formNm = formNm;
    }

    /**
     * 所有者GUIDを取得する。
     * @return 所有者GUID
     */
    public String getOwnGuid() {
        return ownGuid;
    }

    /**
     * 所有者GUIDを設定する。
     * @param ownGuid 所有者GUID
     */
    public void setOwnGuid(String ownGuid) {
        this.ownGuid = ownGuid;
    }

    /**
     * レイアウトコードを取得する。
     * @return レイアウトコード
     */
    public String getLayoutCd() {
        return layoutCd;
    }

    /**
     * レイアウトコードを設定する。
     * @param layoutCd レイアウトコード
     */
    public void setLayoutCd(String layoutCd) {
        this.layoutCd = layoutCd;
    }

    /**
     * ラベルセットコードを取得する。
     * @return ラベルセットコード
     */
    public String getLabelSetCd() {
        return labelSetCd;
    }

    /**
     * ラベルセットコードを設定する。
     * @param labelSetCd ラベルセットコード
     */
    public void setLabelSetCd(String labelSetCd) {
        this.labelSetCd = labelSetCd;
    }

    /**
     * パラメータセットコードを取得する。
     * @return パラメータセットコード
     */
    public String getParamSetCd() {
        return paramSetCd;
    }

    /**
     * パラメータセットコードを設定する。
     * @param paramSetCd パラメータセットコード
     */
    public void setParamSetCd(String paramSetCd) {
        this.paramSetCd = paramSetCd;
    }

    /**
     * 回答セットコードを取得する。
     * @return 回答セットコード
     */
    public String getFillSetCd() {
        return fillSetCd;
    }

    /**
     * 回答セットコードを設定する。
     * @param fillSetCd 回答セットコード
     */
    public void setFillSetCd(String fillSetCd) {
        this.fillSetCd = fillSetCd;
    }

    /**
     * マスクコードを取得する。
     * @return マスクコード
     */
    public String getMaskCd() {
        return maskCd;
    }

    /**
     * マスクコードを設定する。
     * @param maskCd マスクコード
     */
    public void setMaskCd(String maskCd) {
        this.maskCd = maskCd;
    }

    /**
     * 複数シート作成許可を取得する。
     * @return 複数シート作成許可
     */
    public String getMultiFormFlg() {
        return multiFormFlg;
    }

    /**
     * 複数シート作成許可を設定する。
     * @param multiFormFlg 複数シート作成許可
     */
    public void setMultiFormFlg(String multiFormFlg) {
        this.multiFormFlg = multiFormFlg;
    }

    /**
     * フローコードを取得する。
     * @return フローコード
     */
    public String getFlowCd() {
        return flowCd;
    }

    /**
     * フローコードを設定する。
     * @param flowCd フローコード
     */
    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    /**
     * フローパターンを取得する。
     * @return フローパターン
     */
    public String getFlowPtn() {
        return flowPtn;
    }

    /**
     * フローパターンを設定する。
     * @param flowPtn フローパターン
     */
    public void setFlowPtn(String flowPtn) {
        this.flowPtn = flowPtn;
    }

    /**
     * シーケンスNoを取得する。
     * @return シーケンスNo
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * シーケンスNoを設定する。
     * @param seqNo シーケンスNo
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * ステータスコードを取得する。
     * @return ステータスコード
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * ステータスコードを設定する。
     * @param statusCd ステータスコード
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * ステータス名称を取得する。
     * @return ステータス名称
     */
    public String getStatusNm() {
        return statusNm;
    }

    /**
     * ステータス名称を設定する。
     * @param statusNm ステータス名称
     */
    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    /**
     * メインアクターコードを取得する。
     * @return メインアクターコード
     */
    public String getMainActorCd() {
        return mainActorCd;
    }

    /**
     * メインアクターコードを設定する。
     * @param mainActorCd メインアクターコード
     */
    public void setMainActorCd(String mainActorCd) {
        this.mainActorCd = mainActorCd;
    }

    /**
     * シート所持GUIDを取得する。
     * @return シート所持GUID
     */
    public String getHoldGuid() {
        return holdGuid;
    }

    /**
     * シート所持GUIDを設定する。
     * @param holdGuid シート所持GUID
     */
    public void setHoldGuid(String holdGuid) {
        this.holdGuid = holdGuid;
    }

}

