package jp.co.hisas.career.app.sheet.event;

import java.util.Map;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

@SuppressWarnings("serial")
public class MultiEditJinikEvArg extends AbstractEventArg {
	
	public String sharp = null;
	public String loginGuid;
	public String actorCd;
	public String operatorGuid;
	public String statusCd;
	public String holdFilter;
	public String operationCd;
	public String party;
	public String retireFlg;
	public String personId;
	public String personNm;
	public String deptNm;
	public String clsCCd;
	public Map<String, String> jotaiMap;
	
	public MultiEditJinikEvArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: loginNo is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		if (SU.isBlank( sharp )) {
			throw new CareerException( "Invalid MultiEditJinikEvArg: sharp is null." );
		}
		if (SU.equals("SHOW", sharp) && SU.isBlank( operationCd )) {
			throw new CareerException( "Invalid MultiEditJinikEvArg: operationCd is null." );
		}
	}
}
