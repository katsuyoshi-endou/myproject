package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dao.CsmSheetFormGrpDao;
import jp.co.hisas.career.app.sheet.dao.ZzJinikAllSrchRsltDao;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFormGrpDto;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.ValueTextSortDao;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;
import jp.co.hisas.career.util.log.Log;

public class MultiJinikPrepareEvHdlr extends AbstractEventHandler<MultiJinikPrepareEvArg, MultiJinikPrepareEvRslt> {
	
	private String daoLoginNo;
	private String operatorGuid;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static MultiJinikPrepareEvRslt exec(MultiJinikPrepareEvArg arg) throws CareerException {
		MultiJinikPrepareEvHdlr handler = new MultiJinikPrepareEvHdlr();
		return handler.call(arg);
	}
	
	public MultiJinikPrepareEvRslt call(MultiJinikPrepareEvArg arg) throws CareerException {
		MultiJinikPrepareEvRslt result = null;
		Log.method(arg.getLoginNo(), "IN", "");
		if (Log.isDebugMode()) {
			result = this.execute(arg);
		} else {
			result = this.callEjb(arg);
		}
		Log.method(arg.getLoginNo(), "OUT", "");
		return result;
	}
	
	/**
	 * 2018.01
	 * 人材育成計画カスタマイズにてMultiJinikPrepareEvHandlerを流用元とした（ダブルメンテ中）
	 */
	protected MultiJinikPrepareEvRslt execute(MultiJinikPrepareEvArg arg) throws CareerException {
		
		arg.validateArg();
		// Application Login User GUID (for dao logging)
		this.daoLoginNo = arg.getLoginNo();
		// [CAREER_GUID].[OPERATOR_FLG] (Proxied) GUID or equals login GUID
		this.operatorGuid = arg.operatorGuid;
		
		MultiJinikPrepareEvRslt result = new MultiJinikPrepareEvRslt();
		
		try {
			
			if (SU.equals("SEARCH", arg.sharp)) {
				
				// フローステータスリストの取得
				List<ValueTextSortDto> staList = new ArrayList<ValueTextSortDto>();
				if (!CsUtil.isBlank( arg.srchCondMap.get( "operationCd" ) )) {
					staList = getStatusList( arg );
				}
				result.staList = staList;
				
				// [検索] 取扱可能な範囲すべてをワークに登録
				loadAllSheetSrchRslt( arg );
				
				// [検索] ワークから検索条件に従ってデータを削る
				result.hitCnt = reduceSheetSrchRslt( arg );
				
				// [検索] ワークに残ったシートデータを取得
				/* この処理は CsMulti の処理を流用しない */
			}
			return result;
		} catch (Exception e) {
			throw new CareerException(e.getMessage());
		} finally {
			Log.method(arg.getLoginNo(), "OUT", "");
		}
	}

	private void loadAllSheetSrchRslt( MultiJinikPrepareEvArg arg ) {
		//clear
		ZzJinikAllSrchRsltDao dao = new ZzJinikAllSrchRsltDao( daoLoginNo );
		dao.executeDynamic( "delete from ZZ_JINIK_ALL_SRCH_RSLT where LOGIN_PERSON_ID = '" + this.daoLoginNo + "'" );
		
		//insert
		/* Dynamic SQL */
		String targetTable = getTargetTable( arg );
		StringBuilder sql = new StringBuilder();
		sql.append( "insert into ZZ_JINIK_ALL_SRCH_RSLT " );
		sql.append( "select ?, s.SHEET_ID, s.OWN_GUID " );
		sql.append( "  from cst_sheet s " );
		/* STAMP or CASCADE */
		sql.append( " inner join ( select * " );
		sql.append( "                from CSM_SHEET_OPERATION " );
		sql.append( "               where OPEN_FLG = '1' ) ope " );
		sql.append( " on ope.OPERATION_CD = s.OPERATION_CD " );
		if ( SU.equals( arg.opeType, "STAMP" ) ) {
			sql.append( " and ope.OPERATION_TYPE = 'STAMP' " );
		}
		else if ( SU.equals( arg.opeType, "CASCADE" ) ) {
			sql.append( " and ope.OPERATION_TYPE = 'CASCADE' " );
		}
		if ( SU.isNotBlank( arg.operationCd ) ) {
			sql.append( " and ope.OPERATION_CD = ? " );
		}
		
		sql.append( " where s.PARTY = ? " );
		sql.append( "   and exists ( " );
		sql.append( "         select 'X' from " + targetTable + " a " );
		sql.append( "          where a.SHEET_ID = s.SHEET_ID and a.GUID = ? " );
		sql.append( "       ) " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.daoLoginNo );
		if ( SU.isNotBlank( arg.operationCd ) ) {
			paramList.add( arg.operationCd );
		}
		paramList.add( arg.party );
		paramList.add( this.operatorGuid );
		
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	private int reduceSheetSrchRslt( MultiJinikPrepareEvArg arg ) {
		
		// 特定のアクター（owner/follow）による絞込
		reduceBySpecialActorfilter( arg );
		
		// ホールドフィルタによる絞込
		reduceByActorAndHoldfilter( arg );
				
		// シートに埋め込まれた情報に対する絞込 (CST_SHEET, CST_SHEET_ATTR)
		reduceBySheetEmbeddedInfo( arg );
		
		// 絞込み後のシート件数を取得。表示時はROWNUM制限をかけているのでここでカウント。
		return countSheetsAfterReduce( arg );
	}
	
	private int countSheetsAfterReduce( MultiJinikPrepareEvArg arg ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "select count('X') from ZZ_JINIK_ALL_SRCH_RSLT wk " );
		sql.append( " where wk.LOGIN_PERSON_ID = ? " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.daoLoginNo );
		
		ZzJinikAllSrchRsltDao dao = new ZzJinikAllSrchRsltDao( daoLoginNo );
		return dao.selectCountDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	private void reduceBySpecialActorfilter( MultiJinikPrepareEvArg arg ) {
		
		String holdFilter = arg.srchCondMap.get( "holdFilter" );
		boolean isFollowMode = "FOLLOW".equals( holdFilter );
		String whereActor = (isFollowMode) ? " and a.ACTOR_CD = 'ref-follow' " : " and a.ACTOR_CD <> 'ref-follow' ";
		/* 組織シートは記入者がact-ownerで設定される  */
		if ( !( SU.equals( arg.opeType, "CASCADE" ) ) ) {
			whereActor = whereActor + " and a.ACTOR_CD <> 'act-owner' ";
		}
		/* Dynamic SQL */
		String targetTable = getTargetTable( arg );
		StringBuilder sql = new StringBuilder();
		sql.append( "delete from ZZ_JINIK_ALL_SRCH_RSLT wk " );
		sql.append( " where wk.LOGIN_PERSON_ID = ? " );
		sql.append( "   and not exists ( " );
		sql.append( "         select 'X' " );
		sql.append( "           from " + targetTable + " a " );
		sql.append( "          where a.SHEET_ID = wk.SHEET_ID " );
		sql.append( "            and a.GUID     = ? " );
		sql.append( whereActor );
		sql.append( "       ) " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( this.daoLoginNo );
		paramList.add( this.operatorGuid );
		
		ZzJinikAllSrchRsltDao dao = new ZzJinikAllSrchRsltDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	private void reduceByActorAndHoldfilter( MultiJinikPrepareEvArg arg ) {
		
		String holdFilter = arg.srchCondMap.get( "holdFilter" );
		boolean isHoldMode = "HOLD".equals( holdFilter );
		boolean isFollowMode = "FOLLOW".equals( holdFilter );
		boolean isRetire = (CsUtil.srchCondAvailable( arg.srchCondMap, "retireFlg" ) && "checked".equals( arg.srchCondMap.get( "retireFlg" ) ));
		boolean needsExec = isHoldMode || (isFollowMode && !isRetire);
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "delete from ZZ_JINIK_ALL_SRCH_RSLT wk " );
		sql.append( " where wk.LOGIN_PERSON_ID = ? " );
		if (isHoldMode) {
			sql.append( " and not exists ( " );
			sql.append( "     select 'X' from V_CST_SHEET_INFO vi " );
			sql.append( "      where vi.SHEET_ID  = wk.SHEET_ID " );
			sql.append( "        and vi.HOLD_GUID = ? " );
			sql.append( " ) " );
		}
		if (isFollowMode && !isRetire) {
			sql.append( " and not exists ( " );
			sql.append( "     select 'X' from CA_REGIST_MAIN cp " );
			sql.append( "      where cp.GUID = wk.OWN_GUID " );
			sql.append( "        and cp.FOLLOW_FLG = '1' " );
			sql.append( " ) " );
		}
		
		if (needsExec) {
			/* Parameter List */
			ArrayList<String> paramList = new ArrayList<String>();
			paramList.add( this.daoLoginNo );
			paramList.add( this.operatorGuid );
			
			ZzJinikAllSrchRsltDao dao = new ZzJinikAllSrchRsltDao( daoLoginNo );
			dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
		}
	}

	private void reduceBySheetEmbeddedInfo( MultiJinikPrepareEvArg arg ) {
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "delete from ZZ_JINIK_ALL_SRCH_RSLT wk " );
		sql.append( " where LOGIN_PERSON_ID = ? " );	paramList.add( this.daoLoginNo );
		sql.append( "   and not exists ( " );
		sql.append( "         select 'X' " );
		sql.append( "           from V_CS_INFO_ATTR vcia " );
		sql.append( "          where vcia.SHEET_ID = wk.SHEET_ID " );
		if (CsUtil.srchCondAvailable( arg.srchCondMap, "personId" )) {
			sql.append( "        and vcia.STF_NO like ? " );
			paramList.add( "%" + arg.srchCondMap.get( "personId" ) + "%" );
		}
		if (CsUtil.srchCondAvailable( arg.srchCondMap, "personNm" )) {
			sql.append( "        and vcia.OWN_PERSON_KANA like ? " );
			paramList.add( arg.srchCondMap.get( "personNm" ) + "%" );
		}
		if (CsUtil.srchCondAvailable( arg.srchCondMap, "deptNm" )) {
			sql.append( "        and vcia.FULL_DEPT_NM like ? " ); // 2017.03 Panasonic Customize
			paramList.add( "%" + arg.srchCondMap.get( "deptNm" ) + "%" );
		}
		if (CsUtil.srchCondAvailable( arg.srchCondMap, "clsCCd" )) {
			sql.append( "        and vcia.CLS_C_CD = ? " ); // 2017.03 Panasonic Customize
			paramList.add( arg.srchCondMap.get( "clsCCd" ) );
		}
		if (!CsUtil.isBlank( arg.operationCd )) {
			sql.append( "        and vcia.OPERATION_CD = ? " );
			paramList.add( arg.operationCd );
		}
		/**
		 *人材育成計画ではステータスコードで絞り込みをしない。
		 */
//		if (!CsUtil.isBlank( arg.statusCd )) {
//			sql.append( "        and vcia.STATUS_CD = ? " );
//			paramList.add( arg.statusCd );
//		}
		sql.append( "       ) " );
		
		ZzJinikAllSrchRsltDao dao = new ZzJinikAllSrchRsltDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	private String getTargetTable( MultiJinikPrepareEvArg arg ) {
		String holdFilter = arg.srchCondMap.get( "holdFilter" );
		String targetTable = "V_CST_SHEET_ACTOR_AND_REF";
		if (arg.srchCondMap != null) {
			if (CsUtil.srchCondAvailable( arg.srchCondMap, "holdFilter" )) {
				// ALL or ACTOR or HOLD
				if ("ALL".equals( holdFilter )) {
					targetTable = "V_CST_SHEET_ACTOR_AND_REF";
				} else if ("ACTOR".equals( holdFilter )) {
					targetTable = "CST_SHEET_ACTOR";
				} else if ("HOLD".equals( holdFilter )) {
					targetTable = "CST_SHEET_ACTOR";
				} else if ("FOLLOW".equals( holdFilter )) {
					targetTable = "CST_SHEET_ACTOR_REF";
				}
			}
		}
		return targetTable;
	}
	
	private List<ValueTextSortDto> getStatusList( MultiJinikPrepareEvArg arg ) {
		
		String opeCd = arg.srchCondMap.get( "operationCd" );
		if (opeCd == null) { return null; }
		
		/* Dynamic SQL */
		StringBuilder gsql = new StringBuilder();
		gsql.append( " select" + CsmSheetFormGrpDao.ALLCOLS );
		gsql.append( "   from CSM_SHEET_FORM_GRP " );
		gsql.append( "  where PARTY = ? " );
		gsql.append( "    and OPERATION_CD = ? " );
		gsql.append( "  order by FORM_GRP_CD " );
		
		/* Parameter List */
		ArrayList<String> gParamList = new ArrayList<String>();
		gParamList.add( arg.party );
		gParamList.add( opeCd );
		
		CsmSheetFormGrpDao gDao = new CsmSheetFormGrpDao( daoLoginNo );
		List<CsmSheetFormGrpDto> gDtoList = gDao.selectDynamic( DaoUtil.getPstmt( gsql, gParamList ) );
		CsmSheetFormGrpDto gDto = gDtoList.get( 0 );
		String formGrpCd = gDto.getFormGrpCd();
		if (formGrpCd == null) { return null; }
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select STATUS_CD as value, STATUS_NM as text, SEQ_NO as sort " );
		sql.append( "   from CSM_SHEET_FLOW " );
		sql.append( "  where FLOW_CD = ? " );
		sql.append( "  order by SEQ_NO " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		String flowCd = formGrpCd.replaceAll( "^grp-", "flw-" );
		paramList.add( flowCd );
		
		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}

}
