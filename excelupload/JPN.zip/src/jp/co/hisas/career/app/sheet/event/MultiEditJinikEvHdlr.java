package jp.co.hisas.career.app.sheet.event;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dto.ZzJinikSummaryListDto;
import jp.co.hisas.career.app.sheet.garage.JinikGarage;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dto.PulldownMasterDto;
import jp.co.hisas.career.util.log.Log;

public class MultiEditJinikEvHdlr extends AbstractEventHandler<MultiEditJinikEvArg, MultiEditJinikEvRslt> {
	
	private String daoLoginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static MultiEditJinikEvRslt exec(MultiEditJinikEvArg arg) throws CareerException {
		MultiEditJinikEvHdlr handler = new MultiEditJinikEvHdlr();
		return handler.call(arg);
	}
	
	public MultiEditJinikEvRslt call(MultiEditJinikEvArg arg) throws CareerException {
		MultiEditJinikEvRslt result = null;
		Log.method(arg.getLoginNo(), "IN", "");
		if (Log.isDebugMode()) {
			result = this.execute(arg);
		} else {
			result = this.callEjb(arg);
		}
		Log.method(arg.getLoginNo(), "OUT", "");
		return result;
	}
	
	protected MultiEditJinikEvRslt execute(MultiEditJinikEvArg arg) throws CareerException {
		
		arg.validateArg();
		daoLoginNo = arg.getLoginNo();
		
		MultiEditJinikEvRslt result = new MultiEditJinikEvRslt();
		
		try {
			if (SU.equals("INIT", arg.sharp)) {
				// 業務区分調査流用
				JinikGarage ggJi = new JinikGarage( daoLoginNo );
				result.actorList = ggJi.getActorList(arg);
			}
			else if (SU.equals("SHOW", arg.sharp)) {
				
				JinikGarage ggJi = new JinikGarage( daoLoginNo );
				
				// 画面に表示するシートをワークテーブルに格納
				execMakeWkTable(arg);
				
				// 業務区分調査流用
				List<ZzJinikSummaryListDto> rawSheetList = ggJi.getSheetInfo(arg);
				Map<String, Map<String, String>> maskSetMap = ggJi.getMaskSetMap( arg );
				result.summaryList = ggJi.makeSummaryList(rawSheetList, maskSetMap);
				result.actionList = ggJi.getActionList("flw-jinik", "flwptn-normal", arg.statusCd, arg.actorCd);
				
				// レイアウトプルダウンの取得
				String layoutCd = ggJi.getLayoutCd(arg.operationCd);
				Map<String, List<PulldownMasterDto>> layoutPdList = ggJi.getLayoutPD( layoutCd );
				result.layoutPdList = layoutPdList;
				
				result.rojCntMap = ggJi.getRojCntMap(arg);
			}
			return result;
		} catch (Exception e) {
			throw new CareerException(e.getMessage());
		} finally {
			Log.method(arg.getLoginNo(), "OUT", "");
		}
	}
	
	private void execMakeWkTable( MultiEditJinikEvArg arg ) throws SQLException {
		
		JinikGarage ggJi = new JinikGarage( daoLoginNo );
		
		// 人材WKをクリアして人材RSLTから全件コピー
		ggJi.loadJinikAllRslt( arg.loginGuid );
		
		ggJi.reduceByStatus( arg );
		
		ggJi.reduceByActor( arg );
		
		ggJi.reduceByFill( arg );
		
		// 決められたソート順でWK_IDXを更新
		ggJi.updateWkIdx( arg );
	}

}
