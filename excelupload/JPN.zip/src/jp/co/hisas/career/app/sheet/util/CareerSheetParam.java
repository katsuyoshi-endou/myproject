package jp.co.hisas.career.app.sheet.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dao.CsmSheetParamDao;
import jp.co.hisas.career.app.sheet.dto.CsmSheetParamDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;

public class CareerSheetParam {
	
	private static HashMap<String, HashMap<String, String>> csParamSetMap = new HashMap<String, HashMap<String, String>>();
	
	static {
		Connection conn = null;
		try {
			conn = PZZ040_SQLUtility.getConnection( "" );
			CareerSheetParam.find( conn );
		} catch (final Exception e) {
			Log.error( "", e );
		} finally {
			PZZ040_SQLUtility.close( conn );
		}
	}
	
	private CareerSheetParam() {
	}
	
	/**
	 * データベースからパラメータの値を取得しなおす。
	 */
	public static void find( Connection conn ) throws SQLException {
		
		CsmSheetParamDao dao = new CsmSheetParamDao( conn );
		List<CsmSheetParamDto> result = dao.selectAll();
		
		csParamSetMap = new HashMap<String, HashMap<String, String>>();
		for (CsmSheetParamDto dto : result) {
			String paramSetCd = dto.getParamSetCd();
			String paramId    = dto.getParamId();
			String paramText  = dto.getParamValue();
			HashMap<String, String> paramMap = null;
			if (csParamSetMap.containsKey( paramSetCd )) {
				paramMap = csParamSetMap.get( paramSetCd );
			} else {
				paramMap = new HashMap<String, String>();
			}
			paramMap.put( paramId, paramText );
			csParamSetMap.put( paramSetCd, paramMap );
		}
	}
	
	public static Map<String, String> getParamSet( String paramSetCd ) {
		return CareerSheetParam.csParamSetMap.get( paramSetCd );
	}
	
	public static String getParam( final String paramSetCd, final String paramId ) {
		final HashMap<String, String> paramMap = CareerSheetParam.csParamSetMap.get( paramSetCd );
		String result = "";
		if (paramMap == null || !paramMap.containsKey( paramId )) {
			result = null;
		} else {
			result = paramMap.get( paramId );
		}
		return result;
	}
	
	public static String getParam( final String paramSetCd, final String paramId, boolean isVisible ) {
		if (isVisible) {
			return getParam( paramSetCd, paramId );
		}
		return null;
	}
	
}