package jp.co.hisas.career.app.sheet.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.bean.CsFlowPtnBean;
import jp.co.hisas.career.app.sheet.dto.CsmSheetActionDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFillDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetLayoutJsDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetAttrDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.app.sheet.dto.CsxSheetStatusDto;
import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.app.sheet.dto.VCsmFlowStatusDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActionLogDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActorAndRefDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetInfoDto;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dto.PulldownMasterDto;

public class CsSingleSheet {
	
	public String loginNo;
	public int langNo;
	public String sheetId;
	public HashMap<String, String> fillMap;
	public HashMap<String, String> fillMaskMap;
	public HashMap<String, String> nestFillMap;
	public List<String> nestFillKeyList;
	public String labelSetCd;
	public String paramSetCd;
	public VCstSheetInfoDto sheetInfo;
	public CstSheetAttrDto sheetAttr;
	public VCsInfoAttrDto sheetInfoAttr;
	public List<CsmSheetFillDto> fillIdMasterList;
	public List<VCstSheetInfoDto> csNeighborList;
	public List<CsxSheetStatusDto> csFlowStatusList;
	public List<VCsmFlowStatusDto> flowInfo;
	public List<CsFlowPtnBean> flowPtnList;
	public List<CsmSheetActionDto> actionList;
	public List<CsmSheetLayoutJsDto> layoutJsList;
	public Map<String, List<PulldownMasterDto>> layoutPdList;
	public CstSheetExclusiveDto exclusiveKey;
	public List<VCstSheetActionLogDto> actionLogList;
	public String usingActorCd;
	
	public String getFillContent( String fillId, String escape ) {
		String fc = null;
		if ( isVisible(fillId) ) {
			if ("JS".equals( escape )) {
				fc = CsUtil.escapeForJS( fillMap.get( fillId ) );
			}
			else if ("HTML".equals( escape )) {
				fc = CsUtil.escapeForHTML( fillMap.get( fillId ) );
			}
			else {
				// RAW
				fc = fillMap.get( fillId );
			}
		}
		return (fc != null) ? fc : "" ;
	}
	
	public String getFillContent( String fillId ) {
		return getFillContent( fillId, "JS" );
	}
	
	public String getNestFillContent( String nestFillId ) {
		String fc = CsUtil.escapeForJS( nestFillMap.get( nestFillId ) );
		return (fc != null) ? fc : "" ;
	}
	
	public boolean isVisible( String fillId ) {
		// MODE is read or write -> true
		return fillMaskMap.containsKey( fillId );
	}
	
	public boolean isWritable( String fillId ) {
		// MODE is write -> true
		String rw = fillMaskMap.get( fillId );
		return ("write".equals( rw ));
	}
	
	public HashMap<String, String> getLabelSetMap() {
		return CareerSheetLabel.getLabelSetMap( this.labelSetCd, this.langNo );
	}
	
	public String getLabel( String labelId ) {
		// 取得先が [CSM_SHEET_LABEL] であることに注意
		String labelText = SU.nvl( CareerSheetLabel.getLabel( this.labelSetCd, labelId, this.langNo ), "" );
		String helpText = CareerSheetLabel.getLabel( this.labelSetCd, labelId + "_HELP" );
		if (SU.isNotBlank( helpText )) {
			String tagLeft  = "<span style=\"font-weight:normal;\">[<span class=\"popSwitch\">？</span>]</span><div class=\"popInfoWrap\"><span class=\"popInfo\">";
			String tagRight = "</span></div>";
			return labelText + tagLeft + helpText + tagRight;
		} else {
			return labelText;
		}
	}
	
	public String getParam( String paramId ) {
		String paramValue = CareerSheetParam.getParam( this.paramSetCd, paramId );
		return (paramValue != null) ? paramValue : "";
	}
	
	public Map<String, String> getParamSetMap() {
		return CareerSheetParam.getParamSet( this.paramSetCd );
	}
	
	public String getActorInfo( String actorCd, String infoType ) {
		List<VCstSheetActorAndRefDto> dtoList = CsUtil.getActorInfo( this.loginNo, this.sheetId, actorCd );
		VCstSheetActorAndRefDto dto = (dtoList.size() != 0) ? dtoList.get( 0 ) : new VCstSheetActorAndRefDto();
		String result = "";
		if      (   "ActorNm".equals( infoType )) { result = dto.getActorNm();    }
		else if (  "PersonId".equals( infoType )) { result = dto.getGuid();       }
		else if ("PersonName".equals( infoType )) { result = dto.getPersonName(); }
		result = (result != null) ? result : "";
		return result;
	}
	
	public List<VCstSheetActorAndRefDto> getActorAndRefererAll() {
		return CsUtil.getActorAndRefererAll( this.loginNo, this.sheetId );
	}
	
	public Map<String, String> getTemplateDataFillMap() {
		Map<String, String> map = new HashMap<String, String>();
		for (CsmSheetFillDto fillIdDto : this.fillIdMasterList) {
			String fKey = fillIdDto.getFillId();
			String fVal = this.getFillContent( fillIdDto.getFillId(), "JS" );
			map.put( fKey, fVal );
		}
		return map;
	}
	
	/**
	 *  指定した文字列に一致するvalueを持つkeyを"Fill--"をつけて配列形式のシングルクォートカンマ区切りで連結して返す。
	 */
	public String getMapKeysForJSArray( HashMap<String, String> map, String valueMatchStr ) {
		String resultStr = "";
		int cnt = 0;
		for (Map.Entry<String, String> entry : map.entrySet()) {
			String key = entry.getKey();
			String val = entry.getValue(); // "read" or "write"
			String prefix = "";
			if (key.matches("^\\*--.*$")) {
				prefix = "NestFill--";
				String nfId = CsUtil.extractWithRegex( key, "^\\*--(.*)$" );
				for (String nfKey : nestFillKeyList) {
					if (valueMatchStr.equals(val)) {
						resultStr += (cnt==0) ? "" : ", " ;
						resultStr += "'" + prefix + nfKey + "--" + nfId + "'";
						cnt++;
					}
				}
			} else {
				prefix = "Fill--";
				if (valueMatchStr.equals(val)) {
					resultStr += (cnt==0) ? "" : ", " ;
					resultStr += "'" + prefix + key + "'";
					cnt++;
				}
			}
		}
		return resultStr;
	}
}
