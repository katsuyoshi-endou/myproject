/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jp.co.hisas.career.app.sheet.dto.CstSheetActionLogDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CSTシートアクションログ Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CstSheetActionLogDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " TIMESTAMP as timestamp,"
                     + " SHEET_ID as sheetId,"
                     + " STATUS_CD as statusCd,"
                     + " ACTOR_CD as actorCd,"
                     + " LOGIN_PERSON_ID as loginPersonId,"
                     + " ACTION_CD as actionCd,"
                     + " AFTER_STATUS_CD as afterStatusCd,"
                     + " DELIV_MSG as delivMsg"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CstSheetActionLogDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CstSheetActionLogDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * Insert文を実行する。
     * @param dto CST_SHEET_ACTION_LOGのデータ。
     */ 
    public void insert(CstSheetActionLogDto dto) {

        final String sql = "INSERT INTO CST_SHEET_ACTION_LOG ("
                         + "TIMESTAMP,"
                         + "SHEET_ID,"
                         + "STATUS_CD,"
                         + "ACTOR_CD,"
                         + "LOGIN_PERSON_ID,"
                         + "ACTION_CD,"
                         + "AFTER_STATUS_CD,"
                         + "DELIV_MSG"
                         + ")VALUES(?,?,?,?,?,?,?,? )"
                         ;
        Log.sql("【DaoMethod Call】 CstSheetActionLogDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getTimestamp());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getSheetId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getStatusCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getLoginPersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getActionCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getAfterStatusCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 8, dto.getDelivMsg());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

}

