package jp.co.hisas.career.app.sheet.event;

import java.util.HashMap;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;

public class MultiVshuncEventArg extends AbstractEventArg {

	public String sharp = null;
	public String operatorGuid = null;
	public HashMap<String, String> srchCondMap = null;
	public String operationCd = null;
	public String party = null;
	public String trans = null;
	public String opeType = null;

	public MultiVshuncEventArg(String loginNo, String operatorGuid) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		if (operatorGuid == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
		this.operatorGuid = operatorGuid;
	}

	public void setAll( String sharp, String operationCode ) {
		this.sharp = sharp;
		this.operationCd = operationCode;
	}

	public void validateArg() throws CareerException {
		if (this.sharp == null || "".equals( this.sharp.trim() )) {
			throw new CareerException( "Invalid Arg: state is null." );
		}
	}

}
