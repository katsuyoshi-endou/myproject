package jp.co.hisas.career.app.sheet.event;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dto.CsmSheetActionDto;
import jp.co.hisas.career.app.sheet.dto.ZzJinikSummaryListDto;
import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.PulldownMasterDto;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

@SuppressWarnings("serial")
public class MultiEditJinikEvRslt extends AbstractEventResult {

	public List<ValueTextSortDto> actorList;
	public List<ZzJinikSummaryListDto> summaryList;
	public List<CsmSheetActionDto> actionList;
	public Object statusList;
	public List<ValueTextSortDto> staList;
	public Map<String, Integer> rojCntMap;
	public Map<String, List<PulldownMasterDto>> layoutPdList;
	public Map<String, Map<String, String>> maskSetMap;
	
}