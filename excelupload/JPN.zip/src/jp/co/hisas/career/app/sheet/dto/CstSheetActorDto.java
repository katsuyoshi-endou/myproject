/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSTシートアクター Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CstSheetActorDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * シートID
     */
    private String sheetId;
    /**
     * アクターコード
     */
    private String actorCd;
    /**
     * GUID
     */
    private String guid;
    /**
     * 自動生成フラグ
     */
    private String autoFlg;

    /**
     * シートIDを取得する。
     * @return シートID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * シートIDを設定する。
     * @param sheetId シートID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * アクターコードを取得する。
     * @return アクターコード
     */
    public String getActorCd() {
        return actorCd;
    }

    /**
     * アクターコードを設定する。
     * @param actorCd アクターコード
     */
    public void setActorCd(String actorCd) {
        this.actorCd = actorCd;
    }

    /**
     * GUIDを取得する。
     * @return GUID
     */
    public String getGuid() {
        return guid;
    }

    /**
     * GUIDを設定する。
     * @param guid GUID
     */
    public void setGuid(String guid) {
        this.guid = guid;
    }

    /**
     * 自動生成フラグを取得する。
     * @return 自動生成フラグ
     */
    public String getAutoFlg() {
        return autoFlg;
    }

    /**
     * 自動生成フラグを設定する。
     * @param autoFlg 自動生成フラグ
     */
    public void setAutoFlg(String autoFlg) {
        this.autoFlg = autoFlg;
    }

}

