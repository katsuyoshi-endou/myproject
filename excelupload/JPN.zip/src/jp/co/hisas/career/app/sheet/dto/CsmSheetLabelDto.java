/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSMシートラベル Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetLabelDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ラベルセットコード
     */
    private String labelSetCd;
    /**
     * ラベルID
     */
    private String labelId;
    /**
     * ラベルテキスト言語１
     */
    private String labelText;
    /**
     * ラベルテキスト言語２
     */
    private String labelTextL2;
    /**
     * ラベルテキスト言語３
     */
    private String labelTextL3;

    /**
     * ラベルセットコードを取得する。
     * @return ラベルセットコード
     */
    public String getLabelSetCd() {
        return labelSetCd;
    }

    /**
     * ラベルセットコードを設定する。
     * @param labelSetCd ラベルセットコード
     */
    public void setLabelSetCd(String labelSetCd) {
        this.labelSetCd = labelSetCd;
    }

    /**
     * ラベルIDを取得する。
     * @return ラベルID
     */
    public String getLabelId() {
        return labelId;
    }

    /**
     * ラベルIDを設定する。
     * @param labelId ラベルID
     */
    public void setLabelId(String labelId) {
        this.labelId = labelId;
    }

    /**
     * ラベルテキスト言語１を取得する。
     * @return ラベルテキスト言語１
     */
    public String getLabelText() {
        return labelText;
    }

    /**
     * ラベルテキスト言語１を設定する。
     * @param labelText ラベルテキスト言語１
     */
    public void setLabelText(String labelText) {
        this.labelText = labelText;
    }

    /**
     * ラベルテキスト言語２を取得する。
     * @return ラベルテキスト言語２
     */
    public String getLabelTextL2() {
        return labelTextL2;
    }

    /**
     * ラベルテキスト言語２を設定する。
     * @param labelTextL2 ラベルテキスト言語２
     */
    public void setLabelTextL2(String labelTextL2) {
        this.labelTextL2 = labelTextL2;
    }

    /**
     * ラベルテキスト言語３を取得する。
     * @return ラベルテキスト言語３
     */
    public String getLabelTextL3() {
        return labelTextL3;
    }

    /**
     * ラベルテキスト言語３を設定する。
     * @param labelTextL3 ラベルテキスト言語３
     */
    public void setLabelTextL3(String labelTextL3) {
        this.labelTextL3 = labelTextL3;
    }

}

