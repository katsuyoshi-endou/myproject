package jp.co.hisas.career.app.sheet.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.CareerMenuBean;
import jp.co.hisas.career.app.sheet.event.CsListEventArg;
import jp.co.hisas.career.app.sheet.event.CsListEventHandler;
import jp.co.hisas.career.app.sheet.event.CsListEventResult;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.framework.trans.StateTransitionEvent;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class PHD023Command extends AbstractCommand {
	
	public static final String KINOU_ID = "VHD023";
	private HttpServletRequest request;
	private HttpSession session;
	private String state;
	
	public PHD023Command() {
		super( PHD023Command.class, KINOU_ID, null );
	}
	
	public void init( StateTransitionEvent e ) {
		try {
			request = e.getRequest();
			session = request.getSession( false );
			CSRFTokenUtil.setNewTokenNo( request, e.getResponse() );
			state = request.getParameter( "state" );
			main();
		} catch (CareerException ex) {
			throw new CareerRuntimeException( ex );
		}
	}
	
	private void main() throws CareerException {
		
		if ("INIT".equals( state ) || "RESTORE".equals( state )) {
			execEventInit();
		}
		
		/* 操作ログ */
		OutLogBean.outputLogSousa( request, KINOU_ID, null, state );
	}
	
	private void execEventInit() throws CareerException {
		
		CareerMenuBean oneMenu = AU.getSessionAttr( session, AppSessionKey.CAREER_ONE_MENU );
		
		/* Set Args */
		CsListEventArg arg = new CsListEventArg( super.getLoginNo() );
		arg.sharp = "MYLIST";
		arg.party = oneMenu.party;
		arg.personId = super.getLoginNo();
		arg.opeType  = "STAMP";
		
		/* Execute Event */
		CsListEventResult result = CsListEventHandler.exec( arg );
		
		/* Return to session */
		session.setAttribute( CsSessionKey.VCST_SHEET_SINGLE_DTO_LIST, result.getSingleDtoList() );
	}
	
}