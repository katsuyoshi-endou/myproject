/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * V_CST_SHEET_UNIFY_LIST Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VCstSheetUnifyListDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 会社コード
     */
    private String companyCd;
    /**
     * 運用コード
     */
    private String operationCd;
    /**
     * アクティブフラグ
     */
    private String activeFlg;
    /**
     * 人ID
     */
    private String personId;
    /**
     * 一覧列1
     */
    private String listCol1;
    /**
     * 一覧列2
     */
    private String listCol2;
    /**
     * 一覧列3
     */
    private String listCol3;
    /**
     * 一覧列4
     */
    private String listCol4;
    /**
     * 一覧列5
     */
    private String listCol5;
    /**
     * 一覧列6
     */
    private String listCol6;
    /**
     * 列AシートID
     */
    private String colaSheetId;
    /**
     * 列Aステータス名称
     */
    private String colaStatusNm;
    /**
     * 列Aステータス簡易名称
     */
    private String colaStatusSmlyNm;
    /**
     * 列Aシート所持人ID
     */
    private String colaHoldPersonId;
    /**
     * 列BシートID
     */
    private String colbSheetId;
    /**
     * 列Bステータス名称
     */
    private String colbStatusNm;
    /**
     * 列Bステータス簡易名称
     */
    private String colbStatusSmlyNm;
    /**
     * 列Bシート所持人ID
     */
    private String colbHoldPersonId;
    /**
     * 列CシートID
     */
    private String colcSheetId;
    /**
     * 列Cステータス名称
     */
    private String colcStatusNm;
    /**
     * 列Cステータス簡易名称
     */
    private String colcStatusSmlyNm;
    /**
     * 列Cシート所持人ID
     */
    private String colcHoldPersonId;

    /**
     * 会社コードを取得する。
     * @return 会社コード
     */
    public String getCompanyCd() {
        return companyCd;
    }

    /**
     * 会社コードを設定する。
     * @param companyCd 会社コード
     */
    public void setCompanyCd(String companyCd) {
        this.companyCd = companyCd;
    }

    /**
     * 運用コードを取得する。
     * @return 運用コード
     */
    public String getOperationCd() {
        return operationCd;
    }

    /**
     * 運用コードを設定する。
     * @param operationCd 運用コード
     */
    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    /**
     * アクティブフラグを取得する。
     * @return アクティブフラグ
     */
    public String getActiveFlg() {
        return activeFlg;
    }

    /**
     * アクティブフラグを設定する。
     * @param activeFlg アクティブフラグ
     */
    public void setActiveFlg(String activeFlg) {
        this.activeFlg = activeFlg;
    }

    /**
     * 人IDを取得する。
     * @return 人ID
     */
    public String getPersonId() {
        return personId;
    }

    /**
     * 人IDを設定する。
     * @param personId 人ID
     */
    public void setPersonId(String personId) {
        this.personId = personId;
    }

    /**
     * 一覧列1を取得する。
     * @return 一覧列1
     */
    public String getListCol1() {
        return listCol1;
    }

    /**
     * 一覧列1を設定する。
     * @param listCol1 一覧列1
     */
    public void setListCol1(String listCol1) {
        this.listCol1 = listCol1;
    }

    /**
     * 一覧列2を取得する。
     * @return 一覧列2
     */
    public String getListCol2() {
        return listCol2;
    }

    /**
     * 一覧列2を設定する。
     * @param listCol2 一覧列2
     */
    public void setListCol2(String listCol2) {
        this.listCol2 = listCol2;
    }

    /**
     * 一覧列3を取得する。
     * @return 一覧列3
     */
    public String getListCol3() {
        return listCol3;
    }

    /**
     * 一覧列3を設定する。
     * @param listCol3 一覧列3
     */
    public void setListCol3(String listCol3) {
        this.listCol3 = listCol3;
    }

    /**
     * 一覧列4を取得する。
     * @return 一覧列4
     */
    public String getListCol4() {
        return listCol4;
    }

    /**
     * 一覧列4を設定する。
     * @param listCol4 一覧列4
     */
    public void setListCol4(String listCol4) {
        this.listCol4 = listCol4;
    }

    /**
     * 一覧列5を取得する。
     * @return 一覧列5
     */
    public String getListCol5() {
        return listCol5;
    }

    /**
     * 一覧列5を設定する。
     * @param listCol5 一覧列5
     */
    public void setListCol5(String listCol5) {
        this.listCol5 = listCol5;
    }

    /**
     * 一覧列6を取得する。
     * @return 一覧列6
     */
    public String getListCol6() {
        return listCol6;
    }

    /**
     * 一覧列6を設定する。
     * @param listCol6 一覧列6
     */
    public void setListCol6(String listCol6) {
        this.listCol6 = listCol6;
    }

    /**
     * 列AシートIDを取得する。
     * @return 列AシートID
     */
    public String getColaSheetId() {
        return colaSheetId;
    }

    /**
     * 列AシートIDを設定する。
     * @param colaSheetId 列AシートID
     */
    public void setColaSheetId(String colaSheetId) {
        this.colaSheetId = colaSheetId;
    }

    /**
     * 列Aステータス名称を取得する。
     * @return 列Aステータス名称
     */
    public String getColaStatusNm() {
        return colaStatusNm;
    }

    /**
     * 列Aステータス名称を設定する。
     * @param colaStatusNm 列Aステータス名称
     */
    public void setColaStatusNm(String colaStatusNm) {
        this.colaStatusNm = colaStatusNm;
    }

    /**
     * 列Aステータス簡易名称を取得する。
     * @return 列Aステータス簡易名称
     */
    public String getColaStatusSmlyNm() {
        return colaStatusSmlyNm;
    }

    /**
     * 列Aステータス簡易名称を設定する。
     * @param colaStatusSmlyNm 列Aステータス簡易名称
     */
    public void setColaStatusSmlyNm(String colaStatusSmlyNm) {
        this.colaStatusSmlyNm = colaStatusSmlyNm;
    }

    /**
     * 列Aシート所持人IDを取得する。
     * @return 列Aシート所持人ID
     */
    public String getColaHoldPersonId() {
        return colaHoldPersonId;
    }

    /**
     * 列Aシート所持人IDを設定する。
     * @param colaHoldPersonId 列Aシート所持人ID
     */
    public void setColaHoldPersonId(String colaHoldPersonId) {
        this.colaHoldPersonId = colaHoldPersonId;
    }

    /**
     * 列BシートIDを取得する。
     * @return 列BシートID
     */
    public String getColbSheetId() {
        return colbSheetId;
    }

    /**
     * 列BシートIDを設定する。
     * @param colbSheetId 列BシートID
     */
    public void setColbSheetId(String colbSheetId) {
        this.colbSheetId = colbSheetId;
    }

    /**
     * 列Bステータス名称を取得する。
     * @return 列Bステータス名称
     */
    public String getColbStatusNm() {
        return colbStatusNm;
    }

    /**
     * 列Bステータス名称を設定する。
     * @param colbStatusNm 列Bステータス名称
     */
    public void setColbStatusNm(String colbStatusNm) {
        this.colbStatusNm = colbStatusNm;
    }

    /**
     * 列Bステータス簡易名称を取得する。
     * @return 列Bステータス簡易名称
     */
    public String getColbStatusSmlyNm() {
        return colbStatusSmlyNm;
    }

    /**
     * 列Bステータス簡易名称を設定する。
     * @param colbStatusSmlyNm 列Bステータス簡易名称
     */
    public void setColbStatusSmlyNm(String colbStatusSmlyNm) {
        this.colbStatusSmlyNm = colbStatusSmlyNm;
    }

    /**
     * 列Bシート所持人IDを取得する。
     * @return 列Bシート所持人ID
     */
    public String getColbHoldPersonId() {
        return colbHoldPersonId;
    }

    /**
     * 列Bシート所持人IDを設定する。
     * @param colbHoldPersonId 列Bシート所持人ID
     */
    public void setColbHoldPersonId(String colbHoldPersonId) {
        this.colbHoldPersonId = colbHoldPersonId;
    }

    /**
     * 列CシートIDを取得する。
     * @return 列CシートID
     */
    public String getColcSheetId() {
        return colcSheetId;
    }

    /**
     * 列CシートIDを設定する。
     * @param colcSheetId 列CシートID
     */
    public void setColcSheetId(String colcSheetId) {
        this.colcSheetId = colcSheetId;
    }

    /**
     * 列Cステータス名称を取得する。
     * @return 列Cステータス名称
     */
    public String getColcStatusNm() {
        return colcStatusNm;
    }

    /**
     * 列Cステータス名称を設定する。
     * @param colcStatusNm 列Cステータス名称
     */
    public void setColcStatusNm(String colcStatusNm) {
        this.colcStatusNm = colcStatusNm;
    }

    /**
     * 列Cステータス簡易名称を取得する。
     * @return 列Cステータス簡易名称
     */
    public String getColcStatusSmlyNm() {
        return colcStatusSmlyNm;
    }

    /**
     * 列Cステータス簡易名称を設定する。
     * @param colcStatusSmlyNm 列Cステータス簡易名称
     */
    public void setColcStatusSmlyNm(String colcStatusSmlyNm) {
        this.colcStatusSmlyNm = colcStatusSmlyNm;
    }

    /**
     * 列Cシート所持人IDを取得する。
     * @return 列Cシート所持人ID
     */
    public String getColcHoldPersonId() {
        return colcHoldPersonId;
    }

    /**
     * 列Cシート所持人IDを設定する。
     * @param colcHoldPersonId 列Cシート所持人ID
     */
    public void setColcHoldPersonId(String colcHoldPersonId) {
        this.colcHoldPersonId = colcHoldPersonId;
    }

}

