/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSTシート Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CstSheetDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * SHEET_ID
     */
    private String sheetId;
    /**
     * PARTY
     */
    private String party;
    /**
     * OPERATION_CD
     */
    private String operationCd;
    /**
     * FORM_CD
     */
    private String formCd;
    /**
     * OWN_GUID
     */
    private String ownGuid;
    /**
     * STATUS_CD
     */
    private String statusCd;
    /**
     * FLOW_PTN
     */
    private String flowPtn;

    /**
     * SHEET_IDを取得する。
     * @return SHEET_ID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * SHEET_IDを設定する。
     * @param sheetId SHEET_ID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * OPERATION_CDを取得する。
     * @return OPERATION_CD
     */
    public String getOperationCd() {
        return operationCd;
    }

    /**
     * OPERATION_CDを設定する。
     * @param operationCd OPERATION_CD
     */
    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    /**
     * FORM_CDを取得する。
     * @return FORM_CD
     */
    public String getFormCd() {
        return formCd;
    }

    /**
     * FORM_CDを設定する。
     * @param formCd FORM_CD
     */
    public void setFormCd(String formCd) {
        this.formCd = formCd;
    }

    /**
     * OWN_GUIDを取得する。
     * @return OWN_GUID
     */
    public String getOwnGuid() {
        return ownGuid;
    }

    /**
     * OWN_GUIDを設定する。
     * @param ownGuid OWN_GUID
     */
    public void setOwnGuid(String ownGuid) {
        this.ownGuid = ownGuid;
    }

    /**
     * STATUS_CDを取得する。
     * @return STATUS_CD
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * STATUS_CDを設定する。
     * @param statusCd STATUS_CD
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * FLOW_PTNを取得する。
     * @return FLOW_PTN
     */
    public String getFlowPtn() {
        return flowPtn;
    }

    /**
     * FLOW_PTNを設定する。
     * @param flowPtn FLOW_PTN
     */
    public void setFlowPtn(String flowPtn) {
        this.flowPtn = flowPtn;
    }

}

