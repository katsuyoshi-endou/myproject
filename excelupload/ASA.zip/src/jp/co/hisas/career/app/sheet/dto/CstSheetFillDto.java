/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSTシート回答 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CstSheetFillDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * シートID
     */
    private String sheetId;
    /**
     * 回答ID
     */
    private String fillId;
    /**
     * 回答内容
     */
    private String fillContent;

    /**
     * シートIDを取得する。
     * @return シートID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * シートIDを設定する。
     * @param sheetId シートID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * 回答IDを取得する。
     * @return 回答ID
     */
    public String getFillId() {
        return fillId;
    }

    /**
     * 回答IDを設定する。
     * @param fillId 回答ID
     */
    public void setFillId(String fillId) {
        this.fillId = fillId;
    }

    /**
     * 回答内容を取得する。
     * @return 回答内容
     */
    public String getFillContent() {
        return fillContent;
    }

    /**
     * 回答内容を設定する。
     * @param fillContent 回答内容
     */
    public void setFillContent(String fillContent) {
        this.fillContent = fillContent;
    }

}

