package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.bean.CsFlowPtnBean;
import jp.co.hisas.career.app.sheet.dto.VCsmFlowStatusDto;
import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class CsFlowEvRslt extends AbstractEventResult {

	public List<VCsmFlowStatusDto> allStatuses;
	public List<CsFlowPtnBean> flowPtnList;

}
