package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.VPersonBelongUnionExDto;

@SuppressWarnings("serial")
public class PersonBelongEventResult extends AbstractEventResult {

	private List<VPersonBelongUnionExDto> belList = null;

	public List<VPersonBelongUnionExDto> getBelList() {
		return belList;
	}

	public void setBelList( List<VPersonBelongUnionExDto> belList ) {
		this.belList = belList;
	}

}