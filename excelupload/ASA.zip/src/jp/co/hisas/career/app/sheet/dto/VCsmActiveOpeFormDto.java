/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSTシート Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VCsmActiveOpeFormDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PARTY
     */
    private String party;
    /**
     * OPERATION_SORT
     */
    private String operationSort;
    /**
     * OPERATION_CD
     */
    private String operationCd;
    /**
     * OPERATION_NM
     */
    private String operationNm;
    /**
     * FORM_GRP_CD
     */
    private String formGrpCd;
    /**
     * FORM_GRP_NM
     */
    private String formGrpNm;
    /**
     * FORM_CD
     */
    private String formCd;
    /**
     * FORM_NM
     */
    private String formNm;
    /**
     * FORM_SORT
     */
    private String formSort;

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * OPERATION_SORTを取得する。
     * @return OPERATION_SORT
     */
    public String getOperationSort() {
        return operationSort;
    }

    /**
     * OPERATION_SORTを設定する。
     * @param operationSort OPERATION_SORT
     */
    public void setOperationSort(String operationSort) {
        this.operationSort = operationSort;
    }

    /**
     * OPERATION_CDを取得する。
     * @return OPERATION_CD
     */
    public String getOperationCd() {
        return operationCd;
    }

    /**
     * OPERATION_CDを設定する。
     * @param operationCd OPERATION_CD
     */
    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    /**
     * OPERATION_NMを取得する。
     * @return OPERATION_NM
     */
    public String getOperationNm() {
        return operationNm;
    }

    /**
     * OPERATION_NMを設定する。
     * @param operationNm OPERATION_NM
     */
    public void setOperationNm(String operationNm) {
        this.operationNm = operationNm;
    }

    /**
     * FORM_GRP_CDを取得する。
     * @return FORM_GRP_CD
     */
    public String getFormGrpCd() {
        return formGrpCd;
    }

    /**
     * FORM_GRP_CDを設定する。
     * @param formGrpCd FORM_GRP_CD
     */
    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    /**
     * FORM_GRP_NMを取得する。
     * @return FORM_GRP_NM
     */
    public String getFormGrpNm() {
        return formGrpNm;
    }

    /**
     * FORM_GRP_NMを設定する。
     * @param formGrpNm FORM_GRP_NM
     */
    public void setFormGrpNm(String formGrpNm) {
        this.formGrpNm = formGrpNm;
    }

    /**
     * FORM_CDを取得する。
     * @return FORM_CD
     */
    public String getFormCd() {
        return formCd;
    }

    /**
     * FORM_CDを設定する。
     * @param formCd FORM_CD
     */
    public void setFormCd(String formCd) {
        this.formCd = formCd;
    }

    /**
     * FORM_NMを取得する。
     * @return FORM_NM
     */
    public String getFormNm() {
        return formNm;
    }

    /**
     * FORM_NMを設定する。
     * @param formNm FORM_NM
     */
    public void setFormNm(String formNm) {
        this.formNm = formNm;
    }

    /**
     * FORM_SORTを取得する。
     * @return FORM_SORT
     */
    public String getFormSort() {
        return formSort;
    }

    /**
     * FORM_SORTを設定する。
     * @param formSort FORM_SORT
     */
    public void setFormSort(String formSort) {
        this.formSort = formSort;
    }

}

