package jp.co.hisas.career.app.sheet.util;

import java.util.HashMap;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.BulkOperSheetListDto;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

public class BulkOperSheet {
	public String daoLoginNo;
	public String operatorGuid;
	public List<BulkOperSheetListDto> bulkSheetList;
	public List<ValueTextSortDto> divList;
	public List<ValueTextSortDto> operationList;
	public List<ValueTextSortDto> statusList;
	public HashMap<String, String> gamenCondMap;
	public int hitCnt;

	public BulkOperSheet( String daoLoginNo, String operatorGuid ) {
		this.daoLoginNo = daoLoginNo;
		this.operatorGuid = operatorGuid;
	}
}
