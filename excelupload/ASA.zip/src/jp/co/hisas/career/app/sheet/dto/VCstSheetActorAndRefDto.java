/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * V_CSTシートアクター＆参照者 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VCstSheetActorAndRefDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ACT or REF
     */
    private String actOrRef;
    /**
     * シートID
     */
    private String sheetId;
    /**
     * アクターコード
     */
    private String actorCd;
    /**
     * アクター名称
     */
    private String actorNm;
    /**
     * アクターソート
     */
    private String actorSort;
    /**
     * GUID
     */
    private String guid;
    /**
     * 氏名
     */
    private String personName;
    /**
     * メインアクターコード
     */
    private String mainActorCd;
    /**
     * シート所持GUID
     */
    private String holdGuid;

    /**
     * ACT or REFを取得する。
     * @return ACT or REF
     */
    public String getActOrRef() {
        return actOrRef;
    }

    /**
     * ACT or REFを設定する。
     * @param actOrRef ACT or REF
     */
    public void setActOrRef(String actOrRef) {
        this.actOrRef = actOrRef;
    }

    /**
     * シートIDを取得する。
     * @return シートID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * シートIDを設定する。
     * @param sheetId シートID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * アクターコードを取得する。
     * @return アクターコード
     */
    public String getActorCd() {
        return actorCd;
    }

    /**
     * アクターコードを設定する。
     * @param actorCd アクターコード
     */
    public void setActorCd(String actorCd) {
        this.actorCd = actorCd;
    }

    /**
     * アクター名称を取得する。
     * @return アクター名称
     */
    public String getActorNm() {
        return actorNm;
    }

    /**
     * アクター名称を設定する。
     * @param actorNm アクター名称
     */
    public void setActorNm(String actorNm) {
        this.actorNm = actorNm;
    }

    /**
     * アクターソートを取得する。
     * @return アクターソート
     */
    public String getActorSort() {
        return actorSort;
    }

    /**
     * アクターソートを設定する。
     * @param actorSort アクターソート
     */
    public void setActorSort(String actorSort) {
        this.actorSort = actorSort;
    }

    /**
     * GUIDを取得する。
     * @return GUID
     */
    public String getGuid() {
        return guid;
    }

    /**
     * GUIDを設定する。
     * @param guid GUID
     */
    public void setGuid(String guid) {
        this.guid = guid;
    }

    /**
     * 氏名を取得する。
     * @return 氏名
     */
    public String getPersonName() {
        return personName;
    }

    /**
     * 氏名を設定する。
     * @param personName 氏名
     */
    public void setPersonName(String personName) {
        this.personName = personName;
    }

    /**
     * メインアクターコードを取得する。
     * @return メインアクターコード
     */
    public String getMainActorCd() {
        return mainActorCd;
    }

    /**
     * メインアクターコードを設定する。
     * @param mainActorCd メインアクターコード
     */
    public void setMainActorCd(String mainActorCd) {
        this.mainActorCd = mainActorCd;
    }

    /**
     * シート所持GUIDを取得する。
     * @return シート所持GUID
     */
    public String getHoldGuid() {
        return holdGuid;
    }

    /**
     * シート所持GUIDを設定する。
     * @param holdGuid シート所持GUID
     */
    public void setHoldGuid(String holdGuid) {
        this.holdGuid = holdGuid;
    }

}

