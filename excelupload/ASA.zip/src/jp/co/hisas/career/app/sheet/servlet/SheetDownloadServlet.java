package jp.co.hisas.career.app.sheet.servlet;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.app.sheet.bean.CsMultiSheetSearchBean;
import jp.co.hisas.career.app.sheet.bean.PZE010_ExcelHanyoDownloadBean;
import jp.co.hisas.career.app.sheet.bean.PersonalExcelDownloadBean;
import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.app.sheet.event.CsSheetEventArg;
import jp.co.hisas.career.app.sheet.event.CsSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.CsSheetEventResult;
import jp.co.hisas.career.app.sheet.util.CsMultiSheet;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.trans.ResponsedServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.CommonParameter;

public class SheetDownloadServlet extends ResponsedServlet {
	
	public void serviceMain( Tray tray ) throws Exception {
		
		// if 業務アカウント → 統合アカウントに変換
		tray.operatorGuid = tray.userinfo.getOperatorGuid();
		
		// 出力対象様式
		String state = tray.request.getParameter( "state" );
		
		// パターン振り分け
		String xlsharp = tray.request.getParameter( "xlsharp" );
		
		// 機能ID（操作ログ用）
		String kinouId = tray.request.getParameter( "_FW_TRANSIT_KINOU_ID" );
		
		String sousaTgt = null;
		
		// テンプレートファイルパスの取得
		// "Template-" + state のルールで探す
		String templateFilePath = this.getFilePath( tray.menu.party, state );
		
		// 出力データの元ネタをセット
		PZE010_ExcelHanyoDownloadBean downloadBean = new PZE010_ExcelHanyoDownloadBean( tray.loginNo, tray.operatorGuid );
		if ("JV".equals( xlsharp )) {
//			downloadBean.pz = (PAA010_PersonalBean) session.getAttribute( "personBean" ); // 人材ビューア 縦持ち個人情報
		}
		else if ("CS_SINGLE".equals( xlsharp )) {
			// CareerSheet 回答データ
			String sheetId = CsUtil.setSheetIdOnSession( tray.request, tray.session );
			CsSheetEventArg arg = new CsSheetEventArg( tray.loginNo, tray.operatorGuid );
			arg.sharp = "EXCEL_DL";
			arg.sheetId = sheetId;
			CsSheetEventResult result = CsSheetEventHandler.exec( arg );
			HashMap<String, String> csAttrMap = makeCsAttrMap( result.getInfoAttrDto() );
			downloadBean.ownPersonId = csAttrMap.get( "Attr--getOwnGuid()" );
			downloadBean.csSheet = AU.getSessionAttr( tray.session, CsSessionKey.CS_SINGLE_SHEET );
			downloadBean.csSheet.fillMap.putAll( result.getNestFillMap() );
			downloadBean.csAttrMap = csAttrMap;
			
			sousaTgt = sheetId;
		}
		else if ("CS_MULTI".equals( xlsharp )) {
			// Excel Download 用に全件再検索
			CsMultiSheetSearchBean bean = new CsMultiSheetSearchBean( tray.loginNo, tray.operatorGuid );
			/* TODO Excel出力時のOPERTION_TYPEは暫定でSTAMP固定。CASCADEの出力ができないため、OPERATION_CDから判断するように修正する */
			bean.execMultiSheetSearch( "EXCEL_DL", tray.request, "STAMP" );
			CsMultiSheet csMultiSheet = AU.getSessionAttr( tray.session, CsSessionKey.CS_MULTI_SHEET_XL );
			downloadBean.multiCsDtoList = csMultiSheet.multiCsList;
			downloadBean.multiCsFillMap = csMultiSheet.multiCsFillMap;
			downloadBean.multiCsFillMaskMap = csMultiSheet.multiFillMaskMap;
		}
		
		// 出力対象社員
		String tgtPersonId = tray.request.getParameter( "personId" );
		tgtPersonId = (downloadBean.ownPersonId != null) ? downloadBean.ownPersonId : tgtPersonId;
		tgtPersonId = (tgtPersonId != null) ? tgtPersonId : "";
		
		// 設定情報マップの作成
		PersonalExcelDownloadBean logicBean = new PersonalExcelDownloadBean( tray.request );
		HashMap<String, String> settingInfoMap = logicBean.gettingInfoMap( tray.loginNo, tgtPersonId, tray.session );
		
		// 出力ファイル生成
		byte[] outputFile = downloadBean.executeDownload( templateFilePath, settingInfoMap );
		
		// 出力ファイル名
		String outputFileName = this.getOutputFileName( tgtPersonId, state );
		
		// ダウンロード
		this.fileOutput( tray.response, outputFileName, outputFile );
		
		// サーバ上にバックアップ
		this.fileOutputOnServer( outputFileName, outputFile );
		
		/* 操作ログ */
		OutLogBean.outputLogSousa( tray.request, kinouId, sousaTgt, state );
	}
	
	/**
	 * VCsInfoAttrDtoのgetメソッドをExcelダウンロードから呼び出すのに使うマップを作成する。<br>
	 * attrMap.get( "Attr--getOwnPersonId()" ); のように記述すると値が取得できる。
	 */
	private HashMap<String, String> makeCsAttrMap( VCsInfoAttrDto attr ) {
		
		HashMap<String, String> attrMap = new HashMap<String, String>();
		Method[] methods = attr.getClass().getDeclaredMethods();
		for (Method method : methods) {
			String methodName = method.getName();
			if (methodName.matches("^get[\\dA-Z]\\w*")) {
				try {
					String key = "Attr--" + methodName + "()";
					String value = "";
					if ("getHierarchy".equals( methodName )) {
						Integer val = (Integer)method.invoke( attr );
						value = val.toString();
					} else {
						value = (String)method.invoke( attr );
					}
					attrMap.put(key, value);
				} catch (ClassCastException e) {
					// String変換できなかったものは無視
				} catch (Exception e) {
				}
			}
		}
		return attrMap;
	}
	
	private String getFilePath( String party, String state ) throws Exception {
		
		String templateFileName = null;
		
		if (state != null && !"".equals( state.trim() )) {
			templateFileName = "Template-" + party + "-" + state.trim() + ".xlsx";
		}
		String templateDirectory = CommonParameter.getValue( CommonParameter.BUNRUI_BASE, "EXCEL_TEMPLATE_DIRECTORY" );
		if (templateDirectory == null) {
			templateDirectory = AppDef.APP_DIR + "\\exceltemplate";
		}
		String templateFilePath = new File( templateDirectory, templateFileName ).toString();
		return templateFilePath;
	}
	
	private String getOutputFileName( String personID, String state ) {
		
		String sub = SU.isNotBlank( personID ) ? "_" + personID : "";
		String timestamp = "_" + PZZ010_CharacterUtil.getDayTime();
		
		return state + sub + timestamp + ".xlsx";
	}
	
	private void fileOutput( final HttpServletResponse response, String outputFileName, byte[] outputFile ) throws IOException {
		
		// contentTypeを出力
		response.setContentType( "application/vnd.ms-excel" );
		// ファイル名の送信
		response.setHeader( "Content-Disposition", "attachment; filename=\"" + outputFileName + "\"" );
		
		final byte[] buffer = new byte[4096];
		final ServletOutputStream out = response.getOutputStream();
		final ByteArrayInputStream bais = new ByteArrayInputStream( outputFile );
		
		if (bais != null) {
			int size;
			while ((size = bais.read( buffer )) != -1) {
				out.write( buffer, 0, size );
			}
			bais.close();
		}
		out.close();
		
		// ファイルを出力
		response.flushBuffer();
		
		return;
	}
	
	private void fileOutputOnServer( String outputFileName, byte[] outputFile ) throws IOException {
		String backupDirectory = CommonParameter.getValue( CommonParameter.BUNRUI_PLAN, "PERSONAL_EXCEL_BACKUP_DIRECTORY" );
		if (backupDirectory == null || "".equals( backupDirectory.trim() )) {
			return;
		}
		final FileOutputStream bkOut = new FileOutputStream( backupDirectory + "\\" + outputFileName );
		bkOut.write( outputFile, 0, outputFile.length );
		bkOut.close();
		return;
	}
	
}
