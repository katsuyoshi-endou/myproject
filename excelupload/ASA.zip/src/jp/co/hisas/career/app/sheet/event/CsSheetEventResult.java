package jp.co.hisas.career.app.sheet.event;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dto.CsmSheetActionDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFillDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetLayoutDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetLayoutJsDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.app.sheet.dto.CsxSheetStatusDto;
import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActionLogDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetInfoDto;
import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.PulldownMasterDto;

@SuppressWarnings("serial")
public class CsSheetEventResult extends AbstractEventResult {

	private String resultMessage = null;
	private String resultErrorMessage = null;
	public CsmSheetLayoutDto layoutTemplateDto = null;
	private CstSheetExclusiveDto exclusiveKey = null;
	private VCstSheetInfoDto sheetInfoDto = null;
	private VCsInfoAttrDto infoAttrDto = null;
	private HashMap<String, String> fillMap = null;
	private List<String> nestFillKeyList = null;
	private HashMap<String, String> nestFillMap = null;
	private List<CsmSheetFillDto> fillIdList = null;
	private HashMap<String, String> fillMaskMap = null;
	private List<VCstSheetInfoDto> neighborList = null;
	private List<CsxSheetStatusDto> flowStatusList = null;
	private List<CsmSheetActionDto> actionList = null;
	private List<CsmSheetLayoutJsDto> layoutJsList = null;
	private Map<String, List<PulldownMasterDto>> layoutPdList = null;
	private List<VCstSheetActionLogDto> actionLogList = null;
	public String usingActorCd;
	public String maxMokNo;

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage( String resultMessage ) {
		this.resultMessage = resultMessage;
	}

	public String getResultErrorMessage() {
		return resultErrorMessage;
	}

	public void setResultErrorMessage( String resultErrorMessage ) {
		this.resultErrorMessage = resultErrorMessage;
	}


	public CstSheetExclusiveDto getExclusiveKey() {
		return exclusiveKey;
	}

	public void setExclusiveKey( CstSheetExclusiveDto exclusiveKey ) {
		this.exclusiveKey = exclusiveKey;
	}

	public VCstSheetInfoDto getSheetInfoDto() {
		return sheetInfoDto;
	}

	public void setSheetInfoDto( VCstSheetInfoDto sheetInfoDto ) {
		this.sheetInfoDto = sheetInfoDto;
	}

	public VCsInfoAttrDto getInfoAttrDto() {
		return infoAttrDto;
	}

	public void setInfoAttrDto( VCsInfoAttrDto infoAttrDto ) {
		this.infoAttrDto = infoAttrDto;
	}

	public HashMap<String, String> getFillMap() {
		return fillMap;
	}

	public void setFillMap( HashMap<String, String> fillMap ) {
		this.fillMap = fillMap;
	}

	public List<String> getNestFillKeyList() {
		return nestFillKeyList;
	}

	public void setNestFillKeyList( List<String> nestFillKeyList ) {
		this.nestFillKeyList = nestFillKeyList;
	}

	public HashMap<String, String> getNestFillMap() {
		return nestFillMap;
	}

	public void setNestFillMap( HashMap<String, String> nestFillMap ) {
		this.nestFillMap = nestFillMap;
	}

	public List<CsmSheetFillDto> getFillIdList() {
		return fillIdList;
	}

	public void setFillIdList( List<CsmSheetFillDto> fillIdList ) {
		this.fillIdList = fillIdList;
	}

	public HashMap<String, String> getFillMaskMap() {
		return fillMaskMap;
	}

	public void setFillMaskMap( HashMap<String, String> fillMaskMap ) {
		this.fillMaskMap = fillMaskMap;
	}

	public List<VCstSheetInfoDto> getNeighborList() {
		return neighborList;
	}

	public void setNeighborList( List<VCstSheetInfoDto> neighborList ) {
		this.neighborList = neighborList;
	}

	public List<CsxSheetStatusDto> getFlowStatusList() {
		return flowStatusList;
	}

	public void setFlowStatusList( List<CsxSheetStatusDto> flowStatusList ) {
		this.flowStatusList = flowStatusList;
	}

	public List<CsmSheetActionDto> getActionList() {
		return actionList;
	}

	public void setActionList( List<CsmSheetActionDto> actionList ) {
		this.actionList = actionList;
	}

	public List<CsmSheetLayoutJsDto> getLayoutJsList() {
		return layoutJsList;
	}

	public void setLayoutJsList(List<CsmSheetLayoutJsDto> layoutJsList) {
		this.layoutJsList = layoutJsList;
	}

	public Map<String, List<PulldownMasterDto>> getLayoutPdList() {
		return layoutPdList;
	}

	public void setLayoutPdList( Map<String, List<PulldownMasterDto>> layoutPdList ) {
		this.layoutPdList = layoutPdList;
	}

	public List<VCstSheetActionLogDto> getActionLogList() {
		return actionLogList;
	}

	public void setActionLogList( List<VCstSheetActionLogDto> actionLogList ) {
		this.actionLogList = actionLogList;
	}

}