package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.MktNotificationDto;
import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class MkN10nEvRslt extends AbstractEventResult {
	
	public List<MktNotificationDto> mkN10nList;
	
}
