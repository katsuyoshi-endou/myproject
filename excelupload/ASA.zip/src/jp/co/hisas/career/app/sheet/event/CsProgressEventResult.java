package jp.co.hisas.career.app.sheet.event;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dto.CsmSheetFormGrpDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetOperationDto;
import jp.co.hisas.career.app.sheet.dto.CsxSheetStatusProgressDto;
import jp.co.hisas.career.app.sheet.dto.VCsmOperationFlowDto;
import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class CsProgressEventResult extends AbstractEventResult {

	private String resultMessage = null;
	private List<CsmSheetOperationDto> opeList = null;
	private HashMap<String, List<CsmSheetFormGrpDto>> sectionMap = null;
	
	public Map<String, List<VCsmOperationFlowDto>> opeMap = null;
	public Map<String, List<VCsmOperationFlowDto>> opeFgMap = null;
	public Map<String, List<VCsmOperationFlowDto>> opeFgSgMap = null;
	public Map<String, List<String>> opSets;
	public Map<String, List<String>> fgSets;
	public Map<String, List<String>> sgSets;
	public Map<String, List<String>> stSets;
	public Map<String, CsxSheetStatusProgressDto> sheetCountMap;
	public Map<String, CsxSheetStatusProgressDto> sheetHoldMap;
	public Map <String, String> isFollowModeMap =  new HashMap <String, String>();
// ADD 2018/06/18 COMTURE VSHPRG_シート進捗 START
// MOD 2018/07/26 COMTURE VSHPRG_シート進捗 START
//	public int uncreatedDisplay = 0;
	public Map<String, Integer> uncreatedDisplay;
// MOD 2018/07/26 COMTURE VSHPRG_シート進捗 END
	public Map<String, Integer> uncreatedCount;
// ADD 2018/06/18 COMTURE VSHPRG_シート進捗 END

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage( String resultMessage ) {
		this.resultMessage = resultMessage;
	}

	public List<CsmSheetOperationDto> getOpeList() {
		return opeList;
	}

	public void setOpeList( List<CsmSheetOperationDto> opeList ) {
		this.opeList = opeList;
	}

	public HashMap<String, List<CsmSheetFormGrpDto>> getSectionMap() {
		return sectionMap;
	}

	public void setSectionMap( HashMap<String, List<CsmSheetFormGrpDto>> sectionMap ) {
		this.sectionMap = sectionMap;
	}

}