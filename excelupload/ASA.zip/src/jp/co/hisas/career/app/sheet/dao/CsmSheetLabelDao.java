/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CsmSheetLabelDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 

/**
 * CSMシートラベル Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetLabelDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " LABEL_SET_CD as labelSetCd,"
                     + " LABEL_ID as labelId,"
                     + " LABEL_TEXT as labelText,"
                     + " LABEL_TEXT_L2 as labelTextL2,"
                     + " LABEL_TEXT_L3 as labelTextL3"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CsmSheetLabelDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CsmSheetLabelDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<CsmSheetLabelDto> CSM_SHEET_LABELのレコード型データのリスト。
     */ 
    public List<CsmSheetLabelDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CsmSheetLabelDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CsmSheetLabelDto> lst = new ArrayList<CsmSheetLabelDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CsmSheetLabelDto> CSM_SHEET_LABELのレコード型データのリスト。
     */ 
    public List<CsmSheetLabelDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CsmSheetLabelDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CsmSheetLabelDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmSheetLabelDto dto = new CsmSheetLabelDto();
        dto.setLabelSetCd(DaoUtil.convertNullToString(rs.getString("labelSetCd")));
        dto.setLabelId(DaoUtil.convertNullToString(rs.getString("labelId")));
        dto.setLabelText(DaoUtil.convertNullToString(rs.getString("labelText")));
        dto.setLabelTextL2(DaoUtil.convertNullToString(rs.getString("labelTextL2")));
        dto.setLabelTextL3(DaoUtil.convertNullToString(rs.getString("labelTextL3")));
        return dto;
    }

    /**
     * 全てのラベルを取得する
     * @return List<CsmSheetLabelDto> CSM_SHEET_LABELのレコード型データのリスト。
     */
    public List<CsmSheetLabelDto> selectAll() {

        final String sql = "select " + ALLCOLS + " from CSM_SHEET_LABEL order by LABEL_SET_CD, LABEL_ID";
        Log.sql("【DaoMethod Call】 CsmSheetLabelDao.selectAll");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            List<CsmSheetLabelDto> lst = new ArrayList<CsmSheetLabelDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

