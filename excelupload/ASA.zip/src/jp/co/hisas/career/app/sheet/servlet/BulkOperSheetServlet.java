package jp.co.hisas.career.app.sheet.servlet;

import java.util.HashMap;
import java.util.Map;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.bean.BulkOperSheetActionBean;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.vm.VmVSHBLK;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.NewTokenServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class BulkOperSheetServlet extends NewTokenServlet {

	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "VSHBLK";
	private static final String FORWARD_PAGE = "/view/sheet/layout_multi/MultiBulkOperation.jsp";

	@Override
	public String serviceMain(Tray tray) throws Exception {

		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( tray.session, UserInfoBean.SESSION_KEY );
		tray.operatorGuid = userInfo.getOperatorGuid();

		VmVSHBLK vm = new VmVSHBLK( tray );
		Map<String, String> jotaiMap = new HashMap<String, String>();

		if ( SU.equals( tray.state, "INIT" )) {
			execBulkSheetAction( tray );

			jotaiMap.put( "knskOperationCd", AU.getSessionAttr( tray.session, CsSessionKey.BULK_OPER_SEARCH_OPER_CD ));
			tray.forwardUrl = "/view/sheet/layout_multi/MultiBulkOperation.jsp";
		} else if ( SU.equals( tray.state, "SEARCH" )) {
			putJotaiMapFromRequest( tray, jotaiMap );
			execBulkSheetAction( tray );
		} else if ( SU.equals( tray.state, "CHANGE_OPERATION" )) {
			putJotaiMapFromRequest( tray, jotaiMap );
			execBulkSheetAction( tray );
		} else if ( SU.equals( tray.state, "CHG_STATUS" )) {
			jotaiMap = AU.getSessionAttr( tray.session, CsSessionKey.VSHBLK_JOTAIMAP );
			execBulkSheetAction( tray );
		} else if ( SU.equals( tray.state, "ACTOR_DEL" )) {
			jotaiMap = AU.getSessionAttr( tray.session, CsSessionKey.VSHBLK_JOTAIMAP );
			execBulkSheetAction( tray );
		} else if ( SU.equals( tray.state, "EXCEL_DL" )) {
			execBulkSheetAction( tray );

			String xlTemplateType = AU.getRequestValue( tray.request, "xlTemplateType" );

//			Map<Integer, List<String>> rows = new LinkedHashMap<Integer, List<String>>();
//
//			tray.session.setAttribute( "EXCEL_DL_ROWS", rows );
			tray.forwardUrl = "/servlet/ExcelDownloadServlet?state=" + xlTemplateType;
		} else if ( SU.equals( tray.state, "CHG_ALL_ACT" )) {
			putJotaiMapFromRequest( tray, jotaiMap );
			execBulkSheetAction( tray );
		}

		vm.jotaiMap = jotaiMap;

		AU.setReqAttr( tray.request, VmVSHBLK.VMID, vm );

		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, tray.state );

		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}

	private void execBulkSheetAction( Tray tray ) throws CareerException {
		BulkOperSheetActionBean bean = new BulkOperSheetActionBean( tray.loginNo, tray.operatorGuid );
		bean.execBulkSheetAction( tray.state, tray.request, "STAMP" );
	}

	private void putJotaiMapFromRequest( Tray tray, Map<String, String> jotaiMap ) {
		jotaiMap.put( "knskPersonId", AU.getRequestValue( tray.request, "knskPersonId" ) );
		jotaiMap.put( "knskDeptNm", AU.getRequestValue( tray.request, "knskDeptNm" ) );
		jotaiMap.put( "knskOperationCd", AU.getRequestValue( tray.request, "knskOperationCd" ) );
		jotaiMap.put( "knskPersonNm", AU.getRequestValue( tray.request, "knskPersonNm" ) );
		jotaiMap.put( "knskCmpaCd", AU.getRequestValue( tray.request, "knskCmpaCd" ) );
		jotaiMap.put( "knskStatusCd", AU.getRequestValue( tray.request, "knskStatusCd" ) );
	}
}
