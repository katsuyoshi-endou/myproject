package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CsmExcelFillMapDto;
import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class CsExcelUploadEvRslt extends AbstractEventResult {

	public List<CsmExcelFillMapDto> excelFillMapList;
}