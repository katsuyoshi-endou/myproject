/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CST_RSV_FILL Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CstRsvFillDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * SHEET_ID
     */
    private String sheetId;
    /**
     * FILL_ID
     */
    private String fillId;
    /**
     * FILL_CONTENT
     */
    private String fillContent;

    /**
     * SHEET_IDを取得する。
     * @return SHEET_ID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * SHEET_IDを設定する。
     * @param sheetId SHEET_ID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * FILL_IDを取得する。
     * @return FILL_ID
     */
    public String getFillId() {
        return fillId;
    }

    /**
     * FILL_IDを設定する。
     * @param fillId FILL_ID
     */
    public void setFillId(String fillId) {
        this.fillId = fillId;
    }

    /**
     * FILL_CONTENTを取得する。
     * @return FILL_CONTENT
     */
    public String getFillContent() {
        return fillContent;
    }

    /**
     * FILL_CONTENTを設定する。
     * @param fillContent FILL_CONTENT
     */
    public void setFillContent(String fillContent) {
        this.fillContent = fillContent;
    }

}

