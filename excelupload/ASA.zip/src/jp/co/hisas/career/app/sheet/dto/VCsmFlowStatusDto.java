/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * V_CSM_FLOW_STATUS Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VCsmFlowStatusDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * FLOW_CD
     */
    private String flowCd;
    /**
     * SEQ_NO
     */
    private String seqNo;
    /**
     * STATUS_CD
     */
    private String statusCd;
    /**
     * STATUS_NM
     */
    private String statusNm;
    /**
     * STATUS_GRP_CD
     */
    private String statusGrpCd;
    /**
     * STATUS_GRP_NM
     */
    private String statusGrpNm;
    /**
     * MAIN_ACTOR_CD
     */
    private String mainActorCd;
    /**
     * MAIN_ACTOR_NM
     */
    private String mainActorNm;
    /**
     * RELATED
     */
    private String related;

    /**
     * FLOW_CDを取得する。
     * @return FLOW_CD
     */
    public String getFlowCd() {
        return flowCd;
    }

    /**
     * FLOW_CDを設定する。
     * @param flowCd FLOW_CD
     */
    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    /**
     * SEQ_NOを取得する。
     * @return SEQ_NO
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * SEQ_NOを設定する。
     * @param seqNo SEQ_NO
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * STATUS_CDを取得する。
     * @return STATUS_CD
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * STATUS_CDを設定する。
     * @param statusCd STATUS_CD
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * STATUS_NMを取得する。
     * @return STATUS_NM
     */
    public String getStatusNm() {
        return statusNm;
    }

    /**
     * STATUS_NMを設定する。
     * @param statusNm STATUS_NM
     */
    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    /**
     * STATUS_GRP_CDを取得する。
     * @return STATUS_GRP_CD
     */
    public String getStatusGrpCd() {
        return statusGrpCd;
    }

    /**
     * STATUS_GRP_CDを設定する。
     * @param statusGrpCd STATUS_GRP_CD
     */
    public void setStatusGrpCd(String statusGrpCd) {
        this.statusGrpCd = statusGrpCd;
    }

    /**
     * STATUS_GRP_NMを取得する。
     * @return STATUS_GRP_NM
     */
    public String getStatusGrpNm() {
        return statusGrpNm;
    }

    /**
     * STATUS_GRP_NMを設定する。
     * @param statusGrpNm STATUS_GRP_NM
     */
    public void setStatusGrpNm(String statusGrpNm) {
        this.statusGrpNm = statusGrpNm;
    }

    /**
     * MAIN_ACTOR_CDを取得する。
     * @return MAIN_ACTOR_CD
     */
    public String getMainActorCd() {
        return mainActorCd;
    }

    /**
     * MAIN_ACTOR_CDを設定する。
     * @param mainActorCd MAIN_ACTOR_CD
     */
    public void setMainActorCd(String mainActorCd) {
        this.mainActorCd = mainActorCd;
    }

    /**
     * MAIN_ACTOR_NMを取得する。
     * @return MAIN_ACTOR_NM
     */
    public String getMainActorNm() {
        return mainActorNm;
    }

    /**
     * MAIN_ACTOR_NMを設定する。
     * @param mainActorNm MAIN_ACTOR_NM
     */
    public void setMainActorNm(String mainActorNm) {
        this.mainActorNm = mainActorNm;
    }

    /**
     * RELATEDを取得する。
     * @return RELATED
     */
    public String getRelated() {
        return related;
    }

    /**
     * RELATEDを設定する。
     * @param related RELATED
     */
    public void setRelated(String related) {
        this.related = related;
    }

}

