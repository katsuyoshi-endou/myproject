package jp.co.hisas.career.app.sheet.event;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import jp.co.hisas.career.app.sheet.dao.CstSheetDao;
import jp.co.hisas.career.app.sheet.dao.VCsmActiveOpeFormDao;
import jp.co.hisas.career.app.sheet.dto.CstSheetDto;
import jp.co.hisas.career.app.sheet.dto.VCsmActiveOpeFormDto;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.ConnDef;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

public class CsNewSheetEventHandler extends AbstractEventHandler<CsNewSheetEventArg, CsNewSheetEventResult> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static CsNewSheetEventResult exec( CsNewSheetEventArg arg ) throws CareerException {
		CsNewSheetEventHandler handler = new CsNewSheetEventHandler();
		return handler.call( arg );
	}
	
	public CsNewSheetEventResult call( CsNewSheetEventArg arg ) throws CareerException {
		CsNewSheetEventResult result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CsNewSheetEventResult execute( CsNewSheetEventArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		CsNewSheetEventResult result = new CsNewSheetEventResult();
		
		try {
			
			if (SU.equals( arg.sharp, "FORM_LIST" )) {
				
				result.activeOpeFormList = selectFormList( arg.party );
			}
			else if (SU.equals( arg.sharp, "CREATE" )) {
				
				String newSheetId = getNewSheetId( arg );
				boolean alreadyExists = sheetExistCheck( newSheetId );
				if (alreadyExists) {
					result.exitCd = 1;
					result.resultMsg = "The target period sheet has already been created. Please check the sheet.";
				} else {
					result.exitCd = createNewSheet( arg );
					result.resultMsg = "The sheet has been created.";
				}
				result.newSheetId = newSheetId;
			}
			
		} catch (SQLException e) {
			throw new CareerSQLException( e );
		} catch (NamingException e) {
			throw new CareerRuntimeException( e );
		} catch (Exception e) {
			throw new CareerRuntimeException( e );
		}
		
		return result;
	}
	
	private List<VCsmActiveOpeFormDto> selectFormList( String companyCd ) {
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "select " + SU.addPrefixOnDaoAllCols( "v", VCsmActiveOpeFormDao.ALLCOLS ) );
		sql.append( "  from V_CSM_ACTIVE_OPE_FORM v " );
		sql.append( "       inner join ( select OPERATION_CD " );
		sql.append( "                      from CSM_SHEET_OPERATION " );
		sql.append( "                     where OPERATION_TYPE = 'STAMP') CSM " );
		sql.append( "               on CSM.OPERATION_CD = v.OPERATION_CD " );
		sql.append( " where v.PARTY = ? " );
		sql.append( " order by v.OPERATION_SORT desc, v.FORM_SORT " );
		
		paramList.add( companyCd );
		
		VCsmActiveOpeFormDao dao = new VCsmActiveOpeFormDao( this.loginNo );
		
		return dao.selectDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}

	private String getNewSheetId( CsNewSheetEventArg arg ) {
		return arg.ownGuid + "-" + arg.party + "-" + arg.operationCd;
	}
	
	private boolean sheetExistCheck( String newSheetId ) throws Exception  {
		CstSheetDao dao = new CstSheetDao( this.loginNo );
		CstSheetDto dto = dao.select( newSheetId );
		return (dto != null);
	}
	
	private int createNewSheet( CsNewSheetEventArg arg ) throws Exception {
		return execPlpkgVHD050( arg.party, arg.operationCd, arg.formCd );
	}
	
	/**
	 * PLPKG「VHD050」を呼び出す。
	 * VHD050引数は、実行者GUID、機能ID、断面基準日(システム日付をYYYY/MM/DDで)、PARTY、OPERATION_CD、FORM_CD、OWN_GUID。
	 */
	private int execPlpkgVHD050( String party, String operationCd, String formCd ) {
		int exitCd = 0;
		CallableStatement cstmt = null;
		Connection conn = null;
		try {
			InitialContext ctx = new InitialContext();
			DataSource ds = (DataSource)ctx.lookup( ConnDef.DATASOURCE_NAME );
			conn = ds.getConnection();
			String sql = "{?=call BATCH_WEB_NEW_SHEET.MAIN(?,?,?,?,?,?)}";
			cstmt = conn.prepareCall( sql );
			cstmt.registerOutParameter( 1, java.sql.Types.INTEGER );
			cstmt.setString( 2, this.loginNo ); // Not 統合GUID, ExcelツールによるRSV登録のGUIDと一致させる
			cstmt.setString( 3, "WEB_NEW_SHEET" );
			cstmt.setString( 4, party );
			cstmt.setString( 5, operationCd );
			cstmt.setString( 6, formCd );
			cstmt.setString( 7, this.loginNo );
			cstmt.execute();
			exitCd = cstmt.getInt( 1 );
			cstmt.close();
			conn.close();
		} catch (NamingException e) {
			throw new CareerSQLException( e );
		} catch (SQLException e) {
			throw new CareerSQLException( e );
		}
		return exitCd;
	}
	
}
