package jp.co.hisas.career.app.sheet.servlet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.common.event.CaRegistEvArg;
import jp.co.hisas.career.app.common.event.CaRegistEvHdlr;
import jp.co.hisas.career.app.common.event.CaRegistEvRslt;
import jp.co.hisas.career.app.sheet.dto.CstSheetActorDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActorAndRefDto;
import jp.co.hisas.career.app.sheet.event.CsActorEventArg;
import jp.co.hisas.career.app.sheet.event.CsActorEventHandler;
import jp.co.hisas.career.app.sheet.event.CsActorEventResult;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsSingleSheet;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.KeepTokenServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.CommonLabel;

public class CsActorServlet extends KeepTokenServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "VHD013";
	private static final String FORWARD_PAGE = "";
	
	public String serviceMain( Tray tray ) throws CareerException {
		
		CsSingleSheet sheet = AU.getSessionAttr( tray.session, CsSessionKey.CS_SINGLE_SHEET );
		String sheetId = AU.getSessionAttr( tray.session, CsSessionKey.CS_SHEET_ID );
		String personId = "", personIdArray = "", actorCd = "";
		
		if ("CHG_ACT".equals( tray.state )) {
			String cmpaCd = tray.request.getParameter( "cmpaCd" );
			String stfNo  = tray.request.getParameter( "stfNo" );
			personId = getGuidByCmpaStf( tray.loginNo, cmpaCd, stfNo );
			actorCd = tray.request.getParameter( "actorCd" );
			if (checkNewActorRule( tray, sheet, actorCd, personId )) {
				CsActorEventArg arg = new CsActorEventArg( tray.loginNo );
				arg.setAll( "CHG_ACT", sheetId, actorCd, personId );
				CsActorEventHandler.exec( arg );
				tray.forwardUrl = "/view/sheet/VHD014_CsActors.jsp";
			} else {
				String msg = CommonLabel.getLabel( tray.party, "LSHSAR_MSG_BLOCK_LOGIN_USER", tray.langNo );
				tray.session.setAttribute( AppSessionKey.RESULT_MSG_ERROR, msg );
				tray.forwardUrl = "/view/sheet/VHD012_CsPersonSelect.jsp";
			}
		}
		else if ("DEL_ACT".equals( tray.state )) {
			// Only from VHD014
			actorCd = tray.request.getParameter( "actorCd" );
			CsActorEventArg arg = new CsActorEventArg( tray.loginNo );
			arg.setAll( "DEL_ACT", sheetId, actorCd, null );
			CsActorEventHandler.exec( arg );
			tray.forwardUrl = "/view/sheet/VHD014_CsActors.jsp";
		}
		else if ("ADD_REF".equals( tray.state )) {
			String cmpaCd = tray.request.getParameter( "cmpaCd" );
			String stfNo  = tray.request.getParameter( "stfNo" );
			personId = getGuidByCmpaStf( tray.loginNo, cmpaCd, stfNo );
			actorCd = tray.request.getParameter( "actorCd" );
			if (checkNewActorRule( tray, sheet, actorCd, personId )) {
				CsActorEventArg arg = new CsActorEventArg( tray.loginNo );
				arg.setAll( "ADD_REF", sheetId, actorCd, personId );
				CsActorEventResult result = CsActorEventHandler.exec( arg );
				tray.forwardUrl = "/view/sheet/VHD013_CsReferers.jsp";
				if (!CsUtil.isBlank( result.resultMessageId )) {
					String msg = CommonLabel.getLabel( tray.party, result.resultMessageId, tray.langNo );
					tray.session.setAttribute( AppSessionKey.RESULT_MSG_WARN, msg );
				}
			} else {
				String msg = CommonLabel.getLabel( tray.party, "LSHSAR_MSG_BLOCK_LOGIN_USER", tray.langNo );
				tray.session.setAttribute( AppSessionKey.RESULT_MSG_ERROR, msg );
				tray.forwardUrl = "/view/sheet/VHD012_CsPersonSelect.jsp";
			}
		}
		else if ("DEL_REF".equals( tray.state )) {
			String checkedValueArray = tray.request.getParameter( "checkedValueArray" );
			ArrayList<String> checkedIdxList = CsUtil.toArrayList( checkedValueArray );
			CsActorEventArg arg = new CsActorEventArg( tray.loginNo );
			Map<Integer, VCstSheetActorAndRefDto> refererMap = AU.getSessionAttr( tray.session, CsSessionKey.CS_REFERER_LIST );
			for (String idx : checkedIdxList) {
				VCstSheetActorAndRefDto dto = refererMap.get( SU.toInt( idx, 0 ) );
				arg.setAll( "DEL_REF", sheetId, dto.getActorCd(), dto.getGuid() );
				CsActorEventHandler.exec( arg );
			}
			tray.forwardUrl = "/view/sheet/VHD013_CsReferers.jsp";
		}
		else if (SU.matches( tray.state, "CHG_FLOWPTN" )) {
			Map<String, String> map = AU.getRequestsWithRegex( tray.request, "actor-idx-[0-9]{1,}-actorcd" );
			
			List<CstSheetActorDto> actorList = new ArrayList<CstSheetActorDto>();
			boolean actorCheckOK = true;
			for (Map.Entry<String, String> entry : map.entrySet()) {
				String idx = SU.extract( entry.getKey(), "actor-idx-([0-9]{1,})-actorcd" );
				String aCd = AU.getRequestValue( tray.request, String.format("actor-idx-%s-actorcd", idx) );
				String aGu = AU.getRequestValue( tray.request, String.format("actor-idx-%s-guid", idx) );
				if (checkNewActorRule( tray, sheet, aCd, aGu )) {
					CstSheetActorDto dto = new CstSheetActorDto();
					dto.setSheetId( sheetId );
					dto.setActorCd( aCd );
					dto.setGuid( aGu );
					dto.setAutoFlg( "0" );
					actorList.add( dto );
				} else {
					String msg = CommonLabel.getLabel( tray.party, "LSHSAR_MSG_BLOCK_LOGIN_USER", tray.langNo );
					tray.session.setAttribute( AppSessionKey.RESULT_MSG_ERROR, msg );
					tray.forwardUrl = "/view/sheet/VHD010_ChgFlowPtn.jsp";
					actorCheckOK = false;
				}
			}
			
			if (actorCheckOK) {
				CsActorEventArg arg = new CsActorEventArg( tray.loginNo );
				arg.sharp = "UPD_ALL_ACT";
				arg.sheetId = sheetId;
				arg.actorList = actorList;
				arg.flowCd = sheet.sheetInfo.getFlowCd();
				arg.flowptn = AU.getRequestValue( tray.request, "after_flowptn" );
				CsActorEventResult result = CsActorEventHandler.exec( arg );
				
				String msg = CommonLabel.getLabel( tray.party, result.resultMessageId, tray.langNo );
				tray.session.setAttribute( AppSessionKey.RESULT_MSG_INFO, msg );
				tray.forwardUrl = "/servlet/CsSheetServlet";
			}
		} else if ( SU.matches( tray.state, "CHG_ALL_ACT" )) {
			HashMap<String, String> checkedMap = AU.getSessionAttr( tray.session,  CsSessionKey.BULK_OPER_SELECT_MAP );
			for (String val : checkedMap.values()) {
				String[] d = val.split( "#" );
				String tgtSheetId = d[0];

				CsActorEventArg arg = new CsActorEventArg( tray.loginNo );
				arg.sharp = "CHG_ALL_ACT";
				arg.actorCd = AU.getRequestValue( tray.request, "actorCd" );
				arg.personId = AU.getRequestValue( tray.request, "chgGuid" );
				arg.sheetId = tgtSheetId;

				CsActorEventHandler.exec( arg );
			}
			tray.forwardUrl = "/view/sheet/VHD012_CsActorSelect.jsp";
		} else if ( SU.matches( tray.state, "ADD_ALL_REF|DEL_ALL_REF" )) {
			HashMap<String, String> checkedMap = AU.getSessionAttr( tray.session,  CsSessionKey.BULK_OPER_SELECT_MAP );
			for (String val : checkedMap.values()) {
				String[] d = val.split( "#" );
				String targetId = d[0];

				CsActorEventArg arg = new CsActorEventArg( tray.loginNo );
				arg.sharp = tray.state;
				arg.personId = AU.getRequestValue( tray.request, "stfNo" );
				arg.sheetId = targetId;

				CsActorEventHandler.exec( arg );
			}
			tray.forwardUrl = "/view/sheet/VHD012_CsPersonSelect.jsp";
		}
		
		if (personIdArray.length() > 1000) {
			personIdArray = personIdArray.substring( 0, 997 ) + "...";
		}
		String target = "null".equals( personId + personIdArray ) ? "" : personId + personIdArray;
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, target, tray.state + "," + actorCd );
		
		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}
	
	private boolean checkNewActorRule( Tray tray, CsSingleSheet sheet, String newActorCd, String newActorGuid ) {
		if (SU.equals( sheet.sheetInfo.getOwnGuid(), tray.loginNo )) {
			if (SU.matches( newActorCd, "act-owner" )) {
				return true;
			}
			if (SU.equals( tray.loginNo, newActorGuid )) {
				return false;
			}
		}
		return true;
	}
	
	private String getGuidByCmpaStf( String daoLoginNo, String cmpaCd, String stfNo ) throws CareerException {
		CaRegistEvArg arg = new CaRegistEvArg( daoLoginNo );
		arg.sharp  = "GET_BY_CMPA_STF";
		arg.cmpaCd = cmpaCd;
		arg.stfNo  = stfNo;
		CaRegistEvRslt rslt = CaRegistEvHdlr.exec( arg );
		return rslt.caRegistDto.getGuid();
	}
	
}
