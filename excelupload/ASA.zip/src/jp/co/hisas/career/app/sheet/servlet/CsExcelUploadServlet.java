package jp.co.hisas.career.app.sheet.servlet;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.fileupload.FileItem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.dto.CsmExcelFillMapDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.app.sheet.event.CsExcelUploadEvArg;
import jp.co.hisas.career.app.sheet.event.CsExcelUploadEvHdlr;
import jp.co.hisas.career.app.sheet.event.CsExcelUploadEvRslt;
import jp.co.hisas.career.app.sheet.event.CsSheetEventArg;
import jp.co.hisas.career.app.sheet.event.CsSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.CsSheetEventResult;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsSingleSheet;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.FileUploadServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class CsExcelUploadServlet extends FileUploadServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "VHD010";
	private static final String FORWARD_PAGE = "/servlet/CsSheetServlet";
	
	public String serviceMain( Tray tray ) throws CareerException {
		
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( tray.session, UserInfoBean.SESSION_KEY );
		tray.operatorGuid = userInfo.getOperatorGuid();
		
		// set SheetID on Session.
		String sheetId = CsUtil.setSheetIdOnSession( tray.request, tray.session );
		
		try {
			// アップロードされたエクセルファイルから回答データを取得
			@SuppressWarnings("unchecked")
			Map<String, FileItem> paramMap = (Map<String, FileItem>)tray.request.getAttribute( "paramMap" );
			Map<String, String> fillMap = getFillMap( tray, sheetId, paramMap.get( "excelFile" ) );
			
			// 画面表示中のシート所有者とエクセルファイルの所有者が一致しているか確認
			CsSingleSheet sheet = AU.getSessionAttr( tray.session, CsSessionKey.CS_SINGLE_SHEET );
			String xlGuid = fillMap.get( "own_guid" );
			boolean matchOwner = SU.equals( sheet.sheetInfo.getOwnGuid(), xlGuid );
			if (matchOwner) {
				// 回答データをデータベースに反映（ハンドラ内にマスク処理あり）
				String excKey = paramMap.get( "exclusiveKey" ).getString();
				updateFills( tray, sheetId, fillMap, excKey );
			} else {
				// シートの所有者が一致しなかったため処理を中断しました。
				String msg = AU.getCommonLabel( tray, "LSHSHT_MSG_UPFILE_OWNER" );
				throw new CareerException( msg );
			}
		} catch (CareerException e) {
			tray.session.setAttribute( AppSessionKey.RESULT_MSG_ERROR, e.getMessage() );
		}
		
		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, sheetId, tray.state );
		
		tray.request.setAttribute( "state", "INIT" );
		
		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}
	
	private void updateFills( Tray tray, String sheetId, Map<String, String> fillMap, String excKey ) throws CareerException {
		CsSheetEventArg arg = new CsSheetEventArg( tray.loginNo, tray.operatorGuid );
		arg.sharp = "STAY";
		arg.sheetId = sheetId;
		arg.actorCd = AU.getSessionAttr( tray.session, CsSessionKey.CS_VIEW_SHEET_ACTOR_CD );
		arg.fillReqMap = (HashMap<String, String>)fillMap;
		CstSheetExclusiveDto excDto = new CstSheetExclusiveDto();
		excDto.setSheetId( sheetId );
		Integer iExcKey = Integer.parseInt( CsUtil.bvl( excKey, "0" ) );
		excDto.setExclusiveKey( iExcKey );
		arg.exclusiveKey = excDto;
		CsSheetEventResult result = CsSheetEventHandler.exec( arg );
		if (SU.isNotBlank( result.getResultErrorMessage() )) {
			tray.session.setAttribute( AppSessionKey.RESULT_MSG_ERROR, result.getResultErrorMessage() );
		} else {
			// アップロード内容を反映しました。
			String msg = AU.getCommonLabel( tray, "LSHSHT_MSG_UPFILE_DONE" );
			tray.session.setAttribute( AppSessionKey.RESULT_MSG_INFO, msg );
		}
	}
	
	private Map<String, String> getFillMap( Tray tray, String sheetId, FileItem fileItem ) throws CareerException {
		Map<String, String> fillMap = new HashMap<String, String>();
		try {
			String name = fileItem.getName();
			if (!SU.matches( name, "^.*\\.xlsx$" )) {
				// ファイル形式は xlsx のみ対応しています。
				String msg = AU.getCommonLabel( tray, "LSHSHT_MSG_UPFILE_EXTENSION" );
				throw new CareerException( msg );
			}
			InputStream fis = fileItem.getInputStream();
			Workbook workbook = WorkbookFactory.create( fis );
			
			CsExcelUploadEvArg arg = new CsExcelUploadEvArg( tray.loginNo );
			arg.sharp = "GET";
			arg.party = tray.menu.party;
			arg.sheetId = sheetId;
			CsExcelUploadEvRslt rslt = CsExcelUploadEvHdlr.exec( arg );
			
			fillMap.putAll( getFillMapFromExcel( workbook, rslt.excelFillMapList ) );
			
		} catch (CareerException e) {
			throw e;
		} catch (Exception e) {
			// アップロードファイルの読み取りに失敗しました。
			String msg = AU.getCommonLabel( tray, "LSHSHT_MSG_UPFILE_OTHER" );
			throw new CareerException( msg );
		}
		return fillMap;
	}
	
	private static Map<String, String> getFillMapFromExcel( Workbook workbook, List<CsmExcelFillMapDto> excelFillMapList ) throws CareerException {
		Map<String, String> map = new HashMap<String, String>();
		for (CsmExcelFillMapDto dto : excelFillMapList) {
			Sheet sheet = workbook.getSheet( dto.getSheet() );
			Cell cell = getCell( sheet, dto.getCell() );
			String val = SU.ntb ( getStringValue( cell, dto.getCell() ) );
			checkStringValue( val, dto.getCell() );
			map.put( dto.getFillId(), val );
		}
		return map;
	}
	
	private static Cell getCell( Sheet sheet, String position ) {
		CellReference reference = new CellReference( position );
		Row row = sheet.getRow( reference.getRow() );
		if (row != null) {
			return row.getCell( reference.getCol() );
		}
		return null;
	}
	
	private static String getStringValue( Cell cell, String tgtCellAddress ) throws CareerException {
		if (cell == null) {
			return null;
		}
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_NUMERIC:
			return Double.toString( cell.getNumericCellValue() );
		case Cell.CELL_TYPE_STRING:
			return cell.getStringCellValue();
		case Cell.CELL_TYPE_FORMULA:
			throw new CareerException( "Cell type does not correspond to format.[" + tgtCellAddress + "]" );
		case Cell.CELL_TYPE_BLANK:
			return null;
		case Cell.CELL_TYPE_BOOLEAN:
			return Boolean.toString( cell.getBooleanCellValue() );
		case Cell.CELL_TYPE_ERROR:
			throw new CareerException( "There is an error in the cell.[" + tgtCellAddress + "]" );
		default:
			return null;
		}
	}
	
	private static void checkStringValue( String val, String tgtCellAddress ) throws CareerException {
		int len = SU.length( val );
		if (len > 1000) {
			throw new CareerException( "Please enter 1000 characters or less." );
		}
	}
	
}
