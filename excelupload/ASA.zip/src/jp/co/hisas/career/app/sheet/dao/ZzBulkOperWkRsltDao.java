/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.ZzBulkOperWkRsltDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CST_SHEET_SRCH_RSLT Data Access Object。
 * @author CareerDaoTool.xla
*/
public class ZzBulkOperWkRsltDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo;

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " LOGIN_PERSON_ID as loginPersonId,"
                     + " SHEET_ID as sheetId,"
                     + " OWN_GUID as ownGuid,"
                     + " WK_IDX as wkIdx"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public ZzBulkOperWkRsltDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public ZzBulkOperWkRsltDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * Insert文を実行する。
     * @param dto ZZ_BULK_OPER_WK_RSLTのデータ。
     */
    public void insert(ZzBulkOperWkRsltDto dto) {

        final String sql = "INSERT INTO ZZ_BULK_OPER_WK_RSLT ("
                         + "LOGIN_PERSON_ID,"
                         + "SHEET_ID,"
                         + "OWN_GUID,"
                         + "WK_IDX"
                         + ")VALUES(?,?,?,? )"
                         ;
        Log.sql("【DaoMethod Call】 ZzBulkOperWkRsltDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getLoginPersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getSheetId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getOwnGuid());
            DaoUtil.setIntToPreparedStatement(pstmt, 4, dto.getWkIdx());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * 全列update文を実行する。
     * @param dto ZZ_BULK_OPER_WK_RSLTのレコード型データ。
     */
    public void update(ZzBulkOperWkRsltDto dto) {

        final String sql = "UPDATE ZZ_BULK_OPER_WK_RSLT SET "
                         + "OWN_GUID = ?,"
                         + "WK_IDX = ?"
                         + " WHERE LOGIN_PERSON_ID = ?"
                         + " AND SHEET_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 ZzBulkOperWkRsltDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getOwnGuid());
            DaoUtil.setIntToPreparedStatement(pstmt, 2, dto.getWkIdx());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getLoginPersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getSheetId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してdelete文を実行する。
     * @param loginPersonId LOGIN_PERSON_ID
     * @param sheetId SHEET_ID
     */
    public void delete(String loginPersonId, String sheetId) {

        final String sql = "DELETE FROM ZZ_BULK_OPER_WK_RSLT"
                         + " WHERE LOGIN_PERSON_ID = ?"
                         + " AND SHEET_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 ZzBulkOperWkRsltDao.delete");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, loginPersonId);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, sheetId);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param loginPersonId LOGIN_PERSON_ID
     * @param sheetId SHEET_ID
     * @return ZzBulkOperWkRsltDto ZZ_BULK_OPER_WK_RSLTのレコード型データ。
     */
    public ZzBulkOperWkRsltDto select(String loginPersonId, String sheetId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM ZZ_BULK_OPER_WK_RSLT"
                         + " WHERE LOGIN_PERSON_ID = ?"
                         + " AND SHEET_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 ZzBulkOperWkRsltDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, loginPersonId);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, sheetId);
            rs = pstmt.executeQuery();
            ZzBulkOperWkRsltDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /**
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<ZzBulkOperWkRsltDto> ZZ_BULK_OPER_WK_RSLTのレコード型データのリスト。
     */
    public List<ZzBulkOperWkRsltDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 ZzBulkOperWkRsltDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<ZzBulkOperWkRsltDto> lst = new ArrayList<ZzBulkOperWkRsltDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /**
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CstSheetSrchRsltDto> ZZ_BULK_OPER_WK_RSLTのレコード型データのリスト。
     */
    public List<ZzBulkOperWkRsltDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 ZzBulkOperWkRsltDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /**
     * 動的SELECT COUNT 文を実行する。
     * @param pstmt PreparedStatement
     * @return レコード件数。
     */
    public int selectCountDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 ZzBulkOperWkRsltDao.selectCountDynamic");
        ResultSet rs = null;
        int cnt = 0;
        try {
            rs = pstmt.executeQuery();
            if ( rs.next() ) {
                cnt = rs.getInt(1);
            }
            return cnt;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /**
     * 動的SELECT COUNT 文を実行する。
     * @param sql SQL文
     * @return レコード件数。
     */
    public int selectCountDynamic(String sql) {

        Log.sql("【DaoMethod Call】 ZzBulkOperWkRsltDao.selectCountDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectCountDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * 動的UPDATE DELETE文を実行する。
     * @param pstmt PreparedStatement
     */
    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("【DaoMethod Call】 ZzBulkOperWkRsltDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * 動的UPDATE DELETE文を実行する。
     * @param sql SQL文
     */
    public void executeDynamic(String sql) {

        Log.sql("【DaoMethod Call】 ZzBulkOperWkRsltDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private ZzBulkOperWkRsltDto transferRsToDto(ResultSet rs) throws SQLException {

    	ZzBulkOperWkRsltDto dto = new ZzBulkOperWkRsltDto();
        dto.setLoginPersonId(DaoUtil.convertNullToString(rs.getString("loginPersonId")));
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setOwnGuid(DaoUtil.convertNullToString(rs.getString("ownGuid")));
        dto.setWkIdx(rs.getInt("wkIdx"));
        return dto;
    }

    /**
     *
     * @param loginPersonId ログイン人ID
     * @return List<ZzBulkOperWkRsltDto> ZZ_BULK_OPER_WK_RSLTのレコード型データのリスト。
     */
    public List<ZzBulkOperWkRsltDto> selectSrchRslt(String loginPersonId) {

        final String sql = "select " + ALLCOLS + " from ZZ_BULK_OPER_WK_RSLT where LOGIN_PERSON_ID = ?";
        Log.sql("【DaoMethod Call】 ZzBulkOperWkRsltDao.selectSrchRslt");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, loginPersonId);
            rs = pstmt.executeQuery();
            List<ZzBulkOperWkRsltDto> lst = new ArrayList<ZzBulkOperWkRsltDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

