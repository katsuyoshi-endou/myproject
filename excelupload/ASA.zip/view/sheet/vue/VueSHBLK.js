function mountVueSHBLK(vm, loginUser) {
  ES6Promise.polyfill();

  var app = new Vue({
    el: '#VueSHBLK',
    data: {
      vm: vm,
      loginUser: loginUser,
      lbl: App.LabelMap,
      mdlLbl: vm._data.ccpLabelSHAWM,
      wkIdxMin: 0,
      wkIdxMax: 100,
      checkedSheets: [],
      isBulkChecked: false,
      isShowAwayModal: false,
      picked: null,
      reasonText: "",
      isActionNotAllowed: vm.jotaiMap.statusCd == ""
    },
    computed: {
      showingSheetList: function (){
        var self = this;
        return _.filter(this.vm._data.list, function(sheet) {
          return self.wkIdxMin < sheet.wkIdx && sheet.wkIdx <= self.wkIdxMax;
        });
      },
      sheetidExckeyList: function () {
        var map = {};
        _.each(this.vm._data.list, function(sheet){
          map[sheet.sheetId] = sheet.exclusiveKey;
        });
        return map;
      },
      awayModalRadioLabels: function () {
        var self = this;
        var labelIdList = _.filter(Object.keys(self.mdlLbl), function (labelId) {
          return labelId.match(/LSHAWM_CHG_STATUS_REASON_\d\d/);
        }).sort(function (a,b) {
          if (a < b) return -1;
          if (a > b) return 1;
          return 0;
        });
        var labels = _.map(labelIdList, function (labelId) {
          return { labelId: labelId, text: self.mdlLbl[labelId] };
        });
        return labels;
      },
      isPicked99: function () {
          return this.picked && this.picked.labelId === "LSHAWM_CHG_STATUS_REASON_99";
        },
        sendReasonText: function () {
          return this.isPicked99 ? this.reasonText : "";
      }
    },
    mounted: function () {
      this.initPosition();
    },
    updated: function () {
    },
    methods: {
      onScroll: function(e) {
        var deg = (e.target.scrollTop + e.target.offsetHeight) / e.target.scrollHeight;
        if (deg > 0.85) {
          this.wkIdxMax = this.wkIdxMax + 50;
        }
      },
      toggleBulk: function() {
        if(!this.isBulkChecked){
          this.checkedSheets = [];
        } else {
          this.checkedSheets = _.map(this.vm._data.list, function(sheet){ return sheet.sheetId; });
        }
      },
      doBtnAction: function( state, actType ) {
        // 一括操作未選択チェック
        if ( this.checkedSheets.length == 0 ){
          alert( this.vm.vlMap.LSHBLK_ALERT_02 );
          return false;
        }

        // 一括操作上限数チェック
        var limit = $( "input[name='MAX_BULK_OPERATION']" ).val();
        if ( this.checkedSheets.length >= limit ) {
          var msg = ( this.vm.vlMap.LSHBLK_ALERT_03 ).replace( "{0}", limit );
          alert( msg );
          return false;
        }

        if ( state === 'CHG_STATUS' && actType === 'AWAY' ) {
          // 「（ステータス変更）対象外へ」のときは、理由入力画面を表示
          if ( !this.isShowAwayModal ) {
            this.isShowAwayModal = true;
            return false;
          }
        } else if ( state === 'CHG_STATUS' && acttype === 'RESUME' ) {
          if ( !confirm( this.vm.vlMap.LSHBLK_CONFIRM_02 )) {
            return false;
          }

          if ( !this.isShowAwayModal ) {
            makeRequestParameter( "Fill--change_status_reason", "" );
            makeRequestParameter( "Fill--change_status_reason_text", "" );
          }
        } else if ( state === 'ACTOR_DEL' ) {
          // 評価者削除のときは、削除確認メッセージ
          if ( !confirm( this.vm.vlMap.LSHBLK_CONFIRM_01 )) {
            return false;
          }
        }

        var self = this;
        _.each(this.checkedSheets, function(sheetId, i){
          var sheetIdSharpExckey = sheetId + "#" + self.sheetidExckeyList[sheetId];
          makeRequestParameter('multi_' + i, sheetIdSharpExckey);
        });
        makeRequestParameter( 'bulk_operation_kind', actType );
        pageSubmit( '/servlet/BulkOperSheetServlet', state );
      },
      doChangeActor: function( actorCd ) {
        // 一括操作未選択チェック
        if ( this.checkedSheets.length == 0 ){
          alert( this.vm.vlMap.LSHBLK_ALERT_02 );
          return false;
        }

        // 一括操作上限数チェック
        var limit = $( "input[name='MAX_BULK_OPERATION']" ).val();
        if ( this.checkedSheets.length >= limit ) {
          var msg = ( this.vm.vlMap.LSHBLK_ALERT_03 ).replace( "{0}", limit );
          alert( msg );
          return false;
        }

        var self = this;
        _.each(this.checkedSheets, function(sheetId, i){
          var sheetIdSharpExckey = sheetId + "#" + self.sheetidExckeyList[sheetId];
          makeRequestParameter('multi_' + i, sheetIdSharpExckey);
        });

        makeRequestParameter( "actorCd", actorCd );
        makeRequestParameter( "bulkOperType", "CHG_ALL_ACT" );

        openSubWindow('/view/sheet/VHD012_CsActorSelect.jsp', 'INIT', 'change_actors', 1000, 800);
      },
      doChangeRefer: function( operType ) {
        // 一括操作未選択チェック
        if ( this.checkedSheets.length == 0 ){
          alert( this.vm.vlMap.LSHBLK_ALERT_02 );
          return false;
        }

        // 一括操作上限数チェック
        var limit = $( "input[name='MAX_BULK_OPERATION']" ).val();
        if ( this.checkedSheets.length >= limit ) {
          var msg = ( this.vm.vlMap.LSHBLK_ALERT_03 ).replace( "{0}", limit );
          alert( msg );
          return false;
        }

        var self = this;
        _.each(this.checkedSheets, function(sheetId, i){
          var sheetIdSharpExckey = sheetId + "#" + self.sheetidExckeyList[sheetId];
          makeRequestParameter('multi_' + i, sheetIdSharpExckey);
        });

        makeRequestParameter( "actorCd", "ref-other" );
        makeRequestParameter( "VHD012Mode", operType );

        openSubWindow('/view/sheet/VHD012_CsPersonSelect.jsp', 'INIT', 'change_refers', 1000, 800);
      },
      initPosition: function () {
        var leftPos = ($(document).width() / 2) - 265;
        var topPos  = 150;
        $('.vue-modal-window').css('left', leftPos+'px').css('top', topPos+'px');
      },
      toggleAwayModal: function () {
        this.isShowAwayModal = !this.isShowAwayModal;
      },
      handleAwayModalClickOK: function () {
        if (!this.validateAwayModal()) {
          return false;
        }
        var pickedText = this.picked.text.replace(/<br>/g, "\n");
        makeRequestParameter("Fill--change_status_reason", pickedText);
        this.doBtnAction( "CHG_STATUS", "RESUME" );
      },
      validateAwayModal: function () {
        if (this.isPicked99) {
          if (this.reasonText.length === 0) {
            alert(this.vm.vlMap.LSHAWM_MSG_REASON_NEEDED);
            this.$refs.reasonText.focus();
            return false;
          }
          if (this.reasonText.length > 1000) {
            alert(this.vm.vlMap.LSHAWM_MSG_REASON_OVERFLOW);
            this.$refs.reasonText.focus();
            return false;
          }
        }
        return true;
      }
    }
  });
}
