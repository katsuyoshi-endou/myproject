var gulp = require('gulp');
var del = require('del');

gulp.task('clean', function() {
  return del(['tmp', 'css']);
});

gulp.task('pcss2css', function() {
  var rename = require("gulp-rename");
  return gulp.src('pcss/**/*.pcss')
    .pipe(
      rename(function(path){
        path.extname = ".css"
      })
    )
    .pipe(gulp.dest("tmp"));
});

gulp.task('postcss', function() {
  var postcss = require('gulp-postcss');
  var browsers = ['ie >= 11', 'Chrome >= 53', 'iOS >= 8', 'Firefox >= 49', 'Edge >= 14'];
  return gulp.src('tmp/app.css')
    .pipe(
      postcss([
        require('precss'),
        require('autoprefixer')({ browsers: browsers }),
        require('postcss-strip-inline-comments')
      ], {syntax: require('postcss-scss')})
    )
    .pipe( gulp.dest('css') );
});

gulp.task('after', function() {
  return del(['tmp']);
});

gulp.task('watch', function() {
  gulp.watch('pcss/**/*.pcss', ['compile'] );
});

gulp.task('compile', function(cb) {
  var runSequence = require('run-sequence');
  return runSequence('clean', 'pcss2css', 'postcss', 'after');
});

gulp.task('default', ['compile']);
