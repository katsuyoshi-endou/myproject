Career Assets
=============

`assets`: 静的コンテンツを扱うためのフォルダ

### img

アプリ独自のCSSファイルが参照する画像を配置します。

### js

アプリ独自のJSファイルを配置します。

### pcss

アプリ独自のPostCSSファイル(.pcss)を配置します。
Gulpというタスクランナーが .pcss を .css に変換し、
PreCSSというライブラリで各CSSを解釈しベンダープレフィックスを
付加して `_dest` フォルダにCSSファイルを出力しています。
  
- PostCSS
  - https://github.com/postcss/postcss

- PreCSS
  - https://github.com/jonathantneal/precss

### gulpfile.js

Gulpというタスクランナーを使って、静的ファイルをコンパイルするためのタスクを記述しています。

### package.json

Node.js のパッケージ管理システム npm で扱うための情報です。  
これをもとに何をインストールするかが決定され、実行コマンドを提供します。  
インストールしたパッケージは `node_modules` フォルダに入ります。
