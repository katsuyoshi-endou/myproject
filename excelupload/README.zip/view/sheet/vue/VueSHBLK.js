function mountVueSHBLK(vm, loginUser) {
  ES6Promise.polyfill();

  var app = new Vue({
    el: '#VueSHBLK',
    data: {
      vm: vm,
      loginUser: loginUser,
      lbl: App.LabelMap,
      wkIdxMin: 0,
      wkIdxMax: 100,
      checkedSheets: [],
      isBulkChecked: false,
      isActionNotAllowed: vm.jotaiMap.statusCd == ""
    },
    computed: {
      showingSheetList: function (){
        var self = this;
        return _.filter(this.vm._data.list, function(sheet) {
          return self.wkIdxMin < sheet.wkIdx && sheet.wkIdx <= self.wkIdxMax;
        });
      },
      sheetidExckeyList: function () {
          var map = {};
          _.each(this.vm._data.list, function(sheet){
            map[sheet.sheetId] = sheet.exclusiveKey;
          });
          return map;
        }
    },
    mounted: function () {
    },
    updated: function () {
    },
    methods: {
      onScroll: function(e) {
        var deg = (e.target.scrollTop + e.target.offsetHeight) / e.target.scrollHeight;
        if (deg > 0.85) {
          this.wkIdxMax = this.wkIdxMax + 50;
        }
      },
      toggleBulk: function() {
        if(!this.isBulkChecked){
          this.checkedSheets = [];
        } else {
          this.checkedSheets = _.map(this.vm._data.list, function(sheet){ return sheet.sheetId; });
        }
      },
      doBtnAction: function( state, actType ) {
        // 選択されているかどうかは各ボタン共通
        if ( this.checkedSheets.length == 0 ){
          alert( this.vm.vlMap.LSHBLK_ALERT_02 );
          return false;
        }

        if ( state === 'CHG_STATUS' && actType === 'SKIP' ) {
        	// 「（ステータス変更）対象外へ」のときは、理由入力画面を表示
        	openStausChangeModal();
        } else if ( state === 'ACTOR_DEL' ) {
          // 評価者削除のときは、削除確認メッセージ
          if ( !confirm( this.vm.vlMap.LSHBLK_CONFIRM_01 )) {
            return false;
          }
        } else {

        }

        var self = this;
        _.each(this.checkedSheets, function(sheetId, i){
          var sheetIdSharpExckey = sheetId + "#" + self.sheetidExckeyList[sheetId];
          makeRequestParameter('multi_' + i, sheetIdSharpExckey);
        });
        makeRequestParameter( 'bulk_operation_kind', actType );
//        makeRequestParameter('status_cd_multi', this.vm.jotaiMap.statusCd );
        pageSubmit( '/servlet/BulkOperSheetServlet', state );
      },
      doChangeActor: function( actorCd ) {
        // 選択されているかどうかは
        if ( this.checkedSheets.length == 0 ){
          alert( this.vm.vlMap.LSHBLK_ALERT_02 );
          return false;
        }

        var self = this;
        _.each(this.checkedSheets, function(sheetId, i){
          var sheetIdSharpExckey = sheetId + "#" + self.sheetidExckeyList[sheetId];
          makeRequestParameter('multi_' + i, sheetIdSharpExckey);
        });

        makeRequestParameter( "actorCd", actorCd );
        makeRequestParameter( "bulkOperType", "CHG_ALL_ACT" );

        openSubWindow('/view/sheet/VHD012_CsActorSelect.jsp', 'INIT', 'change_actors', 1000, 800);
      },
      doChangeRefer: function( operType ) {
        // 選択されているかどうか
        if ( this.checkedSheets.length == 0 ){
          alert( this.vm.vlMap.LSHBLK_ALERT_02 );
          return false;
        }

        var self = this;
        _.each(this.checkedSheets, function(sheetId, i){
          var sheetIdSharpExckey = sheetId + "#" + self.sheetidExckeyList[sheetId];
          makeRequestParameter('multi_' + i, sheetIdSharpExckey);
        });

        makeRequestParameter( "actorCd", "ref-other" );
        makeRequestParameter( "VHD012Mode", operType );

        openSubWindow('/view/sheet/VHD012_CsPersonSelect.jsp', 'INIT', 'change_refers', 1000, 800);
      }
    }
  });

}
