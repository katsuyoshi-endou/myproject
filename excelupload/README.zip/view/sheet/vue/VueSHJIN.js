function mountVueSHJIN(vm, loginUser) {
  ES6Promise.polyfill();
  
  var app = new Vue({
    el: '#VueSHJIN',
    data: {
      vm: vm,
      loginUser: loginUser,
      lbl: App.LabelMap,
      wkIdxMin: 0,
      wkIdxMax: 100,
      checkedSheets: [],
      isBulkChecked: false,
      isActionNotAllowed: vm.jotaiMap.statusCd == ""
    },
    computed: {
      multiActionList: function () {
        var list = _.filter(vm._data.actionList, function(act){
          return act.actionCd !== 'STAY';
        });
        return list;
      },
      showingSheetList: function (){
        var self = this;
        return _.filter(this.vm._data.list, function(sheet) {
          return self.wkIdxMin < sheet.wkIdx && sheet.wkIdx <= self.wkIdxMax;
        });
      },
      sheetidExckeyList: function () {
        var map = {};
        _.each(this.vm._data.list, function(sheet){
          map[sheet.sheetId] = sheet.exclusiveKey;
        });
        return map;
      }
    },
    mounted: function () {
      $('[data-toggle="tooltip"]').tooltip();
    },
    updated: function () {
    },
    methods: {
      onScroll: function(e) {
        var deg = (e.target.scrollTop + e.target.offsetHeight) / e.target.scrollHeight;
        if (deg > 0.85) {
          this.wkIdxMax = this.wkIdxMax + 50;
        }
        $('.keikaNen').each(function(){
          var $self = $(this);
          if ($self.attr('doitsuKbn') == 1){
          $self.closest('td').css('background-color','#FF0000');
          $self.closest('td').css('color','#FFFFFF');
          }
        });        
      },
      // fetch: function() {
      //   this.wkIdxMax = this.wkIdxMax + 100;
      //   this.wkIdxMin = this.wkIdxMin + 100;
      // },
      toggleBulk: function() {
        if(!this.isBulkChecked){
          this.checkedSheets = [];
        } else {
          this.checkedSheets = _.map(this.vm._data.list, function(sheet){ return sheet.sheetId; });
        }
      },
      doMultiAction: function(act) {
        if ( this.checkedSheets.length == 0 ){
          alert( this.vm.vlMap.LSHJIN_ALERT_01 );
          return false;
        }
        var confMsg = act.confirmMsg;
        if (!confirm(confMsg)) {
          return false;
        }
        var self = this;
        _.each(this.checkedSheets, function(sheetId, i){
          var sheetIdSharpExckey = sheetId + "#" + self.sheetidExckeyList[sheetId];
          makeRequestParameter('multi_' + i, sheetIdSharpExckey);
        });
        makeRequestParameter('action_cd_multi', act.actionCd );
        makeRequestParameter('status_cd_multi', this.vm.jotaiMap.statusCd );
        pageSubmit('/servlet/MultiEditJinikServlet', 'MULTI');
      }
    }
  });
  
}
