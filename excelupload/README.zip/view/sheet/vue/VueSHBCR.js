function mountVueSHBCR(vm, loginUser) {
  ES6Promise.polyfill();

  var app = new Vue({
    el: '#VueSHBCR',
    data: {
      vm: vm,
      loginUser: loginUser,
      lbl: App.LabelMap,
      checkedSheets: [],
      isBulkChecked: false
    },
    computed: {
      showingSheetList: function () {
        return this.vm._data.list;
      },
      showingLangList: function() {
        return this.vm._data.lang
      },
    },
    mounted: function () {
    },
    updated: function () {
    },
    methods: {
      toggleBulk: function() {
        if(!this.isBulkChecked){
          this.checkedSheets = [];
        } else {
          this.checkedSheets = _.map(this.vm._data.list, function(sheet){ return sheet.ownGuid; });
        }
      },
      doBulkSheetCreate: function() {
    	// 作成対象未選択チェック
        if ( this.checkedSheets.length == 0 ){
          alert( this.vm.vlMap.LSHBCR_ALERT_01 );
          return false;
        }

        // 作成対象上限数チェック
        var limit = $( "input[name='MAX_CREATE_LIMIT']" ).val();
        if ( this.checkedSheets.length >= limit ) {
          var msg = ( this.vm.vlMap.LSHBCR_ALERT_02 ).replace( "{0}", limit );
          alert( msg );
          return false;
        }

        // 作成対象言語の選択チェック
        var formCd = $( "select[name='language']" ).val();
        if ( formCd == "" ) {
        	alert( this.vm.vlMap.LSHBCR_ALERT_03 );
        	return false;
        }

        var self = this;
        _.each( this.checkedSheets, function( guid, i ){
          makeRequestParameter( 'multi_' + i, guid );
        });

        pageSubmit( '/servlet/BulkCreateSheetServlet', 'BULK_CREATE' );
      }
    }
  });

}
