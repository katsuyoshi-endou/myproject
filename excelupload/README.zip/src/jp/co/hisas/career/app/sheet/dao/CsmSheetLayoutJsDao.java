/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CsmSheetLayoutJsDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CSM_SHEET_LAYOUT_JS Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetLayoutJsDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " LAYOUT_CD as layoutCd,"
                     + " LINE_NO as lineNo,"
                     + " SCRIPT as script"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CsmSheetLayoutJsDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CsmSheetLayoutJsDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param layoutCd レイアウトコード
     * @param lineNo 行番号
     * @return CsmSheetLayoutJsDto CSM_SHEET_LAYOUT_JSのレコード型データ。
     */ 
    public CsmSheetLayoutJsDto select(String layoutCd, String lineNo) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CSM_SHEET_LAYOUT_JS"
                         + " WHERE LAYOUT_CD = ?"
                         + " AND LINE_NO = ?"
                         ;
        Log.sql("【DaoMethod Call】 CsmSheetLayoutJsDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, layoutCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, lineNo);
            rs = pstmt.executeQuery();
            CsmSheetLayoutJsDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<CsmSheetLayoutJsDto> CSM_SHEET_LAYOUT_JSのレコード型データのリスト。
     */ 
    public List<CsmSheetLayoutJsDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CsmSheetLayoutJsDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CsmSheetLayoutJsDto> lst = new ArrayList<CsmSheetLayoutJsDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CsmSheetLayoutJsDto> CSM_SHEET_LAYOUT_JSのレコード型データのリスト。
     */ 
    public List<CsmSheetLayoutJsDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CsmSheetLayoutJsDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CsmSheetLayoutJsDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmSheetLayoutJsDto dto = new CsmSheetLayoutJsDto();
        dto.setLayoutCd(DaoUtil.convertNullToString(rs.getString("layoutCd")));
        dto.setLineNo(DaoUtil.convertNullToString(rs.getString("lineNo")));
        dto.setScript(DaoUtil.convertNullToString(rs.getString("script")));
        return dto;
    }

}

