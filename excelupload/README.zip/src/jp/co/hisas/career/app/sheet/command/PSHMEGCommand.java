package jp.co.hisas.career.app.sheet.command;

import java.util.List;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.dto.CsmSheetActionDto;
import jp.co.hisas.career.app.sheet.event.MultiEditGymknEvArg;
import jp.co.hisas.career.app.sheet.event.MultiEditGymknEvHdlr;
import jp.co.hisas.career.app.sheet.event.MultiEditGymknEvRslt;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.framework.trans.StateTransitionEvent;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class PSHMEGCommand extends AbstractCommand {
	
	public static final String KINOU_ID = "VSHMEG";
	private Tray tray;
	
	public PSHMEGCommand() {
		super( PSHMEGCommand.class, KINOU_ID, null );
	}
	
	public void init( StateTransitionEvent e ) {
		try {
			this.tray = new Tray(e);
			/* Not Update Token While Single Sheet.
			CSRFTokenUtil.setNewTokenNo( request, e.getResponse() ); */
			main();
		} catch (CareerException ex) {
			throw new CareerRuntimeException(ex);
		}
	}
	
	private void main() throws CareerException {
		
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( tray.session, UserInfoBean.SESSION_KEY );
		tray.operatorGuid = userInfo.getOperatorGuid();
		
		execEventShow();
		
		/* 操作ログ */
		OutLogBean.outputLogSousa(tray.request, KINOU_ID, tray.state);
	}

	private void execEventShow() throws CareerException {
		
		String actorCd = AU.getSessionAttr(tray.session, CsSessionKey.VSHMEG_SELECTED_ACTOR);
		String statusCd = AU.getSessionAttr(tray.session, CsSessionKey.VSHMEG_SHOWING_STCD);
		
		MultiEditGymknEvArg arg = new MultiEditGymknEvArg(tray.loginNo);
		arg.sharp = "SHOW";
		arg.loginGuid = tray.loginNo;
		arg.operatorGuid = tray.operatorGuid;
		arg.actorCd = actorCd;
		arg.statusCd = statusCd;
		MultiEditGymknEvRslt result = MultiEditGymknEvHdlr.exec(arg);
		
		boolean hasStayAction = checkHasStayAction(result.actionList);
		
		AU.setReqAttr(this.tray.request, "VSHMEG_SHEETLIST", result.sheetList);
		AU.setReqAttr(this.tray.request, "VSHMEG_ACTIONLIST", result.actionList);
		AU.setReqAttr(this.tray.request, "VSHMEG_LABELSETMAP", result.labelSetMap);
		AU.setReqAttr(this.tray.request, "VSHMEG_HAS_STAY", hasStayAction);
	}
	
	private boolean checkHasStayAction(List<CsmSheetActionDto> actionList) {
		for (CsmSheetActionDto dto : actionList) {
			if (SU.equals( "STAY", dto.getActionCd() )) {
				return true;
			}
		}
		return false;
	}
}
