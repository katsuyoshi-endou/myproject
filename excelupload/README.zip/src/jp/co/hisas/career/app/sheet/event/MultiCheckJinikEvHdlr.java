package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.OneColumnDao;
import jp.co.hisas.career.util.log.Log;

public class MultiCheckJinikEvHdlr extends AbstractEventHandler<MultiCheckJinikEvArg, MultiCheckJinikEvRslt> {
	
	private String daoLoginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static MultiCheckJinikEvRslt exec(MultiCheckJinikEvArg arg) throws CareerException {
		MultiCheckJinikEvHdlr handler = new MultiCheckJinikEvHdlr();
		return handler.call(arg);
	}
	
	public MultiCheckJinikEvRslt call(MultiCheckJinikEvArg arg) throws CareerException {
		MultiCheckJinikEvRslt result = null;
		Log.method(arg.getLoginNo(), "IN", "");
		if (Log.isDebugMode()) {
			result = this.execute(arg);
		} else {
			result = this.callEjb(arg);
		}
		Log.method(arg.getLoginNo(), "OUT", "");
		return result;
	}
	
	protected MultiCheckJinikEvRslt execute(MultiCheckJinikEvArg arg) throws CareerException {
		
		arg.validateArg();
		daoLoginNo = arg.getLoginNo();
		
		MultiCheckJinikEvRslt result = new MultiCheckJinikEvRslt();
		
		try {
			if (SU.equals("CHECK_A", arg.sharp)) {
				result.chkNgSheetIdSet = checkA( arg.getLoginNo() );
			}
			else if (SU.equals("CHECK_B", arg.sharp)) {
				result.chkNgSheetIdSet = checkB( arg.getLoginNo() );
			}
			else if (SU.equals("CHECK_C", arg.sharp)) {
				result.chkNgSheetIdSet = checkC( arg.getLoginNo() );
			}
			return result;
		} catch (Exception e) {
			throw new CareerException(e.getMessage());
		} finally {
			Log.method(arg.getLoginNo(), "OUT", "");
		}
	}
	
	private Set<String> checkA( String loginPersonId ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select wk.SHEET_ID as text ");
		sql.append( "   from ZZ_JINIK_WK_RSLT wk ");
		sql.append( "     left outer join  ");
		sql.append( "       (select * from V_CST_ALL_FILLS where FILL_ID = 'jinik_kaito_genzai_tanto_gyomu') tant ");
		sql.append( "         on (wk.SHEET_ID	= tant.SHEET_ID) ");
		sql.append( "   where LOGIN_PERSON_ID = ? ");
		sql.append( "     and tant.FILL_CONTENT IS NULL ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( loginPersonId );
		
		OneColumnDao dao = new OneColumnDao( daoLoginNo );
		List<String> chkNgSheetIdList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		Set<String> set = new HashSet<String>(chkNgSheetIdList);
		return set;
	}

	private Set<String> checkB( String loginPersonId ) {
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select wk.SHEET_ID as text " );
		sql.append( "   from ZZ_JINIK_WK_RSLT wk " );
		sql.append( "     left outer join " );
		sql.append( "       (select * from V_CST_ALL_FILLS where FILL_ID = 'jinik_kaito_ido_place') pl " );
		sql.append( "         on (wk.SHEET_ID	= pl.SHEET_ID) " );
		sql.append( "     left outer join " );
		sql.append( "       (select * from V_CST_ALL_FILLS where FILL_ID = 'jinik_kaito_ido_month') mo " );
		sql.append( "         on (wk.SHEET_ID	= mo.SHEET_ID) " );
		sql.append( "   where LOGIN_PERSON_ID = ? " );
		sql.append( "     and (pl.FILL_CONTENT IS NULL or mo.FILL_CONTENT IS NULL) " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( loginPersonId );
		
		OneColumnDao dao = new OneColumnDao( daoLoginNo );
		List<String> chkNgSheetIdList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		Set<String> set = new HashSet<String>( chkNgSheetIdList );
		return set;
	}
	
	private Set<String> checkC( String loginPersonId ) {
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select wk.SHEET_ID as text " );
		sql.append( "   from ZZ_JINIK_WK_RSLT wk " );
		sql.append( "     left outer join " );
		sql.append( "       (select * from V_CST_ALL_FILLS where FILL_ID = 'jinik_kaito_ido_place') pl " );
		sql.append( "         on (wk.SHEET_ID	= pl.SHEET_ID) " );
		sql.append( "     left outer join " );
		sql.append( "       (select * from V_CST_ALL_FILLS where FILL_ID = 'jinik_kaito_ido_month') mo " );
		sql.append( "         on (wk.SHEET_ID	= mo.SHEET_ID) " );
		sql.append( "   where LOGIN_PERSON_ID = ? " );
		sql.append( "     and (pl.FILL_CONTENT IS NOT NULL or mo.FILL_CONTENT IS NOT NULL) " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( loginPersonId );
		
		OneColumnDao dao = new OneColumnDao( daoLoginNo );
		List<String> chkNgSheetIdList = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		Set<String> set = new HashSet<String>( chkNgSheetIdList );
		return set;
	}
}