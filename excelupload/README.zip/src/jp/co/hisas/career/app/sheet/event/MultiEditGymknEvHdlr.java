package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jp.co.hisas.career.app.sheet.dao.CsmSheetActionDao;
import jp.co.hisas.career.app.sheet.dao.ZzGymknSrchRsltDao;
import jp.co.hisas.career.app.sheet.dto.CsmSheetActionDto;
import jp.co.hisas.career.app.sheet.dto.ZzGymknSrchRsltDto;
import jp.co.hisas.career.app.sheet.util.CareerSheetLabel;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.ValueTextSortDao;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;
import jp.co.hisas.career.util.log.Log;

public class MultiEditGymknEvHdlr extends AbstractEventHandler<MultiEditGymknEvArg, MultiEditGymknEvRslt> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static MultiEditGymknEvRslt exec(MultiEditGymknEvArg arg) throws CareerException {
		MultiEditGymknEvHdlr handler = new MultiEditGymknEvHdlr();
		return handler.call(arg);
	}
	
	public MultiEditGymknEvRslt call(MultiEditGymknEvArg arg) throws CareerException {
		MultiEditGymknEvRslt result = null;
		Log.method(arg.getLoginNo(), "IN", "");
		if (Log.isDebugMode()) {
			result = this.execute(arg);
		} else {
			result = this.callEjb(arg);
		}
		Log.method(arg.getLoginNo(), "OUT", "");
		return result;
	}
	
	protected MultiEditGymknEvRslt execute(MultiEditGymknEvArg arg) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		MultiEditGymknEvRslt result = new MultiEditGymknEvRslt();
		
		try {
			
			if (SU.equals("INIT", arg.sharp)) {
				execCopyToWork(arg);
				
				result.actorList = getActorList(arg);
			}
			else if (SU.equals("SHOW", arg.sharp)) {
				
				result.sheetList = getSheetInfo(arg);
				result.actionList = getActionList("flw-gymkn", "flwptn-normal", arg.statusCd, arg.actorCd);
				result.labelSetMap = getLabelSetMap(arg, result.sheetList);
			}
			else if (SU.equals("STAY", arg.sharp)) {

			}
			else if (SU.matches("FORWARD|SKIP|BACKWARD|RESUME", arg.sharp)) {

			}
			
			
			return result;
		} catch (Exception e) {
			throw new CareerException(e.getMessage());
		} finally {
			Log.method(arg.getLoginNo(), "OUT", "");
		}
	}
	
	private Map<String, Map<String, String>> getLabelSetMap(MultiEditGymknEvArg arg, List<CsSheetEventResult> sheetList) {
		Set<String> list = new HashSet<String>();
		for (CsSheetEventResult one : sheetList) {
			String labelSetCd = one.getInfoAttrDto().getLabelSetCd();
			list.add(labelSetCd);
		}
		Map<String, Map<String,String>> result = new HashMap<String, Map<String,String>>();
		for (String labelSetCd : list) {
			HashMap<String, String> lsm = CareerSheetLabel.getLabelSetMap( labelSetCd, 1 );
			result.put(labelSetCd, lsm);
		}
		return result;
	}
	
	/**
	 * CsSheetEventHandlerよりコピー
	 */
	private List<CsmSheetActionDto> getActionList( String flowCd, String flowPtn, String statusCd, String actorCd ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + CsmSheetActionDao.ALLCOLS );
		sql.append( "   from CSM_SHEET_ACTION ");
		sql.append( "  where FLOW_CD = ? and FLOW_PTN = ? and STATUS_CD = ? and ACTOR_CD = ? ");
		sql.append( "  order by LPAD_SORT ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( flowCd );
		paramList.add( flowPtn );
		paramList.add( statusCd );
		paramList.add( actorCd );
		
		CsmSheetActionDao dao = new CsmSheetActionDao(this.loginNo);
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<CsSheetEventResult> getSheetInfo(MultiEditGymknEvArg arg) throws CareerException {
		List<CsSheetEventResult> sheetList = new ArrayList<CsSheetEventResult>();
		
		StringBuilder sql = new StringBuilder();
		sql.append(" select " + SU.addPrefixOnDaoAllCols("zz", ZzGymknSrchRsltDao.ALLCOLS ) );
		sql.append("   from (ZZ_GYMKN_SRCH_RSLT zz ");
		sql.append("        inner join V_CST_SHEET_ACTOR_AND_REF ac ");
		sql.append("          on (ac.SHEET_ID = zz.SHEET_ID)) ");
		sql.append("        inner join V_CS_INFO_ATTR at ON (at.SHEET_ID = zz.SHEET_ID) ");
		sql.append("  where zz.LOGIN_PERSON_ID = ? ");
		sql.append("    and ac.GUID = ? ");
		sql.append("    and ac.ACTOR_CD = ? ");
		sql.append("    order by at.OPERATION_SORT desc, at.CMPA_CD, at.SHEET_SORT ");
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add(arg.loginGuid);
		paramList.add(arg.operatorGuid);
		paramList.add(arg.actorCd);
		
		ZzGymknSrchRsltDao dao = new ZzGymknSrchRsltDao(this.loginNo);
		List<ZzGymknSrchRsltDto> list = dao.selectDynamic(DaoUtil.getPstmt(sql, paramList));
		
		for (ZzGymknSrchRsltDto dto : list) {
			CsSheetEventArg evArg = new CsSheetEventArg(this.loginNo, this.loginNo);
			evArg.sharp = "INIT";
			evArg.sheetId = dto.getSheetId();
			evArg.actorCd = arg.actorCd;
			CsSheetEventResult one = CsSheetEventHandler.exec(evArg);
			one = makeSheetFillMasked(one);
			sheetList.add(one);
		}
		return sheetList;
	}
	
	private CsSheetEventResult makeSheetFillMasked(CsSheetEventResult one) {
		HashMap<String, String> maskedFillMap = new HashMap<String, String>();
		HashMap<String, String> rawFillMap = one.getFillMap();
		HashMap<String, String> maskMap = one.getFillMaskMap();
		for (Map.Entry<String, String> entry : rawFillMap.entrySet()) {
			String key = entry.getKey();
			String val = entry.getValue();
			String mode = maskMap.get(key);
			if (SU.matches(mode, "read|write")) {
				maskedFillMap.put(key, val);
			} else {
				maskedFillMap.put(key, "");
			}
		}
		one.setFillMap(maskedFillMap);
		return one;
	}
	
	private void execCopyToWork(MultiEditGymknEvArg arg) {
		
		StringBuilder delsql = new StringBuilder();
		delsql.append("delete from ZZ_GYMKN_SRCH_RSLT where LOGIN_PERSON_ID = ? ");
		
		StringBuilder inssql = new StringBuilder();
		inssql.append("insert into ZZ_GYMKN_SRCH_RSLT ");
		inssql.append("    select LOGIN_PERSON_ID ,SHEET_ID, OWN_GUID from CST_SHEET_SRCH_RSLT where LOGIN_PERSON_ID = ? ");
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add(arg.loginGuid);
		
		ZzGymknSrchRsltDao dao = new ZzGymknSrchRsltDao(this.loginNo);
		dao.executeDynamic(DaoUtil.getPstmt(delsql, paramList));
		dao.executeDynamic(DaoUtil.getPstmt(inssql, paramList));
	}
	
	private List<ValueTextSortDto> getActorList(MultiEditGymknEvArg arg) {
		
		StringBuilder sql = new StringBuilder();
		sql.append("select distinct ac.ACTOR_CD as value, ac.ACTOR_NM as text, ac.ACTOR_SORT as sort ");
		sql.append("  from ZZ_GYMKN_SRCH_RSLT zz ");
		sql.append("       inner join V_CST_SHEET_ACTOR_AND_REF ac ");
		sql.append("         on ( zz.SHEET_ID = ac.SHEET_ID ) ");
		sql.append(" where ac.GUID = ? ");
		sql.append(" and zz.LOGIN_PERSON_ID	= ? ");
		sql.append(" order by ac.ACTOR_SORT ");
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add(arg.operatorGuid);
		paramList.add(arg.loginGuid);
		
		ValueTextSortDao dao = new ValueTextSortDao(this.loginNo);
		List<ValueTextSortDto> list = dao.selectDynamic(DaoUtil.getPstmt(sql, paramList));
		
		return list;
	}
	

}
