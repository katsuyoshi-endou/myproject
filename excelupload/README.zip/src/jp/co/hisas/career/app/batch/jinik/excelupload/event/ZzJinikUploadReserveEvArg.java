package jp.co.hisas.career.app.batch.jinik.excelupload.event;

import jp.co.hisas.career.ejb.AbstractEventArg;

public class ZzJinikUploadReserveEvArg extends AbstractEventArg {
	
}
