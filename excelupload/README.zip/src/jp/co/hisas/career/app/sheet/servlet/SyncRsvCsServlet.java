package jp.co.hisas.career.app.sheet.servlet;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.NewTokenServlet;
import jp.co.hisas.career.app.sheet.event.CsRsvAdminEvArg;
import jp.co.hisas.career.app.sheet.event.CsRsvAdminEvHdlr;
import jp.co.hisas.career.app.sheet.event.CsRsvAdminEvRslt;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class SyncRsvCsServlet extends NewTokenServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "SyncRsvCs";
	private static final String FORWARD_PAGE = "/view/sheet/VHA011_RsvCsAdmin.jsp";
	
	public String serviceMain( Tray tray ) throws CareerException {
		
		String createdSheetId = null;
		
		/* Set Args */
		CsRsvAdminEvArg arg = new CsRsvAdminEvArg( tray.loginNo );
		arg.sharp = tray.state;
		
		/* Execute Event */
		CsRsvAdminEvRslt result = CsRsvAdminEvHdlr.exec( arg );
		String resultMsg = result.resultMsg;
		String msgKind = "";
		if (result.exitCd == 0) {
			// 0: 正常終了
			msgKind = AppSessionKey.RESULT_MSG_INFO;
		} else if (result.exitCd == 1) {
			// 1: 警告
			msgKind = AppSessionKey.RESULT_MSG_WARN;
		} else if (result.exitCd > 1) {
			// 8: Oracleエラー, 9: 業務エラー
			msgKind = AppSessionKey.RESULT_MSG_ERROR;
			resultMsg = "エラーが発生しました。ログを確認して下さい。";
		}
		
		/* Return to session */
		tray.session.setAttribute( msgKind, resultMsg );
		
		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, createdSheetId, tray.state );
		
		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}
	
}
