package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.VCsmActiveOpeFormDto;
import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class CsNewSheetEventResult extends AbstractEventResult {

	public List<VCsmActiveOpeFormDto> activeOpeFormList = null;
	public String newSheetId = null;
	public int exitCd;
	public String resultMsg = null;
	public String resultWarnMsg = null;

}