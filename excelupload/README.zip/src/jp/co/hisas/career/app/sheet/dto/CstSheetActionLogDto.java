/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSTシートアクションログ Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CstSheetActionLogDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * タイムスタンプ
     */
    private String timestamp;
    /**
     * シートID
     */
    private String sheetId;
    /**
     * ステータスコード
     */
    private String statusCd;
    /**
     * アクターコード
     */
    private String actorCd;
    /**
     * ログイン人ID
     */
    private String loginPersonId;
    /**
     * アクションコード
     */
    private String actionCd;
    /**
     * 操作後ステータスコード
     */
    private String afterStatusCd;
    /**
     * 伝言
     */
    private String delivMsg;

    /**
     * タイムスタンプを取得する。
     * @return タイムスタンプ
     */
    public String getTimestamp() {
        return timestamp;
    }

    /**
     * タイムスタンプを設定する。
     * @param timestamp タイムスタンプ
     */
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * シートIDを取得する。
     * @return シートID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * シートIDを設定する。
     * @param sheetId シートID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * ステータスコードを取得する。
     * @return ステータスコード
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * ステータスコードを設定する。
     * @param statusCd ステータスコード
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * アクターコードを取得する。
     * @return アクターコード
     */
    public String getActorCd() {
        return actorCd;
    }

    /**
     * アクターコードを設定する。
     * @param actorCd アクターコード
     */
    public void setActorCd(String actorCd) {
        this.actorCd = actorCd;
    }

    /**
     * ログイン人IDを取得する。
     * @return ログイン人ID
     */
    public String getLoginPersonId() {
        return loginPersonId;
    }

    /**
     * ログイン人IDを設定する。
     * @param loginPersonId ログイン人ID
     */
    public void setLoginPersonId(String loginPersonId) {
        this.loginPersonId = loginPersonId;
    }

    /**
     * アクションコードを取得する。
     * @return アクションコード
     */
    public String getActionCd() {
        return actionCd;
    }

    /**
     * アクションコードを設定する。
     * @param actionCd アクションコード
     */
    public void setActionCd(String actionCd) {
        this.actionCd = actionCd;
    }

    /**
     * 操作後ステータスコードを取得する。
     * @return 操作後ステータスコード
     */
    public String getAfterStatusCd() {
        return afterStatusCd;
    }

    /**
     * 操作後ステータスコードを設定する。
     * @param afterStatusCd 操作後ステータスコード
     */
    public void setAfterStatusCd(String afterStatusCd) {
        this.afterStatusCd = afterStatusCd;
    }

    /**
     * 伝言を取得する。
     * @return 伝言
     */
    public String getDelivMsg() {
        return delivMsg;
    }

    /**
     * 伝言を設定する。
     * @param delivMsg 伝言
     */
    public void setDelivMsg(String delivMsg) {
        this.delivMsg = delivMsg;
    }

}

