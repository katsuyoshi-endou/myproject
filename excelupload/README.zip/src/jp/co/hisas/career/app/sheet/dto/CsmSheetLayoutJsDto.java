/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSM_SHEET_LAYOUT_JS Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetLayoutJsDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * レイアウトコード
     */
    private String layoutCd;
    /**
     * 行番号
     */
    private String lineNo;
    /**
     * スクリプト
     */
    private String script;

    /**
     * レイアウトコードを取得する。
     * @return レイアウトコード
     */
    public String getLayoutCd() {
        return layoutCd;
    }

    /**
     * レイアウトコードを設定する。
     * @param layoutCd レイアウトコード
     */
    public void setLayoutCd(String layoutCd) {
        this.layoutCd = layoutCd;
    }

    /**
     * 行番号を取得する。
     * @return 行番号
     */
    public String getLineNo() {
        return lineNo;
    }

    /**
     * 行番号を設定する。
     * @param lineNo 行番号
     */
    public void setLineNo(String lineNo) {
        this.lineNo = lineNo;
    }

    /**
     * スクリプトを取得する。
     * @return スクリプト
     */
    public String getScript() {
        return script;
    }

    /**
     * スクリプトを設定する。
     * @param script スクリプト
     */
    public void setScript(String script) {
        this.script = script;
    }

}

