/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CST_RSV_CHG_STATUS Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CstRsvChgStatusDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * シートID
     */
    private String sheetId;
    /**
     * ステータスコード
     */
    private String statusCd;

    /**
     * シートIDを取得する。
     * @return シートID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * シートIDを設定する。
     * @param sheetId シートID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * ステータスコードを取得する。
     * @return ステータスコード
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * ステータスコードを設定する。
     * @param statusCd ステータスコード
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

}

