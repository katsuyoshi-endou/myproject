package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dao.ZzUncreatedWkDao;
import jp.co.hisas.career.app.sheet.dto.ZzUncreatedWkDto;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.ValueTextSortDao;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;
import jp.co.hisas.career.util.log.Log;

public class BulkCreateSheetEvHdlr extends AbstractEventHandler<BulkCreateSheetEvArg, BulkCreateSheetEvRslt> {

	private String daoLoginNo;

	public static BulkCreateSheetEvRslt exec( BulkCreateSheetEvArg arg ) throws CareerException {
		BulkCreateSheetEvHdlr handler = new BulkCreateSheetEvHdlr();
		return handler.call( arg );
	}

	@Override
	public BulkCreateSheetEvRslt call( BulkCreateSheetEvArg arg ) throws CareerException {
		BulkCreateSheetEvRslt result = null;

		Log.method( arg.getLoginNo(), "IN", "" );

		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );

		return result;
	}

	@Override
	protected BulkCreateSheetEvRslt execute( BulkCreateSheetEvArg arg ) throws CareerException {

		this.daoLoginNo = arg.getLoginNo();

		BulkCreateSheetEvRslt result = new BulkCreateSheetEvRslt();

		if ( SU.matches( arg.sharp, "SEARCH" )) {

			// 検索ワーク作成
			insertUnCreatedSheetWK( arg );

			// ワークから検索
			List<ZzUncreatedWkDto> list = getUncreatedSheetList( arg );

			result.setSheetList( list );

			// 作成対象言語リストの取得
			List<ValueTextSortDto> langList = getLanguageList();

			result.setLangList( langList );
		}
		return result;
	}

	private void insertUnCreatedSheetWK( BulkCreateSheetEvArg arg ) {

		// ログオンユーザに紐付くワークテーブルデータ削除
		ZzUncreatedWkDao zuwDao = new ZzUncreatedWkDao( arg.getLoginNo() );
		zuwDao.deleteByLoginPersonID( arg.getLoginNo());

		// ワークテーブルに表示対象者のデータを登録
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " insert into ZZ_UNCREATED_WK " );
		sql.append( "   select ? as LOGIN_PERSON_ID " );
		sql.append( "         ,? as OPERATION_CD " );
		sql.append( "         ,CR.GUID as OWN_GUID " );
		sql.append( "         ,CR.PERSON_NAME as OWN_PERSON_NAME " );
		sql.append( "         ,CR.PERSON_NAME_KANA as OWN_PERSON_NAME_KANA " );
		sql.append( "         ,PB.CMPA_CD as OWN_CMPA_CD " );
		sql.append( "         ,DEPT.FULL_DEPT_NM as OWN_FULL_DEPT_NM " );
		sql.append( "         ,CR.MAIL_ADDRESS as OWN_MAIL_ADDRESS " );
		sql.append( "         ,'' " );
		sql.append( "   from CA_REGIST CR " );
		sql.append( "     inner join PERSON_BELONG PB " );
		sql.append( "            on CR.STF_NO = PB.STF_NO " );
		sql.append( "            and CR.CMPA_CD = PB.CMPA_CD  " );
		sql.append( "     inner join DEPT " );
		sql.append( "            on PB.CMPA_CD = DEPT.CMPA_CD " );
		sql.append( "            and PB.DEPT_CD = DEPT.DEPT_CD " );
		sql.append( "   where CR.GUID in (select distinct " );
		sql.append( "                       AF.OWN_GUID as GUID ");
		sql.append( "                     from ZZ_CST_SHEET_ACTOR_AND_REF AF " );
		sql.append( "                       , CSM_SHEET_OPERATION SO " );
		sql.append( "                     where AF.GUID = ? " );
		sql.append( "                       and AF.ACTOR_CD <> 'act-owner'" );
		sql.append( "                       and SO.PARTY = 'PANA' " );
		sql.append( "                       and SO.OPERATION_CD = ? " );
		sql.append( "                       and SO.OPEN_FLG = '1' " );
		sql.append( "                       and SO.ACTIVE_FLG = '1' " );
		sql.append( "                       and not exists( " );
		sql.append( "                                select 1 " );
		sql.append( "                                from CST_SHEET CS " );
		sql.append( "                                where CS.OPERATION_CD = SO.OPERATION_CD " );
		sql.append( "                                  and CS.PARTY = SO.PARTY " );
		sql.append( "                                  and CS.OWN_GUID = AF.OWN_GUID" );
		sql.append( "                       )" );
		sql.append( "                    )" );

		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.getLoginNo());
		paramList.add( arg.operationCd );
		paramList.add( arg.operatorGuid );
		paramList.add( arg.operationCd );
		// 登録
		zuwDao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}

	private List<ZzUncreatedWkDto> getUncreatedSheetList( BulkCreateSheetEvArg arg ) {

		ZzUncreatedWkDao zuwDao = new ZzUncreatedWkDao( arg.getLoginNo());
		StringBuilder sql = new StringBuilder();
		// パラメータセット
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.getLoginNo());

		// 検索条件絞り込み
		sql.append( " select " + ZzUncreatedWkDao.ALLCOLS );
		sql.append( " from ( " );
		sql.append( " select " );
		sql.append( "  LOGIN_PERSON_ID AS LOGIN_PERSON_ID" );
		sql.append( " ,OPERATION_CD AS OPERATION_CD " );
		sql.append( " ,OWN_GUID AS OWN_GUID " );
		sql.append( " ,OWN_PERSON_NAME AS OWN_PERSON_NAME " );
		sql.append( " ,OWN_PERSON_NAME_KANA AS OWN_PERSON_NAME_KANA " );
		sql.append( " ,OWN_CMPA_CD AS OWN_CMPA_CD " );
		sql.append( " ,OWN_FULL_DEPT_NM AS OWN_FULL_DEPT_NM " );
		sql.append( " ,OWN_MAIL_ADDRESS AS OWN_MAIL_ADDRESS " );
		sql.append( " ,'99' AS SHEET_STATUS " );
		sql.append( " from ZZ_UNCREATED_WK " );
		sql.append( " where LOGIN_PERSON_ID = ? " );
		// Global_ID
		if ( CsUtil.srchCondAvailable( arg.srchCondMap, "personId" )) {
			sql.append( " and OWN_GUID like ? " );
			paramList.add( "%" + arg.srchCondMap.get( "personId" ) + "%" );
		}
		// 所属
		if ( CsUtil.srchCondAvailable( arg.srchCondMap, "deptNm" )) {
			sql.append( " and OWN_FULL_DEPT_NM like ? " );
			paramList.add( "%" + arg.srchCondMap.get( "deptNm" ) + "%" );
		}
		// 氏名
		if ( CsUtil.srchCondAvailable( arg.srchCondMap, "personNm" )) {
			sql.append( " and OWN_PERSON_NAME like ? " );
			paramList.add( "%" + arg.srchCondMap.get( "personNm" ) + "%" );
		}
		// 氏名（カナ）
		if ( CsUtil.srchCondAvailable( arg.srchCondMap, "personNmKn" )) {
			sql.append( " and OWN_PERSON_NAME_KANA like ? " );
			paramList.add( "%" + arg.srchCondMap.get( "personNmKn" ) + "%" );
		}
		// ソート順指定
		sql.append( " order by OWN_CMPA_CD asc, OWN_FULL_DEPT_NM asc, OWN_GUID asc " );
		sql.append( " ) " );
		// 500のみ表示する
		sql.append( " where rownum < 501 " );

		return zuwDao.selectDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}

	private List<ValueTextSortDto> getLanguageList() {

		StringBuilder sql = new StringBuilder();

		sql.append( "SELECT " );
		sql.append( "    FORM_CD AS value, " );
		sql.append( "    LANG_NM AS text, " );
		sql.append( "    LANG_SORT AS sort " );
		sql.append( "FROM ZZ_CSM_SHEET_BULK_LANGUAGE" );

		ValueTextSortDao dao = new ValueTextSortDao( daoLoginNo );
		return dao.selectDynamic( sql.toString());
	}
}
