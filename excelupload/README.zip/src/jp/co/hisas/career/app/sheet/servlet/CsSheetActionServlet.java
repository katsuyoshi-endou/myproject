package jp.co.hisas.career.app.sheet.servlet;

import java.util.HashMap;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.app.sheet.event.CsSheetEventArg;
import jp.co.hisas.career.app.sheet.event.CsSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.CsSheetEventResult;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.KeepTokenServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class CsSheetActionServlet extends KeepTokenServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "VHD010";
	private static final String FORWARD_PAGE = "/servlet/CsSheetServlet";
	
	public String serviceMain( Tray tray ) throws CareerException {
		
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( tray.session, UserInfoBean.SESSION_KEY );
		tray.operatorGuid = userInfo.getOperatorGuid();
		
		// set SheetID on Session.
		String sheetId = CsUtil.setSheetIdOnSession( tray.request, tray.session );
		
		// DB シート情報更新処理
		if (SU.matches( tray.state, "STAY|FORWARD|BACKWARD|RESUME|SKIP|DELETE" )) {
			
			// Requestの中から Fill-- で始まるもののみを抽出 (Prefix will be removed)
			HashMap<String, String> fillReqMap = CsUtil.getRequestsWithRegex( tray.request, "^Fill--" );
			
			// Requestの中から OptFill-- で始まるもののみを抽出 (Prefix will be removed)
			HashMap<String, String> optFillReqMap = CsUtil.getRequestsWithRegex( tray.request, "^Opt--" );
			
			CsSheetEventArg arg = new CsSheetEventArg( tray.loginNo, tray.operatorGuid );
			arg.sharp = tray.state;
			arg.mailSenderName = userInfo.getKanjiSimei();//TODO: 統合アカウントの名前であるべき
			arg.sheetId = sheetId;
			CstSheetExclusiveDto excDto = new CstSheetExclusiveDto();
			excDto.setSheetId( sheetId );
			Integer iExcKey = Integer.parseInt( CsUtil.bvl( tray.request.getParameter( "exclusiveKey" ), "0" ) );
			excDto.setExclusiveKey( iExcKey );
			arg.exclusiveKey = excDto;
			arg.fillReqMap = fillReqMap;
			arg.optFillReqMap = optFillReqMap;
			arg.actionCd = tray.state;
			arg.delivMsg = AU.getRequestValue( tray.request, "deliv_msg" );
			CsSheetEventResult result = CsSheetEventHandler.exec( arg );
			
			if (!CsUtil.isBlank( result.getResultMessage() )) {
				// ホーム画面に遷移する場合もある(削除時)ため、Request/Sessionどちらにも入れる
				tray.request.setAttribute( AppSessionKey.RESULT_MSG_INFO, result.getResultMessage() );
				tray.session.setAttribute( AppSessionKey.RESULT_MSG_INFO, result.getResultMessage() );
			}
			if (!CsUtil.isBlank( result.getResultErrorMessage() )) {
				// ホーム画面に遷移する場合もある(削除時)ため、Request/Sessionどちらにも入れる
				tray.request.setAttribute( AppSessionKey.RESULT_MSG_ERROR, result.getResultErrorMessage() );
				tray.session.setAttribute( AppSessionKey.RESULT_MSG_ERROR, result.getResultErrorMessage() );
			}
			
			// シート削除の場合はシート画面を描画できないので遷移先を指定
			if (SU.equals( tray.state, "DELETE" )) {
				tray.forwardUrl = AppDef.HOME_URL;
			}
		}
		
		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, sheetId, tray.state );
		
		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}
}
