package jp.co.hisas.career.app.batch.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jp.co.hisas.career.app.batch.util.property.HcdbDef;

@SuppressWarnings({ "rawtypes" })
public class BatchUtil {

	private static String JDBC_CONNECTION = "BATCH_JDBC_CONNECTION";
	
	private static String JDBC_USER = "BATCH_JDBC_USER";
	
	private static String JDBC_PASS = "BATCH_JDBC_PASSWORD";

	static public Connection getConnetcion() throws SQLException, Exception {
		
		try {
			Class.forName( HcdbDef.ORACLE_DRIVER );
			
//			final HashMap map = ReadFile.careerProperties;
//			final String jdbc_connect = ( String ) map.get( BatchUtil.JDBC_CONNECTION );
//			final String jdbc_user = ( String ) map.get( BatchUtil.JDBC_USER );
//			final String jdbc_pass = ( String ) map.get( BatchUtil.JDBC_PASS );

			final String jdbc_connect = "jdbc:oracle:thin:@10.230.82.186:1521:ORCL";
			final String jdbc_user = "LYSH_DEV";
			final String jdbc_pass = "LYSH_DEV";
			
			final Connection dbConnection = DriverManager.getConnection( jdbc_connect, jdbc_user, jdbc_pass );
			
			return dbConnection;
		} catch ( final SQLException e ) {
			throw e;
		} catch ( final Exception e ) {
			throw e;
		}
	}

	static public void closeConnection( final Connection conn, final Statement stmt, final ResultSet rs ) {
		try {
			if ( rs != null ) {
				rs.close();
			}
			
			if ( stmt != null ) {
				stmt.close();
			}
			
			if ( conn != null ) {
				conn.close();
			}
		} catch ( final Exception e ) {
			
		}
	}
	
	static public void closeConnection( final Connection conn, final Statement stmt ) {
		BatchUtil.closeConnection( conn, stmt, null );
	}

	static public void closeconnection( final Connection conn ) {
		BatchUtil.closeConnection( conn, null, null );
	}

	static public void rollbackConnection( final Connection conn ) {
		try {
			conn.rollback();
		} catch ( final SQLException e ) {
			
		}
	}

	static public void commitConnection( final Connection conn ) {
		try {
			conn.commit();
		} catch ( SQLException e ) {
			
		}
	}
}
