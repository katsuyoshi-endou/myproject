package jp.co.hisas.career.app.batch.jinik.excelupload.event;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;

public class ZzJinikUploadReserveEvHdlr extends AbstractEventHandler<ZzJinikUploadReserveEvArg, ZzJinikUploadReserveEvRslt> {

	@Override
	public ZzJinikUploadReserveEvRslt call( ZzJinikUploadReserveEvArg arg0 ) throws CareerException {
		return null;
	}

	@Override
	protected ZzJinikUploadReserveEvRslt execute( ZzJinikUploadReserveEvArg arg0 ) throws CareerException {
		return null;
	}
	
}
