/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CstRsvFillDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CST_RSV_FILL Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CstRsvFillDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " SHEET_ID as sheetId,"
                     + " FILL_ID as fillId,"
                     + " FILL_CONTENT as fillContent"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CstRsvFillDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CstRsvFillDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * Insert文を実行する。
     * @param dto CST_RSV_FILLのデータ。
     */ 
    public void insert(CstRsvFillDto dto) {

        final String sql = "INSERT INTO CST_RSV_FILL ("
                         + "SHEET_ID,"
                         + "FILL_ID,"
                         + "FILL_CONTENT"
                         + ")VALUES(?,?,? )"
                         ;
        Log.sql("【DaoMethod Call】 CstRsvFillDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getSheetId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getFillId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getFillContent());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * 全列update文を実行する。
     * @param dto CST_RSV_FILLのレコード型データ。
     */
    public void update(CstRsvFillDto dto) {

        final String sql = "UPDATE CST_RSV_FILL SET "
                         + "FILL_CONTENT = ?"
                         + " WHERE SHEET_ID = ?"
                         + " AND FILL_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstRsvFillDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getFillContent());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getSheetId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getFillId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してdelete文を実行する。
     * @param sheetId SHEET_ID
     * @param fillId FILL_ID
     */ 
    public void delete(String sheetId, String fillId) {

        final String sql = "DELETE FROM CST_RSV_FILL"
                         + " WHERE SHEET_ID = ?"
                         + " AND FILL_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstRsvFillDao.delete");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, fillId);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally { 
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param sheetId SHEET_ID
     * @param fillId FILL_ID
     * @return CstRsvFillDto CST_RSV_FILLのレコード型データ。
     */ 
    public CstRsvFillDto select(String sheetId, String fillId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CST_RSV_FILL"
                         + " WHERE SHEET_ID = ?"
                         + " AND FILL_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstRsvFillDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, fillId);
            rs = pstmt.executeQuery();
            CstRsvFillDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<CstRsvFillDto> CST_RSV_FILLのレコード型データのリスト。
     */ 
    public List<CstRsvFillDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CstRsvFillDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CstRsvFillDto> lst = new ArrayList<CstRsvFillDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CstRsvFillDto> CST_RSV_FILLのレコード型データのリスト。
     */ 
    public List<CstRsvFillDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CstRsvFillDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param pstmt PreparedStatement
     */ 
    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("【DaoMethod Call】 CstRsvFillDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param sql SQL文
     */ 
    public void executeDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CstRsvFillDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CstRsvFillDto transferRsToDto(ResultSet rs) throws SQLException {

        CstRsvFillDto dto = new CstRsvFillDto();
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setFillId(DaoUtil.convertNullToString(rs.getString("fillId")));
        dto.setFillContent(DaoUtil.convertNullToString(rs.getString("fillContent")));
        return dto;
    }

}

