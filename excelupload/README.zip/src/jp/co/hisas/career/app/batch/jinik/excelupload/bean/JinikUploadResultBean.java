package jp.co.hisas.career.app.batch.jinik.excelupload.bean;

import java.io.Serializable;

public class JinikUploadResultBean implements Serializable {
	
	/**
	 * GUID
	 */
	private String ownGuid;

	/**
	 * 氏名
	 */
	private String ownPersonName;

	/**
	 * 所属名称
	 */
	private String ownFullDeptName;
	

	/**
	 * ログメッセージ
	 */
	private String message;

	/**
	 * GUIDを返す
	 * 
	 * @return GUID
	 */
	public String getOwnGuid() {
		return ownGuid;
	}

	/**
	 * GUIDを設定する
	 * 
	 * @param ownGuid GUID
	 */
	public void setOwnGuid( String ownGuid ) {
		this.ownGuid = ownGuid;
	}

	/**
	 * 氏名を取得する
	 * 
	 * @return 氏名
	 */
	public String getOwnPersonName() {
		return ownPersonName;
	}

	/**
	 * 氏名を設定する
	 * 
	 * @param ownPersonName 氏名
	 */
	public void setOwnPersonName( String ownPersonName ) {
		this.ownPersonName = ownPersonName;
	}

	/**
	 * 所属名称を返す
	 * 
	 * @return 所属名称
	 */
	public String getOwnFullDeptName() {
		return ownFullDeptName;
	}

	/**
	 * 所属名称を設定する
	 * 
	 * @param ownFullDeptName 所属名称
	 */
	public void setOwnFullDeptName( String ownFullDeptName ) {
		this.ownFullDeptName = ownFullDeptName;
	}

	/**
	 * メッセージを返す
	 * 
	 * @return メッセージ
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * メッセージを設定する
	 * 
	 * @param message メッセージ
	 */
	public void setMessage( String message ) {
		this.message = message;
	}
}
