package jp.co.hisas.career.app.sheet.vm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.ZzUncreatedWkDto;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.ViewModel;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

public class VmVSHBCR extends ViewModel {

	public static String VMID = VmVSHBCR.class.getSimpleName();

	// 画面を構成する情報
	public HashMap<String, String> jotaiMap;

	// 作成対象の未作成者情報
	public List<String> tgtGuids;

	// 未作成者情報の一覧リスト
	public List<ZzUncreatedWkDto> sheetList;

	// 作成対象言語リスト
	public List<ValueTextSortDto> langList;

	public VmVSHBCR(Tray tray) throws CareerException {
		super( tray );
		this.prepareLabels();

	}

	private void prepareLabels() {
		List<String> l = new ArrayList<String>();
		l.add( "LSHBCR_TITLE" );
		l.add( "LSHBCR_BACK_BTN" );
		l.add( "LSHBCR_BULK_BTN" );
		l.add( "LSHBCR_SHT_LANG" );
		l.add( "LSHBCR_LIST_01" );
		l.add( "LSHBCR_LIST_02" );
		l.add( "LSHBCR_LIST_03" );
		l.add( "LSHBCR_LIST_04" );
		l.add( "LSHBCR_LIST_05" );
		l.add( "LSHBCR_ALERT_01" );
		l.add( "LSHBCR_ALERT_02" );
		l.add( "LSHBCR_ALERT_03" );
		l.add( "LSHBCR_RESULT_MSG_01" );
		l.add( "LSHBCR_RESULT_MSG_02" );
		l.add( "LSHBCR_SHEET_RESULT_00" );
		l.add( "LSHBCR_SHEET_RESULT_01" );
		l.add( "LSHBCR_SHEET_RESULT_08" );
		l.add( "LSHBCR_SHEET_RESULT_09" );
		registerCommonLabels( l );
	}
}
