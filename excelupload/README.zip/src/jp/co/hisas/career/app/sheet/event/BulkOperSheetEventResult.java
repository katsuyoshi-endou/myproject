package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.BulkOperSheetListDto;
import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

public class BulkOperSheetEventResult extends AbstractEventResult {

	private List<BulkOperSheetListDto> sheetList = null;
	public List<ValueTextSortDto> divList = null;
	public List<ValueTextSortDto> opeList = null;
	public List<ValueTextSortDto> statusList = null;
	public int hitCnt;

	public List<BulkOperSheetListDto> getSheetList() {
		return sheetList;
	}

	public void setSheetList(List<BulkOperSheetListDto> sheetList) {
		this.sheetList = sheetList;
	}
}
