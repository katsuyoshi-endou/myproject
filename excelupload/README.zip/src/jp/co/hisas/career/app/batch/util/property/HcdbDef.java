package jp.co.hisas.career.app.batch.util.property;

public class HcdbDef {
	/** JDBCドライバクラス名 */
	public static final String ORACLE_DRIVER = "oracle.jdbc.OracleDriver";
}
