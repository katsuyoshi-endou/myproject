/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CsmSheetRemarkDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CSM_SHEET_REMARK Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetRemarkDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " RANGE_CD as rangeCd,"
                     + " RANGE_FR as rangeFr,"
                     + " RANGE_TO as rangeTo,"
                     + " REMARK as remark"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CsmSheetRemarkDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CsmSheetRemarkDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param rangeCd フローコード
     * @param rangeFr フローパターン
     * @return CsmSheetRemarkDto CSM_SHEET_REMARKのレコード型データ。
     */ 
    public CsmSheetRemarkDto select(String rangeCd, Integer rangeFr) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CSM_SHEET_REMARK"
                         + " WHERE RANGE_CD = ?"
                         + " AND RANGE_FR = ?"
                         ;
        Log.sql("【DaoMethod Call】 CsmSheetRemarkDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, rangeCd);
            DaoUtil.setIntToPreparedStatement(pstmt, 2, rangeFr);
            rs = pstmt.executeQuery();
            CsmSheetRemarkDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<CsmSheetRemarkDto> CSM_SHEET_REMARKのレコード型データのリスト。
     */ 
    public List<CsmSheetRemarkDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CsmSheetRemarkDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CsmSheetRemarkDto> lst = new ArrayList<CsmSheetRemarkDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CsmSheetRemarkDto> CSM_SHEET_REMARKのレコード型データのリスト。
     */ 
    public List<CsmSheetRemarkDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CsmSheetRemarkDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CsmSheetRemarkDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmSheetRemarkDto dto = new CsmSheetRemarkDto();
        dto.setRangeCd(DaoUtil.convertNullToString(rs.getString("rangeCd")));
        dto.setRangeFr(rs.getInt("rangeFr"));
        dto.setRangeTo(rs.getInt("rangeTo"));
        dto.setRemark(DaoUtil.convertNullToString(rs.getString("remark")));
        return dto;
    }

    /**
     * selectRemarkByPoint
     * @param rangeCd 範囲コード
     * @param rangeFr 点数
     * @param rangeTo 点数
     * @return List<CsmSheetRemarkDto> CSM_SHEET_REMARKのレコード型データのリスト。
     */
    public List<CsmSheetRemarkDto> selectRemarkByPoint(String rangeCd, int rangeFr, int rangeTo) {

        final String sql = "select " + ALLCOLS + " from CSM_SHEET_REMARK where RANGE_CD = ? and RANGE_FR <= ? and ? <= RANGE_TO";
        Log.sql("【DaoMethod Call】 CsmSheetRemarkDao.selectRemarkByPoint");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, rangeCd);
            DaoUtil.setIntToPreparedStatement(pstmt, 2, rangeFr);
            DaoUtil.setIntToPreparedStatement(pstmt, 3, rangeTo);
            rs = pstmt.executeQuery();
            List<CsmSheetRemarkDto> lst = new ArrayList<CsmSheetRemarkDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

