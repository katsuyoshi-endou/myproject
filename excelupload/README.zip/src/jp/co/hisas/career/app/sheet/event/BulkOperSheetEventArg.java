package jp.co.hisas.career.app.sheet.event;

import java.util.HashMap;

import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;

public class BulkOperSheetEventArg extends AbstractEventArg {
	public String sharp = null;
	public String party = null;
	public String opeType = null;
	public String operationCd = null;
	public String operatorGuid = null;
//	public String formGrpCd = null;
//	public String formGrps = null;
	public String statusCd = null;
//	public String searchDiv = null;
//	public String flowCd = null;
//	public String trans = null;
	public String sheetId = null;
	public String actorCd = null;
	public CstSheetExclusiveDto exclusiveKey = null;
	public HashMap<String, String> srchCondMap = null;
	public HashMap<String, String> chgStatRiyuMap = null;

	public BulkOperSheetEventArg(String loginNo, String operatorGuid) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		if (operatorGuid == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
		this.operatorGuid = operatorGuid;
	}

//	public void setAll( String sharp, String party, String operationCode, String formGrpCode, String statusCode, String searchDiv, String flowCd ) {
	public void setAll( String sharp, String party, String operationCode, String statusCode ) {
		this.sharp = sharp;
		this.party = party;
		this.operationCd = operationCode;
//		this.formGrpCd = formGrpCode;
		this.statusCd = statusCode;
//		this.searchDiv = searchDiv;
//		this.flowCd = flowCd;
	}

	public void validateArg() throws CareerException {
		if (this.sharp == null || "".equals( this.sharp.trim() )) {
			throw new CareerException( "Invalid Arg: state is null." );
		}
	}
}
