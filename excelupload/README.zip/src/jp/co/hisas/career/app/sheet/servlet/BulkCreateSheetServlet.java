package jp.co.hisas.career.app.sheet.servlet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.bean.BulkCreateSheetBean;
import jp.co.hisas.career.app.sheet.event.BulkCreateSheetEvRslt;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.app.sheet.vm.VmVSHBCR;
import jp.co.hisas.career.framework.trans.NewTokenServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.CommonLabel;

public class BulkCreateSheetServlet extends NewTokenServlet {

	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "VSHBCR";
	private static final String FORWARD_PAGE = "/view/sheet/layout_multi/MultiBulkCreateSheet.jsp";

	@Override
	public String serviceMain( Tray tray ) throws Exception {
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( tray.session, UserInfoBean.SESSION_KEY );
		tray.operatorGuid = userInfo.getOperatorGuid();

		VmVSHBCR vm = null;

		if ( SU.matches( tray.state, "INIT" )) {
			tray.session.removeAttribute( VmVSHBCR.VMID );

			vm = new VmVSHBCR( tray );

			// 前画面（未作成者一覧）からのリクエストを取得
			HashMap<String, String> jotaiMap = new HashMap<String,String>();
			putJotaiMapFromRequest( tray, jotaiMap );

			vm.jotaiMap = jotaiMap;

			tray.session.setAttribute( VmVSHBCR.VMID, vm );

			// 処理実行（INIT : データ取得、BULK_CREATE : 未作成者シート作成）
			BulkCreateSheetBean bean = new BulkCreateSheetBean( tray.loginNo, tray.operatorGuid );
			BulkCreateSheetEvRslt result = bean.execAction( tray.menu.party, tray.state, tray.request );

			vm.sheetList = result.getSheetList();
			vm.langList = result.getLangList();

		} else if ( SU.matches( tray.state, "BULK_CREATE" )) {
			vm = tray.getSessionAttr( VmVSHBCR.VMID );

			// セッションの情報 + 選択言語・リストを取得
			putCreateSheetInfo( tray, vm );

			tray.session.setAttribute( VmVSHBCR.VMID, vm );

			// 処理実行（INIT : データ取得、BULK_CREATE : 未作成者シート作成）
			BulkCreateSheetBean bean = new BulkCreateSheetBean( tray.loginNo, tray.operatorGuid );
			BulkCreateSheetEvRslt result = bean.execAction( tray.menu.party, tray.state, tray.request );

			vm.sheetList = result.getSheetList();
			vm.langList = result.getLangList();

			String msgKind;
			String resultMsg;

			if ( result.isBulkCreateResult()) {
				msgKind = AppSessionKey.RESULT_MSG_INFO;
				resultMsg = CommonLabel.getLabel( "LSHBCR_RESULT_MSG_01" );
			} else {
				msgKind = AppSessionKey.RESULT_MSG_ERROR;
				resultMsg = CommonLabel.getLabel( "LSHBCR_RESULT_MSG_02" );
			}

			tray.session.setAttribute( msgKind, resultMsg );
		}

		tray.session.setAttribute( VmVSHBCR.VMID, vm );

		tray.forwardUrl = "/view/sheet/layout_multi/MultiBulkCreateSheet.jsp";

		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, tray.state );

		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}

	private void putJotaiMapFromRequest( Tray tray, Map<String, String> jotaiMap ) {
		jotaiMap.put( "personId", AU.getRequestValue( tray.request, "personId" ));
		jotaiMap.put( "deptNm", AU.getRequestValue( tray.request, "deptNm" ));
		jotaiMap.put( "personNm", AU.getRequestValue( tray.request, "personNm" ));
		jotaiMap.put( "personNmKn", AU.getRequestValue( tray.request, "personNmKn" ));
		jotaiMap.put( "operationCd", AU.getRequestValue( tray.request, "operationCd" ));
	}

	private void putCreateSheetInfo( Tray tray, VmVSHBCR vm ) {

		// 作成対象言語を格納
		vm.jotaiMap.put( "formCd", AU.getRequestValue( tray.request, "language" ));

		// 選択された未作成者一覧
		HashMap<String, String> map = CsUtil.getRequestsWithRegex( tray.request, "^multi_" );

		// Mapで取得した値をguidだけのリストに変換して格納
		vm.tgtGuids = new ArrayList<String>( map.values());
	}
}
