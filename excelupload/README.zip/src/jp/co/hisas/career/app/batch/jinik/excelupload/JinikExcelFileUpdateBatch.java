package jp.co.hisas.career.app.batch.jinik.excelupload;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import jp.co.hisas.career.app.batch.jinik.excelupload.bean.JinikSheetBean;
import jp.co.hisas.career.app.batch.jinik.excelupload.bean.JinikUploadResultBean;
import jp.co.hisas.career.app.batch.jinik.excelupload.bean.ZzJinikUploadReserveBean;
import jp.co.hisas.career.app.batch.jinik.excelupload.util.property.JinikUploadProperty;
import jp.co.hisas.career.app.batch.util.BatchUtil;
import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dto.MailInfoDto;

public class JinikExcelFileUpdateBatch {
	
	/** SELECTするカラム。 */
	public static final String ALLCOLS = ""
						+ " RSV_SEQ AS RsvSeq,"
						+ " RSV_GUID AS RsvGuid,"
						+ " RSV_MAIL_ADDRESS AS RsvMailAddress,"
						+ " RSV_DATE AS RsvDate,"
						+ " RSV_STATUS AS RsvStatus,"
						+ " UPLOAD_FILE_NAME AS UploadFileName,"
						+ " UPLOAD_CONTENT_TYPE AS UploadContentType,"
						+ " UPLOAD_FILE AS UploadFile,"
						+ " UPDATE_START_DATE AS UpdateStartDate,"
						+ " UPDATE_FINISH_DATE AS UpdateFinishDate"
						;

	// 読み込むシート名
	private final String READ_TARGET_SHEET_NAME = "人材育成計画";
	
	// 回答データの読込み行位置
	private final int CELL_READ_START_LINE = 16;
	
	// シートの年度を取得するためのセル位置（AM13）
	private final int CELL_SHEET_NENDO_ROW = 12;
	private final int CELL_SHEET_NENDO_COLUMN = 38;
	
	private final String MSG_UPDATED_SHEET_NOT_EXIST = "更新対象のシートが存在しません。処理をスキップしました。";
	private final String MSG_UPDATED_BY_OTHERS = "他者による更新が行われていました。処理をスキップしました。";
	private final String MSG_NOT_TARGET_STATUS = "登録可能なシートのステータスではありません。処理をスキップしました。";
	
	private final String ATTACHED_FILE_TEMP_DIR = "";
	private final String UPLOAD_WARN_FILE_CSV_TITLE = "GUID,名前,所属組織,内容";
	
	public static void main( String[] args ) {
		
		final JinikExcelFileUpdateBatch instance = new JinikExcelFileUpdateBatch();
		
		instance.execute();
	}
	
	/**
	 * テストメソッド
	 */
	private void test() {
		
	}
	
	/**
	 * 人材育成計画シートのDB更新処理
	 */
	private void execute() {
		Connection conn = null;
		
		try {
			conn =  BatchUtil.getConnetcion();
			
			// 自動コミットモードを無効に
			conn.setAutoCommit( false );

			// エラージョブ更新
			updateUnderProcJobToErrJob( conn );
			
			// 処理中ジョブの取得
			if ( getUnderProcessingJobCount( conn ) == 0 ) {
				
				// 処理待ちジョブの取得
				List<ZzJinikUploadReserveBean> jobs = getQueuedJob( conn, "処理待ち" );
				if ( jobs.size() > 0 ) {
					ZzJinikUploadReserveBean bean = jobs.get( 0 );
					
					// 処理開始情報の書き込み
					updateUploadReserveStatus( bean.getRsvSeq(), "処理中", conn );
					
					// ここまででいったんトランザクションをコミット
					BatchUtil.commitConnection( conn );
					
					// Excelシート回答情報を取得する
					List<JinikSheetBean> sheetRecords = readExcelBinaryObject( bean );
					
					// 予約者IDをセット
					String RSV_ID = "EXCEL_UPLOAD_" + AU.getTimestamp( "yyyyMMddHH24mmss" );
					
					List<JinikUploadResultBean> result = new ArrayList<JinikUploadResultBean>();
					
					for ( JinikSheetBean rec : sheetRecords ) {
						// 更新対象シート情報の取得
						VCsInfoAttrDto attrDto = getVCsInfoAttr( rec, conn );
						if ( attrDto  == null ) {
							// 更新対象のシートが存在しません。処理をスキップしました。
							addLogMessage( result, rec.getOwnGuid(), rec.getOwnPersonName(), rec.getOwnDeptFullName(), MSG_UPDATED_SHEET_NOT_EXIST );
							continue;
						}
						
						rec.setSheetId( attrDto.getSheetId());
						
						// ステータスチェック
						if (( rec.getSheetStatus() == "計画入力中" || rec.getSheetStatus() == "進捗状況確認中" ) && rec.getSheetStatus() == attrDto.getStatusNm()) {
							// 排他チェック？
							CstSheetExclusiveDto execDto = new CstSheetExclusiveDto();
							execDto.setSheetId( attrDto.getSheetId());
							execDto.setExclusiveKey( attrDto.getExclusiveKey());
							
							if ( !checkSheetExclusiveKey( execDto, conn )) {
								// 他者による更新が行われていました。処理をスキップしました。
								addLogMessage( result, rec.getOwnGuid(), rec.getOwnPersonName(), rec.getOwnDeptFullName(), MSG_UPDATED_BY_OTHERS );
								continue;
							}
							
							// 排他キーの更新
							updateExclusiveKey( execDto, conn );
							
							// ステータスが"計画入力中"のシートをCS_RSV_DSTRBTに登録
							if ( SU.equals( rec.getSheetStatus(), "計画入力中" )) {
								insertSheetReserve( attrDto, RSV_ID, conn );
							}
							
							// CSTシート回答の更新
							updateSheetFill( rec, conn );
							
						} else {
							// 登録可能なシートのステータスではありません。処理をスキップしました。
							addLogMessage( result, rec.getOwnGuid(), rec.getOwnPersonName(), rec.getOwnDeptFullName(), MSG_NOT_TARGET_STATUS );
							continue;
							
						}
					}
					// シート回答情報の更新をコミットする
					BatchUtil.commitConnection( conn );
					
					// FILL_AUTOの物理テーブルへの反映
					updateCstSheetFillAuto( RSV_ID, conn );

					// シート配布予約データの削除
					deleteSheetReserve( RSV_ID, conn );
					
					// 物理テーブルへの反映処理をコミット
					BatchUtil.commitConnection( conn );
					
					// アップロード更新処理完了情報の書き込み
					updateUploadReserveStatus(bean.getRsvSeq(), "完了", conn );
					
					// メール送信関連処理
					sendBatchCompletionMail( bean, result, ( result.size() == 0 ? "SUCCESS" : "WARN" ), sheetRecords.size(), conn );
				}
			}
			BatchUtil.commitConnection( conn );
			
		} catch ( SQLException e ) {
			BatchUtil.rollbackConnection( conn );
		} catch ( Exception e ) {
			BatchUtil.rollbackConnection( conn );
		} finally {
			BatchUtil.closeconnection( conn );
		}
	}

	/**
	 * 一定時間を経過した"処理中"のジョブを、"エラー"ジョブに更新する
	 * 
	 * @param conn Database Connection
	 * @throws SQLException 
	 */
	private void updateUnderProcJobToErrJob( Connection conn ) throws SQLException {
		
		PreparedStatement stmt = null;
		
		try {
			StringBuffer sb = new StringBuffer();
			sb.append( "UPDATE ZZ_JINIK_UPLOAD_RESERVE ");
			sb.append( "SET RSV_STATUS = 'エラー' ");
			sb.append( "WHERE RSV_STATUS = '処理中' ");
			sb.append( "AND UPDATE_START_DATE +  ");
			sb.append( "( ");
			sb.append( "    SELECT TO_NUMBER(PARAM_VALUE) FROM CCP_PARAM WHERE PARAM_BUNRUI_NM = 'Plan' AND PARAM_ID = 'JINIK_ELAPSE_TIME_TO_ERROR' ");
			sb.append( ") / 1440 < SYSDATE");

			stmt = conn.prepareStatement( sb.toString());

			stmt.executeUpdate();
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, null );
		}
	}
	
	/**
	 * 現在実行中のジョブを検索し、検索結果（件数）を返す
	 * 
	 * @param conn Database Connection
	 * @return 実行中ジョブの件数
	 */
	private int getUnderProcessingJobCount( Connection conn ) throws SQLException {
		
		int cnt = 0;
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			String sql = "SELECT COUNT(*) FROM ZZ_JINIK_UPLOAD_RESERVE WHERE RSV_STATUS = '処理中'";
				
			stmt = conn.prepareStatement( sql );
				
			rs = stmt.executeQuery();
			if ( rs.next()) {
				cnt = rs.getInt( 1 );
			}
			return cnt;
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, rs );
		}
	}
	
	/**
	 * 
	 * 
	 * @return
	 */
	private List<ZzJinikUploadReserveBean> getQueuedJob( Connection conn, String status ) throws SQLException {

		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			StringBuilder sb = new StringBuilder();
			
			sb.append( "SELECT " + ALLCOLS + " FROM  ZZ_JINIK_UPLOAD_RESERVE" );
			sb.append( " WHERE RSV_STATUS = ? " );
			sb.append( " ORDER BY RSV_SEQ" );
			
			stmt = conn.prepareStatement( sb.toString());
			stmt.setString( 1, status );

			rs = stmt.executeQuery();

			List<ZzJinikUploadReserveBean> list  = new ArrayList<ZzJinikUploadReserveBean>();
			while( rs.next()) {
				list.add( new ZzJinikUploadReserveBean( rs ));
			}
			return list;
		} catch (SQLException e) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, rs );
		}
	}
	
	/**
	 * 指定された予約SEQに一致する予約情報のステータスを更新する。
	 * 　更新時にステータスに対応した日付項目も更新する。
	 * 
	 * @param rsvSeq 予約SEQ
	 * @param status 変更する予約ステータス
	 * @param conn コネクション
	 * @throws SQLException
	 */
	private void updateUploadReserveStatus( int rsvSeq, String status, Connection conn ) throws SQLException {
		
		PreparedStatement stmt = null;

		try {
			StringBuilder sb = new StringBuilder();
			
			sb.append( "UPDATE ZZ_JINIK_UPLOAD_RESERVE " );
			sb.append( "SET RSV_STATUS = ? " );

			if ( SU.equals( "完了", status )) {
				sb.append( ", UPDATE_FINISH_DATE = TO_CHAR( SYSDATE, 'yyyy/MM/DD HH24:MI:SS' ) " );
			} else if ( SU.equals( "処理中", status )) {
				sb.append( ", UPDATE_START_DATE = TO_CHAR( SYSDATE, 'yyyy/MM/DD HH24:MI:SS' ) " );
			}
			
			sb.append( "WHERE RSV_SEQ = ?" );
			
			stmt = conn.prepareStatement( sb.toString());
			stmt.setString( 1, status );
			stmt.setInt( 2, rsvSeq );

			stmt.executeUpdate();
			
		} catch ( SQLException e ) {
			throw e;
		}
	}
	
	private List<JinikSheetBean> readExcelBinaryObject(ZzJinikUploadReserveBean uploadBean) {
		
		List<JinikSheetBean> sheetBeans = null;

		try {
			Blob blob = uploadBean.getUploadFile();
			InputStream is = blob.getBinaryStream();
			
			XSSFWorkbook xssfwkbk = (XSSFWorkbook)WorkbookFactory.create(is);
			
			XSSFSheet sheet = xssfwkbk.getSheet( READ_TARGET_SHEET_NAME );
			if ( sheet != null ) {
				sheetBeans = new ArrayList<JinikSheetBean>();
				
				// セル"AM13"の年度を読み取ってシートの年度として、運用コードを生成する
				String operCd = SU.ntb( getStringRangeValue( sheet.getRow( CELL_SHEET_NENDO_ROW ).getCell( CELL_SHEET_NENDO_COLUMN )));
				if ( operCd != "" ) {
					operCd = operCd.replace( "年度", "T-jinik" );
				}
				
				for ( int i = CELL_READ_START_LINE; i <= sheet.getLastRowNum(); i++ ) {
					XSSFRow row = sheet.getRow( i );
					
					// getLaastRowNumよりも少ない場合があるので、ステータス欄が空であればループを抜ける
					if ( SU.ntb( getStringValue( row.getCell( 1 ))) == "" ) {
						break;
					}
					
					JinikSheetBean bean = new JinikSheetBean();
					
					bean.setOperationCd( operCd );
					for ( int j = 0; j < JinikUploadProperty.fillMap.length; j++ ) {
						String value = SU.ntb( getStringValue( row.getCell( Integer.valueOf( JinikUploadProperty.fillMap[j][0] ))));
						
						switch ( JinikUploadProperty.fillMap[j][1] ) {
							case "STATUS_NM" :
								bean.setSheetStatus( value );
								break;
							case "OWN_GUID" :
								bean.setOwnGuid( value );
								break;
							case "OWN_PERSON_NAME" :
								bean.setOwnPersonName( value );
								break;
							case "CMPA_CD" :
								bean.setOwnCmpaCd( value );
								break;
							case "DEPT_FULL_NAME" :
								bean.setOwnDeptFullName( value );
								break;
							default :
								bean.putFillData( JinikUploadProperty.fillMap[j][1], value );
						}
					}
					sheetBeans.add( bean );
				}
			} else {
				// 対象のシートが読み込めなかったとき
				
			}
		} catch ( SQLException e ) {
			
		} catch ( Exception e ) {
			System.out.println( e.getMessage() );
		}
		return sheetBeans;
	}

	private static String getStringValue( XSSFCell cell ) {
		if ( cell == null ) {
			return null;
		}
		switch ( cell.getCellType()) {
		case XSSFCell.CELL_TYPE_NUMERIC:
			return Integer.toString( Integer.valueOf(( int )cell.getNumericCellValue()));
		case XSSFCell.CELL_TYPE_STRING:
			return cell.getStringCellValue();
		case XSSFCell.CELL_TYPE_FORMULA:
			return null;
		case XSSFCell.CELL_TYPE_BLANK:
			return null;
		case XSSFCell.CELL_TYPE_BOOLEAN:
			return Boolean.toString( cell.getBooleanCellValue());
		case XSSFCell.CELL_TYPE_ERROR:
			return null;
		default:
			return null;
		}
	}

	private static String getStringRangeValue( XSSFCell cell ) {
		int rowIndex = cell.getRowIndex();
		int columnIndex = cell.getColumnIndex();
		
		XSSFSheet sheet = cell.getSheet();
		int size = sheet.getNumMergedRegions();
		for ( int i= 0; i < size; i++ ) {
			CellRangeAddress range = sheet.getMergedRegion( i );
			if ( range.isInRange( rowIndex, columnIndex )) {
				XSSFCell firstCell = getCell( sheet, range.getFirstRow(), range.getFirstColumn());
				return getStringValue( firstCell );
			}
		}
		return null;
	}
	
	private static XSSFCell getCell( XSSFSheet sheet, int rowIndex, int columnIndex ) {
		XSSFRow row = sheet.getRow( rowIndex );
		if ( row != null ) {
			XSSFCell cell = row.getCell( columnIndex );
			return cell;
		}
		return null;
	}
	
	private VCsInfoAttrDto getVCsInfoAttr( JinikSheetBean bean, Connection conn ) throws SQLException {
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		VCsInfoAttrDto dto = null;
		
		try {
			StringBuilder sb = new StringBuilder();
			
			sb.append( "SELECT SHEET_ID, STATUS_NM, EXCLUSIVE_KEY FROM V_CS_INFO_ATTR CS " );
			sb.append( "WHERE CS.PARTY = ? " );
			sb.append( "AND CS.OPERATION_CD = ? " );
			sb.append( "AND CS.FORM_CD = ? " );
			sb.append( "AND CS.OWN_GUID = ? " );

			stmt = conn.prepareStatement( sb.toString());
			
			stmt.setString( 1, "PANA" );
			stmt.setString( 2, bean.getOperationCd());
			stmt.setString( 3, "frm-jinik" );
			stmt.setString( 4, bean.getOwnGuid());

			rs = stmt.executeQuery();
			
			if ( rs.next()) {
				dto = new VCsInfoAttrDto();
				
				dto.setSheetId( rs.getString( "SHEET_ID" ));
				dto.setStatusNm( rs.getString( "STATUS_NM" ));
				dto.setExclusiveKey( rs.getInt( "EXCLUSIVE_KEY" ));
			}
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, rs );
		}
		return dto;
	}

	private boolean checkSheetExclusiveKey( CstSheetExclusiveDto curSheetDto, Connection conn ) throws SQLException {

		CstSheetExclusiveDto dbSheetDto = getCstSheetExclusiveKey( curSheetDto.getSheetId(), conn );
		if ( curSheetDto != null && dbSheetDto != null ) {
			String curSheetId = curSheetDto.getSheetId();
			String dbSheetId = dbSheetDto.getSheetId();
			if ( dbSheetId.equals( curSheetId )) {
				Integer curSheetExecKey = curSheetDto.getExclusiveKey();
				Integer dbSheetExecKey = dbSheetDto.getExclusiveKey();
				if ( dbSheetExecKey.equals( curSheetExecKey )) {
					return true;
				}
			}
		}
		return false;
	}

	private CstSheetExclusiveDto getCstSheetExclusiveKey( String sheetId, Connection conn ) throws SQLException {
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		CstSheetExclusiveDto dto = null;

		try {
			String sql = "SELECT SHEET_ID, EXCLUSIVE_KEY FROM CST_SHEET_EXCLUSIVE WHERE SHEET_ID = ?";
			
			stmt = conn.prepareStatement( sql );
			stmt.setString( 1, sheetId );
			
			rs = stmt.executeQuery();
			if ( rs.next()) {
				dto = new CstSheetExclusiveDto();
				
				dto.setSheetId( DaoUtil.convertNullToString( rs.getString( "SHEET_ID" )));
				dto.setExclusiveKey( rs.getInt( "EXCLUSIVE_KEY" ));
			}
			
			if ( dto == null ) {
				dto = new CstSheetExclusiveDto();
				
				dto.setSheetId( sheetId );
				dto.setExclusiveKey( 0 );
				
				insertExclusiveKey( dto, conn );
			}
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, rs );
		}
		return dto;
	}
	
	private void insertExclusiveKey( CstSheetExclusiveDto insDto, Connection conn ) throws SQLException {
		
		PreparedStatement stmt = null;

		try {
			String sql = "INSERT INTO CST_SHEET_EXCLUSIVE( SHEET_ID, EXCLUSIVE_KEY ) VALUES( ?, ? )";
			
			stmt = conn.prepareStatement( sql );
			
			stmt.setString( 1, insDto.getSheetId());
			stmt.setInt( 2, insDto.getExclusiveKey());

			stmt.executeUpdate();
			
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, null );
		}
	}

	private void updateExclusiveKey( CstSheetExclusiveDto dto, Connection conn ) throws SQLException {
		
		PreparedStatement stmt = null;
		
		try {
			String sql = "UPDATE CST_SHEET_EXCLUSIVE SET EXCLUSIVE_KEY = ? WHERE SHEET_ID = ?";
			
			stmt = conn.prepareStatement( sql );
			
			stmt.setInt( 1, dto.getExclusiveKey() + 1 );
			stmt.setString( 2, dto.getSheetId());
			
			stmt.executeUpdate();
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, null );
		}
	}

	private void insertSheetReserve( VCsInfoAttrDto dto, String rsvId, Connection conn ) throws SQLException {
		
		PreparedStatement stmt = null;

		try {
			String sql = "INSERT INTO CS_RSV_DSTRBT( RSV_ID, RSV_USER, SHEET_ID, PARTY, OPERATION_CD, FORM_CD, GUID, STATUS_CD, FLOW_PTN ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ? )";

			stmt = conn.prepareStatement( sql );
			
			stmt.setString( 1, rsvId );
			stmt.setString( 2, rsvId );
			stmt.setString( 3, dto.getSheetId());
			stmt.setString( 4, dto.getParty());
			stmt.setString( 5, dto.getOperationCd());
			stmt.setString( 6, dto.getFormCd());
			stmt.setString( 7, dto.getOwnGuid());
			stmt.setString( 8, dto.getStatusCd());
			stmt.setString( 9, dto.getFlowCd());
			
			stmt.executeUpdate();
			
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, null );
		}
	}
	
	private void deleteSheetReserve( String rsvId, Connection conn ) throws SQLException {
		
		PreparedStatement stmt = null;

		try {
			String sql = "DELETE FROM CS_RSV_DSTRBT WHERE RSV_ID = ?";
			
			stmt = conn.prepareStatement( sql );
			
			stmt.setString( 1, rsvId );
			
			stmt.executeUpdate();
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, null );
		}
	}
	
	private void updateSheetFill( JinikSheetBean bean, Connection conn ) throws SQLException {
		
		// ステータスにより処理を振り分ける
		if ( SU.equals( bean.getSheetStatus(), "計画入力中" )) {
			// 異動実績以外を更新
			for ( String key : bean.getFillDataMap().keySet()) {
				if ( !SU.equals( "jinik_kaito_ido_month", key ) && !SU.equals( "jinik_kaito_ido_place", key )) {
					String content = bean.getFillDataMap().get( key );
					
					deleteCstSheetFill( bean.getSheetId(), key, conn );
					
					insertCstSheetFill( bean.getSheetId(), key, content, conn );
				}
			}
			
		} else if ( SU.equals( bean.getSheetStatus(), "進捗状況確認中" )) {
			// 異動実績のみ更新
			String[] idoJisseki = { "jinik_kaito_ido_month", "jinik_kaito_ido_place" };
			
			for ( String item : idoJisseki ) {
				String content = bean.getFillDataMap().get( item );
				
				deleteCstSheetFill( bean.getSheetId(), item, conn );
				
				insertCstSheetFill( bean.getSheetId(), item, content, conn );
			}
		}
	}

	private void deleteCstSheetFill( String sheetId, String fillId, Connection conn ) throws SQLException {
		
		PreparedStatement stmt = null;

		try {
			String sql = "DELETE FROM CST_SHEET_FILL WHERE SHEET_ID = ? AND FILL_ID = ?";
			
			stmt = conn.prepareStatement( sql );

			stmt.setString( 1, sheetId );
			stmt.setString( 2, fillId );
			
			stmt.executeUpdate();
			
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, null );
		}
	}

	private void insertCstSheetFill( String sheetId, String fillId, String fillContent, Connection conn ) throws SQLException {
		
		PreparedStatement stmt = null;
		
		try {
			
			String sql = "INSERT INTO CST_SHEET_FILL( SHEET_ID, FILL_ID, FILL_CONTENT ) VALUES( ?, ?, ? )";
			
			stmt = conn.prepareStatement( sql );
			
			stmt.setString( 1, sheetId );
			stmt.setString( 2, fillId );
			stmt.setString( 3, fillContent );

			stmt.executeUpdate();
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, null );
		}
	}
	
	private void addLogMessage( List<JinikUploadResultBean> list, String guid, String name, String deptName, String message ) {
		
		JinikUploadResultBean bean = new JinikUploadResultBean();
		bean.setOwnGuid( guid );
		bean.setOwnPersonName( name );
		bean.setOwnFullDeptName( deptName );
		bean.setMessage( message );

		list.add( bean );
	}

	private void updateCstSheetFillAuto( String rsvId, Connection conn ) throws SQLException {
		
		PreparedStatement stmt = null;
		
		try {
			StringBuilder sb = new StringBuilder();
			
			// 
			sb.append( "DELETE FROM CST_SHEET_FILL_AUTO CSF " );
			sb.append( "WHERE EXISTS " );
			sb.append( "( " );
			sb.append( "    SELECT SHEET_ID FROM CS_RSV_DSTRBT CRD WHERE CSF.SHEET_ID = CRD.SHEET_ID AND CRD.RSV_ID = ?" );
			sb.append( ")" );
			
			stmt = conn.prepareStatement( sb.toString());
			stmt.setString( 1, rsvId );
			
			stmt.executeUpdate();

			stmt.close();
			sb.setLength( 0 );
			
			sb.append( "INSERT INTO CST_SHEET_FILL_AUTO( SHEET_ID, FILL_ID, FILL_CONTENT ) " );
			sb.append( "SELECT V.SHEET_ID, V.FILL_ID, V.FILL_CONTENT FROM V_CST_SHEET_FILL_AUTO V " );
			sb.append( "INNER JOIN " );
			sb.append( "( " );
			sb.append( "    SELECT SHEET_ID FROM CS_RSV_DSTRBT WHERE RSV_ID = ? " );
			sb.append( ") RSV ON RSV.SHEET_ID = V.SHEET_ID" );

			stmt = conn.prepareStatement( sb.toString());
			stmt.setString( 1, rsvId );
			
			stmt.executeUpdate();
		
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, null );
		}
	}

	private void sendBatchCompletionMail( ZzJinikUploadReserveBean rsvBean, List<JinikUploadResultBean> results, String mailType, int succeed, Connection conn ) throws SQLException, IOException {
		
		// メール送信情報（タイトルと本文）の取得
		String[] contents = getMailContents( mailType, conn );

		// メールの種別により本文の置き換えを行う
		HashMap<String, String> replaceMap = new HashMap<String, String>();
		if ( SU.equals( "SUCCESS", mailType )) {
			replaceMap.put( "upload_num", rsvBean.getRsvGuid());
		}
		replaceMap.put( "sender_name", rsvBean.getRsvGuid());
		replaceMap.put( "file_name", rsvBean.getUploadFileName());
		
		String mailBody = contents[1];
		
		for (Map.Entry<String, String> entry : replaceMap.entrySet()) {
			String key = entry.getKey();
			String val = entry.getValue();
			// #{key} -> val
			mailBody = mailBody.replaceAll( "\\#\\{" + key + "\\}", val );
		}
		
		// メール送信情報の登録
		MailInfoDto mailDto = new MailInfoDto();
		mailDto.setFromAddress( "" );
		mailDto.setToAddress( rsvBean.getRsvMailAddress());
		mailDto.setTitle( contents[0] );
		mailDto.setBody( mailBody );

		int sendNo = insertMailInfo( mailDto, conn );
		
		insertMailAttachment(sendNo, results, conn );
	}

	/**
	 * 
	 * 
	 * @param mailType
	 * @param conn
	 * @return
	 * @throws SQLException
	 */
	private String[] getMailContents( String mailType, Connection conn ) throws SQLException {
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		String contents[] = new String[2];
		
		try {
			StringBuilder sb = new StringBuilder();
			
			sb.append( "SELECT " );
			sb.append( "    MAIL.UP_RESULT, " );
			sb.append( "    MAX( CASE WHEN MAIL.PARAM_ID LIKE 'MailSubject_JINIK_Excel%' THEN MAIL.PARAM_VALUE ELSE NULL END ) AS MAIL_TITLE, " );
			sb.append( "    MAX( CASE WHEN MAIL.PARAM_ID LIKE 'MailBody_JINIK_Excel%' THEN MAIL.PARAM_VALUE ELSE NULL END ) AS MAIL_BODY " );
			sb.append( "FROM " );
			sb.append( "( " );
			sb.append( "    SELECT " );
			sb.append( "        CASE SUBSTR(PARAM_ID, LENGTH(PARAM_ID), 1) " ); 
			sb.append( "            WHEN 'I' THEN 'SUCCESS' " );
			sb.append( "            WHEN 'E' THEN 'ERROR' " );
			sb.append( "            WHEN 'W' THEN 'WARN' " );
			sb.append( "        END AS UP_RESULT, " );
			sb.append( "        PARAM_ID, " );
			sb.append( "        PARAM_VALUE " );
			sb.append( "    FROM CCP_PARAM WHERE PARAM_ID LIKE 'Mail%JINIK_ExcelUL%' " );
			sb.append( ") MAIL " );
			sb.append( "WHERE MAIL.UP_RESULT = ? " );
			sb.append( "GROUP BY MAIL.UP_RESULT" );
			
			stmt = conn.prepareStatement( sb.toString());
			stmt.setString( 1, mailType );
			
			rs = stmt.executeQuery();
			if ( rs.next()) {
				contents[0] = rs.getString( "MAIL_TITLE" );
				contents[1] = rs.getString( "MAIL_BODY" );
			}
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, rs );
		}
		return contents;
	}

	private int insertMailInfo( MailInfoDto mailDto, Connection conn ) throws SQLException {
		
		int sendNo = 0;

		PreparedStatement stmt = null;
		PreparedStatement stmtSelect = null;
		
		ResultSet rs = null;
		
		try {

			String sql = "SELECT NVL(MAX( SEND_NO ) + 1, 1) AS SEND_NO FROM MAIL_INFO";
			
			stmtSelect = conn.prepareStatement( sql );
			
			rs = stmtSelect.executeQuery();
			
			if ( rs.next()) {
				sendNo = rs.getInt( "SEND_NO" );
			}
			
			StringBuilder sb = new StringBuilder();

			sb.append( "INSERT INTO MAIL_INFO( SEND_NO, STATUS, FROM_ADDRESS, TO_ADDRESS, TITLE, BODY, UPDATE_FUNCTION_ID, UPDATE_DATE ) " );
			sb.append( "VALUES( " );
			sb.append( "    ?, " );
			sb.append( "    0, " );
			sb.append( "    ?, ?, ?, ?, " );
			sb.append( "    'JINIK_EXCEL_UL', " );
			sb.append( "    SYSDATE" );
			sb.append( ")" );
			
			stmt = conn.prepareStatement( sb.toString());
			stmt.setInt(1, sendNo );
			stmt.setString( 2, mailDto.getFromAddress());
			stmt.setString( 3, mailDto.getToAddress());
			stmt.setString( 4, mailDto.getTitle());
			stmt.setString( 5, mailDto.getBody());
			
			stmt.executeUpdate();
			
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmtSelect, rs );
			BatchUtil.closeConnection( null, stmt, null );
		}
		return sendNo;
	}
	
	private void insertMailAttachment( int sendNo, List<JinikUploadResultBean> results, Connection conn ) throws IOException, SQLException {
		
		if ( results.size() == 0 ) {
			return;
		}

		File tmpDir = new File( ATTACHED_FILE_TEMP_DIR );
		if ( !tmpDir.exists()) {
			tmpDir.mkdir();
		}

		PreparedStatement stmt = null;

		try {
			File attachedFile = new File( ATTACHED_FILE_TEMP_DIR + "エラーログ.csv" );
			attachedFile.createNewFile();
			
			FileWriter fw = new FileWriter( attachedFile );
			
			// CSVヘッダー
			fw.write( UPLOAD_WARN_FILE_CSV_TITLE + "\r\n" );
			
			for ( JinikUploadResultBean rec : results ) {
				fw.write( rec.getOwnGuid() + "," +  rec.getOwnPersonName()+ "," + rec.getOwnFullDeptName() + "," + rec.getMessage() + "\r\n" );
			}
			fw.close();
			
			//作成したファイルをDBに格納
			String sql = "INSERT INTO MAIL_ATTACHMENT(SEND_NO, ATTACHMENT_NO, ATTACHMENT_FILE_NAME, ATTACHEMNT_FILE ) VALUES( ?, ?, ?, ? )";
			
			StringBuilder sb = new StringBuilder();

			sb.append( "INSERT INTO MAIL_ATTACHMENT(SEND_NO, ATTACHMENT_NO, ATTACHMENT_FILE_NAME, ATTACHEMNT_FILE ) VALUES " );
			sb.append( "( " );
			sb.append( "    ?, " );
			sb.append( "    ( SELECT NVL(MAX(ATTACHMENT_NO) + 1, 1) FROM MAIL_ATTACHEMENT WHERE SEND_NO = ? ), " ); 
			sb.append( "    ?, " );
			sb.append( "    ? " );
			sb.append( ")" );
			
			stmt = conn.prepareStatement( sql );
			stmt.setInt(1, sendNo );
			stmt.setInt(2, sendNo );
			stmt.setString( 3, attachedFile.getName());
			stmt.setBinaryStream( 4, new FileInputStream( attachedFile), attachedFile.length());
			
			stmt.executeUpdate();
			
		} catch ( IOException e ) {
			throw e;
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchUtil.closeConnection( null, stmt, null );
		}
	}
}

