/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSMシートアクター Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetActorDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * フローコード
     */
    private String flowCd;
    /**
     * アクターor参照者
     */
    private String actOrRef;
    /**
     * アクターコード
     */
    private String actorCd;
    /**
     * アクター名称
     */
    private String actorNm;
    /**
     * アクターソート
     */
    private String lpadSort;

    /**
     * フローコードを取得する。
     * @return フローコード
     */
    public String getFlowCd() {
        return flowCd;
    }

    /**
     * フローコードを設定する。
     * @param flowCd フローコード
     */
    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    /**
     * アクターor参照者を取得する。
     * @return アクターor参照者
     */
    public String getActOrRef() {
        return actOrRef;
    }

    /**
     * アクターor参照者を設定する。
     * @param actOrRef アクターor参照者
     */
    public void setActOrRef(String actOrRef) {
        this.actOrRef = actOrRef;
    }

    /**
     * アクターコードを取得する。
     * @return アクターコード
     */
    public String getActorCd() {
        return actorCd;
    }

    /**
     * アクターコードを設定する。
     * @param actorCd アクターコード
     */
    public void setActorCd(String actorCd) {
        this.actorCd = actorCd;
    }

    /**
     * アクター名称を取得する。
     * @return アクター名称
     */
    public String getActorNm() {
        return actorNm;
    }

    /**
     * アクター名称を設定する。
     * @param actorNm アクター名称
     */
    public void setActorNm(String actorNm) {
        this.actorNm = actorNm;
    }

    /**
     * アクターソートを取得する。
     * @return アクターソート
     */
    public String getLpadSort() {
        return lpadSort;
    }

    /**
     * アクターソートを設定する。
     * @param lpadSort アクターソート
     */
    public void setLpadSort(String lpadSort) {
        this.lpadSort = lpadSort;
    }

}

