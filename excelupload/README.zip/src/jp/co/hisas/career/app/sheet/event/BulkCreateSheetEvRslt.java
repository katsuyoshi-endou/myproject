package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.ZzUncreatedWkDto;
import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

public class BulkCreateSheetEvRslt extends AbstractEventResult {

	private boolean bulkCreateResult = true;

	private List<ZzUncreatedWkDto> sheetList;
	private List<ValueTextSortDto> langList;

	public List<ZzUncreatedWkDto> getSheetList() {
		return sheetList;
	}

	public void setSheetList(List<ZzUncreatedWkDto> sheetList) {
		this.sheetList = sheetList;
	}

	public List<ValueTextSortDto> getLangList() {
		return langList;
	}

	public void setLangList(List<ValueTextSortDto> langList) {
		this.langList = langList;
	}

	/**
	 * シート一括作成結果を返す
	 *
	 * @return true : 正常終了、false : エラーあり
	 */
	public boolean isBulkCreateResult() {
		return bulkCreateResult;
	}

	/**
	 * シート一括作成結果をセットする
	 *
	 * @param exitCd 個別のシート作成処理結果
	 */
	public void putBulkCreateResult( int exitCd ) {

		if ( bulkCreateResult == true && exitCd == 0 ) {
			bulkCreateResult = true;
		} else {
			bulkCreateResult = false;
		}
	}
}
