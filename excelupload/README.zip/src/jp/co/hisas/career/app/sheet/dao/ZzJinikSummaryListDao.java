/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.ZzJinikSummaryListDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

/**
 * ZZ_JINIK_SUMMARY_LIST Data Access Object。
 * @author CareerDaoTool.xla
*/
public class ZzJinikSummaryListDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " LOGIN_PERSON_ID as loginPersonId,"
                     + " SHEET_ID as sheetId,"
                     + " OWN_GUID as ownGuid,"
                     + " WK_IDX as wkIdx,"
                     + " STATUS_CD as statusCd,"
                     + " STATUS_NM as statusNm,"
                     + " FILL_SET_CD as fillSetCd,"
                     + " MASK_CD as maskCd,"
                     + " OWN_PERSON_NAME as ownPersonName,"
                     + " FULL_DEPT_NM as fullDeptNm,"
                     + " HOLD_GUID as holdGuid,"
                     + " EXCLUSIVE_KEY as exclusiveKey,"
                     + " FILL_YKSK as fillYksk,"
                     + " FILL_YKBR as fillYkbr,"
                     + " FILL_KBNR as fillKbnr,"
                     + " FILL_WRAI as fillWrai,"
                     + " FILL_ROTA as fillRota,"
                     + " FILL_KAIS as fillKais,"
                     + " FILL_DKBN as fillDkbn,"
                     + " FILL_KNEN as fillKnen,"
                     + " FILL_IUMU as fillIumu,"
                     + " FILL_INEN as fillInen"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public ZzJinikSummaryListDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public ZzJinikSummaryListDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param loginPersonId LOGIN_PERSON_ID
     * @param sheetId SHEET_ID
     * @return ZzJinikSummaryListDto ZZ_JINIK_SUMMARY_LISTのレコード型データ。
     */ 
    public ZzJinikSummaryListDto select(String loginPersonId, String sheetId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM ZZ_JINIK_SUMMARY_LIST"
                         + " WHERE LOGIN_PERSON_ID = ?"
                         + " AND SHEET_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 ZzJinikSummaryListDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, loginPersonId);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, sheetId);
            rs = pstmt.executeQuery();
            ZzJinikSummaryListDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<ZzJinikSummaryListDto> ZZ_JINIK_SUMMARY_LISTのレコード型データのリスト。
     */ 
    public List<ZzJinikSummaryListDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 ZzJinikSummaryListDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<ZzJinikSummaryListDto> lst = new ArrayList<ZzJinikSummaryListDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<ZzJinikSummaryListDto> ZZ_JINIK_SUMMARY_LISTのレコード型データのリスト。
     */ 
    public List<ZzJinikSummaryListDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 ZzJinikSummaryListDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private ZzJinikSummaryListDto transferRsToDto(ResultSet rs) throws SQLException {

        ZzJinikSummaryListDto dto = new ZzJinikSummaryListDto();
        dto.setLoginPersonId(DaoUtil.convertNullToString(rs.getString("loginPersonId")));
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setOwnGuid(DaoUtil.convertNullToString(rs.getString("ownGuid")));
        dto.setWkIdx(rs.getInt("wkIdx"));
        dto.setStatusCd(DaoUtil.convertNullToString(rs.getString("statusCd")));
        dto.setStatusNm(DaoUtil.convertNullToString(rs.getString("statusNm")));
        dto.setFillSetCd(DaoUtil.convertNullToString(rs.getString("fillSetCd")));
        dto.setMaskCd(DaoUtil.convertNullToString(rs.getString("maskCd")));
        dto.setOwnPersonName(DaoUtil.convertNullToString(rs.getString("ownPersonName")));
        dto.setFullDeptNm(DaoUtil.convertNullToString(rs.getString("fullDeptNm")));
        dto.setHoldGuid(DaoUtil.convertNullToString(rs.getString("holdGuid")));
        dto.setExclusiveKey(DaoUtil.convertNullToString(rs.getString("exclusiveKey")));
        dto.setFillYksk(DaoUtil.convertNullToString(rs.getString("fillYksk")));
        dto.setFillYkbr(DaoUtil.convertNullToString(rs.getString("fillYkbr")));
        dto.setFillKbnr(DaoUtil.convertNullToString(rs.getString("fillKbnr")));
        dto.setFillWrai(DaoUtil.convertNullToString(rs.getString("fillWrai")));
        dto.setFillRota(DaoUtil.convertNullToString(rs.getString("fillRota")));
        dto.setFillKais(DaoUtil.convertNullToString(rs.getString("fillKais")));
        dto.setFillDkbn(DaoUtil.convertNullToString(rs.getString("fillDkbn")));
        dto.setFillKnen(DaoUtil.convertNullToString(rs.getString("fillKnen")));
        dto.setFillIumu(DaoUtil.convertNullToString(rs.getString("fillIumu")));
        dto.setFillInen(DaoUtil.convertNullToString(rs.getString("fillInen")));
        return dto;
    }

    /**
     * 
     * @param loginPersonId ログイン人ID
     * @return List<ZzJinikSummaryListDto> ZZ_JINIK_SUMMARY_LISTのレコード型データのリスト。
     */
    public List<ZzJinikSummaryListDto> selectByLoginPersonId(String loginPersonId) {

        final String sql = "select " + ALLCOLS + " from ZZ_JINIK_SUMMARY_LIST where LOGIN_PERSON_ID = ? order by WK_IDX";
        Log.sql("【DaoMethod Call】 ZzJinikSummaryListDao.selectByLoginPersonId");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, loginPersonId);
            rs = pstmt.executeQuery();
            List<ZzJinikSummaryListDto> lst = new ArrayList<ZzJinikSummaryListDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

