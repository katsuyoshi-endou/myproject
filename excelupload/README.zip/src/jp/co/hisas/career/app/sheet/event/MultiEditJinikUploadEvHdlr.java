package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;

import jp.co.hisas.career.app.sheet.dao.ZzJinikUploadReserveDao;
import jp.co.hisas.career.app.sheet.dto.ZzJinikUploadReserveDto;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

public class MultiEditJinikUploadEvHdlr extends AbstractEventHandler<MultiEditJinikUploadEvArg, MultiEditJinikUploadEvRslt> {

	private String daoLoginNo;

	public static MultiEditJinikUploadEvRslt exec( MultiEditJinikUploadEvArg arg ) throws CareerException {
		MultiEditJinikUploadEvHdlr handler = new MultiEditJinikUploadEvHdlr();
		return handler.call( arg );
	}

	@Override
	public MultiEditJinikUploadEvRslt call( MultiEditJinikUploadEvArg arg ) throws CareerException {
		MultiEditJinikUploadEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if ( Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}

	@Override
	protected MultiEditJinikUploadEvRslt execute( MultiEditJinikUploadEvArg arg ) throws CareerException {
		arg.validateArg();
		daoLoginNo = arg.getLoginNo();

		MultiEditJinikUploadEvRslt result = new MultiEditJinikUploadEvRslt();

		if ( SU.equals( arg.sharp, "RESERVE" )) {
			executeUploadReserve( arg );
		} else if ( SU.equals( arg.sharp, "SEARCH" )) {
//			result = searchUploadReserveInfo( arg );
		}
		return result;
	}

	private void executeUploadReserve( MultiEditJinikUploadEvArg arg ) throws CareerException {

		// 同一ユーザによる、アップロードをチェックし、条件に合致した場合、予約済みのレコードを削除する
		ZzJinikUploadReserveDao dao = new ZzJinikUploadReserveDao( this.daoLoginNo );

		StringBuilder sql = new StringBuilder();
		sql.append( "DELETE FROM ZZ_JINIK_UPLOAD_RESERVE " );
		sql.append( "WHERE RSV_GUID = ? " );
		sql.append( "AND RSV_STATUS = ? " );
		sql.append( "AND UPPER( UPLOAD_FILE_NAME ) = UPPER(?)" );

		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.rsvGuid );
		paramList.add( ZzJinikUploadReserveDto.RSV_STATUS_PENDING );
		paramList.add( arg.rsvFileName );

		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ));

		ZzJinikUploadReserveDto dto = new ZzJinikUploadReserveDto();

		dto.setRsvGuid( arg.getLoginNo());
		dto.setRsvStatus( ZzJinikUploadReserveDto.RSV_STATUS_PENDING );
		dto.setUploadFileName( arg.rsvFileName );
		dto.setUploadContentType( arg.rsvFileContentType );
		dto.setUploadFile( arg.uploadFile );

		dao.insert( dto );
	}
}
