package jp.co.hisas.career.app.sheet.event;

import java.util.HashMap;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.ejb.AbstractEventArg;

@SuppressWarnings("serial")
public class CsListEventArg extends AbstractEventArg {
	
	public String sharp = null;
	public String sheetId = null;
	public String party = null;
	public String formGrps = null;
	public String formGrpCd = null;
	public String formCode = null;
	public String personId = null;
	public String statusCd = null;
	public HashMap<String, String> srchCondMap = null;
	public String opeType  = null;
	
	public CsListEventArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		if (this.sharp == null || "".equals( this.sharp.trim() )) {
			throw new CareerException( "Invalid Arg: state is null." );
		}
	}
	
}
