/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * V_CS統合シート情報属性 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VCsInfoAttrUnifyDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * シートID
     */
    private String sheetId;
    /**
     * 会社コード
     */
    private String companyCd;
    /**
     * 運用コード
     */
    private String operationCd;
    /**
     * 運用名称
     */
    private String operationNm;
    /**
     * 運用タイプ
     */
    private String operationType;
    /**
     * 運用ソート
     */
    private String operationSort;
    /**
     * アクティブフラグ
     */
    private String activeFlg;
    /**
     * 書式グループコード
     */
    private String formGrpCd;
    /**
     * 書式グループ名称
     */
    private String formGrpNm;
    /**
     * 書式コード
     */
    private String formCd;
    /**
     * 書式名称
     */
    private String formNm;
    /**
     * 人ID
     */
    private String personId;
    /**
     * 入社年月日
     */
    private String hiredDate;
    /**
     * レイアウトコード
     */
    private String layoutCd;
    /**
     * ラベルセットコード
     */
    private String labelSetCd;
    /**
     * 回答セットコード
     */
    private String fillSetCd;
    /**
     * マスクコード
     */
    private String maskCd;
    /**
     * 複数シート作成許可
     */
    private String multiFormFlg;
    /**
     * フローコード
     */
    private String flowCd;
    /**
     * シーケンスNo
     */
    private String seqNo;
    /**
     * ステータスコード
     */
    private String statusCd;
    /**
     * ステータス名称
     */
    private String statusNm;
    /**
     * メインアクターコード
     */
    private String mainActorCd;
    /**
     * シート所持人ID
     */
    private String holdPersonId;
    /**
     * 所有者人ID
     */
    private String ownPersonId;
    /**
     * 所有者氏名
     */
    private String ownPersonName;
    /**
     * 統合AシートID
     */
    private String unifyASheetId;
    /**
     * 統合BシートID
     */
    private String unifyBSheetId;
    /**
     * 統合CシートID
     */
    private String unifyCSheetId;
    /**
     * シートソート
     */
    private String sheetSort;
    /**
     * 期間
     */
    private String term;
    /**
     * 部署コード
     */
    private String deptCd;
    /**
     * 部署名称
     */
    private String deptNm;
    /**
     * 連結部署コード
     */
    private String fullDeptCd;
    /**
     * 連結部署名称
     */
    private String fullDeptNm;
    /**
     * 階層
     */
    private Integer hierarchy;
    /**
     * 部までの部署コード
     */
    private String bumadeDeptCd;
    /**
     * 部までの部署名称
     */
    private String bumadeDeptNm;
    /**
     * 部署ソート
     */
    private String deptSort;
    /**
     * 検索区分
     */
    private String searchDiv;
    /**
     * クラスＡコード
     */
    private String clsACd;
    /**
     * クラスＡ名称
     */
    private String clsANm;
    /**
     * クラスＡソート
     */
    private String clsASort;
    /**
     * クラスＢコード
     */
    private String clsBCd;
    /**
     * クラスＢ名称
     */
    private String clsBNm;
    /**
     * クラスＢソート
     */
    private String clsBSort;
    /**
     * クラスＣコード
     */
    private String clsCCd;
    /**
     * クラスＣ名称
     */
    private String clsCNm;
    /**
     * クラスＣソート
     */
    private String clsCSort;
    /**
     * クラスＤコード
     */
    private String clsDCd;
    /**
     * クラスＤ名称
     */
    private String clsDNm;
    /**
     * クラスＤソート
     */
    private String clsDSort;
    /**
     * クラスＥコード
     */
    private String clsECd;
    /**
     * クラスＥ名称
     */
    private String clsENm;
    /**
     * クラスＥソート
     */
    private String clsESort;
    /**
     * クラスＦコード
     */
    private String clsFCd;
    /**
     * クラスＦ名称
     */
    private String clsFNm;
    /**
     * クラスＦソート
     */
    private String clsFSort;
    /**
     * クラスＧコード
     */
    private String clsGCd;
    /**
     * クラスＧ名称
     */
    private String clsGNm;
    /**
     * クラスＧソート
     */
    private String clsGSort;
    /**
     * クラスＨコード
     */
    private String clsHCd;
    /**
     * クラスＨ名称
     */
    private String clsHNm;
    /**
     * クラスＨソート
     */
    private String clsHSort;
    /**
     * クラスＩコード
     */
    private String clsICd;
    /**
     * クラスＩ名称
     */
    private String clsINm;
    /**
     * クラスＩソート
     */
    private String clsISort;
    /**
     * クラスＪコード
     */
    private String clsJCd;
    /**
     * クラスＪ名称
     */
    private String clsJNm;
    /**
     * クラスＪソート
     */
    private String clsJSort;
    /**
     * 排他キー
     */
    private Integer exclusiveKey;

    /**
     * シートIDを取得する。
     * @return シートID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * シートIDを設定する。
     * @param sheetId シートID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * 会社コードを取得する。
     * @return 会社コード
     */
    public String getCompanyCd() {
        return companyCd;
    }

    /**
     * 会社コードを設定する。
     * @param companyCd 会社コード
     */
    public void setCompanyCd(String companyCd) {
        this.companyCd = companyCd;
    }

    /**
     * 運用コードを取得する。
     * @return 運用コード
     */
    public String getOperationCd() {
        return operationCd;
    }

    /**
     * 運用コードを設定する。
     * @param operationCd 運用コード
     */
    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    /**
     * 運用名称を取得する。
     * @return 運用名称
     */
    public String getOperationNm() {
        return operationNm;
    }

    /**
     * 運用名称を設定する。
     * @param operationNm 運用名称
     */
    public void setOperationNm(String operationNm) {
        this.operationNm = operationNm;
    }

    /**
     * 運用タイプを取得する。
     * @return 運用タイプ
     */
    public String getOperationType() {
        return operationType;
    }

    /**
     * 運用タイプを設定する。
     * @param operationType 運用タイプ
     */
    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    /**
     * 運用ソートを取得する。
     * @return 運用ソート
     */
    public String getOperationSort() {
        return operationSort;
    }

    /**
     * 運用ソートを設定する。
     * @param operationSort 運用ソート
     */
    public void setOperationSort(String operationSort) {
        this.operationSort = operationSort;
    }

    /**
     * アクティブフラグを取得する。
     * @return アクティブフラグ
     */
    public String getActiveFlg() {
        return activeFlg;
    }

    /**
     * アクティブフラグを設定する。
     * @param activeFlg アクティブフラグ
     */
    public void setActiveFlg(String activeFlg) {
        this.activeFlg = activeFlg;
    }

    /**
     * 書式グループコードを取得する。
     * @return 書式グループコード
     */
    public String getFormGrpCd() {
        return formGrpCd;
    }

    /**
     * 書式グループコードを設定する。
     * @param formGrpCd 書式グループコード
     */
    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    /**
     * 書式グループ名称を取得する。
     * @return 書式グループ名称
     */
    public String getFormGrpNm() {
        return formGrpNm;
    }

    /**
     * 書式グループ名称を設定する。
     * @param formGrpNm 書式グループ名称
     */
    public void setFormGrpNm(String formGrpNm) {
        this.formGrpNm = formGrpNm;
    }

    /**
     * 書式コードを取得する。
     * @return 書式コード
     */
    public String getFormCd() {
        return formCd;
    }

    /**
     * 書式コードを設定する。
     * @param formCd 書式コード
     */
    public void setFormCd(String formCd) {
        this.formCd = formCd;
    }

    /**
     * 書式名称を取得する。
     * @return 書式名称
     */
    public String getFormNm() {
        return formNm;
    }

    /**
     * 書式名称を設定する。
     * @param formNm 書式名称
     */
    public void setFormNm(String formNm) {
        this.formNm = formNm;
    }

    /**
     * 人IDを取得する。
     * @return 人ID
     */
    public String getPersonId() {
        return personId;
    }

    /**
     * 人IDを設定する。
     * @param personId 人ID
     */
    public void setPersonId(String personId) {
        this.personId = personId;
    }

    /**
     * 入社年月日を取得する。
     * @return 入社年月日
     */
    public String getHiredDate() {
        return hiredDate;
    }

    /**
     * 入社年月日を設定する。
     * @param hiredDate 入社年月日
     */
    public void setHiredDate(String hiredDate) {
        this.hiredDate = hiredDate;
    }

    /**
     * レイアウトコードを取得する。
     * @return レイアウトコード
     */
    public String getLayoutCd() {
        return layoutCd;
    }

    /**
     * レイアウトコードを設定する。
     * @param layoutCd レイアウトコード
     */
    public void setLayoutCd(String layoutCd) {
        this.layoutCd = layoutCd;
    }

    /**
     * ラベルセットコードを取得する。
     * @return ラベルセットコード
     */
    public String getLabelSetCd() {
        return labelSetCd;
    }

    /**
     * ラベルセットコードを設定する。
     * @param labelSetCd ラベルセットコード
     */
    public void setLabelSetCd(String labelSetCd) {
        this.labelSetCd = labelSetCd;
    }

    /**
     * 回答セットコードを取得する。
     * @return 回答セットコード
     */
    public String getFillSetCd() {
        return fillSetCd;
    }

    /**
     * 回答セットコードを設定する。
     * @param fillSetCd 回答セットコード
     */
    public void setFillSetCd(String fillSetCd) {
        this.fillSetCd = fillSetCd;
    }

    /**
     * マスクコードを取得する。
     * @return マスクコード
     */
    public String getMaskCd() {
        return maskCd;
    }

    /**
     * マスクコードを設定する。
     * @param maskCd マスクコード
     */
    public void setMaskCd(String maskCd) {
        this.maskCd = maskCd;
    }

    /**
     * 複数シート作成許可を取得する。
     * @return 複数シート作成許可
     */
    public String getMultiFormFlg() {
        return multiFormFlg;
    }

    /**
     * 複数シート作成許可を設定する。
     * @param multiFormFlg 複数シート作成許可
     */
    public void setMultiFormFlg(String multiFormFlg) {
        this.multiFormFlg = multiFormFlg;
    }

    /**
     * フローコードを取得する。
     * @return フローコード
     */
    public String getFlowCd() {
        return flowCd;
    }

    /**
     * フローコードを設定する。
     * @param flowCd フローコード
     */
    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    /**
     * シーケンスNoを取得する。
     * @return シーケンスNo
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * シーケンスNoを設定する。
     * @param seqNo シーケンスNo
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * ステータスコードを取得する。
     * @return ステータスコード
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * ステータスコードを設定する。
     * @param statusCd ステータスコード
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * ステータス名称を取得する。
     * @return ステータス名称
     */
    public String getStatusNm() {
        return statusNm;
    }

    /**
     * ステータス名称を設定する。
     * @param statusNm ステータス名称
     */
    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    /**
     * メインアクターコードを取得する。
     * @return メインアクターコード
     */
    public String getMainActorCd() {
        return mainActorCd;
    }

    /**
     * メインアクターコードを設定する。
     * @param mainActorCd メインアクターコード
     */
    public void setMainActorCd(String mainActorCd) {
        this.mainActorCd = mainActorCd;
    }

    /**
     * シート所持人IDを取得する。
     * @return シート所持人ID
     */
    public String getHoldPersonId() {
        return holdPersonId;
    }

    /**
     * シート所持人IDを設定する。
     * @param holdPersonId シート所持人ID
     */
    public void setHoldPersonId(String holdPersonId) {
        this.holdPersonId = holdPersonId;
    }

    /**
     * 所有者人IDを取得する。
     * @return 所有者人ID
     */
    public String getOwnPersonId() {
        return ownPersonId;
    }

    /**
     * 所有者人IDを設定する。
     * @param ownPersonId 所有者人ID
     */
    public void setOwnPersonId(String ownPersonId) {
        this.ownPersonId = ownPersonId;
    }

    /**
     * 所有者氏名を取得する。
     * @return 所有者氏名
     */
    public String getOwnPersonName() {
        return ownPersonName;
    }

    /**
     * 所有者氏名を設定する。
     * @param ownPersonName 所有者氏名
     */
    public void setOwnPersonName(String ownPersonName) {
        this.ownPersonName = ownPersonName;
    }

    /**
     * 統合AシートIDを取得する。
     * @return 統合AシートID
     */
    public String getUnifyASheetId() {
        return unifyASheetId;
    }

    /**
     * 統合AシートIDを設定する。
     * @param unifyASheetId 統合AシートID
     */
    public void setUnifyASheetId(String unifyASheetId) {
        this.unifyASheetId = unifyASheetId;
    }

    /**
     * 統合BシートIDを取得する。
     * @return 統合BシートID
     */
    public String getUnifyBSheetId() {
        return unifyBSheetId;
    }

    /**
     * 統合BシートIDを設定する。
     * @param unifyBSheetId 統合BシートID
     */
    public void setUnifyBSheetId(String unifyBSheetId) {
        this.unifyBSheetId = unifyBSheetId;
    }

    /**
     * 統合CシートIDを取得する。
     * @return 統合CシートID
     */
    public String getUnifyCSheetId() {
        return unifyCSheetId;
    }

    /**
     * 統合CシートIDを設定する。
     * @param unifyCSheetId 統合CシートID
     */
    public void setUnifyCSheetId(String unifyCSheetId) {
        this.unifyCSheetId = unifyCSheetId;
    }

    /**
     * シートソートを取得する。
     * @return シートソート
     */
    public String getSheetSort() {
        return sheetSort;
    }

    /**
     * シートソートを設定する。
     * @param sheetSort シートソート
     */
    public void setSheetSort(String sheetSort) {
        this.sheetSort = sheetSort;
    }

    /**
     * 期間を取得する。
     * @return 期間
     */
    public String getTerm() {
        return term;
    }

    /**
     * 期間を設定する。
     * @param term 期間
     */
    public void setTerm(String term) {
        this.term = term;
    }

    /**
     * 部署コードを取得する。
     * @return 部署コード
     */
    public String getDeptCd() {
        return deptCd;
    }

    /**
     * 部署コードを設定する。
     * @param deptCd 部署コード
     */
    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    /**
     * 部署名称を取得する。
     * @return 部署名称
     */
    public String getDeptNm() {
        return deptNm;
    }

    /**
     * 部署名称を設定する。
     * @param deptNm 部署名称
     */
    public void setDeptNm(String deptNm) {
        this.deptNm = deptNm;
    }

    /**
     * 連結部署コードを取得する。
     * @return 連結部署コード
     */
    public String getFullDeptCd() {
        return fullDeptCd;
    }

    /**
     * 連結部署コードを設定する。
     * @param fullDeptCd 連結部署コード
     */
    public void setFullDeptCd(String fullDeptCd) {
        this.fullDeptCd = fullDeptCd;
    }

    /**
     * 連結部署名称を取得する。
     * @return 連結部署名称
     */
    public String getFullDeptNm() {
        return fullDeptNm;
    }

    /**
     * 連結部署名称を設定する。
     * @param fullDeptNm 連結部署名称
     */
    public void setFullDeptNm(String fullDeptNm) {
        this.fullDeptNm = fullDeptNm;
    }

    /**
     * 階層を取得する。
     * @return 階層
     */
    public Integer getHierarchy() {
        return hierarchy;
    }

    /**
     * 階層を設定する。
     * @param hierarchy 階層
     */
    public void setHierarchy(Integer hierarchy) {
        this.hierarchy = hierarchy;
    }

    /**
     * 部までの部署コードを取得する。
     * @return 部までの部署コード
     */
    public String getBumadeDeptCd() {
        return bumadeDeptCd;
    }

    /**
     * 部までの部署コードを設定する。
     * @param bumadeDeptCd 部までの部署コード
     */
    public void setBumadeDeptCd(String bumadeDeptCd) {
        this.bumadeDeptCd = bumadeDeptCd;
    }

    /**
     * 部までの部署名称を取得する。
     * @return 部までの部署名称
     */
    public String getBumadeDeptNm() {
        return bumadeDeptNm;
    }

    /**
     * 部までの部署名称を設定する。
     * @param bumadeDeptNm 部までの部署名称
     */
    public void setBumadeDeptNm(String bumadeDeptNm) {
        this.bumadeDeptNm = bumadeDeptNm;
    }

    /**
     * 部署ソートを取得する。
     * @return 部署ソート
     */
    public String getDeptSort() {
        return deptSort;
    }

    /**
     * 部署ソートを設定する。
     * @param deptSort 部署ソート
     */
    public void setDeptSort(String deptSort) {
        this.deptSort = deptSort;
    }

    /**
     * 検索区分を取得する。
     * @return 検索区分
     */
    public String getSearchDiv() {
        return searchDiv;
    }

    /**
     * 検索区分を設定する。
     * @param searchDiv 検索区分
     */
    public void setSearchDiv(String searchDiv) {
        this.searchDiv = searchDiv;
    }

    /**
     * クラスＡコードを取得する。
     * @return クラスＡコード
     */
    public String getClsACd() {
        return clsACd;
    }

    /**
     * クラスＡコードを設定する。
     * @param clsACd クラスＡコード
     */
    public void setClsACd(String clsACd) {
        this.clsACd = clsACd;
    }

    /**
     * クラスＡ名称を取得する。
     * @return クラスＡ名称
     */
    public String getClsANm() {
        return clsANm;
    }

    /**
     * クラスＡ名称を設定する。
     * @param clsANm クラスＡ名称
     */
    public void setClsANm(String clsANm) {
        this.clsANm = clsANm;
    }

    /**
     * クラスＡソートを取得する。
     * @return クラスＡソート
     */
    public String getClsASort() {
        return clsASort;
    }

    /**
     * クラスＡソートを設定する。
     * @param clsASort クラスＡソート
     */
    public void setClsASort(String clsASort) {
        this.clsASort = clsASort;
    }

    /**
     * クラスＢコードを取得する。
     * @return クラスＢコード
     */
    public String getClsBCd() {
        return clsBCd;
    }

    /**
     * クラスＢコードを設定する。
     * @param clsBCd クラスＢコード
     */
    public void setClsBCd(String clsBCd) {
        this.clsBCd = clsBCd;
    }

    /**
     * クラスＢ名称を取得する。
     * @return クラスＢ名称
     */
    public String getClsBNm() {
        return clsBNm;
    }

    /**
     * クラスＢ名称を設定する。
     * @param clsBNm クラスＢ名称
     */
    public void setClsBNm(String clsBNm) {
        this.clsBNm = clsBNm;
    }

    /**
     * クラスＢソートを取得する。
     * @return クラスＢソート
     */
    public String getClsBSort() {
        return clsBSort;
    }

    /**
     * クラスＢソートを設定する。
     * @param clsBSort クラスＢソート
     */
    public void setClsBSort(String clsBSort) {
        this.clsBSort = clsBSort;
    }

    /**
     * クラスＣコードを取得する。
     * @return クラスＣコード
     */
    public String getClsCCd() {
        return clsCCd;
    }

    /**
     * クラスＣコードを設定する。
     * @param clsCCd クラスＣコード
     */
    public void setClsCCd(String clsCCd) {
        this.clsCCd = clsCCd;
    }

    /**
     * クラスＣ名称を取得する。
     * @return クラスＣ名称
     */
    public String getClsCNm() {
        return clsCNm;
    }

    /**
     * クラスＣ名称を設定する。
     * @param clsCNm クラスＣ名称
     */
    public void setClsCNm(String clsCNm) {
        this.clsCNm = clsCNm;
    }

    /**
     * クラスＣソートを取得する。
     * @return クラスＣソート
     */
    public String getClsCSort() {
        return clsCSort;
    }

    /**
     * クラスＣソートを設定する。
     * @param clsCSort クラスＣソート
     */
    public void setClsCSort(String clsCSort) {
        this.clsCSort = clsCSort;
    }

    /**
     * クラスＤコードを取得する。
     * @return クラスＤコード
     */
    public String getClsDCd() {
        return clsDCd;
    }

    /**
     * クラスＤコードを設定する。
     * @param clsDCd クラスＤコード
     */
    public void setClsDCd(String clsDCd) {
        this.clsDCd = clsDCd;
    }

    /**
     * クラスＤ名称を取得する。
     * @return クラスＤ名称
     */
    public String getClsDNm() {
        return clsDNm;
    }

    /**
     * クラスＤ名称を設定する。
     * @param clsDNm クラスＤ名称
     */
    public void setClsDNm(String clsDNm) {
        this.clsDNm = clsDNm;
    }

    /**
     * クラスＤソートを取得する。
     * @return クラスＤソート
     */
    public String getClsDSort() {
        return clsDSort;
    }

    /**
     * クラスＤソートを設定する。
     * @param clsDSort クラスＤソート
     */
    public void setClsDSort(String clsDSort) {
        this.clsDSort = clsDSort;
    }

    /**
     * クラスＥコードを取得する。
     * @return クラスＥコード
     */
    public String getClsECd() {
        return clsECd;
    }

    /**
     * クラスＥコードを設定する。
     * @param clsECd クラスＥコード
     */
    public void setClsECd(String clsECd) {
        this.clsECd = clsECd;
    }

    /**
     * クラスＥ名称を取得する。
     * @return クラスＥ名称
     */
    public String getClsENm() {
        return clsENm;
    }

    /**
     * クラスＥ名称を設定する。
     * @param clsENm クラスＥ名称
     */
    public void setClsENm(String clsENm) {
        this.clsENm = clsENm;
    }

    /**
     * クラスＥソートを取得する。
     * @return クラスＥソート
     */
    public String getClsESort() {
        return clsESort;
    }

    /**
     * クラスＥソートを設定する。
     * @param clsESort クラスＥソート
     */
    public void setClsESort(String clsESort) {
        this.clsESort = clsESort;
    }

    /**
     * クラスＦコードを取得する。
     * @return クラスＦコード
     */
    public String getClsFCd() {
        return clsFCd;
    }

    /**
     * クラスＦコードを設定する。
     * @param clsFCd クラスＦコード
     */
    public void setClsFCd(String clsFCd) {
        this.clsFCd = clsFCd;
    }

    /**
     * クラスＦ名称を取得する。
     * @return クラスＦ名称
     */
    public String getClsFNm() {
        return clsFNm;
    }

    /**
     * クラスＦ名称を設定する。
     * @param clsFNm クラスＦ名称
     */
    public void setClsFNm(String clsFNm) {
        this.clsFNm = clsFNm;
    }

    /**
     * クラスＦソートを取得する。
     * @return クラスＦソート
     */
    public String getClsFSort() {
        return clsFSort;
    }

    /**
     * クラスＦソートを設定する。
     * @param clsFSort クラスＦソート
     */
    public void setClsFSort(String clsFSort) {
        this.clsFSort = clsFSort;
    }

    /**
     * クラスＧコードを取得する。
     * @return クラスＧコード
     */
    public String getClsGCd() {
        return clsGCd;
    }

    /**
     * クラスＧコードを設定する。
     * @param clsGCd クラスＧコード
     */
    public void setClsGCd(String clsGCd) {
        this.clsGCd = clsGCd;
    }

    /**
     * クラスＧ名称を取得する。
     * @return クラスＧ名称
     */
    public String getClsGNm() {
        return clsGNm;
    }

    /**
     * クラスＧ名称を設定する。
     * @param clsGNm クラスＧ名称
     */
    public void setClsGNm(String clsGNm) {
        this.clsGNm = clsGNm;
    }

    /**
     * クラスＧソートを取得する。
     * @return クラスＧソート
     */
    public String getClsGSort() {
        return clsGSort;
    }

    /**
     * クラスＧソートを設定する。
     * @param clsGSort クラスＧソート
     */
    public void setClsGSort(String clsGSort) {
        this.clsGSort = clsGSort;
    }

    /**
     * クラスＨコードを取得する。
     * @return クラスＨコード
     */
    public String getClsHCd() {
        return clsHCd;
    }

    /**
     * クラスＨコードを設定する。
     * @param clsHCd クラスＨコード
     */
    public void setClsHCd(String clsHCd) {
        this.clsHCd = clsHCd;
    }

    /**
     * クラスＨ名称を取得する。
     * @return クラスＨ名称
     */
    public String getClsHNm() {
        return clsHNm;
    }

    /**
     * クラスＨ名称を設定する。
     * @param clsHNm クラスＨ名称
     */
    public void setClsHNm(String clsHNm) {
        this.clsHNm = clsHNm;
    }

    /**
     * クラスＨソートを取得する。
     * @return クラスＨソート
     */
    public String getClsHSort() {
        return clsHSort;
    }

    /**
     * クラスＨソートを設定する。
     * @param clsHSort クラスＨソート
     */
    public void setClsHSort(String clsHSort) {
        this.clsHSort = clsHSort;
    }

    /**
     * クラスＩコードを取得する。
     * @return クラスＩコード
     */
    public String getClsICd() {
        return clsICd;
    }

    /**
     * クラスＩコードを設定する。
     * @param clsICd クラスＩコード
     */
    public void setClsICd(String clsICd) {
        this.clsICd = clsICd;
    }

    /**
     * クラスＩ名称を取得する。
     * @return クラスＩ名称
     */
    public String getClsINm() {
        return clsINm;
    }

    /**
     * クラスＩ名称を設定する。
     * @param clsINm クラスＩ名称
     */
    public void setClsINm(String clsINm) {
        this.clsINm = clsINm;
    }

    /**
     * クラスＩソートを取得する。
     * @return クラスＩソート
     */
    public String getClsISort() {
        return clsISort;
    }

    /**
     * クラスＩソートを設定する。
     * @param clsISort クラスＩソート
     */
    public void setClsISort(String clsISort) {
        this.clsISort = clsISort;
    }

    /**
     * クラスＪコードを取得する。
     * @return クラスＪコード
     */
    public String getClsJCd() {
        return clsJCd;
    }

    /**
     * クラスＪコードを設定する。
     * @param clsJCd クラスＪコード
     */
    public void setClsJCd(String clsJCd) {
        this.clsJCd = clsJCd;
    }

    /**
     * クラスＪ名称を取得する。
     * @return クラスＪ名称
     */
    public String getClsJNm() {
        return clsJNm;
    }

    /**
     * クラスＪ名称を設定する。
     * @param clsJNm クラスＪ名称
     */
    public void setClsJNm(String clsJNm) {
        this.clsJNm = clsJNm;
    }

    /**
     * クラスＪソートを取得する。
     * @return クラスＪソート
     */
    public String getClsJSort() {
        return clsJSort;
    }

    /**
     * クラスＪソートを設定する。
     * @param clsJSort クラスＪソート
     */
    public void setClsJSort(String clsJSort) {
        this.clsJSort = clsJSort;
    }

    /**
     * 排他キーを取得する。
     * @return 排他キー
     */
    public Integer getExclusiveKey() {
        return exclusiveKey;
    }

    /**
     * 排他キーを設定する。
     * @param exclusiveKey 排他キー
     */
    public void setExclusiveKey(Integer exclusiveKey) {
        this.exclusiveKey = exclusiveKey;
    }

}

