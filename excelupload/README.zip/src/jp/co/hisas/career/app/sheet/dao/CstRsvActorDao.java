/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CstRsvActorDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CST_RSV_ACTOR Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CstRsvActorDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " SHEET_ID as sheetId,"
                     + " A01_ACTOR_CD as a01ActorCd,"
                     + " A01_PERSON_ID as a01PersonId,"
                     + " A02_ACTOR_CD as a02ActorCd,"
                     + " A02_PERSON_ID as a02PersonId,"
                     + " A03_ACTOR_CD as a03ActorCd,"
                     + " A03_PERSON_ID as a03PersonId,"
                     + " A04_ACTOR_CD as a04ActorCd,"
                     + " A04_PERSON_ID as a04PersonId,"
                     + " A05_ACTOR_CD as a05ActorCd,"
                     + " A05_PERSON_ID as a05PersonId,"
                     + " A06_ACTOR_CD as a06ActorCd,"
                     + " A06_PERSON_ID as a06PersonId,"
                     + " A07_ACTOR_CD as a07ActorCd,"
                     + " A07_PERSON_ID as a07PersonId,"
                     + " A08_ACTOR_CD as a08ActorCd,"
                     + " A08_PERSON_ID as a08PersonId,"
                     + " A09_ACTOR_CD as a09ActorCd,"
                     + " A09_PERSON_ID as a09PersonId,"
                     + " A10_ACTOR_CD as a10ActorCd,"
                     + " A10_PERSON_ID as a10PersonId,"
                     + " A11_ACTOR_CD as a11ActorCd,"
                     + " A11_PERSON_ID as a11PersonId,"
                     + " A12_ACTOR_CD as a12ActorCd,"
                     + " A12_PERSON_ID as a12PersonId,"
                     + " A13_ACTOR_CD as a13ActorCd,"
                     + " A13_PERSON_ID as a13PersonId,"
                     + " A14_ACTOR_CD as a14ActorCd,"
                     + " A14_PERSON_ID as a14PersonId,"
                     + " A15_ACTOR_CD as a15ActorCd,"
                     + " A15_PERSON_ID as a15PersonId,"
                     + " R01_PERSON_ID as r01PersonId,"
                     + " R02_PERSON_ID as r02PersonId,"
                     + " R03_PERSON_ID as r03PersonId,"
                     + " R04_PERSON_ID as r04PersonId,"
                     + " R05_PERSON_ID as r05PersonId,"
                     + " R06_PERSON_ID as r06PersonId,"
                     + " R07_PERSON_ID as r07PersonId,"
                     + " R08_PERSON_ID as r08PersonId,"
                     + " R09_PERSON_ID as r09PersonId,"
                     + " R10_PERSON_ID as r10PersonId,"
                     + " R11_PERSON_ID as r11PersonId,"
                     + " R12_PERSON_ID as r12PersonId,"
                     + " R13_PERSON_ID as r13PersonId,"
                     + " R14_PERSON_ID as r14PersonId,"
                     + " R15_PERSON_ID as r15PersonId"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CstRsvActorDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CstRsvActorDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * Insert文を実行する。
     * @param dto CST_RSV_ACTORのデータ。
     */ 
    public void insert(CstRsvActorDto dto) {

        final String sql = "INSERT INTO CST_RSV_ACTOR ("
                         + "SHEET_ID,"
                         + "A01_ACTOR_CD,"
                         + "A01_PERSON_ID,"
                         + "A02_ACTOR_CD,"
                         + "A02_PERSON_ID,"
                         + "A03_ACTOR_CD,"
                         + "A03_PERSON_ID,"
                         + "A04_ACTOR_CD,"
                         + "A04_PERSON_ID,"
                         + "A05_ACTOR_CD,"
                         + "A05_PERSON_ID,"
                         + "A06_ACTOR_CD,"
                         + "A06_PERSON_ID,"
                         + "A07_ACTOR_CD,"
                         + "A07_PERSON_ID,"
                         + "A08_ACTOR_CD,"
                         + "A08_PERSON_ID,"
                         + "A09_ACTOR_CD,"
                         + "A09_PERSON_ID,"
                         + "A10_ACTOR_CD,"
                         + "A10_PERSON_ID,"
                         + "A11_ACTOR_CD,"
                         + "A11_PERSON_ID,"
                         + "A12_ACTOR_CD,"
                         + "A12_PERSON_ID,"
                         + "A13_ACTOR_CD,"
                         + "A13_PERSON_ID,"
                         + "A14_ACTOR_CD,"
                         + "A14_PERSON_ID,"
                         + "A15_ACTOR_CD,"
                         + "A15_PERSON_ID,"
                         + "R01_PERSON_ID,"
                         + "R02_PERSON_ID,"
                         + "R03_PERSON_ID,"
                         + "R04_PERSON_ID,"
                         + "R05_PERSON_ID,"
                         + "R06_PERSON_ID,"
                         + "R07_PERSON_ID,"
                         + "R08_PERSON_ID,"
                         + "R09_PERSON_ID,"
                         + "R10_PERSON_ID,"
                         + "R11_PERSON_ID,"
                         + "R12_PERSON_ID,"
                         + "R13_PERSON_ID,"
                         + "R14_PERSON_ID,"
                         + "R15_PERSON_ID"
                         + ")VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? )"
                         ;
        Log.sql("【DaoMethod Call】 CstRsvActorDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getSheetId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getA01ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getA01PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getA02ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getA02PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getA03ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getA03PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 8, dto.getA04ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 9, dto.getA04PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 10, dto.getA05ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 11, dto.getA05PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 12, dto.getA06ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 13, dto.getA06PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 14, dto.getA07ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 15, dto.getA07PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 16, dto.getA08ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 17, dto.getA08PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 18, dto.getA09ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 19, dto.getA09PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 20, dto.getA10ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 21, dto.getA10PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 22, dto.getA11ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 23, dto.getA11PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 24, dto.getA12ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 25, dto.getA12PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 26, dto.getA13ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 27, dto.getA13PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 28, dto.getA14ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 29, dto.getA14PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 30, dto.getA15ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 31, dto.getA15PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 32, dto.getR01PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 33, dto.getR02PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 34, dto.getR03PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 35, dto.getR04PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 36, dto.getR05PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 37, dto.getR06PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 38, dto.getR07PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 39, dto.getR08PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 40, dto.getR09PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 41, dto.getR10PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 42, dto.getR11PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 43, dto.getR12PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 44, dto.getR13PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 45, dto.getR14PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 46, dto.getR15PersonId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * 全列update文を実行する。
     * @param dto CST_RSV_ACTORのレコード型データ。
     */
    public void update(CstRsvActorDto dto) {

        final String sql = "UPDATE CST_RSV_ACTOR SET "
                         + "A01_ACTOR_CD = ?,"
                         + "A01_PERSON_ID = ?,"
                         + "A02_ACTOR_CD = ?,"
                         + "A02_PERSON_ID = ?,"
                         + "A03_ACTOR_CD = ?,"
                         + "A03_PERSON_ID = ?,"
                         + "A04_ACTOR_CD = ?,"
                         + "A04_PERSON_ID = ?,"
                         + "A05_ACTOR_CD = ?,"
                         + "A05_PERSON_ID = ?,"
                         + "A06_ACTOR_CD = ?,"
                         + "A06_PERSON_ID = ?,"
                         + "A07_ACTOR_CD = ?,"
                         + "A07_PERSON_ID = ?,"
                         + "A08_ACTOR_CD = ?,"
                         + "A08_PERSON_ID = ?,"
                         + "A09_ACTOR_CD = ?,"
                         + "A09_PERSON_ID = ?,"
                         + "A10_ACTOR_CD = ?,"
                         + "A10_PERSON_ID = ?,"
                         + "A11_ACTOR_CD = ?,"
                         + "A11_PERSON_ID = ?,"
                         + "A12_ACTOR_CD = ?,"
                         + "A12_PERSON_ID = ?,"
                         + "A13_ACTOR_CD = ?,"
                         + "A13_PERSON_ID = ?,"
                         + "A14_ACTOR_CD = ?,"
                         + "A14_PERSON_ID = ?,"
                         + "A15_ACTOR_CD = ?,"
                         + "A15_PERSON_ID = ?,"
                         + "R01_PERSON_ID = ?,"
                         + "R02_PERSON_ID = ?,"
                         + "R03_PERSON_ID = ?,"
                         + "R04_PERSON_ID = ?,"
                         + "R05_PERSON_ID = ?,"
                         + "R06_PERSON_ID = ?,"
                         + "R07_PERSON_ID = ?,"
                         + "R08_PERSON_ID = ?,"
                         + "R09_PERSON_ID = ?,"
                         + "R10_PERSON_ID = ?,"
                         + "R11_PERSON_ID = ?,"
                         + "R12_PERSON_ID = ?,"
                         + "R13_PERSON_ID = ?,"
                         + "R14_PERSON_ID = ?,"
                         + "R15_PERSON_ID = ?"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstRsvActorDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getA01ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getA01PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getA02ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getA02PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getA03ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getA03PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getA04ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 8, dto.getA04PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 9, dto.getA05ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 10, dto.getA05PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 11, dto.getA06ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 12, dto.getA06PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 13, dto.getA07ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 14, dto.getA07PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 15, dto.getA08ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 16, dto.getA08PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 17, dto.getA09ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 18, dto.getA09PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 19, dto.getA10ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 20, dto.getA10PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 21, dto.getA11ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 22, dto.getA11PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 23, dto.getA12ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 24, dto.getA12PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 25, dto.getA13ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 26, dto.getA13PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 27, dto.getA14ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 28, dto.getA14PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 29, dto.getA15ActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 30, dto.getA15PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 31, dto.getR01PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 32, dto.getR02PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 33, dto.getR03PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 34, dto.getR04PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 35, dto.getR05PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 36, dto.getR06PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 37, dto.getR07PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 38, dto.getR08PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 39, dto.getR09PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 40, dto.getR10PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 41, dto.getR11PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 42, dto.getR12PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 43, dto.getR13PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 44, dto.getR14PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 45, dto.getR15PersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 46, dto.getSheetId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してdelete文を実行する。
     * @param sheetId SHEET_ID
     */ 
    public void delete(String sheetId) {

        final String sql = "DELETE FROM CST_RSV_ACTOR"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstRsvActorDao.delete");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally { 
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param sheetId SHEET_ID
     * @return CstRsvActorDto CST_RSV_ACTORのレコード型データ。
     */ 
    public CstRsvActorDto select(String sheetId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CST_RSV_ACTOR"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstRsvActorDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            rs = pstmt.executeQuery();
            CstRsvActorDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<CstRsvActorDto> CST_RSV_ACTORのレコード型データのリスト。
     */ 
    public List<CstRsvActorDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CstRsvActorDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CstRsvActorDto> lst = new ArrayList<CstRsvActorDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CstRsvActorDto> CST_RSV_ACTORのレコード型データのリスト。
     */ 
    public List<CstRsvActorDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CstRsvActorDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param pstmt PreparedStatement
     */ 
    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("【DaoMethod Call】 CstRsvActorDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param sql SQL文
     */ 
    public void executeDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CstRsvActorDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CstRsvActorDto transferRsToDto(ResultSet rs) throws SQLException {

        CstRsvActorDto dto = new CstRsvActorDto();
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setA01ActorCd(DaoUtil.convertNullToString(rs.getString("a01ActorCd")));
        dto.setA01PersonId(DaoUtil.convertNullToString(rs.getString("a01PersonId")));
        dto.setA02ActorCd(DaoUtil.convertNullToString(rs.getString("a02ActorCd")));
        dto.setA02PersonId(DaoUtil.convertNullToString(rs.getString("a02PersonId")));
        dto.setA03ActorCd(DaoUtil.convertNullToString(rs.getString("a03ActorCd")));
        dto.setA03PersonId(DaoUtil.convertNullToString(rs.getString("a03PersonId")));
        dto.setA04ActorCd(DaoUtil.convertNullToString(rs.getString("a04ActorCd")));
        dto.setA04PersonId(DaoUtil.convertNullToString(rs.getString("a04PersonId")));
        dto.setA05ActorCd(DaoUtil.convertNullToString(rs.getString("a05ActorCd")));
        dto.setA05PersonId(DaoUtil.convertNullToString(rs.getString("a05PersonId")));
        dto.setA06ActorCd(DaoUtil.convertNullToString(rs.getString("a06ActorCd")));
        dto.setA06PersonId(DaoUtil.convertNullToString(rs.getString("a06PersonId")));
        dto.setA07ActorCd(DaoUtil.convertNullToString(rs.getString("a07ActorCd")));
        dto.setA07PersonId(DaoUtil.convertNullToString(rs.getString("a07PersonId")));
        dto.setA08ActorCd(DaoUtil.convertNullToString(rs.getString("a08ActorCd")));
        dto.setA08PersonId(DaoUtil.convertNullToString(rs.getString("a08PersonId")));
        dto.setA09ActorCd(DaoUtil.convertNullToString(rs.getString("a09ActorCd")));
        dto.setA09PersonId(DaoUtil.convertNullToString(rs.getString("a09PersonId")));
        dto.setA10ActorCd(DaoUtil.convertNullToString(rs.getString("a10ActorCd")));
        dto.setA10PersonId(DaoUtil.convertNullToString(rs.getString("a10PersonId")));
        dto.setA11ActorCd(DaoUtil.convertNullToString(rs.getString("a11ActorCd")));
        dto.setA11PersonId(DaoUtil.convertNullToString(rs.getString("a11PersonId")));
        dto.setA12ActorCd(DaoUtil.convertNullToString(rs.getString("a12ActorCd")));
        dto.setA12PersonId(DaoUtil.convertNullToString(rs.getString("a12PersonId")));
        dto.setA13ActorCd(DaoUtil.convertNullToString(rs.getString("a13ActorCd")));
        dto.setA13PersonId(DaoUtil.convertNullToString(rs.getString("a13PersonId")));
        dto.setA14ActorCd(DaoUtil.convertNullToString(rs.getString("a14ActorCd")));
        dto.setA14PersonId(DaoUtil.convertNullToString(rs.getString("a14PersonId")));
        dto.setA15ActorCd(DaoUtil.convertNullToString(rs.getString("a15ActorCd")));
        dto.setA15PersonId(DaoUtil.convertNullToString(rs.getString("a15PersonId")));
        dto.setR01PersonId(DaoUtil.convertNullToString(rs.getString("r01PersonId")));
        dto.setR02PersonId(DaoUtil.convertNullToString(rs.getString("r02PersonId")));
        dto.setR03PersonId(DaoUtil.convertNullToString(rs.getString("r03PersonId")));
        dto.setR04PersonId(DaoUtil.convertNullToString(rs.getString("r04PersonId")));
        dto.setR05PersonId(DaoUtil.convertNullToString(rs.getString("r05PersonId")));
        dto.setR06PersonId(DaoUtil.convertNullToString(rs.getString("r06PersonId")));
        dto.setR07PersonId(DaoUtil.convertNullToString(rs.getString("r07PersonId")));
        dto.setR08PersonId(DaoUtil.convertNullToString(rs.getString("r08PersonId")));
        dto.setR09PersonId(DaoUtil.convertNullToString(rs.getString("r09PersonId")));
        dto.setR10PersonId(DaoUtil.convertNullToString(rs.getString("r10PersonId")));
        dto.setR11PersonId(DaoUtil.convertNullToString(rs.getString("r11PersonId")));
        dto.setR12PersonId(DaoUtil.convertNullToString(rs.getString("r12PersonId")));
        dto.setR13PersonId(DaoUtil.convertNullToString(rs.getString("r13PersonId")));
        dto.setR14PersonId(DaoUtil.convertNullToString(rs.getString("r14PersonId")));
        dto.setR15PersonId(DaoUtil.convertNullToString(rs.getString("r15PersonId")));
        return dto;
    }

}

