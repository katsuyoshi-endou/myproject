/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSMシートフロー Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetFlowDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * フローコード
     */
    private String flowCd;
    /**
     * シーケンスNo
     */
    private String seqNo;
    /**
     * ステータスコード
     */
    private String statusCd;
    /**
     * ステータス名称
     */
    private String statusNm;
    /**
     * ステータスグループコード
     */
    private String statusGrpCd;
    /**
     * メインアクターコード
     */
    private String mainActorCd;

    /**
     * フローコードを取得する。
     * @return フローコード
     */
    public String getFlowCd() {
        return flowCd;
    }

    /**
     * フローコードを設定する。
     * @param flowCd フローコード
     */
    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    /**
     * シーケンスNoを取得する。
     * @return シーケンスNo
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * シーケンスNoを設定する。
     * @param seqNo シーケンスNo
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * ステータスコードを取得する。
     * @return ステータスコード
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * ステータスコードを設定する。
     * @param statusCd ステータスコード
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * ステータス名称を取得する。
     * @return ステータス名称
     */
    public String getStatusNm() {
        return statusNm;
    }

    /**
     * ステータス名称を設定する。
     * @param statusNm ステータス名称
     */
    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    /**
     * ステータスグループコードを取得する。
     * @return ステータスグループコード
     */
    public String getStatusGrpCd() {
        return statusGrpCd;
    }

    /**
     * ステータスグループコードを設定する。
     * @param statusGrpCd ステータスグループコード
     */
    public void setStatusGrpCd(String statusGrpCd) {
        this.statusGrpCd = statusGrpCd;
    }

    /**
     * メインアクターコードを取得する。
     * @return メインアクターコード
     */
    public String getMainActorCd() {
        return mainActorCd;
    }

    /**
     * メインアクターコードを設定する。
     * @param mainActorCd メインアクターコード
     */
    public void setMainActorCd(String mainActorCd) {
        this.mainActorCd = mainActorCd;
    }

}

