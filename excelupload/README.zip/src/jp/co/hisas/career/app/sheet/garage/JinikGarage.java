package jp.co.hisas.career.app.sheet.garage;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dao.CsmSheetActionDao;
import jp.co.hisas.career.app.sheet.dao.CsmSheetFillMaskDao;
import jp.co.hisas.career.app.sheet.dao.ZzJinikSummaryListDao;
import jp.co.hisas.career.app.sheet.dao.ZzJinikWkRsltDao;
import jp.co.hisas.career.app.sheet.dao.ZzxJinikRojCntDao;
import jp.co.hisas.career.app.sheet.dao.extra.GeneralMapDao;
import jp.co.hisas.career.app.sheet.dto.CsmSheetActionDto;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFillMaskDto;
import jp.co.hisas.career.app.sheet.dto.ZzJinikSummaryListDto;
import jp.co.hisas.career.app.sheet.dto.ZzxJinikRojCntDto;
import jp.co.hisas.career.app.sheet.event.MultiEditJinikEvArg;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.PulldownMasterDao;
import jp.co.hisas.career.util.dao.useful.OneColumnDao;
import jp.co.hisas.career.util.dao.useful.ValueTextSortDao;
import jp.co.hisas.career.util.dto.PulldownMasterDto;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

public class JinikGarage extends Garage {
	
	public JinikGarage(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public void loadJinikAllRslt( String loginGuid ) {
		
		StringBuilder delsql = new StringBuilder();
		delsql.append( " delete from ZZ_JINIK_WK_RSLT where LOGIN_PERSON_ID = ? " );
		
		StringBuilder inssql = new StringBuilder();
		inssql.append( " insert into ZZ_JINIK_WK_RSLT " );
		inssql.append( "    select LOGIN_PERSON_ID, SHEET_ID, OWN_GUID, null from ZZ_JINIK_ALL_SRCH_RSLT where LOGIN_PERSON_ID = ? " );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( loginGuid );
		
		ZzJinikWkRsltDao dao = new ZzJinikWkRsltDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( delsql, paramList ) );
		dao.executeDynamic( DaoUtil.getPstmt( inssql, paramList ) );
	}
	
	public void reduceByStatus( MultiEditJinikEvArg arg ) {
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "delete from ZZ_JINIK_WK_RSLT wk " );
		sql.append( " where LOGIN_PERSON_ID = ? " );	paramList.add( arg.loginGuid );
		sql.append( "   and not exists ( " );
		sql.append( "         select 'X' " );
		sql.append( "           from V_CS_INFO_ATTR vcia " );
		sql.append( "          where vcia.SHEET_ID = wk.SHEET_ID " );
		if (!CsUtil.isBlank( arg.statusCd )) {
			sql.append( "        and vcia.STATUS_CD = ? " );
			paramList.add( arg.statusCd );
		}
		sql.append( "       ) " );
		
		ZzJinikWkRsltDao dao = new ZzJinikWkRsltDao( arg.getLoginNo() );
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	public void reduceByActor( MultiEditJinikEvArg arg ) {
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " delete from ZZ_JINIK_WK_RSLT wk  ");
		sql.append( "  where LOGIN_PERSON_ID = ? ");	paramList.add( arg.loginGuid );
		sql.append( "    and not exists ( ");
		sql.append( "      select 'X' ");
		sql.append( "        from V_CST_SHEET_ACTOR_AND_REF ac ");
		sql.append( "          where ac.SHEET_ID = wk.SHEET_ID ");
		sql.append( "      and ac.GUID = ? ");	paramList.add( arg.operatorGuid );
		if (!CsUtil.isBlank( arg.actorCd )) {
			sql.append( "      and ac.ACTOR_CD = ? ");
			paramList.add( arg.actorCd );
		}
		sql.append( " ) ");
		
		ZzJinikWkRsltDao dao = new ZzJinikWkRsltDao( arg.getLoginNo() );
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	public void reduceByFill( MultiEditJinikEvArg arg ) {
		
		String knskCondYksk = arg.jotaiMap.get( "knskCondYksk" );
		String knskCondYkskBnri = arg.jotaiMap.get( "knskCondYkskBnri" );
		String knskRotationKbn = arg.jotaiMap.get( "knskRotationKbn" );
		String knskKeikanen = arg.jotaiMap.get( "knskKeikanen" );
		String knskKeikanenOpe = arg.jotaiMap.get( "knskKeikanenOpe" );
		String knskIdoUmu = arg.jotaiMap.get( "knskIdoUmu" );
		String knskIdoChokkin = arg.jotaiMap.get( "knskIdoChokkin" );
		String knskTaishoku = arg.jotaiMap.get( "knskTaishoku" );
		String knskShokumu = arg.jotaiMap.get( "knskShokumu" );
		String knskJigyojo = arg.jotaiMap.get( "knskJigyojo" );
		String knskKyoten = arg.jotaiMap.get( "knskKyoten" );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " delete from ZZ_JINIK_WK_RSLT wk  ");
		sql.append( "  where LOGIN_PERSON_ID = ? ");	paramList.add( arg.loginGuid );
		sql.append( "  and ( ");
		sql.append( "        1 = 0 "); // ORで接続するために必要

		if (!CsUtil.isBlank( knskCondYksk )) {
			if(SU.equals( knskCondYksk, "その他" )) { //その他は空欄とプルダウンマスタに存在する値以外
				sql.append( "    or not exists ( ");
				sql.append( "      select 'X' from ZZ_JINIK_FILL_AUTO fl where fl.SHEET_ID = wk.SHEET_ID ");
				sql.append( "        and ( FILL_ID = 'jinik_ichiran_yksk' and FILL_CONTENT not in ('主任', '主務', '主幹', '係長', '課長', '担当部長', '部長', '室長', '総括担当', '部責任者', '所長')) ");
				sql.append( "    )");
			} else{
				sql.append( "    or not exists ( ");
				sql.append( "      select 'X' from ZZ_JINIK_FILL_AUTO fl where fl.SHEET_ID = wk.SHEET_ID ");
				sql.append( "         and FILL_ID = 'jinik_ichiran_yksk' and FILL_CONTENT = ? ");
				sql.append( "    )");
				paramList.add( knskCondYksk );
			}
		}
		if (!CsUtil.isBlank( knskCondYkskBnri )) {
			sql.append( "    or not exists ( ");
			sql.append( "      select 'X' from ZZ_JINIK_FILL_AUTO fl where fl.SHEET_ID = wk.SHEET_ID ");
			sql.append( "         and FILL_ID = 'jinik_kaito_yksk_bnri' and FILL_CONTENT = ? ");
			sql.append( "    )");
			paramList.add( knskCondYkskBnri );
		}
		if (!CsUtil.isBlank( knskRotationKbn )) {
			sql.append( "    or not exists ( ");
			sql.append( "      select 'X' from ZZ_JINIK_FILL_AUTO fl where fl.SHEET_ID = wk.SHEET_ID ");
			sql.append( "         and FILL_ID = 'jinik_kaito_rotation' and FILL_CONTENT = ? ");
			sql.append( "    )");
			paramList.add( knskRotationKbn );
		}
		if (!CsUtil.isBlank( knskKeikanen )) {
			String kigo = null;
			if ( CsUtil.isBlank(knskKeikanenOpe)) {
				kigo = "=";
			} else {
				kigo = knskKeikanenOpe;
			}
			sql.append( "    or not exists ( ");
			sql.append( "      select 'X' from ZZ_JINIK_FILL_AUTO fl where fl.SHEET_ID = wk.SHEET_ID ");
			sql.append( "         and FILL_ID = 'jinik_kaito_keika_nen_num' and TO_NUMBER(FILL_CONTENT) " +  kigo + " ? ");
			sql.append( "    )");
			paramList.add( knskKeikanen );
		}
		if (!CsUtil.isBlank( knskIdoUmu )) {
			sql.append( "    or not exists ( ");
			sql.append( "      select 'X' from ZZ_JINIK_FILL_AUTO fl where fl.SHEET_ID = wk.SHEET_ID ");
			sql.append( "         and FILL_ID = 'jinik_ichiran_idoukeikaku_umu' and FILL_CONTENT = ? ");
			sql.append( "    )");
			paramList.add( knskIdoUmu );
		}
		if (!CsUtil.isBlank( knskIdoChokkin )) {
			sql.append( "    or not exists ( ");
			sql.append( "      select 'X' from ZZ_JINIK_FILL_AUTO fl where fl.SHEET_ID = wk.SHEET_ID ");
			sql.append( "         and FILL_ID = 'jinik_ichiran_idoukeikaku_nendo' and FILL_CONTENT = ? ");
			sql.append( "    )");
			paramList.add( knskIdoChokkin );
		}
		if (!CsUtil.isBlank( knskTaishoku )) {
			sql.append( "    or not exists ( ");
			sql.append( "      select 'X' from ZZ_JINIK_FILL_AUTO fl where fl.SHEET_ID = wk.SHEET_ID ");
			sql.append( "         and FILL_ID = 'jinik_ichiran_taishoku_yotei_flg' and FILL_CONTENT = ? ");
			sql.append( "    )");
			paramList.add( knskTaishoku );
		}
		if (!CsUtil.isBlank( knskShokumu )) {
			String kigo = null;
			if ( SU.equals( knskShokumu, "なし" )){
				kigo = "=";
			} else {
				kigo = "<>";
			}
			sql.append( "    or not exists ( ");
			sql.append( "      select 'X' from ZZ_JINIK_FILL_AUTO fl where fl.SHEET_ID = wk.SHEET_ID ");
			sql.append( "         and (   ");
			sql.append( "               (FILL_ID = 'jinik_kaito_shokumu_01' and FILL_CONTENT " + kigo + " '変更なし')  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_shokumu_02' and FILL_CONTENT " + kigo + " '変更なし')  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_shokumu_03' and FILL_CONTENT " + kigo + " '変更なし')  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_shokumu_04' and FILL_CONTENT " + kigo + " '変更なし')  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_shokumu_05' and FILL_CONTENT " + kigo + " '変更なし')  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_shokumu_06' and FILL_CONTENT " + kigo + " '変更なし')  ");
			sql.append( "         ) ");
			sql.append( "    ) ");
		}
		if (!CsUtil.isBlank( knskJigyojo )) {
			String kigo = null;
			if ( SU.equals( knskJigyojo, "なし" )){
				kigo = "=";
			} else {
				kigo = "<>";
			}
			sql.append( "    or not exists ( ");
			sql.append( "      select 'X' from ZZ_JINIK_FILL_AUTO fl where fl.SHEET_ID = wk.SHEET_ID ");
			sql.append( "         and (   ");
			sql.append( "               (FILL_ID = 'jinik_kaito_jigyojo_01' and FILL_CONTENT " + kigo + " '変更なし')  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_jigyojo_02' and FILL_CONTENT " + kigo + " '変更なし')  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_jigyojo_03' and FILL_CONTENT " + kigo + " '変更なし')  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_jigyojo_04' and FILL_CONTENT " + kigo + " '変更なし')  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_jigyojo_05' and FILL_CONTENT " + kigo + " '変更なし')  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_jigyojo_06' and FILL_CONTENT " + kigo + " '変更なし')  ");
			sql.append( "         ) ");
			sql.append( "    ) ");
		}
		if (!CsUtil.isBlank( knskKyoten )) {
			String kyoten = null;
			if (SU.equals( knskKyoten, "なし" )) {
				kyoten = "('変更なし')";
			}
			else if (SU.equals( knskKyoten, "国内" )) {
				kyoten = "('同一県内', '同一県外')";
			}
			else if (SU.equals( knskKyoten, "国外" )) {
				kyoten = "('海外赴任', '海外帰任')";
			}
			sql.append( "    or not exists ( ");
			sql.append( "      select 'X' from ZZ_JINIK_FILL_AUTO fl where fl.SHEET_ID = wk.SHEET_ID ");
			sql.append( "         and (   ");
			sql.append( "               (FILL_ID = 'jinik_kaito_kyoten_01' and FILL_CONTENT in " + kyoten + ")  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_kyoten_02' and FILL_CONTENT in " + kyoten + ")  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_kyoten_03' and FILL_CONTENT in " + kyoten + ")  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_kyoten_04' and FILL_CONTENT in " + kyoten + ")  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_kyoten_05' and FILL_CONTENT in " + kyoten + ")  ");
			sql.append( "               or ");
			sql.append( "               (FILL_ID = 'jinik_kaito_kyoten_06' and FILL_CONTENT in " + kyoten + ")  ");
			sql.append( "         ) ");
			sql.append( "    ) ");
		}
		sql.append( " ) ");
		
		ZzJinikWkRsltDao dao = new ZzJinikWkRsltDao( arg.getLoginNo() );
		dao.executeDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
	
	public void updateWkIdx( MultiEditJinikEvArg arg ) throws SQLException {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " merge into ZZ_JINIK_WK_RSLT w " );
		sql.append( " using ( " );
		sql.append( "   select x.LOGIN_PERSON_ID " );
		sql.append( "        , x.SHEET_ID " );
		sql.append( "        , x.OWN_GUID " );
		sql.append( "        , ROW_NUMBER() OVER( order by ar.FULL_DEPT_NM, yk.FILL_CONTENT, ag.FILL_CONTENT desc, x.OWN_GUID ) as WK_IDX " );
		sql.append( "   from ZZ_JINIK_WK_RSLT x " );
		sql.append( "     left outer join " );
		sql.append( "       V_CS_INFO_ATTR ar " );
		sql.append( "       on ( x.SHEET_ID = ar.SHEET_ID ) " );
		sql.append( "     left outer join " );
		sql.append( "       (select * from CST_SHEET_FILL where FILL_ID = 'jinik_kaito_yksk_bnri') yk " );
		sql.append( "       on ( x.SHEET_ID = yk.SHEET_ID ) " );
		sql.append( "     left outer join " );
		sql.append( "       (select * from CST_SHEET_FILL where FILL_ID = 'jinik_info_age') ag " );
		sql.append( "       on ( x.SHEET_ID = ag.SHEET_ID ) " );
		sql.append( "     where x.LOGIN_PERSON_ID = ? " );
		sql.append( " ) s " );
		sql.append( "   on (w.LOGIN_PERSON_ID = s.LOGIN_PERSON_ID and w.SHEET_ID = s.SHEET_ID ) " );
		sql.append( "  when matched then update " );
		sql.append( "  set w.WK_IDX = s.WK_IDX " );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.loginGuid );
		
		ZzJinikWkRsltDao dao = new ZzJinikWkRsltDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public List<ZzJinikSummaryListDto> makeSummaryList( List<ZzJinikSummaryListDto> rawSheetList, Map<String, Map<String, String>> maskSetMap ) {
		List<ZzJinikSummaryListDto> makedSummaryList = new ArrayList<ZzJinikSummaryListDto>();
		for (ZzJinikSummaryListDto raw : rawSheetList) {
			String maskKey = raw.getStatusCd() + "#" + raw.getFillSetCd() + "#" + raw.getMaskCd();
			Map<String, String> mask = maskSetMap.get( maskKey );
			
			ZzJinikSummaryListDto masked = new ZzJinikSummaryListDto();
			masked.setLoginPersonId( raw.getLoginPersonId() );
			masked.setSheetId( raw.getSheetId() );
			masked.setOwnGuid( raw.getOwnGuid() );
			masked.setWkIdx( raw.getWkIdx() );
			masked.setStatusCd( raw.getStatusCd() );
			masked.setStatusNm( raw.getStatusNm() );
			masked.setFillSetCd( raw.getFillSetCd() );
			masked.setMaskCd( raw.getMaskCd() );
			masked.setOwnPersonName( raw.getOwnPersonName() );
			masked.setFullDeptNm( raw.getFullDeptNm() );
			masked.setHoldGuid( raw.getHoldGuid() );
			masked.setExclusiveKey( raw.getExclusiveKey() );
			masked.setFillYksk( mask.containsKey( "jinik_ichiran_yksk" )              ? raw.getFillYksk() : "" );
			masked.setFillYkbr( mask.containsKey( "jinik_kaito_yksk_bnri" )           ? raw.getFillYkbr() : "" );
			masked.setFillKbnr( mask.containsKey( "jinik_ichiran_shain_kbn_ryaku" )   ? raw.getFillKbnr() : "" );
			masked.setFillWrai( mask.containsKey( "jinik_ichiran_chotatsu_wariai" )   ? raw.getFillWrai() : "" );
			masked.setFillRota( mask.containsKey( "jinik_kaito_rotation" )            ? raw.getFillRota() : "" );
			masked.setFillKais( mask.containsKey( "jinik_ichiran_gyomu_kaisi" )       ? raw.getFillKais() : "" );
			masked.setFillDkbn( mask.containsKey( "jinik_chohyo_doitsu_gyomu_kbn" )   ? raw.getFillDkbn() : "" );
			masked.setFillKnen( mask.containsKey( "jinik_kaito_keika_nen" )           ? raw.getFillKnen() : "" );
			masked.setFillIumu( mask.containsKey( "jinik_ichiran_idoukeikaku_umu" )   ? raw.getFillIumu() : "" );
			masked.setFillInen( mask.containsKey( "jinik_ichiran_idoukeikaku_nendo" ) ? raw.getFillInen() : "" );
			makedSummaryList.add( masked );
		}
		return makedSummaryList;
	}

	public List<ZzJinikSummaryListDto> getSheetInfo(MultiEditJinikEvArg arg) throws CareerException {
		ZzJinikSummaryListDao dao = new ZzJinikSummaryListDao(daoLoginNo);
		return dao.selectByLoginPersonId( arg.loginGuid );
	}
	
	public Map<String, Map<String, String>> getMaskSetMap(MultiEditJinikEvArg arg ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select distinct ar.STATUS_CD, ar.FILL_SET_CD, ar.MASK_CD ");
		sql.append( "   from (select SHEET_ID from ZZ_JINIK_WK_RSLT where LOGIN_PERSON_ID = ? ) wk ");
		sql.append( "   inner join V_CS_INFO_ATTR ar ");
		sql.append( "     on ( wk.SHEET_ID = ar.SHEET_ID ) ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.loginGuid );
		
		String[] cols = { "STATUS_CD", "FILL_SET_CD", "MASK_CD" };
		String[] keys = { "statusCd", "fillSetCd", "maskCd" };

		GeneralMapDao dao = new GeneralMapDao( this.daoLoginNo );
		List<Map<String, String>> argMapList = dao.select( cols, keys, DaoUtil.getPstmt( sql, paramList ) );
		
		Map<String, Map<String,String>> result = new HashMap<String, Map<String,String>>();
		for (Map<String, String> argMap : argMapList) {
			String fillSetCd = argMap.get("fillSetCd");
			String maskCd = argMap.get("maskCd");
			String statusCd = argMap.get("statusCd");
			HashMap<String, String> msk = getFillMaskMap( arg.loginGuid, fillSetCd , maskCd, statusCd, arg.actorCd );
			String maskKey = statusCd + "#" + fillSetCd + "#" + maskCd;
			result.put(maskKey, msk);
		}
		return result;
	}
	
	
	//CsSheetEventHandlerより流用
	public static HashMap<String, String> getFillMaskMap( String daoLoginNo, String fillSetCd, String maskCd, String statusCd, String actorCd ) {
		List<CsmSheetFillMaskDto> maskDtoList = new ArrayList<CsmSheetFillMaskDto>();
		CsmSheetFillMaskDao allDao = new CsmSheetFillMaskDao( daoLoginNo );
		CsmSheetFillMaskDto allDto = allDao.select( maskCd, statusCd, actorCd, "ALL" );
		
		CsmSheetFillMaskDao dao = new CsmSheetFillMaskDao( daoLoginNo );
		if (allDto != null) {
			// FILL_ID に 'ALL' が存在する → 処理中のシートをすべてそのREAD_OR_WRITEでマスク。ALL以外の定義でオーバーライド。
			maskDtoList = getFillMasksWithALL( daoLoginNo, fillSetCd, maskCd, statusCd, actorCd, allDto.getReadOrWrite() );
		} else {
			// FILL_ID に 'ALL' が存在しない
			maskDtoList = dao.selectFillMasks( maskCd, statusCd, actorCd );
		}
		HashMap<String, String> fillMaskMap = new HashMap<String, String>();
		for (CsmSheetFillMaskDto maskDto : maskDtoList) {
			String mode = maskDto.getReadOrWrite();
			if ("read".equals( mode ) || "write".equals( mode )) {
				fillMaskMap.put( maskDto.getFillId(), mode );
			}
		}
		return fillMaskMap;
	}
	
	//CsSheetEventHandlerより流用
	public static List<CsmSheetFillMaskDto> getFillMasksWithALL( String daoLoginNo, String fillSetCd, String maskCd, String statusCd, String actorCd, String readOrWrite ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select mask.MASK_CD as maskCd, mask.STATUS_CD as statusCd, mask.ACTOR_CD as actorCd, mask.FILL_ID as fillId, mask.READ_OR_WRITE as readOrWrite from " );
		sql.append( " ( " );
		sql.append( "   select ? as MASK_CD, ? as STATUS_CD, ? as ACTOR_CD, FILL_ID, ? as READ_OR_WRITE, 100 as LV " );
		sql.append( "     from CSM_SHEET_FILL where FILL_SET_CD = ? " );
		sql.append( "   union " );
		sql.append( "   select MASK_CD, STATUS_CD, ACTOR_CD, FILL_ID, READ_OR_WRITE, 999 as LV " );
		sql.append( "     from CSM_SHEET_FILL_MASK where MASK_CD = ? and STATUS_CD = ? and ACTOR_CD = ? " );
		sql.append( " ) mask " );
		sql.append( "   inner join ( " );
		sql.append( "     select FILL_ID, max(LV) as LV from " );
		sql.append( "     ( " );
		sql.append( "       select FILL_ID, 100 as LV from CSM_SHEET_FILL where FILL_SET_CD = ? " );
		sql.append( "       union " );
		sql.append( "       select FILL_ID, 999 as LV from CSM_SHEET_FILL_MASK where FILL_ID <> 'ALL' and MASK_CD = ? and STATUS_CD = ? and ACTOR_CD = ? " );
		sql.append( "     ) " );
		sql.append( "     group by FILL_ID " );
		sql.append( "   ) sub on (sub.FILL_ID = mask.FILL_ID and sub.LV = mask.LV) " );
		sql.append( " order by mask.MASK_CD, mask.STATUS_CD, mask.ACTOR_CD, mask.FILL_ID " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( maskCd );  paramList.add( statusCd );  paramList.add( actorCd );  paramList.add( readOrWrite );
		paramList.add( fillSetCd );
		paramList.add( maskCd );  paramList.add( statusCd );  paramList.add( actorCd );
		paramList.add( fillSetCd );
		paramList.add( maskCd );  paramList.add( statusCd );  paramList.add( actorCd );
		
		CsmSheetFillMaskDao dao = new CsmSheetFillMaskDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}

	/**
	 * CsSheetEventHandlerよりコピー
	 */
	public List<CsmSheetActionDto> getActionList( String flowCd, String flowPtn, String statusCd, String actorCd ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + CsmSheetActionDao.ALLCOLS );
		sql.append( "   from CSM_SHEET_ACTION ");
		sql.append( "  where FLOW_CD = ? and FLOW_PTN = ? and STATUS_CD = ? and ACTOR_CD = ? ");
		sql.append( "  order by LPAD_SORT ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( flowCd );
		paramList.add( flowPtn );
		paramList.add( statusCd );
		paramList.add( actorCd );
		
		CsmSheetActionDao dao = new CsmSheetActionDao(daoLoginNo);
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}

	public Map<String, List<PulldownMasterDto>> getLayoutPD( String layoutCd ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + CsUtil.addPrefixOnDaoAllCols( "pm", PulldownMasterDao.ALLCOLS ) );
		sql.append( "   from CSM_SHEET_LAYOUT_PD pd ");
		sql.append( "        inner join PULLDOWN_MASTER pm ");
		sql.append( "          on (pm.PD_SET_CD = pd.PD_SET_CD) ");
		sql.append( "  where pd.LAYOUT_CD = ? ");
		sql.append( "  order by pm.PD_SET_CD, pm.LPAD_SORT ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( layoutCd );
		
		PulldownMasterDao dao = new PulldownMasterDao( daoLoginNo );
		List<PulldownMasterDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		
		Map<String, List<PulldownMasterDto>> result = AU.toMap( list, "pdSetCd" );
		return result;
	}

	public String getLayoutCd( String operationCd ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select LAYOUT_CD as text " );
		sql.append( "   from CSM_SHEET_FORM ");
		sql.append( "  where OPERATION_CD = ? ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( operationCd );
		
		OneColumnDao dao = new OneColumnDao( daoLoginNo );
		String layoutCd = dao.selectDynamicFirst( DaoUtil.getPstmt( sql, paramList ) );
		
		return layoutCd;
	}
	
	public Map<String, Integer> getRojCntMap( MultiEditJinikEvArg arg ) {

		StringBuilder sql = new StringBuilder();
		sql.append(" select ROJ_PTN as rojPtn, COUNT(ROJ_PTN) as rojPtnCnt ");
		sql.append("   from ZZ_JINIK_WK_RSLT rslt ");
		sql.append("        inner join ZZ_JINIK_ROJ roj on (rslt.SHEET_ID = roj.SHEET_ID) ");
		sql.append("   where LOGIN_PERSON_ID = ? ");
		sql.append("   group by roj.ROJ_PTN ");
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add(arg.loginGuid);
		
		ZzxJinikRojCntDao dao = new ZzxJinikRojCntDao(daoLoginNo);
		List<ZzxJinikRojCntDto> list = dao.selectDynamic(DaoUtil.getPstmt(sql, paramList));
		
		Map<String, Integer> receivedMap = new HashMap<String, Integer>();
		for (ZzxJinikRojCntDto dto : list) {
			receivedMap.put( dto.getRojPtn(), dto.getRojPtnCnt() );
		}
		Map<String, Integer> rojCntMap = new HashMap<String, Integer>();
		rojCntMap.put( "A", receivedMap.get("A") == null ? 0 : receivedMap.get("A") );
		rojCntMap.put( "B", receivedMap.get("B") == null ? 0 : receivedMap.get("B") );
		rojCntMap.put( "C", receivedMap.get("C") == null ? 0 : receivedMap.get("C") );
		rojCntMap.put( "D", receivedMap.get("D") == null ? 0 : receivedMap.get("D") );
		rojCntMap.put( "E", receivedMap.get("E") == null ? 0 : receivedMap.get("E") );
		rojCntMap.put( "F", receivedMap.get("F") == null ? 0 : receivedMap.get("F") );
		rojCntMap.put( "G", receivedMap.get("G") == null ? 0 : receivedMap.get("G") );
		
		Integer rojCntTotal = 0;
		for(Integer val : rojCntMap.values() ){
			rojCntTotal = rojCntTotal + val;
		}
		rojCntMap.put( "Total", rojCntTotal );
		
		return rojCntMap;
	}
	
	public List<ValueTextSortDto> getActorList( MultiEditJinikEvArg arg ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append("select distinct ac.ACTOR_CD as value, ac.ACTOR_NM as text, ac.ACTOR_SORT as sort ");
		sql.append("  from ZZ_JINIK_ALL_SRCH_RSLT zz ");
		sql.append("       inner join V_CST_SHEET_ACTOR_AND_REF ac ");
		sql.append("         on ( zz.SHEET_ID = ac.SHEET_ID ) ");
		sql.append(" where ac.GUID = ? ");
		sql.append(" and zz.LOGIN_PERSON_ID	= ? ");
		sql.append(" order by ac.ACTOR_SORT desc ");
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add(arg.operatorGuid);
		paramList.add(arg.loginGuid);
		
		ValueTextSortDao dao = new ValueTextSortDao(daoLoginNo);
		List<ValueTextSortDto> list = dao.selectDynamic(DaoUtil.getPstmt(sql, paramList));
		
		return list;
	}

	
}
