package jp.co.hisas.career.app.sheet.event;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.ejb.AbstractEventArg;

@SuppressWarnings("serial")
public class RsvAdminEventArg extends AbstractEventArg {
	
	public String sharp = null;
	
	public RsvAdminEventArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		if (this.sharp == null || "".equals( this.sharp.trim() )) {
			throw new CareerException( "Invalid Arg: sharp is null." );
		}
	}
	
}
