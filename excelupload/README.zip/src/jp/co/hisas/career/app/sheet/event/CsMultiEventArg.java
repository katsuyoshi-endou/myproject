package jp.co.hisas.career.app.sheet.event;

import java.util.HashMap;
import java.util.List;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.ejb.AbstractEventArg;

@SuppressWarnings("serial")
public class CsMultiEventArg extends AbstractEventArg {
	
	public String sharp = null;
	public String operatorGuid = null;
	public HashMap<String, String> srchCondMap = null;
	public String party = null;
	public String operationCd = null;
	public String formGrpCd = null;
	public String statusCd = null;
	public String searchDiv = null;
	public String flowCd, actorCd = null;
	public List<String> sheetIdList = null;
	public String trans = null;
	public String formGrps = null;
	public String opeType = null;
	
	public CsMultiEventArg(String loginNo, String operatorGuid) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		if (operatorGuid == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
		this.operatorGuid = operatorGuid;
	}
	
	public void setAll( String sharp, String party, String operationCode, String formGrpCode, String statusCode, String searchDiv, String flowCd ) {
		this.sharp = sharp;
		this.party = party;
		this.operationCd = operationCode;
		this.formGrpCd = formGrpCode;
		this.statusCd = statusCode;
		this.searchDiv = searchDiv;
		this.flowCd = flowCd;
	}
	
	public void setAll2( String sharp, String flowCd, String statusCd, String actorCd ) {
		this.sharp = sharp;
		this.flowCd   = flowCd;
		this.statusCd = statusCd;
		this.actorCd  = actorCd;
	}
	
	public void validateArg() throws CareerException {
		if (this.sharp == null || "".equals( this.sharp.trim() )) {
			throw new CareerException( "Invalid Arg: state is null." );
		}
	}
	
}
