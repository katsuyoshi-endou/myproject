package jp.co.hisas.career.app.sheet.bean;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.event.MultiJinikPrepareEvArg;
import jp.co.hisas.career.app.sheet.event.MultiJinikPrepareEvHdlr;
import jp.co.hisas.career.app.sheet.event.MultiJinikPrepareEvRslt;
import jp.co.hisas.career.app.sheet.util.CsMultiSheet;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class MultiJinikPrepareSearchBean {
	
	private String loginNo;
	private String operatorGuid;
	private HttpServletRequest request;
	private HttpSession session;
	
	public MultiJinikPrepareSearchBean(String loginNo, String operatorGuid) {
		this.loginNo = loginNo;
		this.operatorGuid = operatorGuid;
	}
	
	public CsMultiSheet execMultiSheetSearch( Tray tray ) throws CareerException {
		this.request = tray.request;
		this.session = request.getSession( false );
		
		String party = tray.party;
		
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( session, UserInfoBean.SESSION_KEY );
		this.operatorGuid = userInfo.getOperatorGuid();
		this.operatorGuid = tray.operatorGuid;
		
		HashMap<String, String> gamenCondMap = makeSrchCondMap( party );
		
		String operationCd  = gamenCondMap.get( "operationCd" );
		
		// 自分がアクターに紐付けされているシートの一覧を取得 <<常に更新>>
		MultiJinikPrepareEvRslt searchResult = execEventSearch( party, operationCd, gamenCondMap);
		CsMultiSheet csMultiSheet = new CsMultiSheet( loginNo, operatorGuid );
		csMultiSheet.statusList    = searchResult.staList;
		
		return csMultiSheet;
		
	}
	
	private HashMap<String, String> makeSrchCondMap( String party ) {
		
		String operationCd = CsUtil.getRequestValue( request, "operationCd" );
		String operationNm = CsUtil.getCsmOperation( loginNo, party, operationCd ).getOperationNm();
		String formGrpCd   = CsUtil.getOneFormGrpCd( loginNo, party, operationCd );
		String formGrpNm   = CsUtil.getCsmFormGrp( loginNo, party, operationCd, formGrpCd ).getFormGrpNm();
		String flowCd      = convertFormGrpCd2FlowCd( formGrpCd );
		String formCtgCd   = CsUtil.getRequestValue( request, "formCtgCd" );
		String deptCd   = CsUtil.getRequestValue( request, "deptCd" );
		String companyCd   = CsUtil.getRequestValue( request, "companyCd" );
		String statusCd    = CsUtil.getRequestValue( request, "statusCd" );
		String statusNm    = CsUtil.getCsmFlow( loginNo, flowCd, statusCd ).getStatusNm();
		String retireFlg   = CsUtil.getRequestValue( request, "retireFlg" );
		String tab         = CsUtil.getMultiTab( loginNo, formGrpCd, formCtgCd, statusCd );
		String holdFilter  = CsUtil.getRequestValue( request, "holdFilter" );
		String clsCCd      = CsUtil.getRequestValue( request, "clsCCd" );
		if (SU.isBlank( holdFilter )) {
			// パナソニック独自仕様：デフォルトが「すべて」
			holdFilter = "ALL";
		}
		
		HashMap<String, String> srchCondMap = new HashMap<String, String>();
		srchCondMap.put( "actorCd",      CsUtil.getRequestValue( request, "actorCd"      ) );
		srchCondMap.put( "clsHCd",       CsUtil.getRequestValue( request, "clsHCd"       ) );
		srchCondMap.put( "deptCd",       CsUtil.getRequestValue( request, "deptCd"       ) );
		srchCondMap.put( "deptNm",       CsUtil.getRequestValue( request, "deptNm"       ) );
		srchCondMap.put( "flowCd",       flowCd );
		srchCondMap.put( "formCtgCd",    formCtgCd );
		srchCondMap.put( "formGrpCd",    formGrpCd );
		srchCondMap.put( "formGrpNm",    formGrpNm );
		srchCondMap.put( "deptCd",       deptCd );
		srchCondMap.put( "companyCd",    companyCd );
		srchCondMap.put( "holdFilter",   holdFilter );
		srchCondMap.put( "operationCd",  operationCd );
		srchCondMap.put( "operationNm",  operationNm );
		srchCondMap.put( "personId",     CsUtil.getRequestValue( request, "personId"     ) );
		srchCondMap.put( "personNm",     CsUtil.getRequestValue( request, "personNm"     ) );
		srchCondMap.put( "searchDiv",    CsUtil.getRequestValue( request, "searchDiv"    ) );
		srchCondMap.put( "sort",         CsUtil.getRequestValue( request, "sort"         ) );
		srchCondMap.put( "sort", "sort1" );
		srchCondMap.put( "statusCd",     "" );
		srchCondMap.put( "statusCd",     CsUtil.getRequestValue( request, "statusCd"     ) );
		srchCondMap.put( "statusNm",     statusNm );
		srchCondMap.put( "retireFlg",    retireFlg );
		srchCondMap.put( "tab",          tab );
		srchCondMap.put( "clsCCd",       clsCCd );
		return srchCondMap;
	}
	
	private String convertFormGrpCd2FlowCd( String formGrpCd ) {
		return SU.isNotBlank( formGrpCd ) ? "flw-" + CsUtil.extractWithRegex( formGrpCd, "grp-(.*)" ) : null;
	}
	
	private MultiJinikPrepareEvRslt execEventSearch( String party, String operationCd, HashMap<String, String> srchCondMap ) throws CareerException {
		MultiJinikPrepareEvArg arg = new MultiJinikPrepareEvArg( loginNo, operatorGuid );
		arg.setAll( "SEARCH", party, operationCd );
		arg.srchCondMap = srchCondMap;
		arg.opeType =  "STAMP";
		return MultiJinikPrepareEvHdlr.exec( arg );
	}
	
}
