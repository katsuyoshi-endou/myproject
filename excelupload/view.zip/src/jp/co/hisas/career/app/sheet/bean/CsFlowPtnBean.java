package jp.co.hisas.career.app.sheet.bean;

import java.io.Serializable;
import java.util.List;

public class CsFlowPtnBean implements Serializable {
	
	public String code;
	public String name;
	public List<String> pathStatuses;
	public List<String> mainActors;
	
}
