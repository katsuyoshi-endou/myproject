/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CST_SHEET_SRCH_RSLT Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class ZzBulkOperWkRsltDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * LOGIN_PERSON_ID
     */
    private String loginPersonId;

    /**
     * SHEET_ID
     */
    private String sheetId;

    /**
     * OWN_GUID
     */
    private String ownGuid;

    /**
     * WK_IDX
     */
    private Integer wkIdx;

    /**
     * LOGIN_PERSON_IDを取得する。
     * @return LOGIN_PERSON_ID
     */
    public String getLoginPersonId() {
        return loginPersonId;
    }

    /**
     * LOGIN_PERSON_IDを設定する。
     * @param loginPersonId LOGIN_PERSON_ID
     */
    public void setLoginPersonId(String loginPersonId) {
        this.loginPersonId = loginPersonId;
    }

    /**
     * SHEET_IDを取得する。
     * @return SHEET_ID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * SHEET_IDを設定する。
     * @param sheetId SHEET_ID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * OWN_GUIDを取得する。
     * @return OWN_GUID
     */
    public String getOwnGuid() {
        return ownGuid;
    }

    /**
     * OWN_GUIDを設定する。
     * @param ownGuid OWN_GUID
     */
    public void setOwnGuid(String ownGuid) {
        this.ownGuid = ownGuid;
    }

    /**
     * WK_IDXを取得する。
     * @return WK_IDX
     */
	public Integer getWkIdx() {
		return wkIdx;
	}

    /**
     * WK_IDXを設定する。
     * @param wkIdx WK_IDX
     */
	public void setWkIdx(Integer wkIdx) {
		this.wkIdx = wkIdx;
	}
}

