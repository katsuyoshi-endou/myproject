/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CstSheetAttrDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CSTシート属性 Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CstSheetAttrDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " SHEET_ID as sheetId,"
                     + " OWN_GUID as ownGuid,"
                     + " OWN_PERSON_NAME as ownPersonName,"
                     + " SHEET_SORT as sheetSort,"
                     + " TERM as term,"
                     + " DEPT_CD as deptCd,"
                     + " DEPT_NM as deptNm,"
                     + " FULL_DEPT_CD as fullDeptCd,"
                     + " FULL_DEPT_NM as fullDeptNm,"
                     + " HIERARCHY as hierarchy,"
                     + " BUMADE_DEPT_CD as bumadeDeptCd,"
                     + " BUMADE_DEPT_NM as bumadeDeptNm,"
                     + " SEARCH_DIV as searchDiv,"
                     + " CLS_A_CD as clsACd,"
                     + " CLS_A_NM as clsANm,"
                     + " CLS_B_CD as clsBCd,"
                     + " CLS_B_NM as clsBNm,"
                     + " CLS_C_CD as clsCCd,"
                     + " CLS_C_NM as clsCNm,"
                     + " CLS_D_CD as clsDCd,"
                     + " CLS_D_NM as clsDNm,"
                     + " CLS_E_CD as clsECd,"
                     + " CLS_E_NM as clsENm,"
                     + " CLS_F_CD as clsFCd,"
                     + " CLS_F_NM as clsFNm,"
                     + " CLS_G_CD as clsGCd,"
                     + " CLS_G_NM as clsGNm,"
                     + " CLS_H_CD as clsHCd,"
                     + " CLS_H_NM as clsHNm,"
                     + " CLS_I_CD as clsICd,"
                     + " CLS_I_NM as clsINm,"
                     + " CLS_J_CD as clsJCd,"
                     + " CLS_J_NM as clsJNm,"
                     + " CLS_K_CD as clsKCd,"
                     + " CLS_K_NM as clsKNm,"
                     + " CLS_L_CD as clsLCd,"
                     + " CLS_L_NM as clsLNm,"
                     + " CLS_M_CD as clsMCd,"
                     + " CLS_M_NM as clsMNm,"
                     + " CLS_N_CD as clsNCd,"
                     + " CLS_N_NM as clsNNm,"
                     + " TXT_A as txtA,"
                     + " TXT_B as txtB,"
                     + " TXT_C as txtC,"
                     + " TXT_D as txtD,"
                     + " TXT_E as txtE,"
                     + " TXT_F as txtF,"
                     + " TXT_G as txtG,"
                     + " TXT_H as txtH,"
                     + " TXT_I as txtI,"
                     + " TXT_J as txtJ,"
                     + " TXT_K as txtK,"
                     + " TXT_L as txtL,"
                     + " TXT_M as txtM,"
                     + " TXT_N as txtN"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CstSheetAttrDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CstSheetAttrDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * Insert文を実行する。
     * @param dto CST_SHEET_ATTRのデータ。
     */ 
    public void insert(CstSheetAttrDto dto) {

        final String sql = "INSERT INTO CST_SHEET_ATTR ("
                         + "SHEET_ID,"
                         + "OWN_GUID,"
                         + "OWN_PERSON_NAME,"
                         + "SHEET_SORT,"
                         + "TERM,"
                         + "DEPT_CD,"
                         + "DEPT_NM,"
                         + "FULL_DEPT_CD,"
                         + "FULL_DEPT_NM,"
                         + "HIERARCHY,"
                         + "BUMADE_DEPT_CD,"
                         + "BUMADE_DEPT_NM,"
                         + "SEARCH_DIV,"
                         + "CLS_A_CD,"
                         + "CLS_A_NM,"
                         + "CLS_B_CD,"
                         + "CLS_B_NM,"
                         + "CLS_C_CD,"
                         + "CLS_C_NM,"
                         + "CLS_D_CD,"
                         + "CLS_D_NM,"
                         + "CLS_E_CD,"
                         + "CLS_E_NM,"
                         + "CLS_F_CD,"
                         + "CLS_F_NM,"
                         + "CLS_G_CD,"
                         + "CLS_G_NM,"
                         + "CLS_H_CD,"
                         + "CLS_H_NM,"
                         + "CLS_I_CD,"
                         + "CLS_I_NM,"
                         + "CLS_J_CD,"
                         + "CLS_J_NM,"
                         + "CLS_K_CD,"
                         + "CLS_K_NM,"
                         + "CLS_L_CD,"
                         + "CLS_L_NM,"
                         + "CLS_M_CD,"
                         + "CLS_M_NM,"
                         + "CLS_N_CD,"
                         + "CLS_N_NM,"
                         + "TXT_A,"
                         + "TXT_B,"
                         + "TXT_C,"
                         + "TXT_D,"
                         + "TXT_E,"
                         + "TXT_F,"
                         + "TXT_G,"
                         + "TXT_H,"
                         + "TXT_I,"
                         + "TXT_J,"
                         + "TXT_K,"
                         + "TXT_L,"
                         + "TXT_M,"
                         + "TXT_N"
                         + ")VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? )"
                         ;
        Log.sql("【DaoMethod Call】 CstSheetAttrDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getSheetId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getOwnGuid());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getOwnPersonName());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getSheetSort());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getTerm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getDeptCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getDeptNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 8, dto.getFullDeptCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 9, dto.getFullDeptNm());
            DaoUtil.setIntToPreparedStatement(pstmt, 10, dto.getHierarchy());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 11, dto.getBumadeDeptCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 12, dto.getBumadeDeptNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 13, dto.getSearchDiv());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 14, dto.getClsACd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 15, dto.getClsANm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 16, dto.getClsBCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 17, dto.getClsBNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 18, dto.getClsCCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 19, dto.getClsCNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 20, dto.getClsDCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 21, dto.getClsDNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 22, dto.getClsECd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 23, dto.getClsENm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 24, dto.getClsFCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 25, dto.getClsFNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 26, dto.getClsGCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 27, dto.getClsGNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 28, dto.getClsHCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 29, dto.getClsHNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 30, dto.getClsICd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 31, dto.getClsINm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 32, dto.getClsJCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 33, dto.getClsJNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 34, dto.getClsKCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 35, dto.getClsKNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 36, dto.getClsLCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 37, dto.getClsLNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 38, dto.getClsMCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 39, dto.getClsMNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 40, dto.getClsNCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 41, dto.getClsNNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 42, dto.getTxtA());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 43, dto.getTxtB());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 44, dto.getTxtC());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 45, dto.getTxtD());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 46, dto.getTxtE());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 47, dto.getTxtF());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 48, dto.getTxtG());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 49, dto.getTxtH());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 50, dto.getTxtI());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 51, dto.getTxtJ());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 52, dto.getTxtK());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 53, dto.getTxtL());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 54, dto.getTxtM());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 55, dto.getTxtN());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * 全列update文を実行する。
     * @param dto CST_SHEET_ATTRのレコード型データ。
     */
    public void update(CstSheetAttrDto dto) {

        final String sql = "UPDATE CST_SHEET_ATTR SET "
                         + "OWN_GUID = ?,"
                         + "OWN_PERSON_NAME = ?,"
                         + "SHEET_SORT = ?,"
                         + "TERM = ?,"
                         + "DEPT_CD = ?,"
                         + "DEPT_NM = ?,"
                         + "FULL_DEPT_CD = ?,"
                         + "FULL_DEPT_NM = ?,"
                         + "HIERARCHY = ?,"
                         + "BUMADE_DEPT_CD = ?,"
                         + "BUMADE_DEPT_NM = ?,"
                         + "SEARCH_DIV = ?,"
                         + "CLS_A_CD = ?,"
                         + "CLS_A_NM = ?,"
                         + "CLS_B_CD = ?,"
                         + "CLS_B_NM = ?,"
                         + "CLS_C_CD = ?,"
                         + "CLS_C_NM = ?,"
                         + "CLS_D_CD = ?,"
                         + "CLS_D_NM = ?,"
                         + "CLS_E_CD = ?,"
                         + "CLS_E_NM = ?,"
                         + "CLS_F_CD = ?,"
                         + "CLS_F_NM = ?,"
                         + "CLS_G_CD = ?,"
                         + "CLS_G_NM = ?,"
                         + "CLS_H_CD = ?,"
                         + "CLS_H_NM = ?,"
                         + "CLS_I_CD = ?,"
                         + "CLS_I_NM = ?,"
                         + "CLS_J_CD = ?,"
                         + "CLS_J_NM = ?,"
                         + "CLS_K_CD = ?,"
                         + "CLS_K_NM = ?,"
                         + "CLS_L_CD = ?,"
                         + "CLS_L_NM = ?,"
                         + "CLS_M_CD = ?,"
                         + "CLS_M_NM = ?,"
                         + "CLS_N_CD = ?,"
                         + "CLS_N_NM = ?,"
                         + "TXT_A = ?,"
                         + "TXT_B = ?,"
                         + "TXT_C = ?,"
                         + "TXT_D = ?,"
                         + "TXT_E = ?,"
                         + "TXT_F = ?,"
                         + "TXT_G = ?,"
                         + "TXT_H = ?,"
                         + "TXT_I = ?,"
                         + "TXT_J = ?,"
                         + "TXT_K = ?,"
                         + "TXT_L = ?,"
                         + "TXT_M = ?,"
                         + "TXT_N = ?"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstSheetAttrDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getOwnGuid());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getOwnPersonName());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getSheetSort());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getTerm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getDeptCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getDeptNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getFullDeptCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 8, dto.getFullDeptNm());
            DaoUtil.setIntToPreparedStatement(pstmt, 9, dto.getHierarchy());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 10, dto.getBumadeDeptCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 11, dto.getBumadeDeptNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 12, dto.getSearchDiv());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 13, dto.getClsACd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 14, dto.getClsANm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 15, dto.getClsBCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 16, dto.getClsBNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 17, dto.getClsCCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 18, dto.getClsCNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 19, dto.getClsDCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 20, dto.getClsDNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 21, dto.getClsECd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 22, dto.getClsENm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 23, dto.getClsFCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 24, dto.getClsFNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 25, dto.getClsGCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 26, dto.getClsGNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 27, dto.getClsHCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 28, dto.getClsHNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 29, dto.getClsICd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 30, dto.getClsINm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 31, dto.getClsJCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 32, dto.getClsJNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 33, dto.getClsKCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 34, dto.getClsKNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 35, dto.getClsLCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 36, dto.getClsLNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 37, dto.getClsMCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 38, dto.getClsMNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 39, dto.getClsNCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 40, dto.getClsNNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 41, dto.getTxtA());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 42, dto.getTxtB());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 43, dto.getTxtC());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 44, dto.getTxtD());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 45, dto.getTxtE());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 46, dto.getTxtF());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 47, dto.getTxtG());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 48, dto.getTxtH());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 49, dto.getTxtI());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 50, dto.getTxtJ());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 51, dto.getTxtK());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 52, dto.getTxtL());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 53, dto.getTxtM());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 54, dto.getTxtN());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 55, dto.getSheetId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してdelete文を実行する。
     * @param sheetId シートID
     */ 
    public void delete(String sheetId) {

        final String sql = "DELETE FROM CST_SHEET_ATTR"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstSheetAttrDao.delete");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally { 
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param sheetId シートID
     * @return CstSheetAttrDto CST_SHEET_ATTRのレコード型データ。
     */ 
    public CstSheetAttrDto select(String sheetId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CST_SHEET_ATTR"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstSheetAttrDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            rs = pstmt.executeQuery();
            CstSheetAttrDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<CstSheetAttrDto> CST_SHEET_ATTRのレコード型データのリスト。
     */ 
    public List<CstSheetAttrDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CstSheetAttrDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CstSheetAttrDto> lst = new ArrayList<CstSheetAttrDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CstSheetAttrDto> CST_SHEET_ATTRのレコード型データのリスト。
     */ 
    public List<CstSheetAttrDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CstSheetAttrDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CstSheetAttrDto transferRsToDto(ResultSet rs) throws SQLException {

        CstSheetAttrDto dto = new CstSheetAttrDto();
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setOwnGuid(DaoUtil.convertNullToString(rs.getString("ownGuid")));
        dto.setOwnPersonName(DaoUtil.convertNullToString(rs.getString("ownPersonName")));
        dto.setSheetSort(DaoUtil.convertNullToString(rs.getString("sheetSort")));
        dto.setTerm(DaoUtil.convertNullToString(rs.getString("term")));
        dto.setDeptCd(DaoUtil.convertNullToString(rs.getString("deptCd")));
        dto.setDeptNm(DaoUtil.convertNullToString(rs.getString("deptNm")));
        dto.setFullDeptCd(DaoUtil.convertNullToString(rs.getString("fullDeptCd")));
        dto.setFullDeptNm(DaoUtil.convertNullToString(rs.getString("fullDeptNm")));
        dto.setHierarchy(rs.getInt("hierarchy"));
        dto.setBumadeDeptCd(DaoUtil.convertNullToString(rs.getString("bumadeDeptCd")));
        dto.setBumadeDeptNm(DaoUtil.convertNullToString(rs.getString("bumadeDeptNm")));
        dto.setSearchDiv(DaoUtil.convertNullToString(rs.getString("searchDiv")));
        dto.setClsACd(DaoUtil.convertNullToString(rs.getString("clsACd")));
        dto.setClsANm(DaoUtil.convertNullToString(rs.getString("clsANm")));
        dto.setClsBCd(DaoUtil.convertNullToString(rs.getString("clsBCd")));
        dto.setClsBNm(DaoUtil.convertNullToString(rs.getString("clsBNm")));
        dto.setClsCCd(DaoUtil.convertNullToString(rs.getString("clsCCd")));
        dto.setClsCNm(DaoUtil.convertNullToString(rs.getString("clsCNm")));
        dto.setClsDCd(DaoUtil.convertNullToString(rs.getString("clsDCd")));
        dto.setClsDNm(DaoUtil.convertNullToString(rs.getString("clsDNm")));
        dto.setClsECd(DaoUtil.convertNullToString(rs.getString("clsECd")));
        dto.setClsENm(DaoUtil.convertNullToString(rs.getString("clsENm")));
        dto.setClsFCd(DaoUtil.convertNullToString(rs.getString("clsFCd")));
        dto.setClsFNm(DaoUtil.convertNullToString(rs.getString("clsFNm")));
        dto.setClsGCd(DaoUtil.convertNullToString(rs.getString("clsGCd")));
        dto.setClsGNm(DaoUtil.convertNullToString(rs.getString("clsGNm")));
        dto.setClsHCd(DaoUtil.convertNullToString(rs.getString("clsHCd")));
        dto.setClsHNm(DaoUtil.convertNullToString(rs.getString("clsHNm")));
        dto.setClsICd(DaoUtil.convertNullToString(rs.getString("clsICd")));
        dto.setClsINm(DaoUtil.convertNullToString(rs.getString("clsINm")));
        dto.setClsJCd(DaoUtil.convertNullToString(rs.getString("clsJCd")));
        dto.setClsJNm(DaoUtil.convertNullToString(rs.getString("clsJNm")));
        dto.setClsKCd(DaoUtil.convertNullToString(rs.getString("clsKCd")));
        dto.setClsKNm(DaoUtil.convertNullToString(rs.getString("clsKNm")));
        dto.setClsLCd(DaoUtil.convertNullToString(rs.getString("clsLCd")));
        dto.setClsLNm(DaoUtil.convertNullToString(rs.getString("clsLNm")));
        dto.setClsMCd(DaoUtil.convertNullToString(rs.getString("clsMCd")));
        dto.setClsMNm(DaoUtil.convertNullToString(rs.getString("clsMNm")));
        dto.setClsNCd(DaoUtil.convertNullToString(rs.getString("clsNCd")));
        dto.setClsNNm(DaoUtil.convertNullToString(rs.getString("clsNNm")));
        dto.setTxtA(DaoUtil.convertNullToString(rs.getString("txtA")));
        dto.setTxtB(DaoUtil.convertNullToString(rs.getString("txtB")));
        dto.setTxtC(DaoUtil.convertNullToString(rs.getString("txtC")));
        dto.setTxtD(DaoUtil.convertNullToString(rs.getString("txtD")));
        dto.setTxtE(DaoUtil.convertNullToString(rs.getString("txtE")));
        dto.setTxtF(DaoUtil.convertNullToString(rs.getString("txtF")));
        dto.setTxtG(DaoUtil.convertNullToString(rs.getString("txtG")));
        dto.setTxtH(DaoUtil.convertNullToString(rs.getString("txtH")));
        dto.setTxtI(DaoUtil.convertNullToString(rs.getString("txtI")));
        dto.setTxtJ(DaoUtil.convertNullToString(rs.getString("txtJ")));
        dto.setTxtK(DaoUtil.convertNullToString(rs.getString("txtK")));
        dto.setTxtL(DaoUtil.convertNullToString(rs.getString("txtL")));
        dto.setTxtM(DaoUtil.convertNullToString(rs.getString("txtM")));
        dto.setTxtN(DaoUtil.convertNullToString(rs.getString("txtN")));
        return dto;
    }

}

