/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * ZZ_UNCREATED_WK Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class ZzUncreatedWkDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * LOGIN_PERSON_ID
     */
    private String loginPersonId;
    /**
     * OPERATION_CD
     */
    private String operationCd;
    /**
     * OWN_GUID
     */
    private String ownGuid;
    /**
     * OWN_PERSON_NAME
     */
    private String ownPersonName;
    /**
     * OWN_PERSON_NAME_KANA
     */
    private String ownPersonNameKana;
    /**
     * OWN_CMPA_CD
     */
    private String ownCmpaCd;
    /**
     * OWN_FULL_DEPT_NM
     */
    private String ownFullDeptNm;
    /**
     * OWN_MAIL_ADDRESS
     */
    private String ownMailAddress;

    /**
     * LOGIN_PERSON_IDを取得する。
     * @return LOGIN_PERSON_ID
     */
    public String getLoginPersonId() {
        return loginPersonId;
    }

    /**
     * LOGIN_PERSON_IDを設定する。
     * @param loginPersonId LOGIN_PERSON_ID
     */
    public void setLoginPersonId(String loginPersonId) {
        this.loginPersonId = loginPersonId;
    }

    /**
     * OPERATION_CDを取得する。
     * @return OPERATION_CD
     */
    public String getOperationCd() {
        return operationCd;
    }

    /**
     * OPERATION_CDを設定する。
     * @param operationCd OPERATION_CD
     */
    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    /**
     * OWN_GUIDを取得する。
     * @return OWN_GUID
     */
    public String getOwnGuid() {
        return ownGuid;
    }

    /**
     * OWN_GUIDを設定する。
     * @param ownGuid OWN_GUID
     */
    public void setOwnGuid(String ownGuid) {
        this.ownGuid = ownGuid;
    }

    /**
     * OWN_PERSON_NAMEを取得する。
     * @return OWN_PERSON_NAME
     */
    public String getOwnPersonName() {
        return ownPersonName;
    }

    /**
     * OWN_PERSON_NAMEを設定する。
     * @param ownPersonName OWN_PERSON_NAME
     */
    public void setOwnPersonName(String ownPersonName) {
        this.ownPersonName = ownPersonName;
    }

    /**
     * OWN_PERSON_NAME_KANAを取得する。
     * @return OWN_PERSON_NAME_KANA
     */
    public String getOwnPersonNameKana() {
        return ownPersonNameKana;
    }

    /**
     * OWN_PERSON_NAME_KANAを設定する。
     * @param ownPersonNameKana OWN_PERSON_NAME_KANA
     */
    public void setOwnPersonNameKana(String ownPersonNameKana) {
        this.ownPersonNameKana = ownPersonNameKana;
    }

    /**
     * OWN_CMPA_CDを取得する。
     * @return OWN_CMPA_CD
     */
    public String getOwnCmpaCd() {
        return ownCmpaCd;
    }

    /**
     * OWN_CMPA_CDを設定する。
     * @param ownCmpaCd OWN_CMPA_CD
     */
    public void setOwnCmpaCd(String ownCmpaCd) {
        this.ownCmpaCd = ownCmpaCd;
    }

    /**
     * OWN_FULL_DEPT_NMを取得する。
     * @return OWN_FULL_DEPT_NM
     */
    public String getOwnFullDeptNm() {
        return ownFullDeptNm;
    }

    /**
     * OWN_FULL_DEPT_NMを設定する。
     * @param ownFullDeptNm OWN_FULL_DEPT_NM
     */
    public void setOwnFullDeptNm(String ownFullDeptNm) {
        this.ownFullDeptNm = ownFullDeptNm;
    }

    /**
     * OWN_MAIL_ADDRESSを取得する。
     * @return OWN_MAIL_ADDRESS
     */
    public String getOwnMailAddress() {
        return ownMailAddress;
    }

    /**
     * OWN_MAIL_ADDRESSを設定する。
     * @param ownMailAddress OWN_MAIL_ADDRESS
     */
    public void setOwnMailAddress(String ownMailAddress) {
        this.ownMailAddress = ownMailAddress;
    }

}

