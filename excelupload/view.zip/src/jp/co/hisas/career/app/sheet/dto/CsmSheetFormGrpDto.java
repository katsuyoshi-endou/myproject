/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSM書式グループ Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetFormGrpDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PARTY
     */
    private String party;
    /**
     * 運用コード
     */
    private String operationCd;
    /**
     * 書式グループコード
     */
    private String formGrpCd;
    /**
     * 書式グループ名称
     */
    private String formGrpNm;

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * 運用コードを取得する。
     * @return 運用コード
     */
    public String getOperationCd() {
        return operationCd;
    }

    /**
     * 運用コードを設定する。
     * @param operationCd 運用コード
     */
    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    /**
     * 書式グループコードを取得する。
     * @return 書式グループコード
     */
    public String getFormGrpCd() {
        return formGrpCd;
    }

    /**
     * 書式グループコードを設定する。
     * @param formGrpCd 書式グループコード
     */
    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    /**
     * 書式グループ名称を取得する。
     * @return 書式グループ名称
     */
    public String getFormGrpNm() {
        return formGrpNm;
    }

    /**
     * 書式グループ名称を設定する。
     * @param formGrpNm 書式グループ名称
     */
    public void setFormGrpNm(String formGrpNm) {
        this.formGrpNm = formGrpNm;
    }

}

