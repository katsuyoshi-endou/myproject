/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSMシート書式 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetFormDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PARTY
     */
    private String party;
    /**
     * OPERATION_CD
     */
    private String operationCd;
    /**
     * FORM_GRP_CD
     */
    private String formGrpCd;
    /**
     * FORM_CTG_CD
     */
    private String formCtgCd;
    /**
     * FORM_CD
     */
    private String formCd;
    /**
     * FORM_NM
     */
    private String formNm;
    /**
     * FORM_SORT
     */
    private String formSort;
    /**
     * LAYOUT_CD
     */
    private String layoutCd;
    /**
     * LABEL_SET_CD
     */
    private String labelSetCd;
    /**
     * PARAM_SET_CD
     */
    private String paramSetCd;
    /**
     * FILL_SET_CD
     */
    private String fillSetCd;
    /**
     * MASK_CD
     */
    private String maskCd;
    /**
     * FLOW_CD
     */
    private String flowCd;
    /**
     * MULTI_FORM_FLG
     */
    private String multiFormFlg;

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * OPERATION_CDを取得する。
     * @return OPERATION_CD
     */
    public String getOperationCd() {
        return operationCd;
    }

    /**
     * OPERATION_CDを設定する。
     * @param operationCd OPERATION_CD
     */
    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    /**
     * FORM_GRP_CDを取得する。
     * @return FORM_GRP_CD
     */
    public String getFormGrpCd() {
        return formGrpCd;
    }

    /**
     * FORM_GRP_CDを設定する。
     * @param formGrpCd FORM_GRP_CD
     */
    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    /**
     * FORM_CTG_CDを取得する。
     * @return FORM_CTG_CD
     */
    public String getFormCtgCd() {
        return formCtgCd;
    }

    /**
     * FORM_CTG_CDを設定する。
     * @param formCtgCd FORM_CTG_CD
     */
    public void setFormCtgCd(String formCtgCd) {
        this.formCtgCd = formCtgCd;
    }

    /**
     * FORM_CDを取得する。
     * @return FORM_CD
     */
    public String getFormCd() {
        return formCd;
    }

    /**
     * FORM_CDを設定する。
     * @param formCd FORM_CD
     */
    public void setFormCd(String formCd) {
        this.formCd = formCd;
    }

    /**
     * FORM_NMを取得する。
     * @return FORM_NM
     */
    public String getFormNm() {
        return formNm;
    }

    /**
     * FORM_NMを設定する。
     * @param formNm FORM_NM
     */
    public void setFormNm(String formNm) {
        this.formNm = formNm;
    }

    /**
     * FORM_SORTを取得する。
     * @return FORM_SORT
     */
    public String getFormSort() {
        return formSort;
    }

    /**
     * FORM_SORTを設定する。
     * @param formSort FORM_SORT
     */
    public void setFormSort(String formSort) {
        this.formSort = formSort;
    }

    /**
     * LAYOUT_CDを取得する。
     * @return LAYOUT_CD
     */
    public String getLayoutCd() {
        return layoutCd;
    }

    /**
     * LAYOUT_CDを設定する。
     * @param layoutCd LAYOUT_CD
     */
    public void setLayoutCd(String layoutCd) {
        this.layoutCd = layoutCd;
    }

    /**
     * LABEL_SET_CDを取得する。
     * @return LABEL_SET_CD
     */
    public String getLabelSetCd() {
        return labelSetCd;
    }

    /**
     * LABEL_SET_CDを設定する。
     * @param labelSetCd LABEL_SET_CD
     */
    public void setLabelSetCd(String labelSetCd) {
        this.labelSetCd = labelSetCd;
    }

    /**
     * PARAM_SET_CDを取得する。
     * @return PARAM_SET_CD
     */
    public String getParamSetCd() {
        return paramSetCd;
    }

    /**
     * PARAM_SET_CDを設定する。
     * @param paramSetCd PARAM_SET_CD
     */
    public void setParamSetCd(String paramSetCd) {
        this.paramSetCd = paramSetCd;
    }

    /**
     * FILL_SET_CDを取得する。
     * @return FILL_SET_CD
     */
    public String getFillSetCd() {
        return fillSetCd;
    }

    /**
     * FILL_SET_CDを設定する。
     * @param fillSetCd FILL_SET_CD
     */
    public void setFillSetCd(String fillSetCd) {
        this.fillSetCd = fillSetCd;
    }

    /**
     * MASK_CDを取得する。
     * @return MASK_CD
     */
    public String getMaskCd() {
        return maskCd;
    }

    /**
     * MASK_CDを設定する。
     * @param maskCd MASK_CD
     */
    public void setMaskCd(String maskCd) {
        this.maskCd = maskCd;
    }

    /**
     * FLOW_CDを取得する。
     * @return FLOW_CD
     */
    public String getFlowCd() {
        return flowCd;
    }

    /**
     * FLOW_CDを設定する。
     * @param flowCd FLOW_CD
     */
    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    /**
     * MULTI_FORM_FLGを取得する。
     * @return MULTI_FORM_FLG
     */
    public String getMultiFormFlg() {
        return multiFormFlg;
    }

    /**
     * MULTI_FORM_FLGを設定する。
     * @param multiFormFlg MULTI_FORM_FLG
     */
    public void setMultiFormFlg(String multiFormFlg) {
        this.multiFormFlg = multiFormFlg;
    }

}

