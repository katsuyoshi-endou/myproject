/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * ZZ_JINIK_SUMMARY_LIST Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class ZzJinikSummaryListDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * LOGIN_PERSON_ID
     */
    private String loginPersonId;
    /**
     * SHEET_ID
     */
    private String sheetId;
    /**
     * OWN_GUID
     */
    private String ownGuid;
    /**
     * WK_IDX
     */
    private Integer wkIdx;
    /**
     * STATUS_CD
     */
    private String statusCd;
    /**
     * STATUS_NM
     */
    private String statusNm;
    /**
     * FILL_SET_CD
     */
    private String fillSetCd;
    /**
     * MASK_CD
     */
    private String maskCd;
    /**
     * OWN_PERSON_NAME
     */
    private String ownPersonName;
    /**
     * FULL_DEPT_NM
     */
    private String fullDeptNm;
    /**
     * HOLD_GUID
     */
    private String holdGuid;
    /**
     * EXCLUSIVE_KEY
     */
    private String exclusiveKey;
    /**
     * FILL_YKSK
     */
    private String fillYksk;
    /**
     * FILL_YKBR
     */
    private String fillYkbr;
    /**
     * FILL_KBNR
     */
    private String fillKbnr;
    /**
     * FILL_WRAI
     */
    private String fillWrai;
    /**
     * FILL_ROTA
     */
    private String fillRota;
    /**
     * FILL_KAIS
     */
    private String fillKais;
    /**
     * FILL_DKBN
     */
    private String fillDkbn;
    /**
     * FILL_KNEN
     */
    private String fillKnen;
    /**
     * FILL_IUMU
     */
    private String fillIumu;
    /**
     * FILL_INEN
     */
    private String fillInen;

    /**
     * LOGIN_PERSON_IDを取得する。
     * @return LOGIN_PERSON_ID
     */
    public String getLoginPersonId() {
        return loginPersonId;
    }

    /**
     * LOGIN_PERSON_IDを設定する。
     * @param loginPersonId LOGIN_PERSON_ID
     */
    public void setLoginPersonId(String loginPersonId) {
        this.loginPersonId = loginPersonId;
    }

    /**
     * SHEET_IDを取得する。
     * @return SHEET_ID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * SHEET_IDを設定する。
     * @param sheetId SHEET_ID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * OWN_GUIDを取得する。
     * @return OWN_GUID
     */
    public String getOwnGuid() {
        return ownGuid;
    }

    /**
     * OWN_GUIDを設定する。
     * @param ownGuid OWN_GUID
     */
    public void setOwnGuid(String ownGuid) {
        this.ownGuid = ownGuid;
    }

    /**
     * WK_IDXを取得する。
     * @return WK_IDX
     */
    public Integer getWkIdx() {
        return wkIdx;
    }

    /**
     * WK_IDXを設定する。
     * @param wkIdx WK_IDX
     */
    public void setWkIdx(Integer wkIdx) {
        this.wkIdx = wkIdx;
    }

    /**
     * STATUS_CDを取得する。
     * @return STATUS_CD
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * STATUS_CDを設定する。
     * @param statusCd STATUS_CD
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * STATUS_NMを取得する。
     * @return STATUS_NM
     */
    public String getStatusNm() {
        return statusNm;
    }

    /**
     * STATUS_NMを設定する。
     * @param statusNm STATUS_NM
     */
    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    /**
     * FILL_SET_CDを取得する。
     * @return FILL_SET_CD
     */
    public String getFillSetCd() {
        return fillSetCd;
    }

    /**
     * FILL_SET_CDを設定する。
     * @param fillSetCd FILL_SET_CD
     */
    public void setFillSetCd(String fillSetCd) {
        this.fillSetCd = fillSetCd;
    }

    /**
     * MASK_CDを取得する。
     * @return MASK_CD
     */
    public String getMaskCd() {
        return maskCd;
    }

    /**
     * MASK_CDを設定する。
     * @param maskCd MASK_CD
     */
    public void setMaskCd(String maskCd) {
        this.maskCd = maskCd;
    }

    /**
     * OWN_PERSON_NAMEを取得する。
     * @return OWN_PERSON_NAME
     */
    public String getOwnPersonName() {
        return ownPersonName;
    }

    /**
     * OWN_PERSON_NAMEを設定する。
     * @param ownPersonName OWN_PERSON_NAME
     */
    public void setOwnPersonName(String ownPersonName) {
        this.ownPersonName = ownPersonName;
    }

    /**
     * FULL_DEPT_NMを取得する。
     * @return FULL_DEPT_NM
     */
    public String getFullDeptNm() {
        return fullDeptNm;
    }

    /**
     * FULL_DEPT_NMを設定する。
     * @param fullDeptNm FULL_DEPT_NM
     */
    public void setFullDeptNm(String fullDeptNm) {
        this.fullDeptNm = fullDeptNm;
    }

    /**
     * HOLD_GUIDを取得する。
     * @return HOLD_GUID
     */
    public String getHoldGuid() {
        return holdGuid;
    }

    /**
     * HOLD_GUIDを設定する。
     * @param holdGuid HOLD_GUID
     */
    public void setHoldGuid(String holdGuid) {
        this.holdGuid = holdGuid;
    }

    /**
     * EXCLUSIVE_KEYを取得する。
     * @return EXCLUSIVE_KEY
     */
    public String getExclusiveKey() {
        return exclusiveKey;
    }

    /**
     * EXCLUSIVE_KEYを設定する。
     * @param exclusiveKey EXCLUSIVE_KEY
     */
    public void setExclusiveKey(String exclusiveKey) {
        this.exclusiveKey = exclusiveKey;
    }

    /**
     * FILL_YKSKを取得する。
     * @return FILL_YKSK
     */
    public String getFillYksk() {
        return fillYksk;
    }

    /**
     * FILL_YKSKを設定する。
     * @param fillYksk FILL_YKSK
     */
    public void setFillYksk(String fillYksk) {
        this.fillYksk = fillYksk;
    }

    /**
     * FILL_YKBRを取得する。
     * @return FILL_YKBR
     */
    public String getFillYkbr() {
        return fillYkbr;
    }

    /**
     * FILL_YKBRを設定する。
     * @param fillYkbr FILL_YKBR
     */
    public void setFillYkbr(String fillYkbr) {
        this.fillYkbr = fillYkbr;
    }

    /**
     * FILL_KBNRを取得する。
     * @return FILL_KBNR
     */
    public String getFillKbnr() {
        return fillKbnr;
    }

    /**
     * FILL_KBNRを設定する。
     * @param fillKbnr FILL_KBNR
     */
    public void setFillKbnr(String fillKbnr) {
        this.fillKbnr = fillKbnr;
    }

    /**
     * FILL_WRAIを取得する。
     * @return FILL_WRAI
     */
    public String getFillWrai() {
        return fillWrai;
    }

    /**
     * FILL_WRAIを設定する。
     * @param fillWrai FILL_WRAI
     */
    public void setFillWrai(String fillWrai) {
        this.fillWrai = fillWrai;
    }

    /**
     * FILL_ROTAを取得する。
     * @return FILL_ROTA
     */
    public String getFillRota() {
        return fillRota;
    }

    /**
     * FILL_ROTAを設定する。
     * @param fillRota FILL_ROTA
     */
    public void setFillRota(String fillRota) {
        this.fillRota = fillRota;
    }

    /**
     * FILL_KAISを取得する。
     * @return FILL_KAIS
     */
    public String getFillKais() {
        return fillKais;
    }

    /**
     * FILL_KAISを設定する。
     * @param fillKais FILL_KAIS
     */
    public void setFillKais(String fillKais) {
        this.fillKais = fillKais;
    }

    /**
     * FILL_DKBNを取得する。
     * @return FILL_DKBN
     */
    public String getFillDkbn() {
        return fillDkbn;
    }

    /**
     * FILL_DKBNを設定する。
     * @param fillDkbn FILL_DKBN
     */
    public void setFillDkbn(String fillDkbn) {
        this.fillDkbn = fillDkbn;
    }

    /**
     * FILL_KNENを取得する。
     * @return FILL_KNEN
     */
    public String getFillKnen() {
        return fillKnen;
    }

    /**
     * FILL_KNENを設定する。
     * @param fillKnen FILL_KNEN
     */
    public void setFillKnen(String fillKnen) {
        this.fillKnen = fillKnen;
    }

    /**
     * FILL_IUMUを取得する。
     * @return FILL_IUMU
     */
    public String getFillIumu() {
        return fillIumu;
    }

    /**
     * FILL_IUMUを設定する。
     * @param fillIumu FILL_IUMU
     */
    public void setFillIumu(String fillIumu) {
        this.fillIumu = fillIumu;
    }

    /**
     * FILL_INENを取得する。
     * @return FILL_INEN
     */
    public String getFillInen() {
        return fillInen;
    }

    /**
     * FILL_INENを設定する。
     * @param fillInen FILL_INEN
     */
    public void setFillInen(String fillInen) {
        this.fillInen = fillInen;
    }

}

