/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.VCstSheetListDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CSTシートリストビュー Data Access Object。
 * @author CareerDaoTool.xla
*/
public class VCstSheetListDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " SHEET_ID as sheetId,"
                     + " PARTY as party,"
                     + " OPERATION_CD as operationCd,"
                     + " OPERATION_NM as operationNm,"
                     + " OPERATION_SORT as operationSort,"
                     + " ACTIVE_FLG as activeFlg,"
                     + " FORM_GRP_CD as formGrpCd,"
                     + " FORM_GRP_NM as formGrpNm,"
                     + " FORM_CD as formCd,"
                     + " FORM_NM as formNm,"
                     + " OWN_GUID as ownGuid,"
                     + " PERSON_NAME as personName,"
                     + " SHEET_SORT as sheetSort,"
                     + " LIST_COL1 as listCol1,"
                     + " LIST_COL2 as listCol2,"
                     + " LIST_COL3 as listCol3,"
                     + " LIST_COL4 as listCol4,"
                     + " LIST_COL5 as listCol5,"
                     + " LIST_COL6 as listCol6,"
                     + " LIST_COL7 as listCol7,"
                     + " LIST_COL8 as listCol8,"
                     + " LIST_COL9 as listCol9,"
                     + " LIST_COL10 as listCol10,"
                     + " STATUS_CD as statusCd,"
                     + " STATUS_NM as statusNm,"
                     + " HOLD_GUID as holdGuid,"
                     + " LATEST_TIMESTAMP as latestTimestamp,"
                     + " DEPT_CD as deptCd"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public VCstSheetListDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public VCstSheetListDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<VCstSheetListDto> V_CST_SHEET_LISTのレコード型データのリスト。
     */ 
    public List<VCstSheetListDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 VCstSheetListDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<VCstSheetListDto> lst = new ArrayList<VCstSheetListDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<VCstSheetListDto> V_CST_SHEET_LISTのレコード型データのリスト。
     */ 
    public List<VCstSheetListDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 VCstSheetListDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private VCstSheetListDto transferRsToDto(ResultSet rs) throws SQLException {

        VCstSheetListDto dto = new VCstSheetListDto();
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setOperationCd(DaoUtil.convertNullToString(rs.getString("operationCd")));
        dto.setOperationNm(DaoUtil.convertNullToString(rs.getString("operationNm")));
        dto.setOperationSort(DaoUtil.convertNullToString(rs.getString("operationSort")));
        dto.setActiveFlg(DaoUtil.convertNullToString(rs.getString("activeFlg")));
        dto.setFormGrpCd(DaoUtil.convertNullToString(rs.getString("formGrpCd")));
        dto.setFormGrpNm(DaoUtil.convertNullToString(rs.getString("formGrpNm")));
        dto.setFormCd(DaoUtil.convertNullToString(rs.getString("formCd")));
        dto.setFormNm(DaoUtil.convertNullToString(rs.getString("formNm")));
        dto.setOwnGuid(DaoUtil.convertNullToString(rs.getString("ownGuid")));
        dto.setPersonName(DaoUtil.convertNullToString(rs.getString("personName")));
        dto.setSheetSort(DaoUtil.convertNullToString(rs.getString("sheetSort")));
        dto.setListCol1(DaoUtil.convertNullToString(rs.getString("listCol1")));
        dto.setListCol2(DaoUtil.convertNullToString(rs.getString("listCol2")));
        dto.setListCol3(DaoUtil.convertNullToString(rs.getString("listCol3")));
        dto.setListCol4(DaoUtil.convertNullToString(rs.getString("listCol4")));
        dto.setListCol5(DaoUtil.convertNullToString(rs.getString("listCol5")));
        dto.setListCol6(DaoUtil.convertNullToString(rs.getString("listCol6")));
        dto.setListCol7(DaoUtil.convertNullToString(rs.getString("listCol7")));
        dto.setListCol8(DaoUtil.convertNullToString(rs.getString("listCol8")));
        dto.setListCol9(DaoUtil.convertNullToString(rs.getString("listCol9")));
        dto.setListCol10(DaoUtil.convertNullToString(rs.getString("listCol10")));
        dto.setStatusCd(DaoUtil.convertNullToString(rs.getString("statusCd")));
        dto.setStatusNm(DaoUtil.convertNullToString(rs.getString("statusNm")));
        dto.setHoldGuid(DaoUtil.convertNullToString(rs.getString("holdGuid")));
        dto.setLatestTimestamp(DaoUtil.convertNullToString(rs.getString("latestTimestamp")));
        dto.setDeptCd(DaoUtil.convertNullToString(rs.getString("deptCd")));
        return dto;
    }

}

