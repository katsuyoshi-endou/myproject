package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.BulkOperSheetListDto;
import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

public class BulkOperSheetEventResult extends AbstractEventResult {

	private List<BulkOperSheetListDto> sheetList = null;
	public List<ValueTextSortDto> divList = null;
	public List<ValueTextSortDto> opeList = null;
	public List<ValueTextSortDto> statusList = null;
	public int hitCnt;

	private String resultMessage = null;
	private String resultErrorMessage = null;

	public List<BulkOperSheetListDto> getSheetList() {
		return sheetList;
	}

	public void setSheetList(List<BulkOperSheetListDto> sheetList) {
		this.sheetList = sheetList;
	}

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage( String resultMessage ) {
		this.resultMessage = resultMessage;
	}

	public String getResultErrorMessage() {
		return resultErrorMessage;
	}

	public void setResultErrorMessage( String resultErrorMessage ) {
		this.resultErrorMessage = resultErrorMessage;
	}
}
