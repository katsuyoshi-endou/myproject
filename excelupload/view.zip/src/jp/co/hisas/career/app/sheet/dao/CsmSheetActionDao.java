/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CsmSheetActionDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CSMシートアクション Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetActionDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " FLOW_CD as flowCd,"
                     + " FLOW_PTN as flowPtn,"
                     + " STATUS_CD as statusCd,"
                     + " ACTOR_CD as actorCd,"
                     + " LPAD_SORT as lpadSort,"
                     + " ACTION_CD as actionCd,"
                     + " ACTION_NM as actionNm,"
                     + " AFTER_STATUS_CD as afterStatusCd,"
                     + " CONFIRM_MSG as confirmMsg,"
                     + " RESULT_MSG as resultMsg,"
                     + " MAIL_TEMPLATE as mailTemplate,"
                     + " USE_DELIV_FLG as useDelivFlg"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CsmSheetActionDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CsmSheetActionDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param flowCd フローコード
     * @param flowPtn フローパターン
     * @param statusCd ステータスコード
     * @param actorCd アクターコード
     * @param actionCd アクションコード
     * @return CsmSheetActionDto CSM_SHEET_ACTIONのレコード型データ。
     */ 
    public CsmSheetActionDto select(String flowCd, String flowPtn, String statusCd, String actorCd, String actionCd) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CSM_SHEET_ACTION"
                         + " WHERE FLOW_CD = ?"
                         + " AND FLOW_PTN = ?"
                         + " AND STATUS_CD = ?"
                         + " AND ACTOR_CD = ?"
                         + " AND ACTION_CD = ?"
                         ;
        Log.sql("【DaoMethod Call】 CsmSheetActionDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, flowCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, flowPtn);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, statusCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, actorCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, actionCd);
            rs = pstmt.executeQuery();
            CsmSheetActionDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<CsmSheetActionDto> CSM_SHEET_ACTIONのレコード型データのリスト。
     */ 
    public List<CsmSheetActionDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CsmSheetActionDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CsmSheetActionDto> lst = new ArrayList<CsmSheetActionDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CsmSheetActionDto> CSM_SHEET_ACTIONのレコード型データのリスト。
     */ 
    public List<CsmSheetActionDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CsmSheetActionDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CsmSheetActionDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmSheetActionDto dto = new CsmSheetActionDto();
        dto.setFlowCd(DaoUtil.convertNullToString(rs.getString("flowCd")));
        dto.setFlowPtn(DaoUtil.convertNullToString(rs.getString("flowPtn")));
        dto.setStatusCd(DaoUtil.convertNullToString(rs.getString("statusCd")));
        dto.setActorCd(DaoUtil.convertNullToString(rs.getString("actorCd")));
        dto.setLpadSort(DaoUtil.convertNullToString(rs.getString("lpadSort")));
        dto.setActionCd(DaoUtil.convertNullToString(rs.getString("actionCd")));
        dto.setActionNm(DaoUtil.convertNullToString(rs.getString("actionNm")));
        dto.setAfterStatusCd(DaoUtil.convertNullToString(rs.getString("afterStatusCd")));
        dto.setConfirmMsg(DaoUtil.convertNullToString(rs.getString("confirmMsg")));
        dto.setResultMsg(DaoUtil.convertNullToString(rs.getString("resultMsg")));
        dto.setMailTemplate(DaoUtil.convertNullToString(rs.getString("mailTemplate")));
        dto.setUseDelivFlg(DaoUtil.convertNullToString(rs.getString("useDelivFlg")));
        return dto;
    }

}

