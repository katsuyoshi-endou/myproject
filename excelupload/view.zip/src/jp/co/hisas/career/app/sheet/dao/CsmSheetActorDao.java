/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CsmSheetActorDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CSMシートアクター Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetActorDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " FLOW_CD as flowCd,"
                     + " ACT_OR_REF as actOrRef,"
                     + " ACTOR_CD as actorCd,"
                     + " ACTOR_NM as actorNm,"
                     + " LPAD_SORT as lpadSort"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CsmSheetActorDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CsmSheetActorDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * Insert文を実行する。
     * @param dto CSM_SHEET_ACTORのデータ。
     */ 
    public void insert(CsmSheetActorDto dto) {

        final String sql = "INSERT INTO CSM_SHEET_ACTOR ("
                         + "FLOW_CD,"
                         + "ACT_OR_REF,"
                         + "ACTOR_CD,"
                         + "ACTOR_NM,"
                         + "LPAD_SORT"
                         + ")VALUES(?,?,?,?,? )"
                         ;
        Log.sql("【DaoMethod Call】 CsmSheetActorDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getFlowCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getActOrRef());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getActorNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getLpadSort());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * 全列update文を実行する。
     * @param dto CSM_SHEET_ACTORのレコード型データ。
     */
    public void update(CsmSheetActorDto dto) {

        final String sql = "UPDATE CSM_SHEET_ACTOR SET "
                         + "ACTOR_CD = ?,"
                         + "ACTOR_NM = ?,"
                         + "LPAD_SORT = ?"
                         + " WHERE FLOW_CD = ?"
                         + " AND ACT_OR_REF = ?"
                         ;
        Log.sql("【DaoMethod Call】 CsmSheetActorDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getActorNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getLpadSort());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getFlowCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getActOrRef());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してdelete文を実行する。
     * @param flowCd フローコード
     * @param actOrRef アクターor参照者
     */ 
    public void delete(String flowCd, String actOrRef) {

        final String sql = "DELETE FROM CSM_SHEET_ACTOR"
                         + " WHERE FLOW_CD = ?"
                         + " AND ACT_OR_REF = ?"
                         ;
        Log.sql("【DaoMethod Call】 CsmSheetActorDao.delete");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, flowCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, actOrRef);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally { 
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param flowCd フローコード
     * @param actOrRef アクターor参照者
     * @return CsmSheetActorDto CSM_SHEET_ACTORのレコード型データ。
     */ 
    public CsmSheetActorDto select(String flowCd, String actOrRef) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CSM_SHEET_ACTOR"
                         + " WHERE FLOW_CD = ?"
                         + " AND ACT_OR_REF = ?"
                         ;
        Log.sql("【DaoMethod Call】 CsmSheetActorDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, flowCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, actOrRef);
            rs = pstmt.executeQuery();
            CsmSheetActorDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<CsmSheetActorDto> CSM_SHEET_ACTORのレコード型データのリスト。
     */ 
    public List<CsmSheetActorDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CsmSheetActorDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CsmSheetActorDto> lst = new ArrayList<CsmSheetActorDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CsmSheetActorDto> CSM_SHEET_ACTORのレコード型データのリスト。
     */ 
    public List<CsmSheetActorDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CsmSheetActorDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param pstmt PreparedStatement
     */ 
    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("【DaoMethod Call】 CsmSheetActorDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param sql SQL文
     */ 
    public void executeDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CsmSheetActorDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CsmSheetActorDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmSheetActorDto dto = new CsmSheetActorDto();
        dto.setFlowCd(DaoUtil.convertNullToString(rs.getString("flowCd")));
        dto.setActOrRef(DaoUtil.convertNullToString(rs.getString("actOrRef")));
        dto.setActorCd(DaoUtil.convertNullToString(rs.getString("actorCd")));
        dto.setActorNm(DaoUtil.convertNullToString(rs.getString("actorNm")));
        dto.setLpadSort(DaoUtil.convertNullToString(rs.getString("lpadSort")));
        return dto;
    }

}

