package jp.co.hisas.career.app.sheet.util;

public class CsSessionKey {

	public static final String CS_SINGLE_SHEET = "CsSingleSheet";

	public static final String CS_SHEET_ID = "CsSheetId";

	public static final String CS_SHEET_TEMPLATE = "CsSheetTemplate";

	public static final String CS_SHEET_TEMPLATE_JS = "CsSheetTemplateJs";

	public static final String CS_SHEET_TEMPLATE_DIR = "CsSheetTemplateDir";

	public static final String CS_SHEET_TEMPLATE_CSPE = "CsSheetTemplateCspe";

	public static final String CS_VIEW_SHEET_ACTOR_CD = "CsViewSheetActorCd";

	public static final String CS_ACTOR_LIST = "CsRefererList";

	public static final String CS_HOLD_ACTOR_LIST = "CsHoldActorList";

	public static final String CS_REFERER_LIST = "CsRefererList";

	public static final String CS_REFERER_MASTER_LIST = "CsRefererMaterList";

	public static final String CS_ACTIVE_OPE_FORM_LIST = "CsActiveOpeFormList";

	public static final String CS_PROGRESS = "CsProgress";

	public static final String PERSON_BELONG_LIST = "PersonBelongList";

	public static final String VHD012_SRCH_COND = "VHD012_SrchCond";

	public static final String VHD021_SRCH_COND = "VHD021_SrchCond";

	public static final String VHD022_SRCH_COND = "VHD022_SrchCond";

	public static final String VHD030_SRCH_COND = "VHD030_SrchCond";

	public static final String VHE020_SRCH_COND = "VHE020_SrchCond";

	public static final String VHG010_SRCH_COND = "VHG010_SrchCond";

	public static final String VHF010_SRCH_COND = "VHF010_SrchCond";

	public static final String VCST_SHEET_DTO_LIST = "VCstSheetDtoList";

	public static final String VCST_SHEET_SINGLE_DTO_LIST = "VCstSheetSingleDtoList";

	public static final String VHF010_APRV_GYOS_LIST = "VHF010_AprvGyosList";

	public static final String VHF010_APRV_SHOK_LIST = "VHF010_AprvShokList";

	public static final String CS_MULTI_SHEET = "CsMultiSheet";

	public static final String CS_MULTI_SHEET_XL = "CsMultiSheetXl";

	public static final String STAT_PROG_OPE_LIST = "StatProgOpeList";

	public static final String STAT_PROG_SECTION_MAP = "StatProgSectionMap";

	public static final String STAT_PROG_SHEET_COUNT_MAP = "StatProgSheetCountMap";

	public static final String STAT_PROG_SHEET_HOLD_MAP = "StatProgSheetHoldMap";

	public static final String GS2KEYS_DTO_LIST = "Gs2keysDtoList";

	public static final String VHG010_SRCH_OPTION_1 = "Vhg010SrchOption1";

	public static final String VHD021_SRCH_OPTION_1 = "Vhd021SrchOption1";

	public static final String VHD021_SRCH_OPTION_2 = "Vhd021SrchOption2";

	public static final String VHD021_SRCH_OPTION_3 = "Vhd021SrchOption3";

	public static final String VHD022_SRCH_OPTION_1 = "Vhd022SrchOption1";

	public static final String VHD022_SRCH_OPTION_2 = "Vhd022SrchOption2";

	public static final String VHE020_SRCH_OPTION_1 = "Vhe020SrchOption1";

	public static final String VHF010_SRCH_OPTION_1 = "Vhf010SrchOption1";

	public static final String VHF010_SRCH_OPTION_2 = "Vhf010SrchOption2";

	public static final String DBPIPE_TGT_TBL = "DBpipeTgtTbl";

	public static final String VSHMEG_ACTOR_LIST = "VSHMEG_ACTOR_LIST";

	public static final String VSHMEG_SELECTED_ACTOR = "VSHMEG_SELECTED_ACTOR";

	public static final String VSHMEG_SHOWING_STNM = "VSHMEG_SHOWING_STNM";

	public static final String VSHMEG_SHOWING_STCD = "VSHMEG_SHOWING_STCD";

	public static final String VSHMEG_SHOWING_OPNM = "VSHMEG_SHOWING_OPNM";

	public static final String CS_MULTI_SEARCHED_STATUSCD = "CS_MULTI_SEARCHED_STATUSCD";

	public static final String VSHJIN_ACTOR_LIST = "VSHJIN_ACTOR_LIST";

	public static final String VSHJIN_SHOWING_OPNM = "VSHJIN_SHOWING_OPNM";

	public static final String VSHJIN_STATUSLIST = "VSHJIN_STATUSLIST";

	public static final String VSHJIN_SHEETLIST = "VSHJIN_SHEETLIST";

	public static final String VSHJIN_ACTIONLIST = "VSHJIN_ACTIONLIST";

	public static final String VSHJIN_LABELSETMAP = "VSHJIN_LABELSETMAP";

	public static final String VSHJIN_OPERATIONCD = "VSHJIN_OPERATIONCD";

	public static final String VSHJIN_JOTAIMAP = "VSHJIN_JOTAIMAP";

	public static final String VSHJIN_CHKNGLIST = "VSHJIN_CHKNGLIST";

	public static final String VSHJIN_TRANS = "VSHJIN_TRANS";
// ADD 2018/06/20 COMTURE VSHUNC_スキルチェックシート未作成者一覧 START
	public static final String VSHUNC_SEARCH = "VSHUNC_SEARCH";
	
	public static final String VSHUNC_RESULT = "VSHUNC_RESULT";
// ADD 2018/06/20 COMTURE VSHUNC_スキルチェックシート未作成者一覧 END

	public static final String BULK_OPER_SHEET = "BulkOperSheet";

	public static final String BULK_OPER_SEARCH_STATUS_CD = "BULK_OPER_SEARCH_STATUS_CD";

	public static final String BULK_OPER_SEARCH_OPER_CD = "BULK_OPER_SEARCH_OPER_CD";

	public static final String VSHBLK_JOTAIMAP = "VSHBLK_JOTAIMAP";

	public static final String BULK_OPER_SELECT_MAP = "BULK_OPER_SELECT_MAP";
}
