/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSMシートアクション Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetActionDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * フローコード
     */
    private String flowCd;
    /**
     * フローパターン
     */
    private String flowPtn;
    /**
     * ステータスコード
     */
    private String statusCd;
    /**
     * アクターコード
     */
    private String actorCd;
    /**
     * アクションソート
     */
    private String lpadSort;
    /**
     * アクションコード
     */
    private String actionCd;
    /**
     * アクション名称
     */
    private String actionNm;
    /**
     * 操作後ステータスコード
     */
    private String afterStatusCd;
    /**
     * 確認メッセージ
     */
    private String confirmMsg;
    /**
     * 処理結果メッセージ
     */
    private String resultMsg;
    /**
     * メールテンプレート
     */
    private String mailTemplate;
    /**
     * 伝言利用フラグ
     */
    private String useDelivFlg;

    /**
     * フローコードを取得する。
     * @return フローコード
     */
    public String getFlowCd() {
        return flowCd;
    }

    /**
     * フローコードを設定する。
     * @param flowCd フローコード
     */
    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    /**
     * フローパターンを取得する。
     * @return フローパターン
     */
    public String getFlowPtn() {
        return flowPtn;
    }

    /**
     * フローパターンを設定する。
     * @param flowPtn フローパターン
     */
    public void setFlowPtn(String flowPtn) {
        this.flowPtn = flowPtn;
    }

    /**
     * ステータスコードを取得する。
     * @return ステータスコード
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * ステータスコードを設定する。
     * @param statusCd ステータスコード
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * アクターコードを取得する。
     * @return アクターコード
     */
    public String getActorCd() {
        return actorCd;
    }

    /**
     * アクターコードを設定する。
     * @param actorCd アクターコード
     */
    public void setActorCd(String actorCd) {
        this.actorCd = actorCd;
    }

    /**
     * アクションソートを取得する。
     * @return アクションソート
     */
    public String getLpadSort() {
        return lpadSort;
    }

    /**
     * アクションソートを設定する。
     * @param lpadSort アクションソート
     */
    public void setLpadSort(String lpadSort) {
        this.lpadSort = lpadSort;
    }

    /**
     * アクションコードを取得する。
     * @return アクションコード
     */
    public String getActionCd() {
        return actionCd;
    }

    /**
     * アクションコードを設定する。
     * @param actionCd アクションコード
     */
    public void setActionCd(String actionCd) {
        this.actionCd = actionCd;
    }

    /**
     * アクション名称を取得する。
     * @return アクション名称
     */
    public String getActionNm() {
        return actionNm;
    }

    /**
     * アクション名称を設定する。
     * @param actionNm アクション名称
     */
    public void setActionNm(String actionNm) {
        this.actionNm = actionNm;
    }

    /**
     * 操作後ステータスコードを取得する。
     * @return 操作後ステータスコード
     */
    public String getAfterStatusCd() {
        return afterStatusCd;
    }

    /**
     * 操作後ステータスコードを設定する。
     * @param afterStatusCd 操作後ステータスコード
     */
    public void setAfterStatusCd(String afterStatusCd) {
        this.afterStatusCd = afterStatusCd;
    }

    /**
     * 確認メッセージを取得する。
     * @return 確認メッセージ
     */
    public String getConfirmMsg() {
        return confirmMsg;
    }

    /**
     * 確認メッセージを設定する。
     * @param confirmMsg 確認メッセージ
     */
    public void setConfirmMsg(String confirmMsg) {
        this.confirmMsg = confirmMsg;
    }

    /**
     * 処理結果メッセージを取得する。
     * @return 処理結果メッセージ
     */
    public String getResultMsg() {
        return resultMsg;
    }

    /**
     * 処理結果メッセージを設定する。
     * @param resultMsg 処理結果メッセージ
     */
    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    /**
     * メールテンプレートを取得する。
     * @return メールテンプレート
     */
    public String getMailTemplate() {
        return mailTemplate;
    }

    /**
     * メールテンプレートを設定する。
     * @param mailTemplate メールテンプレート
     */
    public void setMailTemplate(String mailTemplate) {
        this.mailTemplate = mailTemplate;
    }

    /**
     * 伝言利用フラグを取得する。
     * @return 伝言利用フラグ
     */
    public String getUseDelivFlg() {
        return useDelivFlg;
    }

    /**
     * 伝言利用フラグを設定する。
     * @param useDelivFlg 伝言利用フラグ
     */
    public void setUseDelivFlg(String useDelivFlg) {
        this.useDelivFlg = useDelivFlg;
    }

}

