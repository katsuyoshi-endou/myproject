/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * V_CSTシートアクションログ Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VCstSheetActionLogDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * タイムスタンプ
     */
    private String timestamp;
    /**
     * シートID
     */
    private String sheetId;
    /**
     * 氏名
     */
    private String personName;
    /**
     * 評価者氏名
     */
    private String actorNm;
    /**
     * ステータス名
     */
    private String statusNm;
    /**
     * アクションコード
     */
    private String actionCd;
    /**
     * アクション名
     */
    private String actionNm;
    /**
     * コメント
     */
    private String delivMsg;

    /**
     * タイムスタンプを取得する。
     * @return タイムスタンプ
     */
    public String getTimestamp() {
        return timestamp;
    }

    /**
     * タイムスタンプを設定する。
     * @param timestamp タイムスタンプ
     */
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * シートIDを取得する。
     * @return シートID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * シートIDを設定する。
     * @param sheetId シートID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * 氏名を取得する。
     * @return 氏名
     */
    public String getPersonName() {
        return personName;
    }

    /**
     * 氏名を設定する。
     * @param personName 氏名
     */
    public void setPersonName(String personName) {
        this.personName = personName;
    }

    /**
     * 評価者氏名を取得する。
     * @return 評価者氏名
     */
    public String getActorNm() {
        return actorNm;
    }

    /**
     * 評価者氏名を設定する。
     * @param actorNm 評価者氏名
     */
    public void setActorNm(String actorNm) {
        this.actorNm = actorNm;
    }

    /**
     * ステータス名を取得する。
     * @return ステータス名
     */
    public String getStatusNm() {
        return statusNm;
    }

    /**
     * ステータス名を設定する。
     * @param statusNm ステータス名
     */
    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    /**
     * アクションコードを取得する。
     * @return アクションコード
     */
    public String getActionCd() {
        return actionCd;
    }

    /**
     * アクションコードを設定する。
     * @param actionCd アクションコード
     */
    public void setActionCd(String actionCd) {
        this.actionCd = actionCd;
    }

    /**
     * アクション名を取得する。
     * @return アクション名
     */
    public String getActionNm() {
        return actionNm;
    }

    /**
     * アクション名を設定する。
     * @param actionNm アクション名
     */
    public void setActionNm(String actionNm) {
        this.actionNm = actionNm;
    }

    /**
     * コメントを取得する。
     * @return コメント
     */
    public String getDelivMsg() {
        return delivMsg;
    }

    /**
     * コメントを設定する。
     * @param delivMsg コメント
     */
    public void setDelivMsg(String delivMsg) {
        this.delivMsg = delivMsg;
    }

}

