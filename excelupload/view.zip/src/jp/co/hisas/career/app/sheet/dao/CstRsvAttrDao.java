/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CstRsvAttrDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CST_RSV_ATTR Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CstRsvAttrDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " SHEET_ID as sheetId,"
                     + " OWN_PERSON_ID as ownPersonId,"
                     + " OWN_PERSON_NAME as ownPersonName,"
                     + " SHEET_SORT as sheetSort,"
                     + " TERM as term,"
                     + " DEPT_CD as deptCd,"
                     + " DEPT_NM as deptNm,"
                     + " FULL_DEPT_CD as fullDeptCd,"
                     + " FULL_DEPT_NM as fullDeptNm,"
                     + " HIERARCHY as hierarchy,"
                     + " BUMADE_DEPT_CD as bumadeDeptCd,"
                     + " BUMADE_DEPT_NM as bumadeDeptNm,"
                     + " SEARCH_DIV as searchDiv,"
                     + " CLS_A_CD as clsACd,"
                     + " CLS_A_NM as clsANm,"
                     + " CLS_B_CD as clsBCd,"
                     + " CLS_B_NM as clsBNm,"
                     + " CLS_C_CD as clsCCd,"
                     + " CLS_C_NM as clsCNm,"
                     + " CLS_D_CD as clsDCd,"
                     + " CLS_D_NM as clsDNm,"
                     + " CLS_E_CD as clsECd,"
                     + " CLS_E_NM as clsENm,"
                     + " CLS_F_CD as clsFCd,"
                     + " CLS_F_NM as clsFNm,"
                     + " CLS_G_CD as clsGCd,"
                     + " CLS_G_NM as clsGNm,"
                     + " CLS_H_CD as clsHCd,"
                     + " CLS_H_NM as clsHNm,"
                     + " CLS_I_CD as clsICd,"
                     + " CLS_I_NM as clsINm,"
                     + " CLS_J_CD as clsJCd,"
                     + " CLS_J_NM as clsJNm"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CstRsvAttrDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CstRsvAttrDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * Insert文を実行する。
     * @param dto CST_RSV_ATTRのデータ。
     */ 
    public void insert(CstRsvAttrDto dto) {

        final String sql = "INSERT INTO CST_RSV_ATTR ("
                         + "SHEET_ID,"
                         + "OWN_PERSON_ID,"
                         + "OWN_PERSON_NAME,"
                         + "SHEET_SORT,"
                         + "TERM,"
                         + "DEPT_CD,"
                         + "DEPT_NM,"
                         + "FULL_DEPT_CD,"
                         + "FULL_DEPT_NM,"
                         + "HIERARCHY,"
                         + "BUMADE_DEPT_CD,"
                         + "BUMADE_DEPT_NM,"
                         + "SEARCH_DIV,"
                         + "CLS_A_CD,"
                         + "CLS_A_NM,"
                         + "CLS_B_CD,"
                         + "CLS_B_NM,"
                         + "CLS_C_CD,"
                         + "CLS_C_NM,"
                         + "CLS_D_CD,"
                         + "CLS_D_NM,"
                         + "CLS_E_CD,"
                         + "CLS_E_NM,"
                         + "CLS_F_CD,"
                         + "CLS_F_NM,"
                         + "CLS_G_CD,"
                         + "CLS_G_NM,"
                         + "CLS_H_CD,"
                         + "CLS_H_NM,"
                         + "CLS_I_CD,"
                         + "CLS_I_NM,"
                         + "CLS_J_CD,"
                         + "CLS_J_NM"
                         + ")VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? )"
                         ;
        Log.sql("【DaoMethod Call】 CstRsvAttrDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getSheetId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getOwnPersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getOwnPersonName());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getSheetSort());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getTerm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getDeptCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getDeptNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 8, dto.getFullDeptCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 9, dto.getFullDeptNm());
            DaoUtil.setIntToPreparedStatement(pstmt, 10, dto.getHierarchy());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 11, dto.getBumadeDeptCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 12, dto.getBumadeDeptNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 13, dto.getSearchDiv());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 14, dto.getClsACd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 15, dto.getClsANm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 16, dto.getClsBCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 17, dto.getClsBNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 18, dto.getClsCCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 19, dto.getClsCNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 20, dto.getClsDCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 21, dto.getClsDNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 22, dto.getClsECd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 23, dto.getClsENm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 24, dto.getClsFCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 25, dto.getClsFNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 26, dto.getClsGCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 27, dto.getClsGNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 28, dto.getClsHCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 29, dto.getClsHNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 30, dto.getClsICd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 31, dto.getClsINm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 32, dto.getClsJCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 33, dto.getClsJNm());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * 全列update文を実行する。
     * @param dto CST_RSV_ATTRのレコード型データ。
     */
    public void update(CstRsvAttrDto dto) {

        final String sql = "UPDATE CST_RSV_ATTR SET "
                         + "OWN_PERSON_ID = ?,"
                         + "OWN_PERSON_NAME = ?,"
                         + "SHEET_SORT = ?,"
                         + "TERM = ?,"
                         + "DEPT_CD = ?,"
                         + "DEPT_NM = ?,"
                         + "FULL_DEPT_CD = ?,"
                         + "FULL_DEPT_NM = ?,"
                         + "HIERARCHY = ?,"
                         + "BUMADE_DEPT_CD = ?,"
                         + "BUMADE_DEPT_NM = ?,"
                         + "SEARCH_DIV = ?,"
                         + "CLS_A_CD = ?,"
                         + "CLS_A_NM = ?,"
                         + "CLS_B_CD = ?,"
                         + "CLS_B_NM = ?,"
                         + "CLS_C_CD = ?,"
                         + "CLS_C_NM = ?,"
                         + "CLS_D_CD = ?,"
                         + "CLS_D_NM = ?,"
                         + "CLS_E_CD = ?,"
                         + "CLS_E_NM = ?,"
                         + "CLS_F_CD = ?,"
                         + "CLS_F_NM = ?,"
                         + "CLS_G_CD = ?,"
                         + "CLS_G_NM = ?,"
                         + "CLS_H_CD = ?,"
                         + "CLS_H_NM = ?,"
                         + "CLS_I_CD = ?,"
                         + "CLS_I_NM = ?,"
                         + "CLS_J_CD = ?,"
                         + "CLS_J_NM = ?"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstRsvAttrDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getOwnPersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getOwnPersonName());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getSheetSort());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getTerm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getDeptCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getDeptNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getFullDeptCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 8, dto.getFullDeptNm());
            DaoUtil.setIntToPreparedStatement(pstmt, 9, dto.getHierarchy());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 10, dto.getBumadeDeptCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 11, dto.getBumadeDeptNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 12, dto.getSearchDiv());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 13, dto.getClsACd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 14, dto.getClsANm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 15, dto.getClsBCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 16, dto.getClsBNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 17, dto.getClsCCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 18, dto.getClsCNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 19, dto.getClsDCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 20, dto.getClsDNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 21, dto.getClsECd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 22, dto.getClsENm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 23, dto.getClsFCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 24, dto.getClsFNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 25, dto.getClsGCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 26, dto.getClsGNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 27, dto.getClsHCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 28, dto.getClsHNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 29, dto.getClsICd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 30, dto.getClsINm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 31, dto.getClsJCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 32, dto.getClsJNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 33, dto.getSheetId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してdelete文を実行する。
     * @param sheetId シートID
     */ 
    public void delete(String sheetId) {

        final String sql = "DELETE FROM CST_RSV_ATTR"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstRsvAttrDao.delete");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally { 
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param sheetId シートID
     * @return CstRsvAttrDto CST_RSV_ATTRのレコード型データ。
     */ 
    public CstRsvAttrDto select(String sheetId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CST_RSV_ATTR"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstRsvAttrDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            rs = pstmt.executeQuery();
            CstRsvAttrDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<CstRsvAttrDto> CST_RSV_ATTRのレコード型データのリスト。
     */ 
    public List<CstRsvAttrDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CstRsvAttrDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CstRsvAttrDto> lst = new ArrayList<CstRsvAttrDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CstRsvAttrDto> CST_RSV_ATTRのレコード型データのリスト。
     */ 
    public List<CstRsvAttrDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CstRsvAttrDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param pstmt PreparedStatement
     */ 
    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("【DaoMethod Call】 CstRsvAttrDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param sql SQL文
     */ 
    public void executeDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CstRsvAttrDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CstRsvAttrDto transferRsToDto(ResultSet rs) throws SQLException {

        CstRsvAttrDto dto = new CstRsvAttrDto();
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setOwnPersonId(DaoUtil.convertNullToString(rs.getString("ownPersonId")));
        dto.setOwnPersonName(DaoUtil.convertNullToString(rs.getString("ownPersonName")));
        dto.setSheetSort(DaoUtil.convertNullToString(rs.getString("sheetSort")));
        dto.setTerm(DaoUtil.convertNullToString(rs.getString("term")));
        dto.setDeptCd(DaoUtil.convertNullToString(rs.getString("deptCd")));
        dto.setDeptNm(DaoUtil.convertNullToString(rs.getString("deptNm")));
        dto.setFullDeptCd(DaoUtil.convertNullToString(rs.getString("fullDeptCd")));
        dto.setFullDeptNm(DaoUtil.convertNullToString(rs.getString("fullDeptNm")));
        dto.setHierarchy(rs.getInt("hierarchy"));
        dto.setBumadeDeptCd(DaoUtil.convertNullToString(rs.getString("bumadeDeptCd")));
        dto.setBumadeDeptNm(DaoUtil.convertNullToString(rs.getString("bumadeDeptNm")));
        dto.setSearchDiv(DaoUtil.convertNullToString(rs.getString("searchDiv")));
        dto.setClsACd(DaoUtil.convertNullToString(rs.getString("clsACd")));
        dto.setClsANm(DaoUtil.convertNullToString(rs.getString("clsANm")));
        dto.setClsBCd(DaoUtil.convertNullToString(rs.getString("clsBCd")));
        dto.setClsBNm(DaoUtil.convertNullToString(rs.getString("clsBNm")));
        dto.setClsCCd(DaoUtil.convertNullToString(rs.getString("clsCCd")));
        dto.setClsCNm(DaoUtil.convertNullToString(rs.getString("clsCNm")));
        dto.setClsDCd(DaoUtil.convertNullToString(rs.getString("clsDCd")));
        dto.setClsDNm(DaoUtil.convertNullToString(rs.getString("clsDNm")));
        dto.setClsECd(DaoUtil.convertNullToString(rs.getString("clsECd")));
        dto.setClsENm(DaoUtil.convertNullToString(rs.getString("clsENm")));
        dto.setClsFCd(DaoUtil.convertNullToString(rs.getString("clsFCd")));
        dto.setClsFNm(DaoUtil.convertNullToString(rs.getString("clsFNm")));
        dto.setClsGCd(DaoUtil.convertNullToString(rs.getString("clsGCd")));
        dto.setClsGNm(DaoUtil.convertNullToString(rs.getString("clsGNm")));
        dto.setClsHCd(DaoUtil.convertNullToString(rs.getString("clsHCd")));
        dto.setClsHNm(DaoUtil.convertNullToString(rs.getString("clsHNm")));
        dto.setClsICd(DaoUtil.convertNullToString(rs.getString("clsICd")));
        dto.setClsINm(DaoUtil.convertNullToString(rs.getString("clsINm")));
        dto.setClsJCd(DaoUtil.convertNullToString(rs.getString("clsJCd")));
        dto.setClsJNm(DaoUtil.convertNullToString(rs.getString("clsJNm")));
        return dto;
    }

}

