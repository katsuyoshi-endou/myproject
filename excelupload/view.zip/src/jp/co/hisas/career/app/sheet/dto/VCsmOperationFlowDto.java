/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * V_CSM_OPERATION_FLOW Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VCsmOperationFlowDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PARTY
     */
    private String party;
    /**
     * OPERATION_CD
     */
    private String operationCd;
    /**
     * OPERATION_NM
     */
    private String operationNm;
    /**
     * OPE_SORT
     */
    private String opeSort;
    /**
     * ACTIVE_FLG
     */
    private String activeFlg;
    /**
     * FORM_GRP_CD
     */
    private String formGrpCd;
    /**
     * FORM_GRP_NM
     */
    private String formGrpNm;
    /**
     * STATUS_GRP_CD
     */
    private String statusGrpCd;
    /**
     * STATUS_GRP_NM
     */
    private String statusGrpNm;
    /**
     * SEQ_NO
     */
    private String seqNo;
    /**
     * STATUS_CD
     */
    private String statusCd;
    /**
     * STATUS_NM
     */
    private String statusNm;

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * OPERATION_CDを取得する。
     * @return OPERATION_CD
     */
    public String getOperationCd() {
        return operationCd;
    }

    /**
     * OPERATION_CDを設定する。
     * @param operationCd OPERATION_CD
     */
    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    /**
     * OPERATION_NMを取得する。
     * @return OPERATION_NM
     */
    public String getOperationNm() {
        return operationNm;
    }

    /**
     * OPERATION_NMを設定する。
     * @param operationNm OPERATION_NM
     */
    public void setOperationNm(String operationNm) {
        this.operationNm = operationNm;
    }

    /**
     * OPE_SORTを取得する。
     * @return OPE_SORT
     */
    public String getOpeSort() {
        return opeSort;
    }

    /**
     * OPE_SORTを設定する。
     * @param opeSort OPE_SORT
     */
    public void setOpeSort(String opeSort) {
        this.opeSort = opeSort;
    }

    /**
     * ACTIVE_FLGを取得する。
     * @return ACTIVE_FLG
     */
    public String getActiveFlg() {
        return activeFlg;
    }

    /**
     * ACTIVE_FLGを設定する。
     * @param activeFlg ACTIVE_FLG
     */
    public void setActiveFlg(String activeFlg) {
        this.activeFlg = activeFlg;
    }

    /**
     * FORM_GRP_CDを取得する。
     * @return FORM_GRP_CD
     */
    public String getFormGrpCd() {
        return formGrpCd;
    }

    /**
     * FORM_GRP_CDを設定する。
     * @param formGrpCd FORM_GRP_CD
     */
    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    /**
     * FORM_GRP_NMを取得する。
     * @return FORM_GRP_NM
     */
    public String getFormGrpNm() {
        return formGrpNm;
    }

    /**
     * FORM_GRP_NMを設定する。
     * @param formGrpNm FORM_GRP_NM
     */
    public void setFormGrpNm(String formGrpNm) {
        this.formGrpNm = formGrpNm;
    }

    /**
     * STATUS_GRP_CDを取得する。
     * @return STATUS_GRP_CD
     */
    public String getStatusGrpCd() {
        return statusGrpCd;
    }

    /**
     * STATUS_GRP_CDを設定する。
     * @param statusGrpCd STATUS_GRP_CD
     */
    public void setStatusGrpCd(String statusGrpCd) {
        this.statusGrpCd = statusGrpCd;
    }

    /**
     * STATUS_GRP_NMを取得する。
     * @return STATUS_GRP_NM
     */
    public String getStatusGrpNm() {
        return statusGrpNm;
    }

    /**
     * STATUS_GRP_NMを設定する。
     * @param statusGrpNm STATUS_GRP_NM
     */
    public void setStatusGrpNm(String statusGrpNm) {
        this.statusGrpNm = statusGrpNm;
    }

    /**
     * SEQ_NOを取得する。
     * @return SEQ_NO
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * SEQ_NOを設定する。
     * @param seqNo SEQ_NO
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * STATUS_CDを取得する。
     * @return STATUS_CD
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * STATUS_CDを設定する。
     * @param statusCd STATUS_CD
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * STATUS_NMを取得する。
     * @return STATUS_NM
     */
    public String getStatusNm() {
        return statusNm;
    }

    /**
     * STATUS_NMを設定する。
     * @param statusNm STATUS_NM
     */
    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

}

