/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSX_SHEET_STATUS Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsxSheetStatusDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * シートID
     */
    private String sheetId;
    /**
     * フローコード
     */
    private String flowCd;
    /**
     * シーケンスNo
     */
    private String seqNo;
    /**
     * ステータスコード
     */
    private String statusCd;
    /**
     * ステータス名称
     */
    private String statusNm;
    /**
     * メインアクターコード
     */
    private String mainActorCd;
    /**
     * メインアクター人ID
     */
    private String mainPersonId;
    /**
     * メインアクター氏名
     */
    private String mainPersonName;
    /**
     * 処理者人ID
     */
    private String donePersonId;
    /**
     * 処理者氏名
     */
    private String donePersonName;
    /**
     * 処理タイムスタンプ
     */
    private String timestamp;

    /**
     * シートIDを取得する。
     * @return シートID
     */
    public String getSheetId() {
        return sheetId;
    }

    /**
     * シートIDを設定する。
     * @param sheetId シートID
     */
    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    /**
     * フローコードを取得する。
     * @return フローコード
     */
    public String getFlowCd() {
        return flowCd;
    }

    /**
     * フローコードを設定する。
     * @param flowCd フローコード
     */
    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    /**
     * シーケンスNoを取得する。
     * @return シーケンスNo
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * シーケンスNoを設定する。
     * @param seqNo シーケンスNo
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * ステータスコードを取得する。
     * @return ステータスコード
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * ステータスコードを設定する。
     * @param statusCd ステータスコード
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * ステータス名称を取得する。
     * @return ステータス名称
     */
    public String getStatusNm() {
        return statusNm;
    }

    /**
     * ステータス名称を設定する。
     * @param statusNm ステータス名称
     */
    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    /**
     * メインアクターコードを取得する。
     * @return メインアクターコード
     */
    public String getMainActorCd() {
        return mainActorCd;
    }

    /**
     * メインアクターコードを設定する。
     * @param mainActorCd メインアクターコード
     */
    public void setMainActorCd(String mainActorCd) {
        this.mainActorCd = mainActorCd;
    }

    /**
     * メインアクター人IDを取得する。
     * @return メインアクター人ID
     */
    public String getMainPersonId() {
        return mainPersonId;
    }

    /**
     * メインアクター人IDを設定する。
     * @param mainPersonId メインアクター人ID
     */
    public void setMainPersonId(String mainPersonId) {
        this.mainPersonId = mainPersonId;
    }

    /**
     * メインアクター氏名を取得する。
     * @return メインアクター氏名
     */
    public String getMainPersonName() {
        return mainPersonName;
    }

    /**
     * メインアクター氏名を設定する。
     * @param mainPersonName メインアクター氏名
     */
    public void setMainPersonName(String mainPersonName) {
        this.mainPersonName = mainPersonName;
    }

    /**
     * 処理者人IDを取得する。
     * @return 処理者人ID
     */
    public String getDonePersonId() {
        return donePersonId;
    }

    /**
     * 処理者人IDを設定する。
     * @param donePersonId 処理者人ID
     */
    public void setDonePersonId(String donePersonId) {
        this.donePersonId = donePersonId;
    }

    /**
     * 処理者氏名を取得する。
     * @return 処理者氏名
     */
    public String getDonePersonName() {
        return donePersonName;
    }

    /**
     * 処理者氏名を設定する。
     * @param donePersonName 処理者氏名
     */
    public void setDonePersonName(String donePersonName) {
        this.donePersonName = donePersonName;
    }

    /**
     * 処理タイムスタンプを取得する。
     * @return 処理タイムスタンプ
     */
    public String getTimestamp() {
        return timestamp;
    }

    /**
     * 処理タイムスタンプを設定する。
     * @param timestamp 処理タイムスタンプ
     */
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

}

