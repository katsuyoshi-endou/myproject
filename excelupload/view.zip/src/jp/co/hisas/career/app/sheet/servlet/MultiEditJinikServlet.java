package jp.co.hisas.career.app.sheet.servlet;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.bean.MultiJinikPrepareSearchBean;
import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.app.sheet.event.CsSheetEventArg;
import jp.co.hisas.career.app.sheet.event.CsSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.CsSheetEventResult;
import jp.co.hisas.career.app.sheet.event.MultiCheckJinikEvArg;
import jp.co.hisas.career.app.sheet.event.MultiCheckJinikEvHdlr;
import jp.co.hisas.career.app.sheet.event.MultiCheckJinikEvRslt;
import jp.co.hisas.career.app.sheet.event.MultiEditJinikEvArg;
import jp.co.hisas.career.app.sheet.event.MultiEditJinikEvHdlr;
import jp.co.hisas.career.app.sheet.event.MultiEditJinikEvRslt;
import jp.co.hisas.career.app.sheet.util.CsMultiSheet;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.app.sheet.vm.VmVSHJIN;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.NewTokenServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class MultiEditJinikServlet extends NewTokenServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "VSHJIN";
	private static final String FORWARD_PAGE = "/view/sheet/layout_multi/MultiEditJinik.jsp";
	
	public String serviceMain( Tray tray ) throws CareerException {
		
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( tray.session, UserInfoBean.SESSION_KEY );
		tray.operatorGuid = userInfo.getOperatorGuid();
		
		VmVSHJIN vm = new VmVSHJIN( tray );
		Map<String, String> jotaiMap = new HashMap<String, String>();
		
		if (SU.equals( tray.state, "INIT" )) {
			
			// 人材RSLTを作成
			List<ValueTextSortDto> statusList = execMultiSheetSearch( tray );
			
			MultiEditJinikEvRslt result = execStateInit( tray );
			
			String operationCd = CsUtil.getRequestValue( tray.request, "operationCd" );
			tray.session.setAttribute( CsSessionKey.VSHJIN_OPERATIONCD, operationCd );
			
			String selectedActor = null;
			if (result.actorList.size() > 0) {
				selectedActor = result.actorList.get( 0 ).getValue();
			}
			tray.session.setAttribute( CsSessionKey.VSHJIN_ACTOR_LIST, result.actorList );
			
			String selectedStatusCd = AU.getRequestValue( tray.request, "showingStatusCd" );
			tray.session.setAttribute( CsSessionKey.VSHJIN_STATUSLIST, statusList );
			
			String showingOperationNm = AU.getRequestValue( tray.request, "showingOperationNm" );
			tray.session.setAttribute( CsSessionKey.VSHJIN_SHOWING_OPNM, showingOperationNm );
			
			jotaiMap.put( "actorCd", selectedActor );
			jotaiMap.put( "statusCd", selectedStatusCd );
			jotaiMap.put( "operationCd", operationCd );
			tray.session.setAttribute( CsSessionKey.VSHJIN_JOTAIMAP, jotaiMap );
			
			// 単票に遷移した場合の戻るボタン用
			tray.session.setAttribute( CsSessionKey.VSHJIN_TRANS, "TRANS-VSHJIN" );
		}
		
		else if (SU.equals( tray.state, "SHOW" )) {
			putJotaiMapFromRequest( tray, jotaiMap );
			tray.session.setAttribute( CsSessionKey.VSHJIN_JOTAIMAP, jotaiMap );
		}
		else if (SU.equals( tray.state, "MULTI" )) {
			jotaiMap = AU.getSessionAttr( tray.session, CsSessionKey.VSHJIN_JOTAIMAP );
			Set<String> chkNgSheetIdSet = execStateMulti( tray, userInfo );
			tray.request.setAttribute( CsSessionKey.VSHJIN_CHKNGLIST, chkNgSheetIdSet );
		}
		else if (SU.equals( tray.state, "RESTORE" )) {
			//単票から遷移した場合
			jotaiMap = AU.getSessionAttr( tray.session, CsSessionKey.VSHJIN_JOTAIMAP );
		}
		else if (SU.equals( tray.state, "TRANS_CSMULTI" )) {
			
			tray.session.removeAttribute( CsSessionKey.VSHJIN_OPERATIONCD );
			tray.session.removeAttribute( CsSessionKey.VSHJIN_ACTOR_LIST );
			tray.session.removeAttribute( CsSessionKey.VSHJIN_STATUSLIST );
			tray.session.removeAttribute( CsSessionKey.VSHJIN_SHOWING_OPNM );
			tray.session.removeAttribute( CsSessionKey.VSHJIN_JOTAIMAP );
			tray.session.removeAttribute( CsSessionKey.VSHJIN_TRANS );
			tray.forwardUrl = "/servlet/CsMultiSheetServlet";
		}
		
		vm.jotaiMap = jotaiMap;
		AU.setReqAttr( tray.request, VmVSHJIN.VMID, vm );
		
		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, tray.state );
		
		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}
	
	private void putJotaiMapFromRequest( Tray tray, Map<String, String> jotaiMap ) {
		jotaiMap.put( "operationCd", AU.getRequestValue( tray.request, "operationCd" ) );
		jotaiMap.put( "actorCd", AU.getRequestValue( tray.request, "actorCd" ) );
		jotaiMap.put( "statusCd", AU.getRequestValue( tray.request, "statusCd" ) );
		jotaiMap.put( "knskCondYksk", AU.getRequestValue( tray.request, "knskCondYksk" ) );
		jotaiMap.put( "knskCondYkskBnri", AU.getRequestValue( tray.request, "knskCondYkskBnri" ) );
		jotaiMap.put( "knskRotationKbn", AU.getRequestValue( tray.request, "knskRotationKbn" ) );
		jotaiMap.put( "knskKeikanen", AU.getRequestValue( tray.request, "knskKeikanen" ) );
		jotaiMap.put( "knskKeikanenOpe", AU.getRequestValue( tray.request, "knskKeikanenOpe" ) );
		jotaiMap.put( "knskIdoUmu", AU.getRequestValue( tray.request, "knskIdoUmu" ) );
		jotaiMap.put( "knskIdoChokkin", AU.getRequestValue( tray.request, "knskIdoChokkin" ) );
		jotaiMap.put( "knskTaishoku", AU.getRequestValue( tray.request, "knskTaishoku" ) );
		jotaiMap.put( "knskShokumu", AU.getRequestValue( tray.request, "knskShokumu" ) );
		jotaiMap.put( "knskJigyojo", AU.getRequestValue( tray.request, "knskJigyojo" ) );
		jotaiMap.put( "knskKyoten", AU.getRequestValue( tray.request, "knskKyoten" ) );
	}
	
	private List<ValueTextSortDto> execMultiSheetSearch( Tray tray ) throws CareerException {
		MultiJinikPrepareSearchBean bean = new MultiJinikPrepareSearchBean( tray.loginNo, tray.operatorGuid );
		CsMultiSheet csMultiSheet = bean.execMultiSheetSearch( tray );
		return csMultiSheet.statusList;
	}
	
	private MultiEditJinikEvRslt execStateInit( Tray tray ) throws CareerException {
		MultiEditJinikEvArg arg = new MultiEditJinikEvArg( tray.loginNo );
		arg.sharp = "INIT";
		arg.operatorGuid = tray.operatorGuid;
		arg.loginGuid = tray.loginNo;
		MultiEditJinikEvRslt result = MultiEditJinikEvHdlr.exec( arg );
		
		return result;
	}
	
	/**
	 * 業務区分調査流用
	 */
	private Set<String> execStateMulti( Tray tray, UserInfoBean userInfo ) throws CareerException {
		String actionCd = AU.getRequestValue( tray.request, "action_cd_multi" );
		String statusCd = AU.getRequestValue( tray.request, "status_cd_multi" );
		// 一括にチェックが入っていた場合は、WKから直接
		HashMap<String, String> checkedMap = CsUtil.getRequestsWithRegex( tray.request, "^multi_" );
		
		Set<String> chkNgSheetIdSet = new HashSet<String>();
		
		Set<String> sheetIdSet = new HashSet<String>();
		for (String val : checkedMap.values()) {
			String[] d = val.split( "#" );
			sheetIdSet.add( d[0] );
		}
		if (SU.equals( actionCd, "FORWARD" ) && SU.equals( statusCd, "00-New" )) {
			// 担当業務必須チェック
			chkNgSheetIdSet = detectNGListChkA( sheetIdSet, tray );
			if (chkNgSheetIdSet.size() > 0) {
				String msg = "現在の担当業務を入力してください。";
				tray.session.setAttribute( AppSessionKey.RESULT_MSG_WARN, msg );
				return chkNgSheetIdSet;
			}
		}
		if (SU.equals( actionCd, "SKIP" ) && SU.equals( statusCd, "02-ChkSin" )) {
			// 異動ありチェック
			chkNgSheetIdSet = detectNGListChkB( sheetIdSet, tray );
			if (chkNgSheetIdSet.size() > 0) {
				String msg = "異動した場合は、異動実績を入力してください。";
				tray.session.setAttribute( AppSessionKey.RESULT_MSG_WARN, msg );
				return chkNgSheetIdSet;
			}
		}
		if (SU.equals( actionCd, "FORWARD" ) && SU.equals( statusCd, "02-ChkSin" )) {
			// 異動なしチェック
			chkNgSheetIdSet = detectNGListChkC( sheetIdSet, tray );
			if (chkNgSheetIdSet.size() > 0) {
				String msg = "異動実績は、異動がある場合のみ入力してください。異動していない場合は、異動実績は入力しないでくたさい。";
				tray.session.setAttribute( AppSessionKey.RESULT_MSG_WARN, msg );
				return chkNgSheetIdSet;
			}
		}
		
		// シートアクション実行
		String chkNgSheetId = null;
		for (String val : checkedMap.values()) {
			String[] d = val.split( "#" );
			String sheetId = d[0];
			String excKey = d[1];
			chkNgSheetId = callCsSheetEvent( actionCd, tray, userInfo, sheetId, excKey );
			if (!SU.isBlank( chkNgSheetId )){
				chkNgSheetIdSet.add( chkNgSheetId );
			}
		}
		return chkNgSheetIdSet;
	}
	
	private Set<String> detectNGListChkA( Set<String> sheetIdSet, Tray tray ) throws CareerException {
		Set<String> chkNgSheetIdSet = new HashSet<String>(sheetIdSet);
		MultiCheckJinikEvArg arg = new MultiCheckJinikEvArg( tray.loginNo );
		arg.sharp = "CHECK_A";
		MultiCheckJinikEvRslt result = MultiCheckJinikEvHdlr.exec( arg );
		chkNgSheetIdSet.retainAll( result.chkNgSheetIdSet );
		return chkNgSheetIdSet;
	}
	
	private Set<String> detectNGListChkB( Set<String> sheetIdSet, Tray tray ) throws CareerException {
		Set<String> chkNgSheetIdSet = new HashSet<String>(sheetIdSet);
		MultiCheckJinikEvArg arg = new MultiCheckJinikEvArg( tray.loginNo );
		arg.sharp = "CHECK_B";
		MultiCheckJinikEvRslt result = MultiCheckJinikEvHdlr.exec( arg );
		chkNgSheetIdSet.retainAll( result.chkNgSheetIdSet );
		return chkNgSheetIdSet;
	}
	
	private Set<String> detectNGListChkC( Set<String> sheetIdSet, Tray tray ) throws CareerException {
		Set<String> chkNgSheetIdSet = new HashSet<String>(sheetIdSet);
		MultiCheckJinikEvArg arg = new MultiCheckJinikEvArg( tray.loginNo );
		arg.sharp = "CHECK_C";
		MultiCheckJinikEvRslt result = MultiCheckJinikEvHdlr.exec( arg );
		chkNgSheetIdSet.retainAll( result.chkNgSheetIdSet );
		return chkNgSheetIdSet;
	}
	
	private String callCsSheetEvent( String actionCd, Tray tray, UserInfoBean userInfo, String sheetId, String exclusiveKey ) throws CareerException {
		// Requestの中から Fill-- で始まるもののみを抽出 (Prefix will be removed)
		HashMap<String, String> fillReqMap = CsUtil.getRequestsWithRegex( tray.request, "^Fill--" );
		
		CsSheetEventArg arg = new CsSheetEventArg( tray.loginNo, tray.operatorGuid );
		arg.sharp = actionCd;
		arg.mailSenderName = userInfo.getKanjiSimei();
		arg.sheetId = sheetId;
		CstSheetExclusiveDto excDto = new CstSheetExclusiveDto();
		excDto.setSheetId( sheetId );
		Integer iExcKey = Integer.parseInt( CsUtil.bvl( exclusiveKey, "0" ) );
		excDto.setExclusiveKey( iExcKey );
		arg.exclusiveKey = excDto;
		arg.fillReqMap = fillReqMap;
		arg.actionCd = actionCd;
		CsSheetEventResult result = CsSheetEventHandler.exec( arg );
		
		String chkNgSheetId = null;
		
		if (!CsUtil.isBlank( result.getResultMessage() )) {
			// ホーム画面に遷移する場合もある(削除時)ため、Request/Sessionどちらにも入れる
			tray.request.setAttribute( AppSessionKey.RESULT_MSG_INFO, result.getResultMessage() );
			tray.session.setAttribute( AppSessionKey.RESULT_MSG_INFO, result.getResultMessage() );
		}
		if (!CsUtil.isBlank( result.getResultErrorMessage() )) {
			// ホーム画面に遷移する場合もある(削除時)ため、Request/Sessionどちらにも入れる
			tray.request.setAttribute( AppSessionKey.RESULT_MSG_ERROR, result.getResultErrorMessage() );
			tray.session.setAttribute( AppSessionKey.RESULT_MSG_ERROR, result.getResultErrorMessage() );
			//排他などのエラーで該当シートの背景色を変えるため、NGリストに格納
			chkNgSheetId = sheetId;
		}
		return chkNgSheetId;
	}
	
}
