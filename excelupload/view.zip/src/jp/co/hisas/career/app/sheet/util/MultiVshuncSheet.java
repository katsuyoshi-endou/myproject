package jp.co.hisas.career.app.sheet.util;

import java.util.HashMap;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.ZzUncreatedWkDto;

public class MultiVshuncSheet {

	public String daoLoginNo;
	public String operatorGuid;
	// 運用名称
	public String operationNm;
	// 画面表示項目用リスト
	public List<ZzUncreatedWkDto> uncreatedsheetList;
	// 画面マップ
	public HashMap<String, String> gamenCondMap;
	// ステータス
	public String status;
	// 検索結果件数
	public int hitCnt;

	public MultiVshuncSheet( String daoLoginNo, String operatorGuid ) {
		this.daoLoginNo = daoLoginNo;
		this.operatorGuid = operatorGuid;
	}

}
