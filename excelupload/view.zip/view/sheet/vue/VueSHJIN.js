function mountVueSHJIN(vm, loginUser) {
  ES6Promise.polyfill();
  var app = new Vue({
    el: '#VueSHJIN',
    data: {
      vm: vm,
      loginUser: loginUser,
      lbl: App.LabelMap,
      mdlLbl: vm._data.ccpLabelSHAWM,
      wkIdxMin: 0,
      wkIdxMax: 100,
      checkedSheets: [],
      isBulkChecked: false,
      isActionNotAllowed: vm.jotaiMap.statusCd == "",
      isShowAwayModal: false,
      picked: null,
      reasonText: "",
      selectedAction: null
    },
    computed: {
      multiActionList: function () {
        var list = _.filter(vm._data.actionList, function(act){
          return act.actionCd !== 'STAY';
        });
        return list;
      },
      showingSheetList: function (){
        var self = this;
        return _.filter(this.vm._data.list, function(sheet) {
          return self.wkIdxMin < sheet.wkIdx && sheet.wkIdx <= self.wkIdxMax;
        });
      },
      sheetidExckeyList: function () {
        var map = {};
        _.each(this.vm._data.list, function(sheet){
          map[sheet.sheetId] = sheet.exclusiveKey;
        });
        return map;
      },
      awayModalRadioLabels: function () {
        var self = this;
        var labelIdList = _.filter(Object.keys(self.mdlLbl), function (labelId) {
          return labelId.match(/LSHAWM_CHG_STATUS_REASON_\d\d/);
        }).sort(function (a,b) {
          if (a < b) return -1;
          if (a > b) return 1;
          return 0;
        });
        var labels = _.map(labelIdList, function (labelId) {
          return { labelId: labelId, text: self.mdlLbl[labelId] };
        });
        return labels;
      },
      isPicked99: function () {
        return this.picked && this.picked.labelId === "LSHAWM_CHG_STATUS_REASON_99";
      },
      sendReasonText: function () {
        return this.isPicked99 ? this.reasonText : "";
      }
    },
    mounted: function () {
      $('[data-toggle="tooltip"]').tooltip();
      this.initPositionAwayModal();
    },
    updated: function () {
    },
    methods: {
      onScroll: function(e) {
        var deg = (e.target.scrollTop + e.target.offsetHeight) / e.target.scrollHeight;
        if (deg > 0.85) {
          this.wkIdxMax = this.wkIdxMax + 50;
        }
        $('.keikaNen').each(function(){
          var $self = $(this);
          if ($self.attr('doitsuKbn') == 1){
            $self.closest('td').css('background-color','#FF0000');
            $self.closest('td').css('color','#FFFFFF');
          }
        });
      },
      toggleBulk: function() {
        if(!this.isBulkChecked){
          this.checkedSheets = [];
        } else {
          this.checkedSheets = _.map(this.vm._data.list, function(sheet){ return sheet.sheetId; });
        }
      },
      doMultiAction: function(act) {
        if ( this.checkedSheets.length == 0 ){
          alert( this.vm.vlMap.LSHJIN_ALERT_01 );
          return false;
        }
        this.selectedAction = act;
        if (act.actionCd === 'AWAY' && !this.isShowAwayModal) {
          this.isShowAwayModal = true;
          return false;
        }
        var confMsg = act.confirmMsg;
        if (confMsg && !confirm(confMsg)) {
          return false;
        }
        // 対象に戻すのは確認メッセージOK後。リクエストパラメータが残ってしまうため。
        if (act.actionCd === 'RESUME' && vm.jotaiMap.statusCd === "99-End" && !this.isShowAwayModal) {
          makeRequestParameter("Fill--change_status_reason", "");
          makeRequestParameter("Fill--change_status_reason_text", "");
        }
        var self = this;
        _.each(this.checkedSheets, function(sheetId, i){
          var sheetIdSharpExckey = sheetId + "#" + self.sheetidExckeyList[sheetId];
          makeRequestParameter('multi_' + i, sheetIdSharpExckey);
        });
        makeRequestParameter('action_cd_multi', act.actionCd );
        makeRequestParameter('status_cd_multi', this.vm.jotaiMap.statusCd );
        pageSubmit('/servlet/MultiEditJinikServlet', 'MULTI');
      },
      initPositionAwayModal: function () {
        var leftPos = ($(document).width() / 2) - 265;
        var topPos  = 150;
        $('.vue-modal-window').css('left', leftPos+'px').css('top', topPos+'px');
      },
      toggleAwayModal: function() {
        this.isShowAwayModal = !this.isShowAwayModal;
      },
      handleAwayModalClickOK: function () {
        if (!this.validateAwayModal()) {
          return false;
        }
        var pickedText = this.picked.text.replace(/<br>/g, "\n");
        makeRequestParameter("Fill--change_status_reason", pickedText);
        this.doMultiAction(this.selectedAction);
      },
      validateAwayModal: function () {
        if (this.isPicked99) {
          if (this.reasonText.length === 0) {
            alert(this.mdlLbl.LSHAWM_MSG_REASON_NEEDED);
            this.$refs.reasonText.focus();
            return false;
          }
          if (this.reasonText.length > 1000) {
            alert(this.mdlLbl.LSHAWM_MSG_REASON_OVERFLOW);
            this.$refs.reasonText.focus();
            return false;
          }
        }
        return true;
      }
    }
  });
}
