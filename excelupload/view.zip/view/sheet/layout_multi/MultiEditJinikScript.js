function execMultiEditJinikJQuery(vm, pulldownList) {

   /**
   ** Initialize
  **/
  $('.csActionBtns [data-actioncd="FORWARD"], .csActionBtns [data-actioncd="SKIP"]').each(function(){
    var $self = $(this);
    if ( $self.hasClass('btn') ) {
      $self.addClass('btn-secondary');
    }
  });

  $('.keikaNen').each(function(){
    var $self = $(this);
    if ($self.attr('doitsuKbn') == 1){
    $self.closest('td').css('background-color','#FF0000');
    $self.closest('td').css('color','#FFFFFF');
    }
  });

  // Pulldowns
  _.each(pulldownList, function(records, pdSetCd){
    _.each(records, function(rec){
      var optionElems = $('<option>', { value: rec.pdValue, text: rec.pdText });
      $('select[data-pulldown="'+pdSetCd+'"]').append(optionElems);
    });
  });
  // 異動計画年度(直近)
  var operationCd = vm.jotaiMap.operationCd;
  var chokkinPdList = [];
  var val = parseInt(operationCd.substr(0, 4));
  chokkinPdList.push($('<option>', { value: "", text: "" }));
  chokkinPdList.push($('<option>', { value: val, text: val }));
  chokkinPdList.push($('<option>', { value: val + 1, text: val + 1 }));
  chokkinPdList.push($('<option>', { value: val + 2, text: val + 2 }));
  chokkinPdList.push($('<option>', { value: val + 3, text: val + 3 }));
  chokkinPdList.push($('<option>', { value: val + 4, text: val + 4 }));
  chokkinPdList.push($('<option>', { value: "未定", text: "未定" }));
  $('select[data-pulldown=jinik_kensaku_ido_chokkin]').append(chokkinPdList);

  /* 入力した検索条件の復元 */
  $('select[name="statusCd"]').val( vm.jotaiMap.statusCd );
  $('select[name="actorCd"]').val( vm.jotaiMap.actorCd );
  $('select[name="knskCondYksk"]'    ).val( vm.jotaiMap.knskCondYksk );
  $('select[name="knskCondYkskBnri"]').val( vm.jotaiMap.knskCondYkskBnri );
  $('select[name="knskRotationKbn"]' ).val( vm.jotaiMap.knskRotationKbn );
  $('select[name="knskKeikanen"]'    ).val( vm.jotaiMap.knskKeikanen );
  $('select[name="knskKeikanenOpe"]' ).val( vm.jotaiMap.knskKeikanenOpe );
  $('select[name="knskIdoUmu"]'      ).val( vm.jotaiMap.knskIdoUmu );
  $('select[name="knskIdoChokkin"]'  ).val( vm.jotaiMap.knskIdoChokkin );
  $('select[name="knskTaishoku"]'    ).val( vm.jotaiMap.knskTaishoku );
  $('select[name="knskShokumu"]'     ).val( vm.jotaiMap.knskShokumu );
  $('select[name="knskJigyojo"]'     ).val( vm.jotaiMap.knskJigyojo );
  $('select[name="knskKyoten"]'      ).val( vm.jotaiMap.knskKyoten );


   /**
   ** Event
  **/

  $(document).on('click', '#transCSMLTI', function(){
    pageSubmit('/servlet/MultiEditJinikServlet', 'TRANS_CSMULTI');
  });

  $(document).on( 'click', '#btnKensaku', function(){
    $('.kensakuDisp').each( function(){
      if($(this).css('display') == 'none'){ 
        $(this).closest('div').show();
      }
      else{
        $(this).closest('div').hide();
      }
    })
  })

  $(document).on( 'click', '#btnRELOAD', function(){
    pageSubmit('/servlet/MultiEditJinikServlet', 'SHOW');
  })

  $(document).on('click', 'a.sheetlink', function(ev){
    ev.preventDefault();
    var sheetId = $(this).attr('data-sheetid');
    showSheet( sheetId );
  });

  $(document).on('click', '#xldownload', function(e){
    e.preventDefault();
    var xlTemplate = $(this).attr('data-xltemplate');
    if (xlTemplate == '') {
      return false;
    }
    var sqlprop = $(this).attr('data-sqlprop');
    if (sqlprop == '') {
      return false;
    }
    downloadXlsxFileWithSqlprop( vm.jotaiMap.operationCd, xlTemplate, sqlprop );
  });

  $(document).on('change', '.hideTrg', function(e){
    $('.hideTgt').css('display', 'none');
    $('.hideTgtCnt').text('');
  });

}

function showSheet(sheetId) {
  document.F001.sheetId.value = sheetId;
  pageSubmit('/servlet/CsSheetServlet', 'INIT');
}

function downloadXlsxFileWithSqlprop(xlTemplatePrefix, xlTemplateId, sqlPropKey) {
  if (!chkTimeout()) { return false; }
  document.F001.action = App.root + "/servlet/CsMultiSheetServlet";
  document.F001.state.value = "EXCEL_DL";
  makeRequestParameter( "xlTemplateType", 'SQLPROP' );
  makeRequestParameter( "xlTemplatePrefix", xlTemplatePrefix );
  makeRequestParameter( "xlTemplateId", xlTemplateId );
  makeRequestParameter( "sqlPropKey", sqlPropKey );
  document.F001.submit();
  showBlockingOverlay();
}
