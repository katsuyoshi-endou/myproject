/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.CommonParameter;

public class CommonParameterEJBBean implements SessionBean {
	
	private SessionContext context = null;
	
	/**
	 * 汎用パラメータの全ての値を返す。
	 * 
	 * @return HashMap 分類IDをキーとし、値にはパラメータIDをキーとしたHashMapを格納。
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashMap find() throws NamingException, SQLException {
		Log.method( "", "IN", "" );
		
		Connection dbConn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			
			dbConn = PZZ040_SQLUtility.getConnection( "" );
			
			final String sql = "SELECT PARAM_BUNRUI_NM, PARAM_ID, PARAM_VALUE, PARAM_NM, PARAM_BIKO " + "FROM CCP_PARAM " + "ORDER BY PARAM_BUNRUI_NM, PARAM_ID";
			
			Log.debug( sql );
			stmt = dbConn.prepareStatement( sql );
			rs = stmt.executeQuery();
			
			String tmpParamBunruiNum = "";
			final HashMap categoryMap = new HashMap();
			HashMap paramIdMap = new HashMap();
			ArrayList list = new ArrayList( CommonParameter.ccpParamColumnSize );
			
			while (rs.next()) {
				list = new ArrayList( CommonParameter.ccpParamColumnSize );
				list.add( rs.getString( "PARAM_BUNRUI_NM" ) );
				list.add( rs.getString( "PARAM_ID" ) );
				list.add( rs.getString( "PARAM_VALUE" ) );
				list.add( rs.getString( "PARAM_NM" ) );
				list.add( rs.getString( "PARAM_BIKO" ) );
				if (tmpParamBunruiNum.equals( "" )) {
					Log.debug( "１件目：" + list.get( 0 ) + ", " + list.get( 1 ) + ", " + list.get( 2 ) + ", " + list.get( 3 ) + ", " + list.get( 4 ) );
					/* １件目 */
					tmpParamBunruiNum = (String)list.get( 0 );
					paramIdMap.put( list.get( 1 ), list );
				} else if (!tmpParamBunruiNum.equals( list.get( 0 ) )) {
					Log.debug( "分類変更：" + list.get( 0 ) + ", " + list.get( 1 ) + ", " + list.get( 2 ) + ", " + list.get( 3 ) + ", " + list.get( 4 ) );
					/* PARAM_BUNRUI_NUMが変わった */
					categoryMap.put( tmpParamBunruiNum, paramIdMap );
					paramIdMap = new HashMap();
					tmpParamBunruiNum = (String)list.get( 0 );
					paramIdMap.put( list.get( 1 ), list );
				} else {
					Log.debug( "通常：" + list.get( 0 ) + ", " + list.get( 1 ) + ", " + list.get( 2 ) + ", " + list.get( 3 ) + ", " + list.get( 4 ) );
					/* PARAM_BUNRUI_NUMに変更なし */
					paramIdMap.put( list.get( 1 ), list );
				}
			}
			if (!tmpParamBunruiNum.equals( "" )) {
				Log.debug( "" );
				categoryMap.put( tmpParamBunruiNum, paramIdMap );
			}
			
			Log.method( "", "OUT", "" );
			return categoryMap;
		} catch (final SQLException sqle) {
			Log.error( "", sqle );
			throw sqle;
		} catch (final NamingException ne) {
			Log.error( "", ne );
			throw ne;
		} catch (final IndexOutOfBoundsException ioobe) {
			Log.error( "", ioobe );
			throw ioobe;
		} finally {
			PZZ040_SQLUtility.closeConnection( "", dbConn, stmt, rs );
		}
	}
	
	public void ejbActivate() throws RemoteException {
		/* Do nothing. */
	}
	
	public void ejbCreate() throws CreateException, RemoteException {
		/* Do nothing. */
	}
	
	public void ejbPassivate() throws RemoteException {
		/* Do nothing. */
	}
	
	public void ejbRemove() throws RemoteException {
		/* Do nothing. */
	}
	
	public SessionContext getSessionContext() {
		return this.context;
	}
	
	public void setSessionContext( final SessionContext val ) throws RemoteException {
		this.context = val;
	}
	
}
