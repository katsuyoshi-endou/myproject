package jp.co.hisas.career.app.common.logic;

import java.text.MessageFormat;
import java.util.Hashtable;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.log.Log;

public class LdapAuth {
	
	public boolean isAuthed;
	public String messageId;
	public String message;
	private String primaryPath;
	private String secondaryPath;
	private String userDn;
	private String baseDn;
	private String filter;
	
	public void authByIdPw( String ldapId, String ldapPw ) {
		try {
			isAuthed = authCore( ldapId, ldapPw );
		} catch (CareerException e) {
			isAuthed = false;
			String msgId = e.getMessage();
			message = getMessage( msgId );
		} catch (NamingException e) {
			Log.error( ldapId, e );
			isAuthed = false;
			message = getMessage( "CA00E110" );
		}
		return;
	}
	
	private boolean authCore( String ldapId, String ldapPw ) throws CareerException, NamingException {
		InitialLdapContext ctx = null;
		try {
			loadLdapProperties();
			
			ctx = getLdapCtx( ldapId, ldapPw );
			NamingEnumeration<SearchResult> searchResult = search( ctx, ldapId );
			if (!searchResult.hasMore()) {
				throw new AuthenticationException();
			}
			
			return true;
			
		} finally {
			if (ctx != null) {
				ctx.close();
			}
		}
	}
	
	private InitialLdapContext getLdapCtx( String reqId, String reqPw ) throws CareerException {
		String principal = MessageFormat.format( userDn, new Object[] { reqId } );
		InitialLdapContext ctxLdapLogin = null;
		boolean try2nd = false;
		try {
			/* Primary */
			Hashtable<String, String> env = makeEnv( primaryPath, principal, reqPw );
			ctxLdapLogin = new InitialLdapContext( env, null );
		} catch (AuthenticationException ae) {
			applyMessageId( ae );
			throw new CareerException( this.messageId );
		} catch (NamingException ne) {
			try2nd = true;
		}
		if (try2nd) {
			try {
				/* Secondary */
				Hashtable<String, String> env = makeEnv( secondaryPath, principal, reqPw );
				ctxLdapLogin = new InitialLdapContext( env, null );
			} catch (AuthenticationException ae) {
				applyMessageId( ae );
				throw new CareerException( this.messageId );
			} catch (NamingException ne) {
				// 認証サーバに接続できませんでした。
				throw new CareerException( "CA00E070" );
			}
		}
		return ctxLdapLogin;
	}
	
	private void applyMessageId( AuthenticationException ae ) {
		// 認証エラーからエラーコードを特定
		String errorCode = getAuthenticationErrorCode( ae );
		if (errorCode == null) {
			messageId = "CA00E110";
		} else if (errorCode.equals( ERROR_LOGON_FAILURE )) {
			messageId = "CA00E080";
		} else if (errorCode.equals( ERROR_INVALID_CREDENTIALS )) {
			messageId = "CA00E080";
		} else if (errorCode.equals( ERROR_PASSWORD_EXPIRED )) {
			messageId = "CA00E140";
		} else if (errorCode.equals( ERROR_ACCOUNT_LOCKED )) {
			messageId = "CA00E090";
		} else if (errorCode.equals( ERROR_MUST_RESET_PASSWORD )) {
			messageId = "CA00E100";
		} else {
			messageId = "CA00E110";
		}
	}
	
	private String getMessage( String msgId ) {
//		return SU.ntb( (String)ReadFile.messageMapData.get( msgId ) );
		return SU.ntb( "Error message ID is: " + msgId );
	}
	
	private void loadLdapProperties() {
		primaryPath   = getLdapProperty( "ldap.path.primary" );
		secondaryPath = getLdapProperty( "ldap.path.secondary" );
		userDn        = getLdapProperty( "ldap.dn.user" );
		baseDn        = getLdapProperty( "ldap.dn.base" );
		filter        = getLdapProperty( "ldap.filter" );
	}
	
	private static String getLdapProperty( String key ) {
//		return SU.ntb( (String)ReadFile.ldapProperties.getProperty( key ) );
		return null;
	}
	
	private Hashtable<String, String> makeEnv( String path, String principal, String credentials ) {
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put( Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory" );
		env.put( Context.PROVIDER_URL, path );
		env.put( Context.SECURITY_AUTHENTICATION, "simple" );
		env.put( Context.SECURITY_PRINCIPAL, principal );
		env.put( Context.SECURITY_CREDENTIALS, credentials );
		return env;
	}
	
	private NamingEnumeration<SearchResult> search( InitialLdapContext ctxLdap, String reqId ) throws NamingException {
		SearchControls ctrl = new SearchControls();
		ctrl.setSearchScope( SearchControls.SUBTREE_SCOPE );
		return ctxLdap.search( baseDn, MessageFormat.format( filter, new Object[] { reqId } ), ctrl );
	}
	
	/** エラーコード：パスワード不一致 */
	private static final String ERROR_LOGON_FAILURE = "52e";
	/** エラーコード：パスワード不一致 */
	private static final String ERROR_INVALID_CREDENTIALS = "53e";
	/** エラーコード：アカウントロックアウト */
	private static final String ERROR_ACCOUNT_LOCKED = "775";
	/** エラーコード：パスワード初期設定 */
	private static final String ERROR_MUST_RESET_PASSWORD = "773";
	/** エラーコード：パスワード有効期限切れ */
	private static final String ERROR_PASSWORD_EXPIRED = "532";
	
	private String getAuthenticationErrorCode( AuthenticationException ae ) {
		String errorCode = null;
		String detailMsg = ae.getMessage();
		if (detailMsg != null) {
			// 無効な資格情報
			if (detailMsg.indexOf( "data " + ERROR_LOGON_FAILURE ) > 0) {
				errorCode = ERROR_LOGON_FAILURE;
			}
			// パスワード不一致
			if (detailMsg.indexOf( "data " + ERROR_INVALID_CREDENTIALS ) > 0) {
				errorCode = ERROR_INVALID_CREDENTIALS;
			}
			// アカウントロックアウト
			if (detailMsg.indexOf( "data " + ERROR_ACCOUNT_LOCKED ) > 0) {
				errorCode = ERROR_ACCOUNT_LOCKED;
			}
			// パスワード初期設定
			if (detailMsg.indexOf( "data " + ERROR_MUST_RESET_PASSWORD ) > 0) {
				errorCode = ERROR_MUST_RESET_PASSWORD;
			}
			// パスワード有効期限切れ
			if (detailMsg.indexOf( "data " + ERROR_PASSWORD_EXPIRED ) > 0) {
				errorCode = ERROR_PASSWORD_EXPIRED;
			}
		}
		return errorCode;
	}
	
}
