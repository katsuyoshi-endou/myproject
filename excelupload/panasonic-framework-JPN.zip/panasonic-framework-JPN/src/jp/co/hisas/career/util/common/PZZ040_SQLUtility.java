/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.util.common;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import jp.co.hisas.career.framework.CareerConnection;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.util.ConnDef;
import jp.co.hisas.career.util.log.Log;

/**
 * SQL操作に関する便利な操作を集めたクラス。
 * 
 * @version 1.0
 * @since 1.0
 */
public class PZZ040_SQLUtility {
	
	/** データソース */
	private static DataSource ds = null;
	
	/** スレッド内のコネクションキャッシュ */
	private static final ThreadLocal<Connection> connectionCache = new ThreadLocal<Connection>();
	
	/**
	 * Static Initializer
	 */
	static {
		try {
			PZZ040_SQLUtility.createDataSource();
		} catch (final NamingException e) {
			Log.error( "", e );
		}
	}
	
	/**
	 * このクラスで使用するデータソースを作成する<BR>
	 * データソースの再設定を行う場合に呼び出してください。
	 * 
	 * @exception NamingException データソースの参照取得に失敗した場合
	 */
	public static void createDataSource() throws NamingException {
		try {
			// コンテキストの取得
			final InitialContext con = new InitialContext();
			// データソースの取得
			PZZ040_SQLUtility.ds = (DataSource)con.lookup( ConnDef.DATASOURCE_NAME );
		} catch (final NamingException e) {
			Log.error( "", e );
			throw e;
		}
	}
	
	/**
	 * Connectionをclose処理する。
	 * 
	 * @param con close対象のConnection
	 * @see PZZ040_SQLUtility#closeConnection(String, Connection, Statement,
	 *      ResultSet)
	 */
	public static void close( final Connection con ) {
		if (con != null) {
			try {
				con.close();
			} catch (final SQLException e) {
				Log.error( "", e );
			}
		}
	}
	
	/**
	 * PreparetedStatementをclose処理する。
	 * 
	 * @param ps close対象のPreparetedStetement
	 * @see PZZ040_SQLUtility#closeConnection(String, Connection, Statement,
	 *      ResultSet)
	 */
	public static void close( final PreparedStatement ps ) {
		if (ps != null) {
			try {
				ps.close();
			} catch (final SQLException e) {
				Log.error( "", e );
			}
		}
	}
	
	/**
	 * 引数のStatementをclose処理する。
	 * 
	 * @param stmt close対象のStatement
	 * @see PZZ040_SQLUtility#closeConnection(String, Connection, Statement,
	 *      ResultSet)
	 */
	public static void close( final Statement stmt ) {
		if (stmt != null) {
			try {
				stmt.close();
			} catch (final SQLException e) {
				Log.error( "", e );
			}
		}
	}
	
	/**
	 * データベース接続を行う。
	 * 
	 * @return データベース接続オブジェクト
	 * @exception SQLException SQLエラーが発生した場合
	 * @exception NamingException データソースの参照取得に失敗した場合
	 */
	public static Connection getConnection( final String login_no ) throws SQLException, NamingException {
		Log.method( login_no, "IN", "" );
		try {
			// DBコネクションプールの取得
			// ※ここで NullPointerException が発生する場合は旧方式の独自EJBを利用した接続を試みているのが原因
			final Connection dbConn = ProxyConnection.createProxy( PZZ040_SQLUtility.ds.getConnection() );
			Log.method( login_no, "OUT", "" );
			if (Log.isSqlDebugOn()) {
				return new CareerConnection( dbConn );
			} else {
				return dbConn;
			}
		} catch (final SQLException sqle) {
			Log.error( login_no, sqle );
			throw sqle;
		}
	}
	
	/**
	 * 引数のConntection、Statement、ResultSetをcloseします。
	 * closeする必要が無い箇所にはnullを設定すればそこはcloseしません。
	 * 
	 * @param login_no ログインユーザの氏名No
	 * @param con closeしたいConntectionインスタンス
	 * @param stmt closeしたいStatementインスタンス
	 * @param rs colseしたいResultSetインスタンス
	 */
	public static void closeConnection( final String login_no, final Connection con, final Statement stmt, final ResultSet rs ) {
		try {
			if (rs != null) {
				rs.close();
			}
		} catch (final SQLException e) {
			Log.error( login_no, e );
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
			} catch (final SQLException e) {
				Log.error( login_no, e );
			} finally {
				try {
					if (con != null) {
						con.close();
					}
				} catch (final SQLException e) {
					Log.error( login_no, e );
				}
			}
		}
	}
	
	/**
	 * DBに設定する文字列の検証を行う
	 * 
	 * @param str 検証対象文字列
	 * @param minLength 最小文字数
	 * @param maxLength 最大文字数
	 * @param notNull NULLを許可しないならtrue
	 * @return 検証結果問題がないならtrue、あるならfalse
	 */
	public static boolean validateString( final String str, final int minLength, final int maxLength, final boolean notNull ) {
		final String temp = str != null ? str : "";
		
		// Not Nullチェック
		if (notNull && (str == null || temp.length() == 0)) {
			return false;
		}
		// 最小文字列チェック
		if (temp.length() < minLength) {
			return false;
		}
		// 最大文字列チェック
		if (temp.length() > maxLength) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * SQLの結果セットからマップに変換します。
	 * 
	 * @param rs SQLの結果設定
	 * @param columnNames 列名
	 * @return 変換後のマップ
	 * @throws SQLException SQL例外が発生した場合
	 */
	public static Map<String, String> convertResultSetToMap( ResultSet rs, String... columnNames ) throws SQLException {
		Map<String, String> map = new HashMap<String, String>( columnNames.length * 2 );
		for (String col : columnNames) {
			map.put( col, PZZ010_CharacterUtil.normalizedStr( rs.getString( col ) ) );
		}
		return map;
	}
	
	/**
	 * コネクションのキャッシュを生成します。
	 * 
	 * @param loginNo ログイン社員No.
	 * @throws SQLException
	 * @throws NamingException
	 */
	public static void createCachedConnection( String loginNo ) {
		
		Log.sql( "【PZZ040_SQLUtility createCachedConnection】" );
		
		try {
			connectionCache.set( getConnection( loginNo ) );
		} catch (SQLException e) {
			Log.error( loginNo, e );
			throw new CareerRuntimeException( e );
		} catch (NamingException e) {
			Log.error( loginNo, e );
			throw new CareerRuntimeException( e );
		}
	}
	
	/**
	 * キャッシュしたコネクションを閉じます。
	 */
	public static void removeCachedConnection() {
		Connection conn = connectionCache.get();
		try {
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		} catch (SQLException e) {
			Log.error( "", e );
		}
		connectionCache.remove();
	}
	
	/**
	 * キャッシュしたコネクションを取得します。
	 * 
	 * @return コネクション
	 */
	public static Connection getCachedConnection() {
		return connectionCache.get();
	}
	
	/**
	 * データソースを取得します。
	 * 
	 * @return データソース
	 */
	public static DataSource getDataSource() {
		return PZZ040_SQLUtility.ds;
	}
}
