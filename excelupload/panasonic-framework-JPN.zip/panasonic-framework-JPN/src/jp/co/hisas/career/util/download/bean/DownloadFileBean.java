/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.util.download.bean;

/**
 * ダウンロードファイルのデータを格納するValueBeanクラス<br>
 */
public class DownloadFileBean {
	/** ダウンロードファイルのファイルパス */
	private String filePath = null;

	/** ダウンロードファイルのファイル名 */
	private String fileName = null;

	/** ダウンロードファイルのContentType */
	private String contentType = null;

	/** ダウンロードファイルのデータ配列 */
	private byte[] flieData = null;

	/** ダウンロード実行を示すフラグ */
	private boolean downolad = false;

	/** 元画面の状態を再現するためのJavaScript */
	private String scriptStr = null;

	/**
	 * コンストラクタ
	 */
	public DownloadFileBean() {
	}

	/**
	 * すべてのデータをセットするコンストラクタ
	 */
	public DownloadFileBean(final String filePath, final String fileName, final String contentType, final byte[] fileData, final String scriptStr) {
		this.setFilePath(filePath);
		this.setFileName(fileName);
		this.setContentType(contentType);
		this.setFlieData(fileData);
		this.setScriptStr(scriptStr);
		this.setDownolad(true);
	}

	/**
	 * @return ダウンロードファイルのデータ配列
	 */
	public final byte[] getFlieData() {
		return this.flieData;
	}

	/**
	 * @param flieData ダウンロードファイルのデータ配列
	 */
	public final void setFlieData(final byte[] flieData) {
		this.flieData = flieData;
	}

	/**
	 * @return ダウンロードファイルのContentType
	 */
	public final String getContentType() {
		return this.contentType;
	}

	/**
	 * @param contentType ダウンロードファイルのContentType
	 */
	public final void setContentType(final String contentType) {
		this.contentType = contentType;
	}

	/**
	 * @return ダウンロード実行を示すフラグ trueならダウンロード実行
	 */
	public final boolean isDownolad() {
		return this.downolad;
	}

	/**
	 * @param downolad ダウンロードを実行を示すフラグ trueならダウンロード実行
	 */
	public final void setDownolad(final boolean downolad) {
		this.downolad = downolad;
	}

	/**
	 * @return ダウンロードファイルのファイル名
	 */
	public final String getFileName() {
		return this.fileName;
	}

	/**
	 * @param fileName ダウンロードファイルのファイル名
	 */
	public final void setFileName(final String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return ダウンロードファイルのファイルパス
	 */
	public final String getFilePath() {
		return this.filePath;
	}

	/**
	 * @param filePath ダウンロードファイルのファイルパス
	 */
	public final void setFilePath(final String filePath) {
		this.filePath = filePath;
	}

	/**
	 * @return 元画面の状態を再現するためのJavaScript
	 */
	public final String getScriptStr() {
		return this.scriptStr;
	}

	/**
	 * @param scriptStr 元画面の状態を再現するためのJavaScript
	 */
	public final void setScriptStr(final String scriptStr) {
		this.scriptStr = scriptStr;
	}

}
