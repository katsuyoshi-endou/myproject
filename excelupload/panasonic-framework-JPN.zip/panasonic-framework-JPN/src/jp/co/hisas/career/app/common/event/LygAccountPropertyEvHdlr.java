package jp.co.hisas.career.app.common.event;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.LygAccountPropertyDao;
import jp.co.hisas.career.util.dto.LygAccountPropertyDto;
import jp.co.hisas.career.util.log.Log;

public class LygAccountPropertyEvHdlr extends AbstractEventHandler<LygAccountPropertyEvArg, LygAccountPropertyEvRslt> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static LygAccountPropertyEvRslt exec( LygAccountPropertyEvArg arg ) throws CareerException {
		LygAccountPropertyEvHdlr handler = new LygAccountPropertyEvHdlr();
		return handler.call( arg );
	}
	
	public LygAccountPropertyEvRslt call( LygAccountPropertyEvArg arg ) throws CareerException {
		LygAccountPropertyEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected LygAccountPropertyEvRslt execute( LygAccountPropertyEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		LygAccountPropertyEvRslt result = new LygAccountPropertyEvRslt();
		
		if (SU.equals( "INIT", arg.accountId )) {
			result.lygAccountPropertyDto = getLygAccountProperty( arg );
		}
		
		return result;
	}
	
	private LygAccountPropertyDto getLygAccountProperty( LygAccountPropertyEvArg arg ) {
		LygAccountPropertyDao dao = new LygAccountPropertyDao( this.loginNo );
		LygAccountPropertyDto result = dao.select( arg.accountId );
		return result;
	}
}
