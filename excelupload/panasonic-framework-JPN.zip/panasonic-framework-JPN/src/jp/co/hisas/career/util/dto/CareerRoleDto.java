/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * キャリアロール Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CareerRoleDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PARTY
     */
    private String party;
    /**
     * GUID
     */
    private String guid;
    /**
     * モジュールID
     */
    private String moduleId;
    /**
     * ロールID
     */
    private String roleId;

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * GUIDを取得する。
     * @return GUID
     */
    public String getGuid() {
        return guid;
    }

    /**
     * GUIDを設定する。
     * @param guid GUID
     */
    public void setGuid(String guid) {
        this.guid = guid;
    }

    /**
     * モジュールIDを取得する。
     * @return モジュールID
     */
    public String getModuleId() {
        return moduleId;
    }

    /**
     * モジュールIDを設定する。
     * @param moduleId モジュールID
     */
    public void setModuleId(String moduleId) {
        this.moduleId = moduleId;
    }

    /**
     * ロールIDを取得する。
     * @return ロールID
     */
    public String getRoleId() {
        return roleId;
    }

    /**
     * ロールIDを設定する。
     * @param roleId ロールID
     */
    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

}

