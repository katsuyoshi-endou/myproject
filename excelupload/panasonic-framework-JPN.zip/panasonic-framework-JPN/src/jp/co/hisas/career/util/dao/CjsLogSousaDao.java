/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jp.co.hisas.career.util.dto.CjsLogSousaDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * 操作ログ Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CjsLogSousaDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " JIKKOU_HIDUKE as jikkouHiduke,"
                     + " JIKKOU_JIKOKU as jikkouJikoku,"
                     + " JIKKOU_KINOU_ID as jikkouKinouId,"
                     + " JIKKOU_SIMEI_NO as jikkouSimeiNo,"
                     + " TAISYOU_SIMEI_NO as taisyouSimeiNo,"
                     + " JOUKEN as jouken"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CjsLogSousaDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CjsLogSousaDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param jikkouHiduke 実行日付
     * @param jikkouJikoku 実行時刻
     * @param jikkouKinouId 実行機能ID
     * @return CjsLogSousaDto CJS_LOG_SOUSAのレコード型データ。
     */ 
    public CjsLogSousaDto select(String jikkouHiduke, String jikkouJikoku, String jikkouKinouId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CJS_LOG_SOUSA"
                         + " WHERE JIKKOU_HIDUKE = ?"
                         + " AND JIKKOU_JIKOKU = ?"
                         + " AND JIKKOU_KINOU_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CjsLogSousaDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setCharToPreparedStatement(pstmt, 1, jikkouHiduke);
            DaoUtil.setCharToPreparedStatement(pstmt, 2, jikkouJikoku);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, jikkouKinouId);
            rs = pstmt.executeQuery();
            CjsLogSousaDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CjsLogSousaDto transferRsToDto(ResultSet rs) throws SQLException {

        CjsLogSousaDto dto = new CjsLogSousaDto();
        dto.setJikkouHiduke(DaoUtil.convertNullToString(rs.getString("jikkouHiduke")));
        dto.setJikkouJikoku(DaoUtil.convertNullToString(rs.getString("jikkouJikoku")));
        dto.setJikkouKinouId(DaoUtil.convertNullToString(rs.getString("jikkouKinouId")));
        dto.setJikkouSimeiNo(DaoUtil.convertNullToString(rs.getString("jikkouSimeiNo")));
        dto.setTaisyouSimeiNo(DaoUtil.convertNullToString(rs.getString("taisyouSimeiNo")));
        dto.setJouken(DaoUtil.convertNullToString(rs.getString("jouken")));
        return dto;
    }

    /**
     * レコードが取得できる場合、対象者がログイン中であるものとする。
     * @param loginNo ログインID
     * @param hiduke 日付
     * @param jikoku 時刻
     * @return レコード件数。
     */
    public int countLoginUser(String loginNo, String hiduke, String jikoku) {

        final String sql = "SELECT COUNT(*) "
                         + " FROM CJS_LOG_SOUSA "
                         + " WHERE "
                         + " JIKKOU_SIMEI_NO = ? AND "
                         + " JIKKOU_HIDUKE = ? AND "
                         + " JIKKOU_JIKOKU >= ?"
                         ;
        Log.sql("【DaoMethod Call】 CjsLogSousaDao.countLoginUser");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int cnt = 0;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, loginNo);
            DaoUtil.setCharToPreparedStatement(pstmt, 2, hiduke);
            DaoUtil.setCharToPreparedStatement(pstmt, 3, jikoku);
            rs = pstmt.executeQuery();
            if ( rs.next() ) {
                cnt = rs.getInt(1);
            }
            return cnt;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

