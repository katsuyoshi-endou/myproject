package jp.co.hisas.career.util.property;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Properties;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.framework.def.AC;
import jp.co.hisas.career.util.log.Log;

@SuppressWarnings({ "rawtypes", "unchecked" })
public class ReadFile {
	
	public static HashMap careerProperties = null;
	public static Properties sqlProperties = null;
	
	private static String careerBaseDir = AC.CAREER_BASE_DIR;
	private static boolean isCached = false;
	
	/**
	 * Static Initializer
	 */
	static {
		// Do not initialize on loaded.
		// Triggered from Log class.
	}
	
	public static String getCareerBaseDir() {
		return careerBaseDir;
	}
	
	public static void loadIfNotCached() {
		if (!isCached) {
			synchronized (ReadFile.class) {
				ReadFile.refreshAllProperties();
				Log.refresh();
				isCached = true;
			}
		}
	}
	
	/**
	 * コンストラクタ
	 */
	private ReadFile() {
	}
	
	/**
	 * 引数で渡したファイル名のファイルを読み込む。
	 * 
	 * @param defineFile 読み込むファイル名
	 * @return 情報格納オブジェクト
	 */
	private static HashMap loadFile( final String defineFile ) {
		String line = "";
		BufferedReader br = null;
		HashMap fileDataMap = null;
		File file;
		
		try {
			fileDataMap = new HashMap();
			
			/* 定義ファイル取得チェック */
			if (defineFile != null) {
				/* ファイルの存在チェック */
				file = new File( defineFile );
				
				if (file.exists()) {
					/* 設定ファイル読み込み */
					br = new BufferedReader( new InputStreamReader( new FileInputStream( defineFile ) ) );
					
					while ((line = br.readLine()) != null) {
						/* 前後のスペースを取り除く */
						final String keyValue = line.trim();
						
						/* 空行判定 */
						if (keyValue.length() == 0 || keyValue.charAt( 0 ) == '#') {
							continue;
						}
						
						/* １行データ解析 */
						final int sepPos = line.indexOf( ',' );
						
						/* 無効行判定（分離文字（','）が無い） */
						if (sepPos == -1) {
							continue; // 無効行スキップ
						}
						
						/* キーと値を分離し、それぞれの前後のスペースを取り除く */
						final String keyWord = line.substring( 0, sepPos ).trim();
						final String value = line.substring( sepPos + 1 ).trim();
						
						fileDataMap.put( keyWord, value );
					}
				} else {
					System.err.println( "設定ファイルが存在しません。" + " [ファイル名:" + defineFile + "]" );
				}
			}
		} catch (final FileNotFoundException fnfe) {
			System.err.println( "設定ファイルが存在しません。" );
			
			/* 例外のスタックトレースを出力 */
			fnfe.printStackTrace( System.err );
			
			return null;
		} catch (final IOException ioe) {
			System.err.println( "設定ファイルの読み込み時に、エラーが発生しました。" );
			
			/* 例外のスタックトレースを出力 */
			ioe.printStackTrace( System.err );
			
			return null;
		} finally {
			/* ファイルのクローズ */
			if (br != null) {
				try {
					br.close();
				} catch (final IOException e) {
					System.err.println( "ファイルのクローズ処理に失敗しました。" );
					
					/* 例外のスタックトレースを出力 */
					e.printStackTrace( System.err );
				}
			}
		}
		
		/* 正常終了（情報格納オブジェクトを返す） */
		return fileDataMap;
	}
	
	/**
	 * 引数で渡したファイル名のプロパティファイルを読み込む。
	 * 
	 * @param defineFile 読み込むファイル名
	 * @return 情報格納オブジェクト
	 */
	private static Properties loadFileProperties( final String defineFile ) {
		BufferedReader br = null;
		Properties fileDataProperties = null;
		File file;
		
		try {
			fileDataProperties = new Properties();
			
			/* 定義ファイル取得チェック */
			if (defineFile != null) {
				/* ファイルの存在チェック */
				file = new File( defineFile );
				
				if (file.exists()) {
					fileDataProperties.load( new FileInputStream( defineFile ) );
				} else {
					System.err.println( "設定ファイルが存在しません。" + " [ファイル名:" + defineFile + "]" );
				}
			}
		} catch (final FileNotFoundException fnfe) {
			System.err.println( "設定ファイルが存在しません。" );
			
			/* 例外のスタックトレースを出力 */
			fnfe.printStackTrace( System.err );
			
			return null;
		} catch (final IOException ioe) {
			System.err.println( "設定ファイルの読み込み時に、エラーが発生しました。" );
			
			/* 例外のスタックトレースを出力 */
			ioe.printStackTrace( System.err );
			
			return null;
		} finally {
			/* ファイルのクローズ */
			if (br != null) {
				try {
					br.close();
				} catch (final IOException e) {
					System.err.println( "ファイルのクローズ処理に失敗しました。" );
					
					/* 例外のスタックトレースを出力 */
					e.printStackTrace( System.err );
				}
			}
		}
		
		/* 正常終了（情報格納オブジェクトを返す） */
		return fileDataProperties;
	}
	
	/**
	 * プロパティキャッシュのリフレッシュ
	 * ※Logクラスからのみ呼ばれる
	 */
	synchronized public static void refreshAllProperties() {
		Log.debug( "★ReadFile cache start" );
		String carPath = AppDef.APP_DIR + "/properties/career.properties";
		String sqlPath = AppDef.APP_DIR + "/properties/sql.properties";
		Log.debug( "★ReadFile propertyFileName:" + carPath );
		Log.debug( "★ReadFile sqlPropertyFileName:" + sqlPath );
		
		final HashMap careerProps = ReadFile.loadFile( carPath );
		final Properties sqlProps = ReadFile.loadFileProperties( sqlPath );
		
		if (careerProps != null && sqlProps != null) {
			ReadFile.careerProperties = careerProps;
			ReadFile.sqlProperties = sqlProps;
			isCached = true;
		}
		Log.debug( "★ReadFile cache end" );
	}
	
}
