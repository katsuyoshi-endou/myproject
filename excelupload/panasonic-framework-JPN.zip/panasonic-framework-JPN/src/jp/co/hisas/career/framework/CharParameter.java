package jp.co.hisas.career.framework;

public class CharParameter implements SQLParameter {
	
	String value;
	
	public CharParameter(String value) {
		this.value = value;
	}
	
	public String getFormatedParameter() {
		if (value == null || value.length() == 0) {
			return "NULL";
		} else {
			return "'" + value.replace( "'", "''" ) + "'";
		}
	}
	
	public String getParameter() {
		return value;
	}
	
	public void setParameter( String parameter ) {
		value = parameter;
	}
	
}
