/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * プロジェクト名　：
 *   人材戦略システム（リシテアCareer計画系）
 *
 * 備考　：
 *   なし
 *
 * 履歴　：
 *   日付        バージョン   名前　　　　　内容
 *   2004/04/01  01.00       小野　隆之　　新規作成
 */

package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
 * <PRE>
 * 
 * 概要: クライアントがSessionBeanを生成、検索、削除するためのホームインタフェース。
 * 
 * </PRE>
 */
public interface PYF_BlobDBAccessEJBHome extends EJBHome {

	/**
	 * SessionBeanを生成、検索、削除する。
	 * @return リモートインタフェース
	 * @exception CreateException SQLエラーが発生した場合
	 * @exception RemoteException リモートメソッド呼び出しの実行中に発生する例外
	 */
	PYF_BlobDBAccessEJB create() throws CreateException, RemoteException;
}
