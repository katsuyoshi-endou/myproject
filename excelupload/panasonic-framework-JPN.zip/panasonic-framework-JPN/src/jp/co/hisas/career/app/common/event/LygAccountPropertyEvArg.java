package jp.co.hisas.career.app.common.event;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

@SuppressWarnings("serial")
public class LygAccountPropertyEvArg extends AbstractEventArg {
	
	public String accountId;

	public LygAccountPropertyEvArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid LygAccountPropertyEvArg: loginNo is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		if (SU.isBlank( accountId )) {
			throw new CareerException( "Invalid LygAccountPropertyEvArg: accountId is null." );
		}
	}
}
