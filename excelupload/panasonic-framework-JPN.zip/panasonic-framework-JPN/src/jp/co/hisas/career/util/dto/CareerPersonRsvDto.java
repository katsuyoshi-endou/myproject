/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * 人 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CareerPersonRsvDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 人ID
     */
    private String personId;
    /**
     * 氏名
     */
    private String personName;
    /**
     * メールアドレス
     */
    private String mailAddress;
    /**
     * 入社年月日
     */
    private String hiredDate;
    /**
     * 退職年月日
     */
    private String retireDate;
    /**
     * 在籍フラグ
     */
    private String registFlg;
    /**
     * 部署階層ランク
     */
    private Integer deptHierRank;

    /**
     * 人IDを取得する。
     * @return 人ID
     */
    public String getPersonId() {
        return personId;
    }

    /**
     * 人IDを設定する。
     * @param personId 人ID
     */
    public void setPersonId(String personId) {
        this.personId = personId;
    }

    /**
     * 氏名を取得する。
     * @return 氏名
     */
    public String getPersonName() {
        return personName;
    }

    /**
     * 氏名を設定する。
     * @param personName 氏名
     */
    public void setPersonName(String personName) {
        this.personName = personName;
    }

    /**
     * メールアドレスを取得する。
     * @return メールアドレス
     */
    public String getMailAddress() {
        return mailAddress;
    }

    /**
     * メールアドレスを設定する。
     * @param mailAddress メールアドレス
     */
    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    /**
     * 入社年月日を取得する。
     * @return 入社年月日
     */
    public String getHiredDate() {
        return hiredDate;
    }

    /**
     * 入社年月日を設定する。
     * @param hiredDate 入社年月日
     */
    public void setHiredDate(String hiredDate) {
        this.hiredDate = hiredDate;
    }

    /**
     * 退職年月日を取得する。
     * @return 退職年月日
     */
    public String getRetireDate() {
        return retireDate;
    }

    /**
     * 退職年月日を設定する。
     * @param retireDate 退職年月日
     */
    public void setRetireDate(String retireDate) {
        this.retireDate = retireDate;
    }

    /**
     * 在籍フラグを取得する。
     * @return 在籍フラグ
     */
    public String getRegistFlg() {
        return registFlg;
    }

    /**
     * 在籍フラグを設定する。
     * @param registFlg 在籍フラグ
     */
    public void setRegistFlg(String registFlg) {
        this.registFlg = registFlg;
    }

    /**
     * 部署階層ランクを取得する。
     * @return 部署階層ランク
     */
    public Integer getDeptHierRank() {
        return deptHierRank;
    }

    /**
     * 部署階層ランクを設定する。
     * @param deptHierRank 部署階層ランク
     */
    public void setDeptHierRank(Integer deptHierRank) {
        this.deptHierRank = deptHierRank;
    }

}

