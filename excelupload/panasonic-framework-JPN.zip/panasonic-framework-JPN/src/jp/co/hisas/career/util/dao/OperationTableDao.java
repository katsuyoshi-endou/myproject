package jp.co.hisas.career.util.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dto.OperationTableDto;
import jp.co.hisas.career.util.log.Log;

public class OperationTableDao {
	
	Connection conn;
	boolean isConnectionGiven = false;
	String loginNo;
	
	public String whereStr = "";
	
	public OperationTableDao(String loginNo) {
		this.loginNo = loginNo;
	}
	
	public OperationTableDao(Connection conn) {
		this.conn = conn;
		this.isConnectionGiven = true;
	}
	
	private Connection getConnection() {
		Connection connection = isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
		if (connection == null) {
			throw new CareerRuntimeException();
		}
		return connection;
	}
	
	public List<OperationTableDto> select( String tableName, List<String> colList ) {
		
		String sql = "";
		
		Log.sql( "【DaoMethod Call】 OperationTableDao.select" );
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			
			sql  = "";
			sql += " SELECT " + this.convCommaSeparatedString( colList ) ;
			sql += " FROM " + tableName ;
			sql += ("".equals( whereStr )) ? "" : "  WHERE " + whereStr ;
			pstmt = conn.prepareStatement( sql );
			rs = pstmt.executeQuery();
			List<OperationTableDto> lst = new ArrayList<OperationTableDto>();
			while ( rs.next() ) {
				lst.add( transferRsToDto( rs, colList ) );
			}
			
			return lst;
			
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, rs );
		}
	}
	
	public void insert( String tableName, List<String> colList, List<String> valueList ) {
		
		String sql = "";
		
		Log.sql( "【DaoMethod Call】 OperationTableDao.insert" );
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			
			sql  = "";
			sql += " INSERT INTO " + tableName;
			sql += " ( ";
			sql += this.convCommaSeparatedString( colList );
			sql += " ) VALUES ( "; 
			sql += this.convCommaSeparatedString( valueList, "'" );
			sql += " ) ";
			pstmt = conn.prepareStatement( sql );
			pstmt.executeUpdate();
			
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, rs );
		}
	}
	
	private OperationTableDto transferRsToDto( ResultSet rs, List<String> colList ) throws SQLException {
		
		List<String> valueList = new ArrayList<String>();
		for (int i=0; i<colList.size(); i++) {
			valueList.add( DaoUtil.convertNullToString( rs.getString( colList.get( i ) ) ) );
		}
		OperationTableDto dto = new OperationTableDto();
		dto.setColValueList( valueList );
		return dto;
	}
	
	private String convCommaSeparatedString( List<String> cols, String wrapStr ) {
		String str = "";
		for (int i=0; i<cols.size(); i++) {
			str += (i==0) ? "" : "," ;
			str += wrapStr + cols.get( i ) + wrapStr;
		}
		return str;
	}
	
	private String convCommaSeparatedString( List<String> cols ) {
		return convCommaSeparatedString( cols, "" );
	}
	
}
