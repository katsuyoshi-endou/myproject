package jp.co.hisas.career.framework.def;

/**
 * Application Constant
 */
public class AC {
	
	public static final String CAREER_BASE_DIR = "C:/Lysithea/Career";
	
	public static final String ERROR_PAGE = "/view/error.jsp";
}
