package jp.co.hisas.career.util.dao.useful;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

public class OneColumnDao extends CoreDao {
	
	public static final String ALLCOLS = "" + " TEXT as text";
	
	public OneColumnDao(String loginNo) {
		super( loginNo );
	}
	
	/**
	 * 動的SELECT文を実行する。
	 * 
	 * @param pstmt PreparedStatement
	 * @return List<String> String型データのリスト。
	 */
	public List<String> selectDynamic( PreparedStatement pstmt ) {
		
		Log.sql( "【DaoMethod Call】 OneColumnDao.selectDynamic" );
		ResultSet rs = null;
		try {
			rs = pstmt.executeQuery();
			List<String> lst = new ArrayList<String>();
			while (rs.next()) {
				lst.add( transferRsToDto( rs ) );
			}
			return lst;
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, rs );
		}
	}
	
	/**
	 * 動的SELECT文を実行する。
	 * 
	 * @param sql SQL文
	 * @return List<String> String型データのリスト。
	 */
	public List<String> selectDynamic( String sql ) {
		
		Log.sql( "【DaoMethod Call】 OneColumnDao.selectDynamic" );
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement( sql );
			return selectDynamic( pstmt );
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, null );
		}
	}
	
	/**
	 * 動的SELECT文を実行する。
	 * 
	 * @param pstmt PreparedStatement
	 * @return String 先頭レコードのテキスト
	 */
	public String selectDynamicFirst( PreparedStatement pstmt ) {
		
		Log.sql( "【DaoMethod Call】 OneColumnDao.selectDynamic" );
		ResultSet rs = null;
		try {
			rs = pstmt.executeQuery();
			List<String> lst = new ArrayList<String>();
			while (rs.next()) {
				lst.add( transferRsToDto( rs ) );
			}
			return (lst.size() > 0) ? lst.get( 0 ) : null;
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, rs );
		}
	}
	
	/**
	 * 動的SELECT文を実行する。
	 * 
	 * @param sql SQL文
	 * @return String 先頭レコードのテキスト
	 */
	public String selectDynamicFirst( String sql ) {
		
		Log.sql( "【DaoMethod Call】 OneColumnDao.selectDynamic" );
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement( sql );
			return selectDynamicFirst( pstmt );
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, null );
		}
	}
	
	/**
	 * 動的SELECT COUNT文を実行してレコードが存在するかどうかを返す。
	 * 
	 * @param pstmt
	 * @return
	 */
	public boolean checkExistDynamic( PreparedStatement pstmt ) {
		
		Log.sql( "【DaoMethod Call】 OneColumnDao.checkExistDynamic" );
		ResultSet rs = null;
		int cnt = 0;
		try {
			rs = pstmt.executeQuery();
			if (rs.next()) {
				cnt = rs.getInt( 1 );
			}
			return (cnt > 0);
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, rs );
		}
	}
	
	/**
	 * ResultSetからData Transfer Objectへのデータ転送
	 */
	private String transferRsToDto( ResultSet rs ) throws SQLException {
		return DaoUtil.convertNullToString( rs.getString( "text" ) );
	}
	
}
