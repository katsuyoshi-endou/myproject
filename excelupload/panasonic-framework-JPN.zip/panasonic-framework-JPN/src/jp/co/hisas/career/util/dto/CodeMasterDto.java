/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * コードマスタ Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CodeMasterDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * マスタID
     */
    private String masterId;
    /**
     * マスタコード
     */
    private String masterCode;
    /**
     * マスタ名
     */
    private String masterName;
    /**
     * マスタ属性1
     */
    private String masterZokusei1;
    /**
     * マスタ属性2
     */
    private String masterZokusei2;
    /**
     * マスタ属性3
     */
    private String masterZokusei3;
    /**
     * マスタ属性4
     */
    private String masterZokusei4;
    /**
     * マスタ属性5
     */
    private String masterZokusei5;
    /**
     * 更新者
     */
    private String updatePersonId;
    /**
     * 更新機能
     */
    private String updateFunction;
    /**
     * 更新日
     */
    private String updateDate;
    /**
     * 更新時間
     */
    private String updateTime;

    /**
     * マスタIDを取得する。
     * @return マスタID
     */
    public String getMasterId() {
        return masterId;
    }

    /**
     * マスタIDを設定する。
     * @param masterId マスタID
     */
    public void setMasterId(String masterId) {
        this.masterId = masterId;
    }

    /**
     * マスタコードを取得する。
     * @return マスタコード
     */
    public String getMasterCode() {
        return masterCode;
    }

    /**
     * マスタコードを設定する。
     * @param masterCode マスタコード
     */
    public void setMasterCode(String masterCode) {
        this.masterCode = masterCode;
    }

    /**
     * マスタ名を取得する。
     * @return マスタ名
     */
    public String getMasterName() {
        return masterName;
    }

    /**
     * マスタ名を設定する。
     * @param masterName マスタ名
     */
    public void setMasterName(String masterName) {
        this.masterName = masterName;
    }

    /**
     * マスタ属性1を取得する。
     * @return マスタ属性1
     */
    public String getMasterZokusei1() {
        return masterZokusei1;
    }

    /**
     * マスタ属性1を設定する。
     * @param masterZokusei1 マスタ属性1
     */
    public void setMasterZokusei1(String masterZokusei1) {
        this.masterZokusei1 = masterZokusei1;
    }

    /**
     * マスタ属性2を取得する。
     * @return マスタ属性2
     */
    public String getMasterZokusei2() {
        return masterZokusei2;
    }

    /**
     * マスタ属性2を設定する。
     * @param masterZokusei2 マスタ属性2
     */
    public void setMasterZokusei2(String masterZokusei2) {
        this.masterZokusei2 = masterZokusei2;
    }

    /**
     * マスタ属性3を取得する。
     * @return マスタ属性3
     */
    public String getMasterZokusei3() {
        return masterZokusei3;
    }

    /**
     * マスタ属性3を設定する。
     * @param masterZokusei3 マスタ属性3
     */
    public void setMasterZokusei3(String masterZokusei3) {
        this.masterZokusei3 = masterZokusei3;
    }

    /**
     * マスタ属性4を取得する。
     * @return マスタ属性4
     */
    public String getMasterZokusei4() {
        return masterZokusei4;
    }

    /**
     * マスタ属性4を設定する。
     * @param masterZokusei4 マスタ属性4
     */
    public void setMasterZokusei4(String masterZokusei4) {
        this.masterZokusei4 = masterZokusei4;
    }

    /**
     * マスタ属性5を取得する。
     * @return マスタ属性5
     */
    public String getMasterZokusei5() {
        return masterZokusei5;
    }

    /**
     * マスタ属性5を設定する。
     * @param masterZokusei5 マスタ属性5
     */
    public void setMasterZokusei5(String masterZokusei5) {
        this.masterZokusei5 = masterZokusei5;
    }

    /**
     * 更新者を取得する。
     * @return 更新者
     */
    public String getUpdatePersonId() {
        return updatePersonId;
    }

    /**
     * 更新者を設定する。
     * @param updatePersonId 更新者
     */
    public void setUpdatePersonId(String updatePersonId) {
        this.updatePersonId = updatePersonId;
    }

    /**
     * 更新機能を取得する。
     * @return 更新機能
     */
    public String getUpdateFunction() {
        return updateFunction;
    }

    /**
     * 更新機能を設定する。
     * @param updateFunction 更新機能
     */
    public void setUpdateFunction(String updateFunction) {
        this.updateFunction = updateFunction;
    }

    /**
     * 更新日を取得する。
     * @return 更新日
     */
    public String getUpdateDate() {
        return updateDate;
    }

    /**
     * 更新日を設定する。
     * @param updateDate 更新日
     */
    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * 更新時間を取得する。
     * @return 更新時間
     */
    public String getUpdateTime() {
        return updateTime;
    }

    /**
     * 更新時間を設定する。
     * @param updateTime 更新時間
     */
    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

}

