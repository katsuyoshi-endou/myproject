package jp.co.hisas.career.app.common.event;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class SelectWithSqlPropEvRslt extends AbstractEventResult {

	public Map<Integer, List<String>> rows = null;

}