/*
 * All Rights Reserved. Copyright (C) 2004,2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

/**
 * サブアプリケーションの分類を表す列挙型。
 * セッションスコープの値を保持する範囲を定めるために用いる。
 * <b>このクラスは必ずsynchronized内で使用すること。</b>
 * @author kats-watanabe
 */
public enum SubApplication {
    /**
     * スキルマップメンテナンス機能
     */
    SKILLMAP_MAINTENANCE,
    /**
     * 共通スキルマップ一覧機能
     */
    KYOTSU_SKILLMAP_LIST,
    /**
     * 人財ポートフォリオ機能
     */
    JINZAI_PORTOFORIO,
    /**
     * 人事考課
     */
    JINJI_KOKA,
    /**
     * 評価一覧参照
     */
    HYOKA_ICHIRAN_SANSHO,
    ;

    private static final String ATTRIBUTE_NAME_PREFIX = "_FW_SCOPE_SUBAPP_";

    /**
     * サブアプリケーションの属性のマップを取得する。
     * <b>このクラスは必ずsynchronized内で使用すること。</b>
     * @param session 値の格納先となるHTTPセッション。
     * @param key 属性の名称。
     * @return 属性の値。
     */
    @SuppressWarnings( "unchecked" )
    public Map<String, Object> getAttributes( HttpSession session ) {
        Map<String, Object> map =
                (Map<String, Object>) session.getAttribute( ATTRIBUTE_NAME_PREFIX + this.name() );
        if ( map == null ) {
            map = new HashMap<String, Object>();
            session.setAttribute( ATTRIBUTE_NAME_PREFIX + this.name(), map );
        }
        return map;
    }

    /**
     * サブアプリケーションの属性を取得する。
     * <b>このクラスは必ずsynchronized内で使用すること。</b>
     * @param session 値の格納先となるHTTPセッション。
     * @param key 属性の名称。
     * @return 属性の値。
     */
    public Object getAttribute( HttpSession session, String key ) {
        return getAttributes( session ).get( key );
    }

    /**
     * サブアプリケーションの属性を設定する。nullを指定したら値をクリアする。
     * <b>このクラスは必ずsynchronized内で使用すること。</b>
     * @param session 値の格納先となるHTTPセッション。
     * @param key 属性の名称。
     * @param value 属性の値。
     */
    public void setAttribute( HttpSession session, String key, Object value ) {
        if ( value != null ) {
            getAttributes( session ).put( key, value );
        } else {
            getAttributes( session ).remove( key );
        }
    }

    /**
     * サブアプリケーションの属性をすべて消去する。
     * <b>このクラスは必ずsynchronized内で使用すること。</b>
     * @param session 値の格納先となるHTTPセッション。
     */
    public void init( HttpSession session ) {
        getAttributes( session ).clear();
    }

}
