/*
 * All Rights Reserved. Copyright (C) 2004,2008, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.naming.NamingException;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.EJBHomeFactory;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.util.log.Log;

/**
 * ビジネスロジックを実装するクラスの基底クラス。
 * 
 * @author kats-watanabe
 * @param <Arg> EventHandler の引数クラス
 * @param <Res> EventHandler の戻り値クラス
 */
public abstract class AbstractEventHandler<Arg extends AbstractEventArg, Res extends AbstractEventResult> {
	
	/**
	 * 画面側から呼び出すメソッド。また、呼び出し履歴をきれいに表示するために必要なメソッド。 内部で execute を呼び出す。
	 * デバッグモードの場合、直接呼出し、そうでない場合は EJB 呼び出しを行うようにする。
	 * 
	 * @param arg EventHandler の引数
	 * @return execute の結果。
	 * @throws CareerException アプリケーション定義の例外が発生した場合
	 */
	public abstract Res call( Arg arg ) throws CareerException;
	
	/**
	 * ビジネスロジックを実装する抽象メソッド
	 * 
	 * @param arg ビジネスロジックの引数
	 * @return 処理結果
	 * @throws CareerException アプリケーション定義の例外が発生した場合
	 */
	protected abstract Res execute( Arg arg ) throws CareerException;
	
	/**
	 * EJB呼び出し
	 * 
	 * @param arg ビジネスロジックの引数
	 * @return 処理結果
	 * @throws CareerException アプリケーション定義の例外が発生した場合
	 * @throws CareerRuntimeException EJB呼び出しに失敗した場合
	 */
	@SuppressWarnings("unchecked")
	protected Res callEjb( Arg arg ) throws CareerException {
		Res result = null;
		try {
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final EventEJBHome home = (EventEJBHome)fact.lookup( EventEJBHome.class );
			EventEJB ejb = home.create();
			
			Log.transaction( arg.getLoginNo(), true, "" );
			result = (Res)ejb.callHanlder( this.getClass(), arg );
			Log.transaction( arg.getLoginNo(), false, "" );
		} catch (NamingException e) {
			Log.error( arg.getLoginNo(), e );
			throw new CareerRuntimeException( e );
		} catch (CreateException e) {
			throw new CareerRuntimeException( e );
		} catch (RemoteException e) {
			// EJB仕様では、宣言済みのアプリケーション例外を除き、
			// 例外がRemoteExceptionにラップされることがある。
			// throwのネストを走査し、CareerException、CareerRuntimeExceptionを取り出す
			Throwable cause = e.getCause();
			while (cause != null) {
				if (cause instanceof CareerRuntimeException) {
					throw (CareerRuntimeException)cause;
				} else if (cause instanceof CareerException) {
					throw (CareerException)cause;
				}
				// next cause
				if (cause instanceof EJBException) {
					cause = ((EJBException)cause).getCausedByException();
				} else {
					cause = cause.getCause();
				}
			}
			Log.error( arg.getLoginNo(), e );
			throw new CareerRuntimeException( e );
		}
		return result;
	}
	
}
