package jp.co.hisas.career.util.cache;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.io.FileUtils;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.util.log.Log;

public final class CsTemplateCache {
	
	private ConcurrentHashMap<String, String> map = new ConcurrentHashMap<String, String>();
	
	/**
	 * Singleton パターン - Wikipedia
	 * https://ja.wikipedia.org/wiki/Singleton_パターン
	 */
	private CsTemplateCache() {
	}
	
	private static class CsTemplateCacheHolder {
		private static final CsTemplateCache instance = new CsTemplateCache();
	}
	
	private static CsTemplateCache getInstance() {
		return CsTemplateCacheHolder.instance;
	}
	
	public static String getTemplate( String templateId ) {
		CsTemplateCache instance = CsTemplateCache.getInstance();
		return instance.getTemplateData( templateId );
	}
	
	private String getTemplateData( String templateId ) {
		// マップにすでにキーが存在するかどうかでキャッシュ済みかどうかを判断する
		if (!map.containsKey( templateId )) {
			// マップにキーがなければテンプレートファイルを読み込みに行く
			addCache( templateId );
		}
		return map.get( templateId );
	}
	
	private void addCache( String templatePath ) {
		try {
			String fullPath = AppDef.APP_DIR + "/sheettemplate/" + templatePath;
			String template = FileUtils.readFileToString( new File( fullPath ), "utf-8" );
			map.put( templatePath, template );
		} catch (IOException e) {
			Log.warn( e.getLocalizedMessage() );
			map.put( templatePath, null );
		}
	}
	
	public static void clearCache() {
		CsTemplateCache instance = CsTemplateCache.getInstance();
		instance.clearCacheData();
	}
	
	private void clearCacheData() {
		map = new ConcurrentHashMap<String, String>();
	}
	
}
