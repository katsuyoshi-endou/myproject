package jp.co.hisas.career.app.common.logic.sso;

import java.util.Objects;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import jp.co.hisas.career.app.common.event.CareerGuidEvArg;
import jp.co.hisas.career.app.common.event.CareerGuidEvHdlr;
import jp.co.hisas.career.app.common.event.CareerGuidEvRslt;
import jp.co.hisas.career.app.common.event.LygLoginEvArg;
import jp.co.hisas.career.app.common.event.LygLoginEvHdlr;
import jp.co.hisas.career.app.common.event.LygLoginEvRslt;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.dto.CareerGuidDto;
import jp.co.hisas.career.util.dto.LygLoginDto;

/**
 * 認証用フィルタ
 */
public class LysitheaSso {
	public static AccountResult auth( HttpServletRequest request ) throws CareerException {
		Cookie[] cookies = request.getCookies();
		Cookie cookie = null;
		if (cookies == null) {
			// 有効なログインセッションでないのでダメです。
			return null;
		} else {
			for (Cookie c : cookies) {
				if(Objects.equals( c.getName(), SsoConsts.GUID_COOKIE_NAME )) {
					cookie = c;
					break;
				}
			}
			if (cookie == null) {
				// 有効なログインセッションでないのでダメです。
				return null;
			}
		}
		
		AccountResult result = resolveAccount( cookie.getValue() );
		
		return result;
	}
	
	private static AccountResult resolveAccount( String guid ) throws CareerException {
		AccountResult result = new AccountResult();
		CareerGuidDto guidResult = null;
		
		LygLoginDto login = getPortalLoginInfo( guid );
		
		if ( login != null ) {
			guidResult = getCareerGuid( login.getAccountId() );			
		}
		
		if ( guidResult != null && guidResult.getGuid() != null ) {
			result.setGuid( guidResult.getGuid() );
			result.setGunm( guidResult.getGunm() );
			result.setAuthed( true );
		} else {
			result.setAuthed( false );
		}
		
		return result;
	}
	
	private static CareerGuidDto getCareerGuid( String guid ) throws CareerException {
		CareerGuidDto dto = null;

		/* Set Args */
		CareerGuidEvArg arg = new CareerGuidEvArg( guid );
		arg.sharp = "INIT";
		arg.guid = guid;
		
		/* Execute Event */
		CareerGuidEvRslt result = CareerGuidEvHdlr.exec( arg );
		dto = result.careerGuidDto;
		
		return dto;
	}
	
	private static LygLoginDto getPortalLoginInfo( String authKey ) throws CareerException {
		/* Set Args */
		LygLoginEvArg arg = new LygLoginEvArg();
		arg.sharp = "INIT";
		arg.authKey = authKey;
		
		/* Execute Event */
		LygLoginEvRslt result = LygLoginEvHdlr.exec( arg );
		return result.lygLoginDto;
	}
}
