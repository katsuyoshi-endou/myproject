package jp.co.hisas.career.app.common.event;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.DualDao;
import jp.co.hisas.career.util.dto.DualDto;
import jp.co.hisas.career.util.log.Log;

public class DualEvHdlr extends AbstractEventHandler<DualEvArg, DualEvRslt> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static DualEvRslt exec( DualEvArg arg ) throws CareerException {
		DualEvHdlr handler = new DualEvHdlr();
		return handler.call( arg );
	}
	
	public DualEvRslt call( DualEvArg arg ) throws CareerException {
		DualEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected DualEvRslt execute( DualEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		DualEvRslt result = new DualEvRslt();
		
		result.dualDto = selectDual( arg );
		
		return result;
	}
	
	private DualDto selectDual( DualEvArg arg ) throws CareerException {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "select 1 as dummy from CAREER_GUID" );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		DualDao dao = new DualDao( this.loginNo );
		List<DualDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		if (list.size() > 0) {
			// DB access is OK
			return list.get( 0 );
		} else {
			throw new CareerException( "DualEvHdlr: Couldn't connect to DataBase." );
		}
	}
	
}
