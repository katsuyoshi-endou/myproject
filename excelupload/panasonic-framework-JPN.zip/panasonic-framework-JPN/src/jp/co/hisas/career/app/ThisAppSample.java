package jp.co.hisas.career.app;

/**
 * For AppDef.java
 */
public class ThisAppSample {

//	public static String APP_ID = "Sheet";
//	public static String APP_ID = "Talent";
//	public static String APP_ID = "Admin";

	/**
	 * Context root
	 * - build.properties
	 * - application.xml
	 * - web.xml
	 */
//	public static String CTX_ROOT = "career";
//	public static String CTX_ROOT = "sheet";
//	public static String CTX_ROOT = "talent";
//	public static String CTX_ROOT = "admin";

//	public static String HOME_JSP = "/view/sheet/SHVHOM.jsp";
//	public static String HOME_JSP = "/view/talent/TLVHOM.jsp";
//	public static String HOME_JSP = "/view/admin/AMVHOM.jsp";

}
