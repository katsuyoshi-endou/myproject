/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jp.co.hisas.career.util.dto.MailInfoDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * MAIL_INFO Data Access Object。
 * @author CareerDaoTool.xla
*/
public class MailInfoDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " SEND_NO as sendNo,"
                     + " STATUS as status,"
                     + " FROM_ADDRESS as fromAddress,"
                     + " TO_ADDRESS as toAddress,"
                     + " CC_ADDRESS as ccAddress,"
                     + " BCC_ADDRESS as bccAddress,"
                     + " TITLE as title,"
                     + " BODY as body,"
                     + " ACTION_PERSON_ID as actionPersonId,"
                     + " KIND as kind,"
                     + " MESSAGE as message,"
                     + " UPDATE_FUNCTION_ID as updateFunctionId,"
                     + " UPDATE_DATE as updateDate,"
                     + " RESERVED_STRING_1 as reservedString1,"
                     + " RESERVED_STRING_2 as reservedString2,"
                     + " RESERVED_STRING_3 as reservedString3,"
                     + " RESERVED_STRING_4 as reservedString4,"
                     + " RESERVED_STRING_5 as reservedString5,"
                     + " RESERVED_STRING_6 as reservedString6,"
                     + " RESERVED_STRING_7 as reservedString7,"
                     + " RESERVED_STRING_8 as reservedString8,"
                     + " RESERVED_STRING_9 as reservedString9,"
                     + " RESERVED_STRING_10 as reservedString10"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public MailInfoDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public MailInfoDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param sendNo 送信連番
     * @return MailInfoDto MAIL_INFOのレコード型データ。
     */ 
    public MailInfoDto select(Integer sendNo) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM MAIL_INFO"
                         + " WHERE SEND_NO = ?"
                         ;
        Log.sql("【DaoMethod Call】 MailInfoDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setIntToPreparedStatement(pstmt, 1, sendNo);
            rs = pstmt.executeQuery();
            MailInfoDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param pstmt PreparedStatement
     */ 
    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("【DaoMethod Call】 MailInfoDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param sql SQL文
     */ 
    public void executeDynamic(String sql) {

        Log.sql("【DaoMethod Call】 MailInfoDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private MailInfoDto transferRsToDto(ResultSet rs) throws SQLException {

        MailInfoDto dto = new MailInfoDto();
        dto.setSendNo(rs.getInt("sendNo"));
        dto.setStatus(rs.getInt("status"));
        dto.setFromAddress(DaoUtil.convertNullToString(rs.getString("fromAddress")));
        dto.setToAddress(DaoUtil.convertNullToString(rs.getString("toAddress")));
        dto.setCcAddress(DaoUtil.convertNullToString(rs.getString("ccAddress")));
        dto.setBccAddress(DaoUtil.convertNullToString(rs.getString("bccAddress")));
        dto.setTitle(DaoUtil.convertNullToString(rs.getString("title")));
        dto.setBody(DaoUtil.convertNullToString(rs.getString("body")));
        dto.setActionPersonId(DaoUtil.convertNullToString(rs.getString("actionPersonId")));
        dto.setKind(DaoUtil.convertNullToString(rs.getString("kind")));
        dto.setMessage(DaoUtil.convertNullToString(rs.getString("message")));
        dto.setUpdateFunctionId(DaoUtil.convertNullToString(rs.getString("updateFunctionId")));
        dto.setUpdateDate(DaoUtil.convertNullToString(rs.getString("updateDate")));
        dto.setReservedString1(DaoUtil.convertNullToString(rs.getString("reservedString1")));
        dto.setReservedString2(DaoUtil.convertNullToString(rs.getString("reservedString2")));
        dto.setReservedString3(DaoUtil.convertNullToString(rs.getString("reservedString3")));
        dto.setReservedString4(DaoUtil.convertNullToString(rs.getString("reservedString4")));
        dto.setReservedString5(DaoUtil.convertNullToString(rs.getString("reservedString5")));
        dto.setReservedString6(DaoUtil.convertNullToString(rs.getString("reservedString6")));
        dto.setReservedString7(DaoUtil.convertNullToString(rs.getString("reservedString7")));
        dto.setReservedString8(DaoUtil.convertNullToString(rs.getString("reservedString8")));
        dto.setReservedString9(DaoUtil.convertNullToString(rs.getString("reservedString9")));
        dto.setReservedString10(DaoUtil.convertNullToString(rs.getString("reservedString10")));
        return dto;
    }

}

