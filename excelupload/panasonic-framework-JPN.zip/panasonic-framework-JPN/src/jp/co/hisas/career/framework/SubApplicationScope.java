/*
 * All Rights Reserved. Copyright (C) 2004,2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Commandクラスのgetter/setterメソッドに付けるアノテーション。
 * プロパティのスコープを定める。
 * このスコープは、アプリケーションのサブシステムごとに変数を保持し続けることを表す。
 * 画面上部のメニューから画面遷移したとき、この値はクリアされる。
 * @author kats-watanabe
 */
@Target( ElementType.METHOD )
@Retention( RetentionPolicy.RUNTIME )
public @interface SubApplicationScope {

    SubApplication value();

}
