package jp.co.hisas.career.app.common.event;

import java.sql.SQLException;
import java.util.List;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.CareerMenuActiveDao;
import jp.co.hisas.career.util.dto.CareerMenuActiveDto;
import jp.co.hisas.career.util.log.Log;

public class CareerMenuEvHdlr extends AbstractEventHandler<CareerMenuEvArg, CareerMenuEvRslt> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static CareerMenuEvRslt exec( CareerMenuEvArg arg ) throws CareerException {
		CareerMenuEvHdlr handler = new CareerMenuEvHdlr();
		return handler.call( arg );
	}
	
	public CareerMenuEvRslt call( CareerMenuEvArg arg ) throws CareerException {
		CareerMenuEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CareerMenuEvRslt execute( CareerMenuEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		CareerMenuEvRslt result = new CareerMenuEvRslt();
		
		try {
			
			if (SU.equals( "INIT", arg.sharp )) {
				result.careerMenuList = getActiveCareerMenuList( arg );
				result.careerMenuPtn = getMenuPtn( result.careerMenuList );
			} else if (SU.equals( "ONE_MENU", arg.sharp )) {
				result.oneMenu = getOneMenu( arg );
			}
			
			return result;
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
	}
	
	private String getMenuPtn( List<CareerMenuActiveDto> careerMenuList ) {
		return (careerMenuList.size() > 0) ? careerMenuList.get( 0 ).getMenuPtn() : null;
	}
	
	private List<CareerMenuActiveDto> getActiveCareerMenuList( CareerMenuEvArg arg ) throws SQLException {
		CareerMenuActiveDao dao = new CareerMenuActiveDao( this.loginNo );
		return dao.selectMenuByGrp( arg.guid, arg.menuGrp );
	}
	
	private CareerMenuActiveDto getOneMenu( CareerMenuEvArg arg ) throws SQLException {
		CareerMenuActiveDao dao = new CareerMenuActiveDao( this.loginNo );
		List<CareerMenuActiveDto> list = dao.selectOneMenu( arg.guid, arg.menuGrp, arg.menuId );
		CareerMenuActiveDto oneMenu = list.get( 0 );
		return oneMenu;
	}
	
}
