/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.app.common.servlet;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.download.bean.DownloadFileBean;
import jp.co.hisas.career.util.log.Log;

public class FileDownloadServlet extends HttpServlet {
	// 拡張子contentType対応テーブル
	private final static String[][] contentTypeTable = {
			{ "jpg", "image/jpeg" },
			{ "gif", "image/gif" },
			{ "txt", "text/plain" },
			{ "xls", "application/vnd.ms-excel" },
			{ "pdf", "application/octet-stream" },
			{ "html", "application/octet-stream" },
			{ "csv", "application/octet-stream" } };

	private final static int EXTENTION = 0;

	private final static int CONTENT_TYPE = 1;

	/** ServletContextオブジェクト */
	private ServletContext ctx = null;

	/**
	 * ServletContextオブジェクトを取得する。
	 * @param config Servletの設定や初期化パラメータが含まれているServletConfigオブジェクト
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * ブラウザからの検索要求を受け取り、クライアントBeanの検索処理メソッドを呼び出す。
	 * @param request クライアントのリクエストを表すHttpServletRequestオブジェクト
	 * @param response Servlet からのレスポンスを表すHttpServletResponseオブジェクト
	 * @exception IOException 入出力関連処理で発生する例外
	 * @exception ServletException Servlet の正常な処理が妨げられたときに発生する例外
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = null;

		try {
			
			/* sessionスコープのBeansを取得する */
			final HttpSession session = request.getSession(false);

			if (session == null) {
				final RequestDispatcher rd = this.ctx.getRequestDispatcher("/view/error.jsp");
				rd.forward(request, response);

			} else {
				
				// CSRF対策 k-nishihara add start
				CSRFTokenUtil.checkTokenNo(request);
				// CSRF対策 k-nishihara add end
				
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
				login_no = bean.getLogin_no();
				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				/* ファイル読み込み用バッファ */
				final byte[] buffer = new byte[4096];

				/* ストリーム出力 */
				ByteArrayInputStream bais = null;
				// ダウンロード用コンテナ
				DownloadFileBean container = (DownloadFileBean) session.getAttribute("downloadFileContainer");

				if (container != null && container.isDownolad()) { // ダウンロード用コンテナが存在する場合
					// 必要な情報を設定する
					response.setContentType(this.createHeaerContentType(container.getContentType(), container.getFileName()));
					response.setHeader("Content-disposition", "attachment; " + this.createHeaderFileName(container.getFileName()));
					// ファイル出力
					response.getOutputStream().write(container.getFlieData());
					// close
					response.getOutputStream().close();
					// 出力情報の明示的Commit
					response.flushBuffer();
					// ダウンロードファイル情報をクリア
					container = null;
					session.setAttribute("downloadFileContainer", null);
				} else { // それ以外
					/* ファイル名を取得 */
					String filePath = PZZ010_CharacterUtil.strEncode(request.getParameter("H079_FilePath"));
					String fileName = PZZ010_CharacterUtil.strEncode(request.getParameter("H080_FileName"));
					String contentType = PZZ010_CharacterUtil.strEncode(request.getParameter("H081_ContentType"));
					
					/* 送信元がサーブレットの場合 */
					if (filePath == null && fileName == null) {
						filePath = (String) request.getAttribute("H079_FilePath");
						fileName = (String) request.getAttribute("H080_FileName");
						contentType = (String) request.getAttribute("H081_ContentType");
						bais = (ByteArrayInputStream) request.getAttribute("STREAM");
					}

					// モバイル端末ブラウザ向け振り分け処理
					String mobileBrowserFlg = (String) request.getAttribute("mobileBrowserFlg");
					boolean isMobileBrowser = ("1".equals(mobileBrowserFlg)) ? true : false ;
					String headerFilename;
					if (isMobileBrowser) {
						// iOS Safariにファイル名を渡すとデータ内容が表示できない
						headerFilename = "";
					} else {
						headerFilename = this.createHeaderFileName(fileName);
					}

//                  BC0405-01-009 修正対応　2009/09/29 YOSHIDA START
					fileName = new String(fileName.getBytes("Windows-31J"), "ISO-8859-1");
//					BC0405-01-009 修正対応　2009/09/29 YOSHIDA END

					/* contentTypeを出力 */
					response.setContentType(this.createHeaerContentType(contentType, fileName));
					/* ファイル名の送信(attachment部分をinlineに変更すればインライン表示) */
					response.setHeader("Content-disposition", "attachment; " + headerFilename);

					/* ファイル内容の出力 */
					final ServletOutputStream out = response.getOutputStream();

					/* セッションにあるByteArrayInputStreamを出力 */
					if (bais != null) {
						int size;

						while ((size = bais.read(buffer)) != -1) {
							out.write(buffer, 0, size);
						}

						bais.close();
						out.close();
					}
					/* 指定されたパス、ファイル名を出力 */
					else {
						final FileInputStream fin = new FileInputStream(filePath + "/" + fileName);
						int size;

						while ((size = fin.read(buffer)) != -1) {
							out.write(buffer, 0, size);
						}

						fin.close();
						out.close();
					}

					response.flushBuffer();
				}

				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}
	}

	/**
	 * ファイル名から拡張子を取り出す
	 * @param fileName
	 * @return
	 */
	private String getExtention(final String fileName) {
		if (fileName != null) {
			final int idx = fileName.lastIndexOf('.');

			if (idx != -1) {
				return fileName.substring(idx + 1);
			}
		}
		return "";
	}

	/**
	 * 拡張子からcontentTypeを取り出す
	 * @param fileName
	 * @return
	 */
	private String getContentType(final String fileName) {
		final String extention = this.getExtention(fileName);

		for (int j = 0; j < FileDownloadServlet.contentTypeTable.length; j++) {
			if (FileDownloadServlet.contentTypeTable[j][FileDownloadServlet.EXTENTION].equalsIgnoreCase(extention)) {
				return FileDownloadServlet.contentTypeTable[j][FileDownloadServlet.CONTENT_TYPE];
			}
		}

		return "application/octet-stream";
	}

	/**
	 * ファイル名からResponseのヘッダに設定する文字列を生成する
	 * @param fileName ファイル名
	 * @return ヘッダ設定用ファイル名
	 */
	private String createHeaderFileName(final String fileName) {
		String headerFileName = "";
		if (fileName != null && fileName.length() > 0) {
			headerFileName = "filename=\"" + fileName + "\"";
		}
		return headerFileName;
	}

	/**
	 * ContentTypeからResponseのヘッダに設定する文字列を生成する<br>
	 * 未設定の場合、ファイル名の拡張子からcontentTypeを判定、生成する。
	 * @param contentType ContentType
	 * @param fileName ファイル名
	 * @return ヘッダ設定用ContentType
	 */
	private String createHeaerContentType(final String contentType, final String fileName) {
		if (contentType != null && contentType.length() > 0) {
			return contentType + "; charset=Windows-31J";
		} else {
			return this.getContentType(fileName) + "; charset=Windows-31J";
		}
	}
}
