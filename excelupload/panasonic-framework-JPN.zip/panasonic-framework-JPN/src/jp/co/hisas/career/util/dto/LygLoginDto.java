/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * キャリアGUID Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class LygLoginDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * GUID
     */
    private String guid;
    /**
     * アカウントID
     */
    private String accountId;
    /**
     * ログイン日時
     */
    private String loginDatetime;
    /**
     * 最終操作日時
     */
    private String lastOperationDatetime;
    /**
     * ログアウトリダイレクト目標
     */
    private String logoutRedirectTarget;
    /**
     * XSRF対策トークン
     */
    private String tokenForXsrfMeasure;

    /**
     * GUIDを取得する。
     * @return GUID
     */
    public String getGuid() {
        return guid;
    }

    /**
     * GUIDを設定する。
     * @param guid GUID
     */
    public void setGuid(String guid) {
        this.guid = guid;
    }

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId( String accountId ) {
		this.accountId = accountId;
	}

	public String getLoginDatetime() {
		return loginDatetime;
	}

	public void setLoginDatetime( String loginDatetime ) {
		this.loginDatetime = loginDatetime;
	}

	public String getLastOperationDatetime() {
		return lastOperationDatetime;
	}

	public void setLastOperationDatetime( String lastOperationDatetime ) {
		this.lastOperationDatetime = lastOperationDatetime;
	}

	public String getLogoutRedirectTarget() {
		return logoutRedirectTarget;
	}

	public void setLogoutRedirectTarget( String logoutRedirectTarget ) {
		this.logoutRedirectTarget = logoutRedirectTarget;
	}

	public String getTokenForXsrfMeasure() {
		return tokenForXsrfMeasure;
	}

	public void setTokenForXsrfMeasure( String tokenForXsrfMeasure ) {
		this.tokenForXsrfMeasure = tokenForXsrfMeasure;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}


}

