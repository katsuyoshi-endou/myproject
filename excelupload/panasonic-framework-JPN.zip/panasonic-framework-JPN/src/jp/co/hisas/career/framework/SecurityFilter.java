package jp.co.hisas.career.framework;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.framework.exception.CareerSecurityException;
import jp.co.hisas.career.util.log.Log;

public class SecurityFilter implements Filter {
	
	private ServletContext ctx = null;
	
	static final String ERR_ID_UNEXPECTED = "HJE-0021";
	static final String ERR_ID_ILLEGAL = "HJE-0022";
	
	/** ログイン時メンテナンス権限チェック */
	static final String CHK_KENGEN_MAINTENANCE_AT_LOGIN = "CHK_KENGEN_MAINTENANCE_AT_LOGIN";
	/** メンテナンスモードチェック */
	static final String CHK_MAINTENANCE_MODE = "CHK_MAINTENANCE_MODE";
	/** 退職者検索権限チェック */
	static final String CHK_KENGEN_TAISYOKUSYA_KENSAKU = "CHK_KENGEN_TAISYOKUSYA_KENSAKU";
	/** 参照可能組織チェック */
	static final String CHK_KENGEN_SOSIKI_REF_RANGE = "CHK_KENGEN_SOSIKI_REF_RANGE";
	/** 個人情報検索参照範囲チェック */
	static final String CHK_KOJINKENSAKU_REF_RANGE = "CHK_KOJINKENSAKU_REF_RANGE";
	/** 自由条件検索参照範囲チェック */
	static final String CHK_JIYUKENSAKU_REF_RANGE = "CHK_JIYUKENSAKU_REF_RANGE";
	/** キャリアチャレンジ参照範囲チェック */
	static final String CHK_CAREERCHALLENGE_REF_RANGE = "CHK_CAREERCHALLENGE_REF_RANGE";
	
	/** メニュー権限チェック **/
	static final String CHK_MENU_KENGEN = "CHK_MENU_KENGEN";
	/** 社員検索設定範囲チェック **/
	static final String CHK_SHAIN_INPUT_RANGE = "CHK_SHAIN_INPUT_RANGE";
	/** 評価書参照範囲チェック **/
	static final String CHK_HYOUKASHO_REF_RANGE = "CHK_HYOUKASHO_REF_RANGE";
	/** 部下一覧参照範囲チェック **/
	static final String CHK_BUKAICHIRAN_RANGE = "CHK_BUKAICHIRAN_RANGE";
	/** 面談記録参照範囲チェック **/
	static final String CHK_MENDANKIROKU_REF_RANGE = "CHK_MENDANKIROKU_REF_RANGE";
	
	static Map<String, String> checkTableMap = new HashMap<String, String>();
	
	String[][] checkTableCore = new String[][] {
			// { サーブレットパス, リクエストパラメータ名称, チェック処理 }
			new String[] { "SearchPersonalServlet",					"kengen",			CHK_MENU_KENGEN },
			new String[] { "PDC010_BukaIchiranServlet",				"kengen",			CHK_MENU_KENGEN },
			new String[] { "PEE010_HyokaSheetSakuseiServlet",		"kengen",			CHK_MENU_KENGEN },
			new String[] { "PDA010_FreeConditionalSearchServlet",	"kengen",			CHK_MENU_KENGEN },
			new String[] { "PEE020_HyokaSheetSentakuServlet",		"kengen",			CHK_MENU_KENGEN },
			new String[] { "PEE020_HyokaSheetSentakuServlet",		"select_sheet_id",	CHK_HYOUKASHO_REF_RANGE },
			new String[] { "PEE110_HyokaSheetHyokaServlet",			"hyokaSheetAction",	CHK_SHAIN_INPUT_RANGE },
			new String[] { "SearchPersonalServlet",					"personID",			CHK_BUKAICHIRAN_RANGE },
			new String[] { "SearchPersonalServlet",					"kirokuNo",			CHK_MENDANKIROKU_REF_RANGE }
	};
	
	public class SecurityFilterLocalItem {
		HttpServletRequest _request = null;
		HttpSession _session = null;
		UserInfoBean _userInfo = null;
		String _loginNo = "";
	}
	
	public void init( final FilterConfig config ) throws ServletException {
		
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
			
			for (int i = 0; i < checkTableCore.length; i++) {
				// Servletと変数名の組合せをキーとするため、両者を#で連結
				// key:Servlet#paramName, value:checkMethod
				checkTableMap.put( "/" + AppDef.CTX_ROOT + "/servlet/" + checkTableCore[i][0] + "#" + checkTableCore[i][1], checkTableCore[i][2] );
			}
		}
		
	}
	
	public void doFilter( final ServletRequest request, final ServletResponse response, final FilterChain chain ) throws IOException, ServletException {
		
		SecurityFilterLocalItem item = new SecurityFilterLocalItem();
		try {
			item._request = (HttpServletRequest)request;
			item._session = item._request.getSession( false );
			item._userInfo = (item._session != null) ? (UserInfoBean)item._session.getAttribute( "userinfo" ) : null;
			item._loginNo = (item._userInfo != null) ? item._userInfo.getLogin_no() : "";
			
			this.doSecurityCheck( item );
			
			chain.doFilter( request, response );
			
		} catch (final CareerSecurityException e) {
			Log.securityError( item._loginNo, "◆不正操作検出" );
			Log.error( item._loginNo, ERR_ID_ILLEGAL, e ); // 不正操作検出
			this.ctx.getRequestDispatcher( "/view/error.jsp" ).forward( request, response );
			
		} catch (final Exception e) {
			Log.securityError( item._loginNo, "▲セキュリティフィルタで予期せぬエラー発生" );
			Log.error( item._loginNo, ERR_ID_UNEXPECTED, e ); // セキュリティフィルタのバグ
			this.ctx.getRequestDispatcher( "/view/error.jsp" ).forward( request, response );
		}
	}
	
	public void destroy() {
	}
	
	/**
	 * セキュリティチェック処理<br>
	 * <br>
	 * 調査用 Security.log の出力切替は log4j.properties を編集。<br>
	 * ---------------------------------------------------------------<br>
	 * 【出力する】<br>
	 * log4j.category.CTG_SECURITY = DEBUG, APN_SECURITY<br>
	 * 【出力しない】<br>
	 * log4j.category.CTG_SECURITY = INFO, APN_SECURITY<br>
	 * ---------------------------------------------------------------<br>
	 * ※定義記述は他のカテゴリと同様に必要。<br>
	 * 
	 * @param loginNo
	 * @param request
	 * @throws Exception
	 */
	public void doSecurityCheck( SecurityFilterLocalItem item ) throws Exception {
		
		final String reqURL = item._request.getRequestURI();
		final Map<?, ?> reqParamMap = item._request.getParameterMap();
		
		for (Iterator<?> ite = reqParamMap.keySet().iterator(); ite.hasNext();) {
			
			String reqParamName = (String)ite.next();
			String[] reqParamValueArr = (String[])reqParamMap.get( reqParamName );
			String reqParamValue = reqParamValueArr[0];
			
			if (reqParamName == null || reqParamValue == null || "null".equals( reqParamValue )) {
				// チェック処理上でのNullPointerExceptionを排除
				continue;
			}
			
			Log.security( item._loginNo, "[" + reqURL + "] [" + reqParamName + "=" + cnvStrArr( reqParamValueArr ) + "]" );
			
			/* Servletと変数名の組合せからチェック処理を導く */
			String checkMethod = (String)checkTableMap.get( reqURL + "#" + reqParamName );
			if (checkMethod != null) {
				
				Log.security( "★", reqParamName + "に対して" + checkMethod + "を実行します。" );
				
				if (CHK_KENGEN_MAINTENANCE_AT_LOGIN.equals( checkMethod )) {
//					this.checkKengen_MaintenanceAtLogin( reqParamName, reqParamValue, item );
				} else if (CHK_MAINTENANCE_MODE.equals( checkMethod )) {
//					this.check_MaintenanceMode( reqParamName, reqParamValue, item );
				} else if (CHK_KENGEN_TAISYOKUSYA_KENSAKU.equals( checkMethod )) {
//					this.checkKengen_TaisyokusyaKensaku( reqParamName, reqParamValue, item );
				} else if (CHK_KOJINKENSAKU_REF_RANGE.equals( checkMethod )) {
//					this.check_KojinkensakuRefRange( reqParamName, reqParamValue, item );
				} else if (CHK_JIYUKENSAKU_REF_RANGE.equals( checkMethod )) {
//					this.check_JiyukensakuRefRange( reqParamName, reqParamValue, item );
				} else if (CHK_MENU_KENGEN.equals( checkMethod )) {
//					this.checkMenuKengen( reqParamName, reqParamValue, item );
				} else if (CHK_BUKAICHIRAN_RANGE.equals( checkMethod )) {
//					this.checkBukaichiranRefRange( reqParamName, reqParamValue, item );
				} else if (CHK_MENDANKIROKU_REF_RANGE.equals( checkMethod )) {
//					this.check_MendanRefRange( reqParamName, reqParamValue, item );
				}
			}
		}
	}
	
	/**
	 * String配列を１行String（カンマ区切り）にして返す。
	 */
	public String cnvStrArr( String[] str ) {
		String rtnStr = "";
		if (str == null) {
			return rtnStr;
		}
		for (int i = 0; i < str.length; i++) {
			if (i == 0) {
				rtnStr = str[i];
			} else {
				rtnStr = rtnStr + "," + str[i];
			}
		}
		return rtnStr;
	}
	
}
