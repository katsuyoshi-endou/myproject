package jp.co.hisas.career.app.common.bean;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.event.CareerMenuEvArg;
import jp.co.hisas.career.app.common.event.CareerMenuEvHdlr;
import jp.co.hisas.career.app.common.event.CareerMenuEvRslt;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dto.CareerMenuActiveDto;

public class CareerMenuBean implements Serializable {
	
	public String guid;
	public String menuGrp;
	public String menuId;
	public String menuLabel;
	public String menuPath;
	public String menuTrans;
	public String party;
	public String partyLabel;
	public String lpadSort;
	public String availFlg;
	public String menuPtn;
	
	public CareerMenuBean() {
	}
	
	public static void init( HttpServletRequest request ) throws CareerException {
		HttpSession session = request.getSession( false );
		UserInfoBean userinfo = (UserInfoBean)session.getAttribute( "userinfo" );
		String loginNo = SU.ntb( userinfo.getLogin_no() );
		
		String selectedMenuGrp = AU.getSessionAttr( session, AppSessionKey.CAREER_MENU_GRP );
		String selectedMenuId = AU.getRequestValue( request, "selectedMenuId" );
		
		/* Set Args */
		CareerMenuEvArg arg = new CareerMenuEvArg( loginNo );
		arg.sharp = "ONE_MENU";
		arg.guid = loginNo;
		arg.menuGrp = selectedMenuGrp;
		arg.menuId = selectedMenuId;
		
		/* Execute Event */
		CareerMenuEvRslt result = CareerMenuEvHdlr.exec( arg );
		
		/* Set to session */
		CareerMenuBean bean = convDto2Bean( result.oneMenu );
		session.setAttribute( AppSessionKey.CAREER_ONE_MENU, bean );
	}
	
	private static CareerMenuBean convDto2Bean( CareerMenuActiveDto dto ) {
		CareerMenuBean bean = new CareerMenuBean();
		bean.guid        = dto.getGuid();
		bean.menuGrp     = dto.getMenuGrp();
		bean.menuId      = dto.getMenuId();
		bean.menuLabel   = dto.getMenuLabel();
		bean.menuPath    = dto.getMenuPath();
		bean.menuTrans   = dto.getMenuTrans();
		bean.party       = dto.getParty();
		bean.partyLabel  = dto.getPartyLabel();
		bean.lpadSort    = dto.getLpadSort();
		bean.availFlg    = dto.getAvailFlg();
		bean.menuPtn     = dto.getMenuPtn();
		return bean;
	}
}