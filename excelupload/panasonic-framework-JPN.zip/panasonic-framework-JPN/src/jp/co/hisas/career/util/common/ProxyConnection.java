package jp.co.hisas.career.util.common;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import jp.co.hisas.career.util.log.Log;

/**
 * Connectionクラスのプロキシクラス
 * http://codezine.jp/article/detail/151
 * @author k-ozawa
 */
public class ProxyConnection {
    private Connection connection;
    private Set<Statement> openedStatements;
    private Set<ResultSet> openedResultSets;
    private Object proxy;

    protected void finalize() throws Throwable {
        try {
            super.finalize();
        } finally {
            if (connection != null && !connection.isClosed()) {
            	//add B-CT-0621 k-nishihara start
            	Log.sql("【ProxyConnection finalize close】");
            	//add B-CT-0621 k-nishihara end
                connection.close();
            }
        }
    }

    private ProxyConnection(Connection org) {
        connection = org;
        openedStatements = new HashSet<Statement>();
        openedResultSets = new HashSet<ResultSet>();
        proxy = Proxy.newProxyInstance(Connection.class.getClassLoader(),
                new Class[] { Connection.class }, new ConnectionHandler());
    }

    /**
     * 指定されたコネクションのプロキシを生成する。
     * @param c 生成対象のコネクション
     * @return PreparedStatementとResultSetのclose検証処理を 含んだコネクション
     */
    public static Connection createProxy(Connection c) {
        ProxyConnection pc = new ProxyConnection(c);
        return (Connection) pc.proxy;
    }

    private Object send(Object target, Method m, Object[] args)
            throws Throwable {
        try {
            return m.invoke(target, args);
        } catch (InvocationTargetException e) {
            if (e.getCause() != null) {
                throw e.getCause();
            }
            throw e;
        }
    }

    private void remove(Object o) {
        if (o instanceof ResultSet) {
            openedResultSets.remove(o);
        } else if (o instanceof Statement) {
            openedStatements.remove(o);
        } else {
            throw new IllegalArgumentException("bad class:" + o);
        }
    }

    private void closeAll() {
        for (ResultSet rs : openedResultSets) {
            try {
                rs.close();
            } catch (SQLException e) {
            }
        }
        for (Statement ps : openedStatements) {
            try {
                ps.close();
            } catch (SQLException e) {
            }
        }
    }

    private class ConnectionHandler implements InvocationHandler {
        public Object invoke(Object proxy, Method method, Object[] args)
                throws Throwable {
            if (method.getName().equals("close")) {
                closeAll();
            }
            Object o = send(connection, method, args);
            if (o instanceof Statement) {
                openedStatements.add((Statement) o);
                o = new Delegate(o, PreparedStatement.class).proxy;
            }
            return o;
        }
    }

    private class Delegate implements InvocationHandler {
        private Object proxy;
        private Object original;

        private Delegate(Object o, Class<?> c) {
            original = o;
            proxy = Proxy.newProxyInstance(c.getClassLoader(),
                    new Class[] { c }, this);
        }

        public Object invoke(Object proxy, Method method, Object[] args)
                throws Throwable {
            if (method.getName().equals("close")) {
                remove(original);
            }
            Object o = send(original, method, args);
            if (o instanceof ResultSet) {
                openedResultSets.add((ResultSet) o);
                o = new Delegate(o, ResultSet.class).proxy;
            }
            return o;
        }
    }

}
