/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * DUAL Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class DualDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * DUMMY
     */
    private String dummy;

    /**
     * DUMMYを取得する。
     * @return DUMMY
     */
    public String getDummy() {
        return dummy;
    }

    /**
     * DUMMYを設定する。
     * @param dummy DUMMY
     */
    public void setDummy(String dummy) {
        this.dummy = dummy;
    }

}

