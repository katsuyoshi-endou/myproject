package jp.co.hisas.career.util.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ040_SQLUtility;

public class LocalConnectionManager {

	private boolean isCreateConnection = false;

	private String _loginNo;

	public LocalConnectionManager(String loginNo) {
		_loginNo = loginNo;
		if (null == PZZ040_SQLUtility.getCachedConnection()) {
			PZZ040_SQLUtility.createCachedConnection(_loginNo);
			isCreateConnection = true;
		}
	}

	public Connection getConnection() throws SQLException, NamingException {
		return PZZ040_SQLUtility.getCachedConnection();
	}

	public void releaseConnection() {
		if (isCreateConnection) {
			PZZ040_SQLUtility.removeCachedConnection();
			isCreateConnection = false;
		}
	}

	protected void finalize() throws Throwable {
		try {
			super.finalize();
		} finally {
			releaseConnection();
		}
	}

}
