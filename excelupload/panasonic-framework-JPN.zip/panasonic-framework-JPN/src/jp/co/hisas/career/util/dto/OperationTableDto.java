package jp.co.hisas.career.util.dto;

import java.io.Serializable;
import java.util.List;

public class OperationTableDto implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private List<String> colValueList;

	public List<String> getColValueList() { return colValueList; }
	public void setColValueList( List<String> colValueList ) { this.colValueList = colValueList; }
	
}
