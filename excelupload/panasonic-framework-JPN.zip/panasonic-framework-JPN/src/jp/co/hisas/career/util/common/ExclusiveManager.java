/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */

package jp.co.hisas.career.util.common;

/**
 * 排他制御用ユーティリティ<br>
 * 
 * <pre>
 *     使い方：
 *     if(ExclusiveManager.getInstance().getExclusiveLock(&lt;&lt;排他ロジック&gt;&gt;,&lt;&lt;key&gt;&gt;)){
 *       try{
 *         &lt;&lt;排他成功時の処理&gt;&gt;
 *       }finally{
 *         ExclusiveManager.getInstance().releaseExclusiveLock(&lt;&lt;排他ロジック&gt;&gt;,&lt;&lt;key&gt;&gt;);
 *       }
 *     } else {
 *       &lt;&lt;排他失敗時の処理&gt;&gt;
 *     }
 * </pre>
 */
public class ExclusiveManager {
	private static final ExclusiveManager singleton = new ExclusiveManager();

	/**
	 * コンストラクタ
	 */
	private ExclusiveManager() {
	}

	/**
	 * インスタンスを取得する。
	 * @return インスタンス
	 */
	public static ExclusiveManager getInstance() {
		return ExclusiveManager.singleton;
	}

	/** ロックを取得する */
	public boolean getExclusiveLock(final ExclusiveLogic logic, final Object key) {
		if (!logic.checkKey(key)) {
			throw new IllegalArgumentException();
		}
		return logic.getExclusiveLock(key);
	}

	/** ロックを解放する */
	public void releaseExclusiveLock(final ExclusiveLogic logic, final Object key) {
		if (!logic.checkKey(key)) {
			throw new IllegalArgumentException();
		}
		logic.releaseExclusiveLock(key);
	}
}
