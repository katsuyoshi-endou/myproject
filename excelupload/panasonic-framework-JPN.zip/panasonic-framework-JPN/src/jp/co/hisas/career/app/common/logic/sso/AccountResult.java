package jp.co.hisas.career.app.common.logic.sso;

import org.omg.IOP.ServiceContext;

/**
 * {@link com.hisol.lysithea.sso.service.AccountService#resolveAccount(ServiceContext, String)}
 * メソッドの戻り値を保持するクラス
 */
public class AccountResult {

	private String guid;
	
	private String gunm;
	
	private boolean isAuthed;

	private String selectedLanguageId;
	
	private String tokenForXsrfMeasure;

	/**
	 * 選択言語IDを取得します。
	 * 
	 * @return 選択言語ID
	 */
	public String getSelectedLanguageId() {
		return selectedLanguageId;
	}

	/**
	 * 選択言語IDを設定します。
	 * 
	 * @param selectedLanguageId 選択言語ID
	 */
	public void setSelectedLanguageId(String selectedLanguageId) {
		this.selectedLanguageId = selectedLanguageId;
	}

	/**
	 * XSRF対策用トークンを取得します。
	 * 
	 * @return XSRF対策用トークン
	 */
	public String getTokenForXsrfMeasure() {
		return tokenForXsrfMeasure;
	}

	/**
	 * XSRF対策用トークンを設定します。
	 * 
	 * @param tokenForXsrfMeasure XSRF対策用トークン
	 */
	public void setTokenForXsrfMeasure(String tokenForXsrfMeasure) {
		this.tokenForXsrfMeasure = tokenForXsrfMeasure;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid( String guid ) {
		this.guid = guid;
	}

	public String getGunm() {
		return gunm;
	}

	public void setGunm( String gunm ) {
		this.gunm = gunm;
	}
	
	public boolean isAuthed() {
		return isAuthed;
	}

	public void setAuthed( boolean isAuthed ) {
		this.isAuthed = isAuthed;
	}
}
