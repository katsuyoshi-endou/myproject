/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * 操作ログ Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CjsLogSousaDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 実行日付
     */
    private String jikkouHiduke;
    /**
     * 実行時刻
     */
    private String jikkouJikoku;
    /**
     * 実行機能ID
     */
    private String jikkouKinouId;
    /**
     * 実行氏名No
     */
    private String jikkouSimeiNo;
    /**
     * 対象氏名No
     */
    private String taisyouSimeiNo;
    /**
     * 条件
     */
    private String jouken;

    /**
     * 実行日付を取得する。
     * @return 実行日付
     */
    public String getJikkouHiduke() {
        return jikkouHiduke;
    }

    /**
     * 実行日付を設定する。
     * @param jikkouHiduke 実行日付
     */
    public void setJikkouHiduke(String jikkouHiduke) {
        this.jikkouHiduke = jikkouHiduke;
    }

    /**
     * 実行時刻を取得する。
     * @return 実行時刻
     */
    public String getJikkouJikoku() {
        return jikkouJikoku;
    }

    /**
     * 実行時刻を設定する。
     * @param jikkouJikoku 実行時刻
     */
    public void setJikkouJikoku(String jikkouJikoku) {
        this.jikkouJikoku = jikkouJikoku;
    }

    /**
     * 実行機能IDを取得する。
     * @return 実行機能ID
     */
    public String getJikkouKinouId() {
        return jikkouKinouId;
    }

    /**
     * 実行機能IDを設定する。
     * @param jikkouKinouId 実行機能ID
     */
    public void setJikkouKinouId(String jikkouKinouId) {
        this.jikkouKinouId = jikkouKinouId;
    }

    /**
     * 実行氏名Noを取得する。
     * @return 実行氏名No
     */
    public String getJikkouSimeiNo() {
        return jikkouSimeiNo;
    }

    /**
     * 実行氏名Noを設定する。
     * @param jikkouSimeiNo 実行氏名No
     */
    public void setJikkouSimeiNo(String jikkouSimeiNo) {
        this.jikkouSimeiNo = jikkouSimeiNo;
    }

    /**
     * 対象氏名Noを取得する。
     * @return 対象氏名No
     */
    public String getTaisyouSimeiNo() {
        return taisyouSimeiNo;
    }

    /**
     * 対象氏名Noを設定する。
     * @param taisyouSimeiNo 対象氏名No
     */
    public void setTaisyouSimeiNo(String taisyouSimeiNo) {
        this.taisyouSimeiNo = taisyouSimeiNo;
    }

    /**
     * 条件を取得する。
     * @return 条件
     */
    public String getJouken() {
        return jouken;
    }

    /**
     * 条件を設定する。
     * @param jouken 条件
     */
    public void setJouken(String jouken) {
        this.jouken = jouken;
    }

}

