package jp.co.hisas.career.util.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dto.TableInfoDto;
import jp.co.hisas.career.util.log.Log;

public class TableInfoDao {
	
	Connection conn;
	boolean isConnectionGiven = false;
	String loginNo;
	
	
	public TableInfoDao(String loginNo) {
		this.loginNo = loginNo;
	}
	
	public TableInfoDao(Connection conn) {
		this.conn = conn;
		this.isConnectionGiven = true;
	}
	
	private Connection getConnection() {
		Connection connection = isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
		if (connection == null) {
			throw new CareerRuntimeException();
		}
		return connection;
	}
	
	public List<String> getTableList() {
		
		String sql = "";
		
		Log.sql( "【DaoMethod Call】 TableInfoDao.getTableList" );
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			
			sql = " select TABLE_NAME from USER_TABLES order by TABLE_NAME " ;
			pstmt = conn.prepareStatement( sql );
			rs = pstmt.executeQuery();
			List<String> tables = new ArrayList<String>();
			while ( rs.next() ) {
				tables.add( DaoUtil.convertNullToString( rs.getString( "TABLE_NAME" ) ) );
			}
			
			return tables;
			
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, rs );
		}
	}
	
	public List<TableInfoDto> getTableColumnList( String tableName ) {
		
		StringBuilder sql = new StringBuilder();
		
		Log.sql( "【DaoMethod Call】 TableInfoDao.getTableColumnList" );
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			
			sql.append( " SELECT " );
			sql.append( "    C.TABLE_NAME " );
			sql.append( "   ,B.COMMENTS AS TABLE_COMMENT " );
			sql.append( "   ,C.COLUMN_NAME " );
			sql.append( "   ,U.COMMENTS AS COLUMN_COMMENT " );
			sql.append( "   ,C.DATA_TYPE " );
			sql.append( "   ,CASE " );
			sql.append( "      WHEN C.DATA_TYPE = 'NUMBER' THEN '(' || C.DATA_PRECISION || ',' || C.DATA_SCALE || ')' " );
			sql.append( "      WHEN C.CHAR_USED = 'C'      THEN '(' || C.CHAR_LENGTH || ' CHAR' || ')' " );
			sql.append( "      WHEN C.CHAR_USED = 'B'      THEN '(' || C.CHAR_LENGTH || ')' " );
			sql.append( "      ELSE NULL " );
			sql.append( "    END AS LENGTH " );
			sql.append( "   ,DECODE(P.POSITION, NULL, NULL, 'Yes') PK " );
			sql.append( "   ,DECODE(C.NULLABLE,'N','Yes',NULL) NOTNULL " );
			sql.append( " FROM " );
			sql.append( "   USER_TAB_COLUMNS C " );
			sql.append( "   LEFT OUTER JOIN USER_TABLES T " );
			sql.append( "     ON (C.TABLE_NAME = T.TABLE_NAME) " );
			sql.append( "   LEFT OUTER JOIN USER_COL_COMMENTS U " );
			sql.append( "     ON (U.TABLE_NAME=C.TABLE_NAME AND U.COLUMN_NAME = C.COLUMN_NAME) " );
			sql.append( "   LEFT OUTER JOIN USER_TAB_COMMENTS B " );
			sql.append( "     ON (B.TABLE_NAME=C.TABLE_NAME) " );
			sql.append( "   LEFT OUTER JOIN USER_CONS_COLUMNS P " );
			sql.append( "     ON (P.TABLE_NAME=C.TABLE_NAME AND P.COLUMN_NAME = C.COLUMN_NAME AND P.POSITION IS NOT NULL) " );
			sql.append( " WHERE " );
			sql.append( "     C.TABLE_NAME = '" + tableName + "' " );
			sql.append( " ORDER BY " );
			sql.append( "   C.TABLE_NAME, C.COLUMN_ID " );
			
			pstmt = conn.prepareStatement( sql.toString() );
			rs = pstmt.executeQuery();
			List<TableInfoDto> cols = new ArrayList<TableInfoDto>();
			while ( rs.next() ) {
				TableInfoDto dto = new TableInfoDto();
				dto.setTableName     ( DaoUtil.convertNullToString( rs.getString( "TABLE_NAME" ) ) );
				dto.setTableComment  ( DaoUtil.convertNullToString( rs.getString( "TABLE_COMMENT" ) ) );
				dto.setColumnName    ( DaoUtil.convertNullToString( rs.getString( "COLUMN_NAME" ) ) );
				dto.setColumnComment ( DaoUtil.convertNullToString( rs.getString( "COLUMN_COMMENT" ) ) );
				dto.setDataType      ( DaoUtil.convertNullToString( rs.getString( "DATA_TYPE" ) ) );
				dto.setLength        ( DaoUtil.convertNullToString( rs.getString( "LENGTH" ) ) );
				dto.setPk            ( DaoUtil.convertNullToString( rs.getString( "PK" ) ) );
				dto.setNotNull       ( DaoUtil.convertNullToString( rs.getString( "NOTNULL" ) ) );
				cols.add( dto );
			}
			
			return cols;
			
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, rs );
		}
	}
	
}
