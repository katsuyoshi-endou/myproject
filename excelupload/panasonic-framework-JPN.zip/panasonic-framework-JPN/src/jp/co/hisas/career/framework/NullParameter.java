package jp.co.hisas.career.framework;

public class NullParameter implements SQLParameter {
	
	public String getFormatedParameter() {
		return "NULL";
	}
	
	public String getParameter() {
		return null;
	}
	
	public void setParameter( String parameter ) {
		
	}
	
}
