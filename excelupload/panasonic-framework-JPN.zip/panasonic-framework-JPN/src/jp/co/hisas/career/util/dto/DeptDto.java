/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * 部署 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class DeptDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 会社コード
     */
    private String cmpaCd;
    /**
     * 部署コード
     */
    private String deptCd;
    /**
     * 部署名称
     */
    private String deptNm;
    /**
     * 親部署コード
     */
    private String parentDeptCd;
    /**
     * 連結部署コード
     */
    private String fullDeptCd;
    /**
     * 連結部署名称
     */
    private String fullDeptNm;
    /**
     * 階層
     */
    private Integer hierarchy;
    /**
     * ソート
     */
    private String lpadSort;
    /**
     * 組織長従業員番号
     */
    private String chiefStfNo;

    /**
     * 会社コードを取得する。
     * @return 会社コード
     */
    public String getCmpaCd() {
        return cmpaCd;
    }

    /**
     * 会社コードを設定する。
     * @param cmpaCd 会社コード
     */
    public void setCmpaCd(String cmpaCd) {
        this.cmpaCd = cmpaCd;
    }

    /**
     * 部署コードを取得する。
     * @return 部署コード
     */
    public String getDeptCd() {
        return deptCd;
    }

    /**
     * 部署コードを設定する。
     * @param deptCd 部署コード
     */
    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    /**
     * 部署名称を取得する。
     * @return 部署名称
     */
    public String getDeptNm() {
        return deptNm;
    }

    /**
     * 部署名称を設定する。
     * @param deptNm 部署名称
     */
    public void setDeptNm(String deptNm) {
        this.deptNm = deptNm;
    }

    /**
     * 親部署コードを取得する。
     * @return 親部署コード
     */
    public String getParentDeptCd() {
        return parentDeptCd;
    }

    /**
     * 親部署コードを設定する。
     * @param parentDeptCd 親部署コード
     */
    public void setParentDeptCd(String parentDeptCd) {
        this.parentDeptCd = parentDeptCd;
    }

    /**
     * 連結部署コードを取得する。
     * @return 連結部署コード
     */
    public String getFullDeptCd() {
        return fullDeptCd;
    }

    /**
     * 連結部署コードを設定する。
     * @param fullDeptCd 連結部署コード
     */
    public void setFullDeptCd(String fullDeptCd) {
        this.fullDeptCd = fullDeptCd;
    }

    /**
     * 連結部署名称を取得する。
     * @return 連結部署名称
     */
    public String getFullDeptNm() {
        return fullDeptNm;
    }

    /**
     * 連結部署名称を設定する。
     * @param fullDeptNm 連結部署名称
     */
    public void setFullDeptNm(String fullDeptNm) {
        this.fullDeptNm = fullDeptNm;
    }

    /**
     * 階層を取得する。
     * @return 階層
     */
    public Integer getHierarchy() {
        return hierarchy;
    }

    /**
     * 階層を設定する。
     * @param hierarchy 階層
     */
    public void setHierarchy(Integer hierarchy) {
        this.hierarchy = hierarchy;
    }

    /**
     * ソートを取得する。
     * @return ソート
     */
    public String getLpadSort() {
        return lpadSort;
    }

    /**
     * ソートを設定する。
     * @param lpadSort ソート
     */
    public void setLpadSort(String lpadSort) {
        this.lpadSort = lpadSort;
    }

    /**
     * 組織長従業員番号を取得する。
     * @return 組織長従業員番号
     */
    public String getChiefStfNo() {
        return chiefStfNo;
    }

    /**
     * 組織長従業員番号を設定する。
     * @param chiefStfNo 組織長従業員番号
     */
    public void setChiefStfNo(String chiefStfNo) {
        this.chiefStfNo = chiefStfNo;
    }

}

