package jp.co.hisas.career.framework.trans;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.framework.def.AC;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.Log;

public abstract class ResponsedServlet extends HttpServlet {
	
	protected ServletContext ctx = null;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	public void service( final HttpServletRequest req, final HttpServletResponse res ) throws IOException, ServletException {
		try {
			Tray tray = new Tray( req, res );
			
			Log.method( tray.loginNo, "IN", "" );
			Log.performance( tray.loginNo, true, "" );
			
			CSRFTokenUtil.checkTokenNo( tray.request );
			serviceMain( tray );
			
			/* Keep Token */
			
			// ページ遷移: なし（クライアントはすでにレスポンス受取済み）
			/* Response has already been committed */
			
			Log.performance( tray.loginNo, false, "" );
			Log.method( tray.loginNo, "OUT", "" );
		} catch (final Exception e) {
			Log.error( req, e );
			this.ctx.getRequestDispatcher( AC.ERROR_PAGE ).forward( req, res );
		}
	}
	
	public abstract void serviceMain( Tray tray ) throws Exception;
	
}
