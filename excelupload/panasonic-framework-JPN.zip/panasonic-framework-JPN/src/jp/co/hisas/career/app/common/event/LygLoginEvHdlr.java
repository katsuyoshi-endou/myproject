package jp.co.hisas.career.app.common.event;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.LygLoginDao;
import jp.co.hisas.career.util.dto.LygLoginDto;
import jp.co.hisas.career.util.log.Log;

public class LygLoginEvHdlr extends AbstractEventHandler<LygLoginEvArg, LygLoginEvRslt> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static LygLoginEvRslt exec( LygLoginEvArg arg ) throws CareerException {
		LygLoginEvHdlr handler = new LygLoginEvHdlr();
		return handler.call( arg );
	}
	
	public LygLoginEvRslt call( LygLoginEvArg arg ) throws CareerException {
		LygLoginEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected LygLoginEvRslt execute( LygLoginEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		LygLoginEvRslt result = new LygLoginEvRslt();
		
		if (SU.equals( "INIT", arg.sharp )) {
			result.lygLoginDto = getLygLogin( arg );
		}
		
		return result;
	}
	
	private LygLoginDto getLygLogin( LygLoginEvArg arg ) {
		LygLoginDao dao = new LygLoginDao( this.loginNo );
		LygLoginDto result = dao.select( arg.authKey );
		return result;
	}
}
