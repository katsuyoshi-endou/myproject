/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.taglib;

import java.io.IOException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import jp.co.hisas.career.util.log.Log;

/**
 * スクロールする画面のヘッダ部分
 * @author kat-watanabe
 */
public class ScrollHeaderTag extends BodyTagSupport {

    /**
     * {@inheritDoc}
     */
    @Override
    public int doStartTag() throws JspException {
        try {
            JspWriter out = pageContext.getOut();
            out.println( "<style type=\"text/css\">html { overflow-y: hidden; }</style>" );
            out.println( "<div style=\"margin-right: 16px;\">" );
        } catch ( IOException ex ) {
            Log.error( "", ex );
        }
        return BodyTagSupport.EVAL_BODY_BUFFERED;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int doEndTag() throws JspException {
        try {
            JspWriter out = pageContext.getOut();
            out.println( "</div>" );
        } catch ( IOException ex ) {
            Log.error( "", ex );
        }
        return BodyTagSupport.EVAL_PAGE;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int doAfterBody() throws JspException {
        try {
            BodyContent bodyContent = getBodyContent();
            JspWriter out = bodyContent.getEnclosingWriter();
            bodyContent.writeOut( out );
            bodyContent.clearBody();
        } catch ( IOException ex ) {
            Log.error( "", ex );
        }
        return BodyTagSupport.SKIP_BODY;
    }

}
