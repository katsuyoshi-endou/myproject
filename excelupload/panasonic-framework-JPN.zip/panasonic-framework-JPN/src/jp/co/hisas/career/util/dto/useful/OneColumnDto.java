/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto.useful;

import java.io.Serializable;

/**
 * ONE_COLUMN Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class OneColumnDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * TEXT
     */
    private String text;

    /**
     * TEXTを取得する。
     * @return TEXT
     */
    public String getText() {
        return text;
    }

    /**
     * TEXTを設定する。
     * @param text TEXT
     */
    public void setText(String text) {
        this.text = text;
    }

}

