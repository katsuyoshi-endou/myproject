/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * CJS_NINSYOU_RSV Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CjsNinsyouRsvDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * SIMEI_NO
     */
    private String simeiNo;
    /**
     * PASSWORD
     */
    private String password;

    /**
     * SIMEI_NOを取得する。
     * @return SIMEI_NO
     */
    public String getSimeiNo() {
        return simeiNo;
    }

    /**
     * SIMEI_NOを設定する。
     * @param simeiNo SIMEI_NO
     */
    public void setSimeiNo(String simeiNo) {
        this.simeiNo = simeiNo;
    }

    /**
     * PASSWORDを取得する。
     * @return PASSWORD
     */
    public String getPassword() {
        return password;
    }

    /**
     * PASSWORDを設定する。
     * @param password PASSWORD
     */
    public void setPassword(String password) {
        this.password = password;
    }

}

