/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dto.LygLoginDto;
import jp.co.hisas.career.util.log.Log;

/**
 * PORTALのログイン Data Access Object。
 * @author CareerDaoTool.xla
*/
public class LygLoginDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " GUID as guid,"
                     + " ACCOUNT_ID as accountId,"
                     + " LOGIN_DATETIME as loginDatetime,"
                     + " LAST_OPERATION_DATETIME as lastOperationDatetime,"
                     + " LOGOUT_REDIRECT_TARGET as logoutRedirectTarget,"
                     + " TOKEN_FOR_XSRF_MEASURE as tokenForXsrfMeasure"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public LygLoginDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public LygLoginDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param guid GUID
     * @return LygLoginDto LYG_LOGINのレコード型データ。
     */ 
    public LygLoginDto select(String guid) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM LYG_LOGIN"
                         + " WHERE GUID = ?"
                         ;
        Log.sql("【DaoMethod Call】 LygLoginDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, guid);
            rs = pstmt.executeQuery();
            LygLoginDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private LygLoginDto transferRsToDto(ResultSet rs) throws SQLException {

    	LygLoginDto dto = new LygLoginDto();
        dto.setGuid(DaoUtil.convertNullToString(rs.getString("guid")));
        dto.setAccountId(DaoUtil.convertNullToString(rs.getString("accountId")));
        dto.setLastOperationDatetime( DaoUtil.convertNullToString(rs.getString("lastOperationDatetime" ) ) );
        dto.setLoginDatetime( DaoUtil.convertNullToString( rs.getString( "loginDatetime" ) ) );
        dto.setLogoutRedirectTarget( DaoUtil.convertNullToString( rs.getString( "logoutRedirectTarget" ) ) );
        dto.setTokenForXsrfMeasure( DaoUtil.convertNullToString( rs.getString( "tokenForXsrfMeasure" ) ) );
        return dto;
    }
}

