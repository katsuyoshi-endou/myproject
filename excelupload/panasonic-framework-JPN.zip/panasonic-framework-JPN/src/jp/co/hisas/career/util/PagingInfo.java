package jp.co.hisas.career.util;

import java.io.Serializable;

public class PagingInfo implements Serializable {
	
	public int showCnt;
	public int nowPage;
	public boolean hasPrev;
	public boolean hasNext;
	public int hitCnt;
	
}
