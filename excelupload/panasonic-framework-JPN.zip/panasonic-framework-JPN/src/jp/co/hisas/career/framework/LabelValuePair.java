/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework;

import java.io.Serializable;

/**
 * ラベルと値のペア。リストボックスの項目などで利用する。
 * @author kat-watanabe
 */
public class LabelValuePair implements Serializable {

    private final String label;

    private final String value;

    public LabelValuePair( String label, String value ) {
        this.label = label;
        this.value = value;
    }

    /**
     * label を取得します。
     * @return label
     */
    public String getLabel() {
        return label;
    }

    /**
     * value を取得します。
     * @return value
     */
    public String getValue() {
        return value;
    }

}
