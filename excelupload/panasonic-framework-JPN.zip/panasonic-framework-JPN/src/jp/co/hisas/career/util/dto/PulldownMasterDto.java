/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * PULLDOWN_MASTER Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class PulldownMasterDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * プルダウンセットコード
     */
    private String pdSetCd;
    /**
     * プルダウン値
     */
    private String pdValue;
    /**
     * プルダウンテキスト
     */
    private String pdText;
    /**
     * ソート
     */
    private String lpadSort;

    /**
     * プルダウンセットコードを取得する。
     * @return プルダウンセットコード
     */
    public String getPdSetCd() {
        return pdSetCd;
    }

    /**
     * プルダウンセットコードを設定する。
     * @param pdSetCd プルダウンセットコード
     */
    public void setPdSetCd(String pdSetCd) {
        this.pdSetCd = pdSetCd;
    }

    /**
     * プルダウン値を取得する。
     * @return プルダウン値
     */
    public String getPdValue() {
        return pdValue;
    }

    /**
     * プルダウン値を設定する。
     * @param pdValue プルダウン値
     */
    public void setPdValue(String pdValue) {
        this.pdValue = pdValue;
    }

    /**
     * プルダウンテキストを取得する。
     * @return プルダウンテキスト
     */
    public String getPdText() {
        return pdText;
    }

    /**
     * プルダウンテキストを設定する。
     * @param pdText プルダウンテキスト
     */
    public void setPdText(String pdText) {
        this.pdText = pdText;
    }

    /**
     * ソートを取得する。
     * @return ソート
     */
    public String getLpadSort() {
        return lpadSort;
    }

    /**
     * ソートを設定する。
     * @param lpadSort ソート
     */
    public void setLpadSort(String lpadSort) {
        this.lpadSort = lpadSort;
    }

}

