package jp.co.hisas.career.util.dao.useful;

import java.sql.Connection;

import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;

public abstract class CoreDao {
	
	Connection conn;
	boolean isConnectionGiven = false;
	public String loginNo;
	
	public CoreDao(String loginNo) {
		this.loginNo = loginNo;
	}
	
	public CoreDao(Connection conn) {
		this.conn = conn;
		this.isConnectionGiven = true;
	}
	
	protected Connection getConnection() {
		Connection connection = isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
		if (connection == null) {
			throw new CareerRuntimeException();
		}
		return connection;
	}
}
