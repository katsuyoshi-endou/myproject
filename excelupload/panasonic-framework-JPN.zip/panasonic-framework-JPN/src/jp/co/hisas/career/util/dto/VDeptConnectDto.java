/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * 所属連結 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VDeptConnectDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 会社コード
     */
    private String cmpaCd;
    /**
     * 開始部署コード
     */
    private String startDeptCd;
    /**
     * 対象部署コード
     */
    private String tgtDeptCd;
    /**
     * 対象部署名称
     */
    private String tgtDeptNm;
    /**
     * 親部署コード
     */
    private String parentDeptCd;
    /**
     * 階層
     */
    private Integer hierarchy;
    /**
     * ルート
     */
    private String root;

    /**
     * 会社コードを取得する。
     * @return 会社コード
     */
    public String getCmpaCd() {
        return cmpaCd;
    }

    /**
     * 会社コードを設定する。
     * @param cmpaCd 会社コード
     */
    public void setCmpaCd(String cmpaCd) {
        this.cmpaCd = cmpaCd;
    }

    /**
     * 開始部署コードを取得する。
     * @return 開始部署コード
     */
    public String getStartDeptCd() {
        return startDeptCd;
    }

    /**
     * 開始部署コードを設定する。
     * @param startDeptCd 開始部署コード
     */
    public void setStartDeptCd(String startDeptCd) {
        this.startDeptCd = startDeptCd;
    }

    /**
     * 対象部署コードを取得する。
     * @return 対象部署コード
     */
    public String getTgtDeptCd() {
        return tgtDeptCd;
    }

    /**
     * 対象部署コードを設定する。
     * @param tgtDeptCd 対象部署コード
     */
    public void setTgtDeptCd(String tgtDeptCd) {
        this.tgtDeptCd = tgtDeptCd;
    }

    /**
     * 対象部署名称を取得する。
     * @return 対象部署名称
     */
    public String getTgtDeptNm() {
        return tgtDeptNm;
    }

    /**
     * 対象部署名称を設定する。
     * @param tgtDeptNm 対象部署名称
     */
    public void setTgtDeptNm(String tgtDeptNm) {
        this.tgtDeptNm = tgtDeptNm;
    }

    /**
     * 親部署コードを取得する。
     * @return 親部署コード
     */
    public String getParentDeptCd() {
        return parentDeptCd;
    }

    /**
     * 親部署コードを設定する。
     * @param parentDeptCd 親部署コード
     */
    public void setParentDeptCd(String parentDeptCd) {
        this.parentDeptCd = parentDeptCd;
    }

    /**
     * 階層を取得する。
     * @return 階層
     */
    public Integer getHierarchy() {
        return hierarchy;
    }

    /**
     * 階層を設定する。
     * @param hierarchy 階層
     */
    public void setHierarchy(Integer hierarchy) {
        this.hierarchy = hierarchy;
    }

    /**
     * ルートを取得する。
     * @return ルート
     */
    public String getRoot() {
        return root;
    }

    /**
     * ルートを設定する。
     * @param root ルート
     */
    public void setRoot(String root) {
        this.root = root;
    }

}

