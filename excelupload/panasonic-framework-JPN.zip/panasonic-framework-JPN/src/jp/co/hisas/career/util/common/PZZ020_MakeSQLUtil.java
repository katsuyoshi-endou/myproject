/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.util.common;

import java.util.HashMap;

import jp.co.hisas.career.util.log.Log;

/**
 * @author Administrator データベースに関する文字列等の生成、チェックなどを行うクラスです。
 */
public class PZZ020_MakeSQLUtil {
	/* カラムタイプを格納する */
	private static final HashMap<String, String> column_type = new HashMap<String, String>();

	/** SQLの動的生成でwhere、insert時にシングルコーテーションを含めないリスト */
	public static final String[] P_INTEGER_COLUMN_NAME = { "tasseido_ritu", "skill_ritu", "nintei_point", "omomi", "omomi_1", "omomi_2", "omomi_3", "omomi_4", "omomi_5", "jissi_kaisu", "gyomu_keiken_t_do", "skill_t_do", "sougou_t_do", "jissi_kaisu", "rank", "syukei_kekka", "kekka_pdf", "sougou_t_do1", "sougou_t_do2", "sougou_t_do3", "KAO_SYASIN", "HOUKOKU", "IKUSEI_HOUSIN", "DOCUMENT" };

	/**
	 * static initializer
	 */
	static {
		if (PZZ020_MakeSQLUtil.column_type.size() == 0) {
			for (int i = 0; i < P_INTEGER_COLUMN_NAME.length; i++) {

				PZZ020_MakeSQLUtil.column_type.put(P_INTEGER_COLUMN_NAME[i].toUpperCase(), "1");
			}
		}
	}

	/**
	 * 引数で渡されたテーブル名、カラム、データを元にインサート文を作成する
	 * @param login_no
	 * @param tbl
	 * @param column
	 * @param save
	 * @return 生成されたSQL
	 * @deprecated PreparetedStatementを使ってSQLに埋め込む値は?とsetXXXで設定してください
	 * @throws Exception
	 */
	public static String makeInsertSQL(final String login_no, final String tbl, final String[] column, final String[] save) throws Exception {
		Log.method(login_no, "IN", "");

		try {
			int i;
			String sql = "INSERT INTO " + tbl + " ( " + column[0];

			for (i = 1; i < column.length; i++) {
				sql = sql + ", " + column[i];
			}

			if (PZZ020_MakeSQLUtil.getColumnTypeCheck(column[0]).equals("1")) {
				sql = sql + ") VALUES( " + save[0];
			} else {
				sql = sql + ") VALUES( '" + PZZ020_MakeSQLUtil.sanitizeSQLData(save[0]) + "'";
			}

			for (i = 1; i < column.length; i++) {
				if (PZZ020_MakeSQLUtil.getColumnTypeCheck(column[i]).equals("1")) {
					sql = sql + "," + save[i];
				} else {
					sql = sql + ",'" + PZZ020_MakeSQLUtil.sanitizeSQLData(save[i]) + "'";
				}
			}

			sql = sql + ")";

			Log.method(login_no, "OUT", "");

			return sql;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		}
	}

	/**
	 * 引数で渡されたテーブル名、カラム、データを元にアップデート文を作成する
	 * @param tbl
	 * @param column
	 * @param save
	 * @return 生成されたSQ
	 * @deprecated PreparetedStatementを使ってSQLに埋め込む値は?とsetXXXで設定してください
	 * @throws Exception
	 */
	public static String makeUpdateSQL(final String login_no, final String tbl, final String[] column, final String[] save, final String[] primary_key, final String[] primary_value) throws Exception {
		Log.method(login_no, "IN", "");

		try {
			String sql = "UPDATE " + tbl + " set ";

			/* set */
			if (PZZ020_MakeSQLUtil.getColumnTypeCheck(column[0]).equals("1")) {
				sql = sql + column[0] + " = " + save[0];
			} else {
				sql = sql + column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(save[0]) + "'";
			}

			for (int i = 1; i < column.length; i++) {
				if (PZZ020_MakeSQLUtil.getColumnTypeCheck(column[i]).equals("1")) {
					sql = sql + ", " + column[i] + " = " + save[i];
				} else {
					sql = sql + ", " + column[i] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(save[i]) + "'";
				}
			}

			/* WHERE句 */
			if (PZZ020_MakeSQLUtil.getColumnTypeCheck(primary_key[0]).equals("1")) {
				sql = sql + " WHERE " + primary_key[0] + " = " + primary_value[0];
			} else {
				sql = sql + " WHERE " + primary_key[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(primary_value[0]) + "'";
			}

			for (int i = 1; i < primary_key.length; i++) {
				if (PZZ020_MakeSQLUtil.getColumnTypeCheck(primary_key[i]).equals("1")) {
					sql = sql + " AND " + primary_key[i] + " = " + primary_value[i];
				} else {
					sql = sql + " AND " + primary_key[i] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(primary_value[i]) + "'";
				}
			}

			Log.method(login_no, "OUT", "");

			return sql;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		}
	}

	/**
	 * 引数で渡されたテーブル名、カラム、データを元にデリート文を作成する
	 * @param login_no
	 * @param tbl
	 * @param column
	 * @param del
	 * @return 生成されたSQL
	 * @deprecated PreparetedStatementを使ってSQLに埋め込む値は?とsetXXXで設定してください
	 * @throws Exception
	 */
	public static String makeDeleteSQL(final String login_no, final String tbl, final String[] column, final String[] del) throws Exception {
		Log.method(login_no, "IN", "");

		try {
			String sql = "DELETE FROM " + tbl + " WHERE ";

			if (PZZ020_MakeSQLUtil.getColumnTypeCheck(column[0]).equals("1")) {
				sql = sql + column[0] + " = " + del[0];
			} else {
				sql = sql + column[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(del[0]) + "'";
			}

			for (int i = 1; i < column.length; i++) {
				if (PZZ020_MakeSQLUtil.getColumnTypeCheck(column[i]).equals("1")) {
					sql = sql + "  AND " + column[i] + " = " + del[i];
				} else {
					sql = sql + "  AND " + column[i] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(del[i]) + "'";
				}
			}

			Log.method(login_no, "OUT", "");

			return sql;
		} catch (final Exception e) {
			Log.error(login_no, e);
			throw e;
		}
	}

	/**
	 * 引数で渡されたカラム名称からカラムタイプを返す
	 * @param カラム名
	 * @return シングルコーテーションがいらない型の場合 1 シングルコーテーションがいる方の場合 0
	 */
	public static String getColumnTypeCheck(final String column_name) {
		if ((String) PZZ020_MakeSQLUtil.column_type.get(column_name.toUpperCase()) == null) {
			return new String("0");
		} else {
			return new String("1");
		}
	}

	/**
	 * SQL文に適用する文字列変数に対してサニタイジング処理を実行する。
	 * @param str サニタイズする文字列
	 * @return サニタイズ後の文字列
	 */
	public static String sanitizeSQLData(final String str) {
		if (str == null) {
			return str;
		}
		String dat = str;
		dat = dat.replaceAll("'", "''");
		return dat;
	}

	/**
	 * SQL文のLIKE句に適用する文字列変数に対してサニタイジング処理を実行する。<br>
	 * エスケープ文字は #
	 * @param str サニタイズする文字列
	 * @return サニタイズ後の文字列
	 */
	public static String sanitizeSQLLikeData(final String str) {
		if (str == null) {
			return str;
		}
		String dat = str;

		dat = dat.replaceAll("([%％_＿#])", "#$1").replaceAll("'", "''");
		return dat;
	}
}
