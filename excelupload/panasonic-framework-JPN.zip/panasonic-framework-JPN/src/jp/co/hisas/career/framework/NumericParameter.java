package jp.co.hisas.career.framework;

public class NumericParameter implements SQLParameter {
	
	String value;
	
	public NumericParameter(String value) {
		this.value = value;
	}
	
	public String getFormatedParameter() {
		return value;
	}
	
	public String getParameter() {
		return value;
	}
	
	public void setParameter( String parameter ) {
		value = parameter;
	}
	
}
