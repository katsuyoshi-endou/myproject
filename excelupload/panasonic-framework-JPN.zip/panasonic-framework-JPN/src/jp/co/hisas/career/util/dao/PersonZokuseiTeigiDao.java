/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.PersonZokuseiTeigiDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * 人属性定義 Data Access Object。
 * @author CareerDaoTool.xla
*/
public class PersonZokuseiTeigiDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " PERSON_ZOKUSEI_ID as personZokuseiId,"
                     + " PERSON_ZOKUSEI_BUNRUI3_ID as personZokuseiBunrui3Id,"
                     + " PERSON_ZOKUSEI_NAME as personZokuseiName,"
                     + " PERSON_ZOKUSEI_HYOJI_NAME as personZokuseiHyojiName,"
                     + " BUTSURI_KAKUNO_SAKI as butsuriKakunoSaki,"
                     + " RONRI_TABLE_FLAG as ronriTableFlag,"
                     + " RONRI_TABLE_NAME as ronriTableName,"
                     + " RIREKI_KANRI_FLAG as rirekiKanriFlag,"
                     + " KOKAI_SEIGEN_FLAG as kokaiSeigenFlag,"
                     + " ZOKUSEI_TYPE as zokuseiType,"
                     + " MASTER_TYPE as masterType,"
                     + " MASTER_ID as masterId,"
                     + " UPDATE_PERSON_ID as updatePersonId,"
                     + " UPDATE_FUNCTION as updateFunction,"
                     + " UPDATE_DATE as updateDate,"
                     + " UPDATE_TIME as updateTime"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public PersonZokuseiTeigiDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public PersonZokuseiTeigiDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private PersonZokuseiTeigiDto transferRsToDto(ResultSet rs) throws SQLException {

        PersonZokuseiTeigiDto dto = new PersonZokuseiTeigiDto();
        dto.setPersonZokuseiId(DaoUtil.convertNullToString(rs.getString("personZokuseiId")));
        dto.setPersonZokuseiBunrui3Id(DaoUtil.convertNullToString(rs.getString("personZokuseiBunrui3Id")));
        dto.setPersonZokuseiName(DaoUtil.convertNullToString(rs.getString("personZokuseiName")));
        dto.setPersonZokuseiHyojiName(DaoUtil.convertNullToString(rs.getString("personZokuseiHyojiName")));
        dto.setButsuriKakunoSaki(DaoUtil.convertNullToString(rs.getString("butsuriKakunoSaki")));
        dto.setRonriTableFlag(rs.getInt("ronriTableFlag"));
        dto.setRonriTableName(DaoUtil.convertNullToString(rs.getString("ronriTableName")));
        dto.setRirekiKanriFlag(rs.getInt("rirekiKanriFlag"));
        dto.setKokaiSeigenFlag(rs.getInt("kokaiSeigenFlag"));
        dto.setZokuseiType(rs.getInt("zokuseiType"));
        dto.setMasterType(rs.getInt("masterType"));
        dto.setMasterId(DaoUtil.convertNullToString(rs.getString("masterId")));
        dto.setUpdatePersonId(DaoUtil.convertNullToString(rs.getString("updatePersonId")));
        dto.setUpdateFunction(DaoUtil.convertNullToString(rs.getString("updateFunction")));
        dto.setUpdateDate(DaoUtil.convertNullToString(rs.getString("updateDate")));
        dto.setUpdateTime(DaoUtil.convertNullToString(rs.getString("updateTime")));
        return dto;
    }

    /**
     * 人属性定義を全て取得します。
     * @return List<PersonZokuseiTeigiDto> PERSON_ZOKUSEI_TEIGIのレコード型データのリスト。
     */
    public List<PersonZokuseiTeigiDto> selectPersonZokuseiAll() {

        final String sql = "SELECT " + ALLCOLS + " FROM PERSON_ZOKUSEI_TEIGI";
        Log.sql("【DaoMethod Call】 PersonZokuseiTeigiDao.selectPersonZokuseiAll");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            List<PersonZokuseiTeigiDto> lst = new ArrayList<PersonZokuseiTeigiDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

