/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.event;

import jp.co.hisas.career.ejb.AbstractEventResult;

/**
 * EventHandlerの戻り値が空である場合に使用する定数的なクラス。
 * 
 * @author kats-watanabe
 */
@SuppressWarnings("serial")
public final class VoidEventResult extends AbstractEventResult {
	
	/**
	 * このクラスの唯一のインスタンス。
	 */
	public static final VoidEventResult INSTANCE = new VoidEventResult();
	
	/**
	 * プライベートコンストラクタ。外部からはインスタンス化できない。 このクラスのインスタンスはINSTANCE定数からのみ取得できる。
	 */
	private VoidEventResult() {
	}
	
}
