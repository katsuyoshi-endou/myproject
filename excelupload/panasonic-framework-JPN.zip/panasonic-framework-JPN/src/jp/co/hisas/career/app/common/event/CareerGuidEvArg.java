package jp.co.hisas.career.app.common.event;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

@SuppressWarnings("serial")
public class CareerGuidEvArg extends AbstractEventArg {
	
	public String sharp = null;
	public String guid;

	public CareerGuidEvArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid CareerGuidEvArg: loginNo is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		if (SU.isBlank( sharp )) {
			throw new CareerException( "Invalid CareerGuidEvArg: sharp is null." );
		}
	}
}
