/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * 汎用パラメータ Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CcpParamDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * パラメータ分類
     */
    private String paramBunruiNm;
    /**
     * パラメータＩＤ
     */
    private String paramId;
    /**
     * パラメータ値
     */
    private String paramValue;
    /**
     * パラメータ名称
     */
    private String paramNm;
    /**
     * パラメータ備考
     */
    private String paramBiko;

    /**
     * パラメータ分類を取得する。
     * @return パラメータ分類
     */
    public String getParamBunruiNm() {
        return paramBunruiNm;
    }

    /**
     * パラメータ分類を設定する。
     * @param paramBunruiNm パラメータ分類
     */
    public void setParamBunruiNm(String paramBunruiNm) {
        this.paramBunruiNm = paramBunruiNm;
    }

    /**
     * パラメータＩＤを取得する。
     * @return パラメータＩＤ
     */
    public String getParamId() {
        return paramId;
    }

    /**
     * パラメータＩＤを設定する。
     * @param paramId パラメータＩＤ
     */
    public void setParamId(String paramId) {
        this.paramId = paramId;
    }

    /**
     * パラメータ値を取得する。
     * @return パラメータ値
     */
    public String getParamValue() {
        return paramValue;
    }

    /**
     * パラメータ値を設定する。
     * @param paramValue パラメータ値
     */
    public void setParamValue(String paramValue) {
        this.paramValue = paramValue;
    }

    /**
     * パラメータ名称を取得する。
     * @return パラメータ名称
     */
    public String getParamNm() {
        return paramNm;
    }

    /**
     * パラメータ名称を設定する。
     * @param paramNm パラメータ名称
     */
    public void setParamNm(String paramNm) {
        this.paramNm = paramNm;
    }

    /**
     * パラメータ備考を取得する。
     * @return パラメータ備考
     */
    public String getParamBiko() {
        return paramBiko;
    }

    /**
     * パラメータ備考を設定する。
     * @param paramBiko パラメータ備考
     */
    public void setParamBiko(String paramBiko) {
        this.paramBiko = paramBiko;
    }

}

