/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * MKT_NOTIFICATION Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class MktNotificationDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * N10N_SEQ
     */
    private Integer n10nSeq;
    /**
     * PARTY
     */
    private String party;
    /**
     * GUID
     */
    private String guid;
    /**
     * N10N_TEXT
     */
    private String n10nText;
    /**
     * READ_FLG
     */
    private Integer readFlg;
    /**
     * SENDER
     */
    private String sender;
    /**
     * SENT_AT
     */
    private String sentAt;

    /**
     * N10N_SEQを取得する。
     * @return N10N_SEQ
     */
    public Integer getN10nSeq() {
        return n10nSeq;
    }

    /**
     * N10N_SEQを設定する。
     * @param n10nSeq N10N_SEQ
     */
    public void setN10nSeq(Integer n10nSeq) {
        this.n10nSeq = n10nSeq;
    }

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * GUIDを取得する。
     * @return GUID
     */
    public String getGuid() {
        return guid;
    }

    /**
     * GUIDを設定する。
     * @param guid GUID
     */
    public void setGuid(String guid) {
        this.guid = guid;
    }

    /**
     * N10N_TEXTを取得する。
     * @return N10N_TEXT
     */
    public String getN10nText() {
        return n10nText;
    }

    /**
     * N10N_TEXTを設定する。
     * @param n10nText N10N_TEXT
     */
    public void setN10nText(String n10nText) {
        this.n10nText = n10nText;
    }

    /**
     * READ_FLGを取得する。
     * @return READ_FLG
     */
    public Integer getReadFlg() {
        return readFlg;
    }

    /**
     * READ_FLGを設定する。
     * @param readFlg READ_FLG
     */
    public void setReadFlg(Integer readFlg) {
        this.readFlg = readFlg;
    }

    /**
     * SENDERを取得する。
     * @return SENDER
     */
    public String getSender() {
        return sender;
    }

    /**
     * SENDERを設定する。
     * @param sender SENDER
     */
    public void setSender(String sender) {
        this.sender = sender;
    }

    /**
     * SENT_ATを取得する。
     * @return SENT_AT
     */
    public String getSentAt() {
        return sentAt;
    }

    /**
     * SENT_ATを設定する。
     * @param sentAt SENT_AT
     */
    public void setSentAt(String sentAt) {
        this.sentAt = sentAt;
    }

}

