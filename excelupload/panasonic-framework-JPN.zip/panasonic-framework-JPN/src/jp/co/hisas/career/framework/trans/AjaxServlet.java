package jp.co.hisas.career.framework.trans;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.Log;

public abstract class AjaxServlet extends HttpServlet {
	
	protected ServletContext ctx = null;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	public void doGet( final HttpServletRequest req, final HttpServletResponse res ) throws IOException, ServletException {
		try {
			Tray tray = new Tray( req, res );
			
			Log.method( tray.loginNo, "IN", "" );
			Log.performance( tray.loginNo, true, "" );
			
			CSRFTokenUtil.checkTokenNo( tray.request );
			String json = doGetMain( tray );
			
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.getWriter().write( json );
			
			/* Keep Token */
			// CSRFTokenUtil.setNewTokenNo( tray.request, tray.response, fPath );
			
			Log.performance( tray.loginNo, false, "" );
			Log.method( tray.loginNo, "OUT", "" );
		} catch (final Exception e) {
			Log.error( req, e );
			res.getWriter().write( "Error" );
		}
	}
	
	public abstract String doGetMain( Tray tray ) throws Exception;
	
	public void doPost( HttpServletRequest req, HttpServletResponse res ) throws ServletException, IOException {
		try {
			Tray tray = new Tray( req, res );
			
			Log.method( tray.loginNo, "IN", "" );
			Log.performance( tray.loginNo, true, "" );
			
			CSRFTokenUtil.checkTokenNo( tray.request );
			String json = doPostMain( tray );
			
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.getWriter().write( json );
			
			/* Keep Token */
			// CSRFTokenUtil.setNewTokenNo( tray.request, tray.response, fPath );
			
			Log.performance( tray.loginNo, false, "" );
			Log.method( tray.loginNo, "OUT", "" );
		} catch (final Exception e) {
			Log.error( req, e );
			res.getWriter().write( "Error" );
		}
	}
	
	public abstract String doPostMain( Tray tray ) throws Exception;
}
