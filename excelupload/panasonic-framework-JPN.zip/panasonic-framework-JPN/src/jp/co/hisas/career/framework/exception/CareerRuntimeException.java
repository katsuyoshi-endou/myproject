/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.exception;

/**
 * リシテアCareer用実行時Exception
 * 予想外のエラーを表す
 * @author k-ozawa
 */
@SuppressWarnings( "serial" )
public class CareerRuntimeException extends RuntimeException {

    /**
     * 詳細メッセージに null を使用して、CareerRuntimeException を生成します。
     */
    public CareerRuntimeException() {
    }

    /**
     * 指定された詳細メッセージを使用して、CareerRuntimeException を生成します。
     * @param message 詳細メッセージ。
     */
    public CareerRuntimeException( String message ) {
        super( message );
    }

    /**
     * 指定された原因を使用して、CareerRuntimeException を生成します。
     * @param cause 原因。
     */
    public CareerRuntimeException( Throwable cause ) {
        super( cause );
    }

    /**
     * 指定された詳細メッセージおよび原因を使用して、CareerRuntimeException を生成します。
     * @param message 詳細メッセージ。
     * @param cause 原因。
     */
    public CareerRuntimeException( String message, Throwable cause ) {
        super( message, cause );
    }

}
