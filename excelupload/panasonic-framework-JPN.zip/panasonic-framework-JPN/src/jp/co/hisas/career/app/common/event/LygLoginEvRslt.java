package jp.co.hisas.career.app.common.event;

import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.LygLoginDto;

@SuppressWarnings("serial")
public class LygLoginEvRslt extends AbstractEventResult {

	public LygLoginDto lygLoginDto;
}