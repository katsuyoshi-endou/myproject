/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * キャリアGUID Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CareerGuidDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * GUID
     */
    private String guid;
    /**
     * GUNM
     */
    private String gunm;
    /**
     * 有効フラグ
     */
    private String availFlg;
    /**
     * 業務アカウントフラグ
     */
    private String operatorFlg;

    /**
     * GUIDを取得する。
     * @return GUID
     */
    public String getGuid() {
        return guid;
    }

    /**
     * GUIDを設定する。
     * @param guid GUID
     */
    public void setGuid(String guid) {
        this.guid = guid;
    }

    /**
     * GUNMを取得する。
     * @return GUNM
     */
    public String getGunm() {
        return gunm;
    }

    /**
     * GUNMを設定する。
     * @param gunm GUNM
     */
    public void setGunm(String gunm) {
        this.gunm = gunm;
    }

    /**
     * 有効フラグを取得する。
     * @return 有効フラグ
     */
    public String getAvailFlg() {
        return availFlg;
    }

    /**
     * 有効フラグを設定する。
     * @param availFlg 有効フラグ
     */
    public void setAvailFlg(String availFlg) {
        this.availFlg = availFlg;
    }

    /**
     * 業務アカウントフラグを取得する。
     * @return 業務アカウントフラグ
     */
    public String getOperatorFlg() {
        return operatorFlg;
    }

    /**
     * 業務アカウントフラグを設定する。
     * @param operatorFlg 業務アカウントフラグ
     */
    public void setOperatorFlg(String operatorFlg) {
        this.operatorFlg = operatorFlg;
    }

}

