package jp.co.hisas.career.app.common.event;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.CareerGuidDao;
import jp.co.hisas.career.util.dto.CareerGuidDto;
import jp.co.hisas.career.util.log.Log;

public class UserInfoEvHdlr extends AbstractEventHandler<UserInfoEvArg, UserInfoEvRslt> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static UserInfoEvRslt exec( UserInfoEvArg arg ) throws CareerException {
		UserInfoEvHdlr handler = new UserInfoEvHdlr();
		return handler.call( arg );
	}
	
	public UserInfoEvRslt call( UserInfoEvArg arg ) throws CareerException {
		UserInfoEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected UserInfoEvRslt execute( UserInfoEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		UserInfoEvRslt result = new UserInfoEvRslt();
		
		if (SU.equals( "INIT", arg.sharp )) {
			result.careerGuidDto = getUserInfo( arg, result );
		}
		
		return result;
	}
	
	private CareerGuidDto getUserInfo( UserInfoEvArg arg, UserInfoEvRslt result ) throws CareerException {
		CareerGuidDao dao = new CareerGuidDao( this.loginNo );
		CareerGuidDto dto = dao.select( arg.guid );
		if (dto == null) {
			throw new CareerRuntimeException( "指定したアカウントが見つかりません。: " + arg.guid );
		}
		return dto;
	}
	
}
