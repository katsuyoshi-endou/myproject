/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * ラベルビュー Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VCcpLabelDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PARTY
     */
    private String party;
    /**
     * ラベルID
     */
    private String labelId;
    /**
     * ラベル言語1
     */
    private String labelText;
    /**
     * ラベル言語2
     */
    private String labelTextL2;
    /**
     * ラベル言語3
     */
    private String labelTextL3;

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * ラベルIDを取得する。
     * @return ラベルID
     */
    public String getLabelId() {
        return labelId;
    }

    /**
     * ラベルIDを設定する。
     * @param labelId ラベルID
     */
    public void setLabelId(String labelId) {
        this.labelId = labelId;
    }

    /**
     * ラベル言語1を取得する。
     * @return ラベル言語1
     */
    public String getLabelText() {
        return labelText;
    }

    /**
     * ラベル言語1を設定する。
     * @param labelText ラベル言語1
     */
    public void setLabelText(String labelText) {
        this.labelText = labelText;
    }

    /**
     * ラベル言語2を取得する。
     * @return ラベル言語2
     */
    public String getLabelTextL2() {
        return labelTextL2;
    }

    /**
     * ラベル言語2を設定する。
     * @param labelTextL2 ラベル言語2
     */
    public void setLabelTextL2(String labelTextL2) {
        this.labelTextL2 = labelTextL2;
    }

    /**
     * ラベル言語3を取得する。
     * @return ラベル言語3
     */
    public String getLabelTextL3() {
        return labelTextL3;
    }

    /**
     * ラベル言語3を設定する。
     * @param labelTextL3 ラベル言語3
     */
    public void setLabelTextL3(String labelTextL3) {
        this.labelTextL3 = labelTextL3;
    }

}

