/*
 * All Rights Reserved. Copyright (C) 2004,2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.trans;

import java.io.Serializable;
import java.util.LinkedHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.download.bean.DownloadFileBean;
import jp.co.hisas.career.util.log.Log;

/**
 * @author kats-watanabe
 */
public class StateTransitionEvent implements Serializable {

    private HttpServletRequest request;

    private HttpServletResponse response;

    private ForwardUri forwardUri;

    private Class<? extends AbstractCommand> previousCommand;

    /** ダウンロードするファイルがある場合、その情報を設定する。 */
    private DownloadFileBean DownloadFileBean = null;

    /**
     * @return the request
     */
    public HttpServletRequest getRequest() {
        return request;
    }

    /**
     * @param request the request to set
     */
    public void setRequest( HttpServletRequest request ) {
        this.request = request;
    }

    /**
     * @return the response
     */
    public HttpServletResponse getResponse() {
        return response;
    }

    /**
     * @param response the response to set
     */
    public void setResponse( HttpServletResponse response ) {
        this.response = response;
    }

    /**
     * @return the forwardUri
     */
    public ForwardUri getForwardUri() {
        return forwardUri;
    }

    /**
     * HttpSessionオブジェクトを取得します。
     * @return HttpSessionオブジェクト
     */
    public HttpSession getSession() {
        return ( request != null ) ? request.getSession( false ) : null;
    }

    /**
     * セッションIDを取得します。
     * @return セッションID
     */
    public String getSessionId() {
        HttpSession session = getSession();
        return ( session != null ) ? session.getId() : null;
    }

    /**
     * 遷移元画面のコマンドクラスを取得します。
     * @return 遷移元画面のコマンドクラス
     */
    public Class<? extends AbstractCommand> getPreviousCommand() {
        return this.previousCommand;
    }

    /**
     * 遷移元画面のコマンドクラスを設定します。
     * @param previousCommand 遷移元画面のコマンドクラス
     */
    void setPreviousCommand( Class<? extends AbstractCommand> previousCommand ) {
        this.previousCommand = previousCommand;
    }

    /**
     * @param forwardUri the forwardUri to set
     */
    public void setForwardUri( ForwardUri forwardUri ) {
        this.forwardUri = forwardUri;
    }

    /**
     * 遷移先画面のパスを設定します。
     * @param jspPath 遷移先画面のパス
     */
    public void setForwardUriByJSPPath( String jspPath ) {
        this.forwardUri = ForwardUri.asJSP( jspPath );
    }

    /**
     * 遷移先を表すクラス
     * @author k-ozawa
     */
    public static class ForwardUri {

        private static final String DEFAULT_PATH = "/" + AppDef.CTX_ROOT + "/servlet/CommonServlet";

        private String path = DEFAULT_PATH;

        private String queryString = "";

        /**
         * デフォルトコンストラクタ
         */
        public ForwardUri() {

        }

        /**
         * 機能ID、アクションIDを指定して ForwardUri クラスのインスタンスを初期化します。
         * @param kinouId 機能ID
         * @param actionId アクションID
         * @return 機能ID、アクションIDを指定して生成した ForwardUri クラスのインスタンス。
         */
        public static ForwardUri asAction( String kinouId, String actionId ) {
            ForwardUri result = new ForwardUri();
            result.setPath( "/servlet/CommonServlet" );
            result.queryString = String.format( "?Kinou_Id=%s&Action=%s", kinouId, actionId );
            return result;
        }

        /**
         * JSPのパスを指定して ForwardUri クラスのインスタンスを初期化します。
         * @param path JSPのパス
         * @return JSPのパスを指定して生成した ForwardUri クラスのインスタンス。
         */
        public static ForwardUri asJSP( String path ) {
            ForwardUri result = new ForwardUri();
            result.setPath( path );
            return result;
        }

        /**
         * @return the path
         */
        public String getPath() {
            return path;
        }

        /**
         * @param path the path to set
         */
        public void setPath( String path ) {
            this.path = path;
        }

        /**
         * "/servlet/CommonServlet?param1=value1&param2=value2 ..." のような形式の文字列を取得する。
         * 
         * {@inheritDoc}
         */
        @Override
        public String toString() {
            String s = path + getQueryString();
            Log.debug( s );
            return s;
        }

        /**
         * リクエストの ? 以降の文字列を取得する。
         * 常に timestamp パラメータを付加して返す。
         * @return クエリ文字列
         */
        public String getQueryString() {
            StringBuilder buf = new StringBuilder( this.queryString );
            // 既存QUERYにtimestamp属性があったら、更新すべき？
            if ( buf.indexOf( "timestamp=" ) == -1 ) {
                if ( buf.length() == 0 ) {
                    buf.append( '?' );
                } else {
                    buf.append( '&' );
                }
                buf.append( "timestamp=" );
                buf.append( new java.util.Date().getTime() );
            }
            return buf.toString();
        }

        /**
         * queryString を設定します。
         * @param queryString queryString に設定する値。
         */
        public void setQueryString( String queryString ) {
            this.queryString = queryString;
        }

        /**
         * queryString を Map で設定します。
         * @param params queryString に設定する値を保持したLinkedHashMap。
         */
        public void setQueryStringByMap( LinkedHashMap<String, String> params ) {
            StringBuilder buf = new StringBuilder();
            if ( params != null ) {
                for ( String paramName : params.keySet() ) {
                    buf.append( '&' ).append( paramName );
                    buf.append( '=' ).append( params.get( paramName ) );
                }
            }
            buf.setCharAt( 0, '?' );
            this.queryString = buf.toString();
        }

        /**
         * queryString にパラメータを追加します。
         * @param param パラメータ名
         * @param value パラメータの値
         */
        public void appendQueryString( String param, String value ) {
            char c = ( PZZ010_CharacterUtil.isEmpty( this.queryString ) ) ? '?' : '&';
            this.queryString = String.format( "%c%s=%s", c, param, value );
        }

    }

    /**
     * 次画面でダウンロードするファイルを取得します。
     * @return DownloadFileBean
     */
    public DownloadFileBean getDownloadFileInfo() {
        return DownloadFileBean;
    }

    /**
     * 次画面でダウンロードするファイルを設定します。
     * @param DownloadFileBean DownloadFileBean に設定する値。
     */
    public void setDownloadFileInfo( DownloadFileBean DownloadFileBean ) {
        this.DownloadFileBean = DownloadFileBean;
    }

}
