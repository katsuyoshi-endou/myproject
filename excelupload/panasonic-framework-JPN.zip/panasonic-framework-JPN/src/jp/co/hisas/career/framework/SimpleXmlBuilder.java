/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework;

import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;

/**
 * XML (XHTML含む) を出力するための簡易的なビルダー。
 * チェック機構がないので、正しい順序でメソッドを呼び出さないと、壊れたXMLが出力されます。
 * @author kat-watanabe
 */
public class SimpleXmlBuilder {

    private final StringBuilder buf = new StringBuilder();

    public SimpleXmlBuilder() {
    }

    /**
     * 要素の出力を開始する。
     * @param elementName 要素名
     */
    public void startElement( String elementName ) {
        buf.append( '<' ).append( elementName );
    }

    /**
     * startElement メソッドで出力開始したタグを開始タグとして閉じて、要素の内容に移動する。
     */
    public void finishStartTag() {
        buf.append( '>' );
    }

    /**
     * startElement メソッドで出力開始した開始タグを、空要素タグとして閉じる。
     */
    public void finishEmptyElementTag() {
        buf.append( " />" );
    }

    /**
     * 要素の終了タグを出力する。
     * @param elementName 要素名
     */
    public void writeElementEndTag( String elementName ) {
        buf.append( "</" ).append( elementName ).append(  ">" );
    }

    /**
     * テキスト内容を出力する。
     * @param text 出力するテキスト
     */
    public void writeText( String text ) {
        buf.append( PZZ010_CharacterUtil.sanitizeStrData( text ) );
    }

    /**
     * コメントを出力する。
     * @param text 出力するコメントの内容
     */
    public void writeComment( String comment ) {
        buf.append( "<!-- " ).append( comment ).append( " -->" );
    }

    /**
     * 属性を出力します。
     * @param attributeName 属性名
     * @param value 属性の値
     */
    public void writeAttribute( String attributeName, Object value ) {
        buf.append( " " ).append( attributeName ).append( "=\"" ).append( value ).append( "\"" );
    }

    /**
     * 属性を出力します。
     * ただし value が null または空文字列の場合、出力しません。
     * @param attributeName 属性名
     * @param value 属性の値
     */
    public void writeOptionalAttribute( String attributeName, String value ) {
        if ( value != null && !value.equals( "" ) ) {
            writeAttribute( attributeName, value );
        }
    }

    /**
     * 属性を出力します。
     * ただし value が null または空文字列の場合、出力しません。
     * @param attributeName 属性名
     * @param value 属性の値
     */
    public void writeOptionalAttribute( String attributeName, Object value ) {
        if ( value != null ) {
            writeAttribute( attributeName, value.toString() );
        }
    }

    /**
     * 属性を書式付で出力します。
     * @param attributeName 属性名
     * @param format 属性に設定する値のフォーマット
     * @param args フォーマットに渡される引数
     */
    public void formatAttribute( String attributeName, String format, Object... args ) {
        writeAttribute( attributeName, String.format( format, args ) );
    }
    
    
    /**
     * JavaScriptの内容を指定して、scriptタグを出力します。
     * @param script
     */
    public void writeScriptElement(String script) {
        startElement( "script" );
        writeAttribute( "type", "text/javascript" );
        finishStartTag();
        writeComment( String.format( "\r\n%s\r\n//", script) );
        writeElementEndTag( "script" );
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return buf.toString();
    }

}
