package jp.co.hisas.career.app.common.bean;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.UserInfoBean;

public class CsvDownloadBean {
	
	HttpServletRequest request;
	HttpSession session;
	String loginNo;
	
	public CsvDownloadBean(HttpServletRequest req, HttpSession ses) {
		this.request = req;
		this.session = ses;
		final UserInfoBean userinfo = (UserInfoBean)session.getAttribute( "userinfo" );
		this.loginNo = (userinfo != null) ? userinfo.getLogin_no() : "";
	}
	
	public StringBuffer createCsvData( Map<Integer, List<String>> rows ) throws Exception {
		if (rows == null || rows.isEmpty()) {
			return new StringBuffer();
		}
		StringBuffer result = this.convertRows2Lines( rows );
		return result;
	}
	
	private StringBuffer convertRows2Lines( Map<Integer, List<String>> rows ) {
		StringBuffer sb = new StringBuffer();
		for (List<String> list : rows.values()) {
			sb.append( list2CsvOneLine( list ) );
		}
		return sb;
	}
	
	private StringBuffer list2CsvOneLine( List<String> list ) {
		StringBuffer line = new StringBuffer();
		for (int i = 0; i < list.size(); i++) {
			String str = list.get( i );
			line.append( str );
			if (i < list.size() - 1) {
				line.append( "," );
			}
		}
		line.append( "\r\n" );
		return line;
	}
}
