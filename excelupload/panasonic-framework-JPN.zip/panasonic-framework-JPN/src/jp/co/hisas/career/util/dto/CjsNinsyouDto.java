/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * CJS_NINSYOU Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CjsNinsyouDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * SIMEI_NO
     */
    private String simeiNo;
    /**
     * PASSWORD
     */
    private String password;
    /**
     * PASSWORD_UPDATE
     */
    private String passwordUpdate;
    /**
     * MANAGED_ID
     */
    private Integer managedId;
    /**
     * SYSTEM_FLG
     */
    private Integer systemFlg;

    /**
     * SIMEI_NOを取得する。
     * @return SIMEI_NO
     */
    public String getSimeiNo() {
        return simeiNo;
    }

    /**
     * SIMEI_NOを設定する。
     * @param simeiNo SIMEI_NO
     */
    public void setSimeiNo(String simeiNo) {
        this.simeiNo = simeiNo;
    }

    /**
     * PASSWORDを取得する。
     * @return PASSWORD
     */
    public String getPassword() {
        return password;
    }

    /**
     * PASSWORDを設定する。
     * @param password PASSWORD
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * PASSWORD_UPDATEを取得する。
     * @return PASSWORD_UPDATE
     */
    public String getPasswordUpdate() {
        return passwordUpdate;
    }

    /**
     * PASSWORD_UPDATEを設定する。
     * @param passwordUpdate PASSWORD_UPDATE
     */
    public void setPasswordUpdate(String passwordUpdate) {
        this.passwordUpdate = passwordUpdate;
    }

    /**
     * MANAGED_IDを取得する。
     * @return MANAGED_ID
     */
    public Integer getManagedId() {
        return managedId;
    }

    /**
     * MANAGED_IDを設定する。
     * @param managedId MANAGED_ID
     */
    public void setManagedId(Integer managedId) {
        this.managedId = managedId;
    }

    /**
     * SYSTEM_FLGを取得する。
     * @return SYSTEM_FLG
     */
    public Integer getSystemFlg() {
        return systemFlg;
    }

    /**
     * SYSTEM_FLGを設定する。
     * @param systemFlg SYSTEM_FLG
     */
    public void setSystemFlg(Integer systemFlg) {
        this.systemFlg = systemFlg;
    }

}

