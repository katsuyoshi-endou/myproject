/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * CAREER_MENU_ACTIVE Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CareerMenuActiveDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * GUID
     */
    private String guid;
    /**
     * MENU_GRP
     */
    private String menuGrp;
    /**
     * MENU_ID
     */
    private String menuId;
    /**
     * MENU_LABEL
     */
    private String menuLabel;
    /**
     * MENU_PATH
     */
    private String menuPath;
    /**
     * MENU_TRANS
     */
    private String menuTrans;
    /**
     * PARTY
     */
    private String party;
    /**
     * PARTY_LABEL
     */
    private String partyLabel;
    /**
     * LPAD_SORT
     */
    private String lpadSort;
    /**
     * AVAIL_FLG
     */
    private String availFlg;
    /**
     * SHOW_IF
     */
    private String showIf;
    /**
     * MENU_PTN
     */
    private String menuPtn;

    /**
     * GUIDを取得する。
     * @return GUID
     */
    public String getGuid() {
        return guid;
    }

    /**
     * GUIDを設定する。
     * @param guid GUID
     */
    public void setGuid(String guid) {
        this.guid = guid;
    }

    /**
     * MENU_GRPを取得する。
     * @return MENU_GRP
     */
    public String getMenuGrp() {
        return menuGrp;
    }

    /**
     * MENU_GRPを設定する。
     * @param menuGrp MENU_GRP
     */
    public void setMenuGrp(String menuGrp) {
        this.menuGrp = menuGrp;
    }

    /**
     * MENU_IDを取得する。
     * @return MENU_ID
     */
    public String getMenuId() {
        return menuId;
    }

    /**
     * MENU_IDを設定する。
     * @param menuId MENU_ID
     */
    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    /**
     * MENU_LABELを取得する。
     * @return MENU_LABEL
     */
    public String getMenuLabel() {
        return menuLabel;
    }

    /**
     * MENU_LABELを設定する。
     * @param menuLabel MENU_LABEL
     */
    public void setMenuLabel(String menuLabel) {
        this.menuLabel = menuLabel;
    }

    /**
     * MENU_PATHを取得する。
     * @return MENU_PATH
     */
    public String getMenuPath() {
        return menuPath;
    }

    /**
     * MENU_PATHを設定する。
     * @param menuPath MENU_PATH
     */
    public void setMenuPath(String menuPath) {
        this.menuPath = menuPath;
    }

    /**
     * MENU_TRANSを取得する。
     * @return MENU_TRANS
     */
    public String getMenuTrans() {
        return menuTrans;
    }

    /**
     * MENU_TRANSを設定する。
     * @param menuTrans MENU_TRANS
     */
    public void setMenuTrans(String menuTrans) {
        this.menuTrans = menuTrans;
    }

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * PARTY_LABELを取得する。
     * @return PARTY_LABEL
     */
    public String getPartyLabel() {
        return partyLabel;
    }

    /**
     * PARTY_LABELを設定する。
     * @param partyLabel PARTY_LABEL
     */
    public void setPartyLabel(String partyLabel) {
        this.partyLabel = partyLabel;
    }

    /**
     * LPAD_SORTを取得する。
     * @return LPAD_SORT
     */
    public String getLpadSort() {
        return lpadSort;
    }

    /**
     * LPAD_SORTを設定する。
     * @param lpadSort LPAD_SORT
     */
    public void setLpadSort(String lpadSort) {
        this.lpadSort = lpadSort;
    }

    /**
     * AVAIL_FLGを取得する。
     * @return AVAIL_FLG
     */
    public String getAvailFlg() {
        return availFlg;
    }

    /**
     * AVAIL_FLGを設定する。
     * @param availFlg AVAIL_FLG
     */
    public void setAvailFlg(String availFlg) {
        this.availFlg = availFlg;
    }

    /**
     * SHOW_IFを取得する。
     * @return SHOW_IF
     */
    public String getShowIf() {
        return showIf;
    }

    /**
     * SHOW_IFを設定する。
     * @param showIf SHOW_IF
     */
    public void setShowIf(String showIf) {
        this.showIf = showIf;
    }

    /**
     * MENU_PTNを取得する。
     * @return MENU_PTN
     */
    public String getMenuPtn() {
        return menuPtn;
    }

    /**
     * MENU_PTNを設定する。
     * @param menuPtn MENU_PTN
     */
    public void setMenuPtn(String menuPtn) {
        this.menuPtn = menuPtn;
    }

}

