/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dto.VPersonBelongUnionExDto;
import jp.co.hisas.career.util.log.Log;

/**
 * V_人所属本務兼務★GUID追加★ Data Access Object。
 * @author CareerDaoTool.xla
*/
public class VPersonBelongUnionExDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     // GUIDカラムは接頭辞が別になるはずなのでここに書いていません。
                     + " CMPA_CD as cmpaCd,"
                     + " STF_NO as stfNo,"
                     + " PERSON_NAME as personName,"
                     + " HONMU_FLG as honmuFlg,"
                     + " BEL_SORT as belSort,"
                     + " DEPT_CD as deptCd,"
                     + " DEPT_NM as deptNm,"
                     + " CLS_A_CD as clsACd,"
                     + " CLS_A_NM as clsANm,"
                     + " CLS_B_CD as clsBCd,"
                     + " CLS_B_NM as clsBNm,"
                     + " CLS_C_CD as clsCCd,"
                     + " CLS_C_NM as clsCNm,"
                     + " CLS_D_CD as clsDCd,"
                     + " CLS_D_NM as clsDNm,"
                     + " CLS_E_CD as clsECd,"
                     + " CLS_E_NM as clsENm,"
                     + " CLS_F_CD as clsFCd,"
                     + " CLS_F_NM as clsFNm,"
                     + " CLS_G_CD as clsGCd,"
                     + " CLS_G_NM as clsGNm,"
                     + " CLS_H_CD as clsHCd,"
                     + " CLS_H_NM as clsHNm,"
                     + " CLS_I_CD as clsICd,"
                     + " CLS_I_NM as clsINm,"
                     + " CLS_J_CD as clsJCd,"
                     + " CLS_J_NM as clsJNm,"
                     + " CLS_K_CD as clsKCd,"
                     + " CLS_K_NM as clsKNm,"
                     + " CLS_L_CD as clsLCd,"
                     + " CLS_L_NM as clsLNm,"
                     + " CLS_M_CD as clsMCd,"
                     + " CLS_M_NM as clsMNm,"
                     + " CLS_N_CD as clsNCd,"
                     + " CLS_N_NM as clsNNm,"
                     + " TXT_A as txtA,"
                     + " TXT_B as txtB,"
                     + " TXT_C as txtC,"
                     + " TXT_D as txtD,"
                     + " TXT_E as txtE,"
                     + " TXT_F as txtF,"
                     + " TXT_G as txtG,"
                     + " TXT_H as txtH,"
                     + " TXT_I as txtI,"
                     + " TXT_J as txtJ,"
                     + " TXT_K as txtK,"
                     + " TXT_L as txtL,"
                     + " TXT_M as txtM,"
                     + " TXT_N as txtN"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public VPersonBelongUnionExDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public VPersonBelongUnionExDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<VPersonBelongUnionExDto> V_PERSON_BELONG_UNIONのレコード型データのリスト。
     */ 
    public List<VPersonBelongUnionExDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 VPersonBelongUnionDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<VPersonBelongUnionExDto> lst = new ArrayList<VPersonBelongUnionExDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<VPersonBelongUnionExDto> V_PERSON_BELONG_UNIONのレコード型データのリスト。
     */ 
    public List<VPersonBelongUnionExDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 VPersonBelongUnionDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private VPersonBelongUnionExDto transferRsToDto(ResultSet rs) throws SQLException {

        VPersonBelongUnionExDto dto = new VPersonBelongUnionExDto();
        dto.setGuid(DaoUtil.convertNullToString(rs.getString("guid")));
        dto.setCmpaCd(DaoUtil.convertNullToString(rs.getString("cmpaCd")));
        dto.setStfNo(DaoUtil.convertNullToString(rs.getString("stfNo")));
        dto.setPersonName(DaoUtil.convertNullToString(rs.getString("personName")));
        dto.setHonmuFlg(DaoUtil.convertNullToString(rs.getString("honmuFlg")));
        dto.setBelSort(DaoUtil.convertNullToString(rs.getString("belSort")));
        dto.setDeptCd(DaoUtil.convertNullToString(rs.getString("deptCd")));
        dto.setDeptNm(DaoUtil.convertNullToString(rs.getString("deptNm")));
        dto.setClsACd(DaoUtil.convertNullToString(rs.getString("clsACd")));
        dto.setClsANm(DaoUtil.convertNullToString(rs.getString("clsANm")));
        dto.setClsBCd(DaoUtil.convertNullToString(rs.getString("clsBCd")));
        dto.setClsBNm(DaoUtil.convertNullToString(rs.getString("clsBNm")));
        dto.setClsCCd(DaoUtil.convertNullToString(rs.getString("clsCCd")));
        dto.setClsCNm(DaoUtil.convertNullToString(rs.getString("clsCNm")));
        dto.setClsDCd(DaoUtil.convertNullToString(rs.getString("clsDCd")));
        dto.setClsDNm(DaoUtil.convertNullToString(rs.getString("clsDNm")));
        dto.setClsECd(DaoUtil.convertNullToString(rs.getString("clsECd")));
        dto.setClsENm(DaoUtil.convertNullToString(rs.getString("clsENm")));
        dto.setClsFCd(DaoUtil.convertNullToString(rs.getString("clsFCd")));
        dto.setClsFNm(DaoUtil.convertNullToString(rs.getString("clsFNm")));
        dto.setClsGCd(DaoUtil.convertNullToString(rs.getString("clsGCd")));
        dto.setClsGNm(DaoUtil.convertNullToString(rs.getString("clsGNm")));
        dto.setClsHCd(DaoUtil.convertNullToString(rs.getString("clsHCd")));
        dto.setClsHNm(DaoUtil.convertNullToString(rs.getString("clsHNm")));
        dto.setClsICd(DaoUtil.convertNullToString(rs.getString("clsICd")));
        dto.setClsINm(DaoUtil.convertNullToString(rs.getString("clsINm")));
        dto.setClsJCd(DaoUtil.convertNullToString(rs.getString("clsJCd")));
        dto.setClsJNm(DaoUtil.convertNullToString(rs.getString("clsJNm")));
        dto.setClsKCd(DaoUtil.convertNullToString(rs.getString("clsKCd")));
        dto.setClsKNm(DaoUtil.convertNullToString(rs.getString("clsKNm")));
        dto.setClsLCd(DaoUtil.convertNullToString(rs.getString("clsLCd")));
        dto.setClsLNm(DaoUtil.convertNullToString(rs.getString("clsLNm")));
        dto.setClsMCd(DaoUtil.convertNullToString(rs.getString("clsMCd")));
        dto.setClsMNm(DaoUtil.convertNullToString(rs.getString("clsMNm")));
        dto.setClsNCd(DaoUtil.convertNullToString(rs.getString("clsNCd")));
        dto.setClsNNm(DaoUtil.convertNullToString(rs.getString("clsNNm")));
        dto.setTxtA(DaoUtil.convertNullToString(rs.getString("txtA")));
        dto.setTxtB(DaoUtil.convertNullToString(rs.getString("txtB")));
        dto.setTxtC(DaoUtil.convertNullToString(rs.getString("txtC")));
        dto.setTxtD(DaoUtil.convertNullToString(rs.getString("txtD")));
        dto.setTxtE(DaoUtil.convertNullToString(rs.getString("txtE")));
        dto.setTxtF(DaoUtil.convertNullToString(rs.getString("txtF")));
        dto.setTxtG(DaoUtil.convertNullToString(rs.getString("txtG")));
        dto.setTxtH(DaoUtil.convertNullToString(rs.getString("txtH")));
        dto.setTxtI(DaoUtil.convertNullToString(rs.getString("txtI")));
        dto.setTxtJ(DaoUtil.convertNullToString(rs.getString("txtJ")));
        dto.setTxtK(DaoUtil.convertNullToString(rs.getString("txtK")));
        dto.setTxtL(DaoUtil.convertNullToString(rs.getString("txtL")));
        dto.setTxtM(DaoUtil.convertNullToString(rs.getString("txtM")));
        dto.setTxtN(DaoUtil.convertNullToString(rs.getString("txtN")));
        return dto;
    }

}

