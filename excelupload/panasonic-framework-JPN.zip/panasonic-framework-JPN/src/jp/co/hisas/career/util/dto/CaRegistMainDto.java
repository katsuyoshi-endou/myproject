/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * CA_REGIST_MAIN Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CaRegistMainDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * CMPA_CD
     */
    private String cmpaCd;
    /**
     * STF_NO
     */
    private String stfNo;
    /**
     * PARTY
     */
    private String party;
    /**
     * GUID
     */
    private String guid;
    /**
     * PERSON_NAME
     */
    private String personName;
    /**
     * PERSON_NAME_KANA
     */
    private String personNameKana;
    /**
     * MAIL_ADDRESS
     */
    private String mailAddress;
    /**
     * HIRED_DATE
     */
    private String hiredDate;
    /**
     * RETIRE_DATE
     */
    private String retireDate;
    /**
     * REGIST_FLG
     */
    private String registFlg;
    /**
     * MAIN_FLG
     */
    private String mainFlg;
    /**
     * GNSK_FLG
     */
    private String gnskFlg;
    /**
     * FOLLOW_FLG
     */
    private String followFlg;
    /**
     * DEPT_HIER_RANK
     */
    private Integer deptHierRank;

    /**
     * CMPA_CDを取得する。
     * @return CMPA_CD
     */
    public String getCmpaCd() {
        return cmpaCd;
    }

    /**
     * CMPA_CDを設定する。
     * @param cmpaCd CMPA_CD
     */
    public void setCmpaCd(String cmpaCd) {
        this.cmpaCd = cmpaCd;
    }

    /**
     * STF_NOを取得する。
     * @return STF_NO
     */
    public String getStfNo() {
        return stfNo;
    }

    /**
     * STF_NOを設定する。
     * @param stfNo STF_NO
     */
    public void setStfNo(String stfNo) {
        this.stfNo = stfNo;
    }

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * GUIDを取得する。
     * @return GUID
     */
    public String getGuid() {
        return guid;
    }

    /**
     * GUIDを設定する。
     * @param guid GUID
     */
    public void setGuid(String guid) {
        this.guid = guid;
    }

    /**
     * PERSON_NAMEを取得する。
     * @return PERSON_NAME
     */
    public String getPersonName() {
        return personName;
    }

    /**
     * PERSON_NAMEを設定する。
     * @param personName PERSON_NAME
     */
    public void setPersonName(String personName) {
        this.personName = personName;
    }

    /**
     * PERSON_NAME_KANAを取得する。
     * @return PERSON_NAME_KANA
     */
    public String getPersonNameKana() {
        return personNameKana;
    }

    /**
     * PERSON_NAME_KANAを設定する。
     * @param personNameKana PERSON_NAME_KANA
     */
    public void setPersonNameKana(String personNameKana) {
        this.personNameKana = personNameKana;
    }

    /**
     * MAIL_ADDRESSを取得する。
     * @return MAIL_ADDRESS
     */
    public String getMailAddress() {
        return mailAddress;
    }

    /**
     * MAIL_ADDRESSを設定する。
     * @param mailAddress MAIL_ADDRESS
     */
    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    /**
     * HIRED_DATEを取得する。
     * @return HIRED_DATE
     */
    public String getHiredDate() {
        return hiredDate;
    }

    /**
     * HIRED_DATEを設定する。
     * @param hiredDate HIRED_DATE
     */
    public void setHiredDate(String hiredDate) {
        this.hiredDate = hiredDate;
    }

    /**
     * RETIRE_DATEを取得する。
     * @return RETIRE_DATE
     */
    public String getRetireDate() {
        return retireDate;
    }

    /**
     * RETIRE_DATEを設定する。
     * @param retireDate RETIRE_DATE
     */
    public void setRetireDate(String retireDate) {
        this.retireDate = retireDate;
    }

    /**
     * REGIST_FLGを取得する。
     * @return REGIST_FLG
     */
    public String getRegistFlg() {
        return registFlg;
    }

    /**
     * REGIST_FLGを設定する。
     * @param registFlg REGIST_FLG
     */
    public void setRegistFlg(String registFlg) {
        this.registFlg = registFlg;
    }

    /**
     * MAIN_FLGを取得する。
     * @return MAIN_FLG
     */
    public String getMainFlg() {
        return mainFlg;
    }

    /**
     * MAIN_FLGを設定する。
     * @param mainFlg MAIN_FLG
     */
    public void setMainFlg(String mainFlg) {
        this.mainFlg = mainFlg;
    }

    /**
     * GNSK_FLGを取得する。
     * @return GNSK_FLG
     */
    public String getGnskFlg() {
        return gnskFlg;
    }

    /**
     * GNSK_FLGを設定する。
     * @param gnskFlg GNSK_FLG
     */
    public void setGnskFlg(String gnskFlg) {
        this.gnskFlg = gnskFlg;
    }

    /**
     * FOLLOW_FLGを取得する。
     * @return FOLLOW_FLG
     */
    public String getFollowFlg() {
        return followFlg;
    }

    /**
     * FOLLOW_FLGを設定する。
     * @param followFlg FOLLOW_FLG
     */
    public void setFollowFlg(String followFlg) {
        this.followFlg = followFlg;
    }

    /**
     * DEPT_HIER_RANKを取得する。
     * @return DEPT_HIER_RANK
     */
    public Integer getDeptHierRank() {
        return deptHierRank;
    }

    /**
     * DEPT_HIER_RANKを設定する。
     * @param deptHierRank DEPT_HIER_RANK
     */
    public void setDeptHierRank(Integer deptHierRank) {
        this.deptHierRank = deptHierRank;
    }

}

