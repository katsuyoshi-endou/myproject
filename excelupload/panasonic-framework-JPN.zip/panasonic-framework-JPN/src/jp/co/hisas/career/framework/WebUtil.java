/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework;

/**
 * Web層のためのユーティリティクラス。
 * @author kat-watanabe
 */
public final class WebUtil {

    private WebUtil() {
    }
    
    public static String normalizeJavascript( String s ) {
        String ret = "";
        if ( s != null ) {
            ret = s;
            if ( !ret.trim().endsWith( ";" ) ) {
                ret += ";";
            }
        }
        return ret;
    }

}
