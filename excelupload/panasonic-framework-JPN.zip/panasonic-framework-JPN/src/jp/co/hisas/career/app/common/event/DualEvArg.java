package jp.co.hisas.career.app.common.event;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.ejb.AbstractEventArg;

@SuppressWarnings("serial")
public class DualEvArg extends AbstractEventArg {
	
	public String sharp = null;
	public String guid;

	public DualEvArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid DualEvArg: loginNo is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
	}
}
