/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * 人属性定義 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class PersonZokuseiTeigiDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 人属性ID
     */
    private String personZokuseiId;
    /**
     * 人属性分類3ID
     */
    private String personZokuseiBunrui3Id;
    /**
     * 人属性名
     */
    private String personZokuseiName;
    /**
     * 人属性表示名
     */
    private String personZokuseiHyojiName;
    /**
     * 物理格納先
     */
    private String butsuriKakunoSaki;
    /**
     * 論理テーブルフラグ
     */
    private Integer ronriTableFlag;
    /**
     * 論理テーブル名
     */
    private String ronriTableName;
    /**
     * 履歴管理フラグ
     */
    private Integer rirekiKanriFlag;
    /**
     * 公開制限フラグ
     */
    private Integer kokaiSeigenFlag;
    /**
     * 属性タイプ
     */
    private Integer zokuseiType;
    /**
     * マスタタイプ
     */
    private Integer masterType;
    /**
     * マスタID
     */
    private String masterId;
    /**
     * 更新者
     */
    private String updatePersonId;
    /**
     * 更新機能
     */
    private String updateFunction;
    /**
     * 更新日
     */
    private String updateDate;
    /**
     * 更新時間
     */
    private String updateTime;

    /**
     * 人属性IDを取得する。
     * @return 人属性ID
     */
    public String getPersonZokuseiId() {
        return personZokuseiId;
    }

    /**
     * 人属性IDを設定する。
     * @param personZokuseiId 人属性ID
     */
    public void setPersonZokuseiId(String personZokuseiId) {
        this.personZokuseiId = personZokuseiId;
    }

    /**
     * 人属性分類3IDを取得する。
     * @return 人属性分類3ID
     */
    public String getPersonZokuseiBunrui3Id() {
        return personZokuseiBunrui3Id;
    }

    /**
     * 人属性分類3IDを設定する。
     * @param personZokuseiBunrui3Id 人属性分類3ID
     */
    public void setPersonZokuseiBunrui3Id(String personZokuseiBunrui3Id) {
        this.personZokuseiBunrui3Id = personZokuseiBunrui3Id;
    }

    /**
     * 人属性名を取得する。
     * @return 人属性名
     */
    public String getPersonZokuseiName() {
        return personZokuseiName;
    }

    /**
     * 人属性名を設定する。
     * @param personZokuseiName 人属性名
     */
    public void setPersonZokuseiName(String personZokuseiName) {
        this.personZokuseiName = personZokuseiName;
    }

    /**
     * 人属性表示名を取得する。
     * @return 人属性表示名
     */
    public String getPersonZokuseiHyojiName() {
        return personZokuseiHyojiName;
    }

    /**
     * 人属性表示名を設定する。
     * @param personZokuseiHyojiName 人属性表示名
     */
    public void setPersonZokuseiHyojiName(String personZokuseiHyojiName) {
        this.personZokuseiHyojiName = personZokuseiHyojiName;
    }

    /**
     * 物理格納先を取得する。
     * @return 物理格納先
     */
    public String getButsuriKakunoSaki() {
        return butsuriKakunoSaki;
    }

    /**
     * 物理格納先を設定する。
     * @param butsuriKakunoSaki 物理格納先
     */
    public void setButsuriKakunoSaki(String butsuriKakunoSaki) {
        this.butsuriKakunoSaki = butsuriKakunoSaki;
    }

    /**
     * 論理テーブルフラグを取得する。
     * @return 論理テーブルフラグ
     */
    public Integer getRonriTableFlag() {
        return ronriTableFlag;
    }

    /**
     * 論理テーブルフラグを設定する。
     * @param ronriTableFlag 論理テーブルフラグ
     */
    public void setRonriTableFlag(Integer ronriTableFlag) {
        this.ronriTableFlag = ronriTableFlag;
    }

    /**
     * 論理テーブル名を取得する。
     * @return 論理テーブル名
     */
    public String getRonriTableName() {
        return ronriTableName;
    }

    /**
     * 論理テーブル名を設定する。
     * @param ronriTableName 論理テーブル名
     */
    public void setRonriTableName(String ronriTableName) {
        this.ronriTableName = ronriTableName;
    }

    /**
     * 履歴管理フラグを取得する。
     * @return 履歴管理フラグ
     */
    public Integer getRirekiKanriFlag() {
        return rirekiKanriFlag;
    }

    /**
     * 履歴管理フラグを設定する。
     * @param rirekiKanriFlag 履歴管理フラグ
     */
    public void setRirekiKanriFlag(Integer rirekiKanriFlag) {
        this.rirekiKanriFlag = rirekiKanriFlag;
    }

    /**
     * 公開制限フラグを取得する。
     * @return 公開制限フラグ
     */
    public Integer getKokaiSeigenFlag() {
        return kokaiSeigenFlag;
    }

    /**
     * 公開制限フラグを設定する。
     * @param kokaiSeigenFlag 公開制限フラグ
     */
    public void setKokaiSeigenFlag(Integer kokaiSeigenFlag) {
        this.kokaiSeigenFlag = kokaiSeigenFlag;
    }

    /**
     * 属性タイプを取得する。
     * @return 属性タイプ
     */
    public Integer getZokuseiType() {
        return zokuseiType;
    }

    /**
     * 属性タイプを設定する。
     * @param zokuseiType 属性タイプ
     */
    public void setZokuseiType(Integer zokuseiType) {
        this.zokuseiType = zokuseiType;
    }

    /**
     * マスタタイプを取得する。
     * @return マスタタイプ
     */
    public Integer getMasterType() {
        return masterType;
    }

    /**
     * マスタタイプを設定する。
     * @param masterType マスタタイプ
     */
    public void setMasterType(Integer masterType) {
        this.masterType = masterType;
    }

    /**
     * マスタIDを取得する。
     * @return マスタID
     */
    public String getMasterId() {
        return masterId;
    }

    /**
     * マスタIDを設定する。
     * @param masterId マスタID
     */
    public void setMasterId(String masterId) {
        this.masterId = masterId;
    }

    /**
     * 更新者を取得する。
     * @return 更新者
     */
    public String getUpdatePersonId() {
        return updatePersonId;
    }

    /**
     * 更新者を設定する。
     * @param updatePersonId 更新者
     */
    public void setUpdatePersonId(String updatePersonId) {
        this.updatePersonId = updatePersonId;
    }

    /**
     * 更新機能を取得する。
     * @return 更新機能
     */
    public String getUpdateFunction() {
        return updateFunction;
    }

    /**
     * 更新機能を設定する。
     * @param updateFunction 更新機能
     */
    public void setUpdateFunction(String updateFunction) {
        this.updateFunction = updateFunction;
    }

    /**
     * 更新日を取得する。
     * @return 更新日
     */
    public String getUpdateDate() {
        return updateDate;
    }

    /**
     * 更新日を設定する。
     * @param updateDate 更新日
     */
    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * 更新時間を取得する。
     * @return 更新時間
     */
    public String getUpdateTime() {
        return updateTime;
    }

    /**
     * 更新時間を設定する。
     * @param updateTime 更新時間
     */
    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

}

