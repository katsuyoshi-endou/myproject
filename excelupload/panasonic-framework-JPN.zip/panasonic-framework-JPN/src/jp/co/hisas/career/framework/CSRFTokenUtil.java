package jp.co.hisas.career.framework;

import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CSRF対策用の関数
 */
public class CSRFTokenUtil {
	
	/**
	 * トークン番号を発行してセッションに保存する。
	 */
	public static void setNewTokenNo( HttpServletRequest request, HttpServletResponse response ) {
		
		String login_no = null;
		HttpSession session = request.getSession();
		final UserInfoBean userinfobean = (UserInfoBean)session.getAttribute( "userinfo" );
		login_no = userinfobean.getLogin_no();
		String newTokenNo = UUID.randomUUID().toString();
		session.setAttribute( "tokenNo", newTokenNo );
		
		if (Log.isSecurityDebugOn()) {
			Log.security( login_no, "トークンNoを新規に採番します。" );
			Log.security( login_no, "トークン番号：" + session.getAttribute( "tokenNo" ) );
		}
		
		/* Set Token on Cookie */
		Cookie cookie = new Cookie( "token", newTokenNo );
		cookie.setPath( "/" + AppDef.CTX_ROOT );
		response.addCookie( cookie );
		
		logRequest( request, "[setNewTokenNo]" );
		
	}
	
	/**
	 * トークン番号を発行してセッションに保存する。 JSPに遷移する場合は、トークンを新しくする。
	 * Servletにforwardする場合は、トークンを新しくするとトークン不一致で落ちる。
	 * リクエストパラメータは、forwardで引き継がれるため。
	 */
	public static void setNewTokenNo( HttpServletRequest request, HttpServletResponse response, String forwardPage ) {
		boolean isJsp = (forwardPage != null) ? forwardPage.matches( "^.*(JSP|jsp)$" ) : false;
		if (isJsp) {
			if (Log.isSecurityDebugOn()) {
				Log.security( null, "CSRFTokenUtil.setNewTokenNo" );
			}
			CSRFTokenUtil.setNewTokenNo( request, response );
		}
		if (Log.isSecurityDebugOn()) {
			Log.security( null, "dispatcher:" + forwardPage );
		}
	}
	
	/**
	 * リクエストのトークン番号とセッションのトークン番号を比較して 異なる場合はエラーとします。
	 */
	public static void checkTokenNo( HttpServletRequest request ) throws CareerException {
		
		logRequest( request, "[checkTokenNo]" );
		
		String login_no = null;
		HttpSession session = request.getSession();
		
		String sessionTokenNo = AU.getSessionAttr( session, "tokenNo" );
		String tokenNo = AU.getReqParaAttrVal( request, "tokenNo" );
		if (!SU.equals( sessionTokenNo, tokenNo )) {
			tokenNo = SU.getCookieValue( request, "token" );
		}
		
		request.getContextPath();
		
		if (sessionTokenNo == null) {
			session.setAttribute( "VYY_ERROR_PAGE_REQUEST_KEY", "セキュリティエラーが発生しました。" );
			Log.securityError( login_no, "[" + request.getRequestURL() + "]" + "sessionTokenNo-トークン番号がNullです。" );
			throw new CareerException( "HJE-1001" );
		} else if (tokenNo == null) {
			session.setAttribute( "VYY_ERROR_PAGE_REQUEST_KEY", "セキュリティエラーが発生しました。" );
			Log.securityError( login_no, "[" + request.getRequestURL() + "]" + "tokenNo-トークン番号がNullです。" );
			throw new CareerException( "HJE-1001" );
		} else {
			if (sessionTokenNo.equals( tokenNo )) {
				if (Log.isSecurityDebugOn()) {
					Log.security( login_no, "[" + request.getRequestURL() + "]" + "トークン番号一致" );
					Log.security( login_no, "[" + request.getRequestURL() + "][tokenNo]" + tokenNo );
					Log.security( login_no, "[" + request.getRequestURL() + "][sessionTokenNo]" + sessionTokenNo );
				}
			} else {
				session.setAttribute( "VYY_ERROR_PAGE_REQUEST_KEY", "セキュリティエラーが発生しました。" );
				Log.securityError( login_no, "[" + request.getRequestURL() + "]" + "トークン番号不一致" );
				Log.securityError( login_no, "[" + request.getRequestURL() + "][tokenNo]" + tokenNo );
				Log.securityError( login_no, "[" + request.getRequestURL() + "][sessionTokenNo]" + sessionTokenNo );
				throw new CareerException( "HJE-1001" );
			}
		}
	}
	
	/**
	 * リクエストパラメータのログへの出力。
	 */
	public static void logRequest( HttpServletRequest request, String prefix ) {
		
		if (!Log.isSecurityDebugOn()) {
			return;
		}
		
		String loginNo = null;
		final String reqURL = request.getRequestURI();
		@SuppressWarnings("rawtypes")
		final Map reqParamMap = request.getParameterMap();
		
		for (@SuppressWarnings("rawtypes")
		Iterator ite = reqParamMap.keySet().iterator(); ite.hasNext();) {
			
			String reqParamName = (String)ite.next();
			String[] reqParamValueArr = (String[])reqParamMap.get( reqParamName );
			String reqParamValue = reqParamValueArr[0];
			
			if (reqParamName == null || reqParamValue == null) {
				// チェック処理上でのNullPointerを排除
				continue;
			}
			
			Log.security( loginNo, prefix + "[" + reqURL + "] [" + reqParamName + "=" + cnvStrArr( reqParamValueArr ) + "]" );
		}
	}
	
	/**
	 * String配列を１行String（カンマ区切り）にして返す。
	 */
	public static String cnvStrArr( String[] str ) {
		String rtnStr = "";
		if (str == null) {
			return rtnStr;
		}
		for (int i = 0; i < str.length; i++) {
			if (i == 0) {
				rtnStr = str[i];
			} else {
				rtnStr = rtnStr + "," + str[i];
			}
		}
		try {
			rtnStr = PZZ010_CharacterUtil.strEncode( rtnStr );
		} catch (UnsupportedEncodingException e) {
		}
		return rtnStr;
	}
}
