package jp.co.hisas.career.framework;

public interface SQLParameter {
	
	public void setParameter( String parameter );
	
	public String getParameter();
	
	public String getFormatedParameter();
	
}
