package jp.co.hisas.career.app.common.event;

import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.CaRegistDto;

@SuppressWarnings("serial")
public class CaRegistEvRslt extends AbstractEventResult {
	
	public String party;
	public CaRegistDto caRegistDto;
}
