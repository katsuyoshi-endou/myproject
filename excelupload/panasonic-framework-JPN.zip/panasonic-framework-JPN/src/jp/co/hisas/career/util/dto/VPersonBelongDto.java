/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * V_人所属 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VPersonBelongDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 人ID
     */
    private String personId;
    /**
     * 氏名
     */
    private String personName;
    /**
     * 部署コード
     */
    private String deptCd;
    /**
     * 部署名称
     */
    private String deptNm;
    /**
     * クラスＡコード
     */
    private String clsACd;
    /**
     * クラスＡ名称
     */
    private String clsANm;
    /**
     * クラスＡソート
     */
    private String clsASort;
    /**
     * クラスＢコード
     */
    private String clsBCd;
    /**
     * クラスＢ名称
     */
    private String clsBNm;
    /**
     * クラスＢソート
     */
    private String clsBSort;
    /**
     * クラスＣコード
     */
    private String clsCCd;
    /**
     * クラスＣ名称
     */
    private String clsCNm;
    /**
     * クラスＣソート
     */
    private String clsCSort;
    /**
     * クラスＤコード
     */
    private String clsDCd;
    /**
     * クラスＤ名称
     */
    private String clsDNm;
    /**
     * クラスＤソート
     */
    private String clsDSort;
    /**
     * クラスＥコード
     */
    private String clsECd;
    /**
     * クラスＥ名称
     */
    private String clsENm;
    /**
     * クラスＥソート
     */
    private String clsESort;
    /**
     * クラスＦコード
     */
    private String clsFCd;
    /**
     * クラスＦ名称
     */
    private String clsFNm;
    /**
     * クラスＦソート
     */
    private String clsFSort;
    /**
     * クラスＧコード
     */
    private String clsGCd;
    /**
     * クラスＧ名称
     */
    private String clsGNm;
    /**
     * クラスＧソート
     */
    private String clsGSort;
    /**
     * クラスＨコード
     */
    private String clsHCd;
    /**
     * クラスＨ名称
     */
    private String clsHNm;
    /**
     * クラスＨソート
     */
    private String clsHSort;
    /**
     * クラスＩコード
     */
    private String clsICd;
    /**
     * クラスＩ名称
     */
    private String clsINm;
    /**
     * クラスＩソート
     */
    private String clsISort;
    /**
     * クラスＪコード
     */
    private String clsJCd;
    /**
     * クラスＪ名称
     */
    private String clsJNm;
    /**
     * クラスＪソート
     */
    private String clsJSort;

    /**
     * 人IDを取得する。
     * @return 人ID
     */
    public String getPersonId() {
        return personId;
    }

    /**
     * 人IDを設定する。
     * @param personId 人ID
     */
    public void setPersonId(String personId) {
        this.personId = personId;
    }

    /**
     * 氏名を取得する。
     * @return 氏名
     */
    public String getPersonName() {
        return personName;
    }

    /**
     * 氏名を設定する。
     * @param personName 氏名
     */
    public void setPersonName(String personName) {
        this.personName = personName;
    }

    /**
     * 部署コードを取得する。
     * @return 部署コード
     */
    public String getDeptCd() {
        return deptCd;
    }

    /**
     * 部署コードを設定する。
     * @param deptCd 部署コード
     */
    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    /**
     * 部署名称を取得する。
     * @return 部署名称
     */
    public String getDeptNm() {
        return deptNm;
    }

    /**
     * 部署名称を設定する。
     * @param deptNm 部署名称
     */
    public void setDeptNm(String deptNm) {
        this.deptNm = deptNm;
    }

    /**
     * クラスＡコードを取得する。
     * @return クラスＡコード
     */
    public String getClsACd() {
        return clsACd;
    }

    /**
     * クラスＡコードを設定する。
     * @param clsACd クラスＡコード
     */
    public void setClsACd(String clsACd) {
        this.clsACd = clsACd;
    }

    /**
     * クラスＡ名称を取得する。
     * @return クラスＡ名称
     */
    public String getClsANm() {
        return clsANm;
    }

    /**
     * クラスＡ名称を設定する。
     * @param clsANm クラスＡ名称
     */
    public void setClsANm(String clsANm) {
        this.clsANm = clsANm;
    }

    /**
     * クラスＡソートを取得する。
     * @return クラスＡソート
     */
    public String getClsASort() {
        return clsASort;
    }

    /**
     * クラスＡソートを設定する。
     * @param clsASort クラスＡソート
     */
    public void setClsASort(String clsASort) {
        this.clsASort = clsASort;
    }

    /**
     * クラスＢコードを取得する。
     * @return クラスＢコード
     */
    public String getClsBCd() {
        return clsBCd;
    }

    /**
     * クラスＢコードを設定する。
     * @param clsBCd クラスＢコード
     */
    public void setClsBCd(String clsBCd) {
        this.clsBCd = clsBCd;
    }

    /**
     * クラスＢ名称を取得する。
     * @return クラスＢ名称
     */
    public String getClsBNm() {
        return clsBNm;
    }

    /**
     * クラスＢ名称を設定する。
     * @param clsBNm クラスＢ名称
     */
    public void setClsBNm(String clsBNm) {
        this.clsBNm = clsBNm;
    }

    /**
     * クラスＢソートを取得する。
     * @return クラスＢソート
     */
    public String getClsBSort() {
        return clsBSort;
    }

    /**
     * クラスＢソートを設定する。
     * @param clsBSort クラスＢソート
     */
    public void setClsBSort(String clsBSort) {
        this.clsBSort = clsBSort;
    }

    /**
     * クラスＣコードを取得する。
     * @return クラスＣコード
     */
    public String getClsCCd() {
        return clsCCd;
    }

    /**
     * クラスＣコードを設定する。
     * @param clsCCd クラスＣコード
     */
    public void setClsCCd(String clsCCd) {
        this.clsCCd = clsCCd;
    }

    /**
     * クラスＣ名称を取得する。
     * @return クラスＣ名称
     */
    public String getClsCNm() {
        return clsCNm;
    }

    /**
     * クラスＣ名称を設定する。
     * @param clsCNm クラスＣ名称
     */
    public void setClsCNm(String clsCNm) {
        this.clsCNm = clsCNm;
    }

    /**
     * クラスＣソートを取得する。
     * @return クラスＣソート
     */
    public String getClsCSort() {
        return clsCSort;
    }

    /**
     * クラスＣソートを設定する。
     * @param clsCSort クラスＣソート
     */
    public void setClsCSort(String clsCSort) {
        this.clsCSort = clsCSort;
    }

    /**
     * クラスＤコードを取得する。
     * @return クラスＤコード
     */
    public String getClsDCd() {
        return clsDCd;
    }

    /**
     * クラスＤコードを設定する。
     * @param clsDCd クラスＤコード
     */
    public void setClsDCd(String clsDCd) {
        this.clsDCd = clsDCd;
    }

    /**
     * クラスＤ名称を取得する。
     * @return クラスＤ名称
     */
    public String getClsDNm() {
        return clsDNm;
    }

    /**
     * クラスＤ名称を設定する。
     * @param clsDNm クラスＤ名称
     */
    public void setClsDNm(String clsDNm) {
        this.clsDNm = clsDNm;
    }

    /**
     * クラスＤソートを取得する。
     * @return クラスＤソート
     */
    public String getClsDSort() {
        return clsDSort;
    }

    /**
     * クラスＤソートを設定する。
     * @param clsDSort クラスＤソート
     */
    public void setClsDSort(String clsDSort) {
        this.clsDSort = clsDSort;
    }

    /**
     * クラスＥコードを取得する。
     * @return クラスＥコード
     */
    public String getClsECd() {
        return clsECd;
    }

    /**
     * クラスＥコードを設定する。
     * @param clsECd クラスＥコード
     */
    public void setClsECd(String clsECd) {
        this.clsECd = clsECd;
    }

    /**
     * クラスＥ名称を取得する。
     * @return クラスＥ名称
     */
    public String getClsENm() {
        return clsENm;
    }

    /**
     * クラスＥ名称を設定する。
     * @param clsENm クラスＥ名称
     */
    public void setClsENm(String clsENm) {
        this.clsENm = clsENm;
    }

    /**
     * クラスＥソートを取得する。
     * @return クラスＥソート
     */
    public String getClsESort() {
        return clsESort;
    }

    /**
     * クラスＥソートを設定する。
     * @param clsESort クラスＥソート
     */
    public void setClsESort(String clsESort) {
        this.clsESort = clsESort;
    }

    /**
     * クラスＦコードを取得する。
     * @return クラスＦコード
     */
    public String getClsFCd() {
        return clsFCd;
    }

    /**
     * クラスＦコードを設定する。
     * @param clsFCd クラスＦコード
     */
    public void setClsFCd(String clsFCd) {
        this.clsFCd = clsFCd;
    }

    /**
     * クラスＦ名称を取得する。
     * @return クラスＦ名称
     */
    public String getClsFNm() {
        return clsFNm;
    }

    /**
     * クラスＦ名称を設定する。
     * @param clsFNm クラスＦ名称
     */
    public void setClsFNm(String clsFNm) {
        this.clsFNm = clsFNm;
    }

    /**
     * クラスＦソートを取得する。
     * @return クラスＦソート
     */
    public String getClsFSort() {
        return clsFSort;
    }

    /**
     * クラスＦソートを設定する。
     * @param clsFSort クラスＦソート
     */
    public void setClsFSort(String clsFSort) {
        this.clsFSort = clsFSort;
    }

    /**
     * クラスＧコードを取得する。
     * @return クラスＧコード
     */
    public String getClsGCd() {
        return clsGCd;
    }

    /**
     * クラスＧコードを設定する。
     * @param clsGCd クラスＧコード
     */
    public void setClsGCd(String clsGCd) {
        this.clsGCd = clsGCd;
    }

    /**
     * クラスＧ名称を取得する。
     * @return クラスＧ名称
     */
    public String getClsGNm() {
        return clsGNm;
    }

    /**
     * クラスＧ名称を設定する。
     * @param clsGNm クラスＧ名称
     */
    public void setClsGNm(String clsGNm) {
        this.clsGNm = clsGNm;
    }

    /**
     * クラスＧソートを取得する。
     * @return クラスＧソート
     */
    public String getClsGSort() {
        return clsGSort;
    }

    /**
     * クラスＧソートを設定する。
     * @param clsGSort クラスＧソート
     */
    public void setClsGSort(String clsGSort) {
        this.clsGSort = clsGSort;
    }

    /**
     * クラスＨコードを取得する。
     * @return クラスＨコード
     */
    public String getClsHCd() {
        return clsHCd;
    }

    /**
     * クラスＨコードを設定する。
     * @param clsHCd クラスＨコード
     */
    public void setClsHCd(String clsHCd) {
        this.clsHCd = clsHCd;
    }

    /**
     * クラスＨ名称を取得する。
     * @return クラスＨ名称
     */
    public String getClsHNm() {
        return clsHNm;
    }

    /**
     * クラスＨ名称を設定する。
     * @param clsHNm クラスＨ名称
     */
    public void setClsHNm(String clsHNm) {
        this.clsHNm = clsHNm;
    }

    /**
     * クラスＨソートを取得する。
     * @return クラスＨソート
     */
    public String getClsHSort() {
        return clsHSort;
    }

    /**
     * クラスＨソートを設定する。
     * @param clsHSort クラスＨソート
     */
    public void setClsHSort(String clsHSort) {
        this.clsHSort = clsHSort;
    }

    /**
     * クラスＩコードを取得する。
     * @return クラスＩコード
     */
    public String getClsICd() {
        return clsICd;
    }

    /**
     * クラスＩコードを設定する。
     * @param clsICd クラスＩコード
     */
    public void setClsICd(String clsICd) {
        this.clsICd = clsICd;
    }

    /**
     * クラスＩ名称を取得する。
     * @return クラスＩ名称
     */
    public String getClsINm() {
        return clsINm;
    }

    /**
     * クラスＩ名称を設定する。
     * @param clsINm クラスＩ名称
     */
    public void setClsINm(String clsINm) {
        this.clsINm = clsINm;
    }

    /**
     * クラスＩソートを取得する。
     * @return クラスＩソート
     */
    public String getClsISort() {
        return clsISort;
    }

    /**
     * クラスＩソートを設定する。
     * @param clsISort クラスＩソート
     */
    public void setClsISort(String clsISort) {
        this.clsISort = clsISort;
    }

    /**
     * クラスＪコードを取得する。
     * @return クラスＪコード
     */
    public String getClsJCd() {
        return clsJCd;
    }

    /**
     * クラスＪコードを設定する。
     * @param clsJCd クラスＪコード
     */
    public void setClsJCd(String clsJCd) {
        this.clsJCd = clsJCd;
    }

    /**
     * クラスＪ名称を取得する。
     * @return クラスＪ名称
     */
    public String getClsJNm() {
        return clsJNm;
    }

    /**
     * クラスＪ名称を設定する。
     * @param clsJNm クラスＪ名称
     */
    public void setClsJNm(String clsJNm) {
        this.clsJNm = clsJNm;
    }

    /**
     * クラスＪソートを取得する。
     * @return クラスＪソート
     */
    public String getClsJSort() {
        return clsJSort;
    }

    /**
     * クラスＪソートを設定する。
     * @param clsJSort クラスＪソート
     */
    public void setClsJSort(String clsJSort) {
        this.clsJSort = clsJSort;
    }

}

