/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.CareerPersonRsvExDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * 人 Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CareerPersonRsvExDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " PERSON_ID as personId,"
                     + " PERSON_NAME as personName,"
                     + " MAIL_ADDRESS as mailAddress,"
                     + " REGIST_FLG as registFlg,"
                     + " DEPT_HIER_RANK as deptHierRank"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CareerPersonRsvExDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CareerPersonRsvExDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param personId 人ID
     * @return CareerPersonRsvExDto CAREER_PERSON_RSVのレコード型データ。
     */ 
    public CareerPersonRsvExDto select(String personId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CAREER_PERSON_RSV"
                         + " WHERE PERSON_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CareerPersonRsvDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, personId);
            rs = pstmt.executeQuery();
            CareerPersonRsvExDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<CareerPersonRsvExDto> CAREER_PERSON_RSVのレコード型データのリスト。
     */ 
    public List<CareerPersonRsvExDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CareerPersonRsvDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CareerPersonRsvExDto> lst = new ArrayList<CareerPersonRsvExDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CareerPersonRsvExDto> CAREER_PERSON_RSVのレコード型データのリスト。
     */ 
    public List<CareerPersonRsvExDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CareerPersonRsvDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param pstmt PreparedStatement
     */ 
    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("【DaoMethod Call】 CareerPersonRsvDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param sql SQL文
     */ 
    public void executeDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CareerPersonRsvDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CareerPersonRsvExDto transferRsToDto(ResultSet rs) throws SQLException {

        CareerPersonRsvExDto dto = new CareerPersonRsvExDto();
        dto.setPersonId(DaoUtil.convertNullToString(rs.getString("personId")));
        dto.setPersonName(DaoUtil.convertNullToString(rs.getString("personName")));
        dto.setMailAddress(DaoUtil.convertNullToString(rs.getString("mailAddress")));
        dto.setRegistFlg(DaoUtil.convertNullToString(rs.getString("registFlg")));
        dto.setDeptHierRank(rs.getInt("deptHierRank"));
        dto.setStat(DaoUtil.convertNullToString(rs.getString("stat")));
        return dto;
    }

}

