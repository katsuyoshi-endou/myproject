package jp.co.hisas.career.ejb;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.rmi.RemoteException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ020_MakeSQLUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;

public class PYF_BlobDBAccessCosmiEJBBean implements SessionBean {
	
	/** SessionContextオブジェクト */
	private SessionContext my_ssc = null;
	
	/**
	 * BLOB型をインサートする
	 */
	public int InsertBLOB( final String login_no, final String table, final String[] column, final String[] save, final byte[] blob, final String[] primary_key, final String[] primary_value ) throws SQLException, NamingException, Exception {
		Log.method( login_no, "IN", "" );
		final int count = this.InsertBlob( login_no, table, column, save, blob, primary_key, primary_value, "INSERT" );
		Log.method( login_no, "OUT", "" );
		return count;
	}
	
	/**
	 * BLOB型をアップデートする
	 */
	public int UpdateBLOB( final String login_no, final String table, final String[] column, final String[] save, final byte[] blob, final String[] primary_key, final String[] primary_value ) throws SQLException, NamingException, Exception {
		Log.method( login_no, "IN", "" );
		final int count = this.InsertBlob( login_no, table, column, save, blob, primary_key, primary_value, "UPDATE" );
		Log.method( login_no, "OUT", "" );
		return count;
	}
	
	/**
	 * BLOB型をアップデートする(PYF_ByteDataBean[]にあるデータをすべてアップデートする)
	 */
	public int UpdateBLOB( final String login_no, final String table, final String[] column, final String[] save, final PYF_ByteDataBean[] byteDataBeans, final String[] primary_key, final String[] primary_value ) throws SQLException, NamingException, Exception {
		Log.method( login_no, "IN", "" );
		int ret = 0;
		for (int i = 0; i < byteDataBeans.length; i++) {
			final byte[] blob = byteDataBeans[i].getData();
			final String[] primaryValue = { primary_value[i] };
			final int count = this.InsertBlob( login_no, table, column, save, blob, primary_key, primaryValue, "UPDATE" );
			ret += count;
		}
		Log.method( login_no, "OUT", "" );
		return ret;
	}
	
	/**
	 * BLOBをセレクトする
	 */
	public byte[] SelectBLOB( final String login_no, final String table, final String blob_colum, final String[] primary_key, final String[] primary_value ) throws SQLException, NamingException, Exception {
		Log.method( login_no, "IN", "" );
		byte[] blob = null;
		blob = this.SelectBlob( login_no, table, blob_colum, primary_key, primary_value );
		Log.method( login_no, "IN", "" );
		return blob;
	}
	
	/**
	 * BLOBをセレクトする
	 */
	public byte[] SelectBLOB1( final String login_no, final String table, final String blob_colum, final String[] primary_key, final String[] primary_value ) throws SQLException, NamingException {
		Log.method( login_no, "IN", "" );
		byte[] blob = null;
		try {
			blob = this.SelectBlob( login_no, table, blob_colum, primary_key, primary_value );
		} catch (final Exception e) {
			throw new EJBException( e );
		}
		Log.method( login_no, "IN", "" );
		return blob;
	}
	
	/**
	 * OracleJDBC用 BLOBインサート
	 */
	@SuppressWarnings("deprecation")
	private int InsertBlob( final String login_no, final String table, final String[] column, final String[] save, final byte[] blob, final String[] primary_key, final String[] primary_value, final String TYPE ) throws SQLException, NamingException, Exception {
		Log.method( login_no, "IN", "" );
		Connection dbConn = null;
		PreparedStatement stmt = null;
		final ResultSet rs = null;
		try {
			dbConn = PZZ040_SQLUtility.getConnection( login_no );
			String sql = null;
			if (TYPE.equals( "INSERT" )) {
				sql = PZZ020_MakeSQLUtil.makeInsertSQL( login_no, table, column, save );
			} else if (TYPE.equals( "UPDATE" )) {
				sql = PZZ020_MakeSQLUtil.makeUpdateSQL( login_no, table, column, save, primary_key, primary_value );
			}
			sql = sql.replaceAll( "BLOB_DATA", "?" );
			Log.debug( sql );
			stmt = dbConn.prepareStatement( sql );
			if (blob == null) {
				stmt.setNull( 1, java.sql.Types.BLOB );
			} else {
				stmt.setBytes( 1, blob );
			}
			final int num = stmt.executeUpdate();
			Log.method( login_no, "OUT", "" );
			return num;
		} catch (final SQLException sqle) {
			this.my_ssc.setRollbackOnly();
			Log.error( login_no, sqle );
			throw sqle;
		} catch (final NamingException ne) {
			this.my_ssc.setRollbackOnly();
			Log.error( login_no, ne );
			throw ne;
		} catch (final Exception e) {
			this.my_ssc.setRollbackOnly();
			Log.error( login_no, e );
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection( login_no, dbConn, stmt, rs );
		}
	}
	
	/**
	 * BLOBをセレクトする
	 */
	private byte[] SelectBlob( final String login_no, final String table, final String blob_colum, final String[] primary_key, final String[] primary_value ) throws SQLException, NamingException, Exception {
		Log.method( login_no, "IN", "" );
		Connection dbConn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			dbConn = PZZ040_SQLUtility.getConnection( login_no );
			final String sql = this.makeSelectSQL( login_no, table, blob_colum, primary_key, primary_value );
			Log.debug( sql );
			stmt = dbConn.prepareStatement( sql );
			rs = stmt.executeQuery();
			byte[] result_byte = null;
			if (rs.next()) {
				final Blob blob = rs.getBlob( blob_colum );
				if (blob != null) {
					final ByteArrayOutputStream baos = new ByteArrayOutputStream();
					final byte[] buffer = new byte[4096];
					final InputStream is = blob.getBinaryStream();
					int size;
					while ((size = is.read( buffer )) != -1) {
						baos.write( buffer, 0, size );
					}
					baos.close();
					result_byte = baos.toByteArray();
				}
			}
			Log.method( login_no, "OUT", "" );
			return result_byte;
		} catch (final SQLException sqle) {
			Log.error( login_no, sqle );
			throw sqle;
		} catch (final NamingException ne) {
			Log.error( login_no, ne );
			throw ne;
		} catch (final Exception e) {
			Log.error( login_no, e );
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection( login_no, dbConn, stmt, rs );
		}
	}
	
	/**
	 * 引数で渡されたテーブル名、カラム、データを元にインサート文を作成する
	 */
	private String makeSelectSQL( final String login_no, final String table, final String blob_colum, final String[] primary_key, final String[] primary_value ) throws Exception {
		Log.method( login_no, "IN", "" );
		try {
			String sql = "SELECT " + blob_colum + " FROM " + table + " WHERE ";
			if (PZZ020_MakeSQLUtil.getColumnTypeCheck( primary_key[0] ).equals( "1" )) {
				sql = sql + primary_key[0] + " = " + primary_value[0];
			} else {
				sql = sql + primary_key[0] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData( primary_value[0] ) + "'";
			}
			for (int i = 1; i < primary_key.length; i++) {
				if (PZZ020_MakeSQLUtil.getColumnTypeCheck( primary_key[i] ).equals( "1" )) {
					sql = sql + " AND " + primary_key[i] + " = " + primary_value[i];
				} else {
					sql = sql + " AND " + primary_key[i] + " = '" + PZZ020_MakeSQLUtil.sanitizeSQLData( primary_value[i] ) + "'";
				}
			}
			Log.method( login_no, "OUT", "" );
			return sql;
		} catch (final Exception e) {
			Log.error( login_no, "HJE-0017", e );
			throw e;
		}
	}
	
	public void ejbActivate() throws RemoteException {
		/* Do nothing. */
	}
	
	public void ejbCreate() throws CreateException, RemoteException {
		/* Do nothing. */
	}
	
	public void ejbPassivate() throws RemoteException {
		/* Do nothing. */
	}
	
	public void ejbRemove() throws RemoteException {
		/* Do nothing. */
	}
	
	public SessionContext getSessionContext() {
		return this.my_ssc;
	}
	
	public void setSessionContext( final SessionContext val ) throws RemoteException {
		this.my_ssc = val;
	}
}
