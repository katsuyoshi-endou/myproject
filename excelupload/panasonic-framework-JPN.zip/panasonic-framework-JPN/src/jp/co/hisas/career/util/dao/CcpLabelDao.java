/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dto.CcpLabelDto;
import jp.co.hisas.career.util.log.Log; 

/**
 * ラベル Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CcpLabelDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " PARTY as party,"
                     + " LABEL_ID as labelId,"
                     + " LABEL_TEXT as labelText,"
                     + " LABEL_TEXT_L2 as labelTextL2,"
                     + " LABEL_TEXT_L3 as labelTextL3"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CcpLabelDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CcpLabelDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * Insert文を実行する。
     * @param dto CCP_LABELのデータ。
     */ 
    public void insert(CcpLabelDto dto) {

        final String sql = "INSERT INTO CCP_LABEL ("
                         + "PARTY,"
                         + "LABEL_ID,"
                         + "LABEL_TEXT,"
                         + "LABEL_TEXT_L2,"
                         + "LABEL_TEXT_L3"
                         + ")VALUES(?,?,?,?,? )"
                         ;
        Log.sql("【DaoMethod Call】 CcpLabelDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getParty());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getLabelId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getLabelText());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getLabelTextL2());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getLabelTextL3());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * 全列update文を実行する。
     * @param dto CCP_LABELのレコード型データ。
     */
    public void update(CcpLabelDto dto) {

        final String sql = "UPDATE CCP_LABEL SET "
                         + "LABEL_TEXT = ?,"
                         + "LABEL_TEXT_L2 = ?,"
                         + "LABEL_TEXT_L3 = ?"
                         + " WHERE PARTY = ?"
                         + " AND LABEL_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CcpLabelDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getLabelText());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getLabelTextL2());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getLabelTextL3());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getParty());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getLabelId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param party PARTY
     * @param labelId ラベルID
     * @return CcpLabelDto CCP_LABELのレコード型データ。
     */ 
    public CcpLabelDto select(String party, String labelId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CCP_LABEL"
                         + " WHERE PARTY = ?"
                         + " AND LABEL_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CcpLabelDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, party);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, labelId);
            rs = pstmt.executeQuery();
            CcpLabelDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CcpLabelDto transferRsToDto(ResultSet rs) throws SQLException {

        CcpLabelDto dto = new CcpLabelDto();
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setLabelId(DaoUtil.convertNullToString(rs.getString("labelId")));
        dto.setLabelText(DaoUtil.convertNullToString(rs.getString("labelText")));
        dto.setLabelTextL2(DaoUtil.convertNullToString(rs.getString("labelTextL2")));
        dto.setLabelTextL3(DaoUtil.convertNullToString(rs.getString("labelTextL3")));
        return dto;
    }

    /**
     * 全てのラベルを取得する
     * @return List<CcpLabelDto> CCP_LABELのレコード型データのリスト。
     */
    public List<CcpLabelDto> selectAll() {

        final String sql = "SELECT " + ALLCOLS + " FROM CCP_LABEL";
        Log.sql("【DaoMethod Call】 CcpLabelDao.selectAll");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            List<CcpLabelDto> lst = new ArrayList<CcpLabelDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

