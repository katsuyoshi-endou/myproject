package jp.co.hisas.career.app.common.bean;

import java.io.Serializable;
import java.util.List;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class UserInfoBean implements Serializable {
	
	/**
	 * UserInfo SessionKey
	 * 
	 * ログイン情報は特別にここで管理。
	 * ※AppSessionKeyに定義するとメニュー表示時にクリアされるため。
	 */
	public static final String SESSION_KEY = "userinfo";
	
	private String party = "";
	private int langNo = 1;
	
	private List<String> kengenList = null;
	
	private String mainKengen = "";
	
	private String login_no = "";
	
	private String kanji_simei = "";
	
	/** 業務アカウント向け統合アカウント変換後GUID */
	private String operatorGuid;
	
	/** 業務アカウントかどうか */
	public boolean isOperator = false;
	
	public UserInfoBean() {
		super();
	}
	
	public void loadParty( String party ) throws CareerException {
		if (SU.isNotBlank( party )) {
			this.party = party;
			return;
		} else {
			throw new CareerException( "Party is Required." );
		}
	}
	
	public String getParty() {
		return party;
	}
	
	public void setParty( String party ) {
		this.party = party;
	}
	
	public void loadLangNo( String lang ) {
		if (SU.equals( lang, "en" )) {
			this.langNo = 2;
		}
		else if (SU.equals( lang, "zh" )) {
			this.langNo = 3;
		}
		else {
			this.langNo = 1;
		}
	}
	
	public int getLangNo() {
		return this.langNo;
	}
	
	public void setLangNo( int langNo ) {
		this.langNo = langNo;
	}
	
	/**
	 * ログインユーザの氏名番号を返す。
	 * 
	 * @return ログインユーザの氏名番号
	 */
	public String getLogin_no() {
		return this.login_no;
	}
	
	/**
	 * ログインユーザの氏名番号をセットする。
	 * 
	 * @param ログインユーザの氏名番号
	 */
	public void setLogin_no( final String val ) {
		this.login_no = val;
	}
	
	public String getKanjiSimei() {
		return this.kanji_simei;
	}
	
	public void setKanjiSimei( String val ) {
		this.kanji_simei = val;
	}
	
	public List<String> getKengenList() {
		return kengenList;
	}
	
	public void setKengenList( List<String> kengenList ) {
		this.kengenList = kengenList;
	}
	
	public String getMainKengen() {
		return mainKengen;
	}
	
	public void setMainKengen( String mainKengen ) {
		this.mainKengen = mainKengen;
	}

	public String getOperatorGuid() {
		return operatorGuid;
	}

	public void setOperatorGuid( String operatorGuid ) {
		this.operatorGuid = operatorGuid;
	}

}
