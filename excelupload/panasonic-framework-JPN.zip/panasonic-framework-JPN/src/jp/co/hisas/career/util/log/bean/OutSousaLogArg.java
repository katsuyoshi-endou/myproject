package jp.co.hisas.career.util.log.bean;

import java.io.Serializable;

public class OutSousaLogArg implements Serializable {
    
    private String logonShimeiNo = null;
    
    private String displayCondition = null;
    
    private String targetShimeiNo = null;
    
    //UPD 20100901 B-CT-1212 a.funew ログ整備 Start
    //操作(基本的にはボタンIDを格納)
    private String sousa = null;
    //UPD 20100901 B-CT-1212 a.funew ログ整備 Start

	public String getDisplayCondition() {
        return displayCondition;
    }

    /**
     * 一覧系の画面を表示する際の表示条件を設定する。
     * 一覧系の画面ではない場合は、設定不要。
     * @param diaplayCondition
     */
    public void setDisplayCondition( String diaplayCondition ) {
        this.displayCondition = diaplayCondition;
    }

    public String getTargetShimeiNo() {
        return targetShimeiNo;
    }

    /**
     * 表示対象者の氏名NOを設定する。
     * 一覧系の画面で、複数人同時に表示する場合は設定不要。
     * @param targetShimeiNo
     */
    public void setTargetShimeiNo( String targetShimeiNo ) {
        this.targetShimeiNo = targetShimeiNo;
    }

    public String getLogonShimeiNo() {
        return logonShimeiNo;
    }

    public void setLogonShimeiNo( String logonShimeiNo ) {
        this.logonShimeiNo = logonShimeiNo;
    }

    public String getSousa() {
		return sousa;
	}

	public void setSousa(String sousa) {
		this.sousa = sousa;
	}
    
   //upd B-CT-0566 a-funew 20100819 操作ログ整備 start
    public String addCondition ( String renketsu, String label, String value, boolean isLast){
    	renketsu = renketsu + label + "：";
    	//最後でなければカンマを足す
    	if (!isLast){	    	
	    	if(value != null){
	    		renketsu = renketsu + value + ",";  
			} else {
				renketsu = renketsu +" ,";
			}
    	} else {
    		if(value != null){
    			renketsu = renketsu + value; 
			} else {
				renketsu = renketsu + " ";
			}
    	}  	
    	return renketsu;
    }
    
    public String addConditionList ( String renketsu, String label, String[] value, boolean isLast){
    	renketsu = renketsu + label + "：";
    	//最後でなければカンマを足す
    	if (!isLast){	    	
	    	if(value != null){
	    		for(int i=0;i<value.length;i++){
	    			if("".equals(value[i])){
	    				break;
	    			} else {
	    				renketsu = renketsu + value[i] + " ";
	    			}
	    		}	    		
	    		renketsu = renketsu + ",";  
			} else {
				renketsu = renketsu +" ,";
			}
    	} else {
    		if(value != null){
    			for(int i=0;i<value.length;i++){
    				if("".equals(value[i])){
    					break;
    				} else {
    					renketsu = renketsu + value[i] + " ";
    				}
	    		}
			} else {
				renketsu = renketsu + " ";
			}
    	}  	
    	return renketsu;
    }
    //upd B-CT-0566 a-funew 20100819 操作ログ整備 end
    
    
}
