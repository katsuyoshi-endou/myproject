/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.util.common;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.lowagie.text.BadElementException;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Table;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;

/**
 * 文字列に関するユーティリティ
 */
public class PZZ010_CharacterUtil {
	
	/** 整数値であることをチェックする正規表現 */
	private static final String REGEX_INTEGER_NUMBER = "^[-.0-9]+$";

	/**
	 * シングルクォーテーション二重化<br>
	 * シングルクォーテーションが入力された場合、SQL発行時に不具合を発生させないために シングルクォーテーションを二重化する。
	 * @param str 入力値
	 * @return シングルクォーテーション二重化を行った文字列
	 * @deprecated 説明されている動作は行いません、呼び出し箇所がなくなった時点で削除
	 */
	public static String changeQuotation( final String str ) {
		String retStr;
		/* nullチェック */
		if (str == null) {
			retStr = "";
		} else {
			retStr = str;
		}
		return retStr;
	}
	
	/**
	 * シングルクォーテーション二重化<br>
	 * シングルクォーテーションが入力された場合、SQL発行時に不具合を発生させないために シングルクォーテーションを二重化する。
	 * @param col 入力値を格納した配列
	 * @return シングルクォーテーション二重化を行った配列
	 * @deprecated 説明されている動作は行いません、呼び出し箇所がなくなった時点で削除
	 */
	public static String[] changeQuotation( final String[] col ) {
		for (int i = 0; i < col.length; i++) {
			/* nullチェック */
			if (col[i] == null) {
				col[i] = "";
			}
		}
		return col;
	}
	
	/**
	 * 引数として渡された文字列をリテラル文字列として使用可能なように以下の変換を行います。
	 * <ul>
	 * <li>改行コードを \n、\r に変換</li>
	 * <li>シングルクォーテーションを \' に変換</li>
	 * </ul>
	 * 引数が null だった場合、空文字列を返します。
	 * @return リテラル文字列として使用可能な文字列
	 */
	public static String changeToLiteralString( final String str ) {
		if (str == null) {
			return "";
		}
		return str.replaceAll( "\r", "\\\\r" ).replaceAll( "\n", "\\\\n" ).replaceAll( "'", "\\\\'" );
	}
	
	/**
	 * 文字列内の全角カナを半角カナに変換する。<br>
	 * @param fullString 全角カナの混入している文字列
	 * @return 半角カナに変換後の文字列
	 */
	public static String convertHalfSizeKana( final String fullString ) {
		final String halfKana = " ,.:;?!ﾞﾟ`^_/|''+-=\\$%#@0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜｦﾝｧｨｩｪｫｬｭｮｯｰｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾊﾋﾌﾍﾎｳﾊﾋﾌﾍﾎ";
		final String fullKana = "　，．：；？！゛゜｀＾＿／｜‘’＋－＝￥＄％＃＠０１２３４５６７８９ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚアイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲンァィゥェォャュョッーガギグゲゴザジズゼゾダヂヅデドバビブベボヴパピプペポ";
		String halfString = "";
		char c;
		int n;
		
		if (fullString == null) {
			return null;
		}
		
		for (int i = 0; i < fullString.length(); i++) {
			c = fullString.charAt( i );
			n = fullKana.indexOf( c );
			if (n >= 0) {
				c = halfKana.charAt( n );
			}
			
			halfString += c;
			
			// 半濁点の時(パ～)
			if (n >= fullKana.indexOf( 'パ' )) {
				halfString += "ﾟ";
				// 濁点の時(ガ～ヴ)
			} else if (n >= fullKana.indexOf( 'ガ' )) {
				halfString += "ﾞ";
			}
		}
		return halfString;
	}
	
	/**
	 * PDFドキュメントのテーブルを作成する。<br>
	 * 以下はデフォルトで設定される。<br>
	 * <br>
	 * セル内のドキュメントの縦方向配置位置(setDefaultVerticalAlignment)：真中<br>
	 * セルの枠線とドキュメントの間の空間(setPadding)：2<br>
	 * <br>
	 * また、列の数はrowWidthsの要素の数だけ作成される。
	 * @param tableWidth テーブルの幅（ドキュメントの幅に対する割合をパーセントで指定）
	 * @param rowWidths 列の幅格納配列（テーブルの幅に対する割合をパーセントで指定）
	 * @param tableAlignment テーブルのデフォルト配置位置（Tableクラスの定数で指定 例：Table.ALIGN_CENTER）
	 * @param cellAlignment セル内のドキュメントの横方向デフォルト配置位置（Tableクラスの定数で指定 例：Table.ALIGN_CENTER）
	 * @return 作成したテーブル
	 * @throws BadElementException
	 * @throws DocumentException
	 * @deprecated itext 1.3を使った場合、Tableを使うとセル上部に余白が発生します。極力PdfPTableを使用してください。
	 */
	public static Table createNewTable( final int tableWidth, final int[] rowWidths, final int tableAlignment, final int cellAlignment ) throws BadElementException, DocumentException {
		final Table table = new Table( rowWidths.length );
		
		table.setDefaultVerticalAlignment( Table.ALIGN_MIDDLE );
		table.setPadding( 2 );
		table.setWidth( tableWidth );
		table.setWidths( rowWidths );
		table.setAlignment( tableAlignment );
		table.setDefaultHorizontalAlignment( cellAlignment );
		
		return table;
	}

	/**
	 * 数値のカンマ編集 入力値がnullの場合は、入力値を返す。
	 * 
	 * @param val 入力値(double型)
	 * @return カンマ編集後の数値(文字列型)
	 */
	public static String editComma( final double val ) {
		return PZZ010_CharacterUtil.editComma( Double.toString( val ) );
	}
	
	/**
	 * 数値のカンマ編集 入力値がnullの場合は、入力値を返す。
	 * 
	 * @param val 入力値(int型)
	 * @return カンマ編集後の数値(文字列型)
	 */
	public static String editComma( final int val ) {
		return PZZ010_CharacterUtil.editComma( Integer.toString( val ) );
	}
	
	/**
	 * 数値のカンマ編集 入力値がnull、または数値以外の場合は、入力値を返す。
	 * 
	 * @param val 入力値(文字列型)
	 * @return カンマ編集後の数値(文字列型)
	 */
	public static String editComma( final String val ) {
		// 小数点9桁まで
		final DecimalFormat df = new DecimalFormat( "###,###.###########" );
		String ret = null;
		// nullチェック
		if (val == null) {
			return val;
		}
		// 数値チェック
		try {
			ret = df.format( new BigDecimal( val ) );
		} catch (final NumberFormatException e) {
			ret = val;
		}
		return ret;
	}
	
	/**
	 * 金額の\表示編集 入力値がnullの場合は、入力値を返す。
	 * 
	 * @param val 入力値(String型)
	 * @return \表示編集後の数値(文字列型)
	 */
	public static String editYen( final String val ) {
		if (val == null || val.equals( "" )) {
			return val;
		}
		
		return "\\" + val;
	}
	
	/**
	 * リンクボタン用のスタイルシートを返す。 <BR>
	 * 例：<input type="button" style="<%= PZZ010_CharacterUtil.getButtonStyle( "P001_icon.gif", 82 ) %>">
	 * @param img バックグラウンドイメージ
	 * @param width ボタン（イメージ）の長さ
	 * @return スタイル定義
	 */
	public static String getButtonStyle( final String img, final int width ) {
		return new String( "background:url(/" + AppDef.CTX_ROOT + "/view/parts/img/button/" + img + "); WIDTH:" + width + "; HEIGHT:20; border-style:none; cursor:hand;" ); // CHG#P-PJT01-003-001
	}
	
	/**
	 * GetDayメソッド システム日付を取得する
	 * 
	 * @return String システム日付 YYYYMMDD
	 */
	public static String GetDay() {
		final DateFormat df = new SimpleDateFormat( "yyyyMMdd" );
		return df.format( new Date( Calendar.getInstance().getTimeInMillis() ) );
	}
	
	/**
	 * 現在の日年月日時刻の文字列を返す
	 * 
	 * @return 日付と時刻の文字列 (yyyyMMddHHmmss)
	 */
	public static String getDayTime() {
		final DateFormat df = new SimpleDateFormat( "yyyyMMddHHmmss" );
		return df.format( new Date( Calendar.getInstance().getTimeInMillis() ) );
	}
	
	/**
	 * 帳票のフッターに出力する印刷日を取得する。<br>
	 * 
	 * @return 現在の日付を[日（数字）-月（英字３文字）-年（数字）]の形式で返す。 例）2000年1月1日の場合
	 *         戻り値：01-Jan-2000
	 */
	public static String getPrintDate() {
		final DateFormat df = new SimpleDateFormat( "dd-MMM-yyyy", new DateFormatSymbols( Locale.US ) );
		return df.format( new Date( Calendar.getInstance().getTimeInMillis() ) );
	}
	
	/**
	 * GetTimeメソッド システム時刻を取得する
	 * 
	 * @return String システム時刻 HHMMSS
	 */
	public static String GetTime() {
		final DateFormat df = new SimpleDateFormat( "HHmmss" );
		return df.format( new Date( Calendar.getInstance().getTimeInMillis() ) );
	}
	
	/**
	 * 文字列が整数値かどうかを返す
	 * 
	 * @param str 対象文字列
	 * @return 整数値ならtrue、それ以外の場合false
	 */
	public static boolean isIntegerNumber( final String str ) {
		if (str == null) {
			return false;
		}
		final Pattern p = Pattern.compile( PZZ010_CharacterUtil.REGEX_INTEGER_NUMBER );
		return p.matcher( str ).find();
	}
	
	/**
	 * 引数がnullの場合、""に変換し返す。 null以外の場合は、引数そのまま返す。
	 * 
	 * @param str
	 * @return
	 */
	public static String normalizedStr( final String str ) {
		return str != null ? str : "";
	}
	
	/**
	 * 引数がnullの場合、""に変換し返す。 null以外の場合は、引数そのまま返す。
	 * 
	 * @param strArray
	 * @return
	 */
	public static String[] normalizedStr( final String[] strArray ) {
		if (strArray == null || strArray.length == 0) {
			return strArray;
		}
		for (int i = 0; i < strArray.length; i++) {
			if (strArray[i] == null) {
				strArray[i] = "";
			}
		}
		
		return strArray;
	}
	
	/**
	 * HTML属性値文字列のサニタイジング処理を実行する
	 * 
	 * @param str サニタイズする文字列
	 * @return サニタイズ後の文字列
	 */
	public static String sanitizeStrAttribute( final String str ) {
		String dat = str;
		if (dat == null) {
			return "";
		}
		// 既にサニタイズされた文字列があれば元に戻す
		dat = dat.replaceAll( "&quot;", "\"" ).replaceAll( "&#39;", "'" );
		// サニタイズ
		dat = PZZ010_CharacterUtil.sanitizeStrData( dat ).replaceAll( "\"", "&quot;" ).replaceAll( "'", "&#39;" );
		return dat;
	}
	
	/**
	 * 画面表示文字列のサニタイジング処理を実行する
	 * 
	 * @param str サニタイズする文字列
	 * @return サニタイズ後の文字列
	 */
	public static String sanitizeStrData( final String str ) {
		String dat = str;
		if (dat == null) {
			return "";
		}
		// 既にサニタイズされた文字列があれば元に戻す
		dat = dat.replaceAll( "&amp;", "&" ).replaceAll( "&lt;", "<" ).replaceAll( "&gt;", ">" );
		// 既にサニタイズされた文字列があれば元に戻す
		dat = dat.replaceAll( "&quot;", "\"" ).replaceAll( "&#39;", "'" );
		dat = dat.replaceAll( "&#037;", "%" );
		dat = dat.replaceAll( "&#059;", ";" );
		dat = dat.replaceAll( "&#040;", "(" );
		dat = dat.replaceAll( "&#041;", ")" );
		dat = dat.replaceAll( "&#043;", "+" );
		dat = dat.replaceAll( ";", "&#059;" );
		// "&" のエスケープ
		dat = dat.replaceAll( "&", "&amp;" );
		// ";"のサニタイズ文字の復元
		dat = dat.replaceAll( "&amp;#059;", "&#059;" );
		
		// 許可タグを退避
		String tagStart = "&S";
		String tagEnd = "&E";
		Pattern pattern = Pattern.compile( "<span(\\s+style\\s*=\\s*\"[^\"<>]*\")?\\s*>" );
		while (true) {
			Matcher matcher = pattern.matcher( dat );
			if (matcher.find()) {
				String matchStr = matcher.group();
				String replaceStr = matchStr.replace( "<", tagStart ).replace( ">", tagEnd ).replaceAll( "&#059;", "&C" ).replaceAll( "\"", "&Q" );
				dat = dat.replace( matchStr, replaceStr );
			} else {
				break;
			}
		}
		
		dat = dat.replaceAll( "\"", "&quot;" );
		dat = dat.replaceAll( "%", "&#037;" );
		dat = dat.replaceAll( "'", "&#39;" );
		dat = dat.replaceAll( "\\(", "&#040;" );
		dat = dat.replaceAll( "\\)", "&#041;" );
		dat = dat.replaceAll( "\\+", "&#043;" );
		dat = dat.replaceAll( "</span>", tagStart + "/span" + tagEnd );
		dat = dat.replaceAll( "<br>", tagStart + "br" + tagEnd );
		
		// "<", ">" のエスケープ
		dat = dat.replaceAll( "<", "&lt;" ).replaceAll( ">", "&gt;" );
		// 許可タグの回復
		dat = dat.replaceAll( tagStart, "<" ).replaceAll( tagEnd, ">" ).replace( "&C", ";" ).replace( "&Q", "\"" );
		
		return convertCharCode( dat );
	}
	
	public static String sanitizeStrData( final int i ) {
		return sanitizeStrData( String.valueOf( i ) );
	}
	
	public static String sanitizeStrData( final boolean b ) {
		return String.valueOf( b );
	}
	
	/**
	 * selectタグのoptionを文字列する場合のサニタイジング処理を実行する
	 * 
	 * @param str サニタイズする文字列
	 * @return サニタイズ後の文字列
	 */
	public static String sanitizeOptionStr( final String str ) {
		String dat = str;
		if (dat == null) {
			return "";
		}
		// 既にサニタイズされた文字列があれば元に戻す
		dat = dat.replaceAll( "\\\\'", "'" );
		// サニタイズ
		dat = dat.replaceAll( "'", "\\\\'" );
		
		return convertCharCode( dat );
	}
	
	/**
	 * 文字コードの変換を行う。
	 * 
	 * @param strVal 文字コードの変換を行う文字列
	 * @exception UnsupportedEncodingException サポートされていない文字コードで変換を行おうとした時に発生する例外
	 */
	public static String strEncode( final String strVal ) throws UnsupportedEncodingException {
		if (strVal == null) {
			return null;
		} else {
			return new String( strVal.getBytes( "ISO-8859-1" ), "Windows-31J" );
		}
	}
	
	/**
	 * 文字列の最初の1文字目を除いた文字列を返す。<BR>
	 * null、空白文字の場合、空白文字を返す。
	 * 
	 * @param str 処理対象文字列
	 * @return 処理対象文字列の2文字目以降。
	 */
	public static String cutFirstChar( final String str ) {
		if (str != null && str.length() > 0) {
			return str.substring( 1 );
		} else {
			return "";
		}
	}
	
	/**
	 * 引数がNULLor空文字の場合、"&nbsp"に変換し返す。 それ以外の場合は、引数そのまま返す。
	 * 
	 * @param str 処理対象文字列
	 * @return NULLor空文字の場合、"&nbsp"に変換し返す
	 */
	public static String changeHTMLSpace( final String str ) {
		if (str == null || str.equals( "" )) {
			return "&nbsp";
		}
		return str.replaceAll( " ", "&nbsp" );
	}
	
	/**
	 * 引数がNULLor空文字の場合、"&lt;BR&gt;"に変換し返す。 それ以外の場合は、引数そのまま返す。
	 * 
	 * @param str 処理対象文字列
	 * @return NULLor空文字の場合、"<BR>
	 *         "に変換し返す
	 */
	public static String changeHTMLBr( final String str ) {
		if (str == null || str.equals( "" )) {
			return "<BR>";
		}
		return str.replaceAll( " ", "&nbsp" );
	}
	
	/**
	 * 引数の文字列が「\r\nか\n(改行文字)」を含んでいる場合、<BR>
	 * に変換して返す
	 * 
	 * @param str 処理対象文字列
	 * @return \r\nを含んでいる場合<BR>
	 */
	public static String changeHTMLBr2( final String str ) {
		if (str == null || str.equals( "" )) {
			return "<BR>";
		}
		if (str.indexOf("\r\n") != -1) {
			// \r\nを<BR>に変換して返す
			return str.replaceAll("\r\n","<BR>");
		} else if(str.indexOf("\n") != -1) {
			// \nを<BR>に変換して返す
			return str.replaceAll("\n","<BR>");
		}
		return str.replaceAll( " ","&nbsp" );
	}
	
	/**
	 * 文字列が正常に表示されるようにエスケープする
	 * 
	 * @param s
	 * @return
	 */
	public static synchronized String escapeString( final String s ) {
		if (s != null) {
			final StringBuffer sb = new StringBuffer( s.length() );
			char c;
			for (int i = 0; i < s.length(); i++) {
				c = s.charAt( i );
				switch (c) {
				case 0x00a5: // YEN SIGN ->
					c = 0x005c; // REVERSE SOLIDUS
					break;
				case 0x301c: // WAVE DASH ->
					c = 0xff5e; // FULLWIDTH TILDE
					break;
				case 0x2016: // DOUBLE VERTICAL LINE ->
					c = 0x2225; // PARALLEL TO
					break;
				case 0x2212: // MINUS SIGN ->
					c = 0xff0d; // FULLWIDTH HYPHEN-MINUS
					break;
				case 0x00a2: // CENT SIGN ->
					c = 0xffe0; // FULLWIDTH CENT SIGN
					break;
				case 0x00a3: // POUND SIGN ->
					c = 0xffe1; // FULLWIDTH POUND SIGN
					break;
				case 0x00ac: // NOT SIGN ->
					c = 0xffe2; // FULLWIDTH NOT SIGN
					break;
				}
				sb.append( c );
			}
			return sb.toString();
		} else {
			return "";
		}
	}
	
	/**
	 * 引数がNULLor空文字の場合、trueを返す。
	 * 
	 * @param str ﾁｪｯｸ対象文字列
	 * @return 対象の文字列がNULLor空文字かの判定(true:NULLor空文字、false：NULLでも空文字でもない)
	 */
	public static boolean checkEmptyString( final String str ) {
		if (str == null || "".equals( str )) {
			return true;
		}
		return false;
	}

	/**
	 * 引数がNULLor空文字の場合、trueを返す。
	 * 
	 * @param str ﾁｪｯｸ対象文字列
	 * @return 対象の文字列がNULLor空文字かの判定(true:NULLor空文字、false：NULLでも空文字でもない)
	 */
	public static boolean isEmpty( final String str ) {
		if (str == null || "".equals( str )) {
			return true;
		}
		return false;
	}
	
	/**
	 * 引数に含まれる改行コードをHTMLの改行タグに変換する
	 * 
	 * @param str 処理対象文字列
	 * @return 改行コード(\r\n、\n)を改行タグ(<br>)に変換して返す
	 */
	public static String changeHTMLbr( final String str ) {
		if (str == null) {
			return "";
		}
		return str.replaceAll( "\r", "" ).replaceAll( "\n", "<br>" );
	}

	/**
	 * GetDayメソッド システム日付を取得する
	 * 
	 * @return String システム日付 YYYY/MM/DD
	 */
	public static String GetDayFormat() {
		final DateFormat df = new SimpleDateFormat( "yyyy/MM/dd" );
		return df.format( new Date( Calendar.getInstance().getTimeInMillis() ) );
	}
	
	/**
	 * GetTimeメソッド システム時刻を取得する
	 * 
	 * @return String システム時刻 HH:MM:SS
	 */
	public static String GetTimeFormat() {
		final DateFormat df = new SimpleDateFormat( "HH:mm:ss" );
		return df.format( new Date( Calendar.getInstance().getTimeInMillis() ) );
	}
	
	@SuppressWarnings("unchecked")
	public static <T extends Number> T convertStrToNum( String str, Class<T> clazz ) throws CareerRuntimeException {
		if (isEmpty( str ) || clazz == null) {
			return null;
		}
		try {
			if (Integer.class.equals( clazz )) {
				return (T)new Integer( str );
			} else if (Double.class.equals( clazz )) {
				return (T)new Double( str );
			} else if (Long.class.equals( clazz )) {
				return (T)new Long( str );
			} else if (Float.class.equals( clazz )) {
				return (T)new Float( str );
			} else if (Byte.class.equals( clazz )) {
				return (T)new Byte( str );
			}
		} catch (Exception ex) {
			throw new CareerRuntimeException( ex );
		}
		
		return null;
	}
	
	/**
	 * 日付変換(YYYY/MM/DD → (和暦YY)YYYY/MM/DD)を行う
	 * 
	 * @param String 変換前日付
	 * @return String 変換後日付
	 * @throws NumberFormatException
	 * @throws ParseException
	 */
	public static String ChangeWaYmd( final String strYmd ) throws NumberFormatException, ParseException {
		
		ArrayList<String> WaRekiList = new ArrayList<String>();
		ArrayList<String> WaNenList = new ArrayList<String>();
		String WaString = "";
		
		// 年号の略号と開始日を設定
		WaRekiList.add( "H" );
		WaNenList.add( "1989/01/08" );
		
		if (strYmd == null || strYmd.length() < 10) {
			return "";
		} else {
			Date dateYmd = toDate( strYmd );
			SimpleDateFormat dateYmdF = new SimpleDateFormat( "yyyy" );
			for (int intJ = 0; intJ < WaNenList.size(); intJ++) {
				if (dateYmd.after( toDate( WaNenList.get( intJ ) ) )) {
					// 和暦の追加
					// 年度の計算
					WaString = "(" + WaRekiList.get( intJ ) + String.valueOf( Integer.parseInt( dateYmdF.format( dateYmd ) ) - Integer.parseInt( WaNenList.get( intJ ).substring( 0, 4 ) ) + 1 ) + ")";
				}
			}
			return WaString + strYmd;
		}
	}

	/**
	 * 日付文字列"yyyy/MM/dd"をjava.util.Date型へ変換します。
	 * 
	 * @param str 変換対象の文字列
	 * @return 変換後のjava.util.Dateオブジェクト
	 * @throws ParseException 日付文字列が"yyyy/MM/dd"以外の場合
	 */
	public static Date toDate( String str ) throws ParseException {
		Date date = DateFormat.getDateInstance().parse( str );
		return date;
	}
	
	public static String convertCharCode( String str ) {
		
		if (str != null) {
			
			StringBuffer sb = new StringBuffer( str.length() );
			char c;
			for (int i = 0; i < str.length(); i++) {
				c = str.charAt( i );
				switch (c) {
				case 0x00a5: // YEN SIGN ->
					c = 0x005c; // REVERSE SOLIDUS
					break;
				case 0x005c: // REVERSE SOLIDUS ->
					c = 0x005c; // REVERSE SOLIDUS
					break;
				case 0x301c: // WAVE DASH ->
					c = 0xff5e; // FULLWIDTH TILDE
					break;
				case 0x2016: // DOUBLE VERTICAL LINE ->
					c = 0x2225; // PARALLEL TO
					break;
				case 0x2212: // MINUS SIGN ->
					c = 0xff0d; // FULLWIDTH HYPHEN-MINUS
					break;
				case 0x00a2: // CENT SIGN ->
					c = 0xffe0; // FULLWIDTH CENT SIGN
					break;
				case 0x00a3: // POUND SIGN ->
					c = 0xffe1; // FULLWIDTH POUND SIGN
					break;
				case 0x00ac: // NOT SIGN ->
					c = 0xffe2; // FULLWIDTH NOT SIGN
					break;
				}
				sb.append( c );
			}
			return sb.toString();
		} else {
			return "";
		}
	}
	
	/**
	 * 文字列配列に指定の要素が含まれているか。
	 */
	public static boolean contains( String[] list, String value ) {
		return list != null ? (new ArrayList<String>( Arrays.asList( list ) )).contains( value ) : false;
	}

	/**
	 * 日時変換(YYYYMMDD,HHMMSS → YYYY/MM/DD HH:MM:SS)を行う
	 * 
	 * @param strYmd
	 * @param strHms
	 * @return
	 */
	public static String ChangeYmdHms( final String strYmd, final String strHms ) {
		
		if (strYmd == null || strYmd.length() < 8) {
			return " ";
		} else if (strHms == null || strHms.length() < 6) {
			return " ";
		} else {
			return strYmd.substring(0, 4) + "/" + strYmd.substring(4, 6) + "/" + strYmd.substring(6, 8) + " " +
				   strHms.substring(0, 2) + ":" + strHms.substring(2, 4) + ":" + strHms.substring(4, 6);
		}
	}
	
	/**
	 * double を 文字列に変換する
	 * double 12.500000     → String 12.5
	 * double 12.56 int 1   → String 12.6
	 * double 12.5412 int 3 → String 12.541
	 * double 12.00000      → String 12
	 */
	public static String formatDouble( Double value, int fLen ) throws CareerRuntimeException {
		try {
			if (value == null) {
				return "";
			}
			
			String ret = formatDoubleCore( value.doubleValue(), fLen );
			
			int nLen = ret.length();
			int i = 0;
			
			int nIndex = ret.indexOf( "." );
			if (nIndex == -1) {
				return ret;
			}
			
			for (i = nLen - 1; i >= 0; i--) {
				char c = ret.charAt( i );
				
				if (c == '.') {
					i = i - 1;
					break;
				} else if (c != '0') {
					break;
				}
			}
			
			return ret.substring( 0, i + 1 );
			
		} catch (Exception e) {
			throw new CareerRuntimeException( e );
		}
	}
	
	/**
	 * 四捨五入
	 * 
	 * @param value 変換元の数
	 * @param fLen 小数部桁数
	 * @return 変換後の数
	 */
	public static String formatDoubleCore( double value, int fLen ) {
		
		// double数のLong部分の表示
		String strLong;
		// double数の小数部分の表示
		String strSM;
		// double数の符号表示
		String strPrix = "";
		
		if (value < 0) {
			strPrix = "-";
			value = -1 * value;
		}
		
		Double d = new Double( value );
		Long l = new Long( d.longValue() );
		strLong = l.toString();
		// 小数の取得
		double sm = d.doubleValue() - l.doubleValue();
		
		int count = 1;
		
		if (sm == 0) {
			
			if (fLen == 0) {
				return strPrix + strLong;
			}
			
			strSM = String.valueOf( sm );
			for (int j = 0; j < fLen - 1; j++) {
				strSM = strSM + "0";
			}
			
			return strPrix + strLong + strSM.substring( 1 );
		}
		
		if (fLen == 0) {
			if (sm >= 0.5) {
				l = new Long( l.longValue() + 1 );
				strLong = l.toString();
			}
			return strPrix + strLong;
		}
		
		for (int i = 0; i < fLen; i++) {
			count = count * 10;
		}
		sm = Math.round( sm * count );
		sm = sm / count;
		if (sm >= 1) {
			sm = sm - 1;
			l = new Long( l.longValue() + 1 );
			strLong = l.toString();
		}
		strSM = String.valueOf( sm );
		
		String strEnd = strSM.substring( strSM.indexOf( "." ) + 1 );
		int length = strEnd.length();
		
		for (int j = 0; j < fLen - length; j++) {
			strSM = strSM + "0";
		}
		return strPrix + strLong + strSM.substring( 1 );
	}

}
