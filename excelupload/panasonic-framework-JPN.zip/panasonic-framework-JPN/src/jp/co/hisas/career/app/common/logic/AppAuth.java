package jp.co.hisas.career.app.common.logic;

import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class AppAuth {
	
	public static String authByTray( Tray tray ) throws Exception {
		String reqId = SU.trim( AU.getRequestValue( tray.request, "guid" ) );
		String reqPw = AU.getRequestValue( tray.request, "password" );
		if (authCore( reqPw )) {
			return reqId;
		}
		else {
			throw new CareerRuntimeException( "管理者パスワードが一致しません。" );
		}
	}
	
	private static boolean authCore( String password ) throws Exception {
		// From Property for admin only
		String pw = AU.getCareerProperty( "ADMIN_PASSWORD" );
		return SU.equals( pw, password );
	}
	
}
