package jp.co.hisas.career.framework.event;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class DynamicSqlSelectEvRslt extends AbstractEventResult {

	public List<Map<String, String>> dataList = null;

}