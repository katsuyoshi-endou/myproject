/*
 * All Rights Reserved. Copyright (C) 2008, 2009, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.framework.taglib;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import jp.co.hisas.career.framework.SimpleXmlBuilder;
import jp.co.hisas.career.framework.WebUtil;
//import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;

/**
 * JSPに画像付きボタンを表示するためのカスタムタグ。
 * actionId属性で指定した値が、コマンドクラスのメソッド名に対応する。
 * @author kats-watanabe
 */
public class ButtonTag extends SimpleTagSupport {

//    private static final int DEFAULT_IMAGE_SIZE = 82;

    private static final Map<String, Integer> imageSizeMap = new HashMap<String, Integer>();

    private String actionId;

    private String imageName;

    private String onclick;

    private String target = "_self";

    private String style;

    private String label;

    private String message;


    /**
     * @return label
     */
    public String getLabel() {
        return label;
    }


    /**
     * @param label 設定する label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * target を取得します。
     * @return target
     */
    public String getTarget() {
        return target;
    }

    /**
     * target を設定します。
     * @param target target に設定する値。
     */
    public void setTarget( String target ) {
        this.target = target;
    }

    /**
     * onclick を取得します。
     * @return onclick
     */
    public String getOnclick() {
        return onclick;
    }

    /**
     * onclick を設定します。
     * @param onclick onclick に設定する値。
     */
    public void setOnclick( String onclick ) {
        this.onclick = onclick;
    }

    /**
     * actionId を取得します。
     * @return actionId
     */
    public String getActionId() {
        return actionId;
    }

    /**
     * actionId を設定します。
     * @param actionId actionId に設定する値。
     */
    public void setActionId( String actionId ) {
        this.actionId = actionId;
    }

    /**
     * imageName を取得します。
     * @return imageName
     */
    public String getImageName() {
        return imageName;
    }

    /**
     * imageName を設定します。
     * @param imageName imageName に設定する値。
     */
    public void setImageName( String imageName ) {
        this.imageName = imageName;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void doTag() throws JspException, IOException {
//DEL torigoe START
//        Integer imageSizeInMap = imageSizeMap.get( imageName );
//        int imageSize = ( imageSizeInMap == null ) ? DEFAULT_IMAGE_SIZE : imageSizeInMap.intValue();
//        String style = PZZ010_CharacterUtil.getButtonStyle( imageName, imageSize );
//        if ( target == null ) {
//            target = "_self";
//        }
//DEL torigoe END
        SimpleXmlBuilder html = new SimpleXmlBuilder();
//        html.startElement( "input" );
//        html.writeAttribute( "type", "button" );
//        html.writeAttribute( "name", actionId );
//        html.formatAttribute( "onclick", TransitTag.ACTION_JSCRIPT, actionId, target,
//                WebUtil.normalizeJavascript( onclick ) );
//        html.writeAttribute( "value", "" );
//        html.writeAttribute( "style", style );
//        html.writeAttribute( "disabled", "disabled" );
        html.startElement( "button" );
        html.writeAttribute( "name", actionId );
        html.formatAttribute( "onclick", TransitTag.ACTION_JSCRIPT, actionId, target,
                WebUtil.normalizeJavascript( onclick ) );
        html.writeAttribute( "style", style );
        html.writeAttribute( "type", "button" );
        html.writeAttribute( "message", message );
        //
        html.finishStartTag();
        //
        html.writeText(PZZ010_CharacterUtil.convertCharCode(label));
        //html.finishEmptyElementTag();
        //
        html.writeElementEndTag("button");
        //
        this.getJspContext().getOut().println( html.toString() );
    }

    static {
        // ボタン画像のサイズが標準の 82 ピクセル以外の場合、ここで登録しておく。
        imageSizeMap.put( "shori_taisho.gif", Integer.valueOf( 42 ) );
        imageSizeMap.put( "shori_taishogai.gif", Integer.valueOf( 42 ) );
        imageSizeMap.put( "shori_honnintemp.gif", Integer.valueOf( 42 ) );
        imageSizeMap.put( "shori_hyokashatemp.gif", Integer.valueOf( 42 ) );
        imageSizeMap.put( "back2.gif", Integer.valueOf( 74 ) );
        // imageSizeMap.put( "edit.gif", Integer.valueOf( 74 ) );
        imageSizeMap.put( "extend.gif", Integer.valueOf( 92 ) );
        imageSizeMap.put( "narrow.gif", Integer.valueOf( 92 ) );
        imageSizeMap.put( "tempback.gif", Integer.valueOf( 112 ) );
        imageSizeMap.put( "knowledgesansho.gif", Integer.valueOf( 112 ) );
        imageSizeMap.put( "change_hyokasha.gif", Integer.valueOf( 112 ) );
        imageSizeMap.put( "Temp_Save_Del.gif", Integer.valueOf( 112 ) );
        imageSizeMap.put( "P060_icon.gif", Integer.valueOf( 112 ) );
        imageSizeMap.put( "P74_icon.gif", Integer.valueOf( 112 ) );
        imageSizeMap.put( "T004_icon.gif", Integer.valueOf( 112 ) );
        imageSizeMap.put( "VED010_icon.gif", Integer.valueOf( 112 ) );
        imageSizeMap.put( "output_csv.gif", Integer.valueOf( 74 ) );
        imageSizeMap.put( "deleteEditData.gif", Integer.valueOf( 112 ) );
        imageSizeMap.put( "outputEditData.gif", Integer.valueOf( 112 ) );
        imageSizeMap.put( "hyoji.gif", Integer.valueOf( 42 ) );
        imageSizeMap.put( "search.gif", Integer.valueOf( 74 ) );
        imageSizeMap.put( "P048_icon.gif", Integer.valueOf( 82 ) );
        imageSizeMap.put( "edit_small.gif", Integer.valueOf( 33 ) );
        imageSizeMap.put( "setting.gif", Integer.valueOf( 44 ) );
        imageSizeMap.put( "clear.gif", Integer.valueOf( 44 ) );
        imageSizeMap.put( "shikakuIchiran.gif", Integer.valueOf( 128 ) );

    }


    /**
     * @return style
     */
    public String getStyle() {
        return style;
    }


    /**
     * @param style 設定する style
     */
    public void setStyle(String style) {
        this.style = style;
    }


	/**
	 * messageを取得します。
	 * @return message
	 */
	public String getMessage() {
	    return message;
	}


	/**
	 * messageを設定します。
	 * @param message message
	 */
	public void setMessage(String message) {
	    this.message = message;
	}

}
