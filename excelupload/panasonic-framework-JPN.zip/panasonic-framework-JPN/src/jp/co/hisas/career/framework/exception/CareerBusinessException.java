package jp.co.hisas.career.framework.exception;

public class CareerBusinessException extends CareerException {
	
	public static final String INVALID_SESSION = "INVALID_SESSION";
	
	private String pattern;
	
	public CareerBusinessException(String pattern) {
		super( pattern );
		this.setPattern( pattern );
	}
	
	public String getPattern() {
		return pattern;
	}
	
	public void setPattern( String pattern ) {
		this.pattern = pattern;
	}
	
}
