/*
 * All Rights Reserved. Copyright (C) 2004,2009, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.trans;

import jp.co.hisas.career.util.log.bean.OutSousaLogArg;

/**
 * Commandクラスの基底クラス。
 * @author kats-watanabe
 */
public abstract class AbstractCommand {

    /**
     * ログインユーザの氏名NOを保持します。
     * CommonServlet クラスにより、自動的に値が設定されます。
     * この値は、JSPから読み取り専用で参照できます。
     */
    private String loginNo = "";
    
    /**
     * 画面表示条件を保持します。（操作ログ出力用）
     */
    private OutSousaLogArg sousaLogArg = null;
    

    /** イベント発生後に画面に表示するエラーメッセージIDを保持します。 */
    private String errorMessageId = "";

    /**
     * ログインユーザの氏名NOを取得します。
     * CommonServlet クラスにより、自動的に値が設定されます。
     * この値は、JSPから読み取り専用で参照できます。
     * @return ログインユーザの氏名NO
     */
    public final String getLoginNo() {
        return loginNo;
    }

    /**
     * ログインユーザの氏名NOを設定します。
     * このメソッドは CommonServlet クラスが、自動的に値を設定する際に使用します。
     * JSPからの値変更はさせたくないため、publicスコープではなくデフォルトスコープとします。
     * @param loginNo ログインユーザの氏名NO
     */
    final void setLoginNo( String loginNo ) {
        this.loginNo = loginNo;
    }

    /**
     * イベント発生後に画面に表示するエラーメッセージIDを取得します。
     * @return errorMessageId
     */
    public String getErrorMessageId() {
        return errorMessageId;
    }

    /**
     * イベント発生後に画面に表示するエラーメッセージIDを設定します。
     * @param errorMessage イベント発生後に画面に表示するエラーメッセージID
     */
    public void setErrorMessageId( String errorMessageId ) {
        this.errorMessageId = errorMessageId;
    }

    /**
     * ユーザコマンドクラスを生成します。
     * @param thisClass このクラス（を実装するクラス）の型を指定します。
     * @param kinouId このクラスの機能ID。
     * @param jspPath このクラス（を実装するクラス）に対応するJSPのパスを指定します。
     */
    public AbstractCommand( Class<? extends AbstractCommand> thisClass, String kinouId,
            String jspPath ) {
        ViewManager.regist( thisClass, kinouId, jspPath );
        this.kinouId = kinouId;
    }

    /**
     * ユーザコマンドクラスを生成します。
     * @param thisClass このクラス（を実装するクラス）の型を指定します。
     * @param kinouId このクラスの機能ID。
     * @param jspPath このクラス（を実装するクラス）に対応するJSPのパスを指定します。
     * @param frameJspPath jspPathの親フレームのパスを指定します。
     */
    public AbstractCommand( Class<? extends AbstractCommand> thisClass, String kinouId,
            String jspPath, String frameJspPath ) {
        ViewManager.regist( thisClass, kinouId, jspPath, frameJspPath );
    }

    public abstract void init( StateTransitionEvent e );
    
    /**
     * 子画面で使用するコマンドクラスの場合、trueを設定します。
     * この場合、遷移元画面のコマンドクラスを子画面コマンドクラスで上書きしません。
     * 通常の画面コマンドクラスの場合は、false（デフォルト）を設定します。
     */
    public boolean isChildCommand = false;

    private String kinouId = null;

    public String getKinouId() {
        return kinouId;
    }

    public void setKinouId( String kinouId ) {
        this.kinouId = kinouId;
    }

    public OutSousaLogArg getSousaLogArg() {
        if( sousaLogArg == null ){
            sousaLogArg = new OutSousaLogArg();
        }
        if( sousaLogArg.getLogonShimeiNo() == null ){
            sousaLogArg.setLogonShimeiNo( getLoginNo() );
        }
        return sousaLogArg;
    }

    public void setSousaLogArg( OutSousaLogArg sousaLogArg ) {
        this.sousaLogArg = sousaLogArg;
    }

}
