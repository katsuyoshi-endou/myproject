package jp.co.hisas.career.app.common.event;

import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.DualDto;

@SuppressWarnings("serial")
public class DualEvRslt extends AbstractEventResult {
	
	public DualDto dualDto;
	
}
