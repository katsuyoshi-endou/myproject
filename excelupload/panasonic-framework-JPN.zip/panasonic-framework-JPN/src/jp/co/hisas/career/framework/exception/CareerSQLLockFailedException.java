/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.exception;

/**
 * 排他に失敗したことを表す例外クラス
 * @author k-ozawa
 */
public class CareerSQLLockFailedException extends CareerSQLException {

    /**
     * 詳細メッセージに null を使用して、CareerSQLLockFailedException を生成します。
     */
    public CareerSQLLockFailedException() {
    }

    /**
      * 指定された詳細メッセージを使用して、CareerSQLLockFailedException を生成します。
     * @param message 詳細メッセージ。
    */
    public CareerSQLLockFailedException( String message ) {
        super( message );
    }

    /**
     * (cause==null ? null : cause.toString()) の指定された原因および詳細メッセージを使用して
     * 新しい CareerSQLLockFailedException を生成します。
     * 通常、(cause==null ? null : cause.toString()) には、cause のクラスおよび詳細メッセージが含まれます。
     * このコンストラクタは、実行時例外が他のスロー可能オブジェクトのラッパーである場合に有用です。 
     * @param cause 原因。
     */
    public CareerSQLLockFailedException( Throwable cause ) {
        super( cause );
    }

    /**
     * 指定された詳細メッセージおよび原因を使用して、CareerSQLLockFailedException を生成します。
     * @param message 詳細メッセージ。
     * @param cause 原因。
     */
    public CareerSQLLockFailedException( String message, Throwable cause ) {
        super( message, cause );
    }

}
