package jp.co.hisas.career.app.common.servlet;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.common.bean.CsvDownloadBean;
import jp.co.hisas.career.framework.trans.ResponsedServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class CsvDownloadServlet extends ResponsedServlet {
	
	private static final long serialVersionUID = 1L;
	
	public void serviceMain( Tray tray ) throws Exception {
		String dlFileName = "download.csv";
		byte[] dlByteArr = null;
		if (SU.isNotBlank( tray.state )) {
			dlFileName = AU.getRequestAttr( tray.request, "dlFileName" );
			dlByteArr = this.getCsvData( tray );
			AU.httpFileDownload( tray.response, "application/octet-stream", dlByteArr, dlFileName );
		}
	}
	
	private byte[] getCsvData( Tray tray ) throws Exception {
		Map<Integer, List<String>> dlCsvRows = AU.getRequestAttr( tray.request, "dlCsvRows" );
		CsvDownloadBean bean = new CsvDownloadBean( tray.request, tray.session );
		StringBuffer csvData = bean.createCsvData( dlCsvRows );
		return csvData.toString().getBytes();
	}
}
