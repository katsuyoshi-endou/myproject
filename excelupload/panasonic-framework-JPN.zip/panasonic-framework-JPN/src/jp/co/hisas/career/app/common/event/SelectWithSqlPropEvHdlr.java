package jp.co.hisas.career.app.common.event;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.SqlPropDao;
import jp.co.hisas.career.util.log.Log;

public class SelectWithSqlPropEvHdlr extends AbstractEventHandler<SelectWithSqlPropEvArg, SelectWithSqlPropEvRslt> {
	
	private String daoLoginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static SelectWithSqlPropEvRslt exec( SelectWithSqlPropEvArg arg ) throws CareerException {
		SelectWithSqlPropEvHdlr handler = new SelectWithSqlPropEvHdlr();
		return handler.call( arg );
	}
	
	public SelectWithSqlPropEvRslt call( SelectWithSqlPropEvArg arg ) throws CareerException {
		SelectWithSqlPropEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected SelectWithSqlPropEvRslt execute( SelectWithSqlPropEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.daoLoginNo = arg.getLoginNo();
		
		SelectWithSqlPropEvRslt result = new SelectWithSqlPropEvRslt();
		
		if (SU.equals( arg.sharp, "SELECT" )) {
			result.rows = selectWithSqlProp( arg );
		}
		
		return result;
	}
	
	private Map<Integer, List<String>> selectWithSqlProp( SelectWithSqlPropEvArg arg ) {
		
		/* Dynamic SQL */
		String sql = AU.getSqlProperty( arg.sqlPropKey );
		try {
			sql = new String(sql.getBytes("ISO-8859-1"), "Windows-31J");
		} catch (UnsupportedEncodingException e) {
		}
		sql = SU.replaceAll( sql, ":LOGIN_GUID", quoting( arg.getLoginNo() ) );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		
		/* Dao Access */
		SqlPropDao dao = new SqlPropDao( daoLoginNo );
		Map<Integer, List<String>> result = dao.select( DaoUtil.getPstmt( sql, paramList ) );
		
		return result;
	}
	
	private String quoting( String str ) {
		return "'" + str + "'";
	}
}
