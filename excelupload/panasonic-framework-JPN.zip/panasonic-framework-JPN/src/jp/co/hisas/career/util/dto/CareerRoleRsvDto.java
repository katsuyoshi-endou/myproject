/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * CAREER_ROLE_RSV Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CareerRoleRsvDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 人ID
     */
    private String personId;
    /**
     * 会社コード
     */
    private String companyCd;
    /**
     * ロールID
     */
    private String roleId;

    /**
     * 人IDを取得する。
     * @return 人ID
     */
    public String getPersonId() {
        return personId;
    }

    /**
     * 人IDを設定する。
     * @param personId 人ID
     */
    public void setPersonId(String personId) {
        this.personId = personId;
    }

    /**
     * 会社コードを取得する。
     * @return 会社コード
     */
    public String getCompanyCd() {
        return companyCd;
    }

    /**
     * 会社コードを設定する。
     * @param companyCd 会社コード
     */
    public void setCompanyCd(String companyCd) {
        this.companyCd = companyCd;
    }

    /**
     * ロールIDを取得する。
     * @return ロールID
     */
    public String getRoleId() {
        return roleId;
    }

    /**
     * ロールIDを設定する。
     * @param roleId ロールID
     */
    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

}

