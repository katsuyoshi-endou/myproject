/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * 階層コードマスタ Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class HierCodeMasterDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * マスタID
     */
    private String masterId;
    /**
     * マスタコード
     */
    private String masterCode;
    /**
     * マスタ名
     */
    private String masterName;
    /**
     * 親マスタコード
     */
    private String parentMasterCode;
    /**
     * 階層
     */
    private Integer hier;
    /**
     * ソート
     */
    private String lpadSort;

    /**
     * マスタIDを取得する。
     * @return マスタID
     */
    public String getMasterId() {
        return masterId;
    }

    /**
     * マスタIDを設定する。
     * @param masterId マスタID
     */
    public void setMasterId(String masterId) {
        this.masterId = masterId;
    }

    /**
     * マスタコードを取得する。
     * @return マスタコード
     */
    public String getMasterCode() {
        return masterCode;
    }

    /**
     * マスタコードを設定する。
     * @param masterCode マスタコード
     */
    public void setMasterCode(String masterCode) {
        this.masterCode = masterCode;
    }

    /**
     * マスタ名を取得する。
     * @return マスタ名
     */
    public String getMasterName() {
        return masterName;
    }

    /**
     * マスタ名を設定する。
     * @param masterName マスタ名
     */
    public void setMasterName(String masterName) {
        this.masterName = masterName;
    }

    /**
     * 親マスタコードを取得する。
     * @return 親マスタコード
     */
    public String getParentMasterCode() {
        return parentMasterCode;
    }

    /**
     * 親マスタコードを設定する。
     * @param parentMasterCode 親マスタコード
     */
    public void setParentMasterCode(String parentMasterCode) {
        this.parentMasterCode = parentMasterCode;
    }

    /**
     * 階層を取得する。
     * @return 階層
     */
    public Integer getHier() {
        return hier;
    }

    /**
     * 階層を設定する。
     * @param hier 階層
     */
    public void setHier(Integer hier) {
        this.hier = hier;
    }

    /**
     * ソートを取得する。
     * @return ソート
     */
    public String getLpadSort() {
        return lpadSort;
    }

    /**
     * ソートを設定する。
     * @param lpadSort ソート
     */
    public void setLpadSort(String lpadSort) {
        this.lpadSort = lpadSort;
    }

}

