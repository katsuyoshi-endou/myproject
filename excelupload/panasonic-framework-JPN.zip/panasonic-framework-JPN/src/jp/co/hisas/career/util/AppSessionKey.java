package jp.co.hisas.career.util;

public class AppSessionKey {
	
	/* Do NOT difine UserInfo key here. see: UserInfoBean */
	/* public static final String USER_INFO = "userinfo"; */
	
	public static final String ACCOUNT_INFO = "AccountInfo";
	public static final String CAREER_MENU_LIST = "CAREER_MENU_LIST";
	public static final String CAREER_MENU_GRP = "CAREER_MENU_GRP";
	public static final String CAREER_MENU_PTN = "CAREER_MENU_PTN";
	public static final String CAREER_ONE_MENU = "oneMenu";
	public static final String BASE_ROLE_ID = "BASE_ROLE_ID";
	public static final String PLAN_ROLE_ID = "PLAN_ROLE_ID";
	
	public static final String RESULT_MSG_ERROR = "VYY_MESSAGE_ERROR_REQUEST_KEY";
	public static final String RESULT_MSG_WARN = "VYY_MESSAGE_WARNING_EQUEST_KEY";
	public static final String RESULT_MSG_INFO = "VYY_MESSAGE_SUCCESS_REQUEST_KEY";
}
