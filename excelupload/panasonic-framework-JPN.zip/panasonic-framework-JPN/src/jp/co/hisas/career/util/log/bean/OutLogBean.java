/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.util.log.bean;

import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.ejb.OutLogEJB;
import jp.co.hisas.career.ejb.OutLogEJBHome;
import jp.co.hisas.career.framework.EJBHomeFactory;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.util.log.Log;

public class OutLogBean {
	
	/**
	 * デフォルトコンストラクタ
	 */
	private OutLogBean() {
	}
	
	/**
	 * EJBの個人情報操作ログ追加機能を呼び出す。
	 * 
	 * @param kinou_ID 実行機能ID
	 * @param simei_no 実行氏名No
	 * @param taisyou 対象氏名No(対象操作が1ユーザーの場合)
	 * @param jouken 対象操作が複数ユーザの場合、対象となる情報を絞り込むための条件
	 * @param server JNDI名
	 * @throws NamingException
	 * @throws SQLException
	 */
	public static void sousaKojinJohoLog( final String kinou_ID, final String simei_no, final String taisyou, String jouken ) throws NamingException, SQLException, Exception {
		Log.method( "", "IN", "" );
		try {
			// EJBHomeの取得
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final OutLogEJBHome my_home = (OutLogEJBHome)fact.lookup( OutLogEJBHome.class );
			
			/* EJBObjectの取得 */
			final OutLogEJB usersession = my_home.create();
			
			/* 条件カラムの桁数(バイト) */
			final int jokenColumnMax = 2000;
			
			// 条件文が全て２バイト文字でもカラムに収まるように、カラム長の半分の文字数で切る。
			if (jouken != null && jouken.length() > (jokenColumnMax / 2)) {
				jouken = jouken.substring( 0, (jokenColumnMax / 2) );
			}
			
			/* ログの出力 */
			usersession.sousaKojinJohoLog( kinou_ID, simei_no, taisyou, jouken );
			
			Log.method( simei_no, "OUT", "" );
		} catch (final NamingException ne) {
			Log.error( simei_no, ne );
			throw ne;
		} catch (final ClassCastException cce) {
			Log.error( simei_no, cce );
			throw cce;
		} catch (final Exception e) {
			Log.error( simei_no, e );
			throw e;
		}
	}
	
	/**
	 * EJBの権限変更ログ追加機能を呼び出す。
	 * 
	 * @param kinou_ID 実行機能ID
	 * @param simei_no 実行氏名No
	 * @param taisyo 対象氏名No
	 * @param syubetsu 変更種別(0：登録 1:削除)
	 * @param kengenName 権限種別
	 * @throws NamingException
	 * @throws SQLException
	 */
	public static void sousaChangeKengenLog( final String kinou_ID, final String simei_no, final String taisyo, final int syubetsu, final String kengenName ) throws NamingException, SQLException, Exception {
		Log.method( simei_no, "IN", "" );
		try {
			// EJBHomeの取得
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final OutLogEJBHome my_home = (OutLogEJBHome)fact.lookup( OutLogEJBHome.class );
			
			/* EJBObjectの取得 */
			final OutLogEJB usersession = my_home.create();
			
			/* ログの出力 */
			usersession.sousaChangeKengenLog( kinou_ID, simei_no, taisyo, syubetsu, kengenName );
			
			Log.method( simei_no, "OUT", "" );
		} catch (final NamingException ne) {
			Log.error( simei_no, ne );
			throw ne;
		} catch (final ClassCastException cce) {
			Log.error( simei_no, cce );
			throw cce;
		} catch (final Exception e) {
			Log.error( simei_no, e );
			throw e;
		}
	}
	
	public static void outputLogSousa( final String kinouId, OutSousaLogArg arg ) {
		// 条件に操作(基本ボタンID)を加える
		String condition = "";
		if (arg.getSousa() != null) {
			condition = "操作：" + arg.getSousa();
		}
		
		if (arg.getDisplayCondition() != null) {
			// 代行ログイン社員の場合はカンマを足す
			if ("".equals( condition )) {
				condition += arg.getDisplayCondition();
			} else {
				condition = condition + "," + arg.getDisplayCondition();
			}
		}
		try {
			sousaKojinJohoLog( kinouId, arg.getLogonShimeiNo(), arg.getTargetShimeiNo(), condition );
		} catch (Exception e) {
			throw new CareerRuntimeException( e );
		}
	}
	
	public static void outputLogSousa( final HttpServletRequest request, final String kinouId, final String target, final String state ) {
		final HttpSession session = request.getSession( false );
		if (session == null) {
			throw new CareerRuntimeException();
		}
		final UserInfoBean userinfo = (UserInfoBean)session.getAttribute( "userinfo" );
		OutSousaLogArg sousaLogArg = new OutSousaLogArg();
		sousaLogArg.setLogonShimeiNo( userinfo.getLogin_no() );
		sousaLogArg.setTargetShimeiNo( target );
		sousaLogArg.setSousa( state );
		OutLogBean.outputLogSousa( kinouId, sousaLogArg );
	}
	
	public static void outputLogSousa( final HttpServletRequest request, final String kinouId, final String state ) {
		outputLogSousa( request, kinouId, null, state );
	}
	
}
