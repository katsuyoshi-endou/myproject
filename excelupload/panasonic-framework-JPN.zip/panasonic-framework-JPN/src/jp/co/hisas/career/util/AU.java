package jp.co.hisas.career.util;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.util.cache.YamlCache;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.property.CommonLabel;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * Application Utility
 */
public class AU {
	
	/**
	 * デバッグモード
	 */
	public static boolean isDebugMode() {
		return AU.matchesCareerProperty( "DEBUG_MODE", "ON" );
	}
	
	public static String getTimestamp() {
		DateFormat df = new SimpleDateFormat( "yyyy/MM/dd HH:mm:ss.SSS" );
		return df.format( new Date( Calendar.getInstance().getTimeInMillis() ) );
	}
	
	public static String getTimestamp( String format ) {
		DateFormat df = new SimpleDateFormat( format );
		return df.format( new Date( Calendar.getInstance().getTimeInMillis() ) );
	}
	
	public static String getYYYYMMDD() {
		return getTimestamp( "yyyyMMdd" );
	}
	
	public static String toYYYYMMDD( String timestamp ) {
		// timestamp is 'yyyy/MM/dd HH:mm:ss.SSS'
		if (timestamp == null || timestamp.length() < 10) {
			return "";
		}
		return timestamp.substring( 0, 10 );
	}
	
	public static String toJson( Object obj ) {
		Gson gson = new Gson();
		return gson.toJson( obj );
	}
	
	public static String getParty( HttpSession session ) {
		UserInfoBean userInfo = AU.getSessionAttr( session, UserInfoBean.SESSION_KEY );
		return userInfo.getParty();
	}
	
	public static int getLangNo( HttpSession session ) {
		UserInfoBean userInfo = AU.getSessionAttr( session, UserInfoBean.SESSION_KEY );
		return userInfo.getLangNo();
	}
	
	public static String getCommonLabel( Tray tray, String labelId ) {
		return CommonLabel.getLabel( tray.party, labelId, tray.langNo );
	}
	
	/**
	 * career.properties から key をもとに値を取得する
	 */
	public static String getCareerProperty( String key ) {
		return PZZ010_CharacterUtil.normalizedStr( (String)ReadFile.careerProperties.get( key ) );
	}
	
	/**
	 * career.properties から key をもとに値を取得して一致しているかどうかを返す
	 */
	public static boolean matchesCareerProperty( String key, String val ) {
		String propVal = PZZ010_CharacterUtil.normalizedStr( (String)ReadFile.careerProperties.get( key ) );
		return SU.equals( val, propVal );
	}
	
	/**
	 * sql.properties から key をもとに値を取得する
	 */
	public static String getSqlProperty( String key ) {
		return ReadFile.sqlProperties.getProperty( key );
	}
	
	public static String encodeRequestValue(final String val) throws UnsupportedEncodingException {
		if (val == null) {
			return null;
		}
		return new String(val.getBytes("ISO-8859-1"), "UTF-8");
		
	}
	
	/**
	 * YAML - https://bitbucket.org/asomov/snakeyaml/wiki/Documentation
	 */
	public static String getYamlDocument( String filename ) {
		String document = YamlCache.getSection( filename );
		return document;
	}
	
	public static String[] encodeRequestValue( final String[] vals ) throws UnsupportedEncodingException {
		if (vals == null) {
			return null;
		}
		// String配列は参照渡しなので注意。戻り値用変数resultsに格納して返す。
		String[] results = new String[vals.length];
		for (int i = 0; i < vals.length; i++) {
			results[i] = new String( vals[i].getBytes( "ISO-8859-1" ), "UTF-8" );
		}
		return results;
	}
	
	public static String getRequestValue( final HttpServletRequest request, String requestParameter ) {
		String requestValue = "";
		try {
			String[] values = encodeRequestValue( request.getParameterValues( requestParameter ) );
			if (values == null) {
				return null;
			}
			for (int i = 0; i < values.length; i++) {
				if (!"".equals( values[i] )) {
					requestValue = values[i];
					break;
				}
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			requestValue = "";
		}
		return requestValue;
	}
	
	public static String[] getRequestValues( final HttpServletRequest request, String requestParameter ) {
		String[] results = null;
		try {
			String[] values = encodeRequestValue( request.getParameterValues( requestParameter ) );
			if (values == null) {
				return null;
			}
			results = new String[values.length];
			for (int i = 0; i < values.length; i++) {
				if (SU.isNotBlank( values[i] )) {
					results[i] = values[i];
				}
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return results;
	}
	
	public static Map<String, String> getRequestsWithRegex( final HttpServletRequest request, String regex ) {
		HashMap<String, String> fillReqMap = new HashMap<String, String>();
		Enumeration<?> e = request.getParameterNames();
		while (e.hasMoreElements()) {
			String key = (String)e.nextElement();
			if (!key.matches( regex + ".*" )) {
				continue;
			}
			String val = getRequestValue( request, key );
			fillReqMap.put( key, val );
		}
		return fillReqMap;
	}
	
	/**
	 * 次の優先順位で値を取得する。<br>
	 * RequestParameter, RequestAttribute, SessionAttribute
	 */
	public static String getReqSesVal( final HttpServletRequest request, String key ) {
		String result = AU.getRequestValue( request, key );
		if (SU.isNotBlank( result )) {
			return result;
		} else {
			result = AU.getRequestAttr( request, key );
			if (SU.isNotBlank( result )) {
				return result;
			} else {
				HttpSession session = request.getSession( false );
				return AU.getSessionAttr( session, key );
			}
		}
	}
	
	/**
	 * 次の優先順位で値を取得する。<br>
	 * RequestParameter, RequestAttribute
	 */
	public static String getReqParaAttrVal( final HttpServletRequest request, String key ) {
		String result = AU.getRequestValue( request, key );
		if (SU.isNotBlank( result )) {
			return result;
		} else {
			return AU.getRequestAttr( request, key );
		}
	}
	
	public static void setReqAttr( final HttpServletRequest request, String key, String val ) {
		if (request != null) {
			request.setAttribute( key, val );
		}
	}
	
	public static void setReqAttr( final HttpServletRequest request, String key, Object obj ) {
		if (request != null) {
			request.setAttribute( key, obj );
		}
	}
	
	public static void httpFileDownload( final HttpServletResponse response, String contentType, byte[] dlByteArr, String dlFileName ) throws IOException {
		
		response.setContentType( contentType + "; charset=utf-8" );
		String fileName = URLEncoder.encode( dlFileName, "UTF-8" );
		// Content-Disposition: attachment / inline (添付ファイル / インライン)
		response.setHeader( "Content-Disposition", "attachment; filename=\"" + fileName + "\"" );
		
		final ServletOutputStream out = response.getOutputStream();
		if (dlByteArr != null) {
			final byte[] buffer = new byte[4096];
			final ByteArrayInputStream bais = new ByteArrayInputStream( dlByteArr );
			int size;
			while ((size = bais.read( buffer )) != -1) {
				out.write( buffer, 0, size );
			}
			bais.close();
		}
		out.close();
		response.flushBuffer();
		return;
	}
	public static void httpExcelFileDownload( final HttpServletResponse response, byte[] dlByteArr, String dlFileName ) throws IOException {
		/** ".xlsx": http://support.microsoft.com/kb/936496/en-us */
		httpFileDownload( response, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", dlByteArr, dlFileName );
	}
	
	public static <T> T nvl( T obj, T objWhenNull ) {
		T result = null;
		try {
			result = (obj == null) ? objWhenNull : obj;
		} catch (Exception e) {
		}
		return result;
	}
	
	/**
	 * マップを渡してキーをリストで返す
	 */
	public static <K, V> List<K> toKeyList( Map<K, V> map ) {
		List<K> list = new ArrayList<K>();
		for (K key : map.keySet()) {
			list.add( key );
		}
		return list;
	}
	
	/**
	 * マップの値がすべて空であるかどうか
	 */
	public static <K, V> boolean isAllValueBlank( Map<K, V> map ) {
		Collection<V> vals = map.values();
		for (V v : vals) {
			if (v instanceof String) {
				if (SU.isNotBlank( (String)v )) {
					return false;
				}
				continue;
			}
			if (v != null) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Dtoリストとフィールド名を与えると、そのフィールド値をキーとしたマップで返すありがたいメソッド
	 */
	public static <K, D> Map<K, List<D>> toMap( Collection<D> list, String keyField ) {
		Map<K, List<D>> m = new LinkedHashMap<K, List<D>>();
		if (list == null) {
			return m;
		}
		try {
			for (D d : list) {
				PropertyDescriptor pd = new PropertyDescriptor( keyField, d.getClass() );
				@SuppressWarnings("unchecked")
				K k = (K)pd.getReadMethod().invoke( d, (Object[])null );
				List<D> l = m.get( k );
				if (l != null) {
					l.add( d );
				} else {
					l = new ArrayList<D>();
					l.add( d );
				}
				m.put( k, l );
			}
		} catch (IntrospectionException e) {
		} catch (IllegalArgumentException e) {
		} catch (IllegalAccessException e) {
		} catch (InvocationTargetException e) {
		}
		return m;
	}
	
	/**
	 * Dtoリストとフィールド名を与えると、そのフィールド値をキーとしたマップで返すありがたいメソッド
	 * （１対１紐付け版）
	 */
	public static <K, D> Map<K, D> toMap1to1( Collection<D> list, String keyField ) {
		Map<K, D> m = new LinkedHashMap<K, D>();
		if (list == null) {
			return m;
		}
		try {
			for (D d : list) {
				PropertyDescriptor pd = new PropertyDescriptor( keyField, d.getClass() );
				@SuppressWarnings("unchecked")
				K k = (K)pd.getReadMethod().invoke( d, (Object[])null );
				D dto = m.get( k );
				if (dto != null) {
					;
				} else {
					dto = d;
				}
				m.put( k, dto );
			}
		} catch (IntrospectionException e) {
		} catch (IllegalArgumentException e) {
		} catch (IllegalAccessException e) {
		} catch (InvocationTargetException e) {
		}
		return m;
	}
	
	public static int getSesAttrInt( HttpSession session, String sessionKey ) {
		if (session == null) {
			return 0;
		}
		int result = 0;
		Object obj = session.getAttribute( sessionKey );
		if (obj instanceof String) {
			result = SU.toInt( (String)obj, 0 );
		}
		else if (obj instanceof Number) {
			result = (Integer)obj;
		}
		return result;
	}
	
	/**
	 * 戻り値の型に合わせてキャストしたリクエスト値を取得する
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getRequestAttr( HttpServletRequest request, String reqAttrKey ) {
		return (T)automaticCast( request.getAttribute( reqAttrKey ) );
	}
	
	/**
	 * 戻り値の型に合わせてキャストしたセッション値を取得する
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getSessionAttr( HttpSession session, String sessionKey ) {
		if (session == null) {
			return null;
		}
		return (T)automaticCast( session.getAttribute( sessionKey ) );
	}
	
	/**
	 * 戻り値の型に合わせてキャストする
	 * http://www.profaim.jp/lang-ref/java/generics/cast.php
	 */
	@SuppressWarnings("unchecked")
	public static <T> T automaticCast( Object src ) {
		T castedObject = (T)src;
		return castedObject;
	}
	
}
