/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.CjsNinsyouDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CJS_NINSYOU Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CjsNinsyouDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " SIMEI_NO as simeiNo,"
                     + " PASSWORD as password,"
                     + " PASSWORD_UPDATE as passwordUpdate,"
                     + " MANAGED_ID as managedId,"
                     + " SYSTEM_FLG as systemFlg"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CjsNinsyouDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CjsNinsyouDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * Insert文を実行する。
     * @param dto CJS_NINSYOUのデータ。
     */ 
    public void insert(CjsNinsyouDto dto) {

        final String sql = "INSERT INTO CJS_NINSYOU ("
                         + "SIMEI_NO,"
                         + "PASSWORD,"
                         + "PASSWORD_UPDATE,"
                         + "MANAGED_ID,"
                         + "SYSTEM_FLG"
                         + ")VALUES(?,?,?,?,? )"
                         ;
        Log.sql("【DaoMethod Call】 CjsNinsyouDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getSimeiNo());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getPassword());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getPasswordUpdate());
            DaoUtil.setIntToPreparedStatement(pstmt, 4, dto.getManagedId());
            DaoUtil.setIntToPreparedStatement(pstmt, 5, dto.getSystemFlg());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * 全列update文を実行する。
     * @param dto CJS_NINSYOUのレコード型データ。
     */
    public void update(CjsNinsyouDto dto) {

        final String sql = "UPDATE CJS_NINSYOU SET "
                         + "PASSWORD = ?,"
                         + "PASSWORD_UPDATE = ?,"
                         + "SYSTEM_FLG = ?"
                         + " WHERE SIMEI_NO = ?"
                         + " AND MANAGED_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CjsNinsyouDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getPassword());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getPasswordUpdate());
            DaoUtil.setIntToPreparedStatement(pstmt, 3, dto.getSystemFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getSimeiNo());
            DaoUtil.setIntToPreparedStatement(pstmt, 5, dto.getManagedId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param simeiNo SIMEI_NO
     * @param managedId MANAGED_ID
     * @return CjsNinsyouDto CJS_NINSYOUのレコード型データ。
     */ 
    public CjsNinsyouDto select(String simeiNo, Integer managedId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CJS_NINSYOU"
                         + " WHERE SIMEI_NO = ?"
                         + " AND MANAGED_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CjsNinsyouDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, simeiNo);
            DaoUtil.setIntToPreparedStatement(pstmt, 2, managedId);
            rs = pstmt.executeQuery();
            CjsNinsyouDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<CjsNinsyouDto> CJS_NINSYOUのレコード型データのリスト。
     */ 
    public List<CjsNinsyouDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CjsNinsyouDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CjsNinsyouDto> lst = new ArrayList<CjsNinsyouDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CjsNinsyouDto> CJS_NINSYOUのレコード型データのリスト。
     */ 
    public List<CjsNinsyouDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CjsNinsyouDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param pstmt PreparedStatement
     */ 
    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("【DaoMethod Call】 CjsNinsyouDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param sql SQL文
     */ 
    public void executeDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CjsNinsyouDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CjsNinsyouDto transferRsToDto(ResultSet rs) throws SQLException {

        CjsNinsyouDto dto = new CjsNinsyouDto();
        dto.setSimeiNo(DaoUtil.convertNullToString(rs.getString("simeiNo")));
        dto.setPassword(DaoUtil.convertNullToString(rs.getString("password")));
        dto.setPasswordUpdate(DaoUtil.convertNullToString(rs.getString("passwordUpdate")));
        dto.setManagedId(rs.getInt("managedId"));
        dto.setSystemFlg(rs.getInt("systemFlg"));
        return dto;
    }

}

