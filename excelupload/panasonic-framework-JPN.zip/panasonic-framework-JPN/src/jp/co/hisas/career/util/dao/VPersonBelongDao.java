/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.VPersonBelongDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * V_人所属 Data Access Object。
 * @author CareerDaoTool.xla
*/
public class VPersonBelongDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " PERSON_ID as personId,"
                     + " PERSON_NAME as personName,"
                     + " DEPT_CD as deptCd,"
                     + " DEPT_NM as deptNm,"
                     + " CLS_A_CD as clsACd,"
                     + " CLS_A_NM as clsANm,"
                     + " CLS_A_SORT as clsASort,"
                     + " CLS_B_CD as clsBCd,"
                     + " CLS_B_NM as clsBNm,"
                     + " CLS_B_SORT as clsBSort,"
                     + " CLS_C_CD as clsCCd,"
                     + " CLS_C_NM as clsCNm,"
                     + " CLS_C_SORT as clsCSort,"
                     + " CLS_D_CD as clsDCd,"
                     + " CLS_D_NM as clsDNm,"
                     + " CLS_D_SORT as clsDSort,"
                     + " CLS_E_CD as clsECd,"
                     + " CLS_E_NM as clsENm,"
                     + " CLS_E_SORT as clsESort,"
                     + " CLS_F_CD as clsFCd,"
                     + " CLS_F_NM as clsFNm,"
                     + " CLS_F_SORT as clsFSort,"
                     + " CLS_G_CD as clsGCd,"
                     + " CLS_G_NM as clsGNm,"
                     + " CLS_G_SORT as clsGSort,"
                     + " CLS_H_CD as clsHCd,"
                     + " CLS_H_NM as clsHNm,"
                     + " CLS_H_SORT as clsHSort,"
                     + " CLS_I_CD as clsICd,"
                     + " CLS_I_NM as clsINm,"
                     + " CLS_I_SORT as clsISort,"
                     + " CLS_J_CD as clsJCd,"
                     + " CLS_J_NM as clsJNm,"
                     + " CLS_J_SORT as clsJSort"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public VPersonBelongDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public VPersonBelongDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param personId 人ID
     * @return VPersonBelongDto V_PERSON_BELONGのレコード型データ。
     */ 
    public VPersonBelongDto select(String personId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM V_PERSON_BELONG"
                         + " WHERE PERSON_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 VPersonBelongDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, personId);
            rs = pstmt.executeQuery();
            VPersonBelongDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<VPersonBelongDto> V_PERSON_BELONGのレコード型データのリスト。
     */ 
    public List<VPersonBelongDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 VPersonBelongDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<VPersonBelongDto> lst = new ArrayList<VPersonBelongDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<VPersonBelongDto> V_PERSON_BELONGのレコード型データのリスト。
     */ 
    public List<VPersonBelongDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 VPersonBelongDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private VPersonBelongDto transferRsToDto(ResultSet rs) throws SQLException {

        VPersonBelongDto dto = new VPersonBelongDto();
        dto.setPersonId(DaoUtil.convertNullToString(rs.getString("personId")));
        dto.setPersonName(DaoUtil.convertNullToString(rs.getString("personName")));
        dto.setDeptCd(DaoUtil.convertNullToString(rs.getString("deptCd")));
        dto.setDeptNm(DaoUtil.convertNullToString(rs.getString("deptNm")));
        dto.setClsACd(DaoUtil.convertNullToString(rs.getString("clsACd")));
        dto.setClsANm(DaoUtil.convertNullToString(rs.getString("clsANm")));
        dto.setClsASort(DaoUtil.convertNullToString(rs.getString("clsASort")));
        dto.setClsBCd(DaoUtil.convertNullToString(rs.getString("clsBCd")));
        dto.setClsBNm(DaoUtil.convertNullToString(rs.getString("clsBNm")));
        dto.setClsBSort(DaoUtil.convertNullToString(rs.getString("clsBSort")));
        dto.setClsCCd(DaoUtil.convertNullToString(rs.getString("clsCCd")));
        dto.setClsCNm(DaoUtil.convertNullToString(rs.getString("clsCNm")));
        dto.setClsCSort(DaoUtil.convertNullToString(rs.getString("clsCSort")));
        dto.setClsDCd(DaoUtil.convertNullToString(rs.getString("clsDCd")));
        dto.setClsDNm(DaoUtil.convertNullToString(rs.getString("clsDNm")));
        dto.setClsDSort(DaoUtil.convertNullToString(rs.getString("clsDSort")));
        dto.setClsECd(DaoUtil.convertNullToString(rs.getString("clsECd")));
        dto.setClsENm(DaoUtil.convertNullToString(rs.getString("clsENm")));
        dto.setClsESort(DaoUtil.convertNullToString(rs.getString("clsESort")));
        dto.setClsFCd(DaoUtil.convertNullToString(rs.getString("clsFCd")));
        dto.setClsFNm(DaoUtil.convertNullToString(rs.getString("clsFNm")));
        dto.setClsFSort(DaoUtil.convertNullToString(rs.getString("clsFSort")));
        dto.setClsGCd(DaoUtil.convertNullToString(rs.getString("clsGCd")));
        dto.setClsGNm(DaoUtil.convertNullToString(rs.getString("clsGNm")));
        dto.setClsGSort(DaoUtil.convertNullToString(rs.getString("clsGSort")));
        dto.setClsHCd(DaoUtil.convertNullToString(rs.getString("clsHCd")));
        dto.setClsHNm(DaoUtil.convertNullToString(rs.getString("clsHNm")));
        dto.setClsHSort(DaoUtil.convertNullToString(rs.getString("clsHSort")));
        dto.setClsICd(DaoUtil.convertNullToString(rs.getString("clsICd")));
        dto.setClsINm(DaoUtil.convertNullToString(rs.getString("clsINm")));
        dto.setClsISort(DaoUtil.convertNullToString(rs.getString("clsISort")));
        dto.setClsJCd(DaoUtil.convertNullToString(rs.getString("clsJCd")));
        dto.setClsJNm(DaoUtil.convertNullToString(rs.getString("clsJNm")));
        dto.setClsJSort(DaoUtil.convertNullToString(rs.getString("clsJSort")));
        return dto;
    }

}

