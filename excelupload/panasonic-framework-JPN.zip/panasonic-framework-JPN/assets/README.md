Career Assets for Framework
===========================

各Career系アプリはこのフォルダのリソースを以下のパスで参照します。

- `/(context-root)/assets/vendor/lysithea/`

Framework リポジトリでの変更は make フォルダにある

- `build-css.cmd`
- `distribute-assets.cmd`

を使ってビルドし各アプリのリポジトリに配布します。
