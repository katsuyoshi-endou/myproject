var gulp = require('gulp');
var del = require('del');

gulp.task('clean', function() {
  return del(['_dest', 'css']);
});

gulp.task('pcss2css', function() {
  var rename = require("gulp-rename");
  return gulp.src('pcss/**/*.pcss')
    .pipe(
      rename(function(path){
        path.extname = ".css"
      })
    )
    .pipe(gulp.dest("css"));
});

gulp.task('postcss', function() {
  var postcss = require('gulp-postcss');
  var browsers = ['ie >= 11', 'Chrome >= 53', 'iOS >= 8', 'Firefox >= 49', 'Edge >= 14'];
  return gulp.src('css/lysithea.css')
    .pipe(
      postcss([
        require('precss'),
        require('autoprefixer')({ browsers: browsers }),
        require('postcss-strip-inline-comments')
      ], {syntax: require('postcss-scss')})
    )
    .pipe( gulp.dest('_dest/css') );
});

gulp.task('js', function() {
  return gulp.src('js/**/*.js')
    .pipe(gulp.dest("_dest/js"));
});

gulp.task('img', function() {
  return gulp.src('img/**/*')
    .pipe(gulp.dest("_dest/img"));
});

gulp.task('after', function() {
  return del(['css']);
});

gulp.task('compile', function(cb) {
  var runSequence = require('run-sequence');
  return runSequence('clean', 'pcss2css', 'postcss', 'js', 'img', 'after');
});

gulp.task('default', ['compile']);
