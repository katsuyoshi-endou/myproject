Career 開発環境構築手順
=======================

## Download tools

下記のフォルダをローカルにコピーする

```bat
\\hsadfs25¥ly-product\330_リシテア_製品開発\70_Career\16_Next-01-00\33_ローカル開発環境
```

- Pleiades Eclipse 4.5 Mars (Standard)
  - `C:\pleiades`
- JDK 8
  - `C:\java\jdk1.8.0_91`
- Ant 1.9.7
  - `C:\java\apache-ant-1.9.7`
- GlassFish 4
  - `C:\java\glassfish4`
- JDBC Driver
  - `C:\java\glassfish4\glassfish\lib\ojdbc7.jar`
- Ruby 2.3 (for Generate Batch SQL scripts)
  - `C:\Ruby23`
- Node.js v6.9.1 LTS
  - `C:\Program Files\nodejs`
  - NPM Package Install
    - `cd C:\repo\framework`
    - `npm config set proxy http://ly-proxy:3128`
    - `npm config set https-proxy http://ly-proxy:3128`
    - `npm install`
- Git
  - https://desktop.github.com/
  - Internet option
    - `ly-proxy`
    - `3128`
  - インストールが済んだらプロキシ設定を元に戻す
- Cmder
  - Startup / Tasks / {cmd}


## Career Framework EJB

Talent, Sheet, Admin アプリは Career フレームワークを使って構築されています。  
Framework が共通部分を Jar にまとめて提供しているので、それを各アプリに読み込ませます。

- `<App>/library-fw/careerEJB.jar`


## Download Repository

### make repo folder
```bat
> cd c:\
> mkdir repo
```

### Get source code
```bat
> cd repo
> git clone http://dev02.appmills2.itg.hitachi.co.jp/career-2016/framework
```

### Get CD-ROM data
- SVN Checkout
  - `http://dev02.appmills2.itg.hitachi.co.jp/career-2016/cdrom`

#### アプリケーションフォルダの配置

```bat
> mkdir C:\Lysithea
```

- `http://dev02.appmills2.itg.hitachi.co.jp/career-2016/cdrom/Lysithea`
  - 末尾注意。チェックアウトするフォルダと合わせる


## Eclipse

### パースペクティブを開く
- Git
- 既存のローカルGitリポジトリーを追加
- `C:\repo\framework`

### プロジェクトのインポート
- Git パースペクティブ
- framework [master] 右クリック
- プロジェクトのインポート
- Import existing Eclipse projects

### Formatter
- 設定
- 左上入力欄 `フォーマッター` でフィルタ
- Java > コード・スタイル > フォーマッター を選択
- インポートボタン をクリック
- `開発環境/eclipse設定/Eclipse_LysitheaFormatter.xml` を読み込む
- `インポートしたプロファイルを名前変更`: __`Career`__

### 構文の色
- `C:\pleiades\workspace\.metadata\.plugins\org.eclipse.core.runtime\.settings` をエクスプローラで開く
- `開発環境/eclipse設定` にある以下のファイルをドラッグして上書き
  - `org.eclipse.jdt.ui.prefs`
  - `org.eclipse.ui.editors.prefs`
  - `org.eclipse.ui.workbench.prefs`

### 末尾スペース
- 設定
- 左上入力欄 `any` でフィルタして「AnyEdit ツール」を選択
- □ 末尾の空白を除去 のチェックをはずす


## GlassFishの設定

### GlassFish の Eclipse プラグイン
- メニュー > ウィンドウ > ビュー > 「サーバー」ビューを追加
  - 「サーバー」ビューで新規サーバーを作成
    - GlassFish Tools を選択しプラグインをダウンロード
      - 再度サーバーを新規作成し GlassFish 4 を指定
        - GlassFish location: `C:\java\glassfish4\glassfish`
        - Java location: `C:\java\jdk1.8.0_91`

### GlassFishの起動
- 「サーバー」ビュー
  - 「サーバーを始動」ボタン

### GlassFish 管理画面
- http://localhost:4848

### JDBC Connection Pools

#### General

- Pool Name:
  - `CareerPool`
- Resource Type:
  - `javax.sql.DataSource`
- Database Driver Vendor:
  - `Oracle`

#### Additional Properties

既存のものをすべて削除して以下をつくりなおす。

| Name     | Value    |
|----------|----------|
| URL      | `jdbc:oracle:thin:@<IP>:1521:ORCL` |
| User     | `CAREER` |
| Password | `CAREER` |

### JDBC Resources

- JNDI Name:
  - `jdbc/HCDB`
- Pool Name:
  - `CareerPool`


## Build and Deploy

- `make/build.bat`
- `make/BuildAndDeploy.bat`


## Framework develop

Framework ソース（careerEJB.jar の中身や `assets/vendor/lysithea` 配下）の改修を行った際は、
各アプリに成果物を再配布する必要があります。詳しくは有識者にご確認下さい。

- `make`
  - `build-assets.cmd`
  - `build-ejb.bat`
  - `distribute-assets.cmd`
  - `distribute-ejb.cmd`


## Start App
- http://localhost:8080/career/view/prelogin.html
