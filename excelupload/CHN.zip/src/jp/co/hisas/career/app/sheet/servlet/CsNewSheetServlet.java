package jp.co.hisas.career.app.sheet.servlet;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.KeepTokenServlet;
import jp.co.hisas.career.app.sheet.event.CsNewSheetEventArg;
import jp.co.hisas.career.app.sheet.event.CsNewSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.CsNewSheetEventResult;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class CsNewSheetServlet extends KeepTokenServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "VHD050";
	private static final String FORWARD_PAGE = null;
	
	public String serviceMain( Tray tray ) throws CareerException {
		
		String createdSheetId = null;
		if ("CREATE".equals( tray.state )) {
			
			CsNewSheetEventArg arg = new CsNewSheetEventArg( tray.loginNo );
			arg.sharp       = tray.state;
			arg.operationCd = tray.request.getParameter( "operationCd" );
			arg.formGroupCd = tray.request.getParameter( "formGroupCd" );
			arg.formCd      = tray.request.getParameter( "formCd" );
			arg.party       = tray.menu.party;
			arg.ownGuid     = tray.loginNo;
			CsNewSheetEventResult result = CsNewSheetEventHandler.exec( arg );
			createdSheetId = result.newSheetId;
			String resultMsg = result.resultMsg;
			String msgKind = "";
			if (result.exitCd == 0) {
				// 0: 正常終了
				msgKind = AppSessionKey.RESULT_MSG_INFO;
				tray.forwardUrl = "/servlet/CsSheetServlet?state=INIT";
			} else if (result.exitCd == 1) {
				// 1: 警告
				msgKind = AppSessionKey.RESULT_MSG_WARN;
				tray.forwardUrl = "/view/sheet/VHD050_NewSheet.jsp";
			} else if (result.exitCd > 1) {
				// 8: Oracleエラー, 9: 業務エラー
				msgKind = AppSessionKey.RESULT_MSG_ERROR;
				resultMsg = AU.getCommonLabel( tray, "LSHSHT_MSG_SHEET_CREATE_FAILURE" );
				// シート新規作成失敗
				tray.forwardUrl = "/view/sheet/VHD050_NewSheet.jsp";
			}
			tray.session.setAttribute( msgKind, resultMsg );
			tray.session.setAttribute( CsSessionKey.CS_SHEET_ID, createdSheetId );
		}
		
		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, createdSheetId, tray.state );
		
		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}
	
}
