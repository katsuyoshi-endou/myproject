/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSM_EXCEL_FILL_MAP Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmExcelFillMapDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PARTY
     */
    private String party;
    /**
     * LAYOUT_CD
     */
    private String layoutCd;
    /**
     * FILL_ID
     */
    private String fillId;
    /**
     * SHEET
     */
    private String sheet;
    /**
     * CELL
     */
    private String cell;

    /**
     * PARTYを取得する。
     * @return PARTY
     */
    public String getParty() {
        return party;
    }

    /**
     * PARTYを設定する。
     * @param party PARTY
     */
    public void setParty(String party) {
        this.party = party;
    }

    /**
     * LAYOUT_CDを取得する。
     * @return LAYOUT_CD
     */
    public String getLayoutCd() {
        return layoutCd;
    }

    /**
     * LAYOUT_CDを設定する。
     * @param layoutCd LAYOUT_CD
     */
    public void setLayoutCd(String layoutCd) {
        this.layoutCd = layoutCd;
    }

    /**
     * FILL_IDを取得する。
     * @return FILL_ID
     */
    public String getFillId() {
        return fillId;
    }

    /**
     * FILL_IDを設定する。
     * @param fillId FILL_ID
     */
    public void setFillId(String fillId) {
        this.fillId = fillId;
    }

    /**
     * SHEETを取得する。
     * @return SHEET
     */
    public String getSheet() {
        return sheet;
    }

    /**
     * SHEETを設定する。
     * @param sheet SHEET
     */
    public void setSheet(String sheet) {
        this.sheet = sheet;
    }

    /**
     * CELLを取得する。
     * @return CELL
     */
    public String getCell() {
        return cell;
    }

    /**
     * CELLを設定する。
     * @param cell CELL
     */
    public void setCell(String cell) {
        this.cell = cell;
    }

}

