package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;

import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class CSheetStatusProgressFlowDto extends AbstractEventResult {
	
	private String flowNm = null;
	private ArrayList<String[]> statusArray = null;
	
	public String getFlowNm() {
		return flowNm;
	}

	public void setFlowNm( String flowNm ) {
		this.flowNm = flowNm;
	}

	public ArrayList<String[]> getStatusArray() {
		return statusArray;
	}
	
	public void setStatusArray( ArrayList<String[]> statusArray ) {
		this.statusArray = statusArray;
	}
	
}