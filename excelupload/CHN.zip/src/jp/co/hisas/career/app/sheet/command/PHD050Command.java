package jp.co.hisas.career.app.sheet.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.CareerMenuBean;
import jp.co.hisas.career.app.sheet.event.CsNewSheetEventArg;
import jp.co.hisas.career.app.sheet.event.CsNewSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.CsNewSheetEventResult;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.framework.trans.StateTransitionEvent;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class PHD050Command extends AbstractCommand {
	
	public static final String KINOU_ID = "VHD050";
	private HttpServletRequest request;
	private HttpSession session;
	private String state;
	
	public PHD050Command() {
		super( PHD050Command.class, KINOU_ID, null );
	}
	
	public void init( StateTransitionEvent e ) {
		try {
			request = e.getRequest();
			session = request.getSession( false );
			CSRFTokenUtil.setNewTokenNo( request, e.getResponse() );
			state = request.getParameter( "state" );
			main();
		} catch (CareerException ex) {
			throw new CareerRuntimeException( ex );
		}
	}
	
	private void main() throws CareerException {
		
		if ("INIT".equals( state ) || "RESTORE".equals( state )) {
			execEventInit();
		}
		
		/* 操作ログ */
		OutLogBean.outputLogSousa( request, KINOU_ID, null, state );
	}
	
	private void execEventInit() throws CareerException {
		
		CareerMenuBean oneMenu = AU.getSessionAttr( session, AppSessionKey.CAREER_ONE_MENU );
		String companyCd = oneMenu.party;
		
		/* Set Args */
		CsNewSheetEventArg arg = new CsNewSheetEventArg( super.getLoginNo() );
		arg.sharp = "FORM_LIST";
		arg.party = companyCd;
		
		/* Execute Event */
		CsNewSheetEventResult result = CsNewSheetEventHandler.exec( arg );
		
		/* Return to session */
		session.setAttribute( CsSessionKey.CS_ACTIVE_OPE_FORM_LIST, result.activeOpeFormList );
	}
	
}