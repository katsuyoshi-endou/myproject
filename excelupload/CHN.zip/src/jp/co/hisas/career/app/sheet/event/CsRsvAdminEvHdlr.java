package jp.co.hisas.career.app.sheet.event;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.ConnDef;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.CommonLabel;

public class CsRsvAdminEvHdlr extends AbstractEventHandler<CsRsvAdminEvArg, CsRsvAdminEvRslt> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static CsRsvAdminEvRslt exec( CsRsvAdminEvArg arg ) throws CareerException {
		CsRsvAdminEvHdlr handler = new CsRsvAdminEvHdlr();
		return handler.call( arg );
	}
	
	public CsRsvAdminEvRslt call( CsRsvAdminEvArg arg ) throws CareerException {
		CsRsvAdminEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CsRsvAdminEvRslt execute( CsRsvAdminEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		CsRsvAdminEvRslt result = new CsRsvAdminEvRslt();
		
		try {
			
			if (SU.equals( arg.sharp, "SYNC_DSTRBT_SINGLE" )) {
				
				result.exitCd = createNewSheetSyncSingle();
				result.resultMsg = CommonLabel.getLabel("LSHSHT_MSG_SHEET_DISTRIBUTE_DONE");
			}
			else if (SU.equals( arg.sharp, "SYNC_CST_RSV_DEL_SHEET" )) {
				
				result.exitCd = deleteSheet();
				result.resultMsg = CommonLabel.getLabel("LSHSHT_MSG_SHEET_DELETE_DONE");
			}
			else if (SU.equals( arg.sharp, "SYNC_CST_RSV_ACTOR" )) {
				
				result.exitCd = syncActors();
				result.resultMsg = CommonLabel.getLabel("LSHSHT_MSG_SHEET_ACTOR_UPD_DONE");
			}
			else if (SU.equals( arg.sharp, "SYNC_CST_RSV_ATTR" )) {
				
				result.exitCd = syncAttrs();
				result.resultMsg = CommonLabel.getLabel("LSHSHT_MSG_SHEET_ATTR_UPD_DONE");
			}
			else if (SU.equals( arg.sharp, "SYNC_CST_RSV_CHG_FORM" )) {
				
				result.exitCd = syncForms();
				result.resultMsg = CommonLabel.getLabel("LSHSHT_MSG_SHEET_FORMAT_UPD_DONE");
			}
			else if (SU.equals( arg.sharp, "SYNC_CST_RSV_CHG_STATUS" )) {
				
				result.exitCd = syncStatuses();
				result.resultMsg = CommonLabel.getLabel("LSHSHT_MSG_SHEET_STATUS_UPD_DONE");
			}
			else if (SU.equals( arg.sharp, "SYNC_CST_RSV_FILL" )) {
				
				result.exitCd = syncFills();
				result.resultMsg = CommonLabel.getLabel("LSHSHT_MSG_SHEET_FILL_UPD_DONE");
			}
			
		} catch (SQLException e) {
			throw new CareerSQLException( e );
		} catch (Exception e) {
			throw new CareerRuntimeException( e );
		}
		
		return result;
	}
	
	/**
	 * Single: 1 Operation & Form Group = 1 Sheet
	 */
	private int createNewSheetSyncSingle() throws SQLException {
		return execPlpkgFunction( "PLPKG_CS_EXE_DSTRBT" );
	}
	
	private int deleteSheet() throws SQLException {
		return execPlpkgFunction( "PLPKG_CS_EXE_DEL_SHEET" );
	}
	
	private int syncActors() throws SQLException {
		int exitCd1 = execPlpkgFunction( "PLPKG_CS_EXE_ACTOR" );
		int exitCd2 = execPlpkgFunction( "PLPKG_CS_EXE_ACTOR_REF" );
		return Math.max( exitCd1, exitCd2 );
	}
	
	private int syncAttrs() throws SQLException {
		return execPlpkgFunction( "PLPKG_CS_EXE_ATTR" );
	}
	
	private int syncForms() throws SQLException {
		return execPlpkgFunction( "PLPKG_CS_EXE_CHG_FORM" );
	}
	
	private int syncStatuses() throws SQLException {
		return execPlpkgFunction( "PLPKG_CS_EXE_CHG_STATUS" );
	}
	
	private int syncFills() throws SQLException {
		return execPlpkgFunction( "PLPKG_CS_EXE_FILL" );
	}
	
	/**
	 * FUNCTION名を指定してPLPKGを呼び出す。
	 * 引数 vRsvUser はログインユーザを自動でセットする。
	 * intでEXITCODEを受け取る。
	 * @param functionName
	 * @return exitCd
	 */
	private int execPlpkgFunction( String functionName ) throws SQLException {
		int exitCd = 0;
		CallableStatement cstmt = null;
		Connection conn = null;
		try {
			InitialContext ctx = new InitialContext();
			DataSource ds = (DataSource)ctx.lookup( ConnDef.DATASOURCE_NAME );
			conn = ds.getConnection();
			cstmt = conn.prepareCall( "{?=call " + functionName + ".MAIN(?,?)}" );
			cstmt.registerOutParameter( 1, java.sql.Types.INTEGER );
			cstmt.setString( 2, this.loginNo ); // Not 統合GUID, ExcelツールによるRSV登録のGUIDと一致させる
			cstmt.setString( 3, "VHA011" );
			cstmt.execute();
			exitCd = cstmt.getInt( 1 );
		} catch (NamingException e) {
			throw new CareerSQLException( e );
		} catch (SQLException e) {
			throw new CareerSQLException( e );
		} finally {
			cstmt.close();
			conn.close();
		}
		return exitCd;
	}
	
}
