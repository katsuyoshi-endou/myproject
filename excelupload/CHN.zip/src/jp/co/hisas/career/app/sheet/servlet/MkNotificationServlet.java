package jp.co.hisas.career.app.sheet.servlet;

import java.util.List;

import com.google.gson.Gson;

import jp.co.hisas.career.app.sheet.dto.MktNotificationDto;
import jp.co.hisas.career.app.sheet.event.MkN10nEvArg;
import jp.co.hisas.career.app.sheet.event.MkN10nEvHdlr;
import jp.co.hisas.career.app.sheet.event.MkN10nEvRslt;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.AjaxServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class MkNotificationServlet extends AjaxServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "N10N";
	
	public String doGetMain( Tray tray ) throws CareerException {
		
		List<MktNotificationDto> list = retrieveNotifications( tray );
		
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, null, "GET" );
		
		Gson gson = new Gson();
		return gson.toJson( list );
	}
	
	public String doPostMain( Tray tray ) throws CareerException {
		
		String seq = readNotification( tray );
		
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, seq, "READ" );
		
		Gson gson = new Gson();
		return gson.toJson( "success" );
	}
	
	private List<MktNotificationDto> retrieveNotifications( Tray tray ) throws CareerException {
		MkN10nEvArg arg = new MkN10nEvArg( tray.loginNo );
		arg.sharp = "GET_ALL_UNREAD_N10NS";
		arg.party = tray.party;
		arg.guid = tray.loginNo;
		MkN10nEvRslt rslt = MkN10nEvHdlr.exec( arg );
		return rslt.mkN10nList;
	}
	
	private String readNotification( Tray tray ) throws CareerException {
		String seq = AU.getRequestValue( tray.request, "seq" );
		MkN10nEvArg arg = new MkN10nEvArg( tray.loginNo );
		arg.sharp = "READ_N10N";
		arg.party = tray.party;
		arg.guid  = tray.loginNo;
		arg.seq   = SU.toInt( seq, 0 );
		MkN10nEvHdlr.exec( arg );
		return seq;
	}
}
