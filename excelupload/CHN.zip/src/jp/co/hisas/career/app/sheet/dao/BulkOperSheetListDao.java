package jp.co.hisas.career.app.sheet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.BulkOperSheetListDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

public class BulkOperSheetListDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public BulkOperSheetListDao( String loginNo ) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public BulkOperSheetListDao( Connection conn ) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<BulkOperSheetListDto>
     */
    public List<BulkOperSheetListDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 BulkOperSheetListDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<BulkOperSheetListDto> lst = new ArrayList<BulkOperSheetListDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /**
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<BulkOperSheetListDto>
     */
    public List<BulkOperSheetListDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 BulkOperSheetListDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /**
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private BulkOperSheetListDto transferRsToDto(ResultSet rs) throws SQLException {

    	BulkOperSheetListDto dto = new BulkOperSheetListDto();
    	dto.setSheetId(DaoUtil.convertNullToString( rs.getString( "sheetId" )));
    	dto.setOperationNm(DaoUtil.convertNullToString( rs.getString( "operationNm" )));
    	dto.setOwnPersonName(DaoUtil.convertNullToString( rs.getString( "ownPeronName" )));
    	dto.setFullDeptNm(DaoUtil.convertNullToString( rs.getString( "fullDeptNm" )));
    	dto.setCmpaCd(DaoUtil.convertNullToString( rs.getString( "cmpaCd" )));
    	dto.setStatusNm(DaoUtil.convertNullToString( rs.getString( "statusNm" )));
    	dto.setActor1stNm(DaoUtil.convertNullToString( rs.getString( "actor1stNm" )));
    	dto.setActor2ndNm(DaoUtil.convertNullToString( rs.getString( "actor2ndNm" )));
    	dto.setActor3rdNm(DaoUtil.convertNullToString( rs.getString( "actor3rdNm" )));
    	dto.setActor4thNm(DaoUtil.convertNullToString( rs.getString( "actor4thNm" )));
    	dto.setExclusiveKey(DaoUtil.convertNullToString( rs.getString( "exclusiveKey" )));
    	dto.setWkIdx(rs.getInt( "wkIdx" ));

        return dto;
    }
}
