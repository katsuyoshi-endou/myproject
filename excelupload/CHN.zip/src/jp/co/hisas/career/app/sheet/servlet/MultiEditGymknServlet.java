package jp.co.hisas.career.app.sheet.servlet;

import java.util.HashMap;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.app.sheet.event.CsSheetEventArg;
import jp.co.hisas.career.app.sheet.event.CsSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.CsSheetEventResult;
import jp.co.hisas.career.app.sheet.event.MultiEditGymknEvArg;
import jp.co.hisas.career.app.sheet.event.MultiEditGymknEvHdlr;
import jp.co.hisas.career.app.sheet.event.MultiEditGymknEvRslt;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.NewTokenServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class MultiEditGymknServlet extends NewTokenServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "VSHMEG";
	private static final String FORWARD_PAGE = "/view/sheet/layout_multi/MultiEditGymkn.jsp";
	
	public String serviceMain( Tray tray ) throws CareerException {
		
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( tray.session, UserInfoBean.SESSION_KEY );
		tray.operatorGuid = userInfo.getOperatorGuid();
		
		if (SU.equals( tray.state, "INIT" )) {
			execStateInit(tray);
			String showingOperationNm = AU.getRequestValue(tray.request, "showingOperationNm");
			String showingStatusCd = AU.getRequestValue(tray.request, "showingStatusCd");
			String showingStatusNm = AU.getRequestValue(tray.request, "showingStatusNm");
			tray.session.setAttribute(CsSessionKey.VSHMEG_SHOWING_OPNM, showingOperationNm);
			tray.session.setAttribute(CsSessionKey.VSHMEG_SHOWING_STCD, showingStatusCd);
			tray.session.setAttribute(CsSessionKey.VSHMEG_SHOWING_STNM, showingStatusNm);
		}
		else if (SU.equals( tray.state, "SHOW" )) {
			String selectedActor = AU.getRequestValue(tray.request, "actorCd");
			tray.session.setAttribute(CsSessionKey.VSHMEG_SELECTED_ACTOR, selectedActor );
		}
		else if (SU.equals( tray.state, "SAVE" )) {
			execStateSave(tray, userInfo);
		}
		else if (SU.equals( tray.state, "MULTI" )) {
			execStateMulti(tray, userInfo);
		}
		
		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, tray.state );
		
		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}
	
	private void execStateInit(Tray tray) throws CareerException {
		
		MultiEditGymknEvArg arg = new MultiEditGymknEvArg(tray.loginNo);
		arg.sharp = "INIT";
		arg.loginGuid = tray.loginNo;
		arg.operatorGuid = tray.operatorGuid;
		MultiEditGymknEvRslt result = MultiEditGymknEvHdlr.exec(arg);
		
		String selectedActor = null;
		if (result.actorList.size() > 0) {
			selectedActor = result.actorList.get(0).getValue();
		}
		
		tray.session.setAttribute(CsSessionKey.VSHMEG_ACTOR_LIST, result.actorList);
		tray.session.setAttribute(CsSessionKey.VSHMEG_SELECTED_ACTOR, selectedActor );
	}

	/**
	 * CsSheetActionServletからコピーして改変
	 */
	private void execStateSave(Tray tray, UserInfoBean userInfo) throws CareerException {
		
		String sheetId = AU.getRequestValue(tray.request, "edited_sheet_id");
		String exclusiveKey = AU.getRequestValue(tray.request, "exclusive_key");
		
		callCsSheetEvent("STAY", tray, userInfo, sheetId, exclusiveKey);
	}

	private void callCsSheetEvent(String actionCd, Tray tray, UserInfoBean userInfo, String sheetId, String exclusiveKey) throws CareerException {
		// Requestの中から Fill-- で始まるもののみを抽出 (Prefix will be removed)
		HashMap<String, String> fillReqMap = CsUtil.getRequestsWithRegex(tray.request, "^Fill--");
		
		CsSheetEventArg arg = new CsSheetEventArg(tray.loginNo, tray.operatorGuid);
		arg.sharp = actionCd;
		arg.mailSenderName = userInfo.getKanjiSimei();
		arg.sheetId = sheetId;
		CstSheetExclusiveDto excDto = new CstSheetExclusiveDto();
		excDto.setSheetId(sheetId);
		Integer iExcKey = Integer.parseInt(CsUtil.bvl(exclusiveKey, "0"));
		excDto.setExclusiveKey(iExcKey);
		arg.exclusiveKey = excDto;
		arg.fillReqMap = fillReqMap;
		arg.actionCd = actionCd;
		CsSheetEventResult result = CsSheetEventHandler.exec(arg);
		
		if (!CsUtil.isBlank(result.getResultMessage())) {
			// ホーム画面に遷移する場合もある(削除時)ため、Request/Sessionどちらにも入れる
			tray.request.setAttribute(AppSessionKey.RESULT_MSG_INFO, result.getResultMessage());
			tray.session.setAttribute(AppSessionKey.RESULT_MSG_INFO, result.getResultMessage());
		}
		if (!CsUtil.isBlank(result.getResultErrorMessage())) {
			// ホーム画面に遷移する場合もある(削除時)ため、Request/Sessionどちらにも入れる
			tray.request.setAttribute(AppSessionKey.RESULT_MSG_ERROR, result.getResultErrorMessage());
			tray.session.setAttribute(AppSessionKey.RESULT_MSG_ERROR, result.getResultErrorMessage());
		}
	}
	
	private void execStateMulti(Tray tray, UserInfoBean userInfo) throws CareerException {
		String actionCd = AU.getRequestValue(tray.request, "action_cd_multi");
		HashMap<String, String> checkedMap = CsUtil.getRequestsWithRegex(tray.request, "^multi_");
		for (String val : checkedMap.values()) {
			String[] d = val.split("#");
			String sheetId = d[0];
			String excKey = d[1];
			callCsSheetEvent(actionCd, tray, userInfo, sheetId, excKey);
		}
	}
}
