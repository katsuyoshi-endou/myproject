/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.hisas.career.app.sheet.dto.CsmSheetLayoutDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CSMシートレイアウト Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetLayoutDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " PARTY as party,"
                     + " LAYOUT_CD as layoutCd,"
                     + " VERSION as version,"
                     + " TEMPLATE_FILE as templateFile"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CsmSheetLayoutDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CsmSheetLayoutDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param party PARTY
     * @param layoutCd レイアウトコード
     * @param version バージョン
     * @return CsmSheetLayoutDto CSM_SHEET_LAYOUTのレコード型データ。
     */ 
    public CsmSheetLayoutDto select(String party, String layoutCd, String version) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CSM_SHEET_LAYOUT"
                         + " WHERE PARTY = ?"
                         + " AND LAYOUT_CD = ?"
                         + " AND VERSION = ?"
                         ;
        Log.sql("【DaoMethod Call】 CsmSheetLayoutDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, party);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, layoutCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, version);
            rs = pstmt.executeQuery();
            CsmSheetLayoutDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CsmSheetLayoutDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmSheetLayoutDto dto = new CsmSheetLayoutDto();
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setLayoutCd(DaoUtil.convertNullToString(rs.getString("layoutCd")));
        dto.setVersion(DaoUtil.convertNullToString(rs.getString("version")));
        dto.setTemplateFile(DaoUtil.convertNullToString(rs.getString("templateFile")));
        return dto;
    }

}

