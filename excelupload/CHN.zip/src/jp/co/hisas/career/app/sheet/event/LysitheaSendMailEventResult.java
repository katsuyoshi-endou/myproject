package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.VCstSheetActorAndRefDto;
import jp.co.hisas.career.ejb.AbstractEventResult;

@SuppressWarnings("serial")
public class LysitheaSendMailEventResult extends AbstractEventResult {

	private String resultMessage = null;
	private List<VCstSheetActorAndRefDto> actorList = null;
	private List<VCstSheetActorAndRefDto> refererList = null;

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage( String resultMessage ) {
		this.resultMessage = resultMessage;
	}

	public List<VCstSheetActorAndRefDto> getActorList() {
		return actorList;
	}

	public void setActorList( List<VCstSheetActorAndRefDto> actorList ) {
		this.actorList = actorList;
	}

	public List<VCstSheetActorAndRefDto> getRefererList() {
		return refererList;
	}

	public void setRefererList( List<VCstSheetActorAndRefDto> refererList ) {
		this.refererList = refererList;
	}

}