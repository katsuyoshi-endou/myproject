package jp.co.hisas.career.app.sheet.vm;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.ViewModel;
import jp.co.hisas.career.util.Tray;

public class VmVSHBLK extends ViewModel {

	public static String VMID = VmVSHBLK.class.getSimpleName();
	public Map<String, String> jotaiMap;

	public VmVSHBLK(Tray tray) throws CareerException {
		super( tray );
		this.prepareLabels();

	}

	private void prepareLabels() {
		List<String> l = new ArrayList<String>();
		l.add( "LSHBLK_TITLE" );
		l.add( "LSHBLK_RETURN_BTN" );
		l.add( "LSHBLK_KNSK_01" );
		l.add( "LSHBLK_KNSK_02" );
		l.add( "LSHBLK_KNSK_03" );
		l.add( "LSHBLK_KNSK_04" );
		l.add( "LSHBLK_KNSK_05" );
		l.add( "LSHBLK_KNSK_06" );
		l.add( "LSHBLK_KNSK_BTN" );
		l.add( "LSHBLK_BTN_010" );
		l.add( "LSHBLK_BTN_011" );
		l.add( "LSHBLK_BTN_012" );
		l.add( "LSHBLK_BTN_020" );
		l.add( "LSHBLK_BTN_021" );
		l.add( "LSHBLK_BTN_022" );
		l.add( "LSHBLK_BTN_023" );
		l.add( "LSHBLK_BTN_024" );
		l.add( "LSHBLK_BTN_030" );
		l.add( "LSHBLK_BTN_031" );
		l.add( "LSHBLK_BTN_032" );
		l.add( "LSHBLK_BTN_033" );
		l.add( "LSHBLK_BTN_034" );
		l.add( "LSHBLK_BTN_040" );
		l.add( "LSHBLK_BTN_041" );
		l.add( "LSHBLK_BTN_042" );
		l.add( "LSHBLK_BTN_050" );
		l.add( "LSHBLK_LIST_01" );
		l.add( "LSHBLK_LIST_02" );
		l.add( "LSHBLK_LIST_03" );
		l.add( "LSHBLK_LIST_04" );
		l.add( "LSHBLK_LIST_05" );
		l.add( "LSHBLK_LIST_06" );
		l.add( "LSHBLK_LIST_07" );
		l.add( "LSHBLK_LIST_08" );
		l.add( "LSHBLK_LIST_09" );
		l.add( "LSHBLK_ALERT_01" );
		l.add( "LSHBLK_ALERT_02" );
		l.add( "LSHBLK_ALERT_03" );
		l.add( "LSHBLK_CONFIRM_01" );
		l.add( "LSHBLK_CONFIRM_02" );
		l.add( "LSHBLK_MSG_EXCLUSIVE_ERR" );
		l.add( "LSHAWM_MSG_REASON_NEEDED" );
		l.add( "LSHAWM_MSG_REASON_OVERFLOW" );
		registerCommonLabels( l );
	}
}
