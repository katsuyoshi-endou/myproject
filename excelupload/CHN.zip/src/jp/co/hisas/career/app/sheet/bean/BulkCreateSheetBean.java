package jp.co.hisas.career.app.sheet.bean;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.dto.ZzUncreatedWkDto;
import jp.co.hisas.career.app.sheet.event.BulkCreateSheetEvArg;
import jp.co.hisas.career.app.sheet.event.BulkCreateSheetEvHdlr;
import jp.co.hisas.career.app.sheet.event.BulkCreateSheetEvRslt;
import jp.co.hisas.career.app.sheet.event.CsNewSheetEventArg;
import jp.co.hisas.career.app.sheet.event.CsNewSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.CsNewSheetEventResult;
import jp.co.hisas.career.app.sheet.vm.VmVSHBCR;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;

public class BulkCreateSheetBean {

	private String loginNo;
	private String operatorGuid;
	private HttpServletRequest request;
	private HttpSession session;

	public BulkCreateSheetBean( String loginNo, String operatorGuid) {
		this.loginNo = loginNo;
		this.operatorGuid = operatorGuid;
	}

	public BulkCreateSheetEvRslt execAction( String party, String state, final HttpServletRequest req ) throws CareerException {
		this.request = req;
		this.session = request.getSession( false );

		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( session, UserInfoBean.SESSION_KEY );
		this.operatorGuid = userInfo.getOperatorGuid();

		BulkCreateSheetEvRslt result = new BulkCreateSheetEvRslt();;

		if ( SU.matches( state, "INIT" )) {
			// 未作成者一覧リストの取得
			result = getUncreatedSheetList( state );
		} else if ( SU.matches( state, "BULK_CREATE" )) {
			result = createUncreatedSheet( party, state );
		}
		return result;
	}

	private BulkCreateSheetEvRslt getUncreatedSheetList( String state ) throws CareerException {

		VmVSHBCR vm = AU.getSessionAttr( session, VmVSHBCR.VMID );

		BulkCreateSheetEvArg arg = new BulkCreateSheetEvArg( this.loginNo );

		arg.sharp = "SEARCH";
		arg.operatorGuid = this.operatorGuid;
		arg.srchCondMap = vm.jotaiMap;
		arg.operationCd = vm.jotaiMap.get( "operationCd" );

		return  BulkCreateSheetEvHdlr.exec( arg );
	}

	private BulkCreateSheetEvRslt createUncreatedSheet( String party, String state ) throws CareerException {

		// リストに作成結果を書き込むため、作成前の状態で取得しておく
		BulkCreateSheetEvRslt result = getUncreatedSheetList( "SEARCH" );

		// 未作成者シートの作成
		VmVSHBCR vm = AU.getSessionAttr( session, VmVSHBCR.VMID );

		for ( String guid: vm.tgtGuids ) {
			CsNewSheetEventArg arg = new CsNewSheetEventArg( guid );
			arg.sharp       = "CREATE";
			arg.operationCd = vm.jotaiMap.get( "operationCd" );
			arg.formCd      = vm.jotaiMap.get( "formCd" );
			arg.party       = party;
			arg.ownGuid     = guid;

			// シート作成処理呼び出し（PL/SQL:BATCH_WEB_NEW_SHEET）
			CsNewSheetEventResult excRslt = CsNewSheetEventHandler.exec( arg );

			replaceCreatedStatusMsg( result.getSheetList(), guid, excRslt.exitCd );

			result.putBulkCreateResult( excRslt.exitCd );
		}
		return result;
	}

	private void replaceCreatedStatusMsg( List<ZzUncreatedWkDto> list, String guid, int exitCd ) {

		for ( ZzUncreatedWkDto item: list ) {
			if ( SU.matches( guid, item.getOwnGuid())) {
				item.setSheetStatus( String.valueOf( exitCd ));
				break;
			}
		}
	}
}
