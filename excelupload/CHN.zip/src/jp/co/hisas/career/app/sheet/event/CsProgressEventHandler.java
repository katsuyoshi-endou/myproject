package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dao.CsxSheetStatusProgressDao;
import jp.co.hisas.career.app.sheet.dao.VCsmOperationFlowDao;
import jp.co.hisas.career.app.sheet.dao.ZzUncreatedWkDao;
import jp.co.hisas.career.app.sheet.dto.CsxSheetStatusProgressDto;
import jp.co.hisas.career.app.sheet.dto.VCsmOperationFlowDto;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

public class CsProgressEventHandler extends AbstractEventHandler<CsProgressEventArg, CsProgressEventResult> {
	
	private String daoLoginNo;
	private boolean isActiveOnly;
	private boolean isBindedOnly;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static CsProgressEventResult exec( CsProgressEventArg arg ) throws CareerException {
		CsProgressEventHandler handler = new CsProgressEventHandler();
		return handler.call( arg );
	}
	
	public CsProgressEventResult call( CsProgressEventArg arg ) throws CareerException {
		CsProgressEventResult result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CsProgressEventResult execute( CsProgressEventArg arg ) throws CareerException {
		
		arg.validateArg();
		this.daoLoginNo = arg.getLoginNo();
		this.isActiveOnly = arg.isActiveOnly;
		this.isBindedOnly = arg.isBindedOnly;
		
		CsProgressEventResult result = new CsProgressEventResult();
		
		try {
			
			if ("INIT".equals( arg.sharp )) {
				
				Map<String, List<VCsmOperationFlowDto>> opeMap     = new LinkedHashMap<String, List<VCsmOperationFlowDto>>();
				Map<String, List<VCsmOperationFlowDto>> opeFgMap   = new LinkedHashMap<String, List<VCsmOperationFlowDto>>();
				Map<String, List<VCsmOperationFlowDto>> opeFgSgMap = new LinkedHashMap<String, List<VCsmOperationFlowDto>>();
				Map<String, List<VCsmOperationFlowDto>> fgMap;
				Map<String, List<VCsmOperationFlowDto>> sgMap;
				Map<String, List<VCsmOperationFlowDto>> stMap;
				
				HashMap<String, CsxSheetStatusProgressDto> sheetCountMap = new HashMap<String, CsxSheetStatusProgressDto>();
				HashMap<String, CsxSheetStatusProgressDto> sheetHoldMap  = new HashMap<String, CsxSheetStatusProgressDto>();
				
				Map<String, List<String>> opSets = new LinkedHashMap<String, List<String>>();
				Map<String, List<String>> fgSets = new LinkedHashMap<String, List<String>>();
				Map<String, List<String>> sgSets = new LinkedHashMap<String, List<String>>();
				Map<String, List<String>> stSets = new LinkedHashMap<String, List<String>>();
				Map <String, String> isFollowModeMap =  new HashMap <String, String>();
// ADD 2018/06/18 COMTURE VSHPRG_シート進捗 START
// MOD 2018/07/26 COMTURE phase6-8月リリース_CT_046 START
//				int uncreatedDisplay = 0;
				Map<String, Integer> uncreatedDisplay = new LinkedHashMap<String, Integer>();
// MOD 2018/07/26 COMTURE phase6-8月リリース_CT_046 END
				Map<String, Integer> uncreatedCount = new LinkedHashMap<String, Integer>();
// ADD 2018/06/18 COMTURE VSHPRG_シート進捗 END
				
				/* op > fg > sg > st */
				List<VCsmOperationFlowDto> flowRecs = getFlowRecs( arg );
				opeMap = AU.toMap( flowRecs, "operationCd" );
				opSets.put( arg.party, new ArrayList<String>( opeMap.keySet() ) );
				for (String opeCd : opeMap.keySet()) {
					List<VCsmOperationFlowDto> fgRecs = opeMap.get( opeCd );
					fgMap = AU.toMap( fgRecs, "formGrpCd" );
					fgSets.put( opeCd, new ArrayList<String>( fgMap.keySet() ) );
					for (String fgCd : fgMap.keySet()) {
						List<VCsmOperationFlowDto> sgRecs = fgMap.get( fgCd );
						opeFgMap.put( opeCd+fgCd, sgRecs );
						sgMap = AU.toMap( sgRecs, "statusGrpCd" );
						sgSets.put( opeCd+fgCd, new ArrayList<String>( sgMap.keySet() ) );
						for (String sgCd : sgMap.keySet()) {
							List<VCsmOperationFlowDto> stRecs = sgMap.get( sgCd );
							opeFgSgMap.put( opeCd+fgCd+sgCd, stRecs );
							stMap = AU.toMap( stRecs, "statusCd" );
							stSets.put( opeCd+fgCd+sgCd, new ArrayList<String>( stMap.keySet() ) );
						}
						List<CsxSheetStatusProgressDto> sheetCountList = getSheetCountEveryStatus( arg.guid, arg.party, opeCd, fgCd );
						for (CsxSheetStatusProgressDto dto : sheetCountList) {
							sheetCountMap.put( opeCd + fgCd + dto.getStatusCd(), dto );
						}
						List<CsxSheetStatusProgressDto> followCountList = getFollowCountEveryStatus( arg.guid, arg.party, opeCd, fgCd );
						for (CsxSheetStatusProgressDto dto : followCountList) {
							if (!(dto.getSheetCount() == 0)) {
								isFollowModeMap.put( opeCd, "true" );
							}
							sheetCountMap.put( opeCd + fgCd + dto.getStatusCd() + "follow", dto );
						}
						List<CsxSheetStatusProgressDto> sheetHoldList = getHoldCountEveryStatus( arg.guid, arg.party, opeCd, fgCd );
						for (CsxSheetStatusProgressDto dto : sheetHoldList) {
							sheetHoldMap.put( opeCd + fgCd + dto.getStatusCd(), dto );
						}
					}
// ADD 2018/07/26 COMTURE phase6-8月リリース_CT_046 START
					uncreatedDisplay.put(opeCd, getUncreatedDisplay(arg.guid, opeCd));
// ADD 2018/07/26 COMTURE phase6-8月リリース_CT_046 END
// ADD 2018/06/18 COMTURE VSHPRG_シート進捗 START
					uncreatedCount.put(opeCd, getUncreatedCount(arg.guid, opeCd));
// ADD 2018/06/18 COMTURE VSHPRG_シート進捗 END
				}
// DEL 2018/07/26 COMTURE phase6-8月リリース_CT_046 START
//// ADD 2018/06/18 COMTURE VSHPRG_シート進捗 START
//				uncreatedDisplay = getUncreatedDisplay(arg.guid);
//// ADD 2018/06/18 COMTURE VSHPRG_シート進捗 END
// DEL 2018/07/26 COMTURE phase6-8月リリース_CT_046 END
				
				result.opeMap        = opeMap;
				result.opeFgMap      = opeFgMap;
				result.opeFgSgMap    = opeFgSgMap;
				result.opSets        = opSets;
				result.fgSets        = fgSets;
				result.sgSets        = sgSets;
				result.stSets        = stSets;
				result.sheetCountMap = sheetCountMap;
				result.isFollowModeMap = isFollowModeMap;
				result.sheetHoldMap  = sheetHoldMap;
// ADD 2018/06/18 COMTURE VSHPRG_シート進捗 START
				result.uncreatedDisplay = uncreatedDisplay;
				result.uncreatedCount = uncreatedCount;
// ADD 2018/06/18 COMTURE VSHPRG_シート進捗 END
			}
			
			return result;
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
	}
	
	private List<VCsmOperationFlowDto> getFlowRecs( CsProgressEventArg arg ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + SU.addPrefixOnDaoAllCols( "V", VCsmOperationFlowDao.ALLCOLS ) );
		sql.append( "   from CSM_SHEET_OPERATION OPE " );
		if (this.isBindedOnly) {
			sql.append( "   inner join ( " );
			sql.append( "       SELECT DISTINCT SH.PARTY " );
			sql.append( "             ,SH.OPERATION_CD " );
			sql.append( "         FROM CST_SHEET SH " );
			sql.append( "              LEFT OUTER JOIN CST_SHEET_ACTOR ACT ON (ACT.SHEET_ID = SH.SHEET_ID AND ACT.ACTOR_CD <>'act-owner' AND ACT.GUID = ?) " );
			sql.append( "              LEFT OUTER JOIN CST_SHEET_ACTOR_REF REF ON(REF.SHEET_ID = SH.SHEET_ID AND REF.ACTOR_CD <>'act-owner' AND REF.GUID = ?) " );
			sql.append( "        WHERE (ACT.GUID IS NOT NULL OR REF.GUID IS NOT NULL) " );
// ADD 2018/07/26 COMTURE phase6-8月リリース_CT_046 START
			sql.append( "        UNION " );
			sql.append( "        SELECT PARTY,OPERATION_CD " ); 
			sql.append( "        FROM CSM_SHEET_OPERATION " );
			sql.append( "        WHERE OPERATION_CD like '%skill%' " );
			sql.append( "        AND PARTY = 'PANA' " );
			sql.append( "        AND OPEN_FLG = '1' " );
			sql.append( "        AND ACTIVE_FLG = '1' " );
			sql.append( "        AND (SELECT COUNT(1) FROM ZZ_CST_SHEET_ACTOR_AND_REF WHERE ACTOR_CD <> 'act-owner' AND GUID = ?)  > 0 " );
// ADD 2018/07/26 COMTURE phase6-8月リリース_CT_046 END
			sql.append( "   ) TGT " );
			sql.append( "     ON (TGT.PARTY = OPE.PARTY AND TGT.OPERATION_CD = OPE.OPERATION_CD) " );
		}
		sql.append( "       INNER JOIN V_CSM_OPERATION_FLOW V ON(V.PARTY = OPE.PARTY AND V.OPERATION_CD = OPE.OPERATION_CD) " );
		sql.append( "  where OPE.PARTY = ?  " );
		if (arg.operationCd != null) {
			sql.append( "    and OPE.OPERATION_CD = ? " );
		}
		if (this.isActiveOnly) {
			sql.append( "    and OPE.ACTIVE_FLG = '1' " );
		}
		if (SU.equals( arg.opeType, "STAMP" )) {
			sql.append( "    and OPE.OPERATION_TYPE = 'STAMP' " );
		}
		sql.append( "  order by V.OPE_SORT desc, SEQ_NO " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		if (this.isBindedOnly) {
			paramList.add( arg.guid );
			paramList.add( arg.guid );
// ADD 2018/07/26 COMTURE phase6-8月リリース_CT_046 START
			paramList.add( arg.guid );
// ADD 2018/07/26 COMTURE phase6-8月リリース_CT_046 END
		}
		paramList.add( arg.party );
		if (arg.operationCd != null) {
			paramList.add( arg.operationCd );
		}
		
		VCsmOperationFlowDao dao = new VCsmOperationFlowDao( this.daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}

	public static List<String> getFormCategoryList( String formGrpCd ) throws Exception {
		
		List<String> list = new ArrayList<String>();
		String ctg = formGrpCd.replaceAll( "^grp-", "ctg-" );
		list.add( ctg );
		
		return list;
	}
	
	private List<CsxSheetStatusProgressDto> getSheetCountEveryStatus( String guid, String party, String operationCd, String formGrpCd ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select F.PARTY as party, F.OPERATION_CD as operationCd, F.FORM_GRP_CD as formGrpCd, F.SEQ_NO as seqNo, F.STATUS_CD as statusCd, F.STATUS_NM as statusNm, CNT.SHEET_COUNT as sheetCount ");
		sql.append( " from V_CSM_OPERATION_FLOW F ");
		sql.append( "        left outer join ");
		sql.append( "        ( ");
		sql.append( "          select V.PARTY, V.OPERATION_CD, V.FORM_GRP_CD, V.STATUS_CD, count(A.SHEET_ID) as SHEET_COUNT ");
		sql.append( "          from (select distinct SHEET_ID from CST_SHEET_ACTOR A where GUID = ?) A ");
		sql.append( "               inner join V_CST_SHEET_INFO V ");
		sql.append( "                 on( V.SHEET_ID = A.SHEET_ID ) ");
		sql.append( "          where V.OWN_GUID <> ? "); // 自分のシートを除外
		sql.append( "          group by V.PARTY, V.OPERATION_CD, V.FORM_GRP_CD, V.STATUS_CD ");
		sql.append( "        ) CNT ");
		sql.append( "            on (CNT.PARTY        = F.PARTY ");
		sql.append( "            and CNT.OPERATION_CD = F.OPERATION_CD ");
		sql.append( "            and CNT.FORM_GRP_CD  = F.FORM_GRP_CD ");
		sql.append( "            and CNT.STATUS_CD    = F.STATUS_CD) ");
		sql.append( " where F.PARTY        = ? ");
		sql.append( "   and F.OPERATION_CD = ? ");
		sql.append( "   and F.FORM_GRP_CD  = ? ");
		if (this.isActiveOnly) {
		sql.append( "   and F.ACTIVE_FLG   = '1' ");
		}
		sql.append( " order by 1,2,3,4 ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( guid );
		paramList.add( guid );
		paramList.add( party );
		paramList.add( operationCd );
		paramList.add( formGrpCd );
		
		CsxSheetStatusProgressDao dao = new CsxSheetStatusProgressDao( this.daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<CsxSheetStatusProgressDto> getFollowCountEveryStatus( String guid, String party, String operationCd, String formGrpCd ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select F.PARTY as party, F.OPERATION_CD as operationCd, F.FORM_GRP_CD as formGrpCd, F.SEQ_NO as seqNo, F.STATUS_CD as statusCd, F.STATUS_NM as statusNm, CNT.SHEET_COUNT as sheetCount ");
		sql.append( " from V_CSM_OPERATION_FLOW F ");
		sql.append( "        left outer join ");
		sql.append( "        ( ");
		sql.append( "          select V.PARTY, V.OPERATION_CD, V.FORM_GRP_CD, V.STATUS_CD, count(R.SHEET_ID) as SHEET_COUNT ");
		sql.append( "          from (select distinct SHEET_ID, ACTOR_CD from CST_SHEET_ACTOR_REF R where GUID = ?) R ");
		sql.append( "               inner join V_CST_SHEET_INFO V ");
		sql.append( "                 on  ( V.SHEET_ID = R.SHEET_ID ");
		sql.append( "                 and   R.ACTOR_CD = 'ref-follow' ) "); // 自分のシートを除外しない
		sql.append( "          where exists ( select 'X' from CA_REGIST CP "); 
		sql.append( "                          where CP.FOLLOW_FLG = '1' ");
		sql.append( "                            and CP.MAIN_FLG = '1' ");
		sql.append( "                            and CP.GUID = V.OWN_GUID) ");
		sql.append( "          group by V.PARTY, V.OPERATION_CD, V.FORM_GRP_CD, V.STATUS_CD ");
		sql.append( "        ) CNT ");
		sql.append( "            on (CNT.PARTY        = F.PARTY ");
		sql.append( "            and CNT.OPERATION_CD = F.OPERATION_CD ");
		sql.append( "            and CNT.FORM_GRP_CD  = F.FORM_GRP_CD ");
		sql.append( "            and CNT.STATUS_CD    = F.STATUS_CD) ");
		sql.append( " where F.PARTY        = ? ");
		sql.append( "   and F.OPERATION_CD = ? ");
		sql.append( "   and F.FORM_GRP_CD  = ? ");
		if (this.isActiveOnly) {
		sql.append( "   and F.ACTIVE_FLG   = '1' ");
		}
		sql.append( " order by 1,2,3,4 ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( guid );
		paramList.add( party );
		paramList.add( operationCd );
		paramList.add( formGrpCd );
		
		CsxSheetStatusProgressDao dao = new CsxSheetStatusProgressDao( this.daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<CsxSheetStatusProgressDto> getHoldCountEveryStatus( String personId, String companyCd, String operationCd, String formGrpCd ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select V.PARTY as party, V.OPERATION_CD as operationCd, V.FORM_GRP_CD as formGrpCd, '-' as seqNo, V.STATUS_CD as statusCd, '-' as statusNm, count(A.SHEET_ID) as sheetCount ");
		sql.append( "   from CST_SHEET_ACTOR A ");
		sql.append( "        inner join V_CST_SHEET_INFO V ");
		sql.append( "          on( V.SHEET_ID = A.SHEET_ID ) ");
		sql.append( "   where V.PARTY        = ? ");
		sql.append( "     and V.OPERATION_CD = ? ");
		sql.append( "     and V.FORM_GRP_CD  = ? ");
		sql.append( "     and A.GUID         = ? and V.OWN_GUID <> ? "); // 自分のシートを除外
		sql.append( "     and V.HOLD_GUID    = ? ");
		sql.append( "   group by V.PARTY, V.OPERATION_CD, V.FORM_GRP_CD, V.STATUS_CD ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( companyCd );
		paramList.add( operationCd );
		paramList.add( formGrpCd );
		paramList.add( personId );
		paramList.add( personId );
		paramList.add( personId );
		
		CsxSheetStatusProgressDao dao = new CsxSheetStatusProgressDao( this.daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
// ADD 2018/06/18 COMTURE VSHPRG_シート進捗 START
// MOD 2018/07/26 COMTURE phase6-8月リリース_CT_046 START
//	private int getUncreatedDisplay( String operatorGuid) {
	private int getUncreatedDisplay( String operatorGuid, String operationCd) {
// MOD 2018/07/26 COMTURE phase6-8月リリース_CT_046 END

		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
// MOD 2018/07/26 COMTURE phase6-8月リリース_CT_046 START
//		sql.append( "select count('X') from ZZ_CST_SHEET_ACTOR_AND_REF " );
//		sql.append( " where GUID = ? " );
//		sql.append( "   and ACTOR_CD <> 'act-owner'" );
		sql.append( "select count('X') " );
		sql.append( " from ZZ_CST_SHEET_ACTOR_AND_REF AF " );
		sql.append( " , CSM_SHEET_OPERATION SO " );
		sql.append( " where AF.GUID = ? " );
		sql.append( " and AF.ACTOR_CD <> 'act-owner'" );
		sql.append( " and SO.OPERATION_CD like '%skill%' " );
		sql.append( " and SO.PARTY = 'PANA' " );
		sql.append( " and SO.OPERATION_CD = ? " );
		sql.append( " and SO.OPEN_FLG = '1' " );
		sql.append( " and SO.ACTIVE_FLG = '1' " );
// MOD 2018/07/26 COMTURE phase6-8月リリース_CT_046 END
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( operatorGuid );
// ADD 2018/07/26 COMTURE phase6-8月リリース_CT_046 START
		paramList.add( operationCd );
// ADD 2018/07/26 COMTURE phase6-8月リリース_CT_046 END
		
		ZzUncreatedWkDao dao = new ZzUncreatedWkDao( daoLoginNo );
		int count = dao.selectCountDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
		return count > 0 ? 1 : 0;
	}
	
	private int getUncreatedCount( String operatorGuid, String operationCd ) {


		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( "select count('X') " );
		sql.append( " from CA_REGIST CR " );
		sql.append( "   inner join PERSON_BELONG PB " );
		sql.append( "          on CR.STF_NO = PB.STF_NO " );
		sql.append( "          and CR.CMPA_CD = PB.CMPA_CD  " );
		sql.append( "   inner join DEPT " );
		sql.append( "          on PB.CMPA_CD = DEPT.CMPA_CD " );
		sql.append( "          and PB.DEPT_CD = DEPT.DEPT_CD " );
		sql.append( " where CR.GUID in (select distinct " );
		sql.append( "                     AF.OWN_GUID as GUID ");
		sql.append( "                   from ZZ_CST_SHEET_ACTOR_AND_REF AF " );
		sql.append( "                     , CSM_SHEET_OPERATION SO " );
		sql.append( "                   where AF.GUID = ? " );
		sql.append( "                     and AF.ACTOR_CD <> 'act-owner'" );
		sql.append( "                     and SO.OPERATION_CD like '%skill%' " );
		sql.append( "                     and SO.PARTY = 'PANA' " );
		sql.append( "                     and SO.OPERATION_CD = ? " );
		sql.append( "                     and SO.OPEN_FLG = '1' " );
		sql.append( "                     and SO.ACTIVE_FLG = '1' " );
		sql.append( "                     and not exists( " );
		sql.append( "                              select 1 " );
		sql.append( "                              from CST_SHEET CS " );
		sql.append( "                              where CS.OPERATION_CD = SO.OPERATION_CD " );
		sql.append( "                                and CS.PARTY = SO.PARTY " );
		sql.append( "                                and CS.OWN_GUID = AF.OWN_GUID" );
		sql.append( "                     )" );
		sql.append( "                  )" );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( operatorGuid );
		paramList.add( operationCd );
		
		ZzUncreatedWkDao dao = new ZzUncreatedWkDao( daoLoginNo );
		return dao.selectCountDynamic( DaoUtil.getPstmt( sql.toString(), paramList ) );
	}
// ADD 2018/06/18 COMTURE VSHPRG_シート進捗 END
	
}
