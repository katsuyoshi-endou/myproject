/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
package jp.co.hisas.career.app.sheet.bean;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.app.sheet.util.CareerSheetLabel;
import jp.co.hisas.career.app.sheet.util.CareerSheetParam;
import jp.co.hisas.career.app.sheet.util.CsMultiSheet;
import jp.co.hisas.career.app.sheet.util.CsSingleSheet;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.ejb.PZE_ExcelHanyoDownloadEJB;
import jp.co.hisas.career.ejb.PZE_ExcelHanyoDownloadEJBHome;
import jp.co.hisas.career.framework.EJBHomeFactory;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.CommonLabel;


/**
 * <PRE>
 * 
 * クラス名: PZE010_ExcelHanyoDownloadBean クラス
 * 機能説明: 帳票をExcel形式でダウンロードする。
 * 
 * </PRE>
 */
public class PZE010_ExcelHanyoDownloadBean {
	
	/** 定義シート名 */
	private static final String DEFINITION_SHEET_NAME = "def";
	
	/** 定義名開始文字 */
	private static final String START_CHAR_OF_DEF_NAME = "#";
	
	/** 置換対象文字 */
	private static final String REPLACE_TARGET_CHAR = "&";
	
	/** 最終文字 */
	private static final String LAST_CHAR = ";";
	
	/** ログインNo */
	private String loginNo = null;
	private String operatorGuid = null;
	
	/** 所有者人ID */
	public String ownPersonId = null;
	
	/** ワークブック */
	private Workbook workbook = null;
	
	/** 出力シート情報 */
	private HashMap<String, String> outputResultMap = new HashMap<String, String>();
	
	/** CareerSheet Single */
	public CsSingleSheet csSheet = null;
	public HashMap<String, String> csAttrMap = null;
	
	/** CareerSheet Multi */
	public List<VCsInfoAttrDto> multiCsDtoList = null;
	public HashMap<String, HashMap<String, String>> multiCsFillMap = null;
	public HashMap<String, HashMap<String, String>> multiCsFillMaskMap = null;
	
	
	/**
	 * コンストラクタ
	 * 
	 * @param login_no
	 */
	public PZE010_ExcelHanyoDownloadBean(String loginNo, String operatorGuid) {
		this.loginNo = loginNo;
		this.operatorGuid = operatorGuid;
	}


	/**
	 * 指定したファイルパスからテンプレートファイルを取得し、データを設定し
	 * ダウンロード処理を実行する。
	 * 
	 * @param path ファイルパス
	 * @param settingInfoMap 設定情報マップ
	 * @throws Exception
	 */
	public byte[] executeDownload(String filePath, Map<String, String> settingInfoMap) throws CareerException {
		
		Log.method(this.loginNo, "IN", "");
		
		// ダウンロード初期処理を行う
		initDownload(filePath);
		
		// 定義情報を取得する
		getDefinitionInfo(settingInfoMap);
		
		// 取得した定義情報を埋め込む
		setResultValueToTemplateSheet();
		
		// 出力ファイル情報を取得する
		byte[] outputFile = getOutputTargetFile(settingInfoMap);
		
		Log.method(this.loginNo, "OUT", "");
		
		return outputFile;
		
	}
	
	/**
	 * ダウンロード初期処理を実行する
	 * @param filePath テンプレートのファイルパス
	 */
	private void initDownload( String filePath ) throws CareerException {
		FileInputStream inputStream = null;
		String excptMsg;
		try {
			Log.method( this.loginNo, "IN", "" );
			
			// テンプレートファイルを読込む
			inputStream = new FileInputStream( filePath );
			
			// エクセルファイルに変換
			this.workbook = WorkbookFactory.create( inputStream );
			
			Log.method( this.loginNo, "OUT", "" );
		} catch (FileNotFoundException fnfe) {
			Log.error( this.loginNo, fnfe );
			excptMsg = CommonLabel.getLabel("LSHSHT_MSG_OUT_TEMPLATE_NOT_EXIST");
			throw new CareerException( excptMsg );
		} catch (IOException ioe) {
			Log.error( this.loginNo, ioe );
			excptMsg = CommonLabel.getLabel("LSHSHT_MSG_TEMPLATE_TYPE_NOT_EXCEL");
			throw new CareerException( excptMsg );
		} catch (InvalidFormatException ife) {
			Log.error( this.loginNo, ife );
			excptMsg = CommonLabel.getLabel("LSHSHT_MSG_TEMPLATE_TYPE_NOT_EXCEL");
			throw new CareerException( excptMsg );
		} catch (IllegalArgumentException iae) {
			Log.error( this.loginNo, iae );
			excptMsg = CommonLabel.getLabel("LSHSHT_MSG_TEMPLATE_TYPE_NOT_EXCEL");
			throw new CareerException( excptMsg );
		} catch (Exception e) {
			Log.error( this.loginNo, e );
			throw new CareerException( e.getMessage() );
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException io) {
				}
			}
		}
	}
	
	/**
	 * 定義シートの記載内容から出力データマップにデータを追加する
	 * 
	 * @param settingInfoMap 設定情報マップ
	 * @exception CareerException
	 */
	private void getDefinitionInfo(Map<String, String> settingInfoMap) throws CareerException {
		
		try {
			Log.method(this.loginNo, "IN", "");
			
			// 定義シートオブジェクトの取得 
			Sheet sheet = workbook.getSheet(DEFINITION_SHEET_NAME);
			// A列:Key、B列:isSingleItem、C列:Value
			ArrayList<String[]> rowList = this.getAllCellTextInSheet(sheet, 3);
			
			for (int i=0; i<rowList.size(); i++) {
				
				String[] columns = rowList.get(i);
				String defKey = columns[0]; // 定義名
				String defFlg = columns[1]; // 単一項目:○
				String defSQL = columns[2]; // 定義SQL
				
				// "#Key"形式の場合DBからデータを取得し出力データマップにデータを追加
				if (defKey != null && START_CHAR_OF_DEF_NAME.equals(defKey.substring(0,1))) {
					
					// SQL生成
					String replacedDefContent = this.replaceParameterToValue(defSQL, settingInfoMap);
					String mapKey = defKey.substring(1);
					boolean isSingleItem = !(defFlg == null || "".equals(defFlg)); // B列が空白でなければ単一項目
					
					// DBからデータを取得
					Log.transaction(this.loginNo, true , "");
					HashMap<String, String> resultMap = this.getResultMapByTargetSql(replacedDefContent, mapKey, isSingleItem);
					Log.transaction(this.loginNo, false , "");
					
					outputResultMap.putAll(resultMap);
				}
			}
			
			// 設定情報マップも出力データマップに入れる
			outputResultMap.putAll( settingInfoMap );
			
			Log.method(this.loginNo, "OUT", "");
		} catch (SQLException sqle) {
			String sqlErrorMsg = "CPM-RZE010-E006";
			sqlErrorMsg = sqlErrorMsg.replaceAll( "\\Q" + "{0}" + "\\E", sqle.getMessage() );
			throw new CareerException(sqlErrorMsg);
		} catch (Exception e) {
			Log.error("", e);
			throw new CareerException( "CPM-RZE010-E006" );
		}
	}


	/**
	 * シートに記載されたデータを、String形式で行のリスト・列の配列に変換して返す。
	 * 
	 * @param sheet シートオブジェクト
	 * @param endColumnNo 読み取り最終列(データが存在する列すべてを対象とする場合は 0 を指定)
	 * @return
	 */
	private ArrayList<String[]> getAllCellTextInSheet(Sheet sheet, int endColumnNo) {
		
		// 行のリスト・列の配列
		ArrayList<String[]> rowList = new ArrayList<String[]>();
		boolean isColmunsLimited = (endColumnNo > 0); 
		
		// 行ループ
		for (Row row : sheet) {
			String[] colmuns = new String[endColumnNo];
			// 列ループ
			for (Cell cell : row) {
				int colIndex = cell.getColumnIndex();
				if ( isColmunsLimited && (colIndex > endColumnNo-1) ) {
					break;
				}
				if (cell != null) {
					if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
						colmuns[colIndex] = cell.getRichStringCellValue().toString();
					}
				}
			}
			rowList.add(colmuns);
		}
		
		return rowList;
	}


	/**
	 * 定義内容の情報を置換対象文字列から始まる文字列を設定情報の
	 * キーとし、それに紐づく値を定義内容に置換する。
	 * 
	 * @param defContent 定義情報
	 * @param settingInfoMap 設定情報
	 * @return 置換後の定義内容
	 * @exception Exception
	 */
	private String replaceParameterToValue(String defContent, Map<String, String> settingInfoMap) throws Exception {
		
		try {
		
			Log.method(this.loginNo, "IN", "");
			
			// 定義内容を空白文字区切りで取得
			StringTokenizer st = new StringTokenizer(defContent, " ");
			
			StringBuffer newSb = new StringBuffer();
			
			while (st.hasMoreTokens()) {
				String tempStr = st.nextToken();
				StringBuffer sb = new StringBuffer(tempStr);
				int firstTargeCharIndex = sb.indexOf(REPLACE_TARGET_CHAR);
				int lastCharIndex = sb.indexOf(LAST_CHAR);
				
				String mapKey = null;
				String replaceValue = null;
				
				// 区切られた文字列に置換対象文字列が入っている場合
				if (firstTargeCharIndex != -1) {
					
					// 最終文字に";"が入っている場合
					if (lastCharIndex != -1) {
						mapKey = sb.substring(firstTargeCharIndex, lastCharIndex);
					} else {
						mapKey = sb.substring(firstTargeCharIndex);
					}
					
					// 取得した設定キーで値を取得する
					replaceValue = (String)settingInfoMap.get(mapKey);
					
					if (replaceValue == null) {
						replaceValue = "''";
					} else {
						replaceValue = "'" + replaceValue + "'";
					}
					// 置換処理
					if (lastCharIndex != -1) {
						sb.replace(firstTargeCharIndex, sb.length(), replaceValue);
					} else {
						sb.replace(firstTargeCharIndex, sb.length(), replaceValue);
					}
				}
				// 置換後の定義内容を作成
				newSb.append(sb.toString() + " ");
			}
			
			Log.method(this.loginNo, "OUT", "");
			
			return newSb.toString();
			
		} catch (Exception e) {
			Log.error("", e);
			throw e;
		}
	}


	/**
	 * 生成したSQLを元に、DBから情報を取得する。
	 * 	<dl>※戻り値のキーについて
	 * 		<dt>isSingleItem: true</dt><dd>→ "defKey"</dd>
	 * 		<dt>isSingleItem: false</dt><dd>→ "defKey_ColNm_1" (※ColNm: targetSQLのSELECT句のAS)</dd>
	 * 	</dl>
	 * 
	 * @param targetSql 対象のSQL
	 * @param mapKey 定義名(#含まない)
	 * @param isSingleItem 単一項目かどうか
	 * @return resultMap 取得結果
	 * @throws SQLException
	 * @throws Exception
	 */
	private HashMap<String, String> getResultMapByTargetSql(String targetSql, String mapKey, boolean isSingleItem) throws SQLException, Exception {
		
		Log.method(this.loginNo, "IN", "");
		
		// 定義ファイルシート情報を取得
		// EJBHomeの取得
		EJBHomeFactory fact = EJBHomeFactory.getInstance();
		PZE_ExcelHanyoDownloadEJBHome home = (PZE_ExcelHanyoDownloadEJBHome) fact.lookup(PZE_ExcelHanyoDownloadEJBHome.class);
		
		// EJBObjectの取得
		PZE_ExcelHanyoDownloadEJB userSession = home.create();
		
		// DBから対象の情報を取得する
		HashMap<String, String> resultMap = userSession.getResultMapByTargetSql(loginNo, targetSql, mapKey, isSingleItem);
		
		Log.method(this.loginNo, "OUT", "");
		
		return resultMap;
	}
	
	private void setResultValueToTemplateSheet() throws CareerException {
		try {
			Log.method(this.loginNo, "IN", "");
			
			/*
			 *  ◆注意◆
			 *  上記テンプレートシートの取得を実行した時点で、行ループの最終行を確定している。
			 *  これから行う処理のうち &Loop のように処理中の行を越えて埋め込みをする場合、
			 *  それが事前に確定した最終行より下まで到達するとエラーが発生する。
			 */
			for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
				Sheet sheet = workbook.getSheetAt( i );
				for (Row row : sheet) {
					for (Cell cell : row) {
						cellProcess( sheet, cell );
					}
				}
			}
			
			Log.method(this.loginNo, "OUT", "");
			
		} catch (ConcurrentModificationException e) {
			// Do nothing.
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		}
	}
	
	private void cellProcess( Sheet sheet, Cell cell ) throws Exception {
		String cellValue = null;
		int cellType = cell.getCellType();
		
		// セルタイプが文字列の場合
		if (cellType == Cell.CELL_TYPE_STRING) {
			cellValue = cell.getStringCellValue();
			
			// テキストの始まりが定義名開始文字(=#)で始まっている場合
			if (cellValue.startsWith(START_CHAR_OF_DEF_NAME)) {
				String defName = cellValue.substring(1); // #を除去して格納
				
				// マップキー存在フラグ
				boolean existKeyFlg = false;
				
				boolean isReplaceMode = defName.startsWith("&PZ") ||
										defName.startsWith("&Fill--") ||
										defName.startsWith("&Label--") ||
										defName.startsWith("&Param--") ||
										defName.startsWith("&Attr--") ||
										defName.startsWith("&Actor--") ||
										defName.startsWith("&MkPr--") ||
										defName.startsWith("&MkPrD--") ||
										defName.startsWith("&Loop$");
				
				// 置換対象文字(&)開始マップキーが一致→セルに値をセット
				if ( isReplaceMode ) {
					String defValue = getDefValue( sheet, cell, defName );
					if (defValue != null) {
						cell.setCellValue( defValue );
					}
					existKeyFlg = true;
				}
				
				// マップのキーを取得
				Set<String> defKeySet = outputResultMap.keySet();
				Iterator<String> defItr = defKeySet.iterator();
				
				// 出力データマップ(定義SQLで取得したもの＋設定情報マップ)に含まれているものかどうかを見て
				while (defItr.hasNext()) {
					Object key = defItr.next();
					String keyValue = key.toString();
					if (defName.startsWith(REPLACE_TARGET_CHAR) && defName.substring(1).equals(keyValue)) {
						String defValue = (String) outputResultMap.get(keyValue);
						cell.setCellValue(defValue);
						existKeyFlg = true;
					}
				}
				
				// マップに情報がなかった場合
				if (!existKeyFlg) {
					cell.setCellValue("");
				}
			}
		}
	}
	
	private String getDefValue( Sheet sheet, Cell cell, String defName ) throws Exception {
		String defValue = "";
		String[] defArr = defName.split("--");
		if (defName.startsWith("&Label--")) {
			// CareerSheet シートラベル 例: #&Label--AttrClsCNm
			String labelId = defName.replaceAll( "^&Label--", "" );
			defValue = CareerSheetLabel.getLabel( csSheet.labelSetCd, labelId );
			defValue = SU.nvl( defValue, "" ); // nullだと定義記述が残る(Loopのため)
		}
		if (defName.startsWith("&Param--")) {
			// CareerSheet シートパラメータ 例: #&Param--weight
			String paramId = defName.replaceAll( "^&Param--", "" );
			defValue = CareerSheetParam.getParam( csSheet.paramSetCd, paramId );
			defValue = SU.nvl( defValue, "" ); // nullだと定義記述が残る(Loopのため)
		}
		if (defName.startsWith("&Attr--")) {
			// CareerSheet シート属性データ 例: #&Attr--getOwnPersonId()
			String key = defArr[1];
			defValue = csAttrMap.get( "Attr--" + key );
			defValue = SU.nvl( defValue, "" ); // nullだと定義記述が残る(Loopのため)
		}
		if (defName.startsWith("&Actor--")) {
			// CareerSheet シートアクター情報 例: #&Actor--actr-rater-1st--PersonName
			String actorCd  = defArr[1];
			String infoType = defArr[2];
			defValue = csSheet.getActorInfo( actorCd, infoType );
			defValue = SU.nvl( defValue, "" ); // nullだと定義記述が残る(Loopのため)
		}
		if (defName.startsWith("&Fill--")) {
			// CareerSheet 回答データ 例: #&Fill--careerstep_genzai
			String fillId = defName.replaceAll( "^&Fill--", "" );
			defValue = CsUtil.getFillContent( csSheet.fillMap, csSheet.fillMaskMap, fillId );
			defValue = SU.nvl( defValue, "" ); // nullだと定義記述が残る(Loopのため)
		}
		if (defName.startsWith("&Loop$")) {
			// Multi CareerSheet シートID付加 例: #&LoopFill--careerstep_genzai
			String _key = defName.replaceAll( "^&Loop\\$", "" );
			boolean isFill = _key.matches( "^Fill--.*$");
			boolean isInfo = _key.matches( "^Info--.*$");
			boolean isActor = _key.matches( "^Actor--.*$");
			int rowIdx = cell.getRowIndex();
			int colIdx = cell.getColumnIndex();
			if (this.multiCsDtoList.size() == 0) {
				// 定義記述を空白で上書き
				return "";
			}
			else if (isFill) {
				String fillId = _key.replaceAll( "^Fill--", "" );
				for (int i=0; i<this.multiCsDtoList.size(); i++) {
					VCsInfoAttrDto dto = this.multiCsDtoList.get( i );
					String cellValue = CsMultiSheet.getFillContentStatic( this.operatorGuid, dto, multiCsFillMap, fillId, multiCsFillMaskMap );
					updateCell( i, sheet, rowIdx, colIdx, cellValue );
				}
			}
			else if (isInfo) {
				String infoMethod = _key.replaceAll( "^Info--", "" );
				infoMethod = infoMethod.replaceAll( "\\(\\)", "" );
				for (int i=0; i<this.multiCsDtoList.size(); i++) {
					VCsInfoAttrDto dto = this.multiCsDtoList.get( i );
					Method[] methods = dto.getClass().getDeclaredMethods();
					String methodReturn = null;
					for (Method method : methods) {
						if (method.getName().matches( infoMethod )) {
							methodReturn = (String)method.invoke( dto );
							break;
						}
					}
					updateCell( i, sheet, rowIdx, colIdx, methodReturn );
				}
			}
			else if (isActor) {
				String args = _key.replaceAll( "^Actor--", "" );
				String[] argArr = args.split( "--" );
				for (int i=0; i<this.multiCsDtoList.size(); i++) {
					VCsInfoAttrDto dto = this.multiCsDtoList.get( i );
					CsSingleSheet cs = new CsSingleSheet();
					cs.loginNo = this.loginNo;
					cs.sheetId = dto.getSheetId();
					String cellValue = cs.getActorInfo( argArr[0], argArr[1] );
					updateCell( i, sheet, rowIdx, colIdx, cellValue );
				}
			}
			// if defValue is NOT null, the cell will be overwrited.
			defValue = null;
		}
		return defValue;
	}

	private Row styleRow = null;
	private void updateCell( int i, Sheet sheet, int rowIdx, int colIdx, String cellValue ) {
		Row _row = sheet.getRow( rowIdx + i );
		_row = (_row == null) ? sheet.createRow( rowIdx + i ) : _row;
		if (i == 0) {
			styleRow = _row;
		}
		Cell _cell = _row.getCell( colIdx );
		_cell = (_cell != null) ? _cell : _row.createCell( colIdx );
		_cell.setCellStyle( styleRow.getCell( colIdx ).getCellStyle() );
		_cell.setCellValue( cellValue );
	}

	/**
	 * ファイルを出力する。
	 * 
	 * @param settingInfoMap 設定情報マップ
	 * @exception CareerException
	 */
	private byte[] getOutputTargetFile(Map<String, String> settingInfoMap) throws CareerException {
		
		ByteArrayOutputStream byteOutStream = null;
		
		try {
			Log.method(this.loginNo, "IN", "");
			
			// 定義シートを削除する
			int defSheetIndex = workbook.getSheetIndex(DEFINITION_SHEET_NAME);
			workbook.removeSheetAt(defSheetIndex);
			
			// ファイルの出力
			byteOutStream = new ByteArrayOutputStream();
			workbook.write(byteOutStream);
			
			Log.method(this.loginNo, "OUT", "");
			
			return byteOutStream.toByteArray();
		
		} catch (Exception e) {
			Log.error("", e);
			throw new CareerException( "CPM-RZE010-E006" );
			
		} finally {
			
			if (byteOutStream != null) {
				try {
					byteOutStream.close();
				} catch (IOException io) {
					
				}
			}
		}
	}


}
