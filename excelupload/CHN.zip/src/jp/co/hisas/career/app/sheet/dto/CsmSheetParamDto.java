/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSMシートパラメータ Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetParamDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PARAM_SET_CD
     */
    private String paramSetCd;
    /**
     * PARAM_ID
     */
    private String paramId;
    /**
     * PARAM_VALUE
     */
    private String paramValue;

    /**
     * PARAM_SET_CDを取得する。
     * @return PARAM_SET_CD
     */
    public String getParamSetCd() {
        return paramSetCd;
    }

    /**
     * PARAM_SET_CDを設定する。
     * @param paramSetCd PARAM_SET_CD
     */
    public void setParamSetCd(String paramSetCd) {
        this.paramSetCd = paramSetCd;
    }

    /**
     * PARAM_IDを取得する。
     * @return PARAM_ID
     */
    public String getParamId() {
        return paramId;
    }

    /**
     * PARAM_IDを設定する。
     * @param paramId PARAM_ID
     */
    public void setParamId(String paramId) {
        this.paramId = paramId;
    }

    /**
     * PARAM_VALUEを取得する。
     * @return PARAM_VALUE
     */
    public String getParamValue() {
        return paramValue;
    }

    /**
     * PARAM_VALUEを設定する。
     * @param paramValue PARAM_VALUE
     */
    public void setParamValue(String paramValue) {
        this.paramValue = paramValue;
    }

}

