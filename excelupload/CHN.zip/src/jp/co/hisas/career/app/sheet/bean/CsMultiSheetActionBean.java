package jp.co.hisas.career.app.sheet.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.app.sheet.event.CsSheetEventArg;
import jp.co.hisas.career.app.sheet.event.CsSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.CsSheetEventResult;
import jp.co.hisas.career.app.sheet.util.CsMultiSheet;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.property.CommonLabel;

public class CsMultiSheetActionBean {
	
	private String loginNo;
	private String operatorGuid;
	private HttpServletRequest request;
	private HttpSession session;
	
	CsMultiSheet csMultiSheet;
	LinkedHashMap<String, String> chkResultMsgMap = new LinkedHashMap<String, String>();
	HashMap<String, List<String>> ngFillIdListMap = new HashMap<String, List<String>>();
	String resultMessage = "";
	
	public CsMultiSheetActionBean(String loginNo, String operatorGuid) {
		this.loginNo = loginNo;
		this.operatorGuid = operatorGuid;
	}
	
	public void execMultiSheetAction( String state, final HttpServletRequest req ) throws CareerException {
		
		this.request = req;
		this.session = request.getSession( false );
		
		String sheetIdArray = request.getParameter( "sheetIdArray" );
		ArrayList<String> sheetIdList = CsUtil.toArrayList( sheetIdArray );
		
		csMultiSheet = AU.getSessionAttr( session, CsSessionKey.CS_MULTI_SHEET );
		HashMap<String, VCsInfoAttrDto> multiCsDtoMap = new HashMap<String, VCsInfoAttrDto>();
		for (VCsInfoAttrDto dto : csMultiSheet.multiCsList) {
			multiCsDtoMap.put( dto.getSheetId(), dto );
		}
		for (String sheetId : sheetIdList) {
			VCsInfoAttrDto sheetDto = multiCsDtoMap.get( sheetId );
			execOneSheetAction( state, sheetDto );
		}
		session.setAttribute( "ngFillIdListMap", this.ngFillIdListMap );
		if (chkResultMsgMap.size() > 0) {
//			String ngMsg = "保存了输入内容，但是有检查ＮＧ的表单。";
			String ngMsg = CommonLabel.getLabel("LSHSHT_MSG_CHK_NG_SHEET_EXIST");
			for (String msg : chkResultMsgMap.keySet()) {
				ngMsg += "<br>・" + msg;
			}
			session.setAttribute( AppSessionKey.RESULT_MSG_WARN, ngMsg );
		}
		else if (!CsUtil.isBlank( resultMessage )) {
			session.setAttribute( AppSessionKey.RESULT_MSG_INFO, resultMessage );
		}
	}
	
	public void execOneSheetAction( String sharp, VCsInfoAttrDto sheetDto ) throws CareerException {
		
		String sheetId = sheetDto.getSheetId();
		
		// Requestの中から (SheetId)--Fill-- で始まるもののみを抽出
		HashMap<String, String> fillReqMap = CsUtil.getFillRequestsForMulti( request, sheetId );
		
		// 差戻し系アクションのときは入力チェックをしない
		if ( !(SU.matches( sharp, "BACKWARD|RESUME" )) ) {
			/* 入力チェック <Msg, NgFills> */
			HashMap<String, List<String>> checkResult = this.csMultiSheet.checkRequestFills( sheetDto, request, fillReqMap );
			if (checkResult.size() > 0) {
				// Msgだけ格納(どのシートに対するものかはメッセージでは明確にしない)
				for (String msg : checkResult.keySet()) {
					this.chkResultMsgMap.put( msg, msg );
				}
				// Msg関係なくNGのFillIdをマージしてシートIDをキーにして格納
				List<String> mergedNgFillIdList = new ArrayList<String>();
				for (List<String> ngFillIdList : checkResult.values()) {
					mergedNgFillIdList.addAll( ngFillIdList );
				}
				this.ngFillIdListMap.put( sheetId, mergedNgFillIdList );
				// ステータス変更せずに保存だけ行う
				sharp = "STAY";
			}
		}
		
		/* Sheet Action */
		CsSheetEventArg arg = new CsSheetEventArg( this.loginNo, this.operatorGuid );
		arg.sharp = sharp;
		UserInfoBean userInfo = AU.getSessionAttr( session, UserInfoBean.SESSION_KEY );
		arg.mailSenderName = userInfo.getKanjiSimei();
		arg.sheetId = sheetId;
		CstSheetExclusiveDto excDto = new CstSheetExclusiveDto();
		excDto.setSheetId( sheetId );
		excDto.setExclusiveKey( sheetDto.getExclusiveKey() );
		arg.exclusiveKey = excDto;
		arg.fillReqMap = fillReqMap;
		arg.actionCd = sharp;
		CsSheetEventResult result = CsSheetEventHandler.exec( arg );
		
		/* After Process */
		this.resultMessage = result.getResultMessage();
		String resultErrMsg  = result.getResultErrorMessage();
		if (resultErrMsg != null) {
//			this.chkResultMsgMap.put( resultErrMsg + "（社員番号: " + sheetDto.getOwnGuid() + "）", "" );
			String msg = CommonLabel.getLabel("LSHSHT_MSG_GLOBAL_ID").replace("{0}", sheetDto.getOwnGuid());
			this.chkResultMsgMap.put( resultErrMsg + msg, "" );
		}
	
	}
}
