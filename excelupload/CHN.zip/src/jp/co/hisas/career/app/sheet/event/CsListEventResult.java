package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.VCstSheetListDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetUnifyListDto;
import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

@SuppressWarnings("serial")
public class CsListEventResult extends AbstractEventResult {

	private String resultMessage = null;
	private List<ValueTextSortDto> divList = null;
	private List<ValueTextSortDto> opeList = null;
	public List<ValueTextSortDto> staList = null;
	private List<VCstSheetUnifyListDto> unifyDtoList = null;
	private List<VCstSheetListDto> singleDtoList = null;

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage( String resultMessage ) {
		this.resultMessage = resultMessage;
	}

	public List<ValueTextSortDto> getDivList() {
		return divList;
	}

	public void setDivList( List<ValueTextSortDto> divList ) {
		this.divList = divList;
	}

	public List<ValueTextSortDto> getOpeList() {
		return opeList;
	}

	public void setOpeList( List<ValueTextSortDto> opeList ) {
		this.opeList = opeList;
	}

	public List<VCstSheetUnifyListDto> getUnifyDtoList() {
		return unifyDtoList;
	}

	public void setUnifyDtoList( List<VCstSheetUnifyListDto> unifyDtoList ) {
		this.unifyDtoList = unifyDtoList;
	}

	public List<VCstSheetListDto> getSingleDtoList() {
		return singleDtoList;
	}

	public void setSingleDtoList( List<VCstSheetListDto> singleDtoList ) {
		this.singleDtoList = singleDtoList;
	}

}