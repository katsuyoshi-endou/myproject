
var ingSheetId = "";
var ingExcKey = "";
$(function(){
   /**
   ** Initialize
  **/
  $('select[name="actorCd"]').val(actorCd);
  FixedMidashi.create();

  // FORWARDボタンを青色に
  $('.csActionBtns [data-actioncd="FORWARD"], .csActionBtns [data-actioncd="SKIP"]').each(function(){
    var $self = $(this);
    if ( $self.hasClass('btn') ) {
      $self.addClass('btn-secondary');
    }
  });
   
   /**
   ** Event
  **/
  $(document).on('click', '#transCSMLTI', function(){
    pageSubmit('/servlet/CsMultiSheetServlet', 'RESTORE');
  });

  $(document).on('click', '#RELOAD', function(){
    pageSubmit('/servlet/MultiEditGymknServlet', 'SHOW');
  });

  $(document).on('click', '.modaledit', function(){
    // Editing target
    ingSheetId = $(this).attr('data-sheetid');
    ingExcKey = $(this).attr('data-exclusivekey');

    var dataIdx = Number($(this).attr('data-idx'));
    
    // Modal style
    var leftPos = ($(document).width() / 2) - 425;
    var topPos  = 50;
    $('#modal-overlay').show();
    $('#modal-window').empty();
    var ingSheet = _data["list"][dataIdx];
    var ingLabelSetCd = ingSheet.infoAttrDto.labelSetCd;
    var ingLabel = _data["sheetLabelSet"][ingLabelSetCd];
    usTemplateRenderModal('#us-template-MultiEditGymknModal', '#us-render-MultiEditGymknModal', {sheet: ingSheet, label: ingLabel} );
    $('#modal-window').append( $('.modal-body-src').html() );
    loadFills(dataIdx);
    $('#modal-window').css('left', leftPos+'px').css('top', topPos+'px').show();

    styleModal();

    // 自動計算
    if ($('.autoCalcSKill').exists()) {
      autoCalcWeightSkill();
    }
    $(document).on( 'blur', 'input.autoCalcSKill', function(){
      autoCalcWeightSkill();
    });
  });

  $(document).on('click', '#modal-overlay, #modal-window .close', function(){
    $('#modal-window').hide();
    $('#modal-overlay').hide();
  });

  $(document).on('click', '#modal-submit-btn', function(){
    if (!checkOnSave()){
      return false;
    }
    makeRequestParameter('edited_sheet_id', ingSheetId);
    makeRequestParameter('exclusive_key', ingExcKey);
    pageSubmit('/servlet/MultiEditGymknServlet', 'SAVE');
  });
  
  $(document).on('click', '.csActionBtns button', function(){
    var actionCd = $(this).attr('data-actioncd');
    execSheetAction(actionCd, false);
  });

  $(document).on( 'blur', '.weight input', function(){
    $(this).val( pretty0to100( $(this).val() ) );
  });

  //Modalの大きさを表示画面によって変更
  $(window).on('load resize', function(){
    styleModal();
  });

});

function execSheetAction(actionCd, fromModal) {
  if (!checkOnAction(actionCd)) {
    return false;
  }
  if (actionCd === 'AWAY' && !fromModal) {
    toggleCsReasonModal(actionCd);
    return false;
  }
  var msg = getActionMessage(actionCd);
  if (msg && !confirm(msg)) {
    return false;
  }
  // 対象に戻すのは確認メッセージOK後。リクエストパラメータが残ってしまうため。
  if (actionCd === 'RESUME' && _data["showingStcd"] === "99-End" && !fromModal) {
    makeRequestParameter("Fill--change_status_reason", "");
    makeRequestParameter("Fill--change_status_reason_text", "");
  }

  $('#MultiEditGymkn .checkbox :checkbox:checked').each(function(i,el){
    makeRequestParameter('multi_'+i, $(el).attr('data-sheetidexckey'));
  });
  makeRequestParameter('action_cd_multi', actionCd);
  pageSubmit('/servlet/MultiEditGymknServlet', 'MULTI');
}

function styleModal(){
  var heightM = $(document).height() * 0.92;
  var heightB = heightM - 170;
  $('#modal-window').css('height', heightM+'px' );
  $('#modal-window .modal-body ').css('height', heightB+'px' );

  var leftPos = ($(document).width() / 2) - 425;
  $('#modal-window').css('left', leftPos+'px');
}

function getActionMessage(clickedActionCd) {
  var $tr = $($('#MultiEditGymkn .checkbox :checkbox:checked')[0]).closest('tr');
  var idx = $tr.attr('data-idx');
  var actionObj = _.find(_data["list"][idx].actionList, function(d){
    return d.actionCd === clickedActionCd;
  });
  return actionObj.confirmMsg;
}

function checkOnSave() {
  var isCheckOk = true;
  // 担当業務必須チェック
  $area = $('#modal-window');
  $area.find('.tantoChk .chkNG').removeClass('chkNG');
  $area.find('.skill_wght_sum_rslt .error').removeClass('error');

  if (_.isEmpty($area.find('.tantoChk').val())){
    $area.find('.tantoChk').addClass("chkNG");
    alert("担当業務を選択してください。");
    isCheckOk = false;
  }
  if(isCheckOk){
    // ウェイト合計100%チェック
    var wght_sum = $area.find('.skill_wght_sum_rslt').text();
    var sumErrorFlg = false;
    if (_.isEmpty(wght_sum)) {
      sumErrorFlg = true;
    } else {
      wght_sum = new Decimal(wght_sum);
    }
    if (wght_sum != 100) {
      sumErrorFlg = true;
    }
    if(sumErrorFlg){
      $area.find('.skill_wght_sum_rslt').addClass("error");
      alert("ウェイト合計が100%になるようにウェイトを入力してください。");
      isCheckOk = false;
    }
  }
  return isCheckOk;
}

function needsCheck(fillId) {
  var $tr = $($('#MultiEditGymkn .checkbox :checkbox:checked')[0]).closest('tr');
  var idx = $tr.attr('data-idx');

  var fmm = _data["list"][idx].fillMaskMap;
  var maskArr = _.map(Object.keys(fmm), function(k){ return {fillId: k, maskVal: fmm[k]} });
  var writeMaskArr = _.filter(maskArr, function(d){ return d.maskVal === "write"; });
  var writeFillList = _.map(writeMaskArr, function(m){ return "Fill--"+m.fillId; });

  return $.inArray( fillId, writeFillList ) != -1;
}

function checkOnAction(actionCd) {
  $('#MultiEditGymkn .error').removeClass('error');

  var isCheckOk = true;

  // 操作対象シート未選択
  if ($('#MultiEditGymkn .checkbox :checkbox:checked').size() === 0 ) {
    alert("操作対象のシートが選択されていません。");
    return false;
  }

  if (actionCd == "FORWARD") {
    if (needsCheck("Fill--chk_necessary_gymkn")) {
      // チェックしたものの担当業務未入力
      var tantoChkOk = true;
      var tantoErrIdxes = [];
      $('#MultiEditGymkn .checkbox :checkbox:checked').each(function(i, el){
        var $tr = $(el).closest('tr');
        var idx = $tr.attr('data-idx');
        if (_.isEmpty($tr.find('.listTanto').text()) ){
          tantoErrIdxes.push(idx);
          tantoChkOk = false;
          isCheckOk = false;
        }
      });
      if (!tantoChkOk) {
        alert("担当業務を選択してください。");
      }
      _.each(tantoErrIdxes, function(i){
        $tr = $("#MultiEditGymkn table tr[data-idx='" + i + "']");
        $tr.find('.listTanto').addClass("error");
      });

      if (isCheckOk){
        // チェックしたもののウェイト合計未入力
        var weightSumChkOk = true;
        var weightErrIdxes = [];
        $('#MultiEditGymkn .checkbox :checkbox:checked').each(function(i, el){
          var $tr = $(el).closest('tr');
          var idx = $tr.attr('data-idx');
          if (_.isEmpty($tr.find('.listWeightSum').text()) ){
            weightErrIdxes.push(idx);
            weightSumChkOk = false;
            isCheckOk = false;
          }
        });
        if (!weightSumChkOk) {
          alert("ウェイトを入力してください。");
        }
        _.each(weightErrIdxes, function(i){
          $tr = $("#MultiEditGymkn table tr[data-idx='" + i + "']");
          $tr.find('.listWeightSum').addClass("error");
        });
      }
    }
  }
  return isCheckOk;
}

function autoCalcWeightSkill(){
  var weightSum = 0;
  $area = $('#modal-window');
  $area.find('.skill_wght_sum_tgt').each(function(i,e){
    var num = Number($(e).val());
    weightSum = weightSum + num;
  })
  if (weightSum == 0){
    $area.find(".skill_wght_sum_rslt").text("");
  } else {
    $area.find(".skill_wght_sum_rslt").text(weightSum);
  }
}

function loadFills(dataIdx) {
  var fillMap = _data["list"][dataIdx].fillMap;
  var newFillMap = {};
  _.each(Object.keys(fillMap), function(k){ newFillMap["Fill--"+k] = fillMap[k]; })
  var fmm = _data["list"][dataIdx].fillMaskMap;
  var maskArr = _.map(Object.keys(fmm), function(k){ return {fillId: k, maskVal: fmm[k]} });
  var readMaskArr = _.filter(maskArr, function(d){ return d.maskVal === "read"; });
  var writeMaskArr = _.filter(maskArr, function(d){ return d.maskVal === "write"; });
  var readFillList = _.map(readMaskArr, function(m){ return "Fill--"+m.fillId; });
  var writeFillList = _.map(writeMaskArr, function(m){ return "Fill--"+m.fillId; });
  var pdList = _data["list"][dataIdx].layoutPdList;
  makePulldowns(pdList);
  makeFills(newFillMap, readFillList, writeFillList);
}

function makeFills(_fillMap, _readFillList, _writeFillList) {
  // サーバから取得したfillContentでinput/textareaに埋め込み :: Fill & NestFill
  $('textarea[name*="Fill--"]').each(function(){
    var elemName = $(this).prop('name');
    $(this).val( _fillMap[elemName] );
  });
  $('input[name*="Fill--"]').each(function(){
    var elemName = $(this).prop('name');
    var elemType = $($(this)[0]).attr('type');
    if (elemType === 'radio') {
      $(this).val( [ _fillMap[elemName] ] );
    } else if (elemType === 'checkbox') {
      var isChecked = 'on' === _fillMap[elemName];
      $(this).prop( 'checked', isChecked );
    } else {
      $(this).val( _fillMap[elemName] );
    }
  });
  $('select[name*="Fill--"]').each(function(){
    var elemName = $(this).prop('name');
    $(this).val( _fillMap[elemName] );
  });
  
  // 入力エリアをReadOnlyに
  for (var i=0; i<_readFillList.length; i++) {
    try {
      var elem = "*[name='" + _readFillList[i] + "']";
      var elemTag = $(elem)[0].tagName;
      var elemType = $(elem).attr('type');
      var elemContent = getReadOnlyContent(elem, elemTag);
      if (elemType === 'checkbox') {
        $(elem).prop('disabled', true);
        $(elem).attr('data-mask', 'read');
      } else {
        $(elem).replaceWith( elemContent );
      }
    } catch (e) {
    }
  }
  // 上記ReadOnly処理後に残った入力エリアがwriteリストになければReadOnlyに :: Fill
  $('*[name*="Fill--"]').each(function(){
    var elemType = $(this).attr('type');
    if (elemType === 'checkbox') {
      // チェックボックスはReadモード( data-mask: read )として残される。
      // そのため、ここに到達した場合にマスクNULLのものだけを取り除いている。
      var elemName = $(this).prop('name');
      var elemTag  = $(this)[0].tagName;
      var isWriteFill = $.inArray( elemName, _writeFillList );
      var mask = $(this).attr('data-mask');
      if (mask === 'read') {
        // Keep
      } else {
        if (-1 == isWriteFill) {
          if ($(this).siblings('i').exists()) {
            $(this).closest('.checkbox').remove();
          } else {
            $(this).remove();
          }
        } else {
          // Write mode (do nothing)
        }
      }
    } else {
      var elemName = $(this).prop('name');
      var elemTag  = $(this)[0].tagName;
      var elemContent = getReadOnlyContent(this, elemTag);
      var isWriteFill = $.inArray( elemName, _writeFillList );
      if (-1 == isWriteFill) {
        $(this).replaceWith( elemContent );
      }
    }
  });
}

function makePulldowns(pdList) {
  var cspd = {};
  _.each(Object.keys(pdList), function(k){
    var options = pdList[k];
    var converted = _.map(options, function(o){ return {value: o.pdValue, text: o.pdText}; });
    cspd[k] = converted;
  });
  _.each(cspd, function(data, key){
    _.each(data, function(obj, i){
      var optionElems = $('<option>', obj);
      $('select[data-pulldown="'+key+'"]').append(optionElems);
    });
  });
}

function usTemplateRenderModal(fromSelector, toSelector, dataSet) {
  _.templateSettings = {
    evaluate    : /\{\{(.+?)\}\}/g,
    interpolate : /\{\{=(.+?)\}\}/g,
    escape      : /\{\{-(.+?)\}\}/g
  };
  try {
    var compiled = _.template( $(fromSelector).html() );
    $(toSelector).html( compiled(dataSet) );
  } catch(e) {
    console.warn( "Unable to compile the template." );
    console.error( e );
  }
}


///////////////////////////////////////////////////

function toInt( str ) {
  if (!str.match(/^[0-9]+$/)) {
    return "";
  }
  if (_.isEmpty( str )) {
    return "";
  }
  var num = Number( str );
  if (_.isNaN( num )) {
    return "";
  }
  return Math.floor( num );
}

function isInt0to100( str ) {
  var num = Number( str );
  if (_.isNaN( num )) {
    return false;
  }
  if (num == 100) {
    return true;
  }
  if (!!num.toString().match(/^[0-9]?[0-9]$/)) {
    return true;
  }
  return false;
}

function pretty0to100( val ) {
  val = FHConvert.ftoh( val )
  if (_.isEmpty( val )) { return ""; }
  var num = toInt( val );
  if (num === '' || num < 0 || 100 < num) {
    alert("0～100の整数で入力して下さい。");
    return "";
  } else if (isInt0to100( num )) {
    return num;
  } else {
    return "";
  }
}

function getReadOnlyContent(jqObj, tagName) {
  var elemContent;
  if (tagName == 'TEXTAREA') {
    elemContent = $(jqObj).val();
  } else if (tagName == 'INPUT') {
    elemContent = $(jqObj).val();
  } else if (tagName == 'SELECT') {
    elemContent = $(':selected', jqObj).text();
  }
  return escapeHTML(elemContent);
}

function escapeHTML(text) {
  return String(text)
    .replace(/&/g, '&amp;')//&(?!\w+;)
    .replace( /</g, "&lt;" )
    .replace( />/g, "&gt;" )
    .replace( /\n/g, "<br>" )
    .replace( /"/g, "&quot;" )//"
    .replace( /'/g, "&#39;" )//'
    .replace( /^$/g, "&nbsp;" );// add space when blank for replaceWith
}