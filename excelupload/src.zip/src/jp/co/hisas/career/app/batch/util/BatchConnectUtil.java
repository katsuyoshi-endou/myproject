package jp.co.hisas.career.app.batch.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import jp.co.hisas.career.app.batch.util.property.HcdbDef;

@SuppressWarnings({ "rawtypes" })
public class BatchConnectUtil {

	private static String JDBC_CONNECTION = "BATCH_JDBC_CONNECTION";

	private static String JDBC_USER = "BATCH_JDBC_USER";

	private static String JDBC_PASS = "BATCH_JDBC_PASSWORD";

	static public Connection getConnetcion() throws SQLException, Exception {

		try {
			Class.forName( HcdbDef.ORACLE_DRIVER );

//			final HashMap map = ReadFile.careerProperties;
//			final String jdbc_connect = ( String ) map.get( BatchUtil.JDBC_CONNECTION );
//			final String jdbc_user = ( String ) map.get( BatchUtil.JDBC_USER );
//			final String jdbc_pass = ( String ) map.get( BatchUtil.JDBC_PASS );

//			final String jdbc_connect = "jdbc:oracle:thin:@10.230.82.186:1521:ORCL";
			final String jdbc_connect = "jdbc:oracle:thin:@192.168.11.16:1521:ORCL";
			final String jdbc_user = "LYSH";
			final String jdbc_pass = "LYSH";

			final Connection dbConnection = DriverManager.getConnection( jdbc_connect, jdbc_user, jdbc_pass );

			return dbConnection;
		} catch ( final SQLException e ) {
			throw e;
		} catch ( final Exception e ) {
			throw e;
		}
	}

	static public void closeConnection( final Connection conn, final Statement stmt, final ResultSet rs ) throws SQLException {
		try {
			if ( rs != null ) {
				rs.close();
			}

			if ( stmt != null ) {
				stmt.close();
			}

			if ( conn != null ) {
				conn.close();
			}
		} catch ( final Exception e ) {
			throw e;
		}
	}

	static public void closeConnection( final Connection conn, final Statement stmt ) throws SQLException {
		BatchConnectUtil.closeConnection( conn, stmt, null );
	}

	static public void closeconnection( final Connection conn ) throws SQLException {
		BatchConnectUtil.closeConnection( conn, null, null );
	}

	static public void rollbackConnection( final Connection conn ) throws SQLException {
		try {
			conn.rollback();
		} catch ( final SQLException e ) {
			throw e;
		}
	}

	static public void commitConnection( final Connection conn ) throws SQLException {
		try {
			conn.commit();
		} catch ( SQLException e ) {
			throw e;
		}
	}

	static public PreparedStatement getStatement( Connection conn, String sql, List<String> paramList ) throws SQLException {

		PreparedStatement stmt = null;

		try {
			stmt = conn.prepareStatement( sql );

			for ( int i = 0; i < paramList.size(); i++ ) {
				String param = paramList.get( i );
				if ( param == null ) {
					stmt.setNull(i + 1, 12 );
				} else {
					stmt.setString( i + 1, paramList.get( i ));
				}
			}
		} catch ( SQLException e ) {
			throw e;
		}
		return stmt;
	}
}
