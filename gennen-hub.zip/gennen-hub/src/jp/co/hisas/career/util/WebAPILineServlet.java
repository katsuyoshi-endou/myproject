package jp.co.hisas.career.util;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.http.HTTPException;

import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.framework.exception.CareerSecurityException;
import jp.co.hisas.career.util.log.Log;

public abstract class WebAPILineServlet extends HttpServlet {
	
	protected ServletContext ctx = null;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	public static void forDebug( HttpServletRequest req, HttpServletResponse res ) {
		if (AU.isDebugMode()) {
			String origin = req.getHeader( "Origin" );
			res.setHeader( "Access-Control-Allow-Origin", origin );
			res.setHeader( "Access-Control-Allow-Headers", "Content-Type" );
			res.setHeader( "Access-Control-Allow-Methods", "GET, POST, PUT, DELETE" );
		}
	}
	
	public static void writeJsonResponse( HttpServletRequest req, HttpServletResponse res, int status, String json ) throws IOException {
		forDebug( req, res );
		res.setHeader( "Access-Control-Allow-Credentials", "true" );
		res.setContentType( "application/json" );
		res.setCharacterEncoding( "UTF-8" );
		res.setStatus( status );
		res.getWriter().write( SU.ntb( json ) );
	}
	
	public void doOptions( HttpServletRequest req, HttpServletResponse res ) throws ServletException, IOException {
		AU.systemReady();
		forDebug( req, res );
		res.setHeader( "Access-Control-Allow-Credentials", "true" );
	}
	
	public void doGet( final HttpServletRequest req, final HttpServletResponse res ) throws IOException, ServletException {
		try {
			Line line = new Line( req, res );
			
			Log.method( line.tracer, "IN", "" );
			Log.performance( line.tracer, true, "" );
			
			line.checkToken();
			
			String json = doGetMain( line );
			writeJsonResponse( req, res, 200, json );
			
			/* Keep Token for random order access */
			
			Log.performance( line.tracer, false, "" );
			Log.method( line.tracer, "OUT", "" );
			
		} catch (final CareerBusinessException e) {
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, 403, json );
			
		} catch (final CareerSecurityException e) {
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, 403, json );
			
		} catch (final HTTPException e) {
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, e.getStatusCode(), json );
			
		} catch (final Exception e) {
			Log.error( req, e );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, 500, json );
		}
	}
	
	public abstract String doGetMain( Line line ) throws Exception;
	
	public void doPost( HttpServletRequest req, HttpServletResponse res ) throws ServletException, IOException {
		try {
			Line line = new Line( req, res );
			
			Log.method( line.tracer, "IN", "" );
			Log.performance( line.tracer, true, "" );
			
			CSRFTokenUtil.checkTokenNo( line.request );
			
			String json = doPostMain( line );
			writeJsonResponse( req, res, 200, json );
			
			/* Keep Token for random order access */
			
			Log.performance( line.tracer, false, "" );
			Log.method( line.tracer, "OUT", "" );
			
		} catch (final CareerBusinessException e) {
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, 403, json );
			
		} catch (final CareerSecurityException e) {
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, 403, json );
			
		} catch (final HTTPException e) {
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, e.getStatusCode(), json );
			
		} catch (final Exception e) {
			Log.error( req, e );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, 500, json );
		}
	}
	
	public abstract String doPostMain( Line line ) throws Exception;
	
	public void doPut( HttpServletRequest req, HttpServletResponse res ) throws ServletException, IOException {
		try {
			Line line = new Line( req, res );
			
			Log.method( line.tracer, "IN", "" );
			Log.performance( line.tracer, true, "" );
			
			CSRFTokenUtil.checkTokenNo( line.request );
			
			String json = doPutMain( line );
			writeJsonResponse( req, res, 200, json );
			
			/* Keep Token for random order access */
			
			Log.performance( line.tracer, false, "" );
			Log.method( line.tracer, "OUT", "" );
			
		} catch (final CareerBusinessException e) {
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, 403, json );
			
		} catch (final CareerSecurityException e) {
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, 403, json );
			
		} catch (final HTTPException e) {
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, e.getStatusCode(), json );
			
		} catch (final Exception e) {
			Log.error( req, e );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, 500, json );
		}
	}
	
	public abstract String doPutMain( Line line ) throws Exception;
	
	public void doDelete( HttpServletRequest req, HttpServletResponse res ) throws ServletException, IOException {
		try {
			Line line = new Line( req, res );
			
			Log.method( line.tracer, "IN", "" );
			Log.performance( line.tracer, true, "" );
			
			CSRFTokenUtil.checkTokenNo( line.request );
			
			String json = doDeleteMain( line );
			writeJsonResponse( req, res, 200, json );
			
			/* Keep Token for random order access */
			
			Log.performance( line.tracer, false, "" );
			Log.method( line.tracer, "OUT", "" );
			
		} catch (final CareerBusinessException e) {
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, 403, json );
			
		} catch (final CareerSecurityException e) {
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, 403, json );
			
		} catch (final HTTPException e) {
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, e.getStatusCode(), json );
			
		} catch (final Exception e) {
			Log.error( req, e );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			writeJsonResponse( req, res, 500, json );
		}
	}
	
	public abstract String doDeleteMain( Line line ) throws Exception;
}
