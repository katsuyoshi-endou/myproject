package jp.co.hisas.career.app.career.deliver;

import java.io.IOException;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;

import com.google.gson.Gson;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class RequestReceiver implements Serializable {
	
	/**
	 * HTTPメソッド GET / DELETE のパラメータ (QueryString) を読み取る
	 */
	public static <T> T readParams( Line line, Class<T> cls ) {
		Gson gson = new Gson();
		Map<String, String> params = readRequestQueryString( line );
		String json = gson.toJson( params );
		T order = gson.fromJson( SU.bvl( json, "{}" ), cls );
		return order;
	}
	
	public static <T> T readParams( Tray tray, Class<T> cls ) throws CareerException {
		return readParams( tray.getLine(), cls );
	}
	
	private static Map<String, String> readRequestQueryString( Line line ) {
		Map<String, String> map = new HashMap<String, String>();
		@SuppressWarnings("rawtypes")
		Enumeration names = line.request.getParameterNames();
		while (names.hasMoreElements()) {
			String name = (String)names.nextElement();
			map.put( name, AU.getRequestValue( line.request, name ) );
		}
		return map;
	}
	
	/**
	 * jQueryのAjax機能で POST / PUT されたリクエストのデータを読み取る
	 */
	public static <T> T readBodyViaJQuery( Line line, Class<T> cls ) {
		Gson gson = new Gson();
		Map<String, String> params = line.convertPostRequestBodyToMap();
		String json = gson.toJson( params );
		T order = gson.fromJson( SU.bvl( json, "{}" ), cls );
		return order;
	}
	
	/**
	 * Axiosなど標準的なHTTPクライアントで POST / PUT されたリクエストのデータを読み取る
	 */
	public static <T> T readBodyAsJson( Line line, Class<T> cls ) {
		Gson gson = new Gson();
		String json = getRequestBody( line );
		T order = gson.fromJson( SU.bvl( json, "{}" ), cls );
		return order;
	}
	
	public static <T> T readBodyAsJson( Tray tray, Class<T> cls ) throws CareerException {
		return readBodyAsJson( tray.getLine(), cls );
	}
	
	private static String getRequestBody( Line line ) {
		try {
			return IOUtils.toString( line.request.getInputStream(), "UTF-8" );
		} catch (IOException e) {
			return null;
		}
	}
}
