package jp.co.hisas.career.app.career.event;

import jp.co.hisas.career.app.common.unit.PasswordUnit;
import jp.co.hisas.career.app.common.unit.PasswordUnitIn;
import jp.co.hisas.career.app.common.unit.PasswordUnitOut;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.log.Log;

public class PasswordEvHdlr extends AbstractEventHandler<PasswordEvArg, PasswordEvRslt> {
	
	public static PasswordEvRslt exec( PasswordEvArg arg ) throws CareerException {
		PasswordEvHdlr handler = new PasswordEvHdlr();
		return handler.call( arg );
	}
	
	public PasswordEvRslt call( PasswordEvArg arg ) throws CareerException {
		return this.callEjb( arg );
	}
	
	protected PasswordEvRslt execute( PasswordEvArg arg ) throws CareerException {
		Log.method( arg.getLoginNo(), "IN", "" );
		arg.validateArg();
		String daoLoginNo = arg.getLoginNo();
		PasswordEvRslt result = new PasswordEvRslt();
		try {
			
			if (SU.equals( "CHECK", arg.sharp )) {
				
				PasswordUnitIn in = new PasswordUnitIn( daoLoginNo );
				in.pid = arg.pid;
				in.newPassword = arg.newPassword;
				PasswordUnitOut out = PasswordUnit.check( in );
				
				result.rules = out.rules;
			}
			else if (SU.equals( arg.sharp, "CHANGE_PASSWORD" )) {
				
				PasswordUnitIn in = new PasswordUnitIn( daoLoginNo );
				in.sign = arg.sign;
				in.newPassword = arg.newPassword;
				PasswordUnitOut out = PasswordUnit.changePassword( in );
				
				result.isSuccess = out.isSuccess;
			}
			else if (SU.equals( "PREPARE_TOKEN", arg.sharp )) {
				
				PasswordUnitIn in = new PasswordUnitIn( daoLoginNo );
				in.sign = arg.sign;
				in.email = arg.email;
				PasswordUnitOut out = PasswordUnit.prepareToken( in );
				
				result.isCheckOK = out.isCheckOK;
			}
			else if (SU.equals( "CONFIRM_TOKEN", arg.sharp )) {
				
				PasswordUnitIn in = new PasswordUnitIn( daoLoginNo );
				in.token = arg.token;
				PasswordUnitOut out = PasswordUnit.confirmToken( in );
				
				result.isVerifyOK = out.isVerifyOK;
				result.sign = out.sign;
			}
			
			return result;
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
	}
	
}
