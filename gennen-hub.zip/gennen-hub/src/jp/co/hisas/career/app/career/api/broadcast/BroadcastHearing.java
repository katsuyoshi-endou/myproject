package jp.co.hisas.career.app.career.api.broadcast;

import jp.co.hisas.career.app.career.deliver.RequestReceiver;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.framework.exception.CareerSecurityException;
import jp.co.hisas.career.util.SU;

public class BroadcastHearing extends RequestReceiver {
	
	public String title;
	public String desc;
	
	public void validate() throws CareerBusinessException {
		if (SU.length( title ) > 100) {
			throw new CareerSecurityException( "MaxLength is 100. " + "[attentionTitle]" );
		}
		if (SU.length( desc ) > 500) {
			throw new CareerSecurityException( "MaxLength is 500. " + "[attentionDesc]" );
		}
	}
}
