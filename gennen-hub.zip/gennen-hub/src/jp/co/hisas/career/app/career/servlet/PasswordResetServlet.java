package jp.co.hisas.career.app.career.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import jp.co.hisas.career.app.career.api.password.change.PasswordChangeHearing;
import jp.co.hisas.career.app.career.deliver.PasswordDeliver;
import jp.co.hisas.career.app.career.deliver.PasswordOrder;
import jp.co.hisas.career.app.career.deliver.RequestReceiver;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.NoTokenRedirectServlet;
import jp.co.hisas.career.util.Tray;

public class PasswordResetServlet extends NoTokenRedirectServlet {
	
	private static final long serialVersionUID = 1L;
	protected ServletContext ctx = null;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	public String serviceMain( Tray tray ) throws IOException, ServletException {
		String fPath = null;
		try {
			PasswordChangeHearing h = RequestReceiver.readParams( tray, PasswordChangeHearing.class );
			PasswordOrder o = new PasswordOrder( tray );
			o.sign = h.sign;
			o.email = h.email;
			boolean isCheckOK = PasswordDeliver.prepareTokenForResetPassword( o );
			if (isCheckOK) {
				fPath = "/app/password/reset-accepted";
			}
			else {
				fPath = "/app/password/reset-rejected";
			}
		} catch (CareerException e) {
			e.printStackTrace();
		}
		return fPath;
	}
}
