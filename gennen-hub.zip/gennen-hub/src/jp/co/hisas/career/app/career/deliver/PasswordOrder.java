package jp.co.hisas.career.app.career.deliver;

import jp.co.hisas.career.app.common.deliver.DeliveryOrder;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.Tray;

public class PasswordOrder extends DeliveryOrder {
	
	public String sign;
	public String email;
	
	public String token;
	
	public int pid;
	public String newPassword;
	
	public PasswordOrder(Tray tray) throws CareerException {
		super( tray );
	}
	
	public PasswordOrder(Line line) throws CareerException {
		super( line );
	}
	
	public void validate() throws CareerBusinessException {
	}
}
