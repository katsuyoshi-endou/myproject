package jp.co.hisas.career.app.career.service;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import jp.co.hisas.career.app.common.service.df.CcpLabelEvArg;
import jp.co.hisas.career.app.common.service.df.CcpLabelEvHdlr;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.cache.HtmlTemplateCache;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.property.CommonLabel;

public class BroadcastService {
	
	public static Map<String, String> get( BroadcastOrder o ) throws CareerException {
		
		HashMap<String, String> map = new HashMap<String, String>();
		
		String attTitle = CommonLabel.getLabel( o.party, "Hub.Attention.Title" );
		String attDesc = CommonLabel.getLabel( o.party, "Hub.Attention.Desc" );
		
		map.put( "attention-title", attTitle );
		map.put( "attention-desc", attDesc );
		map.put( "signage", getSignage( o.party ) );
		
		return map;
	}
	
	private static String getSignage( String party ) {
		String templateId = "signage/signage";
		if (SU.isNotBlank( party )) {
			templateId = "signage/signage-" + party;
		}
		return HtmlTemplateCache.getTemplate( templateId );
	}
	
	public static void change( BroadcastOrder o ) throws CareerException {
		
		changeLabel( o.tracer, o.party, "Hub.Attention.Title", o.attentionTitle );
		changeLabel( o.tracer, o.party, "Hub.Attention.Desc", o.attentionDesc );
		
		/* ラベルキャッシュ リフレッシュ */
		Connection conn;
		try {
			conn = PZZ040_SQLUtility.getConnection( "" );
			CommonLabel.find( conn );
			PZZ040_SQLUtility.close( conn );
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void changeLabel( String tracer, String party, String labelId, String labelText ) throws CareerException {
		CcpLabelEvArg arg = new CcpLabelEvArg( tracer );
		arg.sharp = "CHANGE";
		arg.party = party;
		arg.labelId = labelId;
		arg.labelText = labelText;
		CcpLabelEvHdlr.exec( arg );
	}
}
