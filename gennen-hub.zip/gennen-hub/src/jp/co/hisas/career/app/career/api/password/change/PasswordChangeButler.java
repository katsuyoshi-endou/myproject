package jp.co.hisas.career.app.career.api.password.change;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.ws.http.HTTPException;

import jp.co.hisas.career.app.career.api.Butler;
import jp.co.hisas.career.app.career.deliver.PasswordDeliver;
import jp.co.hisas.career.app.career.deliver.PasswordOrder;
import jp.co.hisas.career.app.career.deliver.RequestReceiver;
import jp.co.hisas.career.app.career.service.SessionService;
import jp.co.hisas.career.app.common.bean.UserBean;
import jp.co.hisas.career.app.common.unit.PasswordUnit.PasswordRule;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerSecurityException;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.SU;

public class PasswordChangeButler extends Butler {
	
	@Override
	public String takeGET( Line line ) throws CareerException {
		
		PasswordChangeHearing h = RequestReceiver.readParams( line, PasswordChangeHearing.class );
		h.validate();
		
		PasswordOrder o = new PasswordOrder( line );
		o.pid = line.getUser().getPid();
		o.newPassword = h.newPassword;
		List<PasswordRule> rules = PasswordDeliver.checkNewPassword( o );
		return SU.toJson( rules );
	}
	
	@Override
	public String takePOST( Line line ) throws CareerException {
		
		PasswordChangeHearing h = RequestReceiver.readBodyAsJson( line, PasswordChangeHearing.class );
		
		UserBean user = line.getUser();
		if (user == null) {
			throw new CareerSecurityException( "UserBean not found." );
		}
		
		PasswordOrder o = new PasswordOrder( line );
		o.sign = user.getSign();
		o.pid = user.getPid();
		o.newPassword = h.newPassword;
		boolean isSuccess = PasswordDeliver.changePassword( o );
		
		// パスワード変更直後に強制ログアウトする。
		// ・ブラウザバックから再度変更できてしまう
		// ・ブラウザの記憶しているパスワードを更新するチャンスを逃す
		SessionService.logout( line );
		
		Map<String, String> map = new HashMap<String, String>();
		map.put( "success", isSuccess ? "true" : "false" );
		return SU.toJson( map );
	}
	
	@Override
	public String takePUT( Line line ) throws CareerException {
		throw new HTTPException( 405 );
	}
	
	@Override
	public String takeDELETE( Line line ) throws CareerException {
		throw new HTTPException( 405 );
	}
}
