package jp.co.hisas.career.app.career.api.session;

import javax.xml.ws.http.HTTPException;

import jp.co.hisas.career.app.career.api.Butler;
import jp.co.hisas.career.app.career.service.SessionService;
import jp.co.hisas.career.app.common.bean.UserBean;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.SU;

public class SessionButler extends Butler {
	
	@Override
	public String takeGET( Line line ) throws CareerException {
		UserBean user = SessionService.getUser( line );
		return SU.toJson( user );
	}
	
	@Override
	public String takePOST( Line line ) throws CareerException {
		throw new HTTPException( 405 );
	}
	
	@Override
	public String takePUT( Line tray ) throws CareerException {
		throw new HTTPException( 405 );
	}
	
	@Override
	public String takeDELETE( Line tray ) throws CareerException {
		throw new HTTPException( 405 );
	}
}
