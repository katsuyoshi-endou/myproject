package jp.co.hisas.career.app.career.event;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class PasswordEvArg extends AbstractEventArg {
	
	public String sharp = null;
	
	public String party;
	public String sign;
	public String email;
	
	public String token;
	
	public int pid;
	public String newPassword;
	
	public PasswordEvArg(String loginNo) throws CareerException {
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		if (SU.isBlank( sharp )) {
			throw new CareerException( "Invalid PasswordEvArg: sharp is null." );
		}
	}
	
}
