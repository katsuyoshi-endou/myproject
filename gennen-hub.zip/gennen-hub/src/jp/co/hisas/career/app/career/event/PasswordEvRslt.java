package jp.co.hisas.career.app.career.event;

import java.util.List;

import jp.co.hisas.career.app.common.unit.PasswordUnit.PasswordRule;
import jp.co.hisas.career.ejb.AbstractEventResult;

public class PasswordEvRslt extends AbstractEventResult {
	
	public boolean isCheckOK;
	public boolean isVerifyOK;
	public boolean isSuccess;
	public String sign;
	public List<PasswordRule> rules;
}
