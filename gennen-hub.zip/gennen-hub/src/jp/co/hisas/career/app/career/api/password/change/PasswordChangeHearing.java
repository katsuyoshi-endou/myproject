package jp.co.hisas.career.app.career.api.password.change;

import jp.co.hisas.career.app.career.deliver.RequestReceiver;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.framework.exception.CareerSecurityException;
import jp.co.hisas.career.util.SU;

public class PasswordChangeHearing extends RequestReceiver {
	
	public String sign;
	public String email;
	
	public String newPassword;
	
	public void validate() throws CareerBusinessException {
		if (!SU.isOnlyCode( sign, true )) {
			throw new CareerSecurityException( "Not only code. " + "[sign]" );
		}
		if (!SU.isOnlyCode( email, true )) {
			throw new CareerSecurityException( "Not only code. " + "[email]" );
		}
		if (!SU.isOnlyCode( newPassword, true )) {
			throw new CareerSecurityException( "Not only code. " + "[newPassword]" );
		}
		if (SU.length( sign ) > 100) {
			throw new CareerSecurityException( "MaxLength is 100. " + "[sign]" );
		}
		if (SU.length( email ) > 100) {
			throw new CareerSecurityException( "MaxLength is 100. " + "[email]" );
		}
		if (SU.length( newPassword ) > 100) {
			throw new CareerSecurityException( "MaxLength is 100. " + "[newPassword]" );
		}
	}
}
