package jp.co.hisas.career.app.career.api.gate.secret;

import java.util.HashMap;
import java.util.Map;

import javax.xml.ws.http.HTTPException;

import jp.co.hisas.career.app.career.api.Butler;
import jp.co.hisas.career.app.common.service.gate.GateService;
import jp.co.hisas.career.app.common.service.gate.auth.GateAuthEvRslt;
import jp.co.hisas.career.app.common.service.gate.auth.GateSecretOrder;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.SU;

public class GateSecretButler extends Butler {
	
	@Override
	public String takeGET( Line line ) throws CareerException {
		GateSecretOrder order = new GateSecretOrder( line );
		GateAuthEvRslt rslt = GateService.getSecret( line, order );
		Map<String, String> map = new HashMap<String, String>();
		map.put( "secret", rslt.secret );
		return SU.toJson( map );
	}
	
	@Override
	public String takePOST( Line line ) throws CareerException {
		throw new HTTPException( 405 );
	}
	
	@Override
	public String takePUT( Line tray ) throws CareerException {
		throw new HTTPException( 405 );
	}
	
	@Override
	public String takeDELETE( Line tray ) throws CareerException {
		throw new HTTPException( 405 );
	}
}
