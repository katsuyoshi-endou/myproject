package jp.co.hisas.career.app;

/**
 * For AppDef.java
 */
public class ThisApp {

	public static String APP_ID = "Hub";

	/**
	 * Context root
	 * - build.properties
	 * - application.xml
	 * - web.xml
	 * - config.bat
	 */
	public static String CTX_ROOT = "hub";

	public static String HOME_JSP = "/app/";

}
