package jp.co.hisas.career.app.career.api.password.change;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.http.HTTPException;

import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.WebAPILineServlet;

public class PasswordChangeAPI extends WebAPILineServlet {
	
	public void doOptions( HttpServletRequest req, HttpServletResponse res ) throws ServletException, IOException {
		AU.systemReady();
		WebAPILineServlet.forDebug( req, res );
		res.setHeader( "Access-Control-Allow-Credentials", "true" );
	}
	
	@Override
	public String doGetMain( Line line ) throws Exception {
		PasswordChangeButler butler = new PasswordChangeButler();
		return butler.takeGET( line );
	}
	
	@Override
	public String doPostMain( Line line ) throws Exception {
		PasswordChangeButler butler = new PasswordChangeButler();
		return butler.takePOST( line );
	}
	
	@Override
	public String doPutMain( Line line ) throws Exception {
		throw new HTTPException( 405 );
	}
	
	@Override
	public String doDeleteMain( Line line ) throws Exception {
		throw new HTTPException( 405 );
	}
	
}
