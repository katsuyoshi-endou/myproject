package jp.co.hisas.career.app.career.service;

import jp.co.hisas.career.app.common.bean.UserBean;
import jp.co.hisas.career.app.common.event.UserEvArg;
import jp.co.hisas.career.app.common.event.UserEvHdlr;
import jp.co.hisas.career.app.common.event.UserEvRslt;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.dto.CaUserDto;

public class SessionService {
	
	/**
	 * 信頼された SIGN をもとに UserBean を作成。<br>
	 * SSOカスタマイズロジックでも使えるように applyUser メソッドと分離している。
	 */
	public static UserBean createUserBeanBySign( String trustedSign ) throws CareerException {
		
		UserEvArg arg = new UserEvArg( trustedSign );
		arg.sharp = "SELECT_BY_SIGN";
		arg.sign = trustedSign;
		UserEvRslt rslt = UserEvHdlr.exec( arg );
		CaUserDto dto = rslt.caUserDto != null ? rslt.caUserDto : new CaUserDto();
		
		UserBean user = new UserBean();
		user.setSign( trustedSign );
		user.setPid( dto.getPid() );
		user.setDisplayName( dto.getDisplayName() );
		user.setLang( dto.getLang() );
		user.setCmpaCd( dto.getCmpaCd() );
		user.setStfNo( dto.getStfNo() );
		user.setParty( dto.getParty() );
		user.setGuid( dto.getGuid() );
		user.setPersonName( dto.getPersonName() );
		user.setPersonNameKana( dto.getPersonNameKana() );
		user.setMailAddress( dto.getMailAddress() );
		user.setOperator( rslt.isOperator );
		
		return user;
	}
	
	public static void applyUser( Line line, UserBean user ) throws CareerException {
		line.session.setAttribute( UserBean.SESSION_KEY, user );
	}
	
	public static UserBean getUser( Line line ) throws CareerException {
		UserBean user = line.getSessionAttr( UserBean.SESSION_KEY );
		return user;
	}
	
	public static void logout( Line line ) {
		line.session.invalidate();
	}
}
