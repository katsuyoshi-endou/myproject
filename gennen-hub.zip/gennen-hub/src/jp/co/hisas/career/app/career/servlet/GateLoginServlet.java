package jp.co.hisas.career.app.career.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.app.AppDef;

public class GateLoginServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	protected ServletContext ctx = null;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	/**
	 * GET /career/login → /career/app/gate/login
	 */
	public void doGet( HttpServletRequest req, HttpServletResponse res ) throws IOException, ServletException {
		res.sendRedirect( "/" + AppDef.CTX_ROOT + "/app/gate/login" );
	}
}
