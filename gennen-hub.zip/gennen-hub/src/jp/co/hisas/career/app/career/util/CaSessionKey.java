package jp.co.hisas.career.app.career.util;

public class CaSessionKey {
	
	public static final String CS_SINGLE_SHEET = "CsSingleSheet";
	
}
