package jp.co.hisas.career.app.career.service;

import jp.co.hisas.career.app.common.deliver.DeliveryOrder;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Line;

public class BroadcastOrder extends DeliveryOrder {
	
	public String attentionTitle;
	public String attentionDesc;
	
	public BroadcastOrder(Line line) throws CareerException {
		super( line );
	}
	
	public void validate() throws CareerBusinessException {
	}
}
