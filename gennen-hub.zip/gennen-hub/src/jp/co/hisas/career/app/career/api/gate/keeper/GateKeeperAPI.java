package jp.co.hisas.career.app.career.api.gate.keeper;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.WebAPILineServlet;
import jp.co.hisas.career.util.log.Log;

public class GateKeeperAPI extends HttpServlet {
	
	protected ServletContext ctx = null;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	public void doOptions( HttpServletRequest req, HttpServletResponse res ) throws ServletException, IOException {
		AU.systemReady();
		WebAPILineServlet.forDebug( req, res );
		res.setHeader( "Access-Control-Allow-Credentials", "true" );
	}
	
	public void doGet( final HttpServletRequest req, final HttpServletResponse res ) throws IOException, ServletException {
		try {
			Line line = new Line( req, res );
			
			Log.method( line.tracer, "IN", "" );
			Log.performance( line.tracer, true, "" );
			
			/* New session to set a token */
			line.resetSession();
			
			/* Give a new token for the first visit */
			CSRFTokenUtil.setNewTokenOnCookie( line.request, line.response );
			
			WebAPILineServlet.writeJsonResponse( req, res, 200, null );
			
			Log.performance( line.tracer, false, "" );
			Log.method( line.tracer, "OUT", "" );
			
		} catch (final Exception e) {
			Log.error( req, e );
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.setStatus( 500 );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			res.getWriter().write( json );
		}
	}
	
}
