package jp.co.hisas.career.app.career.api.broadcast;

import java.util.Map;

import javax.xml.ws.http.HTTPException;

import jp.co.hisas.career.app.career.api.Butler;
import jp.co.hisas.career.app.career.deliver.RequestReceiver;
import jp.co.hisas.career.app.career.service.BroadcastOrder;
import jp.co.hisas.career.app.career.service.BroadcastService;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.SU;

public class BroadcastButler extends Butler {
	
	@Override
	public String takeGET( Line line ) throws CareerException {
		BroadcastOrder o = new BroadcastOrder( line );
		Map<String, String> map = BroadcastService.get( o );
		return SU.toJson( map );
	}
	
	@Override
	public String takePOST( Line line ) throws CareerException {
		throw new HTTPException( 405 );
	}
	
	@Override
	public String takePUT( Line line ) throws CareerException {
		
		BroadcastHearing h = RequestReceiver.readBodyAsJson( line, BroadcastHearing.class );
		
		BroadcastOrder o = new BroadcastOrder( line );
		o.attentionTitle = h.title;
		o.attentionDesc = h.desc;
		BroadcastService.change( o );
		
		return null;
	}
	
	@Override
	public String takeDELETE( Line line ) throws CareerException {
		throw new HTTPException( 405 );
	}
}
