package jp.co.hisas.career.app.career.vm;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.ViewModel;
import jp.co.hisas.career.util.Tray;

public class VmVCAHOM extends ViewModel {
	
	public static String VMID = VmVCAHOM.class.getSimpleName();
	
	public VmVCAHOM(Tray tray) throws CareerException {
		super( tray );
	}
	
}
