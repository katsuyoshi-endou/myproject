package jp.co.hisas.career.app.career.api;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Line;

public abstract class Butler {
	
	public abstract String takeGET( Line tray ) throws CareerException;
	
	public abstract String takePOST( Line tray ) throws CareerException;
	
	public abstract String takePUT( Line tray ) throws CareerException;
	
	public abstract String takeDELETE( Line tray ) throws CareerException;
	
}
