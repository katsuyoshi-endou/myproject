package jp.co.hisas.career.app.career.api.gate.login;

import javax.xml.ws.http.HTTPException;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.WebAPILineServlet;

public class GateLoginAPI extends WebAPILineServlet {
	
	private static final long serialVersionUID = 1L;
	
	@Override
	public String doGetMain( Line line ) throws CareerException {
		throw new HTTPException( 405 );
	}
	
	@Override
	public String doPostMain( Line line ) throws CareerException {
		GateLoginButler butler = new GateLoginButler();
		return butler.takePOST( line );
	}
	
	@Override
	public String doPutMain( Line line ) throws CareerException {
		throw new HTTPException( 405 );
	}
	
	@Override
	public String doDeleteMain( Line line ) throws CareerException {
		GateLoginButler butler = new GateLoginButler();
		return butler.takeDELETE( line );
	}
	
}
