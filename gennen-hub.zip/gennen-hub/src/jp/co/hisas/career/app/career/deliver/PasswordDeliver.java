package jp.co.hisas.career.app.career.deliver;

import java.util.List;

import jp.co.hisas.career.app.career.event.PasswordEvArg;
import jp.co.hisas.career.app.career.event.PasswordEvHdlr;
import jp.co.hisas.career.app.career.event.PasswordEvRslt;
import jp.co.hisas.career.app.common.unit.PasswordUnit.PasswordRule;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerSecurityException;

public class PasswordDeliver {
	
	public static List<PasswordRule> checkNewPassword( PasswordOrder order ) throws CareerException {
		PasswordEvArg arg = new PasswordEvArg( order.tracer );
		arg.sharp = "CHECK";
		arg.pid = order.pid;
		arg.newPassword = order.newPassword;
		PasswordEvRslt result = PasswordEvHdlr.exec( arg );
		return result.rules;
	}
	
	public static boolean changePassword( PasswordOrder order ) throws CareerException {
		
		List<PasswordRule> rules = checkNewPassword( order );
		for (PasswordRule rule : rules) {
			if (!rule.isValid) {
				throw new CareerSecurityException( "Server-side password check is invalid." );
			}
		}
		
		PasswordEvArg arg = new PasswordEvArg( order.tracer );
		arg.sharp = "CHANGE_PASSWORD";
		arg.sign = order.sign;
		arg.newPassword = order.newPassword;
		PasswordEvRslt rslt = PasswordEvHdlr.exec( arg );
		
		return rslt.isSuccess;
	}
	
	public static boolean prepareTokenForResetPassword( PasswordOrder order ) throws CareerException {
		/* サインとメールアドレスの一致確認と生成したトークンのメール送信 */
		PasswordEvArg arg = new PasswordEvArg( order.tracer );
		arg.sharp = "PREPARE_TOKEN";
		arg.sign = order.sign;
		arg.email = order.email;
		PasswordEvRslt rslt = PasswordEvHdlr.exec( arg );
		return rslt.isCheckOK;
	}
	
	public static PasswordEvRslt verifyTokenForResetPassword( PasswordOrder order ) throws CareerException {
		/* メールに記載されたURLのトークンでDBからレコード選択してセッションのものと比較 */
		PasswordEvArg arg = new PasswordEvArg( order.tracer );
		arg.sharp = "CONFIRM_TOKEN";
		arg.token = order.token;
		PasswordEvRslt rslt = PasswordEvHdlr.exec( arg );
		return rslt;
	}
}
