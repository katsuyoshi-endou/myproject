package jp.co.hisas.career.app.career.servlet;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.framework.trans.NoTokenRedirectServlet;
import jp.co.hisas.career.util.Tray;

public class AppFrontServlet extends NoTokenRedirectServlet {
	
	private static final long serialVersionUID = 1L;
	
	@Override
	public String serviceMain( Tray tray ) throws Exception {
		
		CSRFTokenUtil.setNewTokenOnCookie( tray.request, tray.response );
		
		return AppDef.HOME_JSP;
	}
	
}
