package jp.co.hisas.career.app.career.api.gate.login;

import jp.co.hisas.career.app.career.api.Butler;
import jp.co.hisas.career.app.career.service.SessionService;
import jp.co.hisas.career.app.common.bean.UserBean;
import jp.co.hisas.career.app.common.service.OrderMaker;
import jp.co.hisas.career.app.common.service.gate.GateService;
import jp.co.hisas.career.app.common.service.gate.auth.GateAuthEvRslt;
import jp.co.hisas.career.app.common.service.gate.auth.GateAuthOrder;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.SU;

public class GateLoginButler extends Butler {
	
	@Override
	public String takeGET( Line line ) throws CareerException {
		return null;
	}
	
	@Override
	public String takePOST( Line line ) throws CareerException {
		
		GateAuthOrder order = OrderMaker.fromJson( line, GateAuthOrder.class );
		order.init( line );
		GateAuthEvRslt rslt = GateService.auth( line, order );
		
		if (rslt.success) {
			UserBean user = SessionService.createUserBeanBySign( rslt.sign );
			SessionService.applyUser( line, user );
		}
		
		return SU.toJson( rslt );
	}
	
	@Override
	public String takePUT( Line line ) throws CareerException {
		return null;
	}
	
	@Override
	public String takeDELETE( Line line ) throws CareerException {
		SessionService.logout( line );
		return null;
	}
}
