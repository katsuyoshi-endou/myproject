package jp.co.hisas.career.app.career.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import jp.co.hisas.career.app.career.deliver.PasswordDeliver;
import jp.co.hisas.career.app.career.deliver.PasswordOrder;
import jp.co.hisas.career.app.career.event.PasswordEvRslt;
import jp.co.hisas.career.app.career.service.SessionService;
import jp.co.hisas.career.app.common.bean.UserBean;
import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.NoTokenRedirectServlet;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.Tray;

public class PasswordResetVerifyServlet extends NoTokenRedirectServlet {
	
	private static final long serialVersionUID = 1L;
	protected ServletContext ctx = null;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	public String serviceMain( Tray tray ) throws IOException, ServletException {
		String fPath = null;
		try {
			Line line = tray.getLine();
			PasswordOrder o = new PasswordOrder( tray );
			o.token = tray.getRequestValue( "token" );
			PasswordEvRslt rslt = PasswordDeliver.verifyTokenForResetPassword( o );
			if (rslt.isVerifyOK) {
				line.resetSession();
				CSRFTokenUtil.setNewTokenOnCookie( tray.request, tray.response );
				UserBean user = SessionService.createUserBeanBySign( rslt.sign );
				SessionService.applyUser( line, user );
				fPath = "/app/password/change";
			}
			else {
				fPath = "/app/password/reset-verify-failed";
			}
		} catch (CareerException e) {
			e.printStackTrace();
		}
		return fPath;
	}
}
