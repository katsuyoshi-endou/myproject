import debug from 'debug'

const dg = debug('@:middleware:authcheck')

export default async function({ store, route, redirect }) {
  dg(route.path)
  await store.dispatch('auth/fetchSecret')
  if (!store.getters['auth/isLogin']) {
    dg('Not authenticated. Redirect to /gate/login')
    redirect('/gate/login')
  }
}
