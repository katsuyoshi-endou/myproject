<template>
  <Layout class="layout-fullheight">
    <Sider width="250">
      <sidebar />
    </Sider>
    <Layout>
      <Header>
        <global-header></global-header>
      </Header>
      <Content>
        <Layout :style="{ padding: '15px 30px' }">
          <Sider :style="{ background: '#fff' }" hide-trigger>
            <pref-menu />
          </Sider>
          <Content
            :style="{
              padding: '24px',
              minHeight: '280px',
              background: '#fff',
              position: 'relative'
            }"
          >
            <nuxt />
          </Content>
        </Layout>
      </Content>
      <Footer></Footer>
    </Layout>
  </Layout>
</template>

<script>
import Sidebar from '@/components/Sidebar'
import GlobalHeader from '@/components/GlobalHeader'
import PrefMenu from '@/components/PrefMenu'

export default {
  components: {
    Sidebar,
    GlobalHeader,
    PrefMenu
  },
  middleware: 'authcheck',
  data() {
    return {}
  },
  beforeCreate: () => {
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.document.body.className = 'layout-portal'
  }
}
</script>

<style lang="scss">
.layout-portal {
  .layout-pageroot {
    min-height: 100vh;
  }
}
.ivu-layout-header {
  background: transparent;
  padding: 0;
  height: 60px;
  line-height: 60px;
}
</style>
