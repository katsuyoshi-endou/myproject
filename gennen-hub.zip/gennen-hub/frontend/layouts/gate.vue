<template>
  <nuxt />
</template>

<script>
export default {
  beforeCreate: () => {
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.document.body.className = 'layout-gate'
  }
}
</script>

<style lang="scss">
.layout-gate {
  background: none;
  .layout-pageroot {
    min-height: 100vh;
  }
  .ivu-layout-header {
    background: none;
  }
  .ivu-layout-content {
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  .support {
    text-align: center;
  }
}
</style>
