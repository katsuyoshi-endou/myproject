<template>
  <main class="container">this is redirect page.</main>
</template>

<script>
export default {
  fetch(context) {
    // const { store, redirect } = context
    const { redirect } = context
    let newPath = context.route.path.replace(/\/index.html$/, '')
    newPath = newPath || '/'
    console.log('====================================')
    console.log('route path  => ', context.route.path)
    console.log('redirect to => ', newPath)
    console.log('====================================')
    // TODO: save auth info on state
    // if (!store.state.authUser) {
    //   return redirect('/')
    // }
    return redirect(newPath)
  },
  data() {
    return {}
  },
  computed: {}
}
</script>

<style lang="scss" scoped></style>
