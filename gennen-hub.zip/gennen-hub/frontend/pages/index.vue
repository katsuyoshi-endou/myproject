<template>
  <main class="container">
    <Row>
      <Col>
        <attention />
      </Col>
    </Row>

    <Card v-if="signage">
      <!-- eslint-disable-next-line vue/no-v-html -->
      <div v-html="signage"></div>
    </Card>

    <div v-if="isDev">
      <hr />
      <Row>
        <Col :span="12" :offset="6">
          <h3>Cookies</h3>
          <table>
            <tr v-for="(v, k) in cookieList" :key="k">
              <th>{{ k }}</th>
              <td>
                <code>{{ v }}</code>
              </td>
            </tr>
          </table>
        </Col>
      </Row>
    </div>
  </main>
</template>

<script>
import Attention from '@/components/Attention'
import { mapState } from 'vuex'
import Cookies from 'js-cookie'

export default {
  layout: 'portal',
  middleware: 'authcheck',
  components: { Attention },
  data() {
    return {
      isDev: process.env.NODE_ENV === 'development'
    }
  },
  computed: {
    ...mapState('broadcast', {
      signage: state => state.signage
    }),
    cookieList() {
      return Cookies.get()
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    async init() {
      await this.$store.dispatch('broadcast/fetch')
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  margin: 16px 32px;
}
.tiles {
  display: flex;
}
.tile {
  margin: 15px;
  cursor: pointer;
}
.tile:hover .ivu-card {
  background-color: #e6e6e6;
}
.app-tile {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100px;
  height: 100px;
  padding: 20px;
}
#aboutpage .el-card:hover {
  background-color: #ccc;
  border-color: transparent;
  cursor: pointer;
}
.app-tile i {
  font-size: 3em;
}
.app-tile .title {
  font-size: 1.3em;
  margin: 0.5em 0 0;
}

table th {
  text-align: right;
  color: #909399;
}
table td {
  text-align: left;
  padding: 0.5em;
}
code {
  font-family: consolas;
}
hr {
  margin: 3em 0;
}
</style>
