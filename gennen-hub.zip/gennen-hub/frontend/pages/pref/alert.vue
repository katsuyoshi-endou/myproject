<template>
  <div>
    <h1>アラート</h1>
    <Divider />
    <Form
      :model="theForm"
      label-position="top"
      @submit.native.prevent="submitForm"
    >
      <FormItem label="現在">
        <attention />
      </FormItem>
      <FormItem label="変更後プレビュー">
        <template v-if="theForm.title || theForm.desc">
          <Alert show-icon>
            {{ theForm.title }}
            <template slot="desc">{{ theForm.desc }}</template>
          </Alert>
        </template>
        <template v-else>
          <p style="margin:1em 0 2em;">（何も表示されません）</p>
        </template>
      </FormItem>
      <FormItem label="見出し">
        <Input
          v-model="theForm.title"
          :maxlength="100"
          show-word-limit
          size="large"
        ></Input>
      </FormItem>
      <FormItem label="補足">
        <Input
          v-model="theForm.desc"
          :rows="3"
          :maxlength="500"
          type="textarea"
          show-word-limit
        ></Input>
      </FormItem>
      <FormItem>
        <Button html-type="submit" type="primary">変更を反映</Button>
      </FormItem>
    </Form>
    <Spin v-if="loading" size="large" fix></Spin>
  </div>
</template>

<script>
import Attention from '@/components/Attention'
import { mapState } from 'vuex'

export default {
  layout: 'pref',
  components: { Attention },
  data() {
    return {
      theForm: { title: '', desc: '' },
      loading: false
    }
  },
  computed: {
    ...mapState('broadcast', {
      attention: state => state.attention
    })
  },
  async mounted() {
    await this.$store.dispatch('broadcast/fetch')
    this.theForm = { ...this.attention }
  },
  methods: {
    async submitForm() {
      this.loading = true
      await this.$store.dispatch('broadcast/change', this.theForm)
      this.loading = false
      this.$Message.success('変更を反映しました。')
    }
  }
}
</script>
