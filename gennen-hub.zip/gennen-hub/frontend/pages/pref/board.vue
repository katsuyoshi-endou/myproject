<template>
  <div>
    <h1>ボード</h1>
    <Divider />
    <Alert show-icon
      >アプリケーションサーバ上のファイルを編集してください。</Alert
    >
    <code>C:\Lysithea\Career\Hub\htmltemplate\signage</code>
  </div>
</template>

<script>
export default {
  layout: 'pref'
}
</script>
