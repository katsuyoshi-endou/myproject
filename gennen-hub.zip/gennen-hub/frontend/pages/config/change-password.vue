<template>
  <main>
    <nuxt-link to="/gate/new-password">
      <Button type="primary" ghost>新しいパスワードの設定</Button>
    </nuxt-link>
  </main>
</template>

<script>
export default {
  layout: 'portal'
}
</script>
