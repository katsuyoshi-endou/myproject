<template>
  <Layout class="layout-pageroot">
    <Header></Header>
    <Content>
      <Card class="box-card">
        <h1 class="mg-b">パスワードリセット</h1>

        <Alert show-icon>
          パスワードをお忘れの場合は、ログインIDとメールアドレスを入力してください。
          <template slot="desc"
            >ご入力されたメールアドレスとシステムに登録されたメールアドレスが一致する場合、
            新しいパスワードを送信します。
            メールアドレスが一致しない場合やシステムに登録されていない場合は、システム管理者までお問い合わせください。
          </template>
        </Alert>

        <Form
          ref="theForm"
          :model="theForm"
          :rules="theRule"
          action="path/to/action"
          label-position="top"
          @submit.native.prevent="submitForm"
        >
          <FormItem label="ログインID" prop="sign">
            <Input
              v-model="theForm.sign"
              type="text"
              placeholder="ログインID"
              style="width: 300px"
            />
          </FormItem>
          <FormItem label="メールアドレス" prop="email">
            <Input
              v-model="theForm.email"
              type="text"
              placeholder="メールアドレス"
              style="width: 300px"
            />
          </FormItem>
          <FormItem label="">
            <Button type="primary" @click="handleSubmit">送信</Button>
          </FormItem>
        </Form>

        <Spin v-if="loading" size="large" fix></Spin>
      </Card>
    </Content>
    <Footer></Footer>
  </Layout>
</template>

<script>
import EP from '@/store/endpoint'
import { mapState } from 'vuex'

export default {
  layout: 'gate',
  components: {},
  data() {
    return {
      loading: false,
      theForm: {
        sign: '',
        email: ''
      },
      theRule: {
        sign: [
          {
            required: true,
            message: 'ログインIDを入力してください。',
            trigger: 'blur'
          }
        ],
        email: [
          {
            required: true,
            message: 'メールアドレスを入力してください。',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  computed: {
    ...mapState('auth', {
      isExpired: state => state.isExpired
    })
  },
  mounted() {},
  methods: {
    handleSubmit() {
      this.$Loading.start()
      this.$refs.theForm.validate(async valid => {
        if (valid) {
          await 0
          this.submitForm()
          this.loading = true
        } else {
          this.$Loading.error()
        }
      })
    },
    submitForm() {
      const form = document.createElement('form')
      form.setAttribute('method', 'post')
      form.setAttribute('action', `${EP.HUB}/password-reset`)
      document.body.appendChild(form)
      form.appendChild(this.makeInput('hidden', 'sign', this.theForm.sign))
      form.appendChild(this.makeInput('hidden', 'email', this.theForm.email))
      form.submit()
    },
    makeInput(type, name, value) {
      const input = document.createElement('input')
      input.setAttribute('type', type)
      input.setAttribute('name', name)
      input.setAttribute('value', value)
      return input
    }
  }
}
</script>

<style lang="scss" scoped>
.box-card {
  width: 720px;
  margin: 0 auto;
  padding: 0 30px;
  .logo {
    margin: 1em 1em 2em;
  }
  .logo img {
    width: 100%;
  }
  label {
    line-height: 1;
  }
  .btn-submit {
    text-align: center;
  }
}
</style>
