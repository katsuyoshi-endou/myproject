<template>
  <Layout class="layout-pageroot">
    <Header></Header>
    <Content>
      <div class="holder">
        <Alert show-icon>
          確認メールが送信されました。
          <template slot="desc"
            >メールに記載のURLをクリックして手続きを進めてください。
          </template>
        </Alert>
      </div>
    </Content>
    <Footer></Footer>
  </Layout>
</template>

<script>
export default {
  layout: 'gate'
}
</script>

<style scoped>
.holder {
  width: 720px;
  margin: auto;
}
</style>
