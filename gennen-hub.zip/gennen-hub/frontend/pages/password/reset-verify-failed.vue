<template>
  <Layout class="layout-pageroot">
    <Header></Header>
    <Content>
      <div class="holder">
        <Alert type="error" show-icon>
          無効なアクセスです。
          <template slot="desc"
            >このURLはすでに使用済みか、有効なものではありません。
          </template>
        </Alert>
      </div>
    </Content>
    <Footer></Footer>
  </Layout>
</template>

<script>
export default {
  layout: 'gate',
  methods: {
    closeWindow() {
      window.close()
    }
  }
}
</script>

<style scoped>
.holder {
  width: 720px;
  margin: auto;
}
</style>
