<template>
  <Layout class="layout-pageroot">
    <Header></Header>
    <Content>
      <Card class="box-card">
        <h1 class="mg-b">新しいパスワード</h1>
        <div v-if="isExpired" style="margin-bottom:30px;">
          <Alert type="warning" show-icon>
            パスワードの有効期限が切れています。
            <template slot="desc">
              新しいパスワードを設定してください。
            </template>
          </Alert>
        </div>
        <div v-if="needsReset" style="margin-bottom:30px;">
          <Alert type="warning" show-icon>
            パスワードの変更が必要です。
            <template slot="desc">
              新しいパスワードを設定してください。
            </template>
          </Alert>
        </div>
        <Row :gutter="16">
          <Col span="12">
            <Form
              ref="theForm"
              :model="formNewPassword"
              :rules="theRule"
              label-position="top"
              @submit.native.prevent="submitFormNewPassword"
            >
              <FormItem label="新しいパスワード" prop="newPassword">
                <Input
                  v-model="formNewPassword.newPassword"
                  type="password"
                  placeholder="新しいパスワード"
                  style="width: 300px"
                  @on-blur="serverCheck"
                />
                <span>{{ formNewPassword.newPassword.length }}</span>
              </FormItem>
              <div class="xx-spacer"></div>
              <FormItem
                label="新しいパスワードの再入力"
                prop="newPasswordAgain"
              >
                <Input
                  v-model="formNewPassword.newPasswordAgain"
                  type="password"
                  placeholder="新しいパスワードの再入力"
                  style="width: 300px"
                />
              </FormItem>
              <div class="xx-spacer"></div>
              <FormItem label="">
                <Button html-type="submit" type="primary">決定</Button>
              </FormItem>
            </Form>
          </Col>
          <Col span="12">
            <div style="color: #808695;">
              <span>パスワードポリシー</span>
              <Button
                type="text"
                size="large"
                icon="md-refresh"
                @click="serverCheck"
              />
            </div>
            <section class="xx-passwordrule-checks">
              <div
                v-for="(rule, idx) of rules"
                :key="idx"
                class="xx-passwordrule-check-item"
              >
                <div>
                  <ok-ng-icon :flag="rule.isValid" size="20px"></ok-ng-icon>
                  {{ rule.label }}
                </div>
              </div>
            </section>
            <section>
              <div
                v-for="(desc, idx) of ruleDescs"
                :key="idx"
                class="xx-ruledesc"
              >
                {{ desc }}
              </div>
            </section>
          </Col>
        </Row>
      </Card>
    </Content>
    <Footer></Footer>
  </Layout>
</template>

<script>
import OkNgIcon from '@/components/OkNgIcon'
import { mapState } from 'vuex'

export default {
  layout: 'gate',
  middleware: 'authcheck',
  components: {
    OkNgIcon
  },
  data() {
    return {
      rules: [],
      theRule: {
        newPassword: [
          { required: true, validator: this.validate1, trigger: 'change' }
        ],
        newPasswordAgain: [
          {
            required: true,
            validator: this.validate2,
            trigger: 'change'
          }
        ]
      },
      formNewPassword: {
        newPassword: '',
        newPasswordAgain: ''
      }
    }
  },
  computed: {
    ...mapState('auth', {
      isExpired: state => state.isExpired,
      needsReset: state => state.needsReset
    }),
    ruleDescs() {
      return this.rules.filter(x => !!x.desc).map(x => x.desc)
    }
  },
  async mounted() {
    await this.$store.dispatch('auth/fetchSession')
    await this.serverCheck()
  },
  methods: {
    async serverCheck() {
      console.log('[#serverCheck] start')
      const result = await this.$axios
        .$get(`/api/password/change`, {
          params: {
            newPassword: this.formNewPassword.newPassword
          }
        })
        .catch(e => {
          this.$Message.error('パスワードポリシーの確認に失敗しました。')
        })
      this.rules = result
    },
    validate1(rule, value, callback) {
      if (value === '') {
        callback(new Error('必須入力です。'))
      } else {
        callback()
      }
    },
    validate2(rule, value, callback) {
      const { newPassword, newPasswordAgain } = this.formNewPassword
      if (value === '') {
        callback(new Error('必須入力です。'))
      } else if (newPassword !== newPasswordAgain) {
        callback(new Error('一致していません。'))
      } else {
        callback()
      }
    },
    async checkServerRuleOK() {
      await this.serverCheck()
      const ngRules = this.rules.filter(x => !x.isValid)
      console.log({ ngRules })
      if (ngRules.length > 0) {
        return false
      }
      return true
    },
    submitFormNewPassword() {
      this.$refs.theForm.validate(async valid => {
        if (valid) {
          const ok = await this.checkServerRuleOK()
          if (ok) {
            this.execChange()
          } else {
            this.$Message.error('パスワードポリシーの要件を満たしていません。')
            return false
          }
        } else {
          return false
        }
      })
    },
    async execChange() {
      this.$Loading.start()
      const result = await this.$axios
        .$post(`/api/password/change`, {
          newPassword: this.formNewPassword.newPassword
        })
        .catch(e => {
          this.$Message.error('処理を完了できませんでした。')
        })
      if (result && result.success === 'true') {
        this.$Loading.finish()
        this.$router.push('/password/change-done')
      } else {
        this.$Loading.error()
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.box-card {
  width: 800px;
  margin: 0 auto;
  padding: 0 30px;
  .logo {
    margin: 1em 1em 2em;
  }
  .logo img {
    width: 100%;
  }
  label {
    line-height: 1;
  }
  .btn-submit {
    text-align: center;
  }
}
.xx-spacer {
  padding-top: 1em;
}
.xx-passwordrule-check-item {
  margin-top: 0.3em;
}
.xx-ruledesc {
  margin-top: 1em;
  font-size: 11px;
  padding: 0.5em;
  background-color: #f8f8f9;
  border: 1px solid #dcdee2;
  border-radius: 2px;
}
</style>
