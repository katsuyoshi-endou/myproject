<template>
  <Layout class="layout-pageroot">
    <Header></Header>
    <Content>
      <div class="holder">
        <Alert type="success" show-icon>
          新しいパスワードを設定しました。
          <span slot="desc"
            >新しいパスワードを使ってログインし直してください。
          </span>
        </Alert>
        <nuxt-link to="/gate/login"
          ><Button type="primary">ログイン</Button></nuxt-link
        >
      </div>
    </Content>
    <Footer></Footer>
  </Layout>
</template>

<script>
export default {
  layout: 'gate'
}
</script>

<style scoped>
.holder {
  width: 720px;
  margin: auto;
}
</style>
