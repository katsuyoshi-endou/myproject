<template>
  <Layout class="layout-pageroot">
    <Header></Header>
    <Content>
      <div class="holder">
        <Alert type="error" show-icon>
          アカウントの確認に失敗しました。
          <template slot="desc"
            >入力内容を確認してもう一度お試しください。
          </template>
        </Alert>
        <nuxt-link to="/password/reset"
          ><Button type="primary">戻る</Button></nuxt-link
        >
      </div>
    </Content>
    <Footer></Footer>
  </Layout>
</template>

<script>
export default {
  layout: 'gate'
}
</script>

<style scoped>
.holder {
  width: 720px;
  margin: auto;
}
</style>
