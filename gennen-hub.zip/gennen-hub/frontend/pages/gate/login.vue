<template>
  <Layout class="layout-pageroot">
    <Header></Header>
    <Content>
      <Row type="flex" justify="center">
        <Col>
          <Card class="box-card">
            <div class="logo">
              <img src="@/assets/login_logo.png" alt="logo" />
            </div>
            <Form
              ref="theForm"
              :model="form"
              :rules="theRule"
              label-position="top"
              @submit.native.prevent="submitForm"
            >
              <FormItem label="ログインID" prop="signItem">
                <Input v-model="form.signItem" type="text" />
              </FormItem>
              <FormItem label="パスワード" prop="passItem">
                <Input v-model="form.passItem" type="password" />
              </FormItem>
              <FormItem>
                <Button html-type="submit" type="primary" long>ログイン</Button>
              </FormItem>
            </Form>
            <Spin v-if="loading" size="large" fix></Spin>
          </Card>
        </Col>
      </Row>
    </Content>
    <Footer>
      <p class="support">
        <nuxt-link to="/password/reset">パスワードを忘れた方はこちら</nuxt-link>
      </p>
    </Footer>
  </Layout>
</template>

<script>
export default {
  layout: 'gate',
  data() {
    return {
      form: {
        signItem: '',
        passItem: ''
      },
      theRule: {
        signItem: [
          {
            required: true,
            message: 'ログインIDを入力してください。',
            trigger: 'change'
          }
        ],
        passItem: [
          {
            required: true,
            message: 'パスワードを入力してください。',
            trigger: 'change'
          }
        ]
      },
      loading: false
    }
  },
  mounted() {},
  methods: {
    submitForm() {
      this.$refs.theForm.validate(valid => {
        if (valid) {
          this.enterGate()
        } else {
          return false
        }
      })
    },
    async enterGate() {
      this.loading = true
      try {
        await new Promise(resolve => setTimeout(resolve, 1000))
        await this.$axios.$get(`/api/gate/keeper`)
        const result = await this.$store.dispatch('auth/login', this.form)
        if (result.success) {
          if (result.needsReset) {
            this.$Message.warning('パスワードの変更が必要です。')
            this.$router.push('/password/change')
          } else if (result.isExpired) {
            this.$Message.warning('パスワードの有効期限が切れています。')
            this.$router.push('/password/change')
          } else {
            this.$router.push('/')
          }
          await this.$store.dispatch('auth/fetchSession')
        } else if (result.isAccountLocked) {
          this.$Message.error('アカウントがロックされています。')
        } else {
          this.$Message.error('ログインIDまたはパスワードが間違っています。')
        }
      } catch (e) {
        console.error(e.toString())
        this.$Notice.error({
          title: 'ログインエラー',
          desc: 'しばらく待ってから再度お試しください。'
        })
      }
      this.loading = false
    }
  }
}
</script>

<style lang="scss" scoped>
.box-card {
  width: 360px;
  padding: 0 30px;
  .logo {
    margin: 1em 1em 2em;
  }
  .logo img {
    width: 100%;
  }
  label {
    line-height: 1;
  }
  .btn-submit {
    text-align: center;
  }
}
</style>
