<template>
  <Layout class="layout-pageroot">
    <Header></Header>
    <Content>
      <Row type="flex" justify="center">
        <Col>
          <Alert type="success" show-icon>
            ログアウトしました。
            <span slot="desc">ページを閉じてください。</span>
          </Alert>
        </Col>
      </Row>
    </Content>
  </Layout>
</template>

<script>
export default {
  layout: 'gate'
}
</script>

<style lang="scss" scoped>
.ivu-alert {
  width: 360px;
}
</style>
