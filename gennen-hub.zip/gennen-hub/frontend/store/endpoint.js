console.log('process.env.NODE_ENV:', process.env.NODE_ENV)

const isDev = process.env.NODE_ENV === 'development'
const useLocalServer = isDev

let HUB_HOST = ''
let SHEET_HOST = ''
let TALENT_HOST = ''
let LEARNING_HOST = ''

if (isDev) {
  HUB_HOST = useLocalServer ? 'http://localhost:8080' : ''
  SHEET_HOST = useLocalServer ? 'http://localhost:8080' : ''
  TALENT_HOST = useLocalServer ? 'http://localhost:8080' : ''
  LEARNING_HOST = useLocalServer ? 'http://localhost:8080' : ''
}

export default {
  HUB: `${HUB_HOST}/hub`,
  SHEET: `${SHEET_HOST}/sheet`,
  TALENT: `${TALENT_HOST}/talent`,
  LEARNING: `${LEARNING_HOST}/career`
}
