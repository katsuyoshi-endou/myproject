export const state = () => ({
  attention: {},
  signage: ''
})

export const getters = {}

export const mutations = {
  setAttention(state, attention) {
    state.attention = attention || {}
  },
  setSignage(state, signage) {
    state.signage = signage || ''
  }
}

export const actions = {
  async fetch({ commit }) {
    const result = await this.$axios.$get(`/api/broadcast`)
    const attention = {
      title: result['attention-title'],
      desc: result['attention-desc']
    }
    commit('setAttention', attention)
    commit('setSignage', result.signage)
  },
  async change({ dispatch }, { title, desc }) {
    const data = { title, desc }
    await this.$axios.$put('/api/broadcast', data)
    await dispatch('fetch')
  }
}
