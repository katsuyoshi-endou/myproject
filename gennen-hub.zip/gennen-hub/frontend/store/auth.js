const initialState = {
  pid: null,
  isExpired: null,
  isAccountLocked: null,
  secret: null,
  session: {}
}

export const state = () => Object.assign({}, initialState)

export const getters = {
  isLogin(state) {
    return !!state.secret
  },
  gSession(state) {
    return state.session || {}
  }
}

export const mutations = {
  reset(state) {
    Object.assign(state, initialState)
  },
  setLoginInfo(state, payload) {
    state.pid = payload.pid
    state.isExpired = payload.isExpired
    state.isAccountLocked = payload.isAccountLocked
    state.needsReset = payload.needsReset
  },
  setSecret(state, secret) {
    state.secret = secret
  },
  setSession(state, session) {
    state.session = session || {}
  }
}

export const actions = {
  async login({ commit }, form) {
    commit('reset')
    const result = await this.$axios.$post(`/api/gate/login`, {
      sign: form.signItem,
      password: form.passItem
    })
    commit('setLoginInfo', result)
    return result
  },
  async fetchSession({ commit }) {
    const session = await this.$axios.$get(`/api/session`)
    commit('setSession', session)
  },
  async fetchSecret({ commit }, id) {
    // in server, make SECRET to DB, then obtain it.
    const result = await this.$axios
      .$get(`/api/gate/secret`)
      .catch(e => ({ secret: null }))
    const { secret } = result
    commit('setSecret', secret)
  },
  async logout({ commit, state }) {
    await this.$axios.$delete(`/api/gate/login`)
    commit('reset')
  }
}
