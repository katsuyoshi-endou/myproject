<template>
  <Menu :active-name="$route.name" theme="light" width="auto">
    <MenuGroup title="お知らせ欄">
      <MenuItem name="pref-alert" to="/pref/alert">
        <Icon type="md-megaphone" />アラート
      </MenuItem>
      <MenuItem name="pref-board" to="/pref/board">
        <Icon type="md-easel" />ボード</MenuItem
      >
    </MenuGroup>
  </Menu>
</template>
