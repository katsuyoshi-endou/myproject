<template>
  <span>
    <Icon
      v-if="flag"
      :style="iconStyle"
      class="ok-green"
      type="md-checkmark-circle"
    />
    <Icon v-else :style="iconStyle" class="ng-red" type="md-close-circle" />
  </span>
</template>

<script>
export default {
  props: { flag: Boolean, size: { type: String, default: '16px' } },
  computed: {
    iconStyle() {
      return {
        fontSize: this.size
      }
    }
  }
}
</script>

<style lang="scss" scoped>
i.ok-green {
  color: #19be6b;
}
i.ng-red {
  color: #ed4014;
}
</style>
