<template>
  <Alert v-if="attention.title || attention.desc" show-icon>
    {{ attention.title }}
    <template slot="desc">{{ attention.desc }}</template>
  </Alert>
</template>

<script>
import { mapState } from 'vuex'

export default {
  computed: {
    ...mapState('broadcast', {
      attention: state => state.attention
    })
  },
  async mounted() {
    await this.$store.dispatch('broadcast/fetch')
  }
}
</script>
