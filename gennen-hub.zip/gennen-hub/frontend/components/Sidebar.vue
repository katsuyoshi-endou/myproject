<template>
  <Menu theme="dark" width="auto" active-name="1">
    <nuxt-link to="/">
      <div class="layout-logo">
        <Icon type="md-compass" size="24" color="#ffc900" />
        <span>Portal</span>
      </div>
    </nuxt-link>
    <!-- <MenuGroup title="グループ">
      <Select v-model="selectedParty" style="padding:0 24px;">
        <Option v-for="item in parties" :key="item.code" :value="item.code">{{
          item.name
        }}</Option>
      </Select>
    </MenuGroup> -->
    <MenuGroup title="アプリ">
      <!-- <MenuItem name="1">
        <div class="launchapp-tile" @click="goSheet">
          <Icon type="md-clipboard" size="32" />
          <span>目標管理</span>
          <Icon type="md-open" />
        </div>
      </MenuItem> -->
      <MenuItem name="2">
        <div class="launchapp-tile" @click="goTalent">
          <Icon type="ios-people" size="32" />
          <span>人財検索</span>
          <Icon type="md-open" />
        </div>
      </MenuItem>
      <MenuItem name="3">
        <div class="launchapp-tile" @click="goLearning">
          <Icon type="ios-school" size="32" />
          <span>研修管理</span>
          <Icon type="md-open" />
        </div>
      </MenuItem>
      <form name="form001" method="POST">
        <input v-model="selectedParty" type="hidden" name="party" />
        <input v-model="secret" type="hidden" name="secret" />
      </form>
    </MenuGroup>
    <MenuGroup v-if="gSession.isOperator" title="管理部門">
      <MenuItem name="1" to="/pref/alert">
        <Icon type="md-clipboard" size="20" />
        <span>ポータル設定</span>
      </MenuItem>
    </MenuGroup>
  </Menu>
</template>

<script>
import EP from '@/store/endpoint'
import { mapState, mapGetters } from 'vuex'

export default {
  data() {
    return {
      selectedParty: 'JNFL',
      parties: [
        { code: 'MAJOR', name: 'メジャーカンパニー' },
        { code: 'DEMO', name: 'デモカンパニー' }
      ]
    }
  },
  computed: {
    ...mapState('auth', {
      secret: state => state.secret
    }),
    ...mapGetters({
      gSession: 'auth/gSession'
    })
  },
  methods: {
    goSheet() {
      // クッキーも検討したけど別ホスト/ポートになると受け取れない。
      window.open('', 'lysh')
      document.form001.action = `${EP.SHEET}/viagate`
      document.form001.target = 'lysh'
      document.form001.submit()
    },
    goTalent() {
      // クッキーも検討したけど別ホスト/ポートになると受け取れない。
      window.open('', 'lytl')
      document.form001.action = `${EP.TALENT}/viagate`
      document.form001.target = 'lytl'
      document.form001.submit()
    },
    goLearning() {
      var option;
      var subX = (window.screen.availWidth - 1280) / 2;
      var subY = (window.screen.availHeight - 800) / 2;

      option = "scrollbars=yes, resizable=yes, width=1280, height=800, top=" + subY + ", left=" + subX + ", menubar=no, location=no";

      // クッキーも検討したけど別ホスト/ポートになると受け取れない。
      window.open('about:blank', 'hcdb_main', option)
      document.form001.action = `${EP.LEARNING}/viagate`
      document.form001.target = 'hcdb_main'
      document.form001.submit()
    }
  }
}
</script>

<style lang="scss" scoped>
.layout-logo {
  display: flex;
  align-items: center;
  padding: 15px 0 20px 20px;
  font-size: 22px;
  font-weight: bold;
  color: white;
  i {
    margin-right: 8px;
  }
  span {
    margin-top: 4px;
    line-height: 1;
  }
}
.launchapp-tile {
  display: flex;
  align-items: center;
  padding: 10px 5px 10px 10px;
  background-image: linear-gradient(135deg, #f5f7fa 0%, #d6deeb 100%);
  border-radius: 2px;
  box-shadow: 0 2px 3px 1px rgba(0, 0, 0, 0.3);
  color: rgba(0, 0, 0, 0.6);
  &:hover {
    color: #515a6e;
    font-weight: bold;
  }
  span {
    flex: 1;
  }
  i {
    margin-right: 8px;
  }
}
</style>

<style lang="scss">
.ivu-layout-sider {
  background: #19212a;
}
.ivu-menu-dark {
  background: #19212a;
}
.ivu-menu-dark.ivu-menu-vertical .ivu-menu-item-group-title {
  color: rgba(255, 255, 255, 0.56);
}
.ivu-menu-item-group {
  margin-top: 1em;
}
.ivu-menu-item-active {
  background: auto;
}
</style>
