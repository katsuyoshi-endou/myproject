<template>
  <Menu mode="horizontal" theme="primary" active-name="4">
    <div class="layout-nav">
      <MenuItem name="1">
        <div class="layout-nav-menuitem">
          <div class="layout-nav-item" @click="handleClickUser">
            <Avatar icon="md-person" />
            <span>{{ gSession.displayName }}</span>
          </div>
          <div class="layout-nav-item" @click="handleClickUser">
            <Icon type="md-settings" size="20" />
          </div>
        </div>
      </MenuItem>
    </div>

    <Drawer v-model="showDrawer" :closable="false">
      <div>
        <Avatar icon="md-person" size="small" />
        <span>{{ gSession.displayName }}</span>
      </div>
      <template v-if="canChangePassword">
        <Divider />
        <CellGroup>
          <Cell title="パスワード変更" to="/password/change" />
        </CellGroup>
      </template>
      <Divider />
      <Button type="error" ghost long @click="handleClickLogout"
        >ログアウト</Button
      >
      <Modal
        v-model="showLogoutConfirm"
        width="300"
        @on-cancel="showLogoutConfirm = false"
      >
        <p>ログアウトしますか？</p>
        <div slot="footer">
          <Button id="LogoutBtn" type="error" long @click="handleLogout"
            >ログアウト</Button
          >
        </div>
      </Modal>
    </Drawer>
  </Menu>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  data() {
    return {
      showDrawer: false,
      showLogoutConfirm: false
    }
  },
  computed: {
    ...mapGetters({
      gSession: 'auth/gSession'
    }),
    canChangePassword() {
      // for JNFL
      return this.gSession.isOperator
    }
  },
  mounted() {
    this.$store.dispatch('auth/fetchSession')
  },
  methods: {
    async handleLogout() {
      await this.$store.dispatch('auth/logout')
      this.$router.push('/gate/logout')
    },
    handleClickUser() {
      this.showDrawer = true
    },
    handleClickLogout() {
      this.showLogoutConfirm = true
      const el = window.document.getElementById('LogoutBtn')
      el.focus()
    }
  }
}
</script>

<style lang="scss" scoped>
.ivu-menu.ivu-menu-horizontal .layout-nav .ivu-menu-item {
  float: right;
}
.layout-nav-menuitem {
  display: flex;
}
.layout-nav-item {
  padding: 0 1em;
  &:hover {
    background-color: rgba(0, 0, 0, 0.2);
  }
}
</style>
