import EP from './store/endpoint'

console.log(EP)

export default {
  mode: 'spa',

  router: {
    base: '/hub/app/',
    /* Cosminexus が /index.html を付与する挙動のため強制リダイレクト */
    extendRoutes(routes, resolve) {
      routes.push({
        name: 'indexredirect',
        path: '*/index.html',
        component: resolve(__dirname, 'pages/redirect.vue')
      })
    }
  },

  /*
   ** Headers of the page
   */
  head: {
    title: 'Portal',
    meta: [
      { charset: 'utf-8' },
      { 'http-equiv': 'X-UA-Compatible', content: 'IE=edge' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' }
    ],
    script: [
      // IE11 https://polyfill.io/v3/polyfill.min.js?features=es2015%2Ces2016%2Ces2017%2Ces2018
      { src: '/hub/app/polyfill.min.js' }
    ]
    // link: [{ rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' }]
  },

  /*
   ** Customize the progress-bar color
   */
  loading: { color: '#ffc900' },

  /*
   ** Global CSS
   */
  css: [
    { src: '~/plugins/iview-custom.less', lang: 'less' },
    { src: '~/assets/main.scss', lang: 'scss' }
  ],

  /*
   ** Plugins to load before mounting the App
   */
  plugins: ['@/plugins/axios.js', '@/plugins/iview'],

  /*
   ** Nuxt.js modules
   */
  modules: [
    // Doc: https://axios.nuxtjs.org/usage
    '@nuxtjs/axios'
  ],

  /*
   ** Axios module configuration
   */
  axios: {
    // See https://axios.nuxtjs.org/options
    baseURL: EP.HUB,
    credentials: true
  },

  /*
   ** Build configuration
   */
  build: {
    /*
     ** You can extend webpack config here
     */
    extend(config, ctx) {
      // Run ESLint on save
      if (ctx.isDev && ctx.isClient) {
        config.module.rules.push({
          enforce: 'pre',
          test: /\.(js|vue)$/,
          loader: 'eslint-loader',
          exclude: /(node_modules)/
        })
      }
      // Source map
      config.devtool = 'eval-source-map'
    },
    loaders: {
      less: {
        javascriptEnabled: true
      }
    }
  }
}
