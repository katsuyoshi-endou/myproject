# Lyca Hub Frontend

> Nuxt.js project

## Setup

```bash
$ npm ci
```

## Dev

```bash
$ npm run dev
```

## Note

- DevTools Console: `localStorage.debug = '*'`
- IE11はサーバ上にデプロイした先で動作確認すること（localhost:3000では動かない）
- Package: `debug` はv3を指定。v4以降はIE11対応していない。
