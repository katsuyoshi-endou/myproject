const dg = Debug("vue");

const vueapp = vm => {
  return new Vue({
    el: "#VueCAGTI",
    data: {
      vm,
      ready: false,
      isLoading: false,
      lbl: App.LabelMap,
      form: {}
    },
    computed: {
    },
    mounted() {
    },
    updated() {
    },
    methods: {
      onSubmit() {
        makeRequestParameter("loginid", this.form.loginid);
        makeRequestParameter("password", this.form.password);
        pageSubmit("/login");
      }
    },
  });
};

function mountVueCAGTI(vm) {
  window.vueapp = vueapp(vm);
}

export default mountVueCAGTI;
