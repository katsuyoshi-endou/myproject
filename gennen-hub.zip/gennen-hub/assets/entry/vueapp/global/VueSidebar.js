const dg = Debug("vue");

const vueapp = vm => {
  console.log("VueSidebar.js");
  return new Vue({
    el: "#gSidebar",
    data: {
      vm,
      ready: false,
      isLoading: false,
      lbl: App.LabelMap,
      currentPage4: 1,
    },
    computed: {
    },
    mounted() {
    },
    updated() {
    },
    methods: {
      handleClickMenu(path) {
        pageSubmit(path, "INIT");
      }
    },
  });
};

function mountVueSidebar(vm) {
  window.VueSidebar = vueapp(vm);
}

export default mountVueSidebar;
