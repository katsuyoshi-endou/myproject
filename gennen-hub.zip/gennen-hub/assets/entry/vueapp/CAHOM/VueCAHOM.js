const dg = Debug("vue");

const vueapp = vm => {
  return new Vue({
    el: "#VueCAHOM",
    data: {
      vm,
      ready: false,
      isLoading: false,
      lbl: App.LabelMap,
      currentPage4: 1,
    },
    computed: {
    },
    mounted() {
    },
    updated() {
    },
    methods: {
    },
  });
};

function mountVueCAHOM(vm) {
  window.vueapp = vueapp(vm);
}

export default mountVueCAHOM;
