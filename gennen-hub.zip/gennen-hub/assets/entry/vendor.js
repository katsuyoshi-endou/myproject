// Polyfill
require("es6-promise").polyfill();
require("url-search-params-polyfill");

// NPM
window.jQuery = window.$ = require("jquery");
window._ = require("underscore");
window.Debug = require("debug");
window.axios = require("axios");
window.Decimal = require("decimal.js");

// Custom
window.FHConvert = require("./vendor/fhconvert");
