import "babel-polyfill";

import mountVueSidebar from "./vueapp/global/VueSidebar";
import mountVueCAGTI from "./vueapp/CAGTI/VueCAGTI";
import mountVueCAHOM from "./vueapp/CAHOM/VueCAHOM";

window.mountVueSidebar = mountVueSidebar;
window.mountVueCAGTI = mountVueCAGTI;
window.mountVueCAHOM = mountVueCAHOM;
