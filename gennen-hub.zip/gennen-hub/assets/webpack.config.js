const path = require("path");
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const VueLoaderPlugin = require("vue-loader/lib/plugin");
const Autoprefixer = require("autoprefixer");

const cssLoader = {
  loader: "css-loader",
  options: {
    url: false,
    sourceMap: true,
    importLoaders: 2
  }
};

const postcssLoader = {
  loader: "postcss-loader",
  options: {
    sourceMap: true,
    plugins: [
      Autoprefixer({
        grid: true,
        overrideBrowserslist: [
          "ie >= 11",
          "Chrome >= 53",
          "iOS >= 8",
          "Firefox >= 49",
          "Edge >= 14"
        ]
      })
    ]
  }
};

const sassLoader = {
  loader: "sass-loader",
  options: {
    sourceMap: true
  }
};

module.exports = {
  entry: {
    vueapp: "./entry/vueapp.js",
    vendor: "./entry/vendor.js",
    style: "./entry/style.js",
    components: "./entry/components.js"
  },
  output: {
    path: `${__dirname}/bundle`,
    filename: "[name].bundle.js"
  },
  module: {
    rules: [
      // ---- Element UI ----------------
      {
        test: /\.css$/,
        include: /element-ui/,
        use: ExtractTextPlugin.extract({
          use: [
            {
              loader: "css-loader"
            }
          ]
        })
      },
      {
        test: /\.(ttf|woff)$/,
        include: /element-ui/,
        loader: "file-loader",
        options: {
          name: "fonts/[name].[ext]"
        }
      },
      // ---- Custom Components ----------------
      {
        test: /\.vue$/,
        loader: "vue-loader"
      },
      {
        test: /\.styl(us)?$/,
        include: path.resolve(__dirname, "entry/components"),
        use: [
          "style-loader",
          "vue-style-loader",
          cssLoader,
          postcssLoader,
          "stylus-loader"
        ]
      },
      {
        test: /\.js$/,
        include: [path.resolve(__dirname, "entry/components"), path.resolve(__dirname, "entry/vueapp")],
        loader: "babel-loader"
      },
      // ---- Application Style ----------------
      {
        test: /\.scss$/,
        include: path.resolve(__dirname, "entry/scss"),
        use: ExtractTextPlugin.extract({
          use: [cssLoader, postcssLoader, sassLoader]
        })
      }
    ]
  },
  resolve: {
    modules: [path.join(__dirname, "entry"), "node_modules"],
    extensions: [".js", ".vue"],
    alias: {
      vue$: "vue/dist/vue.esm.js"
    }
  },
  plugins: [new ExtractTextPlugin("[name].bundle.css"), new VueLoaderPlugin()],
  devtool: "source-map"
};
