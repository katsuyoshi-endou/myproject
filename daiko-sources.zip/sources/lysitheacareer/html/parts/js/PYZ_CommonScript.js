function fileDownload(){
	document.F001.H079_FilePath.value = "C:\\lysitheacareer\\html\\download_files";
	next('/career/servlet/PYE010_FileDownloadServlet');
}

function backMenu(url){
	document.F100.action = "/career/view/base/menu/VYY_MenuMain.jsp";
	document.F100.target = "_top";
	document.F100.method = "post";
	document.F100.submit();
}

function logout(){
    document.F100.action = "/career/servlet/LogoutServlet";
    document.F100.target = "_top";
    document.F100.method = "post";
    document.F100.submit(); 
}

function next(url){
	document.F001.action = url;
	document.F001.target = "_top";
	document.F001.method = "post";
	document.F001.submit();
}

function back(url){
	document.F001.action = url;
	document.F001.target = "_top";
	document.F001.method = "post";
	document.F001.submit();
}

function SubWindow(url,width,height){
    Style="scrollbars=no,resizable=yes,width="+width+",height="+height+",top=100,left=100";
    window.open("","SubWindow",Style);
    document.F001.action = url;
	document.F001.target = "SubWindow";
	document.F001.method = "post";
	document.F001.submit();
}
function SubWindowScroll(url,width,height){
    Style="scrollbars=yes,resizable=yes,width="+width+",height="+height+",top=100,left=100";
    window.open("","SubWindow",Style);
    document.F001.action = url;
	document.F001.target = "SubWindow";
	document.F001.method = "post";
	document.F001.submit();
}
function byte(s) {
    var r = 0;
    for (var i = 0; i < s.length; i++) {
        var c = s.charCodeAt(i);
        if ( (c >= 0x0 && c < 0x81) || (c == 0xf8f0) || (c >= 0xff61 && c < 0xffa0) || (c >= 0xf8f1 && c < 0xf8f4)) {
            r += 1;
        } else {
            r += 2;
        }
    }
    return r;
}
function htmlEncode(checkKomoku , checkString){
    if ( checkString.indexOf( ">" , 0 )  != -1 ) {
        alert(checkKomoku+"�� > �͓��͏o���܂���B");
        return false;
    }
    if ( checkString.indexOf( "<" , 0 )  != -1) {
        alert(checkKomoku+"�� < �͓��͏o���܂���B");
        return false;
    }
    if ( checkString.indexOf( "\"" , 0 )  != -1) {
        alert(checkKomoku+"�� \" �͓��͏o���܂���B");
        return false;
    }
    if ( checkString.indexOf( "&" , 0 )  != -1) {
        alert(checkKomoku+"�� & �͓��͏o���܂���B");
        return false;   
    } else {
        return true;
    }
}

function noframes(){
	location.href="/<%= HcdbDef.root %>/view/base/err/VYY_NoFrames.jsp";
}