window.document.onkeydown=PressKeyCheck;
window.document.onmousewheel=PressKeyCheck; 
window.document.onmousedown = shiftKeyCheck;

function PressKeyCheck(e){

// Ctrl + A
  if(window.event.ctrlKey==true && event.keyCode == 65) {
	return false;
  }

// Ctrl + D
  if(window.event.ctrlKey==true && event.keyCode == 68) {
	return false;
  }

// Ctrl + E
  if(window.event.ctrlKey==true && event.keyCode == 69) {
	return false;
  }

// Ctrl + F
/*  if(window.event.ctrlKey==true && event.keyCode == 70) {
	alert("CTRL + F �͋֎~����Ă��܂��B");
	return false;
  }
*/

// Ctrl + H
  if(window.event.ctrlKey==true && event.keyCode == 72) {
	return false;
  }

// Ctrl + I
  if(window.event.ctrlKey==true && event.keyCode == 73) {
	return false;
  }

// Ctrl + L
  if(window.event.ctrlKey==true && event.keyCode == 76) {
	return false;
  }

// Ctrl + N
  if(window.event.ctrlKey==true && event.keyCode == 78) {
	return false;
  }

// Ctrl + O
  if(window.event.ctrlKey==true && event.keyCode == 79) {
	event.keyCode=8;
	return false;
  }

// Ctrl + P
  if(window.event.ctrlKey==true && event.keyCode == 80) {
	event.keyCode=8;
	return false;
  }

// Ctrl + R
  if(window.event.ctrlKey==true && event.keyCode == 82) {
	return false;
  }

// Ctrl + W
  if(window.event.ctrlKey==true && event.keyCode == 87) {
	return false;
  }

// Ctrl + X
  if(window.event.ctrlKey==true && event.keyCode == 88) {
	return false;
  }

// Ctrl + F5
  if(window.event.ctrlKey==true && event.keyCode == 116) {
	return false;
  }

// Ctrl + Tab
  if(window.event.ctrlKey==true && event.keyCode == 9) {
	return false;
  }

//Ctrl + Shift + Tab
  if(window.event.ctrlKey==true && window.event.shiftKey==true && event.keyCode == 9) {
	return false;
  }

//Ctrl + Shift + R
  if(window.event.ctrlKey==true && window.event.shiftKey==true && event.keyCode == 82) {
	return false;
  }

// Alt + D
  if(window.event.altKey==true && event.keyCode == 68) {
	event.keyCode=39;
	return false;
  }

// Alt + ��
  if(window.event.altKey==true && event.keyCode == 37) {
	return false;
  }

// Alt + ��
  if(window.event.altKey==true && event.keyCode == 39) {
	return false;
  }

// Alt + SPACE
  if(window.event.altKey==true && event.keyCode == 32) {
	event.keyCode=39;
	return false;
  }

// Alt + F4
  if(window.event.altKey==true && event.keyCode == 115) {
	event.keyCode=39;
	return false ;
  }

// Alt + HOME
  if(window.event.altKey==true && event.keyCode == 36) {
	event.keyCode=39;
	return false ;
  }

// Alt + Enter
  if(window.event.altKey==true && event.keyCode == 13) {
	event.keyCode=39;
	return false ;
  }

// F2
  if( event.keyCode == 113 ) {
	event.keyCode=8;
	return false ; 
  }

// F3
  if( event.keyCode == 114 ) {
	event.keyCode=8;
	return false ; 
  }

// F4
  if( event.keyCode == 115 ) {
	event.keyCode=8;
	return false ; 
  }

// F5
  if( event.keyCode == 116 ) {
	event.keyCode=8;
	return false ; 
  }

// F11
  if( event.keyCode == 122 ) {
	event.keyCode=8;
	return false ; 
  }

// BackSpace
  if( event.keyCode == 8 ) {

        //�e�L�X�g�{�b�N�X�A�p�X���[�h�{�b�N�X�͋��� 
        var elementTag = window.event.srcElement.tagName;
        if (elementTag == 'INPUT') {
            var elementType = window.event.srcElement.type;
            if ((elementType == 'text' || elementType == 'password' || elementType == "file") && window.event.srcElement.readOnly == false) {
                return true;
            }
        } else if (elementTag == 'TEXTAREA' && window.event.srcElement.readOnly == false) {
            return true;
        }

	return false ; 
  }
// ESC
  if( event.keyCode == 27 ) {
	return false ; 
  }
  
//Shift + Enter
  if(window.event.shiftKey==true && event.keyCode == 13) {
	return false;
  }

  //Enter
  if( event.keyCode == 13 ) {
        //�e�L�X�g�G���A�͕s���� 
        for (i = 0; i < document.all.tags("TEXTAREA").length; i++) { 
            if (document.all.tags("TEXTAREA")(i).name == window.event.srcElement.name
             && document.all.tags("TEXTAREA")(i).readOnly == false
             && document.all.tags("TEXTAREA")(i).className != "AllowEnter"){ 
                return false; 
            } 
        }
	return true;
   }
       
//Shift
/*
  if(window.event.shiftKey == true){
          //�e�L�X�g�G���A�͋��� 
          for (i = 0; i < document.all.tags("TEXTAREA").length; i++) { 
              if (document.all.tags("TEXTAREA")(i).name == window.event.srcElement.name && 
                  document.all.tags("TEXTAREA")(i).readOnly == false){ 
                  return true; 
              } 
          }
          //�e�L�X�g�{�b�N�X�A�p�X���[�h�{�b�N�X�͋��� 
          for (i = 0; i < document.all.tags("INPUT").length; i++) { 
             if (document.all.tags("INPUT")(i).name == window.event.srcElement.name && 
                (document.all.tags("INPUT")(i).type == "text" || document.all.tags("INPUT")(i).type == "password") && 
                 document.all.tags("INPUT")(i).readOnly == false){ 
                 return true; 
             }
          }
          //�Q�ƃG���A�͋���
          for (i = 0; i < document.all.tags("INPUT").length; i++) { 
              if (document.all.tags("INPUT")(i).name == window.event.srcElement.name && 
                  document.all.tags("INPUT")(i).type == "file" && 
                  document.all.tags("INPUT")(i).readOnly == false){ 
                  return true; 
             }              
          }
          //SELECT(���X�g�{�b�N�X)�͋���
          for (i = 0; i < document.all.tags("SELECT").length; i++) {
              if (document.all.tags("SELECT")(i).name == window.event.srcElement.name &&
                  document.all.tags("SELECT")(i).readOnly != true){
                  return true;
              }
          }
  return false;     
  }
*/

}

 function shiftKeyCheck(){
    if(window.event.shiftKey == true && (event.button == 1 || event.button == 2)){
        alert("Shift�L�[�̎g�p�́A�e�L�X�g���͎��ȊO�֎~����Ă��܂�");
        return false;
    }
}

/*
function shiftKeyCheck(){
    if(window.event.shiftKey == true && (event.button == 1 || event.button == 2)){
          //�e�L�X�g�G���A�͋���
          for (i = 0; i < document.all.tags("TEXTAREA").length; i++) {
              if (document.all.tags("TEXTAREA")(i).name == window.event.srcElement.name &&
                  document.all.tags("TEXTAREA")(i).readOnly == false){
                  return true;
              }
          }
          //�e�L�X�g�{�b�N�X�A�p�X���[�h�{�b�N�X�͋��� 
          for (i = 0; i < document.all.tags("INPUT").length; i++) {
             if (document.all.tags("INPUT")(i).name == window.event.srcElement.name &&
                (document.all.tags("INPUT")(i).type == "text" || document.all.tags("INPUT")(i).type == "password") &&
                 document.all.tags("INPUT")(i).readOnly == false){
                 return true; 
             }
          }
        alert("Shift�L�[�̎g�p�́A�e�L�X�g���͎��ȊO�֎~����Ă��܂�");
        return false;
    }
}
*/
