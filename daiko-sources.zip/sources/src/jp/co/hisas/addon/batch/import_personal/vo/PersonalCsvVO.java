/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g��  : ���V�e�A�iCareer�j
 *
 *
 * ���l : �p�[�\�i���v���t�@�C��CSV�̂P�s����ێ�����ValueObject�B
 *
 * ���� :
 *   ���t�o�[�W����  ���O ���e
 *   2005/10/30  1.00       TUANTT      �V�K�쐬
 *
 */
package jp.co.hisas.addon.batch.import_personal.vo;

import java.io.Serializable;

import jp.co.hisas.addon.batch.import_personal.exception.BatchFailedException;
import jp.co.hisas.career.util.log.Log;

/**
 *
 * <PRE>
 *
 * �N���X���F PersonalCsvVO�N���X
 *
 * �@�\�����F �p�[�\�i���v���t�@�C��CSV�̂P�s����ێ�����ValueObject�B
 *
 * </PRE>
 */
public class PersonalCsvVO implements Serializable, PersonalCsvColumn {

    /** �ǉ�����������B*/
    public static final int ADD_PERSONAL = 1;

    /** �X�V����������B*/
    public static final int UPDATE_PERSONAL = 2;

    /** CSV���ڐ� */
    private static final int ITEM_NUMBERS = 46;

    /** �b�r�u�ǂݍ��݊J�n�ʒu */
    private static final int DEFAULT_POINT = 1;

    /** CSV�ǂݍ��ݍs�� */
    private int csvRecordCount = 0;

    /** ����NO�t���O */
    private String simei_no;

    /** �p�X���[�h */
    private String password;

    /** �{���^�����t���O */
    private String honmu_flg;

    /** �������� */
    private String kanji_simei;

    /** �J�i�����i�S�p�j */
    private String kana_simei;

    /** �����i�p���j */
    private String eiji_simei;

    /** ���� */
    private String seibetu;

    /** ���N���� */
    private String seinengappi;

    /** ���ДN�� */
    private String nyusya_nengetu;

    /** ���E�ސE�t���O */
    private String gensyoku_taisyoku_flg;

    /** �ސE�N���� */
    private String taisyoku_nengappi;

    /** �����R�[�h */
    private String kengen_code;

    /** ��E�R�[�h */
    private String yakusyoku_code;

    /** �E�ʃR�[�h */
    private String syokui_code;

    /** �g�D�R�[�h */
    private String sosiki_code;

    /** �A������� */
    private String naisen;

    /** �A����O�� */
    private String gaisen;

    /** FAX�ԍ� */
    private String fax_no;

    /** Mail */
    private String mail;

    /** ����PR */
    private String jiko_pr;

    /** �\���P */
    private String yobi1;

    /** Job�i���{��j */
    private String yobi2;

    /** Job�i�p��j */
    private String yobi3;

    /** Supervisor�i���{��j�t���O */
    private String yobi4;

    /** Supervisor�i�p��j�t���O */
    private String yobi5;

    /** �E��R�[�h�P�t���O */
    private String syoku_code1;

    /** ��啪��R�[�h�P�t���O */
    private String senmon_code1;

    /** ���x���R�[�h�P�t���O */
    private String level_code1;

    /** �����B���x�P�t���O */
    private String sougou_t_do1;

    /** �E��R�[�h�Q�t���O */
    private String syoku_code2;

    /** ��啪��R�[�h�Q�t���O */
    private String senmon_code2;

    /** ���x���R�[�h�Q�t���O */
    private String level_code2;

    /** �����B���x�Q�t���O */
    private String sougou_t_do2;

    /** �E��R�[�h�R�t���O */
    private String syoku_code3;

    /** ��啪��R�[�h�R�t���O */
    private String senmon_code3;

    /** ���x���R�[�h�R�t���O */
    private String level_code3;

    /** �����B���x�R�t���O */
    private String sougou_t_do3;

    /** �X�L���Z�b�g�����e�i���X�t���O�t���O */
    private String skill_mainte_flg;

    /** �֘A�Ɩ��o�^�\�t���O�t���O */
    private String kanren_gyomu_touroku_flg;

    /** �p�[�\�i���v���t�@�C�������e�i���X�t���O�t���O */
    private String personal_mainte_flg;

    /** ���i�c�a�����e�t���O�t���O */
    private String sikaku_mainte_flg;

    /** ���C�Ǘ��҃t���O�t���O */
    private String kenpo_mainte_flg;

    /** ���O�C�����m�点��񃁃��e�t���O�t���O */
    private String login_osirase_mainte_flg;

    /** ���v�E���͏�񌟍������t���O */
    private String tokei_bunseki_kengen;

    /** �ސE�Ҍ��������t���O�t���O */
    private String taisyokusya_kensaku_kengen_flg;

    /** ����J���������t���O�t���O */
    private String hikoukai_kensaku_kengen_flg;

    /**
     *CSV�f�[�^�̃`�F�b�N�A�i�[���s��
     *@param csvData String[] CSV�f�[�^��z��������́B
     *@exception BatchFailedException �o�b�`���s��O�B
     */
    public PersonalCsvVO(String[] csvData) throws BatchFailedException {

        Log.method( "", "IN", "" );

        /* CSV���ڐ��`�F�b�N */
        checkSize( csvData );

        printCsvData( csvData );

        String[] inputData = new String[ITEM_NUMBERS];
        for ( int i = 0; i < ITEM_NUMBERS; i++ ) {
            inputData[i] = new String( "" );
        }
        for ( int i = 0; i < csvData.length; i++ ) {
            inputData[i] = csvData[i];
        }

        setSimei_no( inputData[KEY_SIMEI_NO] );
        setPassword( inputData[KEY_PASSWORD] );
        setHonmu_flg( inputData[KEY_HONMU_FLG] );
        setKanji_simei( inputData[KEY_KANJI_SIMEI] );
        setKana_simei( inputData[KEY_KANA_SIMEI] );
        setEiji_simei( inputData[KEY_EIJI_SIMEI] );
        setSeibetu( inputData[KEY_SEIBETU] );
        setSeinengappi( inputData[KEY_SEINENGAPPI] );
        setNyusya_nengetu( inputData[KEY_NYUSYA_NENGETU] );
        setGensyoku_taisyoku_flg( inputData[KEY_GENSYOKU_TAISYOKU_FLG] );
        setTaisyoku_nengappi( inputData[KEY_TAISYOKU_NENGAPPI] );
        setKengen_code( inputData[KEY_KENGEN_CODE] );
        setYakusyoku_code( inputData[KEY_YAKUSYOKU_CODE] );
        setSyokui_code( inputData[KEY_SYOKUI_CODE] );
        setSosiki_code( inputData[KEY_SOSIKI_CODE] );
        setNaisen( inputData[KEY_NAISEN] );
        setGaisen( inputData[KEY_GAISEN] );
        setFax_no( inputData[KEY_FAX_NO] );
        setMail( inputData[KEY_MAIL] );
        setJiko_pr( inputData[KEY_JIKO_PR] );
        setYobi1( inputData[KEY_YOBI1] );
        setYobi2( inputData[KEY_YOBI2] );
        setYobi3( inputData[KEY_YOBI3] );
        setYobi4( inputData[KEY_YOBI4] );
        setYobi5( inputData[KEY_YOBI5] );
        setSyoku_code1( inputData[KEY_SYOKU_CODE1] );
        setSenmon_code1( inputData[KEY_SENMON_CODE1] );
        setLevel_code1( inputData[KEY_LEVEL_CODE1] );
        setSougou_t_do1( inputData[KEY_SOUGOU_T_DO1] );
        setSyoku_code2( inputData[KEY_SYOKU_CODE2] );
        setSenmon_code2( inputData[KEY_SENMON_CODE2] );
        setLevel_code2( inputData[KEY_LEVEL_CODE2] );
        setSougou_t_do2( inputData[KEY_SOUGOU_T_DO2] );
        setSyoku_code3( inputData[KEY_SYOKU_CODE3] );
        setSenmon_code3( inputData[KEY_SENMON_CODE3] );
        setLevel_code3( inputData[KEY_LEVEL_CODE3] );
        setSougou_t_do3( inputData[KEY_SOUGOU_T_DO3] );
        setSkill_mainte_flg( inputData[KEY_SKILL_MAINTE_FLG] );
        setKanren_gyomu_touroku_flg( inputData[KEY_KANREN_GYOMU_TOUROKU_FLG] );
        setPersonal_mainte_flg( inputData[KEY_PERSONAL_MAINTE_FLG] );
        setSikaku_mainte_flg( inputData[KEY_SIKAKU_MAINTE_FLG] );
        setKenpo_mainte_flg( inputData[KEY_KENPO_MAINTE_FLG] );
        setLogin_osirase_mainte_flg( inputData[KEY_LOGIN_OSIRASE_MAINTE_FLG] );
        setTokei_bunseki_kengen( inputData[KEY_TOKEI_BUNSEKI_KENGEN] );
        setTaisyokusya_kensaku_kengen_flg( inputData[KEY_TAISYOKUSYA_KENSAKU_KENGEN_FLG] );
        setHikoukai_kensaku_kengen_flg( inputData[KEY_HIKOUKAI_KENSAKU_KENGEN_FLG] );

        Log.method( "", "OUT", "" );
    }

    /**
     *�f�o�b�N�p���\�b�h�B
     *@param csvData String[] �f�[�^�����ׂă��O�o�͂���B
     */
    private void printCsvData(String[] csvData) {

        Log.method( "", "IN", "" );

        if (csvData == null) {
            Log.debug( getClass( ).getName( ) + "#printCsvData null warning." );
            return;
        }
        Log.debug( getClass( ).getName( ) + "#printCsvData: print start..." );
        for ( int i = 0; i < csvData.length; i++ ) {
            String strIdx = String.valueOf( i );
            //2���܂ł̌����␳
            if (strIdx.length( ) == 1) {
                strIdx = "0" + strIdx;
            }
            Log.debug( "csv[" + strIdx + "]=" + csvData[i] );

        }
        Log.debug( getClass( ).getName( ) + "#printCsvData: print end..." );
        Log.method( "", "OUT", "" );
    }

    /**
     *CSV���ڐ��`�F�b�N���s���B
     *�قȂ�ꍇ�́A�o�b�`���s�Ƃ���B
     *@param csvData String[] CSV��s����z��ϊ��������́B
     *@exception BatchFailedException CSV�J���������K��Ƃ͈قȂ�ꍇ�B
     */
    private void checkSize(String[] csvData) throws BatchFailedException {

        Log.method( "", "IN", "" );
        if (csvData.length != ITEM_NUMBERS) {
            throw new BatchFailedException( "CSV data error: invalid number of column" );
        }
        Log.method( "", "OUT", "" );
    }

    /**
     * csvRecordCount���擾����B
     * @return int csvRecordCount
     */
    public int getCsvRecordCount() {
        return csvRecordCount;
    }

    /**
     * csvRecordCount��ݒ肷��B
     * @param csvRecordCount csvRecordCount
     */
    public void setCsvRecordCount(int csvRecordCount) {
        this.csvRecordCount = csvRecordCount;
    }

    /**
     * eiji_simei���擾����B
     * @return String eiji_simei
     */
    public String getEiji_simei() {
        return eiji_simei;
    }

    /**
     * eiji_simei��ݒ肷��B
     * @param eiji_simei eiji_simei
     */
    public void setEiji_simei(String eiji_simei) {
        this.eiji_simei = eiji_simei;
    }

    /**
     * fax_no���擾����B
     * @return String fax_no
     */
    public String getFax_no() {
        return fax_no;
    }

    /**
     * fax_no��ݒ肷��B
     * @param fax_no fax_no
     */
    public void setFax_no(String fax_no) {
        this.fax_no = fax_no;
    }

    /**
     * gaisen���擾����B
     * @return String gaisen
     */
    public String getGaisen() {
        return gaisen;
    }

    /**
     * gaisen��ݒ肷��B
     * @param gaisen gaisen
     */
    public void setGaisen(String gaisen) {
        this.gaisen = gaisen;
    }

    /**
     * gensyoku_taisyoku_flg���擾����B
     * @return String gensyoku_taisyoku_flg
     */
    public String getGensyoku_taisyoku_flg() {
        return gensyoku_taisyoku_flg;
    }

    /**
     * gensyoku_taisyoku_flg��ݒ肷��B
     * @param gensyoku_taisyoku_flg gensyoku_taisyoku_flg
     */
    public void setGensyoku_taisyoku_flg(String gensyoku_taisyoku_flg) {
        this.gensyoku_taisyoku_flg = gensyoku_taisyoku_flg;
    }

    /**
     * group_nyusya_nengetu���擾����B
     * @return String group_nyusya_nengetu
     */
    public String getNyusya_nengetu() {
        return nyusya_nengetu;
    }

    /**
     * group_nyusya_nengetu��ݒ肷��B
     * @param nyusya_nengetu group_nyusya_nengetu
     */
    public void setNyusya_nengetu(String nyusya_nengetu) {
        this.nyusya_nengetu = nyusya_nengetu;
    }

    /**
     * hikoukai_kensaku_kengen_flg���擾����B
     * @return String hikoukai_kensaku_kengen_flg
     */
    public String getHikoukai_kensaku_kengen_flg() {
        return hikoukai_kensaku_kengen_flg;
    }

    /**
     * hikoukai_kensaku_kengen_flg��ݒ肷��B
     * @param hikoukai_kensaku_kengen_flg hikoukai_kensaku_kengen_flg
     */
    public void setHikoukai_kensaku_kengen_flg(String hikoukai_kensaku_kengen_flg) {
        this.hikoukai_kensaku_kengen_flg = hikoukai_kensaku_kengen_flg;
    }

    /**
     * honmu_flg���擾����B
     * @return String honmu_flg
     */
    public String getHonmu_flg() {
        return honmu_flg;
    }

    /**
     * honmu_flg��ݒ肷��B
     * @param honmu_flg honmu_flg
     */
    public void setHonmu_flg(String honmu_flg) {
        this.honmu_flg = honmu_flg;
    }

    /**
     * jiko_pr���擾����B
     * @return String jiko_pr
     */
    public String getJiko_pr() {
        return jiko_pr;
    }

    /**
     * jiko_pr��ݒ肷��B
     * @param jiko_pr jiko_pr
     */
    public void setJiko_pr(String jiko_pr) {
        this.jiko_pr = jiko_pr;
    }

    /**
     * kana_simei���擾����B
     * @return String kana_simei
     */
    public String getKana_simei() {
        return kana_simei;
    }

    /**
     * kana_simei��ݒ肷��B
     * @param kana_simei kana_simei
     */
    public void setKana_simei(String kana_simei) {
        this.kana_simei = kana_simei;
    }

    /**
     * kanji_simei���擾����B
     * @return String kanji_simei
     */
    public String getKanji_simei() {
        return kanji_simei;
    }

    /**
     * kanji_simei��ݒ肷��B
     * @param kanji_simei kanji_simei
     */
    public void setKanji_simei(String kanji_simei) {
        this.kanji_simei = kanji_simei;
    }

    /**
     * kanren_gyomu_touroku_flg���擾����B
     * @return String kanren_gyomu_touroku_flg
     */
    public String getKanren_gyomu_touroku_flg() {
        return kanren_gyomu_touroku_flg;
    }

    /**
     * kanren_gyomu_touroku_flg��ݒ肷��B
     * @param kanren_gyomu_touroku_flg kanren_gyomu_touroku_flg
     */
    public void setKanren_gyomu_touroku_flg(String kanren_gyomu_touroku_flg) {
        this.kanren_gyomu_touroku_flg = kanren_gyomu_touroku_flg;
    }

    /**
     * kengen_code���擾����B
     * @return String kengen_code
     */
    public String getKengen_code() {
        return kengen_code;
    }

    /**
     * kengen_code��ݒ肷��B
     * @param kengen_code kengen_code
     */
    public void setKengen_code(String kengen_code) {
        this.kengen_code = kengen_code;
    }

    /**
     * kenpo_mainte_flg���擾����B
     * @return String kenpo_mainte_flg
     */
    public String getKenpo_mainte_flg() {
        return kenpo_mainte_flg;
    }

    /**
     * kenpo_mainte_flg��ݒ肷��B
     * @param kenpo_mainte_flg kenpo_mainte_flg
     */
    public void setKenpo_mainte_flg(String kenpo_mainte_flg) {
        this.kenpo_mainte_flg = kenpo_mainte_flg;
    }

    /**
     * level_code1���擾����B
     * @return String level_code1
     */
    public String getLevel_code1() {
        return level_code1;
    }

    /**
     * level_code1��ݒ肷��B
     * @param level_code1 level_code1
     */
    public void setLevel_code1(String level_code1) {
        this.level_code1 = level_code1;
    }

    /**
     * level_code2���擾����B
     * @return String level_code2
     */
    public String getLevel_code2() {
        return level_code2;
    }

    /**
     * level_code2��ݒ肷��B
     * @param level_code2 level_code2
     */
    public void setLevel_code2(String level_code2) {
        this.level_code2 = level_code2;
    }

    /**
     * level_code3���擾����B
     * @return String level_code3
     */
    public String getLevel_code3() {
        return level_code3;
    }

    /**
     * level_code3��ݒ肷��B
     * @param level_code3 level_code3
     */
    public void setLevel_code3(String level_code3) {
        this.level_code3 = level_code3;
    }

    /**
     * login_osirase_mainte_flg���擾����B
     * @return String login_osirase_mainte_flg
     */
    public String getLogin_osirase_mainte_flg() {
        return login_osirase_mainte_flg;
    }

    /**
     * login_osirase_mainte_flg��ݒ肷��B
     * @param login_osirase_mainte_flg login_osirase_mainte_flg
     */
    public void setLogin_osirase_mainte_flg(String login_osirase_mainte_flg) {
        this.login_osirase_mainte_flg = login_osirase_mainte_flg;
    }

    /**
     * mail���擾����B
     * @return String mail
     */
    public String getMail() {
        return mail;
    }

    /**
     * mail��ݒ肷��B
     * @param mail mail
     */
    public void setMail(String mail) {
        this.mail = mail;
    }

    /**
     * naisen���擾����B
     * @return String naisen
     */
    public String getNaisen() {
        return naisen;
    }

    /**
     * naisen��ݒ肷��B
     * @param naisen naisen
     */
    public void setNaisen(String naisen) {
        this.naisen = naisen;
    }

    /**
     * password���擾����B
     * @return String password
     */
    public String getPassword() {
        return password;
    }

    /**
     * password��ݒ肷��B
     * @param password password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * personal_mainte_flg���擾����B
     * @return String personal_mainte_flg
     */
    public String getPersonal_mainte_flg() {
        return personal_mainte_flg;
    }

    /**
     * personal_mainte_flg��ݒ肷��B
     * @param personal_mainte_flg personal_mainte_flg
     */
    public void setPersonal_mainte_flg(String personal_mainte_flg) {
        this.personal_mainte_flg = personal_mainte_flg;
    }

    /**
     * seibetu���擾����B
     * @return String seibetu
     */
    public String getSeibetu() {
        return seibetu;
    }

    /**
     * seibetu��ݒ肷��B
     * @param seibetu seibetu
     */
    public void setSeibetu(String seibetu) {
        this.seibetu = seibetu;
    }

    /**
     * seinengappi���擾����B
     * @return String seinengappi
     */
    public String getSeinengappi() {
        return seinengappi;
    }

    /**
     * seinengappi��ݒ肷��B
     * @param seinengappi seinengappi
     */
    public void setSeinengappi(String seinengappi) {
        this.seinengappi = seinengappi;
    }

    /**
     * senmon_code1���擾����B
     * @return String senmon_code1
     */
    public String getSenmon_code1() {
        return senmon_code1;
    }

    /**
     * senmon_code1��ݒ肷��B
     * @param senmon_code1 senmon_code1
     */
    public void setSenmon_code1(String senmon_code1) {
        this.senmon_code1 = senmon_code1;
    }

    /**
     * senmon_code2���擾����B
     * @return String senmon_code2
     */
    public String getSenmon_code2() {
        return senmon_code2;
    }

    /**
     * senmon_code2��ݒ肷��B
     * @param senmon_code2 senmon_code2
     */
    public void setSenmon_code2(String senmon_code2) {
        this.senmon_code2 = senmon_code2;
    }

    /**
     * senmon_code3���擾����B
     * @return String senmon_code3
     */
    public String getSenmon_code3() {
        return senmon_code3;
    }

    /**
     * senmon_code3��ݒ肷��B
     * @param senmon_code3 senmon_code3
     */
    public void setSenmon_code3(String senmon_code3) {
        this.senmon_code3 = senmon_code3;
    }

    /**
     * sikaku_mainte_flg���擾����B
     * @return String sikaku_mainte_flg
     */
    public String getSikaku_mainte_flg() {
        return sikaku_mainte_flg;
    }

    /**
     * sikaku_mainte_flg��ݒ肷��B
     * @param sikaku_mainte_flg sikaku_mainte_flg
     */
    public void setSikaku_mainte_flg(String sikaku_mainte_flg) {
        this.sikaku_mainte_flg = sikaku_mainte_flg;
    }

    /**
     * simei_no���擾����B
     * @return String simei_no
     */
    public String getSimei_no() {
        return simei_no;
    }

    /**
     * simei_no��ݒ肷��B
     * @param simei_no simei_no
     */
    public void setSimei_no(String simei_no) {
        this.simei_no = simei_no;
    }

    /**
     * skill_mainte_flg���擾����B
     * @return String skill_mainte_flg
     */
    public String getSkill_mainte_flg() {
        return skill_mainte_flg;
    }

    /**
     * skill_mainte_flg��ݒ肷��B
     * @param skill_mainte_flg skill_mainte_flg
     */
    public void setSkill_mainte_flg(String skill_mainte_flg) {
        this.skill_mainte_flg = skill_mainte_flg;
    }

    /**
     * sosiki_code���擾����B
     * @return String sosiki_code
     */
    public String getSosiki_code() {
        return sosiki_code;
    }

    /**
     * sosiki_code��ݒ肷��B
     * @param sosiki_code sosiki_code
     */
    public void setSosiki_code(String sosiki_code) {
        this.sosiki_code = sosiki_code;
    }

    /**
     * sougou_t_do1���擾����B
     * @return String sougou_t_do1
     */
    public String getSougou_t_do1() {
        return sougou_t_do1;
    }

    /**
     * sougou_t_do1��ݒ肷��B
     * @param sougou_t_do1 sougou_t_do1
     */
    public void setSougou_t_do1(String sougou_t_do1) {
        this.sougou_t_do1 = sougou_t_do1;
    }

    /**
     * sougou_t_do2���擾����B
     * @return String sougou_t_do2
     */
    public String getSougou_t_do2() {
        return sougou_t_do2;
    }

    /**
     * sougou_t_do2��ݒ肷��B
     * @param sougou_t_do2 sougou_t_do2
     */
    public void setSougou_t_do2(String sougou_t_do2) {
        this.sougou_t_do2 = sougou_t_do2;
    }

    /**
     * sougou_t_do3���擾����B
     * @return String sougou_t_do3
     */
    public String getSougou_t_do3() {
        return sougou_t_do3;
    }

    /**
     * sougou_t_do3��ݒ肷��B
     * @param sougou_t_do3 sougou_t_do3
     */
    public void setSougou_t_do3(String sougou_t_do3) {
        this.sougou_t_do3 = sougou_t_do3;
    }

    /**
     * syoku_code1���擾����B
     * @return String syoku_code1
     */
    public String getSyoku_code1() {
        return syoku_code1;
    }

    /**
     * syoku_code1��ݒ肷��B
     * @param syoku_code1 syoku_code1
     */
    public void setSyoku_code1(String syoku_code1) {
        this.syoku_code1 = syoku_code1;
    }

    /**
     * syoku_code2���擾����B
     * @return String syoku_code2
     */
    public String getSyoku_code2() {
        return syoku_code2;
    }

    /**
     * syoku_code2��ݒ肷��B
     * @param syoku_code2 syoku_code2
     */
    public void setSyoku_code2(String syoku_code2) {
        this.syoku_code2 = syoku_code2;
    }

    /**
     * syoku_code3���擾����B
     * @return String syoku_code3
     */
    public String getSyoku_code3() {
        return syoku_code3;
    }

    /**
     * syoku_code3��ݒ肷��B
     * @param syoku_code3 syoku_code3
     */
    public void setSyoku_code3(String syoku_code3) {
        this.syoku_code3 = syoku_code3;
    }

    /**
     * syokui_code���擾����B
     * @return String syokui_code
     */
    public String getSyokui_code() {
        return syokui_code;
    }

    /**
     * syokui_code��ݒ肷��B
     * @param syokui_code syokui_code
     */
    public void setSyokui_code(String syokui_code) {
        this.syokui_code = syokui_code;
    }

    /**
     * taisyoku_nengappi���擾����B
     * @return String taisyoku_nengappi
     */
    public String getTaisyoku_nengappi() {
        return taisyoku_nengappi;
    }

    /**
     * taisyoku_nengappi��ݒ肷��B
     * @param taisyoku_nengappi taisyoku_nengappi
     */
    public void setTaisyoku_nengappi(String taisyoku_nengappi) {
        this.taisyoku_nengappi = taisyoku_nengappi;
    }

    /**
     * taisyokusya_kensaku_kengen_flg���擾����B
     * @return String taisyokusya_kensaku_kengen_flg
     */
    public String getTaisyokusya_kensaku_kengen_flg() {
        return taisyokusya_kensaku_kengen_flg;
    }

    /**
     * taisyokusya_kensaku_kengen_flg��ݒ肷��B
     * @param taisyokusya_kensaku_kengen_flg taisyokusya_kensaku_kengen_flg
     */
    public void setTaisyokusya_kensaku_kengen_flg(String taisyokusya_kensaku_kengen_flg) {
        this.taisyokusya_kensaku_kengen_flg = taisyokusya_kensaku_kengen_flg;
    }

    /**
     * tokei_bunseki_kengen���擾����B
     * @return String tokei_bunseki_kengen
     */
    public String getTokei_bunseki_kengen() {
        return tokei_bunseki_kengen;
    }

    /**
     * tokei_bunseki_kengen��ݒ肷��B
     * @param tokei_bunseki_kengen tokei_bunseki_kengen
     */
    public void setTokei_bunseki_kengen(String tokei_bunseki_kengen) {
        this.tokei_bunseki_kengen = tokei_bunseki_kengen;
    }

    /**
     * yakusyoku_code���擾����B
     * @return String yakusyoku_code
     */
    public String getYakusyoku_code() {
        return yakusyoku_code;
    }

    /**
     * yakusyoku_code��ݒ肷��B
     * @param yakusyoku_code yakusyoku_code
     */
    public void setYakusyoku_code(String yakusyoku_code) {
        this.yakusyoku_code = yakusyoku_code;
    }

    /**
     * yobi1���擾����B
     * @return String yobi1
     */
    public String getYobi1() {
        return yobi1;
    }

    /**
     * yobi1��ݒ肷��B
     * @param yobi1 yobi1
     */
    public void setYobi1(String yobi1) {
        this.yobi1 = yobi1;
    }

    /**
     * yobi2���擾����B
     * @return String yobi2
     */
    public String getYobi2() {
        return yobi2;
    }

    /**
     * yobi2��ݒ肷��B
     * @param yobi2 yobi2
     */
    public void setYobi2(String yobi2) {
        this.yobi2 = yobi2;
    }

    /**
     * yobi3���擾����B
     * @return String yobi3
     */
    public String getYobi3() {
        return yobi3;
    }

    /**
     * yobi3��ݒ肷��B
     * @param yobi3 yobi3
     */
    public void setYobi3(String yobi3) {
        this.yobi3 = yobi3;
    }

    /**
     * yobi4���擾����B
     * @return String yobi4
     */
    public String getYobi4() {
        return yobi4;
    }

    /**
     * yobi4��ݒ肷��B
     * @param yobi4 yobi4
     */
    public void setYobi4(String yobi4) {
        this.yobi4 = yobi4;
    }

    /**
     * yobi5���擾����B
     * @return String yobi5
     */
    public String getYobi5() {
        return yobi5;
    }

    /**
     * yobi5��ݒ肷��B
     * @param yobi5 yobi5
     */
    public void setYobi5(String yobi5) {
        this.yobi5 = yobi5;
    }
}
