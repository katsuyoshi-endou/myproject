/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g��  : ���V�e�A�iCareer�j
 *
 *
 * ���l : �Ȃ�
 *
 * ���� :
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/11/20  1.0         ringou       �V�K�쐬
 */
package jp.co.hisas.addon.batch.import_personal.checker;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;

import javax.naming.NamingException;

import jp.co.hisas.addon.batch.import_personal.dao.PersonalDAO;
import jp.co.hisas.addon.batch.import_personal.dao.SoshikiDAO;
import jp.co.hisas.addon.batch.import_personal.dao.YakusyokuDao;
import jp.co.hisas.addon.batch.import_personal.exception.BatchFailedException;
import jp.co.hisas.addon.batch.import_personal.exception.WrongArgumentException;
import jp.co.hisas.addon.batch.import_personal.man.MessageManager;
import jp.co.hisas.addon.batch.import_personal.record.PersonalProfileImportRecord;
import jp.co.hisas.addon.batch.import_personal.record.PersonalRecord;
import jp.co.hisas.addon.batch.import_personal.util.CheckUtils;
import jp.co.hisas.addon.batch.import_personal.util.CommonUtils;
import jp.co.hisas.addon.batch.import_personal.vo.BatchResultVO;
import jp.co.hisas.addon.batch.import_personal.vo.PersonalProfileCsvVO;
import jp.co.hisas.addon.batch.import_personal.vo.TorikomiLog;
import jp.co.hisas.career.learning.base.PCY_ServiceLocator;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 *
 * �N���X���F PersonalProfileCsvRecordChecker�N���X
 *
 * �@�\�����F CSV���R�[�h�̃f�[�^�ɑ΂���`�F�b�N���s��
 *
 * </PRE>
 */
public final class PersonalProfileCsvRecordChecker {

    /* ����ō��̒����y�эŏ��̒���*/
    /** ����NO�ő包��*/
    private final static int SIMEI_NO_MAXLENGTH = 10;

    /** ����NO�ŏ�����(�捞�f�[�^�̓�2�����폜���邽��)*/
    private final static int SIMEI_NO_MINLENGTH = 3;

    /** �p�X���[�h�ő包��*/
    private final static int PASSWORD_MAXLENGTH = 10;

    /** �p�X���[�h�ŏ�����*/
    private final static int PASSWORD_MINLENGTH = 6;

    /** ���������ő包��*/
    private final static int KANJI_SIMEI_MAXLENGTH = 20;

    /** ���������ŏ�����*/
    private final static int KANJI_SIMEI_MINLENGTH = 1;

    /** �J�i�����i�S�p�j�ő包��*/
    private final static int KANA_SIMEI_MAXLENGTH = 40;

    /** �J�i�����i�S�p�j�ŏ�����*/
    private final static int KANA_SIMEI_MINLENGTH = 1;

    /** �g�D�R�[�h�ő包��*/
    private final static int SOSIKI_CODE_MAXLENGTH = 20;

    /** �g�D�R�[�h�ŏ�����*/
    private final static int SOSIKI_CODE_MINLENGTH = 0;

    /** Mail�ő包��*/
    private final static int MAIL_MAXLENGTH = 50;

    /** Mail�ŏ�����*/
    private final static int MAIL_MINLENGTH = 0;

    /** Job�i���{��j�ő包��*/
    private final static int YOBI2_MAXLENGTH = 30;

    /** Job�i���{��j�ŏ�����*/
    private final static int YOBI2_MINLENGTH = 0;

    /** �ő包��*/
    // �G���[���b�Z�[�W�R�[�h��`
    /** ����NO�G���[�P */
    private static final String SIMEI_NO_ERROR_CODE1 = "HJE-2011";

    /** ����NO�G���[�Q */
    private static final String SIMEI_NO_ERROR_CODE2 = "HJE-2012";

    /** ����NO�G���[�R */
    private static final String SIMEI_NO_ERROR_CODE3 = "HJE-2013";

    /** �{���^�����t���O�G���[�P */
    private static final String HONMU_FLG_ERROR_CODE1 = "HJE-2031";

    /** �{���^�����t���O�G���[�Q */
    private static final String HONMU_FLG_ERROR_CODE2 = "HJE-2032";

    /** ���������G���[�P */
    private static final String KANJI_SIMEI_ERROR_CODE1 = "HJE-2041";

    /** ���������G���[�Q */
    private static final String KANJI_SIMEI_ERROR_CODE2 = "HJE-2042";

    /** �J�i�����i�S�p�j�G���[�P */
    private static final String KANA_SIMEI_ERROR_CODE1 = "HJE-2051";

    /** �J�i�����i�S�p�j�G���[�Q */
    private static final String KANA_SIMEI_ERROR_CODE2 = "HJE-2052";

    /** �����i�p���j�G���[ */
    private static final String EIJI_SIMEI_ERROR_CODE = "HJE-2061";

    /** ���ʃG���[�P */
    private static final String SEIBETU_ERROR_CODE1 = "HJE-2071";

    /** ���ʃG���[�Q */
    private static final String SEIBETU_ERROR_CODE2 = "HJE-2072";

    /** ���N�����G���[�P */
    private static final String SEINENGAPPI_ERROR_CODE1 = "HJE-2081";

    /** ���N�����G���[�Q */
    private static final String SEINENGAPPI_ERROR_CODE2 = "HJE-2082";

    /** ���ДN���G���[�P */
    private static final String NYUSYA_NENGETU_ERROR_CODE1 = "HJE-2091";

    /** ���ДN���G���[�Q */
    private static final String NYUSYA_NENGETU_ERROR_CODE2 = "HJE-2092";

    /** �ސE�N�����G���[�P */
    private static final String TAISYOKU_NENGAPPI_ERROR_CODE1 = "HJE-2111";

    /** �ސE�N�����G���[�Q */
    private static final String TAISYOKU_NENGAPPI_ERROR_CODE2 = "HJE-2112";

    /** �ސE�N�����G���[�R */
    private static final String TAISYOKU_NENGAPPI_ERROR_CODE3 = "HJE-2113";

    /** ��E�R�[�h�G���[�P */
    private static final String YAKUSYOKU_CODE_ERROR_CODE1 = "HJE-2131";

    /** ��E�R�[�h�G���[�Q */
    private static final String YAKUSYOKU_CODE_ERROR_CODE2 = "HJE-2132";

    /** �g�D�R�[�h�G���[�P */
    private static final String SOSIKI_CODE_ERROR_CODE1 = "HJE-2151";

    /** �g�D�R�[�h�G���[�Q */
    private static final String SOSIKI_CODE_ERROR_CODE2 = "HJE-2152";

    /** �g�D�R�[�h�G���[�R */
    private static final String SOSIKI_CODE_ERROR_CODE3 = "HJE-2153";

    /** Mail�G���[�P */
    private static final String MAIL_ERROR_CODE1 = "HJE-2164";

    /** Mail�G���[�Q */
    private static final String MAIL_ERROR_CODE2 = "HJE-2165";

    /** �O���[�vID�G���[ */
    private static final String YOBI2_ERROR_CODE = "HJE-2172";

    /** �o�b�`�G���[���e�i�[ */
    private BatchResultVO brl;

    /** �G���[���e�E���R�[�h���e �i�[ */
    private HashMap hm;

    int csvRecordCount;

    private PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance( );

    /**
     *�R���X�g���N�^
     */
    public PersonalProfileCsvRecordChecker() {
        brl = new BatchResultVO( );
        hm = new HashMap( );
        csvRecordCount = 0;
        locator = PCY_ServiceLocator.getInstance( );
    }

    /**
     *CSV�̓��e�̃`�F�b�N���s���BOK�̏ꍇ�́A������s���p�[�\�i�����R�[�h��߂��B
     *�{������CSV���R�[�h�̍��ڐ������������Ƃ�O��ōs��
     *@param PersonaProfilelCsvVO PersonaProfilelCsvVO CSV�̓��e(ValueObject)
     *@return HashMap �G���[���e�E���R�[�h���e
     *@exception NamingException �l�[�~���O��O�B
     *@exception WrongArgumentException �����ُ�B
     *@exception SQLException DB�֘A��O�B
     *@exception FileNotFoundException ���\�[�X�ُ�
     *@exception IOException IO��O�B
     *@exception BatchFailedException �o�b�`���s��O�B
     */
    public HashMap check(PersonalProfileCsvVO personaProfilelCsvVO) throws NamingException,
            WrongArgumentException, SQLException, FileNotFoundException, IOException,
            BatchFailedException {

        Log.method( "", "IN", "" );
        PersonalDAO personalDAO = new PersonalDAO( locator.getDataSource( ) );
        ReadFile.refreshFile( );

        PersonalProfileImportRecord personalPIRecord = new PersonalProfileImportRecord( );
        csvRecordCount = personaProfilelCsvVO.getCsvRecordCount( );

        ///////////////////////////////////////////////
        //���ڒl�`�F�b�N                             //
        ///////////////////////////////////////////////

        checkSimei_No( personaProfilelCsvVO.getSimei_no() , SIMEI_NO_MINLENGTH, SIMEI_NO_MAXLENGTH );
        checkKanji_simei( CommonUtils.convertHalfSizeKana( personaProfilelCsvVO.getKanji_simei() ), KANJI_SIMEI_MINLENGTH,  // CHG#2007/3/7 s-hiura
                KANJI_SIMEI_MAXLENGTH );
        checkKana_simei( personaProfilelCsvVO.getKana_simei(), KANA_SIMEI_MINLENGTH,
                KANA_SIMEI_MAXLENGTH );
        checkSeibetu( personaProfilelCsvVO.getSeibetu() );
        checkNyusya_nengetu( personaProfilelCsvVO.getNyusya_nengetu() );
        checkTaisyoku_nengappi( personaProfilelCsvVO.getTaisyoku_nengappi() );
        checkHonmu_flg( personaProfilelCsvVO.getHonmu_flg() );
        checkSosiki_code( personaProfilelCsvVO.getSosiki_code(), SOSIKI_CODE_MAXLENGTH );
        checkSeinengappi( personaProfilelCsvVO.getSeinengappi() );

        if("����".equals(personaProfilelCsvVO.getHonmu_flg())){
            //�����̏ꍇ
            checkYakusyoku_code( personaProfilelCsvVO.getYakusyoku_kenmu_code());
        }

        checkYakusyoku_code( personaProfilelCsvVO.getYakusyoku_honmu_code());
//����2005/11/29 ringou B-A30AI1-021
//        checkMail( personaProfilelCsvVO.getMail(), YOBI2_MAXLENGTH );
        checkMail( personaProfilelCsvVO.getMail(), MAIL_MAXLENGTH );
//����2005/11/29 ringou B-A30AI1-021
        checkYobi2( personaProfilelCsvVO.getKinmuchi(), YOBI2_MAXLENGTH );

        if(brl.getTorikomiLogSize( ) > 0){
            //1���ł��G���[������ꍇ
            hm.put( "error", brl );
            Log.method( "", "OUT", "" );
            return hm;
        }
        ///////////////////////////////////////////////
        //�p�[�\�i��������������                   //
        ///////////////////////////////////////////////

        //����NO
        String simei_no = personaProfilelCsvVO.getSimei_no()
            .substring(2, personaProfilelCsvVO.getSimei_no().length());


        PersonalRecord personalRecord = null;

        //�p�[�\�����e�[�u��������
        if("�{��".equals(personaProfilelCsvVO.getHonmu_flg())){
            personalRecord = personalDAO.lookupPersonInfoHonmu( simei_no );    
        }else{
            personalRecord = personalDAO.lookupPersonInfo( simei_no ,"2", personaProfilelCsvVO.getSosiki_code());
        }
            
        if(personalRecord == null){
            //�Y�����R�[�h�Ȃ�
            personalPIRecord.setModify_type( "0" );
            personalPIRecord.setPassword( simei_no );
//����2005/11/29 ringou
            personalPIRecord.setSimei_no( simei_no );
            personalPIRecord.setSimei_no_flg(simei_no);
//����2005/11/29 ringou
        }else{
            //�Y�����R�[�h����
            personalPIRecord.setModify_type( "1" );
//����2005/11/29 ringou
            personalPIRecord.setSimei_no(simei_no);
//����2005/11/29 ringou
            personalPIRecord.setPassword(personalRecord.getPassword());
            personalPIRecord.setHonmu_flg(personalRecord.getHonmu_flg());
            personalPIRecord.setSimei_no_flg(personalRecord.getSimei_no_flg());
            personalPIRecord.setKanji_simei(personalRecord.getKanji_simei());
            personalPIRecord.setKana_simei(personalRecord.getKana_simei());
            personalPIRecord.setEiji_simei(personalRecord.getEiji_simei());
            personalPIRecord.setSeibetu(personalRecord.getSeibetu());
            personalPIRecord.setSeinengappi(personalRecord.getSeinengappi());
            personalPIRecord.setNyusya_nengetu(personalRecord.getNyusya_nengetu());
            personalPIRecord.setGensyoku_taisyoku_flg(personalRecord.getGensyoku_taisyoku_flg());
            personalPIRecord.setTaisyoku_nengappi(personalRecord.getTaisyoku_nengappi());
            personalPIRecord.setKengen_code(personalRecord.getKengen_code());
            personalPIRecord.setYakusyoku_code(personalRecord.getYakusyoku_code());
            personalPIRecord.setSyokui_code(personalRecord.getSyokui_code());
            personalPIRecord.setSosiki_code(personalRecord.getSosiki_code());
            personalPIRecord.setSyozoku_code_1(personalRecord.getSyozoku_code_1());
            personalPIRecord.setSyozoku_code_2(personalRecord.getSyozoku_code_2());
            personalPIRecord.setSyozoku_code_3(personalRecord.getSyozoku_code_3());
            personalPIRecord.setSyozoku_code_4(personalRecord.getSyozoku_code_4());
            personalPIRecord.setSyozoku_code_5(personalRecord.getSyozoku_code_5());
            personalPIRecord.setSyozoku_code_6(personalRecord.getSyozoku_code_6());
            personalPIRecord.setSyozoku_code_7(personalRecord.getSyozoku_code_7());
            personalPIRecord.setSyozoku_code_8(personalRecord.getSyozoku_code_8());
            personalPIRecord.setSyozoku_code_9(personalRecord.getSyozoku_code_9());
            personalPIRecord.setNaisen(personalRecord.getNaisen());
            personalPIRecord.setGaisen(personalRecord.getGaisen());
            personalPIRecord.setFax_no(personalRecord.getFax_no());
            personalPIRecord.setMail(personalRecord.getMail());
            personalPIRecord.setJiko_pr(personalRecord.getJiko_pr());
            personalPIRecord.setYobi1(personalRecord.getYobi1());
            personalPIRecord.setYobi2(personalRecord.getYobi2());
            personalPIRecord.setYobi3(personalRecord.getYobi3());
            personalPIRecord.setYobi4(personalRecord.getYobi4());
            personalPIRecord.setYobi5(personalRecord.getYobi5());
            personalPIRecord.setSyoku_code1(personalRecord.getSyoku_code1());
            personalPIRecord.setSenmon_code1(personalRecord.getSenmon_code1());
            personalPIRecord.setLevel_code1(personalRecord.getLevel_code1());
            personalPIRecord.setSougou_t_do1(personalRecord.getSougou_t_do1());
            personalPIRecord.setSyoku_code2(personalRecord.getSyoku_code2());
            personalPIRecord.setSenmon_code2(personalRecord.getSenmon_code2());
            personalPIRecord.setLevel_code2(personalRecord.getLevel_code2());
            personalPIRecord.setSougou_t_do2(personalRecord.getSougou_t_do2());
            personalPIRecord.setSyoku_code3(personalRecord.getSyoku_code3());
            personalPIRecord.setSenmon_code3(personalRecord.getSenmon_code3());
            personalPIRecord.setLevel_code3(personalRecord.getLevel_code3());
            personalPIRecord.setSougou_t_do3(personalRecord.getSougou_t_do3());
            personalPIRecord.setAssessment_kokai_flg(personalRecord.getAssessment_kokai_flg());
            personalPIRecord.setKao_kokai_flg(personalRecord.getKao_kokai_flg());
            personalPIRecord.setSkill_kokai_flg(personalRecord.getSkill_kokai_flg());
            personalPIRecord.setKyoiku_kokai_flg(personalRecord.getKyoiku_kokai_flg());
            personalPIRecord.setSikaku_kokai_flg(personalRecord.getSikaku_kokai_flg());
            personalPIRecord.setHyosyo_kokai_flg(personalRecord.getHyosyo_kokai_flg());
            personalPIRecord.setRonbun_kokai_flg(personalRecord.getRonbun_kokai_flg());
            personalPIRecord.setSyagai_kokai_flg(personalRecord.getSyagai_kokai_flg());
            personalPIRecord.setGakureki_kokai_flg(personalRecord.getGakureki_kokai_flg());
            personalPIRecord.setSyanaireki_kokai_flg(personalRecord.getSyanaireki_kokai_flg());
            personalPIRecord.setZensyokureki_kokai_flg(personalRecord.getZensyokureki_kokai_flg());
            personalPIRecord.setSosiki_kokai_flg(personalRecord.getSosiki_kokai_flg());
            personalPIRecord.setYakusyoku_kokai_flg(personalRecord.getYakusyoku_kokai_flg());
            personalPIRecord.setSyokui_kokai_flg(personalRecord.getSyokui_kokai_flg());
            personalPIRecord.setSkill_mainte_flg(personalRecord.getSkill_mainte_flg());
//����2005/11/29 ringou
            personalPIRecord.setSyokumu_kokai_flg(personalRecord.getSyokumu_kokai_flg());
//����2005/11/29 ringou
            personalPIRecord.setKanren_gyomu_touroku_flg(personalRecord.getKanren_gyomu_touroku_flg());
            personalPIRecord.setPersonal_mainte_flg(personalRecord.getPersonal_mainte_flg());
            personalPIRecord.setSikaku_mainte_flg(personalRecord.getSikaku_mainte_flg());
            personalPIRecord.setKenpo_mainte_flg(personalRecord.getKenpo_mainte_flg());
            personalPIRecord.setLogin_osirase_mainte_flg(personalRecord.getLogin_osirase_mainte_flg());
            personalPIRecord.setTokei_bunseki_kengen(personalRecord.getTokei_bunseki_kengen());
            personalPIRecord.setTaisyokusya_kensaku_kengen_flg(personalRecord.getTaisyokusya_kensaku_kengen_flg());
            personalPIRecord.setHikoukai_kensaku_kengen_flg(personalRecord.getHikoukai_kensaku_kengen_flg());
            personalPIRecord.setGroup_nyusya_nengetu(personalRecord.getGroup_nyusya_nengetu());
            personalPIRecord.setSosiki_mainte_flg(personalRecord.getSosiki_mainte_flg());
            personalPIRecord.setKyoiku_mainte_flg(personalRecord.getKyoiku_mainte_flg());
            personalPIRecord.setRonbun_mainte_flg(personalRecord.getRonbun_mainte_flg());
            personalPIRecord.setHyosyo_mainte_flg(personalRecord.getHyosyo_mainte_flg());
            personalPIRecord.setSyagai_ronbun_mainte_flg(personalRecord.getSyagai_ronbun_mainte_flg());
            personalPIRecord.setSyagai_mainte_flg(personalRecord.getSyagai_mainte_flg());
            personalPIRecord.setGamen_kokai_flg_yobi1(personalRecord.getGamen_kokai_flg_yobi1());
            personalPIRecord.setGamen_kokai_flg_yobi2(personalRecord.getGamen_kokai_flg_yobi2());
            personalPIRecord.setGamen_kokai_flg_yobi3(personalRecord.getGamen_kokai_flg_yobi3());
            personalPIRecord.setGamen_kokai_flg_yobi4(personalRecord.getGamen_kokai_flg_yobi4());
            personalPIRecord.setGamen_kokai_flg_yobi5(personalRecord.getGamen_kokai_flg_yobi5());
            personalPIRecord.setGamen_kokai_flg_yobi6(personalRecord.getGamen_kokai_flg_yobi6());
            personalPIRecord.setGamen_kokai_flg_yobi7(personalRecord.getGamen_kokai_flg_yobi7());
            personalPIRecord.setGamen_kokai_flg_yobi8(personalRecord.getGamen_kokai_flg_yobi8());
            personalPIRecord.setGamen_kokai_flg_yobi9(personalRecord.getGamen_kokai_flg_yobi9());
            personalPIRecord.setGamen_kokai_flg_yobi10(personalRecord.getGamen_kokai_flg_yobi10());
            personalPIRecord.setGamen_kokai_flg_yobi11(personalRecord.getGamen_kokai_flg_yobi11());
            personalPIRecord.setGamen_kokai_flg_yobi12(personalRecord.getGamen_kokai_flg_yobi12());
            personalPIRecord.setMainte_flg_yobi1(personalRecord.getMainte_flg_yobi1());
            personalPIRecord.setYobi6(personalRecord.getYobi6());
            personalPIRecord.setYobi7(personalRecord.getYobi7());
            personalPIRecord.setYobi8(personalRecord.getYobi8());
            personalPIRecord.setYobi9(personalRecord.getYobi9());
            personalPIRecord.setYobi10(personalRecord.getYobi10());
            personalPIRecord.setYakusyoku(personalRecord.getYakusyoku());
            personalPIRecord.setYobi_ryoiki(personalRecord.getYobi_ryoiki());
            personalPIRecord.setKaigai_kokai_flg(personalRecord.getKaigai_kokai_flg());
            personalPIRecord.setKaigai_mainte_flg(personalRecord.getKaigai_mainte_flg());
            personalPIRecord.setJinmei_ryakusyo(personalRecord.getJinmei_ryakusyo());
            personalPIRecord.setBusyo_ryakusyo_mei(personalRecord.getBusyo_ryakusyo_mei());
            personalPIRecord.setGakureki_gakko_mei(personalRecord.getGakureki_gakko_mei());
            personalPIRecord.setGakureki_gakubu_mei(personalRecord.getGakureki_gakubu_mei());
            personalPIRecord.setGakureki_gakka_mei(personalRecord.getGakureki_gakka_mei());
            personalPIRecord.setGakureki_sotugyo_nengetu(personalRecord.getGakureki_sotugyo_nengetu());
//����2005/11/29 ringou
            personalPIRecord.setSyanaibin(personalRecord.getSyanaibin());
//����2005/11/29 ringou            

            
        }

        ///////////////////////////////////////////////
        //CSV���R�[�h��personalPIRecord�Ɋi�[        //
        ///////////////////////////////////////////////

        boolean honmflg = false;

//����2005/11/29 ringou
//        if(personalPIRecord.getSimei_no() == null
//            || "".equals(personalPIRecord.getSimei_no())){
//            //�ǉ��f�[�^�̏ꍇ
//            personalPIRecord.setSimei_no( simei_no );
//            personalPIRecord.setSimei_no_flg(simei_no);
//        }
//����2005/11/29 ringou
//����2005/11/29 ringou B-A30AI-032
        if("0".equals(personalPIRecord.getModify_type())){
            //�ǉ��̏ꍇ
            personalPIRecord.setKanji_simei( CommonUtils.convertHalfSizeKana( personaProfilelCsvVO.getKanji_simei() ) );  // CHG#2007/3/7 s-hiura
            personalPIRecord.setKana_simei( personaProfilelCsvVO.getKana_simei() );
            
            if("�j".equals(personaProfilelCsvVO.getSeibetu()) ){
                personalPIRecord.setSeibetu( "1" );        
            }else if("��".equals(personaProfilelCsvVO.getSeibetu()) ){
                personalPIRecord.setSeibetu( "2" );    
            }
            personalPIRecord.setNyusya_nengetu( personaProfilelCsvVO.getNyusya_nengetu().replaceAll("/","") );
            personalPIRecord.setSeinengappi( personaProfilelCsvVO.getSeinengappi().replaceAll("/","") );
			personalPIRecord.setYobi2(  personaProfilelCsvVO.getKinmuchi() );
        }else{
            //�X�V�̏ꍇ �}�X�^�̒l�ɕt�^����Ă�����J����J�t���O�ɂčX�V����B
            String publicFlag = null;

            publicFlag = personalPIRecord.getKanji_simei().substring(0,1);
            personalPIRecord.setKanji_simei( publicFlag.concat( CommonUtils.convertHalfSizeKana( personaProfilelCsvVO.getKanji_simei() ) ) );  // CHG#2007/3/7 s-hiura
 
            publicFlag = personalPIRecord.getKana_simei().substring(0,1);
            personalPIRecord.setKana_simei( publicFlag.concat( personaProfilelCsvVO.getKana_simei() ) );

			publicFlag = personalPIRecord.getSeibetu().substring(0,1);
			if("�j".equals(personaProfilelCsvVO.getSeibetu()) ){
				personalPIRecord.setSeibetu( publicFlag.concat( "1" ) );
			}else if("��".equals(personaProfilelCsvVO.getSeibetu()) ){
				personalPIRecord.setSeibetu( publicFlag.concat( "2" ) );
			}

            publicFlag = personalPIRecord.getNyusya_nengetu().substring(0,1);
            personalPIRecord.setNyusya_nengetu( publicFlag.concat( personaProfilelCsvVO.getNyusya_nengetu().replaceAll("/","") ) );

            publicFlag = personalPIRecord.getSeinengappi().substring(0,1);
            personalPIRecord.setSeinengappi( publicFlag.concat( personaProfilelCsvVO.getSeinengappi().replaceAll("/","") ) );

            publicFlag = personalPIRecord.getYobi2().substring(0,1);
            if( personalPIRecord.getYobi2() != null ){
                personalPIRecord.setYobi2(  publicFlag.concat(personaProfilelCsvVO.getKinmuchi()) );
            }else{
                personalPIRecord.setYobi2( publicFlag );
            }
        }
//����2005/11/29 ringou B-A30AI-032
//����2005/11/29 ringou B-A30AI-028
//        if(personalPIRecord.getTaisyoku_nengappi() != null 
//            && !"".equals(personalPIRecord.getTaisyoku_nengappi())) {
        if(personaProfilelCsvVO.getTaisyoku_nengappi() != null 
            && !"".equals(personaProfilelCsvVO.getTaisyoku_nengappi())) {
//����2005/11/29 ringou B-A30AI-028
            personalPIRecord.setTaisyoku_nengappi( personaProfilelCsvVO.getTaisyoku_nengappi().replaceAll("/","") );
        }
        
        if(personaProfilelCsvVO.getTaisyoku_nengappi() == null 
            || "".equals(personaProfilelCsvVO.getTaisyoku_nengappi())){
            personalPIRecord.setGensyoku_taisyoku_flg("1");
                
        } else {
            if(Integer.parseInt(CommonUtils.GetDay()) <= Integer.parseInt(personaProfilelCsvVO.getTaisyoku_nengappi().replaceAll("/",""))){
                personalPIRecord.setGensyoku_taisyoku_flg("1");    
            }else{
                personalPIRecord.setGensyoku_taisyoku_flg("2");
            }
        }
//����2005/11/30 ringou 
//        if(getDefaultFlag("KENGEN_CODE1").equals(personaProfilelCsvVO.getYakusyoku_honmu_code())){
//            personalPIRecord.setKengen_code("1");
//        }else if(getDefaultFlag("KENGEN_CODE2").equals(personaProfilelCsvVO.getYakusyoku_honmu_code())){
//            personalPIRecord.setKengen_code("2");
//        }else{
//            personalPIRecord.setKengen_code("3");
//        }
//����2005/11/30 ringou
        
        if("�{��".equals(personaProfilelCsvVO.getHonmu_flg())){
            honmflg = true;
            personalPIRecord.setHonmu_flg( "1" );    
        }else{
            personalPIRecord.setHonmu_flg( "2" );
        }
        
        personalPIRecord.setSosiki_code( personaProfilelCsvVO.getSosiki_code() );
//����2005/11/29 ringou B-A30AI-032
//        personalPIRecord.setSeinengappi( personaProfilelCsvVO.getSeinengappi().replaceAll("/","") );
//����2005/11/29 ringou B-A30AI-032
            
        if(honmflg){
            //�{���̏ꍇ
//����2005//11/29 ringou B-A30AI1-022
//            personalPIRecord.setYakusyoku_code( personaProfilelCsvVO.getYakusyoku_honmu_code() );
            if(getDefaultFlag("KENGEN_CODE1").equals(personaProfilelCsvVO.getYakusyoku_honmu_code())){
                personalPIRecord.setKengen_code("1");
                personalPIRecord.setYakusyoku_code("1");
            }else if(getDefaultFlag("KENGEN_CODE2").equals(personaProfilelCsvVO.getYakusyoku_honmu_code())){
                personalPIRecord.setKengen_code("2");
                personalPIRecord.setYakusyoku_code("2");
            }else{
                personalPIRecord.setKengen_code("3");
                personalPIRecord.setYakusyoku_code("3");
            }

//����2005//11/29 ringou B-A30AI1-022
        }else{
            //�����̏ꍇ
//����2005//11/29 ringou B-A30AI1-022
//            personalPIRecord.setYakusyoku_code( personaProfilelCsvVO.getYakusyoku_kenmu_code() );
            if(getDefaultFlag("KENGEN_CODE1").equals(personaProfilelCsvVO.getYakusyoku_kenmu_code())){
				personalPIRecord.setKengen_code("1");
                personalPIRecord.setYakusyoku_code("1");
            }else if(getDefaultFlag("KENGEN_CODE2").equals(personaProfilelCsvVO.getYakusyoku_kenmu_code())){
				personalPIRecord.setKengen_code("2");
                personalPIRecord.setYakusyoku_code("2");
            }else{
				personalPIRecord.setKengen_code("3");
                personalPIRecord.setYakusyoku_code("3");
            }
//����2005//11/29 ringou B-A30AI1-022
        }
        if(personalPIRecord.getMail() != null 
            || !"".equals(personalPIRecord.getMail())){
            personalPIRecord.setMail(  personaProfilelCsvVO.getMail() );
        }
//����2005//11/29 ringou B-A30AI1-031
//        personalPIRecord.setYobi2(  personaProfilelCsvVO.getKinmuchi() );
//����2005//11/29 ringou B-A30AI1-031

        hm.put( "record", personalPIRecord );
        hm.put( "error", brl );
        Log.method( "", "OUT", "" );
        return hm;
    }

    /**
     * ����NO�`�F�b�N
     * @param simeiNo ����NO
     * @param minLength �ŏ��s���B
     * @param maxLength �ő�s���B
     * @return true: OK, false : �G���[�B
     * @exception FileNotFoundException ���\�[�X�ُ�
     * @exception IOException IO��O�B
     * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
     */
    private boolean checkSimei_No(String simeiNo, int minLength, int maxLength)
            throws FileNotFoundException, IOException, BatchFailedException {
        Log.method( "", "IN", "" );

        if (!CheckUtils.isNotNull( simeiNo )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( SIMEI_NO_ERROR_CODE1 );
            tkl.setErrorMessage( MessageManager.getMessage( SIMEI_NO_ERROR_CODE1 ) );
            brl.addTorikomiLog( tkl );
            Log.method( "", "OUT", "" );
            return false;
        }

        if (!CheckUtils.isByteSizeUnder( simeiNo, maxLength )
                || !CheckUtils.isByteSizeOver( simeiNo, minLength )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( SIMEI_NO_ERROR_CODE2 );
            tkl.setErrorMessage( MessageManager.getMessage( SIMEI_NO_ERROR_CODE2 ) );
            brl.addTorikomiLog( tkl );
            Log.method( "", "OUT", "" );
            return false;
        }

        if (!CheckUtils.isAlphabetOrNumeric( simeiNo )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( SIMEI_NO_ERROR_CODE3 );
            tkl.setErrorMessage( MessageManager.getMessage( SIMEI_NO_ERROR_CODE3 ) );
            brl.addTorikomiLog( tkl );
            Log.method( "", "OUT", "" );
            return false;
        }

        Log.method( "", "OUT", "" );

        return true;
    }

    /**
     * �{���^�����t���O�`�F�b�N
     * @param honmuFlg �{���^�����t���O
     * @exception FileNotFoundException ���\�[�X�ُ�
     * @exception IOException IO��O�B
     * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
     */
    private void checkHonmu_flg(String honmuFlg) throws FileNotFoundException, IOException,
            BatchFailedException {
        Log.method( "", "IN", "" );

        if (!CheckUtils.isNotNull( honmuFlg )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( HONMU_FLG_ERROR_CODE1 );
            tkl.setErrorMessage( MessageManager.getMessage( HONMU_FLG_ERROR_CODE1 ) );
            brl.addTorikomiLog( tkl );
            Log.method( "", "OUT", "" );
            return;
        }

        if (!"�{��".equals( honmuFlg ) && !"����".equals( honmuFlg )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( HONMU_FLG_ERROR_CODE2 );
            tkl.setErrorMessage( MessageManager.getMessage( HONMU_FLG_ERROR_CODE2 ) );
            brl.addTorikomiLog( tkl );
        }
        
        Log.method( "", "OUT", "" );

    }

    /**
     * ���������`�F�b�N
     * @param kanjiSimei ��������
     * @param minLength �ŏ��s���B
     * @param maxLength �ő�s���B
     * @exception FileNotFoundException ���\�[�X�ُ�
     * @exception IOException IO��O�B
     * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
     */
    private void checkKanji_simei(String kanjiSimei, int minLength, int maxLength)
            throws FileNotFoundException, IOException, BatchFailedException {
        Log.method( "", "IN", "" );

        if (!CheckUtils.isNotNull( kanjiSimei )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( KANJI_SIMEI_ERROR_CODE1 );
            tkl.setErrorMessage( MessageManager.getMessage( KANJI_SIMEI_ERROR_CODE1 ) );
            brl.addTorikomiLog( tkl );
            Log.method( "", "OUT", "" );
            return;
        }

        if (!CheckUtils.isNotIncludeNGWord( kanjiSimei )
                || !CheckUtils.isByteSizeUnder( kanjiSimei, maxLength )
                || !CheckUtils.isByteSizeOver( kanjiSimei, minLength )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( KANJI_SIMEI_ERROR_CODE2 );
            tkl.setErrorMessage( MessageManager.getMessage( KANJI_SIMEI_ERROR_CODE2 ) );
            brl.addTorikomiLog( tkl );
        }

        Log.method( "", "OUT", "" );
    }

    /**
     * �J�i�����i���p�j�`�F�b�N
     * @param kanaSimei �J�i�����i���p�j
     * @param minLength �ŏ��s���B
     * @param maxLength �ő�s���B
     * @exception FileNotFoundException ���\�[�X�ُ�
     * @exception IOException IO��O�B
     * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
     */
    private void checkKana_simei(String kanaSimei, int minLength, int maxLength)
            throws FileNotFoundException, IOException, BatchFailedException {
        Log.method( "", "IN", "" );

        if (!CheckUtils.isNotNull( kanaSimei )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( KANA_SIMEI_ERROR_CODE1 );
            tkl.setErrorMessage( MessageManager.getMessage( KANA_SIMEI_ERROR_CODE1 ) );
            brl.addTorikomiLog( tkl );
            Log.method( "", "OUT", "" );
            return;
        }

        if (!CheckUtils.isNotIncludeNGWord( kanaSimei )
                || !CheckUtils.isByteSizeUnder( kanaSimei, maxLength )
                || !CheckUtils.isByteSizeOver( kanaSimei, minLength )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( KANA_SIMEI_ERROR_CODE2 );
            tkl.setErrorMessage( MessageManager.getMessage( KANA_SIMEI_ERROR_CODE2 ) );
            brl.addTorikomiLog( tkl );
        }

        Log.method( "", "OUT", "" );
    }

    /**
     * ���ʃ`�F�b�N
     * @param seibetu ����
     * @exception FileNotFoundException ���\�[�X�ُ�
     * @exception IOException IO��O�B
     * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
     */
    private void checkSeibetu(String seibetu) throws FileNotFoundException, IOException,
            BatchFailedException {
        Log.method( "", "IN", "" );

        if (!CheckUtils.isNotNull( seibetu )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( SEIBETU_ERROR_CODE1 );
            tkl.setErrorMessage( MessageManager.getMessage( SEIBETU_ERROR_CODE1 ) );
            brl.addTorikomiLog( tkl );
            Log.method( "", "OUT", "" );
            return;
        }

        if (!"�j".equals( seibetu ) && !"��".equals( seibetu )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( SEIBETU_ERROR_CODE2 );
            tkl.setErrorMessage( MessageManager.getMessage( SEIBETU_ERROR_CODE2 ) );
            brl.addTorikomiLog( tkl );
        }
        Log.method( "", "OUT", "" );

    }

    /**
     * ���N�����`�F�b�N
     * @param seinengappi ���N����
     * @exception FileNotFoundException ���\�[�X�ُ�
     * @exception IOException IO��O�B
     * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
     */
    private void checkSeinengappi(String seinengappi) throws FileNotFoundException, IOException,
            BatchFailedException {
        Log.method( "", "IN", "" );

        if (!CheckUtils.isNotNull( seinengappi )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( SEINENGAPPI_ERROR_CODE1 );
            tkl.setErrorMessage( MessageManager.getMessage( SEINENGAPPI_ERROR_CODE1 ) );
            brl.addTorikomiLog( tkl );
            Log.method( "", "OUT", "" );
            return;
        }
        // "/"���͂����ăt�H�[�}�b�g�`�F�b�N
        if (!CheckUtils.isYYYYMMDDFormat( seinengappi.replaceAll("/","") )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( SEINENGAPPI_ERROR_CODE2 );
            tkl.setErrorMessage( MessageManager.getMessage( SEINENGAPPI_ERROR_CODE2 ) );
            brl.addTorikomiLog( tkl );
        }
        Log.method( "", "OUT", "" );

    }

    /**�����O���[�v���ДN���`�F�b�N
     * @param nyusyaNengetu �����O���[�v���ДN��
     * @exception FileNotFoundException ���\�[�X�ُ�
     * @exception IOException IO��O�B
     * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
     */
    private void checkNyusya_nengetu(String nyusyaNengetu) throws FileNotFoundException,
            IOException, BatchFailedException {
        Log.method( "", "IN", "" );

        if (!CheckUtils.isNotNull( nyusyaNengetu )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( NYUSYA_NENGETU_ERROR_CODE1 );
            tkl.setErrorMessage( MessageManager.getMessage( NYUSYA_NENGETU_ERROR_CODE1 ) );
            brl.addTorikomiLog( tkl );
            Log.method( "", "OUT", "" );
            return;
        }

        // "/"���͂����ăt�H�[�}�b�g�`�F�b�N
        if (!CheckUtils.isYYYYMMDDFormat( nyusyaNengetu.replaceAll("/","") )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( NYUSYA_NENGETU_ERROR_CODE2 );
            tkl.setErrorMessage( MessageManager.getMessage( NYUSYA_NENGETU_ERROR_CODE2 ) );
            brl.addTorikomiLog( tkl );
        }
        Log.method( "", "OUT", "" );
    }

    /**
     * �ސE�N�����`�F�b�N
     * @param taisyokuNengappi �ސE�N����
     * @exception FileNotFoundException ���\�[�X�ُ�
     * @exception IOException IO��O�B
     * @exception BatchFailedException �`�F�b�N���ʂ�NG�B
     */
    private void checkTaisyoku_nengappi(String taisyokuNengappi)
            throws FileNotFoundException, IOException, BatchFailedException {
        Log.method( "", "IN", "" );

        if (CheckUtils.isNotNull( taisyokuNengappi )) {
            //"/"���͂����ăt�H�[�}�b�g�`�F�b�N
            if (!CheckUtils.isYYYYMMDDFormat( taisyokuNengappi.replaceAll("/","") )) {
                TorikomiLog tkl = new TorikomiLog( );
                tkl.setLineNo( csvRecordCount );
                tkl.setMsgID( TAISYOKU_NENGAPPI_ERROR_CODE1 );
                tkl.setErrorMessage( MessageManager.getMessage( TAISYOKU_NENGAPPI_ERROR_CODE1 ) );
                brl.addTorikomiLog( tkl );
                Log.method( "", "OUT", "" );
                return;
            }
        }
        Log.method( "", "OUT", "" );
    }

    /**
     * ��E�R�[�h�`�F�b�N
     * @param yakusyokuCode ��E�R�[�h
     * @exception FileNotFoundException ���\�[�X�ُ�
     * @exception WrongArgumentException �����ُ�B
     * @exception IOException IO��O�B
     * @exception SQLException DB�֘A��O�B
     * @exception NamingException �l�[�~���O��O�B
     */
    private void checkYakusyoku_code(String yakusyokuCode) throws FileNotFoundException,
            WrongArgumentException, IOException, SQLException, NamingException {
        Log.method( "", "IN", "" );

        YakusyokuDao yakusyokuDao = new YakusyokuDao( locator.getDataSource( ) );
        String yakusyokuCd = "";


		if(getDefaultFlag("KENGEN_CODE1").equals(yakusyokuCode)){
			yakusyokuCd = "1";
		}else if(getDefaultFlag("KENGEN_CODE2").equals(yakusyokuCode)){
			yakusyokuCd = "2";
		}else{
			yakusyokuCd = "3";
		}

        if (!CheckUtils.isNotNull( yakusyokuCd )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( YAKUSYOKU_CODE_ERROR_CODE1 );
            tkl.setErrorMessage( MessageManager.getMessage( YAKUSYOKU_CODE_ERROR_CODE1 ) );
            brl.addTorikomiLog( tkl );
            Log.method( "", "OUT", "" );
            return;
        }
//����2005/11/30 ringou B-A30AI1-035,036
//
//        if (!yakusyokuDao.isExist( yakusyokuCd )) {
//            TorikomiLog tkl = new TorikomiLog( );
//            tkl.setLineNo( csvRecordCount );
//            tkl.setMsgID( YAKUSYOKU_CODE_ERROR_CODE2 );
//            tkl.setErrorMessage( MessageManager.getMessage( YAKUSYOKU_CODE_ERROR_CODE2 ) );
//            brl.addTorikomiLog( tkl );
//        }
//
//����2005/11/30 ringou B-A30AI1-035,036
        Log.method( "", "OUT", "" );
    }

    /**
     * �g�D�R�[�h�`�F�b�N
     * @param sosikiCode �g�D�R�[�h
     * @param maxLength �ő�s���B
     * @exception NamingException �l�[�~���O��O�B
     * @exception FileNotFoundException ���\�[�X�ُ�
     * @exception WrongArgumentException �����ُ�B
     * @exception IOException IO��O�B
     * @exception SQLException DB�֘A��O�B
     */
    private void checkSosiki_code(String sosikiCode, int maxLength) throws NamingException,
            FileNotFoundException, WrongArgumentException, IOException, SQLException {
        Log.method( "", "IN", "" );

        SoshikiDAO soshikiDAO = new SoshikiDAO( locator.getDataSource( ) );

        if (!CheckUtils.isNotNull( sosikiCode )) {
            TorikomiLog tkl = new TorikomiLog( );
            tkl.setLineNo( csvRecordCount );
            tkl.setMsgID( SOSIKI_CODE_ERROR_CODE3 );
            tkl.setErrorMessage( MessageManager.getMessage( SOSIKI_CODE_ERROR_CODE3 ) );
            brl.addTorikomiLog( tkl );
            Log.method( "", "OUT", "" );
            return;
        }
        if (CheckUtils.isNotNull( sosikiCode )) {
            if (!CheckUtils.isByteSizeUnder( sosikiCode, maxLength )) {
                TorikomiLog tkl = new TorikomiLog( );
                tkl.setLineNo( csvRecordCount );
                tkl.setMsgID( SOSIKI_CODE_ERROR_CODE1 );
                tkl.setErrorMessage( MessageManager.getMessage( SOSIKI_CODE_ERROR_CODE1 ) );
                brl.addTorikomiLog( tkl );
                Log.method( "", "OUT", "" );
                return;
            }

            if (!soshikiDAO.isExist( sosikiCode )) {
                TorikomiLog tkl = new TorikomiLog( );
                tkl.setLineNo( csvRecordCount );
                tkl.setMsgID( SOSIKI_CODE_ERROR_CODE2 );
                tkl.setErrorMessage( MessageManager.getMessage( SOSIKI_CODE_ERROR_CODE2 ) );
                brl.addTorikomiLog( tkl );
            }
        }
        Log.method( "", "OUT", "" );
    }

    /**
     * Mail�`�F�b�N
     * @param mail Mail
     * @param maxLength
     * @exception FileNotFoundException ���\�[�X�ُ�
     * @exception IOException IO��O�B
     */
    private void checkMail(String mail, int maxLength) throws FileNotFoundException, IOException {
        Log.method( "", "IN", "" );

        if (CheckUtils.isNotNull( mail )) {
            if (!CheckUtils.isByteSizeUnder( mail, maxLength )) {
                TorikomiLog tkl = new TorikomiLog( );
                tkl.setLineNo( csvRecordCount );
                tkl.setMsgID( MAIL_ERROR_CODE1 );
                tkl.setErrorMessage( MessageManager.getMessage( MAIL_ERROR_CODE1 ) );
                brl.addTorikomiLog( tkl );
            }
            if (CheckUtils.hasSpace( mail )) {
                TorikomiLog tkl = new TorikomiLog( );
                tkl.setLineNo( csvRecordCount );
                tkl.setMsgID( MAIL_ERROR_CODE2 );
                tkl.setErrorMessage( MessageManager.getMessage( MAIL_ERROR_CODE2 ) );
                brl.addTorikomiLog( tkl );
            }
        }
        Log.method( "", "OUT", "" );
    }

    /**
     * Job�i���{��j�`�F�b�N
     * @param yobi2 Job�i���{��j
     * @param maxLength �ő�s���B
     * @exception FileNotFoundException ���\�[�X�ُ�
     * @exception IOException IO��O�B
     */
    private void checkYobi2(String yobi2, int maxLength) throws FileNotFoundException, IOException {
        Log.method( "", "IN", "" );

        if (CheckUtils.isNotNull( yobi2 )) {
            if (!CheckUtils.isByteSizeUnder( yobi2, maxLength )) {
                TorikomiLog tkl = new TorikomiLog( );
                tkl.setLineNo( csvRecordCount );
                tkl.setMsgID( YOBI2_ERROR_CODE );
                tkl.setErrorMessage( MessageManager.getMessage( YOBI2_ERROR_CODE ) );
                brl.addTorikomiLog( tkl );
            }
        }
        Log.method( "", "OUT", "" );
    }

    /**
     * �p�����[�^���擾����
     * @param key ���B
     * @return �f�t�H���g���J�E����J�t���O�B
     */
    private String getDefaultFlag(String key) {
        String flag = (String)ReadFile.fileMapData.get( key );
        if (flag == null) {
            flag = new String( );
        }
        return flag;
    }

}