/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/10/28  01.00      ���� ���V    �V�K�쐬
 */
package jp.co.hisas.addon.batch.learning.kaikotuchi.ejb;

import jp.co.hisas.addon.batch.learning.kaikotuchi.valuebean.*;
import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.rmi.*;

import java.sql.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_KaikoTuchiDaoEJBBean�N���X
 *
 * �@�\�����F
 *   �J�u�ʒm���t�Ɋւ���f�[�^�A�N�Z�X���s���N���X
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PCY_KaikoTuchiDaoEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PCY_KaikoTuchiDaoEJBBean implements SessionBean {
    private SessionContext context = null;

    /**
     *
     * @param kensaku_classBean
     * @param loginuser
     * @return
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_KaikoTuchiBean[] doSelectKaikoTuchiInfo( PCY_ClassBean kensaku_classBean,
        PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "SELECT " );
            sql.append( PCY_KamokuBean.getColumns( "KAMOKU" ) + ", " );
            sql.append( PCY_ClassBean.getColumns( "CLASS" ) + ", " );
            sql.append( PCY_MousikomiJyokyoBean.getColumns( "MOUSIKOMI" ) + ", " );
            sql.append( PCY_PersonalBean.getColumns( "PERSONAL" ) );
            sql.append( " FROM " );
            sql.append( HcdbDef.L01_TBL + " KAMOKU, " );
            sql.append( HcdbDef.L02_TBL + " CLASS, " );
            sql.append( HcdbDef.L15_TBL + " MOUSIKOMI, " );
            sql.append( HcdbDef.personalTbl + " PERSONAL " );
            sql.append( " WHERE CLASS.KAISIBI >=?" );
            sql.append( "   AND CLASS.KAISIBI <=?" );
            sql.append( "   AND CLASS.MOUSIKOMI_KUBUN = '1'" );
            sql.append( "   AND CLASS.KAISAI_JYOTAI = '0'" );
            sql.append( "   AND CLASS.SAKUJYO_FLG = '0'" );
            sql.append( "   AND KAMOKU.SAKUJYO_FLG = '0'" );
            sql.append( "   AND MOUSIKOMI.STATUS = '1'" );
            sql.append( "   AND " );
            sql.append( "     ( MOUSIKOMI.UKETSUKE_JYOTAI = '2' " );
            sql.append( "    OR MOUSIKOMI.UKETSUKE_JYOTAI = '3' " );
            sql.append( "    OR MOUSIKOMI.UKETSUKE_JYOTAI = '4' ) " );
            sql.append( "   AND PERSONAL.HONMU_FLG = '" + HcdbDef.HONMU + "'" );
            sql.append( "   AND KAMOKU.KAMOKU_CODE = CLASS.KAMOKU_CODE" );
            sql.append( "   AND CLASS.KAMOKU_CODE  = MOUSIKOMI.KAMOKU_CODE" );
            sql.append( "   AND CLASS.CLASS_CODE   = MOUSIKOMI.CLASS_CODE" );
            sql.append( "   AND MOUSIKOMI.SIMEI_NO = PERSONAL.SIMEI_NO" );
            sql.append( "   ORDER BY PERSONAL.SIMEI_NO ASC,CLASS.KAISIBI ASC" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            Log.debug( sql.toString(  ) );
            ps = con.prepareStatement( sql.toString(  ) );

            /* �����ߓ��l���Z�b�g���� */
            ps.setString( 1, kensaku_classBean.getKaisibi(  ) );

            /* �������l���Z�b�g���� */
            ps.setString( 2, kensaku_classBean.getSyuryobi(  ) );

            ResultSet rs  = ps.executeQuery(  );
            ArrayList ret = new ArrayList(  );

            String simeiNoTemp = null;
            Map kaikoTuchiMap  = new HashMap(  );

            while ( rs.next(  ) ) {
                /* �L�[�ƂȂ鎁���ԍ����擾���邽�߁A�p�[�\�i�������擾 */
                PCY_PersonalBean personalBean         = new PCY_PersonalBean( rs, "PERSONAL" );
                PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean( rs, "KAMOKU",
                        "CLASS", "PERSONAL", "MOUSIKOMI" );

                if ( kaikoTuchiMap.containsKey( personalBean.getSimeiNo(  ) ) ) {
                    /* ���ɃZ�b�g����Ă���ꍇ�A�\���ݏ���ǉ����� */
                    PCY_KaikoTuchiBean kaikoBean = ( PCY_KaikoTuchiBean )kaikoTuchiMap.get( personalBean
                            .getSimeiNo(  ) );

                    ArrayList mousikomiList = new ArrayList(  );
                    mousikomiList.addAll( Arrays.asList( kaikoBean.getMousikomiBeans(  ) ) );
                    mousikomiList.add( mousikomiBean );
                    kaikoBean.setMousikomiBeans( ( PCY_MousikomiJyokyoBean[] )mousikomiList.toArray( 
                            new PCY_MousikomiJyokyoBean[0] ) );
                } else {
                    /* ���߂ăZ�b�g����ꍇ�A�p�[�\�i�����Ɛ\�����ݏ����Z�b�g���� */
                    PCY_KaikoTuchiBean kaikoBean = new PCY_KaikoTuchiBean(  );
                    kaikoBean.setPersonalBean( personalBean );
                    kaikoBean.setMousikomiBeans( new PCY_MousikomiJyokyoBean[] { mousikomiBean } );
                    kaikoTuchiMap.put( personalBean.getSimeiNo(  ), kaikoBean );
                }
            }

            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ( PCY_KaikoTuchiBean[] )kaikoTuchiMap.values(  ).toArray( new PCY_KaikoTuchiBean[0] );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            throw new EJBException( e );
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }
}
