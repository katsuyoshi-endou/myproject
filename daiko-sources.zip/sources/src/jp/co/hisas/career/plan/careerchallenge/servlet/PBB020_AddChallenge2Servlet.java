/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 * 
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i���V�e�ACareer�v��n�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2005/08/09  03.00       ���@�h     �V�K�쐬(�u�N�x�v�u���v���u���Ԗ��v�ɔ����C��[P33_�L�����A�`�������W���ԃe�[�u���ŊǗ�])
 *   2005/11/08              QUANLA        sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */
package jp.co.hisas.career.plan.careerchallenge.servlet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.code.bean.CodeBean;
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.plan.base.bean.PBY_SkillStandardBean;
import jp.co.hisas.career.plan.careerchallenge.bean.PBB_ChallengeBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.pdf.PZE070_ChallengePDF;
import jp.co.hisas.career.util.property.HcdbDef;


/**
 * <PRE>
 * �T�v:
 *   �u���E�U���瑗�M���ꂽ�l���󂯎��A�N���C�A���gBean�̋@���ی�ݒ菈�����\�b�h���Ăяo���B
 *
 * �g�p���@: 
 *   JSP����Ăяo���B
 * </PRE>
 */
public class PBB020_AddChallenge2Servlet extends HttpServlet
{
	
	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;
	
	/* ���O�C��NO */
	private String login_no = null;
    
	/** 
	 * ServletContext�I�u�W�F�N�g���擾����B 
	 * 
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */ 
	public void init(ServletConfig config) {
		  synchronized(this) {
		  if(ctx == null) {
			 ctx = config.getServletContext();
		 }
	  }
  } 

  /**
   * �u���E�U���瑗�M���ꂽ�l���󂯎��A�N���C�A���gBean�̋@���ی�ݒ菈�����\�b�h���Ăяo���B
   * 
   * @param request  �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
   * @param response  Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
   * @exception IOException  ���o�͊֘A�����Ŕ��������O
   * @exception ServletException  Servlet�̐���ȏ������W����ꂽ���ɔ��������O
   */
  public void service(HttpServletRequest request,HttpServletResponse response) 
	  throws IOException,ServletException {
		  try {
			  
			  /* �u���E�U����̓��͒l���i�[����ϐ��̃T�C�Y */
			  int column_count = 0;
			  
			  String result = HcdbDef.result;
			  String plan = HcdbDef.plan;

			  /* �Ɩ����� */
			  HttpSession session = request.getSession(false);
	 
			  if ( session == null ) {
				   //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
				   ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
			  } else { 
				/* bean�Ăяo�� */
				PBB_ChallengeBean challengebean = (PBB_ChallengeBean)session.getAttribute("challenge");

				UserInfoBean bean = (UserInfoBean)session.getAttribute("userinfo");
				login_no = bean.getLogin_no();

				if( challengebean == null ) {
					challengebean = new PBB_ChallengeBean( login_no );
					session.setAttribute("challenge", challengebean);
				}
				Log.method(login_no,"IN","");
				Log.performance( login_no, true, "");
				
				String kanji = bean.getKanji_Login();
				kanji = kanji.substring(1);
				
				String busyo = bean.getBusyo_Login();
				busyo = busyo.substring(1);
                
				/* WWW�u���E�U������͒l���󂯎�� */	
				/* ���͍��ڐ� */
				column_count = HcdbDef.p31_column.length;
				/* ���͂��ꂽ�l���i�[����z����쐬 */
				String[] save = new String[column_count];
				save[0] = login_no;
				save[1] = PZZ010_CharacterUtil.strEncode( request.getParameter("H007_Nen") );	//nendo = kikan_mei
				save[2] = PZZ010_CharacterUtil.strEncode( request.getParameter("H007_Ki") );	//ki = kikan_mei
				save[3] = request.getParameter("H015_Kubun");
				if ( request.getParameter("H002_SyokuCode").equals("DUMMY") ) {
					save[4] = "";
				} else {
					save[4] = request.getParameter("H002_SyokuCode");
				}
				if ( request.getParameter("H004_SenmonCode").equals("DUMMY") ) {
					save[5] = "";
				} else {
					save[5] = request.getParameter("H004_SenmonCode");
				}
				if ( request.getParameter("H006_LevelCode").equals("DUMMY") ) {
					save[6] = "";
				} else {
					save[6] = request.getParameter("H006_LevelCode");
				}

				save[7] = PZZ010_CharacterUtil.strEncode( request.getParameter("A001_Gyomu") );
				save[8] = PZZ010_CharacterUtil.strEncode( request.getParameter("A002_Kyoiku") );
				
				String [][] sikakuargs = CodeBean.getSikaku();
				/* �v����o�^�� */
				if ( request.getParameter("H015_Kubun").equals(plan) ) {
					if (request.getParameter("S006_Sikaku1").equals("-1") ) {
						save[9] = "";
					} else {
						save[9] = sikakuargs[Integer.parseInt(request.getParameter("S006_Sikaku1"))][0];
					}
					if (request.getParameter("S009_SikakuCode1").equals("-1") ) {
						save[10] = "";
					} else {
						save[10] = request.getParameter("S009_SikakuCode1");
					}
					save[11] = PZZ010_CharacterUtil.strEncode(request.getParameter("T005_Tokuten1"));
					save[47] = PZZ010_CharacterUtil.strEncode(request.getParameter("H033_Sikaku_meisyo1"));
					save[48] = PZZ010_CharacterUtil.strEncode(request.getParameter("H036_Level_mei1"));
					
					if (request.getParameter("S007_Sikaku2").equals("-1") ) {
						save[12] = "";
					} else {
						save[12] = sikakuargs[Integer.parseInt(request.getParameter("S007_Sikaku2"))][0];
					}
					if (request.getParameter("S010_SikakuCode2").equals("-1") ) {
						save[13] = "";
					} else {
						save[13] = request.getParameter("S010_SikakuCode2");
					}
					save[14] = PZZ010_CharacterUtil.strEncode(request.getParameter("T006_Tokuten2"));
					save[49] = PZZ010_CharacterUtil.strEncode(request.getParameter("H034_Sikaku_meisyo2"));
					save[50] = PZZ010_CharacterUtil.strEncode(request.getParameter("H037_Level_mei2"));

					if (request.getParameter("S008_Sikaku3").equals("-1") ) {
						save[15] = "";
					} else {
						save[15] = sikakuargs[Integer.parseInt(request.getParameter("S008_Sikaku3"))][0];
					}
					if (request.getParameter("S011_SikakuCode3").equals("-1") ) {
						save[16] = "";
					} else {
						save[16] = request.getParameter("S011_SikakuCode3");
					}
					save[17] = PZZ010_CharacterUtil.strEncode(request.getParameter("T007_Tokuten3"));
					save[51] = PZZ010_CharacterUtil.strEncode(request.getParameter("H035_Sikaku_meisyo3"));
					save[52] = PZZ010_CharacterUtil.strEncode(request.getParameter("H038_Level_mei3"));

				}
				
				if ( request.getParameter("H015_Kubun").equals(result) ) {
					/* bean�ɓ����Ă��鎑�i����z��Ɋi�[���� */
					String[][] sikakuData = challengebean.getSikakuData();
					if ( sikakuData != null ) {
						if ( sikakuData.length <= 3 ) {
							for ( int i = 0; i < sikakuData.length; i++ ) {
								/* ���i���̃R�[�h */
								save[9+(i*3)] = sikakuData[i][5];
								/*  ���i�R�[�h */
								save[10+(i*3)] = sikakuData[i][0];
								// DEL#P-PPT00-012-001-S
								save[47+(i*2)] = sikakuData[i][1];
								save[48+(i*2)] = sikakuData[i][2];
								save[11+(i*3)] = sikakuData[i][3];
								// DEL#P-PPT00-012-001-E
							}
						} else {
							for ( int i = 0; i < 3; i++ ) {
								/* ���i���̃R�[�h */
								save[9+(i*3)] = sikakuData[i][5];
								/*  ���i�R�[�h */
								save[10+(i*3)] = sikakuData[i][0];
								// DEL#P-PPT00-012-001-S
								save[47+(i*2)] = sikakuData[i][1];
								save[48+(i*2)] = sikakuData[i][2];
								save[11+(i*3)] = sikakuData[i][3];
								//DEL#P-PPT00-012-001-E
							}
						}
					} else {
						for ( int i = 0; i < 5; i++ ) {
							/* ���i���̃R�[�h */
							save[9+(i*3)] = "";
							/*  ���i�R�[�h */
							save[10+(i*3)] = "";
							save[47+(i*2)] = "";
							save[48+(i*2)] = "";
							save[11+(i*3)] = "";
						}								
					}
				}
								
				save[18] = "";
				save[19] = "";
				save[20] = "";
				save[21] = "";
				save[22] = "";
				save[23] = "";
				
				save[53] = "";
				save[54] = "";
				save[55] = "";
				save[56] = "";			
				
				save[24] = PZZ010_CharacterUtil.strEncode( request.getParameter("A003_Keihatu") );
				save[25] = PZZ010_CharacterUtil.strEncode( request.getParameter("A004_Ido") );
				save[26] = "";
				save[27] = "";
				save[28] = "";
				save[29] = "";
				save[30] = "";
				save[31] = "";
				save[32] = "";
				save[33] = "";
				save[34] = PZZ010_CharacterUtil.strEncode( request.getParameter("A005_Tuiki") );
				save[35] = PZZ010_CharacterUtil.strEncode( request.getParameter("A006_Jyou") );
				save[36] = "          ";
				save[37] = HcdbDef.flg1;
				save[38] = HcdbDef.flg0;
				save[39] = PZZ010_CharacterUtil.GetDay();
				save[40] = PZZ010_CharacterUtil.GetTime();
				save[41] = "";
				save[42] = "";
				save[43] = kanji;
				save[44] = busyo;
				save[45] = "";
				save[46] = "";
				save[57] = "BLOB_DATA";
				save[58] = "";
				
				for( int i = 0; i < HcdbDef.p31_column.length-1; i++ ) {
					if( save[i] == null ) {
						save[i] = "";
						Log.debug(save[i]);
					}
				}

				/* PDF�쐬 */
				PZE070_ChallengePDF pdf = new PZE070_ChallengePDF( login_no );
				
				String sindanData[] = new String[6];
				String hyokaData[]  = new String[6];
				
				/* PDF���ږ��̎擾 */
				String[] outDefItem = challengebean.getoutDefPDF2( save[1], save[3]);
				
				/* �����Đf�f�ް� */
				sindanData = challengebean.getsindanPDF();
                
				/* �����ĕ]���ް� */
				hyokaData  = challengebean.gethyokaPDF();
				
				/* ��ر���ݼގ����ް� */
				String[] resultData = new String[HcdbDef.p31_hyoji_column.length];
				
				/* ��ر���ݼތv���ް� */
				String[] planData   = new String[HcdbDef.p31_hyoji_column.length];
				
				/* �E�����e���ް� */
				String[][] syokumuData =  challengebean.getSyokumuData();
				
				/* �v��̏ꍇ */
				if ( request.getParameter("H015_Kubun").equals("1") ) {

					for( int i = 0; i < HcdbDef.p31_hyoji_column.length; i++ ) {
						planData[i] = save[i];					
					}
				/* ���т̏ꍇ */
				} else {
					/* �v������擾 */
					planData = challengebean.getPlanData();
				}

				/* �E��R�[�h */
				String syokusyuCode    = "";
					   syokusyuCode    = save[4];
				       
				/* ��啪��R�[�h */
				String senmonCode      = "";
					   senmonCode      = save[5];
				       
				/* ���x���R�[�h */
				String levelCode       = "";
					   levelCode       = save[6];
				
				/* �E�� */
				if ( !syokusyuCode.equals("") ) {
					planData[4] = PBY_SkillStandardBean.getSyokuName( syokusyuCode );
				} 
					
				/* ��啪�� */
				if ( !senmonCode.equals("") ) {
					planData[5] = PBY_SkillStandardBean.getSenmonName( syokusyuCode,senmonCode );
				}
					
				/* ���x�� */
				if ( !levelCode.equals("") ) {
					planData[6] = PBY_SkillStandardBean.getLevelName( syokusyuCode, senmonCode, levelCode );
				}
				/* �v��PDF�쐬 */
				if ( request.getParameter("H015_Kubun").equals("1") ) {

					/* �v�掞�͎��я��̕\���͂��Ȃ����ߋ󕶎����Z�b�g���� */
					for ( int i = 0; i < HcdbDef.p31_hyoji_column.length; i++ ) {
						resultData[i] = "";
					}
					
					/* ���i�ް� */
					String[][] sikakuData  =  challengebean.getSikakuData();
					
					/* ���Z�b�g */
					pdf.setChallengeValue( outDefItem, request.getParameter("H015_Kubun"), planData, resultData );
					pdf.setSikakuValue( sikakuData );
					pdf.setSyokumuValue( syokumuData );
					pdf.setAssessmentValue( sindanData, hyokaData  );
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					pdf.executePDF( baos );
					
					/* �v����͎��������T�[�x�C�������ɃR�~�b�g���� */
					String [] moral = challengebean.getAddMoral();
					moral[0] = save[0];
					moral[1] = save[1];
					moral[2] = save[2];
					moral[29] = save[39];
					moral[30] = save[40];
					moral[31] = save[43];
					moral[32] = save[44];
				    
					/* �ēxbean�ɃZ�b�g���� */
					challengebean.AddChallengePlan( moral, save, baos.toByteArray() );
				
				/* ����PDF�쐬 */						
				} else {
					
					for( int i = 0; i < HcdbDef.p31_hyoji_column.length; i++ ) {
						resultData[i] = save[i];					
					}

					/* ���Z�b�g */
					pdf.setChallengeValue( outDefItem, request.getParameter("H015_Kubun"), planData, resultData );
					pdf.setAssessmentValue( sindanData, hyokaData  );
					
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					pdf.executePDF( baos );
					
					/* �o�^���\�b�h�Ăяo�� */
					challengebean.AddChallengeResult( save, baos.toByteArray() );
				 }
			 
				  /* JSP�y�[�W���Ăяo�� */
				  //20050811 ���h Version 03.00�̃G���n���X�Œǉ�
				  String next_url = "/view/plan/careerchallenge/VBB060_SelectHistoryMain.jsp";
				  String window_site = (String)request.getParameter( "window_site" );
				  String menu_kind = request.getParameter( "menu_kind" );
				  if ( window_site != null && window_site.equals( "careerchallenge" ) ) {
					  next_url = "/servlet/PBB010_CareerChallengeHanteiServlet?window_site=careerchallenge";
					  if ( menu_kind != null && !menu_kind.equals("") ) {
					  	  next_url = next_url + "&menu_kind=" + menu_kind;
					  } else {
						  next_url = next_url + "&menu_kind=DZZ901";
					  }
				  }
				  RequestDispatcher rd = ctx.getRequestDispatcher( next_url );
				  rd.forward(request, response);
				  Log.performance( login_no, false, "");
				  Log.method(login_no,"OUT",""); 
			   }
		   } catch ( IOException e ) {
			   Log.error(login_no, "HJE-0012", e);
			   //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
			   ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
		   } catch ( Exception e ) {
			   Log.error(login_no, "HJE-0012", e);
			   //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
			   ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
		  }
	 }
}
