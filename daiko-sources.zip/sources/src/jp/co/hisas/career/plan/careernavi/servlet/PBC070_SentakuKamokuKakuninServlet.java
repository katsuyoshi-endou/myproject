/*
 * All Rights Reserved. Copyright (C) 2003, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�v��nHCDB�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/08/12  01.00      ���� ���V    �V�K�쐬
 *   2005/11/08              QUANLA        sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */
package jp.co.hisas.career.plan.careernavi.servlet;

import jp.co.hisas.career.base.userinfo.bean.*;
import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.io.*;

import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;


/**
 *<PRE>
 * �T�v:
 *   ��u�����̉Ȗڈꗗ����A�N���X�����擾���܂��B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 *</PRE>
 */
public class PBC070_SentakuKamokuKakuninServlet extends HttpServlet {
    /** ServletContext�I�u�W�F�N�g */
    private ServletContext ctx = null;

    /* ���O�C��NO */
    private String login_no = null;

    /**
     * ServletContext�I�u�W�F�N�g���擾����B
     *
     * @param config   Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
     */
    public void init( ServletConfig config ) {
        synchronized ( this ) {
            if ( ctx == null ) {
                ctx = config.getServletContext(  );
            }
        }
    }

    /**
     * �u���E�U���瑗�M���ꂽ�l���󂯎��A���猤�C�����\�b�h���Ăяo���B
     *
     * @param request   �N���C�A���g�̃��N�G�X�g��\��HttpServletRequest�I�u�W�F�N�g
     * @param response   Servlet ����̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
     * @exception IOException   ���o�͊֘A�����Ŕ��������O
     * @exception ServletException   Servlet �̐���ȏ������W����ꂽ�Ƃ��ɔ��������O
     */
    public void service( HttpServletRequest request, HttpServletResponse response )
        throws IOException, ServletException {
        try {
            /******************************
             * ���͏���
             ******************************/
            HttpSession session = request.getSession( false );

            if ( session == null ) {
                //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } else {
                UserInfoBean userinfo = ( UserInfoBean )session.getAttribute( "userinfo" );
                login_no = userinfo.getLogin_no(  );

                Log.method( login_no, "IN", "" );
                Log.performance( login_no, true, "" );

                PCY_KamokuBean[] sessionKamokuBeans = ( PCY_KamokuBean[] )session.getAttribute( 
                        "careernavi.kamokuBeans" );

                if ( sessionKamokuBeans != null ) {
                    HashMap map = new HashMap(  );

                    for ( int i = 0; i < sessionKamokuBeans.length; i++ ) {
                        map.put( sessionKamokuBeans[i].getKamokuCode(  ), "" );
                    }

                    /* ClassEJB */
                    PCY_ServiceLocator locator  = PCY_ServiceLocator.getInstance(  );
                    PCY_ClassEJBHome class_home = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
                            PCY_ClassEJBHome.class );
                    PCY_ClassEJB class_ejb = class_home.create(  );

                    PCY_ClassBean kensakuClassBean = new PCY_ClassBean(  );
                    kensakuClassBean.getKamokuBean(  ).setKamokuCode( "" );

                    PCY_PersonalBean loginuser = new PCY_PersonalBean(  );
                    loginuser.setSimeiNo( login_no );

                    for ( Iterator ite = map.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                        Object key = ite.next(  );
                        kensakuClassBean.getKamokuBean(  ).setKamokuCode( ( String )key );
                        map.put( key, class_ejb.doSelect( kensakuClassBean, false, loginuser ) );
                    }

                    request.setAttribute( "classBeansMap", map );
                }

                /* JSP�y�[�W���Ăяo�� */
                RequestDispatcher rd = ctx.getRequestDispatcher( 
                        "/view/plan/careernavi/VBC110_SentakuKamokuKakunin.jsp" );
                rd.forward( request, response );
                Log.performance( login_no, false, "" );
                Log.method( login_no, "OUT", "" );
            }
        } catch ( IllegalStateException e ) {
            Log.error( login_no, "HJE-0010", e );
            //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( IOException e ) {
            Log.error( login_no, "HJE-0012", e );
            //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( ServletException e ) {
            Log.error( login_no, "HJE-0015", e );
            //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( Exception e ) {
            Log.error( login_no, "HJE-0017", e );
            //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        }
    }
}
