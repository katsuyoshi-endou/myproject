/*
 * All Rights Reserved. Copyright (C) 2003, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�v��nHCDB�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/08/12  01.00      ���� ���V    �V�K�쐬
 *   2004/08/18             ���� ���V    �d���Ȗړo�^�`�F�b�N�C��(B-APC03-003)
 *   2005/11/08              QUANLA        sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */
package jp.co.hisas.career.plan.careernavi.servlet;

import jp.co.hisas.career.base.userinfo.bean.*;
import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.io.*;

import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;


/**
 *<PRE>
 * �T�v:
 *   ��u�����Ȗڂ̒ǉ����s���܂��B
 *   ����ȖڂŁA����X�L���̉Ȗڂ͒ǉ�����܂���B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 *</PRE>
 */
public class PBC060_JyukouKentouAddServlet extends HttpServlet {
    /** ServletContext�I�u�W�F�N�g */
    private ServletContext ctx = null;

    /* ���O�C��NO */
    private String login_no = null;

    /**
     * ServletContext�I�u�W�F�N�g���擾����B
     *
     * @param config   Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
     */
    public void init( ServletConfig config ) {
        synchronized ( this ) {
            if ( ctx == null ) {
                ctx = config.getServletContext(  );
            }
        }
    }

    /**
     * �u���E�U���瑗�M���ꂽ�l���󂯎��A���猤�C�����\�b�h���Ăяo���B
     *
     * @param request   �N���C�A���g�̃��N�G�X�g��\��HttpServletRequest�I�u�W�F�N�g
     * @param response   Servlet ����̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
     * @exception IOException   ���o�͊֘A�����Ŕ��������O
     * @exception ServletException   Servlet �̐���ȏ������W����ꂽ�Ƃ��ɔ��������O
     */
    public void service( HttpServletRequest request, HttpServletResponse response )
        throws IOException, ServletException {
        try {
            /******************************
             * ���͏���
             ******************************/
            HttpSession session = request.getSession( false );

            if ( session == null ) {
                //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } else {
                UserInfoBean bean = ( UserInfoBean )session.getAttribute( "userinfo" );
                login_no = bean.getLogin_no(  );

                Log.method( login_no, "IN", "" );
                Log.performance( login_no, true, "" );

                String[] kamoku_codes = request.getParameterValues( "kamoku_codes" );

                if ( kamoku_codes != null ) {
                    for ( int i = 0; i < kamoku_codes.length; i++ ) {
                        kamoku_codes[i] = PZZ010_CharacterUtil.strEncode( kamoku_codes[i] );
                    }
                }

                String syoku_code = PZZ010_CharacterUtil.strEncode( request.getParameter( 
                            "syoku_code" ) );
                String senmon_code = PZZ010_CharacterUtil.strEncode( request.getParameter( 
                            "senmon_code" ) );
                String level_code = PZZ010_CharacterUtil.strEncode( request.getParameter( 
                            "level_code" ) );
                String skill_code = PZZ010_CharacterUtil.strEncode( request.getParameter( 
                            "skill_code" ) );
                String kamoku_group_code = PZZ010_CharacterUtil.strEncode( request.getParameter( 
                            "kamoku_group_code" ) );
                String kyoiku_kubun_code = PZZ010_CharacterUtil.strEncode( request.getParameter( 
                            "kyoiku_kubun_code" ) );

                /* PCY_KamokuEJB */
                PCY_ServiceLocator locator    = PCY_ServiceLocator.getInstance(  );
                PCY_KamokuEJBHome kamoku_home = ( PCY_KamokuEJBHome )locator.getServiceLocation( "PCY_KamokuEJB",
                        PCY_KamokuEJBHome.class );
                PCY_KamokuEJB kamoku_ejb = kamoku_home.create(  );

                PCY_KanrenKyoikuKamokuBean kensakuBean = new PCY_KanrenKyoikuKamokuBean(  );
                kensakuBean.setSyokusyuCode( syoku_code );
                kensakuBean.setSenmonCode( senmon_code );
                kensakuBean.setLevelCode( String.valueOf( Integer.parseInt( level_code ) - 1 ) );
                kensakuBean.setSkillCode( skill_code );
                kensakuBean.setKamokuGroupCode( kamoku_group_code );
                kensakuBean.setKyoikuKubunCode( kyoiku_kubun_code );

                PCY_KamokuBean[] kamokuBeans = kamoku_ejb.doSelectByKanrenKyoiku( kensakuBean,
                        new PCY_PersonalBean(  ) );

                Collection col = new ArrayList(  );

                if ( kamoku_codes != null ) {
                    for ( int i = 0; i < kamoku_codes.length; i++ ) {
                        for ( int j = 0; j < kamokuBeans.length; j++ ) {
                            if ( kamoku_codes[i].equals( kamokuBeans[j].getKamokuCode(  ) ) ) {
                                col.add( kamokuBeans[j] );
                            }
                        }
                    }
                }

                PCY_KamokuBean[] sessionKamokuBeans = ( PCY_KamokuBean[] )session.getAttribute( 
                        "careernavi.kamokuBeans" );

                if ( sessionKamokuBeans != null ) {
                    PCY_KamokuBean[] check_kamokuBeans = ( PCY_KamokuBean[] )col.toArray( new PCY_KamokuBean[0] );
                    col.clear(  );

                    /* �d�������ȖڃR�[�h�A�X�L���R�[�h�̂��̂̓J�[�g�ɑ}�����Ȃ� */
                    for ( int i = 0; i < check_kamokuBeans.length; i++ ) {
                        boolean flg = true;

                        /* CHG#P-APC03-003-001-S */
                        for ( int j = 0; j < sessionKamokuBeans.length; j++ ) {
                            if ( check_kamokuBeans[i].getKamokuCode(  ).equals( sessionKamokuBeans[j]
                                    .getKamokuCode(  ) )
                                && check_kamokuBeans[i].getKanrenKamokuBeans(  )[0].getSkillCode(  )
                                                                                   .equals( sessionKamokuBeans[j]
                                    .getKanrenKamokuBeans(  )[0].getSkillCode(  ) ) ) {
                                /* �ȖڃR�[�h�A�X�L���R�[�h������̂��̂����ɓo�^����Ă��� */
                                flg = false;

                                break;
                            }
                        }

                        if ( flg ) {
                            col.add( check_kamokuBeans[i] );
                        }

                        /* CHG#P-APC03-003-001-E */
                    }

                    col.addAll( Arrays.asList( sessionKamokuBeans ) );
                }

                session.setAttribute( "careernavi.kamokuBeans",
                    ( PCY_KamokuBean[] )col.toArray( new PCY_KamokuBean[0] ) );

                /* JSP�y�[�W���Ăяo�� */
                RequestDispatcher rd = ctx.getRequestDispatcher( 
                        "/view/plan/careernavi/VBC040_KamokuListMain.jsp" );
                rd.forward( request, response );
                Log.performance( login_no, false, "" );
                Log.method( login_no, "OUT", "" );
            }
        } catch ( IllegalStateException e ) {
            Log.error( login_no, "HJE-0010", e );
            //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( IOException e ) {
            Log.error( login_no, "HJE-0012", e );
            //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( ServletException e ) {
            Log.error( login_no, "HJE-0015", e );
            //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( Exception e ) {
            Log.error( login_no, "HJE-0017", e );
            //response.sendRedirect( "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        }
    }
}
