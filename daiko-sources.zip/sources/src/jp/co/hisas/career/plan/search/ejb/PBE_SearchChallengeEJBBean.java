/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 * 
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i���V�e�ACareer�v��n�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/04/01  01.00       �n�� ��q    �V�K�쐬
 *   2005/08/09	 03.00		 �͏@�@���s   �L�����A�`�������W���ԃe�[�u���Ή� 
 *   2005/09/09  03.00		 ���H���G�F�@�@�\�[�g���ύX�Ή��i�d�l�ύX
 *   2005/09/28              ���c�@���V    Oracle10gAS�Ή�
 *   2005/11/26  03.01       LOINT		 searchChallenge()�@�\�ł́ASQL��ύX����B
 *   2005/11/28  03.02       QUANLA      searchChallenge()�@�\�ł́ASQL��ύX����B
 */
package jp.co.hisas.career.plan.search.ejb;

import java.rmi.*;
import javax.ejb.*;
import javax.sql.*;
import javax.naming.*;
import java.sql.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

/**
 *<PRE>
 * �T�v:
 *   DB�A�N�Z�X���s���A�L�����A�`�������W���̌������s���A�X�e�[�g���XSessionBean�B
 *
 * �g�p���@:
 *   �����[�g�C���^�t�F�[�X����āA�N���C�A���gBean����Ăяo���B
 *</PRE>
 */
public class PBE_SearchChallengeEJBBean implements SessionBean {

    // SessionContext�I�u�W�F�N�g
    private SessionContext my_ssc = null;

    // DB�ڑ�
    private DataSource ds = null;

    // ���s����sql��
    private String sql;

    // SQL�𑗂邽�߂�Statement�I�u�W�F�N�g
    private Statement stmt;

    // �f�[�^�x�[�X�̌��ʃZ�b�g���i�[����ResultSet�I�u�W�F�N�g
    private ResultSet rs;

    // �p�[�\�i���v���t�@�C���e�[�u��
    private static final String T01tbl    = HcdbDef.personalTbl + " t01";

    // ��E�}�X�^�e�[�u��
    private static final String T15tbl    = HcdbDef.yakusyokuTbl + " t15";

    // �L�����A�`�������W�e�[�u��
    private static final String P31tbl    = HcdbDef.p_career_challengeTbl + " p31";

    // �������ʊi�[�z��
    private String[][] challengeList;

    // �������ʃJ�E���g�i�[
    private int count_challenge = 0;


    /**
     * �f�[�^�x�[�X����Ώۃ��R�[�h�̌������J�E���g���A���^�[������B
     * 
     * @param      login_no          ���O�C��No
     * @param      search_kbn        �������@
     * @param      search_cnd        ��������
     * @return                       ��������
     * @exception  SQLException      SQL�G���[�����������ꍇ
     * @exception  NamingException   �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
     */
    public int countChallenge( String login_no , String search_kbn , String[] search_cnd )
    throws RemoteException , SQLException , NamingException{
        // MethodLog�o��
        Log.method( login_no ,"IN","");

        Connection dbConn = null;                          // DB�ڑ��I�u�W�F�N�g�̊l��
        try{

            dbConn = this.getConnection( login_no );       // �f�[�^�x�[�X�ڑ����擾

            /* SQL�X�e�[�g�����g�̔��s */
            // �����擾
            int engName        = Integer.parseInt( search_cnd[0] );
            int jinRyaku       = Integer.parseInt( search_cnd[1] );
            int yakuMaster     = Integer.parseInt( search_cnd[2] );
            int busyoPos       = Integer.parseInt( search_cnd[3] );
			/* 2005.08.09 �͏@�@���s */
			String kikan       = "%";
            String kbn         = "%";
            String syoriflg    = "%";
            String syoninflg   = "%";
            String kaihatuplan = "";
            String umu         = "";
            String simeino     = "";
            String simeikanji  = "_";
            String simeikana   = "_";
            String simeieiji   = "_";
            String buryakusyo  = "";

            int unionFlg      = 0;

            if ( search_kbn.equals( "1" ) ) {
                /* 2005.08.09 �͏@�@���s */
                kikan		= (String)search_cnd[4];
				kbn       = (String)search_cnd[5];
                syoriflg  = "";
                syoninflg = "";

                for ( int i = 0 ; i < HcdbDef.sinchoku.length ; i++ ) {
                    if ( HcdbDef.sinchoku[i][0].equals( search_cnd[6] ) ) {
                        syoriflg  = HcdbDef.sinchoku[i][2];
                        syoninflg = HcdbDef.sinchoku[i][3];
                    }
                }

                buryakusyo  = (String)search_cnd[7];

                if ( search_cnd[6].equals( "1" ) ) {
                    unionFlg = 1;
                }

            } else if ( search_kbn.equals( "2" ) ) {
				/* 2005.08.09 �͏@�@���s */
				kikan		= (String)search_cnd[4];				
				kbn         = (String)search_cnd[5];
				kaihatuplan = (String)search_cnd[6];
				umu         = (String)search_cnd[7];
				buryakusyo  = (String)search_cnd[8];

            } else if ( search_kbn.equals( "3" ) ) {
                simeino     = (String)search_cnd[4];
                simeikanji  = "_" + (String)search_cnd[5];
                simeikana   = "_" + (String)search_cnd[6];
                simeieiji   = "_" + (String)search_cnd[7];
                buryakusyo  = (String)search_cnd[8];
            }

            String whr_p31 = "";
            if ( ( search_kbn.equals( "2" ) ) 
            &&   ( !kaihatuplan.equals( "" ) ) ) {
                String cond  = "";
                String cond2 = "";
                whr_p31 = " AND ";
                if ( umu.equals( "1" ) ) {
                    cond  = " IS NOT NULL";
                    cond2 = " OR ";
                } else {
                    cond =  " IS NULL";
                    cond2 = " AND ";
                }
                if ( kaihatuplan.equals( "1" ) ) {
                    whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[0] + cond;
                } else if ( kaihatuplan.equals( "2" ) ) {
                    whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[1] + cond;
                } else if ( kaihatuplan.equals( "3" ) ) {
                    whr_p31 = whr_p31 + "( " + "p31." + HcdbDef.p31_searchchallenge_whr_column[2] + cond;
                    for ( int i = 3 ; i < 7 ; i++ ) {
                        whr_p31 = whr_p31
                                + cond2 + "p31." + HcdbDef.p31_searchchallenge_whr_column[i] + cond;
                    }
                    whr_p31 = whr_p31 + " ) ";
                } else if ( kaihatuplan.equals( "4" ) ) {
                    whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[7] + cond;
                } else if ( kaihatuplan.equals( "5" ) ) {
                    whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[8] + cond;
                } else if ( kaihatuplan.equals( "6" ) ) {
                    whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[9] + cond;
                } else if ( kaihatuplan.equals( "7" ) ) {
                    whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[10] + cond;
                }
            }

            String[] t01_whr  = {
                simeino.trim().concat( "%" ),
                simeikanji.trim().concat( "%" ),
                simeikana.trim().concat( "%" ),
                buryakusyo.trim()
            };

            String[] t01_whr_eng  = {
                simeino.trim().concat( "%" ),
                simeikanji.trim().concat( "%" ),
                simeikana.trim().concat( "%" ),
                simeieiji.trim().concat( "%" ),
                buryakusyo.trim()
            };

            sql = "SELECT COUNT( * ) c"
                + " FROM " + T01tbl
                + " , "    + P31tbl;
            if ( yakuMaster == 1 ) {
                sql = sql
                    + " , " + T15tbl;
            }

            String whr_stm  = "";
            String whr_stm2 = "";
            sql = sql
                + " WHERE " + "t01." + HcdbDef.t01_searchchallenge_column[0] + " = p31." + HcdbDef.p31_searchchallenge_column[0]
                + " AND ";
			/* 2005.08.09 �͏@�@���s */
			whr_stm =      "p31." + HcdbDef.p31_searchchallenge_column[1] + " LIKE '" + kikan     + "'"
                    + " AND p31." + HcdbDef.p31_searchchallenge_column[3] + " LIKE '" + kbn       + "'";
            sql = sql
                + whr_stm
                + " AND p31." + HcdbDef.p31_searchchallenge_column[4] + " LIKE '" + syoriflg  + "'"
                + " AND p31." + HcdbDef.p31_searchchallenge_column[5] + " LIKE '" + syoninflg + "'"
                + whr_p31;

            int ind;

            if ( engName == 0
            ||    engName == 1 && simeieiji.trim().equals( "_" ) ) {
            // �p��������\�����Ȃ� or �p��������\������A���p�������̎w��Ȃ�
                for ( ind = 0 ; ind < t01_whr.length - 1 ; ind++ ) {
                    whr_stm2 = whr_stm2
                             + " AND t01." + HcdbDef.t01_searchchallenge_column[ind] + " LIKE '" + t01_whr[ind] + "'";
                }
                if ( !buryakusyo.trim().equals( "" ) ) {
                    whr_stm2 = whr_stm2
                             + " AND t01." + HcdbDef.t01_search_syozoku[ busyoPos - 1 ] + " LIKE '" + t01_whr[ind] + "'";
                }
            } else {
            // �p��������\������
                for ( ind = 0 ; ind < t01_whr_eng.length - 1 ; ind++ ) {
                    whr_stm2 = whr_stm2
                             + " AND t01." + HcdbDef.t01_searchchallenge_eng_column[ind] + " LIKE '" + t01_whr_eng[ind] + "'";
                }
                if ( !buryakusyo.trim().equals( "" ) ) {
                    whr_stm2 = whr_stm2
                             + " AND t01." + HcdbDef.t01_search_syozoku[ busyoPos - 1 ] + " LIKE '" + t01_whr_eng[ind] + "'";
                }
            }

            whr_stm2 = whr_stm2
                     + " AND t01." + HcdbDef.t01_honmu_cnd
                     + " AND t01." + HcdbDef.t01_taisyoku_cnd;

            if ( yakuMaster == 1 ) {
                whr_stm2 = whr_stm2
                         + " AND t15." + HcdbDef.yakusyoku_code
                         +   " = t01." + HcdbDef.yakusyoku_code;
            }

            sql = sql
                + whr_stm2;

            if ( unionFlg == 1 ) {
                sql = "SELECT SUM ( c ) FROM ( ( "
                    + sql
                    + ") "
                    + " UNION ALL"
                    + "( SELECT COUNT( * ) c"
                //2005/11/28_LYCE_R_QUANLA START
//                   + " FROM " + T01tbl;
//               if ( yakuMaster == 1 ) {
//                   sql = sql
//                       + " , " + T15tbl;
//               }
//               sql = sql
//                   + " WHERE t01." + HcdbDef.t01_searchchallenge_column[0]
//                   + " NOT IN ( SELECT " + HcdbDef.p31_searchchallenge_column[0]
//                   + " FROM "  + P31tbl
//                   + " WHERE " + whr_stm + " )"
//                   + whr_stm2 + " ) ) ";
               //2005/11/28_LYCE_R_QUANLA END
               //2005/11/28_LYCE_A_QUANLA START
                   + " FROM " + T01tbl + " LEFT OUTER JOIN " + P31tbl
                   + " ON (T01." + HcdbDef.p31_search_jinmei[0] + " = P31." + HcdbDef.p31_hyoji_column[0]
                   + " AND " + whr_stm + ")";

               if ( yakuMaster == 1 ) {
                   sql = sql
                       + " , " + T15tbl;
               }
               sql = sql
                   + " WHERE "
                   + " P31." + HcdbDef.p31_hyoji_column[0] + " IS NULL "
                   + whr_stm2 + " ))";
               //2005/11/28_LYCE_A_QUANLA END
            }


            Log.debug( "countChallengeSQL:" + sql );
            stmt = dbConn.createStatement();
            rs   = stmt.executeQuery(sql);
            rs.next();
        
            count_challenge = rs.getInt(1);

            Log.debug( "countChallenge:" + count_challenge );

            // MethodLog�o��
            Log.method( login_no ,"OUT","");
            return count_challenge;

        } catch ( SQLException sqle ) {
            throw sqle;
        } catch ( NamingException ne ) {
            throw ne;
        } finally {
            rs.close();
            stmt.close();
            dbConn.close();
        }
    }

    /**
     * �f�[�^�x�[�X�������s���A���ʂ��i�[�����z������^�[������B
     * 
     * @param      login_no          ���O�C��No
     * @param      search_kbn        �������@
     * @param      search_cnd        ��������
     * @param      count             �������ʌ���
     * @return                       �������ʔz��
     * @exception  SQLException      SQL�G���[�����������ꍇ
     * @exception  NamingException   �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
     */
    public String[][] searchChallenge( String login_no , String search_kbn , String[] search_cnd , int count )
    throws RemoteException , SQLException , NamingException{
        // MethodLog�o��
        Log.method( login_no ,"IN","");

        Connection dbConn = null;                          // DB�ڑ��I�u�W�F�N�g�̊l��
        try{

            dbConn = this.getConnection( login_no );       // �f�[�^�x�[�X�ڑ����擾

            /* SQL�X�e�[�g�����g�̔��s */
            // �����擾
            int engName        = Integer.parseInt( search_cnd[0] );
            int jinRyaku       = Integer.parseInt( search_cnd[1] );
            int yakuMaster     = Integer.parseInt( search_cnd[2] );
            int busyoPos       = Integer.parseInt( search_cnd[3] );
            String kikan		= "%";
            String kbn         = "%";
            String syoriflg    = "%";
            String syoninflg   = "%";
            String kaihatuplan = "";
            String umu         = "";
            String simeino     = "";
            String simeikanji  = "_";
            String simeikana   = "_";
            String simeieiji   = "_";
            String buryakusyo  = "";

            int unionFlg      = 0;

            if ( search_kbn.equals( "1" ) ) {
				/* 2005.08.09 �͏@�@���s */
				kikan	  = (String)search_cnd[4];			            	
				kbn       = (String)search_cnd[5];
                syoriflg  = "";
                syoninflg = "";

                for ( int i = 0 ; i < HcdbDef.sinchoku.length ; i++ ) {
				/* 2005.08.09 �͏@ ���s */
                    if ( HcdbDef.sinchoku[i][0].equals( search_cnd[6] ) ) {
                        syoriflg  = HcdbDef.sinchoku[i][2];
                        syoninflg = HcdbDef.sinchoku[i][3];
                    }
                }
			
                buryakusyo  = (String)search_cnd[7];

                if ( search_cnd[6].equals( "1" ) ) {
                    unionFlg = 1;
                }

            } else if ( search_kbn.equals( "2" ) ) {
            	/* 2005.08.09 �͏@�@���s */
				kikan       = (String)search_cnd[4];
				kbn         = (String)search_cnd[5];
				kaihatuplan = (String)search_cnd[6];
				umu         = (String)search_cnd[7];
				buryakusyo  = (String)search_cnd[8];
            } else if ( search_kbn.equals( "3" ) ) {
                simeino     = (String)search_cnd[4];
                simeikanji  = "_" + (String)search_cnd[5];
                simeikana   = "_" + (String)search_cnd[6];
                simeieiji   = "_" + (String)search_cnd[7];
                buryakusyo  = (String)search_cnd[8];
            }

            String whr_p31 = "";
            if ( ( search_kbn.equals( "2" ) ) 
            &&   ( !kaihatuplan.equals( "" ) ) ) {
                String cond  = "";
                String cond2 = "";
                whr_p31 = " AND ";
                if ( umu.equals( "1" ) ) {
                    cond  = " IS NOT NULL";
                    cond2 = " OR ";
                } else {
                    cond =  " IS NULL";
                    cond2 = " AND ";
                }
                if ( kaihatuplan.equals( "1" ) ) {
                    whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[0] + cond;
                } else if ( kaihatuplan.equals( "2" ) ) {
                    whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[1] + cond;
                } else if ( kaihatuplan.equals( "3" ) ) {
                    whr_p31 = whr_p31 + "( " + "p31." + HcdbDef.p31_searchchallenge_whr_column[2] + cond;
                    for ( int i = 3 ; i < 7 ; i++ ) {
                        whr_p31 = whr_p31
                                + cond2 + "p31." + HcdbDef.p31_searchchallenge_whr_column[i] + cond;
                    }
                    whr_p31 = whr_p31 + " ) ";
                } else if ( kaihatuplan.equals( "4" ) ) {
                    whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[7] + cond;
                } else if ( kaihatuplan.equals( "5" ) ) {
                    whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[8] + cond;
                } else if ( kaihatuplan.equals( "6" ) ) {
                    whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[9] + cond;
                } else if ( kaihatuplan.equals( "7" ) ) {
                    whr_p31 = whr_p31 + "p31." + HcdbDef.p31_searchchallenge_whr_column[10] + cond;
                }
            }

            String[] t01_whr  = {
                simeino.trim().concat( "%" ),
                simeikanji.trim().concat( "%" ),
                simeikana.trim().concat( "%" ),
                buryakusyo.trim()
            };

            String[] t01_whr_eng  = {
                simeino.trim().concat( "%" ),
                simeikanji.trim().concat( "%" ),
                simeikana.trim().concat( "%" ),
                simeieiji.trim().concat( "%" ),
                buryakusyo.trim()
            };


            // select�̗�
            int colnum = HcdbDef.t01_searchchallenge_column.length
                       + HcdbDef.p31_searchchallenge_column.length - 1
                       + engName;

            String[] selcol = new String[colnum];

            int selind = 0;
            if ( jinRyaku == 1 && engName == 0 ) {
                selind = 0;
                for ( int i = 0 ; i < HcdbDef.t01_searchchallenge_column.length ; i++ ) {
                    selcol[selind] = "t01." + HcdbDef.t01_searchchallenge_column[i];
                    selind++;
                }
            } else if ( jinRyaku == 1 && engName == 1 ){
                selind = 0;
				for ( int i = 0 ; i < HcdbDef.t01_searchchallenge_eng_column.length ; i++ ) {
					selcol[selind] = "t01." + HcdbDef.t01_searchchallenge_eng_column[i];
                    selind++;
                }
            } else if ( jinRyaku == 2 && engName == 0 ) {
                selind = 0;
                for ( int i = 0 ; i < HcdbDef.t01_searchchallenge_yaku_column.length ; i++ ) {
                    if ( i == HcdbDef.jinryaku_pos && yakuMaster == 1 ) {
                        selcol[selind] = "t15." + HcdbDef.t01_searchchallenge_yaku_column[i];
                    } else {
                        selcol[selind] = "t01." + HcdbDef.t01_searchchallenge_yaku_column[i];
                    }
                    selind++;
                }
            } else if ( jinRyaku == 2 && engName == 1 ) {
                selind = 0;
                for ( int i = 0 ; i < HcdbDef.t01_searchchallenge_yaku_eng_column.length ; i++ ) {
                    if ( i == HcdbDef.jinryaku_eng_pos && yakuMaster == 1 ) {
                        selcol[selind] = "t15." + HcdbDef.t01_searchchallenge_yaku_eng_column[i];
                    } else {
                        selcol[selind] = "t01." + HcdbDef.t01_searchchallenge_yaku_eng_column[i];
                    }
                    selind++;
                }
            }

            for ( int i = 1 ; i < HcdbDef.p31_searchchallenge_column.length ; i++ ) {
                selcol[selind] = "p31." + HcdbDef.p31_searchchallenge_column[i];
                selind++;
            }

            sql = "SELECT " + selcol[0];

//20050818 ���H���G�F�@�G���n���X�ɔ����Z���N�g�ύX
			sql = sql
				+ ", " + selcol[1]
				+ ", " + selcol[2]
				+ ", " + selcol[3]
				+ ", " + selcol[4]
				+ ", " + selcol[5]
				+ ", " + selcol[6]                     //CHG#BPX-0301J-0427
				+ ", " + selcol[7]  + " as KIKAN_MEI2" //CHG#BPX-0301J-0427
				+ ", " + selcol[8]
				+ ", " + selcol[9]
				+ ", " + selcol[10]
				+ ", " + selcol[11]
                + ", " + selcol[12];                   //INS#BPX-0301J-0427
			
			//20050909 ���H���G�F�@����NO�����̂Ƃ���Seigyo_No���\�[�g�ɉ�����B	
			if ( search_kbn.equals( "3" )){
				sql=sql+ ", " + "p33.seigyo_no";
			}

            
            sql = sql
                + " FROM " + T01tbl
                + " , "    + P31tbl;
            if ( yakuMaster == 1 ) {
                sql = sql
                    + " , " + T15tbl;
            }
			//20050909 ���H���G�F�@����NO�����̂Ƃ��͂o33��from�ɉ�����B	
			if ( search_kbn.equals( "3" )){
				sql=sql+ ", " + "P33_CAREER_CHALLENGE_KIKAN_TBL p33 ";
			}

            String whr_stm  = "";
            String whr_stm2 = "";
            sql = sql
                + " WHERE " + "t01." + HcdbDef.t01_searchchallenge_column[0] + " = p31." + HcdbDef.p31_searchchallenge_column[0]
                + " AND ";
            /* 2005.08.09 �͏@�@���s */
            whr_stm =      "p31." + HcdbDef.p31_searchchallenge_column[1] + " LIKE '" + kikan     + "'"
                + " AND p31." + HcdbDef.p31_searchchallenge_column[3] + " LIKE '" + kbn       + "'";
            sql = sql
                + whr_stm
                + " AND p31." + HcdbDef.p31_searchchallenge_column[4] + " LIKE '" + syoriflg  + "'"
                + " AND p31." + HcdbDef.p31_searchchallenge_column[5] + " LIKE '" + syoninflg + "'"
                + whr_p31;

            int ind;

            if ( engName == 0
            ||    engName == 1 && simeieiji.trim().equals( "_" ) ) {
            // �p��������\�����Ȃ� or �p��������\������A���p�������̎w��Ȃ�
                for ( ind = 0 ; ind < t01_whr.length - 1 ; ind++ ) {
                    whr_stm2 = whr_stm2
                             + " AND t01." + HcdbDef.t01_searchchallenge_column[ind] + " LIKE '" + t01_whr[ind] + "'";
                }
                if ( !buryakusyo.trim().equals( "" ) ) {
                    whr_stm2 = whr_stm2
					         + " AND t01." + HcdbDef.t01_search_syozoku[ busyoPos - 1 ] + " LIKE '" + t01_whr[ind] + "'";
                }
            } else {
            // �p��������\������
                for ( ind = 0 ; ind < t01_whr_eng.length - 1 ; ind++ ) {
                    whr_stm2 = whr_stm2
                             + " AND t01." + HcdbDef.t01_searchchallenge_eng_column[ind] + " LIKE '" + t01_whr_eng[ind] + "'";
                }
                if ( !buryakusyo.trim().equals( "" ) ) {
                    whr_stm2 = whr_stm2
                             + " AND t01." + HcdbDef.t01_search_syozoku[ busyoPos - 1 ] + " LIKE '" + t01_whr_eng[ind] + "'";
                }
            }

            whr_stm2 = whr_stm2
                     + " AND t01." + HcdbDef.t01_honmu_cnd
                     + " AND t01." + HcdbDef.t01_taisyoku_cnd;

            if ( yakuMaster == 1 ) {
                whr_stm2 = whr_stm2
                         + " AND t15." + HcdbDef.yakusyoku_code
                         +   " = t01." + HcdbDef.yakusyoku_code;
            }

            sql = sql
                + whr_stm2;

			//20050909 ���H���G�F�@����NO�����̂Ƃ���P33�e�[�u���ƌ������A����NO���擾����B
			//2005/11/26_LYCE-AP_M_LOINT START	
			if ( search_kbn.equals( "3" )){
				sql = sql +" AND ("
						+" (P31.KUBUN = '2' AND P31.KIKAN_MEI = P33.JISSEKI_KIKAN_MEI )"
						+" OR (P31.KUBUN = '1' AND P31.KIKAN_MEI = P33.KEIKAKU_KIKAN_MEI ))";
			}
			//2005/11/26_LYCE-AP_M_LOINT END

            if ( unionFlg == 1 ) {
                sql = "( " + sql + " )"
                    + " UNION ALL"
                    + "( SELECT " + selcol[0];
                int newind;
                for ( newind = 1 ; newind < selcol.length - 7 ; newind++ ) {
                    sql = sql
                        + ", " + selcol[newind];
                }
                sql = sql
                /* 2005.08.09 �͏@�@���s */
                    + ", '" + kikan + "' " + selcol[newind].substring( 4 )
					+ ", '" + kikan + "' " + "KIKAN_MEI2"
                    + ", '" + kbn   + "' " + selcol[newind+2].substring( 4 )
                    + ", '' " + selcol[newind+3].substring( 4 )
                    + ", '' " + selcol[newind+4].substring( 4 )
                    + ", '' " + selcol[newind+5].substring( 4 )
                    + ", '' " + selcol[newind+6].substring( 4 )
                //2005/11/28_LYCE_R_QUANLA START
//                        + " FROM " + T01tbl;
//                    if ( yakuMaster == 1 ) {
//                        sql = sql
//                            + " , " + T15tbl;
//                    }
//                    sql = sql
//                        + " WHERE t01." + HcdbDef.t01_searchchallenge_column[0]
//                        + " NOT IN ( SELECT " + HcdbDef.p31_searchchallenge_column[0]
//                        + " FROM "  + P31tbl
//                        + " WHERE " + whr_stm + " )"
//                        + whr_stm2 + " )";
                //2005/11/28_LYCE_R_QUANLA END
                //2005/11/28_LYCE_A_QUANLA START
                        + " FROM " + T01tbl + " LEFT OUTER JOIN " + P31tbl
                        + " ON (T01." + HcdbDef.p31_search_jinmei[0] + " = P31." + HcdbDef.p31_hyoji_column[0]
                        + " AND " + whr_stm + ")";

                    if ( yakuMaster == 1 ) {
                        sql = sql
                            + " , " + T15tbl;
                    }
                    sql = sql
                        + " WHERE "
                        + " P31." + HcdbDef.p31_hyoji_column[0] + " IS NULL "
                        + whr_stm2 + " ) ";
                //2005/11/28_LYCE_A_QUANLA END
            }


			//20050909 ���H���G�F�@����NO�����̂Ƃ���P33�e�[�u���ƌ������A����NO���擾����B	
			if ( search_kbn.equals( "3" )){
				sql = sql
					  + " ORDER BY SOSIKI_CODE,SIMEI_NO,SEIGYO_NO DESC,KUBUN";
			}else
			{
				sql = sql
					  + " ORDER BY SOSIKI_CODE,SIMEI_NO,KUBUN";
			}

//20050818 ���H���G�F�@�G���n���X�Ή�

            Log.debug( "searchChallengeSQL:" + sql );
            stmt = dbConn.createStatement();
            rs   = stmt.executeQuery(sql);

            challengeList = new String[count][colnum];

            /* �������ʂ��e���ڂ��ƂɎ擾 */
            int index = 0;
            while( rs.next() ){
                for ( int i = 0 ; i < colnum ; i++ ) {
                    if ( rs.getString( selcol[i].substring( 4 ) ) == null ) {
                        challengeList[index][i] = "";
                    } else {
                        challengeList[index][i] = rs.getString( selcol[i].substring( 4 ) );
                    }
                }
                index++;
            }
            // MethodLog�o��
            Log.method( login_no ,"OUT","");

            return challengeList;
        } catch ( SQLException sqle ) {
            throw sqle;
        } catch ( NamingException ne ) {
            throw ne;
        } finally {
            rs.close();
            stmt.close();
            dbConn.close();
        }
    }




    /**
     * �f�[�^�x�[�X�ڑ����s���B
     * 
     * @return                       �f�[�^�x�[�X�ڑ��I�u�W�F�N�g
     * @exception  SQLException      SQL�G���[�����������ꍇ
     * @exception  NamingException   �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
     */ 
    private Connection getConnection( String login_no ) throws NamingException , SQLException {
        try {
            // MethodLog�o��
            Log.method( login_no ,"IN","");
            InitialContext initCtx = new InitialContext();
            /* Oracle JDBC Driver�̃��[�h */
            ds = (DataSource)initCtx.lookup("java:comp/env/jdbc/HCDB");
            /* DB�ڑ��I�u�W�F�N�g�̊l�� */
            Connection dbConn=ds.getConnection();
            // MethodLog�o��
            Log.method( login_no ,"OUT","");
            return dbConn;
        } catch ( SQLException sqle ) {
            throw sqle;
        } catch ( NamingException ne ) {
            throw ne;
        }
    }

    /**
     * SessionContext�����擾����B
     * @return  SessionContext���
     */     
    public SessionContext getSessionContext() {return my_ssc;}

    /**
     * EJB�R���e�i���Ǘ�����SessionContext����SessionBean�ɓn���BSessionBean�̍쐬���ɌĂяo�����B
     * @param  val   SessionContext���
     * @exception  RemoteException
     */
    public void setSessionContext(SessionContext val) throws RemoteException {my_ssc = val;}

    /**
     * �������Ȃ��B
     * @exception RemoteException
     */
    public void ejbActivate() throws RemoteException {/*�������܂���*/}

    /**
     * �������Ȃ��B
     * @exception CreateException
     * @exception RemoteException
     */    
    public void ejbCreate() throws CreateException,RemoteException {/*�������܂���*/}

    /**
     * �������Ȃ��B
     * @exception RemoteException
     */    
    public void ejbPassivate() throws RemoteException {/*�������܂���*/}

    /**
     * �������Ȃ��B
     * @exception RemoteException
     */    
    public void ejbRemove() throws RemoteException {/*�������܂���*/}

}
