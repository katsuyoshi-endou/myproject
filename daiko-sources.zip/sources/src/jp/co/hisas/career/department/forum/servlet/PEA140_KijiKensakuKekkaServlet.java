/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�t�H�[�����x���@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O       ���e
 *   2004/10/05  02-00-A     �c���N�W   �V�K�쐬
 *   2004/10/20  02-00-A     �������q   B-ADC01-K04�΍�
 *                                      �����L�[�̃G�X�P�[�v��߂�������ǉ�
 *                                      ("&quot;"��"\"")
 *   2004/10/21  02-00-A     �y���r�F   B-ADC01-K05�΍�
 *                                      �d�����錟���L�[���[�h���폜����悤�ɏC���B
 */
package jp.co.hisas.career.department.forum.servlet;

import jp.co.hisas.career.department.base.PEY_ServiceLocator;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.forum.ejb.*;

//import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.department.forum.valuebean.*;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.*;

import java.rmi.RemoteException;

import java.util.*;

import javax.ejb.CreateException;

import javax.naming.NamingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 *<PRE>
 *
 * �N���X���F
 *   PEA140_KijiKensakuKekkaServlet
 *
 * �@�\�����F
 *   �L�����������̐�����s���B
 *
 *</PRE>
 */
public class PEA140_KijiKensakuKekkaServlet extends PEY010_ControllerServlet {
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PEY_PersonalBean loginuser )
        throws NamingException, CreateException, PEY_WarningException, RemoteException, 
            PEY_WarningException {
        /*���\�b�h�g���[�X�o��*/
        Log.method( "", "IN", "" );

        /* �P��ʂɕ\������b�萔�̏�� */
        String searchSize = ( String )ReadFile.fileMapData.get( "FORUM_KENSAKU_MAX" );
        String forumPage  = ( String )ReadFile.fileMapData.get( "FORUM_KENSAKU_PAGE" );
        String forumIndex = ( String )ReadFile.fileMapData.get( "FORUM_KENSAKU_INDEX" );

        String forumId          = request.getParameter( "forum_id" );
        String searchKey        = request.getParameter( "search_key" );
        String searchTarget     = request.getParameter( "search_target" );
        String pageNo           = request.getParameter( "page_no" );
        String kensakuPageStart = request.getParameter( "page_start_no" );
        HttpSession session     = request.getSession(  );

        if ( ( pageNo != null ) && ( pageNo.trim(  ).length(  ) > 0 ) ) {
            // pageNo������ꍇ�͌������s��Ȃ��B
            Log.method( "", "OUT", "" );

            return getForwardPath(  );
        }

        searchKey = searchKey.replaceAll("&quot;", "\"");
        KeywordParser parser = new KeywordParser( searchKey );
        String[] keyword     = parser.parse(  );

        if ( ( keyword == null ) || ( keyword.length <= 0 ) ) {
            session.setAttribute( "toukouSearchBeans", new PEA_ToukouSearchBean[0] );
            Log.method( "", "OUT", "" );

            return getForwardPath(  );
        }

        if ( ( searchTarget == null ) || ( searchTarget.trim(  ).length(  ) <= 0 )
            || ( "all".equals( searchTarget.toLowerCase(  ) ) ) ) {
            forumId = null;
        }

        /* JNDI���̃��b�N�A�b�v */
        PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
        PEA_ToukouEJBHome home     = ( PEA_ToukouEJBHome )locator.getServiceLocation( "PEA_ToukouEJB",
                PEA_ToukouEJBHome.class );

        /* EJBObject�̎擾 */
        PEA_ToukouEJB ejb = home.create(  );

        PEA_ToukouSearchBean[] result = ejb.doSelect( forumId, keyword, loginuser );

        session.setAttribute( "toukouSearchBeans", chkMaxResult( result, searchSize ) );

        session.setAttribute( "forum_kensaku_max", searchSize );
        session.setAttribute( "forum_page", forumPage );
        session.setAttribute( "forum_index", forumIndex );

        /*���\�b�h�g���[�X�o��*/
        Log.method( "", "OUT", "" );

        return getForwardPath(  );
    }

    /**
     * �������ʍő匏���`�F�b�N
     * ���t�@�C���ɓo�^���Ă��錏�������͍폜���ĉ�ʕ\���B
     * �������A���t�@�C�����l�����Ȃ������ꍇ�ő�P�O�O�O���ɂĊm�F����B
     * @param result ��������
     * @param size �ő�\������
     * @return  ��ʕ\�����s��PEA_ToukouSearchBean
     */
    private PEA_ToukouSearchBean[] chkMaxResult( PEA_ToukouSearchBean[] result, String size ) {

        int i = 1000;

        try {
            i = ( ( ( size == null ) || size.equals( "" ) ) ? 1000 : Integer.parseInt( size ) );
        } catch ( Exception e ) {
        }

        i = ( ( i > result.length ) ? result.length : i );

        PEA_ToukouSearchBean[] rtnResult = new PEA_ToukouSearchBean[i];

        for ( int cnt = 0; cnt < i; cnt++ ) {
            rtnResult[cnt] = result[cnt];
        }


        return rtnResult;
    }
}


/**
 * KeywordParser<br />
 * �L�[���[�h�̉�͂��s���B
 *
 * @version 1.0
 * @since 1.0
 */
class KeywordParser {
    private String keyword        = null;
    private int parsePosition     = 0;
    private ArrayList keywordList = new ArrayList(  );

    /**
     * �R���X�g���N�^�B
     * @param keyword ��͑Ώۂ̕�����B
     */
    public KeywordParser( String keyword ) {
        this.keyword = keyword;
    }

    /**
     * ��͂��s���B<br />
     * @return ��͌��ʂ̕�����̔z��B
     */
    public String[] parse(  ) {
        // �_�u���N�H�[�e�[�V�����̐����`�F�b�N����B
        chkDoubleQuoteCount(  );

        for ( parsePosition = 0; parsePosition < keyword.length(  ); ++parsePosition ) {
            char c = keyword.charAt( parsePosition );

            if ( isDoubleQuote( c ) ) {
                parseDoubleQuote(  );
            } else if ( isSepareteString( c ) || isIgnoreString( c ) ) {
                continue;
            } else {
                parseNormalWord(  );
            }
        }
    	//B-ADC01-K05-S �d������L�[���[�h���폜����B
        ArrayList conpactList = new ArrayList();
        for (int i = 0; i < keywordList.size(); ++i) {
        	String k = (String)keywordList.get(i);
        	if (!conpactList.contains(k)) {
        		conpactList.add(k);
        	}
        }
        
        String[] keyword = new String[conpactList.size(  )];
        return ( String[] )conpactList.toArray( keyword );
    	//B-ADC01-K05-E
    }

    /**
     * ����"��������܂ł��P�̃L�[���[�h�Ƃ��Đ؂�o���ǉ�����B
     */
    private void parseDoubleQuote(  ) {
        int saveParsePosition = parsePosition;
        parsePosition++;

        StringBuffer buf = new StringBuffer(  );
        boolean breakFlg = false;

        for ( int i = parsePosition; i < keyword.length(  ); ++i ) {
            char c = keyword.charAt( i );

            if ( isDoubleQuote( c ) ) {
                if ( buf.length(  ) > 0 ) {
                    keywordList.add( buf.toString(  ) );
                }

                parsePosition     = i;
                breakFlg          = true;

                break;
            }

            if ( isIgnoreString( c ) ) {
                continue;
            } else {
                buf.append( c );
            }
        }

        if ( !breakFlg ) {
            parsePosition = saveParsePosition + 1;
            parseNormalWord(  );
        }
    }

    /**
     * �X�y�[�X���邢��"��������܂ł�1�̃L�[���[�h�Ƃ��Đ؂�o���ǉ�����B
     *
     */
    private void parseNormalWord(  ) {
        StringBuffer buf = new StringBuffer(  );
        boolean breakFlg = false;

        for ( int i = parsePosition; i < keyword.length(  ); ++i ) {
            char c = keyword.charAt( i );

            if ( isDoubleQuote( c ) ) {
                boolean findNextQuote  = false;
                boolean separatorBreak = false;
                StringBuffer buf2      = new StringBuffer(  );
                int j                  = 0;

                for ( j = i + 1; j < keyword.length(  ); ++j ) {
                    char cc = keyword.charAt( j );

                    if ( isSepareteString( cc ) ) {
                        separatorBreak = true;

                        break;
                    } else if ( isDoubleQuote( cc ) ) {
                        findNextQuote = true;
                    } else {
                        buf2.append( cc );
                    }
                }

                if ( findNextQuote ) {
                    if ( buf.length(  ) > 0 ) {
                        keywordList.add( buf.toString(  ) );
                    }

                    parsePosition     = i;
                    breakFlg          = true;

                    break;
                } else if ( !separatorBreak ) {
                    if ( buf.length(  ) > 0 ) {
                        keywordList.add( buf.toString(  ) );
                    }

                    breakFlg          = true;
                    parsePosition     = j;

                    break;
                } else {
                    if ( buf.length(  ) > 0 ) {
                        keywordList.add( buf.toString(  ) );
                    }

                    parsePosition     = i - 1; // ����̃p�[�X��"���܂߂�
                    breakFlg          = true;

                    break;
                }
            } else if ( isSepareteString( c ) ) {
                if ( buf.length(  ) > 0 ) {
                    keywordList.add( buf.toString(  ) );
                }

                parsePosition     = i;
                breakFlg          = true;

                break;
            } else if ( isIgnoreString( c ) ) {
                continue;
            } else {
                buf.append( c );
            }
        }

        if ( !breakFlg ) {
            if ( buf.length(  ) > 0 ) {
                keywordList.add( buf.toString(  ) );
            }

            parsePosition = keyword.length(  );
        }
    }

    /**
     * �_�u���N�H�[�e�[�V�����̐����`�F�b�N���A��̏ꍇ
     * �Ō�̃_�u���N�H�[�e�[�V��������菜��
     *         *
     */
    private void chkDoubleQuoteCount(  ) {
        String tmp = this.keyword;
        int cnt    = 0;

        while ( true ) {
            int i = tmp.indexOf( "\"" );

            if ( i >= 0 ) {
                cnt++;
                tmp = tmp.substring( i + 1, tmp.length(  ) );
            } else {
                break;
            }
        }

        if ( ( cnt % 2 ) != 0 ) {
            // ��܂�ł���ꍇ
            int i = this.keyword.lastIndexOf( "\"" );
            this.keyword = this.keyword.substring( 0, i ) + this.keyword.substring( i + 1 );
        }
    }

    private boolean isDoubleQuote( char c ) {
        return ( c == '"' ) || ( c == '�h' );
    }

    private boolean isSepareteString( char c ) {
        return ( c == ' ' ) || ( c == '�@' );
    }

    private boolean isIgnoreString( char c ) {
        return ( c == '<' ) || ( c == '<' ) || ( c == '>' ) || ( c == '&' );
    }
}
