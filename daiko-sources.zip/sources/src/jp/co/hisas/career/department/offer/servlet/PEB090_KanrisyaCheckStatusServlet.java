/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�Г�����@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O            ���e
 *   2004/08/12  01.00       �c���@�N�W      �V�K�쐬
 */
package jp.co.hisas.career.department.offer.servlet;

import jp.co.hisas.career.department.base.PEY_ServiceLocator;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.ejb.PEY_KouboEJB;
import jp.co.hisas.career.department.base.ejb.PEY_KouboEJBHome;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

import java.rmi.RemoteException;

import javax.ejb.CreateException;

import javax.naming.NamingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *<PRE>
 *
 * �N���X���F
 *   �Ǘ��҉�ʃT�[�u���b�g�N���X
 *
 * �@�\�����F
 *   ������e�[�u�����f�[�^���擾����
 *
 *</PRE>
 */
public class PEB090_KanrisyaCheckStatusServlet extends PEY010_ControllerServlet {
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PEY_PersonalBean loginuser )
        throws NamingException, CreateException, RemoteException, PEY_WarningException {
        /*���\�b�h�g���[�X�o��*/
        Log.method( "", "IN", "" );

        PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
        PEY_KouboEJBHome home      = ( PEY_KouboEJBHome )locator.getServiceLocation( "PEY_KouboEJB",
                PEY_KouboEJBHome.class );
        PEY_KouboEJB ejb = ( PEY_KouboEJB )home.create(  );

        String flg = request.getParameter( "job_type" );
		String url = "";

        /* �����������i�[���� */
        PEY_KouboBean koubo_Beans = new PEY_KouboBean(  );
        koubo_Beans.setKouboankenid( request.getParameter( "koubo_anken_id" ) );

        /* �f�[�^���擾���� */
        PEY_KouboBean[] kouboBeans = ejb.doSelect( koubo_Beans, loginuser, null );

        if ( ( kouboBeans == null ) || ( kouboBeans.length != 1 ) ) {
            // �G���[
        }

        if ( flg.equals( "0" ) ) {
// C-ADT02-001-S
//            if ( !kouboBeans[0].getSyoristatus(  ).equals( HcdbDef.D01_SINSATYU ) ) {
			if ( !kouboBeans[0].getSyoristatus(  ).equals( HcdbDef.D01_SINSATYU ) && 
				 !kouboBeans[0].getSyoristatus(  ).equals( HcdbDef.D01_KARISINSA_GOUKAKU ) && 
				 !kouboBeans[0].getSyoristatus(  ).equals( HcdbDef.D01_KARISINSA_FUGOUKAKU ) ){
// C-ADT02-001-E
                request.setAttribute( "warningID", "WEB034" );
                throw new PEY_WarningException(  );
            }
			url = getForwardPath(  );
        } else if ( flg.equals( "1" ) ) {
            if ( !kouboBeans[0].getSyoristatus(  ).equals( HcdbDef.D01_KARISINSA_GOUKAKU )
                && !kouboBeans[0].getSyoristatus(  ).equals( HcdbDef.D01_KARISINSA_FUGOUKAKU ) ) {
                request.setAttribute( "warningID", "WEB035" );
                throw new PEY_WarningException(  );
            }
			url = getForwardPath( "successtuuti"  );
        }

        /*���\�b�h�g���[�X�o��*/
        Log.method( "", "OUT", "" );

        return url;
    }
}
