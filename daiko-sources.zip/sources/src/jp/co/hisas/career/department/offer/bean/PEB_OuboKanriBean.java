/*
 * All Rights Reserved, Copyright (C) 2004,Hitachi System & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�Г�����@�\�j
 *
 * ���l�@�F
 *
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/11  01.00      ��]�F ��     �V�K�쐬
 *   2005/10/26  01.01       THANHLVT     �C���|�[�g���ꂽ�p�b�P�[�W��u��������B
 *
 */
package jp.co.hisas.career.department.offer.bean;

import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
//import jp.co.hisas.hcdb.personalsite.util.log.Log;//2005/10/26_LYCE_R_THANHLVT
import jp.co.hisas.career.util.log.Log;//2005/10/26_LYCE_A_THANHLVT

import java.io.Serializable;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletRequest;


/**
 *<PRE>
 *
 * �N���X��:
 *   PEB_OuboKanriBean �N���X
 *
 * �@�\����:
 *   ����Ǘ��ꗗ�f�[�^�̕ێ����s���B
 *
 *</PRE>
 */
public class PEB_OuboKanriBean extends PEY_KouboBean implements Serializable {
    private String gouhistatus         = null;
    private String oubosyakousinbi     = null;
    private String oubosyakousinjikoku = null;
    private String oubosyasyozoku      = null;
    private String oubosyasimei        = null;
    private String oubosyagaisen       = null;
    private String oubosyanaisen       = null;
    private String oubosyamail         = null;
    private String oubosyarenrakujikou = null;

    /**
     * �f�t�H���g�̃R���X�g���N�^
     */
    public PEB_OuboKanriBean(  ) {
        super(  );
    }

    /**
     * Request ����l���擾���ĉ���Ǘ�ValueBean���쐬���܂��B
     *
     * @param request �Ăь���ʂŐݒ肵�����N�G�X�g
     *
     */
    public PEB_OuboKanriBean( ServletRequest request ) {
        super( request );

        setGouhistatus( request.getParameter( "gouhi_status" ) );
        setOubosyakousinbi( request.getParameter( "kousinbi" ) );
        setOubosyakousinjikoku( request.getParameter( "kousinjikoku" ) );
    }

    /**
     * ResultSet ����l���擾���ĉ���Ǘ�ValueBean���쐬���܂��B
     *
     * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
     * @param TableName �e�[�u����
     *
     */
    public PEB_OuboKanriBean( ResultSet rs, String TableName )
        throws SQLException {
        super( rs, TableName );

        try {
            setGouhistatus( rs.getString( getIdentifier(  ) + "GOUHI_STATUS" ) );
            setOubosyakousinbi( rs.getString( getIdentifier(  ) + "OUBOSYA_KOUSINBI" ) );
            setOubosyakousinjikoku( rs.getString( getIdentifier(  ) + "OUBOSYA_KOUSINJIKOKU" ) );
            setOubosyasyozoku( rs.getString( getIdentifier(  ) + "OUBOSYA_TOIAWASE_SYOZOKU" ) );
            setOubosyasimei( rs.getString( getIdentifier(  ) + "OUBOSYA_TOIAWASE_SIMEI" ) );
            setOubosyagaisen( rs.getString( getIdentifier(  ) + "OUBOSYA_TOIAWASE_GAISEN" ) );
            setOubosyanaisen( rs.getString( getIdentifier(  ) + "OUBOSYA_TOIAWASE_NAISEN" ) );
            setOubosyamail( rs.getString( getIdentifier(  ) + "OUBOSYA_TOIAWASE_MAIL" ) );
            setOubosyarenrakujikou( rs.getString( getIdentifier(  ) + "OUBOSYA_RENRAKU_JIKOU" ) );
        } catch ( SQLException e ) {
            Log.error( "", "HJE-0001", e );
            throw e;
        }
    }

    /**
     * @return
     */
    public String getGouhistatus(  ) {
        return gouhistatus;
    }

    /**
     * @return
     */
    public String getOubosyakousinbi(  ) {
        return oubosyakousinbi;
    }

    /**
     * @return
     */
    public String getOubosyakousinjikoku(  ) {
        return oubosyakousinjikoku;
    }

    /**
     * @param string
     */
    public void setGouhistatus( String gouhistatus ) {
        this.gouhistatus = gouhistatus;
    }

    /**
     * @param string
     */
    public void setOubosyakousinbi( String oubosyakousinbi ) {
        this.oubosyakousinbi = oubosyakousinbi;
    }

    /**
     * @param string
     */
    public void setOubosyakousinjikoku( String oubosyakousinjikoku ) {
        this.oubosyakousinjikoku = oubosyakousinjikoku;
    }

    /**
     * @return
     */
    public String getOubosyagaisen(  ) {
        return oubosyagaisen;
    }

    /**
     * @return
     */
    public String getOubosyamail(  ) {
        return oubosyamail;
    }

    /**
     * @return
     */
    public String getOubosyanaisen(  ) {
        return oubosyanaisen;
    }

    /**
     * @return
     */
    public String getOubosyarenrakujikou(  ) {
        return oubosyarenrakujikou;
    }

    /**
     * @return
     */
    public String getOubosyasimei(  ) {
        return oubosyasimei;
    }

    /**
     * @return
     */
    public String getOubosyasyozoku(  ) {
        return oubosyasyozoku;
    }

    /**
     * @param string
     */
    public void setOubosyagaisen( String oubosyagaisen ) {
        this.oubosyagaisen = oubosyagaisen;
    }

    /**
     * @param string
     */
    public void setOubosyamail( String oubosyamail ) {
        this.oubosyamail = oubosyamail;
    }

    /**
     * @param string
     */
    public void setOubosyanaisen( String oubosyanaisen ) {
        this.oubosyanaisen = oubosyanaisen;
    }

    /**
     * @param string
     */
    public void setOubosyarenrakujikou( String oubosyarenrakujikou ) {
        this.oubosyarenrakujikou = oubosyarenrakujikou;
    }

    /**
     * @param string
     */
    public void setOubosyasimei( String oubosyasimei ) {
        this.oubosyasimei = oubosyasimei;
    }

    /**
     * @param string
     */
    public void setOubosyasyozoku( String oubosyasyozoku ) {
        this.oubosyasyozoku = oubosyasyozoku;
    }
}
