/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�Г�����@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/19  01.00       �V�_�@���Y  �V�K�쐬
 */
package jp.co.hisas.career.department.offer.servlet;

import jp.co.hisas.career.department.base.PEY_ServiceLocator;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.valuebean.*;

import jp.co.hisas.career.util.log.Log;

import jp.co.hisas.career.department.base.servlet.*;
import jp.co.hisas.career.department.offer.ejb.*;

import java.rmi.RemoteException;

import javax.ejb.CreateException;

import javax.naming.NamingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *<PRE>
 *
 * �N���X���F
 *   IchijiShinsaGouhiSetteiServlet
 *
 * �@�\�����F
 *   �񎟐R�����ېݒ�F�c�a�̃f�[�^���X�V���܂��B
 *
 *</PRE>
 */

public class PEB052_NijiShinsaGouhiSetteiServlet extends PEY010_ControllerServlet {

    /**
     * request������̓f�[�^���擾���A�c�a�Ƀf�[�^���i�[���܂��B
     * �i�[���D03_KOUBO_OUBOSYA_TBL�e�[�u��
     */
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PEY_PersonalBean loginuser )
        throws NamingException, CreateException, RemoteException, PEY_WarningException {
        /* ���\�b�h�g���[�X�o�� */
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );

        /* request ����A�l���擾 */
		String koubo_anken_id  = request.getParameter("koubo_anken_id");
		String simei_no  = request.getParameter("simei_no");
		String gouhi_status = request.getParameter("gouhi_status_g");
		String shozoku_t = request.getParameter("shozoku_t_txt");
		String shimei_t = request.getParameter("shimei_t_txt");
		String gaisen = request.getParameter("gaisen_txt");
		String naisen = request.getParameter("naisen_txt");
		String mail = request.getParameter("mail_txt");
		String renraku_jikou = request.getParameter("renraku_jikou_txt");
		String kousinbi 		= request.getParameter("kousinbi");
		String kousinjikoku 	= request.getParameter("kousinjikoku");

//		Log.debug("Koubo_anken_id=" + koubo_anken_id );
//		Log.debug("shimei_no=" + simei_no );
//		Log.debug("gouhi_status=" + gouhi_status );
//		Log.debug("shozoku_t=" + shozoku_t );
//		Log.debug("shimei_t=" + shimei_t );
//		Log.debug("gaisen=" + gaisen );
//		Log.debug("naisen=" + naisen );
//		Log.debug("mail=" + mail );
//		Log.debug("renraku_jikou=" + renraku_jikou );

        PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
		PEB_NijiShinsaGouhiSetteiEJBHome home   = ( PEB_NijiShinsaGouhiSetteiEJBHome )locator.getServiceLocation( "PEB_NijiShinsaGouhiSetteiEJB",
		PEB_NijiShinsaGouhiSetteiEJBHome.class );
		PEB_NijiShinsaGouhiSetteiEJB ejb           = home.create(  );

		PEY_KouboOubosyaBean koubooubosyaBean = new PEY_KouboOubosyaBean();
		koubooubosyaBean.setKouboankenid(koubo_anken_id);
		koubooubosyaBean.setSimeino(simei_no);
		koubooubosyaBean.setGouhistatus(gouhi_status);
		koubooubosyaBean.setToiawasesyozoku(shozoku_t);
		koubooubosyaBean.setToiawasesimei(shimei_t);
		koubooubosyaBean.setToiawasegaisen(gaisen);
		koubooubosyaBean.setToiawasenaisen(naisen);
		koubooubosyaBean.setToiawasemail(mail);
		koubooubosyaBean.setRenrakujikou(renraku_jikou);
		koubooubosyaBean.setKousinbi(kousinbi);
		koubooubosyaBean.setKousinjikoku(kousinjikoku);
		
        /* �X�V���s */
		int count = ejb.doUpdate( koubooubosyaBean ,loginuser );

        /* ���\�b�h�g���[�X�o�� */
        Log.method( loginuser.getSimeiNo(), "OUT", "" );

        return getForwardPath();
    }
    
}
