/*
 * All Rights Reserved, Copyright (C) 2004,Hitachi System & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�Г�����@�\�j
 *
 * ���l�@�F
 *
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/11  01.00      �c���@�N�W      �V�K�쐬
 *   2005/10/26  01.01      THANHLVT        �C���|�[�g���ꂽ�p�b�P�[�W��u��������B
 *
 */
package jp.co.hisas.career.department.base.valuebean;
	
//import jp.co.hisas.hcdb.personalsite.util.log.Log;//2005/10/26_LYCE_R_THANHLVT
import jp.co.hisas.career.util.log.Log;//2005/10/26_LYCE_A_THANHLVT

import java.io.Serializable;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.*;

import javax.servlet.ServletRequest;


/**
 *<PRE>
 *
 * �N���X��:
 *   PEY_KouboBean �N���X
 *
 * �@�\����:
 *   ����e�[�u���̃f�[�^�ێ����s���B
 *
 *</PRE>
 */
public class PEY_KouboBean extends PEY_MasterBean implements Serializable {
	private String kouboankenid			= null;
	private String kouboankenmei			= null;
	private String jigyobumei				= null;
	private String jigyoubutyomei			= null;
	private String sosikicode				= null;
	private String simeino 				= null;
	private String ankengaiyo 				= null;
	private Integer bosyuninzu              = null;
	private String idoukiboujiki           = null;
	private String kibousyokusyusonota    = null;
	private String syozokukinmuti          = null;
	private String kitaiyakuwaributyo      = null;
	private String kitaiyakuwarisyuningisi = null;
	private String kitaiyakuwarigisi		= null;
	private String kitaiyakuwariippan		= null;
	private String gyomunaiyo				= null;
	private String jobgrade				= null;
	private String syokumurireki			= null;
	private String oubosyayoukensonota		= null;
	private String koubopr					= null;
	private String sinseiriyu				= null;
	private String syoristatus				= null;
	private String jigyobutyosyoninbi		= null;
	private String keieikaigibi			= null;
	private String koukaibi				= null;
	private String toiawasesyozoku			= null;
	private String toiawasesimei			= null;
	private String toiawasegaisen			= null;
	private String toiawasenaisen			= null;
	private String toiawasemail			= null;
	private String renrakujikou			= null;

	/**
	 * �f�t�H���g�̃R���X�g���N�^
	 */
	public PEY_KouboBean(  ) {

	}
	/**
	 * �f�t�H���g�̃R���X�g���N�^
	 */
	public PEY_KouboBean( ServletRequest request ) {

		super( request );
		
		setAnkengaiyo(request.getParameter( "anken_gaiyo" ));
		try {
			setBosyuninzu( new Integer( request.getParameter( "bosyu_ninzu" ) ) );
		} catch ( NumberFormatException e ) {
			Log.debug( e.getMessage(  ) );
		}
		setGyomunaiyo(request.getParameter( "gyomu_naiyo" ));
		setIdoukiboujiki(request.getParameter( "idou_kibou_jiki" ));
		setJigyobumei(request.getParameter( "jigyobu_mei" ));
		setJigyoubutyomei(request.getParameter( "jigyobutyo_mei" ));
		setJigyobutyoSyoninbi(request.getParameter( "jigyobutyo_syoninbi" ));
		setJobgrade(request.getParameter( "job_grade" ));
		setKeieikaigibi(request.getParameter( "keiei_kaigibi" ));
		setKibousyokusyuSonota(request.getParameter( "kibou_syokusyu_sonota" ));
		setKitaiyakuwaributyo(request.getParameter( "kitai_yakuwari_butyo" ));
		setKitaiyakuwarigisi(request.getParameter( "kitai_yakuwari_gisi" ));
		setKitaiyakuwariippan(request.getParameter( "kitai_yakuwari_ippan" ));
		setKitaiyakuwarisyuningisi(request.getParameter( "kitai_yakuwari_syuningisi" ));
		setKouboankenid(request.getParameter( "koubo_anken_id" ));
		setKouboankenmei(request.getParameter( "koubo_anken_mei" ));
		setKoubopr(request.getParameter( "koubo_pr" ));
		setKoukaibi(request.getParameter( "koukaibi" ));
		setOubosyayoukensonota(request.getParameter( "oubosya_youken_sonota" ));
		setRenrakujikou(request.getParameter( "renraku_jikou" ) );
		setSimeino(request.getParameter( "simei_no" ));
		setSinseiriyu(request.getParameter( "sinsei_riyu" ));
		setSosikicode(request.getParameter( "sosiki_code" ));
		setSyokumurireki(request.getParameter( "syokumu_rireki" ));
		setSyoristatus(request.getParameter( "syori_status" ));
		setSyozokukinmuti(request.getParameter( "syozoku_kinmuti" ));
		setToiawasegaisen(request.getParameter( "toiawase_gaisen" ));
		setToiawasemail(request.getParameter( "toiawase_mail" ));
		setToiawasenaisen(request.getParameter( "toiawase_naisen" ));
		setToiawasesimei(request.getParameter( "toiawase_simei" ));
		setToiawasesyozoku(request.getParameter( "toiawase_syozoku" ));

	}

	/**
	 * ResultSet ����l���擾���Ă��m�点ValueBean���쐬���܂��B
	 *
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param TableName ���m�点���̃e�[�u����
	 *
	 */
	public PEY_KouboBean( ResultSet rs, String TableName )
		throws SQLException {

		super( rs, TableName );

		try {

			setAnkengaiyo(rs.getString( getIdentifier(  ) +"ANKEN_GAIYO" ));
			if ( rs.getString( getIdentifier(  ) + "BOSYU_NINZU" ) != null ) {
				setBosyuninzu( new Integer( rs.getInt( getIdentifier(  ) + "BOSYU_NINZU" ) ) );
			} else {
				setBosyuninzu( null );
			}
			setGyomunaiyo(rs.getString( getIdentifier(  ) +"GYOMU_NAIYO" ));
			setIdoukiboujiki(rs.getString( getIdentifier(  ) +"IDOU_KIBOU_JIKI" ));
			setJigyobumei(rs.getString( getIdentifier(  ) +"JIGYOBU_MEI" ));
			setJigyoubutyomei(rs.getString( getIdentifier(  ) +"JIGYOBUTYO_MEI" ));
			setJigyobutyoSyoninbi(rs.getString( getIdentifier(  ) +"JIGYOBUTYO_SYONINBI" ));
			setJobgrade(rs.getString( getIdentifier(  ) +"JOB_GRADE" ));
			setKeieikaigibi(rs.getString( getIdentifier(  ) +"KEIEI_KAIGIBI" ));
			setKibousyokusyuSonota(rs.getString( getIdentifier(  ) +"KIBOU_SYOKUSYU_SONOTA" ));
			setKitaiyakuwaributyo(rs.getString( getIdentifier(  ) +"KITAI_YAKUWARI_BUTYO" ));
			setKitaiyakuwarigisi(rs.getString( getIdentifier(  ) +"KITAI_YAKUWARI_GISI" ));
			setKitaiyakuwariippan(rs.getString( getIdentifier(  ) +"KITAI_YAKUWARI_IPPAN" ));
			setKitaiyakuwarisyuningisi(rs.getString( getIdentifier(  ) +"KITAI_YAKUWARI_SYUNINGISI" ));
			setKouboankenid(rs.getString( getIdentifier(  ) +"KOUBO_ANKEN_ID" ));
			setKouboankenmei(rs.getString( getIdentifier(  ) +"KOUBO_ANKEN_MEI" ));
			setKoubopr(rs.getString( getIdentifier(  ) +"KOUBO_PR" ));
			setKoukaibi(rs.getString( getIdentifier(  ) +"KOUKAIBI" ));
			setOubosyayoukensonota(rs.getString( getIdentifier(  ) +"OUBOSYA_YOUKEN_SONOTA" ));
			setRenrakujikou(rs.getString( getIdentifier(  ) +"RENRAKU_JIKOU" ));
			setSimeino(rs.getString( getIdentifier(  ) +"SIMEI_NO" ));
			setSinseiriyu(rs.getString( getIdentifier(  ) +"SINSEI_RIYU" ));
			setSosikicode(rs.getString( getIdentifier(  ) +"SOSIKI_CODE" ));
			setSyokumurireki(rs.getString( getIdentifier(  ) +"SYOKUMU_RIREKI" ));
			setSyoristatus(rs.getString( getIdentifier(  ) +"SYORI_STATUS" ));
			setSyozokukinmuti(rs.getString( getIdentifier(  ) +"SYOZOKU_KINMUTI" ));
			setToiawasegaisen(rs.getString( getIdentifier(  ) +"TOIAWASE_GAISEN" ));
			setToiawasemail(rs.getString( getIdentifier(  ) +"TOIAWASE_MAIL" ));
			setToiawasenaisen(rs.getString( getIdentifier(  ) +"TOIAWASE_NAISEN" ));
			setToiawasesimei(rs.getString( getIdentifier(  ) +"TOIAWASE_SIMEI" ));
			setToiawasesyozoku(rs.getString( getIdentifier(  ) +"TOIAWASE_SYOZOKU" ));

		} catch ( SQLException e ) {
			Log.error( "", "HJE-0001", e );
			throw e;
		}
	}

	/**
	 * @return
	 */
	public String getAnkengaiyo() {
		return ankengaiyo;
	}

	/**
	 * @return
	 */
	public Integer getBosyuninzu() {
		return bosyuninzu;
	}

	/**
	 * @return
	 */
	public String getGyomunaiyo() {
		return gyomunaiyo;
	}

	/**
	 * @return
	 */
	public String getIdoukiboujiki() {
		return idoukiboujiki;
	}

	/**
	 * @return
	 */
	public String getJigyobumei() {
		return jigyobumei;
	}

	/**
	 * @return
	 */
	public String getJigyobutyoSyoninbi() {
		return jigyobutyosyoninbi;
	}

	/**
	 * @return
	 */
	public String getJobgrade() {
		return jobgrade;
	}

	/**
	 * @return
	 */
	public String getKeieikaigibi() {
		return keieikaigibi;
	}

	/**
	 * @return
	 */
	public String getKibousyokusyuSonota() {
		return kibousyokusyusonota;
	}

	/**
	 * @return
	 */
	public String getKitaiyakuwaributyo() {
		return kitaiyakuwaributyo;
	}

	/**
	 * @return
	 */
	public String getKitaiyakuwarigisi() {
		return kitaiyakuwarigisi;
	}

	/**
	 * @return
	 */
	public String getKitaiyakuwariippan() {
		return kitaiyakuwariippan;
	}

	/**
	 * @return
	 */
	public String getKitaiyakuwarisyuningisi() {
		return kitaiyakuwarisyuningisi;
	}

	/**
	 * @return
	 */
	public String getKouboankenid() {
		return kouboankenid;
	}

	/**
	 * @return
	 */
	public String getKouboankenmei() {
		return kouboankenmei;
	}

	/**
	 * @return
	 */
	public String getKoubopr() {
		return koubopr;
	}

	/**
	 * @return
	 */
	public String getKoukaibi() {
		return koukaibi;
	}

	/**
	 * @return
	 */
	public String getOubosyayoukensonota() {
		return oubosyayoukensonota;
	}

	/**
	 * @return
	 */
	public String getRenrakujikou() {
		return renrakujikou;
	}

	/**
	 * @return
	 */
	public String getSimeino() {
		return simeino;
	}

	/**
	 * @return
	 */
	public String getSinseiriyu() {
		return sinseiriyu;
	}

	/**
	 * @return
	 */
	public String getSosikicode() {
		return sosikicode;
	}

	/**
	 * @return
	 */
	public String getSyokumurireki() {
		return syokumurireki;
	}

	/**
	 * @return
	 */
	public String getSyoristatus() {
		return syoristatus;
	}

	/**
	 * @return
	 */
	public String getSyozokukinmuti() {
		return syozokukinmuti;
	}

	/**
	 * @return
	 */
	public String getToiawasegaisen() {
		return toiawasegaisen;
	}

	/**
	 * @return
	 */
	public String getToiawasemail() {
		return toiawasemail;
	}

	/**
	 * @return
	 */
	public String getToiawasenaisen() {
		return toiawasenaisen;
	}

	/**
	 * @return
	 */
	public String getToiawasesimei() {
		return toiawasesimei;
	}

	/**
	 * @return
	 */
	public String getToiawasesyozoku() {
		return toiawasesyozoku;
	}

	/**
	 * @param string
	 */
	public void setAnkengaiyo(String string) {
		ankengaiyo = string;
	}

	/**
	 * @param string
	 */
	public void setBosyuninzu(Integer integer) {
		bosyuninzu = integer;
	}

	/**
	 * @param string
	 */
	public void setGyomunaiyo(String string) {
		gyomunaiyo = string;
	}

	/**
	 * @param string
	 */
	public void setIdoukiboujiki(String string) {
		idoukiboujiki = string;
	}

	/**
	 * @param string
	 */
	public void setJigyobumei(String string) {
		jigyobumei = string;
	}

	/**
	 * @param string
	 */
	public void setJigyobutyoSyoninbi(String string) {
		jigyobutyosyoninbi = string;
	}

	/**
	 * @param string
	 */
	public void setJobgrade(String string) {
		jobgrade = string;
	}

	/**
	 * @param string
	 */
	public void setKeieikaigibi(String string) {
		keieikaigibi = string;
	}

	/**
	 * @param string
	 */
	public void setKibousyokusyuSonota(String string) {
		kibousyokusyusonota = string;
	}

	/**
	 * @param string
	 */
	public void setKitaiyakuwaributyo(String string) {
		kitaiyakuwaributyo = string;
	}

	/**
	 * @param string
	 */
	public void setKitaiyakuwarigisi(String string) {
		kitaiyakuwarigisi = string;
	}

	/**
	 * @param string
	 */
	public void setKitaiyakuwariippan(String string) {
		kitaiyakuwariippan = string;
	}

	/**
	 * @param string
	 */
	public void setKitaiyakuwarisyuningisi(String string) {
		kitaiyakuwarisyuningisi = string;
	}

	/**
	 * @param string
	 */
	public void setKouboankenid(String string) {
		kouboankenid = string;
	}

	/**
	 * @param string
	 */
	public void setKouboankenmei(String string) {
		kouboankenmei = string;
	}

	/**
	 * @param string
	 */
	public void setKoubopr(String string) {
		koubopr = string;
	}

	/**
	 * @param string
	 */
	public void setKoukaibi(String string) {
		koukaibi = string;
	}

	/**
	 * @param string
	 */
	public void setOubosyayoukensonota(String string) {
		oubosyayoukensonota = string;
	}

	/**
	 * @param string
	 */
	public void setRenrakujikou(String string) {
		renrakujikou = string;
	}

	/**
	 * @param string
	 */
	public void setSimeino(String string) {
		simeino = string;
	}

	/**
	 * @param string
	 */
	public void setSinseiriyu(String string) {
		sinseiriyu = string;
	}

	/**
	 * @param string
	 */
	public void setSosikicode(String string) {
		sosikicode = string;
	}

	/**
	 * @param string
	 */
	public void setSyokumurireki(String string) {
		syokumurireki = string;
	}

	/**
	 * @param string
	 */
	public void setSyoristatus(String string) {
		syoristatus = string;
	}

	/**
	 * @param string
	 */
	public void setSyozokukinmuti(String string) {
		syozokukinmuti = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasegaisen(String string) {
		toiawasegaisen = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasemail(String string) {
		toiawasemail = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasenaisen(String string) {
		toiawasenaisen = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasesimei(String string) {
		toiawasesimei = string;
	}

	/**
	 * @param string
	 */
	public void setToiawasesyozoku(String string) {
		toiawasesyozoku = string;
	}

	/**
	 * <pre>
	 * ����e�[�u���̌��������𒊏o���܂��B
	 * �ȉ��̍��ڂ����������Ƃ��Ďg�p�ł��܂��B
	 * �E����Č�ID
	 * </pre>
	 *
	 * @return ���o���ꂽ��������
	 */
	public Map extractConditions(  ) {
		Map conditions = new LinkedHashMap(  );
		
		if ( ( getKouboankenid(  ) != null ) && !getKouboankenid(  ).equals( "" ) ) {
			conditions.put( "KOUBO_ANKEN_ID", getKouboankenid(  ) );
		}
		if ( ( getSyoristatus(  ) != null ) && !getSyoristatus(  ).equals( "" ) ) {
			conditions.put( "SYORI_STATUS", getSyoristatus(  ) );
		}

		return conditions;
	}

	/**
	 * @return
	 */
	public String getJigyoubutyomei() {
		return jigyoubutyomei;
	}

	/**
	 * @param string
	 */
	public void setJigyoubutyomei(String string) {
		jigyoubutyomei = string;
	}

}