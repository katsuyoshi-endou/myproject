/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�Г�����@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/16  01.00       ��� �ӎ�    �V�K�쐬
 *   2005/11/08             QUANLA       sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */
package jp.co.hisas.career.department.offer.servlet;

import java.rmi.RemoteException;
import java.io.IOException;
import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;

import jp.co.hisas.career.department.base.PEY_ServiceLocator;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.*;
import jp.co.hisas.career.department.offer.ejb.*;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;



/**
 *<PRE>
 *
 * �T�v�F
 *   �Г�����Č��̃f�[�^���擾����B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 *
 *</PRE>
 */
public class PEB040_CreateKouboDownServlet extends PEY010_ControllerServlet {
	
    protected String execute( HttpServletRequest request, HttpServletResponse response,
		PEY_PersonalBean loginuser )
        throws Exception {
        /*���\�b�h�g���[�X�o��*/
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );
        Log.performance( loginuser.getSimeiNo(  ), true, "" );

		PEB_KouboAnkenBean kouboAnkenData = null;
		String kouboAnkenId = request.getParameter("koubo_anken_id");
		String searchFlg = request.getParameter("searchFlg");

		if(searchFlg== null || searchFlg.length()<=0){
			if (kouboAnkenId == null || kouboAnkenId.length() <= 0){ //�V�K�쐬��
				kouboAnkenData = new PEB_KouboAnkenBean();
			}else{//����Č��C����
				try {
					PEY_ServiceLocator locator   = PEY_ServiceLocator.getInstance();
					PEB_KouboAnkenEJBHome kouboAnkenEJBHome = ( PEB_KouboAnkenEJBHome )locator.getServiceLocation( "PEB_KouboAnkenEJB",	PEB_KouboAnkenEJBHome.class );
					PEB_KouboAnkenEJB kouboAnkenEJB = kouboAnkenEJBHome.create(  );			
					kouboAnkenData = kouboAnkenEJB.getKouboAnkenInfo(kouboAnkenId);
				} catch ( NamingException e ) {
					Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
					throw e;
				} catch ( CreateException e ) {
					Log.error( loginuser.getSimeiNo(  ), "", e );
					throw e;
				} catch ( RemoteException e ) {
					Log.error( loginuser.getSimeiNo(  ), "", e );
					throw e;
				} catch ( Exception e ) {
					Log.error( loginuser.getSimeiNo(  ), "", e );
					throw e;
				}				
			}
		}else{//�ēǂݍ��ݎ�			
			kouboAnkenData = new PEB_KouboAnkenBean();
			PEB_KouboExtBean kouboAnken = new PEB_KouboExtBean();
			kouboAnken.setKouboankenid((String)request.getParameter("koubo_anken_id"));
			kouboAnken.setJigyobumei((String)request.getParameter("jigyobu_mei"));
			kouboAnken.setJigyoubutyomei((String)request.getParameter("jigyobutyo_mei"));
			kouboAnken.setSosikicode((String)request.getParameter("sosiki_code"));
			kouboAnken.setSimeino((String)request.getParameter("simei_no"));
			kouboAnken.setKouboankenmei((String)request.getParameter("koubo_anken_mei"));
			kouboAnken.setAnkengaiyo((String)request.getParameter("anken_gaiyo"));
			if(request.getParameter("bosyu_ninzu")==null || ((String)request.getParameter("bosyu_ninzu")).equals("") || ((String)request.getParameter("bosyu_ninzu")).length()==0)
			{
				kouboAnken.setBosyuninzu(null);
			}else{
				try{
					Integer boshu = Integer.valueOf((String)request.getParameter("bosyu_ninzu"));
					kouboAnken.setBosyuninzu(boshu);
				}catch(Exception ex){//�ĕ\�����ɕ�W�l���ɕs���Ȓl�����͂���Ă���ꍇ��null��ݒ肷��
					kouboAnken.setBosyuninzu(null);
				}
			}
			kouboAnken.setIdoukiboujiki((String)request.getParameter("idou_kibou_jiki"));
			kouboAnken.setKibousyokusyuSonota((String)request.getParameter("kibou_syokusyu_sonota"));
			kouboAnken.setKitaiyakuwaributyo((String)request.getParameter("kitai_yakuwari_butyo"));
			kouboAnken.setKitaiyakuwarisyuningisi((String)request.getParameter("kitai_yakuwari_syuningisi"));
			kouboAnken.setKitaiyakuwarigisi((String)request.getParameter("kitai_yakuwari_gisi"));
			kouboAnken.setKitaiyakuwariippan((String)request.getParameter("kitai_yakuwari_ippan"));
			kouboAnken.setSyozokukinmuti((String)request.getParameter("syozoku_kinmuti"));
			kouboAnken.setGyomunaiyo((String)request.getParameter("gyomu_naiyo"));
			kouboAnken.setJobgrade((String)request.getParameter("job_grade"));
			kouboAnken.setSyokumurireki((String)request.getParameter("syokumu_rireki"));
			kouboAnken.setOubosyayoukensonota((String)request.getParameter("oubosya_youken_sonota"));
			kouboAnken.setKoubopr((String)request.getParameter("koubo_pr"));
			kouboAnken.setSinseiriyu((String)request.getParameter("sinsei_riyu"));
			kouboAnken.setSyoristatus((String)request.getParameter("syori_status"));
			kouboAnken.setKousinbi((String)request.getParameter("kousinbi"));
			kouboAnken.setKousinjikoku((String)request.getParameter("kousinjikoku"));
			kouboAnken.setKinyusyaBusyomei((String)request.getParameter("kinyusyabusyomei"));
			kouboAnken.setKinyusyaSimei((String)request.getParameter("kinyusyasimei"));
			
			for(int i=0;i<3;i++){
				PEB_KouboKibouSyokusyuBean syokuBean = new PEB_KouboKibouSyokusyuBean();
				int no = i+1;
				syokuBean.setSyokuCode((String)request.getParameter("syokusyu_code"+no));
				syokuBean.setSenmonCode((String)request.getParameter("senmon_code"+no));
				syokuBean.setLevelCode((String)request.getParameter("level_code"+no));
				syokuBean.setKousinbi((String)request.getParameter("kousinbi"+no));
				syokuBean.setKousinjikoku((String)request.getParameter("kousinjikoku"+no));
				kouboAnkenData.addKouboKibouSyokusyuBean(syokuBean);
			}

			kouboAnkenData.setKouboBean(kouboAnken);

		}
		request.setAttribute("kouboAnkenBean",kouboAnkenData);	
		Log.performance( loginuser.getSimeiNo(  ), false, "" );

		/*���\�b�h�g���[�X�o��*/
		Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
		return getForwardPath();
    }
    
    /**
     * �G���[��ʂ�\������B
     */
    //private void redirectErrorView(HttpServletResponse response, PEY_PersonalBean loginuser) { //2005/11/08_LYCE_R_QUANLA
    //2005/11/08_LYCE_A_QUANLA START
    private void redirectErrorView(
            HttpServletRequest request,
            HttpServletResponse response,
            PEY_PersonalBean loginuser)
    throws ServletException {
    //2005/11/08_LYCE_A_QUANLA END
    	try {
			//response.sendRedirect( "/" + HcdbDef.root + "/view/Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
			this.getServletConfig( ).getServletContext( ).getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
    	}
    	catch (IOException e) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0012", e );
			throw new RuntimeException(e);
    	}
    }

}
