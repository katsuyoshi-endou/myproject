/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�Г�����@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/12  01.00     ��� �ӎ�   �V�K�쐬
 */
package jp.co.hisas.career.department.offer.ejb;

import jp.co.hisas.career.department.base.*;
import jp.co.hisas.career.department.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;
import jp.co.hisas.career.util.common.*;

import java.rmi.*;

import java.sql.*;

import javax.ejb.*;

import javax.naming.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PEB_ShinsaKekkaSetteiEJBBean�N���X
 *
 * �@�\�����F
 *   (�l��)�R�����ʂ��c�a�Ɋi�[����@�\�ł��B
 *   �i�[����f�[�^�͐R�����ʁA�A������
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PEB_ShinsaKekkaSetteiEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PEB_ShinsaKekkaSetteiEJBBean implements SessionBean {
    private SessionContext context = null;

	/**
	 * KOUBO_ANKEN_ID�ɑΉ����郌�R�[�h�̍X�V���s���܂��B
	 *
	 * @param sinsaKekkaSetteiBean
	 * @param loginuser
	 * @return
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
    public int doUpdate( PEY_KouboBean kouboBean, PEY_PersonalBean loginuser )
        throws PEY_WarningException, RemoteException, NamingException, CreateException {
			   Connection con       = null;
			   PreparedStatement ps = null;

			   try {
				   // ���\�b�h�g���[�X�o��
				   Log.method( loginuser.getSimeiNo(  ), "IN", "" );


				   // SQL�쐬
				   StringBuffer sql = new StringBuffer(  );
				   sql.append( "UPDATE " );
				   sql.append( HcdbDef.D01_TBL );
				   sql.append( " SET " );
				   sql.append( " SYORI_STATUS = ?," );
				   sql.append( " RENRAKU_JIKOU = ?," );
				   sql.append( " KOUSINSYA = ?,");
				   sql.append( " KOUSINBI = ?," );
				   sql.append( " KOUSINJIKOKU = ? " );
				   sql.append( " WHERE KOUBO_ANKEN_ID = ?");
				   sql.append( " AND KOUSINBI = ?");
				   sql.append("  AND KOUSINJIKOKU =?");
				   

				   // �R�l�N�V�����擾
				   PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance();
				   con = locator.getDataSource().getConnection();

				   //�f�o�b�O���O���o��
				   Log.debug(sql.toString());

				   // �X�V���s
				   ps = con.prepareStatement(sql.toString());
				   
				   ps.setString(1,kouboBean.getSyoristatus());
				   ps.setString(2,kouboBean.getRenrakujikou());
				   ps.setString(3,loginuser.getSimeiNo());
				   ps.setString(4,PZZ010_CharacterUtil.GetDay());
				   ps.setString(5,PZZ010_CharacterUtil.GetTime());
				   ps.setString(6,kouboBean.getKouboankenid());
				   ps.setString(7,kouboBean.getKousinbi());
				   ps.setString(8,kouboBean.getKousinjikoku());
				   
				   int count = ps.executeUpdate();				   
				   
				   if ( count != 1 ) {
					context.setRollbackOnly(  );
					throw new PEY_WarningException();
				   }				   
				   return count;

			   } catch ( NamingException e ) {
				   Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
				   throw new EJBException( e );
			   } catch ( SQLException e ) {
				   Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
				   throw new EJBException( e );
			   } catch ( RuntimeException e ) {
				   Log.error( loginuser.getSimeiNo(  ), "", e );
				   throw e;
			   } finally {
				   if ( ps != null ) {
					   try {
						   ps.close(  );
					   } catch ( SQLException e ) {
						   // �������Ȃ�
					   }
				   }

				   if ( con != null ) {
					   try {
						   con.close(  );
					   } catch ( SQLException e ) {
						   // �������Ȃ�
					   }
				   }
				// ���\�b�h�g���[�X�o��
				Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
			   }
		   }

  
    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }
}
