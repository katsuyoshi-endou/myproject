/*
 * �쐬��: 2004/06/17
 *
 * ���̐������ꂽ�R�����g�̑}�������e���v���[�g��ύX���邽��
 * �E�B���h�E > �ݒ� > Java > �R�[�h���� > �R�[�h�ƃR�����g
 */
package jp.co.hisas.career.learning.base.bean;

import java.io.Serializable;


/**
 * @author Administrator
 *
 * ���̐������ꂽ�R�����g�̑}�������e���v���[�g��ύX���邽��
 * �E�B���h�E > �ݒ� > Java > �R�[�h���� > �R�[�h�ƃR�����g
 */
public class PCY_AccessLogBean implements Serializable {
    private String sessionId                = null;
    private String loginJikoku              = null;
    private String logoutJikoku             = null;
    private String simeiNo                  = null;
    private String sosikiCode               = null;
    private int honninKensyuJyohou          = 0;
    private int kensyuJyohouTuika           = 0;
    private int kensyuJyohouKousin          = 0;
    private int kensyuJyohouSakujyo         = 0;
    private int kensyuKanryobiKousin        = 0;
    private int kensyuSyosai                = 0;
    private int jikosinkokuSyosai           = 0;
    private int kensyusyaClassSyosai        = 0;
    private int kensyuMousikomi             = 0;
    private int mousikomiTorikesi           = 0;
    private int jyukouHoukoku                = 0;
    private int esNinsyo                    = 0;
    private int reportTeisyutu              = 0;
    private int situmonNyuryoku             = 0;
    private int jikohyokaNyuryoku           = 0;
    private int jyukouSinkokuNyuryoku        = 0;
    private int kamokuItiran                = 0;
    private int syoninsyaKakuninHenkou      = 0;
    private int syoninsyaSentaku            = 0;
    private int syoninsyaSettei             = 0;
    private int syoninsyaSakujyo            = 0;
    private int syonin                      = 0;
    private int syoninSasimodosi            = 0;
    private int kensyukanriJyohou           = 0;
    private int kensyukanriClassSyosai      = 0;
    private int classCyosei                 = 0;
    private int uketuke                     = 0;
    private int uketukeSasimodosi           = 0;
    private int classCyusi                  = 0;
    private int seisekiNyuryoku             = 0;
    private int classSyuryo                 = 0;
    private int daikouNyuryoku              = 0;
    private int situmonHyoji                = 0;
    private int classSaikai                 = 0;
    private int kamokuTouroku               = 0;
    private int kamokuHenkou                = 0;
    private int kamokuSakujyo               = 0;
    private int kamokuSentaku               = 0;
    private int classTouroku                = 0;
    private int classHenkou                 = 0;
    private int classSakujyo                = 0;
    private int curriculumMapTouroku        = 0;
    private int taisyoBumonSettei           = 0;
    private int taisyoSyokusyuSettei        = 0;
    private int taisyosyaSettei             = 0;
    private int taisyosyaSetteiKensakukekka = 0;
    private int jyukouJyokyo                = 0;
    private int jyukouFollow                = 0;
    private int ninteiTaisyosyaKensaku      = 0;
    private int ninteiTaisyosyaItiran       = 0;
    private int jyukouNinteiTouroku         = 0;
	private int jyukouNinteiKaijyo          = 0;
	private int defaultSettei               = 0;
	/**
	 * @return
	 */
	public int getClassCyosei() {
		return classCyosei;
	}

	/**
	 * @return
	 */
	public int getClassCyusi() {
		return classCyusi;
	}

	/**
	 * @return
	 */
	public int getClassHenkou() {
		return classHenkou;
	}

	/**
	 * @return
	 */
	public int getClassSaikai() {
		return classSaikai;
	}

	/**
	 * @return
	 */
	public int getClassSakujyo() {
		return classSakujyo;
	}

	/**
	 * @return
	 */
	public int getClassSyuryo() {
		return classSyuryo;
	}

	/**
	 * @return
	 */
	public int getClassTouroku() {
		return classTouroku;
	}

	/**
	 * @return
	 */
	public int getCurriculumMapTouroku() {
		return curriculumMapTouroku;
	}

	/**
	 * @return
	 */
	public int getDaikouNyuryoku() {
		return daikouNyuryoku;
	}

	/**
	 * @return
	 */
	public int getEsNinsyo() {
		return esNinsyo;
	}

	/**
	 * @return
	 */
	public int getHonninKensyuJyohou() {
		return honninKensyuJyohou;
	}

	/**
	 * @return
	 */
	public int getJikohyokaNyuryoku() {
		return jikohyokaNyuryoku;
	}

	/**
	 * @return
	 */
	public int getJikosinkokuSyosai() {
		return jikosinkokuSyosai;
	}

	/**
	 * @return
	 */
	public int getJyukouHoukoku() {
		return jyukouHoukoku;
	}

	/**
	 * @return
	 */
	public int getJyukouSinkokuNyuryoku() {
		return jyukouSinkokuNyuryoku;
	}

	/**
	 * @return
	 */
	public int getJyukouFollow() {
		return jyukouFollow;
	}

	/**
	 * @return
	 */
	public int getJyukouJyokyo() {
		return jyukouJyokyo;
	}

	/**
	 * @return
	 */
	public int getJyukouNinteiKaijyo() {
		return jyukouNinteiKaijyo;
	}

	/**
	 * @return
	 */
	public int getJyukouNinteiTouroku() {
		return jyukouNinteiTouroku;
	}

	/**
	 * @return
	 */
	public int getKamokuHenkou() {
		return kamokuHenkou;
	}

	/**
	 * @return
	 */
	public int getKamokuItiran() {
		return kamokuItiran;
	}

	/**
	 * @return
	 */
	public int getKamokuSakujyo() {
		return kamokuSakujyo;
	}

	/**
	 * @return
	 */
	public int getKamokuSentaku() {
		return kamokuSentaku;
	}

	/**
	 * @return
	 */
	public int getKamokuTouroku() {
		return kamokuTouroku;
	}

	/**
	 * @return
	 */
	public int getKensyuJyohouKousin() {
		return kensyuJyohouKousin;
	}

	/**
	 * @return
	 */
	public int getKensyuJyohouSakujyo() {
		return kensyuJyohouSakujyo;
	}

	/**
	 * @return
	 */
	public int getKensyuJyohouTuika() {
		return kensyuJyohouTuika;
	}

	/**
	 * @return
	 */
	public int getKensyukanriClassSyosai() {
		return kensyukanriClassSyosai;
	}

	/**
	 * @return
	 */
	public int getKensyukanriJyohou() {
		return kensyukanriJyohou;
	}

	/**
	 * @return
	 */
	public int getKensyuKanryobiKousin() {
		return kensyuKanryobiKousin;
	}

	/**
	 * @return
	 */
	public int getKensyuMousikomi() {
		return kensyuMousikomi;
	}

	/**
	 * @return
	 */
	public int getKensyusyaClassSyosai() {
		return kensyusyaClassSyosai;
	}

	/**
	 * @return
	 */
	public int getKensyuSyosai() {
		return kensyuSyosai;
	}

	/**
	 * @return
	 */
	public String getLoginJikoku() {
		return loginJikoku;
	}

	/**
	 * @return
	 */
	public String getLogoutJikoku() {
		return logoutJikoku;
	}

	/**
	 * @return
	 */
	public int getMousikomiTorikesi() {
		return mousikomiTorikesi;
	}

	/**
	 * @return
	 */
	public int getNinteiTaisyosyaItiran() {
		return ninteiTaisyosyaItiran;
	}

	/**
	 * @return
	 */
	public int getNinteiTaisyosyaKensaku() {
		return ninteiTaisyosyaKensaku;
	}

	/**
	 * @return
	 */
	public int getReportTeisyutu() {
		return reportTeisyutu;
	}

	/**
	 * @return
	 */
	public int getSeisekiNyuryoku() {
		return seisekiNyuryoku;
	}

	/**
	 * @return
	 */
	public String getSessionId() {
		return sessionId;
	}

	/**
	 * @return
	 */
	public String getSimeiNo() {
		return simeiNo;
	}

	/**
	 * @return
	 */
	public int getSitumonHyoji() {
		return situmonHyoji;
	}

	/**
	 * @return
	 */
	public int getSitumonNyuryoku() {
		return situmonNyuryoku;
	}

	/**
	 * @return
	 */
	public String getSosikiCode() {
		return sosikiCode;
	}

	/**
	 * @return
	 */
	public int getSyonin() {
		return syonin;
	}

	/**
	 * @return
	 */
	public int getSyoninSasimodosi() {
		return syoninSasimodosi;
	}

	/**
	 * @return
	 */
	public int getSyoninsyaKakuninHenkou() {
		return syoninsyaKakuninHenkou;
	}

	/**
	 * @return
	 */
	public int getSyoninsyaSakujyo() {
		return syoninsyaSakujyo;
	}

	/**
	 * @return
	 */
	public int getSyoninsyaSentaku() {
		return syoninsyaSentaku;
	}

	/**
	 * @return
	 */
	public int getSyoninsyaSettei() {
		return syoninsyaSettei;
	}

	/**
	 * @return
	 */
	public int getTaisyoBumonSettei() {
		return taisyoBumonSettei;
	}

	/**
	 * @return
	 */
	public int getTaisyosyaSettei() {
		return taisyosyaSettei;
	}

	/**
	 * @return
	 */
	public int getTaisyosyaSetteiKensakukekka() {
		return taisyosyaSetteiKensakukekka;
	}

	/**
	 * @return
	 */
	public int getTaisyoSyokusyuSettei() {
		return taisyoSyokusyuSettei;
	}

	/**
	 * @return
	 */
	public int getUketuke() {
		return uketuke;
	}

	/**
	 * @return
	 */
	public int getUketukeSasimodosi() {
		return uketukeSasimodosi;
	}

	/**
	 * @param i
	 */
	public void setClassCyosei(int i) {
		classCyosei = i;
	}

	/**
	 * @param i
	 */
	public void setClassCyusi(int i) {
		classCyusi = i;
	}

	/**
	 * @param i
	 */
	public void setClassHenkou(int i) {
		classHenkou = i;
	}

	/**
	 * @param i
	 */
	public void setClassSaikai(int i) {
		classSaikai = i;
	}

	/**
	 * @param i
	 */
	public void setClassSakujyo(int i) {
		classSakujyo = i;
	}

	/**
	 * @param i
	 */
	public void setClassSyuryo(int i) {
		classSyuryo = i;
	}

	/**
	 * @param i
	 */
	public void setClassTouroku(int i) {
		classTouroku = i;
	}

	/**
	 * @param i
	 */
	public void setCurriculumMapTouroku(int i) {
		curriculumMapTouroku = i;
	}

	/**
	 * @param i
	 */
	public void setDaikouNyuryoku(int i) {
		daikouNyuryoku = i;
	}

	/**
	 * @param i
	 */
	public void setEsNinsyo(int i) {
		esNinsyo = i;
	}

	/**
	 * @param i
	 */
	public void setHonninKensyuJyohou(int i) {
		honninKensyuJyohou = i;
	}

	/**
	 * @param i
	 */
	public void setJikohyokaNyuryoku(int i) {
		jikohyokaNyuryoku = i;
	}

	/**
	 * @param i
	 */
	public void setJikosinkokuSyosai(int i) {
		jikosinkokuSyosai = i;
	}

	/**
	 * @param i
	 */
	public void setJyukouHoukoku(int i) {
		jyukouHoukoku = i;
	}

	/**
	 * @param i
	 */
	public void setJyukouSinkokuNyuryoku(int i) {
		jyukouSinkokuNyuryoku = i;
	}

	/**
	 * @param i
	 */
	public void setJyukouFollow(int i) {
		jyukouFollow = i;
	}

	/**
	 * @param i
	 */
	public void setJyukouJyokyo(int i) {
		jyukouJyokyo = i;
	}

	/**
	 * @param i
	 */
	public void setJyukouNinteiKaijyo(int i) {
		jyukouNinteiKaijyo = i;
	}

	/**
	 * @param i
	 */
	public void setJyukouNinteiTouroku(int i) {
		jyukouNinteiTouroku = i;
	}

	/**
	 * @param i
	 */
	public void setKamokuHenkou(int i) {
		kamokuHenkou = i;
	}

	/**
	 * @param i
	 */
	public void setKamokuItiran(int i) {
		kamokuItiran = i;
	}

	/**
	 * @param i
	 */
	public void setKamokuSakujyo(int i) {
		kamokuSakujyo = i;
	}

	/**
	 * @param i
	 */
	public void setKamokuSentaku(int i) {
		kamokuSentaku = i;
	}

	/**
	 * @param i
	 */
	public void setKamokuTouroku(int i) {
		kamokuTouroku = i;
	}

	/**
	 * @param i
	 */
	public void setKensyuJyohouKousin(int i) {
		kensyuJyohouKousin = i;
	}

	/**
	 * @param i
	 */
	public void setKensyuJyohouSakujyo(int i) {
		kensyuJyohouSakujyo = i;
	}

	/**
	 * @param i
	 */
	public void setKensyuJyohouTuika(int i) {
		kensyuJyohouTuika = i;
	}

	/**
	 * @param i
	 */
	public void setKensyukanriClassSyosai(int i) {
		kensyukanriClassSyosai = i;
	}

	/**
	 * @param i
	 */
	public void setKensyukanriJyohou(int i) {
		kensyukanriJyohou = i;
	}

	/**
	 * @param i
	 */
	public void setKensyuKanryobiKousin(int i) {
		kensyuKanryobiKousin = i;
	}

	/**
	 * @param i
	 */
	public void setKensyuMousikomi(int i) {
		kensyuMousikomi = i;
	}

	/**
	 * @param i
	 */
	public void setKensyusyaClassSyosai(int i) {
		kensyusyaClassSyosai = i;
	}

	/**
	 * @param i
	 */
	public void setKensyuSyosai(int i) {
		kensyuSyosai = i;
	}

	/**
	 * @param string
	 */
	public void setLoginJikoku(String string) {
		loginJikoku = string;
	}

	/**
	 * @param string
	 */
	public void setLogoutJikoku(String string) {
		logoutJikoku = string;
	}

	/**
	 * @param i
	 */
	public void setMousikomiTorikesi(int i) {
		mousikomiTorikesi = i;
	}

	/**
	 * @param i
	 */
	public void setNinteiTaisyosyaItiran(int i) {
		ninteiTaisyosyaItiran = i;
	}

	/**
	 * @param i
	 */
	public void setNinteiTaisyosyaKensaku(int i) {
		ninteiTaisyosyaKensaku = i;
	}

	/**
	 * @param i
	 */
	public void setReportTeisyutu(int i) {
		reportTeisyutu = i;
	}

	/**
	 * @param i
	 */
	public void setSeisekiNyuryoku(int i) {
		seisekiNyuryoku = i;
	}

	/**
	 * @param string
	 */
	public void setSessionId(String string) {
		sessionId = string;
	}

	/**
	 * @param string
	 */
	public void setSimeiNo(String string) {
		simeiNo = string;
	}

	/**
	 * @param i
	 */
	public void setSitumonHyoji(int i) {
		situmonHyoji = i;
	}

	/**
	 * @param i
	 */
	public void setSitumonNyuryoku(int i) {
		situmonNyuryoku = i;
	}

	/**
	 * @param string
	 */
	public void setSosikiCode(String string) {
		sosikiCode = string;
	}

	/**
	 * @param i
	 */
	public void setSyonin(int i) {
		syonin = i;
	}

	/**
	 * @param i
	 */
	public void setSyoninSasimodosi(int i) {
		syoninSasimodosi = i;
	}

	/**
	 * @param i
	 */
	public void setSyoninsyaKakuninHenkou(int i) {
		syoninsyaKakuninHenkou = i;
	}

	/**
	 * @param i
	 */
	public void setSyoninsyaSakujyo(int i) {
		syoninsyaSakujyo = i;
	}

	/**
	 * @param i
	 */
	public void setSyoninsyaSentaku(int i) {
		syoninsyaSentaku = i;
	}

	/**
	 * @param i
	 */
	public void setSyoninsyaSettei(int i) {
		syoninsyaSettei = i;
	}

	/**
	 * @param i
	 */
	public void setTaisyoBumonSettei(int i) {
		taisyoBumonSettei = i;
	}

	/**
	 * @param i
	 */
	public void setTaisyosyaSettei(int i) {
		taisyosyaSettei = i;
	}

	/**
	 * @param i
	 */
	public void setTaisyosyaSetteiKensakukekka(int i) {
		taisyosyaSetteiKensakukekka = i;
	}

	/**
	 * @param i
	 */
	public void setTaisyoSyokusyuSettei(int i) {
		taisyoSyokusyuSettei = i;
	}

	/**
	 * @param i
	 */
	public void setUketuke(int i) {
		uketuke = i;
	}

	/**
	 * @param i
	 */
	public void setUketukeSasimodosi(int i) {
		uketukeSasimodosi = i;
	}

	/**
	 * @return
	 */
	public int getDefaultSettei() {
		return defaultSettei;
	}

	/**
	 * @param i
	 */
	public void setDefaultSettei(int i) {
		defaultSettei = i;
	}

}
