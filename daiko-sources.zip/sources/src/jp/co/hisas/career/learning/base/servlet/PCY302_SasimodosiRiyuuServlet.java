/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 * 
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/11  01.00      �n�� ��q    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.*;
import javax.ejb.*;
import javax.naming.*;
import javax.servlet.http.*;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;

/**
 *<PRE>
 *
 * �N���X���F
 *   PCY302_SasimodosiRiyuuServlet �N���X
 *
 * �@�\�����F
 *   ���߂����R���͊m�F��ʂɑJ�ڂ��܂��B
 *
 *</PRE>
 */
public class PCY302_SasimodosiRiyuuServlet extends PCY010_ControllerServlet {

    protected String execute( HttpServletRequest request, HttpServletResponse response, PCY_PersonalBean loginuser )
        throws NamingException, CreateException, RemoteException, PCY_WarningException {

        // Log�o��
        Log.method     ( loginuser.getSimeiNo(), "IN", "" );
        Log.performance( loginuser.getSimeiNo(), true, "" );

        String[] check    = (String[])request.getParameterValues( "syonin" );
        String kamokuCode = "";
        String classCode  = "";
        String simeiNo    = "";
        String status     = "";
        String uketsuke   = "";

        PCY_ServiceLocator      locator = PCY_ServiceLocator.getInstance();
        PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome)locator
                                          .getServiceLocation( "PCY_MousikomiJyokyoEJB", PCY_MousikomiJyokyoEJBHome.class );
        PCY_MousikomiJyokyoEJB     ejb  = home.create();

        PCY_ClassEJBHome      homeClass = (PCY_ClassEJBHome)locator
                                          .getServiceLocation( "PCY_ClassEJB", PCY_ClassEJBHome.class );
        PCY_ClassEJB           ejbClass = homeClass.create();

        for ( int i = 0 ; i < check.length ; i++ ) {

            kamokuCode = (String)request.getParameter( "kamoku_code_" + check[i] );
            classCode  = (String)request.getParameter( "class_code_"  + check[i] );
            simeiNo    = (String)request.getParameter( "simei_no_"    + check[i] );
            status     = (String)request.getParameter( "status_"      + check[i] );
            uketsuke   = (String)request.getParameter( "uketsuke_"    + check[i] );

            // �I���������R�[�h�̃N���X�����擾����
            PCY_ClassBean classBeanDummy = new PCY_ClassBean();
            classBeanDummy.getKamokuBean().setKamokuCode( kamokuCode );
            classBeanDummy.setClassCode( classCode );
            Log.transaction( loginuser.getSimeiNo(), true, "" );
            PCY_ClassBean classBean = ejbClass.doSelectByPrimaryKey( classBeanDummy, loginuser );
            Log.transaction( loginuser.getSimeiNo(), false, "" );

            /* �I���������R�[�h�̏��(�\����)���擾���� */
            PCY_MousikomiJyokyoBean mousikomiJyokyoBean = new PCY_MousikomiJyokyoBean();
            mousikomiJyokyoBean.setKamokuCode( kamokuCode );
            mousikomiJyokyoBean.setClassCode( classCode );
            mousikomiJyokyoBean.setSimeiNo( simeiNo );
            mousikomiJyokyoBean.setStatus( status );

            Log.transaction( loginuser.getSimeiNo(), true, "" );
            PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = ejb.getList( mousikomiJyokyoBean, loginuser );
            Log.transaction( loginuser.getSimeiNo(), false, "" );

            // ���F�s�v�̏ꍇ
            if ( classBean.getSyoninKubun().equals( "0" ) ) {
                request.setAttribute( "warningID", "WCB050" );
                throw new PCY_WarningException();
            }
            // ��t�敪��"�v"�̃N���X�̏ꍇ
            if ( classBean.getUketukeKubun().equals( "1" ) ) {
                // �񍐑҂��A����҂��̏ꍇ
                if ( Integer.parseInt( mousikomiJyokyoBeans[0].getStatus() ) >= 2 ) {
                    request.setAttribute( "warningID", "WCB060" );
                    throw new PCY_WarningException();
                }
                // ��t�҂��̏ꍇ
                if ( Integer.parseInt( mousikomiJyokyoBeans[0].getStatus() ) == 1 ) {
                    request.setAttribute( "warningID", "WCB070" );
                    throw new PCY_WarningException();
                }
            // ��t�s�v�E�񍐋敪��"�v"�̃N���X�̏ꍇ
            } else if ( !classBean.getHoukokuKubun().equals( "0" ) ) {
                if ( Integer.parseInt( mousikomiJyokyoBeans[0].getStatus() ) == 3 ) {
                    request.setAttribute( "warningID", "WCB080" );
                    throw new PCY_WarningException();
                }
            }
            // ���̑��p�^�[���ŏ��F�ς݂̏ꍇ
            if ( Integer.parseInt( mousikomiJyokyoBeans[0].getStatus() ) != 0 ) {
                request.setAttribute( "warningID", "WCB070" );
                throw new PCY_WarningException();
            }
            classBeanDummy      = null;
            mousikomiJyokyoBean = null;
        }
        return getForwardPath();
    }
}
