package jp.co.hisas.career.learning.base.valuebean;

import java.io.Serializable;

/**
 * �g�D����u�󋵂̍s���Bean�N���X
 */
public class PCY_SoshikiJukouJyokyoRowBean implements Serializable {

	/** �Ј�NO */
	private String personCode;
	/** ���� */
	private String personName;
	/** ������ */
	private String shozokuCode;
	private String shozokuName;
	/** �u���R�[�h */
	private String kamokuCode;
	private boolean kamokuExist;
	/** �u���� */
	private String kamokuName;
	/** �N���X */
	private String classCode;
	private boolean classExist;
	private String className;
	/** �J�Ó� */
	private String startDate;
	private String endDate;
	/** �J�Òn */
	private String chikuMei;
	/** ��� */
	private String status;
	/** �K�{�u���敪 */
	private String hissuKubun;
	/** �g�D�R�[�h*/
	private String sosikiCode;
	
	public String getChikuMei() {
		return chikuMei;
	}
	public void setChikuMei(String chikuMei) {
		this.chikuMei = chikuMei;
	}
	public String getClassCode() {
		return classCode;
	}
	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}
	public boolean isClassExist() {
		return classExist;
	}
	public void setClassExist(boolean classExist) {
		this.classExist = classExist;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getHissuKubun() {
		return hissuKubun;
	}
	public void setHissuKubun(String hissuKubun) {
		this.hissuKubun = hissuKubun;
	}
	public String getKamokuCode() {
		return kamokuCode;
	}
	public void setKamokuCode(String kamokuCode) {
		this.kamokuCode = kamokuCode;
	}
	public boolean isKamokuExist() {
		return kamokuExist;
	}
	public void setKamokuExist(boolean kamokuExist) {
		this.kamokuExist = kamokuExist;
	}
	public String getKamokuName() {
		return kamokuName;
	}
	public void setKamokuName(String kamokuName) {
		this.kamokuName = kamokuName;
	}
	public String getPersonCode() {
		return personCode;
	}
	public void setPersonCode(String personCode) {
		this.personCode = personCode;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public String getShozokuCode() {
		return shozokuCode;
	}
	public void setShozokuCode(String shozokuCode) {
		this.shozokuCode = shozokuCode;
	}
	public String getShozokuName() {
		return shozokuName;
	}
	public void setShozokuName(String shozokuName) {
		this.shozokuName = shozokuName;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSosikiCode() {
		return sosikiCode;
	}
	public void setSosikiCode(String sosikiCode) {
		this.sosikiCode = sosikiCode;
	}
	
}
