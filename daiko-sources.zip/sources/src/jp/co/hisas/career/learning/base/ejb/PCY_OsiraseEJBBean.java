/*
* All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
*
* �v���W�F�N�g���@�F
*   ���V�e�ACareer�i���C�Ǘ��@�\�j
*
* ���l�@�F
*   �Ȃ�
*
* �����@�F
*   ���t        �o�[�W����  ���O         ���e
*   2004/08/03  01.00       ���� ��    �V�K�쐬
*/
package jp.co.hisas.career.learning.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.common.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_OsiraseEJBBean �N���X
 *
 * �@�\�����F
 *   ���m�点�e�[�u���ւ̑�����s���܂��B
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PCY_OsiraseEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PCY_OsiraseEJBBean implements SessionBean {
    private SessionContext context = null;

    /**
     * ���m�点�������f�[�^�擾���Ԃ��܂��B
     *
     * @param osiraseBean ��������
     * @param loginuser ���O�C�����[�U
     * @return PCY_OsiraseBean[] �擾����
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
	public PCY_OsiraseBean[] doSelect( PCY_OsiraseBean osiraseBean, PCY_PersonalBean loginuser ) {
		
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			// ���������̍쐬
			Map conditions     = osiraseBean.extractConditions(  );

			PCY_OsiraseBean[] osiraseBeans = null;
            StringBuffer sql  = new StringBuffer(  );

			sql.append( "SELECT * ");
			sql.append( " FROM " + HcdbDef.L52_TBL );

			StringBuffer where = new StringBuffer(  );

			for ( Iterator ite = conditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
				Object column = ite.next(  );
				where.append( " AND " + column + "=?" );
			}

			sql.append( where.toString(  ).replaceFirst( "AND", "WHERE" ) );

			// ���m�点�e�[�u���\�[�g���̍쐬
			sql.append( "  ORDER BY HAKKOUBI DESC, HAKKOUJIKOKU ASC" );

			// �f�o�b�O�̏o��
			Log.debug( sql.toString( ) );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �������s
            ps = con.prepareStatement( sql.toString(  ) );

			List osiraseBeanList = new ArrayList(  );

			int count = 1;
			for ( Iterator ite = conditions.keySet(  ).iterator(  ); ite.hasNext(  ); count++ ) {
				Object key = ite.next(  );
				Log.debug( Integer.toString( count ) + ":" + key + ":"
					+ conditions.get( key ) );
				ps.setObject(count, conditions.get( key ) );
			}

			ResultSet rs = ps.executeQuery(  );

			while ( rs.next(  ) ) {
				osiraseBeanList.add( new PCY_OsiraseBean( rs, null ) );
			}
			rs.close(  );
			ps.clearParameters(  );

			osiraseBeans = new PCY_OsiraseBean[osiraseBeanList.size(  )];
			osiraseBeanList.toArray( osiraseBeans );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
            return osiraseBeans;

        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

	/**
	 * ���m�点�����f�[�^�ǉ����܂��B
	 *
	 * @param osiraseBean �ǉ��f�[�^
	 * @param loginuser ���O�C�����[�U
	 * @return ret ��������
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doInsert( PCY_OsiraseBean osiraseBean, PCY_PersonalBean loginuser ) throws PCY_WarningException{
		
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			// ���������̍쐬
			Map conditions     = osiraseBean.extractConditions(  );

			PCY_OsiraseBean[] osiraseBeans = null;
			StringBuffer sql  = new StringBuffer(  );

			sql.append( "INSERT INTO ");
			sql.append( HcdbDef.L52_TBL );
			sql.append(" (" + "SEQ_NO," + PCY_OsiraseBean.getColumns() + ") ");
			
			sql.append( " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)" );

			// �f�o�b�O�̏o��
			Log.debug( sql.toString( ) );

			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con     = locator.getDataSource(  ).getConnection(  );

			PCY_CounterEJBHome counterHome = ( PCY_CounterEJBHome )locator.getServiceLocation( "PCY_CounterEJB",
					PCY_CounterEJBHome.class );
			PCY_CounterEJB counterEjb = counterHome.create(  );
			String seqNo = counterEjb.countLearningOsiraseSeqNo();
			
			// �������s
			ps = con.prepareStatement( sql.toString(  ) );

			ps.setString(1,seqNo);
			ps.setString(2,osiraseBean.getHakkoubi());
			ps.setString(3,osiraseBean.getHakkoujikoku());
			ps.setString(4,osiraseBean.getSyubetsuFlg());
			ps.setString(5,osiraseBean.getKigenbi());
			ps.setString(6,osiraseBean.getNaiyou());
			ps.setString(7,osiraseBean.getTsuutatsu_page());
			ps.setString(8,osiraseBean.getHyoujiFlg());
			ps.setString(9,PZZ010_CharacterUtil.GetDay(  ));
			ps.setString(10,PZZ010_CharacterUtil.GetTime(  ));
			ps.setString(11,loginuser.getSimeiNo());
			ps.setString(12,PZZ010_CharacterUtil.GetDay(  ));
			ps.setString(13,PZZ010_CharacterUtil.GetTime(  ));
			ps.setString(14,loginuser.getSimeiNo());
			
			int ret = ps.executeUpdate();

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
			return ret;

		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new PCY_WarningException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new PCY_WarningException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw new PCY_WarningException( e );
		} catch ( RemoteException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw new PCY_WarningException( e );
		} catch ( CreateException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw new PCY_WarningException( e );
		}finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * ���m�点�����X�V���܂��B
	 *
	 * @param osiraseBean �X�V�f�[�^
	 * @param loginuser ���O�C�����[�U
	 * @return count �擾����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdate( PCY_OsiraseBean osiraseBean, PCY_PersonalBean loginuser )
		throws PCY_WarningException {
		Connection con       = null;
		PreparedStatement ps = null;
		try {
		// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			// SQL�쐬
			StringBuffer sql = new StringBuffer(  );
			sql.append( "UPDATE " + HcdbDef.L52_TBL );
			sql.append( " SET  HAKKOUBI=?," );
			sql.append( "      HAKKOUJIKOKU=?," );
			sql.append( "      SYUBETSU_FLG=?," );
			sql.append( "      KIGENBI=?," );
			sql.append( "      NAIYOU=?," );
			sql.append( "      TSUUTATSU_PAGE=?," );
			sql.append( "      HYOUJI_FLG=?," );
			sql.append( "      KOUSINBI=?," );
			sql.append( "      KOUSINJIKOKU=?," );
			sql.append( "      KOUSINSYA=?" );
			sql.append( " WHERE SEQ_NO=?" );
			sql.append( "   AND KOUSINBI=?" );
			sql.append( "   AND KOUSINJIKOKU=?" );
			
			//�f�o�b�O�̏o��
			Log.debug( sql.toString( ) );
			
			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con     = locator.getDataSource(  ).getConnection(  );
			
			int count=0;
			
			ps = con.prepareStatement( sql.toString(  ) );
			ps.setString(1,osiraseBean.getHakkoubi());
			ps.setString(2,osiraseBean.getHakkoujikoku());
			ps.setString(3,osiraseBean.getSyubetsuFlg());
			ps.setString(4,osiraseBean.getKigenbi());
			ps.setString(5,osiraseBean.getNaiyou());
			ps.setString(6,osiraseBean.getTsuutatsu_page());
			ps.setString(7,osiraseBean.getHyoujiFlg());
			ps.setString(8,PZZ010_CharacterUtil.GetDay(  ));
			ps.setString(9,PZZ010_CharacterUtil.GetTime(  ));
			ps.setString(10,loginuser.getSimeiNo());
			
			String seqNo = osiraseBean.getseqNo();
			for ( int i = seqNo.length(  ); i < HcdbDef.SEQ_NO_LENGTH; i++ ) {
				seqNo = seqNo + " ";
			}
			ps.setString(11,seqNo);
			ps.setString(12,osiraseBean.getKousinbi());
			ps.setString(13,osiraseBean.getKousinjikoku());
				
			count = ps.executeUpdate(  );
			
			if ( count != 1 ) {
				context.setRollbackOnly(  );
				throw new PCY_WarningException(  );
			}
				// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
			return count;
			
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new PCY_WarningException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new PCY_WarningException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw new PCY_WarningException( e );
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * ���m�点�����폜���܂��B
	 *
	 * @param osiraseBean[] �폜����
	 * @param loginuser ���O�C�����[�U
	 * @return count �擾����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doDelete( PCY_OsiraseBean[] osiraseBean, PCY_PersonalBean loginuser ) throws PCY_WarningException{
		
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			PCY_OsiraseBean[] osiraseBeans = null;
			StringBuffer sql  = new StringBuffer(  );

			sql.append( "DELETE FROM " + HcdbDef.L52_TBL );
			sql.append( " WHERE SEQ_NO=?" );
			sql.append( "   AND KOUSINBI=?" );
			sql.append( "   AND KOUSINJIKOKU=?" );
			
			// �f�o�b�O�̏o��
			Log.debug( sql.toString( ) );

			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con     = locator.getDataSource(  ).getConnection(  );

			ps = con.prepareStatement( sql.toString(  ) );

			int count=0;
			for(int i=0; i< osiraseBean.length; i++){
			
				// �폜���s
				ps = con.prepareStatement( sql.toString(  ) );
				
				String seqNo = osiraseBean[i].getseqNo();
				for ( int t = seqNo.length(  ); t < HcdbDef.SEQ_NO_LENGTH; i++ ) {
					seqNo = seqNo + " ";
				}
				ps.setString(1,seqNo);
				ps.setString(2,osiraseBean[i].getKousinbi());
				ps.setString(3,osiraseBean[i].getKousinjikoku());
				
				count += ps.executeUpdate(  );
			}
			if ( count != osiraseBean.length ) {
				context.setRollbackOnly(  );
				throw new PCY_WarningException(  );
			}
				// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
			return count;
			
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new PCY_WarningException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new PCY_WarningException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw new PCY_WarningException( e );
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }
}
