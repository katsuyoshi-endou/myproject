/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/05/27  01.00      ���� ���V    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import jp.co.hisas.career.base.sosiki.bean.SosikiBean;
import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.common.*; //INS#0301L-0103

import javax.servlet.http.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY240_SearchPersonalInfoServlet �N���X
 *
 * �@�\�����F
 *        �����L�[�ƂȂ�p�[�\�i�������擾���������ʂ�Ԃ��܂��B
 *
 *</PRE>
 */
public class PCY253_PersonalIchiranServlet extends PCY010_ControllerServlet {
    /**
     * �����L�[�ƂȂ�p�[�\�i�������擾���������ʂ�Ԃ��܂��B
     * �E�����ԍ�
     * �E��������
     * �E�J�i����
     * �E�p�ꎁ��
     * �E�g�D�R�[�h�i�g�D�K�w���`�F�b�N���܂��B�j
     * 
     * @param request
     * @param response
     * @param loginuser
     * @return
     * @throws NamingException
     * @throws CreateException
     * @throws RemoteException
     * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
     */
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PCY_PersonalBean loginuser ) throws Exception {
        /* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );
        Log.performance( loginuser.getSimeiNo(  ), true, "" );

        PCY_PersonalBean kensakuPersnalBean = new PCY_PersonalBean(  );
        if ( request.getParameter( "simei_no" ) != null && !request.getParameter( "simei_no" ).equals("") ) {
			kensakuPersnalBean.setSimeiNo( request.getParameter( "simei_no" ) );
        }

		if ( request.getParameter( "kanji_simei" ) != null && !request.getParameter( "kanji_simei" ).equals("") ) {
			//kensakuPersnalBean.setKanjiSimei( request.getParameter( "kanji_simei" ) );
			kensakuPersnalBean.setKanjiSimei( PZZ010_CharacterUtil.convertHalfSizeKana( request.getParameter( "kanji_simei" ) ) ); //CHG#0301L-0103
		}
		
		if ( request.getParameter( "kana_simei" ) != null && !request.getParameter( "kana_simei" ).equals("") ) {
			//kensakuPersnalBean.setKanaSimei( request.getParameter( "kana_simei" ) );
			kensakuPersnalBean.setKanaSimei( PZZ010_CharacterUtil.convertHalfSizeKana( request.getParameter( "kana_simei" ) ) ); //CHG#0301L-0103
		}
		
		if ( request.getParameter( "eigo_simei" ) != null && !request.getParameter( "eigo_simei" ).equals("") ) {
			//kensakuPersnalBean.setEigoSimei( request.getParameter( "eigo_simei" ) );
			kensakuPersnalBean.setEigoSimei( PZZ010_CharacterUtil.convertHalfSizeKana( request.getParameter( "eigo_simei" ) ) ); //CHG#0301L-0103
		}

        /* �g�D�R�[�h���擾���A�Ώۂ̑g�D�K�w�ɃZ�b�g���� */
        String sosiki_kaiso_code = request.getParameter( "sosiki_code" );

        if ( ( sosiki_kaiso_code != null ) && !sosiki_kaiso_code.equals( "" ) ) {
            String[] sosiki_info = SosikiBean.getSosikiByCode( sosiki_kaiso_code,
                    loginuser.getSimeiNo(  ) );

            if ( sosiki_info[4].equals( "1" ) ) {
                kensakuPersnalBean.setSyozokuCode1( sosiki_kaiso_code );
            } else if ( sosiki_info[4].equals( "2" ) ) {
                kensakuPersnalBean.setSyozokuCode2( sosiki_kaiso_code );
            } else if ( sosiki_info[4].equals( "3" ) ) {
                kensakuPersnalBean.setSyokuCode3( sosiki_kaiso_code );
            } else if ( sosiki_info[4].equals( "4" ) ) {
                kensakuPersnalBean.setSyozokuCode4( sosiki_kaiso_code );
            } else if ( sosiki_info[4].equals( "5" ) ) {
                kensakuPersnalBean.setSyozokuCode5( sosiki_kaiso_code );
            } else if ( sosiki_info[4].equals( "6" ) ) {
                kensakuPersnalBean.setSyozokuCode6( sosiki_kaiso_code );
            } else if ( sosiki_info[4].equals( "7" ) ) {
                kensakuPersnalBean.setSyozokuCode7( sosiki_kaiso_code );
            } else if ( sosiki_info[4].equals( "8" ) ) {
                kensakuPersnalBean.setSyozokuCode8( sosiki_kaiso_code );
            } else if ( sosiki_info[4].equals( "9" ) ) {
                kensakuPersnalBean.setSyozokuCode9( sosiki_kaiso_code );
            }
        }

        /* �T�[�r�X���P�[�^�[�̎擾 */
        PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

        /* PersonalEJB */
        PCY_PersonalEJBHome personal_home = ( PCY_PersonalEJBHome )locator.getServiceLocation( "PCY_PersonalEJB",
                PCY_PersonalEJBHome.class );
        PCY_PersonalEJB personal_ejb = personal_home.create(  );
        Log.transaction( loginuser.getSimeiNo(  ), true, "" );

        PCY_PersonalBean[] personalBeans = personal_ejb.doSelect( kensakuPersnalBean, loginuser );
        Log.transaction( loginuser.getSimeiNo(  ), false, "" );
        request.setAttribute( "personalBeans", personalBeans );
        
        PCY_SyoninsyaBean syoninsyaBean = new PCY_SyoninsyaBean( request );
        request.setAttribute( "syoninsyaBean" , syoninsyaBean );

        /* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
        Log.performance( loginuser.getSimeiNo(  ), false, "" );
        Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

        return getForwardPath(  );
    }
}
