/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/05/27  01.00      ���� ���V    �V�K�쐬
 *   2005/12/03  01.00      �c�� ��`    �\���폜������p�~  BPX-0301J-0475
 */
package jp.co.hisas.career.learning.base.servlet;

import jp.co.hisas.career.learning.base.*;
// DEL#BPX-0301J-0475
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;

import javax.servlet.http.*;
import java.util.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY241_MousikomiKensyurirekiKensakuByClassBeansServlet �N���X
 *
 * �@�\�����F
 *        �����ԍ��A�N���X�������ɁA�\���󋵂ƌ��C���������擾���܂��B
 *
 *</PRE>
 */
public class PCY241_MousikomiKensyurirekiKensakuByClassBeansServlet extends PCY010_ControllerServlet {
    /**
     * �����ԍ������ɁA�p�[�\�i�������������܂��B
     * �E�����ԍ�
     * �E�N���X���
     *
     * @param request
     * @param response
     * @param loginuser
     * @return
     * @throws NamingException
     * @throws CreateException
     * @throws RemoteException
     * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
     */
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PCY_PersonalBean loginuser ) throws Exception {
        /* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );
        Log.performance( loginuser.getSimeiNo(  ), true, "" );

        String simeiNo = request.getParameter( "simei_no" );

        PCY_ClassBean[] classBeans = ( PCY_ClassBean[] )request.getAttribute( "classBeans" );

//        PCY_MousikomiJyokyoBean[] mousikomiBeans = new PCY_MousikomiJyokyoBean[classBeans.length];
		
		ArrayList kamokuNinteiList = new ArrayList();
//      DEL#BPX-0301J-0475
		ArrayList kensyuRirekiList = new ArrayList();
		ArrayList classList        = new ArrayList();
		ArrayList mousikomiList    = new ArrayList();
		
        /* �T�[�r�X���P�[�^�[�̎擾 */
        PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

        /* MousikomiEJB */
        PCY_MousikomiJyokyoEJBHome mousikomi_home = ( PCY_MousikomiJyokyoEJBHome )locator
            .getServiceLocation( "PCY_MousikomiJyokyoEJB", PCY_MousikomiJyokyoEJBHome.class );
        PCY_MousikomiJyokyoEJB mousikomi_ejb = mousikomi_home.create(  );

        /* KensyuRirekiEJB */
        PCY_KensyuRirekiEJBHome kensyuRireki_home = ( PCY_KensyuRirekiEJBHome )locator
            .getServiceLocation( "PCY_KensyuRirekiEJB", PCY_KensyuRirekiEJBHome.class );
        PCY_KensyuRirekiEJB kensyuRireki_ejb = kensyuRireki_home.create(  );

        /* �\���󋵂ƌ��C���������� */
        for ( int i = 0; i < classBeans.length; i++ ) {
        	boolean saveClass = false;
        	
            /* �\���󋵌������� */
            PCY_MousikomiJyokyoBean kensakuMousikomiBean = new PCY_MousikomiJyokyoBean(  );
            kensakuMousikomiBean.setSimeiNo( simeiNo );
            kensakuMousikomiBean.setClassBean( classBeans[i] );

            /* �\���󋵌������s�� */
            Log.transaction( loginuser.getSimeiNo(  ), true, "" );

            PCY_MousikomiJyokyoBean[] kekka_mousikomiBeans = mousikomi_ejb.getList( kensakuMousikomiBean,
                    loginuser );
            Log.performance( loginuser.getSimeiNo(  ), false, "" );

			if ( ( kekka_mousikomiBeans != null ) && ( kekka_mousikomiBeans.length != 0 ) ) {
				/* �\���󋵁A��u�󋵂�ݒ肷��*/
				String st = kekka_mousikomiBeans[0].getStatus();
				String uk = kekka_mousikomiBeans[0].getUketsukeJyotai();
				
				if(st.equals("0") && uk == null ){
					kekka_mousikomiBeans[0].setJyukoJyokyo("0");
					kekka_mousikomiBeans[0].setMousikomijyokyo("1");
				}else if(st.equals("1") && uk.equals("0") ){
					kekka_mousikomiBeans[0].setJyukoJyokyo("0");
					kekka_mousikomiBeans[0].setMousikomijyokyo("2");					
				}else if(st.equals("1") && uk.equals("1") ){
					kekka_mousikomiBeans[0].setJyukoJyokyo("0");
					kekka_mousikomiBeans[0].setMousikomijyokyo("3");					
				}else if(st.equals("1") && uk.equals("2") ){
					kekka_mousikomiBeans[0].setJyukoJyokyo("0");
					kekka_mousikomiBeans[0].setMousikomijyokyo("4");
				}else if(st.equals("1") && uk.equals("3") ){
					kekka_mousikomiBeans[0].setJyukoJyokyo("0");
					kekka_mousikomiBeans[0].setMousikomijyokyo("5");
				}else if(st.equals("1") && uk.equals("4") ){
					kekka_mousikomiBeans[0].setJyukoJyokyo("0");
					kekka_mousikomiBeans[0].setMousikomijyokyo("6");
				}else if(st.equals("2") && uk == null ){
					kekka_mousikomiBeans[0].setJyukoJyokyo("1");
					kekka_mousikomiBeans[0].setMousikomijyokyo("");
				}else if(st.equals("3") && uk == null ){
					kekka_mousikomiBeans[0].setJyukoJyokyo("2");
					kekka_mousikomiBeans[0].setMousikomijyokyo("");
				}else{
					kekka_mousikomiBeans[i].setJyukoJyokyo("");
					kekka_mousikomiBeans[i].setMousikomijyokyo("");
				}
					mousikomiList.add(kekka_mousikomiBeans[0]);
					kensyuRirekiList.add(null);
					classList.add(classBeans[i]);
					saveClass=true;
			}
			
						
            /* ���C���̌������s�� */
            /* ���C���������� */
            PCY_KensyuRirekiBean kensakuKensyuRirekiBean = new PCY_KensyuRirekiBean(  );
            kensakuKensyuRirekiBean.setSimeiNo( simeiNo );
            kensakuKensyuRirekiBean.setKamokuCode( classBeans[i].getKamokuBean(  ).getKamokuCode(  ) );
            kensakuKensyuRirekiBean.setClassCode( classBeans[i].getClassCode(  ) );

            /* ���C���������s�� */
            Log.transaction( loginuser.getSimeiNo(  ), true, "" );

            PCY_KensyuRirekiBean[] kekka_kensyurekiBeans = kensyuRireki_ejb.getList( new PCY_KensyuRirekiBean[] { kensakuKensyuRirekiBean },
                    loginuser );

            Log.performance( loginuser.getSimeiNo(  ), false, "" );

			if ( ( kekka_kensyurekiBeans != null ) && ( kekka_kensyurekiBeans.length != 0 ) ) {
				for(int t = 0; t<kekka_kensyurekiBeans.length;t++){
					kensyuRirekiList.add(kekka_kensyurekiBeans[t]);
					mousikomiList.add(null);
					classList.add(classBeans[i]);
					saveClass=true;
				}
			}
			
			/*�ȖڔF�茟��*/
			kensakuKensyuRirekiBean.setClassCode(null);            
			PCY_KensyuRirekiBean[] kekka_KamokukensyurekiBeans = kensyuRireki_ejb.getList( new PCY_KensyuRirekiBean[] { kensakuKensyuRirekiBean },
					loginuser );

			if ( ( kekka_KamokukensyurekiBeans != null ) && ( kekka_KamokukensyurekiBeans.length != 0 ) ) {
				for(int t = 0; t<kekka_KamokukensyurekiBeans.length;t++){
					kamokuNinteiList.add(kekka_KamokukensyurekiBeans[t]);
				}
			}

//          DEL#BPX-0301J-0475
			if(saveClass==false){
				mousikomiList.add(null);
				kensyuRirekiList.add(null);
				classList.add(classBeans[i]);
			}
		}
        
		/*���C�����������ʂ�Bean��*/	
		PCY_KensyuRirekiBean[] kensyurirekiBeans = new PCY_KensyuRirekiBean[kensyuRirekiList.size()];
		kensyurirekiBeans = ( PCY_KensyuRirekiBean[] )kensyuRirekiList.toArray( kensyurirekiBeans );
		
		/*�\���������ʂ�Bean��*/	
		PCY_MousikomiJyokyoBean[] mousikomiBeans = new PCY_MousikomiJyokyoBean[mousikomiList.size()];
		mousikomiBeans = ( PCY_MousikomiJyokyoBean[] )mousikomiList.toArray( mousikomiBeans );
		
        /*�ȖڔF�茟�����ʂ�Bean��*/
		PCY_KensyuRirekiBean[] kensyuKamokuRirekiBeans = new PCY_KensyuRirekiBean[kamokuNinteiList.size()];
		kensyuKamokuRirekiBeans = ( PCY_KensyuRirekiBean[] )kamokuNinteiList.toArray( kensyuKamokuRirekiBeans );

//      DEL#BPX-0301J-0475

		/*class����Bean��*/	
		PCY_ClassBean[] ret_classBeans = new PCY_ClassBean[classList.size()];
		ret_classBeans = ( PCY_ClassBean[] )classList.toArray( ret_classBeans );
				
        /* ���ʂ��Z�b�g���� */
        request.setAttribute( "mousikomiBeans", mousikomiBeans );
        request.setAttribute( "rirekiBeans", kensyurirekiBeans );
        request.setAttribute( "rirekiKamokuBeans", kensyuKamokuRirekiBeans );
//      DEL#BPX-0301J-0475
        request.setAttribute( "classBeans",ret_classBeans);

        /* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
        Log.performance( loginuser.getSimeiNo(  ), false, "" );
        Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

        return getForwardPath(  );
    }
}
