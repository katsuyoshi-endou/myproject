/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 * 
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/12/28  01.00       ��� �ӎ�    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.*;
import javax.ejb.*;
import javax.naming.*;
import javax.servlet.http.*;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.bean.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;

/**
 *<PRE>
 *
 * �N���X���F
 *   PCY321_ClassCyouseiIkkatuTorikeshiKaisiKakuninServlet �N���X
 *
 * �@�\�����F
 *   �N���X�����ꊇ�m�F���s���܂��B
 *
 *</PRE>
 */
public class PCY321_ClassCyouseiIkkatuTorikeshiKaisiKakuninServlet extends PCY010_ControllerServlet {

    protected String execute(HttpServletRequest request, HttpServletResponse response, PCY_PersonalBean loginuser)
        throws NamingException, CreateException, RemoteException, PCY_WarningException {
        /* ���\�b�h�g���[�X */
        Log.method( loginuser.getSimeiNo(), "IN", "" );

        PCY_ClassBean classBean = new PCY_ClassBean( request );

        String[] simeiNo = request.getParameterValues( "mousikomisya" );

        if ( simeiNo != null ) {
            PCY_KensyuKanriJohoBean[]
                taisyosyaBeans = new PCY_KensyuKanriJohoBean[simeiNo.length];
            for ( int i = 0; i < simeiNo.length; i++ ) {
                taisyosyaBeans[i] = new PCY_KensyuKanriJohoBean();
                String index = simeiNo[i];

                PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean();
                mousikomiBean.setKamokuCode(request.getParameter( "kamoku_code_" + index ));
                mousikomiBean.setClassCode(request.getParameter( "class_code_" + index ));
                mousikomiBean.getClassBean().setKousinbi(request.getParameter( "class_kousinbi_" + index ));
                mousikomiBean.getClassBean().setKousinjikoku(request.getParameter( "class_kousinjikoku_" + index ));
                
                mousikomiBean.setSimeiNo(request.getParameter( "simei_no_" + index ));
                mousikomiBean.setMousikomibi( request.getParameter( "mousikomibi_" + index ) );
                mousikomiBean.setKousinbi( request.getParameter( "kousinbi_" + index ) );
                mousikomiBean.setKousinjikoku( request.getParameter( "kousinjikoku_" + index ) );
                mousikomiBean.setStatus("1");
                mousikomiBean.setUketsukeJyotai("4");

                taisyosyaBeans[i].setMousikomiBean( mousikomiBean );
            }

            request.setAttribute( "taisyosyaBeans", taisyosyaBeans );
        }

        request.setAttribute( "classBean", classBean );

        /* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
        Log.performance( loginuser.getSimeiNo(), false, "" );
        Log.method( loginuser.getSimeiNo(), "OUT", "" );

        return getForwardPath();
    }

}
