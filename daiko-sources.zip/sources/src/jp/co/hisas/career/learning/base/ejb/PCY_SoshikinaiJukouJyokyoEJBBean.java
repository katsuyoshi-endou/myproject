/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 */
package jp.co.hisas.career.learning.base.ejb;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.rmi.*;

import java.sql.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;

import jp.co.hisas.career.util.common.*;

/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_SoshikinaiJukouJyokyoEJBBean�N���X
 *
 * �@�\�����F
 *   �g�D����u�󋵈ꗗ���擾���܂��B
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PCY_SoshikinaiJukouJyokyoEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PCY_SoshikinaiJukouJyokyoEJBBean implements SessionBean {
    private SessionContext context = null;
    
    /** �S�Ј��K�{�i�N�P��j*/
	private final String ZENSYA_HISSU_1 = "1";
	
	/** �S�Ј��K�{�i�N�P��ȏ�j*/
	private final String ZENSYA_HISSU_1IJO = "2";
	
	/** �o���h�ʕK�{�u�� */
	private final String BAND_HISSU = "3";
	
	/** �ΏێҎw��u�� */
	private final String TAISHOSYA_HISSU = "4";

// DEL 2010/03/18 COMTURE BAK1-002 START
//	public ArrayList getJukousyaList (
//	    	PCY_PersonalBean loginuser) throws NamingException, RemoteException, CreateException {
// DEL 2010/03/18 COMTURE BAK1-002 END
// DEL 2010/03/18 COMTURE BAK1-002 START
	/**
	 * ��u�҃��X�g���擾����
     *
     * @param kenpoMainteFlg
     * @param kengenCode
     * @param sosikiCode
     * @param loginNo
     *
     * @return ��u�҃��X�g
     *
     * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
     * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
     * @exception CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     *
     * @ejb.interface-method
     * @ejb.transaction type="Required"
	 */
	public ArrayList getJukousyaList (
	    	boolean kenpoMainteFlg , String kengenCode, String sosikiCode, String loginNo) throws NamingException, RemoteException, CreateException {
// DEL 2010/03/18 COMTURE BAK1-002 END

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
// DEL 2010/03/18 COMTURE BAK1-002 START
//		String loginNo = loginuser.getSimeiNo();
// DEL 2010/03/18 COMTURE BAK1-002 END

		try {
			// ���\�b�h�g���[�X�o�� 
			Log.method(loginNo, "IN", "");

			StringBuffer sql = new StringBuffer();
			ArrayList paramList = new ArrayList();
			
// DEL 2010/03/18 COMTURE BAK1-002 START
//			// ���C�Ǘ��҃t���O
//			boolean kenpoMainteFlg = "1".equals(loginuser.getKenpoMainteFlg());
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-003 START
			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
			con = locator.getDataSource().getConnection();
			
			// ���O�C���҂̑g�D�K�w���擾����
			String sosikiKaiso = getSosikiCodeKaiso(con, null, sosikiCode, loginNo);
// ADD 2010/03/18 COMTURE BAK1-003 END
			
			sql.append("SELECT ");
			sql.append("SIMEI_NO, ");
			sql.append("KANJI_SIMEI, ");
			sql.append("SYOZOKU_CODE_1, ");
			sql.append("SYOZOKU_CODE_2, ");
			sql.append("SYOZOKU_CODE_3, ");
			sql.append("SYOZOKU_CODE_4, ");
			sql.append("SYOZOKU_CODE_5, ");
			sql.append("SYOZOKU_CODE_6, ");
			sql.append("SYOZOKU_CODE_7, ");
			sql.append("SYOZOKU_CODE_8, ");
			sql.append("SYOZOKU_CODE_9 ");
			sql.append("FROM T01_PERSONAL_TBL ");
			sql.append("WHERE HONMU_FLG = ? ");
			sql.append("AND GENSYOKU_TAISYOKU_FLG = ? ");
			sql.append("AND KENGEN_CODE > ? ");
// DEL 2010/03/18 COMTURE BAK1-002,BAK1-003 START
//			if (!kenpoMainteFlg && !"0".equals(loginuser.getKengenCode())) {
//				sql.append("AND SYOZOKU_CODE_" + loginuser.getKengenCode() + " = ? ");
//			}
// DEL 2010/03/18 COMTURE BAK1-002,BAK1-003 END
// ADD 2010/03/18 COMTURE BAK1-002,BAK1-003 START
			if (!kenpoMainteFlg && !"0".equals(kengenCode)) {
				sql.append("AND SYOZOKU_CODE_" + sosikiKaiso + " = ? ");
			}
// ADD 2010/03/18 COMTURE BAK1-002,BAK1-003 END
			sql.append("ORDER BY SOSIKI_CODE, SIMEI_NO");

			paramList.add("1");
			paramList.add("1");
// DEL 2010/03/18 COMTURE BAK1-002 START
//			if (!kenpoMainteFlg && !"0".equals(loginuser.getKengenCode())) {
//				paramList.add(loginuser.getKengenCode());
//				paramList.add(loginuser.getSosikiCode());
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
			if (!kenpoMainteFlg && !"0".equals(kengenCode)) {
				paramList.add(kengenCode);
				paramList.add(sosikiCode);
// ADD 2010/03/18 COMTURE BAK1-002 END
			} else {
				paramList.add("0");
			}
			
// DEL 2010/03/18 COMTURE BAK1-003 START
//			// �R�l�N�V�����擾
//			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
//			con = locator.getDataSource().getConnection();
// DEL 2010/03/18 COMTURE BAK1-003 END

			// �������s
			Log.debug(sql.toString());
			ps = con.prepareStatement(sql.toString());
			
			// �p�����[�^�Z�b�g
			for (int i = 0 ; i < paramList.size() ; i++)  {
				ps.setString(i+1, (String)paramList.get(i));
			}

			rs = ps.executeQuery();
			
			ArrayList jukousyaList = new ArrayList();

			while (rs.next()) {
				String[] jukousyaInfo = new String[11];
				
				jukousyaInfo[0] = PZZ010_CharacterUtil.normalizedStr(rs.getString(1));	// ����NO
				jukousyaInfo[1] = PZZ010_CharacterUtil.normalizedStr(rs.getString(2));	// ��������
				jukousyaInfo[2] = PZZ010_CharacterUtil.normalizedStr(rs.getString(3));	// �ȉ������P�`�X
				jukousyaInfo[3] = PZZ010_CharacterUtil.normalizedStr(rs.getString(4));
				jukousyaInfo[4] = PZZ010_CharacterUtil.normalizedStr(rs.getString(5));
				jukousyaInfo[5] = PZZ010_CharacterUtil.normalizedStr(rs.getString(6));
				jukousyaInfo[6] = PZZ010_CharacterUtil.normalizedStr(rs.getString(7));
				jukousyaInfo[7] = PZZ010_CharacterUtil.normalizedStr(rs.getString(8));
				jukousyaInfo[8] = PZZ010_CharacterUtil.normalizedStr(rs.getString(9));
				jukousyaInfo[9] = PZZ010_CharacterUtil.normalizedStr(rs.getString(10));
				jukousyaInfo[10] = PZZ010_CharacterUtil.normalizedStr(rs.getString(11));
				
				jukousyaInfo[1] = (jukousyaInfo[1].length() > 0) ? jukousyaInfo[1].substring(1): jukousyaInfo[1];
				
				jukousyaList.add(jukousyaInfo);
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginNo, "OUT", "");

			return jukousyaList;

// DEL 2010/03/18 COMTURE BAK1-002 START
//		} catch (NamingException e) {
//			Log.error(loginuser.getSimeiNo(), "HJE-0002", e);
//			throw new EJBException(e);
//		} catch (SQLException e) {
//			Log.error(loginuser.getSimeiNo(), "HJE-0001", e);
//			throw new EJBException(e);
//		} catch (RuntimeException e) {
//			Log.error(loginuser.getSimeiNo(), "", e);
//			throw e;
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
		} catch (NamingException e) {
			Log.error(loginNo, "HJE-0002", e);
			throw new EJBException(e);
		} catch (SQLException e) {
			Log.error(loginNo, "HJE-0001", e);
			throw new EJBException(e);
		} catch (RuntimeException e) {
			Log.error(loginNo, "", e);
			throw e;
// ADD 2010/03/18 COMTURE BAK1-002 END
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, con, ps, rs);
		}
	}

	/**
	 * �K�{�u�����X�g���擾����
     *
     * @param loginuser ���O�C�����[�U���
     *
     * @return �K�{�u�����X�g
     *
     * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
     * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
     * @exception CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     *
     * @ejb.interface-method
     * @ejb.transaction type="Required"
	 */
	public ArrayList getHissuKouzaList (
	    	PCY_PersonalBean loginuser) throws NamingException, RemoteException, CreateException {

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String loginNo = loginuser.getSimeiNo();

		try {
			// ���\�b�h�g���[�X�o�� 
			Log.method(loginNo, "IN", "");

			StringBuffer sql = new StringBuffer();
			ArrayList paramList = new ArrayList();
			
			// ���C�Ǘ��҃t���O
			boolean kenpoMainteFlg = "1".equals(loginuser.getKenpoMainteFlg());
			
			sql.append("SELECT ");
			sql.append("L04.CATEGORY_CODE2, ");
			sql.append("L04.CATEGORY_MEI2, ");
			sql.append("L71.KUBUN ");
			sql.append("FROM ");
			sql.append("L04_CATEGORY2_TBL L04, ");
			sql.append("L71_HISSU_SUISYO_KOUZA_TBL L71 ");
			sql.append("WHERE ");
			sql.append("L04.CATEGORY_CODE2 = L71.CATEGORY_CODE ");
			sql.append("AND L71.KUBUN BETWEEN ? AND ? ");
			sql.append("ORDER BY ");
			sql.append("L71.KUBUN, ");
			sql.append("L04.CATEGORY_CODE2 ");
			
			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
			con = locator.getDataSource().getConnection();

			// �������s
			Log.debug(sql.toString());
			ps = con.prepareStatement(sql.toString());
			
			// �p�����[�^�Z�b�g
			ps.setString(1, "1");
			ps.setString(2, "4");

			rs = ps.executeQuery();
			
			ArrayList hissuKouzaList = new ArrayList();

			while (rs.next()) {
				String[] hissuKouza = new String[11];
				
				hissuKouza[0] = PZZ010_CharacterUtil.normalizedStr(rs.getString(1));	// ���C�J�e�S���Q�R�[�h
				hissuKouza[1] = PZZ010_CharacterUtil.normalizedStr(rs.getString(2));	// ���C�J�e�S���Q����
				hissuKouza[2] = PZZ010_CharacterUtil.normalizedStr(rs.getString(3));	// �敪
				
				hissuKouzaList.add(hissuKouza);
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginNo, "OUT", "");

			return hissuKouzaList;

		} catch (NamingException e) {
			Log.error(loginuser.getSimeiNo(), "HJE-0002", e);
			throw new EJBException(e);
		} catch (SQLException e) {
			Log.error(loginuser.getSimeiNo(), "HJE-0001", e);
			throw new EJBException(e);
		} catch (RuntimeException e) {
			Log.error(loginuser.getSimeiNo(), "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, con, ps, rs);
		}
	}

	/**
     * �g�D����u�󋵂֕\������l��u�󋵈ꗗ�𒊏o����B
     *
     * @param simeiNo   ����NO�i���������j
     * @param loginuser ���O�C�����[�U���
     *
     * @return �K�{�u�����X�g
     *
     * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
     * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
     * @exception CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     *
     * @ejb.interface-method
     * @ejb.transaction type="Required"
	 */
	public ArrayList getKojinJukouJyokyoList (String simeiNo,
	    	PCY_PersonalBean loginuser) throws NamingException, RemoteException, CreateException {

		Connection con = null;
		
		String loginNo = loginuser.getSimeiNo();

		try {
			// ���\�b�h�g���[�X�o�� 
			Log.method(loginNo, "IN", "");

			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
			con = locator.getDataSource().getConnection();
			
			// �Ј������擾
			String[] personalInfo = getPersonalInfoBySimeiNo(con, loginNo, simeiNo);
			
			ArrayList kojinJukouJyokyoList = new ArrayList();
			
			// �\���E��u�󋵂��擾
			kojinJukouJyokyoList.addAll(getMousikomiJyokyo(con, loginNo, personalInfo, simeiNo, null, null));
			kojinJukouJyokyoList.addAll(getJukoJyokyo(con, loginNo, personalInfo, simeiNo, null, null));
			
			// �ߋ��̎�u�����擾
			kojinJukouJyokyoList.addAll(getKyoikuKenshureki(con, loginNo, personalInfo, simeiNo));
			
			// ���\�b�h�g���[�X�o��
			Log.method(loginNo, "OUT", "");

			return kojinJukouJyokyoList;

		} catch (NamingException e) {
			Log.error(loginuser.getSimeiNo(), "HJE-0002", e);
			throw new EJBException(e);
		} catch (SQLException e) {
			Log.error(loginuser.getSimeiNo(), "HJE-0001", e);
			throw new EJBException(e);
		} catch (RuntimeException e) {
			Log.error(loginuser.getSimeiNo(), "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, con, null, null);
		}
	}
	
	/**
	 * �Ј������擾
	 * @param conn     �R�l�N�V����
	 * @param loginNo  ���O�C���Ј��̎���NO
	 * @param simeiNo  ���������F����NO
	 * @return
	 */
	private String[] getPersonalInfoBySimeiNo (
			Connection con, 
			String loginNo, 
			String simeiNo
			) throws SQLException {

		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {

			StringBuffer sql = new StringBuffer();
			ArrayList paramList = new ArrayList();
			
			sql.append("SELECT ");
			sql.append("T01.SIMEI_NO, ");
			sql.append("T01.KANJI_SIMEI, ");
			sql.append("T01.SOSIKI_CODE, ");
			sql.append("T19.BUSYO_RYAKUSYO_MEI ");
			sql.append("FROM ");
			sql.append("T01_PERSONAL_TBL T01, ");
			sql.append("T19_SOSIKI_TBL T19 ");
			sql.append("WHERE ");
			sql.append("T01.SOSIKI_CODE = T19.SOSIKI_CODE ");
			sql.append("AND T01.HONMU_FLG = ? ");
			paramList.add("1");
			if (simeiNo != null) {
				sql.append("AND T01.SIMEI_NO = ? ");
				paramList.add(simeiNo);
			}
			
			// �������s
			Log.debug(sql.toString());
			ps = con.prepareStatement(sql.toString());
			
			// �p�����[�^�Z�b�g
			for (int i = 0 ; i < paramList.size() ; i++)  {
				ps.setString(i+1, (String)paramList.get(i));
			}
	
			rs = ps.executeQuery();

			String[] personalInfo = new String[4];
			if (rs.next()) {

				personalInfo[0] = PZZ010_CharacterUtil.normalizedStr(rs.getString(1));	// ����NO
				personalInfo[1] = PZZ010_CharacterUtil.normalizedStr(rs.getString(2));	// ��������
				personalInfo[2] = PZZ010_CharacterUtil.normalizedStr(rs.getString(3));	// �g�D�R�[�h
				personalInfo[3] = PZZ010_CharacterUtil.normalizedStr(rs.getString(4));	// �������̖�
				
				personalInfo[1] = (personalInfo[1].length() > 0) ? personalInfo[1].substring(1): personalInfo[1];
			}
			
			return personalInfo;
			
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);
		}
	}
	
	/**
	 * �\���E��u�󋵂��擾
	 * @param conn     �R�l�N�V����
	 * @param loginNo  ���O�C���Ј��̎���NO
	 * @param simeiNo  ���������F����NO
	 * @param kaisibi  ���������F�J�ÊJ�n��
	 * @param syuryobi ���������F�J�ÏI����
	 * @return
	 */
	private ArrayList getMousikomiJyokyo (
			Connection con, 
			String loginNo, 
			String[] personalInfo,
			String simeiNo, 
			String kaisibi, 
			String syuryobi
			) throws SQLException {

		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {

			StringBuffer sql = new StringBuffer();
			ArrayList paramList = new ArrayList();
			
			sql.append("SELECT ");
			sql.append("L15.KAMOKU_CODE, ");
			sql.append("L01.KAMOKU_MEI1, ");
			sql.append("L02.CLASS_CODE, ");
			sql.append("L02.CLASS_MEI, ");
			sql.append("L02.KAISIBI, ");
			sql.append("L02.SYURYOBI, ");
// DEL 2010/02/24 COMTURE PB-008 START
//			sql.append("L02.CHIKU_MEI ");
// DEL 2010/02/24 COMTURE PB-008 END
// ADD 2010/02/24 COMTURE PB-008 START
			sql.append("L02.CHIKU_MEI, ");
			sql.append("L09.CHIKU_MEI, ");
// ADD 2010/02/24 COMTURE PB-008 END
// ADD 2010/02/24 COMTURE PB-007 START
			sql.append("L71.KUBUN ");
// ADD 2010/02/24 COMTURE PB-007 END
			sql.append("FROM ");
			sql.append("L15_MOUSIKOMI_JYOKYO_TBL L15, ");
			sql.append("L01_KAMOKU_TBL L01, ");
// DEL 2010/02/24 COMTURE PB-008 START
//			sql.append("L02_CLASS_TBL L02 ");
// DEL 2010/02/24 COMTURE PB-008 END
// ADD 2010/02/24 COMTURE PB-008 START
			sql.append("L02_CLASS_TBL L02, ");
			sql.append("L09_CHIKU_TBL L09, ");
// ADD 2010/02/24 COMTURE PB-008 END
// ADD 2010/02/24 COMTURE PB-007 START
			sql.append("L71_HISSU_SUISYO_KOUZA_TBL L71 ");
// ADD 2010/02/24 COMTURE PB-007 END
			sql.append("WHERE ");
			sql.append("L15.KAMOKU_CODE = L01.KAMOKU_CODE ");
			sql.append("AND L15.KAMOKU_CODE = L02.KAMOKU_CODE ");
			sql.append("AND L15.CLASS_CODE = L02.CLASS_CODE ");
// ADD 2010/02/24 COMTURE PB-008 START
			sql.append("AND L02.CHIKU_CODE = L09.CHIKU_CODE(+) ");
// ADD 2010/02/24 COMTURE PB-008 END
// ADD 2010/02/24 COMTURE PB-007 START
			sql.append("AND L01.CATEGORY_CODE2 = L71.CATEGORY_CODE(+) ");
// ADD 2010/02/24 COMTURE PB-007 END
			if (simeiNo != null) {
				sql.append("AND L15.SIMEI_NO = ? ");
				paramList.add(simeiNo);
			}
			if (kaisibi != null) {
				sql.append("AND L02.KAISIBI >= ? ");
				paramList.add(kaisibi);
			}
			if (syuryobi != null) {
				sql.append("AND L02.SYURYOBI <= ? ");
				paramList.add(syuryobi);
			}
			sql.append("ORDER BY L01.KAMOKU_CODE, L02.CLASS_CODE ");
			
			// �������s
			Log.debug(sql.toString());
			ps = con.prepareStatement(sql.toString());
			
			// �p�����[�^�Z�b�g
			for (int i = 0 ; i < paramList.size() ; i++)  {
				ps.setString(i+1, (String)paramList.get(i));
			}
	
			rs = ps.executeQuery();
			
			ArrayList mousikomiJyokyoList = new ArrayList();
	
			while (rs.next()) {
// DEL 2010/02/24 COMTURE PB-007 START
//				String[] mousikomiJyokyo = new String[14];
// DEL 2010/02/24 COMTURE PB-007 END
// ADD 2010/02/24 COMTURE PB-007 START
				String[] mousikomiJyokyo = new String[15];
// ADD 2010/02/24 COMTURE PB-007 END

				mousikomiJyokyo[0] = personalInfo[0];
				mousikomiJyokyo[1] = personalInfo[1];
				mousikomiJyokyo[2] = personalInfo[2];
				mousikomiJyokyo[3] = personalInfo[3];
				mousikomiJyokyo[4] = PZZ010_CharacterUtil.normalizedStr(rs.getString(1));	// �ȖڃR�[�h
				mousikomiJyokyo[5] = PZZ010_CharacterUtil.normalizedStr(rs.getString(2));	// �Ȗږ��P
				mousikomiJyokyo[6] = PZZ010_CharacterUtil.normalizedStr(rs.getString(3));	// �N���X�R�[�h
				mousikomiJyokyo[7] = PZZ010_CharacterUtil.normalizedStr(rs.getString(4));	// �N���X��
				mousikomiJyokyo[8] = PZZ010_CharacterUtil.normalizedStr(rs.getString(5));	// �J�n��
				mousikomiJyokyo[9] = PZZ010_CharacterUtil.normalizedStr(rs.getString(6));	// �I����
// DEL 2010/02/24 COMTURE PB-008 START
//				mousikomiJyokyo[10] = PZZ010_CharacterUtil.normalizedStr(rs.getString(7));	// �n�於
// DEL 2010/02/24 COMTURE PB-008 END
// ADD 2010/02/24 COMTURE PB-008 START
				String chikuMei = PZZ010_CharacterUtil.normalizedStr(rs.getString(7));      // �n�於
				if (!"".equals(chikuMei)){
					mousikomiJyokyo[10] = chikuMei;
				} else {
					mousikomiJyokyo[10] = PZZ010_CharacterUtil.normalizedStr(rs.getString(8));
				}
// ADD 2010/02/24 COMTURE PB-008 END
				mousikomiJyokyo[11] = "�\����";
				mousikomiJyokyo[12] = mousikomiJyokyo[4];	// �Ȗڑ��݃`�F�b�N
				mousikomiJyokyo[13] = mousikomiJyokyo[6];	// �N���X���݃`�F�b�N
// ADD 2010/02/24 COMTURE PB-007 START
				mousikomiJyokyo[14] = PZZ010_CharacterUtil.normalizedStr(rs.getString(9));   // �K�{�E�����u���敪
// ADD 2010/02/24 COMTURE PB-007 END
				
				mousikomiJyokyoList.add(mousikomiJyokyo);
			}
			
			return mousikomiJyokyoList;
			
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);
		}
	}
	
	/**
	 * ��u�󋵂̎擾
	 * @param conn     �R�l�N�V����
	 * @param loginNo  ���O�C���Ј��̎���NO
	 * @param simeiNo  ���������F����NO
	 * @param kaisibi  ���������F�J�ÊJ�n��
	 * @param syuryobi ���������F�J�ÏI����
	 * @return
	 */
	private ArrayList getJukoJyokyo (
			Connection con, 
			String loginNo, 
			String[] personalInfo,
			String simeiNo, 
			String kaisibi, 
			String syuryobi
			) throws SQLException {

		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {

			StringBuffer sql = new StringBuffer();
			ArrayList paramList = new ArrayList();
			
			sql.append("SELECT ");
			sql.append("L51.KAMOKU_CODE, ");
			sql.append("L51.KAMOKU_MEI1, ");
			sql.append("L51.CLASS_CODE, ");
			sql.append("L51.CLASS_MEI, ");
			sql.append("L51.KAISIBI, ");
			sql.append("L51.SYURYOBI, ");
			sql.append("L51.CHIKU_MEI, ");
// DEL 2010/02/24 COMTURE PB-007 START
//			sql.append("L51.SYURYO_HANTEI ");
// DEL 2010/02/24 COMTURE PB-007 END
// ADD 2010/02/24 COMTURE PB-007 START
			sql.append("L51.SYURYO_HANTEI, ");
			sql.append("L71.KUBUN ");
// ADD 2010/02/24 COMTURE PB-007 END
			sql.append("FROM ");
			sql.append("L51_KYOIKU_TBL L51, ");
			sql.append("L01_KAMOKU_TBL L01, ");
// DEL 2010/02/24 COMTURE PB-007 START
//			sql.append("L02_CLASS_TBL L02 ");
// DEL 2010/02/24 COMTURE PB-007 END
// ADD 2010/02/24 COMTURE PB-007 START
			sql.append("L02_CLASS_TBL L02, ");
			sql.append("L71_HISSU_SUISYO_KOUZA_TBL L71 ");
// ADD 2010/02/24 COMTURE PB-007 END
			sql.append("WHERE ");
			sql.append("L51.KAMOKU_CODE = L01.KAMOKU_CODE ");
			sql.append("AND L51.KAMOKU_CODE = L02.KAMOKU_CODE ");
			sql.append("AND L51.CLASS_CODE = L02.CLASS_CODE ");
// ADD 2010/02/24 COMTURE PB-007 START
			sql.append("AND L01.CATEGORY_CODE2 = L71.CATEGORY_CODE(+) ");
// ADD 2010/02/24 COMTURE PB-007 END
			if (simeiNo != null) {
				sql.append("AND L51.SIMEI_NO = ? ");
				paramList.add(simeiNo);
			}
			if (kaisibi != null) {
				sql.append("AND L51.KAISIBI >= ? ");
				paramList.add(kaisibi);
			}
			if (syuryobi != null) {
				sql.append("AND L51.SYURYOBI <= ? ");
				paramList.add(syuryobi);
			}
			sql.append("ORDER BY L51.KAMOKU_CODE, L51.CLASS_CODE ");
			
			// �������s
			Log.debug(sql.toString());
			ps = con.prepareStatement(sql.toString());
			
			// �p�����[�^�Z�b�g
			for (int i = 0 ; i < paramList.size() ; i++)  {
				ps.setString(i+1, (String)paramList.get(i));
			}
	
			rs = ps.executeQuery();
			
			ArrayList jukoJyokyoList = new ArrayList();
	
			while (rs.next()) {
// DEL 2010/02/24 COMTURE PB-007 START
//				String[] jukoJyokyo = new String[14];
// DEL 2010/02/24 COMTURE PB-007 END
// ADD 2010/02/24 COMTURE PB-007 START
				String[] jukoJyokyo = new String[15];
// ADD 2010/02/24 COMTURE PB-007 END

				jukoJyokyo[0] = personalInfo[0];
				jukoJyokyo[1] = personalInfo[1];
				jukoJyokyo[2] = personalInfo[2];
				jukoJyokyo[3] = personalInfo[3];
				jukoJyokyo[4] = PZZ010_CharacterUtil.normalizedStr(rs.getString(1));	// �ȖڃR�[�h
				jukoJyokyo[5] = PZZ010_CharacterUtil.normalizedStr(rs.getString(2));	// �Ȗږ��P
				jukoJyokyo[6] = PZZ010_CharacterUtil.normalizedStr(rs.getString(3));	// �N���X�R�[�h
				jukoJyokyo[7] = PZZ010_CharacterUtil.normalizedStr(rs.getString(4));	// �N���X��
				jukoJyokyo[8] = PZZ010_CharacterUtil.normalizedStr(rs.getString(5));	// �J�n��
				jukoJyokyo[9] = PZZ010_CharacterUtil.normalizedStr(rs.getString(6));	// �I����
				jukoJyokyo[10] = PZZ010_CharacterUtil.normalizedStr(rs.getString(7));	// �n�於
				
				String syuryoHantei = PZZ010_CharacterUtil.normalizedStr(rs.getString(8));	// �C������
				if ("0".equals(syuryoHantei)) {
					jukoJyokyo[11] = "���C��";
				} else if ("1".equals(syuryoHantei)) {
					jukoJyokyo[11] = "��u��";
				} else if ("2".equals(syuryoHantei)) {
					jukoJyokyo[11] = "��u��";
				} else {
					jukoJyokyo[11] = "";
				}
				
				jukoJyokyo[12] = jukoJyokyo[4];	// �Ȗڑ��݃`�F�b�N
				jukoJyokyo[13] = jukoJyokyo[6];	// �N���X���݃`�F�b�N
// ADD 2010/02/24 COMTURE PB-007 START
				jukoJyokyo[14] = PZZ010_CharacterUtil.normalizedStr(rs.getString(9));   // �K�{�E�����u���敪
// ADD 2010/02/24 COMTURE PB-007 END
				
				jukoJyokyoList.add(jukoJyokyo);
			}
			
			return jukoJyokyoList;
			
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);
		}
	}
	
	/**
	 * ��u�󋵂̎擾
	 * @param conn     �R�l�N�V����
	 * @param loginNo  ���O�C���Ј��̎���NO
	 * @param simeiNo  ���������F����NO
	 * @param kaisibi  ���������F�J�ÊJ�n��
	 * @param syuryobi ���������F�J�ÏI����
	 * @return
	 */
	private ArrayList getKyoikuKenshureki (
			Connection con, 
			String loginNo, 
			String[] personalInfo,
			String simeiNo
			) throws SQLException {

		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {

			StringBuffer sql = new StringBuffer();
			ArrayList paramList = new ArrayList();
			
			sql.append("SELECT ");
			sql.append("T05.KAMOKU_CODE, ");
			sql.append("T05.KAMOKU_MEI1, ");
			sql.append("T05.CLASS_MEI, ");
			sql.append("T05.KAISIBI, ");
			sql.append("T05.SYURYOBI, ");
			sql.append("T05.SYURYO_HANTEI, ");
// DEL 2010/02/24 COMTURE PB-007 START
//			sql.append("L01.KAMOKU_CODE ");
// DEL 2010/02/24 COMTURE PB-007 END
// ADD 2010/02/24 COMTURE PB-007 START
			sql.append("L01.KAMOKU_CODE, ");
			sql.append("L71.KUBUN ");
// ADD 2010/02/24 COMTURE PB-007 END
			sql.append("FROM ");
			sql.append("T05_KYOIKU_TBL T05, ");
// DEL 2010/02/24 COMTURE PB-007 START
//			sql.append("L01_KAMOKU_TBL L01 ");
// DEL 2010/02/24 COMTURE PB-007 END
// ADD 2010/02/24 COMTURE PB-007 START
			sql.append("L01_KAMOKU_TBL L01, ");
			sql.append("L71_HISSU_SUISYO_KOUZA_TBL L71 ");
			sql.append("");
// ADD 2010/02/24 COMTURE PB-007 END
			sql.append("WHERE ");
			sql.append("T05.KAMOKU_CODE = L01.KAMOKU_CODE(+) ");
// ADD 2010/02/24 COMTURE PB-007 START
			sql.append("AND L01.CATEGORY_CODE2 = L71.CATEGORY_CODE(+) ");
// ADD 2010/02/24 COMTURE PB-007 END
			if (simeiNo != null) {
				sql.append("AND T05.SIMEI_NO = ? ");
				paramList.add(simeiNo);
			}
			sql.append("ORDER BY T05.KAMOKU_CODE ");
			
			// �������s
			Log.debug(sql.toString());
			ps = con.prepareStatement(sql.toString());
			
			// �p�����[�^�Z�b�g
			for (int i = 0 ; i < paramList.size() ; i++)  {
				ps.setString(i+1, (String)paramList.get(i));
			}
	
			rs = ps.executeQuery();
			
			ArrayList kyoikuKenshurekiList = new ArrayList();
	
			while (rs.next()) {
// DEL 2010/02/24 COMTURE PB-007 START
//				String[] kyoikuKenshureki = new String[14];
// DEL 2010/02/24 COMTURE PB-007 END
// ADD 2010/02/24 COMTURE PB-007 START
				String[] kyoikuKenshureki = new String[15];
// ADD 2010/02/24 COMTURE PB-007 END
				
				kyoikuKenshureki[0] = personalInfo[0];
				kyoikuKenshureki[1] = personalInfo[1];
				kyoikuKenshureki[2] = personalInfo[2];
				kyoikuKenshureki[3] = personalInfo[3];
				kyoikuKenshureki[4] = PZZ010_CharacterUtil.normalizedStr(rs.getString(1));	// �ȖڃR�[�h
				kyoikuKenshureki[5] = PZZ010_CharacterUtil.normalizedStr(rs.getString(2));	// �Ȗږ��P
				kyoikuKenshureki[6] = "";	// �N���X�R�[�h
				kyoikuKenshureki[7] = PZZ010_CharacterUtil.normalizedStr(rs.getString(3));	// �N���X��
				kyoikuKenshureki[8] = PZZ010_CharacterUtil.normalizedStr(rs.getString(4));	// �J�n��
				kyoikuKenshureki[9] = PZZ010_CharacterUtil.normalizedStr(rs.getString(5));	// �I����
				kyoikuKenshureki[10] = "";	// �n�於
				
				String syuryoHantei = PZZ010_CharacterUtil.normalizedStr(rs.getString(6));	// �C������
				if ("0".equals(syuryoHantei)) {
					kyoikuKenshureki[11] = "���C��";
				} else if ("1".equals(syuryoHantei)) {
					kyoikuKenshureki[11] = "��u��";
				} else if ("2".equals(syuryoHantei)) {
					kyoikuKenshureki[11] = "��u��";
				} else {
					kyoikuKenshureki[11] = "";
				}
				
				kyoikuKenshureki[12] = rs.getString(7);		// �Ȗڑ��݃`�F�b�N
				kyoikuKenshureki[13] = null;	// �N���X���݃`�F�b�N
// ADD 2010/02/24 COMTURE PB-007 START
				kyoikuKenshureki[14] = PZZ010_CharacterUtil.normalizedStr(rs.getString(7)); // �K�{�E�����敪�u��
// ADD 2010/02/24 COMTURE PB-007 END
				
				kyoikuKenshurekiList.add(kyoikuKenshureki);
			}
			
			return kyoikuKenshurekiList;
			
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);
		}
	}
	
// DEL 2010/02/24 COMTURE PB-015 START
//    /**
//     * �g�D����u�󋵂֕\������g�D����u�󋵈ꗗ�𒊏o����B
//     *
//     * @param shozokuCode �����R�[�h�i���������j
//     * @param startDate   �J�n���i���������j
//     * @param endDate     �I�����i���������j
//     * @param loginuser ���O�C�����[�U���
//     * @return �g�D����u�󋵈ꗗ
//     *
//     * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
//     * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
//     * @exception CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
//     *
//     * @ejb.interface-method
//     * @ejb.transaction type="Required"
//     */
//	public ArrayList getSoshikiJukouJyokyoList(String shozokuCode, String startDate, String endDate, 
//		PCY_PersonalBean loginuser) throws NamingException, RemoteException, CreateException{
//		
//		Connection con = null;
//		
//		String loginNo = loginuser.getSimeiNo();
//		
//		try {
//			// ���\�b�h�g���[�X�o��
//			Log.method(loginNo, "IN", "" );
//            
//			// �R�l�N�V�����擾
//			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
//			con = locator.getDataSource().getConnection();
//            
//			// �I���������̎Ј������擾 
//			PCY_PersonalBean[] personalBeans = getPersonInfo(con, shozokuCode, loginuser);
//			
//			ArrayList soshikiJukouJyokyoList = new ArrayList();
//			
//			for (int i = 0 ; i < personalBeans.length ; i++) {
//				
//				PCY_PersonalBean personalBean = personalBeans[i];
//				
//				// �ΏێЈ��̏���ݒ�
//				String[] personalInfo = new String[4];
//				personalInfo[0] = personalBean.getSimeiNo();
//				personalInfo[1] = personalBean.getKanjiSimei();
//				personalInfo[2] = personalBean.getSosikiCode();
//				personalInfo[3] = personalBean.getBusyoRyakusyoMei();
//				String simeiNo = personalBean.getSimeiNo();
//
//				// �\���󋵂��擾
//				soshikiJukouJyokyoList.addAll(getMousikomiJyokyo(con, loginNo, personalInfo,
//																simeiNo, startDate, endDate));
//				// ��u�󋵂��擾
//				soshikiJukouJyokyoList.addAll(getJukoJyokyo(con, loginNo, personalInfo, 
//																simeiNo, startDate, endDate));
//			}
//            
//			//���\�b�h�g���[�X�o��
//			Log.method(loginNo, "OUT", "");
//            
//			return soshikiJukouJyokyoList;
//			
//        } catch (NamingException e) {
//            Log.error(loginuser.getSimeiNo(), "HJE-0002", e);
//            throw new EJBException(e);
//        } catch (SQLException e) {
//        	Log.error(loginuser.getSimeiNo(), "HJE-0001", e);
//            throw new EJBException(e);
//        } catch (RuntimeException e) {
//            Log.error(loginuser.getSimeiNo(), "", e );
//            throw e;
//		} finally {
//			PZZ040_SQLUtility.closeConnection(loginNo, con, null, null);
//		}
//	}
// DEL 2010/02/24 COMTURE PB-015 END
// ADD 2010/02/24 COMTURE PB-015 START
// DEL 2010/03/18 COMTURE BAK1-002 START
//	public ArrayList getSoshikiJukouJyokyoList(String shozokuCode, String startDate, String endDate, 
//		PCY_PersonalBean loginuser) throws NamingException, RemoteException, CreateException {
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
    /**
     * �g�D����u�󋵂֕\������g�D����u�󋵈ꗗ�𒊏o����B
     *
     * @param shozokuCode �����R�[�h�i���������j
     * @param startDate   �J�n���i���������j
     * @param endDate     �I�����i���������j
     * @param kenpoMainteFlg
     * @param kengenCode
     * @param sosikiCode
     * @param loginNo
     * 
     * @return �g�D����u�󋵈ꗗ
     *
     * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
     * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
     * @exception CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     *
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
	public ArrayList getSoshikiJukouJyokyoList(String shozokuCode, String startDate, String endDate, 
			boolean kenpoMainteFlg, String kengenCode, String sosikiCode, String loginNo
			) throws NamingException, RemoteException, CreateException {
// ADD 2010/03/18 COMTURE BAK1-002 END
        
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
// DEL 2010/03/18 COMTURE BAK1-002 START
//		String loginNo = loginuser.getSimeiNo();
// DEL 2010/03/18 COMTURE BAK1-002 END
		
		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginNo, "IN", "" );
            
			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
			con = locator.getDataSource().getConnection();
            
			StringBuffer sql = new StringBuffer();
			ArrayList paramList = new ArrayList();
			
			// �g�D�R�[�h�̊K�w���擾
// DEL 2010/03/18 COMTURE BAK1-002 START
//			String kaiso = getSosikiCodeKaiso(con, shozokuCode, loginuser);
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
			String kaiso = getSosikiCodeKaiso(con, shozokuCode, sosikiCode, loginNo);
// ADD 2010/03/18 COMTURE BAK1-002 END
			
	        sql.append("SELECT");
	        sql.append(" SIMEI_NO");
	        sql.append(", KANJI_SIMEI");
	        sql.append(", SOSIKI_CODE");
	        sql.append(", BUSYO_RYAKUSYO_MEI");
	        sql.append(", KAMOKU_CODE");
	        sql.append(", KAMOKU_MEI1");
	        sql.append(", CLASS_CODE");
	        sql.append(", CLASS_MEI");
	        sql.append(", KAISIBI");
	        sql.append(", SYURYOBI");
	        sql.append(", CHIKU_MEI");
	        sql.append(", CHIKU_MEI2");
	        sql.append(", SYURYO_HANTEI");
	        sql.append(", KAMOKU_EXISTS ");
	        sql.append(", CLASS_EXISTS ");
	        sql.append(", KUBUN");
	        sql.append(" FROM ( (");
	        sql.append(" SELECT");
	        sql.append(" T01.SIMEI_NO");
	        sql.append(", T01.KANJI_SIMEI");
	        sql.append(", T01.SOSIKI_CODE");
	        sql.append(", T19.BUSYO_RYAKUSYO_MEI");
	        sql.append(", L51.KAMOKU_CODE");
	        sql.append(", L51.KAMOKU_MEI1");
	        sql.append(", L51.CLASS_CODE");
	        sql.append(", L51.CLASS_MEI");
	        sql.append(", L51.KAISIBI");
	        sql.append(", L51.SYURYOBI");
	        sql.append(", L51.CHIKU_MEI");
	        sql.append(", L51.CHIKU_MEI AS CHIKU_MEI2");
	        sql.append(", L51.SYURYO_HANTEI");
	        sql.append(", L01.KAMOKU_CODE AS KAMOKU_EXISTS");
	        sql.append(", L51.CLASS_CODE AS CLASS_EXISTS");
	        sql.append(", L71.KUBUN");
	        sql.append(" FROM");
	        sql.append(" T01_PERSONAL_TBL T01");
	        sql.append(", T19_SOSIKI_TBL T19");
	        sql.append(", L51_KYOIKU_TBL L51");
	        sql.append(", L01_KAMOKU_TBL L01");
	        sql.append(", L02_CLASS_TBL L02");
	        sql.append(", L71_HISSU_SUISYO_KOUZA_TBL L71");
	        sql.append(" WHERE");
	        sql.append(" T01.KENGEN_CODE > ?");
// DEL 2010/03/18 COMTURE BAK1-002 START
//			if ("1".equals(loginuser.getKenpoMainteFlg())) {
//				paramList.add("0");
//			} else {
//				paramList.add(loginuser.getKengenCode());
//			}
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
			if (kenpoMainteFlg) {
				paramList.add("0");
			} else {
				paramList.add(kengenCode);
			}
// ADD 2010/03/18 COMTURE BAK1-002 END
	        sql.append(" AND T01.HONMU_FLG = ?");
	        sql.append(" AND T01.GENSYOKU_TAISYOKU_FLG = ?");
	        paramList.add("1");
	        paramList.add("1");
	        
			// ���������F�����ɑI������
			if ((shozokuCode != null 
					&& !shozokuCode.equals(""))) {
				sql.append(" AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
				paramList.add(shozokuCode);
				
			} else {
				// ���O�C���Ј����u���C�Ǘ��ҁv�ȊO�̏ꍇ
// DEL 2010/03/18 COMTURE BAK1-002 START
//				if(!"1".equals(loginuser.getKenpoMainteFlg())) {
//					sql.append(" AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
//					paramList.add(loginuser.getSosikiCode());
//				}
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
				if(!kenpoMainteFlg) {
					sql.append(" AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
					paramList.add(kengenCode);
				}
// ADD 2010/03/18 COMTURE BAK1-002 END
			}
	        sql.append(" AND T01.SOSIKI_CODE = T19.SOSIKI_CODE");
	        sql.append(" AND T01.SIMEI_NO = L51.SIMEI_NO");
	        sql.append(" AND L51.KAMOKU_CODE = L01.KAMOKU_CODE");
	        sql.append(" AND L51.KAMOKU_CODE = L02.KAMOKU_CODE");
	        sql.append(" AND L51.CLASS_CODE = L02.CLASS_CODE ");
	        if (startDate != null || "".equals(startDate)) {
	        	sql.append(" AND L51.KAISIBI >= ?");
	        	paramList.add(startDate);
	        }
	        if (endDate != null || "".equals(endDate)) {
	        	sql.append(" AND L51.SYURYOBI <= ?");
	        	paramList.add(endDate);
	        }
	        sql.append(" AND L01.CATEGORY_CODE2 = L71.CATEGORY_CODE(+) )");
	        sql.append(" UNION ALL ( ");
	        sql.append(" SELECT ");
	        sql.append(" T01.SIMEI_NO");
	        sql.append(", T01.KANJI_SIMEI");
	        sql.append(", T01.SOSIKI_CODE");
	        sql.append(", T19.BUSYO_RYAKUSYO_MEI");
	        sql.append(", L15.KAMOKU_CODE");
	        sql.append(", L01.KAMOKU_MEI1");
	        sql.append(", L02.CLASS_CODE");
	        sql.append(", L02.CLASS_MEI");
	        sql.append(", L02.KAISIBI");
	        sql.append(", L02.SYURYOBI");
	        sql.append(", L02.CHIKU_MEI");
	        sql.append(", L09.CHIKU_MEI AS CHIKU_MEI2");
	        sql.append(", '�\����'");
	        sql.append(", L01.KAMOKU_CODE AS KAMOKU_EXISTS");
	        sql.append(", L02.CLASS_CODE AS CLASS_EXISTS");
	        sql.append(", L71.KUBUN");
	        sql.append(" FROM");
	        sql.append(" T01_PERSONAL_TBL T01");
	        sql.append(", T19_SOSIKI_TBL T19");
	        sql.append(", L15_MOUSIKOMI_JYOKYO_TBL L15");
	        sql.append(", L01_KAMOKU_TBL L01");
	        sql.append(", L02_CLASS_TBL L02");
	        sql.append(", L09_CHIKU_TBL L09");
	        sql.append(", L71_HISSU_SUISYO_KOUZA_TBL L71");
	        sql.append(" WHERE");
	        sql.append(" T01.KENGEN_CODE > ?");
// DEL 2010/03/18 COMTURE BAK1-002 START
//			if ("1".equals(loginuser.getKenpoMainteFlg())) {
//				paramList.add("0");
//			} else {
//				paramList.add(loginuser.getKengenCode());
//			}
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
			if (kenpoMainteFlg) {
				paramList.add("0");
			} else {
				paramList.add(kengenCode);
			}
// ADD 2010/03/18 COMTURE BAK1-002 END
	        sql.append(" AND T01.HONMU_FLG = ?");
	        sql.append(" AND T01.GENSYOKU_TAISYOKU_FLG = ?");
	        paramList.add("1");
	        paramList.add("1");
	        
			// ���������F�����ɑI������
			if ((shozokuCode != null 
					&& !shozokuCode.equals(""))) {
				sql.append(" AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
				paramList.add(shozokuCode);
				
			} else {
				// ���O�C���Ј����u���C�Ǘ��ҁv�ȊO�̏ꍇ
// DEL 2010/03/18 COMTURE BAK1-002 START
//				if(!"1".equals(loginuser.getKenpoMainteFlg())) {
//					sql.append(" AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
//					paramList.add(loginuser.getSosikiCode());
//				}
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
				if(!kenpoMainteFlg) {
					sql.append(" AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
					paramList.add(sosikiCode);
				}
// ADD 2010/03/18 COMTURE BAK1-002 END
			}
	        sql.append(" AND T01.SIMEI_NO = L15.SIMEI_NO");
	        sql.append(" AND T01.SOSIKI_CODE = T19.SOSIKI_CODE");
	        sql.append(" AND L15.KAMOKU_CODE = L01.KAMOKU_CODE");
	        sql.append(" AND L15.KAMOKU_CODE = L02.KAMOKU_CODE");
	        sql.append(" AND L15.CLASS_CODE = L02.CLASS_CODE");
	        sql.append(" AND L02.CHIKU_CODE = L09.CHIKU_CODE(+)");
	        if (startDate != null || "".equals(startDate)) {
	        	sql.append(" AND L02.KAISIBI >= ?");
	        	paramList.add(startDate);
	        }
	        if (endDate != null || "".equals(endDate)) {
	        	sql.append(" AND L02.SYURYOBI <= ?");
	        	paramList.add(endDate);
	        }
	        sql.append(" AND L01.CATEGORY_CODE2 = L71.CATEGORY_CODE(+) ))");
	        sql.append(" ORDER BY SOSIKI_CODE, SIMEI_NO, KAMOKU_CODE");
	        
			// �������s
			Log.debug(sql.toString());
			ps = con.prepareStatement(sql.toString());
			
			// �p�����[�^�Z�b�g
			for (int i = 0 ; i < paramList.size() ; i++)  {
				ps.setString(i+1, (String)paramList.get(i));
			}
			
			rs = ps.executeQuery();
			
			ArrayList soshikiJukouJyokyoList = new ArrayList();
			
			while (rs.next()) {
				String[] soshikiJukouJyokyo = new String[15];

				soshikiJukouJyokyo[0] = PZZ010_CharacterUtil.normalizedStr(rs.getString(1)); // ����No
				
				String kanjisimei = PZZ010_CharacterUtil.normalizedStr(rs.getString(2));     // ��������
				soshikiJukouJyokyo[1] = kanjisimei.length() > 0 ? kanjisimei.substring(1) : kanjisimei;
				
				soshikiJukouJyokyo[2] = PZZ010_CharacterUtil.normalizedStr(rs.getString(3)); // �g�D�R�[�h
				soshikiJukouJyokyo[3] = PZZ010_CharacterUtil.normalizedStr(rs.getString(4)); // �g�D����
				soshikiJukouJyokyo[4] = PZZ010_CharacterUtil.normalizedStr(rs.getString(5)); // �ȖڃR�[�h
				soshikiJukouJyokyo[5] = PZZ010_CharacterUtil.normalizedStr(rs.getString(6)); // �Ȗږ��P
				soshikiJukouJyokyo[6] = PZZ010_CharacterUtil.normalizedStr(rs.getString(7)); // �N���X�R�[�h
				soshikiJukouJyokyo[7] = PZZ010_CharacterUtil.normalizedStr(rs.getString(8)); // �N���X��
				soshikiJukouJyokyo[8] = PZZ010_CharacterUtil.normalizedStr(rs.getString(9)); // �J�n��
				soshikiJukouJyokyo[9] = PZZ010_CharacterUtil.normalizedStr(rs.getString(10)); // �I����
				
				String chikuMei = PZZ010_CharacterUtil.normalizedStr(rs.getString(11));       // �n�於
				if (!"".equals(chikuMei)) {
					soshikiJukouJyokyo[10] = chikuMei;
				} else {
					soshikiJukouJyokyo[10] = PZZ010_CharacterUtil.normalizedStr(rs.getString(12));
				}
				
				String syuryoHantei = PZZ010_CharacterUtil.normalizedStr(rs.getString(13));	// �C������
				
				if ("0".equals(syuryoHantei)) {
					soshikiJukouJyokyo[11] = "���C��";
				} else if ("1".equals(syuryoHantei)) {
					soshikiJukouJyokyo[11] = "��u��";
				} else if ("2".equals(syuryoHantei)) {
					soshikiJukouJyokyo[11] = "��u��";
				} else if ("�\����".equals(syuryoHantei)) {
					soshikiJukouJyokyo[11] = "�\����";
				} else {
					soshikiJukouJyokyo[11] = "";
				}
				soshikiJukouJyokyo[12] = PZZ010_CharacterUtil.normalizedStr(rs.getString(14)); // �Ȗڑ��݃`�F�b�N
				soshikiJukouJyokyo[13] = PZZ010_CharacterUtil.normalizedStr(rs.getString(15)); // �N���X���݃`�F�b�N
				soshikiJukouJyokyo[14] = PZZ010_CharacterUtil.normalizedStr(rs.getString(16)); // �K�{�E�����敪
				
				soshikiJukouJyokyoList.add(soshikiJukouJyokyo);
			}
			
			//���\�b�h�g���[�X�o��
			Log.method(loginNo, "OUT", "");
            
			return soshikiJukouJyokyoList;
			
// DEL 2010/03/18 COMTURE BAK1-002 START
//        } catch (NamingException e) {
//            Log.error(loginuser.getSimeiNo(), "HJE-0002", e);
//            throw new EJBException(e);
//        } catch (SQLException e) {
//        	Log.error(loginuser.getSimeiNo(), "HJE-0001", e);
//            throw new EJBException(e);
//        } catch (RuntimeException e) {
//            Log.error(loginuser.getSimeiNo(), "", e );
//            throw e;
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
        } catch (NamingException e) {
            Log.error(loginNo, "HJE-0002", e);
            throw new EJBException(e);
        } catch (SQLException e) {
        	Log.error(loginNo, "HJE-0001", e);
            throw new EJBException(e);
        } catch (RuntimeException e) {
            Log.error(loginNo, "", e );
            throw e;
// ADD 2010/03/18 COMTURE BAK1-002 END
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, con, ps, rs);
		}
	}
// ADD 2010/02/24 COMTURE OB-015 END

// ADD 2010/02/24 COMTURE PB-014,PB-016 START
// DEL 2010/03/18 COMTURE BAK1-002 START
//    public ArrayList getHissuJukouJyokyoList(String shozokuCode, String hissuKoza, String hissuKozaKubun,
//    	PCY_PersonalBean loginuser) throws NamingException, RemoteException, CreateException{
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
    /**
     * �g�D����u�󋵂֕\������K�{�u����u�󋵈ꗗ�𒊏o����B
     *
     * @param shozokuCode
     * @param hissuKoza
     * @param hissuKozaKubun
     * @param kenpoMainteFlg
     * @param kengenCode
     * @param sosikiCode
     * @param loginNo
     * @return �K�{�u����u�󋵈ꗗ
     *
     * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
     * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
     * @exception CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     *
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public ArrayList getHissuJukouJyokyoList(String shozokuCode, String hissuKoza, String hissuKozaKubun,
    		boolean kenpoMainteFlg, String kengenCode, String sosikiCode, String loginNo
    		) throws NamingException, RemoteException, CreateException{
// ADD 2010/03/18 COMTURE BAK1-002 END
    	
    	Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
    	
// DEL 2010/03/18 COMTURE BAK1-002 START
//    	String loginNo = loginuser.getSimeiNo();
// DEL 2010/03/18 COMTURE BAK1-002 END
    	
        try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginNo, "IN", "" );
            
			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
			con = locator.getDataSource().getConnection();
            
			ArrayList hissuJukouJyokyoList = new ArrayList();

			boolean allFlg = false;

			if (hissuKoza == null) {
				allFlg = true;
			}

			String startDate = null;
			String endDate = null;

			// �V�X�e�����t�̎擾
			String systemDate = PZZ010_CharacterUtil.GetDay();
			String systemYear = systemDate.substring(0, 4);
			String systemMonthAndDay = systemDate.substring(4);
			int intSystemMonthAndDay = Integer.parseInt(systemMonthAndDay);

			// �N�x�N�Z���̎擾
			String kisanbi = this.getSystemParameter("NENDO_KISANBI");
			int intKisanbi = Integer.parseInt(kisanbi);

			// �J�n���A�I�����̎擾
			if (intKisanbi <= intSystemMonthAndDay && intSystemMonthAndDay <= 1231) {
				startDate = systemYear + kisanbi;
				endDate = this.getLastDate(startDate, -1);

			} else {
				String thisYear = String .valueOf(Integer.parseInt(systemYear) - 1);
				startDate = thisYear + kisanbi;
				endDate = this.getLastDate(startDate, -1);
			}

			// �g�D�R�[�h�̊K�w���擾
// DEL 2010/03/18 COMTURE BAK1-002 START
//			String kaiso = getSosikiCodeKaiso(con, shozokuCode, loginuser);
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
			String kaiso = getSosikiCodeKaiso(con, shozokuCode, sosikiCode, loginNo);
// ADD 2010/03/18 COMTURE BAK1-002 END
			
			ArrayList paramList = new ArrayList();
			String sql = "";
			
			// �S�Ј��K�{�i�N�P��j
			if(allFlg || ZENSYA_HISSU_1.equals(hissuKozaKubun)) {
				sql += allFlg ? " ( " : "";
// DEL 2010/03/18 COMTURE BAK1-002 START
//				sql += getHissuSuisyoKoza1Data(paramList, shozokuCode, hissuKoza, startDate, endDate, kaiso, loginuser);
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
				sql += getHissuSuisyoKoza1Data(paramList, shozokuCode, hissuKoza, startDate, endDate, kaiso, kenpoMainteFlg, kengenCode, sosikiCode, loginNo);
// ADD 2010/03/18 COMTURE BAK1-002 END
				sql += allFlg ? " ) " : "";
			}
			// �S�Ј��K�{�i�N�P��ȏ�j
			if(allFlg || ZENSYA_HISSU_1IJO.equals(hissuKozaKubun)) {
// ADD 2010/03/18 COMTURE BAK1-001 START
				// �����Ώۂ́u�S�Ј��K�{�i�N�P��ȏ�j�v�ɊY������Ȗڐ�
				String countSql = " SELECT COUNT(*) ";
				ArrayList countParamList = new ArrayList();
				
				countSql += " FROM L71_HISSU_SUISYO_KOUZA_TBL L71, L01_KAMOKU_TBL L01 ";
				countSql += " WHERE L71.KUBUN = ? AND L01.CATEGORY_CODE2 = L71.CATEGORY_CODE";

				countParamList.add(ZENSYA_HISSU_1IJO);
				if (hissuKoza != null) {
					countSql += " AND L71.CATEGORY_CODE = ?";
					countParamList.add(hissuKoza);
				}
				countSql += " AND L01.TOUROKUBI BETWEEN ? AND ?";
				countParamList.add(startDate);
				countParamList.add(endDate);
				
				// �������s
				Log.debug(countSql.toString());
				ps = con.prepareStatement(countSql);
				
				// �p�����[�^�Z�b�g
				for (int i = 0 ; i < countParamList.size() ; i++)  {
					ps.setString(i+1, (String)countParamList.get(i));
				}
				
				rs = ps.executeQuery();
				boolean zensyaHissu1ijoExist = false;
				if (rs.next()) {
					int kamokuCount = rs.getInt(1);
					if (kamokuCount > 0) {
						zensyaHissu1ijoExist = true;
					}
				}
				// SQL���s���ɕK���R�l�N�V�����ȊO���N���[�Y����B
				PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);
				
				// �����Ώۂ́u�S�Ј��K�{�i�N�P��ȏ�j�v�ɊY������Ȗڂ����݂���ꍇ�̂�
				if (zensyaHissu1ijoExist) {
// ADD 2010/03/18 COMTURE BAK1-001 END
				sql += allFlg ? " UNION ALL ( " : "";
// DEL 2010/03/18 COMTURE BAK1-002 START
//				sql += getHissuSuisyoKoza2Data(paramList, shozokuCode, hissuKoza, startDate, endDate, kaiso, loginuser);
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
				sql += getHissuSuisyoKoza2Data(paramList, shozokuCode, hissuKoza, startDate, endDate, kaiso, kenpoMainteFlg, kengenCode, sosikiCode, loginNo);
// ADD 2010/03/18 COMTURE BAK1-002 END
				sql += allFlg ? " ) " : "";
// ADD 2010/03/18 COMTURE BAK1-001 START
				}
// ADD 2010/03/18 COMTURE BAK1-001 END
			}
			// �o���h�ʕK�{�u��
			if(allFlg || BAND_HISSU.equals(hissuKozaKubun)) {
				sql += allFlg ? " UNION ALL ( " : "";
// DEL 2010/03/18 COMTURE BAK1-002 START
//				sql += getHissuSuisyoKoza3Data(paramList, shozokuCode, hissuKoza, startDate, endDate, kaiso, loginuser);
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
				sql += getHissuSuisyoKoza3Data(paramList, shozokuCode, hissuKoza, startDate, endDate, kaiso, kenpoMainteFlg, kengenCode, sosikiCode, loginNo);
// ADD 2010/03/18 COMTURE BAK1-002 END
				sql += allFlg ? " ) " : "";
			}
			// �ΏێҎw��u��
			if(allFlg || TAISHOSYA_HISSU.equals(hissuKozaKubun)) {
				sql += allFlg ? " UNION ALL ( " : "";
// DEL 2010/03/18 COMTURE BAK1-002 START
//				sql += getHissuSuisyoKoza4Data(paramList, shozokuCode, hissuKoza, startDate, endDate, kaiso, loginuser);
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
				sql += getHissuSuisyoKoza4Data(paramList, shozokuCode, hissuKoza, startDate, endDate, kaiso, kenpoMainteFlg, kengenCode, sosikiCode, loginNo);
// ADD 2010/03/18 COMTURE BAK1-002 END
				sql += allFlg ? " ) " : "";
			}
			
// ADD 2010/03/18 COMTURE BAK1-001 START
			// �\�����ꂽSQL���Ȃ��ꍇ�͎��s���Ȃ�
			if (!"".equals(sql)) {
// ADD 2010/03/18 COMTURE BAK1-001 END
			// �������s
			Log.debug(sql.toString());
			ps = con.prepareStatement(sql.toString());
			
			// �p�����[�^�Z�b�g
			for (int i = 0 ; i < paramList.size() ; i++)  {
				ps.setString(i+1, (String)paramList.get(i));
			}

			rs = ps.executeQuery();

			while (rs.next()) {
				PCY_SoshikiJukouJyokyoRowBean rowBean = new PCY_SoshikiJukouJyokyoRowBean();
				rowBean.setPersonCode(rs.getString(1));
				rowBean.setPersonName(rs.getString(2));
				if (rowBean.getPersonName() != null && rowBean.getPersonName().length() > 0) {
					rowBean.setPersonName(rowBean.getPersonName().substring(1));
				}
				
				rowBean.setShozokuCode(rs.getString(3));
				rowBean.setShozokuName(rs.getString(4));
				rowBean.setKamokuCode(rs.getString(5));
				rowBean.setKamokuName(rs.getString(6));
				rowBean.setStatus(rs.getString(7));
				rowBean.setHissuKubun(rs.getString(8));
				rowBean.setKamokuExist(!ZENSYA_HISSU_1IJO.equals(rowBean.getHissuKubun()));
				rowBean.setClassExist(false);
				
				hissuJukouJyokyoList.add(rowBean);
			}


    		// �T�u�N�G���������AUNION ALL���Ă��邽��SQL�ɂ��\�[�g�͒x���A
			// ���\�m�ۂׁ̈A�\�[�g��Java���ōs�����̂Ƃ���
			// �\�[�g���F
			// �@�K�{�E�����u���敪�̏���
			// �@�ȖڃR�[�h�̏���
			// �@��Ԃ����\���E�\���ρE��u�ρE�󔒂̏�
			// �@�g�D�R�[�h�̏����A����No�̏���
    		Collections.sort(hissuJukouJyokyoList, new hissuJukouJyokyoComparator());
// ADD 2010/03/18 COMTURE BAK1-001 START
			}
// ADD 2010/03/18 COMTURE BAK1-001 END
			
            //���\�b�h�g���[�X�o��
            Log.method(loginNo, "OUT", "");

			return hissuJukouJyokyoList;

// DEL 2010/03/18 COMTURE BAK1-002 START
//        } catch (NamingException e) {
//            Log.error(loginuser.getSimeiNo(), "HJE-0002", e);
//            throw new EJBException(e);
//        } catch (SQLException e) {
//        	Log.error(loginuser.getSimeiNo(), "HJE-0001", e);
//            throw new EJBException(e);
//        } catch (RuntimeException e) {
//            Log.error(loginuser.getSimeiNo(), "", e );
//            throw e;
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
        } catch (NamingException e) {
            Log.error(loginNo, "HJE-0002", e);
            throw new EJBException(e);
        } catch (SQLException e) {
        	Log.error(loginNo, "HJE-0001", e);
            throw new EJBException(e);
        } catch (RuntimeException e) {
            Log.error(loginNo, "", e );
            throw e;
// ADD 2010/03/18 COMTURE BAK1-002 END
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, con, ps, rs);
		}
    }
    
    /**
     * �S�Ј��K�{�i�N�P��j�̌������s��SQL�A�p�����[�^��ݒ肷��
     * @param paramList
     * @param shozokuCode
     * @param hissuKoza
     * @param startDate
     * @param endDate
     * @param kaiso
     * @param kenpoMainteFlg
     * @param kengenCode
     * @param sosikiCode
     * @param loginNo
     * @return
     * @throws SQLException
     */
// DEL 2010/03/18 COMTURE BAK1-002 START
//    private String getHissuSuisyoKoza1Data (
//    		ArrayList paramList, String shozokuCode, String hissuKoza, String startDate, String endDate, String kaiso, PCY_PersonalBean loginuser)
//			throws SQLException {
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
    private String getHissuSuisyoKoza1Data (
    		ArrayList paramList, String shozokuCode, String hissuKoza, String startDate, String endDate, String kaiso,
    		boolean kenpoMainteFlg, String kengenCode, String sosikiCode, String loginNo
    		) throws SQLException {
// ADD 2010/03/18 COMTURE BAK1-002 END

    	try {

			StringBuffer sql = new StringBuffer();

			// ���������̍쐬
			sql.append(" SELECT");
			sql.append("  T01.SIMEI_NO,");
			sql.append("  T01.KANJI_SIMEI,");
			sql.append("  T01.SOSIKI_CODE,");
			sql.append("  T19.BUSYO_RYAKUSYO_MEI,");
			sql.append("  L01.KAMOKU_CODE,");
			sql.append("  L01.KAMOKU_MEI1,");
			sql.append("  CASE ");
			sql.append("   WHEN EXISTS(SELECT 1 FROM L51_KYOIKU_TBL L51 WHERE L51.SIMEI_NO = T01.SIMEI_NO AND L51.KAMOKU_CODE = L01.KAMOKU_CODE AND L51.SYURYO_HANTEI IN (?,?) ) THEN '��u��'");
			sql.append("   WHEN EXISTS(SELECT 1 FROM L51_KYOIKU_TBL L51 WHERE L51.SIMEI_NO = T01.SIMEI_NO AND L51.KAMOKU_CODE = L01.KAMOKU_CODE AND L51.SYURYO_HANTEI = ? ) THEN '���C��'");
			sql.append("   WHEN EXISTS(SELECT 1 FROM L15_MOUSIKOMI_JYOKYO_TBL L15 WHERE L15.SIMEI_NO = T01.SIMEI_NO AND L15.KAMOKU_CODE = L01.KAMOKU_CODE) THEN '�\����'");
			sql.append("   ELSE '���\��'");
			sql.append("  END,");
			sql.append("  ?");
			sql.append(" FROM");
			sql.append("  T01_PERSONAL_TBL T01,");
			sql.append("  T19_SOSIKI_TBL T19,");
			sql.append("  L71_HISSU_SUISYO_KOUZA_TBL L71,");
			sql.append("  L01_KAMOKU_TBL L01");
			sql.append(" WHERE");
			sql.append("  T01.KENGEN_CODE > ?");
			paramList.add("1");
			paramList.add("2");
			paramList.add("0");
			paramList.add(ZENSYA_HISSU_1);
			
// DEL 2010/03/18 COMTURE BAK1-002 START
//			if ("1".equals(loginuser.getKenpoMainteFlg())) {
//				paramList.add("0");
//			} else {
//				paramList.add(loginuser.getKengenCode());
//			}
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
			if (kenpoMainteFlg) {
				paramList.add("0");
			} else {
				paramList.add(kengenCode);
			}
// ADD 2010/03/18 COMTURE BAK1-002 END
			
			// ���������F�����ɑI������
			if ((shozokuCode != null 
					&& !shozokuCode.equals(""))) {
				sql.append("  AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
				paramList.add(shozokuCode);
				
			} else {
				// ���O�C���Ј����u���C�Ǘ��ҁv�ȊO�̏ꍇ
// DEL 2010/03/18 COMTURE BAK1-002 START
//				if(!"1".equals(loginuser.getKenpoMainteFlg())) {
//					sql.append("  AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
//					paramList.add(loginuser.getSosikiCode());
//				}
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
				if(!kenpoMainteFlg) {
					sql.append("  AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
					paramList.add(sosikiCode);
				}
// ADD 2010/03/18 COMTURE BAK1-002 END
			}
			
			sql.append("  AND T01.HONMU_FLG = ?");
			sql.append("  AND T01.GENSYOKU_TAISYOKU_FLG = ?");
			sql.append("  AND T01.SOSIKI_CODE = T19.SOSIKI_CODE");
			sql.append("  AND L71.KUBUN = ?");
			paramList.add("1");
			paramList.add("1");
			paramList.add(ZENSYA_HISSU_1);
			
			sql.append("  AND L01.CATEGORY_CODE2 = L71.CATEGORY_CODE");
			if (hissuKoza != null) {
				sql.append("  AND L71.CATEGORY_CODE = ?");
				paramList.add(hissuKoza);
			}
			
			sql.append("  AND L01.TOUROKUBI BETWEEN ? AND ?");
			paramList.add(startDate);
			paramList.add(endDate);
			

			// �������s
			Log.debug(sql.toString());
			
			return sql.toString();

		} finally {
		}
    }
    
    /**
     * �S�Ј��K�{�i�N�P��ȏ�j�̌������s��SQL�A�p�����[�^��ݒ肷��
     * @param paramList
     * @param shozokuCode
     * @param hissuKoza
     * @param startDate
     * @param endDate
     * @param kaiso
     * @param kenpoMainteFlg
     * @param kengenCode
     * @param sosikiCode
     * @param loginNo
     * @return
     * @throws SQLException
     */
// DEL 2010/03/18 COMTURE BAK1-002 START
//    private String getHissuSuisyoKoza2Data (
//    		ArrayList paramList, String shozokuCode, String hissuKoza, String startDate, String endDate, String kaiso, PCY_PersonalBean loginuser)
//			throws SQLException {
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
    private String getHissuSuisyoKoza2Data (
    		ArrayList paramList, String shozokuCode, String hissuKoza, String startDate, String endDate, String kaiso,
    		boolean kenpoMainteFlg, String kengenCode, String sosikiCode, String loginNo
    		) throws SQLException {
// ADD 2010/03/18 COMTURE BAK1-002 END
    	
    	try {

			StringBuffer sql = new StringBuffer();

			// ���������̍쐬
			sql.append(" SELECT");
			sql.append("   T01.SIMEI_NO");
			sql.append("   , T01.KANJI_SIMEI");
			sql.append("   , T01.SOSIKI_CODE");
			sql.append("   , T19.BUSYO_RYAKUSYO_MEI");
			sql.append("   , NULL");
			sql.append("   , ?");
			paramList.add((String)ReadFile.paramMapData.get("DZY247"));
			
			sql.append("   , CASE ");
			sql.append("     WHEN NOT EXISTS( ");
			sql.append("           SELECT");
			sql.append("             1 ");
			sql.append("           FROM");
			sql.append("             L71_HISSU_SUISYO_KOUZA_TBL L71");
			sql.append("             , L01_KAMOKU_TBL L01 ");
			sql.append("           WHERE");
			sql.append("             L71.KUBUN = ? ");
			sql.append("             AND L01.CATEGORY_CODE2 = L71.CATEGORY_CODE");
			paramList.add(ZENSYA_HISSU_1IJO);

			if (hissuKoza != null) {
				sql.append("             AND L71.CATEGORY_CODE = ?");
				paramList.add(hissuKoza);
			}

			sql.append("             AND L01.TOUROKUBI BETWEEN ? AND ?");
			sql.append("     ) ");
			sql.append("     THEN '' ");
			paramList.add(startDate);
			paramList.add(endDate);
			
			sql.append("     WHEN EXISTS( ");
			sql.append("       SELECT");
			sql.append("         1 ");
			sql.append("       FROM");
			sql.append("         L51_KYOIKU_TBL L51");
			sql.append("         , ( ");
			sql.append("           SELECT");
			sql.append("             L01.KAMOKU_CODE ");
			sql.append("           FROM");
			sql.append("             L71_HISSU_SUISYO_KOUZA_TBL L71");
			sql.append("             , L01_KAMOKU_TBL L01 ");
			sql.append("           WHERE");
			sql.append("             L71.KUBUN = ? ");
			sql.append("             AND L01.CATEGORY_CODE2 = L71.CATEGORY_CODE");
			paramList.add(ZENSYA_HISSU_1IJO);

			if (hissuKoza != null) {
				sql.append("             AND L71.CATEGORY_CODE = ?");
				paramList.add(hissuKoza);
			}

			sql.append("             AND L01.TOUROKUBI BETWEEN ? AND ?");
			sql.append("         ) HISSU ");
			sql.append("       WHERE");
			sql.append("         L51.SIMEI_NO = T01.SIMEI_NO ");
			sql.append("         AND L51.KAMOKU_CODE = HISSU.KAMOKU_CODE ");
			sql.append("         AND L51.SYURYO_HANTEI IN (?,?)");
			sql.append("     ) ");
			sql.append("     THEN '��u��' ");
			paramList.add(startDate);
			paramList.add(endDate);
			paramList.add("1");
			paramList.add("2");
			
			sql.append("     WHEN EXISTS( ");
			sql.append("       SELECT");
			sql.append("         1 ");
			sql.append("       FROM");
			sql.append("         L51_KYOIKU_TBL L51");
			sql.append("         , ( ");
			sql.append("           SELECT");
			sql.append("             L01.KAMOKU_CODE ");
			sql.append("           FROM");
			sql.append("             L71_HISSU_SUISYO_KOUZA_TBL L71");
			sql.append("             , L01_KAMOKU_TBL L01 ");
			sql.append("           WHERE");
			sql.append("             L71.KUBUN = ? ");
			sql.append("             AND L01.CATEGORY_CODE2 = L71.CATEGORY_CODE");
			paramList.add(ZENSYA_HISSU_1IJO);

			if (hissuKoza != null) {
				sql.append("             AND L71.CATEGORY_CODE = ?");
				paramList.add(hissuKoza);
			}

			sql.append("             AND L01.TOUROKUBI BETWEEN ? AND ?");
			sql.append("         ) HISSU ");
			sql.append("       WHERE");
			sql.append("         L51.SIMEI_NO = T01.SIMEI_NO ");
			sql.append("         AND L51.KAMOKU_CODE = HISSU.KAMOKU_CODE ");
			sql.append("         AND L51.SYURYO_HANTEI = ?");
			sql.append("     ) ");
			sql.append("     THEN '���C��' ");
			paramList.add(startDate);
			paramList.add(endDate);
			paramList.add("0");
			
			sql.append("     WHEN EXISTS( ");
			sql.append("       SELECT");
			sql.append("         1 ");
			sql.append("       FROM");
			sql.append("         L15_MOUSIKOMI_JYOKYO_TBL L15");
			sql.append("         , ( ");
			sql.append("           SELECT");
			sql.append("             L01.KAMOKU_CODE ");
			sql.append("           FROM");
			sql.append("             L71_HISSU_SUISYO_KOUZA_TBL L71");
			sql.append("             , L01_KAMOKU_TBL L01 ");
			sql.append("           WHERE");
			sql.append("             L71.KUBUN = ? ");
			sql.append("             AND L01.CATEGORY_CODE2 = L71.CATEGORY_CODE");
			paramList.add(ZENSYA_HISSU_1IJO);

			if (hissuKoza != null) {
				sql.append("             AND L71.CATEGORY_CODE = ?");
				paramList.add(hissuKoza);
			}

			sql.append("             AND L01.TOUROKUBI BETWEEN ? AND ?");
			paramList.add(startDate);
			paramList.add(endDate);
			
			sql.append("         ) HISSU ");
			sql.append("       WHERE");
			sql.append("         L15.SIMEI_NO = T01.SIMEI_NO ");
			sql.append("         AND L15.KAMOKU_CODE = HISSU.KAMOKU_CODE");
			sql.append("     ) ");
			sql.append("     THEN '�\����' ");
			sql.append("     ELSE '���\��' ");
			sql.append("     END AS STATUS ");
			sql.append("   , ?");
			sql.append(" FROM");
			sql.append("   T01_PERSONAL_TBL T01");
			sql.append("   , T19_SOSIKI_TBL T19 ");
			sql.append(" WHERE");
			sql.append("  T01.KENGEN_CODE > ?");
			paramList.add(ZENSYA_HISSU_1IJO);
			
// DEL 2010/03/18 COMTURE BAK1-002 START
//			if ("1".equals(loginuser.getKenpoMainteFlg())) {
//				paramList.add("0");
//			} else {
//				paramList.add(loginuser.getKengenCode());
//			}
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
			if (kenpoMainteFlg) {
				paramList.add("0");
			} else {
				paramList.add(kengenCode);
			}
// ADD 2010/03/18 COMTURE BAK1-002 END
			
			// ���������F�����ɑI������
			if ((shozokuCode != null 
					&& !shozokuCode.equals(""))) {
				sql.append("  AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
				paramList.add(shozokuCode);
				
			} else {
				// ���O�C���Ј����u���C�Ǘ��ҁv�ȊO�̏ꍇ
// DEL 2010/03/18 COMTURE BAK1-002 START
//				if(!"1".equals(loginuser.getKenpoMainteFlg())) {
//					sql.append("  AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
//					paramList.add(loginuser.getSosikiCode());
//				}
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
				if(!kenpoMainteFlg) {
					sql.append("  AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
					paramList.add(sosikiCode);
				}
// ADD 2010/03/18 COMTURE BAK1-002 END
			}
			
			sql.append("  AND T01.HONMU_FLG = ?");
			sql.append("  AND T01.GENSYOKU_TAISYOKU_FLG = ?");
			sql.append("   AND T01.SOSIKI_CODE = T19.SOSIKI_CODE");
			paramList.add("1");
			paramList.add("1");


			// �������s
			Log.debug(sql.toString());
			
			return sql.toString();

		} finally {
		}
    }
    
    /**
     * �o���h�ʕK�{�u���̌������s��SQL�A�p�����[�^��ݒ肷��
     * @param paramList
     * @param shozokuCode
     * @param hissuKoza
     * @param startDate
     * @param endDate
     * @param kaiso
     * @param kenpoMainteFlg
     * @param kengenCode
     * @param sosikiCode
     * @param loginNo
     * @return
     * @throws SQLException
     */
// DEL 2010/03/18 COMTURE BAK1-002 START
//    private String getHissuSuisyoKoza3Data (
//    		ArrayList paramList, String shozokuCode, String hissuKoza, String startDate, String endDate, String kaiso, PCY_PersonalBean loginuser)
//			throws SQLException {
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
    private String getHissuSuisyoKoza3Data (
    		ArrayList paramList, String shozokuCode, String hissuKoza, String startDate, String endDate, String kaiso,
    		boolean kenpoMainteFlg, String kengenCode, String sosikiCode, String loginNo
    		) throws SQLException {
// ADD 2010/03/18 COMTURE BAK1-002 END

    	try {

			StringBuffer sql = new StringBuffer();

			// ���������̍쐬
			sql.append(" SELECT");
			sql.append("  T01.SIMEI_NO,");
			sql.append("  T01.KANJI_SIMEI,");
			sql.append("  T01.SOSIKI_CODE,");
			sql.append("  T19.BUSYO_RYAKUSYO_MEI,");
			sql.append("  L01.KAMOKU_CODE,");
			sql.append("  L01.KAMOKU_MEI1,");
			sql.append("  CASE ");
			sql.append("   WHEN EXISTS(SELECT 1 FROM L51_KYOIKU_TBL L51 WHERE L51.SIMEI_NO = T01.SIMEI_NO AND L51.KAMOKU_CODE = L01.KAMOKU_CODE AND L51.SYURYO_HANTEI IN (?,?) ) THEN '��u��'");
			sql.append("   WHEN EXISTS(SELECT 1 FROM L51_KYOIKU_TBL L51 WHERE L51.SIMEI_NO = T01.SIMEI_NO AND L51.KAMOKU_CODE = L01.KAMOKU_CODE AND L51.SYURYO_HANTEI = ? ) THEN '���C��'");
			sql.append("   WHEN EXISTS(SELECT 1 FROM T05_KYOIKU_TBL T05 WHERE T05.SIMEI_NO = T01.SIMEI_NO AND T05.KAMOKU_CODE = L01.KAMOKU_CODE AND T05.SYURYO_HANTEI IN (?,?) ) THEN '��u��'");
			sql.append("   WHEN EXISTS(SELECT 1 FROM L15_MOUSIKOMI_JYOKYO_TBL L15 WHERE L15.SIMEI_NO = T01.SIMEI_NO AND L15.KAMOKU_CODE = L01.KAMOKU_CODE) THEN '�\����'");
			sql.append("   ELSE '���\��'");
			sql.append("  END,");
			sql.append("  ?");
			sql.append(" FROM");
			sql.append("  T01_PERSONAL_TBL T01,");
			sql.append("  T19_SOSIKI_TBL T19,");
			sql.append("  L71_HISSU_SUISYO_KOUZA_TBL L71,");
			sql.append("  L01_KAMOKU_TBL L01");
			sql.append(" WHERE");
			sql.append("  T01.KENGEN_CODE > ?");
			paramList.add("1");
			paramList.add("2");
			paramList.add("0");
			paramList.add("1");
			paramList.add("2");
			paramList.add(BAND_HISSU);
			
// DEL 2010/03/18 COMTURE BAK1-002 START
//			if ("1".equals(loginuser.getKenpoMainteFlg())) {
//				paramList.add("0");
//			} else {
//				paramList.add(loginuser.getKengenCode());
//			}
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
			if (kenpoMainteFlg) {
				paramList.add("0");
			} else {
				paramList.add(kengenCode);
			}
// ADD 2010/03/18 COMTURE BAK1-002 END
			
			// ���������F�����ɑI������
			if ((shozokuCode != null 
					&& !shozokuCode.equals(""))) {
				sql.append("  AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
				paramList.add(shozokuCode);
				
			} else {
				// ���O�C���Ј����u���C�Ǘ��ҁv�ȊO�̏ꍇ
// DEL 2010/03/18 COMTURE BAK1-002 START
//				if(!"1".equals(loginuser.getKenpoMainteFlg())) {
//					sql.append("  AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
//					paramList.add(loginuser.getSosikiCode());
//				}
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
				if(!kenpoMainteFlg) {
					sql.append("  AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
					paramList.add(sosikiCode);
				}
// ADD 2010/03/18 COMTURE BAK1-002 END
			}
			
			sql.append("  AND T01.HONMU_FLG = ?");
			sql.append("  AND T01.GENSYOKU_TAISYOKU_FLG = ?");
			sql.append("  AND T01.SOSIKI_CODE = T19.SOSIKI_CODE");
			sql.append("  AND L71.KUBUN = ?");
			sql.append("  AND L01.CATEGORY_CODE2 = L71.CATEGORY_CODE");
			paramList.add("1");
			paramList.add("1");
			paramList.add(BAND_HISSU);

			if (hissuKoza != null) {
				sql.append("  AND L71.CATEGORY_CODE = ?");
				paramList.add(hissuKoza);
			}
			
			sql.append("  AND EXISTS (");
			sql.append("   SELECT");
			sql.append("    1");
			sql.append("   FROM");
			sql.append("    L02_CLASS_TBL L02"); 
			sql.append("   WHERE");
			sql.append("    L02.KAMOKU_CODE = L01.KAMOKU_CODE");
			sql.append("    AND L02.KAISIBI BETWEEN ? AND ?");
			sql.append("  )");
			sql.append("  AND (L71.KAISI_BAND IS NULL OR T01.SYOKUI_CODE >= L71.KAISI_BAND)");
			sql.append("  AND (L71.SYURYO_BAND IS NULL OR T01.SYOKUI_CODE <= L71.SYURYO_BAND)");
			paramList.add(startDate);
			paramList.add(endDate);
			

			// �������s
			Log.debug(sql.toString());
			
			return sql.toString();

		} finally {
		}
    }
    
    /**
     * �ΏێҎw��u���̌������s��SQL�A�p�����[�^��ݒ肷��
     * @param paramList
     * @param shozokuCode
     * @param hissuKoza
     * @param startDate
     * @param endDate
     * @param kaiso
     * @param kenpoMainteFlg
     * @param kengenCode
     * @param sosikiCode
     * @param loginNo
     * @return
     * @throws SQLException
     */
// DEL 2010/03/18 COMTURE BAK1-002 START
//    private String getHissuSuisyoKoza4Data (
//    		ArrayList paramList, String shozokuCode, String hissuKoza, String startDate, String endDate, String kaiso, PCY_PersonalBean loginuser)
//			throws SQLException {
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
    private String getHissuSuisyoKoza4Data (
    		ArrayList paramList, String shozokuCode, String hissuKoza, String startDate, String endDate, String kaiso,
    		boolean kenpoMainteFlg, String kengenCode, String sosikiCode, String loginNo
    		) throws SQLException {
// ADD 2010/03/18 COMTURE BAK1-002 END
    	
    	try {

			StringBuffer sql = new StringBuffer();

			// ���������̍쐬
			sql.append(" SELECT");
			sql.append("  T01.SIMEI_NO,");
			sql.append("  T01.KANJI_SIMEI,");
			sql.append("  T01.SOSIKI_CODE,");
			sql.append("  T19.BUSYO_RYAKUSYO_MEI,");
			sql.append("  L01.KAMOKU_CODE,");
			sql.append("  L01.KAMOKU_MEI1,");
			sql.append("  CASE ");
			sql.append("   WHEN EXISTS(SELECT 1 FROM L51_KYOIKU_TBL L51 WHERE L51.SIMEI_NO = T01.SIMEI_NO AND L51.KAMOKU_CODE = L01.KAMOKU_CODE AND L51.SYURYO_HANTEI IN (?,?) ) THEN '��u��'");
			sql.append("   WHEN EXISTS(SELECT 1 FROM L51_KYOIKU_TBL L51 WHERE L51.SIMEI_NO = T01.SIMEI_NO AND L51.KAMOKU_CODE = L01.KAMOKU_CODE AND L51.SYURYO_HANTEI = ? ) THEN '���C��'");
			sql.append("   WHEN EXISTS(SELECT 1 FROM L15_MOUSIKOMI_JYOKYO_TBL L15 WHERE L15.SIMEI_NO = T01.SIMEI_NO AND L15.KAMOKU_CODE = L01.KAMOKU_CODE) THEN '�\����'");
			sql.append("   ELSE '���\��'");
			sql.append("  END,");
			sql.append("  ?");
			sql.append(" FROM");
			sql.append("  T01_PERSONAL_TBL T01,");
			sql.append("  T19_SOSIKI_TBL T19,");
			sql.append("  L71_HISSU_SUISYO_KOUZA_TBL L71,");
			sql.append("  L01_KAMOKU_TBL L01");
			sql.append(" WHERE");
			sql.append("  T01.KENGEN_CODE > ?");
			paramList.add("1");
			paramList.add("2");
			paramList.add("0");
			paramList.add(TAISHOSYA_HISSU);
			
// DEL 2010/03/18 COMTURE BAK1-002 START
//			if ("1".equals(loginuser.getKenpoMainteFlg())) {
//				paramList.add("0");
//			} else {
//				paramList.add(loginuser.getKengenCode());
//			}
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
			if (kenpoMainteFlg) {
				paramList.add("0");
			} else {
				paramList.add(kengenCode);
			}
// ADD 2010/03/18 COMTURE BAK1-002 END
			
			// ���������F�����ɑI������
			if ((shozokuCode != null 
					&& !shozokuCode.equals(""))) {
				sql.append("  AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
				paramList.add(shozokuCode);
				
			} else {
				// ���O�C���Ј����u���C�Ǘ��ҁv�ȊO�̏ꍇ
// DEL 2010/03/18 COMTURE BAK1-002 START
//				if(!"1".equals(loginuser.getKenpoMainteFlg())) {
//					sql.append("  AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
//					paramList.add(loginuser.getSosikiCode());
//				}
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
				if(!kenpoMainteFlg) {
					sql.append("  AND T01.SYOZOKU_CODE_"+ kaiso + " = ?");
					paramList.add(sosikiCode);
				}
// ADD 2010/03/18 COMTURE BAK1-002 END
			}
			
			sql.append("  AND T01.HONMU_FLG = ?");
			sql.append("  AND T01.GENSYOKU_TAISYOKU_FLG = ?");
			sql.append("  AND T01.SOSIKI_CODE = T19.SOSIKI_CODE");
			sql.append("  AND L71.KUBUN = ?");
			sql.append("  AND L01.CATEGORY_CODE2 = L71.CATEGORY_CODE");
			paramList.add("1");
			paramList.add("1");
			paramList.add(TAISHOSYA_HISSU);
			
			if (hissuKoza != null) {
				sql.append("  AND L71.CATEGORY_CODE = ?");
				paramList.add(hissuKoza);
			}
			
			sql.append("  AND L01.TOUROKUBI BETWEEN ? AND ?");
			sql.append("  AND EXISTS (");
			sql.append("   SELECT 1 FROM L14_TAISYOSYA_TBL L14");
			sql.append("   WHERE L14.KAMOKU_CODE = L01.KAMOKU_CODE");
			sql.append("   AND L14.SIMEI_NO = T01.SIMEI_NO");
			sql.append("   AND L14.TAISYO_KUBUN = ?");
			sql.append("  )");
			paramList.add(startDate);
			paramList.add(endDate);
			paramList.add("0");
			
			
			// �������s
			Log.debug(sql.toString());
			
			return sql.toString();

		} finally {
		}
    }
// ADD 2010/02/24 COMTURE PB-014,PB-016 END
// DEL 2010/02/24 COMTURE PB-014,PB-016 START
//    /**
//     * �g�D����u�󋵂֕\������K�{�u����u�󋵈ꗗ�𒊏o����B
//     *
//     * @param searchKey ��������Bean
//     * @param loginuser ���O�C�����[�U���
//     * @return �K�{�u����u�󋵈ꗗ
//     *
//     * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
//     * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
//     * @exception CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
//     *
//     * @ejb.interface-method
//     * @ejb.transaction type="Required"
//     */
//    public ArrayList getHissuJukouJyokyoList(String shozokuCode, String hissuKoza, String hissuKozaKubun,
//    	PCY_PersonalBean loginuser) throws NamingException, RemoteException, CreateException{
//    	
//    	Connection con = null;
//    	
//    	String loginNo = loginuser.getSimeiNo();
//    	
//        try {
//            // ���\�b�h�g���[�X�o��
//            Log.method(loginNo, "IN", "" );
//            
//			// �R�l�N�V�����擾
//			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
//			con = locator.getDataSource().getConnection();
//            
//            // �I���������̎Ј������擾���� 
//            PCY_PersonalBean[] personalBeans = getPersonInfo(con, shozokuCode, loginuser);
//            
//            // �K�{�u���̉ȖڃR�[�h���擾���� 
//            ArrayList kamokuCodeList = new ArrayList();
//            
//            boolean allFlg = false;
//            
//            if (hissuKoza == null) {
//            	allFlg = true;
//            }
//            
//            String startDate = null;
//            String endDate = null;
//            
//			// �V�X�e�����t�̎擾
//			String systemDate = PZZ010_CharacterUtil.GetDay();
//			String systemYear = systemDate.substring(0, 4);
//			String systemMonthAndDay = systemDate.substring(4);
//			int intSystemMonthAndDay = Integer.parseInt(systemMonthAndDay);
//
//			// �N�x�N�Z���̎擾
//			String kisanbi = this.getSystemParameter("NENDO_KISANBI");
//			int intKisanbi = Integer.parseInt(kisanbi);
//
//			// �J�n���A�I�����̎擾
//			if (intKisanbi <= intSystemMonthAndDay && intSystemMonthAndDay <= 1231) {
//				startDate = systemYear + kisanbi;
//				endDate = this.getLastDate(startDate, -1);
//
//			} else {
//				String thisYear = String .valueOf(Integer.parseInt(systemYear) - 1);
//				startDate = thisYear + kisanbi;
//				endDate = this.getLastDate(startDate, -1);
//			}
//            
//            // �S�Ј��K�{�i�N�P��j�܂��́A�S�Ă��I�����ꂽ�ꍇ
//            if (ZENSYA_HISSU_1.equals(hissuKozaKubun) || allFlg) {
//            	
//            	kamokuCodeList.addAll(getEachHissuKamokuCodeList(con, hissuKoza, loginuser, 
//            							ZENSYA_HISSU_1, startDate, endDate, allFlg));
//            }
//            
//            // �S�Ј��K�{�i�N�P��ȏ�j�܂��́A�S�Ă��I�����ꂽ�ꍇ
//            if (ZENSYA_HISSU_1IJO.equals(hissuKozaKubun) || allFlg) {
//            	
//            	kamokuCodeList.addAll(getEachHissuKamokuCodeList(con, hissuKoza, loginuser, 
//            							ZENSYA_HISSU_1IJO, startDate, endDate, allFlg));
//            }
//            
//            // �o���h�ʕK�{�u���܂��́A�S�Ă��I�����ꂽ�ꍇ
//            if (BAND_HISSU.equals(hissuKozaKubun) || allFlg) {
//            	
//            	kamokuCodeList.addAll(getEachHissuKamokuCodeList(con, hissuKoza, loginuser, 
//            							BAND_HISSU, startDate, endDate, allFlg));
//            }
//            
//            // �ΏێҎw��u���܂��́A�S�Ă��I�����ꂽ�ꍇ
//            if (TAISHOSYA_HISSU.equals(hissuKozaKubun) || allFlg) {
//            	
//            	kamokuCodeList.addAll(getEachHissuKamokuCodeList(con, hissuKoza, loginuser, 
//            							TAISHOSYA_HISSU, startDate, endDate, allFlg));
//            }
//            
//    		// �\�[�g����i�K�{�E�����敪�̏����A�ȖڃR�[�h�̏���)    
//    		Collections.sort(kamokuCodeList, new hissuKouzaComparator());
//            
//            // �\�����ڂ��擾���� 
//    		PCY_HissuSuisyoKouzaBean hissuBean = null;
//    		
//    		// �S�K�{�u����\�����郊�X�g
//    		ArrayList hissuJukouJyokyoList = new ArrayList();
//    		
//    		// �S�Ј��K�{�i�N�P��ȏ�j
//    		ArrayList zensya1ijoHissuList = new ArrayList();
//    
//    		for (int i = 0 ; i < kamokuCodeList.size() ; i++) {
//
//    			hissuBean = (PCY_HissuSuisyoKouzaBean)kamokuCodeList.get(i);
//    			
//    			// ��u�����擾����
//    			PCY_KamokuBean kamokuBean = new PCY_KamokuBean();
//    			kamokuBean.setKamokuCode(hissuBean.getKamokuCode());
//    			kamokuBean.setKamokuMei1(hissuBean.getKamokuMei());
//    			
//    			if (kamokuBean != null) {
//	    			// �S�Ј��K�{�i�N�P��j
//	    			if (ZENSYA_HISSU_1.equals(hissuBean.getKubun())) {
//	    				// ��Ԃ��擾���A�\�����ڃ��X�g���擾����
//	    				hissuJukouJyokyoList.addAll(getHyojiKoumokuList(con, personalBeans,
//	    											kamokuBean, ZENSYA_HISSU_1, loginuser));
//	    			}
//	    			 
//					// �S�Ј��K�{�i�N�P��ȏ�j
//					if (ZENSYA_HISSU_1IJO.equals(hissuBean.getKubun())) {
//						zensya1ijoHissuList.add(kamokuBean);
//					}
//					
//					// �o���h�ΏەK�{
//					if (BAND_HISSU.equals(hissuBean.getKubun())) {
//						// �Ώێ҂𒊏o����
//						PCY_PersonalBean[] bandTargetPersonList =
//							getBandTargetPersonList(con, personalBeans, loginuser, kamokuBean);
//						
//						// ��Ԃ��擾���A�\�����ڃ��X�g���擾����
//						hissuJukouJyokyoList.addAll(getHyojiKoumokuList(con, bandTargetPersonList,
//													kamokuBean, BAND_HISSU, loginuser));
//					}
//					
//					// �ΏێҎw��u��
//					if (TAISHOSYA_HISSU.equals(hissuBean.getKubun())) {
//						// �Ώێ҂𒊏o����
//						PCY_PersonalBean[] taisyosyasiteiPersonList =
//							getTaisyosyaSiteiPersonList(con, personalBeans, loginuser, kamokuBean);
//						
//						// ��Ԃ��擾���A�\�����ڃ��X�g���擾����
//						hissuJukouJyokyoList.addAll(getHyojiKoumokuList(con, taisyosyasiteiPersonList,
//													kamokuBean, TAISHOSYA_HISSU, loginuser));
//					}
//    			}
//    		}
//    		
//    		if (ZENSYA_HISSU_1IJO.equals(hissuKozaKubun) || allFlg) {
//	    		// �S�Ј��K�{�i�N�P��ȏ�j�̕\�����ڃ��X�g���擾����B
//	    		hissuJukouJyokyoList.addAll(getZensya1ijoHyojiKoumokuList(con, personalBeans,
//	    										zensya1ijoHissuList, ZENSYA_HISSU_1IJO, loginuser));
//    		}
//    		
//    		// �\�[�g����
//    		// �\�[�g���F�K�{�E�����u���敪�̏����A�ȖڃR�[�h�̏����A��Ԃ����\���E�\���ρE��u�ρE�󔒂̏��A
//    		//			�g�D�R�[�h�̏����A����No�̏���
//    		Collections.sort(hissuJukouJyokyoList, new hissuJukouJyokyoComparator());
//    		
//            //���\�b�h�g���[�X�o��
//            Log.method(loginNo, "OUT", "");
//
//			return hissuJukouJyokyoList;
//
//        } catch (NamingException e) {
//            Log.error(loginuser.getSimeiNo(), "HJE-0002", e);
//            throw new EJBException(e);
//        } catch (SQLException e) {
//        	Log.error(loginuser.getSimeiNo(), "HJE-0001", e);
//            throw new EJBException(e);
//        } catch (RuntimeException e) {
//            Log.error(loginuser.getSimeiNo(), "", e );
//            throw e;
//		} finally {
//			PZZ040_SQLUtility.closeConnection(loginNo, con, null, null);
//		}
//    }
//    
//    /**
//     * �I���������̎Ј������擾����B
//	 * 
//	 * @param con �R�l�N�V����
//	 * @param loginuser ���O�C�����[�U���
//	 * @return �I���������̎Ј����
//	 * 
//	 * @exception SQLException SQL�G���[�����������ꍇ
//	 */
//	private PCY_PersonalBean[] getPersonInfo(Connection con, 
//		String shozokuCode, PCY_PersonalBean loginuser)
//		throws SQLException {
//
//		PreparedStatement ps = null;
//		ResultSet rs = null;
//		String loginNo = loginuser.getSimeiNo();
//		
//		try {
//			// ���\�b�h�g���[�X�o�� 
//			Log.method(loginNo, "IN", "");
//
//			StringBuffer sql = new StringBuffer();
//			ArrayList paramList = new ArrayList();
//
//			// �g�D�R�[�h�̊K�w���擾
//			String kaiso = getSosikiCodeKaiso(con, shozokuCode, loginuser);
//
//			// ���������̍쐬
//			sql.append("SELECT PERSONAL.SIMEI_NO AS SIMEI_NO,");
//			sql.append(" PERSONAL.KANJI_SIMEI AS KANJI_SIMEI,");
//			sql.append(" PERSONAL.SOSIKI_CODE AS SOSIKI_CODE,");
//			sql.append(" SOSIKI.BUSYO_RYAKUSYO_MEI AS BUSYO_RYAKUSYO_MEI");
//			sql.append(" FROM");
//			sql.append(" T01_PERSONAL_TBL PERSONAL,");
//			sql.append(" T19_SOSIKI_TBL SOSIKI");
//			sql.append(" WHERE");
//			sql.append(" PERSONAL.KENGEN_CODE > ?");
//			
//			if ("1".equals(loginuser.getKenpoMainteFlg())) {
//				paramList.add("0");
//			} else {
//				paramList.add(loginuser.getKengenCode());
//			}
//			
//			// ���������F�����ɑI������
//			if ((shozokuCode != null 
//					&& !shozokuCode.equals(""))) {
//				sql.append(" AND PERSONAL.SYOZOKU_CODE_"+ kaiso + " = ?");
//				paramList.add(shozokuCode);
//				
//			} else {
//				// ���O�C���Ј����u���C�Ǘ��ҁv�ȊO�̏ꍇ
//				if(!"1".equals(loginuser.getKenpoMainteFlg())) {
//					sql.append(" AND PERSONAL.SYOZOKU_CODE_"+ kaiso + " = ?");
//					paramList.add(loginuser.getSosikiCode());
//				}
//			}
//			
//			sql.append(" AND PERSONAL.HONMU_FLG = ?");
//			sql.append(" AND PERSONAL.GENSYOKU_TAISYOKU_FLG = ?");
//			paramList.add("1");
//			paramList.add("1");
//			
//			sql.append(" AND PERSONAL.SOSIKI_CODE = SOSIKI.SOSIKI_CODE");
//			sql.append(" ORDER BY SOSIKI_CODE, SIMEI_NO");
//
//			// �������s
//			Log.debug(sql.toString());
//			ps = con.prepareStatement(sql.toString());
//			
//			// �p�����[�^�Z�b�g
//			for (int i = 0 ; i < paramList.size() ; i++)  {
//				ps.setString(i+1, (String)paramList.get(i));
//			}
//
//			rs = ps.executeQuery();
//			
//			ArrayList personlBeanList = new ArrayList();
//
//			while (rs.next()) {
//				PCY_PersonalBean personalBean = new PCY_PersonalBean();
//				
//				personalBean.setSimeiNo(rs.getString("SIMEI_NO"));
//				personalBean.setKanjiSimei((rs.getString("KANJI_SIMEI").length() > 0) ?
//											rs.getString("KANJI_SIMEI").substring(1) :
//											rs.getString("KANJI_SIMEI"));
//				personalBean.setSosikiCode(rs.getString("SOSIKI_CODE"));
//				personalBean.setBusyoRyakusyoMei(rs.getString("BUSYO_RYAKUSYO_MEI"));
//				
//				personlBeanList.add(personalBean);
//			}
//
//			// ���\�b�h�g���[�X�o��
//			Log.method(loginNo, "OUT", "");
//
//			return (PCY_PersonalBean[])personlBeanList.toArray(new PCY_PersonalBean[0]);
//
//		} finally {
//			PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);
//		}
//	}
// DEL 2010/02/24 COMTURE PB-014,PB-016 END
	
    /**
     * �g�D�R�[�h�̊K�w���擾����B
	 * 
	 * @param con �R�l�N�V����
	 * @param searchKey ��������
	 * @param loginuser ���O�C�����[�U���
	 * @return �g�D�R�[�h�̊K�w
	 * 
	 * @exception SQLException SQL�G���[�����������ꍇ
	 */
// DEL 2010/03/18 COMTURE BAK1-002 START
//	private String getSosikiCodeKaiso(Connection con, 
//		String shozokuCode, PCY_PersonalBean loginuser)
//		throws SQLException {
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
	private String getSosikiCodeKaiso(Connection con, 
		String shozokuCode, String loginSosikiCode, String loginNo)
		throws SQLException {
// ADD 2010/03/18 COMTURE BAK1-002 END

		PreparedStatement ps = null;
		ResultSet rs = null;
// DEL 2010/03/18 COMTURE BAK1-002 START
//		String loginNo = loginuser.getSimeiNo();
// DEL 2010/03/18 COMTURE BAK1-002 END
		
		try {
			// ���\�b�h�g���[�X�o�� 
			Log.method(loginNo, "IN", "");

			StringBuffer sql = new StringBuffer();
			
			// ���������̍쐬
			sql.append("SELECT KAISOU ");
			sql.append("FROM T19_SOSIKI_TBL ");
			sql.append("WHERE SOSIKI_CODE = ?");

			Log.debug(sql.toString());
			ps = con.prepareStatement(sql.toString());
			
			// �p�����[�^�Z�b�g
			if ((shozokuCode != null 
					&& !shozokuCode.equals(""))) {
				ps.setString(1, shozokuCode);
			} else {
// DEL 2010/03/18 COMTURE BAK1-002 START
//				ps.setString(1, loginuser.getSosikiCode());
// DEL 2010/03/18 COMTURE BAK1-002 END
// ADD 2010/03/18 COMTURE BAK1-002 START
				ps.setString(1, loginSosikiCode);
// ADD 2010/03/18 COMTURE BAK1-002 END
			}
			
			// �������s
			rs = ps.executeQuery();
			
			String kaiso = null;

			while (rs.next()) {
				kaiso = rs.getString("KAISOU");
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginNo, "OUT", "");

			return kaiso;

		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);
		}
	}
	
// DEL 2010/02/24 COMTURE PB-014,PB-016 START
//    /**
//     * �o���h�ʕK�{�u���̑ΏێЈ������擾����B
//	 * 
//	 * @param con �R�l�N�V����
//	 * @param loginuser ���O�C�����[�U���
//	 * @apram kamokuBean �ȖڃR�[�h
//	 * @return �o���h�ʕK�{�u���̑ΏێЈ����
//	 * 
//	 * @exception SQLException SQL�G���[�����������ꍇ
//	 */
//	private PCY_PersonalBean[] getBandTargetPersonList(Connection con, 
//		PCY_PersonalBean[] personalBeans,PCY_PersonalBean loginuser,
//		PCY_KamokuBean kamokuBean) throws SQLException {
//
//		PreparedStatement ps = null;
//		ResultSet rs = null;
//		String loginNo = loginuser.getSimeiNo();
//
//		try {
//			// ���\�b�h�g���[�X�o�� 
//			Log.method(loginNo, "IN", "");
//
//			StringBuffer sql = new StringBuffer();
//			
//			// ���������̍쐬
//			sql.append("SELECT DISTINCT PERSONAL.SIMEI_NO AS SIMEI_NO,");
//			sql.append(" PERSONAL.SOSIKI_CODE AS SOSIKI_CODE");
//			sql.append("  FROM");
//			sql.append(" T01_PERSONAL_TBL PERSONAL,");
//			sql.append(" L01_KAMOKU_TBL KAMOKU,");
//			sql.append(" L71_HISSU_SUISYO_KOUZA_TBL HISSUKOUZA");
//			sql.append(" WHERE");
//			sql.append(" KAMOKU.KAMOKU_CODE = ?");
//			sql.append(" AND KAMOKU.CATEGORY_CODE2 = HISSUKOUZA.CATEGORY_CODE");
//			sql.append(" AND (HISSUKOUZA.KAISI_BAND <= PERSONAL.SYOKUI_CODE");
//			sql.append(" OR HISSUKOUZA.KAISI_BAND IS NULL)");
//			sql.append(" AND (HISSUKOUZA.SYURYO_BAND >= PERSONAL.SYOKUI_CODE");
//			sql.append(" OR HISSUKOUZA.SYURYO_BAND IS NULL)");
//			sql.append(" AND PERSONAL.HONMU_FLG = ?");
//			sql.append(" AND PERSONAL.GENSYOKU_TAISYOKU_FLG = ?");
//			sql.append(" ORDER BY SOSIKI_CODE, SIMEI_NO");
//
//			Log.debug(sql.toString());
//			ps = con.prepareStatement(sql.toString());
//			
//			// �p�����[�^�Z�b�g
//			ps.setString(1, kamokuBean.getKamokuCode());
//			ps.setString(2, "1");
//			ps.setString(3, "1");
//			
//			// �������s
//			rs = ps.executeQuery();
//			
//			ArrayList personlBeanList = new ArrayList();
//
//			while (rs.next()) {
//				PCY_PersonalBean targetPersonalBean = new PCY_PersonalBean();
//				targetPersonalBean.setSimeiNo(rs.getString("SIMEI_NO"));
//				targetPersonalBean.setSosikiCode(rs.getString("SOSIKI_CODE"));
//				
//				// �I���������Ј�����i�荞��
//				for (int i = 0 ; i < personalBeans.length ; i++)  {
//					if (personalBeans[i].getSimeiNo().equals(targetPersonalBean.getSimeiNo())){
//						personlBeanList.add(personalBeans[i]);
//					} 
//				}
//			}
//
//			// ���\�b�h�g���[�X�o��
//			Log.method(loginNo, "OUT", "");
//
//			return (PCY_PersonalBean[])personlBeanList.toArray(new PCY_PersonalBean[0]);
//
//		} finally {
//			PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);
//		}
//	}	
//	
//    /**
//     * �ΏێҎw��K�{�u���̑ΏێЈ������擾����B
//	 * 
//	 * @param con �R�l�N�V����
//	 * @param loginuser ���O�C�����[�U���
//	 * @apram kamokuBean �ȖڃR�[�h
//	 * @return �o���h�ʕK�{�u���̑ΏێЈ����
//	 * 
//	 * @exception SQLException SQL�G���[�����������ꍇ
//	 */
//	private PCY_PersonalBean[] getTaisyosyaSiteiPersonList(Connection con, 
//		PCY_PersonalBean[] personalBeans, PCY_PersonalBean loginuser, 
//		PCY_KamokuBean kamokuBean) throws SQLException {
//
//		PreparedStatement ps = null;
//		ResultSet rs = null;
//		String loginNo = loginuser.getSimeiNo();
//		
//		try {
//			// ���\�b�h�g���[�X�o�� 
//			Log.method(loginNo, "IN", "");
//
//			StringBuffer sql = new StringBuffer();
//			
//			// ���������̍쐬
//			sql.append("SELECT DISTINCT PERSONAL.SIMEI_NO AS SIMEI_NO,");
//			sql.append(" PERSONAL.SOSIKI_CODE AS SOSIKI_CODE");
//			sql.append("  FROM");
//			sql.append(" T01_PERSONAL_TBL PERSONAL,");
//			sql.append(" L14_TAISYOSYA_TBL TAISYOSYA");
//			sql.append(" WHERE");
//			sql.append(" TAISYOSYA.KAMOKU_CODE = ?");
//			sql.append(" AND PERSONAL.SIMEI_NO = TAISYOSYA.SIMEI_NO");
//			sql.append(" AND TAISYOSYA.TAISYO_KUBUN = ?");
//			sql.append(" AND PERSONAL.HONMU_FLG = ?");
//			sql.append(" AND PERSONAL.GENSYOKU_TAISYOKU_FLG = ?");
//			sql.append(" ORDER BY SOSIKI_CODE, SIMEI_NO");
//
//			Log.debug(sql.toString());
//			ps = con.prepareStatement(sql.toString());
//			
//			// �p�����[�^�Z�b�g
//			ps.setString(1, kamokuBean.getKamokuCode());
//			ps.setString(2, "0");
//			ps.setString(3, "1");
//			ps.setString(4, "1");
//			
//			// �������s
//			rs = ps.executeQuery();
//			
//			ArrayList personlBeanList = new ArrayList();
//
//			while (rs.next()) {
//				PCY_PersonalBean targetPersonalBean = new PCY_PersonalBean();
//				targetPersonalBean.setSimeiNo(rs.getString("SIMEI_NO"));
//				targetPersonalBean.setSosikiCode(rs.getString("SOSIKI_CODE"));
//				
//				// �I���������Ј�����i�荞��
//				for (int i = 0 ; i < personalBeans.length ; i++)  {
//					if (personalBeans[i].getSimeiNo().equals(targetPersonalBean.getSimeiNo())){
//						personlBeanList.add(personalBeans[i]);
//					} 
//				}
//			}
//
//			// ���\�b�h�g���[�X�o��
//			Log.method(loginNo, "OUT", "");
//
//			return (PCY_PersonalBean[])personlBeanList.toArray(new PCY_PersonalBean[0]);
//
//		} finally {
//			PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);
//		}
//	}
//	
//	/**
//	 * �e�K�{�u���̉ȖڃR�[�h���擾����B
//	 * 
//	 * @param con �R�l�N�V����
//	 * @param hissuKoza �K�{�u��
//	 * @param loginuser ���O�C�����[�U���
//	 * @param kubun �u���̎��
//	 * @param startDate �N�x�̊J�n��
//	 * @param endDate �N�x�̏I����
//	 * @return �ȖڃR�[�h�̃��X�g
//	 * 
//	 * @exception SQLException SQL�G���[�����������ꍇ
//	 * 
//	 */
//	private ArrayList getEachHissuKamokuCodeList(Connection con, 
//		String hissuKoza,PCY_PersonalBean loginuser,
//		String kubun, String startDate,String endDate, boolean allFlg)
//		throws SQLException {
//
//		PreparedStatement ps = null;
//		ResultSet rs = null;
//		String loginNo = loginuser.getSimeiNo();
//
//		try {
//			// ���\�b�h�g���[�X�o��
//			Log.method(loginNo, "IN", "kubun:" + kubun);
//
//			// �K�{�u���̉ȖڃR�[�h���X�g
//			ArrayList kouzaList = new ArrayList();
//			
//			// �p�����[�^�̃��X�g
//			ArrayList paramList = new ArrayList();
//
//			StringBuffer sql = new StringBuffer();
//			sql.append("SELECT DISTINCT KAMOKU.KAMOKU_CODE AS KAMOKU_CODE,");
//			sql.append(" KAMOKU.KAMOKU_MEI1 AS KAMOKU_MEI,");
//			sql.append(" HISSUSUISYO.KUBUN AS KUBUN");
//			sql.append(" FROM L01_KAMOKU_TBL KAMOKU");
//			sql.append(", L71_HISSU_SUISYO_KOUZA_TBL HISSUSUISYO");
//			
//			if (BAND_HISSU.equals(kubun)) {
//				sql.append(", L02_CLASS_TBL CLASS");
//			}
//			
//			if (TAISHOSYA_HISSU.equals(kubun)) {
//				sql.append(", L14_TAISYOSYA_TBL TAISYOSYA");
//			}
//
//			// ������
//			StringBuffer where = new StringBuffer();
//			
//			// �K�{�u�����ށu�S�āv�I����
//			if (allFlg) {
//				where.append(" WHERE HISSUSUISYO.KUBUN = ?");
//				paramList.add(kubun);
//			
//			} else {
//				where.append(" WHERE KAMOKU.CATEGORY_CODE2 = ?");
//				paramList.add(hissuKoza);
//			}
//			
//			where.append(" AND KAMOKU.CATEGORY_CODE2 = HISSUSUISYO.CATEGORY_CODE");
//			
//			if (BAND_HISSU.equals(kubun)) {
//				where.append(" AND KAMOKU.KAMOKU_CODE = CLASS.KAMOKU_CODE");
//				where.append(" AND TO_DATE(CLASS.KAISIBI) BETWEEN TO_DATE(?) AND TO_DATE(?)");
//			} else {
//				where.append(" AND TO_DATE(KAMOKU.TOUROKUBI) BETWEEN TO_DATE(?) AND TO_DATE(?)");
//			}
//			paramList.add(startDate);
//			paramList.add(endDate);
//			
//			if (TAISHOSYA_HISSU.equals(kubun)) {
//				where.append(" AND TAISYOSYA.TAISYO_KUBUN = ?");
//				paramList.add("0");
//				where.append(" AND TAISYOSYA.KAMOKU_CODE = KAMOKU.KAMOKU_CODE");
//			}
//			
//			where.append(" ORDER BY KAMOKU_CODE");
//
//			// WHERE���A��
//			sql.append(where.toString());
//			
//			// �f�o�b�O���O
//			Log.debug(sql.toString());
//			ps = con.prepareStatement(sql.toString());
//
//			// �p�����[�^�̐ݒ�
//			for (int i = 0; i < paramList.size(); i++) {
//				ps.setString(i + 1, (String) paramList.get(i));
//			}
//
//			// �������s
//			rs = ps.executeQuery();
//
//			PCY_HissuSuisyoKouzaBean hissuKouzaBean = null;
//
//			while (rs.next()) {
//				hissuKouzaBean = new PCY_HissuSuisyoKouzaBean();
//				hissuKouzaBean.setKamokuCode(rs.getString("KAMOKU_CODE"));
//				hissuKouzaBean.setKamokuMei(rs.getString("KAMOKU_MEI"));
//				hissuKouzaBean.setKubun(rs.getString("KUBUN"));
//
//				kouzaList.add(hissuKouzaBean);
//			}
//
//			// ���\�b�h�g���[�X�o�� 
//			Log.method(loginNo, "OUT", "kubun:" + kubun);
//
//			return kouzaList;
//
//		} finally {
//			PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);
//		}
//	}
//
//	/**
//	 * ����NO�A�ȖڃR�[�h���L�[�Ɍ��C����(L51)���擾����B
//	 *
//     * @param con �R�l�N�V����
//	 * @param classBean �N���X���
//	 * @param loginuser ���O�C�����[�U���
//	 * @return kensyuRireki �K�{�̌��C����
//	 * 
//	 * @exception SQLException SQL�G���[�����������ꍇ
//	 * 
//	 */
//	private PCY_KensyuRirekiBean[] getKensyuRirekiList(Connection con, 
//		String kamokuCode, PCY_PersonalBean loginuser, String userId) 
//		throws SQLException{
//
//		PreparedStatement ps = null;
//		ResultSet rs = null;
//		String loginNo = loginuser.getSimeiNo();
//
//		try {
//			// ���\�b�h�g���[�X�o�� 
//			Log.method(loginNo, "IN", "");
//
//			StringBuffer sql = new StringBuffer();
//			sql.append("SELECT *");
//			sql.append(" FROM");
//			sql.append(" L51_KYOIKU_TBL RIREKI");
//			sql.append(" WHERE RIREKI.SIMEI_NO = ?");
//			sql.append(" AND RIREKI.KAMOKU_CODE = ?");
//			
//			// �f�o�b�O���O
//			Log.debug(sql.toString());
//			ps = con.prepareStatement(sql.toString());
//
//			// �p�����[�^��ݒ肷��B
//			ps.setString(1, userId);
//			ps.setString(2, kamokuCode);
//
//			// �������s
//			rs = ps.executeQuery();
//
//			ArrayList rirekiList = new ArrayList();
//
//			while (rs.next()) {
//				rirekiList.add(new PCY_KensyuRirekiBean(rs, null));
//			}
//
//			// ���\�b�h�g���[�X�o��
//			Log.method(loginNo, "OUT", "");
//
//			return (PCY_KensyuRirekiBean[])rirekiList.toArray(new PCY_KensyuRirekiBean[0]);
//			
//		} finally {
//			PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);
//		}
//	}
//	
//	/**
//	 * �e�K�{�u���̕\�����ڂ��擾����B
//	 * 
//     * @param con �R�l�N�V����
//	 * @param personalBeans �ΏێЈ�
//	 * @param kamokuBean �ȖڃR�[�h
//	 * @param kubun �K�{�u���敪
//	 * @param loginuser ���O�C���Ј�
//	 * @return �K�{��u�󋵈ꗗ
//	 * 
//	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
//	 * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
//	 * @exception CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
//	 * @exception SQLException SQL�G���[�����������ꍇ
//	 */
//	private ArrayList getHyojiKoumokuList (Connection con, PCY_PersonalBean[] personalBeans,
//		PCY_KamokuBean kamokuBean,String kubun, PCY_PersonalBean loginuser)
//		throws NamingException, SQLException {
//		
//		// ���\�b�h�g���[�X�o��
//		Log.method(loginuser.getSimeiNo(), "IN", "kubun:" + kubun);
//		
//		// �K�{��u�󋵈ꗗ
//		ArrayList hissuJukouJyokyoList = new ArrayList();
//		
//		PCY_SoshikiJukouJyokyoRowBean rowBean = null;
//		
//		// �Ј����Ƃɕ\�����ڂ��擾
//		for (int j = 0 ; j < personalBeans.length ; j++) {
//			
//			PCY_PersonalBean personalBean = personalBeans[j];
//
//			rowBean = new PCY_SoshikiJukouJyokyoRowBean();
//			
//			// ����No�A�����A�g�D�R�[�h�A�g�D���́A�u�����A�K�{�敪��ݒ�
//			rowBean.setPersonCode(personalBean.getSimeiNo());
//			rowBean.setPersonName(personalBean.getKanjiSimei());
//			rowBean.setShozokuCode(personalBean.getSosikiCode());
//			rowBean.setShozokuName(personalBean.getBusyoRyakusyoMei());
//			rowBean.setHissuKubun(kubun);
//			
//			// ��u����ݒ肷��
//			rowBean.setKamokuCode(kamokuBean.getKamokuCode());
//			rowBean.setKamokuName(kamokuBean.getKamokuMei1());
//			rowBean.setKamokuExist(true);
//			rowBean.setClassExist(false);
//			
//			// ��Ԃ�ݒ肷��
//			// �����ݒ�
//			rowBean.setStatus("���\��");
//			
//			String status = getStatus(con, kamokuBean.getKamokuCode(), kubun, 
//										personalBean.getSimeiNo(), loginuser, null);
//			
//			if (status != null) {
//				rowBean.setStatus(status);
//			}
//			
//			// �e�Ј��̎�u�󋵂�ǉ�����
//			hissuJukouJyokyoList.add(rowBean);
//		}
//		
//		// ���\�b�h�g���[�X�̏o��
//		Log.method(loginuser.getSimeiNo(), "OUT", "kubun:" + kubun);
//		
//		return hissuJukouJyokyoList;
//	}
//	
//	/**
//	 * �S�Ј��K�{�i�N�P��ȏ�j�̕\�����ڂ��擾����B
//	 * 
//     * @param con �R�l�N�V����
//	 * @param personalBeans �ΏێЈ�
//	 * @param kamokuBean �ȖڃR�[�h
//	 * @param kubun �K�{�u���敪
//	 * @param hissuJukouJyokyoList �K�{��u�󋵈ꗗ
//	 * @param loginuser ���O�C���Ј�
//	 * @return �K�{��u�󋵈ꗗ
//	 * 
//	 * @exception SQLException SQL�G���[�����������ꍇ
//	 */
//	private ArrayList getZensya1ijoHyojiKoumokuList (Connection con, 
//		PCY_PersonalBean[] personalBeans, ArrayList zensya1ijoList,
//		String kubun, PCY_PersonalBean loginuser) 
//	    throws SQLException {
//		
//		// ���\�b�h�g���[�X�o��
//		Log.method(loginuser.getSimeiNo(), "IN", "kubun:" + kubun);
//		
//		ArrayList hissuJukouJyokyoList = new ArrayList();
//		
//		PCY_SoshikiJukouJyokyoRowBean rowBean = null;
//		
//		// �Ј����Ƃɕ\�����ڂ��擾
//		for (int i = 0 ; i < personalBeans.length ; i++) {
//			
//			PCY_PersonalBean personalBean = personalBeans[i];
//
//			rowBean = new PCY_SoshikiJukouJyokyoRowBean();
//			
//			// ����No�A�����A�g�D�R�[�h�A�g�D���́A�u�����A�K�{�敪��ݒ�
//			rowBean.setPersonCode(personalBean.getSimeiNo());
//			rowBean.setPersonName(personalBean.getKanjiSimei());
//			rowBean.setShozokuCode(personalBean.getSosikiCode());
//			rowBean.setShozokuName(personalBean.getBusyoRyakusyoMei());
//			rowBean.setKamokuName((String)ReadFile.paramMapData.get("DZY247"));
//			rowBean.setHissuKubun(kubun);
//			rowBean.setKamokuExist(false);
//			rowBean.setClassExist(false);
//				
//			if (zensya1ijoList.size() > 0) {
//				// �����ݒ�
//				rowBean.setStatus("���\��");
//				
//				for (int j = 0 ; j < zensya1ijoList.size() ; j++) {
//						
//					PCY_KamokuBean tempKamokuBean = (PCY_KamokuBean)zensya1ijoList.get(j);
//					
//					// ��Ԃ̎擾
//					String status = getStatus(con, tempKamokuBean.getKamokuCode(), kubun,
//										personalBean.getSimeiNo(), loginuser, rowBean.getStatus());
//					
//					if (status != null) {
//						rowBean.setStatus(status);
//						
//						if (status.equals("��u��")) {
//							break;
//						}
//					}
//				}
//				
//			} else {
//				rowBean.setStatus("");
//			}
//			
//			// �e�Ј��̎�u�󋵂�ǉ�����
//			hissuJukouJyokyoList.add(rowBean);
//		}
//		
//		// ���\�b�h�g���[�X�o��
//		Log.method(loginuser.getSimeiNo(), "OUT", "kubun:" + kubun);
//		
//		return hissuJukouJyokyoList;
//	}
//
//	/**
//	 * �e�K�{�u���̏�Ԃ��擾����B
//	 * 
//	 * @param con �R�l�N�V����
//	 * @param kamokuCode �ȖڃR�[�h
//	 * @param kubun �K�{�E�����u���敪
//	 * @param userId �ΏێЈ�
//	 * @param loginuser ���O�C�����[�U���
//	 * 
//	 * @exception SQLException SQL�G���[�����������ꍇ
//	 */
//	private String getStatus (Connection con, String kamokuCode, String kubun,
//		String userId, PCY_PersonalBean loginuser, String status) 
//		throws SQLException{
//		
//		// ���\�b�h�g���[�X�o��
//		Log.method(loginuser.getSimeiNo(), "IN", "kubun:" + kubun);		
//		
//		// ��ԃt���O
//		String statusFlg = null;
//		
//		// L51_���猤�C���̊m�F
//		PCY_KensyuRirekiBean[] rirekiBeans 
//				= getKensyuRirekiList(con, kamokuCode, loginuser, userId);
//		
//		for (int i = 0 ; i < rirekiBeans.length ; i++) {
//			
//			PCY_KensyuRirekiBean kensyuBean = rirekiBeans[i];
//			
//			// �C������t���O��1(=�C��)�܂��́A2(=�F��)�̏ꍇ
//			if ("1".equals(kensyuBean.getSyuryoHantei()) 
//					|| "2".equals(kensyuBean.getSyuryoHantei())) {
//				return "��u��";
//			
//			// �C������t���O��0(=���C��)
//			} else if ("0".equals(kensyuBean.getSyuryoHantei())) {
//				if (ZENSYA_HISSU_1IJO.equals(kubun) && "�\����".equals(status)) {
//					statusFlg = status;
//				} else {
//					statusFlg = "���C��";
//				}
//			}
//		}
//		
//		if (BAND_HISSU.equals(kubun)) {
//			// T05���猤�C���̊m�F
//			ArrayList syuryoFlgList = getSyuryoHanteiFlg(con, userId, kamokuCode, loginuser);
//			
//			for (int i = 0 ; i < syuryoFlgList.size() ; i++) {
//				String syuryoFlg = (String)syuryoFlgList.get(i);
//				
//				// �C������t���O��1(=�C��)�܂��́A2(=�F��)�̏ꍇ
//				if ("1".equals(syuryoFlg) || "2".equals(syuryoFlg)) {
//					return "��u��";
//				}
//			}
//		}
//		
//		// L15_�\���󋵂̊m�F
//		PCY_MousikomiJyokyoBean[] mousikomiBeans 
//				= getMousikomiJyokyoList(con, userId, kamokuCode, loginuser);
//
//		if (mousikomiBeans.length > 0) {
//			return "�\����";
//		}
//		
//		// ���\�b�h�g���[�X�o��
//		Log.method(loginuser.getSimeiNo(), "OUT", "kubun:" + kubun);
//		
//		return statusFlg;
//	}
//	
//	/**
//	 * T05_���猤�C������C��������擾����B
//	 * 
//     * @param con �R�l�N�V����
//	 * @param targetPerson �ΏێЈ�
//	 * @param kamokuBean �ȖڃR�[�h
//	 * @param personalBean ���O�C���Ј�
//	 * @return �C������t���O���X�g
//	 *
//	 * @exception SQLException SQL�G���[�����������ꍇ
//	 */
//	private ArrayList getSyuryoHanteiFlg (Connection con, String userId,
//		String kamokuCode, PCY_PersonalBean loginuser)
//		throws SQLException {
//		
//		PreparedStatement ps = null;
//		ResultSet rs = null;
//		String loginNo = loginuser.getSimeiNo();
//
//		try {
//			// ���\�b�h�g���[�X�o�� 
//			Log.method(loginNo, "IN", "");
//
//			StringBuffer sql = new StringBuffer();
//			sql.append("SELECT SYURYO_HANTEI");
//			sql.append(" FROM T05_KYOIKU_TBL");
//			sql.append(" WHERE SIMEI_NO = ?");
//			sql.append(" AND KAMOKU_CODE = ?");
//
//			// �f�o�b�O���O
//			Log.debug(sql.toString());
//			ps = con.prepareStatement(sql.toString());
//
//			// �p�����[�^��ݒ肷��B
//			ps.setString(1, userId);
//			ps.setString(2, kamokuCode);
//
//			// �������s
//			rs = ps.executeQuery();
//
//			ArrayList syuryoList = new ArrayList();
//			
//			while (rs.next()) {
//				String syuryoHantei = (String)rs.getString("SYURYO_HANTEI");
//				syuryoList.add(syuryoHantei);
//			}
//
//			// ���\�b�h�g���[�X�o�� 
//			Log.method(loginNo, "OUT", "");
//
//			return syuryoList;
//			
//		} finally {
//			PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);
//		}
//	}
//	
//	/**
//	 * �ΏێЈ��̐\�����ꗗ���擾����
//	 * 
//     * @param con �R�l�N�V����
//     * @param mousikomiBean ��������
//     * @param loginuser ���O�C�����[�U���
//     * @return �\�����ꗗ
//     * 
//	 * @exception SQLException SQL�G���[�����������ꍇ
//     */
//    private PCY_MousikomiJyokyoBean[] getMousikomiJyokyoList(Connection con, String userId,
//    	String kamokuCode, PCY_PersonalBean loginuser)
//    	throws SQLException {
//        
//        PreparedStatement ps = null;
//        ResultSet rs = null;
//        String loginNo = loginuser.getSimeiNo();
//
//        try {
//            // ���\�b�h�g���[�X�o��
//            Log.method(loginNo, "IN", "" );
//
//            StringBuffer sql = new StringBuffer();
//            sql.append("SELECT *");
//            sql.append(" FROM");
//            sql.append(" L15_MOUSIKOMI_JYOKYO_TBL");
//            sql.append(" WHERE SIMEI_NO = ?");
//            sql.append(" AND KAMOKU_CODE = ?");
//
//            // �f�o�b�O���O
//			Log.debug(sql.toString());
//            ps = con.prepareStatement(sql.toString());
//			
//            ps.setString(1, userId);
//            ps.setString(2, kamokuCode);
//			
//            // �������s
//            rs = ps.executeQuery();
//            
//            ArrayList ret = new ArrayList();
//            
//            while (rs.next()) {
//                ret.add(new PCY_MousikomiJyokyoBean(rs, null));
//            }
//
//            // ���\�b�h�g���[�X�o��
//            Log.method(loginNo, "OUT", "" );
//
//            return (PCY_MousikomiJyokyoBean[])ret.toArray(new PCY_MousikomiJyokyoBean[0]);
//
//        } finally {
//        	PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);
//        }
//    }
//
//	/**
//	 * �K�{�u���ȖڃR�[�h�̃\�[�g�L�[���w�肷��N���X
//	 * 
//	 * PCY_HissuKouzaBean�̔z����\�[�g���܂� 
//	 *  �E��P�\�[�g�L�[ �K�{�A�����敪 
//	 *  �E��Q�\�[�g�L�[ �ȖڃR�[�h
//	 */
//	private class hissuKouzaComparator implements Comparator {
//		public int compare(Object o1, Object o2) {
//			PCY_HissuSuisyoKouzaBean hissu1 = (PCY_HissuSuisyoKouzaBean) o1;
//			PCY_HissuSuisyoKouzaBean hissu2 = (PCY_HissuSuisyoKouzaBean) o2;
//
//			int ret = 0;
//
//			// ��P�\�[�g�L�[ �K�{�E�����敪 
//			if ((hissu1.getKubun() != null) && (hissu2.getKubun() != null)) {
//				ret = hissu1.getKubun().compareTo(hissu2.getKubun());
//			} else if ((hissu1.getKubun() == null)
//					&& (hissu2.getKubun() != null)) {
//				return 1;
//			} else if ((hissu1.getKubun() != null)
//					&& (hissu2.getKubun() == null)) {
//				return -1;
//			}
//
//			if (ret != 0) {
//				return ret;
//			}
//
//			// ��Q�\�[�g�L�[ �ȖڃR�[�h 
//			if ((hissu1.getKamokuCode() != null)
//					&& (hissu2.getKamokuCode() != null)) {
//				ret = hissu1.getKamokuCode().compareTo(hissu2.getKamokuCode());
//			} else if ((hissu1.getKamokuCode() == null)
//					&& (hissu2.getKamokuCode() != null)) {
//				return 1;
//			} else if ((hissu1.getKamokuCode() != null)
//					&& (hissu2.getKamokuCode() == null)) {
//				return -1;
//			}
//
//			if (ret != 0) {
//				return ret;
//			}
//
//			return ret;
//		}
//	}
// DEL 2010/02/24 COMTURE PB-014,PB-016 END
	
    /**
     * �\�[�g�L�[���w�肷��N���X
     *
     * PCY_SoshikiJukouJyokyoRowBean�̔z����\�[�g���܂�
     * 
     *  �E��P�\�[�g�L�[ �K�{�E�����u���敪
     *  �E��Q�\�[�g�L�[ �ȖڃR�[�h
     *  �E��R�\�[�g�L�[ ���
     *  �E��S�\�[�g�L�[ �g�D�R�[�h
     *  �E��T�\�[�g�L�[ ����No
     */
    private class hissuJukouJyokyoComparator implements Comparator {
        
    	public int compare(Object o1, Object o2) {
          PCY_SoshikiJukouJyokyoRowBean rowBean1 = (PCY_SoshikiJukouJyokyoRowBean)o1;
          PCY_SoshikiJukouJyokyoRowBean rowBean2 = (PCY_SoshikiJukouJyokyoRowBean)o2;

          int ret = 0;

          // ��P�\�[�g�L�[ �K�{�E�����u���敪 
          if ((rowBean1.getHissuKubun() != null) && (rowBean2.getHissuKubun() != null)) {
              ret = rowBean1.getHissuKubun().compareTo(rowBean2.getHissuKubun());
          } else if ((rowBean1.getHissuKubun() == null) && (rowBean2.getHissuKubun() != null)) {
              return 1;
          } else if ((rowBean1.getHissuKubun() != null) && (rowBean2.getHissuKubun() == null)) {
              return -1;
          }

          if (ret != 0) {
              return ret;
          }

          // ��Q�\�[�g�L�[ �ȖڃR�[�h
          if ((rowBean1.getKamokuCode() != null) && (rowBean2.getKamokuCode() != null)) {
              ret = rowBean1.getKamokuCode().compareTo(rowBean2.getKamokuCode());
          } else if ((rowBean1.getKamokuCode() == null) && (rowBean2.getKamokuCode() != null)) {
              return 1;
          } else if ((rowBean1.getKamokuCode() != null) && (rowBean2.getKamokuCode() == null)) {
              return -1;
          }

          if (ret != 0) {
              return ret;
          }

// DEL 2010/03/18 COMTURE BAK1-004 START
//          // ��R�\�[�g�L�[ ��� 
//          if ((rowBean1.getStatus() != null) && (rowBean2.getStatus() != null)) {
//        	  
//        	  if (rowBean1.getStatus().equals("���\��")){
//        		  
//        		  if (rowBean2.getStatus().equals("���\��")) {
//        			  return 0;
//        		  } else {
//        			  return -1;
//        		  }
//        	  } else if (rowBean1.getStatus().equals("���C��")) {
//        		  
//        		  if (rowBean2.getStatus().equals("���\��")) {
//        			  return 1;
//        		  } else if (rowBean2.getStatus().equals("���C��")) {
//        			  return 0;
//        		  } else {
//        			  return -1;
//        		  }
//        	 
//        	  } else if (rowBean1.getStatus().equals("�\����")) {
//        		  
//        		  if (rowBean2.getStatus().equals("���\��")) {
//        			  return 1;
//        		  } else if (rowBean2.getStatus().equals("���C��")) {
//        			  return 1;
//        		  } else if (rowBean2.getStatus().equals("�\����")) {
//        			  return 0;
//        		  } else {
//        			  return -1;
//        		  }
//        	  } else if (rowBean1.getStatus().equals("��u��")) {
//        		  
//        		  if (rowBean2.getStatus().equals("���\��")) {
//        			  return 1;
//        		  } else if (rowBean2.getStatus().equals("���C��")) {
//            		  return 1;
//        		  } else if (rowBean2.getStatus().equals("�\����")) {
//        			  return 1;
//        		  } else if (rowBean2.getStatus().equals("��u��")) {
//        			  return 0;
//        		  } else {
//        			  return -1;
//        		  }
//        		  
//        	  } else if (rowBean1.getStatus().equals("")) {
//        		  if (rowBean2.getStatus().equals("")) {
//        			  return 0;
//        		  } else {
//        			  return 1;
//        		  }
//        	  }
//        	  
//          } else if ((rowBean1.getKamokuCode() == null) && (rowBean2.getKamokuCode() != null)) {
//              return 1;
//          } else if ((rowBean1.getKamokuCode() != null) && (rowBean2.getKamokuCode() == null)) {
//              return -1;
//          }
// DEL 2010/03/18 COMTURE BAK1-004 END
// ADD 2010/03/19 COMTURE BAK1-004 START
          // ��R�\�[�g�L�[ ��� 
          Integer statusSortNo1 = new Integer(getStatusSortNo(rowBean1.getStatus()));
          Integer statusSortNo2 = new Integer(getStatusSortNo(rowBean2.getStatus()));
          ret = statusSortNo1.compareTo(statusSortNo2);
// ADD 2010/03/19 COMTURE BAK1-004 END

          if (ret != 0) {
              return ret;
          }

          // ��S�\�[�g�L�[ �g�D�R�[�h 
          if ((rowBean1.getShozokuCode() != null) && (rowBean2.getShozokuCode() != null)) {
              ret = rowBean1.getShozokuCode().compareTo(rowBean2.getShozokuCode());
          } else if ((rowBean1.getShozokuCode() == null) && (rowBean2.getShozokuCode() != null)) {
              return 1;
          } else if ((rowBean1.getShozokuCode() != null) && (rowBean2.getShozokuCode() == null)) {
              return -1;
          }

          if (ret != 0) {
              return ret;
          }
          
          // ��T�\�[�g�L�[ ����No 
          if ((rowBean1.getPersonCode() != null) && (rowBean2.getPersonCode() != null)) {
              ret = rowBean1.getPersonCode().compareTo(rowBean2.getPersonCode());
          } else if ((rowBean1.getPersonCode() == null) && (rowBean2.getPersonCode() != null)) {
              return 1;
          } else if ((rowBean1.getPersonCode() != null) && (rowBean2.getPersonCode() == null)) {
              return -1;
          }

          if (ret != 0) {
              return ret;
          }

          return ret;
      }
// ADD 2010/03/19 COMTURE BAK1-004 START
    	// �X�e�[�^�X��������\�[�g�ԍ��ɕϊ�����
    	private int getStatusSortNo (String status) {
    		// NULL�͋󔒈����A�O�㔼�p�X�y�[�X��TRIM����
    		String tmpStatus = PZZ010_CharacterUtil.normalizedStr(status).trim();
    		
    		if ("���\��".equals(tmpStatus)) {
    			return 0;
    		}
    		if ("���C��".equals(tmpStatus)) {
    			return 1;
    		}
    		if ("�\����".equals(tmpStatus)) {
    			return 2;
    		}
    		if ("��u��".equals(tmpStatus)) {
    			return 3;
    		}
    		
    		return 4;
    	}
// ADD 2010/03/19 COMTURE BAK1-004 END
     }

	/**
	 * �N�x�̍ŏI�����擾����
	 * 
	 * @param String ���͓��t MMDD
	 * @param int �w��� X��
	 * @return String �o�͓��t MMDD
	 */
	private String getLastDate(String startDate, int date) {
		
		int intStartYY = java.lang.Integer.parseInt(startDate.substring(0, 4));
		int intStartMM = java.lang.Integer.parseInt(startDate.substring(4, 6));
		int intStartDD = java.lang.Integer.parseInt(startDate.substring(6, 8));
		GregorianCalendar gc = new GregorianCalendar(intStartYY,
				intStartMM - 1, intStartDD);
		gc.add(GregorianCalendar.DATE, date);
		int intTodayY = gc.get(GregorianCalendar.YEAR);
		int intTodayM = gc.get(GregorianCalendar.MONTH) + 1;
		int intTodayD = gc.get(GregorianCalendar.DAY_OF_MONTH);

		String strSdateYYYY = String.valueOf(intTodayY);

		String strSdateMM;
		if (intTodayM < 10) {
			strSdateMM = "0" + String.valueOf(intTodayM);
		} else {
			strSdateMM = String.valueOf(intTodayM);
		}

		String strSdateDD;
		if (intTodayD < 10) {
			strSdateDD = "0" + String.valueOf(intTodayD);
		} else {
			strSdateDD = String.valueOf(intTodayD);
		}

		// 1�N���Z����
		strSdateYYYY = String.valueOf(intTodayY + 1);

		return strSdateYYYY + strSdateMM + strSdateDD;
	}

	/**
	 * �V�X�e���p�����[�^���擾����
	 * 
	 * @param key 
	 * @return �擾�����l
	 */
	private String getSystemParameter(String key) {
		String value = (String) ReadFile.fileMapData.get(key);
		if (value == null) {
			value = new String();
		}
		return value;
	}
	
    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }
    
    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }
}
