/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/01/13  01.00       ���� �a��    �V�K�쐬
 *   2004/05/19  01.00       ���� �L��    �ėp�R�[�h�}�X�^�ւ̃A�N�Z�X�֐��쐬
 *   2004/06/20               ����@���V�@�@doInsert���\�b�h�@SQLException�������@EJBException���X���[����悤�ɏC��
 *   2004/06/23               ���� ���V    �g�D�}�X�^�ǉ�
 */
package jp.co.hisas.career.learning.base.ejb;

import jp.co.hisas.career.learning.base.PCY_DBUtils;
import jp.co.hisas.career.learning.base.PCY_ServiceLocator;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.valuebean.PCY_BaseCodeBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

import java.rmi.RemoteException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import javax.naming.NamingException;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_CodeEJBBean�N���X
 *
 * �@�\�����F
 *   �e��}�X�^����ꗗ���擾���܂��B
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PCY_CodeEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PCY_CodeEJBBean implements SessionBean {
    private static final String[][] tables = {
        { HcdbDef.p_kamoku_groupTbl, "KAMOKU_GROUP_CODE", "KAMOKU_GROUP" },
        { HcdbDef.L03_TBL, "CATEGORY_CODE1", "CATEGORY_MEI1" },
        { HcdbDef.L04_TBL, "CATEGORY_CODE2", "CATEGORY_MEI2" },
        { HcdbDef.L05_TBL, "CATEGORY_CODE3", "CATEGORY_MEI3" },
        { HcdbDef.L06_TBL, "CATEGORY_CODE4", "CATEGORY_MEI4" },
        { HcdbDef.L07_TBL, "CATEGORY_CODE5", "CATEGORY_MEI5" },
        { HcdbDef.L08_TBL, "KANRIMOTO_CODE", "KANRIMOTO_MEI" },
        { HcdbDef.L09_TBL, "CHIKU_CODE", "CHIKU_MEI" },
        { HcdbDef.L10_TBL, "KYOSITU_CODE", "KYOSITU_MEI" },
        { HcdbDef.L11_TBL, "KOUSI_CODE", "KOUSI_MEI" },
        { HcdbDef.p_kyoiku_kubunTbl, "KYOIKU_KUBUN_CODE", "KYOIKU_KUBUN" },
        { HcdbDef.sosikiTbl, "SOSIKI_CODE", "SOSIKI_MEI" },
        { HcdbDef.p_kamoku_groupTbl,"KAMOKU_GROUP_CODE","KAMOKU_GROUP" }
    };
    private SessionContext context = null;

    /**
     * �e��}�X�^����ꗗ���擾���AMap �Ɋi�[���ĕԂ��܂��B
     * �߂�l�̓}�X�^���ƃ}�X�^�̓��e�� Map �ŁA�}�X�^���e�́A�R�[�h�Ɩ��̂� Map �ł��B
     *
     * @return �e��}�X�^�̈ꗗ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public Map getCodeMaps(  ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            /*���\�b�h�g���[�X�o��*/
            Log.method( "", "IN", "" );

            Map ret                    = new HashMap(  );
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con                        = locator.getDataSource(  ).getConnection(  );

            for ( int i = 0; i < tables.length; i++ ) {
                ps = con.prepareStatement( "SELECT " + tables[i][1] + ", " + tables[i][2]
                        + " FROM " + tables[i][0] + " ORDER BY " + tables[i][1]);

                ResultSet rs = ps.executeQuery(  );
                Map code     = new LinkedHashMap(  );

                while ( rs.next(  ) ) {
                    code.put( rs.getString( tables[i][1] ), rs.getString( tables[i][2] ) );
                }

                rs.close(  ); // INS#P-ALH41-001-002
                ps.close(  ); // INS#P-ALH41-001-002
                ret.put( tables[i][0], code );
            }

            /*���\�b�h�g���[�X�o��*/
            Log.method( "", "OUT", "" );

            return ret;
        } catch ( NamingException e ) {
            Log.error( "", "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( "", "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( "", "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �e��R�[�h�}�X�^�̃f�[�^���Q�Ƃ��܂��B
     *
     * @param baseCodeBean PCY_BaseCodeBean �̌�������
     * @param lock true�̏ꍇ���b�N����Afalse�̏ꍇ���b�N�Ȃ�
     * @param loginuser ���O�C�����[�U
     * @return ��������
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_BaseCodeBean[] doSelect( PCY_BaseCodeBean baseCodeBean, boolean lock,
        PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        // map �쐬
        Map codeMap = new HashMap(  );
        Map nameMap = new HashMap(  );

        for ( int i = 0; i < tables.length; i++ ) {
            codeMap.put( tables[i][0], tables[i][1] );
            nameMap.put( tables[i][0], tables[i][2] );
        }

        try {
            String tabName = baseCodeBean.getCodeTableName(  );
            String codeCol = ( String )codeMap.get( tabName );
            String nameCol = ( String )nameMap.get( tabName );

            Collection ret   = new ArrayList(  );
            StringBuffer sql = new StringBuffer(  );
            sql.append( "SELECT " );
            sql.append( codeCol + ", " );
            sql.append( nameCol + ", " );
            sql.append( "        TOUROKUBI," );
            sql.append( "        TOUROKUJIKOKU," );
            sql.append( "        TOUROKUSYA," );
            sql.append( "        KOUSINBI," );
            sql.append( "        KOUSINJIKOKU," );
            sql.append( "        KOUSINSYA " );
            sql.append( "  FROM " );
            sql.append( tabName );
            sql.append( "  WHERE " );
            sql.append( codeCol + "=?" );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            //���b�N
            sql.append( PCY_DBUtils.getInstance(  ).getLock( lock ) );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            // �������s
            Log.debug( sql.toString(  ) );
            ps = con.prepareStatement( sql.toString(  ) );

            ps.setString( 1, baseCodeBean.getCode(  ) );

            ResultSet rs = ps.executeQuery(  );

            while ( rs.next(  ) ) {
                ret.add( new PCY_BaseCodeBean( rs, tabName, codeCol, nameCol ) );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ( PCY_BaseCodeBean[] )ret.toArray( new PCY_BaseCodeBean[0] );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �e��R�[�h�}�X�^�Ƀf�[�^��}�����܂��B
     *
     * @param baseCodeBeans �X�V����PCY_BaseCodeBean�̔z��
     * @param loginuser ���O�C�����[�U
     * @return �쐬����
    * @throws PCY_WarningException �C���T�[�g�� SQLException �����������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doInsert( PCY_BaseCodeBean[] baseCodeBeans, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        // map �쐬
        Map codeMap = new HashMap(  );
        Map nameMap = new HashMap(  );

        for ( int i = 0; i < tables.length; i++ ) {
            codeMap.put( tables[i][0], tables[i][1] );
            nameMap.put( tables[i][0], tables[i][2] );
        }

        try {
            String tabName = baseCodeBeans[0].getCodeTableName(  );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "INSERT INTO " );
            sql.append( tabName );
            sql.append( " (" );
            sql.append( ( String )codeMap.get( tabName ) + ", " );
            sql.append( ( String )nameMap.get( tabName ) + ", " );
            sql.append( "    TOUROKUBI, " );
            sql.append( "    TOUROKUJIKOKU, " );
            sql.append( "    TOUROKUSYA, " );
            sql.append( "    KOUSINBI, " );
            sql.append( "    KOUSINJIKOKU, " );
            sql.append( "    KOUSINSYA ) " );
            sql.append( "  VALUES ( ?, ?, ?, ?, ?, ?, ?, ? )" );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �}�����s
            ps = con.prepareStatement( sql.toString(  ) );

            int count = 0;

            for ( int i = 0; i < baseCodeBeans.length; i++ ) {
                ps.setString( 1, baseCodeBeans[i].getCode(  ) );
                ps.setString( 2, baseCodeBeans[i].getName(  ) );
                ps.setString( 3, PZZ010_CharacterUtil.GetDay(  ) );
                ps.setString( 4, PZZ010_CharacterUtil.GetTime(  ) );
                ps.setString( 5, loginuser.getSimeiNo(  ) );
                ps.setString( 6, "        " );
                ps.setString( 7, "      " );
                ps.setString( 8, "          " );
                count += ps.executeUpdate(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new PCY_WarningException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new PCY_WarningException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw new PCY_WarningException( e );
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �e��R�[�h�}�X�^�Ƀf�[�^��}�����܂��B
     *
     * @param baseCodeBean �}������PCY_BaseCodeBean
     * @param loginuser ���O�C�����[�U
     * @return �쐬����
    * @throws PCY_WarningException �C���T�[�g�� SQLException �����������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doInsert( PCY_BaseCodeBean baseCodeBean, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        return doInsert( new PCY_BaseCodeBean[] { baseCodeBean }, loginuser );
    }

    /**
     * �e��R�[�h�}�X�^����f�[�^���폜���܂��B
     *
     * @param baseCodeBeans �X�V����PCY_BaseCodeBean�̔z��
     * @param loginuser ���O�C�����[�U
     * @return �폜����
    * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍ폜����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doDelete( PCY_BaseCodeBean[] baseCodeBeans, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        // map �쐬
        Map codeMap = new HashMap(  );

        for ( int i = 0; i < tables.length; i++ ) {
            codeMap.put( tables[i][0], tables[i][1] );
        }

        try {
            String tabName = baseCodeBeans[0].getCodeTableName(  );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "DELETE FROM " );
            sql.append( tabName );
            sql.append( "  WHERE " );
            sql.append( ( String )codeMap.get( tabName ) + "=? " );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �폜���s
            ps = con.prepareStatement( sql.toString(  ) );

            int count = 0;

            for ( int i = 0; i < baseCodeBeans.length; i++ ) {
                ps.setString( 1, baseCodeBeans[i].getCode(  ) );
                count += ps.executeUpdate(  );
            }

            if ( baseCodeBeans.length != count ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new PCY_WarningException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new PCY_WarningException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw new PCY_WarningException( e );
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �e��R�[�h�}�X�^����f�[�^���폜���܂��B
     *
     * @param baseCodeBean �폜����PCY_BaseCodeBean
     * @param loginuser ���O�C�����[�U
     * @return �쐬����
    * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍ폜����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doDelete( PCY_BaseCodeBean baseCodeBean, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        return doDelete( new PCY_BaseCodeBean[] { baseCodeBean }, loginuser );
    }

    /**
     * �e��R�[�h�}�X�^�Ƀf�[�^���X�V���܂��B
     *
     * @param baseCodeBeans �X�V����PCY_BaseCodeBean�̔z��
     * @param currentBeans  �X�V�O��PCY_BaseCodeBean�̔z��
     * @param loginuser ���O�C�����[�U
     * @return �쐬����
    * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdate( PCY_BaseCodeBean[] baseCodeBeans, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        // map �쐬
        Map codeMap = new HashMap(  );
        Map nameMap = new HashMap(  );

        for ( int i = 0; i < tables.length; i++ ) {
            codeMap.put( tables[i][0], tables[i][1] );
            nameMap.put( tables[i][0], tables[i][2] );
        }

        try {
            String tabName = baseCodeBeans[0].getCodeTableName(  );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "UPDATE " );
            sql.append( tabName );
            sql.append( "    SET " );
            sql.append( ( String )nameMap.get( tabName ) + "=?, " );
            sql.append( "        KOUSINBI=?," );
            sql.append( "        KOUSINJIKOKU=?," );
            sql.append( "        KOUSINSYA=? " );
            sql.append( "  WHERE " );
            sql.append( ( String )codeMap.get( tabName ) + "=? " );
            sql.append( "    AND TOUROKUBI=?" );
            sql.append( "    AND TOUROKUJIKOKU=?" );
            sql.append( "    AND TOUROKUSYA=?" );
            sql.append( "    AND KOUSINBI=?" );
            sql.append( "    AND KOUSINJIKOKU=?" );
            sql.append( "    AND KOUSINSYA=?" );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �}�����s
            ps = con.prepareStatement( sql.toString(  ) );

            int count = 0;

            for ( int i = 0; i < baseCodeBeans.length; i++ ) {
                ps.setString( 1, baseCodeBeans[i].getName(  ) );
                ps.setString( 2, PZZ010_CharacterUtil.GetDay(  ) );
                ps.setString( 3, PZZ010_CharacterUtil.GetTime(  ) );
                ps.setString( 4, loginuser.getSimeiNo(  ) );
                ps.setString( 5, baseCodeBeans[i].getCode(  ) );
                ps.setString( 6, baseCodeBeans[i].getTourokubi(  ) );
                ps.setString( 7, baseCodeBeans[i].getTourokujikoku(  ) );
                ps.setString( 8, baseCodeBeans[i].getTourokusya(  ) );
                ps.setString( 9, baseCodeBeans[i].getKousinbi(  ) );
                ps.setString( 10, baseCodeBeans[i].getKousinjikoku(  ) );
                ps.setString( 11, baseCodeBeans[i].getKousinsya(  ) );

                count += ps.executeUpdate(  );
            }

            if ( baseCodeBeans.length != count ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new PCY_WarningException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new PCY_WarningException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw new PCY_WarningException( e );
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �e��R�[�h�}�X�^�Ƀf�[�^���X�V���܂��B
     *
     * @param baseCodeBean �X�V����PCY_BaseCodeBean
     * @param currentBean  �X�V�O��PCY_BaseCodeBean
     * @param loginuser ���O�C�����[�U
     * @return �쐬����
    * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdate( PCY_BaseCodeBean baseCodeBean, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        return doUpdate( new PCY_BaseCodeBean[] { baseCodeBean }, loginuser );
    }

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }
}
