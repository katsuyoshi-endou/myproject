package jp.co.hisas.career.learning.base.valuebean;

import java.io.*;
import java.util.List;

/**
 * �g�D����u�󋵂̉�ʏ��Bean�N���X
 */
public class PCY_SoshikiJukouJyokyoBean implements Serializable {

	public static final String SESSION_KEY = "VCB090_SESSION_KEY";
	
	/******** ���͒l ********/
	/** ���� */
	private String inputShozokuCode;
	/** ��u�� */
	private String inputPersonCode;
	/** �J�Ó��i�J�n�j */
	private String inputStartDate;
	/** �J�Ó��i�I���j */
	private String inputEndDate;
	/** �K�{�u�� */
	private String inputHissuKoza;
	/** �K�{�u���敪 */
	private String inputHissuKozaKubun;

	/******* �������� *******/
	/** ���� */
	private String searchShozokuCode;
	/** ��u�� */
	private String searchPersonCode;
	/** �J�Ó��i�J�n�j */
	private String searchStartDate;
	/** �J�Ó��i�I���j */
	private String searchEndDate;
	/** �K�{�u�� */
	private String searchHissuKoza;
	/** �K�{�u���敪 */
	private String searchHissuKozaKubun;
	
	/******* �\�����e *******/
	/** �������X�g */
	private List shozokuList;
	/** ��u�҃��X�g */
	private List personList;
	/** �K�{�u�����X�g */
	private List hissuKozaList;
	/** �s���Bean���X�g */
	private List jukouJyokyoRowList;
	
	/*** ���̑�����p��� ***/
	/** �P�y�[�W�\������ */
	private int pageLineMax;
	/** �ő�y�[�W�� */
	private int maxPageNo;
	/** �y�[�W�ԍ� */
	private int pageNo;
	/** �����σt���O */
	private boolean searched;
	/** ������� */
	private int searchType;
	
	public List getHissuKozaList() {
		return hissuKozaList;
	}
	public void setHissuKozaList(List hissuKozaList) {
		this.hissuKozaList = hissuKozaList;
	}
	public String getInputEndDate() {
		return inputEndDate;
	}
	public void setInputEndDate(String inputEndDate) {
		this.inputEndDate = inputEndDate;
	}
	public String getInputHissuKoza() {
		return inputHissuKoza;
	}
	public void setInputHissuKoza(String inputHissuKoza) {
		this.inputHissuKoza = inputHissuKoza;
	}
	public String getInputHissuKozaKubun() {
		return inputHissuKozaKubun;
	}
	public void setInputHissuKozaKubun(String inputHissuKozaKubun) {
		this.inputHissuKozaKubun = inputHissuKozaKubun;
	}
	public String getInputPersonCode() {
		return inputPersonCode;
	}
	public void setInputPersonCode(String inputPersonCode) {
		this.inputPersonCode = inputPersonCode;
	}
	public String getInputShozokuCode() {
		return inputShozokuCode;
	}
	public void setInputShozokuCode(String inputShozokuCode) {
		this.inputShozokuCode = inputShozokuCode;
	}
	public String getInputStartDate() {
		return inputStartDate;
	}
	public void setInputStartDate(String inputStartDate) {
		this.inputStartDate = inputStartDate;
	}
	public List getJukouJyokyoRowList() {
		return jukouJyokyoRowList;
	}
	public void setJukouJyokyoRowList(List jukouJyokyoRowList) {
		this.jukouJyokyoRowList = jukouJyokyoRowList;
	}
	public int getMaxPageNo() {
		return maxPageNo;
	}
	public void setMaxPageNo(int maxPageNo) {
		this.maxPageNo = maxPageNo;
	}
	public int getPageLineMax() {
		return pageLineMax;
	}
	public void setPageLineMax(int pageLineMax) {
		this.pageLineMax = pageLineMax;
	}
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	public List getPersonList() {
		return personList;
	}
	public void setPersonList(List personList) {
		this.personList = personList;
	}
	public boolean isSearched() {
		return searched;
	}
	public void setSearched(boolean searched) {
		this.searched = searched;
	}
	public String getSearchEndDate() {
		return searchEndDate;
	}
	public void setSearchEndDate(String searchEndDate) {
		this.searchEndDate = searchEndDate;
	}
	public String getSearchHissuKoza() {
		return searchHissuKoza;
	}
	public void setSearchHissuKoza(String searchHissuKoza) {
		this.searchHissuKoza = searchHissuKoza;
	}
	public String getSearchHissuKozaKubun() {
		return searchHissuKozaKubun;
	}
	public void setSearchHissuKozaKubun(String searchHissuKozaKubun) {
		this.searchHissuKozaKubun = searchHissuKozaKubun;
	}
	public String getSearchPersonCode() {
		return searchPersonCode;
	}
	public void setSearchPersonCode(String searchPersonCode) {
		this.searchPersonCode = searchPersonCode;
	}
	public String getSearchShozokuCode() {
		return searchShozokuCode;
	}
	public void setSearchShozokuCode(String searchShozokuCode) {
		this.searchShozokuCode = searchShozokuCode;
	}
	public String getSearchStartDate() {
		return searchStartDate;
	}
	public void setSearchStartDate(String searchStartDate) {
		this.searchStartDate = searchStartDate;
	}
	public int getSearchType() {
		return searchType;
	}
	public void setSearchType(int searchType) {
		this.searchType = searchType;
	}
	public List getShozokuList() {
		return shozokuList;
	}
	public void setShozokuList(List shozokuList) {
		this.shozokuList = shozokuList;
	}
}
