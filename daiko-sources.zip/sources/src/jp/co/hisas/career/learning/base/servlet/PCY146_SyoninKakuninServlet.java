/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/06/01  01.00      ���{�@�^��q �V�K�쐬
 *   2004/06/15             ����@���V�@�@�x�����b�Z�[�W���ʂ��C��
 *   2004/06/16             ���� ���V   �x����ʕ\�����b�Z�[�W���h�c�ɕύX
 *   2004/06/19             ����@���V�@�@getListWithSyoninsya�����ύX�ɑΉ�
 *   2004/07/28             �n��  ��q   ���[�����e�쐬�����ǉ�
 *   2004/08/03             �n��  ��q   �\����������ǉ�
 *   2004/08/10             �n��  ��q   ���[���t�H�[�}�b�g�C�� <B-ALC02-002>  
 *   2004/08/16             �n��  ��q   ���b�`�e�L�X�g�\���C�� <B-ALC02-013>
 *   2004/08/16             �n��  ��q   �A�i�E���X�����擾�C�� <B-ALC02-016>
 *   2005/11/07             ���Y  �T��   ���[���o�͗p�̃p�[�\�i�������Z�b�g <B-A30AM1-010>
 *   2005/11/19             ���c�@���V   �L�����Z���҂��̒ǉ��d�l�ɑΉ� [B-A30AM1-002]
 *   2005/11/22             ���c�@���V   �����null�̏ꍇ�ɑΉ� [B-A30AM1-030]
 */
package jp.co.hisas.career.learning.base.servlet;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.*;

import java.rmi.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;

import javax.servlet.http.*;
import jp.co.hisas.career.base.mail.util.*;      // For Syanai
import jp.co.hisas.career.base.sosiki.bean.SosikiBean;
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.util.property.*;       // For Syanai  CHG#P-ALC02-013-001



/**
 *<PRE>
 *
 * �N���X���F
 *   PCY146_SyoninKakuninServlet �N���X
 *
 * �@�\�����F
 *   ���F�E���߂��E���F����m�F��ʂɕ\������������擾���܂��B
 *
 *</PRE>
 */
public class PCY146_SyoninKakuninServlet extends PCY010_ControllerServlet {
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PCY_PersonalBean loginuser )
        throws NamingException, CreateException, RemoteException, PCY_WarningException, Exception { // For Syanai
        /*���\�b�h�g���[�X�o��*/
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );
        Log.performance( loginuser.getSimeiNo(  ), true, "" );

        /* �����t���O
         *  1:���F
         *  2:���߂�
         *  3:���F���
         *  4:�\�����(For Syanai)
         */
// ADD 2016/01/25 COMTURE VCB010_�\�����F�iver.11-00�j START
        String simei_no = loginuser.getSimeiNo();
        final HttpSession session = request.getSession(false);
        if (session != null) {
            final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");
            simei_no = PZZ010_CharacterUtil.changeSimeiNoLength(userinfo.getSimei_no());
        }
// ADD 2016/01/25 COMTURE VCB010_�\�����F�iver.11-00�j END
        String flg = ( String )request.getParameter( "flg" );

        String[] check    = ( String[] )request.getParameterValues( "syonin" );
        String kamokuCode = "";
        String classCode  = "";
        String simeiNo    = "";
        String status     = "";
        String uketsuke   = "";  // For Syanai
		int cancelMachiClass = 0;//INS#P-A30AM1-002-005
		int syoninzumiZyogenClass = 0;//INS#P-A30AM1-002-005

        PCY_ServiceLocator locator      = PCY_ServiceLocator.getInstance(  );
        PCY_MousikomiJyokyoEJBHome home = ( PCY_MousikomiJyokyoEJBHome )locator.getServiceLocation( "PCY_MousikomiJyokyoEJB",
                PCY_MousikomiJyokyoEJBHome.class );
        PCY_MousikomiJyokyoEJB ejb = home.create(  );

        PCY_ClassEJBHome homeClass = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
                PCY_ClassEJBHome.class );
        PCY_ClassEJB ejbClass = homeClass.create(  );

        for ( int i = 0; i < check.length; i++ ) {
            kamokuCode     = ( String )request.getParameter( "kamoku_code_" + check[i] );
            classCode      = ( String )request.getParameter( "class_code_" + check[i] );
            simeiNo        = ( String )request.getParameter( "simei_no_" + check[i] );
            status         = ( String )request.getParameter( "status_" + check[i] );
            uketsuke       = ( String )request.getParameter( "uketsuke_" + check[i] );  // For Syanai

            /* �I���������R�[�h�̃N���X�����擾���� */
            PCY_ClassBean classBeanDummy = new PCY_ClassBean(  );
            classBeanDummy.getKamokuBean(  ).setKamokuCode( kamokuCode );
            classBeanDummy.setClassCode( classCode );
            Log.transaction( loginuser.getSimeiNo(  ), true, "" );

            PCY_ClassBean classBean = ejbClass.doSelectByPrimaryKey( classBeanDummy, loginuser );
            Log.transaction( loginuser.getSimeiNo(  ), false, "" );

            /* �I���������R�[�h�̏��(�\����)���擾���� */
            PCY_MousikomiJyokyoBean mousikomiJyokyoBean = new PCY_MousikomiJyokyoBean(  );
            mousikomiJyokyoBean.setKamokuCode( kamokuCode );
            mousikomiJyokyoBean.setClassCode( classCode );
            mousikomiJyokyoBean.setSimeiNo( simeiNo );
            mousikomiJyokyoBean.setStatus( status );

            Log.transaction( loginuser.getSimeiNo(  ), true, "" );

			/* INS#P-A30AM1-002-005-S */
			/* ���Y�N���X�ŏ��F�ς̐l�����v�Z */
			int count1 = ejb.countClassL15( kamokuCode , classCode , null , "1" ,  loginuser ) ;
			int count2 = ejb.countClassL15( kamokuCode , classCode , null , "2" ,  loginuser ) ;
			int count3 = ejb.countClassL15( kamokuCode , classCode , null , "3" ,  loginuser ) ;
			int mousikomisya = count1 + count2 + count3;
			mousikomiJyokyoBean.getClassBean().setMousikomisya( String.valueOf(mousikomisya) );
			
			if ( classBean.getTeiin() != null ) {// INS#P-A30AM1-030-001
				int teiin = classBean.getTeiin().intValue();
				int cancelMachiNinzuu = 0;
				String str = (String)ReadFile.fileMapData.get("CANCEL_MACHI_NINZUU");
						if (str != null) {
						  cancelMachiNinzuu = Integer.parseInt(str);
						}
			
				if ( mousikomisya >= ( teiin + cancelMachiNinzuu ) ) {
					syoninzumiZyogenClass++;
				} else if ( mousikomisya >= teiin ) {
					cancelMachiClass++;
				}
			}// INS#P-A30AM1-030-001
			/* INS#P-A30AM1-002-005-E */
			
            PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = ejb.getList( mousikomiJyokyoBean,
                    loginuser );
            Log.transaction( loginuser.getSimeiNo(  ), false, "" );

            /* ���F����̏ꍇ */
            if ( ( flg != null ) && flg.equals( "3" ) ) {
                /* ���F�s�v�̏ꍇ */
                if ( classBean.getSyoninKubun(  ).equals( "0" ) ) {
                    request.setAttribute( "warningID", "WCB010" );
                    throw new PCY_WarningException(  );
                }

                /* ���F�҂��̏ꍇ */
                if ( status.equals( "0" ) ) {
                    request.setAttribute( "warningID", "WCB020" );
                    throw new PCY_WarningException(  );
                }

                /* ��t�敪��"�v"�̃N���X�̏ꍇ */
                if ( classBean.getUketukeKubun(  ).equals( "1" ) ) {
                    if ( Integer.parseInt( mousikomiJyokyoBeans[0].getStatus(  ) ) >= 2 ) {
                        request.setAttribute( "warningID", "WCB030" );
                        throw new PCY_WarningException(  );
                    }

                    /* �񍐋敪��"�v"�̃N���X�̏ꍇ */
                } else if ( !classBean.getHoukokuKubun(  ).equals( "0" ) ) {
                    if ( Integer.parseInt( mousikomiJyokyoBeans[0].getStatus(  ) ) == 3 ) {
                        request.setAttribute( "warningID", "WCB040" );
                        throw new PCY_WarningException(  );
                    }
                }

                /* ���߂��̏ꍇ */
            } else if ( ( flg != null ) && flg.equals( "2" ) ) {
                /* ���F�s�v�̏ꍇ */
                if ( classBean.getSyoninKubun(  ).equals( "0" ) ) {
                    request.setAttribute( "warningID", "WCB050" );
                    throw new PCY_WarningException(  );
                }

                /* ��t�敪��"�v"�̃N���X�̏ꍇ */
                if ( classBean.getUketukeKubun(  ).equals( "1" ) ) {
                    /* �񍐑҂��A����҂��̏ꍇ */
                    if ( Integer.parseInt( mousikomiJyokyoBeans[0].getStatus(  ) ) >= 2 ) {
                        request.setAttribute( "warningID", "WCB060" );
                        throw new PCY_WarningException(  );
                    }

                    /* ��t�҂��̏ꍇ */
                    if ( Integer.parseInt( mousikomiJyokyoBeans[0].getStatus(  ) ) == 1 ) {
                        request.setAttribute( "warningID", "WCB070" );
                        throw new PCY_WarningException(  );
                    }

                    /* ��t�s�v�E�񍐋敪��"�v"�̃N���X�̏ꍇ */
                } else if ( !classBean.getHoukokuKubun(  ).equals( "0" ) ) {
                    if ( Integer.parseInt( mousikomiJyokyoBeans[0].getStatus(  ) ) == 3 ) {
                        request.setAttribute( "warningID", "WCB080" );
                        throw new PCY_WarningException(  );
                    }
                }

                /* ���F�̏ꍇ */
            } else if ( ( flg != null ) && flg.equals( "1" ) ) {
                /* ���F�s�v�̏ꍇ */
                if ( classBean.getSyoninKubun(  ).equals( "0" ) ) {
                    request.setAttribute( "warningID", "WCB090" );
                    throw new PCY_WarningException(  );
                }

                /* ���F�҂��łȂ� */
                if ( !status.equals( "0" ) ) {
                    request.setAttribute( "warningID", "WCB100" );
                    throw new PCY_WarningException(  );
                }
            // For Syanai-S
            // �\������̏ꍇ
            } else if ( ( flg != null ) && flg.equals( "4" ) ) {
                if( !status.equals( "1" ) ) {
                    request.setAttribute( "warningID" , "WCB210" );
                    throw new PCY_WarningException();
                }
                if( !uketsuke.equals( "2" ) ) {
                    request.setAttribute( "warningID" , "WCB220" );
                    throw new PCY_WarningException();
                }
            // For Syanai-E
            }

            classBeanDummy          = null;
            mousikomiJyokyoBean     = null;
        }

        Log.transaction( loginuser.getSimeiNo(  ), true, "" );

// MOD 2016/01/25 COMTURE VCB010_�\�����F�iver.11-00�j START
//        PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = ejb.getListWithSyoninsya( loginuser
//                .getSimeiNo(  ), new PCY_MousikomiJyokyoBean(  ), loginuser );
        PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = ejb.getListWithSyoninsya( simei_no, 
                new PCY_MousikomiJyokyoBean(  ), loginuser );
// MOD 2016/01/25 COMTURE VCB010_�\�����F�iver.11-00�j END
        Log.transaction( loginuser.getSimeiNo(  ), false, "" );

        ArrayList list = new ArrayList(  );

        for ( int i = 0; i < check.length; i++ ) {
            kamokuCode     = ( String )request.getParameter( "kamoku_code_" + check[i] );
            classCode      = ( String )request.getParameter( "class_code_" + check[i] );
            simeiNo        = ( String )request.getParameter( "simei_no_" + check[i] );

            for ( int j = 0; j < mousikomiJyokyoBeans.length; j++ ) {
                if ( mousikomiJyokyoBeans[j].getKamokuCode(  ).equals( kamokuCode )
                    && mousikomiJyokyoBeans[j].getClassCode(  ).equals( classCode )
                    && mousikomiJyokyoBeans[j].getSimeiNo(  ).equals( simeiNo ) ) {
					/* INS#P-A30AM1-002-005-S */	
					int count1 = ejb.countClassL15( kamokuCode , classCode , null , "1" ,  loginuser ) ;
					int count2 = ejb.countClassL15( kamokuCode , classCode , null , "2" ,  loginuser ) ;
					int count3 = ejb.countClassL15( kamokuCode , classCode , null , "3" ,  loginuser ) ;
					int mousikomisya = count1 + count2 + count3;
					mousikomiJyokyoBeans[j].getClassBean().setMousikomisya( String.valueOf(mousikomisya) );
					/* INS#P-A30AM1-002-005-E */	
                    list.add( i, mousikomiJyokyoBeans[j] );
                }
            }
        }

        PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans2 = ( PCY_MousikomiJyokyoBean[] )list.toArray( new PCY_MousikomiJyokyoBean[list
                .size(  )] );
        request.setAttribute( "mousikomiJyokyoBeans", mousikomiJyokyoBeans2 );
		request.setAttribute( "cancelMachiClass", String.valueOf(cancelMachiClass) );//INS#P-A30AM1-002-005
		request.setAttribute( "syoninzumiZyogenClass", String.valueOf(syoninzumiZyogenClass) );//INS#P-A30AM1-002-005        
        // For Syanai-S
        // �I�����ꂽ�e���v���[�g�����擾����
        String templateID = request.getParameter( "mail_template" );
        // ���͂��ꂽ�R�����g���擾����
        String comment = request.getParameter( "HTMLcomment" );  // CHG#P-ALC02-013-001

        // ���[�����M���e���쐬����
        if ( templateID != null && !templateID.equals( "" ) ) {
            MessageCreateHelper helper = MessageCreateHelper.createInstance( templateID );
            helper.setParameter( "class", new PCY_ClassBeanForMail( mousikomiJyokyoBeans2[0].getClassBean() ) );
            helper.setParameter( "kamoku", new PCY_KamokuBeanForMail( mousikomiJyokyoBeans2[0].getClassBean().getKamokuBean() ) );
            helper.setParameter( "announce", ( String )ReadFile.announceMapData.get( "AZZ027" ) );  // CHG#P-ALC02-016-001
            helper.setParameter( "honbun", comment );  // INS#P-ALC02-002-001
            // INS#P-A30AM1-010-002-S
            /* �P�l�ڂ̏��̂ݎ擾�i��ʏ�A�P�������\���ł��Ȃ����߁j */
            PCY_PersonalEJBHome personalHome   = ( PCY_PersonalEJBHome )locator.getServiceLocation( "PCY_PersonalEJB",
                    PCY_PersonalEJBHome.class );
            PCY_PersonalEJB personalEjb = personalHome.create(  );
            PCY_PersonalBean mousikomisya = personalEjb.getPersonalInfo( mousikomiJyokyoBeans2[0].getSimeiNo(), loginuser );

            /* �������̖����擾���APCY_PersonalBean���Z�b�g */
            String[] sosiki = SosikiBean.getSosikiByCode( mousikomisya.getSosikiCode().trim(), loginuser.getSimeiNo() );
            mousikomisya.setBusyoRyakusyoMei( sosiki[2] );
            helper.setParameter( "personal", mousikomisya );
            // INS#P-A30AM1-010-002-E

            String mail_template_content = helper.getMessage();
            // �R�����g�̓��e���Z�b�g
            request.setAttribute( "mail_template_content", mail_template_content );
        }
        // For Syanai-E

        /*���\�b�h�g���[�X�o��*/
        Log.performance( loginuser.getSimeiNo(  ), false, "" );
        Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

        return getForwardPath(  );
    }
}
