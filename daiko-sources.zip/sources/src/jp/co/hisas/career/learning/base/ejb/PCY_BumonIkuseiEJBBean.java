/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/04  01.00      ��]�F ��    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.ejb;

import jp.co.hisas.career.base.blob.ejb.*;
import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.rmi.*;

import java.sql.*;

import javax.ejb.*;

import javax.naming.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_BumonIkuseiEJBBean�N���X
 *
 * �@�\�����F
 *   ����琬�e�[�u���ւ̑�����s���܂��B
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PCY_BumonIkuseiEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PCY_BumonIkuseiEJBBean implements SessionBean {
    private SessionContext context = null;

    /**
     * ���O�C�����[�U�̎����ԍ�����琬���j�f�[�^���擾���܂��B
     * @param bumonBean ���F�҂̑g�D�R�[�h
     * @param loginuser ���O�C�����[�U�̎����ԍ�
     * @return �琬���j�f�[�^
     * @ejb.interface-method
    * @ejb.transaction type="Required"
    */
    public PCY_BumonIkuseiBean doSelect( PCY_BumonIkuseiBean bumonBean, PCY_PersonalBean loginuser )
        throws Exception {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "SELECT * FROM  " + HcdbDef.L53_TBL + "  WHERE SOSIKI_CODE=?" );

            /* �f�o�b�O���O */
            Log.debug( sql.toString(  ) );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            ps = con.prepareStatement( sql.toString(  ) );

            /* �����������Z�b�g���� */
            ps.setString( 1, bumonBean.getSosikiCode(  ) );

            /* ���擾 */
            ResultSet rs                        = ps.executeQuery(  );
            PCY_BumonIkuseiBean bumonikuseiBean = null;

            while ( rs.next(  ) ) {
                bumonikuseiBean = new PCY_BumonIkuseiBean( rs, "" );
            }

            String jndi_name = "PYF_BlobDBAccessCosmiEJB";
            String jdbc_type = ( String )ReadFile.fileMapData.get( "AP_SERVER_JDBC_TYPE" );

            if ( jdbc_type.equals( "DABROKER" ) ) {
                jndi_name = "PYF_BlobDBAccessCosmiEJB";
            } else if ( jdbc_type.equals( "ORACLE" ) ) {
                jndi_name = "PYF_BlobDBAccessOracleEJB";
            }

            PYF_BlobDBAccessEJBHome blob_home = ( PYF_BlobDBAccessEJBHome )locator
                .getServiceLocation( jndi_name, PYF_BlobDBAccessEJBHome.class );

            PYF_BlobDBAccessEJB blob_ejb = blob_home.create(  );

            /* L53�e�[�u���@��L�[ + �X�V�������� �J������ */
            String[] PKEY_HOUSIN = { "SOSIKI_CODE" };

            /* �J�����Z�b�g */
            String[] PKEY_VALEU = { bumonBean.getSosikiCode(  ) };

            try {
                byte[] ikkatsuhousin = blob_ejb.SelectBLOB( loginuser.getSimeiNo(  ),
                        HcdbDef.L53_TBL, "IKUSEI_HOUSIN", PKEY_HOUSIN, PKEY_VALEU );

                if ( ikkatsuhousin != null ) {
                    bumonikuseiBean.setIkuseiHousin( ikkatsuhousin );
                }
            } catch ( Exception e ) {
                throw e;
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return bumonikuseiBean;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * ���O�C�����[�U�̎����ԍ�����琬���j�f�[�^���擾���܂��B
     * @param bumonBean ���F�҂̑g�D�R�[�h
     * @param loginuser ���O�C�����[�U�̎����ԍ�
     * @return �琬���j�f�[�^
     * @ejb.interface-method
    * @ejb.transaction type="Required"
    */
    public int doInsert( PCY_BumonIkuseiBean bumonBean, PCY_PersonalBean loginuser )
        throws Exception {
        Connection con           = null;
        PreparedStatement ps     = null;
        PreparedStatement saiban = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // SQL�쐬
            StringBuffer sql = new StringBuffer(  );
            sql.append( "INSERT INTO " );
            sql.append( HcdbDef.L53_TBL );
            sql.append( " (" );
            sql.append( "    SOSIKI_CODE," );
            sql.append( "    IKUSEI_HOUSIN," );
            sql.append( "    TOUROKUBI," );
            sql.append( "    TOUROKUJIKOKU," );
            sql.append( "    TOUROKUSYA," );
            sql.append( "    KOUSINBI," );
            sql.append( "    KOUSINJIKOKU," );
            sql.append( "    KOUSINSYA" );
            sql.append( " )  VALUES ( ?, ?, ?, ?, ?, ?, ?, ? )" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �X�V���s
            ps = con.prepareStatement( sql.toString(  ) );

            ps.setString( 1, bumonBean.getSosikiCode(  ) );
            ps.setNull( 2, java.sql.Types.BLOB );
            ps.setString( 3, PZZ010_CharacterUtil.GetDay(  ) );
            ps.setString( 4, PZZ010_CharacterUtil.GetTime(  ) );
            ps.setString( 5, loginuser.getSimeiNo(  ) );
            ps.setString( 6, "        " );
            ps.setString( 7, "      " );
            ps.setString( 8, "          " );

            int result = ps.executeUpdate(  );

            //����琬���j�݂̂��i�[����B
            if ( ( result == 1 ) && ( bumonBean.getIkuseiHousin(  ) != null ) ) {
                //�t�@�C����DB�Ɋi�[
                //JDBC�̃^�C�v���v���p�e�B�t�@�C������擾����
                String jdbcType = ( String )ReadFile.fileMapData.get( "AP_SERVER_JDBC_TYPE" );
                String jndiName = "";

                if ( jdbcType.equals( "DABROKER" ) ) {
                    jndiName = "PYF_BlobDBAccessCosmiEJB";
                } else if ( jdbcType.equals( "ORACLE" ) ) {
                    jndiName = "PYF_BlobDBAccessOracleEJB";
                }

                //JNDI���̃��b�N�A�b�v
                PYF_BlobDBAccessEJBHome blobHome = ( PYF_BlobDBAccessEJBHome )locator
                    .getServiceLocation( jndiName, PYF_BlobDBAccessEJBHome.class );

                //EJBObject�̎擾
                PYF_BlobDBAccessEJB blobEjb = blobHome.create(  );

                /* �J�����Z�b�g */
                String[] columns = { "IKUSEI_HOUSIN" };

                //�}���l�Z�b�g
                String[] values = { "BLOB_DATA" };

                //�L�[
                String[] primaryKey = { "SOSIKI_CODE" };

                //�L�[�l
                String[] keyValue = { bumonBean.getSosikiCode(  ) };

                blobEjb.UpdateBLOB( loginuser.getSimeiNo(  ), HcdbDef.L53_TBL, columns, values,
                    bumonBean.getIkuseiHousin(  ), primaryKey, keyValue );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return result;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( saiban != null ) {
                try {
                    saiban.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * ���O�C�����[�U�̎����ԍ�����琬���j�f�[�^���擾���܂��B
     * @param bumonBean ���F�҂̑g�D�R�[�h
     * @param loginuser ���O�C�����[�U�̎����ԍ�
     * @return �琬���j�f�[�^
     * @ejb.interface-method
    * @ejb.transaction type="Required"
    */
    public int doUpdate( PCY_BumonIkuseiBean bumonBean, PCY_PersonalBean loginuser )
        throws Exception {
        Connection con           = null;
        PreparedStatement ps     = null;
        PreparedStatement saiban = null;

        /* �X�V���`�F�b�N���s�Ȃ� */
        PCY_BumonIkuseiBean checkBumonBean = doSelect( bumonBean, loginuser );

        try {
            int count           = 0;
            String kousinbi     = PZZ010_CharacterUtil.GetDay(  );
            String kousinjikoku = PZZ010_CharacterUtil.GetTime(  );
            String kousinsya    = loginuser.getSimeiNo(  );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            if ( checkBumonBean.getKousinbi(  ).equals( bumonBean.getKousinbi(  ) )
                && checkBumonBean.getKousinjikoku(  ).equals( bumonBean.getKousinjikoku(  ) )
                && ( bumonBean.getIkuseiHousin(  ) != null ) ) {
                //�t�@�C����DB�Ɋi�[
                //JDBC�̃^�C�v���v���p�e�B�t�@�C������擾����
                String jdbcType = ( String )ReadFile.fileMapData.get( "AP_SERVER_JDBC_TYPE" );
                String jndiName = "";

                if ( jdbcType.equals( "DABROKER" ) ) {
                    jndiName = "PYF_BlobDBAccessCosmiEJB";
                } else if ( jdbcType.equals( "ORACLE" ) ) {
                    jndiName = "PYF_BlobDBAccessOracleEJB";
                }

                // �R�l�N�V�����擾
                PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

                //JNDI���̃��b�N�A�b�v
                PYF_BlobDBAccessEJBHome blobHome = ( PYF_BlobDBAccessEJBHome )locator
                    .getServiceLocation( jndiName, PYF_BlobDBAccessEJBHome.class );

                //EJBObject�̎擾
                PYF_BlobDBAccessEJB blobEjb = blobHome.create(  );

                /* �J�����Z�b�g */
                String[] columns = {
                    "IKUSEI_HOUSIN", "KOUSINBI", "KOUSINJIKOKU", "KOUSINSYA"
                };

                //�}���l�Z�b�g
                String[] values = {
                    "BLOB_DATA", kousinbi, kousinjikoku, kousinsya
                };

                //�L�[
                String[] primaryKey = { "SOSIKI_CODE" };

                //�L�[�l
                String[] keyValue = { bumonBean.getSosikiCode(  ) };
                count = blobEjb.UpdateBLOB( loginuser.getSimeiNo(  ), HcdbDef.L53_TBL, columns,
                        values, bumonBean.getIkuseiHousin(  ), primaryKey, keyValue );
            } else {
                /* �r������`�F�b�N�G���[���� */
                throw new PCY_WarningException( "WCB080" );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( saiban != null ) {
                try {
                    saiban.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }
}
