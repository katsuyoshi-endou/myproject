/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 * 
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/12/28  01.00       ��� �ӎ�    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.*;
import javax.ejb.*;
import javax.naming.*;
import javax.servlet.http.*;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.bean.*;
import jp.co.hisas.career.util.common.*;
/**
 *<PRE>
 *
 * �N���X���F
 *   PCY321_ClassCyouseiIkkatuTorikeshiKaisiServlet �N���X
 *
 * �@�\�����F
 *   �N���X�����ꊇ������s���܂��B
 *
 *</PRE>
 */
public class PCY321_ClassCyouseiIkkatuTorikeshiKaisiServlet extends PCY010_ControllerServlet {

    protected String execute(HttpServletRequest request, HttpServletResponse response, PCY_PersonalBean loginuser)
        throws NamingException, CreateException, RemoteException, PCY_WarningException {
        /* ���\�b�h�g���[�X */
        Log.method( loginuser.getSimeiNo(), "IN", "" );
        
        String count = request.getParameter( "mousikomisya" );
        int length = 0;

		if(count != null){
			length = Integer.valueOf(count).intValue();
		}


        if ( count != null ) {
			PCY_MousikomiJyokyoBean[]
                taisyosyaBeans = new PCY_MousikomiJyokyoBean[length];
            for ( int i = 0; i < length; i++ ) {
                taisyosyaBeans[i] = new PCY_MousikomiJyokyoBean();
                String index = Integer.toString(i);

                PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean();
                mousikomiBean.setKamokuCode(request.getParameter( "kamoku_code_" + index ));
                mousikomiBean.setClassCode(request.getParameter( "class_code_" + index ));
                mousikomiBean.getClassBean().setKousinbi(request.getParameter( "class_kousinbi_" + index ));
                mousikomiBean.getClassBean().setKousinjikoku(request.getParameter( "class_kousinjikoku_" + index ));
                mousikomiBean.setSimeiNo(request.getParameter( "simei_no_" + index ));
                mousikomiBean.setKousinbi( request.getParameter( "kousinbi_" + index ) );
                mousikomiBean.setKousinjikoku( request.getParameter( "kousinjikoku_" + index ) );
                mousikomiBean.setStatus("1");
                mousikomiBean.setUketsukeJyotai("4");

                taisyosyaBeans[i]= mousikomiBean;
            }

			PCY_ServiceLocator locator      = PCY_ServiceLocator.getInstance(  );
			PCY_MousikomiJyokyoEJBHome home = ( PCY_MousikomiJyokyoEJBHome )locator.getServiceLocation( "PCY_MousikomiJyokyoEJB",
					PCY_MousikomiJyokyoEJBHome.class );
			PCY_MousikomiJyokyoEJB ejb = home.create(  );

			PCY_ClassCyouseiEJBHome home_cyousei = ( PCY_ClassCyouseiEJBHome )locator.getServiceLocation( "PCY_ClassCyouseiEJB",
								PCY_ClassCyouseiEJBHome.class );
			PCY_ClassCyouseiEJB ejb_cyousei = home_cyousei.create(  );
						
			PCY_MousikomiJyokyoBean[] rireki_data = new PCY_MousikomiJyokyoBean[length];
			for(int t = 0; t < length; t++){
				String simei = taisyosyaBeans[t].getSimeiNo();
				String[] kensaku_simei = {simei};
				PCY_KensyuKanriJohoBean[] taisyosya = ejb.getListWithClass(taisyosyaBeans[t].getKamokuCode(),taisyosyaBeans[t].getClassCode(),kensaku_simei,loginuser);
				rireki_data[t] = taisyosya[0].getMousikomiBean();
			}
			

			String now_day  = PZZ010_CharacterUtil.GetDay(  );
			String now_time = PZZ010_CharacterUtil.GetTime(  );	
			PCY_ClassCyouseiBean[] classCyouseiBeans = new PCY_ClassCyouseiBean[length]; 
			for(int cont = 0; cont < length; cont++){
				PCY_ClassCyouseiBean classCyouseiBean = new PCY_ClassCyouseiBean();
				classCyouseiBean.setSyoribi(now_day);
				classCyouseiBean.setSyorijikoku(now_time);
				classCyouseiBean.setSyorisya(loginuser.getSimeiNo());
				classCyouseiBean.setSyoriFlg("1");
				classCyouseiBean.setDlKaisu(new Integer(0));
				classCyouseiBean.setKamokuCode(rireki_data[cont].getKamokuCode());
				classCyouseiBean.setClassCode(rireki_data[cont].getClassCode());
				classCyouseiBean.setSimeiNo(rireki_data[cont].getSimeiNo());
				classCyouseiBean.setAfterStatus("1");
				classCyouseiBean.setAfterUketukeJyotai("4");
				classCyouseiBean.setBeforeStatus("1");
				classCyouseiBean.setBeforeUketsukeJyotai("3");
				classCyouseiBean.setMousikomibi(rireki_data[cont].getMousikomibi());
				classCyouseiBean.setMousikomijikoku(rireki_data[cont].getMousikomijikoku());
				classCyouseiBean.setMousikomisya(rireki_data[cont].getMousikomisya());
				classCyouseiBean.setSyoninbi1(rireki_data[cont].getSyoninbi1());
				classCyouseiBean.setSyoninjikoku1(rireki_data[cont].getSyoninjikoku1());
				classCyouseiBean.setSyoninsya1(rireki_data[cont].getSyoninsya1());
				classCyouseiBean.setSyoninbi2(rireki_data[cont].getSyoninbi2());
				classCyouseiBean.setSyoninjikoku2(rireki_data[cont].getSyoninjikoku2());
				classCyouseiBean.setSyoninsya2(rireki_data[cont].getSyoninsya2());
				classCyouseiBean.setUketukebi(rireki_data[cont].getUketukebi());
				classCyouseiBean.setUketukejikoku(rireki_data[cont].getUketukejikoku());
				classCyouseiBean.setUketukesya(rireki_data[cont].getUketukesya());
				
				classCyouseiBeans[cont] = classCyouseiBean;
				
			}

	    
			Log.transaction( loginuser.getSimeiNo(  ), true, "" );
			ejb.doUpdateStatusAndUketukeIkkatu(taisyosyaBeans,loginuser);
			ejb_cyousei.doInsert(classCyouseiBeans,loginuser);
			Log.transaction( loginuser.getSimeiNo(  ), false, "" );
			


		}


        /* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
        Log.performance( loginuser.getSimeiNo(), false, "" );
        Log.method( loginuser.getSimeiNo(), "OUT", "" );

        return getForwardPath();
    }

}
