/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�v��nHCDB�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/04/01  01.00       �ē��@�����@�@�V�K�쐬
 * 
 */

package jp.co.hisas.career.util.pdf;

import java.io.*;

import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.common.*;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import java.awt.Color;


public class PZE070_ChallengePDF {
	
	/* ���O�C��No */
	private String login_no;

	/*PDF���*/
	private String[]   outDefItem;
	private String[]   outPlanItem;
	private String[]   outResultItem;
	private String[]   outSindanItem;
	private String[]   outHyokaItem;
	private String[][]   outSikakuItem;
	private String[][]   outSyokumuItem;
	private String kubun;
	
	/**
	 * �L�����A�`�������W�v������擾����
	 *
	 * @param outplanItem
	 */
	public void setChallengeValue( String[] outDefItem, String kubun, String[] outplanItem, String[] outresultItem ){
		Log.method( login_no , "IN" , "" );

        this.kubun          =   kubun;
        this.outDefItem     =   outDefItem;
		this.outPlanItem    =   outplanItem;
		this.outResultItem  =   outresultItem;

		Log.method( login_no , "OUT" , "" );
	}
	
	/**
	 * �A�Z�X�����g�f�f���ʁA�]�����ʂ��擾����
	 *
	 * @param outsindanItem
	 * @param outhyokaItem
	*/
	public void setAssessmentValue( String[] outsindanItem, String[] outhyokaItem ){
		Log.method( login_no , "IN" , "" );
		
		this.outSindanItem    = outsindanItem;
		this.outHyokaItem  = outhyokaItem;
		
		Log.method( login_no , "OUT" , "" );
	}
	
	/**
	 * ���i�����擾����
	 *
	 * @param outsikakuItem
	*/
	public void setSikakuValue( String[][] outsikakuItem ){
		Log.method( login_no , "IN" , "" );

		this.outSikakuItem    = outsikakuItem;

		Log.method( login_no , "OUT" , "" );
	}

	/**
	 * �E�����e�������擾����
	 *
	 * @param outsyokumuItem
	*/
	public void setSyokumuValue( String[][] outsyokumuItem ){
		Log.method( login_no , "IN" , "" );
		
		this.outSyokumuItem    = outsyokumuItem;
		
		Log.method( login_no , "OUT" , "" );
	}
	
	/* ���ږ� */
	    
    private String[] param_right_data1   =  new String[4];
	private String[] param_right_data2   =  new String[4];
    
    private String param_kubun1          =  "�v��";
	private String param_kubun2          =  "����";
	
	private String sindan_syozoku        =  "";
	private String sindan_simeino        =  "";
	private String sindan_simei          =  "";
	private String sindan_jissi          =  "";
	private String hyoka_syozoku         =  "";
	private String hyoka_simeino         =  "";
	private String hyoka_simei           =  "";
	private String hyoka_jissi           =  "";
	
	private String sikakumeisyoTop1      =  "";
	private String sikakulevelTop1       =  "";
	private String sikakutokutenTop1     =  "";
	private String sikakusyutokuhiTop1   =  "";
	private String sikakumeisyoTop2      =  "";
	private String sikakulevelTop2       =  "";
	private String sikakutokutenTop2     =  "";
	private String sikakusyutokuhiTop2   =  "";
	private String sikakumeisyoTop3      =  "";
	private String sikakulevelTop3       =  "";
	private String sikakutokutenTop3     =  "";
	private String sikakusyutokuhiTop3   =  "";
	
	private String sikakumeisyoDown1      =  "";
	private String sikakulevelDown1       =  "";
	private String sikakutokutenDown1     =  "";
	private String sikakusyutokuhiDown1   =  "";
	private String sikakumeisyoDown2      =  "";
	private String sikakulevelDown2       =  "";
	private String sikakutokutenDown2     =  "";
	private String sikakusyutokuhiDown2   =  "";
	private String sikakumeisyoDown3      =  "";
	private String sikakulevelDown3       =  "";
	private String sikakutokutenDown3     =  "";
	private String sikakusyutokuhiDown3   =  "";
	
	/**
	 * �R���X�g���N�^
	 *
	 * @param login_no
	 */
	public PZE070_ChallengePDF( String login_no ) {
		this.login_no = login_no;
	}
	
	/* �o�̓^�C�v */
	private String type="file";
	private String str_file;
	
	/* �o�̓X�g���[�� */
	private OutputStream pdf_stream; 
                            
	/**
	 * PDF���쐬����
	 * @return
	 */
	public void executePDF( OutputStream ops )
	throws Exception {
		Log.method( login_no , "IN" , "" );
    	
    	param_right_data1[0]   = outPlanItem[24];
		param_right_data1[1]   = outPlanItem[25];
		param_right_data1[2]   = outPlanItem[34];
		param_right_data1[3]   = outPlanItem[35];	

		param_right_data2[0]   = outResultItem[24];
		param_right_data2[1]   = outResultItem[25];
		param_right_data2[2]   = outResultItem[34];
		param_right_data2[3]   = outResultItem[35];
		
		/* �v��̏ꍇ */
		if ( kubun.equals("1") ) {
			sindan_syozoku        =  outPlanItem[44];
			sindan_simeino        =  outPlanItem[0];
			sindan_simei          =  outPlanItem[43];
			sindan_jissi          =  outPlanItem[39];
			hyoka_syozoku         =  outPlanItem[46];
			hyoka_simeino         =  outPlanItem[36];
			hyoka_simei           =  outPlanItem[45];
			hyoka_jissi           =  outPlanItem[41];
			
			/* �ۗL���i */
			if ( outSikakuItem.length >= 1 ) { 
				sikakumeisyoTop1      =  outSikakuItem[0][1];
				sikakulevelTop1       =  outSikakuItem[0][2];
				sikakutokutenTop1     =  outSikakuItem[0][3];
				sikakusyutokuhiTop1   =  PZZ010_CharacterUtil.ChangeYm(outSikakuItem[0][4]);
			} else {
				sikakumeisyoTop1      =  "����";
				sikakulevelTop1       =  "";
				sikakutokutenTop1     =  "";				
				sikakusyutokuhiTop1   =  "";
			}
			if ( outSikakuItem.length >= 2 ) { 
				sikakumeisyoTop2      =  outSikakuItem[1][1];
				sikakulevelTop2       =  outSikakuItem[1][2];
				sikakutokutenTop2     =  outSikakuItem[1][3];
				sikakusyutokuhiTop2   =  PZZ010_CharacterUtil.ChangeYm(outSikakuItem[1][4]);
			} else {
				sikakumeisyoTop2      =  "";
				sikakulevelTop2       =  "";
				sikakutokutenTop2     =  "";				
				sikakusyutokuhiTop2   =  "";
			}
			if ( outSikakuItem.length >= 3 ) { 
				sikakumeisyoTop3      =  outSikakuItem[2][1];
				sikakulevelTop3       =  outSikakuItem[2][2];
				sikakutokutenTop3     =  outSikakuItem[2][3];
				sikakusyutokuhiTop3   =  PZZ010_CharacterUtil.ChangeYm(outSikakuItem[2][4]);
			} else {
				sikakumeisyoTop3      =  "";
				sikakulevelTop3       =  "";
				sikakutokutenTop3     =  "";
				sikakusyutokuhiTop3   =  "";
			}
			/* �v�掑�i */
			sikakumeisyoDown1      =  outPlanItem[47];
			sikakulevelDown1       =  outPlanItem[48];
			sikakutokutenDown1     =  outPlanItem[11];
			sikakumeisyoDown2      =  outPlanItem[49];
			sikakulevelDown2       =  outPlanItem[50];
			sikakutokutenDown2     =  outPlanItem[14];
			sikakumeisyoDown3      =  outPlanItem[51];
			sikakulevelDown3       =  outPlanItem[52];
			sikakutokutenDown3     =  outPlanItem[17];
			
			
		} else {
			sindan_syozoku        =  outResultItem[44];
			sindan_simeino        =  outResultItem[0];
			sindan_simei          =  outResultItem[43];
			sindan_jissi          =  outResultItem[39];
			hyoka_syozoku         =  outResultItem[46];
			hyoka_simeino         =  outResultItem[36];
			hyoka_simei           =  outResultItem[45];
			hyoka_jissi           =  outResultItem[41];	
			
			/* �v�掑�i */
			sikakumeisyoTop1      =  outPlanItem[47];
			sikakulevelTop1       =  outPlanItem[48];
			sikakutokutenTop1     =  outPlanItem[11];
			sikakumeisyoTop2      =  outPlanItem[49];
			sikakulevelTop2       =  outPlanItem[50];
			sikakutokutenTop2     =  outPlanItem[14];
			sikakumeisyoTop3      =  outPlanItem[51];
			sikakulevelTop3       =  outPlanItem[52];
			sikakutokutenTop3     =  outPlanItem[17];	

            /* ���� */
			sikakumeisyoDown1      =  outResultItem[47];
			sikakulevelDown1       =  outResultItem[48];
			sikakutokutenDown1     =  outResultItem[11];
			sikakumeisyoDown2      =  outResultItem[49];
			sikakulevelDown2       =  outResultItem[50];
			sikakutokutenDown2     =  outResultItem[14];
			sikakumeisyoDown3      =  outResultItem[51];
			sikakulevelDown3       =  outResultItem[52];
			sikakutokutenDown3     =  outResultItem[17];
			
			if ( sikakumeisyoDown1.equals("") && sikakumeisyoDown2.equals("") && sikakumeisyoDown3.equals("") ) {
				sikakumeisyoDown1 = "����";
			}

		}
        
		/*
         * Document�I�u�W�F�N�g�̐���
         *  A3���́ADocument document = new Document(PageSize.A3.rotate());
         */
		Document document = new Document( PageSize.A3.rotate() );
        
        //�}�[�W���w��
		float lm = 18;
		document.setMargins(lm,lm,lm,lm);
		
		/* PdfWriter�I�u�W�F�N�g*/
		PdfWriter writer = null;
		
        try {
   
			// PdfWriter�I�u�W�F�N�g�̐���
			writer = PdfWriter.getInstance( document, ops );
			writer.setCloseStream(true);
       
            // �]��
            float gutter = 20;
            // �i�g��
            int numColumns = 2;
            // ����
            float fullWidth = document.right() - document.left();
            // �i��
            float columnWidth = (fullWidth - (numColumns - 1) * gutter) / numColumns;
            
            // �g�p�t�H���g��ݒ肷��
			BaseFont bf  = BaseFont.createFont( "HeiseiMin-W3", "UniJIS-UCS2-HW-H", false );
			Font font9      = new Font( bf, 9 );
			Font font9line  = new Font( bf, 9, Font.UNDERLINE );
			Font font12     = new Font( bf, 12 );
			Font font14     = new Font( bf, 14 );
			Font font10B    = new Font( bf, 10, Font.BOLD );
			
			
			Color silver = new Color(0xC0, 0xC0, 0xC0);  // silver=��F
			Color blue   = new Color(204,204,255);       // blue=�F 
			Color white  = new Color(255,255,255);       // white=��
			
			//�h�L�������g���J��
            document.open();  
            // �L�����o�X���擾          
            PdfContentByte cb = writer.getDirectContent();
            
            //���݂̈ʒu���擾����
            float currentY = document.top();
            
            currentY -= 25;

            
		    /* �y�^�C�g���z */	    
		    PdfPTable Table = new PdfPTable(1);
			Table.getDefaultCell().setBorderWidth(1);
		    Table.getDefaultCell().setPaddingTop(0);
		    Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );  
		    Table.addCell(new Phrase( outDefItem[33], font14));
		    Table.setTotalWidth(columnWidth);
		    
		    currentY = Table.writeSelectedRows(0, -1, document.left(), currentY, cb);

            /* �y�A�Z�X�����g���ʁz */
		    Table = new PdfPTable(1);
		    Table.getDefaultCell().setPaddingTop(0);
		    Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		    Table.addCell(new Phrase( outDefItem[0], font12));
		    Table.setTotalWidth(columnWidth);

		    currentY = Table.writeSelectedRows(0, -1, document.left(), currentY-10, cb) ;
		    
            /* �y�A�Z�X�����g���� ���o���z */
		    Table = new PdfPTable(4);
		    /* �y�ڕW�z */
		    PdfPCell cell  = new PdfPCell(new Phrase( outDefItem[36], font9));
		    cell.setBackgroundColor(silver);
            cell.setBorder( Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT );
		    cell.setHorizontalAlignment( Element.ALIGN_CENTER );
            Table.addCell(cell);
		    Table.getDefaultCell().setPaddingTop(0);
		    Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );
			/* �y�E��z */  
		    Table.addCell(new Phrase( outDefItem[1], font9));  
			/* �y��啪��z */
		    Table.addCell(new Phrase( outDefItem[2], font9));
			/* �y���x���z */  
			
		    Table.addCell(new Phrase( outDefItem[3], font9)); 
		    		    
		    /* �y��z */
		    cell  = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder( Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT );
			cell.setFixedHeight(20); 
			Table.addCell(cell); 

			/* �y�E��f�[�^�z */  
		    Table.addCell(new Phrase( outSindanItem[3], font9));  
			/* �y��啪��f�[�^�z */
		    Table.addCell(new Phrase( outSindanItem[4], font9));  
			/* �y���x���f�[�^�z */
		    Table.addCell(new Phrase( outSindanItem[5], font9));
		    Table.setTotalWidth(columnWidth);

		    currentY = Table.writeSelectedRows(0, -1, document.left(), currentY-10, cb) ;
                           
		    currentY -= 4;	               
			/* �y�A�Z�X�����g���ʁ@���сi���o���j�z */
		    Table = new PdfPTable(4);
			/* �y���сz */
		    cell  = new PdfPCell( new Phrase( outDefItem[38], font9 ) );
		    cell.setBackgroundColor(silver);
		    cell.setHorizontalAlignment( Element.ALIGN_CENTER );
		    Table.addCell(cell);
		    Table.getDefaultCell().setPaddingTop(0);
		    Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );
			/* �y�����B���x�z */    
		    Table.addCell(new Phrase( outDefItem[4], font9));  
			/* �y�Ɩ��o���B���x�z */
		    Table.addCell(new Phrase( outDefItem[5] , font9)); 
			/* �y�X�L���B���x�z */
		    Table.addCell(new Phrase( outDefItem[6] , font9));
			/* �y���ȕ]���z */ 	
		    Table.addCell(new Phrase( outDefItem[7], font9));
			/* �y���ȑ����B���x�f�[�^�z */     
		    Table.addCell(new Phrase( outSindanItem[2], font9));  
			/* �y���ȋƖ��o���B���x�f�[�^�z */    
		    Table.addCell(new Phrase( outSindanItem[0], font9)); 	
			/* �y���ȃX�L���B���x�f�[�^�z */    
		    Table.addCell(new Phrase( outSindanItem[1], font9));	
			/* �y�]���ҕ]���z */    
		    Table.addCell(new Phrase( outDefItem[8], font9)); 
			/* �y�]�������B���x�f�[�^�z */ 
		    Table.addCell(new Phrase( outHyokaItem[3], font9));  
			/* �y�]���Ɩ��o���B���x�f�[�^�z */ 
		    Table.addCell(new Phrase( outHyokaItem[1], font9)); 
			/* �y�]���X�L���B���x�f�[�^�z */ 
		    Table.addCell(new Phrase( outHyokaItem[2], font9));	
		    Table.setTotalWidth(columnWidth);
		    
		    currentY = Table.writeSelectedRows(0, -1, document.left(), currentY-10, cb) ;
              
		    /* �y�]���Ҏ����e�[�u���z */
		    Table = new PdfPTable(4);
		    int[] widths = { 25,30,23,22 };
		    Table.setWidths( widths );		    
            /*	�y�]���Ҏ����z  */
		    cell  = new PdfPCell(new Phrase(outDefItem[9], font9));
		    cell.setBackgroundColor(silver);
		    cell.setHorizontalAlignment( Element.ALIGN_CENTER );
		    Table.addCell(cell);
		    
		    Table.getDefaultCell().setPaddingTop(0);
		    Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_LEFT );
			Table.getDefaultCell().setFixedHeight(25);  
			/*	�y�]���ҏ����z  */
		    Table.addCell(new Phrase( outDefItem[12] + "�F" + outHyokaItem[5], font9));  
			/*	�y�]���Ҏ����z  */
		    Table.addCell(new Phrase( outDefItem[10] + "�F" + outHyokaItem[4], font9));  
			/*	�y�]���Ҏ��{���z  */
		    Table.addCell(new Phrase( outDefItem[13] + "�F" + PZZ010_CharacterUtil.ChangeYmd( outHyokaItem[0]), font9));
		    Table.setTotalWidth(columnWidth);
		    
		    currentY = Table.writeSelectedRows(0, -1, document.left(), currentY-10, cb) ;

			/* �敪=�v��̎��\������ */
			if ( kubun.equals("1") ) {
                /* �y�����ڕW�e�[�u���z */
			    Table = new PdfPTable(4);
			    /* �y�����ڕW�z */
			    cell  = new PdfPCell(new Phrase( outDefItem[37], font9));
			    cell.setBackgroundColor(silver);
			    cell.setBorder( Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT );
			    cell.setHorizontalAlignment( Element.ALIGN_CENTER );
            
			    Table.addCell(cell);
			    Table.getDefaultCell().setPaddingTop(0);
			    Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );  
			    /* �y�E��z */  
			    Table.addCell(new Phrase( outDefItem[1], font9));  
			    /* �y��啪��z */
			    Table.addCell(new Phrase( outDefItem[2], font9));
			    /* �y���x���z */  
			    Table.addCell(new Phrase( outDefItem[3], font9)); 
			    /* �y��z */  
			    cell  = new PdfPCell(new Phrase("", font9));
			    cell.setBackgroundColor(silver);
			    cell.setBorder( Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT );

				cell.setFixedHeight(20); 
			    Table.addCell(cell);  
			    /* �y�E��f�[�^�z */  
			    Table.addCell(new Phrase( outPlanItem[4], font9));  
			    /* �y��啪��f�[�^�z */
			    Table.addCell(new Phrase( outPlanItem[5], font9));  
			    /* �y���x���f�[�^�z */
			    Table.addCell(new Phrase( outPlanItem[6], font9));
			    Table.setTotalWidth(columnWidth);
		    
			    currentY = Table.writeSelectedRows(0, -1, document.left(), currentY-10, cb) ;
            

                /* �y���ݏ]�����Ă���Ɩ��e�[�u�� �z */
		        Table = new PdfPTable(1);
		        Table.getDefaultCell().setPaddingTop(0);
		        Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				/* �y�^�C�g�� �z */
		        Table.addCell(new Phrase( outDefItem[34], font12));
		        Table.setTotalWidth(columnWidth);

		        currentY = Table.writeSelectedRows(0, -1, document.left(), currentY-10, cb) ;
			
		        /* �y�v���W�F�N�g���z */
		        Table = new PdfPTable(4);		    
		        int[] widths2 = { 30,25,30,15 };	
		        Table.setWidths( widths2 );	
		        cell  = new PdfPCell(new Phrase( outDefItem[16] , font9));
		        cell.setBackgroundColor(silver);
		        cell.setBorder( Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT );
		        cell.setHorizontalAlignment( Element.ALIGN_CENTER ); 
		        cell.setColspan(2);  
		        Table.addCell(cell);
		        /* �y�ڋq�� �z*/
		        cell  = new PdfPCell(new Phrase( outDefItem[17] , font9));
		        cell.setBackgroundColor(silver);
		        cell.setBorder( Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT );
		        cell.setHorizontalAlignment( Element.ALIGN_CENTER );   
		        Table.addCell(cell);
		        /* �y�]���J�n�N���z */
		        cell  = new PdfPCell(new Phrase( outDefItem[18], font9));
		        cell.setBackgroundColor(silver);
		        cell.setBorder( Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT );
		        cell.setHorizontalAlignment( Element.ALIGN_CENTER );   
		        Table.addCell(cell);

                /* �y�f�[�^���z */
				/* 3���ȏ�̎� */
				if ( outSyokumuItem.length >= 3 ) {
					for ( int i = 0; i < 3; i++ ) {
				        /* �y�v���W�F�N�g���z */
		                Table.setWidths( widths2 );	
		                cell  = new PdfPCell(new Phrase( outSyokumuItem[i][0], font9) );
		                cell.setHorizontalAlignment( Element.ALIGN_CENTER );
						cell.setFixedHeight(20);  
		                cell.setColspan(2);  
		                Table.addCell(cell);
		                /* �y�ڋq���z */
		                cell  = new PdfPCell(new Phrase( outSyokumuItem[i][1], font9) );
		                cell.setHorizontalAlignment( Element.ALIGN_CENTER );   
		                Table.addCell(cell);
		                /* �y�]���J�n�N���z */
		                cell  = new PdfPCell(new Phrase( PZZ010_CharacterUtil.ChangeYm(outSyokumuItem[i][2]), font9));  
		                cell.setHorizontalAlignment( Element.ALIGN_CENTER );   
		                Table.addCell(cell);
		                Table.setTotalWidth(columnWidth);
					}
				/* 3�������̎� */
				} else {

					for ( int i = 0; i < outSyokumuItem.length; i++ ) {
						/* �y�v���W�F�N�g���z */
						Table.setWidths( widths2 );	
						cell  = new PdfPCell(new Phrase( outSyokumuItem[i][0], font9) );
						cell.setHorizontalAlignment( Element.ALIGN_CENTER ); 
						cell.setFixedHeight(20); 
						cell.setColspan(2);  
						Table.addCell(cell);
						/* �y�ڋq���z */
						cell  = new PdfPCell(new Phrase( outSyokumuItem[i][1], font9) );
						cell.setHorizontalAlignment( Element.ALIGN_CENTER );   
						Table.addCell(cell);
						/* �y�]���J�n�N���z */
						cell  = new PdfPCell(new Phrase( PZZ010_CharacterUtil.ChangeYm(outSyokumuItem[i][2]), font9));  
						cell.setHorizontalAlignment( Element.ALIGN_CENTER );   
						Table.addCell(cell);
						Table.setTotalWidth(columnWidth);
					}
					
					/* �y��z */
					for ( int i = 0; i < 3 - outSyokumuItem.length; i++ ) {
						/* �y�v���W�F�N�g���z */
						Table.setWidths( widths2 );	
						/* 0���̎��A"����"�̕������\�� */
						if ( outSyokumuItem.length == 0 && i == 0 ) {
						    cell  = new PdfPCell(new Phrase( "����", font9) );
						} else {
							cell  = new PdfPCell(new Phrase( "", font9) );	
					    }
						cell.setHorizontalAlignment( Element.ALIGN_CENTER ); 
						cell.setFixedHeight(20); 
						cell.setColspan(2);  
						Table.addCell(cell);
						/* �y�ڋq���z */
						cell  = new PdfPCell(new Phrase( "", font9) );
						cell.setHorizontalAlignment( Element.ALIGN_CENTER );   
						Table.addCell(cell);
						/* �y�]���J�n�N���z */
						cell  = new PdfPCell(new Phrase( "", font9));  
						cell.setHorizontalAlignment( Element.ALIGN_CENTER );   
						Table.addCell(cell);
						Table.setTotalWidth(columnWidth);
					}
				}
		        currentY = Table.writeSelectedRows(0, -1, document.left(), currentY-10, cb) ;
	 	    
	 	        /* �y���ӎ����z */
			    Table = new PdfPTable(1);
			    Table.getDefaultCell().setPaddingTop(0);
			    Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			    Table.addCell(new Phrase( outDefItem[28] , font9));
			    Table.setTotalWidth(columnWidth);

			    currentY = Table.writeSelectedRows(0, -1, document.left(), currentY-10, cb) ;
	 
			/* �敪�����т̏ꍇ�͉����\�����Ȃ� */
			} else {
				currentY -= 98;
			}
		
	 	    /* �y�\�͊J���v��Ǝ��сz�@*/
			Table = new PdfPTable(1);
			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            /* �y�^�C�g���z */
			Table.addCell(new Phrase( outDefItem[35], font12));
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left(), currentY-10, cb) ;
	 	    	              
            /* �y�Ɩ��o���e�[�u���z */
			Table = new PdfPTable(3);
			int[] widths3 = { 5,5,90 };
			Table.setWidths( widths3 );	
			/* �y�Ɩ��o���z */
			cell  = new PdfPCell(new Phrase( outDefItem[5], font9));
			cell.setBackgroundColor(silver);
			cell.setBorder( Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			
			/* �v�掞�͐^�� */
			if ( kubun.equals("1") ) {
			    cell.setVerticalAlignment( Element.ALIGN_MIDDLE );
			/* ���ю��͉� */
			} else {
				cell.setVerticalAlignment( Element.ALIGN_BOTTOM );
			}
			Table.addCell(cell);  
			 
			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setFixedHeight(75); 
			
			/* �y�v��z */
			Table.getDefaultCell().setVerticalAlignment( Element.ALIGN_MIDDLE );
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.getDefaultCell().setBackgroundColor(blue);
			Table.addCell(new Phrase( param_kubun1, font9));  
			cell.setBackgroundColor(white);
			Table.getDefaultCell().setVerticalAlignment( Element.ALIGN_TOP );
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_LEFT );
			Table.getDefaultCell().setBackgroundColor(white);
			
			/* �y�v��f�[�^�z */
			Table.addCell(new Phrase( outPlanItem[7], font9)); 

            /* �v�掞�̏ꍇ */
            if ( kubun.equals("1") ) {
			    Table.getDefaultCell().setFixedHeight(0); 
            }
			/* �y��z */
			cell  = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder( Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT );
            
			Table.addCell(cell);  
			/* �y���сz */
			Table.getDefaultCell().setVerticalAlignment( Element.ALIGN_MIDDLE );
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.getDefaultCell().setBackgroundColor(blue);
			Table.addCell(new Phrase( param_kubun2, font9));
			Table.getDefaultCell().setBackgroundColor(white);
			  
			/* �y���уf�[�^�z */
			Table.getDefaultCell().setVerticalAlignment( Element.ALIGN_TOP );
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_LEFT );
			Table.addCell(new Phrase( outResultItem[7], font9));  
			Table.setTotalWidth(columnWidth);
		    
			currentY = Table.writeSelectedRows(0, -1, document.left(), currentY-10, cb) ;
                
			/* �y�����u�e�[�u���z */
			Table = new PdfPTable(3);
			Table.setWidths( widths3 );
			/* �y�����u�z */	
			cell  = new PdfPCell(new Phrase( outDefItem[19], font9));
			cell.setBackgroundColor(silver);
			cell.setBorder( Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			cell.setVerticalAlignment( Element.ALIGN_MIDDLE );
			Table.addCell(cell);

			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.getDefaultCell().setVerticalAlignment( Element.ALIGN_MIDDLE );
			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setFixedHeight(30);  
			Table.getDefaultCell().setBackgroundColor(blue);
			/* �y�v��z */
			Table.addCell(new Phrase( param_kubun1, font9));
			Table.getDefaultCell().setBackgroundColor(white);
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_LEFT );
			Table.getDefaultCell().setVerticalAlignment( Element.ALIGN_TOP );
			/* �y�����u�f�[�^ �z */
			Table.addCell(new Phrase( outPlanItem[8], font9)); 
			
			/* �v�掞�̏ꍇ */
			if ( kubun.equals("1") ) {
				Table.getDefaultCell().setFixedHeight(0); 
			}
					    
			cell  = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder( Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT );
			Table.addCell(cell);  
			/* �y���сz */
			Table.getDefaultCell().setBackgroundColor(blue);
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.getDefaultCell().setVerticalAlignment( Element.ALIGN_MIDDLE );
			Table.addCell(new Phrase( param_kubun2, font9));
			/* �y�f�[�^�z */  
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_LEFT );
			Table.getDefaultCell().setVerticalAlignment( Element.ALIGN_TOP );
			Table.getDefaultCell().setBackgroundColor(white);
			Table.addCell(new Phrase( outResultItem[8], font9));  
			Table.setTotalWidth(columnWidth);
		    
			currentY = Table.writeSelectedRows(0, -1, document.left(), currentY-10, cb) ;

			/* �y�擾���i�z*/
			Table = new PdfPTable(6);
			int[] widths5 = { 5,5,30,40,10,10 };
			Table.setWidths( widths5 );	
			cell.setBackgroundColor(silver);
			cell.setBorder( Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);
			cell.setBackgroundColor(blue);
			cell.setBorder( Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);
			
			/* �y���i���́A���x���A���_���o���z*/
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER ); 
			Table.getDefaultCell().setBackgroundColor(silver);  
			Table.addCell(new Phrase( outDefItem[21], font9));  
			Table.addCell(new Phrase( outDefItem[3], font9));  
			Table.addCell(new Phrase( outDefItem[22], font9)); 
			Table.addCell(new Phrase( outDefItem[23], font9));  
			Table.setTotalWidth(columnWidth);
			Table.getDefaultCell().setBackgroundColor(white);

            //2�s��
			Table.setWidths( widths5 );	
			cell.setBackgroundColor(silver);
			cell.setBorder( Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);	
			cell.setBackgroundColor(blue);
			cell.setBorder( Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);
			
			/* �y���i���́A���x���A���_�z*/
			Table.getDefaultCell().setFixedHeight(25);
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER ); 
			Table.addCell(new Phrase( sikakumeisyoTop1, font9));  
			Table.addCell(new Phrase( sikakulevelTop1, font9));  
			Table.addCell(new Phrase( sikakutokutenTop1, font9));
			Table.addCell(new Phrase( sikakusyutokuhiTop1, font9));
			
			Table.setTotalWidth(columnWidth);

			//3�s��
			Table.setWidths( widths5 );	
			cell.setBackgroundColor(silver);
			cell.setBorder( Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);
			cell  = new PdfPCell(new Phrase( outDefItem[39], font9 ));	
			cell.setBackgroundColor(blue);
			cell.setBorder( Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);
			
			/* �y���i���́A���x���A���_���o���z*/
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );  
			Table.addCell(new Phrase( sikakumeisyoTop2, font9));  
			Table.addCell(new Phrase( sikakulevelTop2, font9));  
			Table.addCell(new Phrase( sikakutokutenTop2, font9));
			Table.addCell(new Phrase( sikakusyutokuhiTop2, font9));
			 
			Table.setTotalWidth(columnWidth);	
			
			//4�s��		    
			Table.setWidths( widths5 );	
			cell  = new PdfPCell(new Phrase( outDefItem[20], font9));
			cell.setBackgroundColor(silver);
			cell.setBorder( Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);	
			cell  = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(blue);
			cell.setBorder( Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);
			
			/* �y���i���́A���x���A���_���o���z*/
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );  
			Table.addCell(new Phrase( sikakumeisyoTop3, font9));  
			Table.addCell(new Phrase( sikakulevelTop3, font9));  
			Table.addCell(new Phrase( sikakutokutenTop3, font9));
			Table.addCell(new Phrase( sikakusyutokuhiTop3, font9));
			 
			Table.setTotalWidth(columnWidth);	
			
			//5�s�ځy�v��z���y���сz
			Table.setWidths( widths5 );	
			cell  = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder( Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);	
			cell  = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(blue);
			cell.setBorder( Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);
			
			/* �y���i���́A���x���A���_�f�[�^�z*/
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );  
			Table.addCell(new Phrase( sikakumeisyoDown1, font9));  
			Table.addCell(new Phrase( sikakulevelDown1, font9));  
			Table.addCell(new Phrase( sikakutokutenDown1, font9));
			Table.addCell(new Phrase( sikakusyutokuhiDown1, font9));
			 
			Table.setTotalWidth(columnWidth);
			
			//6�s��    
			Table.setWidths( widths5 );
			cell  = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder( Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);
			cell  = new PdfPCell(new Phrase( outDefItem[40], font9));
			cell.setBackgroundColor(blue);
			cell.setBorder( Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);
			
			/* �y���i���́A���x���A���_�f�[�^�z*/
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER ); 
			Table.addCell(new Phrase( sikakumeisyoDown2, font9));  
			Table.addCell(new Phrase( sikakulevelDown2, font9));  
			Table.addCell(new Phrase( sikakutokutenDown2, font9));
			Table.addCell(new Phrase( sikakusyutokuhiDown2, font9));
			 
			Table.setTotalWidth(columnWidth);	
			
			//7�s��
			Table.setWidths( widths5 );	
			cell  = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(silver);
			cell.setBorder( Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);	
			cell  = new PdfPCell(new Phrase("", font9));
			cell.setBackgroundColor(blue);
			cell.setBorder( Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(cell);
			
			/* �y���i���́A���x���A���_�f�[�^�z*/
			Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );
			Table.addCell(new Phrase( sikakumeisyoDown3, font9));  
			Table.addCell(new Phrase( sikakulevelDown3, font9));  
			Table.addCell(new Phrase( sikakutokutenDown3, font9));
			Table.addCell(new Phrase( sikakusyutokuhiDown3, font9));
			Table.setTotalWidth(columnWidth);			

			currentY = Table.writeSelectedRows(0, -1, document.left(), currentY-10, cb) ;
  
			/* �敪=�v��̎��\������ */
			if ( kubun.equals("1") ) {
			    /* �y���ӎ����z */
			    Table = new PdfPTable(1);
			    Table.getDefaultCell().setPaddingTop(0);
			    Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			    Table.addCell(new Phrase( outDefItem[29], font9));
			    Table.setTotalWidth(columnWidth);

			    currentY = Table.writeSelectedRows(0, -1, document.left(), currentY-10, cb) ;
			}       
            
		    /* �y���F�ҁz*/
			Table = new PdfPTable(5);
			int[] widths6 = { 8,35,15,23,19 };
			Table.setWidths( widths6 );	

			cell.setBackgroundColor(white);
			cell.setBorder( Rectangle.RIGHT );
			Table.addCell(cell);

			Table.getDefaultCell().setFixedHeight(25);
		    Table.addCell(new Phrase( outDefItem[12] + "�F" + outPlanItem[44], font9));  
		    Table.addCell(new Phrase( outDefItem[11] + "�F" + outPlanItem[0], font9));
		    Table.addCell(new Phrase( outDefItem[10] + "�F" + outPlanItem[43], font9));
		    Table.addCell(new Phrase( "�쐬���F" + PZZ010_CharacterUtil.ChangeYmd( outPlanItem[39]), font9));
		    
			Table.setTotalWidth(columnWidth);
		    
			Table.setWidths( widths6 );	
			
			cell  = new PdfPCell(new Phrase( "���F�ҁF", font9));
			cell.setBorder( Rectangle.RIGHT );
			Table.addCell(cell);

			Table.addCell(new Phrase( outDefItem[12] + "�F" + hyoka_syozoku, font9));  
			Table.addCell(new Phrase( outDefItem[11] + "�F" + hyoka_simeino, font9));
			Table.addCell(new Phrase( outDefItem[10] + "�F" + hyoka_simei, font9));
			Table.addCell(new Phrase( "���F���F" + PZZ010_CharacterUtil.ChangeYmd( hyoka_jissi ), font9));
		    			
		    Table.setTotalWidth(columnWidth);
		    currentY = Table.writeSelectedRows(0, -1, document.left() +columnWidth + gutter,document.top() - 25 , cb);
            
		    currentY -= 4;	    
		
            /* �y�ʒk���z */
			Table = new PdfPTable(2);
			int[] widths7 = { 8,92 };
			Table.setWidths( widths7 );	
			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			Table.addCell(new Phrase( "�ʒk���F", font9));
			Table.addCell(new Phrase( outDefItem[30], font9line));
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left() +columnWidth + gutter , currentY -5 , cb);
                  
            
            /* �y���Ȍ[���A�ٓ��Ɋւ����]�A�ǋL�����A�㒷�R�����g�z*/
			for ( int i = 0; i < 4; i++ ) {
				Table = new PdfPTable(3);
				Table.setWidths( widths3 );	
				cell  = new PdfPCell(new Phrase(outDefItem[24+i], font9));
				//cell.setPaddingTop(40);
				cell.setBackgroundColor(silver);
				cell.setBorder( Rectangle.TOP | Rectangle.LEFT | Rectangle.RIGHT );
				cell.setHorizontalAlignment( Element.ALIGN_CENTER );
				cell.setVerticalAlignment( Element.ALIGN_BOTTOM);
            
				Table.addCell(cell);
				Table.getDefaultCell().setFixedHeight(50);
				Table.getDefaultCell().setVerticalAlignment( Element.ALIGN_MIDDLE );
				Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );
				Table.getDefaultCell().setBackgroundColor(blue);
				
				Table.addCell(new Phrase( param_kubun1, font9));  
				Table.getDefaultCell().setVerticalAlignment( Element.ALIGN_TOP );
				Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_LEFT);
				Table.getDefaultCell().setBackgroundColor(white);
				Table.getDefaultCell().setPaddingTop(0);
				Table.addCell(new Phrase( param_right_data1[i], font9)); 
		    
				cell  = new PdfPCell(new Phrase("", font9));
				cell.setBackgroundColor(silver);
				cell.setBorder( Rectangle.BOTTOM | Rectangle.LEFT | Rectangle.RIGHT );
            
				Table.addCell(cell);  
				Table.getDefaultCell().setVerticalAlignment( Element.ALIGN_MIDDLE );
				Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_CENTER );
				Table.getDefaultCell().setBackgroundColor(blue);

				Table.addCell(new Phrase( param_kubun2, font9));  
				Table.getDefaultCell().setVerticalAlignment( Element.ALIGN_TOP );
				Table.getDefaultCell().setHorizontalAlignment( Element.ALIGN_LEFT );
				Table.getDefaultCell().setBackgroundColor(white);
				Table.addCell(new Phrase( param_right_data2[i], font9));  
		    
				Table.setTotalWidth(columnWidth);
		    
				currentY = Table.writeSelectedRows(0, -1, document.left() +columnWidth + gutter , currentY -10 , cb);
				currentY -= 4;

            }
            //�ʒk���`
            Table = new PdfPTable(1);

			Table.getDefaultCell().setFixedHeight(155);
			Table.addCell(new Phrase( outDefItem[32], font9));
			Table.setTotalWidth(columnWidth);
  
			currentY = Table.writeSelectedRows(0, -1, document.left() +columnWidth + gutter , currentY -10 , cb);
			 
			//���ӎ���
			Table = new PdfPTable(1);	
			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			Table.addCell(new Phrase( outDefItem[31], font9));
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left() +columnWidth + gutter , currentY -10 , cb);

			Table = new PdfPTable(1);	
			Table.getDefaultCell().setPaddingTop(0);
			Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			Table.addCell(new Phrase( outDefItem[41], font9));
			Table.setTotalWidth(columnWidth);

			currentY = Table.writeSelectedRows(0, -1, document.left() +columnWidth + gutter , currentY -2 , cb);

                        
            document.close();
			Log.method( login_no , "OUT" , "" );

		} catch ( BadElementException e ) {
			  throw (Exception)e;
		} catch ( DocumentException e ) {
			  throw (Exception)e;
		} catch ( IOException e ) {
			  throw (Exception)e;
		} catch ( Exception e ){
			  throw (Exception)e;
		} finally {
			/* �h�L�������g����� */
			if (document != null) {
				try {
					document.close();
				} catch (Exception e) {
					System.out.println(e);
				}
			}
				try {
				} catch (Exception e) {
					System.out.println(e);
					// �������Ȃ�
				}
		}
	}
}
