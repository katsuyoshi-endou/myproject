/*
 * @(#)PZE_KouboBodyMaker.java 2004/08/16
 * Copyright (C) Hitachi, Ltd. 2004. All rights reserved.
 */

package jp.co.hisas.career.util.pdf.koubo;

import java.io.IOException;

import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Rectangle;
import com.lowagie.text.Table;

import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboKibouSyokusyuBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboAnkenBean;

/**
 * 
 * @version 1.0
 * @since 1.0
 */
public class PZE_KouboBodyMaker {
	private PZE_KouboPdfMaker parent = null;
	private String prTitle = null;

	public PZE_KouboBodyMaker(PZE_KouboPdfMaker parent) {
		this.parent = parent;
		if (parent instanceof PZE_KouboAnkenHyojiPDFMaker) {
			prTitle = "���啔�������PR";
		}
		else {
			prTitle = "����҂ւ�PR";
		}

	}

	/**
	 * �o�c�e���쐬����B
	 *
	 * @param os   �o�̓X�g���[��
	 * @param userInfo ���O�C�����[�U���
	 * @param pdfData PDF�o�͗p�f�[�^
	 * @return �����̏ꍇ�Ftrue�A���s�̏ꍇ�Ffalse
	 * @exception DocumentException
	 */
	public void makeBody(String ankenTitle, PEY_PersonalBean userInfo, PEB_KouboAnkenBean pdfData, Document document) throws DocumentException, IOException {
		makeSinseiAnken(ankenTitle, pdfData, document);	
		makeOuboYouken(pdfData, document);		
		makeSinseiRiyu(pdfData, document);		
	}
	
	/**
	 * �o�c�e���쐬����B
	 *
	 * @param os   �o�̓X�g���[��
	 * @param userInfo ���O�C�����[�U���
	 * @param pdfData PDF�o�͗p�f�[�^
	 * @param pdftype PDF�o�̓^�C�v
	 * @return �����̏ꍇ�Ftrue�A���s�̏ꍇ�Ffalse
	 * @exception DocumentException
	 */
	public void makeBody(String ankenTitle, PEY_PersonalBean userInfo, PEB_KouboAnkenBean pdfData, Document document,int pdftype) throws DocumentException, IOException {
		makeSinseiAnken(ankenTitle, pdfData, document);	
		makeOuboYouken(pdfData, document);
//		C-ADT02-002-S
		if( pdftype == 1 ){
			makeSinseiRiyu(pdfData, document);		
		}
//		C-ADT02-002-E
	}

	private void makeSinseiAnken(String ankenTitle, PEB_KouboAnkenBean pdfData, Document document) throws DocumentException {

		Table table = new Table(10, 11);		
		parent.setTableDefault(table);
		table.setWidths(new int[]{19, 1, 10, 10, 10, 10, 10, 10, 10, 10});
		
		PEY_KouboBean kouboData = pdfData.getKouboBean(); 
		
		Cell cell = null;
		// 0�i��
		cell = parent.makeSmallChapterCell(ankenTitle);
		cell.setColspan(10);
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);

		// 1�i��
		cell = parent.makeBigChapterCell("����Č���\n�i�v���W�F�N�g���j");
		table.addCell(cell);
		cell = parent.makeDmyCell();
		table.addCell(cell);		
		
		cell = parent.makeNormalCell(parent.nvl(kouboData.getKouboankenmei()));
		cell.setColspan(8);
		table.addCell(cell);

		// 2�i��
		cell = parent.makeBigChapterCell("�Č��T�v");
		table.addCell(cell);
		cell = parent.makeDmyCell();
		table.addCell(cell);		

		cell = parent.makeNormalCell(parent.nvl(kouboData.getAnkengaiyo()));
		cell.setHorizontalAlignment(Rectangle.LEFT);
		cell.setColspan(8);
		table.addCell(cell);

		// 3�i��
		cell = parent.makeBigChapterCell("��W�l��");
		table.addCell(cell);
		cell = parent.makeDmyCell();
		table.addCell(cell);		

		Integer bosyuNinzu = kouboData.getBosyuninzu();
		cell = parent.makeNormalCell(bosyuNinzu == null ? "0" : bosyuNinzu.toString());
		table.addCell(cell);
		
		cell = parent.makeNormalCell("��");
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setHorizontalAlignment(Rectangle.LEFT);
		cell.setColspan(7);
		table.addCell(cell);

		// 4�i��
		cell = parent.makeBigChapterCell("�ٓ���]����");
		table.addCell(cell);
		cell = parent.makeDmyCell();
		table.addCell(cell);		

		cell = parent.makeNormalCell(parent.nvl(kouboData.getIdoukiboujiki()));
		cell.setHorizontalAlignment(Rectangle.LEFT);
		cell.setColspan(8);
		table.addCell(cell);

		// 5-7�i��
		cell = parent.makeBigChapterCell("��W�E��^\n�Ɩ����e�Ȃ�");
		cell.setVerticalAlignment(Rectangle.ALIGN_MIDDLE);
		cell.setRowspan(10);
		table.addCell(cell);
		
		PEB_KouboKibouSyokusyuBean[] kiboSyokusyu = pdfData.getKouboKibouSyokusyuBean();
		int max = kiboSyokusyu.length;
		if (max > 3) {
			max = 3;	// 3���ȏ�͕\�����Ȃ��B
		}
		int i = 0;
		for (i = 0; i < max;++i) {
			table.addCell(parent.makeDmyCell());		
			table.addCell(parent.makeMiddleChapterCell("�E��"));
			cell = parent.makeNormalCell(parent.nvl(kiboSyokusyu[i].getSyokuName()));
			cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
			cell.setColspan(2);
			table.addCell(cell);
			table.addCell(parent.makeMiddleChapterCell("��啪��"));
			cell = parent.makeNormalCell(parent.nvl(kiboSyokusyu[i].getSenmonName()));
			cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
			cell.setColspan(2);
			table.addCell(cell);
			table.addCell(parent.makeMiddleChapterCell("���x��"));
			table.addCell(parent.makeNormalCell(parent.nvl(kiboSyokusyu[i].getLevelCode())));
		}
		for (int j = i; j < 3; ++j) {
			table.addCell(parent.makeDmyCell());		
			table.addCell(parent.makeMiddleChapterCell("�E��"));
			cell = parent.makeNormalCell("");
			cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
			cell.setColspan(2);
			table.addCell(cell);
			table.addCell(parent.makeMiddleChapterCell("��啪��"));
			cell = parent.makeNormalCell("");
			cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
			cell.setColspan(2);
			table.addCell(cell);
			table.addCell(parent.makeMiddleChapterCell("���x��"));
			table.addCell(parent.makeNormalCell(""));
			 
		}

		// 8�i��
		table.addCell(parent.makeDmyCell());		
		cell = parent.makeMiddleChapterCell("���̑��E��");
		cell.setColspan(2);
		table.addCell(cell);
		cell = parent.makeNormalCell(parent.nvl(kouboData.getKibousyokusyuSonota()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		cell.setColspan(6);
		table.addCell(cell);

		// 9�i��
		table.addCell(parent.makeDmyCell());		
		cell = parent.makeMiddleChapterCell("�����^�Ζ��n");
		cell.setColspan(2);
		table.addCell(cell);
		cell = parent.makeNormalCell(parent.nvl(kouboData.getSyozokukinmuti()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		cell.setColspan(6);
		table.addCell(cell);

		// 10�i��
		table.addCell(parent.makeDmyCell());		
		cell = parent.makeMiddleChapterCell("���Җ���");
		cell.setColspan(2);
		table.addCell(cell);
		boolean added = false;
		StringBuffer kitaiYakuwari = new StringBuffer();
		if ("1".equals(kouboData.getKitaiyakuwaributyo())) {
			kitaiYakuwari.append("����");
			added = true;
		}
		if ("1".equals(kouboData.getKitaiyakuwarisyuningisi())) {
			if (added) {
				kitaiYakuwari.append(" ");
			}
			kitaiYakuwari.append("��C�Z�t�E�����㗝");
			added = true;
		}
		if ("1".equals(kouboData.getKitaiyakuwarigisi())) {
			if (added) {
				kitaiYakuwari.append(" ");
			}
			kitaiYakuwari.append("�Z�t�E��C");
			added = true;
		}
		if ("1".equals(kouboData.getKitaiyakuwariippan())) {
			if (added) {
				kitaiYakuwari.append(" ");
			}
			kitaiYakuwari.append("���");
		}
		
		cell = parent.makeNormalCell(parent.nvl(kitaiYakuwari.toString()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		cell.setColspan(6);
		table.addCell(cell);


		// 11�i��
		table.addCell(parent.makeDmyCell());		
		cell = parent.makeMiddleChapterCell("�Ɩ����e");
		cell.setVerticalAlignment(Rectangle.ALIGN_MIDDLE);
		cell.setColspan(2);
		table.addCell(cell);
		cell = parent.makeNormalCell(parent.nvl(kouboData.getGyomunaiyo()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		cell.setColspan(6);
		table.addCell(cell);

		document.add(table);
	}

	/**
	 * PDF�̐\�����鉞��҂̗v���������B
	 * @param pdfData PDF�o�͗p�f�[�^�B
	 * @param document PDF�h�L�������g�B
	 * @throws DocumentException
	 */
	private void makeOuboYouken(PEB_KouboAnkenBean pdfData, Document document) throws DocumentException {
		Table table = new Table(4, 5);		
		parent.setTableDefault(table);
		table.setWidths(new int[]{19, 1, 30, 50});

		PEY_KouboBean kouboData = pdfData.getKouboBean(); 
		
		Cell cell = null;
		// 0�i��
		cell = parent.makeSmallChapterCell("������҂̗v��");
		cell.setColspan(4);
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);

		// 1�i��
		cell = parent.makeBigChapterCell("����҂̗v��");
		cell.setVerticalAlignment(Rectangle.ALIGN_MIDDLE);
		cell.setRowspan(3);
		table.addCell(cell);
		table.addCell(parent.makeDmyCell());
		table.addCell(parent.makeMiddleChapterCell("�W���u�O���[�h�i�i�t���j"));		
		cell = parent.makeNormalCell(parent.nvl(kouboData.getJobgrade()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);

		// 2�i��
		table.addCell(parent.makeDmyCell());
		table.addCell(parent.makeMiddleChapterCell("�E���o���^�o���N��"));		
		cell = parent.makeNormalCell(parent.nvl(kouboData.getSyokumurireki()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);

		// 3�i��
		table.addCell(parent.makeDmyCell());
		table.addCell(parent.makeMiddleChapterCell("���̑�"));	
		cell = parent.makeNormalCell(parent.nvl(kouboData.getOubosyayoukensonota()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);
		

		// 4�i��
		table.addCell(parent.makeBigChapterCell(prTitle));
		table.addCell(parent.makeDmyCell());
		cell = parent.makeNormalCell(parent.nvl(kouboData.getKoubopr()));
		cell.setColspan(2);
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);
		
		document.add(table);

	}

	/**
	 * PDF�̐\�����鉞��҂̐\�����R�������B
	 * @param pdfData PDF�o�͗p�f�[�^�B
	 * @param document PDF�h�L�������g�B
	 * @throws DocumentException
	 */
	private void makeSinseiRiyu(PEB_KouboAnkenBean pdfData, Document document) throws DocumentException {
		Table table = new Table(3, 2);		
		parent.setTableDefault(table);
		table.setWidths(new int[]{19, 1, 80});

		PEY_KouboBean kouboData = pdfData.getKouboBean(); 
		
		Cell cell = null;
		// 0�i��
		cell = parent.makeSmallChapterCell("���\�����R");
		cell.setColspan(3);
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);

		// 1�i��
		cell = parent.makeBigChapterCell("�\�����R");
		table.addCell(cell);
		table.addCell(parent.makeDmyCell());
		cell = parent.makeNormalCell(parent.nvl(kouboData.getSinseiriyu()));
		cell.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
		table.addCell(cell);
		
		document.add(table);

	}

}
