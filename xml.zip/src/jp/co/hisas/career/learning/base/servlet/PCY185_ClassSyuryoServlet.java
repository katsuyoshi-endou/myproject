/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_KensyuMailSender;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F PCY185_ClassSyuryoServlet �N���X �@�\�����F �擾�������C�Ώێҏ����N���X�I�������`�F�b�N���܂��B
 * 
 * </PRE>
 */
public class PCY185_ClassSyuryoServlet extends PCY010_ControllerServlet {
	/**
	 * �N���X�I���������Ăяo���܂��B
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		/* �I��������N���X�̌��������ƂȂ�N���XBean���쐬 */
		final PCY_ClassBean classBean = new PCY_ClassBean(request);
		classBean.setKousinbi(request.getParameter("kousin_bi"));
		classBean.setKousinjikoku(request.getParameter("kousin_jikoku"));

		/* �N���X�I���������Ăяo�� */
		final PCY_ClassEJBHome class_home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB class_ejb = class_home.create();

		try {
			Log.transaction(loginuser.getSimeiNo(), true, "");
			class_ejb.doClassSyuryo(classBean, loginuser);

			/* ���C�Ǘ������擾 */
			final PCY_MousikomiJyokyoEJBHome mousikomihome = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
			final PCY_MousikomiJyokyoEJB mousikomi_ejb = mousikomihome.create();

			final PCY_KensyuRirekiBean rirekiBean = new PCY_KensyuRirekiBean();
			rirekiBean.setKamokuCode(classBean.getKamokuBean().getKamokuCode());
			rirekiBean.setClassCode(classBean.getClassCode());
			final PCY_KensyuRirekiBean[] kensyuRirekiBeans = mousikomi_ejb.getListL51(rirekiBean, loginuser);

// DEL 2017/05/16 COMTURE VCC07a_��u����(ver.02-00) START
//			try {
//				/* �ē����[���敪���v�̃N���X�ɑ΂��āA���[���𑗐M���� */
//				if (kensyuRirekiBeans != null && kensyuRirekiBeans.length != 0 && kensyuRirekiBeans[0].getAnnaiMailKubun() != null && kensyuRirekiBeans[0].getAnnaiMailKubun().equals("1")) {
//					PCY_KensyuMailSender.sendSeisekiTuuchi(kensyuRirekiBeans, loginuser);
//				}
//			} catch (final Exception e) {
//				request.setAttribute("warningID", "WCC175");
//				throw new PCY_WarningException(e);
//			}
// DEL 2017/05/16 COMTURE VCC07a_��u����(ver.02-00) END
// ADD 2018/03/13 COMTURE VCC07a_��u����iPh.2-3�j START
            try {
                // career.properties�ŁuMAIL_XCC100�v��1�̏ꍇ�A���M����B
                if ("1".equals(ReadFile.fileMapData.get("MAIL_XCC100"))) {
                    /* �ē����[���敪���v�̃N���X�ɑ΂��āA���[���𑗐M���� */
                    if (kensyuRirekiBeans != null
                            && kensyuRirekiBeans.length != 0
                            && kensyuRirekiBeans[0].getAnnaiMailKubun() != null
                            && kensyuRirekiBeans[0].getAnnaiMailKubun().equals(
                                    "1")) {
                        PCY_KensyuMailSender.sendSeisekiTuuchi(
                                kensyuRirekiBeans, loginuser);
                    }
                }
            } catch (final Exception e) {
                request.setAttribute("warningID", "WCC175");
                throw new PCY_WarningException(e);
            }
// ADD 2018/03/13 COMTURE VCC07a_��u����iPh.2-3�j END

			Log.transaction(loginuser.getSimeiNo(), false, "");
		} catch (final PCY_WarningException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			if (e.getMessage().equals("WCC160")) {
				request.setAttribute("warningID", "WCC160");
				throw e;
			} else if (e.getMessage().equals("WCC170")) {
				request.setAttribute("warningID", "WCC170");
				throw e;
			} else if (e.getMessage().equals("WCC161")) {
				request.setAttribute("warningID", "WCC161");
				throw e;
			} else if (e.getMessage().equals("WCC163")) {
				request.setAttribute("warningID", "WCC163");
				throw e;
			} else if (e.getMessage().equals("WCC162")) {
				request.setAttribute("warningID", "WCC162");
				throw e;
			} else {
				throw e;
			}
		}

		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
