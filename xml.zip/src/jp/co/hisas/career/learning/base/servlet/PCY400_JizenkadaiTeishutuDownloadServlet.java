/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJB;
import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJBHome;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_JizenkadaiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_JizenkadaiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_JizenkadaiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * �N���X���F PCY400_JizenkadaiTeishutuDownloadServlet �N���X �@�\�����F ��o�������m�F���܂��B
 * </PRE>
 * ADD 2017/05/15 COMTURE VCA400_���O�ۑ�ҏW�iver.02-00�j
 */
public class PCY400_JizenkadaiTeishutuDownloadServlet extends PCY010_ControllerServlet {

    /**
     * ���N�G�X�g����v���C�}���L�[���擾���A�N���X�����擾���܂��B �N���X���̓��N�G�X�g(�������F"classBean")�Ɋi�[���܂��B �N���X��񂪑��݂��Ȃ��ꍇ�A���N�G�X�g�ɂ� null ���i�[����܂��B
     * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
     * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean )
     */
    protected String execute(final HttpServletRequest request, final HttpServletResponse response,
            final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException, Exception {

        // ���\�b�h�g���[�X�o��
        Log.method(loginuser.getSimeiNo(), "IN", "");

        final EJBHomeFactory fact = EJBHomeFactory.getInstance();

        // ���O�ۑ�󋵂��擾
        final PCY_JizenkadaiJyokyoEJBHome home =
                (PCY_JizenkadaiJyokyoEJBHome)fact.lookup(PCY_JizenkadaiJyokyoEJBHome.class);
        final PCY_JizenkadaiJyokyoEJB ejb = home.create();
        final PCY_JizenkadaiJyokyoBean jizenkadaiJyokyoBean =
                ejb.doSelectByPrimaryKey(new PCY_JizenkadaiJyokyoBean(request), loginuser);

        // ���O�ۑ�󋵑��݃`�F�b�N
        if (jizenkadaiJyokyoBean == null) {
            request.setAttribute("warningID", "WCC272");
            throw new PCY_WarningException("WCC272");
        }

        // �L�[
        final String[] primaryKey = { "KAMOKU_CODE", "CLASS_CODE", "SIMEI_NO" };

        // �L�[�l
        final String[] keyValue =
                { jizenkadaiJyokyoBean.getKamokuCode(), jizenkadaiJyokyoBean.getClassCode(),
                        jizenkadaiJyokyoBean.getSimeiNo() };

        // �t�@�C�����擾
        final PYF_BlobDBAccessEJBHome blobHome = (PYF_BlobDBAccessEJBHome)fact.lookup(PYF_BlobDBAccessEJBHome.class);
        final PYF_BlobDBAccessEJB blobEjb = blobHome.create();
        final byte[] jizenkadai =
                blobEjb.SelectBLOB(loginuser.getSimeiNo(), HcdbDef.L15_JIZENKADAI_JYOKYO_TBL, "JIZENKADAI", primaryKey,
                        keyValue);

        // �t�@�C�����݃`�F�b�N
        if ((jizenkadai == null) || (jizenkadai.length == 0)) {
            request.setAttribute("warningID", "WCC272");
            throw new PCY_WarningException("WCC272");
        }

        // �t�@�C�����
// DEL 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2) START
//        request.setAttribute("H080_FileName",
//        		URLEncoder.encode(PZZ010_CharacterUtil.normalizedStr(jizenkadaiJyokyoBean.getJizenkadaiFilename()), "UTF-8"));
// DEL 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2) END
// ADD 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2) START
        // �t�@�C�����Ɋ܂܂�锼�p�X�y�[�X��"-"�ɒu��
        String fileName = PZZ010_CharacterUtil.normalizedStr(jizenkadaiJyokyoBean.getJizenkadaiFilename()).replaceAll(" ", "-");
        request.setAttribute("H080_FileName",URLEncoder.encode(fileName, "UTF-8"));
// ADD 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2) END
        request.setAttribute("H081_ContentType", jizenkadaiJyokyoBean.getJizenkadaiContentType());
        request.setAttribute("STREAM", new ByteArrayInputStream(jizenkadai));

        // ���\�b�h�g���[�X�o��
        Log.method(loginuser.getSimeiNo(), "OUT", "");

        return this.getForwardPath();
    }
}
