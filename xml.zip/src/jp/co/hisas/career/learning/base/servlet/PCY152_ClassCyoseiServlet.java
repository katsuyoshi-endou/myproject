/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.CreateException;
import javax.mail.internet.AddressException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_KensyuMailSender;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassCyouseiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassCyouseiEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassCyouseiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_DaikoNyuryokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.learning.base.ejb.PCY_DaikoNyuryokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_DaikoNyuryokuEJBHome;

/**
 * <PRE>
 * 
 * �N���X���F PCY152_ClassCyoseiServlet �N���X �@�\�����F �N���X�����ł̐\����t�E���߁E������s���܂��B
 * 
 * </PRE>
 */
public class PCY152_ClassCyoseiServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException, Exception {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final String command = request.getParameter("exec_command");
		String riyu = request.getParameter("riyu");
		if (riyu == null) {
			riyu = "";
		}

		PCY_ClassBean classBean = new PCY_ClassBean(request);
		classBean.getKamokuBean().setKousinbi(null); // �Ȗڃ}�X�^�̍X�V���E�X�V�����̓`�F�b�N���Ȃ�
		classBean.getKamokuBean().setKousinjikoku(null);
		final String kubun = classBean.getAnnaiMailKubun();
		final List mousikomisyaList = new ArrayList();
		final List taisyosyaList = new ArrayList();
		int index = 0;

		String[] simeiNo_req = null;
		if ((command.equals("uketukesasimodosi") || command.equals("torikesisasimodosi")) && !kubun.equals("0")) {
			Log.debug("simeiIndex �擾");
			final String simeiLengthStr = request.getParameter("simeiLength");
			final int length = (new Integer(simeiLengthStr)).intValue();
			simeiNo_req = new String[length];

			for (int t = 0; t < length; t++) {
				simeiNo_req[t] = request.getParameter("simeiNo_" + Integer.toString(t));

				final String simeiNo = request.getParameter("simei_no_" + simeiNo_req[t]);

				if (simeiNo == null || simeiNo.length() == 0) {
					break;
				}

				final PCY_MousikomiJyokyoBean mousikomi = new PCY_MousikomiJyokyoBean();
				mousikomi.setSimeiNo(simeiNo);
				mousikomi.setKamokuCode(classBean.getKamokuBean().getKamokuCode());
				mousikomi.setClassCode(classBean.getClassCode());
				mousikomi.setKousinbi(request.getParameter("kousinbi_" + simeiNo_req[t]));
				mousikomi.setKousinjikoku(request.getParameter("kousinjikoku_" + simeiNo_req[t]));
				mousikomi.setClassBean(classBean);

				mousikomi.setMousikomibi(request.getParameter("mousikomibi_" + simeiNo_req[t]));
				mousikomi.setMousikomijikoku(request.getParameter("mousikomijikoku_" + simeiNo_req[t]));
				mousikomi.setMousikomisya(request.getParameter("mousikomisya_" + simeiNo_req[t]));
				mousikomi.setSyoninbi1(request.getParameter("syoninbi1_" + simeiNo_req[t]));
				mousikomi.setSyoninjikoku1(request.getParameter("syoninjikoku1_" + simeiNo_req[t]));
				mousikomi.setSyoninsya1(request.getParameter("syoniinsya1_" + simeiNo_req[t]));
				mousikomi.setSyoninbi2(request.getParameter("syoninbi2_" + simeiNo_req[t]));
				mousikomi.setSyoninjikoku2(request.getParameter("syoninjikoku2_" + simeiNo_req[t]));
				mousikomi.setSyoninsya2(request.getParameter("syoninsya2_" + simeiNo_req[t]));
				mousikomi.setUketukebi(request.getParameter("uketukebi_" + simeiNo_req[t]));
				mousikomi.setUketukejikoku(request.getParameter("uketukejikoku_" + simeiNo_req[t]));
				mousikomi.setUketukesya(request.getParameter("uketukesya_" + simeiNo_req[t]));

				mousikomisyaList.add(mousikomi);

				final PCY_TaisyosyaBean taisyo = new PCY_TaisyosyaBean();
				taisyo.setTaisyoKubun(request.getParameter("taisyokubun_" + simeiNo_req[t]));

				taisyosyaList.add(taisyo);

			}
		} else {

			while (true) {
				final String simeiNo = request.getParameter("simei_no_" + index);

				if (simeiNo == null || simeiNo.length() == 0) {
					break;
				}

				final PCY_MousikomiJyokyoBean mousikomi = new PCY_MousikomiJyokyoBean();
				mousikomi.setSimeiNo(simeiNo);
				mousikomi.setKamokuCode(classBean.getKamokuBean().getKamokuCode());
				mousikomi.setClassCode(classBean.getClassCode());
				mousikomi.setKousinbi(request.getParameter("kousinbi_" + index));
				mousikomi.setKousinjikoku(request.getParameter("kousinjikoku_" + index));
				mousikomi.setClassBean(classBean);

				mousikomi.setMousikomibi(request.getParameter("mousikomibi_" + index));
				mousikomi.setMousikomijikoku(request.getParameter("mousikomijikoku_" + index));
				mousikomi.setMousikomisya(request.getParameter("mousikomisya_" + index));
				mousikomi.setSyoninbi1(request.getParameter("syoninbi1_" + index));
				mousikomi.setSyoninjikoku1(request.getParameter("syoninjikoku1_" + index));
				mousikomi.setSyoninsya1(request.getParameter("syoniinsya1_" + index));
				mousikomi.setSyoninbi2(request.getParameter("syoninbi2_" + index));
				mousikomi.setSyoninjikoku2(request.getParameter("syoninjikoku2_" + index));
				mousikomi.setSyoninsya2(request.getParameter("syoninsya2_" + index));
				mousikomi.setUketukebi(request.getParameter("uketukebi_" + index));
				mousikomi.setUketukejikoku(request.getParameter("uketukejikoku_" + index));
				mousikomi.setUketukesya(request.getParameter("uketukesya_" + index));

				mousikomisyaList.add(mousikomi);

				final PCY_TaisyosyaBean taisyo = new PCY_TaisyosyaBean();
				taisyo.setTaisyoKubun(request.getParameter("taisyokubun_" + index));

				taisyosyaList.add(taisyo);

				index++;
			}
		}

		final PCY_MousikomiJyokyoBean[] mousikomiBeans = new PCY_MousikomiJyokyoBean[mousikomisyaList.size()];
		mousikomisyaList.toArray(mousikomiBeans);

		final PCY_TaisyosyaBean[] taisyosyaBeans = new PCY_TaisyosyaBean[taisyosyaList.size()];
		taisyosyaList.toArray(taisyosyaBeans);

		// EJB�擾
		final PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_MousikomiJyokyoEJB ejb = home.create();

		if (command.equals("uketuke")) {
			/* ��t�̏ꍇ */
			String nextStatus = null;

			if (classBean.getHoukokuKubun().equals("0")) {
				/* �N���X�}�X�^�̕񍐋敪���s�v�ł���ꍇ */
				nextStatus = "3"; /* ���̏�Ԃ́u����ҁv */
			} else {
				nextStatus = "2"; /* ���̏�Ԃ́u�񍐑ҁv */
			}

			for (int i = 0; i < mousikomiBeans.length; i++) {
				mousikomiBeans[i].setStatus(nextStatus);
			}

			/* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doUpdateStatus(mousikomiBeans, loginuser, false);
			Log.transaction(loginuser.getSimeiNo(), false, "");
		} else if (command.equals("sasimodosi")) {
			/* ���߂̏ꍇ */
			/* �\���󋵃e�[�u���̃��R�[�h�폜 */
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doCancel(mousikomiBeans, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");
		} else if (command.equals("torikesi")) {
			/* ����̏ꍇ */
			for (int i = 0; i < mousikomiBeans.length; i++) {
				mousikomiBeans[i].setStatus("1"); /* ���̏�Ԃ́u��t�ҁv */
			}

			/* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doUpdateStatus(mousikomiBeans, loginuser, false);
			Log.transaction(loginuser.getSimeiNo(), false, "");
		} else if (command.equals("uketukekanryotorikesi")) {
			for (int i = 0; i < mousikomiBeans.length; i++) {
				mousikomiBeans[i].setStatus("1");
				mousikomiBeans[i].setUketsukeJyotai("1");
			}

			/* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doUpdateStatusAndUketuke(mousikomiBeans, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");
			OutLogBean.sousaKojinJohoLog("VCC057", loginuser.getSimeiNo(), null, classBean.getKamokuBean().getKamokuCode() + "," + classBean.getClassCode());
		} else if (command.equals("uketukekaisi")) {
			/* ��t�J�n */
			final PCY_ClassCyouseiEJBHome home1 = (PCY_ClassCyouseiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassCyouseiEJBHome.class);
			final PCY_ClassCyouseiEJB ejb1 = home1.create();

			final PCY_ClassCyouseiBean[] classCyouseiBeans = new PCY_ClassCyouseiBean[mousikomiBeans.length];

			final String now_day = PZZ010_CharacterUtil.GetDay();
			final String now_time = PZZ010_CharacterUtil.GetTime();

			for (int i = 0; i < mousikomiBeans.length; i++) {
				final PCY_MousikomiJyokyoBean[] mou = ejb.getList(mousikomiBeans[i], loginuser);

				mousikomiBeans[i].setStatus("1");
				mousikomiBeans[i].setUketsukeJyotai("1");

				final PCY_ClassCyouseiBean classCyouseiBean = new PCY_ClassCyouseiBean();
				classCyouseiBean.setSyoribi(now_day);
				classCyouseiBean.setSyorijikoku(now_time);
				classCyouseiBean.setSyorisya(loginuser.getSimeiNo());
				classCyouseiBean.setSyoriFlg("0");
				classCyouseiBean.setDlKaisu(new Integer(0));
				classCyouseiBean.setKamokuCode(mou[0].getKamokuCode());
				classCyouseiBean.setClassCode(mou[0].getClassCode());
				classCyouseiBean.setSimeiNo(mou[0].getSimeiNo());
				classCyouseiBean.setAfterStatus("1");
				classCyouseiBean.setAfterUketukeJyotai("1");
				classCyouseiBean.setBeforeStatus("1");
				classCyouseiBean.setBeforeUketsukeJyotai("0");
				classCyouseiBean.setMousikomibi(mou[0].getMousikomibi());
				classCyouseiBean.setMousikomijikoku(mou[0].getMousikomijikoku());
				classCyouseiBean.setMousikomisya(mou[0].getMousikomisya());
				classCyouseiBean.setSyoninbi1(mou[0].getSyoninbi1());
				classCyouseiBean.setSyoninjikoku1(mou[0].getSyoninjikoku1());
				classCyouseiBean.setSyoninsya1(mou[0].getSyoninsya1());
				classCyouseiBean.setSyoninbi2(mou[0].getSyoninbi2());
				classCyouseiBean.setSyoninjikoku2(mou[0].getSyoninjikoku2());
				classCyouseiBean.setSyoninsya2(mou[0].getSyoninsya2());
				classCyouseiBean.setUketukebi(mou[0].getUketukebi());
				classCyouseiBean.setUketukejikoku(mou[0].getUketukejikoku());
				classCyouseiBean.setUketukesya(mou[0].getUketukesya());

				classCyouseiBeans[i] = classCyouseiBean;

			}
			/* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doUpdateStatusAndUketuke(mousikomiBeans, loginuser);
			ejb1.doInsert(classCyouseiBeans, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");

			OutLogBean.sousaKojinJohoLog("VCC301", loginuser.getSimeiNo(), null, classBean.getKamokuBean().getKamokuCode() + "," + classBean.getClassCode());
		} else if (command.equals("syouninmachisasimodosi")) {
			/* ���F�ҍ��߂� */
			for (int i = 0; i < mousikomiBeans.length; i++) {
				mousikomiBeans[i].setStatus("1");
				mousikomiBeans[i].setUketsukeJyotai("2");
			}

			/* �\���󋵃e�[�u�����폜�X�V */
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doCancel(mousikomiBeans, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");
			OutLogBean.sousaKojinJohoLog("VCC311", loginuser.getSimeiNo(), null, classBean.getKamokuBean().getKamokuCode() + "," + classBean.getClassCode());
		} else if (command.equals("uketukekanryo")) {
			/* ��t���� */
			for (int i = 0; i < mousikomiBeans.length; i++) {
				mousikomiBeans[i].setStatus("1");
				mousikomiBeans[i].setUketsukeJyotai("2");
			}

			/* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doUpdateStatusAndUketuke(mousikomiBeans, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");
			OutLogBean.sousaKojinJohoLog("VCC303", loginuser.getSimeiNo(), null, classBean.getKamokuBean().getKamokuCode() + "," + classBean.getClassCode());
		} else if (command.equals("torikesikaisi")) {
			/* ����J�n */
			final PCY_ClassCyouseiEJBHome home1 = (PCY_ClassCyouseiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassCyouseiEJBHome.class);
			final PCY_ClassCyouseiEJB ejb1 = home1.create();

			final PCY_ClassCyouseiBean[] classCyouseiBeans = new PCY_ClassCyouseiBean[mousikomiBeans.length];
			final String now_day = PZZ010_CharacterUtil.GetDay();
			final String now_time = PZZ010_CharacterUtil.GetTime();

			for (int i = 0; i < mousikomiBeans.length; i++) {
				final PCY_MousikomiJyokyoBean[] mou = ejb.getList(mousikomiBeans[i], loginuser);

				mousikomiBeans[i].setStatus("1");
				mousikomiBeans[i].setUketsukeJyotai("4");

				final PCY_ClassCyouseiBean classCyouseiBean = new PCY_ClassCyouseiBean();
				classCyouseiBean.setSyoribi(now_day);
				classCyouseiBean.setSyorijikoku(now_time);
				classCyouseiBean.setSyorisya(loginuser.getSimeiNo());
				classCyouseiBean.setSyoriFlg("1");
				classCyouseiBean.setDlKaisu(new Integer(0));
				classCyouseiBean.setKamokuCode(mou[0].getKamokuCode());
				classCyouseiBean.setClassCode(mou[0].getClassCode());
				classCyouseiBean.setSimeiNo(mou[0].getSimeiNo());
				classCyouseiBean.setAfterStatus("1");
				classCyouseiBean.setAfterUketukeJyotai("4");
				classCyouseiBean.setBeforeStatus("1");
				classCyouseiBean.setBeforeUketsukeJyotai("3");
				classCyouseiBean.setMousikomibi(mou[0].getMousikomibi());
				classCyouseiBean.setMousikomijikoku(mou[0].getMousikomijikoku());
				classCyouseiBean.setMousikomisya(mou[0].getMousikomisya());
				classCyouseiBean.setSyoninbi1(mou[0].getSyoninbi1());
				classCyouseiBean.setSyoninjikoku1(mou[0].getSyoninjikoku1());
				classCyouseiBean.setSyoninsya1(mou[0].getSyoninsya1());
				classCyouseiBean.setSyoninbi2(mou[0].getSyoninbi2());
				classCyouseiBean.setSyoninjikoku2(mou[0].getSyoninjikoku2());
				classCyouseiBean.setSyoninsya2(mou[0].getSyoninsya2());
				classCyouseiBean.setUketukebi(mou[0].getUketukebi());
				classCyouseiBean.setUketukejikoku(mou[0].getUketukejikoku());
				classCyouseiBean.setUketukesya(mou[0].getUketukesya());

				classCyouseiBeans[i] = classCyouseiBean;
			}

			/* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doUpdateStatusAndUketuke(mousikomiBeans, loginuser);
			ejb1.doInsert(classCyouseiBeans, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");
			OutLogBean.sousaKojinJohoLog("VCC305", loginuser.getSimeiNo(), null, classBean.getKamokuBean().getKamokuCode() + "," + classBean.getClassCode());
		} else if (command.equals("torikesisasimodosi")) {
			/* ������� */
			for (int i = 0; i < mousikomiBeans.length; i++) {
				mousikomiBeans[i].setStatus("1");
				mousikomiBeans[i].setUketsukeJyotai("2");
			}

			/* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doUpdateStatusAndUketuke(mousikomiBeans, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");
			OutLogBean.sousaKojinJohoLog("VCC309", loginuser.getSimeiNo(), null, classBean.getKamokuBean().getKamokuCode() + "," + classBean.getClassCode());
		} else if (command.equals("uketukesasimodosi")) {
			/* ��t���߂̏ꍇ */
			// ��s���͂̏ꍇ������̂ŁAL17_��s���͂��m�F���폜
			final PCY_DaikoNyuryokuEJBHome home_daikonyuryoku = (PCY_DaikoNyuryokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_DaikoNyuryokuEJBHome.class);
			final PCY_DaikoNyuryokuEJB ejb_daikonyuryoku = home_daikonyuryoku.create();

// MOD 2018/02/15 COMTURE phase5-LN-OVS-Ph1_CT_011 START
//			final PCY_DaikoNyuryokuBean temp_check_daikoBeans = new PCY_DaikoNyuryokuBean();
//
//			temp_check_daikoBeans.setSimeiNo(mousikomiBeans[0].getSimeiNo());
//			temp_check_daikoBeans.setKousinbi(mousikomiBeans[0].getKousinbi());
//			temp_check_daikoBeans.setKousinjikoku(mousikomiBeans[0].getKousinjikoku());
			for (int i=0; i<mousikomiBeans.length; i++) {
				PCY_DaikoNyuryokuBean temp_check_daikoBeans = new PCY_DaikoNyuryokuBean();
				temp_check_daikoBeans.setSimeiNo(mousikomiBeans[i].getSimeiNo());
				temp_check_daikoBeans.setKousinbi(mousikomiBeans[i].getKousinbi());
				temp_check_daikoBeans.setKousinjikoku(mousikomiBeans[i].getKousinjikoku());
// MOD 2018/02/15 COMTURE phase5-LN-OVS-Ph1_CT_011 END

				// L17_��s���͂ɏ�񂪂��邩�𒲍�����
				Log.transaction(loginuser.getSimeiNo(), true, "");
				final PCY_DaikoNyuryokuBean[] check_daikoBeans = ejb_daikonyuryoku.doSelect(temp_check_daikoBeans, false, loginuser);
				Log.transaction(loginuser.getSimeiNo(), false, "");

				if (check_daikoBeans.length > 0) {
					// L17_��s���͂ɂ���̂�L17�̎�������Ƃ��s��
					Log.transaction(loginuser.getSimeiNo(), true, "");
					ejb_daikonyuryoku.doDeleteByPrimaryKey(check_daikoBeans, loginuser);
					Log.transaction(loginuser.getSimeiNo(), false, "");
				}
// ADD 2018/02/15 COMTURE phase5-LN-OVS-Ph1_CT_011 START
			}
// ADD 2018/02/15 COMTURE phase5-LN-OVS-Ph1_CT_011 END

			/* �\���󋵃e�[�u���̃��R�[�h�폜 */
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doCancelAndRirekiInsert(mousikomiBeans, taisyosyaBeans, loginuser, "0");
			Log.transaction(loginuser.getSimeiNo(), false, "");

			OutLogBean.sousaKojinJohoLog("VCC053", loginuser.getSimeiNo(), null, classBean.getKamokuBean().getKamokuCode() + "," + classBean.getClassCode());
		} else if (command.equals("torikesikanryo")) {
			/* ��������̏ꍇ */
// ADD 2017/05/25 COMTURE UCT1-009�iver.02-00�j START
			// ��s���͂̏ꍇ������̂ŁAL17_��s���͂��m�F���폜
			final PCY_DaikoNyuryokuEJBHome home_daikonyuryoku = (PCY_DaikoNyuryokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_DaikoNyuryokuEJBHome.class);
			final PCY_DaikoNyuryokuEJB ejb_daikonyuryoku = home_daikonyuryoku.create();

// MOD 2018/02/15 COMTURE phase5-LN-OVS-Ph1_CT_011 START
//			final PCY_DaikoNyuryokuBean temp_check_daikoBeans = new PCY_DaikoNyuryokuBean();
//
//			temp_check_daikoBeans.setSimeiNo(mousikomiBeans[0].getSimeiNo());
//			temp_check_daikoBeans.setKousinbi(mousikomiBeans[0].getKousinbi());
//			temp_check_daikoBeans.setKousinjikoku(mousikomiBeans[0].getKousinjikoku());
			for (int i=0; i<mousikomiBeans.length; i++) {
				PCY_DaikoNyuryokuBean temp_check_daikoBeans = new PCY_DaikoNyuryokuBean();
				temp_check_daikoBeans.setSimeiNo(mousikomiBeans[i].getSimeiNo());
				temp_check_daikoBeans.setKousinbi(mousikomiBeans[i].getKousinbi());
				temp_check_daikoBeans.setKousinjikoku(mousikomiBeans[i].getKousinjikoku());
// MOD 2018/02/15 COMTURE phase5-LN-OVS-Ph1_CT_011 END

				// L17_��s���͂ɏ�񂪂��邩�𒲍�����
				Log.transaction(loginuser.getSimeiNo(), true, "");
				final PCY_DaikoNyuryokuBean[] check_daikoBeans = ejb_daikonyuryoku.doSelect(temp_check_daikoBeans, false, loginuser);
				Log.transaction(loginuser.getSimeiNo(), false, "");

				if (check_daikoBeans.length > 0) {
					// L17_��s���͂ɂ���̂�L17�̎�������Ƃ��s��
					Log.transaction(loginuser.getSimeiNo(), true, "");
					ejb_daikonyuryoku.doDeleteByPrimaryKey(check_daikoBeans, loginuser);
					Log.transaction(loginuser.getSimeiNo(), false, "");
				}
// ADD 2018/02/15 COMTURE phase5-LN-OVS-Ph1_CT_011 START
			}
// ADD 2018/02/15 COMTURE phase5-LN-OVS-Ph1_CT_011 END
// ADD 2017/05/25 COMTURE UCT1-009�iver.02-00�j END

			/* �\���󋵃e�[�u���̃��R�[�h�폜 */
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doCancelAndRirekiInsert(mousikomiBeans, taisyosyaBeans, loginuser, "1");
			Log.transaction(loginuser.getSimeiNo(), false, "");
			OutLogBean.sousaKojinJohoLog("VCC307", loginuser.getSimeiNo(), null, classBean.getKamokuBean().getKamokuCode() + "," + classBean.getClassCode());
		} else if (command.equals("jyukoutorikesi")) {
			/* ��u��������̏ꍇ */
			/* ��s���͂̏ꍇ������̂ŁAL17_��s���͂��m�F���폜 */
			final PCY_DaikoNyuryokuEJBHome home_daikonyuryoku = (PCY_DaikoNyuryokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_DaikoNyuryokuEJBHome.class);
			final PCY_DaikoNyuryokuEJB ejb_daikonyuryoku = home_daikonyuryoku.create();

// MOD 2018/02/15 COMTURE phase5-LN-OVS-Ph1_CT_011 START
//			final PCY_DaikoNyuryokuBean temp_check_daikoBeans = new PCY_DaikoNyuryokuBean();
//
//			temp_check_daikoBeans.setSimeiNo(mousikomiBeans[0].getSimeiNo());
//			temp_check_daikoBeans.setKousinbi(mousikomiBeans[0].getKousinbi());
//			temp_check_daikoBeans.setKousinjikoku(mousikomiBeans[0].getKousinjikoku());
			for (int i=0; i<mousikomiBeans.length; i++) {
				PCY_DaikoNyuryokuBean temp_check_daikoBeans = new PCY_DaikoNyuryokuBean();
				temp_check_daikoBeans.setSimeiNo(mousikomiBeans[i].getSimeiNo());
				temp_check_daikoBeans.setKousinbi(mousikomiBeans[i].getKousinbi());
				temp_check_daikoBeans.setKousinjikoku(mousikomiBeans[i].getKousinjikoku());
// MOD 2018/02/15 COMTURE phase5-LN-OVS-Ph1_CT_011 END

				// L17_��s���͂ɏ�񂪂��邩�𒲍�����
				Log.transaction(loginuser.getSimeiNo(), true, "");
				final PCY_DaikoNyuryokuBean[] check_daikoBeans = ejb_daikonyuryoku.doSelect(temp_check_daikoBeans, false, loginuser);
				Log.transaction(loginuser.getSimeiNo(), false, "");

				if (check_daikoBeans.length > 0) {
					// L17_��s���͂ɂ���̂�L17�̎�������Ƃ��s��
					Log.transaction(loginuser.getSimeiNo(), true, "");
					ejb_daikonyuryoku.doDeleteByPrimaryKey(check_daikoBeans, loginuser);
					Log.transaction(loginuser.getSimeiNo(), false, "");
				}
// ADD 2018/02/15 COMTURE phase5-LN-OVS-Ph1_CT_011 START
			}
// ADD 2018/02/15 COMTURE phase5-LN-OVS-Ph1_CT_011 END

			/* �\���󋵃e�[�u���̃��R�[�h�폜 */
			Log.transaction(loginuser.getSimeiNo(), true, "");
			ejb.doCancelAndRirekiInsert(mousikomiBeans, taisyosyaBeans, loginuser, "1");
			Log.transaction(loginuser.getSimeiNo(), false, "");
			OutLogBean.sousaKojinJohoLog("VCC308", loginuser.getSimeiNo(), null, classBean.getKamokuBean().getKamokuCode() + "," + classBean.getClassCode());
		}

		/* �ȖځE�N���X��񌟍� */
		final PCY_ClassEJBHome classHome = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB classEjb = classHome.create();

		Log.transaction(loginuser.getSimeiNo(), true, "");
		classBean = classEjb.doSelectByPrimaryKey(classBean, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");
// ADD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V START
		if (command.equals("uketukesasimodosi") || command.equals("torikesisasimodosi")) {
            Log.transaction(loginuser.getSimeiNo(), true, "");
            classEjb.doUpdateMansekiFlg(classBean, loginuser);
            Log.transaction(loginuser.getSimeiNo(), false, "");
		}
// ADD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V END

		if (classBean.getAnnaiMailKubun().equals("1")) {
			/* �N���X�}�X�^�̈ē����[���敪���f�v�f�̏ꍇ�A���[���𑗐M���� */
			/* Mail���� */
			final String[] simei_no = new String[mousikomisyaList.size()];

			for (int i = 0; i < simei_no.length; i++) {
				simei_no[i] = mousikomiBeans[i].getSimeiNo();
			}

			final PCY_PersonalEJBHome personalHome = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
			final PCY_PersonalEJB personalEjb = personalHome.create();

			Log.transaction(loginuser.getSimeiNo(), true, "");

			final PCY_PersonalBean[] personalBeans = personalEjb.getPersonalInfo(simei_no, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");

			if (command.equals("syouninmachisasimodosi")) { // CHG#2007/3/30 s-hiura
				try {
					/* ���F�ҍ��߂̏ꍇ */
					PCY_KensyuMailSender.sendKensyuKanrisyaSyouninMachiSasimodosi(personalBeans, classBean, loginuser);
				} catch (final AddressException e) {
					request.setAttribute("warningID", "WCC120");
					throw new PCY_WarningException(e);
				} catch (final Exception e) {
					request.setAttribute("warningID", "WCC120");
					throw new PCY_WarningException(e);
				}
			} else if (command.equals("uketukekanryo")) {
				if ("0".equals(classBean.getKisyoIkkatsuFlg())) {
					try {
						/* ��t�����̏ꍇ */
						PCY_KensyuMailSender.sendKensyuKanrisyaUketukeKanryo(personalBeans, classBean, loginuser);
					} catch (final AddressException e) {
						request.setAttribute("warningID", "WCC110");
						throw new PCY_WarningException(e);
					} catch (final Exception e) {
						request.setAttribute("warningID", "WCC110");
						throw new PCY_WarningException(e);
					}
				}
			} else if (command.equals("uketukesasimodosi")) {
				if ("0".equals(classBean.getKisyoIkkatsuFlg())) {
					try {
						/* ��t���߂̏ꍇ */
						PCY_KensyuMailSender.sendKensyuKanrisyaUketukeSasimodosi(personalBeans, classBean, riyu, loginuser);
					} catch (final AddressException e) {
						request.setAttribute("warningID", "WCC120");
						throw new PCY_WarningException(e);
					} catch (final Exception e) {
						request.setAttribute("warningID", "WCC120");
						throw new PCY_WarningException(e);
					}
				}
			} else if (command.equals("torikesisasimodosi")) {
				try {
					/* ������߂̏ꍇ */
					PCY_KensyuMailSender.sendKensyuKanrisyaTorikesiSasimodosi(personalBeans, classBean, riyu, loginuser);
				} catch (final AddressException e) {
					request.setAttribute("warningID", "WCC120");
					throw new PCY_WarningException(e);
				} catch (final Exception e) {
					request.setAttribute("warningID", "WCC120");
					throw new PCY_WarningException(e);
				}
			} else if (command.equals("torikesikanryo")) {
				try {
					/* ��������̏ꍇ */
					PCY_KensyuMailSender.sendKensyuKanrisyaTorikesiKanryo(personalBeans, classBean, loginuser);
				} catch (final AddressException e) {
					request.setAttribute("warningID", "WCC130");
					throw new PCY_WarningException(e);
				} catch (final Exception e) {
					request.setAttribute("warningID", "WCC130");
					throw new PCY_WarningException(e);
				}
			}
		}

		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}