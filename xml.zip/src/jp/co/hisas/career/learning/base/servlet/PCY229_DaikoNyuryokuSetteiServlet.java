package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_DaikoNyuryokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_DaikoNyuryokuEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_DaikoNyuryokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_SyoninsyaBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PCY226_DaikoNyuryokuSetteiServlet �N���X �@�\�����F ��s���͓o�^���s���܂��B
 * 
 * </PRE>
 */
public class PCY229_DaikoNyuryokuSetteiServlet extends PCY010_ControllerServlet {
	/**
	 * ��s���͓o�^���s���܂��B
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, SQLException,
			RemoteException, PCY_WarningException {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

        final PCY_ClassEJBHome class_home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_SyoninsyaEJBHome syoninsya_home = (PCY_SyoninsyaEJBHome) EJBHomeFactory.getInstance().lookup(PCY_SyoninsyaEJBHome.class);
		final PCY_MousikomiJyokyoEJBHome mousikomi_home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_DaikoNyuryokuEJBHome daiko_home = (PCY_DaikoNyuryokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_DaikoNyuryokuEJBHome.class);
        final PCY_ClassEJB class_ejb = class_home.create();
		final PCY_SyoninsyaEJB syoninsya_ejb = syoninsya_home.create();
		final PCY_MousikomiJyokyoEJB ejb = mousikomi_home.create();
		final PCY_DaikoNyuryokuEJB daiko_ejb = daiko_home.create();

        PCY_ClassBean classBean = new PCY_ClassBean(request);
        classBean = class_ejb.doSelectByPrimaryKey(classBean, loginuser);
        final String[] simei_no = request.getParameterValues("H004_simei_no");

		final PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = new PCY_MousikomiJyokyoBean[simei_no.length];
		for (int i = 0; i < simei_no.length; i++) {
			/* �N���X�̑����̏��F�敪���v�̏ꍇ�A���F�҂��ݒ肳��Ă��邱�Ƃ��`�F�b�N���� */
			if (classBean.getSyoninKubun().equals("1")) {
				/* SyoninsyaEJB */
				final PCY_SyoninsyaBean[] syoninsyaBeans = syoninsya_ejb.doSelect(new String[] { simei_no[i] }, true, loginuser);
				if (syoninsyaBeans == null || syoninsyaBeans.length == 0 || syoninsyaBeans[0].getSyoninsya1() == null || syoninsyaBeans[0].getSyoninsya1().equals("")) {
					/* ���F�҂��ݒ肵�ĂȂ��ꍇ�A�x����ʂɑJ�ڂ��� */
					request.setAttribute("warningID", "WCA040");
					throw new PCY_WarningException("WCA040");
				}
			}
            mousikomiJyokyoBeans[i] = new PCY_MousikomiJyokyoBean();
			mousikomiJyokyoBeans[i].setClassBean(classBean);
			mousikomiJyokyoBeans[i].setSimeiNo(simei_no[i]);
			mousikomiJyokyoBeans[i].setMousikomisya(loginuser.getSimeiNo());

			mousikomiJyokyoBeans[i].setMousikomibi(PZZ010_CharacterUtil.GetDay());
			mousikomiJyokyoBeans[i].setMousikomijikoku(PZZ010_CharacterUtil.GetTime());

			/* �N���X�̑�������X�e�[�^�X�𔻕ʂ��Đ\����DB��INSERT */
			String status = "";

			if (mousikomiJyokyoBeans[i].getClassBean().getSyoninKubun().equals("1")) {
				status = "0";
			} else {
				if (mousikomiJyokyoBeans[i].getClassBean().getUketukeKubun().equals("1")) {
					status = "1";
					mousikomiJyokyoBeans[i].setUketsukeJyotai("0");
				} else {
					if (!mousikomiJyokyoBeans[i].getClassBean().getHoukokuKubun().equals("0")) {
						status = "2";
					} else {
						status = "3";
					}
				}
			}
			mousikomiJyokyoBeans[i].setStatus(status);
			mousikomiJyokyoBeans[i].setSeikyuFlg("0");
		}
		ejb.doMousikomiWithZensyaTaisyo(mousikomiJyokyoBeans, loginuser);

		// ��s���͂̏ꍇ�́AL17�ɔ��f����
		PCY_DaikoNyuryokuBean[] daikoNyryokuBeans = null;

		daikoNyryokuBeans = new PCY_DaikoNyuryokuBean[simei_no.length];
		for (int i = 0; i < simei_no.length; i++) {
			daikoNyryokuBeans[i] = new PCY_DaikoNyuryokuBean();
			daikoNyryokuBeans[i].setSimeiNo(simei_no[i]);
			daikoNyryokuBeans[i].setKamokuCode(classBean.getKamokuBean().getKamokuCode());
			daikoNyryokuBeans[i].setClassCode(classBean.getClassCode());

			final PCY_DaikoNyuryokuBean kensaku_daikoBean = new PCY_DaikoNyuryokuBean();
			kensaku_daikoBean.setKamokuCode(classBean.getKamokuBean().getKamokuCode());
			kensaku_daikoBean.setClassCode(classBean.getClassCode());

			final PCY_DaikoNyuryokuBean[] daikoBeans = daiko_ejb.doSelect(kensaku_daikoBean, false, loginuser);

			for (int j = 0; j < daikoBeans.length; j++) {
				if (daikoBeans[j].getSimeiNo().equals(request.getParameter("simei_no"))) {
					daikoNyryokuBeans[i].setTaisyoKubunRireki(daikoBeans[j].getTaisyoKubunRireki());
					daikoNyryokuBeans[i].setTourokubi(daikoBeans[j].getTourokubi());
					daikoNyryokuBeans[i].setTourokujikoku(daikoBeans[j].getTourokujikoku());
					daikoNyryokuBeans[i].setTourokusya(daikoBeans[j].getTourokusya());
					break;
				}
			}
		}
        final PCY_DaikoNyuryokuEJBHome home2 = (PCY_DaikoNyuryokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_DaikoNyuryokuEJBHome.class);
        final PCY_DaikoNyuryokuEJB ejb2 = home2.create();

        ejb2.doInsert(daikoNyryokuBeans, loginuser);
// ADD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V START
        Log.transaction(loginuser.getSimeiNo(), true, "");
        class_ejb.doUpdateMansekiFlg(classBean, loginuser);
        Log.transaction(loginuser.getSimeiNo(), false, "");
// ADD 2019/01/08 COMTURE �N���X���ȃt���O�����X�V END

		try {
			OutLogBean.sousaKojinJohoLog("VCB092", loginuser.getSimeiNo(), null, classBean.getKamokuBean().getKamokuCode() + "," + classBean.getClassCode());
		} catch (final Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
		}
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
