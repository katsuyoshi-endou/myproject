/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.bean.PCY_KensyuKanriJohoBean;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY154_ClassCyusiKakuninServlet �N���X �@�\�����F �N���X���~�m�F��ʂ�\�����܂��B
 * 
 * </PRE>
 */
public class PCY154_ClassCyusiKakuninServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final List taisyosyaList = new ArrayList();
		int index = 0;

		while (true) {
			final String simeiNo = request.getParameter("simei_no_" + index);

			if (simeiNo == null || simeiNo.length() == 0) {
				break;
			}

			final PCY_KensyuKanriJohoBean taisyosya = new PCY_KensyuKanriJohoBean();
			final PCY_MousikomiJyokyoBean mousikomi = new PCY_MousikomiJyokyoBean();

			mousikomi.setSimeiNo(simeiNo);
			mousikomi.setKousinbi(request.getParameter("kousinbi_" + index));
			mousikomi.setKousinjikoku(request.getParameter("kousinjikoku_" + index));
			taisyosya.setMousikomiBean(mousikomi);

			taisyosyaList.add(taisyosya);
			index++;
		}

		final PCY_KensyuKanriJohoBean[] taisyosyaBeans = new PCY_KensyuKanriJohoBean[taisyosyaList.size()];
		taisyosyaList.toArray(taisyosyaBeans);

		// �N���X���擾
		final PCY_ClassEJBHome home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB ejb = home.create();
		final PCY_ClassBean classBean = ejb.doSelectByPrimaryKey(new PCY_ClassBean(request), loginuser);

		// �Ȗڏ��擾
		final PCY_KamokuEJBHome kamokuhome = (PCY_KamokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KamokuEJBHome.class);
		final PCY_KamokuEJB kamokuejb = kamokuhome.create();
		final PCY_KamokuBean kamokuBean = kamokuejb.doSelectByPrimaryKey(new PCY_KamokuBean(request), false, loginuser);

		request.setAttribute("classBean", classBean);
		request.setAttribute("kamokuBean", kamokuBean);
		request.setAttribute("taisyosyaBeans", taisyosyaBeans);
		request.setAttribute("MAILcomment", request.getParameter("MAILcomment"));

		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
