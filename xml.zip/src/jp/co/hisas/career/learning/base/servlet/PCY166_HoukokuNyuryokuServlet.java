/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJB;
import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJBHome;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY166_HoukokuNyuryokuServlet �N���X �@�\�����F ���N�G�X�g����擾�������̈��p���A�y�сA�񍐂̓��͂��s����ʂ�\�����邽�߂̏����擾���܂��B
 * 
 * </PRE>
 */
public class PCY166_HoukokuNyuryokuServlet extends PCY010_ControllerServlet {
	/**
	 * ���N�G�X�g����擾�������̈��p���A�y�сA�񍐂̎擾���s���܂��B
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws SQLException, Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		try {
			/* ���N�G�X�g����v���p�e�B���擾 */
			final PCY_KamokuBean kamokuBean = new PCY_KamokuBean(request);
			final PCY_ClassBean classBean = new PCY_ClassBean(request);
			classBean.setKamokuBean(kamokuBean);
			classBean.setKousinbi(request.getParameter("class_kousinbi"));
			classBean.setKousinjikoku(request.getParameter("class_kousinjikoku"));

			PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean();
			mousikomiBean.setClassBean(classBean);
			mousikomiBean.setStatus(request.getParameter("status"));
			mousikomiBean.setKousinbi(request.getParameter("mousikomi_kousinbi"));
			mousikomiBean.setKousinjikoku(request.getParameter("mousikomi_kousinjikoku"));
			mousikomiBean.setSimeiNo(loginuser.getSimeiNo());

			/* �N���X�J�n���ƃV�X�e�����Ԃƃ`�F�b�N���s�� */
			if (new Integer(classBean.getKaisibi()).intValue() > new Integer(PZZ010_CharacterUtil.GetDay()).intValue()) {
				request.setAttribute("warningID", "WCA050");
				throw new PCY_WarningException("WCA050");
			}

			/* �ĕ񍐂̏ꍇ�́A�\���󋵂c�a�̓��e���擾���� */
			if ("3".equals(mousikomiBean.getStatus())) {
				// EJB�擾
				final PCY_MousikomiJyokyoEJBHome mousikomiHome = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
				final PCY_MousikomiJyokyoEJB mousikomiEjb = mousikomiHome.create();

				/* �\�����̎擾 */
				final PCY_MousikomiJyokyoBean[] ret = mousikomiEjb.getList(mousikomiBean, loginuser);

				// ���|�[�g�ȊO�̏ꍇ��houkoku���擾
				byte[] ret_houkoku = null;

				if (classBean.getHoukokuKubun().equals("2") || classBean.getHoukokuKubun().equals("3")) {

					final PYF_BlobDBAccessEJBHome blobHome = (PYF_BlobDBAccessEJBHome) EJBHomeFactory.getInstance().lookup(PYF_BlobDBAccessEJBHome.class);
					final PYF_BlobDBAccessEJB blobEjb = blobHome.create();

					// �L�[
					final String[] primaryKey = { "kamoku_code", "class_code", "simei_no", "kousinbi", "kousinjikoku" };

					// �L�[�l
					final String[] keyValue = {
							classBean.getKamokuBean().getKamokuCode(),
							classBean.getClassCode(),
							loginuser.getSimeiNo(),
							mousikomiBean.getKousinbi(),
							mousikomiBean.getKousinjikoku() };
					ret_houkoku = blobEjb.SelectBLOB(loginuser.getSimeiNo(), "L15_MOUSIKOMI_JYOKYO_TBL", "houkoku", primaryKey, keyValue);
				}

				mousikomiBean = ret[0];
				mousikomiBean.setHoukoku(ret_houkoku);
				mousikomiBean.setClassBean(classBean);
			}

			/* ���N�G�X�g�ɃZ�b�g���� */
			request.setAttribute("mousikomiBean", mousikomiBean);

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return this.getForwardPath();
		} catch (final NamingException e) {
			throw e;
		} catch (final CreateException e) {
			throw e;
		} catch (final RemoteException e) {
			throw e;
		} catch (final PCY_WarningException e) {
			throw e;
		} catch (final RuntimeException e) {
			throw e;
		}
	}
}
