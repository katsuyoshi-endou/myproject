/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipOutputStream;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.personal.kyoiku.ejb.KyoikuEJB;
import jp.co.hisas.career.personal.kyoiku.ejb.KyoikuEJBHome;
import jp.co.hisas.career.util.common.PZZ060_DateConvertUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

import com.lowagie.text.DocumentException;

/**
 * <PRE>
 * 
 * �T�v�F�C������EXCEL�쐬���s���B �g�p���@: JSP����Ăяo���B
 * �����F2018/03/07 COMTURE VCA350_�{�l���C���(Ph2-2)
 * 
 * </PRE>
 */
public class PCY350_CertificateDownLoadServlet extends PCY010_ControllerServlet {

    private static final long serialVersionUID = 1L;

    /** �_�E�����[�h�t�@�C���� */
    static final String DOWNLOAD_FILENAME = "certificate";

    /** �_�E�����[�h�t�@�C���g���q */
    static final String DOWNLOAD_EXCEL_EXTENSION = ".xlsx";
    static final String DOWNLOAD_ZIP_EXTENSION = ".zip";

    /** �_�E�����[�h�̑��� */
    static final String CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8";
    
    /** ����{�� */
    static final short PAGE_PRINT_SCALE_PERCENT = 99;
    
    /** �ӔC�Җ�(���{��) */
    static final String ZCC001 = (String)ReadFile.paramMapData.get("ZCC001");
    
    /** �ӔC�Җ�(�p��) */
    static final String ZCC002 = (String)ReadFile.paramMapData.get("ZCC002");
    
    /** �e���v���[�g�t�@�C���̃e���v���[�g�V�[�g�ԍ� */
    static final int TEMPLATE_SHEET_INDEX = 0;
    
    /** �s�ԍ�:���� */
    static final int TARGET_ROW_INDEX_NAME = 17;
    
    /** �s�ԍ�:�Ȗږ� */
    static final int TARGET_ROW_INDEX_COURSE = 25;
    
    /** �s�ԍ�:�I���� */
    static final int TARGET_ROW_INDEX_DATE = 34;
    
    /** �s�ԍ�:�ӔC�Җ��i���{��j */
    static final int TARGET_ROW_INDEX_SEKININJ = 41;
    
    /** �s�ԍ�:�ӔC�Җ��i�p��j */
    static final int TARGET_ROW_INDEX_SEKININE = 44;

    protected String execute(final HttpServletRequest request,
            final HttpServletResponse response, final PCY_PersonalBean loginuser)
            throws NamingException, CreateException, RemoteException,
            PCY_WarningException, IOException, DocumentException, Exception {
        
        /* ���\�b�h�g���[�X�o�� */
        Log.method(loginuser.getSimeiNo(), "IN", "");
        Log.performance(loginuser.getSimeiNo(), true, "");
        
        try {
            
            final HttpSession session = request.getSession(false);
            final UserInfoBean userinfo = (UserInfoBean)session.getAttribute("userinfo");
            
            // EJBHome�Ǘ��N���X�̎擾
            final EJBHomeFactory fact = EJBHomeFactory.getInstance();
            final PCY_MousikomiJyokyoEJBHome mousikomihome =
                (PCY_MousikomiJyokyoEJBHome)fact.lookup(PCY_MousikomiJyokyoEJBHome.class);
            final PCY_MousikomiJyokyoEJB mousikomiejb = mousikomihome.create();
            final PCY_PersonalEJBHome personalhome = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
            final PCY_PersonalEJB personalEjb = personalhome.create();
            final KyoikuEJBHome kyoikuhome = (KyoikuEJBHome) fact.lookup(KyoikuEJBHome.class);
            final KyoikuEJB kyoikuEjb = kyoikuhome.create();

            ArrayList<PCY_KensyuRirekiBean> rireki = new ArrayList<PCY_KensyuRirekiBean>();
            ArrayList<PCY_PersonalBean> personal = new ArrayList<PCY_PersonalBean>();
            
            String gamenId = request.getParameter("gamenid");
            
            if ("VCA350".equals(gamenId)) {
                String kamokuCode = request.getParameter("kamoku_code");
                String classCode = request.getParameter("class_code");
                String simeiNo = request.getParameter("simei_no");

                PCY_KensyuRirekiBean rirekiBean = new PCY_KensyuRirekiBean();
                rirekiBean.setKamokuCode(kamokuCode);
                rirekiBean.setClassCode(classCode);
                rirekiBean.setSimeiNo(simeiNo);
                PCY_KensyuRirekiBean[] rirekiBeans = mousikomiejb.getListL51(rirekiBean, loginuser);

                if (rirekiBeans != null && rirekiBeans.length != 0) {
                    rireki.add(rirekiBeans[0]);
                    personal.add(personalEjb.getPersonalInfo(simeiNo, loginuser));
                }

            } else if ("VAD010".equals(gamenId)) {
                String editNo = request.getParameter("edit_no");
                String[] kyoiku = kyoikuEjb.doSelectByPrimaryKey(loginuser.getSimeiNo(), editNo);
                PCY_KensyuRirekiBean bean = new PCY_KensyuRirekiBean();
                bean.setSimeiNo(kyoiku[1]);
                bean.setKamokuCode(kyoiku[2]);
                bean.setKamokuMei1(kyoiku[3]);
                bean.setClassMei(kyoiku[14]);
                bean.setKaisibi(kyoiku[15]);
                bean.setSyuryobi(kyoiku[16]);
                rireki.add(bean);
                personal.add(personalEjb.getPersonalInfo(bean.getSimeiNo(), loginuser));

            } else if ("VCC070".equals(gamenId)) {
                String kamokuCode = request.getParameter("kamoku_code");
                String classCode = request.getParameter("class_code");
                String[] simeiNo = request.getParameterValues("simei_no");

                for (int i = 0; i < simeiNo.length; i++) {
                    PCY_KensyuRirekiBean rirekiBean = new PCY_KensyuRirekiBean();
                    rirekiBean.setKamokuCode(kamokuCode);
                    rirekiBean.setClassCode(classCode);
                    rirekiBean.setSimeiNo(simeiNo[i]);
                    PCY_KensyuRirekiBean[] rirekiBeans = mousikomiejb.getListL51(rirekiBean, loginuser);

                    if (rirekiBeans != null && rirekiBeans.length != 0) {
// ADD 2018/03/28 COMTURE phase5-LN-OVS-Ph2_CT_006 START
                        // �C�����肪�C���̏ꍇ�̂ݏo�͑ΏۂƂ���B
                        if ("1".equals(rirekiBeans[0].getSyuryoHantei())) {
// ADD 2018/03/28 COMTURE phase5-LN-OVS-Ph2_CT_006 END
                        rireki.add(rirekiBeans[0]);
                        personal.add(personalEjb.getPersonalInfo(simeiNo[i], loginuser));
// ADD 2018/03/28 COMTURE phase5-LN-OVS-Ph2_CT_006 START
                        }
// ADD 2018/03/28 COMTURE phase5-LN-OVS-Ph2_CT_006 END
                    }
                }
            }
            
            if (rireki.size() == 0) {
                rireki.add(new PCY_KensyuRirekiBean());
                personal.add(new PCY_PersonalBean());
            }
            
            // EXCEL�t�@�C���̍쐬
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            String downloadFileName ="";
            
            // VCA350�F�{�l���C��񂩂�J�ڂ����ꍇ�܂��́A
            // VAD010�F���猤�C������J�ڂ����ꍇ
            if ("VCA350".equals(gamenId) || "VAD010".equals(gamenId)) {
                
// ADD 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2) START
                // �t�@�C�����擾
                downloadFileName =
                        URLEncoder.encode(
                                (DOWNLOAD_FILENAME + "_"
                                        + rireki.get(0).getKamokuMei1() + "_"
                                        + rireki.get(0).getClassMei() + "_"
                                        + rireki.get(0).getSimeiNo() + DOWNLOAD_EXCEL_EXTENSION).replaceAll(
                                        " ", "-"), "UTF-8");
// ADD 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2)  END
// DEL 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2)  START
//                // �t�@�C�����擾
//                downloadFileName = URLEncoder.encode(
//                        DOWNLOAD_FILENAME + "_" +
//                        rireki.get(0).getKamokuMei1() + "_" + 
//                        rireki.get(0).getClassMei() + "_" + 
//                        rireki.get(0).getSimeiNo() + DOWNLOAD_EXCEL_EXTENSION ,"UTF-8");
// DEL 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2)  END

                // �G�N�Z���t�@�C���쐬
                baos = setExcelData(personal.get(0),rireki.get(0));
                
                // �t�@�C���o��
                baos.close();
                
            } else if ("VCC070".equals(gamenId)) {
// ADD 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2) START
                // �t�H���_���擾
                downloadFileName =
                        URLEncoder.encode(
                                (DOWNLOAD_FILENAME + "_"
                                        + rireki.get(0).getKamokuMei1() + "_"
                                        + rireki.get(0).getClassMei() + DOWNLOAD_ZIP_EXTENSION).replaceAll(
                                        " ", "-"),"UTF-8");
// ADD 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2)  END
// DEL 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2)  START
//                // �t�H���_���擾
//                downloadFileName = URLEncoder.encode(
//                        DOWNLOAD_FILENAME + "_" +
//                        rireki.get(0).getKamokuMei1() + "_" + 
//                        rireki.get(0).getClassMei() + DOWNLOAD_ZIP_EXTENSION ,"UTF-8");
// DEL 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2)  END

                /* zip�쐬 */
                ZipOutputStream zipOutStream = new ZipOutputStream(baos);
                zipOutStream.setEncoding("UTF-8");
                
                for (int i=0; i<rireki.size(); i++) {
                    
                    // �t�@�C�����擾
                    String fileName = 
                        DOWNLOAD_FILENAME + "_" +
                        rireki.get(i).getKamokuMei1() + "_" + 
                        rireki.get(i).getClassMei() + "_" +
                        personal.get(i).getSimeiNo() + DOWNLOAD_EXCEL_EXTENSION;

// ADD 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2) START
                    fileName = fileName.replaceAll(" ", "-");
// ADD 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2) END
                    
                    // ZipOutputStream��ZipEntry��ݒ�
                    ZipEntry objZe = new ZipEntry(fileName);
                    objZe.setMethod(ZipOutputStream.DEFLATED);
                    zipOutStream.putNextEntry(objZe);
                    ByteArrayOutputStream Baos = new ByteArrayOutputStream();
                    
                    // �G�N�Z���t�@�C���쐬
                    Baos = setExcelData(personal.get(i),rireki.get(i));
                    
                    // �t�@�C���̃o�C�g�o��
                    Baos.close();
                    
                    zipOutStream.write(Baos.toByteArray(), 0, Baos.toByteArray().length);
                    
                    // ZipEntry�̃N���[�Y
                    zipOutStream.closeEntry();
                }
                baos.close();
                zipOutStream.close();
            }

            final ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
            /* ���샍�O�o�� */
            final String login_no = userinfo.getLogin_no();
            final String simei_no = userinfo.getSimei_no();
            OutLogBean.sousaKojinJohoLog("LNG004", login_no, simei_no,
                    ("�ȖڃR�[�h:" + rireki.get(0).getKamokuCode()
                            + ",�N���X�R�[�h:" + rireki.get(0).getClassCode()));

            request.setAttribute("H080_FileName", downloadFileName);
            request.setAttribute("H081_ContentType", CONTENT_TYPE);
            request.setAttribute("STREAM", bais);

            Log.performance(loginuser.getSimeiNo(), false, "");
            Log.method(loginuser.getSimeiNo(), "OUT", "");

            return this.getForwardPath();

        } catch (final NamingException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final CreateException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final RemoteException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final IOException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final DocumentException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final Exception e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        }
    }

    /**
     * �Z���ݒ�
     * @param sheet EXCLE�V�[�g
     * @param rowNum �s�ԍ�
     * @param colNum ��ԍ�
     * @param cellVal �Z���ݒ�l
     * @param rowFlag �s�t���O
     * @param iniFlag ����t���O
     * @exception LYSGException �A�v���P�[�V������O�̔���
     */
    void setCell(Sheet sheet, int rowNum, int colNum, String cellVal,
            boolean rowFlag, boolean iniFlag) {
        // �e���v���[�g���\���̏ꍇ
        if (rowFlag) {
            Row row = sheet.getRow(rowNum);
            Cell cell = row.getCell(colNum);
            if (cell == null) cell = row.createCell(colNum);
            cell.setCellValue(cellVal);
            // ����łȂ��̏ꍇ
        } else if (!iniFlag) {
            Row row = sheet.getRow(rowNum);
            if (row == null) row = sheet.createRow(rowNum);
            Cell cell = row.createCell(colNum);
            cell.setCellValue(cellVal);
        } else {
            Row row = sheet.createRow(rowNum);
            Cell cell = row.createCell(colNum);
            cell.setCellValue(cellVal);
        }
    }

    /**
     * �s�`�F�b�N
     * @param sheet EXCLE�V�[�g
     * @param rowNum �s�ԍ�
     * @return �e���v���[�g����true�A����ȊO�̏ꍇ�� false
     * @exception LYSGException �A�v���P�[�V������O�̔���
     */
    boolean chickRow(Sheet sheet, int rowNum) {
        // �e���v���[�g�s�ݒ���̎擾
        Row row = sheet.getRow(rowNum);

        // �e���v���[�g���\���̏ꍇ
        if (row != null) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * �G�N�Z���쐬
     * @param psnl �l���
     * @param rrki ���猤�C��
     * @throws IOException 
     * @throws InvalidFormatException 
     * @exception LYSGException �A�v���P�[�V������O�̔���
     */
    ByteArrayOutputStream setExcelData(PCY_PersonalBean psnl, PCY_KensyuRirekiBean rrki) throws InvalidFormatException, IOException {
        
        Sheet sheet = null;
        int sheetIndex = 0;
        FileInputStream in = null;
        Workbook wb = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        // �e���v���[�g�t�@�C���̎擾
        final String templateFile = (String)ReadFile.fileMapData.get(HcdbDef.DOWNLOAD_PATH) +
                "/" + DOWNLOAD_FILENAME + DOWNLOAD_EXCEL_EXTENSION;
        
        // �e���v���[�g�t�@�C�����J��
        try {
            in = new FileInputStream(templateFile);
            wb = WorkbookFactory.create(in);
        } finally {
            in.close();
        }
        
        // ����͈͂��擾
        String printArea = wb.getPrintArea(wb.getSheetIndex( DOWNLOAD_FILENAME ));
        if (printArea != null) {
            int sheetPosition = printArea.indexOf("!");
            if (sheetPosition != -1) {
                printArea = printArea.substring(sheetPosition + 1);
            } else {
                printArea = null;
            }
        }
        
        // ����{���Ɨp���̐ݒ�
        sheet = wb.getSheetAt(sheetIndex);
        sheet.getPrintSetup().setPaperSize(PrintSetup.A4_PAPERSIZE);
        sheet.getPrintSetup().setScale(PAGE_PRINT_SCALE_PERCENT);
        
        // �e���v���[�g�ύ��ڒu������
        boolean rowFlag = true;
        // ���O�̐ݒ�
        rowFlag = chickRow(sheet, TARGET_ROW_INDEX_NAME);
        setCell(sheet, TARGET_ROW_INDEX_NAME, TEMPLATE_SHEET_INDEX,
                psnl.getKanjiSimei(), rowFlag, false);
        
        // �Ȗږ��̐ݒ�
        rowFlag = chickRow(sheet, TARGET_ROW_INDEX_COURSE);
        setCell(sheet, TARGET_ROW_INDEX_COURSE, TEMPLATE_SHEET_INDEX,
                rrki.getKamokuMei1(), rowFlag, false);
        
        // �I�����̐ݒ�
// MOD 2018/12/03 COMTURE �C�����A�e�X�g���ʈꗗ�̓��t�t�H�[�}�b�g�ύX�Ή� START
//        String syuryo = PZZ060_DateConvertUtil.convertToTsukiRyakusho(rrki.getSyuryobi());
        String syuryo = PZZ060_DateConvertUtil.convertToTsukiMeiFull(rrki.getSyuryobi());
// MOD 2018/12/03 COMTURE �C�����A�e�X�g���ʈꗗ�̓��t�t�H�[�}�b�g�ύX�Ή� END
        rowFlag = chickRow(sheet, TARGET_ROW_INDEX_DATE);
        setCell(sheet, TARGET_ROW_INDEX_DATE, TEMPLATE_SHEET_INDEX,
                syuryo, rowFlag, false);
        
        // �ӔC�ҁi���{��j�̐ݒ�
        rowFlag = chickRow(sheet, TARGET_ROW_INDEX_SEKININJ);
        setCell(sheet, TARGET_ROW_INDEX_SEKININJ, TEMPLATE_SHEET_INDEX,
                ZCC001, rowFlag, false);
        
        // �ӔC�ҁi�p��j�̐ݒ�
        rowFlag = chickRow(sheet, TARGET_ROW_INDEX_SEKININE);
        setCell(sheet, TARGET_ROW_INDEX_SEKININE, TEMPLATE_SHEET_INDEX,
                ZCC002, rowFlag, false);
        
        wb.write(baos);
        
        return baos;
    }
}
