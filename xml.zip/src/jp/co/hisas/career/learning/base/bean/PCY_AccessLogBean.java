/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.bean;

import java.io.Serializable;

/**
 * @author Administrator ���̐������ꂽ�R�����g�̑}�������e���v���[�g��ύX���邽�� �E�B���h�E > �ݒ� > Java > �R�[�h���� > �R�[�h�ƃR�����g
 */
public class PCY_AccessLogBean implements Serializable {
	private String sessionId = null;

	private String loginJikoku = null;

	private String logoutJikoku = null;

	private String simeiNo = null;

	private String sosikiCode = null;

	private int honninKensyuJyohou = 0;

	private int kensyuJyohouTuika = 0;

	private int kensyuJyohouKousin = 0;

	private int kensyuJyohouSakujyo = 0;

	private int kensyuKanryobiKousin = 0;

	private int kensyuSyosai = 0;

	private int jikosinkokuSyosai = 0;

	private int kensyusyaClassSyosai = 0;

	private int kensyuMousikomi = 0;

	private int mousikomiTorikesi = 0;

	private int jyukouHoukoku = 0;

	private int esNinsyo = 0;

	private int reportTeisyutu = 0;

	private int situmonNyuryoku = 0;

	private int jikohyokaNyuryoku = 0;

	private int jyukouSinkokuNyuryoku = 0;

	private int kamokuItiran = 0;

	private int syoninsyaKakuninHenkou = 0;

	private int syoninsyaSentaku = 0;

	private int syoninsyaSettei = 0;

	private int syoninsyaSakujyo = 0;

	private int syonin = 0;

	private int syoninSasimodosi = 0;

	private int kensyukanriJyohou = 0;

	private int kensyukanriClassSyosai = 0;

	private int classCyosei = 0;

	private int uketuke = 0;

	private int uketukeSasimodosi = 0;

	private int classCyusi = 0;

	private int seisekiNyuryoku = 0;

	private int classSyuryo = 0;

	private int daikouNyuryoku = 0;

	private int situmonHyoji = 0;

	private int classSaikai = 0;

	private int kamokuTouroku = 0;

	private int kamokuHenkou = 0;

	private int kamokuSakujyo = 0;

	private int kamokuSentaku = 0;

	private int classTouroku = 0;

	private int classHenkou = 0;

	private int classSakujyo = 0;

	private int curriculumMapTouroku = 0;

	private int taisyoBumonSettei = 0;

	private int taisyoSyokusyuSettei = 0;

	private int taisyosyaSettei = 0;

	private int taisyosyaSetteiKensakukekka = 0;

	private int jyukouJyokyo = 0;

	private int jyukouFollow = 0;

	private int ninteiTaisyosyaKensaku = 0;

	private int ninteiTaisyosyaItiran = 0;

	private int jyukouNinteiTouroku = 0;

	private int jyukouNinteiKaijyo = 0;

	private int defaultSettei = 0;

	/**
	 * @return
	 */
	public int getClassCyosei() {
		return this.classCyosei;
	}

	/**
	 * @return
	 */
	public int getClassCyusi() {
		return this.classCyusi;
	}

	/**
	 * @return
	 */
	public int getClassHenkou() {
		return this.classHenkou;
	}

	/**
	 * @return
	 */
	public int getClassSaikai() {
		return this.classSaikai;
	}

	/**
	 * @return
	 */
	public int getClassSakujyo() {
		return this.classSakujyo;
	}

	/**
	 * @return
	 */
	public int getClassSyuryo() {
		return this.classSyuryo;
	}

	/**
	 * @return
	 */
	public int getClassTouroku() {
		return this.classTouroku;
	}

	/**
	 * @return
	 */
	public int getCurriculumMapTouroku() {
		return this.curriculumMapTouroku;
	}

	/**
	 * @return
	 */
	public int getDaikouNyuryoku() {
		return this.daikouNyuryoku;
	}

	/**
	 * @return
	 */
	public int getEsNinsyo() {
		return this.esNinsyo;
	}

	/**
	 * @return
	 */
	public int getHonninKensyuJyohou() {
		return this.honninKensyuJyohou;
	}

	/**
	 * @return
	 */
	public int getJikohyokaNyuryoku() {
		return this.jikohyokaNyuryoku;
	}

	/**
	 * @return
	 */
	public int getJikosinkokuSyosai() {
		return this.jikosinkokuSyosai;
	}

	/**
	 * @return
	 */
	public int getJyukouHoukoku() {
		return this.jyukouHoukoku;
	}

	/**
	 * @return
	 */
	public int getJyukouSinkokuNyuryoku() {
		return this.jyukouSinkokuNyuryoku;
	}

	/**
	 * @return
	 */
	public int getJyukouFollow() {
		return this.jyukouFollow;
	}

	/**
	 * @return
	 */
	public int getJyukouJyokyo() {
		return this.jyukouJyokyo;
	}

	/**
	 * @return
	 */
	public int getJyukouNinteiKaijyo() {
		return this.jyukouNinteiKaijyo;
	}

	/**
	 * @return
	 */
	public int getJyukouNinteiTouroku() {
		return this.jyukouNinteiTouroku;
	}

	/**
	 * @return
	 */
	public int getKamokuHenkou() {
		return this.kamokuHenkou;
	}

	/**
	 * @return
	 */
	public int getKamokuItiran() {
		return this.kamokuItiran;
	}

	/**
	 * @return
	 */
	public int getKamokuSakujyo() {
		return this.kamokuSakujyo;
	}

	/**
	 * @return
	 */
	public int getKamokuSentaku() {
		return this.kamokuSentaku;
	}

	/**
	 * @return
	 */
	public int getKamokuTouroku() {
		return this.kamokuTouroku;
	}

	/**
	 * @return
	 */
	public int getKensyuJyohouKousin() {
		return this.kensyuJyohouKousin;
	}

	/**
	 * @return
	 */
	public int getKensyuJyohouSakujyo() {
		return this.kensyuJyohouSakujyo;
	}

	/**
	 * @return
	 */
	public int getKensyuJyohouTuika() {
		return this.kensyuJyohouTuika;
	}

	/**
	 * @return
	 */
	public int getKensyukanriClassSyosai() {
		return this.kensyukanriClassSyosai;
	}

	/**
	 * @return
	 */
	public int getKensyukanriJyohou() {
		return this.kensyukanriJyohou;
	}

	/**
	 * @return
	 */
	public int getKensyuKanryobiKousin() {
		return this.kensyuKanryobiKousin;
	}

	/**
	 * @return
	 */
	public int getKensyuMousikomi() {
		return this.kensyuMousikomi;
	}

	/**
	 * @return
	 */
	public int getKensyusyaClassSyosai() {
		return this.kensyusyaClassSyosai;
	}

	/**
	 * @return
	 */
	public int getKensyuSyosai() {
		return this.kensyuSyosai;
	}

	/**
	 * @return
	 */
	public String getLoginJikoku() {
		return this.loginJikoku;
	}

	/**
	 * @return
	 */
	public String getLogoutJikoku() {
		return this.logoutJikoku;
	}

	/**
	 * @return
	 */
	public int getMousikomiTorikesi() {
		return this.mousikomiTorikesi;
	}

	/**
	 * @return
	 */
	public int getNinteiTaisyosyaItiran() {
		return this.ninteiTaisyosyaItiran;
	}

	/**
	 * @return
	 */
	public int getNinteiTaisyosyaKensaku() {
		return this.ninteiTaisyosyaKensaku;
	}

	/**
	 * @return
	 */
	public int getReportTeisyutu() {
		return this.reportTeisyutu;
	}

	/**
	 * @return
	 */
	public int getSeisekiNyuryoku() {
		return this.seisekiNyuryoku;
	}

	/**
	 * @return
	 */
	public String getSessionId() {
		return this.sessionId;
	}

	/**
	 * @return
	 */
	public String getSimeiNo() {
		return this.simeiNo;
	}

	/**
	 * @return
	 */
	public int getSitumonHyoji() {
		return this.situmonHyoji;
	}

	/**
	 * @return
	 */
	public int getSitumonNyuryoku() {
		return this.situmonNyuryoku;
	}

	/**
	 * @return
	 */
	public String getSosikiCode() {
		return this.sosikiCode;
	}

	/**
	 * @return
	 */
	public int getSyonin() {
		return this.syonin;
	}

	/**
	 * @return
	 */
	public int getSyoninSasimodosi() {
		return this.syoninSasimodosi;
	}

	/**
	 * @return
	 */
	public int getSyoninsyaKakuninHenkou() {
		return this.syoninsyaKakuninHenkou;
	}

	/**
	 * @return
	 */
	public int getSyoninsyaSakujyo() {
		return this.syoninsyaSakujyo;
	}

	/**
	 * @return
	 */
	public int getSyoninsyaSentaku() {
		return this.syoninsyaSentaku;
	}

	/**
	 * @return
	 */
	public int getSyoninsyaSettei() {
		return this.syoninsyaSettei;
	}

	/**
	 * @return
	 */
	public int getTaisyoBumonSettei() {
		return this.taisyoBumonSettei;
	}

	/**
	 * @return
	 */
	public int getTaisyosyaSettei() {
		return this.taisyosyaSettei;
	}

	/**
	 * @return
	 */
	public int getTaisyosyaSetteiKensakukekka() {
		return this.taisyosyaSetteiKensakukekka;
	}

	/**
	 * @return
	 */
	public int getTaisyoSyokusyuSettei() {
		return this.taisyoSyokusyuSettei;
	}

	/**
	 * @return
	 */
	public int getUketuke() {
		return this.uketuke;
	}

	/**
	 * @return
	 */
	public int getUketukeSasimodosi() {
		return this.uketukeSasimodosi;
	}

	/**
	 * @param i
	 */
	public void setClassCyosei(final int i) {
		this.classCyosei = i;
	}

	/**
	 * @param i
	 */
	public void setClassCyusi(final int i) {
		this.classCyusi = i;
	}

	/**
	 * @param i
	 */
	public void setClassHenkou(final int i) {
		this.classHenkou = i;
	}

	/**
	 * @param i
	 */
	public void setClassSaikai(final int i) {
		this.classSaikai = i;
	}

	/**
	 * @param i
	 */
	public void setClassSakujyo(final int i) {
		this.classSakujyo = i;
	}

	/**
	 * @param i
	 */
	public void setClassSyuryo(final int i) {
		this.classSyuryo = i;
	}

	/**
	 * @param i
	 */
	public void setClassTouroku(final int i) {
		this.classTouroku = i;
	}

	/**
	 * @param i
	 */
	public void setCurriculumMapTouroku(final int i) {
		this.curriculumMapTouroku = i;
	}

	/**
	 * @param i
	 */
	public void setDaikouNyuryoku(final int i) {
		this.daikouNyuryoku = i;
	}

	/**
	 * @param i
	 */
	public void setEsNinsyo(final int i) {
		this.esNinsyo = i;
	}

	/**
	 * @param i
	 */
	public void setHonninKensyuJyohou(final int i) {
		this.honninKensyuJyohou = i;
	}

	/**
	 * @param i
	 */
	public void setJikohyokaNyuryoku(final int i) {
		this.jikohyokaNyuryoku = i;
	}

	/**
	 * @param i
	 */
	public void setJikosinkokuSyosai(final int i) {
		this.jikosinkokuSyosai = i;
	}

	/**
	 * @param i
	 */
	public void setJyukouHoukoku(final int i) {
		this.jyukouHoukoku = i;
	}

	/**
	 * @param i
	 */
	public void setJyukouSinkokuNyuryoku(final int i) {
		this.jyukouSinkokuNyuryoku = i;
	}

	/**
	 * @param i
	 */
	public void setJyukouFollow(final int i) {
		this.jyukouFollow = i;
	}

	/**
	 * @param i
	 */
	public void setJyukouJyokyo(final int i) {
		this.jyukouJyokyo = i;
	}

	/**
	 * @param i
	 */
	public void setJyukouNinteiKaijyo(final int i) {
		this.jyukouNinteiKaijyo = i;
	}

	/**
	 * @param i
	 */
	public void setJyukouNinteiTouroku(final int i) {
		this.jyukouNinteiTouroku = i;
	}

	/**
	 * @param i
	 */
	public void setKamokuHenkou(final int i) {
		this.kamokuHenkou = i;
	}

	/**
	 * @param i
	 */
	public void setKamokuItiran(final int i) {
		this.kamokuItiran = i;
	}

	/**
	 * @param i
	 */
	public void setKamokuSakujyo(final int i) {
		this.kamokuSakujyo = i;
	}

	/**
	 * @param i
	 */
	public void setKamokuSentaku(final int i) {
		this.kamokuSentaku = i;
	}

	/**
	 * @param i
	 */
	public void setKamokuTouroku(final int i) {
		this.kamokuTouroku = i;
	}

	/**
	 * @param i
	 */
	public void setKensyuJyohouKousin(final int i) {
		this.kensyuJyohouKousin = i;
	}

	/**
	 * @param i
	 */
	public void setKensyuJyohouSakujyo(final int i) {
		this.kensyuJyohouSakujyo = i;
	}

	/**
	 * @param i
	 */
	public void setKensyuJyohouTuika(final int i) {
		this.kensyuJyohouTuika = i;
	}

	/**
	 * @param i
	 */
	public void setKensyukanriClassSyosai(final int i) {
		this.kensyukanriClassSyosai = i;
	}

	/**
	 * @param i
	 */
	public void setKensyukanriJyohou(final int i) {
		this.kensyukanriJyohou = i;
	}

	/**
	 * @param i
	 */
	public void setKensyuKanryobiKousin(final int i) {
		this.kensyuKanryobiKousin = i;
	}

	/**
	 * @param i
	 */
	public void setKensyuMousikomi(final int i) {
		this.kensyuMousikomi = i;
	}

	/**
	 * @param i
	 */
	public void setKensyusyaClassSyosai(final int i) {
		this.kensyusyaClassSyosai = i;
	}

	/**
	 * @param i
	 */
	public void setKensyuSyosai(final int i) {
		this.kensyuSyosai = i;
	}

	/**
	 * @param string
	 */
	public void setLoginJikoku(final String string) {
		this.loginJikoku = string;
	}

	/**
	 * @param string
	 */
	public void setLogoutJikoku(final String string) {
		this.logoutJikoku = string;
	}

	/**
	 * @param i
	 */
	public void setMousikomiTorikesi(final int i) {
		this.mousikomiTorikesi = i;
	}

	/**
	 * @param i
	 */
	public void setNinteiTaisyosyaItiran(final int i) {
		this.ninteiTaisyosyaItiran = i;
	}

	/**
	 * @param i
	 */
	public void setNinteiTaisyosyaKensaku(final int i) {
		this.ninteiTaisyosyaKensaku = i;
	}

	/**
	 * @param i
	 */
	public void setReportTeisyutu(final int i) {
		this.reportTeisyutu = i;
	}

	/**
	 * @param i
	 */
	public void setSeisekiNyuryoku(final int i) {
		this.seisekiNyuryoku = i;
	}

	/**
	 * @param string
	 */
	public void setSessionId(final String string) {
		this.sessionId = string;
	}

	/**
	 * @param string
	 */
	public void setSimeiNo(final String string) {
		this.simeiNo = string;
	}

	/**
	 * @param i
	 */
	public void setSitumonHyoji(final int i) {
		this.situmonHyoji = i;
	}

	/**
	 * @param i
	 */
	public void setSitumonNyuryoku(final int i) {
		this.situmonNyuryoku = i;
	}

	/**
	 * @param string
	 */
	public void setSosikiCode(final String string) {
		this.sosikiCode = string;
	}

	/**
	 * @param i
	 */
	public void setSyonin(final int i) {
		this.syonin = i;
	}

	/**
	 * @param i
	 */
	public void setSyoninSasimodosi(final int i) {
		this.syoninSasimodosi = i;
	}

	/**
	 * @param i
	 */
	public void setSyoninsyaKakuninHenkou(final int i) {
		this.syoninsyaKakuninHenkou = i;
	}

	/**
	 * @param i
	 */
	public void setSyoninsyaSakujyo(final int i) {
		this.syoninsyaSakujyo = i;
	}

	/**
	 * @param i
	 */
	public void setSyoninsyaSentaku(final int i) {
		this.syoninsyaSentaku = i;
	}

	/**
	 * @param i
	 */
	public void setSyoninsyaSettei(final int i) {
		this.syoninsyaSettei = i;
	}

	/**
	 * @param i
	 */
	public void setTaisyoBumonSettei(final int i) {
		this.taisyoBumonSettei = i;
	}

	/**
	 * @param i
	 */
	public void setTaisyosyaSettei(final int i) {
		this.taisyosyaSettei = i;
	}

	/**
	 * @param i
	 */
	public void setTaisyosyaSetteiKensakukekka(final int i) {
		this.taisyosyaSetteiKensakukekka = i;
	}

	/**
	 * @param i
	 */
	public void setTaisyoSyokusyuSettei(final int i) {
		this.taisyoSyokusyuSettei = i;
	}

	/**
	 * @param i
	 */
	public void setUketuke(final int i) {
		this.uketuke = i;
	}

	/**
	 * @param i
	 */
	public void setUketukeSasimodosi(final int i) {
		this.uketukeSasimodosi = i;
	}

	/**
	 * @return
	 */
	public int getDefaultSettei() {
		return this.defaultSettei;
	}

	/**
	 * @param i
	 */
	public void setDefaultSettei(final int i) {
		this.defaultSettei = i;
	}

}
