/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/03/08  01.00       ���� ��F    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.valuebean;

import java.io.Serializable;

import jp.co.hisas.career.learning.base.bean.PCY_CodeBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ060_DateConvertUtil;

/**
 * <PRE>
 * 
 * �N���X���F PCY_KensyuRirekiBeanForMail �N���X �@�\�����F ���[���@�\�p�Ɍ��C��������ێ�����ValueBean�ł��B
 * 
 * </PRE>
 */
public class PCY_KensyuRirekiBeanForMail implements Serializable {

	private String simeiNo = null;

	private String kamokuCode = null;

	private String kamokuMei1 = null;

	private String classCode = null;

	private String classMei = null;

	private String kaisibi = null;

	private String syuryobi = null;

	private String tensu = null;

	private String seiseki = null;

	private String syuryoHantei = null;

	private String syussekiNissuu = null;

	private String seisekiBikou = null;

    // ADD 2018/01/10 COMTURE �����t�Ή� START
    private String hizukeKubun = null;
    // ADD 2018/01/10 COMTURE �����t�Ή� END
	public PCY_KensyuRirekiBeanForMail(final PCY_KensyuRirekiBean kensyuRirekiBean) {

		// ����NO
		this.setSimeiNo(kensyuRirekiBean.getSimeiNo());
		// �ȖڃR�[�h
		if (kensyuRirekiBean.getKamokuCode() != null && !kensyuRirekiBean.getKamokuCode().equals("")) {
			this.setKamokuCode(kensyuRirekiBean.getKamokuCode());
		} else {
			this.setKamokuCode("");
		}
		// �Ȗږ�1
		if (kensyuRirekiBean.getKamokuMei1() != null && !kensyuRirekiBean.getKamokuMei1().equals("")) {
			this.setKamokuMei1(kensyuRirekiBean.getKamokuMei1());
		} else {
			this.setKamokuMei1("");
		}
		// �N���X�R�[�h
		if (kensyuRirekiBean.getClassCode() != null && !kensyuRirekiBean.getClassCode().equals("")) {
			this.setClassCode(kensyuRirekiBean.getClassCode());
		} else {
			this.setClassCode("");
		}
		// �N���X��
		if (kensyuRirekiBean.getClassMei() != null && !kensyuRirekiBean.getClassMei().equals("")) {
			this.setClassMei(kensyuRirekiBean.getClassMei());
		} else {
			this.setClassMei("");
		}
        // ADD 2018/01/10 COMTURE �����t�Ή� START
        String hizukeKubunCode = "";
        /* ���t�敪���Z�b�g���� */
        this.setHizukeKubun(PZZ060_DateConvertUtil.getHizukeKubunLabel(hizukeKubunCode));
        // ADD 2018/01/10 COMTURE �����t�Ή� END
		// �J�n��
		if (kensyuRirekiBean.getKaisibi() != null && !kensyuRirekiBean.getKaisibi().equals("")) {
	        // MOD 2018/01/10 COMTURE �����t�Ή� START
//			this.setKaisibi(PZZ010_CharacterUtil.ChangeYmd(kensyuRirekiBean.getKaisibi()));
	        this.setKaisibi(PZZ060_DateConvertUtil.convertToKarihizuke(
                    kensyuRirekiBean.getKaisibi(), hizukeKubunCode));
	        // MOD 2018/01/10 COMTURE �����t�Ή� END
		} else {
			this.setKaisibi("");
		}
		// �I����
		if (kensyuRirekiBean.getSyuryobi() != null && !kensyuRirekiBean.getSyuryobi().equals("")) {
	        // MOD 2018/01/10 COMTURE �����t�Ή� START
//			this.setSyuryobi(PZZ010_CharacterUtil.ChangeYmd(kensyuRirekiBean.getSyuryobi()));
	        this.setSyuryobi(PZZ060_DateConvertUtil.convertToKarihizuke(
                    kensyuRirekiBean.getSyuryobi(), hizukeKubunCode));
	        // MOD 2018/01/10 COMTURE �����t�Ή� END
		} else {
			this.setSyuryobi("");
		}
		// �_��
		if (kensyuRirekiBean.getTensu() != null) {
			this.setTensu(kensyuRirekiBean.getTensu().toString());
		} else {
			this.setTensu("");
		}
		// ����
		if (kensyuRirekiBean.getSeiseki() != null && !kensyuRirekiBean.getSeiseki().equals("")) {
			this.setSeiseki(kensyuRirekiBean.getSeiseki());
		} else {
			this.setSeiseki("");
		}
		// �o�ȓ���
		if (kensyuRirekiBean.getSyussekiNissuu() != null) {
			this.setSyussekiNissuu(kensyuRirekiBean.getSyussekiNissuu().toString());
		} else {
			this.setSyussekiNissuu("");
		}
		// ���є��l
		if (kensyuRirekiBean.getSeisekiBikou() != null && !kensyuRirekiBean.getSeisekiBikou().equals("")) {
			this.setSeisekiBikou(kensyuRirekiBean.getSeisekiBikou());
		} else {
			this.setSeisekiBikou("");
		}
		// �C������
		if (kensyuRirekiBean.getSyuryoHantei() != null && !kensyuRirekiBean.getSyuryoHantei().equals("")) {
			this.setSyuryoHantei(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.SYURYO_HANTEI, kensyuRirekiBean.getSyuryoHantei()));
		} else {
			this.setSyuryoHantei("");
		}
	}

	/**
	 * @return
	 */
	public String getClassCode() {
		return this.classCode;
	}

	/**
	 * @return
	 */
	public String getClassMei() {
		return this.classMei;
	}

	/**
	 * @return
	 */
	public String getKaisibi() {
		return this.kaisibi;
	}

	/**
	 * @return
	 */
	public String getKamokuCode() {
		return this.kamokuCode;
	}

	/**
	 * @return
	 */
	public String getKamokuMei1() {
		return this.kamokuMei1;
	}

	/**
	 * @return
	 */
	public String getSeiseki() {
		return this.seiseki;
	}

	/**
	 * @return
	 */
	public String getSeisekiBikou() {
		return this.seisekiBikou;
	}

	/**
	 * @return
	 */
	public String getSimeiNo() {
		return this.simeiNo;
	}

	/**
	 * @return
	 */
	public String getSyuryobi() {
		return this.syuryobi;
	}

	/**
	 * @return
	 */
	public String getSyuryoHantei() {
		return this.syuryoHantei;
	}

	/**
	 * @return
	 */
	public String getSyussekiNissuu() {
		return this.syussekiNissuu;
	}

	/**
	 * @return
	 */
	public String getTensu() {
		return this.tensu;
	}

	/**
	 * @param string
	 */
	public void setClassCode(final String string) {
		this.classCode = string;
	}

	/**
	 * @param string
	 */
	public void setClassMei(final String string) {
		this.classMei = string;
	}

	/**
	 * @param string
	 */
	public void setKaisibi(final String string) {
		this.kaisibi = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuCode(final String string) {
		this.kamokuCode = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuMei1(final String string) {
		this.kamokuMei1 = string;
	}

	/**
	 * @param string
	 */
	public void setSeiseki(final String string) {
		this.seiseki = string;
	}

	/**
	 * @param string
	 */
	public void setSeisekiBikou(final String string) {
		this.seisekiBikou = string;
	}

	/**
	 * @param string
	 */
	public void setSimeiNo(final String string) {
		this.simeiNo = string;
	}

	/**
	 * @param string
	 */
	public void setSyuryobi(final String string) {
		this.syuryobi = string;
	}

	/**
	 * @param string
	 */
	public void setSyuryoHantei(final String string) {
		this.syuryoHantei = string;
	}

	/**
	 * @param string
	 */
	public void setSyussekiNissuu(final String string) {
		this.syussekiNissuu = string;
	}

	/**
	 * @param string
	 */
	public void setTensu(final String string) {
		this.tensu = string;
	}

    // ADD 2018/01/10 COMTURE �����t�Ή� START
    /**
     * ���t�敪���擾���܂��B
     * @return
     */
    public String getHizukeKubun() {
        return this.hizukeKubun;
    }

    /**
     * ���t�敪��ݒ肵�܂��B
     * @param string
     */
    public void setHizukeKubun(final String string) {
        this.hizukeKubun = string;
    }

    // ADD 2018/01/10 COMTURE �����t�Ή� END
}
