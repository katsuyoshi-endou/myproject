/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 * 
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/04/08  01.00       ���� ����    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.bean.PCY_KensyuKanriJohoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PCY151_ClassCyoseiKakuninServlet �N���X �@�\�����F �\���󋵂̌������s���܂��B
 * 
 * </PRE>
 */
public class PCY151_ClassCyoseiKakuninServlet extends PCY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final PCY_ClassBean classBean = new PCY_ClassBean(request);

		String[] simeiNo = request.getParameterValues("mousikomisya");

		/** ���ߗ��R���͉�ʂ���Ă΂ꂽ�Ƃ��́AsimeiNo���擾����B */
		if (simeiNo == null) {
			Log.debug("simeiIndex �擾");
			final String simeiLengthStr = request.getParameter("simeiLength");
			final int length = (new Integer(simeiLengthStr)).intValue();
			final String[] simeiNo_req = new String[length];
			simeiNo = new String[length];
			for (int t = 0; t < length; t++) {
				simeiNo_req[t] = request.getParameter("simeiNo_" + Integer.toString(t));
				Log.debug("simeiNo: " + simeiNo_req[t]);
				simeiNo[t] = simeiNo_req[t];
			}
			request.setAttribute("riyu", request.getParameter("riyu"));
			request.setAttribute("riyu_code", request.getParameter("riyu_code"));
		}

		if (simeiNo != null) {
			final PCY_KensyuKanriJohoBean[] taisyosyaBeans = new PCY_KensyuKanriJohoBean[simeiNo.length];
			for (int i = 0; i < simeiNo.length; i++) {
				taisyosyaBeans[i] = new PCY_KensyuKanriJohoBean();
				final String index = simeiNo[i];

				final PCY_PersonalBean personalBean = new PCY_PersonalBean();
				personalBean.setSimeiNo(request.getParameter("simei_no_" + index));
				personalBean.setKanjiSimei(request.getParameter("kanji_simei_" + index));
				personalBean.setSosikiCode(request.getParameter("sosiki_code_" + index));

				final PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean();
				mousikomiBean.setPersonalBean(personalBean);
				mousikomiBean.setMousikomibi(request.getParameter("mousikomibi_" + index));
				mousikomiBean.setStatus(request.getParameter("status_" + index));
				mousikomiBean.setKousinbi(request.getParameter("kousinbi_" + index));
				mousikomiBean.setKousinjikoku(request.getParameter("kousinjikoku_" + index));

				mousikomiBean.setMousikomibi(request.getParameter("mousikomibi_" + index));
				mousikomiBean.setMousikomijikoku(request.getParameter("mousikomijikoku_" + index));
				mousikomiBean.setMousikomisya(request.getParameter("mousikomisya_" + index));
				mousikomiBean.setSyoninbi1(request.getParameter("syoninbi1_" + index));
				mousikomiBean.setSyoninjikoku1(request.getParameter("syoninjikoku1_" + index));
				mousikomiBean.setSyoninsya1(request.getParameter("syoniinsya1_" + index));
				mousikomiBean.setSyoninbi2(request.getParameter("syoninbi2_" + index));
				mousikomiBean.setSyoninjikoku2(request.getParameter("syoninjikoku2_" + index));
				mousikomiBean.setSyoninsya2(request.getParameter("syoninsya2_" + index));
				mousikomiBean.setUketukebi(request.getParameter("uketukebi_" + index));
				mousikomiBean.setUketukejikoku(request.getParameter("uketukejikoku_" + index));
				mousikomiBean.setUketukesya(request.getParameter("uketukesya_" + index));

				taisyosyaBeans[i].setMousikomiBean(mousikomiBean);
				taisyosyaBeans[i].getTaisyousyaBean().setTaisyoKubun(request.getParameter("taisyokubun_" + index));

			}

			request.setAttribute("taisyosyaBeans", taisyosyaBeans);
		}
		request.setAttribute("classBean", classBean);
		request.setAttribute("simeiNoIndex", simeiNo);

		try {
			String logID = null;
			if (request.getParameter("H014_exec_command").equals("uketukesasimodosiriyu")) {
				logID = "VCC313";
			} else if (request.getParameter("H014_exec_command").equals("torikesisasimodosiriyu")) {
				logID = "VCC314";
			}
			if (logID != null) {
				OutLogBean.sousaKojinJohoLog(logID, loginuser.getSimeiNo(), "", classBean.getKamokuBean().getKamokuCode() + "," + classBean.getClassCode());
			}
		} catch (final Exception e) {
		}

		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

}
