/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F PCY110_ClassIchiranServlet �N���X �@�\�����F �N���X�̈ꗗ���擾���܂��B
 * 
 * </PRE>
 */
public class PCY110_ClassIchiranServlet extends PCY010_ControllerServlet {

	/**
	 * ���N�G�X�g���猟���������擾���A���������Ɉ�v����N���X�����擾���܂��B �N���X���̓��N�G�X�g(�������F"classBeans")�Ɋi�[���܂��B �N���X��񂪑��݂��Ȃ��ꍇ�A���N�G�X�g�ɂ͋�̔z�񂪊i�[����܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean )
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		final String searchFlg = request.getParameter("searchFlg");
		String limitFlg = (String) request.getSession().getAttribute("limitFlgKanri");
		final String limitStr = (String) ReadFile.fileMapData.get(HcdbDef.vcc010_limit);
		final int limit = Integer.valueOf(limitStr).intValue();
		final String cancelFlg = request.getParameter("cancelFlg");

		if (cancelFlg != null && cancelFlg.equals("false")) {
			limitFlg = "";
		}
		PCY_ClassBean[] classBeans = null;
		if (searchFlg == null || searchFlg.equals("") || searchFlg.length() <= 0) {
			if (limitFlg == null || limitFlg.equals("") || limitFlg.length() <= 0) {

				final PCY_ClassEJBHome home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
				final PCY_ClassEJB ejb = home.create();

				final PCY_ClassBean classBean = new PCY_ClassBean(request);
				classBean.getKamokuBean().setKamokuMei1(classBean.getKamokuBean().getKamokuMei1());
				classBeans = ejb.doSelect(classBean, false, loginuser);

				final PCY_MousikomiJyokyoEJBHome home1 = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
				final PCY_MousikomiJyokyoEJB ejb1 = home1.create();
				for (int i = 0; i < classBeans.length; i++) {

					classBeans[i] = ejb1.doCountJyukosya(classBeans[i], loginuser);
					classBeans[i] = ejb1.doCountMousikomisya(classBeans[i], loginuser);

				}

				/* ����𒴂����ꍇ�A����l�T�C�Y��classBeans���쐬���� */
				/* �쐬����classBeans��Ԃ��B�܂��A�S�f�[�^classBeans��session�ɕۑ� */
				if (classBeans.length > limit) {
					final PCY_ClassBean[] ret_classBeans = new PCY_ClassBean[limit];
					for (int i = 0; i < limit; i++) {
						ret_classBeans[i] = classBeans[i];
					}

					request.getSession().setAttribute("classBeans", classBeans);
					request.getSession().setAttribute("limitMaxKanri", "true");
					request.getSession().setAttribute("limitFlgKanri", "true");
					classBeans = ret_classBeans;
// ADD 2008/04/09 COMTURE BQUP1-VCC010-001 START
				} else {
					request.getSession().setAttribute("limitMaxKanri", "false");
					request.getSession().setAttribute("limitFlgKanri", "");
// ADD 2008/04/09 COMTURE BQUP1-VCC010-001 END
				}

			} else {
				/* session�ɕۑ����Ă���S�f�[�^���擾���Ԃ� */
				classBeans = (PCY_ClassBean[]) request.getSession().getAttribute("classBeans");
				request.getSession().setAttribute("classBeans", "");
				request.getSession().setAttribute("limitMaxKanri", "false");
				request.getSession().setAttribute("limitFlgKanri", "");
			}
		} else {
			classBeans = new PCY_ClassBean[0];
// ADD 2008/04/09 COMTURE BQUP1-VCC010-001 START
			request.getSession().setAttribute( "limitMaxKanri", "false" );
			request.getSession().setAttribute( "limitFlgKanri", "" );
// ADD 2008/04/09 COMTURE BQUP1-VCC010-001 END
		}

		request.setAttribute("cancelFlg", cancelFlg);
		request.setAttribute("classBeans", classBeans);

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

}
