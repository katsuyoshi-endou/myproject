/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.mail.internet.AddressException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_KensyuMailSender;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_CancelKikanEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_CancelKikanEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_HizukeKubunEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_HizukeKubunEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_JizenkadaiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_JizenkadaiEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_ReportSubmitKikanEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ReportSubmitKikanEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_CancelKikanBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_JizenkadaiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ReportSubmitKikanBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyososikiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyokusyuBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY112_ClassTourokuServlet �N���X �@�\�����F �N���X�̓o�^���s���܂��B
 * 
 * </PRE>
 */
public class PCY112_ClassTourokuServlet extends PCY010_ControllerServlet {
	/**
	 * ���N�G�X�g����N���X���e���擾���A�N���X�����쐬���܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean )
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException, Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		PCY_ClassBean classBean = new PCY_ClassBean(request);
		
		if (request.getParameter("ninsyo_kubun") == null) {
			classBean.setNinsyoKubun("0");
		}
		PCY_TaisyosyokusyuBean[] taisyosyokusyuBeans = null;
		PCY_TaisyososikiBean[] taisyososikiBeans = null;
		PCY_TaisyosyaBean[] taisyosyaBeans = null;

		// �S�БΏۂ��u�Ώہv�̏ꍇ�́A�ΏێҐݒ�̏���o�^���Ȃ��B
		if (!classBean.getZensyaTaisyoFlg().equals("1")) {

			taisyosyokusyuBeans = (PCY_TaisyosyokusyuBean[]) request.getSession().getAttribute("taisyosyokusyuBeans");
			taisyososikiBeans = (PCY_TaisyososikiBean[]) request.getSession().getAttribute("taisyososikiBeans");
			taisyosyaBeans = (PCY_TaisyosyaBean[]) request.getSession().getAttribute("taisyosyaBeans");
		}
		/* ���N���X�̏��������p�� �ꍇ */
		final String succeedClassCode = request.getParameter("SucceedClassCode");

		if (succeedClassCode != null && !succeedClassCode.equals("")) {
			/* TaisyoEJB */
			final PCY_TaisyoEJBHome taisyo_home = (PCY_TaisyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_TaisyoEJBHome.class);
			final PCY_TaisyoEJB taisyo_ejb = taisyo_home.create();

			final String SucceedHissuClassCode = request.getParameter("SucceedClassCode");

			taisyosyokusyuBeans = taisyo_ejb.getTaisyosyokusyu(classBean.getKamokuBean().getKamokuCode(), succeedClassCode, loginuser);

			taisyososikiBeans = taisyo_ejb.getTaisyososiki(classBean.getKamokuBean().getKamokuCode(), succeedClassCode, loginuser);

			taisyosyaBeans = taisyo_ejb.getTaisyosya(classBean.getKamokuBean().getKamokuCode(), succeedClassCode, loginuser);

			for (int i = 0; i < taisyosyokusyuBeans.length; i++) {
				taisyosyokusyuBeans[i].setClassBean(new PCY_ClassBean());
			}

			for (int i = 0; i < taisyososikiBeans.length; i++) {
				taisyososikiBeans[i].setClassBean(new PCY_ClassBean());
			}

			for (int i = 0; i < taisyosyaBeans.length; i++) {
				taisyosyaBeans[i].setClassBean(new PCY_ClassBean());
			}
		}

		final PCY_ClassEJBHome home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB ejb = home.create();

		if (classBean.getKisyoIkkatsuFlg() == null) {
			classBean.setKisyoIkkatsuFlg("0");
		}
		if (classBean.getZensyaTaisyoFlg() == null) {
			classBean.setZensyaTaisyoFlg("0");
		}

		/* �}�����悤�Ƃ��Ă���N���X�����łɂ������ꍇ�G���[�Ƃ���i�폜�ς݊܂ށj */
		final PCY_ClassBean serchClassBean = new PCY_ClassBean();
		serchClassBean.getKamokuBean().setKamokuCode(classBean.getKamokuBean().getKamokuCode());
		serchClassBean.setClassCode(classBean.getClassCode());
		final PCY_ClassBean[] allClassBean = ejb.doAllSelect(serchClassBean, true, loginuser);
		if (allClassBean != null && allClassBean.length != 0) {
			request.setAttribute("warningID", "WCC270");
			throw new PCY_WarningException();
		}

		final int count = ejb.doInsert(new PCY_ClassBean[] { classBean }, taisyosyaBeans, taisyososikiBeans, taisyosyokusyuBeans, loginuser);
		
// ADD 2017/05/10 COMTURE VCC091_�N���X�o�^ ���́iver.02-00�j START
		final HttpSession session = request.getSession(false);
		final PCY_JizenkadaiBean JizenkadaiBean = (PCY_JizenkadaiBean) session.getAttribute("jizenkadaiBean");
		
		//�Z�b�V�������폜
		session.removeAttribute("jizenkadaiBean");
		
        // ���O�ۑ�}�X�^�o�^
        final PCY_JizenkadaiEJBHome jznkdihome = (PCY_JizenkadaiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_JizenkadaiEJBHome.class);
        final PCY_JizenkadaiEJB jznkdiejb = jznkdihome.create();
        jznkdiejb.doInsert(JizenkadaiBean, loginuser);
// ADD 2017/05/10 COMTURE VCC091_�N���X�o�^ ���́iver.02-00�j END

// ADD 2017/10/20 HISOL �\��������Ԓǉ��Ή� START
		final PCY_CancelKikanBean cancelBean = (PCY_CancelKikanBean)session.getAttribute("cancelKikanBean");
		
		// �Z�b�V���������폜
		session.removeAttribute("cancelKikanBean");
		
		// �\��������Ԃ̓o�^
		final PCY_CancelKikanEJBHome cancelHome = (PCY_CancelKikanEJBHome)EJBHomeFactory.getInstance().lookup(PCY_CancelKikanEJBHome.class);
		final PCY_CancelKikanEJB cancelEjb = cancelHome.create();
		cancelEjb.doInsert(cancelBean, loginuser);
// ADD 2017/10/20 HISOL �\��������Ԓǉ��Ή� END
// ADD 2018/12/03 COMTURE ���|�[�g��o���Ԓǉ��Ή� START
		final PCY_ReportSubmitKikanBean reportSubmitKikanBean = (PCY_ReportSubmitKikanBean)session.getAttribute("reportSubmitKikanBean");
		
		// �Z�b�V���������폜
		session.removeAttribute("reportSubmitKikanBean");
		
		// ���|�[�g��o���Ԃ̓o�^
		final PCY_ReportSubmitKikanEJBHome reportSubmitKikanHome = (PCY_ReportSubmitKikanEJBHome)EJBHomeFactory.getInstance().lookup(PCY_ReportSubmitKikanEJBHome.class);
		final PCY_ReportSubmitKikanEJB reportSubmitKikanEjb = reportSubmitKikanHome.create();
// ADD 2019/03/01 COMTURE phase7-2018S-���C_CT_012 START
		// ���|�[�g�敪���u�v�v�̏ꍇ�̓��R�[�h���쐬
		if (("1").equals(JizenkadaiBean.getJizenkadaiKubun())){
// ADD 2019/03/01 COMTURE phase7-2018S-���C_CT_012 END
		reportSubmitKikanEjb.doInsert(reportSubmitKikanBean, loginuser);
// ADD 2019/03/01 COMTURE phase7-2018S-���C_CT_012 START
		}
// ADD 2019/03/01 COMTURE phase7-2018S-���C_CT_012 END
// ADD 2018/12/03 COMTURE ���|�[�g��o���Ԓǉ��Ή� END
		// ADD 2018/01/09 COMTURE �����t�Ή� START
        // ���t�敪�̓o�^
        final PCY_HizukeKubunEJBHome hizukeHome =
                (PCY_HizukeKubunEJBHome)EJBHomeFactory.getInstance().lookup(
                        PCY_HizukeKubunEJBHome.class);
        final PCY_HizukeKubunEJB hizukeEjb = hizukeHome.create();
        hizukeEjb.doInsert(classBean, loginuser);
        // ADD 2018/01/09 COMTURE �����t�Ή� END
        
		/* ���[�����M�敪 ����̏����ňē����[���𑗐M���Ȃ��ꍇ�͂O (�m�F��ʃ`�F�b�N�{�b�N�X) */
		final String mail_sousin_kubun = request.getParameter("mail_sousin_kubun");

		/* �N���X�X�V���������N���X�ē����[���敪���v�̏ꍇ�A�ē����[���𑗐M���܂��B */
		if ("1".equals(classBean.getAnnaiMailKubun()) && count == 1 && mail_sousin_kubun.equals("1")) {
			classBean = new PCY_ClassBean(request);
			/* �N���X�̏ڍ׏����擾����i�Ȗږ����K�v�̂��߁j */
			classBean = ejb.doSelectByPrimaryKey(classBean, loginuser);

			// �S�БΏۂłȂ��N���X�̏ꍇ�́A���̃N���X�̑S�Ώێ҂Ƀ��[��
			if (!classBean.getZensyaTaisyoFlg().equals("1")) {

				/* �S�Ώێ҃��X�g���擾���� */
				/* TaisyoEJB */
				final PCY_TaisyoEJBHome taisyo_home = (PCY_TaisyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_TaisyoEJBHome.class);
				final PCY_TaisyoEJB taisyo_ejb = taisyo_home.create();
				final PCY_TaisyosyaBean[] alltaisyosyaBeans = taisyo_ejb.getAllTaisyosya(classBean, false, loginuser);

				String[] simei_no;
				simei_no = new String[alltaisyosyaBeans.length];
				for (int i = 0; i < simei_no.length; i++) {
					simei_no[i] = alltaisyosyaBeans[i].getSimeiNo();
				}

				/* Mail���� */
				final PCY_PersonalEJBHome personalHome = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
				final PCY_PersonalEJB personalEjb = personalHome.create();

				Log.transaction(loginuser.getSimeiNo(), true, "");

				final PCY_PersonalBean[] personalBeans = personalEjb.getPersonalInfo(simei_no, loginuser);
				Log.transaction(loginuser.getSimeiNo(), false, "");

				try {
					/* �N���X�o�^�ē����[���𑗐M���� */
					PCY_KensyuMailSender.sendClassAdd(personalBeans, classBean, loginuser);
				} catch (final AddressException e) {
					Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
					request.setAttribute("warningID", "WCC090");
					throw new PCY_WarningException(e);
				} catch (final Exception e) {
					Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
					request.setAttribute("warningID", "WCC090");
					throw new PCY_WarningException(e);
				}
			}
		}
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
