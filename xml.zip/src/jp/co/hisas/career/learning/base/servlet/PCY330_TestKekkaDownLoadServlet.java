/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.bean.PCY_CodeBean;
import jp.co.hisas.career.learning.base.bean.PCY_KensyuKanriJohoBean;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PzValueEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PzValueEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_SyoninsyaEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_JizenkadaiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_JizenkadaiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBeanForDL;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PzValueBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_SosikiBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ060_DateConvertUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

import com.lowagie.text.DocumentException;

/**
 * <PRE>
 * 
 * �T�v�F�e�X�g���ʈꗗ�̂�EXCEL�쐬���s���B �g�p���@: JSP����Ăяo���B
 * 
 * �����F2018/02/14 COMTURE VCY330_����(Ph2-1)
 * 
 * </PRE>
 */
public class PCY330_TestKekkaDownLoadServlet extends PCY010_ControllerServlet {

    /** �_�E�����[�h�t�@�C���� */
    static final String DOWNLOAD_FILENAME = "TestResultList";

    /** �_�E�����[�h�t�@�C���g���q */
    static final String DOWNLOAD_FILENAME_EXTENSION = ".xlsx";

    /** �_�E�����[�h�̑��� */
    static final String CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8";

    /** ����{�� */
    static final short PAGE_PRINT_SCALE_PERCENT = 61;

    /** �e���v���[�g�t�@�C���̃e���v���[�g�V�[�g�ԍ� */
    static final int TEMPLATE_SHEET_INDEX = 0;

    /** �l���̏����l */
    static final int PERSON_NUM_INI_VAL = 1;

    /** �Ȗږ��̏���s�ԍ� */
    static final int KAMOKUMEI_START_ROW_INDEX = 4;

    /** �Ȗږ��̗�ԍ� */
    static final int KAMOKUMEI_COL_INDEX = 4;

    /** �u�t�̏���s�ԍ� */
    static final int KOUSIMEI_START_ROW_INDEX = 5;

    /** �u�t�̗�ԍ� */
    static final int KOUSIMEI_COL_INDEX = 4;

    /** �J�Ó��̏���s�ԍ� */
    static final int KAISAIBI_START_ROW_INDEX = 6;

    /** �J�Ó��̗�ԍ� */
    static final int KAISAIBI_COL_INDEX = 4;

    /** �J�Î����̏���s�ԍ� */
    static final int KAISAIJIKOKU_START_ROW_INDEX = 7;

    /** �J�Î����̗�ԍ� */
    static final int KAISAIJIKOKU_COL_INDEX = 4;

    /** �n��̏���s�ԍ� */
    static final int CHIKUMEI_START_ROW_INDEX = 8;

    /** �n��̗�ԍ� */
    static final int CHIKUMEI_COL_INDEX = 4;

    /** �P���̏���s�ԍ� */
    static final int TANKA_START_ROW_INDEX = 9;

    /** �P���̗�ԍ� */
    static final int TANKA_COL_INDEX = 4;

    /** ���땔�̏���s�ԍ� */
    static final int MEIBO_START_ROW_INDEX = 12;

    /** �A�Ԃ̗�ԍ� */
    static final int NO_COL_INDEX = 4;

    /** �A���������̗̂�ԍ� */
    static final int BUSYOMEI_COL_INDEX = 5;

    /** �����̗�ԍ� */
    static final int SHIMEI_COL_INDEX = 6;

    /** �_���̗�ԍ� */
    static final int TENSU_COL_INDEX = 7;

    /** 1�y�[�W�s�� */
    static final int PAGE_ROW_INDEX = 48;

    protected String execute(final HttpServletRequest request,
            final HttpServletResponse response, final PCY_PersonalBean loginuser)
            throws NamingException, CreateException, RemoteException,
            PCY_WarningException, IOException, DocumentException, Exception {

        /* ���\�b�h�g���[�X�o�� */
        Log.method(loginuser.getSimeiNo(), "IN", "");
        Log.performance(loginuser.getSimeiNo(), true, "");

        try {

            final HttpSession session = request.getSession(false);
            final UserInfoBean userinfo = (UserInfoBean)session.getAttribute("userinfo");

            // EJBHome�Ǘ��N���X�̎擾
            final EJBHomeFactory fact = EJBHomeFactory.getInstance();

            // �N���X���
            final PCY_ClassEJBHome classHome = (PCY_ClassEJBHome)fact.lookup(PCY_ClassEJBHome.class);
            final PCY_ClassEJB classEJB = classHome.create();
            final PCY_ClassBean classBean = classEJB.doSelectByPrimaryKey(new PCY_ClassBean(request), loginuser);

            final PCY_TaisyoEJBHome home_taisyo = (PCY_TaisyoEJBHome)fact.lookup(PCY_TaisyoEJBHome.class);
            final PCY_TaisyoEJB ejb_taisyo = home_taisyo.create();
            final PCY_SosikiBean[] sosikiBeens = ejb_taisyo.getSosiki(loginuser);

            // �\����
            PCY_KensyuKanriJohoBean[] taisyosyaBeans = null;
            final PCY_MousikomiJyokyoEJBHome mousikomihome =
                    (PCY_MousikomiJyokyoEJBHome)fact.lookup(PCY_MousikomiJyokyoEJBHome.class);
            final PCY_MousikomiJyokyoEJB mousikomiejb = mousikomihome.create();
            taisyosyaBeans = mousikomiejb.getListWithClass(
                    classBean.getKamokuBean().getKamokuCode(),
                    classBean.getClassCode(), null, loginuser);

            // �\�[�g
            final List<PCY_KensyuKanriJohoBean> taisyosyaList = new ArrayList<PCY_KensyuKanriJohoBean>();
            for (int i = 0; i < taisyosyaBeans.length; i++) {
                taisyosyaList.add(taisyosyaBeans[i]);
            }
            PCY_KensyuKanriJohoBean[] SorttaisyosyaBeans = new PCY_KensyuKanriJohoBean[taisyosyaList.size()];
            SorttaisyosyaBeans = (PCY_KensyuKanriJohoBean[])taisyosyaList.toArray(SorttaisyosyaBeans);

            /* �\�[�g���� */
            Arrays.sort(SorttaisyosyaBeans, new TestKekkaComparator());

            //final PCY_PzValueEJBHome pzvaluehome = (PCY_PzValueEJBHome)fact.lookup(PCY_PzValueEJBHome.class);
            //final PCY_PzValueEJB pzvalueejb = pzvaluehome.create();
            //final PCY_SyoninsyaEJBHome syoninsya_home = (PCY_SyoninsyaEJBHome)fact.lookup(PCY_SyoninsyaEJBHome.class);
            //final PCY_SyoninsyaEJB syoninsya_ejb = syoninsya_home.create();

            // ���O�ۑ�Ɋւ�������擾
            //SorttaisyosyaBeans = mousikomiejb.addJizenkadaiJyokyoList(SorttaisyosyaBeans, loginuser);

            // �e���v���[�g�t�@�C���̎擾
            final String templateFile = (String)ReadFile.fileMapData.get(HcdbDef.DOWNLOAD_TEMPLATE_PATH) +
                    "/" + request.getParameter("download_templete") + DOWNLOAD_FILENAME_EXTENSION;

            // �e�X�g���ʈꗗ�t�@�C���̍쐬
            FileInputStream in = null;
            Workbook wb = null;
            // ���݂̓��t�Ǝ���
            final String dateTime = PZZ010_CharacterUtil.getDayTime();
            String downloadFileName = URLEncoder.encode(
                    dateTime + "_" + DOWNLOAD_FILENAME + DOWNLOAD_FILENAME_EXTENSION ,"UTF-8");

            // �e���v���[�g�t�@�C�����J��
            try {
                in = new FileInputStream(templateFile);
                wb = WorkbookFactory.create(in);
            } finally {
                in.close();
            }

            int sheetIndex = 0;
            int personNum = PERSON_NUM_INI_VAL;
            int detailRow = MEIBO_START_ROW_INDEX;

            Sheet sheet = null;
            String tmpSosikiCode = null;

// ADD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 START
            // ����͈͂��擾
            String printArea = wb.getPrintArea(wb.getSheetIndex(String.valueOf(TEMPLATE_SHEET_INDEX)));
            if (printArea != null) {
                int sheetPosition = printArea.indexOf("!");
                if (sheetPosition != -1) {
                    printArea = printArea.substring(sheetPosition + 1);
                } else {
                    printArea = null;
                }
            }
// ADD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 END
            sheet = wb.getSheetAt(sheetIndex);
            // �w�b�_�[�̐ݒ�
            setHeader(sheet, classBean); 
            // �f�[�^�쐬����V�[�g�̑I��
            wb.setActiveSheet(sheetIndex);

            // �Ώۃf�[�^���J��Ԃ�
            for (int i = 0; i < SorttaisyosyaBeans.length; i++) {

                // �_�E�����[�h�ΏۃX�e�[�^�X (��u�ҁA�񍐑ҁA����ҁA���C���A�C��)
                // ��u��(�\���󋵃X�e�[�^�X1:��t���2)
                if (SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null
                        && SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("1")
                        && SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() != null
                        && SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai().equals("2")
                        || SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null
                        && SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("2")
                        && SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() == null
                        || SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null
                        && SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("3")
                        && SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() == null
                        || SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei() != null
                        && SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei().equals("0")
                        || SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei() != null
                        && SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei().equals("1")) {

                    /* �l���擾 */
                    String busyoRyakusyo = "";
                    String sosikiCode = "";
                    for (int j = 0; j < sosikiBeens.length; j++) {
                        if (sosikiBeens[j].getSosikiCode() != null
                                && SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSosikiCode() != null) {
                            if (sosikiBeens[j].getSosikiCode().trim().equals(
                                    SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSosikiCode().trim())) {
                                busyoRyakusyo = sosikiBeens[j].getBusyoRyakusyoMei();
                                sosikiCode = SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSosikiCode();
                                break;
                            }
                        }
                    }
                    // �\���Ώێ҂̌��E�ސE�t���O��2(�ސE)�ł���Ε\�����Ȃ�
                    final String gensyokuTaisyoku =
                            SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getGensyokuTaisyokuFlg();
                    if (gensyokuTaisyoku == null
                            || gensyokuTaisyoku.equals("2")) {
                        continue;
                    }

                    // T01_�l�����l���擾
                    //PCY_PzValueBean pzValue = pzvalueejb.getPersonalPzValue(
                    //        SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSimeiNo(), loginuser);
                    //if (pzValue == null) {
                    //    pzValue = new PCY_PzValueBean();
                    //}

                    // L16_���F�҃}�X�^.����NO=��u�҂ƂȂ�L16_���F�҃}�X�^.���F�҂P�ɕR�t���f�[�^���擾
                    //PCY_PersonalBean syoninsyaPersonalBean = syoninsya_ejb.getSyoninsyaParsonal(
                    //        SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSimeiNo(),
                    //        false, loginuser);
                    //PCY_PzValueBean syoninsyaPzValue = null;
                    //if (syoninsyaPersonalBean == null) {
                    //    syoninsyaPersonalBean = new PCY_PersonalBean();
                    //} else {
                    //    syoninsyaPzValue = pzvalueejb.getPersonalPzValue(
                    //            syoninsyaPersonalBean.getSimeiNo(), loginuser);
                    //}
                    //if (syoninsyaPzValue == null) {
                    //    syoninsyaPzValue = new PCY_PzValueBean();
                    //}

                    // ���O�ۑ���擾
                    //PCY_JizenkadaiJyokyoBean jizenkadaiJyokyoBean =
                    //        SorttaisyosyaBeans[i].getJizenkadaiJyokyoBean();
                    //PCY_JizenkadaiBean jizenkadaiBean = null;
                    //if (jizenkadaiJyokyoBean != null) {
                    //    jizenkadaiBean =
                    //            jizenkadaiJyokyoBean.getJizenkadaiBean();
                    //} else {
                    //    jizenkadaiJyokyoBean = new PCY_JizenkadaiJyokyoBean();
                    //}
                    //if (jizenkadaiBean == null) {
                    //    jizenkadaiBean = new PCY_JizenkadaiBean();
                    //}

                    if (!sosikiCode.equals(tmpSosikiCode)) {
                        if (sheet != null) {
                            // ����{���Ɨp���̐ݒ�
                            sheet.getPrintSetup().setPaperSize(PrintSetup.A4_PAPERSIZE);
                            sheet.getPrintSetup().setScale(PAGE_PRINT_SCALE_PERCENT);
                        }

                        sheetIndex++;
                        tmpSosikiCode = sosikiCode;
                        detailRow = MEIBO_START_ROW_INDEX;
                        personNum = PERSON_NUM_INI_VAL;
                        // �V�[�g�R�s�[ ����� �V�[�g���ݒ�
                        wb.cloneSheet(TEMPLATE_SHEET_INDEX);
                        String tmpBusyoRyakusyo = busyoRyakusyo;
                        if (tmpBusyoRyakusyo.length() > 31)
                            tmpBusyoRyakusyo = tmpBusyoRyakusyo.substring(0, 32);
                        wb.setSheetName(sheetIndex, tmpBusyoRyakusyo);
                        sheet = wb.getSheetAt(sheetIndex);
// ADD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 START
                        // �擾��������͈͂��V�[�g�R�s�[���č쐬�������[�N�V�[�g�̈���͈͂Ƃ��Đݒ�
                        if (printArea != null) {
                             wb.setPrintArea(sheetIndex, printArea);
                        }
// ADD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 END

                        // �w�b�_�[�̐ݒ�
                        //setHeader(sheet, classBean); 
                        // �f�[�^�쐬����V�[�g�̑I��
                        wb.setActiveSheet(sheetIndex);
                    }

                    // �s�`�F�b�N
                    boolean rowFlag = chickRow(sheet, detailRow);

                    // ���Ԃ̐ݒ�
                    setCell(sheet, detailRow, NO_COL_INDEX,
                            Integer.toString(personNum), rowFlag, true);

                    // �A���������̂̐ݒ�
                    setCell(sheet, detailRow, BUSYOMEI_COL_INDEX,
// MOD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 START
//                            busyoRyakusyo, rowFlag, true);
                            busyoRyakusyo, rowFlag, false);
// MOD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 END
                    
                    // �����i�����j�̐ݒ�
                    setCell(sheet, detailRow, SHIMEI_COL_INDEX,
// MOD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 START
//                            SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getKanjiSimei(), rowFlag, true);
                            SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getKanjiSimei(), rowFlag, false);
// MOD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 END
                    
                    // �o�͑Ώێ҂̓_���̐ݒ�
                    String tensu = "";
                    if (SorttaisyosyaBeans[i].getKensyurirekiBean().getSyussekiNissuu() == null) {
                        if (SorttaisyosyaBeans[i].getKensyurirekiBean().getTensu() != null) {
                            tensu = String.valueOf(SorttaisyosyaBeans[i].getKensyurirekiBean().getTensu());
                        }
                    } else {
                        tensu = String.valueOf(SorttaisyosyaBeans[i].getKensyurirekiBean().getSyussekiNissuu().intValue());
                    }
// MOD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 START
//                    setCell(sheet, detailRow, TENSU_COL_INDEX, tensu, rowFlag, true);
                    setCell(sheet, detailRow, TENSU_COL_INDEX, tensu, rowFlag, false);
// MOD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 END
                    
                    // �l�̐ݒ�
                    detailRow ++;
                    personNum++;

                }
            }

            if (sheet != null) {
                // ����{���Ɨp���̐ݒ�
                sheet.getPrintSetup().setPaperSize(PrintSetup.A4_PAPERSIZE);
                sheet.getPrintSetup().setScale(PAGE_PRINT_SCALE_PERCENT);
            }

            // �e���v���[�g�V�[�g�̍폜
            if (sheetIndex != 0) {
                wb.removeSheetAt(TEMPLATE_SHEET_INDEX);
            }

            // �V�[�g��1�V�[�g�ȏ�̏ꍇ
            if (sheetIndex > 1) {
                wb.setActiveSheet(0);
            }

            // �t�@�C���̃o�C�g�o��
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            wb.write(outputStream);
            outputStream.close();
            final ByteArrayInputStream bais =
                    new ByteArrayInputStream(outputStream.toByteArray());

            /* ���샍�O�o�� */
            final String login_no = userinfo.getLogin_no();
            final String simei_no = userinfo.getSimei_no();
            OutLogBean.sousaKojinJohoLog("LNG004", login_no, simei_no,
                    ("�ȖڃR�[�h:" + classBean.getKamokuBean().getKamokuCode()
                            + ",�N���X�R�[�h:" + classBean.getClassCode()));

            request.setAttribute("H080_FileName", downloadFileName);
            request.setAttribute("H081_ContentType", CONTENT_TYPE);
            request.setAttribute("STREAM", bais);

            Log.performance(loginuser.getSimeiNo(), false, "");
            Log.method(loginuser.getSimeiNo(), "OUT", "");

            return this.getForwardPath();

        } catch (final NamingException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final CreateException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final RemoteException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final IOException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final DocumentException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final Exception e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        }
    }

    /**
     * �w�b�_�[�쐬
     * @param sheet EXCLE�V�[�g
     * @param classBean �N���X���
     * @param kamokuBean �Ȗڏ��
     */
    void setHeader(Sheet sheet, PCY_ClassBean classBean) {
        
        PCY_KamokuBeanForDL kamokuBean = new PCY_KamokuBeanForDL(classBean.getKamokuBean());
        // Course Name (�o�͑Ώی��C�̉Ȗږ�)
        setCell(sheet, KAMOKUMEI_START_ROW_INDEX, KAMOKUMEI_COL_INDEX, kamokuBean.getKamokuMei1(),
                chickRow(sheet, KAMOKUMEI_START_ROW_INDEX), true);

        // Course Trainer(�o�͑Ώی��C�̍u�t)
        setCell(sheet, KOUSIMEI_START_ROW_INDEX, KOUSIMEI_COL_INDEX, classBean.getKousiMei(),
                chickRow(sheet, KOUSIMEI_START_ROW_INDEX), true);

        // Course Date(�o�͑Ώی��C�̊J�Ó�)
        String kaisaibi = null;
        if ( ( classBean.getMousikomiKaisibi()  == null || classBean.getMousikomiKaisibi().equals( "" )  )
                && ( classBean.getMousikomiSyuryobi() == null || classBean.getMousikomiSyuryobi().equals( "" ) ) ) {
            kaisaibi = "";
        } else {
// MOD 2018/12/03 COMTURE �C�����A�e�X�g���ʈꗗ�̓��t�t�H�[�}�b�g�ύX�Ή� START
//            kaisaibi = PZZ060_DateConvertUtil.convertToTsukiRyakusho(classBean.getKaisibi()) +
//                    " - " + PZZ060_DateConvertUtil.convertToTsukiRyakusho(classBean.getSyuryobi());
            kaisaibi = PZZ060_DateConvertUtil.convertToTsukiMeiFull(classBean.getKaisibi()) +
                    " - " + PZZ060_DateConvertUtil.convertToTsukiMeiFull(classBean.getSyuryobi());
// MOD 2018/12/03 COMTURE �C�����A�e�X�g���ʈꗗ�̓��t�t�H�[�}�b�g�ύX�Ή� END
        }
        setCell(sheet,
                KAISAIBI_START_ROW_INDEX, KAISAIBI_COL_INDEX, kaisaibi, 
                chickRow(sheet, KAISAIBI_START_ROW_INDEX), true);

        // Course Time (�o�͑Ώی��C�̊J�Î���)
        String kaisaijikoku = null;
        if ( ( classBean.getKaisijikoku()  == null || classBean.getKaisijikoku().equals( "" )  )
                && ( classBean.getSyuryojikoku() == null || classBean.getSyuryojikoku().equals( "" ) ) ) {
            kaisaijikoku = "";
        } else {
            kaisaijikoku = PZZ010_CharacterUtil.ChangeHm(classBean.getKaisijikoku()) +
                    " - " + PZZ010_CharacterUtil.ChangeHm(classBean.getSyuryojikoku());
        }
        setCell(sheet,
                KAISAIJIKOKU_START_ROW_INDEX, KAISAIJIKOKU_COL_INDEX, kaisaijikoku, 
                chickRow(sheet, KAISAIJIKOKU_START_ROW_INDEX), true);
        
        // Course Venue(�o�͑Ώی��C�̒n��)
        String chikumei = classBean.getChikuMei();
        // �n�於��ݒ肷��B �n�於�������A�n��R�[�h������Βn��R�[�h����n�於���擾����
        if ((chikumei == null || chikumei.equals("")) && classBean.getChikuCode() != null && !classBean.getChikuCode().equals("")) {
            chikumei = PCY_CodeBean.getInstance().getValue(PCY_CodeBean.CHIKU, classBean.getChikuCode());
        }
        setCell(sheet, CHIKUMEI_START_ROW_INDEX, CHIKUMEI_COL_INDEX, chikumei,
                chickRow(sheet, CHIKUMEI_START_ROW_INDEX), true);

        // Course Fee(�o�͑Ώی��C�̃N���X�P��)
        setCell(sheet, TANKA_START_ROW_INDEX, TANKA_COL_INDEX, String.valueOf(classBean.getTanka()),
                chickRow(sheet, TANKA_START_ROW_INDEX), true);
    }

    /**
     * �s�`�F�b�N
     * @param sheet EXCLE�V�[�g
     * @param rowNum �s�ԍ�
     * @return �e���v���[�g����true�A����ȊO�̏ꍇ�� false
     * @exception LYSGException �A�v���P�[�V������O�̔���
     */
    boolean chickRow(Sheet sheet, int rowNum) {
        // �e���v���[�g�s�ݒ���̎擾
        Row row = sheet.getRow(rowNum);

        // �e���v���[�g���\���̏ꍇ
        if (row != null) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * �Z���ݒ�
     * @param sheet EXCLE�V�[�g
     * @param rowNum �s�ԍ�
     * @param colNum ��ԍ�
     * @param cellVal �Z���ݒ�l
     * @param rowFlag �s�t���O
     * @param iniFlag ����t���O
     * @exception LYSGException �A�v���P�[�V������O�̔���
     */
    void setCell(Sheet sheet, int rowNum, int colNum, String cellVal,
            boolean rowFlag, boolean iniFlag) {
        // �e���v���[�g���\���̏ꍇ
        if (rowFlag) {
            Row row = sheet.getRow(rowNum);
            Cell cell = row.getCell(colNum);
// ADD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 START
            if (cell == null) cell = row.createCell(colNum);
// ADD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 END
            cell.setCellValue(cellVal);
            // ����łȂ��̏ꍇ
        } else if (!iniFlag) {
            Row row = sheet.getRow(rowNum);
// ADD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 START
            if (row == null) row = sheet.createRow(rowNum);
// ADD 2018/02/23 COMTURE phase5-LN-OVS-Ph2-1_CT_001 END
            Cell cell = row.createCell(colNum);
            cell.setCellValue(cellVal);
        } else {
            Row row = sheet.createRow(rowNum);
            Cell cell = row.createCell(colNum);
            cell.setCellValue(cellVal);
        }
    }

    /**
     * �g�D�R�[�h�A�����i�����j���L�[�Ƀ\�[�g���܂��B
     */
    private class TestKekkaComparator implements
            Comparator<PCY_KensyuKanriJohoBean> {

        public int compare(final PCY_KensyuKanriJohoBean taisyou1,
                final PCY_KensyuKanriJohoBean taisyou2) {

            int ret = 0;

            /* ��P�\�[�g�L�[ �g�D�R�[�h */
            if (taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode() != null
                    && taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode() != null) {
                ret = taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode().compareTo(
                        taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode());
            } else if (taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode() == null
                    && taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode() != null) {
                return 1;
            } else if (taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode() != null
                    && taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode() == null) {
                return -1;
            }

            if (ret != 0) {
                return ret;
            }

            /* ��Q�\�[�g�L�[ �����i�����j */
            if (taisyou1.getMousikomiBean().getPersonalBean().getKanjiSimei() != null
                    && taisyou2.getMousikomiBean().getPersonalBean().getKanjiSimei() != null) {
                ret = taisyou1.getMousikomiBean().getPersonalBean().getKanjiSimei().compareTo(
                        taisyou2.getMousikomiBean().getPersonalBean().getKanjiSimei());
            } else if (taisyou1.getMousikomiBean().getPersonalBean().getKanjiSimei() == null
                    && taisyou2.getMousikomiBean().getPersonalBean().getKanjiSimei() != null) {
                return 1;
            } else if (taisyou1.getMousikomiBean().getPersonalBean().getKanjiSimei() != null
                    && taisyou2.getMousikomiBean().getPersonalBean().getKanjiSimei() == null) {
                return -1;
            }

            if (ret != 0) {
                return ret;
            }

            return ret;
        }
    }



}
