/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJB;
import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJBHome;
import jp.co.hisas.career.base.upload.bean.PYF010_FileUploadBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_JizenkadaiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_JizenkadaiEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_CancelKikanBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_HizukeKubunBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_JizenkadaiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KyosituBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ReportSubmitKikanBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F PCY117_ClassKakuninServlet �N���X �@�\�����F �N���X�m�F��ʑJ�ڎ��̃f�[�^�ێ����s���܂��B
 * 
 * </PRE>
 */
public class PCY117_ClassKakuninServlet extends PCY010_ControllerServlet {

	/**
	 * ���N�G�X�g����N���X���e���擾���A�N���X�����쐬���܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean )
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException, Exception {
	    
        /* ���\�b�h�g���[�X�o�� */
        Log.method(loginuser.getSimeiNo(), "IN", "");
        
        // session �擾
        final HttpSession session = request.getSession(false);
        
	    /* ���N�G�X�g����t�@�C���y�сA���̑��̃t�B�[���h���擾 */
	    final PYF010_FileUploadBean fileUploadBean = new PYF010_FileUploadBean(loginuser.getSimeiNo(), request);
	    session.setAttribute("SucceedClassCode", (String)fileUploadBean.getnewParameter( "SucceedClassCode" ));
	    session.setAttribute("SucceedClassMei", (String)fileUploadBean.getnewParameter( "SucceedClassMei" ));
	    session.setAttribute("taisyoSetteiFlg", (String)fileUploadBean.getnewParameter( "taisyoSetteiFlg" ));

	    // �Ȗڏ��擾
	    PCY_KamokuBean kamokuBean = new PCY_KamokuBean(request);
	    kamokuBean.setKamokuCode((String)fileUploadBean.getnewParameter("kamoku_code"));
        kamokuBean.setKamokuMei1((String)fileUploadBean.getnewParameter("kamoku_mei1"));
        kamokuBean.setKamokuMei2((String)fileUploadBean.getnewParameter("kamoku_mei2"));
        
	    // �N���X���擾
        PCY_ClassBean classBean = new PCY_ClassBean(request);
        classBean.setKamokuBean(kamokuBean);
        classBean.setClassCode((String)fileUploadBean.getnewParameter("class_code"));
        classBean.setClassMei((String)fileUploadBean.getnewParameter("class_mei"));
        classBean.setKaisibi((String)fileUploadBean.getnewParameter("kaisibi"));
        classBean.setSyuryobi((String)fileUploadBean.getnewParameter("syuryobi"));
        // ADD 2018/01/09 COMTURE �����t�Ή� START
        classBean.getHizukeKubunBean().setHizukeKubun(
                (String)fileUploadBean.getnewParameter("hizuke_kubun"));
        // ADD 2018/01/09 COMTURE �����t�Ή� END
        classBean.setKaisaijikan((String)fileUploadBean.getnewParameter("kaisaijikan"));
        classBean.setKaisijikoku((String)fileUploadBean.getnewParameter("kaisijikoku"));
        classBean.setSyuryojikoku((String)fileUploadBean.getnewParameter("syuryojikoku"));
        classBean.setMousikomiKaisibi((String)fileUploadBean.getnewParameter("mousikomi_kaisibi"));
        classBean.setMousikomiSyuryobi((String)fileUploadBean.getnewParameter("mousikomi_syuryobi"));
        classBean.setJyukouKigen((String)fileUploadBean.getnewParameter("jyukou_kigen"));
        classBean.setChikuCode((String)fileUploadBean.getnewParameter("chiku_code"));
        classBean.setChikuMei((String)fileUploadBean.getnewParameter("chiku_mei"));
        classBean.setKyosituCode((String)fileUploadBean.getnewParameter("kyositu_code"));
        classBean.setKyosituMei((String)fileUploadBean.getnewParameter("kyositu_mei"));
        classBean.setKousiCode((String)fileUploadBean.getnewParameter("kousi_code"));
        classBean.setKousiMei((String)fileUploadBean.getnewParameter("kousi_mei"));
        try {
            classBean.setTeiin(Integer.valueOf((String)fileUploadBean.getnewParameter("teiin")));
        } catch (final NumberFormatException e) {
            Log.debug(e.getMessage());
        }
        
        try {
            classBean.setKaisaiSaisyoNinzuu(Integer.valueOf((String)fileUploadBean.getnewParameter("kaisai_saisyo_ninzuu")));
        } catch (final NumberFormatException e) {
            Log.debug(e.getMessage());
        }
        
        classBean.setMousikomiKubun((String)fileUploadBean.getnewParameter("mousikomi_kubun"));
        classBean.setSyoninKubun((String)fileUploadBean.getnewParameter("syonin_kubun"));
        classBean.setUketukeKubun((String)fileUploadBean.getnewParameter("uketuke_kubun"));
        classBean.setHoukokuKubun((String)fileUploadBean.getnewParameter("houkoku_kubun"));
        classBean.setNinsyoKubun((String)fileUploadBean.getnewParameter("ninsyo_kubun"));
        classBean.setHanteiKubun((String)fileUploadBean.getnewParameter("hantei_kubun"));
        classBean.setKaisaiJyotai((String)fileUploadBean.getnewParameter("kaisai_jyotai"));
        classBean.setAnnaiMailKubun((String)fileUploadBean.getnewParameter("annai_mail_kubun"));
        classBean.setFollowMailKubun((String)fileUploadBean.getnewParameter("follow_mail_kubun"));
        classBean.setFollowMailNissuu1((String)fileUploadBean.getnewParameter("follow_mail_nissuu1"));
        classBean.setFollowMailNissuu2((String)fileUploadBean.getnewParameter("follow_mail_nissuu2"));
        classBean.setBikou((String)fileUploadBean.getnewParameter("bikou"));
        classBean.setSakujyoflg((String)fileUploadBean.getnewParameter("sakujyo_flg"));
        classBean.setZensyaTaisyoFlg((String)fileUploadBean.getnewParameter("zensya_taisyo_flg"));
        classBean.setKisyoIkkatsuFlg((String)fileUploadBean.getnewParameter("kisyo_ikkatsu_flg"));
        classBean.setMousikomiJyokyo((String)fileUploadBean.getnewParameter("mousikomi_jyokyo"));
        classBean.setJyukoJyokyo((String)fileUploadBean.getnewParameter("jukou_jyokyo"));
        classBean.setSort((String)fileUploadBean.getnewParameter("sort"));
        if ((String)fileUploadBean.getnewParameter("nissuu") != null) {
            try {
                classBean.setNissuu(Float.valueOf((String)fileUploadBean.getnewParameter("nissuu")));
            } catch (final NumberFormatException e) {
                Log.debug(e.getMessage());
            }
        }
        
        try {
            classBean.setYoyaku(Integer.valueOf((String)fileUploadBean.getnewParameter("yoyaku")));
        } catch (final NumberFormatException e) {
            Log.debug(e.getMessage());
        }
        
        classBean.setMansekiFlg((String)fileUploadBean.getnewParameter("manseki_flg"));
        
        try {
            classBean.setTanka(Integer.valueOf((String)fileUploadBean.getnewParameter("tanka")));
        } catch (final NumberFormatException e) {
            Log.debug(e.getMessage());
        }
        
        classBean.setTourokubi((String)fileUploadBean.getnewParameter("tourokubi"));
        classBean.setTourokujikoku((String)fileUploadBean.getnewParameter("tourokujikoku"));
        classBean.setTourokusya((String)fileUploadBean.getnewParameter("tourokusya"));
        classBean.setKousinbi((String)fileUploadBean.getnewParameter("kousinbi"));
        classBean.setKousinjikoku((String)fileUploadBean.getnewParameter("kousinjikoku"));
        classBean.setKousinsya((String)fileUploadBean.getnewParameter("kousinsya"));
        
        
        classBean.setKyosituBean(new PCY_KyosituBean(request));
        
        request.setAttribute("classBean", classBean);
        session.setAttribute("classBean", classBean);
        
        // ��ʁQ���O�ۑ�t�@�C�����擾
        PCY_JizenkadaiBean gamen_jznkdiBean = new PCY_JizenkadaiBean(request);
        gamen_jznkdiBean.setKamokuCode((String)fileUploadBean.getnewParameter("kamoku_code"));
        gamen_jznkdiBean.setClassCode((String)fileUploadBean.getnewParameter("class_code"));
        gamen_jznkdiBean.setJizenkadaiKubun((String)fileUploadBean.getnewParameter("jizenkadai_kubun"));
        String deleteflg = (String)fileUploadBean.getnewParameter("H025_jizenkadai_delete_file");
        String jizenkadaitorokufile = (String)fileUploadBean.getnewParameter("H026_jizenkadai_Torokufile");
        byte[] jizenkadaihinagata = new byte[0];
        final long fileSize = Long.parseLong((String) ReadFile.fileMapData.get("JIZENKADAI_SIZE"));
        
        if ((jizenkadaitorokufile != null && !jizenkadaitorokufile.equals("")) && !deleteflg.equals("1") ) {
            // �o�^�ςݎ��O�ۑ�}�X�^�f�[�^���擾
            final PCY_JizenkadaiEJBHome jizenkadaihome = (PCY_JizenkadaiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_JizenkadaiEJBHome.class);
            final PCY_JizenkadaiEJB jizenkadaiejb = jizenkadaihome.create();
            PCY_JizenkadaiBean jznkdiBean = jizenkadaiejb.doSelectByPrimaryKey(gamen_jznkdiBean, loginuser);
            
            // ���O�ۑ�敪���u�v�v�̏ꍇ
            if (gamen_jznkdiBean.getJizenkadaiKubun() != null && gamen_jznkdiBean.getJizenkadaiKubun().equals("1")) {
                
                // �t�@�C�������擾
                gamen_jznkdiBean.setJizenkadaiFilename(jznkdiBean.getJizenkadaiFilename());
                // �R���e���g�^�C�v���擾
                gamen_jznkdiBean.setJizenkadaiContentType(jznkdiBean.getJizenkadaiContentType());
                // �t�@�C�����擾
                // �L�[
                final String[] primaryKey = { "KAMOKU_CODE", "CLASS_CODE" };
                // �L�[�l
                final String[] keyValue = { gamen_jznkdiBean.getKamokuCode(), gamen_jznkdiBean.getClassCode() };
                final EJBHomeFactory fact = EJBHomeFactory.getInstance();
                final PYF_BlobDBAccessEJBHome blobHome = (PYF_BlobDBAccessEJBHome)fact.lookup(PYF_BlobDBAccessEJBHome.class);
                final PYF_BlobDBAccessEJB blobSession = blobHome.create();
                jizenkadaihinagata =
                        blobSession.SelectBLOB(loginuser.getSimeiNo(), HcdbDef.L02_JIZENKADAI_TBL, "JIZENKADAI_HINAGATA",
                                primaryKey, keyValue);
                
                /* �t�@�C���T�C�Y�O�o�C�g�`�F�b�N */
                if (jizenkadaihinagata.length == 0) {
                    request.setAttribute("warningID", "WCC275");
                    throw new PCY_WarningException("WCC275");
                }
                
                /* �ő�t�@�C���T�C�Y�`�F�b�N */
                if (jizenkadaihinagata.length > fileSize) {
                    request.setAttribute("warningID", "WCC278");
                    throw new PCY_WarningException("WCC278");
                }
                // ���O�ۑ�t�@�C�����`���擾
                gamen_jznkdiBean.setJizenkadaiHinagata(jizenkadaihinagata);
            } else {
                // �t�@�C�����擾
                jznkdiBean.setJizenkadaiFilename("");
                // �R���e���g�^�C�v�擾
                jznkdiBean.setJizenkadaiContentType("");
                // ���O�ۑ�t�@�C�����`���擾
                jznkdiBean.setJizenkadaiHinagata(jizenkadaihinagata);
            }
        } else {
            // ���O�ۑ�敪���u�v�v�̏ꍇ
            if (gamen_jznkdiBean.getJizenkadaiKubun() != null && gamen_jznkdiBean.getJizenkadaiKubun().equals("1")) {
                
                // �t�@�C�������擾
                gamen_jznkdiBean.setJizenkadaiFilename(fileUploadBean.getFile_name("F024_jizenkadai_file"));
                
                if (gamen_jznkdiBean.getJizenkadaiFilename() != null && !gamen_jznkdiBean.getJizenkadaiFilename().equals("")) {
                    
                    // �R���e���g�^�C�v���擾
                    gamen_jznkdiBean.setJizenkadaiContentType(fileUploadBean.getFile_contentType("F024_jizenkadai_file"));
                    
                    // �t�@�C�����擾
                    jizenkadaihinagata = (byte[]) fileUploadBean.getParameter("F024_jizenkadai_file");
                    
                    /* �t�@�C���T�C�Y�O�o�C�g�`�F�b�N */
                    if (jizenkadaihinagata.length == 0) {
                        request.setAttribute("warningID", "WCC275");
                        throw new PCY_WarningException("WCC275");
                    }
                    
                    /* �ő�t�@�C���T�C�Y�`�F�b�N */
                    if (jizenkadaihinagata.length > fileSize) {
                        request.setAttribute("warningID", "WCC278");
                        throw new PCY_WarningException("WCC278");
                    }
                    
                    // ���O�ۑ�t�@�C�����`���擾
                    gamen_jznkdiBean.setJizenkadaiHinagata(jizenkadaihinagata);
                } else {
                    // �t�@�C�����擾
                    gamen_jznkdiBean.setJizenkadaiFilename("");
                    // �R���e���g�^�C�v�擾
                    gamen_jznkdiBean.setJizenkadaiContentType("");
                    // ���O�ۑ�t�@�C�����`���擾
                    gamen_jznkdiBean.setJizenkadaiHinagata(jizenkadaihinagata);
                }
            } else {
                // �t�@�C�����擾
                gamen_jznkdiBean.setJizenkadaiFilename("");
                // �R���e���g�^�C�v�擾
                gamen_jznkdiBean.setJizenkadaiContentType("");
                // ���O�ۑ�t�@�C�����`���擾
                gamen_jznkdiBean.setJizenkadaiHinagata(jizenkadaihinagata);
            }
        }
        session.setAttribute("jizenkadaiBean", gamen_jznkdiBean);
        
// ADD 2017/10/20 HISOL �\��������Ԓǉ��Ή� START
		PCY_CancelKikanBean cancelKikanBean = new PCY_CancelKikanBean(request);
		cancelKikanBean.setKamokuCode((String)fileUploadBean.getnewParameter("kamoku_code"));
		cancelKikanBean.setClassCode((String)fileUploadBean.getnewParameter("class_code"));
		cancelKikanBean.setTorikesiKaisibi((String)fileUploadBean.getnewParameter("torikesi_kaisibi"));
		cancelKikanBean.setTorikesiSyuryobi((String)fileUploadBean.getnewParameter("torikesi_syuryobi"));
		
		session.setAttribute("cancelKikanBean", cancelKikanBean);
// ADD 2017/10/20 HISOL �\��������Ԓǉ��Ή� END
// ADD 2018/12/03 COMTURE ���|�[�g��o���Ԓǉ��Ή� START
		PCY_ReportSubmitKikanBean reportSubmitKikanBean = new PCY_ReportSubmitKikanBean(request);
		reportSubmitKikanBean.setKamokuCode((String)fileUploadBean.getnewParameter("kamoku_code"));
		reportSubmitKikanBean.setClassCode((String)fileUploadBean.getnewParameter("class_code"));
		reportSubmitKikanBean.setKaisibi((String)fileUploadBean.getnewParameter("report_kaisibi"));
		reportSubmitKikanBean.setSyuryobi((String)fileUploadBean.getnewParameter("report_syuryobi"));
// ADD 2018/12/05 COMTURE ���|�[�g��o�����[���ǉ� START
		reportSubmitKikanBean.setFollowMailNissuu((String)fileUploadBean.getnewParameter("report_follow_mail"));
// ADD 2018/12/05 COMTURE ���|�[�g��o�����[���ǉ� END
		
		session.setAttribute("reportSubmitKikanBean", reportSubmitKikanBean);
// ADD 2018/12/03 COMTURE ���|�[�g��o���Ԓǉ��Ή� END

        /* ���\�b�h�g���[�X�o�� */
        Log.method(loginuser.getSimeiNo(), "OUT", "");

        return this.getForwardPath();
	}
}
