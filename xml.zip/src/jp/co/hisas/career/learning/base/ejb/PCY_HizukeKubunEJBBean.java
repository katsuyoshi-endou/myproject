package jp.co.hisas.career.learning.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.valuebean.PCY_CancelKikanBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_HizukeKubunBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * �\��������ԃe�[�u���ւ̑�����s���܂��B<br>
 * @ejb.bean name="PCY_HizukeKubunEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_HizukeKubunEJBBean implements SessionBean {

    private SessionContext context = null;

    private static final String INSERT_L2_SQL =
            "INSERT INTO L02_HIZUKE_KUBUN(KAMOKU_CODE, CLASS_CODE, HIZUKE_KUBUN) VALUES(?, ?, ?)";

    private static final String UPDATE_L2_SQL =
            "UPDATE L02_HIZUKE_KUBUN SET HIZUKE_KUBUN = ? WHERE KAMOKU_CODE = ? AND CLASS_CODE = ?";

    /**
     * L02_HIZUKE_KUBUN�e�[�u���Ƀ��R�[�h���쐬����
     * 
     * @param classBean �N���X���
     * @param loginuser       ���O�C�����[�U
     * @throws PCY_WarningException
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public void doInsert(final PCY_ClassBean classBean,
            final PCY_PersonalBean loginuser) throws PCY_WarningException {
        Connection con = null;
        PreparedStatement ps = null;
        int count = 0;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "IN", "");

            // �R�l�N�V�����擾
            con =
                    PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo()
                            : "");

            ps = con.prepareStatement(PCY_HizukeKubunEJBBean.INSERT_L2_SQL);

            // �p�����[�^���Z�b�g
            ps.setString(1, classBean.getKamokuBean().getKamokuCode());
            ps.setString(2, classBean.getClassCode());
            ps.setString(3, classBean.getHizukeKubunBean().getHizukeKubun());

            count = ps.executeUpdate();

            if (count != 1) {
                this.context.setRollbackOnly();
                throw new PCY_WarningException();
            }

            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "OUT", "");

        } catch (final SQLException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } catch (final NamingException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } catch (final RuntimeException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final Exception e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(
                    loginuser != null ? loginuser.getSimeiNo() : "", con, ps,
                    null);
        }
    }

    /**
     * L02_HIZUKE_KUBUN�e�[�u���̉ȖڃR�[�h�A�N���X�R�[�h�̈�v���郌�R�[�h���X�V����
     * 
     * @param classBean �N���X���
     * @param loginuser       ���O�C�����[�U
     * @throws PCY_WarningException
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public void doUpdate(final PCY_ClassBean classBean,
            final PCY_PersonalBean loginuser) throws PCY_WarningException {
        Connection con = null;
        PreparedStatement ps = null;
        int count = 0;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "IN", "");

            // �R�l�N�V�����擾
            con =
                    PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo()
                            : "");

            ps = con.prepareStatement(PCY_HizukeKubunEJBBean.UPDATE_L2_SQL);

            // �p�����[�^���Z�b�g
            ps.setString(1, classBean.getHizukeKubunBean().getHizukeKubun());
            ps.setString(2, classBean.getKamokuBean().getKamokuCode());
            ps.setString(3, classBean.getClassCode());

            count = ps.executeUpdate();

            if (count != 1) {
                this.context.setRollbackOnly();
                throw new PCY_WarningException();
            }

            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "OUT", "");

        } catch (final SQLException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } catch (final NamingException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } catch (final RuntimeException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final Exception e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(
                    loginuser != null ? loginuser.getSimeiNo() : "", con, ps,
                    null);
        }
    }

    /**
     * ���t�敪�e�[�u�������L�[�i�ȖڃR�[�h�A�N���X�R�[�h�j�Ɉ�v������t�敪���擾����B��v���郌�R�[�h�����݂��Ȃ��ꍇ��null��Ԃ��B
     * 
     * @param classBean ��������
     * @param loginuser  ���O�C�����[�U
     * @return ��������
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_HizukeKubunBean doSelectByPrimaryKey(
            final PCY_ClassBean classBean, final PCY_PersonalBean loginuser) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "IN", "");

            PCY_HizukeKubunBean ret = null;

            final StringBuffer sql = new StringBuffer();
            sql.append("SELECT " + PCY_HizukeKubunBean.getColumns("M"));
            sql.append("  FROM ");
            sql.append(HcdbDef.L02_HIZUKE_KUBUN_TBL);
            sql.append(" M");
            sql.append("  WHERE M.KAMOKU_CODE=?");
            sql.append("    AND M.CLASS_CODE=?");

            // �R�l�N�V�����擾
            con =
                    PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo()
                            : "");

            // �������s
            ps = con.prepareStatement(sql.toString());
            ps.setString(1, classBean.getKamokuBean().getKamokuCode());
            ps.setString(2, classBean.getClassCode());

            rs = ps.executeQuery();

            if (rs.next()) {
                ret = new PCY_HizukeKubunBean(rs, "M");
            }

            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "OUT", "");

            return ret;
        } catch (final SQLException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } catch (final NamingException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } catch (final RuntimeException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final Exception e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(
                    loginuser != null ? loginuser.getSimeiNo() : "", con, ps,
                    null);
        }
    }

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext(final SessionContext context)
            throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate() throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove() throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate() throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate() throws EJBException, RemoteException {
    }
}
