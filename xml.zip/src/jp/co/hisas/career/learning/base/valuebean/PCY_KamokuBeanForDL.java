/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/02/16  01.00       ���� ��F    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.valuebean;

import java.io.Serializable;

/**
 * <PRE>
 * 
 * �N���X���F PCY_KamokuBeanForDL �N���X �@�\�����F �_�E�����[�h�@�\�p�ɉȖڏ�����ێ�����ValueBean�ł��B
 * 
 * </PRE>
 */
public class PCY_KamokuBeanForDL implements Serializable {
	private String kamokuCode = null;

	private String kamokuMei1 = null;

	private String kamokuMei2 = null;

	private String kamokuMei3 = null;

	private String kamokuMei4 = null;

	private String kamokuNaiyou = null;

	private String categoryCode1 = null;

	private String categoryCode2 = null;

	private String categoryCode3 = null;

	private String categoryCode4 = null;

	private String categoryCode5 = null;

	private String kamokuGroup = null;

	private String kamokuSyuryoFlg = null;

	private String kanrimotoCode = null;

	private String yobi1 = null;

	private String yobi2 = null;

	private String jyukouJyoken = null;

	public PCY_KamokuBeanForDL(final PCY_KamokuBean kamokuBean) {
		this.kamokuCode = kamokuBean.getKamokuCode();
		this.kamokuMei1 = kamokuBean.getKamokuMei1();
		this.kamokuMei2 = kamokuBean.getKamokuMei2();
		this.kamokuMei3 = kamokuBean.getKamokuMei3();
		this.kamokuMei4 = kamokuBean.getKamokuMei4();
		this.kamokuNaiyou = kamokuBean.getKamokuNaiyou();
		this.categoryCode1 = kamokuBean.getCategoryCode1();
		this.categoryCode2 = kamokuBean.getCategoryCode2();
		this.categoryCode3 = kamokuBean.getCategoryCode3();
		this.categoryCode4 = kamokuBean.getCategoryCode4();
		this.categoryCode5 = kamokuBean.getCategoryCode5();
		this.jyukouJyoken = kamokuBean.getJyukouJyoken();
		this.kamokuGroup = kamokuBean.getKamokuGroup();
		this.kamokuSyuryoFlg = kamokuBean.getKamokuSyuryoFlg();
		this.kanrimotoCode = kamokuBean.getKanrimotoCode();
		this.yobi1 = kamokuBean.getYobi1();
		this.yobi2 = kamokuBean.getYobi2();
		this.jyukouJyoken = kamokuBean.getJyukouJyoken();
	}

	/**
	 * @return
	 */
	public String getJyukouJyoken() {
		return this.jyukouJyoken;
	}

	/**
	 * @param string
	 */
	public void setJyukouJyoken(final String string) {
		this.jyukouJyoken = string;
	}

	/**
	 * @return
	 */
	public String getCategoryCode1() {
		return this.categoryCode1;
	}

	/**
	 * @return
	 */
	public String getCategoryCode2() {
		return this.categoryCode2;
	}

	/**
	 * @return
	 */
	public String getCategoryCode3() {
		return this.categoryCode3;
	}

	/**
	 * @return
	 */
	public String getCategoryCode4() {
		return this.categoryCode4;
	}

	/**
	 * @return
	 */
	public String getCategoryCode5() {
		return this.categoryCode5;
	}

	/**
	 * @return
	 */
	public String getKamokuGroup() {
		return this.kamokuGroup;
	}

	/**
	 * @return
	 */
	public String getKamokuMei1() {
		return this.kamokuMei1;
	}

	/**
	 * @return
	 */
	public String getKamokuMei2() {
		return this.kamokuMei2;
	}

	/**
	 * @return
	 */
	public String getKamokuMei3() {
		return this.kamokuMei3;
	}

	/**
	 * @return
	 */
	public String getKamokuMei4() {
		return this.kamokuMei4;
	}

	/**
	 * @return
	 */
	public String getKamokuNaiyou() {
		return this.kamokuNaiyou;
	}

	/**
	 * @return
	 */
	public String getKamokuCode() {
		return this.kamokuCode;
	}

	/**
	 * @return
	 */
	public String getKamokuSyuryoFlg() {
		return this.kamokuSyuryoFlg;
	}

	/**
	 * @return
	 */
	public String getKanrimotoCode() {
		return this.kanrimotoCode;
	}

	/**
	 * @return
	 */
	public String getYobi1() {
		return this.yobi1;
	}

	/**
	 * @return
	 */
	public String getYobi2() {
		return this.yobi2;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode1(final String string) {
		this.categoryCode1 = string;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode2(final String string) {
		this.categoryCode2 = string;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode3(final String string) {
		this.categoryCode3 = string;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode4(final String string) {
		this.categoryCode4 = string;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode5(final String string) {
		this.categoryCode5 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuCode(final String string) {
		this.kamokuCode = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuGroup(final String string) {
		this.kamokuGroup = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuMei1(final String string) {
		this.kamokuMei1 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuMei2(final String string) {
		this.kamokuMei2 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuMei3(final String string) {
		this.kamokuMei3 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuMei4(final String string) {
		this.kamokuMei4 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuNaiyou(final String string) {
		this.kamokuNaiyou = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuSyuryoFlg(final String string) {
		this.kamokuSyuryoFlg = string;
	}

	/**
	 * @param string
	 */
	public void setKanrimotoCode(final String string) {
		this.kanrimotoCode = string;
	}

	/**
	 * @param string
	 */
	public void setYobi1(final String string) {
		this.yobi1 = string;
	}

	/**
	 * @param string
	 */
	public void setYobi2(final String string) {
		this.yobi2 = string;
	}

}
