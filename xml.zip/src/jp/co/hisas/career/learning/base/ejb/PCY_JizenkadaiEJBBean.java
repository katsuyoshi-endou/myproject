package jp.co.hisas.career.learning.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJB;
import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJBHome;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.valuebean.PCY_JizenkadaiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * ���O�ۑ�}�X�^�ւ̑�����s���܂��B<br>
 * ADD 2017/05/15 COMTURE VCA350_�{�l���C���iver.02-00�j
 * @ejb.bean name="PCY_JizenkadaiEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_JizenkadaiEJBBean implements SessionBean {
    private SessionContext context = null;
    
    /** L02_���O�ۑ�}�X�^�Ƀf�[�^��ǉ�����SQL */
    private static final String INSERT_L02_JIZENKADAI_SQL = "INSERT INTO L02_JIZENKADAI_TBL "
            + "(KAMOKU_CODE,CLASS_CODE,JIZENKADAI_KUBUN,JIZENKADAI_FILENAME,JIZENKADAI_CONTENT_TYPE,JIZENKADAI_HINAGATA) "
            + " VALUES ( ?, ?, ?, ?, ?, ?)";

    /** L02_���O�ۑ�}�X�^�̉ȖڃR�[�h�A�N���X�R�[�h����v����f�[�^���X�V����SQL */
    private static final String UPDATE_L02_JIZENKADAI_SQL = "UPDATE L02_JIZENKADAI_TBL "
            + " SET JIZENKADAI_KUBUN=?, JIZENKADAI_FILENAME=?, JIZENKADAI_CONTENT_TYPE=?, JIZENKADAI_HINAGATA=? "
            + " WHERE KAMOKU_CODE=? AND CLASS_CODE=?";

    /**
     * L02_���O�ۑ�}�X�^���쐬���܂��B
     * @param JizenkadaiBeans       �쐬���e
     * @param loginuser             ���O�C�����[�U
     * @return int                  �쐬����
     * @throws PCY_WarningException �C���T�[�g�� SQLException �����������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     **/
    public void doInsert(final PCY_JizenkadaiBean JizenkadaiBean, final PCY_PersonalBean loginuser) throws PCY_WarningException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        
        try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "IN", "");
            
            // �R�l�N�V�����擾
            con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");
            
            ps = con.prepareStatement(PCY_JizenkadaiEJBBean.INSERT_L02_JIZENKADAI_SQL);
            
            
            /* INSERT�p�����[�^���Z�b�g���� */
            ps.setString(1, JizenkadaiBean.getKamokuCode());
            ps.setString(2, JizenkadaiBean.getClassCode());
            ps.setString(3, JizenkadaiBean.getJizenkadaiKubun());
            ps.setString(4, JizenkadaiBean.getJizenkadaiFilename());
            ps.setString(5, JizenkadaiBean.getJizenkadaiContentType());
            ps.setNull(6, java.sql.Types.BLOB);
            
            // SQL���s
            count += ps.executeUpdate();
            
            if (count != 1) {
                this.context.setRollbackOnly();
                throw new PCY_WarningException();
            }
            
            if (JizenkadaiBean.getJizenkadaiFilename() != null) {
                // ���O�ۑ�t�@�C���̍X�V
                updateFile(JizenkadaiBean, loginuser);
            }
            
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "OUT", "");
            
        } catch (final NamingException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } catch (final SQLException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } catch (final RuntimeException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final Exception e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
        }
    }

    /**
     * �ȖڃR�[�h�A�N���X�R�[�h����v����L02_���O�ۑ�}�X�^�f�[�^���X�V���܂��B
     * @param JizenkadaiBeans   �X�V���e
     * @param loginuser         ���O�C�����[�U
     * @return int              �X�V����
     * @throws PCY_WarningException 
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public void doUpdate(final PCY_JizenkadaiBean JizenkadaiBeans, final PCY_PersonalBean loginuser) throws PCY_WarningException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "IN", "");
            
            // �R�l�N�V�����擾
            con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");
            
            ps = con.prepareStatement(PCY_JizenkadaiEJBBean.UPDATE_L02_JIZENKADAI_SQL);
            
            /* UPDATE�p�����[�^���Z�b�g���� */
            ps.setString(1, JizenkadaiBeans.getJizenkadaiKubun());
            ps.setString(2, JizenkadaiBeans.getJizenkadaiFilename());
            ps.setString(3, JizenkadaiBeans.getJizenkadaiContentType());
            ps.setNull(4, java.sql.Types.BLOB);
            ps.setString(5, JizenkadaiBeans.getKamokuCode());
            ps.setString(6, JizenkadaiBeans.getClassCode());
            
            // SQL���s
            count += ps.executeUpdate();
            
            if (count != 1) {
                this.context.setRollbackOnly();
                throw new PCY_WarningException();
            }
            
            if (JizenkadaiBeans.getJizenkadaiFilename() != null) {
                // ���O�ۑ�t�@�C���̍X�V
                updateFile(JizenkadaiBeans, loginuser);
            }
            
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "OUT", "");
            
        } catch (final NamingException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } catch (final SQLException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } catch (final RuntimeException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;
        } catch (final Exception e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
        }
    }

    /**
     * �N���X�}�X�^���v���C�}���[�L�[�Ō������Č��ʂ�Ԃ��܂��B �������ʂ����������ꍇ�� null ��Ԃ��܂��B
     * @param jizenkadaiBean ��������
     * @param loginuser ���O�C�����[�U
     * @return ��������
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_JizenkadaiBean doSelectByPrimaryKey(final PCY_JizenkadaiBean jizenkadaiBean,
            final PCY_PersonalBean loginuser) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "IN", "");

            PCY_JizenkadaiBean ret = null;
            final StringBuffer sql = new StringBuffer();
            sql.append("SELECT " + PCY_JizenkadaiBean.getColumns("M"));
            sql.append("  FROM ");
            sql.append(HcdbDef.L02_JIZENKADAI_TBL);
            sql.append(" M");
            sql.append("  WHERE M.KAMOKU_CODE=?");
            sql.append("    AND M.CLASS_CODE=?");

            // �R�l�N�V�����擾
            con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

            // �������s
            ps = con.prepareStatement(sql.toString());
            ps.setString(1, jizenkadaiBean.getKamokuCode());
            ps.setString(2, jizenkadaiBean.getClassCode());

            rs = ps.executeQuery();

            if (rs.next()) {
                ret = new PCY_JizenkadaiBean(rs, "M");
            }

            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "OUT", "");

            return ret;

        } catch (final NamingException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } catch (final SQLException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw new EJBException(e);

        } catch (final RuntimeException e) {
            Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
            throw e;

        } finally {
            PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
        }
    }

    /**
     * ���O�ۑ�t�@�C���̍X�V
     * @param jizenkadaiJyokyoBean �X�V���e
     * @param loginuser ���O�C�����[�U
     * @throws Exception ��O
     */
    private void updateFile(final PCY_JizenkadaiBean jizenkadaiBean, final PCY_PersonalBean loginuser)
            throws Exception {

        if (jizenkadaiBean.getJizenkadaiHinagata() == null) {
            return;
        }

        // �J�����Z�b�g
        final String[] columns = { "JIZENKADAI_HINAGATA" };

        // �}���l�Z�b�g
        final String[] values = { "BLOB_DATA" };

        // �L�[
        final String[] primaryKey = { "KAMOKU_CODE", "CLASS_CODE" };

        // �L�[�l
        final String[] keyValue =
                { jizenkadaiBean.getKamokuCode(), jizenkadaiBean.getClassCode()};

        // EJB�擾
        final EJBHomeFactory fact = EJBHomeFactory.getInstance();
        final PYF_BlobDBAccessEJBHome blobHome = (PYF_BlobDBAccessEJBHome)fact.lookup(PYF_BlobDBAccessEJBHome.class);
        final PYF_BlobDBAccessEJB blobEjb = blobHome.create();

        // �o�C�i���f�[�^ (��U�AString�̔z��Ɋi�[����)
        blobEjb.UpdateBLOB(loginuser.getSimeiNo(), HcdbDef.L02_JIZENKADAI_TBL, columns, values,
                jizenkadaiBean.getJizenkadaiHinagata(), primaryKey, keyValue);
    }

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate() throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove() throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate() throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate() throws EJBException, RemoteException {
    }
}
