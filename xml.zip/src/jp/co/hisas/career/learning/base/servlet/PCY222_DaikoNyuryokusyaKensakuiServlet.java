/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_DaikoNyuryokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_DaikoNyuryokuEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_DaikoNyuryokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F PCY222_DaikoNyuryokusyaKensakuiServlet �N���X �@�\�����F ��s���͂ɂĐݒ肳�ꂽ�l�̈ꗗ��\�����܂��B
 * 
 * </PRE>
 */
public class PCY222_DaikoNyuryokusyaKensakuiServlet extends PCY010_ControllerServlet {
	/**
	 * ��s���͂Ƀe�C�ݒ肳�ꂽ�l�̈ꗗ���擾���܂��B
	 * @param request
	 * @param response
	 * @param loginuser
	 * @return
	 * @throws NamingException
	 * @throws CreateException
	 * @throws RemoteException
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, SQLException,
			RemoteException, PCY_WarningException {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final PCY_DaikoNyuryokuBean kensaku_daikoBean = new PCY_DaikoNyuryokuBean(request);

		PCY_ClassBean classBean = new PCY_ClassBean();
		classBean.getKamokuBean().setKamokuCode(kensaku_daikoBean.getKamokuCode());
		classBean.setClassCode(kensaku_daikoBean.getClassCode());

		/* �N���X�����擾���� */
		final PCY_ClassEJBHome class_home = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB class_ejb = class_home.create();
		Log.transaction(loginuser.getSimeiNo(), true, "");
		classBean = class_ejb.doSelectByPrimaryKey(classBean, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		/* ��s���͏������Ăяo�� */
		final PCY_DaikoNyuryokuEJBHome daiko_home = (PCY_DaikoNyuryokuEJBHome) EJBHomeFactory.getInstance().lookup(PCY_DaikoNyuryokuEJBHome.class);
		final PCY_DaikoNyuryokuEJB daiko_ejb = daiko_home.create();
		Log.transaction(loginuser.getSimeiNo(), true, "");

		final PCY_DaikoNyuryokuBean[] daikoBeans = daiko_ejb.doSelect(kensaku_daikoBean, false, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		final String[] simei_no_list = new String[daikoBeans.length];

		for (int i = 0; i < simei_no_list.length; i++) {
			simei_no_list[i] = daikoBeans[i].getSimeiNo();
		}

		/* �p�[�\�i����񏈗����Ăяo�� */
		final PCY_PersonalEJBHome personal_home = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
		final PCY_PersonalEJB personal_ejb = personal_home.create();
		Log.transaction(loginuser.getSimeiNo(), true, "");

		final PCY_PersonalBean[] personalBeans = personal_ejb.getPersonalInfo(simei_no_list, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		if (simei_no_list.length != personalBeans.length) {
			throw new PCY_WarningException("��s���̓e�[�u���Ɋ܂܂��" + (String) ReadFile.paramMapData.get("DZZ002") + "���A�p�[�\�i���e�[�u���ɂ���܂���B");
		}

		request.setAttribute("personalBeans", personalBeans);
		request.setAttribute("classBean", classBean);
		request.setAttribute("daikoBeans", daikoBeans);

		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		
		String strBack;
		strBack = (String) request.getParameter("return_flg");
		if (strBack == null){
			strBack = "";
		}

		
		if (strBack.equals("back")){//��s���͎�����m�F��ʂ���߂��Ă����Ȃ�
			String returnSimei_No = request.getParameter( "return_simei_no" );
			
			request.setAttribute("return_flg2", strBack);
			request.setAttribute("return_simei_no2", returnSimei_No);
		}
	
	
		return this.getForwardPath();
	}
}
