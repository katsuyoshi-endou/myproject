package jp.co.hisas.career.personal.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CsvValueBeanList implements Serializable {

	/**
	 * List
	 */
	private List _downBeanList;

	/**
	 * List�̃C���f�b�N�X
	 */
	private int _index;
	
	/**
	 * �w�b�_�s
	 */
	private CsvValueBean header = null;
	
	/**
	 * �ǉ��w�b�_
	 */
	private CsvValueBeanList additionalHeader = null;
	
	/**
	 * �ǉ�����
	 */
	private CsvValueBean additionalValue = null;

	/**
	 * �����������B
	 */
	public CsvValueBeanList() {
		this._downBeanList = new ArrayList();
		this._index = 0;
	}
	
	/**
	 * ValueBean�����X�g�ɒǉ�����B
	 * @param valueBean
	 */
	public void add(final CsvValueBean valueBean){
		this._downBeanList.add(valueBean);
	}
	
	/**
	 * ���X�g���玟��ValueBean���擾����B
	 * @return
	 */
	public CsvValueBean next(){
		if(this._downBeanList.size() <= this._index){
			return null;
		} else {
			return (CsvValueBean)this._downBeanList.get(this._index++);
		}
	}
	
	/**
	 * �o�^����Ă���List���擾����B
	 * @return List
	 */
	public List getBeanList() {
		return this._downBeanList;
	}

	public CsvValueBean getHeader() {
		return header;
	}

	public void setHeader(CsvValueBean header) {
		this.header = header;
	}

	public CsvValueBeanList getAdditionalHeader() {
		return additionalHeader;
	}

	public void setAdditionalHeader(CsvValueBeanList additionalHeader) {
		this.additionalHeader = additionalHeader;
	}

	public CsvValueBean getAdditionalValue() {
		return additionalValue;
	}

	public void setAdditionalValue(CsvValueBean additionalValue) {
		this.additionalValue = additionalValue;
	}

}
