package jp.co.hisas.career.personal.ronbun.bean;

import jp.co.hisas.career.personal.util.CsvValueBean;

/**
 * �_���E�u����CSV�̏o�͓��e�i�P���R�[�h���j��ێ�����B
 *
 */
public class RonbunCsvValueBean extends CsvValueBean {
	/** ����NO */
	private String shimeiNo = null;

	/** ���� */
	private String shimei = null;

	/** ������ */
	private String busyo = null;

	/** �N�� */
	private String nengetsu = null;

	/** �敪 */
	private String kubun = null;

	/** ���� */
	private String bunrui = null;

	/** ���e�i���́j */
	private String naiyo = null;

	/** �f�� */
	private String keisai = null;

	/** ���l */
	private String biko = null;
	
	/** ����J */
	private String hikokai = null;

	public String getBiko() {
		return biko;
	}

	public void setBiko(String biko) {
		this.biko = biko;
	}

	public String getBunrui() {
		return bunrui;
	}

	public void setBunrui(String bunrui) {
		this.bunrui = bunrui;
	}

	public String getBusyo() {
		return busyo;
	}

	public void setBusyo(String busyo) {
		this.busyo = busyo;
	}

	public String getKeisai() {
		return keisai;
	}

	public void setKeisai(String keisai) {
		this.keisai = keisai;
	}

	public String getKubun() {
		return kubun;
	}

	public void setKubun(String kubun) {
		this.kubun = kubun;
	}

	public String getNaiyo() {
		return naiyo;
	}

	public void setNaiyo(String naiyo) {
		this.naiyo = naiyo;
	}

	public String getNengetsu() {
		return nengetsu;
	}

	public void setNengetsu(String nengetsu) {
		this.nengetsu = nengetsu;
	}

	public String getShimei() {
		return shimei;
	}

	public void setShimei(String shimei) {
		this.shimei = shimei;
	}

	public String getShimeiNo() {
		return shimeiNo;
	}

	public void setShimeiNo(String shimeiNo) {
		this.shimeiNo = shimeiNo;
	}

	public String getHikokai() {
		return hikokai;
	}

	public void setHikokai(String hikokai) {
		this.hikokai = hikokai;
	}

}
