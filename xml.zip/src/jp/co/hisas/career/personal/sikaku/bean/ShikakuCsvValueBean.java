package jp.co.hisas.career.personal.sikaku.bean;

import jp.co.hisas.career.personal.util.CsvValueBean;

/**
 * ���iCSV�̏o�͓��e�i�P���R�[�h���j��ێ�����
 *
 */
public class ShikakuCsvValueBean extends CsvValueBean {

	/** ����NO */
	private String shimeiNo = null;

	/** ���� */
	private String shimei = null;

	/** ������ */
	private String busyo = null;

	/** ���i�R�[�h */
	private String shikakuCode = null;

	/** ���i���� */
	private String shikakuName = null;

	/** ���i���x�� */
	private String shikakuLevel = null;

	/** �擾�N�� */
	private String shutokuNengetsu = null;

	/** ���_ */
	private String score = null;

	/** �����N�� */
	private String sikkoNengetsu = null;

	/** �L�v */
	private String yueki = null;

	/** �ԍ� */
	private String num = null;

	/** ���i��� */
	private String shikakuShubetsu = null;

	/** ����J */
	private String hikokai = null;

	public String getBusyo() {
		return busyo;
	}

	public void setBusyo(String busyo) {
		this.busyo = busyo;
	}

	public String getHikokai() {
		return hikokai;
	}

	public void setHikokai(String hikokai) {
		this.hikokai = hikokai;
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getShikakuCode() {
		return shikakuCode;
	}

	public void setShikakuCode(String shikakuCode) {
		this.shikakuCode = shikakuCode;
	}

	public String getShikakuLevel() {
		return shikakuLevel;
	}

	public void setShikakuLevel(String shikakuLevel) {
		this.shikakuLevel = shikakuLevel;
	}

	public String getShikakuName() {
		return shikakuName;
	}

	public void setShikakuName(String shikakuName) {
		this.shikakuName = shikakuName;
	}

	public String getShikakuShubetsu() {
		return shikakuShubetsu;
	}

	public void setShikakuShubetsu(String shikakuShubetsu) {
		this.shikakuShubetsu = shikakuShubetsu;
	}

	public String getShimei() {
		return shimei;
	}

	public void setShimei(String shimei) {
		this.shimei = shimei;
	}

	public String getShimeiNo() {
		return shimeiNo;
	}

	public void setShimeiNo(String shimeiNo) {
		this.shimeiNo = shimeiNo;
	}

	public String getShutokuNengetsu() {
		return shutokuNengetsu;
	}

	public void setShutokuNengetsu(String shutokuNengetsu) {
		this.shutokuNengetsu = shutokuNengetsu;
	}

	public String getSikkoNengetsu() {
		return sikkoNengetsu;
	}

	public void setSikkoNengetsu(String sikkoNengetsu) {
		this.sikkoNengetsu = sikkoNengetsu;
	}

	public String getYueki() {
		return yueki;
	}

	public void setYueki(String yueki) {
		this.yueki = yueki;
	}
}
