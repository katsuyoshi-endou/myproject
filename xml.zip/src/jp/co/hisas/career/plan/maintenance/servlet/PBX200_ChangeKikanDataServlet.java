/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.maintenance.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.plan.base.bean.PBY_KikanBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PBX200_ChangeKikanDataServlet �N���X �@�\�����F �e�[�u��P33�Ƀf�[�^��}���E�X�V���܂��B
 * 
 * </PRE>
 */
public class PBX200_ChangeKikanDataServlet extends PCY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException, Exception {
		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final String login_no = loginuser.getSimeiNo();

		final PBY_KikanBean kikanBean = new PBY_KikanBean(login_no);

		final String seigyoNo = PZZ010_CharacterUtil.strEncode(request.getParameter("seigyoNo"));
		kikanBean.setKikanSeigyo(seigyoNo);
		kikanBean.setKikanTokikan(PZZ010_CharacterUtil.strEncode(request.getParameter("kikanToKikan")));
		kikanBean.setKikanKaisi(PZZ010_CharacterUtil.strEncode(request.getParameter("T001_kikanKaisi")));
		kikanBean.setKikanSyuryo(PZZ010_CharacterUtil.strEncode(request.getParameter("T001_kikanSyuryo")));
		kikanBean.setKikanAssesmentKikan(PZZ010_CharacterUtil.strEncode(request.getParameter("T001_kikanAssesmentKikan")));
		kikanBean.setKikanJissekiKikan(PZZ010_CharacterUtil.strEncode(request.getParameter("T001_kikanJissekiKikan")));
		kikanBean.setKikanKeikakuKikan(PZZ010_CharacterUtil.strEncode(request.getParameter("T001_kikanKeikakuKikan")));
		kikanBean.setKikanSkillKikan(PZZ010_CharacterUtil.strEncode(request.getParameter("T001_kikanSkillKikan")));

		final String isUpdate = request.getParameter("isUpdate");

		final PBY_KikanBean checkBean = new PBY_KikanBean();
		checkBean.search_KikanList(login_no);

		boolean update = false;
		for (int i = 0; i < checkBean.getKikanResultList().length; i++) {
			if (seigyoNo.equals(checkBean.getKikanResultList()[i][0])) {
				update = true;
			}

			if ("1".equals(kikanBean.getKikanTokikan()) && "1".equals(checkBean.getKikanResultList()[i][6]) && !checkBean.getKikanResultList()[i][0].equals(kikanBean.getKikanSeigyo())) {
				// TOKIKAN_FLG = 0 �ƍX�V���܂��B
				final PBY_KikanBean updateBean = new PBY_KikanBean();

				updateBean.setKikanSeigyo(checkBean.getKikanResultList()[i][0]);
				updateBean.setKikanKaisi(checkBean.getKikanResultList()[i][1]);
				updateBean.setKikanSyuryo(checkBean.getKikanResultList()[i][2]);
				updateBean.setKikanAssesmentKikan(checkBean.getKikanResultList()[i][3]);
				updateBean.setKikanJissekiKikan(checkBean.getKikanResultList()[i][4]);
				updateBean.setKikanKeikakuKikan(checkBean.getKikanResultList()[i][5]);
				updateBean.setKikanTokikan("0");
				updateBean.setKikanSkillKikan(checkBean.getKikanResultList()[i][7]);

				updateBean.update_KikanData(login_no, updateBean);
			}
		}

		if ("0".equals(isUpdate) && !update) {
			kikanBean.insert_KikanData(login_no, kikanBean);
		} else {
			kikanBean.update_KikanData(login_no, kikanBean);
		}

		/* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}