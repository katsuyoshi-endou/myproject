/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.search.servlet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.sosiki.bean.SosikiBean;
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.plan.search.bean.PBE_SearchChallengeBean;
import jp.co.hisas.career.search.kojin.bean.SearchKojinBean;
import jp.co.hisas.career.util.common.PZZ050_FileUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �L�����A�`�������W���Ǘ�����o�͂���L�����A�`�������W���{��CSV�̏o�͂��s��
 */
public class PBE030_ChallengeCSVServlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
	 * @param response Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet�̐���ȏ������W����ꂽ���ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = "";
		
		try {

			final HttpSession session = request.getSession(false);
			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");

				login_no = bean.getLogin_no();

				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				// ����SearchChallengeBean�Ăяo��
				PBE_SearchChallengeBean challenge = (PBE_SearchChallengeBean) session.getAttribute("searchChallenge");
				if (challenge == null) {
					challenge = new PBE_SearchChallengeBean(login_no);
					session.setAttribute("searchChallenge", challenge);
				}
				SearchKojinBean kojin = (SearchKojinBean) session.getAttribute("kojin");
				if (kojin == null) {
					kojin = new SearchKojinBean();
					session.setAttribute("kojin", kojin);
				}

				// �O����`�l�̎擾
				final String engName = (String) ReadFile.fileMapData.get(HcdbDef.searchParam1);
				final String jinRyaku = (String) ReadFile.fileMapData.get(HcdbDef.searchParam2);
				final String yakuMaster = (String) ReadFile.fileMapData.get(HcdbDef.yakusyoku_master);
				final String labelItem1 = (String) ReadFile.paramMapData.get("DZZ001");
				final String labelItem2 = (String) ReadFile.paramMapData.get("DZZ004");
				final String labelItem3 = (String) ReadFile.paramMapData.get("DZZ005");
				final String labelItem4 = (String) ReadFile.paramMapData.get("DZZ006");
				final String labelItem5 = (String) ReadFile.paramMapData.get("DZZ014");
				final String labelItem6 = (String) ReadFile.paramMapData.get("DZZ017");

				// �������ʂ̎擾
				final int rescnt = challenge.getCount();
				final String search_cnd = (String) session.getAttribute("searchCondition");
				final String[][] challengeList = challenge.getChallengeList();

				// �o�͏��Z�b�g�p�ϐ�
				final ByteArrayOutputStream baos = new ByteArrayOutputStream();
				byte[] add;

				/* �w�b�_���o�� */
				String header = "";
				int addIndex = 0;

				header = "\"" + "���������F" + "\"" + "," + "\"" + search_cnd.replaceAll("<br>", "�A") + "\"" + HcdbDef.CSV_LINE_FEED_CODE;
				final String logjouken = "���������F," + search_cnd.replaceAll("<br>", "�A");
				header = header + "\"" + "�������ʁF" + "\"" + "," + "\"" + rescnt + "��" + "\"" + HcdbDef.CSV_LINE_FEED_CODE;

				header = header + HcdbDef.CSV_LINE_FEED_CODE + "\"" + labelItem1 + "\"" + "," + "\"" + labelItem2 + "\"" + ",";
				if (engName.equals("1")) {
					header = header + "\"" + labelItem3 + "\"" + ",";
					addIndex++;
				}
				if (jinRyaku.equals("1")) {
					header = header + "\"" + labelItem4 + "\"" + ",";
				} else {
					header = header + "\"" + labelItem6 + "\"" + ",";
				}
				header = header + "\"" + labelItem5 + "\"" + "," + "\"" + "���Ԗ�" + "\"" + "," + "\"" + "���с^�v��" + "\"" + "," + "\"" + "�i����" + "\"";

				add = header.getBytes();
				baos.write(add);

				String data = "";
				for (int i = 0; i < challengeList.length; i++) {
					data = data + HcdbDef.CSV_LINE_FEED_CODE + "\"" + challengeList[i][1].substring(1) + "\"" + "," + "\"" + challengeList[i][2].substring(1) + "\"" + ",";
					if (engName.equals("1")) {
						data = data + "\"" + challengeList[i][3].substring(1) + "\"" + ",";
					}
					if (jinRyaku.equals("2") && yakuMaster.equals("0")) {
						data = data + "\"" + challengeList[i][3 + addIndex].substring(1) + "\"" + ",";
					} else {
						data = data + "\"" + challengeList[i][3 + addIndex] + "\"" + ",";
					}
					data = data + "\"" + SosikiBean.getSosikiByCode(challengeList[i][4 + addIndex].trim(), login_no)[2] + "\"" + "," + "\"" + challengeList[i][5 + addIndex] + "\"" + ",";
					if (challengeList[i][7 + addIndex].equals(HcdbDef.plan)) {
						data = data + "\"" + "�v��" + "\"" + ",";
					} else {
						data = data + "\"" + "����" + "\"" + ",";
					}
					for (int j = 0; j < HcdbDef.sinchoku.length; j++) {
						if (challengeList[i][8 + addIndex].equals(HcdbDef.sinchoku[j][2]) && challengeList[i][9 + addIndex].equals(HcdbDef.sinchoku[j][3])) {
							data = data + "\"" + HcdbDef.sinchoku[j][1] + "\"";
						}
					}
				}

				add = data.getBytes();
				baos.write(add);
				baos.close();

				/* ���샍�O�o�� */
				final String simei_no = bean.getSimei_no();
				OutLogBean.sousaKojinJohoLog("SEA001", login_no, simei_no, logjouken);

				final ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
				final String csv_name = PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_CAREERCHALLENGE_JOKYO_CSV, new String[] { login_no });
				request.setAttribute("STREAM", bais);
				request.setAttribute("H080_FileName", csv_name);

				final RequestDispatcher rd = this.ctx.getRequestDispatcher("/servlet/PYE010_FileDownloadServlet");
				rd.forward(request, response);

				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}
}