/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.forum.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.ejb.EJBException;
import javax.naming.NamingException;

import jp.co.hisas.career.department.forum.valuebean.PEA_ForumBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PEA_ForumAllSearchDao �@�\�����F
 * 
 * </PRE>
 */
public class PEA_ForumAllSearchDao {
	/** d05_�t�H�[���� �e�[�u�����S�t�H�[�������������ĕԂ��B */
	private static final String FORUM_SEARCH_SQL = "SELECT " + "*" + " FROM " + HcdbDef.D05_TBL + " WHERE syorijyokyo_flg='2'";

	/**
	 * �R���X�g���N�^�B
	 * @param dataSource
	 */
	public PEA_ForumAllSearchDao() {
	}

	/**
	 * �o�^����Ă���t�H�[�����̈ꗗ���擾����B
	 * @return PEA_ForumBean[] �t�H�[�������Bean�̔z��
	 */
	public PEA_ForumBean[] doSelect() {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		final ArrayList resultArray = new ArrayList();

		try {
			con = PZZ040_SQLUtility.getConnection("");
			ps = con.prepareStatement(PEA_ForumAllSearchDao.FORUM_SEARCH_SQL);

			rs = ps.executeQuery();

			while (rs.next()) {
				PEA_ForumBean result = null;
				result = new PEA_ForumBean(rs, null, false);
				resultArray.add(result);
			}

			final PEA_ForumBean[] res = new PEA_ForumBean[resultArray.size()];

			return (PEA_ForumBean[]) resultArray.toArray(res);
		} catch (final SQLException e) {
			Log.error("", e);
			throw new EJBException(e);
		} catch (final NamingException e) {
			Log.error("", e);
			throw new EJBException(e);
		} finally {
			PZZ040_SQLUtility.closeConnection("", con, ps, rs);
		}
	}
}
