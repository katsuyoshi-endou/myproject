/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.forum.ejb;

import java.io.StringReader;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.ejb.PEY_CounterEJB;
import jp.co.hisas.career.department.base.ejb.PEY_CounterEJBHome;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.forum.valuebean.PEA_ForumBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PEA_ForumEJBBean�N���X �@�\�����F D05_�t�H�[����TBL�ւ̑�����s���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="PEA_ForumEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PEA_ForumEJBBean implements SessionBean {
	private SessionContext context = null;

	/**
	 * <pre>
	 *       D05_�t�H�[����TBL�y��D06_���eTBL�̌������s���A
	 *       �������ʂ��i�[�����z���Ԃ��܂��B
	 *       �������ʂ��Ȃ������ꍇ�́A��̔z���Ԃ��܂��B
	 *       �ȉ��̍��ڂ����������Ƃ��Ďg�p�ł��܂��B
	 * </pre>
	 * 
	 * @param login_no ���O�C�����[�U
	 * @return ��������
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PEA_ForumBean[] forumKensaku(final PEA_ForumBean forumBean, final PEY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final Collection ret = new ArrayList();
			StringBuffer sql = new StringBuffer();
			final StringBuffer sql_debug = new StringBuffer(); // debug�\���p

			sql = sql.append(" SELECT * FROM " + HcdbDef.D05_TBL + " A, " + " ( SELECT FORUM_ID ID, " + "          SUBSTR(MAX(TOUKOUBI || TOUKOUJIKOKU), 0, 8) RECENT, "
					+ "          SUBSTR(MAX(TOUKOUBI || TOUKOUJIKOKU), 9, 15) RECENTJIKOKU, " + "          COUNT(*) COUNT " + "          FROM " + HcdbDef.D06_TBL + " GROUP BY FORUM_ID )  B  WHERE "
					+ " A.FORUM_ID = B.ID(+) "); // �S�Ă̏����擾����ꍇ

			// �t�H�[�����h�c���w�肵�ď����擾����ꍇ
			if (forumBean.getForumId() != null) {
				sql.append("        AND FORUM_ID=? ");
				sql_debug.append("   FORUM_ID= ");
				sql.append(" ORDER BY RECENT DESC, RECENTJIKOKU DESC, FORUM_MEI ASC ");

				// ����NO���w�肵�ăt�H�[���������擾����ꍇ
			} else if (forumBean.getSimeiNo() != null) {
				sql.append("        AND SIMEI_NO=? ");
				sql_debug.append("   SIMEI_NO= ");
				sql.append(" ORDER BY SINSEIBI DESC, SINSEIJIKOKU DESC, KOUSINBI DESC, KOUSINJIKOKU DESC, FORUM_MEI ASC ");

				// �����󋵂��w�肵�ď����擾����ꍇ
			} else if (forumBean.getNotKeep() == null && forumBean.getSyoriJyokyoFlg() != null) {
				sql.append("        AND SYORIJYOKYO_FLG=? ");
				sql_debug.append("   SYORIJYOKYO_FLG= ");
				sql.append(" ORDER BY RECENT DESC, RECENTJIKOKU DESC, FORUM_MEI ASC ");

				// �ۑ����Ă���t�H�[�����ȊO���擾����ꍇ
			} else if (forumBean.getNotKeep() != null) {
				sql.append("        AND SYORIJYOKYO_FLG != '0' ");
				sql.append(" ORDER BY SINSEIBI DESC, SINSEIJIKOKU DESC,  FORUM_MEI ASC ");

				// ���̑��i�S���擾�j
			} else {
				sql.append(" ORDER BY RECENT DESC, RECENTJIKOKU DESC, FORUM_MEI ASC ");
			}

			// debug�o��
			Log.debug(sql.toString());

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �������s
			ps = con.prepareStatement(sql.toString());

			// �t�H�[�����h�c���w�肵�ď����擾����ꍇ
			if (forumBean.getForumId() != null) {
				ps.setString(1, forumBean.getForumId());
				sql_debug.append(forumBean.getForumId());

				// ����NO���w�肵�ăt�H�[���������擾����ꍇ
			} else if (forumBean.getSimeiNo() != null) {
				ps.setString(1, forumBean.getSimeiNo());
				sql_debug.append(forumBean.getSimeiNo());

				// �����󋵂��w�肵�ď����擾����ꍇ
			} else if (forumBean.getNotKeep() == null && forumBean.getSyoriJyokyoFlg() != null) {
				ps.setString(1, forumBean.getSyoriJyokyoFlg());
				sql_debug.append(forumBean.getSyoriJyokyoFlg());
			} else {
				// �������Ȃ�
			}

			// debug�o��
			Log.debug(sql_debug.toString());

			rs = ps.executeQuery();

			while (rs.next()) {
				ret.add(new PEA_ForumBean(rs, null));
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return (PEA_ForumBean[]) ret.toArray(new PEA_ForumBean[0]);
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * �t�H�[������o�^���܂��B
	 * @param forumBean �쐬���e
	 * @param loginuser ���O�C�����[�U
	 * @return �쐬����
	 * @throws PEY_WarningException �C���T�[�g�� SQLException �����������ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int forumToroku(final PEA_ForumBean forumBean, final PEY_PersonalBean loginuser) throws PEY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// SQL�쐬
			final StringBuffer sql = new StringBuffer();
			final StringBuffer sql_debug = new StringBuffer(); // debug�\���p

			sql.append("INSERT INTO ");
			sql.append(HcdbDef.D05_TBL);
			sql.append(" (");
			sql.append("    FORUM_ID,");
			sql_debug.append("    FORUM_ID,");
			sql.append("    FORUM_MEI,");
			sql_debug.append("    FORUM_MEI,");
			sql.append("    FORUM_GAIYO,");
			sql_debug.append("    FORUM_GAIYO,");
			sql.append("    SANKA_JYOKEN_FLG,");
			sql_debug.append("    SANKA_JYOKEN_FLG,");
			sql.append("    SYOKUI,");
			sql_debug.append("    SYOKUI,");
			sql.append("    SYOKUI_TAISYO_HANI,");
			sql_debug.append("    SYOKUI_TAISYO_HANI,");
			sql.append("    SYOKU_CODE1,");
			sql_debug.append("    SYOKU_CODE1,");
			sql.append("    SENMON_CODE1,");
			sql_debug.append("    SENMON_CODE1,");
			sql.append("    LEVEL_CODE1,");
			sql_debug.append("    LEVEL_CODE1,");
			sql.append("    SKILL_HANI1,");
			sql_debug.append("    SKILL_HANI1,");
			sql.append("    HYOKA_TAISYO1,");
			sql_debug.append("    HYOKA_TAISYO1,");
			sql.append("    SOUGOU_T_DO1,");
			sql_debug.append("    SOUGOU_T_DO1,");
			sql.append("    T_DO_HANI1,");
			sql_debug.append("    T_DO_HANI1,");
			sql.append("    SYOKU_CODE2,");
			sql_debug.append("    SYOKU_CODE2,");
			sql.append("    SENMON_CODE2,");
			sql_debug.append("    SENMON_CODE2,");
			sql.append("    LEVEL_CODE2,");
			sql_debug.append("    LEVEL_CODE2,");
			sql.append("    SKILL_HANI2,");
			sql_debug.append("    SKILL_HANI2,");
			sql.append("    HYOKA_TAISYO2,");
			sql_debug.append("    HYOKA_TAISYO2,");
			sql.append("    SOUGOU_T_DO2,");
			sql_debug.append("    SOUGOU_T_DO2,");
			sql.append("    T_DO_HANI2,");
			sql_debug.append("    T_DO_HANI2,");
			sql.append("    SYOKU_CODE3,");
			sql_debug.append("    SYOKU_CODE3,");
			sql.append("    SENMON_CODE3,");
			sql_debug.append("    SENMON_CODE3,");
			sql.append("    LEVEL_CODE3,");
			sql_debug.append("    LEVEL_CODE3,");
			sql.append("    SKILL_HANI3,");
			sql_debug.append("    SKILL_HANI3,");
			sql.append("    HYOKA_TAISYO3,");
			sql_debug.append("    HYOKA_TAISYO3,");
			sql.append("    SOUGOU_T_DO3,");
			sql_debug.append("    SOUGOU_T_DO3,");
			sql.append("    T_DO_HANI3,");
			sql_debug.append("    T_DO_HANI3,");
			sql.append("    TAISYOSYA_SIMEI_NO,");
			sql_debug.append("    TAISYOSYA_SIMEI_NO,");
			sql.append("    SANKA_JYOKEN,");
			sql_debug.append("    SANKA_JYOKEN,");
			sql.append("    KANRISYA_COMMENT,");
			sql_debug.append("    KANRISYA_COMMENT,");
			sql.append("    ANNOUNCE,");
			sql_debug.append("    ANNOUNCE,");
			sql.append("    SYORIJYOKYO_FLG,");
			sql_debug.append("    SYORIJYOKYO_FLG,");
			sql.append("    FORUM_KAISETUBI,");
			sql_debug.append("    FORUM_KAISETUBI,");
			sql.append("    SIMEI_NO,");
			sql_debug.append("    SIMEI_NO,");
			sql.append("    KANJI_SIMEI,");
			sql_debug.append("    KANJI_SIMEI,");
			sql.append("    SYOZOKU,");
			sql_debug.append("    SYOZOKU,");
			sql.append("    MAIL,");
			sql_debug.append("    MAIL,");
			sql.append("    SINSEIBI,");
			sql_debug.append("    SINSEIBI,");
			sql.append("    SINSEIJIKOKU,");
			sql_debug.append("    SINSEIJIKOKU,");
			sql.append("    KOUSINSYA,");
			sql_debug.append("    KOUSINSYA,");
			sql.append("    KOUSINBI,");
			sql_debug.append("    KOUSINBI,");
			sql.append("    KOUSINJIKOKU,");
			sql_debug.append("    KOUSINJIKOKU,");
			sql.append("    YOBI1,");
			sql_debug.append("    YOBI1,");
			sql.append("    YOBI2,");
			sql_debug.append("    YOBI2,");
			sql.append("    YOBI3 )");
			sql_debug.append("    YOBI3, ");
			sql.append("  VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,");
			sql.append("           ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,");
			sql.append("           ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,");
			sql.append("           ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,");
			sql.append("           ?, ?, ?, ?, ? )");

			int count = 0;
			ps = con.prepareStatement(sql.toString());
			// �f�o�b�O���O���o��
			Log.debug(sql.toString());

			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PEY_CounterEJBHome counterHome = (PEY_CounterEJBHome) fact.lookup(PEY_CounterEJBHome.class);
			final PEY_CounterEJB counterEjb = counterHome.create();

			ps.setString(1, counterEjb.countForumId());
			sql_debug.append(counterEjb.countForumId());
			sql_debug.append(",");

			ps.setString(2, forumBean.getForumMei());
			sql_debug.append(forumBean.getForumMei());
			sql_debug.append(",");

			if (forumBean.getForumGaiyo() != null && !forumBean.getForumGaiyo().equals("")) {
				final StringReader strReader = new StringReader(forumBean.getForumGaiyo());
				ps.setCharacterStream(3, strReader, forumBean.getForumGaiyo().length());
			} else {
				ps.setNull(3, java.sql.Types.VARCHAR);
			}
			sql_debug.append(forumBean.getForumGaiyo());
			sql_debug.append(",");

			ps.setString(4, forumBean.getSankaJyokenFlg());
			sql_debug.append(forumBean.getSankaJyokenFlg());
			sql_debug.append(",");

			ps.setString(5, forumBean.getSyokui());
			sql_debug.append(forumBean.getSyokui());
			sql_debug.append(",");

			ps.setString(6, forumBean.getSyokuiHani());
			sql_debug.append(forumBean.getSyokuiHani());
			sql_debug.append(",");

			ps.setString(7, forumBean.getSyokuCodeArry()[0]);
			sql_debug.append(forumBean.getSyokuCodeArry()[0]);
			sql_debug.append(",");

			ps.setString(8, forumBean.getSenmonCodeArry()[0]);
			sql_debug.append(forumBean.getSyokuCodeArry()[0]);
			sql_debug.append(",");

			ps.setString(9, forumBean.getLevelCodeArry()[0]);
			sql_debug.append(forumBean.getLevelCodeArry()[0]);
			sql_debug.append(",");

			ps.setString(10, forumBean.getSkillHaniArry()[0]);
			sql_debug.append(forumBean.getSkillHaniArry()[0]);
			sql_debug.append(",");

			ps.setString(11, forumBean.getHyokaTaisyoArry()[0]);
			sql_debug.append(forumBean.getHyokaTaisyoArry()[0]);
			sql_debug.append(",");

			if (forumBean.getSougouTDoArry()[0] == null || forumBean.getSougouTDoArry()[0].equals("")) {
				ps.setNull(12, java.sql.Types.INTEGER);
			} else {
				ps.setInt(12, Integer.parseInt(forumBean.getSougouTDoArry()[0]));
			}
			sql_debug.append(forumBean.getSougouTDoArry()[0]);
			sql_debug.append(",");

			ps.setString(13, forumBean.getTDoHaniArry()[0]);
			sql_debug.append(forumBean.getTDoHaniArry()[0]);
			sql_debug.append(",");

			ps.setString(14, forumBean.getSyokuCodeArry()[1]);
			sql_debug.append(forumBean.getSyokuCodeArry()[1]);
			sql_debug.append(",");

			ps.setString(15, forumBean.getSenmonCodeArry()[1]);
			sql_debug.append(forumBean.getSenmonCodeArry()[1]);
			sql_debug.append(",");

			ps.setString(16, forumBean.getLevelCodeArry()[1]);
			sql_debug.append(forumBean.getLevelCodeArry()[1]);
			sql_debug.append(",");

			ps.setString(17, forumBean.getSkillHaniArry()[1]);
			sql_debug.append(forumBean.getSkillHaniArry()[1]);
			sql_debug.append(",");

			ps.setString(18, forumBean.getHyokaTaisyoArry()[1]);
			if (forumBean.getSougouTDoArry()[1] == null || forumBean.getSougouTDoArry()[1].equals("")) {
				ps.setNull(19, java.sql.Types.INTEGER);
			} else {
				ps.setInt(19, Integer.parseInt(forumBean.getSougouTDoArry()[1]));
			}
			sql_debug.append(forumBean.getSougouTDoArry()[1]);
			sql_debug.append(",");

			ps.setString(20, forumBean.getTDoHaniArry()[1]);
			sql_debug.append(forumBean.getTDoHaniArry()[1]);
			sql_debug.append(",");

			ps.setString(21, forumBean.getSyokuCodeArry()[2]);
			sql_debug.append(forumBean.getSyokuCodeArry()[2]);
			sql_debug.append(",");

			ps.setString(22, forumBean.getSenmonCodeArry()[2]);
			sql_debug.append(forumBean.getSenmonCodeArry()[2]);
			sql_debug.append(",");

			ps.setString(23, forumBean.getLevelCodeArry()[2]);
			sql_debug.append(forumBean.getLevelCodeArry()[2]);
			sql_debug.append(",");

			ps.setString(24, forumBean.getSkillHaniArry()[2]);
			sql_debug.append(forumBean.getSkillHaniArry()[2]);
			sql_debug.append(",");

			ps.setString(25, forumBean.getHyokaTaisyoArry()[2]);
			sql_debug.append(forumBean.getHyokaTaisyoArry()[2]);
			sql_debug.append(",");

			if (forumBean.getSougouTDoArry()[2] == null || forumBean.getSougouTDoArry()[2].equals("")) {
				ps.setNull(26, java.sql.Types.INTEGER);
			} else {
				ps.setInt(26, Integer.parseInt(forumBean.getSougouTDoArry()[2]));
			}
			sql_debug.append(forumBean.getSougouTDoArry()[2]);
			sql_debug.append(",");

			ps.setString(27, forumBean.getTDoHaniArry()[2]);
			sql_debug.append(forumBean.getTDoHaniArry()[2]);
			sql_debug.append(",");

			if (forumBean.getTaisyosyaSimeiNo() != null && !forumBean.getTaisyosyaSimeiNo().equals("")) {
				final StringReader strReader2 = new StringReader(forumBean.getTaisyosyaSimeiNo());
				ps.setCharacterStream(28, strReader2, forumBean.getTaisyosyaSimeiNo().length());
			} else {
				ps.setNull(28, java.sql.Types.VARCHAR);
			}
			sql_debug.append(forumBean.getTaisyosyaSimeiNo());
			sql_debug.append(",");

			ps.setString(29, forumBean.getSankaJyoken());
			sql_debug.append(forumBean.getSankaJyoken());
			sql_debug.append(",");

			ps.setString(30, forumBean.getKanrisyaComment());
			sql_debug.append(forumBean.getKanrisyaComment());
			sql_debug.append(",");

			if (forumBean.getAnnounce() != null && !forumBean.getAnnounce().equals("")) {
				final StringReader strReader3 = new StringReader(forumBean.getAnnounce());
				ps.setCharacterStream(31, strReader3, forumBean.getAnnounce().length());
			} else {
				ps.setNull(31, java.sql.Types.VARCHAR);
			}
			sql_debug.append(forumBean.getAnnounce());
			sql_debug.append(",");

			ps.setString(32, forumBean.getSyoriJyokyoFlg());
			sql_debug.append(forumBean.getSyoriJyokyoFlg());
			sql_debug.append(",");

			ps.setString(33, forumBean.getForumKaisetubi());
			sql_debug.append(forumBean.getForumKaisetubi());
			sql_debug.append(",");

			ps.setString(34, forumBean.getSimeiNo());
			sql_debug.append(forumBean.getSimeiNo());
			sql_debug.append(",");

			ps.setString(35, forumBean.getKanjiSimei());
			sql_debug.append(forumBean.getKanjiSimei());
			sql_debug.append(",");

			ps.setString(36, forumBean.getSyozoku());
			sql_debug.append(forumBean.getSyozoku());
			sql_debug.append(",");

			ps.setString(37, forumBean.getMail());
			sql_debug.append(forumBean.getMail());
			sql_debug.append(",");

			if (forumBean.getSyoriJyokyoFlg().equals("1")) {
				ps.setString(38, PZZ010_CharacterUtil.GetDay());
				sql_debug.append(PZZ010_CharacterUtil.GetDay());
				sql_debug.append(",");
				ps.setString(39, PZZ010_CharacterUtil.GetTime());
				sql_debug.append(PZZ010_CharacterUtil.GetTime());
				sql_debug.append(",");
			} else {
				ps.setString(38, forumBean.getSinseibi());
				sql_debug.append(forumBean.getSinseibi());
				sql_debug.append(",");
				ps.setString(39, forumBean.getSinseijikoku());
				sql_debug.append(forumBean.getSinseijikoku());
				sql_debug.append(",");
			}
			ps.setString(40, loginuser.getSimeiNo());
			sql_debug.append(loginuser.getSimeiNo());
			sql_debug.append(",");

			ps.setString(41, PZZ010_CharacterUtil.GetDay());
			sql_debug.append(PZZ010_CharacterUtil.GetDay());
			sql_debug.append(",");

			ps.setString(42, PZZ010_CharacterUtil.GetTime());
			sql_debug.append(PZZ010_CharacterUtil.GetTime());
			sql_debug.append(",");

			ps.setString(43, forumBean.getYobi1());
			sql_debug.append(forumBean.getYobi1());
			sql_debug.append(",");

			ps.setString(44, forumBean.getYobi2());
			sql_debug.append(forumBean.getYobi2());
			sql_debug.append(",");

			ps.setString(45, forumBean.getYobi3());
			sql_debug.append(forumBean.getYobi3());
			sql_debug.append(",");

			Log.debug(sql_debug.toString());

			// �o�^���s
			count += ps.executeUpdate();

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RemoteException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final CreateException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * �t�H�[�����h�c���L�[�Ƃ��ăt�H�[���������X�V���܂��B
	 * @param forumBean �X�V���e
	 * @param login ���O�C�����[�U
	 * @return �X�V����
	 * @throws PEY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int forumKosin(final PEA_ForumBean forumBean, final PEY_PersonalBean loginuser) throws PEY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// SQL�쐬
			StringBuffer sql = new StringBuffer();
			final StringBuffer sql_debug = new StringBuffer();

			sql.append("UPDATE ");
			sql.append(HcdbDef.D05_TBL);
			sql.append(" SET ");
			if (forumBean.getForumMei() != null) {
				sql.append("        FORUM_MEI=?,");
				sql_debug.append(" FORUM_MEI,");
			}

			if (forumBean.getForumGaiyo() != null) {
				sql.append("        FORUM_GAIYO=?,");
				sql_debug.append(" FORUM_GAIYO,");
			}

			if (forumBean.getSankaJyokenFlg() != null) {
				sql.append("        SANKA_JYOKEN_FLG=?,");
				sql_debug.append(" SANKA_JYOKEN_FLG,");
			}

			if (forumBean.getSyokui() != null) {
				sql.append("        SYOKUI=?,");
				sql_debug.append(" SYOKUI,");
			}

			if (forumBean.getSyokuiHani() != null) {
				sql.append("        SYOKUI_TAISYO_HANI=?,");
				sql_debug.append(" SYOKUI_TAISYO_HANI,");
			}

			if (forumBean.getSyokuCodeArry()[0] != null) {
				sql.append("        SYOKU_CODE1=?,");
				sql_debug.append(" SYOKU_CODE1,");
			}

			if (forumBean.getSenmonCodeArry()[0] != null) {
				sql.append("        SENMON_CODE1=?,");
				sql_debug.append(" SENMON_CODE1,");
			}

			if (forumBean.getLevelCodeArry()[0] != null) {
				sql.append("        LEVEL_CODE1=?,");
				sql_debug.append(" LEVEL_CODE1,");
			}

			if (forumBean.getSkillHaniArry()[0] != null) {
				sql.append("        SKILL_HANI1=?,");
				sql_debug.append(" SKILL_HANI1,");
			}

			if (forumBean.getHyokaTaisyoArry()[0] != null) {
				sql.append("        HYOKA_TAISYO1=?,");
				sql_debug.append(" HYOKA_TAISYO1,");
			}

			if (forumBean.getSougouTDoArry()[0] != null) {
				sql.append("            SOUGOU_T_DO1=?,");
				sql_debug.append(" SOUGOU_T_DO1,");
			}

			if (forumBean.getTDoHaniArry()[0] != null) {
				sql.append("        T_DO_HANI1=?,");
				sql_debug.append(" T_DO_HANI1,");
			}

			if (forumBean.getSyokuCodeArry()[1] != null) {
				sql.append("        SYOKU_CODE2=?,");
				sql_debug.append(" SYOKU_CODE2,");
			}

			if (forumBean.getSenmonCodeArry()[1] != null) {
				sql.append("        SENMON_CODE2=?,");
				sql_debug.append(" SENMON_CODE2,");
			}

			if (forumBean.getLevelCodeArry()[1] != null) {
				sql.append("        LEVEL_CODE2=?,");
				sql_debug.append(" LEVEL_CODE2,");
			}

			if (forumBean.getSkillHaniArry()[1] != null) {
				sql.append("        SKILL_HANI2=?,");
				sql_debug.append(" SKILL_HANI2,");
			}

			if (forumBean.getHyokaTaisyoArry()[1] != null) {
				sql.append("        HYOKA_TAISYO2=?,");
				sql_debug.append(" HYOKA_TAISYO2,");
			}

			if (forumBean.getSougouTDoArry()[1] != null) {
				sql.append("            SOUGOU_T_DO2=?,");
				sql_debug.append(" SOUGOU_T_DO2,");
			}

			if (forumBean.getTDoHaniArry()[1] != null) {
				sql.append("        T_DO_HANI2=?,");
				sql_debug.append(" T_DO_HANI2,");
			}

			if (forumBean.getSyokuCodeArry()[2] != null) {
				sql.append("        SYOKU_CODE3=?,");
				sql_debug.append(" SYOKU_CODE3,");
			}

			if (forumBean.getSenmonCodeArry()[2] != null) {
				sql.append("        SENMON_CODE3=?,");
				sql_debug.append(" SENMON_CODE3,");
			}

			if (forumBean.getLevelCodeArry()[2] != null) {
				sql.append("        LEVEL_CODE3=?,");
				sql_debug.append(" LEVEL_CODE3,");
			}

			if (forumBean.getSkillHaniArry()[2] != null) {
				sql.append("        SKILL_HANI3=?,");
				sql_debug.append(" SKILL_HANI3,");
			}

			if (forumBean.getHyokaTaisyoArry()[2] != null) {
				sql.append("        HYOKA_TAISYO3=?,");
				sql_debug.append(" HYOKA_TAISYO3,");
			}

			if (forumBean.getSougouTDoArry()[2] != null) {
				sql.append("            SOUGOU_T_DO3=?,");
				sql_debug.append(" SOUGOU_T_DO3,");
			}

			if (forumBean.getTDoHaniArry()[2] != null) {
				sql.append("        T_DO_HANI3=?,");
				sql_debug.append(" T_DO_HANI3,");
			}

			if (forumBean.getTaisyosyaSimeiNo() != null) {
				sql.append("        TAISYOSYA_SIMEI_NO=?,");
				sql_debug.append(" TAISYOSYA_SIMEI_NO,");
			}

			if (forumBean.getSankaJyoken() != null) {
				sql.append("        SANKA_JYOKEN=?,");
				sql_debug.append(" SANKA_JYOKEN,");
			}

			if (forumBean.getKanrisyaComment() != null) {
				sql.append("        KANRISYA_COMMENT=?,");
				sql_debug.append(" KANRISYA_COMMENT,");
			}

			if (forumBean.getAnnounce() != null) {
				sql.append("        ANNOUNCE=?,");
				sql_debug.append(" ANNOUNCE,");
			}

			if (forumBean.getSyoriJyokyoFlg() != null) {
				sql.append("        SYORIJYOKYO_FLG=?,");
				sql_debug.append(" SYORIJYOKYO_FLG,");
			}

			if (forumBean.getForumKaisetubi() != null) {
				sql.append("        FORUM_KAISETUBI=?,");
				sql_debug.append(" FORUM_KAISETUBI,");
			}

			if (forumBean.getSinseibi() != null) {
				sql.append("        SINSEIBI=?,");
				sql_debug.append(" SINSEIBI,");
			}

			if (forumBean.getSinseijikoku() != null) {
				sql.append("        SINSEIJIKOKU=?,");
				sql_debug.append(" SINSEIJIKOKU,");
			}

			if (forumBean.getKousinsya() != null) {
				sql.append("        KOUSINSYA=?,");
				sql_debug.append(" KOUSINSYA,");
			}

			sql.append("        KOUSINBI=?,");
			sql_debug.append(" KOUSINBI,");

			sql.append("        KOUSINJIKOKU=?,");
			sql_debug.append(" KOUSINJIKOKU,");

			if (forumBean.getYobi1() != null) {
				sql.append("        YOBI1=?,");
				sql_debug.append(" YOBI1,");
			}

			if (forumBean.getYobi2() != null) {
				sql.append("        YOBI2=?,");
				sql_debug.append(" YOBI2,");
			}

			if (forumBean.getYobi3() != null) {
				sql.append("        YOBI3=?");
				sql_debug.append(" YOBI3,");
			}

			if (forumBean.getForumId() != null) {
				if (sql.toString().endsWith(",")) {
					sql = new StringBuffer(sql.toString().substring(0, sql.toString().lastIndexOf(",")));
				}
				sql.append("  WHERE FORUM_ID=?");
				sql_debug.append(" FORUM_ID,");
			}

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �X�V���s
			ps = con.prepareStatement(sql.toString());

			int count = 1;

			if (forumBean.getForumMei() != null) {
				ps.setString(count++, forumBean.getForumMei());
				sql_debug.append(forumBean.getForumMei());
				sql_debug.append(",");
			}

			if (forumBean.getForumGaiyo() != null) {
				final StringReader strReader = new StringReader(forumBean.getForumGaiyo());
				ps.setCharacterStream(count++, strReader, forumBean.getForumGaiyo().length());

				sql_debug.append(forumBean.getForumGaiyo());
				sql_debug.append(",");
			}

			if (forumBean.getSankaJyokenFlg() != null) {
				ps.setString(count++, forumBean.getSankaJyokenFlg());
				sql_debug.append(forumBean.getSankaJyokenFlg());
				sql_debug.append(",");
			}

			if (forumBean.getSyokui() != null) {
				ps.setString(count++, forumBean.getSyokui());
				sql_debug.append(forumBean.getSyokui());
				sql_debug.append(",");
			}

			if (forumBean.getSyokuiHani() != null) {
				ps.setString(count++, forumBean.getSyokuiHani());
				sql_debug.append(forumBean.getSyokuiHani());
				sql_debug.append(",");
			}

			if (forumBean.getSyokuCodeArry()[0] != null) {
				ps.setString(count++, forumBean.getSyokuCodeArry()[0]);
				sql_debug.append(forumBean.getSyokuCodeArry()[0]);
				sql_debug.append(",");
			}

			if (forumBean.getSenmonCodeArry()[0] != null) {
				ps.setString(count++, forumBean.getSenmonCodeArry()[0]);
				sql_debug.append(forumBean.getSenmonCodeArry()[0]);
				sql_debug.append(",");
			}

			if (forumBean.getLevelCodeArry()[0] != null) {
				ps.setString(count++, forumBean.getLevelCodeArry()[0]);
				sql_debug.append(forumBean.getLevelCodeArry()[0]);
				sql_debug.append(",");
			}

			if (forumBean.getSkillHaniArry()[0] != null) {
				ps.setString(count++, forumBean.getSkillHaniArry()[0]);
				sql_debug.append(forumBean.getSkillHaniArry()[0]);
				sql_debug.append(",");
			}

			if (forumBean.getHyokaTaisyoArry()[0] != null) {
				ps.setString(count++, forumBean.getHyokaTaisyoArry()[0]);
				sql_debug.append(forumBean.getHyokaTaisyoArry()[0]);
				sql_debug.append(",");
			}

			if (forumBean.getSougouTDoArry()[0] != null) {
				if (forumBean.getSougouTDoArry()[0].equals("")) {
					ps.setNull(count++, java.sql.Types.INTEGER);
				} else {
					ps.setInt(count++, Integer.parseInt(forumBean.getSougouTDoArry()[0]));
				}
				sql_debug.append(forumBean.getSougouTDoArry()[0]);
				sql_debug.append(",");
			}

			if (forumBean.getTDoHaniArry()[0] != null) {
				ps.setString(count++, forumBean.getTDoHaniArry()[0]);
				sql_debug.append(forumBean.getTDoHaniArry()[0]);
				sql_debug.append(",");
			}

			if (forumBean.getSyokuCodeArry()[1] != null) {
				ps.setString(count++, forumBean.getSyokuCodeArry()[1]);
				sql_debug.append(forumBean.getSyokuCodeArry()[1]);
				sql_debug.append(",");
			}

			if (forumBean.getSenmonCodeArry()[1] != null) {
				ps.setString(count++, forumBean.getSenmonCodeArry()[1]);
				sql_debug.append(forumBean.getSenmonCodeArry()[1]);
				sql_debug.append(",");
			}

			if (forumBean.getLevelCodeArry()[1] != null) {
				ps.setString(count++, forumBean.getLevelCodeArry()[1]);
				sql_debug.append(forumBean.getLevelCodeArry()[1]);
				sql_debug.append(",");
			}

			if (forumBean.getSkillHaniArry()[1] != null) {
				ps.setString(count++, forumBean.getSkillHaniArry()[1]);
				sql_debug.append(forumBean.getSkillHaniArry()[1]);
				sql_debug.append(",");
			}

			if (forumBean.getHyokaTaisyoArry()[1] != null) {
				ps.setString(count++, forumBean.getHyokaTaisyoArry()[1]);
				sql_debug.append(forumBean.getHyokaTaisyoArry()[1]);
				sql_debug.append(",");
			}

			if (forumBean.getSougouTDoArry()[1] != null) {
				if (forumBean.getSougouTDoArry()[1].equals("")) {
					ps.setNull(count++, java.sql.Types.INTEGER);
				} else {
					ps.setInt(count++, Integer.parseInt(forumBean.getSougouTDoArry()[1]));
				}
				sql_debug.append(forumBean.getSougouTDoArry()[1]);
				sql_debug.append(",");
			}

			if (forumBean.getTDoHaniArry()[1] != null) {
				ps.setString(count++, forumBean.getTDoHaniArry()[1]);
				sql_debug.append(forumBean.getTDoHaniArry()[1]);
				sql_debug.append(",");
			}

			if (forumBean.getSyokuCodeArry()[2] != null) {
				ps.setString(count++, forumBean.getSyokuCodeArry()[2]);
				sql_debug.append(forumBean.getSyokuCodeArry()[2]);
				sql_debug.append(",");
			}

			if (forumBean.getSenmonCodeArry()[2] != null) {
				ps.setString(count++, forumBean.getSenmonCodeArry()[2]);
				sql_debug.append(forumBean.getSenmonCodeArry()[2]);
				sql_debug.append(",");
			}

			if (forumBean.getLevelCodeArry()[2] != null) {
				ps.setString(count++, forumBean.getLevelCodeArry()[2]);
				sql_debug.append(forumBean.getLevelCodeArry()[2]);
				sql_debug.append(",");
			}

			if (forumBean.getSkillHaniArry()[2] != null) {
				ps.setString(count++, forumBean.getSkillHaniArry()[2]);
				sql_debug.append(forumBean.getSkillHaniArry()[2]);
				sql_debug.append(",");
			}

			if (forumBean.getHyokaTaisyoArry()[2] != null) {
				ps.setString(count++, forumBean.getHyokaTaisyoArry()[2]);
				sql_debug.append(forumBean.getHyokaTaisyoArry()[2]);
				sql_debug.append(",");
			}

			if (forumBean.getSougouTDoArry()[2] != null) {
				if (forumBean.getSougouTDoArry()[2].equals("")) {
					ps.setNull(count++, java.sql.Types.INTEGER);
				} else {
					ps.setInt(count++, Integer.parseInt(forumBean.getSougouTDoArry()[2]));
				}
				sql_debug.append(forumBean.getSougouTDoArry()[2]);
				sql_debug.append(",");
			}

			if (forumBean.getTDoHaniArry()[2] != null) {
				ps.setString(count++, forumBean.getTDoHaniArry()[2]);
				sql_debug.append(forumBean.getTDoHaniArry()[2]);
				sql_debug.append(",");
			}

			if (forumBean.getTaisyosyaSimeiNo() != null) {
				final StringReader strReader = new StringReader(forumBean.getTaisyosyaSimeiNo());
				ps.setCharacterStream(count++, strReader, forumBean.getTaisyosyaSimeiNo().length());
				sql_debug.append(",");
			}

			if (forumBean.getSankaJyoken() != null) {
				ps.setString(count++, forumBean.getSankaJyoken());
				sql_debug.append(forumBean.getSankaJyoken());
				sql_debug.append(",");
			}

			if (forumBean.getKanrisyaComment() != null) {
				ps.setString(count++, forumBean.getKanrisyaComment());
				sql_debug.append(forumBean.getKanrisyaComment());
				sql_debug.append(",");
			}

			if (forumBean.getAnnounce() != null) {
				if (forumBean.getAnnounce().equals("")) {
					ps.setNull(count++, java.sql.Types.VARCHAR);
				} else {
					final StringReader strReader = new StringReader(forumBean.getAnnounce());
					ps.setCharacterStream(count++, strReader, forumBean.getAnnounce().length());
				}
			}
			sql_debug.append(forumBean.getAnnounce());
			sql_debug.append(",");

			if (forumBean.getSyoriJyokyoFlg() != null) {
				ps.setString(count++, forumBean.getSyoriJyokyoFlg());
				sql_debug.append(forumBean.getSyoriJyokyoFlg());
				sql_debug.append(",");
			}

			if (forumBean.getForumKaisetubi() != null) {
				ps.setString(count++, forumBean.getForumKaisetubi());
				sql_debug.append(forumBean.getForumKaisetubi());
				sql_debug.append(",");
			}

			if (forumBean.getSyoriJyokyoFlg() != null && forumBean.getSyoriJyokyoFlg().equals("1")) {
				ps.setString(count++, PZZ010_CharacterUtil.GetDay());
				sql_debug.append(PZZ010_CharacterUtil.GetDay());
				sql_debug.append(",");
				ps.setString(count++, PZZ010_CharacterUtil.GetTime());
				sql_debug.append(PZZ010_CharacterUtil.GetTime());
				sql_debug.append(",");
			} else {
				if (forumBean.getSinseibi() != null) {
					ps.setString(count++, forumBean.getSinseibi());
					sql_debug.append(forumBean.getSinseibi());
					sql_debug.append(",");
				}
				if (forumBean.getSinseijikoku() != null) {
					ps.setString(count++, forumBean.getSinseijikoku());
					sql_debug.append(forumBean.getSinseijikoku());
					sql_debug.append(",");
				}
			}

			if (forumBean.getKousinsya() != null) {
				ps.setString(count++, loginuser.getSimeiNo());
				sql_debug.append(loginuser.getSimeiNo());
				sql_debug.append(",");
			}

			if (forumBean.getKousinbi() != null) {
				ps.setString(count++, forumBean.getKousinbi());
				sql_debug.append(forumBean.getKousinbi());
				sql_debug.append(",");
			} else {
				ps.setString(count++, PZZ010_CharacterUtil.GetDay());
				sql_debug.append(PZZ010_CharacterUtil.GetDay());
				sql_debug.append(",");
			}

			if (forumBean.getKousinjikoku() != null) {
				ps.setString(count++, forumBean.getKousinjikoku());
				sql_debug.append(forumBean.getKousinjikoku());
				sql_debug.append(",");
			} else {
				ps.setString(count++, PZZ010_CharacterUtil.GetTime());
				sql_debug.append(PZZ010_CharacterUtil.GetTime());
				sql_debug.append(",");
			}

			if (forumBean.getYobi1() != null) {
				ps.setString(count++, forumBean.getYobi1());
				sql_debug.append(forumBean.getYobi1());
				sql_debug.append(",");
			}

			if (forumBean.getYobi2() != null) {
				ps.setString(count++, forumBean.getYobi2());
				sql_debug.append(forumBean.getYobi2());
				sql_debug.append(",");
			}

			if (forumBean.getYobi3() != null) {
				ps.setString(count++, forumBean.getYobi3());
				sql_debug.append(forumBean.getYobi3());
				sql_debug.append(",");
			}

			if (forumBean.getForumId() != null) {
				ps.setString(count++, forumBean.getForumId());
				sql_debug.append(forumBean.getForumId());
				sql_debug.append(",");
			}

			Log.debug(sql_debug.toString());

			// �X�V�������s
			final int updateCount = ps.executeUpdate();

			if (updateCount != 1) {
				this.context.setRollbackOnly();
				throw new PEY_WarningException();
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return updateCount;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * �t�H�[�����h�c���L�[�Ƃ��ăt�H�[���������폜���܂��B
	 * @param forumId �폜�ΏۂƂ���t�H�[����ID
	 * @param loginuser ���O�C�����[�U
	 * @return �폜����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int forumSakujyo(final PEA_ForumBean[] forumBeans, final PEY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �폜�̃J�E���^
			int count = 0;

			for (int i = 0; i < forumBeans.length; i++) {
				final StringBuffer sql = new StringBuffer();
				final StringBuffer sql_debug = new StringBuffer();// debug�p
				final StringBuffer where = new StringBuffer();
				sql.append("DELETE FROM ");
				sql.append(HcdbDef.D05_TBL);

				/* �폜�����J���� �����ǉ��� �ǉ����͉��L�폜�����l�̒ǉ����K�{ */
				if (forumBeans[i].getSimeiNo() != null) {
					where.append(" AND FORUM_ID =?");
					sql_debug.append("FORUM_ID=");
				}

				sql.append(where.toString().replaceFirst("AND", "WHERE"));

				/* SQL���O�o�� */
				Log.debug(sql.toString());

				ps = con.prepareStatement(sql.toString());

				int j = 1;

				/* �폜�����l ��L�̃J�����Ɠ����ŋL�q���邱�� */
				if (forumBeans[i].getForumId() != null) {
					ps.setString(j++, forumBeans[i].getForumId());
					sql_debug.append(forumBeans[i].getForumId());
				}

				Log.debug(sql_debug.toString());

				/* DELETE�����s */
				count += ps.executeUpdate();

				PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", null, ps, null);
			}

			/* ���eEJB�I�u�W�F�N�g���擾���� */
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PEA_ToukouEJBHome toukou_home = (PEA_ToukouEJBHome) fact.lookup(PEA_ToukouEJBHome.class);
			final PEA_ToukouEJB toukou_ejb = toukou_home.create();

			// �Y���̃t�H�[�����Ɋւ���b�肪����΍폜����
			toukou_ejb.forumSakujyo(forumBeans, loginuser);

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final CreateException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RemoteException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}

}
