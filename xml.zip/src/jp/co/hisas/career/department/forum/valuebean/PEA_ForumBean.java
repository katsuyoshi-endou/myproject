/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.forum.valuebean;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletRequest;

import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PEA_ForumBean �N���X �@�\�����F �t�H�[��������ێ�����ValueBean�ł��B
 * 
 * </PRE>
 */

public class PEA_ForumBean extends PEA_MasterBean implements Serializable {
	private String forumId = null;

	private String forumMei = null;

	private String forumGaiyo = null;

	private String sankaJyokenFlg = null;

	private String syokui = null;

	private String syokuiHani = null;

	private String[] syokuCodeArry = new String[3];

	private String[] senmonCodeArry = new String[3];

	private String[] levelCodeArry = new String[3];

	private String[] skillHaniArry = new String[3];

	private String[] hyokaTaisyoArry = new String[3];

	private String[] sougouTDoArry = new String[3];

	private String[] tDoHaniArry = new String[3];

	private String taisyosyaSimeiNo = null;

	private String sankaJyoken = null;

	private String kanrisyaComment = null;

	private String announce = null;

	private String syoriJyokyoFlg = null;

	private String forumKaisetubi = null;

	private String simeiNo = null;

	private String kanjiSimei = null;

	private String syozoku = null;

	private String mail = null;

	private String sinseibi = null;

	private String sinseijikoku = null;

	private String kousinsya = null;

	private String kousinbi = null;

	private String kousinjikoku = null;

	private String id = null;// �t�H�[����ID(SQL���p)

	private String recent = null;// �ŐV���e��

	private String recentJikoku = null;// �ŐV���e����

	private String count = null;// ���e��

	private String permission = null;// �A�N�Z�X���i����E�Ȃ��j

	private String notKeep = null;// �ۑ����ł͖�������\��

	/**
	 * �f�t�H���g�̃R���X�g���N�^�ł��B
	 */
	public PEA_ForumBean() {
		super();

	}

	/**
	 * ResultSet ����l���擾���ăt�H�[����ValueBean���쐬���܂��B
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param forumTableName �t�H�[�����e�[�u���̕ʖ�
	 * @throws SQLException SQLException�����������ꍇ
	 */
	public PEA_ForumBean(final ResultSet rs, final String forumTableName) throws SQLException {
		super(rs, forumTableName);

		try {
			this.setForumId(rs.getString(this.getIdentifier() + "forum_id"));
			this.setForumMei(rs.getString(this.getIdentifier() + "forum_mei"));
			this.setForumGaiyo(rs.getString(this.getIdentifier() + "forum_gaiyo"));
			this.setSankaJyokenFlg(rs.getString(this.getIdentifier() + "sanka_jyoken_flg"));
			this.setSyokui(rs.getString(this.getIdentifier() + "syokui"));
			this.setSyokuiHani(rs.getString(this.getIdentifier() + "syokui_taisyo_hani"));
			this.setSyokuCode(0, rs.getString(this.getIdentifier() + "syoku_code1"));
			this.setSenmonCode(0, rs.getString(this.getIdentifier() + "senmon_code1"));
			this.setLevelCode(0, rs.getString(this.getIdentifier() + "level_code1"));
			this.setSkillHani(0, rs.getString(this.getIdentifier() + "skill_hani1"));
			this.setHyokaTaisyo(0, rs.getString(this.getIdentifier() + "hyoka_taisyo1"));
			this.setSougouTDo(0, rs.getString(this.getIdentifier() + "sougou_t_do1"));
			this.setTDoHani(0, rs.getString(this.getIdentifier() + "t_do_hani1"));
			this.setSyokuCode(1, rs.getString(this.getIdentifier() + "syoku_code2"));
			this.setSenmonCode(1, rs.getString(this.getIdentifier() + "senmon_code2"));
			this.setLevelCode(1, rs.getString(this.getIdentifier() + "level_code2"));
			this.setSkillHani(1, rs.getString(this.getIdentifier() + "skill_hani2"));
			this.setHyokaTaisyo(1, rs.getString(this.getIdentifier() + "hyoka_taisyo2"));
			this.setSougouTDo(1, rs.getString(this.getIdentifier() + "sougou_t_do2"));
			this.setTDoHani(1, rs.getString(this.getIdentifier() + "t_do_hani2"));
			this.setSyokuCode(2, rs.getString(this.getIdentifier() + "syoku_code3"));
			this.setSenmonCode(2, rs.getString(this.getIdentifier() + "senmon_code3"));
			this.setLevelCode(2, rs.getString(this.getIdentifier() + "level_code3"));
			this.setSkillHani(2, rs.getString(this.getIdentifier() + "skill_hani3"));
			this.setHyokaTaisyo(2, rs.getString(this.getIdentifier() + "hyoka_taisyo3"));
			this.setSougouTDo(2, rs.getString(this.getIdentifier() + "sougou_t_do3"));
			this.setTDoHani(2, rs.getString(this.getIdentifier() + "t_do_hani3"));
			this.setTaisyosyaSimeiNo(rs.getString(this.getIdentifier() + "taisyosya_simei_no"));
			this.setSankaJyoken(rs.getString(this.getIdentifier() + "sanka_jyoken"));
			this.setKanrisyaComment(rs.getString(this.getIdentifier() + "kanrisya_comment"));
			this.setAnnounce(rs.getString(this.getIdentifier() + "announce"));
			this.setSyoriJyokyoFlg(rs.getString(this.getIdentifier() + "syorijyokyo_flg"));
			this.setForumKaisetubi(rs.getString(this.getIdentifier() + "forum_kaisetubi"));
			this.setSimeiNo(rs.getString(this.getIdentifier() + "simei_no"));
			this.setKanjiSimei(rs.getString(this.getIdentifier() + "kanji_simei"));
			this.setSyozoku(rs.getString(this.getIdentifier() + "syozoku"));
			this.setMail(rs.getString(this.getIdentifier() + "mail"));
			this.setSinseibi(rs.getString(this.getIdentifier() + "sinseibi"));
			this.setSinseijikoku(rs.getString(this.getIdentifier() + "sinseijikoku"));
			this.setKousinsya(rs.getString(this.getIdentifier() + "kousinsya"));
			this.setKousinbi(rs.getString(this.getIdentifier() + "kousinbi"));
			this.setKousinjikoku(rs.getString(this.getIdentifier() + "kousinjikoku"));
			this.setId(rs.getString(this.getIdentifier() + "id"));
			this.setRecent(rs.getString(this.getIdentifier() + "recent"));
			this.setRecentJikoku(rs.getString(this.getIdentifier() + "recentjikoku"));
			this.setCount(rs.getString(this.getIdentifier() + "count"));
		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		}

	}

	/**
	 * ResultSet ����l���擾���ăt�H�[����ValueBean���쐬���܂��B
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param forumTableName �t�H�[�����e�[�u���̕ʖ�
	 * @param flg �����p�J�����L���t���O�itrue�F�L false�F���j
	 * @throws SQLException SQLException�����������ꍇ
	 */
	public PEA_ForumBean(final ResultSet rs, final String forumTableName, final boolean flg) throws SQLException {
		super(rs, forumTableName);

		try {
			this.setForumId(rs.getString(this.getIdentifier() + "forum_id"));
			this.setForumMei(rs.getString(this.getIdentifier() + "forum_mei"));
			this.setForumGaiyo(rs.getString(this.getIdentifier() + "forum_gaiyo"));
			this.setSankaJyokenFlg(rs.getString(this.getIdentifier() + "sanka_jyoken_flg"));
			this.setSyokui(rs.getString(this.getIdentifier() + "syokui"));
			this.setSyokuiHani(rs.getString(this.getIdentifier() + "syokui_taisyo_hani"));
			this.setSyokuCode(0, rs.getString(this.getIdentifier() + "syoku_code1"));
			this.setSenmonCode(0, rs.getString(this.getIdentifier() + "senmon_code1"));
			this.setLevelCode(0, rs.getString(this.getIdentifier() + "level_code1"));
			this.setSkillHani(0, rs.getString(this.getIdentifier() + "skill_hani1"));
			this.setHyokaTaisyo(0, rs.getString(this.getIdentifier() + "hyoka_taisyo1"));
			this.setSougouTDo(0, rs.getString(this.getIdentifier() + "sougou_t_do1"));
			this.setTDoHani(0, rs.getString(this.getIdentifier() + "t_do_hani1"));
			this.setSyokuCode(1, rs.getString(this.getIdentifier() + "syoku_code2"));
			this.setSenmonCode(1, rs.getString(this.getIdentifier() + "senmon_code2"));
			this.setLevelCode(1, rs.getString(this.getIdentifier() + "level_code2"));
			this.setSkillHani(1, rs.getString(this.getIdentifier() + "skill_hani2"));
			this.setHyokaTaisyo(1, rs.getString(this.getIdentifier() + "hyoka_taisyo2"));
			this.setSougouTDo(1, rs.getString(this.getIdentifier() + "sougou_t_do2"));
			this.setTDoHani(1, rs.getString(this.getIdentifier() + "t_do_hani2"));
			this.setSyokuCode(2, rs.getString(this.getIdentifier() + "syoku_code3"));
			this.setSenmonCode(2, rs.getString(this.getIdentifier() + "senmon_code3"));
			this.setLevelCode(2, rs.getString(this.getIdentifier() + "level_code3"));
			this.setSkillHani(2, rs.getString(this.getIdentifier() + "skill_hani3"));
			this.setHyokaTaisyo(2, rs.getString(this.getIdentifier() + "hyoka_taisyo3"));
			this.setSougouTDo(2, rs.getString(this.getIdentifier() + "sougou_t_do3"));
			this.setTDoHani(2, rs.getString(this.getIdentifier() + "t_do_hani3"));
			this.setTaisyosyaSimeiNo(rs.getString(this.getIdentifier() + "taisyosya_simei_no"));
			this.setSankaJyoken(rs.getString(this.getIdentifier() + "sanka_jyoken"));
			this.setKanrisyaComment(rs.getString(this.getIdentifier() + "kanrisya_comment"));
			this.setAnnounce(rs.getString(this.getIdentifier() + "announce"));
			this.setSyoriJyokyoFlg(rs.getString(this.getIdentifier() + "syorijyokyo_flg"));
			this.setForumKaisetubi(rs.getString(this.getIdentifier() + "forum_kaisetubi"));
			this.setSimeiNo(rs.getString(this.getIdentifier() + "simei_no"));
			this.setKanjiSimei(rs.getString(this.getIdentifier() + "kanji_simei"));
			this.setSyozoku(rs.getString(this.getIdentifier() + "syozoku"));
			this.setMail(rs.getString(this.getIdentifier() + "mail"));
			this.setSinseibi(rs.getString(this.getIdentifier() + "sinseibi"));
			this.setSinseijikoku(rs.getString(this.getIdentifier() + "sinseijikoku"));
			this.setKousinsya(rs.getString(this.getIdentifier() + "kousinsya"));
			this.setKousinbi(rs.getString(this.getIdentifier() + "kousinbi"));
			this.setKousinjikoku(rs.getString(this.getIdentifier() + "kousinjikoku"));

			if (flg) {
				// �e�[�u���ɑ��݂��Ȃ��J�����Ȃ̂ŕK�v�ȏꍇ�̂ݐݒ�
				this.setId(rs.getString(this.getIdentifier() + "id"));
				this.setRecent(rs.getString(this.getIdentifier() + "recent"));
				this.setRecentJikoku(rs.getString(this.getIdentifier() + "recentjikoku"));
				this.setCount(rs.getString(this.getIdentifier() + "count"));
			}
		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		}
	}

	/**
	 * ServletRequest ����l���擾���ăt�H�[����ValueBean���쐬���܂��B
	 * @param request ���N�G�X�g
	 */
	public PEA_ForumBean(final ServletRequest request) {
		super(request);

		this.setForumId(request.getParameter("forum_id"));
		this.setForumMei(request.getParameter("forum_mei"));
		this.setForumGaiyo(request.getParameter("forum_gaiyo"));
		this.setSankaJyokenFlg(request.getParameter("sanka_jyoken_flg"));
		this.setSyokui(request.getParameter("syokui"));
		this.setSyokuiHani(request.getParameter("syokui_taisyo_hani"));
		this.setSyokuCode(0, request.getParameter("syoku_code1"));
		this.setSenmonCode(0, request.getParameter("senmon_code1"));
		this.setLevelCode(0, request.getParameter("level_code1"));
		this.setSkillHani(0, request.getParameter("skill_hani1"));
		this.setHyokaTaisyo(0, request.getParameter("hyoka_taisyo1"));
		this.setSougouTDo(0, request.getParameter("sougou_t_do1"));
		this.setTDoHani(0, request.getParameter("t_do_hani1"));
		this.setSyokuCode(1, request.getParameter("syoku_code2"));
		this.setSenmonCode(1, request.getParameter("senmon_code2"));
		this.setLevelCode(1, request.getParameter("level_code2"));
		this.setSkillHani(1, request.getParameter("skill_hani2"));
		this.setHyokaTaisyo(1, request.getParameter("hyoka_taisyo2"));
		this.setSougouTDo(1, request.getParameter("sougou_t_do2"));
		this.setTDoHani(1, request.getParameter("t_do_hani2"));
		this.setSyokuCode(2, request.getParameter("syoku_code3"));
		this.setSenmonCode(2, request.getParameter("senmon_code3"));
		this.setLevelCode(2, request.getParameter("level_code3"));
		this.setSkillHani(2, request.getParameter("skill_hani3"));
		this.setHyokaTaisyo(2, request.getParameter("hyoka_taisyo3"));
		this.setSougouTDo(2, request.getParameter("sougou_t_do3"));
		this.setTDoHani(2, request.getParameter("t_do_hani3"));
		this.setTaisyosyaSimeiNo(request.getParameter("taisyosya_simei_no"));
		this.setSankaJyoken(request.getParameter("sanka_jyoken"));
		this.setKanrisyaComment(request.getParameter("kanrisya_comment"));
		this.setAnnounce(request.getParameter("announce"));
		this.setSyoriJyokyoFlg(request.getParameter("syorijyokyo_flg"));
		this.setForumKaisetubi(request.getParameter("forum_kaisetubi"));
		this.setSimeiNo(request.getParameter("simei_no"));
		this.setKanjiSimei(request.getParameter("kanji_simei"));
		this.setSyozoku(request.getParameter("syozoku"));
		this.setMail(request.getParameter("mail"));
		this.setSinseibi(request.getParameter("sinseibi"));
		this.setSinseijikoku(request.getParameter("sinseijikoku"));
		this.setKousinsya(request.getParameter("kousinsya"));
		this.setKousinbi(request.getParameter("kousinbi"));
		this.setKousinjikoku(request.getParameter("kousinjikoku"));
	}

	/**
	 * �J�����̕ʖ����`���� SQL ����Ԃ��܂��B ���̃N���X�̃R���X�g���N�^�� ResultSet �������Ƃ��ēn�����ƂŁA �f�[�^���擾�ł��܂��B
	 * @param tableName �e�[�u���̕ʖ�
	 * @return �J�����̕ʖ����`���� SQL ��
	 * @see jp.co.hisas.career.learning.base.valuebean.PCY_MasterBean#getColumns(java.lang.String)
	 */
	public static String getColumns(final String tableName) {
		if (tableName == null) {
			return "*";
		}

		final StringBuffer ret = new StringBuffer();
		ret.append(tableName + ".forum_id as " + tableName + "_forum_id, ");
		ret.append(tableName + ".forum_mei as " + tableName + "_forum_mei, ");
		ret.append(tableName + ".forum_gaiyo as " + tableName + "_forum_gaiyo, ");
		ret.append(tableName + ".sanka_jyoken_flg as " + tableName + "_sanka_jyoken_flg, ");
		ret.append(tableName + ".syokui as " + tableName + "_syokui, ");
		ret.append(tableName + ".syokui_taisyo_hani as " + tableName + "_syokui_taisyo_hani, ");
		ret.append(tableName + ".syoku_code1 as " + tableName + "_syoku_code1, ");
		ret.append(tableName + ".senmon_code1 as " + tableName + "_senmon_code1, ");
		ret.append(tableName + ".level_code1 as " + tableName + "_level_code1, ");
		ret.append(tableName + ".skill_hani1 as " + tableName + "_skill_hani1, ");
		ret.append(tableName + ".hyoka_taisyo1 as " + tableName + "_hyoka_taisyo1, ");
		ret.append(tableName + ".sougou_t_do1 as " + tableName + "_sougou_t_do1, ");
		ret.append(tableName + ".t_do_hani1 as " + tableName + "_t_do_hani1, ");
		ret.append(tableName + ".syoku_code2 as " + tableName + "_syoku_code2, ");
		ret.append(tableName + ".senmon_code2 as " + tableName + "_senmon_code2, ");
		ret.append(tableName + ".level_code2 as " + tableName + "_level_code2, ");
		ret.append(tableName + ".skill_hani2 as " + tableName + "_skill_hani2, ");
		ret.append(tableName + ".hyoka_taisyo2 as " + tableName + "_hyoka_taisyo2, ");
		ret.append(tableName + ".sougou_t_do2 as " + tableName + "_sougou_t_do2, ");
		ret.append(tableName + ".t_do_hani2 as " + tableName + "_t_do_hani2, ");
		ret.append(tableName + ".syoku_code3 as " + tableName + "_syoku_code3, ");
		ret.append(tableName + ".senmon_code3 as " + tableName + "_senmon_code3, ");
		ret.append(tableName + ".level_code3 as " + tableName + "_level_code3, ");
		ret.append(tableName + ".skill_hani3 as " + tableName + "_skill_hani3, ");
		ret.append(tableName + ".hyoka_taisyo3 as " + tableName + "_hyoka_taisyo3, ");
		ret.append(tableName + ".sougou_t_do3 as " + tableName + "_sougou_t_do3, ");
		ret.append(tableName + ".t_do_hani3 as " + tableName + "_t_do_hani3, ");
		ret.append(tableName + ".taisyosya_simei_no as " + tableName + "_taisyosya_simei_no, ");
		ret.append(tableName + ".sanka_jyoken as " + tableName + "_sanka_jyoken, ");
		ret.append(tableName + ".kanrisya_comment as " + tableName + "_kanrisya_comment, ");
		ret.append(tableName + ".announce as " + tableName + "_announce, ");
		ret.append(tableName + ".syorijyokyo_flg as " + tableName + "_syorijyokyo_flg, ");
		ret.append(tableName + ".forum_kaisetubi as " + tableName + "_forum_kaisetubi, ");
		ret.append(tableName + ".simei_no as " + tableName + "_simei_no, ");
		ret.append(tableName + ".kanji_simei as " + tableName + "_kanji_simei, ");
		ret.append(tableName + ".syozoku as " + tableName + "_syozoku, ");
		ret.append(tableName + ".mail as " + tableName + "_mail, ");
		ret.append(tableName + ".sinseibi as " + tableName + "_sinseibi, ");
		ret.append(tableName + ".sinseijikoku as " + tableName + "_sinseijikoku, ");
		ret.append(tableName + ".kousinsya as " + tableName + "_kousinsya, ");
		ret.append(tableName + ".kousinbi as " + tableName + "_kousinbi, ");
		ret.append(tableName + ".kousinjikoku as " + tableName + "_kousinjikoku, ");
		return ret.toString() + PEA_MasterBean.getColumns(tableName);

	}

	/**
	 * <pre>
	 *     �t�H�[�����̌��������𒊏o���܂��B
	 *     �ȉ��̍��ڂ����������Ƃ��Ďg�p�ł��܂��B
	 *     �E�t�H�[����ID
	 *     �E�t�H�[������
	 *     �E�폜�t���O
	 *     �E����No
	 * </pre>
	 * 
	 * @return ���o���ꂽ��������
	 */
	public Map extractConditions() {
		final Map conditions = new LinkedHashMap();

		if (this.getForumId() != null && !this.getForumId().equals("")) {
			conditions.put("FORUM_ID", this.getForumId());
		}

		if (this.getForumMei() != null && !this.getForumMei().equals("")) {
			conditions.put("FORUM_MEI", this.getForumMei());
		}

		if (this.getSyoriJyokyoFlg() != null && !this.getSyoriJyokyoFlg().equals("")) {
			conditions.put("SYORIJYOKYO_FLG", this.getSyoriJyokyoFlg());
		}

		if (this.getSimeiNo() != null && !this.getSimeiNo().equals("")) {
			conditions.put("SIMEI_NO", this.getSimeiNo());
		}

		return conditions;
	}

	/**
	 * @return
	 */
	public String getAnnounce() {
		return this.announce;
	}

	/**
	 * @return
	 */
	public String getForumGaiyo() {
		return this.forumGaiyo;
	}

	/**
	 * @return
	 */
	public String getForumId() {
		return this.forumId;
	}

	/**
	 * @return
	 */
	public String getForumKaisetubi() {
		return this.forumKaisetubi;
	}

	/**
	 * @return
	 */
	public String getForumMei() {
		return this.forumMei;
	}

	/**
	 * @return
	 */
	public String getKanjiSimei() {
		return this.kanjiSimei;
	}

	/**
	 * @return
	 */
	public String getKanrisyaComment() {
		return this.kanrisyaComment;
	}

	/**
	 * @return
	 */
	public String getKousinbi() {
		return this.kousinbi;
	}

	/**
	 * @return
	 */
	public String getKousinjikoku() {
		return this.kousinjikoku;
	}

	/**
	 * @return
	 */
	public String getKousinsya() {
		return this.kousinsya;
	}

	/**
	 * @return
	 */
	public String getMail() {
		return this.mail;
	}

	/**
	 * @return
	 */
	public String getSankaJyoken() {
		return this.sankaJyoken;
	}

	/**
	 * @return
	 */
	public String getSankaJyokenFlg() {
		return this.sankaJyokenFlg;
	}

	/**
	 * @return
	 */
	public String getSimeiNo() {
		return this.simeiNo;
	}

	/**
	 * @return
	 */
	public String getSinseibi() {
		return this.sinseibi;
	}

	/**
	 * @return
	 */
	public String getSinseijikoku() {
		return this.sinseijikoku;
	}

	/**
	 * @return
	 */
	public String getSyokui() {
		return this.syokui;
	}

	/**
	 * @return
	 */
	public String getSyokuiHani() {
		return this.syokuiHani;
	}

	/**
	 * @return
	 */
	public String getSyoriJyokyoFlg() {
		return this.syoriJyokyoFlg;
	}

	/**
	 * @return
	 */
	public String getSyozoku() {
		return this.syozoku;
	}

	/**
	 * @return
	 */
	public String getTaisyosyaSimeiNo() {
		return this.taisyosyaSimeiNo;
	}

	/**
	 * @param string
	 */
	public void setAnnounce(final String string) {
		this.announce = string;
	}

	/**
	 * @param string
	 */
	public void setForumGaiyo(final String string) {
		this.forumGaiyo = string;
	}

	/**
	 * @param string
	 */
	public void setForumId(final String string) {
		this.forumId = string;
	}

	/**
	 * @param string
	 */
	public void setForumKaisetubi(final String string) {
		this.forumKaisetubi = string;
	}

	/**
	 * @param string
	 */
	public void setForumMei(final String string) {
		this.forumMei = string;
	}

	/**
	 * @param string
	 */
	public void setKanjiSimei(final String string) {
		this.kanjiSimei = string;
	}

	/**
	 * @param string
	 */
	public void setKanrisyaComment(final String string) {
		this.kanrisyaComment = string;
	}

	/**
	 * @param string
	 */
	public void setKousinbi(final String string) {
		this.kousinbi = string;
	}

	/**
	 * @param string
	 */
	public void setKousinjikoku(final String string) {
		this.kousinjikoku = string;
	}

	/**
	 * @param string
	 */
	public void setKousinsya(final String string) {
		this.kousinsya = string;
	}

	/**
	 * @param string
	 */
	public void setMail(final String string) {
		this.mail = string;
	}

	/**
	 * @param string
	 */
	public void setSankaJyoken(final String string) {
		this.sankaJyoken = string;
	}

	/**
	 * @param string
	 */
	public void setSankaJyokenFlg(final String string) {
		this.sankaJyokenFlg = string;
	}

	/**
	 * @param string
	 */
	public void setSimeiNo(final String string) {
		this.simeiNo = string;
	}

	/**
	 * @param string
	 */
	public void setSinseibi(final String string) {
		this.sinseibi = string;
	}

	/**
	 * @param string
	 */
	public void setSinseijikoku(final String string) {
		this.sinseijikoku = string;
	}

	/**
	 * @param string
	 */
	public void setSyokui(final String string) {
		this.syokui = string;
	}

	/**
	 * @param string
	 */
	public void setSyokuiHani(final String string) {
		this.syokuiHani = string;
	}

	/**
	 * @param string
	 */
	public void setSyoriJyokyoFlg(final String string) {
		this.syoriJyokyoFlg = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku(final String string) {
		this.syozoku = string;
	}

	/**
	 * @param string
	 */
	public void setTaisyosyaSimeiNo(final String string) {
		this.taisyosyaSimeiNo = string;
	}

	/**
	 * @return
	 */
	public String[] getHyokaTaisyoArry() {
		return this.hyokaTaisyoArry;
	}

	/**
	 * @return
	 */
	public String[] getLevelCodeArry() {
		return this.levelCodeArry;
	}

	/**
	 * @return
	 */
	public String[] getSenmonCodeArry() {
		return this.senmonCodeArry;
	}

	/**
	 * @return
	 */
	public String[] getSkillHaniArry() {
		return this.skillHaniArry;
	}

	/**
	 * @return
	 */
	public String[] getSougouTDoArry() {
		return this.sougouTDoArry;
	}

	/**
	 * @return
	 */
	public String[] getSyokuCodeArry() {
		return this.syokuCodeArry;
	}

	/**
	 * @return
	 */
	public String[] getTDoHaniArry() {
		return this.tDoHaniArry;
	}

	/**
	 * @param strings
	 */
	public void setHyokaTaisyoArry(final String[] strings) {
		this.hyokaTaisyoArry = strings;
	}

	/**
	 * @param strings
	 */
	public void setLevelCodeArry(final String[] strings) {
		this.levelCodeArry = strings;
	}

	/**
	 * @param strings
	 */
	public void setSenmonCodeArry(final String[] strings) {
		this.senmonCodeArry = strings;
	}

	/**
	 * @param strings
	 */
	public void setSkillHaniArry(final String[] strings) {
		this.skillHaniArry = strings;
	}

	/**
	 * @param strings
	 */
	public void setSougouTDoArry(final String[] strings) {
		this.sougouTDoArry = strings;
	}

	/**
	 * @param strings
	 */
	public void setSyokuCodeArry(final String[] strings) {
		this.syokuCodeArry = strings;
	}

	/**
	 * @param strings
	 */
	public void setTDoHaniArry(final String[] strings) {
		this.tDoHaniArry = strings;
	}

	/**
	 * @param index �Y��
	 * @param val �E��R�[�h
	 */
	public void setSyokuCode(final int index, final String val) {
		this.syokuCodeArry[index] = val;
	}

	/**
	 * @param index �Y��
	 * @param val ���R�[�h
	 */
	public void setSenmonCode(final int index, final String val) {
		this.senmonCodeArry[index] = val;
	}

	/**
	 * @param index �Y��
	 * @param val ���x���R�[�h
	 */
	public void setLevelCode(final int index, final String val) {
		this.levelCodeArry[index] = val;
	}

	/**
	 * @param index �Y��
	 * @param val �X�L���X�^���_�[�h����͈� 0�F�ȏ� 1�F���� 2�F�ȉ�
	 */
	public void setSkillHani(final int index, final String val) {
		this.skillHaniArry[index] = val;
	}

	/**
	 * @param index �Y��
	 * @param val �]���Ώ� 0�F���ȕ]�� 1�F�]���ҕ]��
	 */
	public void setHyokaTaisyo(final int index, final String val) {
		this.hyokaTaisyoArry[index] = val;
	}

	/**
	 * @param index �Y��
	 * @param val �����B���x
	 */
	public void setSougouTDo(final int index, final String val) {
		this.sougouTDoArry[index] = val;
	}

	/**
	 * @param index �Y��
	 * @param val �B���x�͈� 0�F�ȏ� 1�F���� 2�F�ȉ�
	 */
	public void setTDoHani(final int index, final String val) {
		this.tDoHaniArry[index] = val;
	}

	/**
	 * @param index �Y��
	 * @return �E��R�[�h
	 */
	public String getSyokuCode(final int index) {
		return this.syokuCodeArry[index];
	}

	/**
	 * @param index �Y��
	 * @return ���R�[�h
	 */
	public String getSenmonCode(final int index) {
		return this.senmonCodeArry[index];
	}

	/**
	 * @param index �Y��
	 * @return ���x���R�[�h
	 */
	public String getLevelCode(final int index) {
		return this.levelCodeArry[index];
	}

	/**
	 * @param index �Y��
	 * @return �X�L���X�^���_�[�h����͈� 0�F�ȏ� 1�F���� 2�F�ȉ�
	 */
	public String getSkillHani(final int index) {
		return this.skillHaniArry[index];
	}

	/**
	 * @param index �Y��
	 * @return �]���Ώ� 0�F���ȕ]�� 1�F�]���ҕ]��
	 */
	public String getHyokaTaisyo(final int index) {
		return this.hyokaTaisyoArry[index];
	}

	/**
	 * @param index �Y��
	 * @return �����B���x
	 */
	public String getSougouTDo(final int index) {
		return this.sougouTDoArry[index];
	}

	/**
	 * @param index �Y��
	 * @return �B���x�͈� 0�F�ȏ� 1�F���� 2�F�ȉ�
	 */
	public String getTDoHani(final int index) {
		return this.tDoHaniArry[index];
	}

	/**
	 * @return
	 */
	public String getCount() {
		return this.count;
	}

	/**
	 * @return
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * @return
	 */
	public String getRecent() {
		return this.recent;
	}

	/**
	 * @param string
	 */
	public void setCount(final String string) {
		this.count = string;
	}

	/**
	 * @param string
	 */
	public void setId(final String string) {
		this.id = string;
	}

	/**
	 * @param string
	 */
	public void setRecent(final String string) {
		this.recent = string;
	}

	/**
	 * @return
	 */
	public String getNotKeep() {
		return this.notKeep;
	}

	/**
	 * @return
	 */
	public String getPermission() {
		return this.permission;
	}

	/**
	 * @param string
	 */
	public void setNotKeep(final String string) {
		this.notKeep = string;
	}

	/**
	 * @param string
	 */
	public void setPermission(final String string) {
		this.permission = string;
	}

	/**
	 * @return
	 */
	public String getRecentJikoku() {
		return this.recentJikoku;
	}

	/**
	 * @param string
	 */
	public void setRecentJikoku(final String string) {
		this.recentJikoku = string;
	}

}
