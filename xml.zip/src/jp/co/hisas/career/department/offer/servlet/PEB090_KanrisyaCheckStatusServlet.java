/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.ejb.PEY_KouboEJB;
import jp.co.hisas.career.department.base.ejb.PEY_KouboEJBHome;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F �Ǘ��҉�ʃT�[�u���b�g�N���X �@�\�����F ������e�[�u�����f�[�^���擾����
 * 
 * </PRE>
 */
public class PEB090_KanrisyaCheckStatusServlet extends PEY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PEY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEY_KouboEJBHome home = (PEY_KouboEJBHome) fact.lookup(PEY_KouboEJBHome.class);
		final PEY_KouboEJB ejb = home.create();

		final String flg = request.getParameter("job_type");
		String url = "";

		/* �����������i�[���� */
		final PEY_KouboBean koubo_Beans = new PEY_KouboBean();
		koubo_Beans.setKouboankenid(request.getParameter("koubo_anken_id"));

		/* �f�[�^���擾���� */
		final PEY_KouboBean[] kouboBeans = ejb.doSelect(koubo_Beans, loginuser, null);

		if (kouboBeans == null || kouboBeans.length != 1) {
			// �G���[
		}

		if (flg.equals("0")) {
			if (!kouboBeans[0].getSyoristatus().equals(HcdbDef.D01_SINSATYU) && !kouboBeans[0].getSyoristatus().equals(HcdbDef.D01_KARISINSA_GOUKAKU)
					&& !kouboBeans[0].getSyoristatus().equals(HcdbDef.D01_KARISINSA_FUGOUKAKU)) {
				request.setAttribute("warningID", "WEB034");
				throw new PEY_WarningException();
			}
			url = this.getForwardPath();
		} else if (flg.equals("1")) {
			if (!kouboBeans[0].getSyoristatus().equals(HcdbDef.D01_KARISINSA_GOUKAKU) && !kouboBeans[0].getSyoristatus().equals(HcdbDef.D01_KARISINSA_FUGOUKAKU)) {
				request.setAttribute("warningID", "WEB035");
				throw new PEY_WarningException();
			}
			url = this.getForwardPath("successtuuti");
		}

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return url;
	}
}
