/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.bean;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X��: PEB_KanrisyaBean �N���X �@�\����: �Ǘ��҉�ʗp�f�[�^��ێ�����B
 * 
 * </PRE>
 */
public class PEB_KanrisyaBean extends PEY_KouboBean implements Serializable {

	private String simeiNo = "";

	private String gouhiStatus = "";

	public PEB_KanrisyaBean() {

	}

	public PEB_KanrisyaBean(final ResultSet rs, final String TableName) throws SQLException {

		super(rs, TableName);

		try {
			this.setSimeiNo(rs.getString(this.getIdentifier() + "SIMEI_NO"));
			this.setGouhiStatus(rs.getString(this.getIdentifier() + "GOUHI_STATUS"));
		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		}
	}

	/**
	 * @return
	 */
	public String getSimeiNo() {
		return this.simeiNo;
	}

	/**
	 * @param bean
	 */
	public void setSimeiNo(final String string) {
		this.simeiNo = string;
	}

	/**
	 * @return
	 */
	public String getGouhiStatus() {
		return this.gouhiStatus;
	}

	/**
	 * @param bean
	 */
	public void setGouhiStatus(final String string) {
		this.gouhiStatus = string;
	}

}
