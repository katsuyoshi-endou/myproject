/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */

package jp.co.hisas.career.util.pdf;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;

import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class PZE010_SyokusyuSetumeiPDF {
	/* ���O�C��No */
	private String login_no;

	private String[] syoku_yakuwari;

	private String[][] senmon_yakuwari;

	/* �O��������ږ� */
	private final String pram_syokusyu = (String) ReadFile.paramMapData.get("DZZ008");

	private final String pram_senmon_bunya = (String) ReadFile.paramMapData.get("DZZ009");

	/**
	 * �R���X�g���N�^
	 * 
	 * @param login_no
	 */
	public PZE010_SyokusyuSetumeiPDF(final String login_no) {
		this.login_no = login_no;
	}

	/**
	 * �o�͏����i�[����
	 * 
	 * @param syoku_yakuwari
	 * @param senmon_yakuwari
	 */
	public void setData(final String[] syoku_yakuwari, final String[][] senmon_yakuwari) {
		this.syoku_yakuwari = syoku_yakuwari;
		this.senmon_yakuwari = senmon_yakuwari;
	}

	/**
	 * PDF���쐬����
	 * 
	 * @param ops
	 * @throws Exception
	 */
	public void executePDF(final OutputStream ops) throws Exception {
		Log.method(this.login_no, "IN", "");
		/* �f�t�H���g�e�[�u���̐ݒ� */
		class MyTable extends Table {

			/**
			 * @param arg0
			 * @throws BadElementException
			 */
			public MyTable(final int arg0) throws BadElementException {
				super(arg0);
				this.setDefaultHorizontalAlignment(Element.ALIGN_LEFT);
				this.setDefaultVerticalAlignment(Element.ALIGN_MIDDLE);

				this.setPadding(2);
			}

		}

		/*
		 * Document�I�u�W�F�N�g�̐���
		 * A4�c�́ADocument document = new Document(PageSize.A4);
		 * A4���́ADocument document = new Document(PageSize.A4.rotate());
		 */
		final Document document = new Document(PageSize.A4);
		PdfWriter pw = null;

		try {
			/* PdfWriter�I�u�W�F�N�g�̐��� */
			pw = PdfWriter.getInstance(document, ops);
			pw.setCloseStream(true);

			/* �w�i�F */
			final Color BackColor = Color.white;

			/* �h�L�������g��OPEN */
			final HeaderFooter footer = new HeaderFooter(new Phrase("- "), new Phrase(" -"));
			footer.setBorderColor(BackColor);
			footer.setAlignment(Element.ALIGN_CENTER);
			document.setFooter(footer);
			document.open();

			/* �t�H���g�̐ݒ� */
			final float default_font_size = 10;
			final BaseFont bf = BaseFont.createFont("HeiseiMin-W3", "UniJIS-UCS2-HW-H", false);
			final Font font = new Font(bf, default_font_size);

			/* �P�s�X�y�[�X�̒�` */
			final Table space = new MyTable(1);
			space.setBorderColor(BackColor);
			space.addCell("");

			final int TableWidth = 100;

			/* �R���e���c�̋L�q */
			MyTable table;
			Cell cell;
			PdfPCell cellpdf = null;

			/* �E�� */
			final PdfPTable pTableSyokusyu = new PdfPTable(2);
			final int[] syokusyu_widths = { 20, 80 };
			pTableSyokusyu.setWidths(syokusyu_widths);
			pTableSyokusyu.setWidthPercentage(TableWidth);

			cellpdf = new PdfPCell(new Phrase(this.pram_syokusyu, font));
			cellpdf.setBorderColor(BackColor);
			cellpdf.setHorizontalAlignment(Element.ALIGN_CENTER);
			pTableSyokusyu.addCell(cellpdf);

			cellpdf = new PdfPCell(new Phrase(this.syoku_yakuwari[0] + "\n\n", font));
			cellpdf.setBorderColor(BackColor);
			pTableSyokusyu.addCell(cellpdf);

			document.add(pTableSyokusyu);

			/* �� */
			document.add(space);

			/* �E������ */
			table = new MyTable(1);
			table.setBorderColor(BackColor);
			table.setWidth(TableWidth);
			cell = new Cell(new Phrase(this.syoku_yakuwari[1], font));
			cell.setBorderColor(BackColor);
			table.addCell(cell);

			document.add(table);

			/* �� */
			document.add(space);

			/* ���� */
			table = new MyTable(1);
			table.setBorderColor(BackColor);
			table.setWidth(TableWidth);
			cell = new Cell(new Phrase("���Y" + this.pram_syokusyu + "�͈ȉ���" + this.pram_senmon_bunya + "�ɋ敪�����", font));
			cell.setBorderColor(BackColor);
			table.addCell(cell);

			document.add(table);

			/* �� */
			document.add(space);

			/* ��啪����� */
			for (int i = 0; i < this.senmon_yakuwari.length; i++) {
				/* �f�o�b�O���O���o�� */
				Log.debug(this.senmon_yakuwari[i][0] + ":" + this.senmon_yakuwari[i][1]);

				PdfPTable pTable = new PdfPTable(new float[] { 5.0f, 95.0f });
				pTable.getDefaultCell().setBorderColor(BackColor);
				pTable.setWidthPercentage(100.0f);

				PdfPCell pCell = new PdfPCell(new Phrase("��", font));
				pCell.setBorderColor(BackColor);
				pTable.addCell(pCell);

				pCell = new PdfPCell(new Phrase(this.senmon_yakuwari[i][0], font));
				pCell.setBorderColor(BackColor);
				pTable.addCell(pCell);

				pCell = new PdfPCell(new Phrase("", font));
				pCell.setBorderColor(BackColor);
				pTable.addCell(pCell);

				pCell = new PdfPCell(new Phrase(this.senmon_yakuwari[i][1], font));
				pCell.setBorderColor(BackColor);
				pTable.addCell(pCell);

				document.add(pTable);

				/* �� */
				document.add(space);
			}

		} catch (final BadElementException e) {
			Log.error(this.login_no, e);
			throw e;
		} catch (final DocumentException e) {
			Log.error(this.login_no, e);
			throw e;
		} catch (final IOException e) {
			Log.error(this.login_no, e);
			throw e;
		} catch (final Exception e) {
			Log.error(this.login_no, e);
			throw e;
		} finally {
			/* �h�L�������g����� */
			if (document != null) {
				try {
					document.close();
				} catch (final Exception e) {
					Log.error(this.login_no, e);
					throw e;
				}
			}
			if (pw != null) {
				try {
					pw.close();
				} catch (final Exception e) {
					Log.error(this.login_no, e);
					throw e;
				}
			}
		}
	}
}
