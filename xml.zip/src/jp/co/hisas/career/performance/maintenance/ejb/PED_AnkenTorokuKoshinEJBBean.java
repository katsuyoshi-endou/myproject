/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

public class PED_AnkenTorokuKoshinEJBBean implements SessionBean {

	private String login_no = "";

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}

	public void setSessionContext(final SessionContext arg0) throws EJBException, RemoteException {/* �������܂��� */
	}

	public void PED_AnkenTorokuKoshinBean(final String login_no) {
		this.login_no = login_no;
	}

	/**
	 * �ΏۃA���P�[�g�̏����擾����
	 * @param no
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public ArrayList getEnqueteInfo(final String no) throws SQLException, NamingException {
		final ArrayList ret = new ArrayList();
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		Log.method(this.login_no, "IN", "");
		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);
			final String sql = "SELECT * FROM " + HcdbDef.CPM_ENQUETE_TBL + " WHERE ENQUETE_NO = ?";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, no);
			rs = pstmt.executeQuery();

			rs.next();
			ret.add(rs.getString(1));
			ret.add(rs.getString(2));
			ret.add(rs.getString(3));
			ret.add(rs.getString(4));
			ret.add(rs.getString(5));
			ret.add(rs.getString(6));
			ret.add(rs.getString(7));
			ret.add(rs.getString(8));
			ret.add(rs.getString(9));
			ret.add(rs.getString(10));
			ret.add(rs.getString(11));
			ret.add(rs.getString(12));
			ret.add(rs.getString(13));
			ret.add(rs.getString(14));
			ret.add(rs.getString(15));
			ret.add(rs.getString(16));
			ret.add(rs.getString(17));

			Log.method(this.login_no, "OUT", "");

			return ret;
		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, rs);
		}

	}

	/**
	 * �A���P�[�g��V�K�쐬����
	 * @param eData
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String createEnquete(final ArrayList eData) throws SQLException, NamingException {
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		Log.method(this.login_no, "IN", "");

		try {
			// ���̎��_�ŊY���A���P�[�g�ԍ��̃f�[�^�����݂��Ȃ����`�F�b�N
			if (this.isDefinedEnquete((String) eData.get(0))) {
				return "false";
			}
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);
			String sql = "INSERT INTO " + HcdbDef.CPM_ENQUETE_TBL + " VALUES(?,?,?,?,?,?,?,2,?,?,?,0,?,?,?,?,?)";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			for (int cnt = 0; cnt < eData.size(); cnt++) {
				pstmt.setString(cnt + 1, (String) eData.get(cnt));
			}
			if (pstmt.executeUpdate() != 1) {
				return "false";
			}
			PZZ040_SQLUtility.closeConnection(this.login_no, null, pstmt, null);

			if (eData.get(7).equals("1")) {
				String sqlEdit = "SELECT distinct " + " ?," + " a.KOMOKU_CODE, " + " b.SHITSUMON_BUNSHO "
						+ " FROM (SELECT MIN(rowid) AS line, KOMOKU_CODE FROM CPM_SHITSUMON GROUP BY KOMOKU_CODE) a, " + " CPM_SHITSUMON b, " + " (SELECT " + "         MIN(rowid) AS line, "
						+ "         KOMOKU_CODE,BUNSEKI_CATEGORY_CODE " + "     FROM " + "         CPM_SHITSUMON_KANKEI " + "     GROUP BY " + "         KOMOKU_CODE,BUNSEKI_CATEGORY_CODE "
						+ "     ) CPM_SHITSUMON_KANKEI " + " WHERE b.KOMOKU_CODE=CPM_SHITSUMON_KANKEI.KOMOKU_CODE" + " AND a.line = b.rowid";

				String sqlEdit3 = " WHERE KOMOKU_CODE IN (SELECT " + " a.KOMOKU_CODE " + " FROM (SELECT MIN(rowid) AS line, KOMOKU_CODE FROM CPM_SHITSUMON GROUP BY KOMOKU_CODE) a, "
						+ " CPM_SHITSUMON b, " + " (SELECT " + "         MIN(rowid) AS line, " + "         KOMOKU_CODE,BUNSEKI_CATEGORY_CODE " + "     FROM " + "         CPM_SHITSUMON_KANKEI "
						+ "     GROUP BY " + "         KOMOKU_CODE,BUNSEKI_CATEGORY_CODE " + "     ) CPM_SHITSUMON_KANKEI " + " WHERE b.KOMOKU_CODE=CPM_SHITSUMON_KANKEI.KOMOKU_CODE"
						+ " AND a.line = b.rowid";

				String sqlEdit2 = "";
				boolean sqlFlg = false;

				if (eData.get(10).equals("1")) {
					// �`�[���R���f�B�V�����}�b�v��ON�̂Ƃ�
					sqlEdit2 += "CPM_SHITSUMON_KANKEI.BUNSEKI_CATEGORY_CODE LIKE 'Performance%'";
					sqlFlg = true;
				}
				if (eData.get(11).equals("1")) {
					if (sqlEdit2.length() > 0) {
						sqlEdit2 += " OR ";
					}
					// �`�[���R���f�B�V�����}�b�v��ON�̂Ƃ�
					sqlEdit2 += "CPM_SHITSUMON_KANKEI.BUNSEKI_CATEGORY_CODE LIKE 'BusinessMind%'";
					sqlFlg = true;

				}
				if (eData.get(12).equals("1")) {
					if (sqlEdit2.length() > 0) {
						sqlEdit2 += " OR ";
					}
					// �`�[���R���f�B�V�����}�b�v��ON�̂Ƃ�
					sqlEdit2 += "CPM_SHITSUMON_KANKEI.BUNSEKI_CATEGORY_CODE LIKE 'Style%'";
					sqlFlg = true;

				}
				if (eData.get(13).equals("1")) {
					if (sqlEdit2.length() > 0) {
						sqlEdit2 += " OR ";
					}
					// �`�[���R���f�B�V�����}�b�v��ON�̂Ƃ�
					sqlEdit2 += "CPM_SHITSUMON_KANKEI.BUNSEKI_CATEGORY_CODE LIKE 'ES%'";
					sqlFlg = true;

				}
				if (eData.get(14).equals("1")) {
					if (sqlEdit2.length() > 0) {
						sqlEdit2 += " OR ";
					}
					// �`�[���R���f�B�V�����}�b�v��ON�̂Ƃ�
					sqlEdit2 += "CPM_SHITSUMON_KANKEI.BUNSEKI_CATEGORY_CODE LIKE 'Competency%'";
					sqlFlg = true;

				}

				if (sqlFlg == true) {
					sqlEdit += " AND (";
					sqlEdit2 += " )";
					sqlEdit3 += " AND (";
				} else {
					sqlEdit3 = "";
				}

				sqlEdit += sqlEdit2;
				sqlEdit3 += sqlEdit2 + ")";
				// �p�t�H�[�}���X���͑Ή����R�[�h�쐬
				// �A���P�[�g����}�X�^�e�[�u���Ƀ��R�[�h�ǉ�
				sql = "INSERT INTO CPM_ENQUETE_SHITSUMON (ENQUETE_NO,KOMOKU_CD,SHITSUMON_BUNSHO) " + sqlEdit;
				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				pstmt.setString(1, (String) eData.get(0));
				pstmt.executeUpdate();
				pstmt.close();

				// ���ڐ���e�[�u���Ƀ��R�[�h�ǉ�
				sql = "INSERT INTO CPP_KOMOKU_SEIGYO" + " SELECT ?,GAMEN_ID,GAMEN_KOMOKU_ID,KOMOKU_CODE,HYOJI_JUNJO,OBJECT_TYPE,KAITO_SU,DEFAULT_VALUE,HISSU FROM CPP_KOMOKU_SEIGYO_MASTER" + sqlEdit3;
				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				pstmt.setString(1, (String) eData.get(0));
				pstmt.executeUpdate();
				pstmt.close();
			}

			Log.method(this.login_no, "OUT", "");

			return "true";

		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, null);
		}

	}

	/**
	 * �A���P�[�g���X�V����
	 * @param eData
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String updateEnquete(final ArrayList eData) throws SQLException, NamingException {
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		Log.method(this.login_no, "IN", "");

		try {
			final String no = (String) eData.get(0);
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);
			final String sql = "UPDATE " + HcdbDef.CPM_ENQUETE_TBL + " SET ENQUETE_BUNRUI_NO = ?," + "ENQUETE_NAME = ?," + "KAITO_KAISHI_NENGAPPI = ?," + "KAITOSHURYO_NENGAPPI = ?,"
					+ "KAITO_KAISHI_JIKOKU = ?," + "KAITOSHURYO_JIKOKU = ?," + "SANSHUTSU_FLG = ?," + "ENQUETE_COMMENT = ?" + " WHERE ENQUETE_NO = ?";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			for (int cnt = 1; cnt < eData.size(); cnt++) {
				pstmt.setString(cnt, (String) eData.get(cnt));
			}
			pstmt.setString(eData.size(), no);
			Log.method(this.login_no, "OUT", "");

			return pstmt.executeUpdate() == 1 ? "true" : "false";

		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, null);
		}

	}

	/**
	 * �ΏۃA���P�[�g�����݂��邩���ׂ�
	 * @param no
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public boolean isDefinedEnquete(final String no) throws SQLException, NamingException {
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Log.method(this.login_no, "IN", "");

		try {
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);
			final String sql = "SELECT COUNT(*) FROM " + HcdbDef.CPM_ENQUETE_TBL + " WHERE ENQUETE_NO = ?";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, no);

			rs = pstmt.executeQuery();

			rs.next();

			final String result = rs.getString(1);

			if (result.equals("0")) {
				Log.method(this.login_no, "OUT", "");

				return false;
			} else {
				Log.method(this.login_no, "OUT", "");

				return true;
			}
		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * �A���P�[�g�X�e�[�^�X���擾
	 * @param no �ΏۃA���P�[�g�i���o�[
	 * @return String�X�e�[�^�X�i���o�[
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String getStatus(final String no) throws SQLException, NamingException {
		Log.method(this.login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);

			// �����ΏۃA���P�[�g�̌��݂̃X�e�[�^�X���擾
			final String sql = "SELECT (SELECT COUNT(*) FROM CPM_ENQUETE WHERE ENQUETE_NO = CPM1.ENQUETE_NO) CNT, STATUS FROM  CPM_ENQUETE CPM1 WHERE ENQUETE_NO = ?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, no);
			rs = pstmt.executeQuery();

			// �ΏۃA���P�[�g�̌��݂̃X�e�[�^�X
			rs.next();

			final int cnt = Integer.parseInt(rs.getString("CNT"));
			if (cnt < 1) {
				// �ΏۃA���P�[�g�����݂��Ȃ�
				return "false";
			}

			Log.method(this.login_no, "OUT", "");

			return rs.getString("STATUS");
		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, rs);
		}
	}

}
