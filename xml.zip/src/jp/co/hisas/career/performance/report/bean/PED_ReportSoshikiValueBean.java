/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.report.bean;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * ���|�[�g�o��Bean
 * @author �Β�
 */
public class PED_ReportSoshikiValueBean implements Serializable {

	/** �g�D�h�c */
	private String groupID;

	/** �g�D�R�[�h */
	private String soshikiCode;

	/** �g�D���̘A�� */
	private String soshikiName;

	/** �W�v�l�� */
	private String shukeiCount;

	/** �\���Ј���� */
	private ArrayList shainBeanList;

	/** �`�[���R���f�B�V�����}�b�v�o�c�e */
	private TeamCondition teamCondition;

	/** �`�[���R���f�B�V�����}�b�v�o�c�e */
	private BusinessMind businessMind;

	/** �`�[���R���f�B�V�����}�b�v�o�c�e */
	private LeaderTraits leaderTraits;

	/** �g�D�����x����PDF */
	private SoshikiManzoku soshikiManzoku;

	/** ���^�R���s�e���V�[PDF */
	private MetaCompetency metaCompetency;

	/** ��1�K�w�}����� */
	private String yakushoku1_hanrei;

	/** ��2�K�w�}����� */
	private String yakushoku2_hanrei;

	/** ��3�K�w�}����� */
	private String yakushoku3_hanrei;

	/** ��4�K�w�}����� */
	private String yakushoku4_hanrei;

	/** ��5�K�w�}����� */
	private String yakushoku5_hanrei;

	/** ��6�K�w�}����� */
	private String yakushoku6_hanrei;

	/**
	 * �R���X�g���N�^�B�o�c�e�\���f�[�^��������
	 */
	public PED_ReportSoshikiValueBean() {

		// �`�[���R���f�B�V�����}�b�v�o�c�e
		this.teamCondition = new TeamCondition();
		// �`�[���R���f�B�V�����}�b�v�o�c�e
		this.businessMind = new BusinessMind();
		// �`�[���R���f�B�V�����}�b�v�o�c�e
		this.leaderTraits = new LeaderTraits();
		// �g�D�����x����PDF
		this.soshikiManzoku = new SoshikiManzoku();
		// ���^�R���s�e���V�[PDF
		this.metaCompetency = new MetaCompetency();

	}

	public String getGroupID() {
		return this.groupID;
	}

	public void setGroupID(final String groupID) {
		this.groupID = groupID;
	}

	public String getShukeiCount() {
		return this.shukeiCount;
	}

	public void setShukeiCount(final String shukeiCount) {
		this.shukeiCount = shukeiCount;
	}

	public String getSoshikiCode() {
		return this.soshikiCode;
	}

	public void setSoshikiCode(final String soshikiCode) {
		this.soshikiCode = soshikiCode;
	}

	public String getSoshikiName() {
		return this.soshikiName;
	}

	public void setSoshikiName(final String soshikiName) {
		this.soshikiName = soshikiName;
	}

	public String getYakushoku1_hanrei() {
		return this.yakushoku1_hanrei;
	}

	public void setYakushoku1_hanrei(final String yakushoku1_hanrei) {
		this.yakushoku1_hanrei = yakushoku1_hanrei;
	}

	public String getYakushoku2_hanrei() {
		return this.yakushoku2_hanrei;
	}

	public void setYakushoku2_hanrei(final String yakushoku2_hanrei) {
		this.yakushoku2_hanrei = yakushoku2_hanrei;
	}

	public String getYakushoku3_hanrei() {
		return this.yakushoku3_hanrei;
	}

	public void setYakushoku3_hanrei(final String yakushoku3_hanrei) {
		this.yakushoku3_hanrei = yakushoku3_hanrei;
	}

	public String getYakushoku4_hanrei() {
		return this.yakushoku4_hanrei;
	}

	public void setYakushoku4_hanrei(final String yakushoku4_hanrei) {
		this.yakushoku4_hanrei = yakushoku4_hanrei;
	}

	public String getYakushoku5_hanrei() {
		return this.yakushoku5_hanrei;
	}

	public void setYakushoku5_hanrei(final String yakushoku5_hanrei) {
		this.yakushoku5_hanrei = yakushoku5_hanrei;
	}

	public String getYakushoku6_hanrei() {
		return this.yakushoku6_hanrei;
	}

	public void setYakushoku6_hanrei(final String yakushoku6_hanrei) {
		this.yakushoku6_hanrei = yakushoku6_hanrei;
	}

	public BusinessMind getBusinessMind() {
		return this.businessMind;
	}

	public void setBusinessMind(final BusinessMind businessMind) {
		this.businessMind = businessMind;
	}

	public LeaderTraits getLeaderTraits() {
		return this.leaderTraits;
	}

	public void setLeaderTraits(final LeaderTraits leaderTraits) {
		this.leaderTraits = leaderTraits;
	}

	public ArrayList getShainBeanList() {
		return this.shainBeanList;
	}

	public void setShainBeanList(final ArrayList shainBeanList) {
		this.shainBeanList = shainBeanList;
	}

	public TeamCondition getTeamCondition() {
		return this.teamCondition;
	}

	public void setTeamCondition(final TeamCondition teamCondition) {
		this.teamCondition = teamCondition;
	}

	/**
	 * @return Returns the soshikiManzoku.
	 */
	public SoshikiManzoku getSoshikiManzoku() {
		return this.soshikiManzoku;
	}

	/**
	 * @param soshikiManzoku The soshikiManzoku to set.
	 */
	public void setSoshikiManzoku(final SoshikiManzoku soshikiManzoku) {
		this.soshikiManzoku = soshikiManzoku;
	}

	/**
	 * @return Returns the metaCompetency.
	 */
	public MetaCompetency getMetaCompetency() {
		return this.metaCompetency;
	}

	/**
	 * @param metaCompetency The metaCompetency to set.
	 */
	public void setMetaCompetency(final MetaCompetency metaCompetency) {
		this.metaCompetency = metaCompetency;
	}

	/** �`�[���R���f�B�V�����}�b�v�o�c�e */
	public class TeamCondition implements Serializable {
		/** ���[�_�[�̕��ϒm�I�\�͔����x */
		private String leaderAvgChitekinoryoku;

		/** ���[�_�[�̕��σ��[�L���O���`�x�[�V���� */
		private String leaderAvgWorkingmotivation;

		/** ���[�_�[�̐l�� */
		private String leaderSu;

		/** ���[�_�[�̕��σp�t�H�[�}���X�]�[�� */
		private String leaderAvgPerformance;

		/** �����o�[�̕��ϒm�I�\�͔����x */
		private String memberAvgChitekinoryoku;

		/** �����o�[�̕��σ��[�L���O���`�x�[�V���� */
		private String memberAvgWorkingMotivation;

		/** �����o�[�̐l�� */
		private String memberSu;

		/** �����o�[�̕��σp�t�H�[�}���X�]�[�� */
		private String memberAvgPerformance;

		/** �g�D�̕��ϒm�I�\�͔����x */
		private String soshikiAvgChitekinoryoku;

		/** �g�D�̒m�I�\�͔����x�̕W���΍� */
		private String soshikiHyojunChitekinoryoku;

		/** �g�D�̕��σ��[�L���O���`�x�[�V���� */
		private String soshikiAvgWorkingMotivation;

		/** �g�D�̃��[�L���O���`�x�[�V�����̕W���΍� */
		private String soshikiHyojunWorkingMtv;

		/** �g�D�̐l�� */
		private String soshikiSu = "0";

		/** �g�D�̎U��΂� */
		private String soshikiSanpu;

		/** �g�D�^�C�v */
		private String soshikiType;

		/** �`�[���R���f�B�V�����]�[��A���� */
		private String teamConditionZoneARate = "0";

		/** �`�[���R���f�B�V�����]�[��A�l�� */
		private String teamConditionZoneASu = "0";

		/** �`�[���R���f�B�V�����]�[��B���� */
		private String teamConditionZoneBRate = "0";

		/** �`�[���R���f�B�V�����]�[��B�l�� */
		private String teamConditionZoneBSu = "0";

		/** �`�[���R���f�B�V�����]�[��C���� */
		private String teamConditionZoneCRate = "0";

		/** �`�[���R���f�B�V�����]�[��C�l�� */
		private String teamConditionZoneCSu = "0";

		/** �`�[���R���f�B�V�����]�[��D���� */
		private String teamConditionZoneDRate = "0";

		/** �`�[���R���f�B�V�����]�[��D�l�� */
		private String teamConditionZoneDSu = "0";

		/** ���� */
		private String setsumei;

		public String getSetsumei() {
			return this.setsumei;
		}

		public void setSetsumei(final String setsumei) {
			this.setsumei = setsumei;
		}

		public String getLeaderAvgChitekinoryoku() {
			return this.leaderAvgChitekinoryoku;
		}

		public void setLeaderAvgChitekinoryoku(final String leaderAvgChitekinoryoku) {
			this.leaderAvgChitekinoryoku = leaderAvgChitekinoryoku;
		}

		public String getLeaderAvgPerformance() {
			return this.leaderAvgPerformance;
		}

		public void setLeaderAvgPerformance(final String leaderAvgPerformance) {
			this.leaderAvgPerformance = leaderAvgPerformance;
		}

		public String getLeaderAvgWorkingmotivation() {
			return this.leaderAvgWorkingmotivation;
		}

		public void setLeaderAvgWorkingmotivation(final String leaderAvgWorkingmotivation) {
			this.leaderAvgWorkingmotivation = leaderAvgWorkingmotivation;
		}

		public String getLeaderSu() {
			return this.leaderSu;
		}

		public void setLeaderSu(final String leaderSu) {
			this.leaderSu = leaderSu;
		}

		public String getMemberAvgChitekinoryoku() {
			return this.memberAvgChitekinoryoku;
		}

		public void setMemberAvgChitekinoryoku(final String memberAvgChitekinoryoku) {
			this.memberAvgChitekinoryoku = memberAvgChitekinoryoku;
		}

		public String getMemberAvgPerformance() {
			return this.memberAvgPerformance;
		}

		public void setMemberAvgPerformance(final String memberAvgPerformance) {
			this.memberAvgPerformance = memberAvgPerformance;
		}

		public String getMemberAvgWorkingMotivation() {
			return this.memberAvgWorkingMotivation;
		}

		public void setMemberAvgWorkingMotivation(final String memberAvgWorkingMotivation) {
			this.memberAvgWorkingMotivation = memberAvgWorkingMotivation;
		}

		public String getMemberSu() {
			return this.memberSu;
		}

		public void setMemberSu(final String memberSu) {
			this.memberSu = memberSu;
		}

		public String getSoshikiAvgChitekinoryoku() {
			return this.soshikiAvgChitekinoryoku;
		}

		public void setSoshikiAvgChitekinoryoku(final String soshikiAvgChitekinoryoku) {
			this.soshikiAvgChitekinoryoku = soshikiAvgChitekinoryoku;
		}

		public String getSoshikiAvgWorkingMotivation() {
			return this.soshikiAvgWorkingMotivation;
		}

		public void setSoshikiAvgWorkingMotivation(final String soshikiAvgWorkingMotivation) {
			this.soshikiAvgWorkingMotivation = soshikiAvgWorkingMotivation;
		}

		public String getSoshikiHyojunChitekinoryoku() {
			return this.soshikiHyojunChitekinoryoku;
		}

		public void setSoshikiHyojunChitekinoryoku(final String soshikiHyojunChitekinoryoku) {
			this.soshikiHyojunChitekinoryoku = soshikiHyojunChitekinoryoku;
		}

		public String getSoshikiHyojunWorkingMtv() {
			return this.soshikiHyojunWorkingMtv;
		}

		public void setSoshikiHyojunWorkingMtv(final String soshikiHyojunWorkingMtv) {
			this.soshikiHyojunWorkingMtv = soshikiHyojunWorkingMtv;
		}

		public String getSoshikiSanpu() {
			return this.soshikiSanpu;
		}

		public void setSoshikiSanpu(final String soshikiSanpu) {
			this.soshikiSanpu = soshikiSanpu;
		}

		public String getSoshikiSu() {
			return this.soshikiSu;
		}

		public void setSoshikiSu(final String soshikiSu) {
			this.soshikiSu = soshikiSu;
		}

		public String getSoshikiType() {
			return this.soshikiType;
		}

		public void setSoshikiType(final String soshikiType) {
			this.soshikiType = soshikiType;
		}

		public String getTeamConditionZoneARate() {
			return this.teamConditionZoneARate;
		}

		public void setTeamConditionZoneARate(final String teamConditionZoneARate) {
			this.teamConditionZoneARate = teamConditionZoneARate;
		}

		public String getTeamConditionZoneASu() {
			return this.teamConditionZoneASu;
		}

		public void setTeamConditionZoneASu(final String teamConditionZoneASu) {
			this.teamConditionZoneASu = teamConditionZoneASu;
		}

		public String getTeamConditionZoneBRate() {
			return this.teamConditionZoneBRate;
		}

		public void setTeamConditionZoneBRate(final String teamConditionZoneBRate) {
			this.teamConditionZoneBRate = teamConditionZoneBRate;
		}

		public String getTeamConditionZoneBSu() {
			return this.teamConditionZoneBSu;
		}

		public void setTeamConditionZoneBSu(final String teamConditionZoneBSu) {
			this.teamConditionZoneBSu = teamConditionZoneBSu;
		}

		public String getTeamConditionZoneCRate() {
			return this.teamConditionZoneCRate;
		}

		public void setTeamConditionZoneCRate(final String teamConditionZoneCRate) {
			this.teamConditionZoneCRate = teamConditionZoneCRate;
		}

		public String getTeamConditionZoneCSu() {
			return this.teamConditionZoneCSu;
		}

		public void setTeamConditionZoneCSu(final String teamConditionZoneCSu) {
			this.teamConditionZoneCSu = teamConditionZoneCSu;
		}

		public String getTeamConditionZoneDRate() {
			return this.teamConditionZoneDRate;
		}

		public void setTeamConditionZoneDRate(final String teamConditionZoneDRate) {
			this.teamConditionZoneDRate = teamConditionZoneDRate;
		}

		public String getTeamConditionZoneDSu() {
			return this.teamConditionZoneDSu;
		}

		public void setTeamConditionZoneDSu(final String teamConditionZoneDSu) {
			this.teamConditionZoneDSu = teamConditionZoneDSu;
		}

	}

	/** �r�W�l�X�}�C���h�}�b�v�o�c�e */
	public class BusinessMind implements Serializable {
		/** �l�����^�C�v���� */
		private String kojinSeichoTypeRate = "0";

		/** �l�����^�C�v�l�� */
		private String kojinSeichoTypeSu = "0";

		/** �l����^�C�v���� */
		private String kojinAnteiTypeRate = "0";

		/** �l����^�C�v�l�� */
		private String kojinAnteiTypeSu = "0";

		/** �g�D�����^�C�v���� */
		private String soshikiSeichoTypeRate = "0";

		/** �g�D�����^�C�v�l�� */
		private String soshikiSeichoTypeSu = "0";

		/** �g�D����^�C�v���� */
		private String soshikiAnteiTypeRate = "0";

		/** �g�D����^�C�v�l�� */
		private String soshikiAnteiTypeSu = "0";

		/** �g�D�^�C�v */
		private String soshikiType;

		/** �g�D�̐l�� */
		private String soshikiSu = "0";

		/** ���� */
		private String setsumei;

		public String getSetsumei() {
			return this.setsumei;
		}

		public void setSetsumei(final String setsumei) {
			this.setsumei = setsumei;
		}

		public String getKojinAnteiTypeRate() {
			return this.kojinAnteiTypeRate;
		}

		public void setKojinAnteiTypeRate(final String kojinAnteiTypeRate) {
			this.kojinAnteiTypeRate = kojinAnteiTypeRate;
		}

		public String getKojinAnteiTypeSu() {
			return this.kojinAnteiTypeSu;
		}

		public void setKojinAnteiTypeSu(final String kojinAnteiTypeSu) {
			this.kojinAnteiTypeSu = kojinAnteiTypeSu;
		}

		public String getKojinSeichoTypeRate() {
			return this.kojinSeichoTypeRate;
		}

		public void setKojinSeichoTypeRate(final String kojinSeichoTypeRate) {
			this.kojinSeichoTypeRate = kojinSeichoTypeRate;
		}

		public String getKojinSeichoTypeSu() {
			return this.kojinSeichoTypeSu;
		}

		public void setKojinSeichoTypeSu(final String kojinSeichoTypeSu) {
			this.kojinSeichoTypeSu = kojinSeichoTypeSu;
		}

		public String getSoshikiAnteiTypeRate() {
			return this.soshikiAnteiTypeRate;
		}

		public void setSoshikiAnteiTypeRate(final String soshikiAnteiTypeRate) {
			this.soshikiAnteiTypeRate = soshikiAnteiTypeRate;
		}

		public String getSoshikiAnteiTypeSu() {
			return this.soshikiAnteiTypeSu;
		}

		public void setSoshikiAnteiTypeSu(final String soshikiAnteiTypeSu) {
			this.soshikiAnteiTypeSu = soshikiAnteiTypeSu;
		}

		public String getSoshikiSeichoTypeRate() {
			return this.soshikiSeichoTypeRate;
		}

		public void setSoshikiSeichoTypeRate(final String soshikiSeichoTypeRate) {
			this.soshikiSeichoTypeRate = soshikiSeichoTypeRate;
		}

		public String getSoshikiSeichoTypeSu() {
			return this.soshikiSeichoTypeSu;
		}

		public void setSoshikiSeichoTypeSu(final String soshikiSeichoTypeSu) {
			this.soshikiSeichoTypeSu = soshikiSeichoTypeSu;
		}

		public String getSoshikiSu() {
			return this.soshikiSu;
		}

		public void setSoshikiSu(final String soshikiSu) {
			this.soshikiSu = soshikiSu;
		}

		public String getSoshikiType() {
			return this.soshikiType;
		}

		public void setSoshikiType(final String soshikiType) {
			this.soshikiType = soshikiType;
		}

	}

	/** ���[�_�V�b�v�����}�b�v�o�c�e */
	public class LeaderTraits implements Serializable {
		/** ���[�_�[�V�b�v�]�[��A���� */
		private String leadershipZoneARate = "0";

		/** ���[�_�[�V�b�v�]�[��A�l�� */
		private String leadershipZoneASu = "0";

		/** ���[�_�[�V�b�v�]�[��B���� */
		private String leadershipZoneBRate = "0";

		/** ���[�_�[�V�b�v�]�[��B�l�� */
		private String leadershipZoneBSu = "0";

		/** ���[�_�[�V�b�v�]�[��C���� */
		private String leadershipZoneCRate = "0";

		/** ���[�_�[�V�b�v�]�[��C�l�� */
		private String leadershipZoneCSu = "0";

		/** ���[�_�[�V�b�v�]�[��D���� */
		private String leadershipZoneDRate = "0";

		/** ���[�_�[�V�b�v�]�[��D�l�� */
		private String leadershipZoneDSu = "0";

		/** ���[�_�[�V�b�v�]�[��E���� */
		private String leadershipZoneERate = "0";

		/** ���[�_�[�V�b�v�]�[��E�l�� */
		private String leadershipZoneESu = "0";

		/** �g�D�̐l�� */
		private String soshikiSu = "0";

		public String getLeadershipZoneARate() {
			return this.leadershipZoneARate;
		}

		public void setLeadershipZoneARate(final String leadershipZoneARate) {
			this.leadershipZoneARate = leadershipZoneARate;
		}

		public String getLeadershipZoneASu() {
			return this.leadershipZoneASu;
		}

		public void setLeadershipZoneASu(final String leadershipZoneASu) {
			this.leadershipZoneASu = leadershipZoneASu;
		}

		public String getLeadershipZoneBRate() {
			return this.leadershipZoneBRate;
		}

		public void setLeadershipZoneBRate(final String leadershipZoneBRate) {
			this.leadershipZoneBRate = leadershipZoneBRate;
		}

		public String getLeadershipZoneBSu() {
			return this.leadershipZoneBSu;
		}

		public void setLeadershipZoneBSu(final String leadershipZoneBSu) {
			this.leadershipZoneBSu = leadershipZoneBSu;
		}

		public String getLeadershipZoneCRate() {
			return this.leadershipZoneCRate;
		}

		public void setLeadershipZoneCRate(final String leadershipZoneCRate) {
			this.leadershipZoneCRate = leadershipZoneCRate;
		}

		public String getLeadershipZoneCSu() {
			return this.leadershipZoneCSu;
		}

		public void setLeadershipZoneCSu(final String leadershipZoneCSu) {
			this.leadershipZoneCSu = leadershipZoneCSu;
		}

		public String getLeadershipZoneDRate() {
			return this.leadershipZoneDRate;
		}

		public void setLeadershipZoneDRate(final String leadershipZoneDRate) {
			this.leadershipZoneDRate = leadershipZoneDRate;
		}

		public String getLeadershipZoneDSu() {
			return this.leadershipZoneDSu;
		}

		public void setLeadershipZoneDSu(final String leadershipZoneDSu) {
			this.leadershipZoneDSu = leadershipZoneDSu;
		}

		public String getSoshikiSu() {
			return this.soshikiSu;
		}

		public void setSoshikiSu(final String soshikiSu) {
			this.soshikiSu = soshikiSu;
		}

		/**
		 * @return Returns the leadershipZoneERate.
		 */
		public String getLeadershipZoneERate() {
			return this.leadershipZoneERate;
		}

		/**
		 * @param leadershipZoneERate The leadershipZoneERate to set.
		 */
		public void setLeadershipZoneERate(final String leadershipZoneERate) {
			this.leadershipZoneERate = leadershipZoneERate;
		}

		/**
		 * @return Returns the leadershipZoneESu.
		 */
		public String getLeadershipZoneESu() {
			return this.leadershipZoneESu;
		}

		/**
		 * @param leadershipZoneESu The leadershipZoneESu to set.
		 */
		public void setLeadershipZoneESu(final String leadershipZoneESu) {
			this.leadershipZoneESu = leadershipZoneESu;
		}

	}

	/**
	 * �g�D�����x����PDF
	 * @author s_torigoe
	 */
	public class SoshikiManzoku implements Serializable {

		/** ��Е��� */
		private ArrayList kaishaAvg = new ArrayList();

		/** �g�D���� */
		private ArrayList soshikiAvg = new ArrayList();

		/** �E�ʊK�w1 */
		private ArrayList kaiso1Avg = new ArrayList();

		/** �E�ʊK�w2 */
		private ArrayList kaiso2Avg = new ArrayList();

		/** �E�ʊK�w3 */
		private ArrayList kaiso3Avg = new ArrayList();

		/** �E�ʊK�w4 */
		private ArrayList kaiso4Avg = new ArrayList();

		/** �E�ʊK�w5 */
		private ArrayList kaiso5Avg = new ArrayList();

		/** �E�ʊK�w6 */
		private ArrayList kaiso6Avg = new ArrayList();

		/** �g�D�̐l�� */
		private String sosikiSu = "0";

		/**
		 * �R���X�g���N�^ ����������
		 */
		public SoshikiManzoku() {
			for (int i = 0; i < 43; i++) {
				this.kaishaAvg.add("");
				this.soshikiAvg.add("");
				this.kaiso1Avg.add("");
				this.kaiso2Avg.add("");
				this.kaiso3Avg.add("");
				this.kaiso4Avg.add("");
				this.kaiso5Avg.add("");
				this.kaiso6Avg.add("");
			}
		}

		/**
		 * @return Returns the kaisoAvg.
		 */
		public ArrayList getKaisoAvg() {
			final ArrayList kaisoAvg = new ArrayList();
			kaisoAvg.add(this.kaiso1Avg);
			kaisoAvg.add(this.kaiso2Avg);
			kaisoAvg.add(this.kaiso3Avg);
			kaisoAvg.add(this.kaiso4Avg);
			kaisoAvg.add(this.kaiso5Avg);
			kaisoAvg.add(this.kaiso6Avg);
			return kaisoAvg;
		}

		/**
		 * @return Returns the kaishaAvg.
		 */
		public ArrayList getKaishaAvg() {
			return this.kaishaAvg;
		}

		/**
		 * @param kaishaAvg The kaishaAvg to set.
		 */
		public void setKaishaAvg(final ArrayList kaishaAvg) {
			this.kaishaAvg = kaishaAvg;
		}

		/**
		 * @return Returns the kaiso1Avg.
		 */
		public ArrayList getKaiso1Avg() {
			return this.kaiso1Avg;
		}

		/**
		 * @param kaiso1Avg The kaiso1Avg to set.
		 */
		public void setKaiso1Avg(final ArrayList kaiso1Avg) {
			this.kaiso1Avg = kaiso1Avg;
		}

		/**
		 * @return Returns the kaiso2Avg.
		 */
		public ArrayList getKaiso2Avg() {
			return this.kaiso2Avg;
		}

		/**
		 * @param kaiso2Avg The kaiso2Avg to set.
		 */
		public void setKaiso2Avg(final ArrayList kaiso2Avg) {
			this.kaiso2Avg = kaiso2Avg;
		}

		/**
		 * @return Returns the kaiso3Avg.
		 */
		public ArrayList getKaiso3Avg() {
			return this.kaiso3Avg;
		}

		/**
		 * @param kaiso3Avg The kaiso3Avg to set.
		 */
		public void setKaiso3Avg(final ArrayList kaiso3Avg) {
			this.kaiso3Avg = kaiso3Avg;
		}

		/**
		 * @return Returns the kaiso4Avg.
		 */
		public ArrayList getKaiso4Avg() {
			return this.kaiso4Avg;
		}

		/**
		 * @param kaiso4Avg The kaiso4Avg to set.
		 */
		public void setKaiso4Avg(final ArrayList kaiso4Avg) {
			this.kaiso4Avg = kaiso4Avg;
		}

		/**
		 * @return Returns the kaiso5Avg.
		 */
		public ArrayList getKaiso5Avg() {
			return this.kaiso5Avg;
		}

		/**
		 * @param kaiso5Avg The kaiso5Avg to set.
		 */
		public void setKaiso5Avg(final ArrayList kaiso5Avg) {
			this.kaiso5Avg = kaiso5Avg;
		}

		/**
		 * @return Returns the kaiso6Avg.
		 */
		public ArrayList getKaiso6Avg() {
			return this.kaiso6Avg;
		}

		/**
		 * @param kaiso6Avg The kaiso6Avg to set.
		 */
		public void setKaiso6Avg(final ArrayList kaiso6Avg) {
			this.kaiso6Avg = kaiso6Avg;
		}

		/**
		 * @return Returns the soshikiAvg.
		 */
		public ArrayList getSoshikiAvg() {
			return this.soshikiAvg;
		}

		/**
		 * @param soshikiAvg The soshikiAvg to set.
		 */
		public void setSoshikiAvg(final ArrayList soshikiAvg) {
			this.soshikiAvg = soshikiAvg;
		}

		/**
		 * @return Returns the sosikiSu.
		 */
		public String getSosikiSu() {
			return this.sosikiSu;
		}

		/**
		 * @param sosikiSu The sosikiSu to set.
		 */
		public void setSosikiSu(final String sosikiSu) {
			this.sosikiSu = sosikiSu;
		}

	}

	/**
	 * ���^�R���s�e���V�[PDF
	 * @author s_torigoe
	 */
	public class MetaCompetency implements Serializable {

		/** �g�D�̐l�� */
		private String soshikiSu = "0";

		/** �B�� */
		private float tassei = 0f;

		/** �ϋɐ� */
		private float sekkyokusei = 0f;

		/** �p�b�V���� */
		private float passion = 0f;

		/** �Z���t�R���g���[�� */
		private float selfControl = 0f;

		/** ���M */
		private float jisin = 0f;

		/** �ΐl�e���� */
		private float taijinEikyoryoku = 0f;

		/** �`�[�����[�N */
		private float teamWork = 0f;

		/** �琬�E�����w�� */
		private float ikusei = 0f;

		/** �ΐl���� */
		private float taijinRikai = 0f;

		/** �v���� */
		private float kokensei = 0f;

		/** ���X�N�e�C�N */
		private float riskTake = 0f;

		/** �ۑ�\�z�� */
		private float kadaiKotikuryoku = 0f;

		/** ���f�� */
		private float ketudanryoku = 0f;

		/** ���͗� */
		private float bunsekiryoku = 0f;

		/** �󋵑Ή��� */
		private float jokyoTaiouryoku = 0f;

		/** �󋵗���� */
		private float jokyoRikairyoku = 0f;

		/**
		 * @return Returns the bunsekiryoku.
		 */
		public float getBunsekiryoku() {
			return this.bunsekiryoku;
		}

		/**
		 * @param bunsekiryoku The bunsekiryoku to set.
		 */
		public void setBunsekiryoku(final float bunsekiryoku) {
			this.bunsekiryoku = bunsekiryoku;
		}

		/**
		 * @return Returns the ikusei.
		 */
		public float getIkusei() {
			return this.ikusei;
		}

		/**
		 * @param ikusei The ikusei to set.
		 */
		public void setIkusei(final float ikusei) {
			this.ikusei = ikusei;
		}

		/**
		 * @return Returns the jisin.
		 */
		public float getJisin() {
			return this.jisin;
		}

		/**
		 * @param jisin The jisin to set.
		 */
		public void setJisin(final float jisin) {
			this.jisin = jisin;
		}

		/**
		 * @return Returns the jokyoRikairyoku.
		 */
		public float getJokyoRikairyoku() {
			return this.jokyoRikairyoku;
		}

		/**
		 * @param jokyoRikairyoku The jokyoRikairyoku to set.
		 */
		public void setJokyoRikairyoku(final float jokyoRikairyoku) {
			this.jokyoRikairyoku = jokyoRikairyoku;
		}

		/**
		 * @return Returns the jokyoTaiouryoku.
		 */
		public float getJokyoTaiouryoku() {
			return this.jokyoTaiouryoku;
		}

		/**
		 * @param jokyoTaiouryoku The jokyoTaiouryoku to set.
		 */
		public void setJokyoTaiouryoku(final float jokyoTaiouryoku) {
			this.jokyoTaiouryoku = jokyoTaiouryoku;
		}

		/**
		 * @return Returns the kadaiKotikuryoku.
		 */
		public float getKadaiKotikuryoku() {
			return this.kadaiKotikuryoku;
		}

		/**
		 * @param kadaiKotikuryoku The kadaiKotikuryoku to set.
		 */
		public void setKadaiKotikuryoku(final float kadaiKotikuryoku) {
			this.kadaiKotikuryoku = kadaiKotikuryoku;
		}

		/**
		 * @return Returns the ketudanryoku.
		 */
		public float getKetudanryoku() {
			return this.ketudanryoku;
		}

		/**
		 * @param ketudanryoku The ketudanryoku to set.
		 */
		public void setKetudanryoku(final float ketudanryoku) {
			this.ketudanryoku = ketudanryoku;
		}

		/**
		 * @return Returns the kokensei.
		 */
		public float getKokensei() {
			return this.kokensei;
		}

		/**
		 * @param kokensei The kokensei to set.
		 */
		public void setKokensei(final float kokensei) {
			this.kokensei = kokensei;
		}

		/**
		 * @return Returns the passion.
		 */
		public float getPassion() {
			return this.passion;
		}

		/**
		 * @param passion The passion to set.
		 */
		public void setPassion(final float passion) {
			this.passion = passion;
		}

		/**
		 * @return Returns the riskTake.
		 */
		public float getRiskTake() {
			return this.riskTake;
		}

		/**
		 * @param riskTake The riskTake to set.
		 */
		public void setRiskTake(final float riskTake) {
			this.riskTake = riskTake;
		}

		/**
		 * @return Returns the sekkyokusei.
		 */
		public float getSekkyokusei() {
			return this.sekkyokusei;
		}

		/**
		 * @param sekkyokusei The sekkyokusei to set.
		 */
		public void setSekkyokusei(final float sekkyokusei) {
			this.sekkyokusei = sekkyokusei;
		}

		/**
		 * @return Returns the selfControl.
		 */
		public float getSelfControl() {
			return this.selfControl;
		}

		/**
		 * @param selfControl The selfControl to set.
		 */
		public void setSelfControl(final float selfControl) {
			this.selfControl = selfControl;
		}

		/**
		 * @return Returns the soshikiSu.
		 */
		public String getSoshikiSu() {
			return this.soshikiSu;
		}

		/**
		 * @param soshikiSu The soshikiSu to set.
		 */
		public void setSoshikiSu(final String soshikiSu) {
			this.soshikiSu = soshikiSu;
		}

		/**
		 * @return Returns the taijinEikyoryoku.
		 */
		public float getTaijinEikyoryoku() {
			return this.taijinEikyoryoku;
		}

		/**
		 * @param taijinEikyoryoku The taijinEikyoryoku to set.
		 */
		public void setTaijinEikyoryoku(final float taijinEikyoryoku) {
			this.taijinEikyoryoku = taijinEikyoryoku;
		}

		/**
		 * @return Returns the taijinRikai.
		 */
		public float getTaijinRikai() {
			return this.taijinRikai;
		}

		/**
		 * @param taijinRikai The taijinRikai to set.
		 */
		public void setTaijinRikai(final float taijinRikai) {
			this.taijinRikai = taijinRikai;
		}

		/**
		 * @return Returns the tassei.
		 */
		public float getTassei() {
			return this.tassei;
		}

		/**
		 * @param tassei The tassei to set.
		 */
		public void setTassei(final float tassei) {
			this.tassei = tassei;
		}

		/**
		 * @return Returns the teamWork.
		 */
		public float getTeamWork() {
			return this.teamWork;
		}

		/**
		 * @param teamWork The teamWork to set.
		 */
		public void setTeamWork(final float teamWork) {
			this.teamWork = teamWork;
		}

	}

}
