/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.analysis.report.bean;

import java.util.ArrayList;

public class PEF_JinzaiPortfolioValueBean {

	/** �������X�g */
	private ArrayList soshikiList = null;

	/** �A�Z�X�����g���ԃ��X�g */
	private ArrayList assessmentKikanList = null;

	/** �L�����A�`�������W���ԑI�� */
	private String assessment = "";

	/** �����I�� */
	private String busho = "";

	public PEF_JinzaiPortfolioValueBean() {
		this.soshikiList = new ArrayList();
		this.assessmentKikanList = new ArrayList();
	}

	/**
	 * @return soshikiList ��߂��܂��B
	 */
	public ArrayList getSoshikiList() {
		return this.soshikiList;
	}

	/**
	 * @param soshikiList �ݒ肷�� soshikiList�B
	 */
	public void setSoshikiList(final ArrayList soshikiList) {
		this.soshikiList = soshikiList;
	}

	/**
	 * @return busho ��߂��܂��B
	 */
	public String getBusho() {
		return this.busho;
	}

	/**
	 * @param busho �ݒ肷�� busho�B
	 */
	public void setBusho(final String busho) {
		this.busho = busho;
	}

	// --- 20070117 K.takagi Add Sta ---
	/**
	 * @return assessmentKikanList ��߂��܂��B
	 */
	public ArrayList getAssessmentKikanList() {
		return this.assessmentKikanList;
	}

	/**
	 * @param assessmentKikanList �ݒ肷�� assessmentKikanList�B
	 */
	public void setAssessmentKikanList(final ArrayList assessmentKikanList) {
		this.assessmentKikanList = assessmentKikanList;
	}

	/**
	 * @return assessment ��߂��܂��B
	 */
	public String getAssessment() {
		return this.assessment;
	}

	/**
	 * @param assessment �ݒ肷�� assessment�B
	 */
	public void setAssessment(final String assessment) {
		this.assessment = assessment;
	}
	// --- 20070117 K.takagi Add End ---

}
