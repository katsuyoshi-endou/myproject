/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.analysis.report.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.analysis.report.bean.PEF_MoralSurveyReportPDFValueBean;
import jp.co.hisas.career.analysis.report.bean.PEF_MoralSurveyReportValueBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

public class PEF_MoralSurveyReportEJBBean implements SessionBean {

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException {/* �������܂��� */
	}

	public void setSessionContext(final SessionContext arg0) throws EJBException, RemoteException {/* �������܂��� */
	}

	/** �����[���T�[�x�C�Ώۑg�D�K�w���� */
	private static final String MORAL_KAGEN_KAISO_KEY = "MORALESURVEY_SOSIKI_KAISO_MIN";

	/** �����[���T�[�x�C�Ώۑg�D�K�w��� */
	private static final String MORAL_JOGEN_KAISO_KEY = "MORALESURVEY_SOSIKI_KAISO_MAX";

	/** �����[���T�[�x�C���� */
	private static final String MORAL_BUNRUI = "Base";

	/** �����Ԃ�\���t���O */
	private static final String TOKIKAN_FLG = "1";

	/** �I����e�ő吔 */
	private static final int MAX_SENTAKU_NAIYO = 51;

	/** �I����e������ */
	private static final String SENTAKU_NAIYO = "SENTAKU_NAIYO_";

	/** �I����e�O���ԕ����� */
	private static final String PRE_SENTAKU_NAIYO = "PRE_SENTAKU_NAIYO_";

	/** �����[���T�[�x�C�f�[�^�擾�ő�K�w */
	private static final String MAX_KAISO = "2";

	/**
	 * �S�Ќ����̏ꍇ�S�g�D���擾�i�v���_�E�����X�g�j
	 * @param loginNo
	 * @return ArrayList �g�D���X�g
	 */
	public ArrayList getAllSoshiki(final String loginNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		final ArrayList soshikiList = new ArrayList();

		// PRT_START
		String prtStart = null;
		// PRT_END
		String prtEnd = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// PRT_START�̎擾
			String sql = "SELECT " + HcdbDef.CCP_PARAM_COLUMNS[2] + " FROM " + HcdbDef.CCP_PARAM_TBL + " WHERE " + HcdbDef.CCP_PARAM_COLUMNS[0] + "=? AND " + HcdbDef.CCP_PARAM_COLUMNS[1] + "=?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, PEF_MoralSurveyReportEJBBean.MORAL_BUNRUI);
			pstmt.setString(2, PEF_MoralSurveyReportEJBBean.MORAL_KAGEN_KAISO_KEY);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				prtStart = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
			// PRT_END�̎擾
			sql = "SELECT " + HcdbDef.CCP_PARAM_COLUMNS[2] + " FROM " + HcdbDef.CCP_PARAM_TBL + " WHERE " + HcdbDef.CCP_PARAM_COLUMNS[0] + "=? AND " + HcdbDef.CCP_PARAM_COLUMNS[1] + "=?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, PEF_MoralSurveyReportEJBBean.MORAL_BUNRUI);
			pstmt.setString(2, PEF_MoralSurveyReportEJBBean.MORAL_JOGEN_KAISO_KEY);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				prtEnd = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
			}
			// ��U�J��
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			// �p�����[�^��NULL�̏ꍇ���Ԃ�
			if (prtStart == null || prtEnd == null) {
				return soshikiList;
			}

			// CHG#073 2007/02/02 k-genma start
			sql = "SELECT " + HcdbDef.T19_SOSIKI_COLUMNS[0] + "," + HcdbDef.T19_SOSIKI_COLUMNS[2] + " FROM " + HcdbDef.sosikiTbl + " WHERE " + HcdbDef.T19_SOSIKI_COLUMNS[4]
					+ " BETWEEN ? AND ? ORDER BY " + HcdbDef.T19_SOSIKI_COLUMNS[0];
			// CHG#073 2007/02/02 k-genma end

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setInt(1, Integer.parseInt(prtStart));
			pstmt.setInt(2, Integer.parseInt(prtEnd));
			rs = pstmt.executeQuery();
			String[] tmp = new String[2];
			while (rs.next()) {
				tmp = new String[2];
				tmp[0] = rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[0]);
				tmp[1] = rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[2]); // CHG#073 2007/02/02 k-genma

				tmp[0] = tmp[0] != null ? tmp[0] : "";
				tmp[1] = tmp[1] != null ? tmp[1] : "";

				soshikiList.add(tmp);
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			Log.method(loginNo, "OUT", "");
			return soshikiList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �z�������̏ꍇ���O�C�����[�U�̏����g�D����ђ����g�D���擾�i�v���_�E�����X�g�j
	 * @param loginNo
	 * @param soshikiCode
	 * @return ArrayList �g�D���X�g
	 */
	public ArrayList getHaikaSoshiki(final String loginNo, final String soshikiCode) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		final ArrayList soshikiList = new ArrayList();

		// PRT_START
		String prtStart = null;
		// PRT_END
		String prtEnd = null;

		if (soshikiCode == null) {
			return new ArrayList();
		}
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// PRT_START�̎擾
			String sql = "SELECT " + HcdbDef.CCP_PARAM_COLUMNS[2] + " FROM " + HcdbDef.CCP_PARAM_TBL + " WHERE " + HcdbDef.CCP_PARAM_COLUMNS[0] + "=? AND " + HcdbDef.CCP_PARAM_COLUMNS[1] + "=?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, PEF_MoralSurveyReportEJBBean.MORAL_BUNRUI);
			pstmt.setString(2, PEF_MoralSurveyReportEJBBean.MORAL_KAGEN_KAISO_KEY);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				prtStart = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
			// PRT_END�̎擾
			sql = "SELECT " + HcdbDef.CCP_PARAM_COLUMNS[2] + " FROM " + HcdbDef.CCP_PARAM_TBL + " WHERE " + HcdbDef.CCP_PARAM_COLUMNS[0] + "=? AND " + HcdbDef.CCP_PARAM_COLUMNS[1] + "=?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, PEF_MoralSurveyReportEJBBean.MORAL_BUNRUI);
			pstmt.setString(2, PEF_MoralSurveyReportEJBBean.MORAL_JOGEN_KAISO_KEY);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				prtEnd = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
			}
			// �p�����[�^��NULL�̏ꍇ���Ԃ�
			if (prtStart == null || prtEnd == null) {
				return soshikiList;
			}
			// ��U�J��
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			// ���O�I�����[�U�̑g�D�R�[�h�擾
			// CHG#073 2007/02/02 k-genma start
			sql = "SELECT " + HcdbDef.T19_SOSIKI_COLUMNS[0] + "," + HcdbDef.T19_SOSIKI_COLUMNS[2] + "  FROM " + HcdbDef.sosikiTbl + " WHERE " + HcdbDef.T19_SOSIKI_COLUMNS[0] + "=? AND "
					+ HcdbDef.T19_SOSIKI_COLUMNS[4] + " BETWEEN ? AND ?";
			// CHG#073 2007/02/02 k-genma end

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, soshikiCode);
			pstmt.setInt(2, Integer.parseInt(prtStart));
			pstmt.setInt(3, Integer.parseInt(prtEnd));
			rs = pstmt.executeQuery();
			if (rs.next()) {
				final String[] tmp = new String[2];
				tmp[0] = rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[0]);
				tmp[1] = rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[2]); // CHG#073 2007/02/02 k-genma

				tmp[0] = tmp[0] != null ? tmp[0] : "";
				tmp[1] = tmp[1] != null ? tmp[1] : "";
				soshikiList.add(tmp);
			} else {
				return new ArrayList();
			}
			// ��U�J��
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			// CHG#073 2007/02/02 k-genma start
			sql = "SELECT " + HcdbDef.T19_SOSIKI_COLUMNS[0] + "," + HcdbDef.T19_SOSIKI_COLUMNS[2] + "  FROM " + HcdbDef.sosikiTbl + " WHERE " + HcdbDef.T19_SOSIKI_COLUMNS[4] + " BETWEEN ? AND ? AND "
					+ HcdbDef.T19_SOSIKI_COLUMNS[3] + "=? ORDER BY " + HcdbDef.T19_SOSIKI_COLUMNS[0] + " ASC";
			// CHG#073 2007/02/02 k-genma start

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setInt(1, Integer.parseInt(prtStart));
			pstmt.setInt(2, Integer.parseInt(prtEnd));
			pstmt.setString(3, soshikiCode);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				final String[] tmp = new String[2];
				tmp[0] = rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[0]);
				tmp[1] = rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[2]); // CHG#073 2007/02/02 k-genma

				tmp[0] = tmp[0] != null ? tmp[0] : "";
				tmp[1] = tmp[1] != null ? tmp[1] : "";
				if (!tmp[0].equals(soshikiCode)) {
					soshikiList.add(tmp);
				}
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			if (soshikiList.size() == 0) {
				return new ArrayList();
			}
			Log.method(loginNo, "OUT", "");
			return soshikiList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �A�Z�X�����g���Ԃ̎擾
	 * @param loginNo
	 * @return ArrayList �A�Z�X�����g���Ԃ̃��X�g
	 */
	public ArrayList getAssessmentKikanList(final String loginNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		final ArrayList assessmentKikanList = new ArrayList();

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			final String sql = " SELECT P33.SYURYO_NENGAPPI, P33.ASSESSMENT_KIKAN_MEI, P33.SEIGYO_NO, P33.KAISI_NENGAPPI, P33.KEIKAKU_KIKAN_MEI FROM "
					+ " P33_CAREER_CHALLENGE_KIKAN_TBL P33, ( SELECT SEIGYO_NO FROM P33_CAREER_CHALLENGE_KIKAN_TBL  WHERE "
					+ " TOKIKAN_FLG = ? ) TOKIKAN WHERE TOKIKAN.SEIGYO_NO >= P33.SEIGYO_NO ORDER BY P33.SEIGYO_NO DESC ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, PEF_MoralSurveyReportEJBBean.TOKIKAN_FLG);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				final String seigyoNo = PZZ010_CharacterUtil.normalizedStr(rs.getString("SEIGYO_NO"));
				final String kaisiNgp = PZZ010_CharacterUtil.normalizedStr(rs.getString("KAISI_NENGAPPI"));
				final String shuryoNgp = PZZ010_CharacterUtil.normalizedStr(rs.getString("SYURYO_NENGAPPI"));
				final String kikanNm = PZZ010_CharacterUtil.normalizedStr(rs.getString("ASSESSMENT_KIKAN_MEI"));
				final String keikaku = PZZ010_CharacterUtil.normalizedStr(rs.getString("KEIKAKU_KIKAN_MEI"));

				assessmentKikanList.add(new String[] { seigyoNo, kaisiNgp, shuryoNgp, kikanNm, keikaku });
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			Log.method(loginNo, "OUT", "");
			return assessmentKikanList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �V�X�e���p�����[�^���擾
	 * @param loginNo
	 * @param bunrui ���ޖ���
	 * @param id �p�����[�^ID
	 * @return String �l
	 */
	public String getSystemParameter(final String loginNo, final String bunrui, final String id) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String value = "";

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// PRT_START�̎擾
			final String sql = "SELECT " + HcdbDef.CCP_PARAM_COLUMNS[2] + " FROM " + HcdbDef.CCP_PARAM_TBL + " WHERE " + HcdbDef.CCP_PARAM_COLUMNS[0] + "=? AND " + HcdbDef.CCP_PARAM_COLUMNS[1] + "=?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, bunrui);
			pstmt.setString(2, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				value = rs.getString(HcdbDef.CCP_PARAM_COLUMNS[2]);
			}
			Log.method(loginNo, "OUT", "");
			return value;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �����[���O���[�v�}�X�^����O���[�v�R�[�h�A���̂��擾����
	 * @param loginNo ���O�C��NO
	 * @return ArrayList �O���[�v�R�[�h�A���̂̃��X�g
	 */
	public ArrayList getMoralGroupMaster(final String loginNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		final ArrayList moralList = new ArrayList();

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			final String sql = "SELECT " + HcdbDef.CKM_MORAL_GROUP_COLUMNS[0] + "," + HcdbDef.CKM_MORAL_GROUP_COLUMNS[1] + " FROM " + HcdbDef.CKM_MORAL_GROUP_TBL + " ORDER BY "
					+ HcdbDef.CKM_MORAL_GROUP_COLUMNS[0];

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			rs = pstmt.executeQuery();
			String[] tmp = new String[2];
			while (rs.next()) {
				tmp = new String[2];
				tmp[0] = rs.getString(HcdbDef.CKM_MORAL_GROUP_COLUMNS[0]);
				tmp[1] = rs.getString(HcdbDef.CKM_MORAL_GROUP_COLUMNS[1]);

				tmp[0] = tmp[0] != null ? tmp[0] : "";
				tmp[1] = tmp[1] != null ? tmp[1] : "";

				moralList.add(tmp);
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			Log.method(loginNo, "OUT", "");
			return moralList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �����[���}�X�^���烂���[���R�[�h�A���̂��擾����
	 * @param loginNo ���O�C��NO
	 * @param moralCode �����[���O���[�v�R�[�h
	 * @return ArrayList �O���[�v�R�[�h�A���̂̃��X�g
	 */
	public ArrayList getMoralMaster(final String loginNo, final String moralCode) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		final ArrayList moralList = new ArrayList();

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			final String sql = " SELECT " + " B.MORAL_CODE AS code,B.MORAL_RYAKUSYO_MEI AS name" + " FROM " + " 	CKG_MORAL_GROUP A,P10_C_MORAL_KOMOKU_TBL B " + " WHERE "
					+ " 	A.MORAL_GROUP_CODE = ? AND " + " 	B.MORAL_CODE = A.MORAL_CODE " + " ORDER BY " + " 	B.MORAL_CODE ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, moralCode);
			rs = pstmt.executeQuery();
			String[] tmp = new String[2];
			while (rs.next()) {
				tmp = new String[2];
				tmp[0] = rs.getString("code");
				tmp[1] = rs.getString("name");

				tmp[0] = tmp[0] != null ? tmp[0] : "";
				tmp[1] = tmp[1] != null ? tmp[1] : "";

				moralList.add(tmp);
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			Log.method(loginNo, "OUT", "");
			return moralList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * PDF�쐬�p�f�[�^�擾(�g�D�p)
	 * @param logiNo ���O�C���Ј��ԍ�
	 * @param moralBean ���[�U���͏��
	 * @return PEF_MoralSurveyReportPDFValueBean PDF�쐬�p�f�[�^
	 */
	public PEF_MoralSurveyReportPDFValueBean getPDFDataSoshiki(final String loginNo, final PEF_MoralSurveyReportValueBean moralBean) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		final String busho = moralBean.getBusho();
		final PEF_MoralSurveyReportPDFValueBean valueBean = new PEF_MoralSurveyReportPDFValueBean();
		final HashMap nestSoshikiMap = new HashMap();
		final ArrayList sortSoshikiList = new ArrayList();

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			String sql = "SELECT " + HcdbDef.T19_SOSIKI_COLUMNS[0] + "," + HcdbDef.T19_SOSIKI_COLUMNS[3] + "," + HcdbDef.T19_SOSIKI_COLUMNS[2] + "  FROM ("
					+ " SELECT A.sosiki_code, A.joui_sosiki_code,A.busyo_ryakusyo_mei" + " FROM T19_SOSIKI_TBL A, (SELECT * FROM T19_SOSIKI_TBL WHERE "
					+ " SOSIKI_CODE=?) B WHERE A.KAISOU - B.KAISOU <= ?" + ") START WITH  " + HcdbDef.T19_SOSIKI_COLUMNS[0] + "=?" + " CONNECT BY PRIOR " + HcdbDef.T19_SOSIKI_COLUMNS[0] + "="
					+ HcdbDef.T19_SOSIKI_COLUMNS[3] + " ORDER SIBLINGS BY " + HcdbDef.T19_SOSIKI_COLUMNS[0] + " ASC";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, busho);
			pstmt.setString(2, PEF_MoralSurveyReportEJBBean.MAX_KAISO);
			pstmt.setString(3, busho);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String sosikiCode = rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[0]);
				String sosikiNm = rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[2]);
				String jouiSosikiCode = rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[3]);

				sosikiCode = sosikiCode != null ? sosikiCode : "";
				sosikiNm = sosikiNm != null ? sosikiNm : "";
				jouiSosikiCode = jouiSosikiCode != null ? jouiSosikiCode : "";
				sortSoshikiList.add(new String[] { sosikiCode, sosikiNm });
				nestSoshikiMap.put(sosikiCode, jouiSosikiCode);
			}
			valueBean.setNestSoshikiMap(nestSoshikiMap);
			valueBean.setSortSoshikiList(sortSoshikiList);
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
			final HashMap sosikiDataMap = new HashMap();
			// �g�D�����[�v
			for (int j = 0, num = sortSoshikiList.size(); j < num; j++) {
				final String sosiki = ((String[]) sortSoshikiList.get(j))[0];

				sql = " SELECT " + " * " + " FROM ( " + " SELECT ";
				sql += " 	ROUND(AVG(SENTAKU_NAIYO_" + 1 + "),2) AS SENTAKU_NAIYO_" + 1 + " ";
				for (int i = 1; i < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; i++) {
					sql += ", 	ROUND(AVG(SENTAKU_NAIYO_" + (i + 1) + "),2) AS SENTAKU_NAIYO_" + (i + 1) + " ";
				}

				sql += " , count(*) as cnt FROM P32_MORAL_SURVEY_TBL WHERE KIKAN_MEI = ? AND SINDANSYA IN ( "
						+ " SELECT SIMEI_NO FROM T01_PERSONAL_TBL WHERE SOSIKI_CODE IN ( SELECT SOSIKI_CODE FROM "
						+ " T19_SOSIKI_TBL START WITH  sosiki_code=? CONNECT BY PRIOR sosiki_code=joui_sosiki_code) AND " + " HONMU_FLG = '1' AND GENSYOKU_TAISYOKU_FLG = '1' ) " + " ) A, ( "
						+ " SELECT ";
				sql += " ROUND(AVG(SENTAKU_NAIYO_" + 1 + "),2) AS PRE_SENTAKU_NAIYO_" + 1 + " ";
				for (int i = 1; i < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; i++) {
					sql += ", ROUND(AVG(SENTAKU_NAIYO_" + (i + 1) + "),2) AS PRE_SENTAKU_NAIYO_" + (i + 1) + "";
				}

				sql += " FROM P32_MORAL_SURVEY_TBL WHERE KIKAN_MEI = ( SELECT KEIKAKU_KIKAN_MEI FROM " + " P33_CAREER_CHALLENGE_KIKAN_TBL WHERE SEIGYO_NO = ( SELECT max(SEIGYO_NO) FROM "
						+ " P33_CAREER_CHALLENGE_KIKAN_TBL WHERE SEIGYO_NO < ( SELECT SEIGYO_NO FROM " + " P33_CAREER_CHALLENGE_KIKAN_TBL WHERE KEIKAKU_KIKAN_MEI = ?)) ) AND SINDANSYA IN ( "
						+ " SELECT SIMEI_NO FROM T01_PERSONAL_TBL WHERE SOSIKI_CODE IN ( SELECT SOSIKI_CODE FROM "
						+ " T19_SOSIKI_TBL START WITH  sosiki_code=? CONNECT BY PRIOR sosiki_code=joui_sosiki_code ) AND " + " HONMU_FLG = '1' AND GENSYOKU_TAISYOKU_FLG = '1') ) ";

				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				int nowPos = 1;
				final String[] kikan = moralBean.getAssessmentKikan();
				pstmt.setString(nowPos, kikan[4]);
				nowPos++;
				pstmt.setString(nowPos, sosiki);
				nowPos++;
				pstmt.setString(nowPos, kikan[4]);
				nowPos++;
				pstmt.setString(nowPos, sosiki);
				nowPos++;
				rs = pstmt.executeQuery();

				ArrayList dataList = null;
				ArrayList preDataList = null;
				int groupNum = 0;
				while (rs.next()) {
					dataList = new ArrayList();
					preDataList = new ArrayList();
					// ������
					for (int i = 0; i < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; i++) {
						String data = rs.getString(PEF_MoralSurveyReportEJBBean.SENTAKU_NAIYO + (i + 1));
						data = data != null ? data : "";
						dataList.add(data);
					}
					// �O����
					for (int i = 0; i < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; i++) {
						String data = rs.getString(PEF_MoralSurveyReportEJBBean.PRE_SENTAKU_NAIYO + (i + 1));
						data = data != null ? data : "";
						preDataList.add(data);
					}
					groupNum = rs.getInt("cnt");
				}
				sosikiDataMap.put(sosiki, dataList);
				sosikiDataMap.put(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + sosiki, preDataList);
				sosikiDataMap.put(PEF_MoralSurveyReportPDFValueBean.GROUP_NUM + sosiki, new Integer(groupNum));
				PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
			}
			valueBean.setPdfMap(sosikiDataMap);
			return valueBean;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * PDF�쐬�p�f�[�^�擾(��E�p)
	 * @param logiNo ���O�C���Ј��ԍ�
	 * @param moralBean ���[�U���͏��
	 * @return PEF_MoralSurveyReportPDFValueBean PDF�쐬�p�f�[�^
	 */
	public PEF_MoralSurveyReportPDFValueBean getPDFDataYakushoku(final String loginNo, final PEF_MoralSurveyReportValueBean moralBean) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		final String busho = moralBean.getBusho();
		final PEF_MoralSurveyReportPDFValueBean valueBean = new PEF_MoralSurveyReportPDFValueBean();
		final HashMap nestSoshikiMap = new HashMap();
		final ArrayList sortSoshikiList = new ArrayList();

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// ��E�K�w��MIN��MAX���擾
			String sql = "SELECT MAX(" + HcdbDef.T15_YAKUSYOKU_COLUMN[3] + ") AS max,MIN(" + HcdbDef.T15_YAKUSYOKU_COLUMN[3] + ") AS min" + "  FROM " + HcdbDef.yakusyokuTbl;

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			rs = pstmt.executeQuery();
			String minKaisou = "";
			String maxKaisou = "";
			if (rs.next()) {
				minKaisou = rs.getString("min");
				maxKaisou = rs.getString("max");
				minKaisou = minKaisou != null ? minKaisou : "";
				maxKaisou = maxKaisou != null ? maxKaisou : "";
			}
			// ��E�K�w��MIN��MAX���擾�ł��Ȃ��ꍇ���̂܂ܕԂ�
			if ("".equals(maxKaisou) || "".equals(minKaisou)) {
				return valueBean;
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
			final int iMinKaisou = new Integer(minKaisou).intValue();
			final int iMaxKaisou = new Integer(maxKaisou).intValue();

			final HashMap sosikiDataMap = new HashMap();

			// ��E�K�w�����[�v
			for (int i = iMinKaisou; i <= iMaxKaisou; i++) {
				sql = " SELECT " + " * " + " FROM ( " + " SELECT ";
				sql += " ROUND(AVG(SENTAKU_NAIYO_" + 1 + "),2) AS SENTAKU_NAIYO_" + 1 + " ";
				for (int j = 1; j < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; j++) {
					sql += ", 	ROUND(AVG(SENTAKU_NAIYO_" + (j + 1) + "),2) AS SENTAKU_NAIYO_" + (j + 1) + " ";
				}

				sql += " ,count(*) as cnt FROM P32_MORAL_SURVEY_TBL WHERE KIKAN_MEI = ? AND SINDANSYA IN ( " + " SELECT SIMEI_NO FROM ( SELECT * FROM T01_PERSONAL_TBL WHERE YAKUSYOKU_CODE IN ( "
						+ " SELECT YAKUSYOKU_CODE FROM T15_YAKUSYOKU_TBL WHERE KAISOU = ? ) ) WHERE SOSIKI_CODE IN ( "
						+ " SELECT SOSIKI_CODE FROM (SELECT * FROM T19_SOSIKI_TBL START WITH sosiki_code=?  "
						+ " CONNECT BY PRIOR sosiki_code=joui_sosiki_code )) AND HONMU_FLG = '1' AND GENSYOKU_TAISYOKU_FLG = '1' ) ) A, ( " + " SELECT ";
				sql += " 	ROUND(AVG(SENTAKU_NAIYO_" + 1 + "),2) AS PRE_SENTAKU_NAIYO_" + 1 + " ";
				for (int j = 1; j < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; j++) {
					sql += " ,	ROUND(AVG(SENTAKU_NAIYO_" + (j + 1) + "),2) AS PRE_SENTAKU_NAIYO_" + (j + 1) + " ";
				}

				sql += " FROM P32_MORAL_SURVEY_TBL WHERE KIKAN_MEI = ( SELECT KEIKAKU_KIKAN_MEI FROM " + " P33_CAREER_CHALLENGE_KIKAN_TBL WHERE SEIGYO_NO = (SELECT max(SEIGYO_NO) FROM "
						+ " P33_CAREER_CHALLENGE_KIKAN_TBL WHERE SEIGYO_NO < (SELECT SEIGYO_NO FROM " + " P33_CAREER_CHALLENGE_KIKAN_TBL WHERE KEIKAKU_KIKAN_MEI = ? )) ) AND SINDANSYA IN ( "
						+ " SELECT SIMEI_NO FROM (SELECT * FROM T01_PERSONAL_TBL WHERE YAKUSYOKU_CODE IN ( "
						+ " SELECT YAKUSYOKU_CODE FROM T15_YAKUSYOKU_TBL WHERE KAISOU = ?)) WHERE SOSIKI_CODE IN ( "
						+ " SELECT SOSIKI_CODE FROM (SELECT * FROM T19_SOSIKI_TBL START WITH sosiki_code=? "
						+ " CONNECT BY PRIOR sosiki_code=joui_sosiki_code )) AND HONMU_FLG = '1' AND GENSYOKU_TAISYOKU_FLG = '1')) ";

				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				int nowPos = 1;
				final String[] kikan = moralBean.getAssessmentKikan();
				pstmt.setString(nowPos, kikan[4]);
				nowPos++;
				pstmt.setString(nowPos, String.valueOf(i));
				nowPos++;
				pstmt.setString(nowPos, busho);
				nowPos++;
				pstmt.setString(nowPos, kikan[4]);
				nowPos++;
				pstmt.setString(nowPos, String.valueOf(i));
				nowPos++;
				pstmt.setString(nowPos, busho);
				nowPos++;
				rs = pstmt.executeQuery();

				ArrayList dataList = null;
				ArrayList preDataList = null;
				int groupNum = 0;
				while (rs.next()) {
					dataList = new ArrayList();
					preDataList = new ArrayList();
					// ������
					for (int j = 0; j < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; j++) {
						String data = rs.getString(PEF_MoralSurveyReportEJBBean.SENTAKU_NAIYO + (j + 1));
						data = data != null ? data : "";
						dataList.add(data);
					}
					// �O����
					for (int j = 0; j < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; j++) {
						String data = rs.getString(PEF_MoralSurveyReportEJBBean.PRE_SENTAKU_NAIYO + (j + 1));
						data = data != null ? data : "";
						preDataList.add(data);
					}
					groupNum = rs.getInt("cnt");
				}
				sosikiDataMap.put(new Integer(i), dataList);
				sosikiDataMap.put(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + i, preDataList);
				sosikiDataMap.put(PEF_MoralSurveyReportPDFValueBean.GROUP_NUM + i, new Integer(groupNum));
				PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
			}
			valueBean.setNestSoshikiMap(nestSoshikiMap);
			valueBean.setSortSoshikiList(sortSoshikiList);
			valueBean.setPdfMap(sosikiDataMap);
			return valueBean;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * PDF�쐬�p�f�[�^�擾(�N��p)
	 * @param logiNo ���O�C���Ј��ԍ�
	 * @param moralBean ���[�U���͏��
	 * @return PEF_MoralSurveyReportPDFValueBean PDF�쐬�p�f�[�^
	 */
	public PEF_MoralSurveyReportPDFValueBean getPDFDataNendai(final String loginNo, final PEF_MoralSurveyReportValueBean moralBean) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		final String busho = moralBean.getBusho();
		final PEF_MoralSurveyReportPDFValueBean valueBean = new PEF_MoralSurveyReportPDFValueBean();

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �N�㕪���[�v
			final HashMap sosikiDataMap = new HashMap();
			for (int j = 0; j < 5; j++) {
				String sql = " SELECT " + " * " + " FROM ( " + " SELECT ";
				sql += " 	ROUND(AVG(SENTAKU_NAIYO_" + 1 + "),2) AS SENTAKU_NAIYO_" + 1 + " ";
				for (int i = 1; i < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; i++) {
					sql += ", 	ROUND(AVG(SENTAKU_NAIYO_" + (i + 1) + "),2) AS SENTAKU_NAIYO_" + (i + 1) + " ";
				}
				sql += " 	,count(*) as cnt FROM P32_MORAL_SURVEY_TBL WHERE KIKAN_MEI = ? AND SINDANSYA IN ( SELECT SIMEI_NO "
						+ " FROM T01_PERSONAL_TBL WHERE SOSIKI_CODE IN ( SELECT SOSIKI_CODE FROM ( SELECT * FROM T19_SOSIKI_TBL "
						+ " START WITH SOSIKI_CODE = ? CONNECT BY PRIOR SOSIKI_CODE = JOUI_SOSIKI_CODE ) ) " + " AND HONMU_FLG = '1' AND SEINENGAPPI IS NOT NULL AND GENSYOKU_TAISYOKU_FLG = '1' ";
				if (j == 0) {
					sql += " AND 29 >= TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,'YYYYMMDD'), 1, 4)) - TO_NUMBER(SUBSTR(SEINENGAPPI, 2, 4)) ";
				} else if (j == 1) {
					sql += " AND TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,'YYYYMMDD'), 1, 4)) - TO_NUMBER(SUBSTR(SEINENGAPPI, 2, 4)) BETWEEN 30 AND 39 ";
				} else if (j == 2) {
					sql += " AND TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,'YYYYMMDD'), 1, 4)) - TO_NUMBER(SUBSTR(SEINENGAPPI, 2, 4)) BETWEEN 40 AND 49 ";
				} else if (j == 3) {
					sql += " AND TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,'YYYYMMDD'), 1, 4)) - TO_NUMBER(SUBSTR(SEINENGAPPI, 2, 4)) BETWEEN 50 AND 59 ";
				} else {
					sql += " AND 60 <= TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,'YYYYMMDD'), 1, 4)) - TO_NUMBER(SUBSTR(SEINENGAPPI, 2, 4)) ";
				}
				sql += " 	) " + " ) A, ( " + " SELECT ";
				sql += " 	ROUND(AVG(SENTAKU_NAIYO_" + 1 + "),2) AS PRE_SENTAKU_NAIYO_" + 1 + " ";
				for (int i = 1; i < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; i++) {
					sql += ", 	ROUND(AVG(SENTAKU_NAIYO_" + (i + 1) + "),2) AS PRE_SENTAKU_NAIYO_" + (i + 1) + " ";
				}

				sql += " FROM P32_MORAL_SURVEY_TBL " + " WHERE KIKAN_MEI = (SELECT KEIKAKU_KIKAN_MEI FROM " + " P33_CAREER_CHALLENGE_KIKAN_TBL WHERE SEIGYO_NO = (SELECT max(SEIGYO_NO) FROM "
						+ " P33_CAREER_CHALLENGE_KIKAN_TBL WHERE SEIGYO_NO < (SELECT SEIGYO_NO FROM " + " P33_CAREER_CHALLENGE_KIKAN_TBL WHERE KEIKAKU_KIKAN_MEI = ? ) ) ) AND "
						+ " SINDANSYA IN ( SELECT SIMEI_NO FROM T01_PERSONAL_TBL WHERE SOSIKI_CODE IN ( SELECT SOSIKI_CODE FROM ( SELECT * "
						+ " FROM T19_SOSIKI_TBL START WITH SOSIKI_CODE = ? CONNECT BY PRIOR SOSIKI_CODE = JOUI_SOSIKI_CODE "
						+ " )) AND HONMU_FLG = '1' AND SEINENGAPPI IS NOT NULL AND GENSYOKU_TAISYOKU_FLG = '1' ";
				if (j == 0) {
					sql += " AND 29 >= TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,'YYYYMMDD'), 1, 4)) - TO_NUMBER(SUBSTR(SEINENGAPPI, 2, 4)) ";
				} else if (j == 1) {
					sql += " AND TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,'YYYYMMDD'), 1, 4)) - TO_NUMBER(SUBSTR(SEINENGAPPI, 2, 4)) BETWEEN 30 AND 39 ";
				} else if (j == 2) {
					sql += " AND TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,'YYYYMMDD'), 1, 4)) - TO_NUMBER(SUBSTR(SEINENGAPPI, 2, 4)) BETWEEN 40 AND 49 ";
				} else if (j == 3) {
					sql += " AND TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,'YYYYMMDD'), 1, 4)) - TO_NUMBER(SUBSTR(SEINENGAPPI, 2, 4)) BETWEEN 50 AND 59 ";
				} else {
					sql += " AND 60 <= TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,'YYYYMMDD'), 1, 4)) - TO_NUMBER(SUBSTR(SEINENGAPPI, 2, 4)) ";
				}
				sql += " )) ";

				pstmt = dbConn.prepareStatement(sql);
				pstmt.clearParameters();
				int nowPos = 1;
				final String[] kikan = moralBean.getAssessmentKikan();
				pstmt.setString(nowPos, kikan[4]);
				nowPos++;
				pstmt.setString(nowPos, busho);
				nowPos++;
				pstmt.setString(nowPos, kikan[4]);
				nowPos++;
				pstmt.setString(nowPos, busho);
				rs = pstmt.executeQuery();
				ArrayList dataList = null;
				ArrayList preDataList = null;
				int groupNum = 0;
				while (rs.next()) {
					dataList = new ArrayList();
					preDataList = new ArrayList();
					// ������
					for (int i = 0; i < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; i++) {
						String data = rs.getString(PEF_MoralSurveyReportEJBBean.SENTAKU_NAIYO + (i + 1));
						data = data != null ? data : "";
						dataList.add(data);
					}
					// �O����
					for (int i = 0; i < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; i++) {
						String data = rs.getString(PEF_MoralSurveyReportEJBBean.PRE_SENTAKU_NAIYO + (i + 1));
						data = data != null ? data : "";
						preDataList.add(data);
					}
					groupNum = rs.getInt("cnt");

				}

				sosikiDataMap.put(new Integer(j), dataList);
				sosikiDataMap.put(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + j, preDataList);
				sosikiDataMap.put(PEF_MoralSurveyReportPDFValueBean.GROUP_NUM + j, new Integer(groupNum));
				PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			}

			valueBean.setPdfMap(sosikiDataMap);
			return valueBean;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * PDF�쐬�p�f�[�^�擾(�S�Зp)
	 * @param logiNo ���O�C���Ј��ԍ�
	 * @param moralBean ���[�U���͏��
	 * @return PEF_MoralSurveyReportPDFValueBean PDF�쐬�p�f�[�^
	 */
	public HashMap getPDFDataAll(final String loginNo, final PEF_MoralSurveyReportValueBean moralBean) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			final HashMap dataMap = new HashMap();
			String sql = " SELECT * FROM ( SELECT ";
			sql += " ROUND(AVG(SENTAKU_NAIYO_" + 1 + "),2) AS SENTAKU_NAIYO_" + 1 + " ";
			for (int i = 1; i < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; i++) {
				sql += " ,	ROUND(AVG(SENTAKU_NAIYO_" + (i + 1) + "),2) AS SENTAKU_NAIYO_" + (i + 1) + " ";
			}

			sql += " , count(*) as cnt FROM P32_MORAL_SURVEY_TBL WHERE KIKAN_MEI = ? AND  SINDANSYA IN ( SELECT SIMEI_NO "
					+ " FROM T01_PERSONAL_TBL WHERE HONMU_FLG = '1' AND GENSYOKU_TAISYOKU_FLG = '1' ) ) A, ( SELECT ";
			sql += " ROUND(AVG(SENTAKU_NAIYO_" + 1 + "),2) AS PRE_SENTAKU_NAIYO_" + 1 + " ";
			for (int i = 1; i < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; i++) {
				sql += " ,ROUND(AVG(SENTAKU_NAIYO_" + (i + 1) + "),2) AS PRE_SENTAKU_NAIYO_" + (i + 1) + " ";
			}

			sql += " FROM P32_MORAL_SURVEY_TBL WHERE KIKAN_MEI = (SELECT KEIKAKU_KIKAN_MEI FROM "
					+ " P33_CAREER_CHALLENGE_KIKAN_TBL WHERE SEIGYO_NO = (SELECT max(SEIGYO_NO) FROM P33_CAREER_CHALLENGE_KIKAN_TBL "
					+ " WHERE SEIGYO_NO < ( SELECT SEIGYO_NO FROM P33_CAREER_CHALLENGE_KIKAN_TBL WHERE " + " KEIKAKU_KIKAN_MEI = ? ) ) ) AND SINDANSYA IN (SELECT SIMEI_NO FROM T01_PERSONAL_TBL "
					+ " WHERE HONMU_FLG = '1' AND GENSYOKU_TAISYOKU_FLG = '1' ) ) ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			int nowPos = 1;
			final String[] kikan = moralBean.getAssessmentKikan();
			pstmt.setString(nowPos, kikan[4]);
			nowPos++;
			pstmt.setString(nowPos, kikan[4]);
			rs = pstmt.executeQuery();

			ArrayList dataList = null;
			ArrayList preDataList = null;
			int groupNum = 0;
			while (rs.next()) {
				dataList = new ArrayList();
				preDataList = new ArrayList();
				// ������
				for (int i = 0; i < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; i++) {
					String data = rs.getString(PEF_MoralSurveyReportEJBBean.SENTAKU_NAIYO + (i + 1));
					data = data != null ? data : "";
					dataList.add(data);
				}
				// �O����
				for (int i = 0; i < PEF_MoralSurveyReportEJBBean.MAX_SENTAKU_NAIYO - 1; i++) {
					String data = rs.getString(PEF_MoralSurveyReportEJBBean.PRE_SENTAKU_NAIYO + (i + 1));
					data = data != null ? data : "";
					preDataList.add(data);
				}
				groupNum = rs.getInt("cnt");
			}
			dataMap.put(PEF_MoralSurveyReportPDFValueBean.ALL_SHAIN, dataList);
			dataMap.put(PEF_MoralSurveyReportPDFValueBean.PRE_KIKAN + PEF_MoralSurveyReportPDFValueBean.ALL_SHAIN, preDataList);
			dataMap.put(PEF_MoralSurveyReportPDFValueBean.GROUP_NUM + PEF_MoralSurveyReportPDFValueBean.ALL_SHAIN, new Integer(groupNum));

			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			return dataMap;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}
}