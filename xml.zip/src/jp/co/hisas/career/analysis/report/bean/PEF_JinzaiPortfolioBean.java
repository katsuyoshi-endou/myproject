/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.analysis.report.bean;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.naming.NamingException;

import jp.co.hisas.career.analysis.report.ejb.PEF_JinzaiPortfolioEJB;
import jp.co.hisas.career.analysis.report.ejb.PEF_JinzaiPortfolioEJBHome;
import jp.co.hisas.career.base.sosiki.bean.SosikiBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class PEF_JinzaiPortfolioBean {

	/** ���x�� */
	private static final String DEF047 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF047"));

	private static final String DEF048 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF048"));

	private static final String DEF049 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF049"));

	private static final String DEF050 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF050"));

	private static final String DEF051 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF051"));

	private static final String DEF052 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF052"));

	private static final String DEF053 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF053"));

	private static final String DEF054 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF054"));

	private static final String DEF055 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF055"));

	private static final String DEF056 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF056"));

	private static final String DEF057 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF057"));

	private static final String DEF058 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF058"));

	private static final String DEF059 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF059"));

	private static final String DEF060 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF060"));

	private static final String DEF061 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF061"));

	private static final String DEF062 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF062"));

	private static final String DEF063 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF063"));

	private static final String DEF064 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF064"));

	private static final String DEF065 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF065"));

	private static final String DEF066 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF066"));

	private static final String DEF067 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF067"));

	private static final String DEF068 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF068"));

	private static final String DEF069 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF069"));

	private static final String DEF002 = PZZ010_CharacterUtil.normalizedStr((String) ReadFile.paramMapData.get("DEF002"));

	/** �l���|�[�g�t�H���I�I����� */
	private static final String MODE = (String) ReadFile.fileMapData.get("PORTFOLIO_CHOICE");

	/** �E��R�[�h���X�g */
	public ArrayList syokuList = new ArrayList();

	/** �E��}�b�v */
	public HashMap syokuMap = new HashMap();

	/** ���x���R�[�h���X�g */
	public ArrayList levelList = new ArrayList();

	/** ���x���}�b�v */
	public HashMap levelMap = new HashMap();

	/** ���x�����ރ}�b�v */
	public HashMap levelBunruiMap = new HashMap();

	/**
	 * �S�Бg�D���X�g��Ԃ�
	 * @param loginNo
	 * @return
	 * @throws NamingException
	 * @throws Exception
	 */
	public ArrayList getAllSoshiki(final String loginNo) throws NamingException, Exception {
		Log.transaction(loginNo, true, "");

		// EJBHome�̎擾
		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEF_JinzaiPortfolioEJBHome my_home = (PEF_JinzaiPortfolioEJBHome) fact.lookup(PEF_JinzaiPortfolioEJBHome.class);

		/* EJBObject�̎擾 */
		final PEF_JinzaiPortfolioEJB userSession = my_home.create();
		Log.transaction(loginNo, false, "");
		return userSession.getAllSoshiki(loginNo);
	}

	/**
	 * �z���g�D���X�g��Ԃ�
	 * @param loginNo
	 * @return
	 * @throws NamingException
	 * @throws Exception
	 */
	public ArrayList getHaikaSoshiki(final String loginNo) throws NamingException, Exception {
		Log.transaction(loginNo, true, "");

		// EJBHome�̎擾
		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEF_JinzaiPortfolioEJBHome my_home = (PEF_JinzaiPortfolioEJBHome) fact.lookup(PEF_JinzaiPortfolioEJBHome.class);

		/* EJBObject�̎擾 */
		final PEF_JinzaiPortfolioEJB userSession = my_home.create();
		Log.transaction(loginNo, false, "");
		return userSession.getHaikaSoshiki(loginNo);
	}

	/**
	 * �l���|�[�g�t�H���ICSV�f�[�^��Ԃ�
	 * @param sosikiCode
	 * @param start
	 * @param end
	 * @param loginNo
	 * @param kengen
	 * @return
	 * @throws NamingException
	 * @throws Exception
	 */
	public String makeCSV(String sosikiCode, String start, String end, final String kikan, final String loginNo, final boolean kengen, final String kikanway) throws NamingException, Exception {

		/** �|�[�g�t�H���I臒l */
		final int threshold = Integer.parseInt((String) ReadFile.fileMapData.get("PORTFOLIO_THRESHOLD"));

		// ���Ԃ������͂̏ꍇ
		if (start == null || start.equals("")) {
			start = "19900101";
		}
		if (end == null || end.equals("")) {
			end = "99991231";
		}

		ArrayList targetData = new ArrayList();
		ArrayList syokuData = new ArrayList();

		// EJBHome�̎擾
		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEF_JinzaiPortfolioEJBHome my_home = (PEF_JinzaiPortfolioEJBHome) fact.lookup(PEF_JinzaiPortfolioEJBHome.class);

		/* EJBObject�̎擾 */
		final PEF_JinzaiPortfolioEJB userSession = my_home.create();

		// �g�D���I���̏ꍇ�A�ŏ�ʑg�D���擾
		if (sosikiCode == null || sosikiCode.equals("")) {
			Log.transaction(loginNo, true, "");
			sosikiCode = userSession.getRootSosiki(loginNo);
			Log.transaction(loginNo, false, "");
		}

		// �L���ȐE��O���[�v���擾
		syokuData = userSession.getSyokuList(loginNo);

		// �Ώۃf�[�^�擾
		Log.transaction(loginNo, true, "");

		targetData = userSession.getPortfolioData(sosikiCode, start, end, kikan, kikanway, PEF_JinzaiPortfolioBean.MODE, loginNo, kengen, syokuData);

		Log.transaction(loginNo, false, "");

		// ��O�őΏۃf�[�^���擾�ł��Ȃ������ꍇ
		if (targetData == null) {
			throw new Exception();
		}

		// �E��}�b�v�擾 ArrayList �E��R�[�h HashMap �E��R�[�h��[0]order [1]�E�햼��
		final ArrayList tmpSyokuMap = userSession.getSyokuMap(loginNo, this.syokuList, this.syokuMap);
		this.syokuList = (ArrayList) tmpSyokuMap.get(0);
		this.syokuMap = (HashMap) tmpSyokuMap.get(1);

		// ���x���}�b�v�擾 ArrayList ���x���R�[�h HashMap ���x���R�[�h��[0]���x�����ޖ��� [1]���x������ [2]���v�B�� [3]���v�S�� [4]�E��ʍ��v[]
		final ArrayList tmpLevelMap = userSession.getLevelMap(loginNo, this.levelList, this.levelMap, this.syokuList.size());
		this.levelList = (ArrayList) tmpLevelMap.get(0);
		this.levelMap = (HashMap) tmpLevelMap.get(1);

		HashMap tmp = null;
		/** �E��̃C���f�b�N�X�i���o */
		int syokuOrder = 0;
		/** CSV�f�[�^�W�v */
		for (int i = 0; i < targetData.size(); i++) {
			tmp = (HashMap) targetData.get(i);

			syokuOrder = this.syokuList.indexOf(tmp.get("SYOKU_GROUP_CODE"));
			syokuOrder *= 2;
			if (syokuOrder == -2) {
				targetData.remove(i);
				i--;
				continue;
			}

			if (this.levelMap.get(tmp.get("LEVEL_CODE")) == null) {
				targetData.remove(i);
				i--;
				continue;
			}

			// �Ώۃ��x��ArrayList
			final ArrayList tmpLevel = (ArrayList) this.levelMap.get(tmp.get("LEVEL_CODE"));
			// �Ώۃ��x���E��ArrayList
			final ArrayList tmpSyoku = (ArrayList) tmpLevel.get(4);

			// ���x���ʍ��v�S�̉��Z
			tmpLevel.set(3, String.valueOf(Integer.parseInt((String) tmpLevel.get(3)) + 1));
			// �E��ʍ��v�S�̉��Z
			tmpSyoku.set(syokuOrder + 1, String.valueOf(Integer.parseInt((String) tmpSyoku.get(syokuOrder + 1)) + 1));

			if (threshold <= Integer.parseInt((String) tmp.get("SOUGOU_T_DO"))) {
				// �B��
				// ���x���ʍ��v�B�����Z
				tmpLevel.set(2, String.valueOf(Integer.parseInt((String) tmpLevel.get(2)) + 1));
				// �E��ʍ��v�B�����Z
				tmpSyoku.set(syokuOrder, String.valueOf(Integer.parseInt((String) tmpSyoku.get(syokuOrder)) + 1));
			}
			tmpLevel.set(4, tmpSyoku);
			this.levelMap.put(tmp.get("LEVEL_CODE"), tmpLevel);
		}

		/** CSV�`���Ƀf�[�^���` */
		final StringBuffer csv = new StringBuffer();

		// 1�s��
		csv.append("\"").append(PEF_JinzaiPortfolioBean.DEF047).append("�F");
		if (sosikiCode.equals("0")) {
			// �S��

			csv.append(PEF_JinzaiPortfolioBean.DEF048).append("\"" + HcdbDef.CSV_LINE_FEED_CODE);

		} else {

			csv.append(sosikiCode).append("�F").append(SosikiBean.getSosikiByCode(sosikiCode, loginNo)[2]).append("\"" + HcdbDef.CSV_LINE_FEED_CODE); // CHG#73 2007/02/13 k-genma

		}

		// 2�s��
		if (kikanway.equals("0")) {
			csv.append("\"").append(PEF_JinzaiPortfolioBean.DEF002).append("�F").append(PZZ010_CharacterUtil.normalizedStr(kikan)).append("\"" + HcdbDef.CSV_LINE_FEED_CODE);
		} else {
			csv.append("\"").append(PEF_JinzaiPortfolioBean.DEF049).append("�F").append(PZZ010_CharacterUtil.ChangeYmd(start)).append("�`").append(PZZ010_CharacterUtil.ChangeYmd(end)).append(
					"\"" + HcdbDef.CSV_LINE_FEED_CODE);
		}

		// 3�s��
		csv.append("\"").append(PEF_JinzaiPortfolioBean.DEF050).append("\",\"").append(PEF_JinzaiPortfolioBean.DEF051).append("\",\"").append(
				PEF_JinzaiPortfolioBean.DEF052 + PEF_JinzaiPortfolioBean.DEF053).append("\",\"").append(PEF_JinzaiPortfolioBean.DEF052 + PEF_JinzaiPortfolioBean.DEF054);
		// �E��o��
		for (int i = 0; i < this.syokuList.size(); i++) {
			final String syokuName = PZZ010_CharacterUtil.normalizedStr((String) ((ArrayList) this.syokuMap.get(this.syokuList.get(i))).get(1));
			csv.append("\",\"").append(syokuName + PEF_JinzaiPortfolioBean.DEF053).append("\",\"").append(syokuName + PEF_JinzaiPortfolioBean.DEF054);
		}

		csv.append("\"" + HcdbDef.CSV_LINE_FEED_CODE);

		// 4�s�ڈȍ~
		for (int i = 0; i < this.levelList.size(); i++) {
			final ArrayList row = (ArrayList) this.levelMap.get(this.levelList.get(i));
			csv.append("\"").append(PZZ010_CharacterUtil.normalizedStr((String) row.get(0))).append("\",\"").append(PZZ010_CharacterUtil.normalizedStr((String) row.get(1))).append("\",\"").append(
					row.get(2)).append("\",\"").append(row.get(3)).append("\",");
			// �E��ʃf�[�^�o��
			csv.append(row.get(4).toString().replaceAll("\\Q[\\E", "\"").replaceAll("\\Q]\\E", "\"").replaceAll(",", "\",\"").replaceAll(" ", ""));

			csv.append(HcdbDef.CSV_LINE_FEED_CODE);

		}
		return csv.toString();
	}

	/**
	 * �l���|�[�g�t�H���IPDF�f�[�^��Ԃ�
	 * @param sosikiCode
	 * @param start
	 * @param end
	 * @param loginNo
	 * @param kengen
	 * @return
	 * @throws RemoteException
	 * @throws NamingException
	 * @throws NamingException
	 * @throws Exception
	 */
	public byte[] makePDF(String sosikiCode, String start, String end, final String kikan, final String loginNo, final boolean kengen, final String kikanway) throws Exception {

		/** �|�[�g�t�H���I臒l */
		final int threshold = Integer.parseInt((String) ReadFile.fileMapData.get("PORTFOLIO_THRESHOLD"));

		// ���Ԃ������͂̏ꍇ
		if (start == null || start.equals("")) {
			start = "19900101";
		}
		if (end == null || end.equals("")) {
			end = "99991231";
		}

		ArrayList targetData = new ArrayList();
		ArrayList syokuData = new ArrayList();

		try {
			// EJBHome�̎擾
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PEF_JinzaiPortfolioEJBHome my_home = (PEF_JinzaiPortfolioEJBHome) fact.lookup(PEF_JinzaiPortfolioEJBHome.class);
			/* EJBObject�̎擾 */
			final PEF_JinzaiPortfolioEJB userSession = my_home.create();
			// �g�D���I���̏ꍇ�A�ŏ�ʑg�D���擾
			if (sosikiCode == null || sosikiCode.equals("")) {
				Log.transaction(loginNo, true, "");
				sosikiCode = userSession.getRootSosiki(loginNo);
				Log.transaction(loginNo, false, "");
			}

			// �L���ȐE��O���[�v���擾
			syokuData = userSession.getSyokuList(loginNo);

			// �Ώۃf�[�^�擾
			Log.transaction(loginNo, true, "");
			targetData = userSession.getPortfolioData(sosikiCode, start, end, kikan, kikanway, PEF_JinzaiPortfolioBean.MODE, loginNo, kengen, syokuData);
			Log.transaction(loginNo, false, "");

			// ��O�őΏۃf�[�^���擾�ł��Ȃ������ꍇ
			if (targetData == null) {
				throw new Exception();
			}

			// �E��}�b�v�擾 ArrayList �E��R�[�h HashMap �E��R�[�h��[0]order [1]�E�햼�� [2]���v�B�� [3]���v�S��
			final ArrayList tmpSyokuMap = userSession.getSyokuMap(loginNo, this.syokuList, this.syokuMap);
			this.syokuList = (ArrayList) tmpSyokuMap.get(0);
			this.syokuMap = (HashMap) tmpSyokuMap.get(1);

			// ���x���}�b�v�擾 ArrayList ���x���R�[�h HashMap ���x���R�[�h��[0]���x�����ޖ��� [1]���x������ [2]���v�B�� [3]���v�S�� [4]�E��ʍ��v[]
			final ArrayList tmpLevelMap = userSession.getLevelMap(loginNo, this.levelList, this.levelMap, this.syokuList.size());
			this.levelList = (ArrayList) tmpLevelMap.get(0);
			this.levelMap = (HashMap) tmpLevelMap.get(1);
			// ���x�����ރ}�b�v HashMap ���x�����ރR�[�h��[0]���x�����ޖ� [1]���v�B�� [2]���v�S�� [3]�E��ʍ��v[] [4]���x�����ރJ�E���g
			this.levelBunruiMap = (HashMap) tmpLevelMap.get(2);

			/** �E��̃C���f�b�N�X�i���o */
			int syokuOrder = 0;
			/** �S�B������ */
			int tasseiAll = 0;

			HashMap tmp = null;
			String levelBunruiCode = null;

			/** PDF�f�[�^�W�v */
			for (int i = 0; i < targetData.size(); i++) {
				tmp = (HashMap) targetData.get(i);
				final String syokuCode = (String) tmp.get("SYOKU_GROUP_CODE");
				syokuOrder = this.syokuList.indexOf(syokuCode);
				syokuOrder *= 2;

				if (syokuOrder == -2) {

					targetData.remove(i);
					i--;
					continue;
				}
				if (this.levelMap.get(tmp.get("LEVEL_CODE")) == null) {
					targetData.remove(i);
					i--;
					continue;
				}

				// �ΏېE��ArrayList
				final ArrayList tmpSyokuList = (ArrayList) this.syokuMap.get(syokuCode);
				// �Ώۃ��x��ArrayList
				final ArrayList tmpLevel = (ArrayList) this.levelMap.get(tmp.get("LEVEL_CODE"));
				// �Ώۃ��x���E��ArrayList
				final ArrayList tmpSyoku = (ArrayList) tmpLevel.get(4);
				// �Ώۃ��x�����ރR�[�h
				levelBunruiCode = (String) tmpLevel.get(5);
				// �Ώۃ��x������ArrayList
				final ArrayList tmpLevelBunrui = (ArrayList) this.levelBunruiMap.get(levelBunruiCode);
				// �Ώۃ��x�����ސE��ArrayList
				final ArrayList tmpLBSyoku = (ArrayList) tmpLevelBunrui.get(3);

				// �E��ʍ��v�S�̉��Z
				tmpSyokuList.set(3, String.valueOf(Integer.parseInt((String) tmpSyokuList.get(3)) + 1));
				// ���x���ʍ��v�S�̉��Z
				tmpLevel.set(3, String.valueOf(Integer.parseInt((String) tmpLevel.get(3)) + 1));
				// ���x���E��ʍ��v�S�̉��Z
				tmpSyoku.set(syokuOrder + 1, String.valueOf(Integer.parseInt((String) tmpSyoku.get(syokuOrder + 1)) + 1));
				// ���x�����ޕʍ��v�S�̉��Z
				tmpLevelBunrui.set(2, String.valueOf(Integer.parseInt((String) tmpLevelBunrui.get(2)) + 1));
				// ���x�����ސE��ʍ��v�S�̉��Z
				tmpLBSyoku.set(syokuOrder + 1, String.valueOf(Integer.parseInt((String) tmpLBSyoku.get(syokuOrder + 1)) + 1));

				if (threshold <= Integer.parseInt((String) tmp.get("SOUGOU_T_DO"))) {
					// �B��
					// �S�B���������Z
					tasseiAll++;
					// �E��ʍ��v�B�����Z
					tmpSyokuList.set(2, String.valueOf(Integer.parseInt((String) tmpSyokuList.get(2)) + 1));
					// ���x���ʍ��v�B�����Z
					tmpLevel.set(2, String.valueOf(Integer.parseInt((String) tmpLevel.get(2)) + 1));
					// ���x���E��ʍ��v�B�����Z
					tmpSyoku.set(syokuOrder, String.valueOf(Integer.parseInt((String) tmpSyoku.get(syokuOrder)) + 1));
					// ���x�����ޕʍ��v�B�����Z
					tmpLevelBunrui.set(1, String.valueOf(Integer.parseInt((String) tmpLevelBunrui.get(1)) + 1));
					// ���x�����ސE��ʍ��v�B�����Z
					tmpLBSyoku.set(syokuOrder, String.valueOf(Integer.parseInt((String) tmpLBSyoku.get(syokuOrder)) + 1));
				}
				tmpLevel.set(4, tmpSyoku);
				this.levelMap.put(tmp.get("LEVEL_CODE"), tmpLevel);
				this.syokuMap.put(syokuCode, tmpSyokuList);
			}

			/** PDF�`���Ƀf�[�^���` */
			final Document document = new Document(PageSize.A4.rotate(), 8, 8, 8, 8);

			final ByteArrayOutputStream baos = new ByteArrayOutputStream();
			PdfWriter writer;
			writer = PdfWriter.getInstance(document, baos);

			document.open();

			// �t�H���g�̒�`
			final BaseFont bf = BaseFont.createFont("HeiseiKakuGo-W5", "UniJIS-UCS2-H", false);
			final Font font = new Font(bf, 20, Font.BOLD);
			final Font normal = new Font(bf, 8, Font.NORMAL);
			final PdfPTable mainTable = new PdfPTable(1);
			mainTable.setWidthPercentage(100);
			mainTable.getDefaultCell().setPadding(0f);

			// �F�̒�`
			final Color c1 = new Color(255, 0, 0);
			final Color c2 = new Color(255, 51, 0);
			final Color c3 = new Color(255, 102, 0);
			final Color c4 = new Color(255, 153, 0);
			final Color c5 = new Color(255, 255, 0);
			final Color c6 = new Color(255, 255, 153);
			final Color c7 = new Color(255, 255, 255);
			final Color bg1 = new Color(230, 230, 250);
			final Color bg2 = new Color(220, 220, 220);

			// �f�[�^���Z������
			final float fHeight = 20;

			// �E�񂹎��̉E�]��
			final float paddingL = 3;

			// �f�[�^��
			final int dataCnt = this.syokuList.size();

			/** �^�C�g���� */
			final PdfPTable titleTbl = new PdfPTable(2);
			titleTbl.getDefaultCell().setPadding(0f);
			titleTbl.setWidths(new float[] { 85, 15 });
			final PdfPTable titleLTbl = new PdfPTable(1);
			titleLTbl.getDefaultCell().setPadding(0f);

			final PdfPCell titleCell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF055, font));
			titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			titleCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			titleCell.setMinimumHeight((float) 66.0);
			titleLTbl.addCell(titleCell);

			final PdfPTable titleLUnderTbl = new PdfPTable(2);
			titleLUnderTbl.getDefaultCell().setPadding(0f);

			PdfPCell cell = null;
			PdfPTable tmpTbl = null;

			tmpTbl = new PdfPTable(2);
			tmpTbl.setTotalWidth((float) 180.0);
			// tmpTbl.setWidths(new float[]{25,75});
			tmpTbl.setWidths(new float[] { 27, 73 });

			tmpTbl.getDefaultCell().setPadding(0f);
			cell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF047, normal));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setMinimumHeight(fHeight);
			tmpTbl.addCell(cell);
			if (sosikiCode.equals("0")) {
				cell = new PdfPCell(new Phrase(PEF_JinzaiPortfolioBean.DEF048, normal));
			} else {
				cell = new PdfPCell(new Paragraph(sosikiCode + "�F" + SosikiBean.getSosikiByCode(sosikiCode, loginNo)[2], normal)); // CHG#73 2007/02/13 k-genma
			}
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTbl.addCell(cell);

			if (kikanway.equals("0")) {
				cell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF002, normal));
			} else {
				cell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF049, normal));
			}

			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTbl.addCell(cell);

			if (kikanway.equals("0")) {
				cell = new PdfPCell(new Paragraph(PZZ010_CharacterUtil.normalizedStr(kikan), normal));
			} else {
				cell = new PdfPCell(new Paragraph(PZZ010_CharacterUtil.ChangeYmd(start) + "�`" + PZZ010_CharacterUtil.ChangeYmd(end), normal));
			}

			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTbl.addCell(cell);
			titleLUnderTbl.addCell(tmpTbl);

			tmpTbl = new PdfPTable(1);
			tmpTbl.getDefaultCell().setPadding(0f);
			cell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF056, normal));
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTbl.addCell(cell);
			titleLUnderTbl.addCell(tmpTbl);
			titleLTbl.getDefaultCell().setPadding(0f);
			titleLTbl.addCell(titleLUnderTbl);

			titleTbl.addCell(titleLTbl);

			// �F�}��Z���̍���
			float cellHeight = 12f;

			tmpTbl = new PdfPTable(2);
			tmpTbl.setWidths(new float[] { 20, 80 });
			tmpTbl.getDefaultCell().setPadding(0f);
			cell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF057, normal));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setColspan(2);
			cell.setFixedHeight(cellHeight);
			tmpTbl.addCell(cell);
			cell = new PdfPCell(new Paragraph(PZZ010_CharacterUtil.ChangeYmd(PZZ010_CharacterUtil.GetDay()) + " " + this.ChangeHm(PZZ010_CharacterUtil.GetTime()), normal));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setColspan(2);
			cell.setFixedHeight(cellHeight);
			tmpTbl.addCell(cell);
			cell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF058, normal));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setColspan(2);
			cell.setFixedHeight(cellHeight);
			tmpTbl.addCell(cell);
			cellHeight = 10f;
			cell = new PdfPCell();
			cell.setBackgroundColor(c1);
			cell.setFixedHeight(cellHeight);
			tmpTbl.addCell(cell);
			cell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF059, normal));
			cell.setBorderWidth(0);
			cell.setPadding(1f);
			tmpTbl.addCell(cell);
			cell = new PdfPCell();
			cell.setBackgroundColor(c2);
			cell.setFixedHeight(cellHeight);
			tmpTbl.addCell(cell);
			cell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF060, normal));
			cell.setPadding(1f);
			cell.setBorderWidth(0);
			tmpTbl.addCell(cell);
			cell = new PdfPCell();
			cell.setBackgroundColor(c3);
			cell.setFixedHeight(cellHeight);
			tmpTbl.addCell(cell);
			cell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF061, normal));
			cell.setPadding(1f);
			cell.setBorderWidth(0);
			tmpTbl.addCell(cell);
			cell = new PdfPCell();
			cell.setBackgroundColor(c4);
			cell.setFixedHeight(cellHeight);
			tmpTbl.addCell(cell);
			cell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF062, normal));
			cell.setPadding(1f);
			cell.setBorderWidth(0);
			tmpTbl.addCell(cell);
			cell = new PdfPCell();
			cell.setBackgroundColor(c5);
			cell.setFixedHeight(cellHeight);
			tmpTbl.addCell(cell);
			cell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF063, normal));
			cell.setPadding(1f);
			cell.setBorderWidth(0);
			tmpTbl.addCell(cell);
			cell = new PdfPCell();
			cell.setBackgroundColor(c6);
			cell.setFixedHeight(cellHeight);
			tmpTbl.addCell(cell);
			cell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF064, normal));
			cell.setPadding(1f);
			cell.setBorderWidth(0);
			tmpTbl.addCell(cell);
			cell = new PdfPCell();
			cell.setBackgroundColor(c7);
			cell.setFixedHeight(cellHeight);
			tmpTbl.addCell(cell);
			cell = new PdfPCell(new Paragraph(PEF_JinzaiPortfolioBean.DEF065, normal));
			cell.setPadding(1f);
			cell.setBorderWidth(0);
			tmpTbl.addCell(cell);

			titleTbl.addCell(tmpTbl);

			mainTable.addCell(titleTbl);

			/** �E��^�C�g�����e�[�u�� */
			tmpTbl = new PdfPTable(dataCnt + 2);
			tmpTbl.getDefaultCell().setPadding(1f);
			tmpTbl.getDefaultCell().setBackgroundColor(bg1);
			tmpTbl.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tmpTbl.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTbl.getDefaultCell().setMinimumHeight(fHeight);
			final float tmpW[] = new float[dataCnt + 2];
			tmpW[0] = 11.471f;

			final float ft = (float) 88.529 / (dataCnt + 1);

			for (int i = 0; i < dataCnt + 1; i++) {
				tmpW[i + 1] = ft;
			}
			tmpTbl.setWidths(tmpW);

			tmpTbl.addCell(new Phrase("", normal));
			tmpTbl.addCell(new Phrase(PEF_JinzaiPortfolioBean.DEF052, normal));
			for (int i = 0; i < dataCnt; i++) {
				final String syokuName = PZZ010_CharacterUtil.normalizedStr((String) ((ArrayList) this.syokuMap.get(this.syokuList.get(i))).get(1));
				tmpTbl.addCell(new Phrase(syokuName, normal));
			}

			mainTable.addCell(tmpTbl);

			/** �E�핪�z�� */
			tmpTbl = new PdfPTable(dataCnt + 2);
			tmpTbl.getDefaultCell().setPadding(0f);
			tmpTbl.getDefaultCell().setBackgroundColor(bg2);
			tmpTbl.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tmpTbl.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			tmpTbl.getDefaultCell().setPaddingRight(paddingL);
			tmpTbl.getDefaultCell().setMinimumHeight(fHeight);
			tmpTbl.setWidths(tmpW);

			cell = new PdfPCell(new Phrase(PEF_JinzaiPortfolioBean.DEF066, normal));
			cell.setBackgroundColor(bg2);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTbl.addCell(cell);
			tmpTbl.addCell(new Phrase(String.valueOf(tasseiAll) + " (" + String.valueOf(targetData.size()) + ")", normal));
			for (int i = 0; i < dataCnt; i++) {
				final ArrayList tmpSyokuList = (ArrayList) this.syokuMap.get(this.syokuList.get(i));
				if (tmpSyokuList.get(3).equals("0")) {
					tmpTbl.addCell(new Phrase("", normal));
				} else {
					tmpTbl.addCell(new Phrase(tmpSyokuList.get(2) + " (" + tmpSyokuList.get(3) + ")", normal));
				}
			}

			/** �E�핪�z�䗦 */
			cell = new PdfPCell(new Phrase(PEF_JinzaiPortfolioBean.DEF067, normal));
			cell.setBackgroundColor(bg2);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTbl.addCell(cell);
			BigDecimal bd = null;
			if (targetData.size() == 0) {
				tmpTbl.addCell(new Phrase("0.0", normal));
			} else {
				bd = new BigDecimal(((float) tasseiAll / (float) targetData.size() * 100));
				tmpTbl.addCell(new Phrase(String.valueOf(bd.setScale(1, BigDecimal.ROUND_HALF_UP)), normal));
			}
			for (int i = 0; i < dataCnt; i++) {
				final ArrayList tmpSyokuList = (ArrayList) this.syokuMap.get(this.syokuList.get(i));
				if (tmpSyokuList.get(3).equals("0") || targetData.size() == 0) {
					tmpTbl.addCell(new Phrase("", normal));
				} else {
					bd = new BigDecimal(((float) Integer.parseInt((String) tmpSyokuList.get(2)) / (float) targetData.size() * 100));
					tmpTbl.addCell(new Phrase(String.valueOf(bd.setScale(1, BigDecimal.ROUND_HALF_UP)), normal));
				}
			}

			mainTable.addCell(tmpTbl);

			/** ���x���ʃf�[�^�� */
			final PdfPTable levelDataTbl = new PdfPTable(3);
			// levelDataTbl.setWidths(new float[]{6.625f,4f,89.375f});
			levelDataTbl.setWidths(new float[] { 7.471f, 4f, 88.529f });

			levelDataTbl.getDefaultCell().setPadding(0f);
			/** ���x�����ޕ� */
			// ��������
			final PdfPTable levelBunruiTbl = new PdfPTable(dataCnt + 2);
			levelBunruiTbl.setWidths(tmpW);
			levelBunruiTbl.getDefaultCell().setBackgroundColor(bg2);
			levelBunruiTbl.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			levelBunruiTbl.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			levelBunruiTbl.getDefaultCell().setPaddingLeft(paddingL);
			levelBunruiTbl.getDefaultCell().setMinimumHeight(fHeight);

			tmpTbl = new PdfPTable(1);
			final PdfPTable tmpTbl2 = new PdfPTable(1);
			tmpTbl2.getDefaultCell().setMinimumHeight(fHeight);
			tmpTbl2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tmpTbl2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			final PdfPTable tmpTbl3 = new PdfPTable(dataCnt + 1);
			tmpTbl3.getDefaultCell().setMinimumHeight(fHeight);
			tmpTbl3.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tmpTbl3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			String cache = "";
			int lbCnt = 0;
			for (int i = 0; i < this.levelList.size(); i++) {
				final ArrayList targetLevel = (ArrayList) this.levelMap.get(this.levelList.get(i));
				final String tmpLBCode = PZZ010_CharacterUtil.normalizedStr((String) targetLevel.get(5));
				if (!cache.equals(tmpLBCode) && !cache.equals("")) {
					final ArrayList targetLevelBunrui = (ArrayList) this.levelBunruiMap.get(cache);
					// ���x������
					final String lbName = PZZ010_CharacterUtil.normalizedStr((String) targetLevelBunrui.get(0));
					cell = new PdfPCell(new Phrase(lbName, normal));
					cell.setMinimumHeight(fHeight * lbCnt);
					cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					tmpTbl.addCell(cell);

					// ���x�����ޑI�����x��
					cell = new PdfPCell(new Phrase(lbName + PEF_JinzaiPortfolioBean.DEF068, normal));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell.setBackgroundColor(bg2);
					levelBunruiTbl.addCell(cell);
					// ���x�����ޑI�����v
					final String lbTotal = (String) targetLevelBunrui.get(2);
					final String lbTassei = (String) targetLevelBunrui.get(1);
					final ArrayList lbSyoku = (ArrayList) targetLevelBunrui.get(3);
					levelBunruiTbl.addCell(new Phrase(lbTassei + " (" + lbTotal + ")", normal));
					for (int j = 0; j < dataCnt; j++) {
						// ���x�����ޑI��E��ʃf�[�^
						if (lbSyoku.get(j * 2 + 1).equals("0")) {
							levelBunruiTbl.addCell("");
						} else {
							levelBunruiTbl.addCell(new Phrase((String) lbSyoku.get(j * 2) + " (" + (String) lbSyoku.get(j * 2 + 1) + ")", normal));
						}
					}
					// ���x�����ޔ䗦���x��
					cell = new PdfPCell(new Phrase(lbName + PEF_JinzaiPortfolioBean.DEF069, normal));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell.setBackgroundColor(bg2);
					levelBunruiTbl.addCell(cell);
					// ���x�����ޔ䗦���v
					if (Integer.parseInt(lbTotal) == 0) {
						levelBunruiTbl.addCell("");
					} else {
						bd = new BigDecimal(((float) Integer.parseInt(lbTassei) / (float) targetData.size() * 100));
						levelBunruiTbl.addCell(new Phrase(String.valueOf(bd.setScale(1, BigDecimal.ROUND_HALF_UP)), normal));
					}
					for (int j = 0; j < dataCnt; j++) {
						// ���x�����ޔ䗦�E��ʃf�[�^
						if (lbSyoku.get(j * 2 + 1).equals("0")) {
							levelBunruiTbl.addCell("");
						} else {
							bd = new BigDecimal(((float) Integer.parseInt((String) lbSyoku.get(j * 2)) / (float) targetData.size() * 100));
							levelBunruiTbl.addCell(new Phrase(String.valueOf(bd.setScale(1, BigDecimal.ROUND_HALF_UP)), normal));
						}
					}

					lbCnt = 1;
				} else {
					lbCnt++;
				}
				cache = tmpLBCode;
				tmpTbl2.addCell(new Phrase((String) targetLevel.get(1), normal));
				// ���x���ʍ��v
				cell = new PdfPCell(new Phrase((String) targetLevel.get(2) + " (" + (String) targetLevel.get(3) + ")", normal));
				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				cell.setMinimumHeight(fHeight);
				cell.setPaddingRight(paddingL);
				tmpTbl3.addCell(cell);
				final ArrayList tmpSyokuList = (ArrayList) targetLevel.get(4);
				for (int j = 0; j < dataCnt; j++) {
					if (tmpSyokuList.get(j * 2 + 1).equals("0") || targetData.size() == 0) {
						tmpTbl3.addCell("");
					} else {
						cell = new PdfPCell(new Phrase((String) tmpSyokuList.get(j * 2) + " (" + (String) tmpSyokuList.get(j * 2 + 1) + ")", normal));
						final float percent = (float) Integer.parseInt((String) tmpSyokuList.get(j * 2 + 1)) / (float) targetData.size() * 100;
						Color c = c7;
						if (12 < percent) {
							c = c1;
						} else if (10 < percent) {
							c = c2;
						} else if (8 < percent) {
							c = c3;
						} else if (6 < percent) {
							c = c4;
						} else if (4 < percent) {
							c = c5;
						} else if (2 < percent) {
							c = c6;
						} else {
							c = c7;
						}
						cell.setBackgroundColor(c);
						cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
						cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
						cell.setPaddingRight(paddingL);
						tmpTbl3.addCell(cell);
					}
				}
			}
			// �ŏI���x�����ނ̊e���ڂ��o��
			final String lbName = PZZ010_CharacterUtil.normalizedStr((String) ((ArrayList) this.levelBunruiMap.get(cache)).get(0));
			cell = new PdfPCell(new Phrase(lbName, normal));
			cell.setMinimumHeight(fHeight * lbCnt);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			tmpTbl.addCell(cell);

			final ArrayList targetLevelBunrui = (ArrayList) this.levelBunruiMap.get(cache);
			// ���x�����ޑI�����x��
			cell = new PdfPCell(new Phrase(lbName + PEF_JinzaiPortfolioBean.DEF068, normal));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setBackgroundColor(bg2);
			levelBunruiTbl.addCell(cell);
			// ���x�����ޑI�����v
			final String lbTotal = (String) targetLevelBunrui.get(2);
			final String lbTassei = (String) targetLevelBunrui.get(1);
			final ArrayList lbSyoku = (ArrayList) targetLevelBunrui.get(3);
			levelBunruiTbl.addCell(new Phrase(lbTassei + " (" + lbTotal + ")", normal));
			for (int j = 0; j < dataCnt; j++) {
				// ���x�����ޑI��E��ʃf�[�^
				if (lbSyoku.get(j * 2 + 1).equals("0")) {
					levelBunruiTbl.addCell("");
				} else {
					levelBunruiTbl.addCell(new Phrase((String) lbSyoku.get(j * 2) + " (" + (String) lbSyoku.get(j * 2 + 1) + ")", normal));
				}
			}
			// ���x�����ޔ䗦���x��
			cell = new PdfPCell(new Phrase(lbName + PEF_JinzaiPortfolioBean.DEF069, normal));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setBackgroundColor(bg2);
			levelBunruiTbl.addCell(cell);
			// ���x�����ޔ䗦���v
			if (Integer.parseInt(lbTotal) == 0) {
				levelBunruiTbl.addCell("");
			} else {
				bd = new BigDecimal(((float) Integer.parseInt(lbTassei) / (float) targetData.size() * 100));
				levelBunruiTbl.addCell(new Phrase(String.valueOf(bd.setScale(1, BigDecimal.ROUND_HALF_UP)), normal));
			}
			for (int j = 0; j < dataCnt; j++) {
				// ���x�����ޔ䗦�E��ʃf�[�^
				if (lbSyoku.get(j * 2 + 1).equals("0")) {
					levelBunruiTbl.addCell("");
				} else {
					bd = new BigDecimal(((float) Integer.parseInt((String) lbSyoku.get(j * 2)) / (float) targetData.size() * 100));
					levelBunruiTbl.addCell(new Phrase(String.valueOf(bd.setScale(1, BigDecimal.ROUND_HALF_UP)), normal));
				}
			}

			levelDataTbl.addCell(tmpTbl);
			levelDataTbl.addCell(tmpTbl2);
			levelDataTbl.addCell(tmpTbl3);

			mainTable.addCell(levelDataTbl);

			mainTable.addCell(levelBunruiTbl);

			mainTable.setHeaderRows(2);
			document.add(mainTable);
			document.close();
			return baos.toByteArray();
		} catch (final NumberFormatException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final RemoteException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final SQLException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final DocumentException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final IOException e) {
			Log.error(loginNo, e);
			throw e;
		}
	}

	/**
	 * �����ϊ�(HHMMSS �� HH��MM������HH:MM)���s�� ���p�o�[�W����
	 * @param String �ϊ��O����
	 * @return String �ϊ��㎞��
	 */
	public String ChangeHm(final String strHm) {
		final String timeFormat = (String) ReadFile.fileMapData.get(HcdbDef.timeFormat);

		if (strHm == null || strHm.length() < 4) {
			return " ";
		} else {
			if (timeFormat.equals("1")) {
				return strHm.substring(0, 2) + "��" + strHm.substring(2, 4) + "��";
			} else {
				return strHm.substring(0, 2) + ":" + strHm.substring(2, 4);
			}
		}
	}

	// --- 20070117 K.takagi Add Sta ---
	/**
	 * �A�Z�X�����g���Ԃ̎擾
	 * @param loginNo
	 * @return ArrayList �A�Z�X�����g���Ԃ̃��X�g
	 * @throws RemoteException
	 * @throws NamingException
	 * @throws CreateException
	 * @throws SQLException
	 */
	public ArrayList getAssessmentKikanList(final String loginNo) throws RemoteException, NamingException, CreateException, SQLException {
		try {
			Log.transaction(loginNo, true, "");
			// EJBHome�̎擾
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PEF_JinzaiPortfolioEJBHome my_home = (PEF_JinzaiPortfolioEJBHome) fact.lookup(PEF_JinzaiPortfolioEJBHome.class);
			/* EJBObject�̎擾 */
			final PEF_JinzaiPortfolioEJB userSession = my_home.create();
			Log.transaction(loginNo, false, "");
			return userSession.getAssessmentKikanList(loginNo);
		} catch (final RemoteException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginNo, e);
			throw e;
		} catch (final SQLException e) {
			Log.error(loginNo, e);
			throw e;
		}
	}
	// --- 20070117 K.takagi Add End ---
}
