/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.analysis.report.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ020_MakeSQLUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

public class PEF_JinzaiPortfolioEJBBean implements SessionBean {

	/** �l���|�[�g�t�H���I�I������F�ŐV�]���� */
	private static final String SAISIN_HYOKABI = "1";

	/** �l���|�[�g�t�H���I�I������F�ő僌�x�� */
	private static final String MAX_LEVEL = "2";

	/** �����Ԃ�\���t���O */
	private static final String TOKIKAN_FLG = "1";

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException {/* �������܂��� */
	}

	public void setSessionContext(final SessionContext arg0) throws EJBException, RemoteException {/* �������܂��� */
	}

	/** �l���|�[�g�t�H���I�Ώۑg�D�K�w���� */
	private static final String JINZAI_KAGEN_KAISO = (String) ReadFile.fileMapData.get("PORTFOLIO_SOSIKI_KAISO_MIN");

	/** �l���|�[�g�t�H���I�Ώۑg�D�K�w��� */
	private static final String JINZAI_JOGEN_KAISO = (String) ReadFile.fileMapData.get("PORTFOLIO_SOSIKI_KAISO_MAX");

	/** ��ʑg�D�\���t���O */
	private static final String JINZAI_JOUI_SOSIKI = (String) ReadFile.fileMapData.get("PORTFOLIO_SHOW_JOUI_SOSIKI");

	/**
	 * �S�Ќ����̏ꍇ�S�g�D���擾�i���X�g�{�b�N�X�j
	 * @param loginNo
	 * @return ArrayList �g�D���X�g
	 */
	public ArrayList getAllSoshiki(final String loginNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		final ArrayList soshikiList = new ArrayList();

		// PRT_START
		String prtStart = null;
		// PRT_END
		String prtEnd = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			String sql = "";

			prtStart = PEF_JinzaiPortfolioEJBBean.JINZAI_KAGEN_KAISO;
			prtEnd = PEF_JinzaiPortfolioEJBBean.JINZAI_JOGEN_KAISO;

			// �p�����[�^��NULL�̏ꍇ���Ԃ�
			if (prtStart == null || prtEnd == null) {
				return soshikiList;
			}

			// --- 20070117 K.takagi Add --- �������̖��ǉ�
			sql = "SELECT " + HcdbDef.T19_SOSIKI_COLUMNS[0] + "," + HcdbDef.T19_SOSIKI_COLUMNS[1] + "," + HcdbDef.T19_SOSIKI_COLUMNS[2] + " FROM " + HcdbDef.sosikiTbl + " WHERE "
					+ HcdbDef.T19_SOSIKI_COLUMNS[4] + " BETWEEN ? AND ? ORDER BY " + HcdbDef.T19_SOSIKI_COLUMNS[0];

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, prtStart);
			pstmt.setString(2, prtEnd);
			rs = pstmt.executeQuery();
			// �������̖���ۊ�
			String[] tmp = new String[2];
			while (rs.next()) {
				tmp = new String[2];
				tmp[0] = rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[0]);
				tmp[1] = rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[2]);

				tmp[0] = tmp[0] != null ? tmp[0] : "";
				tmp[1] = tmp[1] != null ? tmp[1] : "";

				soshikiList.add(tmp);
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			Log.method(loginNo, "OUT", "");
			return soshikiList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �z�������̏ꍇ���O�C�����[�U�̏����g�D����ђ����g�D���擾�i���X�g�{�b�N�X�j
	 * @param loginNo
	 * @return ArrayList �g�D���X�g
	 */
	public ArrayList getHaikaSoshiki(final String loginNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList soshikiList = new ArrayList();

		// PRT_START
		String prtStart = null;
		// PRT_END
		String prtEnd = null;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			String sql = "";

			prtStart = PEF_JinzaiPortfolioEJBBean.JINZAI_KAGEN_KAISO;
			prtEnd = PEF_JinzaiPortfolioEJBBean.JINZAI_JOGEN_KAISO;

			// �p�����[�^��NULL�̏ꍇ���Ԃ�
			if (prtStart == null || prtEnd == null) {
				return soshikiList;
			}
			// ���O�I�����[�U�̑g�D�R�[�h�擾
			sql = "SELECT DISTINCT " + HcdbDef.t01_column[11] + " FROM " + HcdbDef.personalTbl + " WHERE " + HcdbDef.t01_column[0] + "=?";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, loginNo);
			rs = pstmt.executeQuery();
			final ArrayList loginSoshikiCodeList = new ArrayList();
			while (rs.next()) {
				final String tmpS = rs.getString(HcdbDef.t01_column[11]);
				if (tmpS != null) {
					loginSoshikiCodeList.add(tmpS);
				}
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
			if (loginSoshikiCodeList.size() == 0) {
				return soshikiList;
			}
			// �擾�����g�D�R�[�h�ɑ�����g�D���擾
			soshikiList = (ArrayList) loginSoshikiCodeList.clone();
			if (PEF_JinzaiPortfolioEJBBean.JINZAI_JOUI_SOSIKI.equals("1")) {
				final ArrayList tmpList = new ArrayList();
				for (int i = 0, num = loginSoshikiCodeList.size(); i < num; i++) {

					sql = "SELECT " + HcdbDef.T19_SOSIKI_COLUMNS[0] + "  FROM " + HcdbDef.sosikiTbl + " " + " START WITH  " + HcdbDef.T19_SOSIKI_COLUMNS[0] + "=?" + " CONNECT BY PRIOR "
							+ HcdbDef.T19_SOSIKI_COLUMNS[3] + "=" + HcdbDef.T19_SOSIKI_COLUMNS[0] + " ORDER SIBLINGS BY " + HcdbDef.T19_SOSIKI_COLUMNS[0] + " DESC";
					pstmt = dbConn.prepareStatement(sql);
					pstmt.clearParameters();
					pstmt.setString(1, (String) loginSoshikiCodeList.get(i));
					rs = pstmt.executeQuery();

					while (rs.next()) {
						tmpList.add(rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[0]));
					}
					PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
				}
				soshikiList = (ArrayList) tmpList.clone();
			}
			// �g�D���̎擾
			sql = "SELECT " + HcdbDef.T19_SOSIKI_COLUMNS[0] + "," + HcdbDef.T19_SOSIKI_COLUMNS[1] + "," + HcdbDef.T19_SOSIKI_COLUMNS[2] + " FROM " + HcdbDef.sosikiTbl + " WHERE "
					+ HcdbDef.T19_SOSIKI_COLUMNS[4] + " BETWEEN ? AND ? AND " + HcdbDef.T19_SOSIKI_COLUMNS[0] + " IN(?";
			for (int i = 1, num = soshikiList.size(); i < num; i++) {
				sql += ",?";
			}
			sql += ") ORDER BY " + HcdbDef.T19_SOSIKI_COLUMNS[0] + " ASC";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, prtStart);
			pstmt.setString(2, prtEnd);
			for (int i = 0, num = soshikiList.size(); i < num; i++) {
				pstmt.setString(i + 3, (String) soshikiList.get(i));
			}

			rs = pstmt.executeQuery();
			String[] tmp = new String[2];
			soshikiList = new ArrayList();
			// �������̖���ۊ�
			while (rs.next()) {
				tmp = new String[2];
				tmp[0] = rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[0]);
				tmp[1] = rs.getString(HcdbDef.T19_SOSIKI_COLUMNS[2]);

				tmp[0] = tmp[0] != null ? tmp[0] : "";
				tmp[1] = tmp[1] != null ? tmp[1] : "";
				soshikiList.add(tmp);

			}
			Log.method(loginNo, "OUT", "");
			return soshikiList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �l���|�[�g�t�H���I�o�͑Ώۃf�[�^���擾���܂��B
	 * @param sosikiCode
	 * @param start
	 * @param end
	 * @param mode
	 * @param loginNo
	 * @param kengen TRUE:�S�ЎQ�ƌ������������A�I�������g�D�����O�C�����[�U�����g�D�ł���
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 */
	public ArrayList getPortfolioData(final String sosikiCode, final String start, final String end, final String kikan, final String kikanway, final String mode, final String loginNo,
			final boolean kengen, final ArrayList syokuData) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList result = new ArrayList();
		String sql = "";
		try {

			// �p�����[�^�`�F�b�N
			if (sosikiCode == null || kikanway == null || start == null || end == null || mode == null) {
				return result;
			}

			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			String kengenCondition = "";
			if (kengen) {
				// �S�ЎQ�ƌ������������A�I�������g�D�����O�C�����[�U�����g�D�ł���
				kengenCondition = " AND NOT (SOSIKI_CODE = '" + PZZ020_MakeSQLUtil.sanitizeSQLData(sosikiCode) + "' AND SIMEI_NO <> '" + PZZ020_MakeSQLUtil.sanitizeSQLData(loginNo) + "') ";
			}

			if (mode.equals(PEF_JinzaiPortfolioEJBBean.SAISIN_HYOKABI)) {
				// �ŐV�]�����I�����
				if (kikanway.equals("0")) {
					sql = "SELECT P24.SINDANSYA, P24.SYOKU_CODE, P24.SENMON_CODE, P24.LEVEL_CODE, P24.JISSI_KAISU, P24.HYOKASYA, P24.SINSEI_NENGAPPI, P24.SINSEI_JIKOKU, P24.SYORI_ZYOU_FLG, P24.HYOKA_SIND_FLG, P24.JISSI_NENGAPPI, P24.JISSI_JIKOKU, P24.GYOMU_KEIKEN_T_DO, P24.SKILL_T_DO, P24.SOUGOU_T_DO, P24.HYOKASYA_COMMENT "
						+ " FROM P24_ASSESSMENT_HYOKA_TBL P24 WHERE (	SINDANSYA,JISSI_NENGAPPI,LEVEL_CODE,SOUGOU_T_DO,SYOKU_CODE,SENMON_CODE,JISSI_KAISU) IN ( SELECT SINDANSYA, JISSI_NENGAPPI, LEVEL_CODE, MAX(SOUGOU_T_DO), SYOKU_CODE, SENMON_CODE, JISSI_KAISU FROM P24_ASSESSMENT_HYOKA_TBL WHERE (SINDANSYA,JISSI_NENGAPPI,LEVEL_CODE,SYOKU_CODE,SENMON_CODE,JISSI_KAISU) "
						+ " IN ( SELECT SINDANSYA, JISSI_NENGAPPI, MAX(LEVEL_CODE), SYOKU_CODE, SENMON_CODE, JISSI_KAISU FROM P24_ASSESSMENT_HYOKA_TBL WHERE  (SINDANSYA,JISSI_NENGAPPI,SYOKU_CODE,SENMON_CODE,LEVEL_CODE,JISSI_KAISU) IN ( SELECT TBL_C.SINDANSYA, MAX(TBL_C.JISSI_NENGAPPI), TBL_C.SYOKU_CODE, TBL_C.SENMON_CODE, TBL_C.LEVEL_CODE, "
						+ " TBL_C.JISSI_KAISU FROM ( SELECT TBL_A.SINDANSYA, TBL_A.JISSI_NENGAPPI, TBL_A.NINTEI_FLG, TBL_A.SYOKU_CODE, TBL_A.SENMON_CODE, TBL_A.LEVEL_CODE, TBL_A.JISSI_KAISU from P24_ASSESSMENT_HYOKA_TBL TBL_A, ( SELECT TBL_AA.SINDANSYA, TBL_AA.SYOKU_CODE, TBL_AA.SENMON_CODE, TBL_AA.LEVEL_CODE, TBL_AA.JISSI_KAISU, TBL_AA.NINTEI_FLG "
						+ " FROM P21_ASSESSMENT_SINDAN_TBL TBL_AA WHERE TBL_AA.SINDANSYA IN ( SELECT SIMEI_NO FROM T01_PERSONAL_TBL WHERE SOSIKI_CODE IN ( SELECT SOSIKI_CODE FROM T19_SOSIKI_TBL START WITH SOSIKI_CODE = ? CONNECT BY PRIOR SOSIKI_CODE = JOUI_SOSIKI_CODE ) AND HONMU_FLG = '1' AND GENSYOKU_TAISYOKU_FLG = '1' " + kengenCondition + ") AND "
						+ " TBL_AA.CAREER_CHALLENGE_KIKAN_MEI = ? AND TBL_AA.CAREER_CHALLENGE_FLG = '1' ) TBL_B WHERE TBL_A.SINDANSYA = TBL_B.SINDANSYA AND TBL_A.SYOKU_CODE = TBL_B.SYOKU_CODE AND TBL_A.SENMON_CODE = TBL_B.SENMON_CODE AND TBL_A.LEVEL_CODE = TBL_B.LEVEL_CODE AND TBL_A.JISSI_KAISU = TBL_B.JISSI_KAISU AND TBL_A.NINTEI_FLG = '1' ) TBL_C WHERE TBL_C.NINTEI_FLG = '1' "
						+ " GROUP BY TBL_C.SINDANSYA , TBL_C.SYOKU_CODE, TBL_C.SENMON_CODE, TBL_C.LEVEL_CODE, TBL_C.JISSI_KAISU )  AND NINTEI_FLG = '1' GROUP BY SINDANSYA, JISSI_NENGAPPI, SYOKU_CODE, SENMON_CODE, JISSI_KAISU ) AND NINTEI_FLG = '1' GROUP BY SINDANSYA, JISSI_NENGAPPI, LEVEL_CODE, SYOKU_CODE, SENMON_CODE, "
						+ " JISSI_KAISU ) AND NINTEI_FLG = '1' ORDER BY P24.SYOKU_CODE, P24.SENMON_CODE, P24.JISSI_KAISU DESC ";
					pstmt = dbConn.prepareStatement(sql);
					pstmt.setString(1, sosikiCode);
					pstmt.setString(2, kikan);

				} else {
					sql = " SELECT P24.SINDANSYA, P24.SYOKU_CODE, P24.SENMON_CODE, P24.LEVEL_CODE, P24.JISSI_KAISU, "
							+ " P24.HYOKASYA, P24.SINSEI_NENGAPPI, P24.SINSEI_JIKOKU, P24.SYORI_ZYOU_FLG, P24.HYOKA_SIND_FLG, "
							+ " P24.JISSI_NENGAPPI, P24.JISSI_JIKOKU, P24.GYOMU_KEIKEN_T_DO, P24.SKILL_T_DO, P24.SOUGOU_T_DO, P24.HYOKASYA_COMMENT FROM P24_ASSESSMENT_HYOKA_TBL P24 "
							+ " WHERE (SINDANSYA,JISSI_NENGAPPI,LEVEL_CODE,SOUGOU_T_DO) IN ( SELECT SINDANSYA,JISSI_NENGAPPI,LEVEL_CODE,MAX(SOUGOU_T_DO) FROM P24_ASSESSMENT_HYOKA_TBL "
							+ " WHERE (SINDANSYA,JISSI_NENGAPPI,LEVEL_CODE) IN ( SELECT SINDANSYA,JISSI_NENGAPPI,MAX(LEVEL_CODE) FROM P24_ASSESSMENT_HYOKA_TBL WHERE "
							+ " (SINDANSYA,JISSI_NENGAPPI) IN ( SELECT SINDANSYA,MAX(JISSI_NENGAPPI) FROM ( SELECT * FROM P24_ASSESSMENT_HYOKA_TBL WHERE SINDANSYA IN ( "
							+ " SELECT SIMEI_NO FROM T01_PERSONAL_TBL WHERE SOSIKI_CODE IN ( SELECT SOSIKI_CODE FROM T19_SOSIKI_TBL "
							+ " START WITH SOSIKI_CODE = ? CONNECT BY PRIOR SOSIKI_CODE = JOUI_SOSIKI_CODE ) AND HONMU_FLG = '1' AND GENSYOKU_TAISYOKU_FLG = '1' " + kengenCondition
							+ " ) AND JISSI_NENGAPPI BETWEEN ? AND ? ) WHERE NINTEI_FLG = '1' GROUP BY SINDANSYA ) AND NINTEI_FLG = '1' "
							+ " GROUP BY SINDANSYA,JISSI_NENGAPPI ) AND NINTEI_FLG = '1' GROUP BY SINDANSYA,JISSI_NENGAPPI,LEVEL_CODE ) AND NINTEI_FLG = '1' "
							+ " ORDER BY P24.SYOKU_CODE, P24.SENMON_CODE, P24.JISSI_KAISU DESC";

					pstmt = dbConn.prepareStatement(sql);
					pstmt.setString(1, sosikiCode);
					pstmt.setString(2, start);
					pstmt.setString(3, end);
				}
				rs = pstmt.executeQuery();
				result = this.resultFilter(rs, syokuData);

			} else if (mode.equals(PEF_JinzaiPortfolioEJBBean.MAX_LEVEL)) {
				// �ő僌�x���I�����
				if (kikanway.equals("0")) {
					sql = " SELECT P24.SINDANSYA, P24.SYOKU_CODE, P24.SENMON_CODE, P24.LEVEL_CODE, P24.JISSI_KAISU, "
							+ " P24.HYOKASYA, P24.SINSEI_NENGAPPI, P24.SINSEI_JIKOKU, P24.SYORI_ZYOU_FLG, P24.HYOKA_SIND_FLG, "
							+ " P24.JISSI_NENGAPPI, P24.JISSI_JIKOKU, P24.GYOMU_KEIKEN_T_DO, P24.SKILL_T_DO, P24.SOUGOU_T_DO, P24.HYOKASYA_COMMENT FROM P24_ASSESSMENT_HYOKA_TBL P24 WHERE"
							+ " (SINDANSYA,LEVEL_CODE,SOUGOU_T_DO,JISSI_NENGAPPI) IN ( SELECT SINDANSYA,LEVEL_CODE,SOUGOU_T_DO,MAX(JISSI_NENGAPPI) FROM P24_ASSESSMENT_HYOKA_TBL WHERE "
							+ " (SINDANSYA,LEVEL_CODE,SOUGOU_T_DO) IN ( SELECT SINDANSYA,LEVEL_CODE,MAX(SOUGOU_T_DO) FROM P24_ASSESSMENT_HYOKA_TBL WHERE (SINDANSYA,LEVEL_CODE) IN ( "
							+ " SELECT TBL_C.SINDANSYA,MAX(TBL_C.LEVEL_CODE) FROM ( "
							+ " SELECT TBL_A.SINDANSYA,TBL_A.JISSI_NENGAPPI,TBL_A.NINTEI_FLG,TBL_A.LEVEL_CODE from P24_ASSESSMENT_HYOKA_TBL TBL_A ,"
							+ " (SELECT TBL_AA.SINDANSYA, TBL_AA.SYOKU_CODE, TBL_AA.SENMON_CODE, TBL_AA.LEVEL_CODE, TBL_AA.JISSI_KAISU FROM P21_ASSESSMENT_SINDAN_TBL TBL_AA "
							+ " WHERE TBL_AA.SINDANSYA IN (SELECT SIMEI_NO FROM T01_PERSONAL_TBL WHERE SOSIKI_CODE IN (SELECT SOSIKI_CODE FROM T19_SOSIKI_TBL  START WITH SOSIKI_CODE = ? "
							+ " CONNECT BY PRIOR SOSIKI_CODE = JOUI_SOSIKI_CODE) AND HONMU_FLG = '1'  AND GENSYOKU_TAISYOKU_FLG = '1'" + kengenCondition + ") AND "
							+ " TBL_AA.CAREER_CHALLENGE_KIKAN_MEI = ? AND TBL_AA.CAREER_CHALLENGE_FLG = '1' ) TBL_B WHERE TBL_A.SINDANSYA = TBL_B.SINDANSYA AND "
							+ " TBL_A.SYOKU_CODE = TBL_B.SYOKU_CODE AND TBL_A.SENMON_CODE = TBL_B.SENMON_CODE AND TBL_A.LEVEL_CODE = TBL_B.LEVEL_CODE AND "
							+ " TBL_A.JISSI_KAISU = TBL_B.JISSI_KAISU AND TBL_A.NINTEI_FLG = '1')  TBL_C WHERE TBL_C.NINTEI_FLG = '1' "
							+ " AND TBL_C.JISSI_NENGAPPI BETWEEN ? AND ? GROUP BY TBL_C.SINDANSYA) AND NINTEI_FLG = '1' AND JISSI_NENGAPPI BETWEEN ? AND ? "
							+ " GROUP BY SINDANSYA,LEVEL_CODE) AND NINTEI_FLG = '1' AND JISSI_NENGAPPI BETWEEN ? AND ? GROUP BY SINDANSYA,LEVEL_CODE,SOUGOU_T_DO) "
							+ " AND NINTEI_FLG = '1' ORDER BY P24.SYOKU_CODE, P24.SENMON_CODE, P24.JISSI_KAISU DESC";
					pstmt = dbConn.prepareStatement(sql);
					pstmt.setString(1, sosikiCode);
					pstmt.setString(2, kikan);
					pstmt.setString(3, start);
					pstmt.setString(4, end);
					pstmt.setString(5, start);
					pstmt.setString(6, end);
					pstmt.setString(7, start);
					pstmt.setString(8, end);

				} else {
					sql = " SELECT P24.SINDANSYA, P24.SYOKU_CODE, P24.SENMON_CODE, P24.LEVEL_CODE, P24.JISSI_KAISU, "
							+ " P24.HYOKASYA, P24.SINSEI_NENGAPPI, P24.SINSEI_JIKOKU, P24.SYORI_ZYOU_FLG, P24.HYOKA_SIND_FLG, "
							+ " P24.JISSI_NENGAPPI, P24.JISSI_JIKOKU, P24.GYOMU_KEIKEN_T_DO, P24.SKILL_T_DO, P24.SOUGOU_T_DO, P24.HYOKASYA_COMMENT FROM P24_ASSESSMENT_HYOKA_TBL P24 WHERE"
							+ " (SINDANSYA,LEVEL_CODE,SOUGOU_T_DO,JISSI_NENGAPPI) IN ( SELECT SINDANSYA,LEVEL_CODE,SOUGOU_T_DO,MAX(JISSI_NENGAPPI) FROM P24_ASSESSMENT_HYOKA_TBL WHERE "
							+ " (SINDANSYA,LEVEL_CODE,SOUGOU_T_DO) IN ( SELECT SINDANSYA,LEVEL_CODE,MAX(SOUGOU_T_DO) FROM P24_ASSESSMENT_HYOKA_TBL WHERE (SINDANSYA,LEVEL_CODE) IN ( "
							+ " SELECT SINDANSYA,MAX(LEVEL_CODE) FROM ( SELECT * FROM P24_ASSESSMENT_HYOKA_TBL WHERE SINDANSYA IN ( SELECT SIMEI_NO FROM "
							+ " T01_PERSONAL_TBL WHERE SOSIKI_CODE IN ( SELECT SOSIKI_CODE FROM T19_SOSIKI_TBL START WITH SOSIKI_CODE = ? "
							+ " CONNECT BY PRIOR SOSIKI_CODE = JOUI_SOSIKI_CODE ) AND HONMU_FLG = '1' AND GENSYOKU_TAISYOKU_FLG = '1' " + kengenCondition + " ) "
							+ " AND JISSI_NENGAPPI BETWEEN ? AND ? ) WHERE NINTEI_FLG = '1' AND JISSI_NENGAPPI BETWEEN ? AND ? GROUP BY SINDANSYA) "
							+ " AND NINTEI_FLG = '1' AND JISSI_NENGAPPI BETWEEN ? AND ? GROUP BY SINDANSYA,LEVEL_CODE) AND NINTEI_FLG = '1' "
							+ " AND JISSI_NENGAPPI BETWEEN ? AND ? GROUP BY SINDANSYA,LEVEL_CODE,SOUGOU_T_DO ) AND NINTEI_FLG = '1' ORDER BY "
							+ " P24.SYOKU_CODE, P24.SENMON_CODE, P24.JISSI_KAISU DESC";
					pstmt = dbConn.prepareStatement(sql);
					pstmt.setString(1, sosikiCode);
					pstmt.setString(2, start);
					pstmt.setString(3, end);
					pstmt.setString(4, start);
					pstmt.setString(5, end);
					pstmt.setString(6, start);
					pstmt.setString(7, end);
					pstmt.setString(8, start);
					pstmt.setString(9, end);
				}

				rs = pstmt.executeQuery();
				result = this.resultFilter(rs, syokuData);

			} else {
				return result;
			}

			return result;

		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}

	}

	public ArrayList getSyokuMap(final String loginNo, final ArrayList syokuList, final HashMap syokuMap) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			sql = " SELECT CKM_SYOKUSYU_GROUP.SYOKU_GROUP_CODE, CKM_SYOKUSYU_GROUP.SYOKU_GROUP_NAME, CKM_SYOKUSYU_GROUP.HYOJI_JUNJO FROM CKM_SYOKUSYU_GROUP ORDER BY CKM_SYOKUSYU_GROUP.HYOJI_JUNJO ";

			pstmt = dbConn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			int cnt = 0;
			ArrayList tmp = new ArrayList();
			while (rs.next()) {
				tmp = new ArrayList();
				tmp.add(String.valueOf(cnt));
				tmp.add(rs.getString(2));
				tmp.add("0");
				tmp.add("0");
				syokuMap.put(rs.getString(1), tmp);
				syokuList.add(rs.getString(1));
				cnt++;
			}

			final ArrayList result = new ArrayList();
			result.add(syokuList);
			result.add(syokuMap);

			return result;

		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * ���x�����X�g�ƃ��x���}�b�v�𐶐�����
	 * @param loginNo
	 * @param levelList
	 * @param levelMap
	 * @throws SQLException
	 * @throws NamingException
	 */
	public ArrayList getLevelMap(final String loginNo, final ArrayList levelList, final HashMap levelMap, final int syokuCnt) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		final HashMap levelBunruiMap = new HashMap();
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			sql = " SELECT P12.LEVEL_CODE, P12.LEVEL_NAME, P12.LEVEL_BUNRUI_CODE, BUNRUI.LEVEL_BUNRUI_NAME FROM P12_C_LEVEL_NAME_TBL P12, "
					+ " CKM_LEVEL_BUNRUI BUNRUI WHERE P12.LEVEL_BUNRUI_CODE = BUNRUI.LEVEL_BUNRUI_CODE(+) ORDER BY P12.LEVEL_CODE DESC ";

			pstmt = dbConn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			ArrayList tmp = new ArrayList();
			ArrayList tmp2 = new ArrayList();
			final ArrayList tmpSyoku = new ArrayList();
			for (int i = 0; i < syokuCnt * 2; i++) {
				tmpSyoku.add("0");
			}
			while (rs.next()) {
				tmp = new ArrayList();
				tmp.add(rs.getString(4));
				tmp.add(rs.getString(2));
				tmp.add("0");
				tmp.add("0");
				tmp.add(tmpSyoku.clone());
				tmp.add(PZZ010_CharacterUtil.normalizedStr(rs.getString(3)));
				levelMap.put(rs.getString(1), tmp);
				tmp2 = new ArrayList();
				if (levelBunruiMap.containsKey(PZZ010_CharacterUtil.normalizedStr(rs.getString(3)))) {
					tmp2 = (ArrayList) levelBunruiMap.get(PZZ010_CharacterUtil.normalizedStr(rs.getString(3)));
					tmp2.set(4, String.valueOf(Integer.parseInt((String) tmp2.get(4)) + 1));
				} else {
					tmp2.add(rs.getString(4));
					tmp2.add("0");
					tmp2.add("0");
					tmp2.add(tmpSyoku.clone());
					tmp2.add("1");
				}
				levelBunruiMap.put(PZZ010_CharacterUtil.normalizedStr(rs.getString(3)), tmp2);
				levelList.add(rs.getString(1));
			}
			final ArrayList result = new ArrayList();
			result.add(levelList);
			result.add(levelMap);
			result.add(levelBunruiMap);

			return result;

		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	/**
	 * �K�w���O�̑g�D�̑g�D�R�[�h��Ԃ�
	 * @param loginNo
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 */
	public String getRootSosiki(final String loginNo) throws SQLException, NamingException {
		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);
			sql = "SELECT SOSIKI_CODE FROM T19_SOSIKI_TBL WHERE KAISOU = ?";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.setString(1, "0");
			rs = pstmt.executeQuery();
			rs.next();
			return rs.getString(1);
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}

	}

	/**
	 * ���ʃZ�b�g����d���f�f�҂̃f�[�^���������AArrayList��Ԃ��B
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private ArrayList resultFilter(final ResultSet rs, final ArrayList syokudata) throws SQLException {
		final ArrayList result = new ArrayList();
		final HashMap list = new HashMap();
		HashMap row = null;

		if (syokudata == null || syokudata.size() <= 0) {
			return result;
		}

		while (rs.next()) {
			row = new HashMap();
			if (!list.containsKey(rs.getString("SINDANSYA"))) {
				// �f�f�҂��d�����Ă��Ȃ�
				row.put("SINDANSYA", rs.getString("SINDANSYA"));
				row.put("SYOKU_CODE", rs.getString("SYOKU_CODE"));
				row.put("SENMON_CODE", rs.getString("SENMON_CODE"));
				row.put("LEVEL_CODE", rs.getString("LEVEL_CODE"));
				row.put("JISSI_KAISU", rs.getString("JISSI_KAISU"));
				row.put("HYOKASYA", rs.getString("HYOKASYA"));
				row.put("SINSEI_NENGAPPI", rs.getString("SINSEI_NENGAPPI"));
				row.put("SINSEI_JIKOKU", rs.getString("SINSEI_JIKOKU"));
				row.put("SYORI_ZYOU_FLG", rs.getString("SYORI_ZYOU_FLG"));
				row.put("HYOKA_SIND_FLG", rs.getString("HYOKA_SIND_FLG"));
				row.put("JISSI_NENGAPPI", rs.getString("JISSI_NENGAPPI"));
				row.put("JISSI_JIKOKU", rs.getString("JISSI_JIKOKU"));
				row.put("GYOMU_KEIKEN_T_DO", rs.getString("GYOMU_KEIKEN_T_DO"));
				row.put("SKILL_T_DO", rs.getString("SKILL_T_DO"));
				row.put("SOUGOU_T_DO", rs.getString("SOUGOU_T_DO"));
				row.put("HYOKASYA_COMMENT", rs.getString("HYOKASYA_COMMENT"));
				row.put("SYOKU_GROUP_CODE", "");

				// �L���ȐE��O���[�v�R�[�h��ݒ肷��
				for (int i = 0; i < syokudata.size(); i++) {
					final String[] syokuinfo = (String[]) syokudata.get(i);
					if (rs.getString("SYOKU_CODE").equals(syokuinfo[0])) {
						row.put("SYOKU_GROUP_CODE", syokuinfo[1]);
						break;
					}
				}

				list.put(row.get("SINDANSYA"), row);
			}
		}

		// ���ʂ�ArrayList�ɕϊ�
		final Iterator it = list.keySet().iterator();
		Object obj = new Object();
		while (it.hasNext()) {
			obj = it.next();
			result.add(list.get(obj));

		}
		return result;
	}

	// --- 20070117 K.takagi Add Sta---
	/**
	 * �A�Z�X�����g���Ԃ̎擾
	 * @param loginNo
	 * @return ArrayList �A�Z�X�����g���Ԃ̃��X�g
	 */
	public ArrayList getAssessmentKikanList(final String loginNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		final ArrayList assessmentKikanList = new ArrayList();

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			final String sql = " SELECT P33.SYURYO_NENGAPPI, P33.ASSESSMENT_KIKAN_MEI, P33.SEIGYO_NO, P33.KAISI_NENGAPPI, P33.KEIKAKU_KIKAN_MEI FROM "
					+ " P33_CAREER_CHALLENGE_KIKAN_TBL P33, ( SELECT SEIGYO_NO FROM P33_CAREER_CHALLENGE_KIKAN_TBL WHERE "
					+ " TOKIKAN_FLG = ?) TOKIKAN WHERE TOKIKAN.SEIGYO_NO >= P33.SEIGYO_NO ORDER BY P33.SEIGYO_NO DESC ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, PEF_JinzaiPortfolioEJBBean.TOKIKAN_FLG);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				final String seigyoNo = PZZ010_CharacterUtil.normalizedStr(rs.getString("SEIGYO_NO"));
				final String kaisiNgp = PZZ010_CharacterUtil.normalizedStr(rs.getString("KAISI_NENGAPPI"));
				final String shuryoNgp = PZZ010_CharacterUtil.normalizedStr(rs.getString("SYURYO_NENGAPPI"));
				final String kikanNm = PZZ010_CharacterUtil.normalizedStr(rs.getString("ASSESSMENT_KIKAN_MEI"));
				final String keikaku = PZZ010_CharacterUtil.normalizedStr(rs.getString("KEIKAKU_KIKAN_MEI"));

				assessmentKikanList.add(new String[] { seigyoNo, kaisiNgp, shuryoNgp, kikanNm, keikaku });
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			Log.method(loginNo, "OUT", "");
			return assessmentKikanList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

	// --- 20070117 K.takagi Add End---

	/**
	 * �L���ȐE��O���[�v���擾
	 * @param loginNo
	 * @return ArrayList �E��O���[�v���X�g
	 */
	public ArrayList getSyokuList(final String loginNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		final ArrayList syokulist = new ArrayList();
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);
			/* ���R�[�h�����擾 */
			String sql = "SELECT COUNT(*) FROM CKM_SYOKUSYU_GROUP, CKG_SYOKUSYU_GROUP WHERE CKM_SYOKUSYU_GROUP.SYOKU_GROUP_CODE = CKG_SYOKUSYU_GROUP.SYOKU_GROUP_CODE "
					+ "ORDER BY  CKG_SYOKUSYU_GROUP.SYOKU_CODE ";

			pstmt = dbConn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			final String zentei_cnt = rs.getString(1);

			PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);

			if (zentei_cnt.equals("0")) {
				return syokulist;
			}

			sql = "SELECT CKG_SYOKUSYU_GROUP.SYOKU_CODE, CKM_SYOKUSYU_GROUP.SYOKU_GROUP_CODE, CKM_SYOKUSYU_GROUP.SYOKU_GROUP_NAME, CKM_SYOKUSYU_GROUP.HYOJI_JUNJO "
					+ "FROM  CKM_SYOKUSYU_GROUP, CKG_SYOKUSYU_GROUP WHERE CKM_SYOKUSYU_GROUP.SYOKU_GROUP_CODE = CKG_SYOKUSYU_GROUP.SYOKU_GROUP_CODE ORDER BY CKG_SYOKUSYU_GROUP.SYOKU_CODE ";
			pstmt = dbConn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			String bksyoku_code = null;
			String syoku_code = null;
			String syoku_groupe = null;
			String bksyoku_groupe = null;
			int hyoji = 0;
			int bkhyoji = 0;
			long cnt = 0;
			String[] tmp = new String[3];

			while (rs.next()) {
				cnt++;
				syoku_code = rs.getString(1);
				syoku_groupe = rs.getString(2);
				hyoji = rs.getInt(4);

				if (syoku_code.equals(bksyoku_code)) {
					if (hyoji <= bkhyoji) {
						bksyoku_code = syoku_code;
						bksyoku_groupe = syoku_groupe;
						bkhyoji = hyoji;
					}
				} else {
					if (cnt != 1) {
						tmp = new String[3];
						tmp[0] = bksyoku_code;
						tmp[1] = bksyoku_groupe;
						tmp[2] = String.valueOf(bkhyoji);
						syokulist.add(tmp);
					}
					bksyoku_code = syoku_code;
					bksyoku_groupe = syoku_groupe;
					bkhyoji = hyoji;
				}
			}
			// �ŏI�s
			tmp = new String[3];
			tmp[0] = bksyoku_code;
			tmp[1] = bksyoku_groupe;
			tmp[2] = String.valueOf(bkhyoji);
			syokulist.add(tmp);

			Log.method(loginNo, "OUT", "");
			return syokulist;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}

}
