/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.base.portal.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.base.portal.bean.PYB_KenshuOshiraseValueBean;
import jp.co.hisas.career.base.portal.bean.PYB_KenshuValueBean;
import jp.co.hisas.career.base.portal.bean.PYB_KnowledgeRegistrantValueBean;
import jp.co.hisas.career.base.portal.bean.PYB_KnowledgeValueBean;
import jp.co.hisas.career.base.portal.bean.PYB_LoginOshiraseValueBean;
import jp.co.hisas.career.base.portal.model.PYB_PortalConfigModel;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;

/**
 * �|�[�^������Ɋւ���EJBBean
 */
public class PYB_PortalEJBBean implements SessionBean {
	/** �R���e�L�X�g */
	private SessionContext context = null;

	/** �w�肵�����[�U�����p�\�ȃ|�[�^���̈ꗗ���擾����SQL(���i�p) */
	private static String SELECT_PORTALID_SQL = "SELECT DISTINCT PORTAL_ID, PORTAL_NAME FROM CJM_PORTAL WHERE KINO_ID IS NULL OR KINO_ID IN "
			+ "(SELECT DISTINCT KINO_ID FROM CCP_KINOU_RIYOU_KANRI KINO WHERE KINO.SHAIN_BUNRUI_CODE IN "
			+ "(SELECT SHOKUI.SHAIN_BUNRUI_CODE FROM CCP_SHAIN_BUNRUI_TEIGI SHOKUI, CCP_SHAIN_BUNRUI_TEIGI YAKUSHOKU, T01_PERSONAL_TBL T01 "
			+ "WHERE SHOKUI.MASTER_ZOKUSEI_ID = 'SHOKUI' AND SHOKUI.MASTER_ID = T01.SYOKUI_CODE "
			+ "AND YAKUSHOKU.MASTER_ZOKUSEI_ID = 'YAKUSHOKU' AND YAKUSHOKU.MASTER_ID = T01.YAKUSYOKU_CODE AND SHOKUI.SHAIN_BUNRUI_CODE = YAKUSHOKU.SHAIN_BUNRUI_CODE AND T01.SIMEI_NO = ? AND T01.SOSIKI_CODE = ?))";

	/** �w�肵�����[�U�����p�\�ȃ|�[�^���̈ꗗ���擾����SQL(Career@Net�p) */
	private static String SELECT_PORTALID_CAREERNET_SQL = "SELECT DISTINCT PORTAL_ID, PORTAL_NAME FROM CJM_PORTAL WHERE KINO_ID IS NULL OR KINO_ID IN "
			+ "(SELECT DISTINCT KINO_ID FROM CCP_KINOU_RIYOU_KANRI KINO WHERE KINO.SHAIN_BUNRUI_CODE IN "
			+ "(SELECT YAKUSHOKU.SHAIN_BUNRUI_CODE FROM CCP_SHAIN_BUNRUI_TEIGI YAKUSHOKU, T01_PERSONAL_TBL T01 "
			+ "WHERE YAKUSHOKU.MASTER_ZOKUSEI_ID = 'YAKUSHOKU' AND YAKUSHOKU.MASTER_ID = T01.YAKUSYOKU_CODE AND T01.SIMEI_NO = ? AND T01.SOSIKI_CODE = ?))";

	/** �w�肵�����[�U�A�w�肵���|�[�^���̌l�ݒ���擾����SQL */
	private static String SELECT_PORTAL_PERSONAL_SQL = "SELECT HYOJI_FLAG, HYOJI_JUNJO, SOUSA_FLAG FROM CJS_PORTAL_PERSONAL WHERE PORTAL_ID = ? AND SIMEI_NO = ? AND SOSIKI_CODE = ?";

	/** �w�肵�����[�U�A�w�肵���|�[�^���̌l�ݒ���폜����SQL */
	private static String DELETE_PORTAL_PERSONAL_SQL = "DELETE FROM CJS_PORTAL_PERSONAL WHERE PORTAL_ID = ? AND SIMEI_NO = ? AND SOSIKI_CODE = ?";

	/** �w�肵�����[�U�A�w�肵���|�[�^���̌l�ݒ��ǉ�����SQL */
	private static String INSERT_PORTAL_PERSONAL_SQL = "INSERT INTO CJS_PORTAL_PERSONAL (SIMEI_NO, SOSIKI_CODE, PORTAL_ID, HYOJI_FLAG, HYOJI_JUNJO, SOUSA_FLAG) VALUES (?, ?, ?, ?, ?, ?)";

	/** �w�肵�����[�U�A�w�肵���|�[�^���̃p�����[�^���擾����SQL */
	private static String SELECT_PORTAL_PARAMETER_SQL = "SELECT PARAM_ID, VALUE FROM CJP_PORTAL_PARAM WHERE PORTAL_ID = ? AND SIMEI_NO = ? AND SOSIKI_CODE = ?";

	/** ���O�C�����m�点�����擾����SQL �����F�\���t���O=1 */
	private static String SELECT_LOGIN_OSHIRASE_SQL = "SELECT OSIRASE_NENGAPPI_JIKOKU, OSIRASE_JYOHO, HYOJI_FLG FROM T11_LOGIN_OSIRASE_TBL WHERE HYOJI_FLG = '1' ORDER BY OSIRASE_NENGAPPI_JIKOKU DESC";

	/** ���C���m�点�����擾����SQL �����F�\���t���O=1 */
	private static String SELECT_KENSHU_OSHIRASE_SQL = "SELECT SEQ_NO, HAKKOUBI, HAKKOUJIKOKU, SYUBETSU_FLG, KIGENBI, NAIYOU, TSUUTATSU_PAGE, HYOUJI_FLG, TOUROKUBI, TOUROKUJIKOKU, TOUROKUSYA, KOUSINBI, KOUSINJIKOKU, KOUSINSYA FROM L52_LEARNING_OSIRASE_TBL WHERE HYOUJI_FLG = '1' ORDER BY HAKKOUBI DESC, HAKKOUJIKOKU ASC";

	/** ���C�����擾�����{SQL */
	private static String SELECT_KENSHU_BASE_SQL = "SELECT DISTINCT L01.KAMOKU_CODE AS KAMOKU_CODE, L01.KAMOKU_MEI1 AS KAMOKU_NAME, L01.KAMOKU_GROUP AS KAMOKU_GROUP_CODE, "
			+ "P15.KAMOKU_GROUP AS KAMOKU_GROUP_NAME, L01.CATEGORY_CODE1 AS CATEGORY_CODE1, L03.CATEGORY_MEI1 AS CATEGORY_NAME1, L01.CATEGORY_CODE2 AS CATEGORY_CODE2, L04.CATEGORY_MEI2 AS CATEGORY_NAME2, "
			+ "L01.CATEGORY_CODE3 AS CATEGORY_CODE3, L05.CATEGORY_MEI3 AS CATEGORY_NAME3, L01.CATEGORY_CODE4 AS CATEGORY_CODE4, L06.CATEGORY_MEI4 AS CATEGORY_NAME4, L01.CATEGORY_CODE5 AS CATEGORY_CODE5, "
			+ "L07.CATEGORY_MEI5 AS CATEGORY_NAME5, L01.KANRIMOTO_CODE AS KANRIMOTO_CODE, L08.KANRIMOTO_MEI AS KANRIMOTO_NAME, L01.KAMOKU_NAIYOU AS KAMOKU_NAIYOU, L01.JYUKOU_JYOKEN AS JUKO_JOKEN, "
			+ "L01.YOBI1 AS KAMOKU_YOBI1, L01.YOBI2 AS KAMOKU_YOBI2, L02.CLASS_CODE AS CLASS_CODE, L02.CLASS_MEI AS CLASS_NAME, L02.NISSUU AS NISUU, L02.KAISIBI AS CLASS_KAISIBI, "
			+ "L02.SYURYOBI AS CLASS_SHURYOBI, L02.KAISAIJIKAN AS KAISAI_JIKAN, L02.KAISIJIKOKU AS KAISHI_JIKOKU, L02.SYURYOJIKOKU AS SHURYO_JIKOKU, L02.MOUSIKOMI_KAISIBI AS MOUSHIKOMI_KAISHIBI, "
			+ "L02.MOUSIKOMI_SYURYOBI AS MOUSHIKOMI_SHURYOBI, L02.JYUKOU_KIGEN AS JUKO_KIGENBI, L02.CHIKU_CODE AS CHIKU_CODE, L09.CHIKU_MEI AS CHIKU_NAME1, L02.CHIKU_MEI AS CHIKU_NAME2, "
			+ "L02.KYOSITU_CODE AS KYOSHITSU_CODE, L10.KYOSITU_MEI AS KYOSHITSU_NAME1, L10.ANNAIZU AS ANNAIZU, L02.KYOSITU_MEI AS KYOSHITSU_NAME2, L02.TEIIN AS TEIIN, L02.KAISAI_SAISYO_NINZUU AS KAISAI_SAISHO_NINZU, "
			+ "L02.KOUSI_CODE AS KOUSHI_CODE, L11.KOUSI_MEI AS KOUSHI_NAME1, L02.KOUSI_MEI AS KOUSHI_NAME2, L02.KISYO_IKKATSU_FLG AS KISHO_IKKATSU_FLAG, L02.ZENSYA_TAISYO_FLG AS ZENSYA_TAISHO_FLAG, "
			+ "L02.MOUSIKOMI_KUBUN AS MOUSHIKOMI_KUBUN, L02.SYONIN_KUBUN AS SHONIN_KUBUN, L02.UKETUKE_KUBUN AS UKETSUKE_KUBUN, L02.HOUKOKU_KUBUN AS HOUKOKU_KUBUN, L02.NINSYO_KUBUN AS NINSHO_KUBUN, "
			+ "L02.HANTEI_KUBUN AS HANTEI_KUBUN, L02.KAISAI_JYOTAI AS KAISAI_KUBUN, L02.MANSEKI_FLG AS MANSEKI_FLAG, L02.ANNAI_MAIL_KUBUN AS ANNAI_MAIL_KUBUN, L02.FOLLOW_MAIL_KUBUN AS FOLLOW_MAIL_KUBUN, "
			+ "L02.FOLLOW_MAIL_NISSUU1 AS FOLLOW_MAIL_NISSUU1, L02.FOLLOW_MAIL_NISSUU2 AS FOLLOW_MAIL_NISSUU2, L02.BIKOU AS CLASS_BIKOU, L02.SAKUJYO_FLG AS SAKUJO_FLAG, L02.YOYAKU AS YOYAKUSUU, "
			+ "L02.TANKA AS KINGAKU, L15.SIMEI_NO AS TARGET_SHIMEI_NO, SUBSTR(T01.KANJI_SIMEI, 2) AS TARGET_SHIMEI, T01.SOSIKI_CODE AS TARGET_SOSHIKI_CODE, T19.BUSYO_RYAKUSYO_MEI AS TARGET_SOSHIKI_NAME, "
			+ "L15.STATUS AS TARGET_STATUS, L15.UKETSUKE_JYOTAI AS TARGET_UKETSUKE_JOTAI FROM L15_MOUSIKOMI_JYOKYO_TBL L15, T01_PERSONAL_TBL T01, T19_SOSIKI_TBL T19, P15_C_KAMOKU_GROUP_TBL P15, "
			+ "L11_KOUSI_TBL L11, L10_KYOSITU_TBL L10, L09_CHIKU_TBL L09, L08_KANRIMOTO_TBL L08, L07_CATEGORY5_TBL L07, L06_CATEGORY4_TBL L06, L05_CATEGORY3_TBL L05, L04_CATEGORY2_TBL L04, "
			+ "L03_CATEGORY1_TBL L03, L02_CLASS_TBL L02, L01_KAMOKU_TBL L01 WHERE L15.KAMOKU_CODE = L01.KAMOKU_CODE AND L15.KAMOKU_CODE = L02.KAMOKU_CODE AND L15.CLASS_CODE = L02.CLASS_CODE "
			+ "AND L02.CHIKU_CODE = L09.CHIKU_CODE(+) AND L02.KYOSITU_CODE = L10.KYOSITU_CODE(+) AND L02.KOUSI_CODE = L11.KOUSI_CODE(+) AND L01.KAMOKU_GROUP = P15.KAMOKU_GROUP_CODE(+) "
			+ "AND L01.CATEGORY_CODE1 = L03.CATEGORY_CODE1(+) AND L01.CATEGORY_CODE2 = L04.CATEGORY_CODE2(+) AND L01.CATEGORY_CODE3 = L05.CATEGORY_CODE3(+) AND L01.CATEGORY_CODE4 = L06.CATEGORY_CODE4(+)"
			+ "AND L01.CATEGORY_CODE5 = L07.CATEGORY_CODE5(+) AND L01.KANRIMOTO_CODE = L08.KANRIMOTO_CODE(+) AND T19.SOSIKI_CODE = T01.SOSIKI_CODE AND L15.SIMEI_NO = T01.SIMEI_NO AND T01.HONMU_FLG = '1' ";

	/** �{�l�̎w�肵�����ԓ��Ɏ�u�\��̋�����擾����SQL */
	private static String SELECT_KENSHU_HONNIN_SQL = PYB_PortalEJBBean.SELECT_KENSHU_BASE_SQL
			+ " AND L15.SIMEI_NO = ? AND L02.KAISIBI <= ? AND L02.SYURYOBI >= ? ORDER BY L02.KAISIBI ASC, L02.SYURYOBI ASC";

	/** ���C���F�҂̏��F�Ώۂ̎Ј������ԓ��Ɏ�u�\��̋����\������SQL */
	private static String SELECT_KENSHU_SHONINSYA_SQL = PYB_PortalEJBBean.SELECT_KENSHU_BASE_SQL
			+ " AND L15.SIMEI_NO IN (SELECT DISTINCT SIMEI_NO FROM L16_SYONINSYA_TBL WHERE SYONINSYA1 = ? OR (SYONINSYA2 = ? AND DAIKOUSYA_FLG = '1')) AND L02.KAISIBI <= ? AND L02.SYURYOBI >= ? ORDER BY L15.SIMEI_NO ASC, L02.KAISIBI ASC, L02.SYURYOBI ASC";

	/** �w�肵������No�A�g�D�R�[�h�A�|�[�^��ID�̑S�|�[�^���p�����[�^���폜����SQL */
	private static String DELETE_PORTAL_PARAMETER_SQL = "DELETE FROM CJP_PORTAL_PARAM WHERE SIMEI_NO = ? AND SOSIKI_CODE = ? AND PORTAL_ID = ?";

	/** �|�[�^���p�����[�^��ǉ�����SQL */
	private static String INSERT_PORTAL_PARAMETER_SQL = "INSERT INTO CJP_PORTAL_PARAM (SIMEI_NO, SOSIKI_CODE, PORTAL_ID, PARAM_ID, VALUE) VALUES (?, ?, ?, ?, ?)";

	/** �w�肵���g�D�ɑ΂��Č��J����Ă���i���b�W�h�L�������g�̏����_�E�����[�h�񐔂̑������Ɏ擾����SQL */
	private static String SELECT_KNOWLEDGE_INFO_BASE_SQL = "SELECT  DOC.DOCUMENT_ID AS DOCUMENT_ID, DOC.DOCUMENT_NAME AS DOCUMENT_NAME, DOC.FILE_NAME AS FILE_NAME, DOC.SETUMEI AS SETSUMEI, "
			+ "DOC.CATEGORY_CODE AS CATEGORY_CODE, CAT.CATEGORY_NAME AS CATEGORY_NAME, DOC.KOKAI_FLG AS KOKAI_FLAG, DOC.KOKAIHANI_SOSIKI_CODE AS KOKAIHANI_SOSHIKI_CODE, "
			+ "T19_2.BUSYO_RYAKUSYO_MEI AS KOKAIHANI_SOSHIKI_NAME, DOC.TOUROKU_SIMEI_NO AS TOUROKUSHA_SHIMEI_NO, SUBSTR(T01.KANJI_SIMEI, 2) AS TOUROKUSHA_SHIMEI, DOC.TOUROKUSYA_SOSIKI_CODE AS TOUROKUSHA_SOSHIKI_CODE, "
			+ "T19.BUSYO_RYAKUSYO_MEI AS TOUROKUSHA_SOSHIKI_NAME, DOC.TOUROKUSYA_TOUROKU_NENGAPPI AS TOUROKU_NENGAPPI, DOC.TOUROKUSYA_TOUROKU_JIKOKU AS TOUROKU_JIKOKU, DOC.SYOUNINSYA_TOUROKU_NENGAPPI AS SHONIN_NENGAPPI, "
			+ "DOC.SYOUNINSYA_TOUROKU_JIKOKU AS SHONIN_JIKOKU, DOC.DOWNLOAD_KAISU AS DOWNLOAD_COUNT FROM CJM_CATEGORY CAT, T19_SOSIKI_TBL T19, T19_SOSIKI_TBL T19_2, T01_PERSONAL_TBL T01, CJG_DOCUMENT DOC "
			+ "WHERE KOKAIHANI_SOSIKI_CODE IN (SELECT DISTINCT SOSIKI_CODE FROM (SELECT SOSIKI_CODE FROM T19_SOSIKI_TBL START WITH SOSIKI_CODE = ? CONNECT BY PRIOR JOUI_SOSIKI_CODE = SOSIKI_CODE "
			+ "UNION SELECT SOSIKI_CODE FROM T19_SOSIKI_TBL START WITH SOSIKI_CODE = ? CONNECT BY PRIOR SOSIKI_CODE = JOUI_SOSIKI_CODE)) "
			+ "AND DOC.TOUROKU_SIMEI_NO = T01.SIMEI_NO AND T01.SOSIKI_CODE = T19.SOSIKI_CODE(+) AND T01.HONMU_FLG = '1' AND DOC.KOKAIHANI_SOSIKI_CODE = T19_2.SOSIKI_CODE(+) AND DOC.CATEGORY_CODE = CAT.CATEGORY_CODE(+)";

	/** �w�肵���g�D�ɑ΂��Č��J����Ă���i���b�W�h�L�������g�̏����_�E�����[�h�񐔂̑������Ɏ擾����SQL */
	private static String SELECT_KNOWLEDGE_DOWNLOAD_RANK_SQL = PYB_PortalEJBBean.SELECT_KNOWLEDGE_INFO_BASE_SQL + " ORDER BY DOC.DOWNLOAD_KAISU DESC, DOC.DOCUMENT_ID ASC";

	/** �w�肵���g�D�ɑ΂��Č��J����Ă���i���b�W�h�L�������g�̏����_�E�����[�h�񐔂̑������Ɏ擾����SQL */
	private static String SELECT_KNOWLEDGE_NEW_FILE_SQL = PYB_PortalEJBBean.SELECT_KNOWLEDGE_INFO_BASE_SQL
			+ "  ORDER BY DOC.DOCUMENT_ID DESC ";

	/** �w�肵���g�D�ɑ΂��Č��J����Ă���i���b�W�h�L�������g�̓o�^�҂̖{������o�^���̑������Ɏ擾����SQL */
	private static String SELECT_KNOWLEDGE_REGSTER_RANK_SQL = "SELECT DOC.CNT AS CNT , DOC.SHIMEI_NO AS SHIMEI_NO, SUBSTR(T01.KANJI_SIMEI, 2) AS SHIMEI, T01.SOSIKI_CODE AS SOSHIKI_CODE, T19.BUSYO_RYAKUSYO_MEI AS SOSHIKI_NAME, "
			+ "T01.YAKUSYOKU_CODE AS YAKUSYOKU_CODE, T15.YAKUSYOKU AS YAKUSHOKU_NAME, T01.SYOKUI_CODE AS SHOKUI_CODE, T31.SYOKUI AS SHOKUI_NAME FROM T31_SYOKUI_TBL T31, T15_YAKUSYOKU_TBL T15, T19_SOSIKI_TBL T19, T01_PERSONAL_TBL T01, "
			+ "(SELECT TOUROKU_SIMEI_NO AS SHIMEI_NO, COUNT(*) AS CNT FROM T01_PERSONAL_TBL T01, CJG_DOCUMENT DOC WHERE DOC.KOKAIHANI_SOSIKI_CODE IN (SELECT DISTINCT SOSIKI_CODE FROM "
			+ "(SELECT SOSIKI_CODE FROM T19_SOSIKI_TBL START WITH SOSIKI_CODE = ? CONNECT BY PRIOR JOUI_SOSIKI_CODE = SOSIKI_CODE UNION SELECT SOSIKI_CODE FROM T19_SOSIKI_TBL START WITH SOSIKI_CODE = ? "
			+ "CONNECT BY PRIOR SOSIKI_CODE = JOUI_SOSIKI_CODE)) AND T01.SIMEI_NO = DOC.TOUROKU_SIMEI_NO AND T01.HONMU_FLG =  '1' GROUP BY TOUROKU_SIMEI_NO) DOC "
			+ "WHERE T01.SIMEI_NO = DOC.SHIMEI_NO AND T01.HONMU_FLG = '1' AND T01.SOSIKI_CODE = T19.SOSIKI_CODE(+) AND T01.YAKUSYOKU_CODE = T15.YAKUSYOKU_CODE(+) AND T01.SYOKUI_CODE = T31.SYOKUI_CODE(+) ORDER BY CNT DESC, SHIMEI_NO ASC";

	/**
	 * ���[�U�����p�\�ȃ|�[�^��ID,�|�[�^�������擾����<br>
	 * �Ώۂ́A�|�[�^���@�\�e�[�u��(CJM_PORATAL)�ɒ�`����Ă���f�[�^�̂����A�@�\���p�Ǘ�ID�����w��̂��̂� �Ώێҋ@�\���p�Ǘ�ID��
	 * @param shimeiNo �ΏێҎ���No
	 * @param soshikiCode �Ώێґg�D�R�[�h
	 * @return key:�|�[�^��ID, value:�|�[�^������Map
	 * @throws NamingException �f�[�^�\�[�X�擾���s
	 * @throws SQLException SQL�s��
	 */
	public HashMap getPortalList(final String shimeiNo, final String soshikiCode) throws NamingException, SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		final HashMap result = new HashMap();

		if (shimeiNo == null || shimeiNo.length() == 0 || soshikiCode == null || soshikiCode.length() == 0) {
			return result;
		}

		try {
			con = PZZ040_SQLUtility.getConnection(shimeiNo);
			if (true) {// ��ɐ��i
				ps = con.prepareStatement(PYB_PortalEJBBean.SELECT_PORTALID_SQL);
			} else {
				ps = con.prepareStatement(PYB_PortalEJBBean.SELECT_PORTALID_CAREERNET_SQL);
			}
			ps.setString(1, shimeiNo);
			ps.setString(2, soshikiCode);
			rs = ps.executeQuery();

			while (rs.next()) {
				result.put(rs.getString("PORTAL_ID"), rs.getString("PORTAL_NAME"));
			}

			return result;
		} catch (final SQLException e) {
			Log.error(shimeiNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(shimeiNo, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(shimeiNo, con, ps, rs);
		}
	}

	/**
	 * �w�肵�����[�U�A�|�[�^���̃|�[�^���l�ʐݒ���擾����
	 * @param portalId �|�[�^��ID
	 * @param shimeiNo �ΏێҎ���No
	 * @param soshikiCode �Ώێґg�D�R�[�h
	 * @return �l�ʐݒ�Map(key:HYOJI_FLAG, HYOJI_JUNJO, SOUSA_FLAG)
	 * @throws NamingException �f�[�^�\�[�X�擾���s
	 * @throws SQLException SQL�s��
	 */
	public HashMap getProtalPersonal(final String portalId, final String shimeiNo, final String soshikiCode) throws SQLException, NamingException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		final HashMap result = new HashMap();

		if (portalId == null || portalId.length() == 0 || shimeiNo == null || shimeiNo.length() == 0 || soshikiCode == null || soshikiCode.length() == 0) {
			return result;
		}

		try {
			con = PZZ040_SQLUtility.getConnection(shimeiNo);
			ps = con.prepareStatement(PYB_PortalEJBBean.SELECT_PORTAL_PERSONAL_SQL);
			ps.setString(1, portalId);
			ps.setString(2, shimeiNo);
			ps.setString(3, soshikiCode);
			rs = ps.executeQuery();

			while (rs.next()) {
				result.put("HYOJI_FLAG", rs.getString("HYOJI_FLAG"));
				result.put("HYOJI_JUNJO", new Integer(rs.getInt("HYOJI_JUNJO")));
				result.put("SOUSA_FLAG", rs.getString("SOUSA_FLAG"));
			}

			return result;
		} catch (final SQLException e) {
			Log.error(shimeiNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(shimeiNo, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(shimeiNo, con, ps, rs);
		}

	}

	/**
	 * �w�肵���|�[�^���̃|�[�^���ݒ�����X�V����(DELETE, INSERT)
	 * @param configModel �|�[�^���ݒ���
	 * @throws SQLException SQL��O
	 * @throws NamingException �f�[�^�\�[�X�擾���s
	 */
	public void updateProtalConfig(final PYB_PortalConfigModel configModel) throws SQLException, NamingException {
		Connection con = null;
		PreparedStatement ps = null;

		if (configModel == null) {
			return;
		}

		try {
			con = PZZ040_SQLUtility.getConnection(configModel.getShimeiNo());

			// �l�ݒ�폜
			ps = con.prepareStatement(PYB_PortalEJBBean.DELETE_PORTAL_PERSONAL_SQL);
			ps.setString(1, configModel.getPortalID());
			ps.setString(2, configModel.getShimeiNo());
			ps.setString(3, configModel.getSoshikiCode());
			ps.executeUpdate();

			PZZ040_SQLUtility.closeConnection(configModel.getShimeiNo(), null, ps, null);

			// �l�ݒ�ǉ�
			ps = con.prepareStatement(PYB_PortalEJBBean.INSERT_PORTAL_PERSONAL_SQL);
			ps.setString(1, configModel.getShimeiNo());
			ps.setString(2, configModel.getSoshikiCode());
			ps.setString(3, configModel.getPortalID());
			ps.setString(4, configModel.isDispFlag() ? "1" : "0");
			ps.setInt(5, configModel.getSortOrder());
			ps.setString(6, configModel.isControllFlag() ? "1" : "0");
			ps.executeUpdate();

			PZZ040_SQLUtility.closeConnection(configModel.getShimeiNo(), null, ps, null);
			
			// �p�����[�^�S�f�[�^�폜
			ps = con.prepareStatement(PYB_PortalEJBBean.DELETE_PORTAL_PARAMETER_SQL);
			ps.setString(1, configModel.getShimeiNo());
			ps.setString(2, configModel.getSoshikiCode());
			ps.setString(3, configModel.getPortalID());
			ps.executeUpdate();

			// �p�����[�^�S�f�[�^�ǉ�
			PZZ040_SQLUtility.closeConnection(PZZ010_CharacterUtil.normalizedStr(configModel.getShimeiNo()), null, ps, null);
			ps = con.prepareStatement(PYB_PortalEJBBean.INSERT_PORTAL_PARAMETER_SQL);
			ps.setString(1, configModel.getShimeiNo());
			ps.setString(2, configModel.getSoshikiCode());
			ps.setString(3, configModel.getPortalID());
			for (final Iterator iterator = configModel.getParameter().keySet().iterator(); iterator.hasNext();) {
				final String paramId = (String) iterator.next();
				ps.setString(4, paramId);
				ps.setString(5, (String) configModel.getParameter().get(paramId));
				ps.executeUpdate();
			}
		} catch (final SQLException e) {
			Log.error(configModel.getShimeiNo(), e);
			throw e;
		} catch (final NamingException e) {
			Log.error(configModel.getShimeiNo(), e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(configModel.getShimeiNo(), con, ps, null);
		}
	}

	/**
	 * �w�肵���|�[�^��ID�A����No�A�g�D�R�[�h�Ɉ�v����p�����[�^�̈ꗗ���擾����
	 * @param portalId �|�[�^��ID
	 * @param shimeiNo �ΏێҎ���No
	 * @param soshikiCode �Ώێґg�D�R�[�h
	 * @return �p�����[�^ID�ƒl��Map
	 * @throws NamingException �f�[�^�\�[�X�擾���s
	 * @throws SQLException SQL�s��
	 */
	public HashMap getPortalParameter(final String portalId, final String shimeiNo, final String soshikiCode) throws NamingException, SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		final HashMap result = new HashMap();

		if (portalId == null || portalId.length() == 0 || shimeiNo == null || shimeiNo.length() == 0 || soshikiCode == null || soshikiCode.length() == 0) {
			return result;
		}

		try {
			con = PZZ040_SQLUtility.getConnection(shimeiNo);
			ps = con.prepareStatement(PYB_PortalEJBBean.SELECT_PORTAL_PARAMETER_SQL);
			ps.setString(1, portalId);
			ps.setString(2, shimeiNo);
			ps.setString(3, soshikiCode);
			rs = ps.executeQuery();

			while (rs.next()) {
				result.put(rs.getString("PARAM_ID"), rs.getString("VALUE"));
			}

			return result;
		} catch (final SQLException e) {
			Log.error(shimeiNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(shimeiNo, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(shimeiNo, con, ps, rs);
		}

	}

	/**
	 * ���O�C�����m�点���̃��X�g��Ԃ�
	 * @param shimeiNo �����˗����[�U�̎���No
	 * @return ���O�C�����m�点���̃��X�g
	 * @throws NamingException �f�[�^�\�[�X�擾���s
	 * @throws SQLException SQL�s��
	 */
	public ArrayList getLoginOshiraseList(final String shimeiNo) throws NamingException, SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		final ArrayList result = new ArrayList();

		try {
			con = PZZ040_SQLUtility.getConnection(shimeiNo);
			ps = con.prepareStatement(PYB_PortalEJBBean.SELECT_LOGIN_OSHIRASE_SQL);
			rs = ps.executeQuery();

			while (rs.next()) {
				final PYB_LoginOshiraseValueBean oshirase = new PYB_LoginOshiraseValueBean();
				oshirase.setOshiraseJikoku(rs.getString("OSIRASE_NENGAPPI_JIKOKU"));
				oshirase.setOshiraseJoho(rs.getString("OSIRASE_JYOHO"));
				oshirase.setHyojiFlag(rs.getString("HYOJI_FLG"));

				result.add(oshirase);
			}

			return result;
		} catch (final SQLException e) {
			Log.error(shimeiNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(shimeiNo, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(shimeiNo, con, ps, rs);
		}

	}

	/**
	 * ���C���m�点���̃��X�g��Ԃ�
	 * @param shimeiNo �����˗����[�U�̎���No
	 * @return ���C���m�点���̃��X�g
	 * @throws NamingException �f�[�^�\�[�X�擾���s
	 * @throws SQLException SQL�s��
	 */
	public ArrayList getKenshuOshiraseList(final String shimeiNo) throws NamingException, SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		final ArrayList result = new ArrayList();

		try {
			con = PZZ040_SQLUtility.getConnection(shimeiNo);
			ps = con.prepareStatement(PYB_PortalEJBBean.SELECT_KENSHU_OSHIRASE_SQL);
			rs = ps.executeQuery();

			// �������ʕ����C���m�点Bean���쐬
			while (rs.next()) {
				final PYB_KenshuOshiraseValueBean oshirase = new PYB_KenshuOshiraseValueBean();
				oshirase.setSeqNo(rs.getString("SEQ_NO"));
				oshirase.setHakkoubi(rs.getString("HAKKOUBI"));
				oshirase.setHakkouJikoku(rs.getString("HAKKOUJIKOKU"));
				oshirase.setShubetsuFlag(rs.getString("SYUBETSU_FLG"));
				oshirase.setKigenbi(rs.getString("KIGENBI"));
				oshirase.setNaiyou(rs.getString("NAIYOU"));
				oshirase.setTsutatsuPage(rs.getString("TSUUTATSU_PAGE"));
				oshirase.setHyojiFlag(rs.getString("HYOUJI_FLG"));

				result.add(oshirase);
			}

			return result;
		} catch (final SQLException e) {
			Log.error(shimeiNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(shimeiNo, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(shimeiNo, con, ps, rs);
		}
	}

	/**
	 * �w�肳�ꂽ���ԓ��Ɏw�肵�����[�U����u�\�苳��̃��X�g��Ԃ��B<br>
	 * �����Ώۊ��Ԃ�0�̏ꍇ�A���Ԏw��Ȃ��Ō�������B
	 * @param shimeiNo �����˗����[�U�̎���No
	 * @param targetShimeiNo �����Ώۂ̎���No
	 * @param searchMonth �����Ώۊ���
	 * @return ���C���m�点���̃��X�g
	 * @throws NamingException �f�[�^�\�[�X�擾���s
	 * @throws SQLException SQL�s��
	 */
	public ArrayList getHonninKenshuYoteiList(final String shimeiNo, final String targetShimeiNo, final int searchMonth) throws NamingException, SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		final ArrayList result = new ArrayList();

		if (targetShimeiNo == null || targetShimeiNo.length() == 0) {
			return result;
		}

		try {
			String startDate = "99991231";
			String endDate = "19000101";

			// �������Ԃ�ݒ�
			if (searchMonth > 0) {
				// �I�����ɃV�X�e�����t��ݒ�
				endDate = PZZ010_CharacterUtil.GetDay();
				// �J�n���ɃV�X�e�����t+�������ԍő�͈͂̓��t��ݒ�
				final DateFormat df = new SimpleDateFormat("yyyyMMdd");
				final Calendar cal = Calendar.getInstance();
				cal.add(Calendar.MONTH, searchMonth);
				startDate = df.format(cal.getTime());
			}

			// ��������
			con = PZZ040_SQLUtility.getConnection(shimeiNo);
			ps = con.prepareStatement(PYB_PortalEJBBean.SELECT_KENSHU_HONNIN_SQL);
			ps.setString(1, targetShimeiNo);
			ps.setString(2, startDate);
			ps.setString(3, endDate);

			rs = ps.executeQuery();

			while (rs.next()) {
				result.add(createKenshuBean(rs));
			}

			return result;
		} catch (final SQLException e) {
			Log.error(shimeiNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(shimeiNo, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(shimeiNo, con, ps, rs);
		}
	}

	/**
	 * �w�肳�ꂽ���ԓ��Ɏw�肵�����[�U�����C���F�҂ɐݒ肵�Ă���Ј��̎�u�\�苳��̃��X�g��Ԃ��B<br>
	 * �����Ώۊ��Ԃ�0�̏ꍇ�A���Ԏw��Ȃ��Ō�������B
	 * @param shimeiNo �����˗����[�U�̎���No
	 * @param targetShimeiNo �����Ώۂ̎���No
	 * @param searchMonth �����Ώۊ���
	 * @return ���C���m�点���̃��X�g
	 * @throws NamingException �f�[�^�\�[�X�擾���s
	 * @throws SQLException SQL�s��
	 */
	public ArrayList getKenshusyaKenshuYoteiList(final String shimeiNo, final String targetShimeiNo, final int searchMonth) throws NamingException, SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		final ArrayList result = new ArrayList();

		if (targetShimeiNo == null || targetShimeiNo.length() == 0) {
			return result;
		}

		try {
			String startDate = "99991231";
			String endDate = "19000101";

			// �������Ԃ�ݒ�
			if (searchMonth > 0) {
				// �I�����ɃV�X�e�����t��ݒ�
				endDate = PZZ010_CharacterUtil.GetDay();
				// �J�n���ɃV�X�e�����t+�������ԍő�͈͂̓��t��ݒ�
				final DateFormat df = new SimpleDateFormat("yyyyMMdd");
				final Calendar cal = Calendar.getInstance();
				cal.add(Calendar.MONTH, searchMonth);
				startDate = df.format(cal.getTime());
			}

			// ��������
			con = PZZ040_SQLUtility.getConnection(shimeiNo);
			ps = con.prepareStatement(PYB_PortalEJBBean.SELECT_KENSHU_SHONINSYA_SQL);
			ps.setString(1, targetShimeiNo);
			ps.setString(2, targetShimeiNo);
			ps.setString(3, startDate);
			ps.setString(4, endDate);

			rs = ps.executeQuery();

			while (rs.next()) {
				result.add(createKenshuBean(rs));
			}

			return result;
		} catch (final SQLException e) {
			Log.error(shimeiNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(shimeiNo, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(shimeiNo, con, ps, rs);
		}
	}

	/**
	 * �w�肵���g�D�ɑ΂���i���b�W�̊e�����擾����B
	 * @param shimeiNo �����˗��Ҏ���No
	 * @param targetSoshikiCode �吳�̑g�D�R�[�h
	 * @param rankIds �擾�������ID�̃��X�g
	 * @return ����ID�̃��X�g�ƌ��ʂ�Map
	 * @throws NamingException �f�[�^�\�[�X�擾���s
	 * @throws SQLException SQL�s��
	 */
	public HashMap getKnowledgeRanking(final String shimeiNo, final String targetSoshikiCode, final ArrayList rankIds) throws SQLException, NamingException {
		final HashMap result = new HashMap();
		Connection con = null;

		if (rankIds == null || rankIds.size() == 0 || targetSoshikiCode == null || targetSoshikiCode.length() == 0) {
			return result;
		}

		try {
			con = PZZ040_SQLUtility.getConnection(shimeiNo);
			for (final Iterator ite = rankIds.iterator(); ite.hasNext();) {
				final String id = (String) ite.next();
				if (id.equals("DownloadRank")) {
					result.put(id, getKnowledgeDownloadRank(con, targetSoshikiCode));
				} else if (id.equals("TourokuRank")) {
					result.put(id, getKnowledgeRegistrantRank(con, targetSoshikiCode));
				} else if (id.equals("NewFile")) {
					result.put(id, getKnowledgeNewFile(con, targetSoshikiCode));
				}
			}
			return result;
		} catch (final SQLException e) {
			Log.error(shimeiNo, e);
			throw e;
		} catch (final NamingException e) {
			Log.error(shimeiNo, e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection("", con, null, null);
		}
	}

	private ArrayList getKnowledgeDownloadRank(final Connection con, final String targetSoshikiCode) throws SQLException {
		final ArrayList result = new ArrayList();
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = con.prepareStatement(PYB_PortalEJBBean.SELECT_KNOWLEDGE_DOWNLOAD_RANK_SQL);
			ps.setString(1, targetSoshikiCode);
			ps.setString(2, targetSoshikiCode);
			rs = ps.executeQuery();

			int rank = 1;
			int cur = 1;
			int prevCount = -1;
			for (; rs.next(); cur++) {
				PYB_KnowledgeValueBean bean = createKnowledgeBean(rs);
				if (bean.getDownloadCount() != prevCount) {
					rank = cur;
					prevCount = bean.getDownloadCount();
				}
				bean.setRank(rank);
				result.add(bean);
			}

			return result;
		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection("", null, ps, rs);
		}
	}

	private ArrayList getKnowledgeRegistrantRank(final Connection con, final String targetSoshikiCode) throws SQLException {
		final ArrayList result = new ArrayList();
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = con.prepareStatement(PYB_PortalEJBBean.SELECT_KNOWLEDGE_REGSTER_RANK_SQL);
			ps.setString(1, targetSoshikiCode);
			ps.setString(2, targetSoshikiCode);
			rs = ps.executeQuery();

			int rank = 1;
			int cur = 1;
			int prevCount = -1;
			for (; rs.next(); cur++) {
				final PYB_KnowledgeRegistrantValueBean registrant = createKnowledgeRegistrantBean(rs);
				if (registrant.getCount() != prevCount) {
					rank = cur;
					prevCount = registrant.getCount();
				}
				registrant.setRank(rank);
				result.add(registrant);
			}
			return result;
		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection("", null, ps, rs);
		}
	}

	private ArrayList getKnowledgeNewFile(final Connection con, final String targetSoshikiCode) throws SQLException {
		final ArrayList result = new ArrayList();
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = con.prepareStatement(PYB_PortalEJBBean.SELECT_KNOWLEDGE_NEW_FILE_SQL);
			ps.setString(1, targetSoshikiCode);
			ps.setString(2, targetSoshikiCode);
			rs = ps.executeQuery();

			int rank = 1;
			int cur = 1;
			int prevCount = -1;
			for (; rs.next(); cur++) {
				PYB_KnowledgeValueBean bean = createKnowledgeBean(rs);
				if (bean.getDownloadCount() != prevCount) {
					rank = cur;
					prevCount = bean.getDownloadCount();
				}
				bean.setRank(rank);
				result.add(bean);
			}

			return result;
		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection("", null, ps, rs);
		}
	}

	/**
	 * PYB_PortalEJBBean.SELECT_KENSHU_BASE_SQL��SELECT��Ŏ擾����ResultSet�̌��݂̃J�[�\���ʒu�̏�񂩂�PYB_KenshuValueBean�𐶐�����
	 * @param rs SQL���s����
	 * @return SQL���s���ʂ�ݒ肵��PYB_KenshuValueBean
	 * @throws SQLException SQL��O
	 */
	private PYB_KenshuValueBean createKenshuBean(final ResultSet rs) throws SQLException {
		final PYB_KenshuValueBean kenshu = new PYB_KenshuValueBean();

		if (rs == null) {
			return kenshu;
		}

		kenshu.setKamokuCode(rs.getString("KAMOKU_CODE"));
		kenshu.setKamokuName(rs.getString("KAMOKU_NAME"));
		kenshu.setKamokuGroupCode(rs.getString("KAMOKU_GROUP_CODE"));
		kenshu.setKamokuGroupName(rs.getString("KAMOKU_GROUP_NAME"));
		kenshu.setCategory1Code(rs.getString("CATEGORY_CODE1"));
		kenshu.setCategory1Name(rs.getString("CATEGORY_NAME1"));
		kenshu.setCategory2Code(rs.getString("CATEGORY_CODE2"));
		kenshu.setCategory2Name(rs.getString("CATEGORY_NAME2"));
		kenshu.setCategory3Code(rs.getString("CATEGORY_CODE3"));
		kenshu.setCategory3Name(rs.getString("CATEGORY_NAME3"));
		kenshu.setCategory4Code(rs.getString("CATEGORY_CODE4"));
		kenshu.setCategory4Name(rs.getString("CATEGORY_NAME4"));
		kenshu.setCategory5Code(rs.getString("CATEGORY_CODE5"));
		kenshu.setCategory5Name(rs.getString("CATEGORY_NAME5"));
		kenshu.setKanrimotoCode(rs.getString("KANRIMOTO_CODE"));
		kenshu.setKanrimotoName(rs.getString("KANRIMOTO_NAME"));
		kenshu.setKamokuNaiyou(rs.getString("KAMOKU_NAIYOU"));
		kenshu.setJukoJoken(rs.getString("JUKO_JOKEN"));
		kenshu.setKamokuYobi1(rs.getString("KAMOKU_YOBI1"));
		kenshu.setKamokuYobi2(rs.getString("KAMOKU_YOBI2"));
		kenshu.setClassCode(rs.getString("CLASS_CODE"));
		kenshu.setClassName(rs.getString("CLASS_NAME"));
		kenshu.setNissuu(rs.getString("NISUU"));
		kenshu.setClassKaishibi(rs.getString("CLASS_KAISIBI"));
		kenshu.setClassShuryobi(rs.getString("CLASS_SHURYOBI"));
		kenshu.setKaisaiJikan(rs.getString("KAISAI_JIKAN"));
		kenshu.setKaishiJikoku(rs.getString("KAISHI_JIKOKU"));
		kenshu.setShuryoJikoku(rs.getString("SHURYO_JIKOKU"));
		kenshu.setMoushikomiKaishibi(rs.getString("MOUSHIKOMI_KAISHIBI"));
		kenshu.setMoushikomiShuryobi(rs.getString("MOUSHIKOMI_SHURYOBI"));
		kenshu.setJukoKigenbi(rs.getString("JUKO_KIGENBI"));
		kenshu.setChikuCode(rs.getString("CHIKU_CODE"));
		kenshu.setChikuName(PZZ010_CharacterUtil.normalizedStr(rs.getString("CHIKU_NAME1")) + PZZ010_CharacterUtil.normalizedStr(rs.getString("CHIKU_NAME2")));
		kenshu.setKyoshitsuCode(rs.getString("KYOSHITSU_CODE"));
		kenshu.setKyoshitsuName(PZZ010_CharacterUtil.normalizedStr(rs.getString("KYOSHITSU_NAME1")) + PZZ010_CharacterUtil.normalizedStr(rs.getString("KYOSHITSU_NAME2")));
		kenshu.setAnnaizu(rs.getString("ANNAIZU"));
		kenshu.setTeiin(rs.getString("TEIIN"));
		kenshu.setKaisaiSaishoNinzu(rs.getString("KAISAI_SAISHO_NINZU"));
		kenshu.setKoushiCode(rs.getString("KOUSHI_CODE"));
		kenshu.setKoushiName(PZZ010_CharacterUtil.normalizedStr(rs.getString("KOUSHI_NAME1")) + PZZ010_CharacterUtil.normalizedStr(rs.getString("KOUSHI_NAME2")));
		kenshu.setKishoIkkatsuFlag(rs.getString("KISHO_IKKATSU_FLAG"));
		kenshu.setZensyaTaishoFlag(rs.getString("ZENSYA_TAISHO_FLAG"));
		kenshu.setMoushikomiKubun(rs.getString("MOUSHIKOMI_KUBUN"));
		kenshu.setShoninKubun(rs.getString("SHONIN_KUBUN"));
		kenshu.setUketsukeKubun(rs.getString("UKETSUKE_KUBUN"));
		kenshu.setHoukokuKubun(rs.getString("HOUKOKU_KUBUN"));
		kenshu.setNinshoKubun(rs.getString("NINSHO_KUBUN"));
		kenshu.setHanteiKubun(rs.getString("HANTEI_KUBUN"));
		kenshu.setKaisaiKubun(rs.getString("KAISAI_KUBUN"));
		kenshu.setMansekiFlag(rs.getString("MANSEKI_FLAG"));
		kenshu.setAnnaiMailKubun(rs.getString("ANNAI_MAIL_KUBUN"));
		kenshu.setFollowMailKubun(rs.getString("FOLLOW_MAIL_KUBUN"));
		kenshu.setFollowMailNissuu1(rs.getString("FOLLOW_MAIL_NISSUU1"));
		kenshu.setFollowMailNissuu2(rs.getString("FOLLOW_MAIL_NISSUU2"));
		kenshu.setClassBikou(rs.getString("CLASS_BIKOU"));
		kenshu.setSakujoFlag(rs.getString("SAKUJO_FLAG"));
		kenshu.setYoyakusuu(rs.getString("YOYAKUSUU"));
		kenshu.setKingaku(rs.getString("KINGAKU"));
		kenshu.setTargetShimeiNo(rs.getString("TARGET_SHIMEI_NO"));
		kenshu.setTargetShimei(rs.getString("TARGET_SHIMEI"));
		kenshu.setTargetSoshikiCode(rs.getString("TARGET_SOSHIKI_CODE"));
		kenshu.setTargetSoshikiName(rs.getString("TARGET_SOSHIKI_NAME"));
		kenshu.setTargetStatus(rs.getString("TARGET_STATUS"));
		kenshu.setTargetUketsukeJotai(rs.getString("TARGET_UKETSUKE_JOTAI"));

		return kenshu;
	}

	/**
	 * PYB_PortalEJBBean.SELECT_KNOWLEDGE_INFO_BASE_SQL��SELECT��Ŏ擾����ResultSet�̌��݂̃J�[�\���ʒu�̏�񂩂�PYB_KnowledgeValueBean�𐶐�����
	 * @param rs SQL���s����
	 * @return SQL���s���ʂ�ݒ肵��PYB_KnowledgeBean
	 * @throws SQLException SQL��O
	 */
	private PYB_KnowledgeValueBean createKnowledgeBean(final ResultSet rs) throws SQLException {
		final PYB_KnowledgeValueBean knowledgeInfo = new PYB_KnowledgeValueBean();

		if (rs == null) {
			return knowledgeInfo;
		}

		knowledgeInfo.setDocumentID(rs.getString("DOCUMENT_ID"));
		knowledgeInfo.setDocumentName(rs.getString("DOCUMENT_NAME"));
		knowledgeInfo.setFileName(rs.getString("FILE_NAME"));
		knowledgeInfo.setSetsumei(rs.getString("SETSUMEI"));
		knowledgeInfo.setCategoryCode(rs.getString("CATEGORY_CODE"));
		knowledgeInfo.setCategoryName(rs.getString("CATEGORY_NAME"));
		knowledgeInfo.setKokaiFlag(rs.getString("KOKAI_FLAG"));
		knowledgeInfo.setKokaihaniSoshikiCode(rs.getString("KOKAIHANI_SOSHIKI_CODE"));
		knowledgeInfo.setKokaihaniSoshikiName(rs.getString("KOKAIHANI_SOSHIKI_NAME"));
		knowledgeInfo.setTourokushaShimeiNo(rs.getString("TOUROKUSHA_SHIMEI_NO"));
		knowledgeInfo.setTourokushaShimei(rs.getString("TOUROKUSHA_SHIMEI"));
		knowledgeInfo.setTourokushaSoshikiCode(rs.getString("TOUROKUSHA_SOSHIKI_CODE"));
		knowledgeInfo.setTourokushaSoshikiName(rs.getString("TOUROKUSHA_SOSHIKI_NAME"));
		knowledgeInfo.setTourokuNengappi(rs.getString("TOUROKU_NENGAPPI"));
		knowledgeInfo.setTourokuJikoku(rs.getString("TOUROKU_JIKOKU"));
		knowledgeInfo.setShoninNengappi(rs.getString("SHONIN_NENGAPPI"));
		knowledgeInfo.setShoninJikoku(rs.getString("SHONIN_JIKOKU"));
		knowledgeInfo.setDownloadCount(rs.getInt("DOWNLOAD_COUNT"));

		return knowledgeInfo;
	}

	/**
	 * PYB_PortalEJBBean.SELECT_KNOWLEDGE_REGSTER_RANK_SQL��SELECT��Ŏ擾����ResultSet�̌��݂̃J�[�\���ʒu�̏�񂩂�PYB_KnowledgeRegistrantValueBean�𐶐�����
	 * @param rs SQL���s����
	 * @return SQL���s���ʂ�ݒ肵��PYB_KnowledgeRegistrantValueBean
	 * @throws SQLException SQL��O
	 */
	private PYB_KnowledgeRegistrantValueBean createKnowledgeRegistrantBean(final ResultSet rs) throws SQLException {
		final PYB_KnowledgeRegistrantValueBean registrant = new PYB_KnowledgeRegistrantValueBean();

		if (rs == null) {
			return registrant;
		}

		registrant.setShimeiNo(rs.getString("SHIMEI_NO"));
		registrant.setShimei(rs.getString("SHIMEI"));
		registrant.setSoshikiCode(rs.getString("SOSHIKI_CODE"));
		registrant.setSoshikiName(rs.getString("SOSHIKI_NAME"));
		registrant.setYakushokuCode(rs.getString("YAKUSYOKU_CODE"));
		registrant.setYakushokuName(rs.getString("YAKUSHOKU_NAME"));
		registrant.setShokuiCode(rs.getString("SHOKUI_CODE"));
		registrant.setShokuiName(rs.getString("SHOKUI_NAME"));
		registrant.setCount(rs.getInt("CNT"));

		return registrant;
	}

	/**
	 * ���\�[�X���擾����
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException {
	}

	/**
	 * �N���C�A���g��create���\�b�h���s���Ɏ��s�����
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException {
	}

	/**
	 * ���\�[�X�̊J�����s��
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException {
	}

	/**
	 * �N���C�A���g��remove���\�b�h���s���Ɏ��s�����
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException {
	}

	/**
	 * EJB�R���e�i���Ǘ�����SessionContext����SessionBean�ɓn���BSessionBean�̍쐬���ɌĂяo�����B
	 * @param val SessionContext���
	 * @exception RemoteException
	 */
	public void setSessionContext(final SessionContext con) throws EJBException, RemoteException {
		this.context = con;
	}

	/**
	 * SessionContext�����擾����B
	 * @return SessionContext���
	 */
	public SessionContext getSessionContext() throws EJBException, RuntimeException {
		return this.context;
	}

}
