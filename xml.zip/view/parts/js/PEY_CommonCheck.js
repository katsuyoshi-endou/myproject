/**
 * RichTextEditorで入力された文字装飾データ（アナウンス内容、投稿内容）を
 * 登録用に加工する。
 * ・改行コードを取り除く。
 * ・URL表記がある場合に、<A>タグにtarget="_blank"を付加する。
 * @param ： v  文字装飾データ
 *           vm METAデータ
 * @return： 加工後の文字装飾データ
 */

function remakeRichText( v, vm ) 
{
	var val = v;
	var valm = vm;
	var key1=String.fromCharCode(13);
	var key2=String.fromCharCode(10);
	var key3="<A href=";
	var rep1="";
	var rep2=" <A target=_blank href=";
	 /* 改行コードを取り除く */
	var p=0;
	while ((p = val.indexOf(key1, p)) != -1) {
	   val = val.substring(0, p) + rep1 + val.substring(p + key1.length, val.length);
	   p = p + rep1.length;
	}
	p=0;
	while ((p = val.indexOf(key2, p)) != -1) {
	   val = val.substring(0, p) + rep1 + val.substring(p + key2.length, val.length);
	   p = p + rep1.length;
	}
	 /* URL表記がある場合、<A>タグにtarget="_blank"を付加 */
	p=0;
	while ((p = val.indexOf(key3, p)) != -1) {
	   val = val.substring(0, p) + rep2 + val.substring(p + key3.length, val.length);
	   p = p + rep2.length;
	}
	
	 /* 内容を削除した時に文字装飾データに残るゴミ(タグだけが残ったりする）を削除 */
	if ( valm == null || valm == "" ) {
		val = "";
	}

	return val;
}

