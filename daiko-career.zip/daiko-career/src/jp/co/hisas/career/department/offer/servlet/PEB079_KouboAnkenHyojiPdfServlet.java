/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�Г�����@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/16  01.00       �y��         �V�K�쐬
 *   2005/11/08             QUANLA       sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */
package jp.co.hisas.career.department.offer.servlet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lowagie.text.DocumentException;

import jp.co.hisas.career.department.base.PEY_ServiceLocator;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboAnkenBean;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenEJBHome;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.pdf.PZE130_KouboAnkenPDF;
import jp.co.hisas.career.util.property.HcdbDef;


/**
 *<PRE>
 *
 * �T�v�F
 *   �Г�����Č���PDF�쐬���s���B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 *
 *</PRE>
 */
public class PEB079_KouboAnkenHyojiPdfServlet extends PEY010_ControllerServlet {
	
    protected String execute( HttpServletRequest request, HttpServletResponse response,
		PEY_PersonalBean loginuser )
        throws Exception {
        /*���\�b�h�g���[�X�o��*/
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );
        Log.performance( loginuser.getSimeiNo(  ), true, "" );

		String[] kouboAnkenId = request.getParameterValues("koubo_anken_id");

		if (kouboAnkenId[0] == null || kouboAnkenId[0].length() <= 0) {
            //redirectErrorView(response, loginuser);        //2005/11/08_LYCE_R_QUANLA
            redirectErrorView(request, response, loginuser); //2005/11/08_LYCE_A_QUANLA
			return null;
		}
        try {

            PEY_ServiceLocator locator   = PEY_ServiceLocator.getInstance();
			PEB_KouboAnkenEJBHome kouboAnkenEJBHome = ( PEB_KouboAnkenEJBHome )locator.getServiceLocation( "PEB_KouboAnkenEJB",	PEB_KouboAnkenEJBHome.class );
			PEB_KouboAnkenEJB kouboAnkenEJB = kouboAnkenEJBHome.create(  );
			
			PEB_KouboAnkenBean pdfData = kouboAnkenEJB.getKouboAnkenInfo(kouboAnkenId[0]);

			if (pdfData == null) {
				//�Y���f�[�^�����B
				throw new PEY_WarningException();
			}

            /* �t�@�C���ǂݍ��ݗp�o�b�t�@ */
            byte[] buffer = new byte[4096];

            /* �t�@�C�����e�̏o�� */

            /* PDF�쐬 */
            PZE130_KouboAnkenPDF pdf = new PZE130_KouboAnkenPDF();

            /* contentType���o�� */
            response.setContentType( "application/pdf" );

            /* �t�@�C�����̑��M(attachment������inline�ɕύX����΃C�����C���\��) */
            response.setHeader( "Content-Disposition", "inline;" );
			String pdfFileName = makePdfFileName(loginuser);
			response.setHeader( "Content-Disposition", "attachment; filename=\"" + pdfFileName + "\"");


            ByteArrayOutputStream baos = new ByteArrayOutputStream(  );
// C-ADT02-002-S
		   boolean pdfOutput;
//            boolean pdfOutput = pdf.makePdf( baos, PZE130_KouboAnkenPDF.KOUBO_ANKEN_SYOUSAI, null, loginuser, pdfData);
			if(request.getParameter("hide_flg") != null && 
				request.getParameter("hide_flg").equals("1") ){
				pdfOutput = pdf.makePdf( baos, PZE130_KouboAnkenPDF.KOUBO_ANKEN_SYOUSAI_OUBOSYA, null, loginuser, pdfData);
			}else{
				pdfOutput = pdf.makePdf( baos, PZE130_KouboAnkenPDF.KOUBO_ANKEN_SYOUSAI, null, loginuser, pdfData);
			}
// C-ADT02-002-E

            if ( !pdfOutput ) {
                //redirectErrorView(response, loginuser);        //2005/11/08_LYCE_R_QUANLA
                redirectErrorView(request, response, loginuser); //2005/11/08_LYCE_A_QUANLA
            }
			ServletOutputStream out = response.getOutputStream(  );
			ByteArrayInputStream bais  = new ByteArrayInputStream( baos.toByteArray() );
            if ( bais != null ) {
                int size;

                while ( ( size = bais.read( buffer ) ) != -1 ) {
                    out.write( buffer, 0, size );
                }

                bais.close(  );
            }

            out.close(  );
            response.flushBuffer(  );

            Log.performance( loginuser.getSimeiNo(  ), false, "" );

            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return null;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw e;
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } catch ( IOException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0012", e );
            throw e;
        } catch ( DocumentException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } catch ( Exception e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        }
    }
    
    /**
     * �G���[��ʂ�\������B
     */
    //private void redirectErrorView(HttpServletResponse response, PEY_PersonalBean loginuser) { //2005/11/08_LYCE_R_QUANLA
    //2005/11/08_LYCE_A_QUANLA START
    private void redirectErrorView(
            HttpServletRequest request,
            HttpServletResponse response,
            PEY_PersonalBean loginuser)
    throws ServletException {
    //2005/11/08_LYCE_A_QUANLA END
    	try {
			//response.sendRedirect( "/" + HcdbDef.root + "/view/Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
			this.getServletConfig( ).getServletContext( ).getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
    	}
    	catch (IOException e) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0012", e );
			throw new RuntimeException(e);
    	}
    }
    
	/**
	 * PDF�t�@�C�������쐬����B
	 * @param userinfo
	 * @return PDF�t�@�C�����B
	 */
	private String makePdfFileName(PEY_PersonalBean userinfo) {
		StringBuffer buf = new StringBuffer();
		buf.append(userinfo.getSimeiNo());
		buf.append("_");
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		buf.append(df.format(Calendar.getInstance().getTime()));
		buf.append("_");
		buf.append("VEB070");
		buf.append(".pdf");
		return buf.toString();
	}


}
