/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�Г�����@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/19  01.00     �V�_�@���Y   �V�K�쐬
 */
package jp.co.hisas.career.department.offer.ejb;

import java.rmi.*;
import java.sql.*;
import javax.ejb.*;
import javax.naming.NamingException;

import jp.co.hisas.career.department.base.PEY_ServiceLocator;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 *<PRE>
 *
 * �N���X���F
 *   PEB_NijiShinsaGouhiSetteiEJBBean�N���X
 *
 * �@�\�����F
 *   �񎟐R�����ۂ��c�a�Ɋi�[����@�\�ł��B
 *   �i�[����f�[�^�͍��ۃX�e�[�^�X
 *   �⍇���������A�A������
 *
 *</PRE>
 *  * @ejb.bean
 *   name="PEB_NijiShinsaGouhiSetteiEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PEB_NijiShinsaGouhiSetteiEJBBean implements SessionBean {
    private SessionContext context = null;

	/**
	 * GOUHI_STATUS�ɑΉ����郌�R�[�h�̍X�V���s���܂��B
	 *
	 * @param koubooubosyaBean
	 * @param loginuser
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
    public int doUpdate( PEY_KouboOubosyaBean koubooubosyaBean, PEY_PersonalBean loginuser )
        throws PEY_WarningException, RemoteException, NamingException, CreateException {
			   Connection con       = null;
			   PreparedStatement ps = null;

			   try {
				   // ���\�b�h�g���[�X�o��
				   Log.method( loginuser.getSimeiNo(  ), "IN", "" );

				   // SQL�쐬
				   StringBuffer sql = new StringBuffer(  );
				   sql.append( "UPDATE " );
				   sql.append( HcdbDef.D03_TBL );
				   sql.append( " SET " );
				   sql.append( "GOUHI_STATUS = ?, " );
				   sql.append( "TOIAWASE_SYOZOKU = ?, " );
				   sql.append( "TOIAWASE_SIMEI = ?, " );
				   sql.append( "TOIAWASE_GAISEN = ?, " );
				   sql.append(" TOIAWASE_NAISEN = ?, ");
				   sql.append(" TOIAWASE_MAIL = ?, ");
				   sql.append(" RENRAKU_JIKOU = ?, ");
				   sql.append(" KOUSINSYA = ?, ");
				   sql.append(" KOUSINBI =?, ");
				   sql.append(" KOUSINJIKOKU =?");
				   sql.append(" WHERE KOUBO_ANKEN_ID =?");
				   sql.append(" AND SIMEI_NO =?");
				   sql.append(" AND KOUSINBI =?");
				   sql.append(" AND KOUSINJIKOKU =?");

				   // �R�l�N�V�����擾
				   PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance();
				   con = locator.getDataSource().getConnection();

				   //�f�o�b�O���O���o��
				   Log.debug(sql.toString());

				   // �X�V���s
				   ps = con.prepareStatement(sql.toString());				
				   ps.setString(1,koubooubosyaBean.getGouhistatus().trim());
				   ps.setString(2,koubooubosyaBean.getToiawasesyozoku().trim());
				   ps.setString(3,koubooubosyaBean.getToiawasesimei().trim());
				   ps.setString(4,koubooubosyaBean.getToiawasegaisen().trim() );
				   ps.setString(5,koubooubosyaBean.getToiawasenaisen().trim() );
				   ps.setString(6,koubooubosyaBean.getToiawasemail().trim());
				   ps.setString(7,koubooubosyaBean.getRenrakujikou().trim());
				   ps.setString(8,loginuser.getSimeiNo());
				   ps.setString(9,PZZ010_CharacterUtil.GetDay());
				   ps.setString(10,PZZ010_CharacterUtil.GetTime());
				   ps.setString(11,koubooubosyaBean.getKouboankenid());
				   ps.setString(12,koubooubosyaBean.getSimeino());
				   ps.setString(13,koubooubosyaBean.getKousinbi());
				   ps.setString(14,koubooubosyaBean.getKousinjikoku());

				   int count = ps.executeUpdate();

				   // ���\�b�h�g���[�X�o��
				   Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
				   
				   if ( count != 1 ) {
					context.setRollbackOnly(  );
					throw new PEY_WarningException();
				   }				   
				   return count;

			   } catch ( NamingException e ) {
				   Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
				   throw new EJBException( e );
			   } catch ( SQLException e ) {
				   Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
				   throw new EJBException( e );
			   } catch ( RuntimeException e ) {
				   Log.error( loginuser.getSimeiNo(  ), "", e );
				   throw e;
			   } finally {
				   if ( ps != null ) {
					   try {
						   ps.close(  );
					   } catch ( SQLException e ) {
						   // �������Ȃ�
					   }
				   }

				   if ( con != null ) {
					   try {
						   con.close(  );
					   } catch ( SQLException e ) {
						   // �������Ȃ�
					   }
				   }
			   }
		   }

  
    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }
}
