/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�g�D�n �t�H�[�����x���@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/10/06  01.00       �y���r�F     �V�K�쐬
 */
package jp.co.hisas.career.department.forum.valuebean;

import jp.co.hisas.career.util.log.*;

import java.io.*;

import java.sql.ResultSet;
import java.sql.SQLException;




/**
 *<PRE>
 *
 * �N���X���F
 *   PEA_ForumSearchBean �N���X
 *
 * �@�\�����F
 *
 *
 *</PRE>
 */
public class PEA_ToukouSearchBean extends PEA_MasterBean implements Serializable {
    private String forumId         = null;
    private String wadaiId         = null;
    private String toukouId        = null;
    private String daimei          = null;
    private String toukouNaiyoMeta = null;
    private String toukouNaiyo     = null;
    private String simeiNo         = null;
    private String kanjiSimei      = null;
    private String syozoku         = null;
    private String mail            = null;
    private String toukoubi        = null;
    private String toukoujikoku    = null;
    private String sakujyoFlg      = null;
    private String forumMei        = null;

    /**
     * �f�t�H���g�̃R���X�g���N�^�ł��B
     */
    public PEA_ToukouSearchBean(  ) {
        super(  );
    }

    /**
     * ResultSet ����l���擾���ăt�H�[����ValueBean���쐬���܂��B
     *
     * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
     * @param tableName �t�H�[�����e�[�u���̕ʖ�
     * @throws SQLException SQLException�����������ꍇ
     */
    public PEA_ToukouSearchBean( ResultSet rs ) throws SQLException {
        super( rs, null );
        Log.debug( getIdentifier(  ) );

        try {
            setForumId( rs.getString( getIdentifier(  ) + "forum_id" ) );
            setWadaiId( rs.getString( getIdentifier(  ) + "wadai_id" ) );
            setToukouId( rs.getString( getIdentifier(  ) + "toukou_id" ) );
            setDaimei( rs.getString( getIdentifier(  ) + "daimei" ) );
            setToukouNaiyoMeta( rs.getString( getIdentifier(  ) + "toukou_naiyo_meta" ) );
            setToukouNaiyo( rs.getString( getIdentifier(  ) + "toukou_naiyo" ) );
            setSimeiNo( rs.getString( getIdentifier(  ) + "simei_no" ) );
            setKanjiSimei( rs.getString( getIdentifier(  ) + "kanji_simei" ) );
            setSyozoku( rs.getString( getIdentifier(  ) + "syozoku" ) );
            setMail( rs.getString( getIdentifier(  ) + "mail" ) );
            setToukoubi( rs.getString( getIdentifier(  ) + "toukoubi" ) );
            setToukoujikoku( rs.getString( getIdentifier(  ) + "toukoujikoku" ) );
            setSakujyoFlg( rs.getString( getIdentifier(  ) + "sakujyo_flg" ) );
            setForumMei( rs.getString( getIdentifier(  ) + "forum_mei" ) );
        } catch ( SQLException e ) {
            Log.error( "", "HJE-0001", e );
            throw e;
        }
    }

    /**
     * @return forumMei
     */
    public String getForumMei(  ) {
        return forumMei;
    }

    /**
     * @param forumMei forumMei ��ݒ肵�܂��B
     */
    public void setForumMei( String forumMei ) {
        this.forumMei = forumMei;
    }

    /**
     * @return daimei
     */
    public String getDaimei(  ) {
        return daimei;
    }

    /**
     * @param daimei daimei ��ݒ肵�܂��B
     */
    public void setDaimei( String daimei ) {
        this.daimei = daimei;
    }

    /**
     * @return forumId
     */
    public String getForumId(  ) {
        return forumId;
    }

    /**
     * @param forumId forumId ��ݒ肵�܂��B
     */
    public void setForumId( String forumId ) {
        this.forumId = forumId;
    }

    /**
     * @return kanjiSimei
     */
    public String getKanjiSimei(  ) {
        return kanjiSimei;
    }

    /**
     * @param kanjiSimei kanjiSimei ��ݒ肵�܂��B
     */
    public void setKanjiSimei( String kanjiSimei ) {
        this.kanjiSimei = kanjiSimei;
    }

    /**
     * @return mail
     */
    public String getMail(  ) {
        return mail;
    }

    /**
     * @param mail mail ��ݒ肵�܂��B
     */
    public void setMail( String mail ) {
        this.mail = mail;
    }

    /**
     * @return sakujyoFlg
     */
    public String getSakujyoFlg(  ) {
        return sakujyoFlg;
    }

    /**
     * @param sakujyoFlg sakujyoFlg ��ݒ肵�܂��B
     */
    public void setSakujyoFlg( String sakujyoFlg ) {
        this.sakujyoFlg = sakujyoFlg;
    }

    /**
     * @return simeiNo
     */
    public String getSimeiNo(  ) {
        return simeiNo;
    }

    /**
     * @param simeiNo simeiNo ��ݒ肵�܂��B
     */
    public void setSimeiNo( String simeiNo ) {
        this.simeiNo = simeiNo;
    }

    /**
     * @return syozoku
     */
    public String getSyozoku(  ) {
        return syozoku;
    }

    /**
     * @param syozoku syozoku ��ݒ肵�܂��B
     */
    public void setSyozoku( String syozoku ) {
        this.syozoku = syozoku;
    }

    /**
     * @return toukoubi
     */
    public String getToukoubi(  ) {
        return toukoubi;
    }

    /**
     * @param toukoubi toukoubi ��ݒ肵�܂��B
     */
    public void setToukoubi( String toukoubi ) {
        this.toukoubi = toukoubi;
    }

    /**
     * @return toukouId
     */
    public String getToukouId(  ) {
        return toukouId;
    }

    /**
     * @param toukouId toukouId ��ݒ肵�܂��B
     */
    public void setToukouId( String toukouId ) {
        this.toukouId = toukouId;
    }

    /**
     * @return toukoujikoku
     */
    public String getToukoujikoku(  ) {
        return toukoujikoku;
    }

    /**
     * @param toukoujikoku toukoujikoku ��ݒ肵�܂��B
     */
    public void setToukoujikoku( String toukoujikoku ) {
        this.toukoujikoku = toukoujikoku;
    }

    /**
     * @return toukouNaiyo
     */
    public String getToukouNaiyo(  ) {
        return toukouNaiyo;
    }

    /**
     * @param toukouNaiyo toukouNaiyo ��ݒ肵�܂��B
     */
    public void setToukouNaiyo( String toukouNaiyo ) {
        this.toukouNaiyo = toukouNaiyo;
    }

    /**
     * @return toukouNaiyoMeta
     */
    public String getToukouNaiyoMeta(  ) {
        return toukouNaiyoMeta;
    }

    /**
     * @param toukouNaiyoMeta toukouNaiyoMeta ��ݒ肵�܂��B
     */
    public void setToukouNaiyoMeta( String toukouNaiyoMeta ) {
        this.toukouNaiyoMeta = toukouNaiyoMeta;
    }

    /**
     * @return wadaiId
     */
    public String getWadaiId(  ) {
        return wadaiId;
    }

    /**
     * @param wadaiId wadaiId ��ݒ肵�܂��B
     */
    public void setWadaiId( String wadaiId ) {
        this.wadaiId = wadaiId;
    }
}
