/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�Г�����@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/12  01.00     ��� �ӎ�   �V�K�쐬
 */
package jp.co.hisas.career.department.offer.ejb;

import jp.co.hisas.career.department.base.*;
import jp.co.hisas.career.department.base.valuebean.*;
import jp.co.hisas.career.department.offer.bean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;
import jp.co.hisas.career.util.common.*;

import java.rmi.*;

import java.sql.*;

import javax.ejb.*;

import javax.naming.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PEB_KouboAnkenSakuseiEJBBean�N���X
 *
 * �@�\�����F
 *   (�l��)�R�����ʂ��c�a�Ɋi�[����@�\�ł��B
 *   �i�[����f�[�^�͐R�����ʁA�A������
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PEB_KouboAnkenSakuseiEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PEB_KouboAnkenSakuseiEJBBean implements SessionBean {
    private SessionContext context = null;

	/**
	 * KOUBO_ANKEN_ID�ɑΉ����郌�R�[�h�̍X�V���s���܂��B
	 *
	 * @param sinsaKekkaSetteiBean
	 * @param loginuser
	 * @return
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
    public int doUpdate( PEB_KouboAnkenBean kouboAnkenBean, PEY_PersonalBean loginuser )
        throws PEY_WarningException, RemoteException, NamingException, CreateException {
			Connection con             = null;
			PreparedStatement ps       = null;
			PreparedStatement ps_kibou1 = null;
			PreparedStatement ps_kibou2 = null;
			PreparedStatement ps_kibou3 = null;

			try {
				// ���\�b�h�g���[�X�o��
				Log.method( loginuser.getSimeiNo(  ), "IN", "" );

				PEB_KouboExtBean kouboBean = kouboAnkenBean.getKouboBean();
				PEB_KouboKibouSyokusyuBean[] kibouBean = kouboAnkenBean.getKouboKibouSyokusyuBean();
				
				// SQL�쐬
				StringBuffer sql_koubo = new StringBuffer(  );
				sql_koubo.append( "UPDATE " );
				sql_koubo.append( HcdbDef.D01_TBL );
				sql_koubo.append( " SET " );
				sql_koubo.append( "KOUBO_ANKEN_MEI = ?, " );
				sql_koubo.append( "JIGYOBU_MEI = ?, " );
				sql_koubo.append( "JIGYOBUTYO_MEI = ?, " );
				sql_koubo.append( "ANKEN_GAIYO = ?, " );
				sql_koubo.append(" BOSYU_NINZU = ?, ");
				sql_koubo.append(" IDOU_KIBOU_JIKI = ?, ");
				sql_koubo.append(" KIBOU_SYOKUSYU_SONOTA = ?, ");
				sql_koubo.append(" SYOZOKU_KINMUTI = ?, ");
				sql_koubo.append(" KITAI_YAKUWARI_BUTYO = ?, ");
				sql_koubo.append(" KITAI_YAKUWARI_SYUNINGISI = ?, ");
				sql_koubo.append(" KITAI_YAKUWARI_GISI = ?, ");
				sql_koubo.append(" KITAI_YAKUWARI_IPPAN = ?, ");
				sql_koubo.append(" GYOMU_NAIYO = ?, ");
				sql_koubo.append(" JOB_GRADE = ?, ");
				sql_koubo.append(" SYOKUMU_RIREKI = ?, ");
				sql_koubo.append(" OUBOSYA_YOUKEN_SONOTA = ?, ");
				sql_koubo.append(" KOUBO_PR = ?, ");
				sql_koubo.append(" SINSEI_RIYU = ?, ");
				sql_koubo.append(" SYORI_STATUS = ?, ");
				sql_koubo.append(" KOUSINSYA = ?, ");
				sql_koubo.append(" KOUSINBI =?, ");
				sql_koubo.append(" KOUSINJIKOKU =?");
				sql_koubo.append(" WHERE KOUBO_ANKEN_ID =?");
				sql_koubo.append(" AND KOUSINBI =?");
				sql_koubo.append(" AND KOUSINJIKOKU =?");
				
				// SQL�쐬
				StringBuffer sql_kibou = new StringBuffer(  );
				sql_kibou.append( "UPDATE " );
				sql_kibou.append( HcdbDef.D02_TBL );
				sql_kibou.append( " SET " );
				sql_kibou.append( "SYOKU_CODE = ?, " );
				sql_kibou.append( "SENMON_CODE = ?, " );
				sql_kibou.append( "LEVEL_CODE = ?, " );
				sql_kibou.append(" KOUSINSYA = ?, ");
				sql_kibou.append(" KOUSINBI =?,");
				sql_kibou.append(" KOUSINJIKOKU =?");
				sql_kibou.append(" WHERE KOUBO_ANKEN_ID =?");
				sql_kibou.append(" AND KOUSINBI =?");
				sql_kibou.append(" AND KOUSINJIKOKU =?");
				sql_kibou.append(" AND SEQ_NO =?");

				// �R�l�N�V�����擾
				PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance();
				con = locator.getDataSource().getConnection();

				//�f�o�b�O���O���o��
				Log.debug(sql_koubo.toString());
				Log.debug(sql_kibou.toString());

				// �X�V���s
				ps = con.prepareStatement(sql_koubo.toString());				
				ps.setString(1,kouboBean.getKouboankenmei());
				ps.setString(2,kouboBean.getJigyobumei());
				ps.setString(3,kouboBean.getJigyoubutyomei().trim());
				ps.setString(4,kouboBean.getAnkengaiyo());
				ps.setInt(5,kouboBean.getBosyuninzu().intValue());
				ps.setString(6,kouboBean.getIdoukiboujiki());
				ps.setString(7,kouboBean.getKibousyokusyuSonota());
				ps.setString(8,kouboBean.getSyozokukinmuti());
				ps.setString(9,kouboBean.getKitaiyakuwaributyo());
				ps.setString(10,kouboBean.getKitaiyakuwarisyuningisi());
				ps.setString(11,kouboBean.getKitaiyakuwarigisi());
				ps.setString(12,kouboBean.getKitaiyakuwariippan());
				ps.setString(13,kouboBean.getGyomunaiyo());
				ps.setString(14,kouboBean.getJobgrade());
				ps.setString(15,kouboBean.getSyokumurireki());
				ps.setString(16,kouboBean.getOubosyayoukensonota());
				ps.setString(17,kouboBean.getKoubopr());
				ps.setString(18,kouboBean.getSinseiriyu());
				ps.setString(19,kouboBean.getSyoristatus());
				ps.setString(20,loginuser.getSimeiNo());
				ps.setString(21,PZZ010_CharacterUtil.GetDay());
				ps.setString(22,PZZ010_CharacterUtil.GetTime());
				ps.setString(23,PZZ010_CharacterUtil.changeAnkenIdLength(kouboBean.getKouboankenid()));
				ps.setString(24,kouboBean.getKousinbi());
				ps.setString(25,kouboBean.getKousinjikoku());
				
				int count = ps.executeUpdate();
				
				if ( count != 1 ) {
					 context.setRollbackOnly(  );
				 throw new PEY_WarningException();
				}
				
				ps_kibou1 = con.prepareStatement(sql_kibou.toString());
				ps_kibou1.setString(1,kibouBean[0].getSyokuCode());
				ps_kibou1.setString(2,kibouBean[0].getSenmonCode());
				ps_kibou1.setString(3,kibouBean[0].getLevelCode());
				ps_kibou1.setString(4,loginuser.getSimeiNo());
				ps_kibou1.setString(5,PZZ010_CharacterUtil.GetDay());
				ps_kibou1.setString(6,PZZ010_CharacterUtil.GetTime());
				ps_kibou1.setString(7,PZZ010_CharacterUtil.changeAnkenIdLength(kibouBean[0].getKouboAnkenId()));
				ps_kibou1.setString(8,kibouBean[0].getKousinbi());
				ps_kibou1.setString(9,kibouBean[0].getKousinjikoku());
				ps_kibou1.setInt(10,1);

				ps_kibou2 = con.prepareStatement(sql_kibou.toString());
				ps_kibou2.setString(1,kibouBean[1].getSyokuCode());
				ps_kibou2.setString(2,kibouBean[1].getSenmonCode());
				ps_kibou2.setString(3,kibouBean[1].getLevelCode());
				ps_kibou2.setString(4,loginuser.getSimeiNo());
				ps_kibou2.setString(5,PZZ010_CharacterUtil.GetDay());
				ps_kibou2.setString(6,PZZ010_CharacterUtil.GetTime());
				ps_kibou2.setString(7,PZZ010_CharacterUtil.changeAnkenIdLength(kibouBean[1].getKouboAnkenId()));
				ps_kibou2.setString(8,kibouBean[1].getKousinbi());
				ps_kibou2.setString(9,kibouBean[1].getKousinjikoku());
				ps_kibou2.setInt(10,2);

				ps_kibou3 = con.prepareStatement(sql_kibou.toString());
				ps_kibou3.setString(1,kibouBean[2].getSyokuCode());
				ps_kibou3.setString(2,kibouBean[2].getSenmonCode());
				ps_kibou3.setString(3,kibouBean[2].getLevelCode());
				ps_kibou3.setString(4,loginuser.getSimeiNo());
				ps_kibou3.setString(5,PZZ010_CharacterUtil.GetDay());
				ps_kibou3.setString(6,PZZ010_CharacterUtil.GetTime());
				ps_kibou3.setString(7,PZZ010_CharacterUtil.changeAnkenIdLength(kibouBean[2].getKouboAnkenId()));
				ps_kibou3.setString(8,kibouBean[2].getKousinbi());
				ps_kibou3.setString(9,kibouBean[2].getKousinjikoku());
				ps_kibou3.setInt(10,3);

				int count_kibou1 = ps_kibou1.executeUpdate();
				int count_kibou2 = ps_kibou2.executeUpdate();
				int count_kibou3 = ps_kibou3.executeUpdate();

				if ( count_kibou1 != 1 || count_kibou2 != 1 || count_kibou3 != 1) {
					 context.setRollbackOnly(  );
				 throw new PEY_WarningException();
				}
			   
				return count;

			} catch ( NamingException e ) {
				Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
				throw new EJBException( e );
			} catch ( SQLException e ) {
				Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
				throw new EJBException( e );
			} catch ( RuntimeException e ) {
				Log.error( loginuser.getSimeiNo(  ), "", e );
				throw e;
			} finally {
				if ( ps != null ) {
					try {
						ps.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}
				if ( ps_kibou1 != null ) {
					try {
						ps_kibou1.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}
				if ( ps_kibou2 != null ) {
					try {
						ps_kibou1.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}
				if ( ps_kibou3 != null ) {
					try {
						ps_kibou1.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}

				if ( con != null ) {
					try {
						con.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}
//				���\�b�h�g���[�X�o��
				Log.method( loginuser.getSimeiNo(  ), "OUT", "" );	
			}
		}


	/**
	 * KOUBO_ANKEN_ID�ɑΉ����郌�R�[�h�̑}�����s���܂��B
	 *
	 * @param sinsaKekkaSetteiBean
	 * @param loginuser
	 * @return
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
    public int doInsert( PEB_KouboAnkenBean kouboAnkenBean, PEY_PersonalBean loginuser )
        throws PEY_WarningException, RemoteException, NamingException, CreateException {
			Connection con       = null;
			PreparedStatement ps = null;
			PreparedStatement ps_search = null;
			PreparedStatement ps_kibou1 = null;
			PreparedStatement ps_kibou2 = null;
			PreparedStatement ps_kibou3 = null;

			try {
				// ���\�b�h�g���[�X�o��
				Log.method( loginuser.getSimeiNo(  ), "IN", "" );


				PEB_KouboExtBean kouboBean = kouboAnkenBean.getKouboBean();
				PEB_KouboKibouSyokusyuBean[] kibouBean = kouboAnkenBean.getKouboKibouSyokusyuBean();
				
				// SQL�쐬 �ŐV����Č��h�c�擾�p				
				StringBuffer sql_maxSearch = new StringBuffer();
				sql_maxSearch.append( "SELECT " );
				sql_maxSearch.append( "max(to_number(KOUBO_ANKEN_ID)) NEW_KOUBO_ANKEN_ID" );
				sql_maxSearch.append( " from " );
				sql_maxSearch.append( HcdbDef.D01_TBL);
				
				// SQL�쐬 ����Č��e�[�u���p
				StringBuffer sql = new StringBuffer(  );
				sql.append( "INSERT INTO " );
				sql.append( HcdbDef.D01_TBL );
				sql.append( " ( KOUBO_ANKEN_ID, " );
				sql.append( "KOUBO_ANKEN_MEI, " );
				sql.append( "JIGYOBU_MEI, " );
				sql.append( "JIGYOBUTYO_MEI, " );
				sql.append( "SOSIKI_CODE, " );
				sql.append( "SIMEI_NO, " );
				sql.append( "ANKEN_GAIYO, " );
				sql.append(" BOSYU_NINZU, ");
				sql.append(" IDOU_KIBOU_JIKI, ");
				sql.append(" KIBOU_SYOKUSYU_SONOTA, ");
				sql.append(" SYOZOKU_KINMUTI, ");
				sql.append(" KITAI_YAKUWARI_BUTYO, ");
				sql.append(" KITAI_YAKUWARI_SYUNINGISI, ");
				sql.append(" KITAI_YAKUWARI_GISI, ");
				sql.append(" KITAI_YAKUWARI_IPPAN, ");
				sql.append(" GYOMU_NAIYO, ");
				sql.append(" JOB_GRADE, ");
				sql.append(" SYOKUMU_RIREKI, ");
				sql.append(" OUBOSYA_YOUKEN_SONOTA, ");
				sql.append(" KOUBO_PR, ");
				sql.append(" SINSEI_RIYU, ");
				sql.append(" SYORI_STATUS, ");
				sql.append(" TOUROKUBI, ");
				sql.append(" TOUROKUJIKOKU, ");
				sql.append(" TOUROKUSYA, ");
				sql.append(" KOUSINBI, ");
				sql.append(" KOUSINJIKOKU, ");
				sql.append(" KOUSINSYA) ");
				sql.append(" values(" );
				sql.append("?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
				
				// SQL�쐬 �����]�E��p
				StringBuffer sql_kibou = new StringBuffer(  );
				sql_kibou.append( "INSERT INTO " );
				sql_kibou.append( HcdbDef.D02_TBL );
				sql_kibou.append( " ( KOUBO_ANKEN_ID, ");
				sql_kibou.append(" SEQ_NO, " );
				sql_kibou.append(" SYOKU_CODE, " );
				sql_kibou.append( "SENMON_CODE, " );
				sql_kibou.append( "LEVEL_CODE, " );
				sql_kibou.append( "TOUROKUBI, " );
				sql_kibou.append(" TOUROKUJIKOKU, ");
				sql_kibou.append(" TOUROKUSYA, ");
				sql_kibou.append(" KOUSINBI, ");
				sql_kibou.append(" KOUSINJIKOKU, ");
				sql_kibou.append(" KOUSINSYA) ");
				sql_kibou.append(" values(" );
				sql_kibou.append("?,?,?,?,?,?,?,?,?,?,?)");
				
				// �R�l�N�V�����擾
				PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance();
				con = locator.getDataSource().getConnection();

				//�f�o�b�O���O���o��
				Log.debug(sql_maxSearch.toString());
				Log.debug(sql.toString());
				Log.debug(sql_kibou.toString());

				//�������s
				ps_search = con.prepareStatement(sql_maxSearch.toString());
				ResultSet rs = ps_search.executeQuery();
				
				long new_koubo_anken_id = 0;
				while(rs.next()){
					String str_old_koubo_anken_id = rs.getString( "NEW_KOUBO_ANKEN_ID" );
					if(str_old_koubo_anken_id == null){//DB�ɉ����Ȃ��ꍇ�A�����l"0000000000"
						str_old_koubo_anken_id="0000000000";
					}
					long old_koubo_anken_id = Long.parseLong(str_old_koubo_anken_id);
					
					if(old_koubo_anken_id != Long.parseLong("9999999999")){//����l�ɒB���Ė����ꍇ�͍ٔԂ���
						new_koubo_anken_id = old_koubo_anken_id + 1;
					}else{
						throw new PEY_WarningException("WEB040");
					}
				}
				
				String str_koubo_anken_id = PZZ010_CharacterUtil.changeAnkenIdAddZero(Long.toString(new_koubo_anken_id));
				
				// �X�V���s
				ps = con.prepareStatement(sql.toString());				
				ps.setString(1,str_koubo_anken_id);
				ps.setString(2,kouboBean.getKouboankenmei());
				ps.setString(3,kouboBean.getJigyobumei());
				ps.setString(4,kouboBean.getJigyoubutyomei());
				ps.setString(5,kouboBean.getSosikicode());
				ps.setString(6,kouboBean.getSimeino());
				ps.setString(7,kouboBean.getAnkengaiyo());
				ps.setInt(8,kouboBean.getBosyuninzu().intValue());
				ps.setString(9,kouboBean.getIdoukiboujiki());
				ps.setString(10,kouboBean.getKibousyokusyuSonota());
				ps.setString(11,kouboBean.getSyozokukinmuti());
				ps.setString(12,kouboBean.getKitaiyakuwaributyo());
				ps.setString(13,kouboBean.getKitaiyakuwarisyuningisi());
				ps.setString(14,kouboBean.getKitaiyakuwarigisi());
				ps.setString(15,kouboBean.getKitaiyakuwariippan());
				ps.setString(16,kouboBean.getGyomunaiyo());
				ps.setString(17,kouboBean.getJobgrade());
				ps.setString(18,kouboBean.getSyokumurireki());
				ps.setString(19,kouboBean.getOubosyayoukensonota());
				ps.setString(20,kouboBean.getKoubopr());
				ps.setString(21,kouboBean.getSinseiriyu());
				ps.setString(22,"01");
				ps.setString(23,PZZ010_CharacterUtil.GetDay());
				ps.setString(24,PZZ010_CharacterUtil.GetTime());
				ps.setString(25,loginuser.getSimeiNo());
				ps.setString(26,PZZ010_CharacterUtil.GetDay());
				ps.setString(27,PZZ010_CharacterUtil.GetTime());
				ps.setString(28,loginuser.getSimeiNo());
				
				int count = ps.executeUpdate();
				
				if ( count != 1 ) {
				 context.setRollbackOnly(  );
				 throw new PEY_WarningException();
				}
								   
				ps_kibou1 = con.prepareStatement(sql_kibou.toString());
				ps_kibou1.setString(1,str_koubo_anken_id);
				ps_kibou1.setInt(2,1);
				ps_kibou1.setString(3,kibouBean[0].getSyokuCode());
				ps_kibou1.setString(4,kibouBean[0].getSenmonCode());
				ps_kibou1.setString(5,kibouBean[0].getLevelCode());
				ps_kibou1.setString(6,PZZ010_CharacterUtil.GetDay());
				ps_kibou1.setString(7,PZZ010_CharacterUtil.GetTime());
				ps_kibou1.setString(8,loginuser.getSimeiNo());
				ps_kibou1.setString(9,PZZ010_CharacterUtil.GetDay());
				ps_kibou1.setString(10,PZZ010_CharacterUtil.GetTime());
				ps_kibou1.setString(11,loginuser.getSimeiNo());
				
				
				ps_kibou2 = con.prepareStatement(sql_kibou.toString());
				ps_kibou2.setString(1,str_koubo_anken_id);
				ps_kibou2.setInt(2,2);
				ps_kibou2.setString(3,kibouBean[1].getSyokuCode());
				ps_kibou2.setString(4,kibouBean[1].getSenmonCode());
				ps_kibou2.setString(5,kibouBean[1].getLevelCode());
				ps_kibou2.setString(6,PZZ010_CharacterUtil.GetDay());
				ps_kibou2.setString(7,PZZ010_CharacterUtil.GetTime());
				ps_kibou2.setString(8,loginuser.getSimeiNo());
				ps_kibou2.setString(9,PZZ010_CharacterUtil.GetDay());
				ps_kibou2.setString(10,PZZ010_CharacterUtil.GetTime());
				ps_kibou2.setString(11,loginuser.getSimeiNo());
								
				ps_kibou3 = con.prepareStatement(sql_kibou.toString());
				ps_kibou3.setString(1,str_koubo_anken_id);
				ps_kibou3.setInt(2,3);
				ps_kibou3.setString(3,kibouBean[2].getSyokuCode());
				ps_kibou3.setString(4,kibouBean[2].getSenmonCode());
				ps_kibou3.setString(5,kibouBean[2].getLevelCode());
				ps_kibou3.setString(6,PZZ010_CharacterUtil.GetDay());
				ps_kibou3.setString(7,PZZ010_CharacterUtil.GetTime());
				ps_kibou3.setString(8,loginuser.getSimeiNo());
				ps_kibou3.setString(9,PZZ010_CharacterUtil.GetDay());
				ps_kibou3.setString(10,PZZ010_CharacterUtil.GetTime());
				ps_kibou3.setString(11,loginuser.getSimeiNo());
				
				int count_kibou1 = ps_kibou1.executeUpdate();
				int count_kibou2 = ps_kibou2.executeUpdate();
				int count_kibou3 = ps_kibou3.executeUpdate();
				
				
				if ( count_kibou1 != 1 || count_kibou2 != 1 || count_kibou3 != 1) {
					 context.setRollbackOnly(  );
				 throw new PEY_WarningException();
				}
				return 1;


			} catch ( NamingException e ) {
				Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
				throw new EJBException( e );
			} catch ( SQLException e ) {
				Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
				throw new EJBException( e );
			} catch ( RuntimeException e ) {
				Log.error( loginuser.getSimeiNo(  ), "", e );
				throw e;
			} finally {
				if ( ps != null ) {
					try {
						ps.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}
				if ( ps != null ) {
					try {
						ps_search.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}
				if ( ps_kibou1 != null ) {
					try {
						ps_kibou1.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}
				if ( ps_kibou2 != null ) {
					try {
						ps_kibou2.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}
				if ( ps_kibou3 != null ) {
					try {
						ps_kibou3.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}

				if ( con != null ) {
					try {
						con.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}
//				���\�b�h�g���[�X�o��
				Log.method( loginuser.getSimeiNo(  ), "OUT", "" );	
			}
		}

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }
}
