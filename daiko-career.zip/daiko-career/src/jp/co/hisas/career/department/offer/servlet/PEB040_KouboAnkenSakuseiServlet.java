/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�Г�����@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/12  01.00       ��� �ӎ�    �V�K�쐬
 */
package jp.co.hisas.career.department.offer.servlet;

import jp.co.hisas.career.department.base.PEY_ServiceLocator;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.valuebean.*;

import jp.co.hisas.career.util.log.Log;

import jp.co.hisas.career.department.base.servlet.*;
import jp.co.hisas.career.department.offer.ejb.*;
import jp.co.hisas.career.department.offer.bean.*;

import java.rmi.RemoteException;

import javax.ejb.CreateException;

import javax.naming.NamingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.util.common.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PEB040_KouboAnkenSakuseiServlet.java
 *
 * �@�\�����F
 *   �i�l���j�R�����ʐݒ�ɂ��c�a�̃f�[�^���X�V���܂��B
 *
 *</PRE>
 */

public class PEB040_KouboAnkenSakuseiServlet extends PEY010_ControllerServlet {

	
    /**
     * request������̓f�[�^�i�R�����ʁA�A�������j
     * ���擾���A�c�a�Ƀf�[�^���i�[���܂��B
     * �i�[���SO1_KOUBO_TBL�e�[�u��
     */
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PEY_PersonalBean loginuser )
        throws NamingException, CreateException, RemoteException, PEY_WarningException {
        /* ���\�b�h�g���[�X�o�� */
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );

        /* request ����A�l���擾 */
		String kouboId  = request.getParameter("koubo_anken_id");
		PEY_ServiceLocator locator   = PEY_ServiceLocator.getInstance();
		PEB_KouboAnkenSakuseiEJBHome kouboAnkenSakkuseiEJBHome = ( PEB_KouboAnkenSakuseiEJBHome )locator.getServiceLocation( "PEB_KouboAnkenSakuseiEJB",	PEB_KouboAnkenSakuseiEJBHome.class );
		PEB_KouboAnkenSakuseiEJB kouboSakuseiEJB = kouboAnkenSakkuseiEJBHome.create(  );
		PEB_KouboAnkenBean ankenBean = setKouboBean(request,loginuser);
		
		try {
			if(kouboId == null || kouboId.equals("") || kouboId.length()==0){
				kouboSakuseiEJB.doInsert(ankenBean,loginuser);
				
			}else{
				kouboSakuseiEJB.doUpdate(ankenBean,loginuser);
			}
		}catch (PEY_WarningException e) {
			request.setAttribute( "warningID", "WEB044" );
			throw e;
		}

					
        /* ���\�b�h�g���[�X�o�� */
        Log.method( loginuser.getSimeiNo(), "OUT", "" );

        return getForwardPath();
    }
    
    private PEB_KouboAnkenBean setKouboBean(HttpServletRequest request,PEY_PersonalBean loginuser){
     	
		PEB_KouboAnkenBean kouboAnkenData = new PEB_KouboAnkenBean();
		PEB_KouboExtBean kouboAnken = new PEB_KouboExtBean();
		
		kouboAnken.setKouboankenid(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("koubo_anken_id")));
		kouboAnken.setJigyobumei(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("jigyobu_mei")));
		kouboAnken.setJigyoubutyomei(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("jigyobutyo_mei")));
		kouboAnken.setSosikicode(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("sosiki_code")));
		kouboAnken.setSimeino(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("simei_no")));
		kouboAnken.setKouboankenmei(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("koubo_anken_mei")));
		kouboAnken.setAnkengaiyo(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("anken_gaiyo")));
		
		if(request.getParameter("bosyu_ninzu")==null || ((String)request.getParameter("bosyu_ninzu")).equals("") || ((String)request.getParameter("bosyu_ninzu")).length()==0)
		{
			kouboAnken.setBosyuninzu(new Integer(0));
		}else{
			kouboAnken.setBosyuninzu(Integer.valueOf((String)request.getParameter("bosyu_ninzu")));
		}
		
		kouboAnken.setIdoukiboujiki(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("idou_kibou_jiki")));
		kouboAnken.setKibousyokusyuSonota(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("kibou_syokusyu_sonota")));
		kouboAnken.setKitaiyakuwaributyo(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("kitai_yakuwari_butyo")));
		kouboAnken.setKitaiyakuwarisyuningisi(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("kitai_yakuwari_syuningisi")));
		kouboAnken.setKitaiyakuwarigisi(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("kitai_yakuwari_gisi")));
		kouboAnken.setKitaiyakuwariippan(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("kitai_yakuwari_ippan")));
		kouboAnken.setSyozokukinmuti(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("syozoku_kinmuti")));
		kouboAnken.setGyomunaiyo(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("gyomu_naiyo")));
		kouboAnken.setJobgrade(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("job_grade")));
		kouboAnken.setSyokumurireki(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("syokumu_rireki")));
		kouboAnken.setOubosyayoukensonota(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("oubosya_youken_sonota")));
		kouboAnken.setKoubopr(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("koubo_pr")));
		kouboAnken.setSinseiriyu(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("sinsei_riyu")));
		kouboAnken.setSyoristatus(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("syori_status")));
		kouboAnken.setKousinbi(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("kousinbi")));
		kouboAnken.setKousinjikoku(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("kousinjikoku")));

		for(int i=0;i<3;i++){
			PEB_KouboKibouSyokusyuBean syokuBean = new PEB_KouboKibouSyokusyuBean();
			int no = i+1;
			syokuBean.setKouboAnkenId(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("koubo_anken_id")));			
			syokuBean.setSyokuCode(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("syokusyu_code"+no)));
			syokuBean.setSenmonCode(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("senmon_code"+no)));
			syokuBean.setLevelCode(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("level_code"+no)));
			syokuBean.setKousinbi(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("kousinbi"+no)));
			syokuBean.setKousinjikoku(PZZ010_CharacterUtil.normalizedStr((String)request.getParameter("kousinjikoku"+no)));
			syokuBean.setSeqNo(no);
				
			kouboAnkenData.addKouboKibouSyokusyuBean(syokuBean);
		}

		kouboAnkenData.setKouboBean(kouboAnken);


    	return kouboAnkenData;
    	
    }
}
