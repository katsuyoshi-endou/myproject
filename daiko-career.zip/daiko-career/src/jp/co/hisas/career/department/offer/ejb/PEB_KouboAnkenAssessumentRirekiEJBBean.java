/*
* All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
*
* �v���W�F�N�g���@�F
*   ���V�e�ACareer�i�Г�����@�\�j
*
* ���l�@�F
*   �Ȃ�
*
* �����@�F
*   ���t        �o�[�W����  ���O         ���e
*   2004/08/23  01.00       ���� ��    �V�K�쐬
*/
package jp.co.hisas.career.department.offer.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.department.base.PEY_ServiceLocator;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaAssessBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;


/**
 *<PRE>
 *
 * �N���X���F
 *   PEB_KouboAnkenAssessumentRirekiEJB �N���X
 *
 * �@�\�����F
 *   ����e�[�u���ւ̑�����s���܂��B
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PEB_KouboAnkenAssessumentRirekiEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PEB_KouboAnkenAssessumentRirekiEJBBean implements SessionBean {

    private SessionContext context = null;

	/** SQL�𑗂邽�߂�Statement�I�u�W�F�N�g */
	private Statement stmt;


    /**
     * �A�Z�X�����g�����f�[�^���擾���Ԃ��܂��B
     * (�@��ꗗ�f�[�^ )
     * @param loginuser ���O�C�����[�U
     * @return PEB_KouboKanriBean[] �擾����
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
	public PEY_KouboOubosyaAssessBean[] doSelect( PEY_PersonalBean loginuser ) {
		
        Connection con       = null;
		ResultSet rs;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			// ���������̍쐬

			PEY_KouboOubosyaAssessBean[] assessmentBeans = null;
			String P21_TBL = HcdbDef.p_assessment_sindanTbl;
			String P24_TBL = HcdbDef.p_assessment_hyokaTbl;

            StringBuffer sql  = new StringBuffer(  );

			sql.append( " SELECT " + P21_TBL + ".JISSI_NENGAPPI," );
			sql.append( 			 P21_TBL + ".SYOKU_CODE," );
			sql.append( 			 P21_TBL + ".SENMON_CODE," );
			sql.append( 			 P21_TBL + ".LEVEL_CODE," );
			sql.append( 			 P21_TBL + ".SOUGOU_T_DO AS JIKO_SOUGOU_T_DO," );
			sql.append( 			 P21_TBL + ".SYOKU_NAME," );
			sql.append( 			 P21_TBL + ".SENMON_NAME," );
			sql.append( 			 P21_TBL + ".LEVEL_NAME," );
			sql.append( 			 P24_TBL + ".SOUGOU_T_DO AS HYOKASYA_SOUGOU_T_DO" );
			sql.append( " FROM "  + P21_TBL + "," );
			sql.append( 		    P24_TBL + " "); 
			sql.append( " WHERE " + P21_TBL + ".SINDANSYA   = '"+ loginuser.getSimeiNo(  ) + "'");
			sql.append( "   AND " + P21_TBL + ".SINDANSYA   = " + P24_TBL + ".SINDANSYA" );
			sql.append( "   AND " + P21_TBL + ".SYOKU_CODE  = " + P24_TBL + ".SYOKU_CODE ");
			sql.append( "   AND " + P21_TBL + ".SENMON_CODE = " + P24_TBL + ".SENMON_CODE ");
			sql.append( "   AND " + P21_TBL + ".LEVEL_CODE  = " + P24_TBL + ".LEVEL_CODE" );
			sql.append( "   AND " + P21_TBL + ".JISSI_KAISU = " + P24_TBL + ".JISSI_KAISU" );

			// ����e�[�u���\�[�g���̍쐬
			sql.append( "  ORDER BY " + P21_TBL + ".JISSI_NENGAPPI DESC " );

			// �f�o�b�O�̏o��
			Log.debug( sql.toString( ) );

            // �R�l�N�V�����擾
            PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

			stmt = con.createStatement(  );
			rs  = stmt.executeQuery( sql.toString(  ) );

            // �������s
			List assessmentBeanList = new ArrayList(  );

			while ( rs.next(  ) ) {
				assessmentBeanList.add( new PEY_KouboOubosyaAssessBean( rs ) );
			}
			rs.close(  );

			assessmentBeans = new PEY_KouboOubosyaAssessBean[assessmentBeanList.size(  )];
			assessmentBeanList.toArray( assessmentBeans );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return ( PEY_KouboOubosyaAssessBean[] )assessmentBeanList.toArray( new PEY_KouboOubosyaAssessBean[0] );

        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( stmt != null ) {
                try {
					stmt.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }
}
