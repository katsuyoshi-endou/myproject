/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 * 
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/04/08  01.00       ���� ����    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.*;
import javax.ejb.*;
import javax.naming.*;
import javax.servlet.http.*;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.bean.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;

/**
 *<PRE>
 *
 * �N���X���F
 *   PCY151_ClassCyoseiKakuninServlet �N���X
 *
 * �@�\�����F
 *   �\���󋵂̌������s���܂��B
 *
 *</PRE>
 */
public class PCY151_ClassCyoseiKakuninServlet extends PCY010_ControllerServlet {

    protected String execute(HttpServletRequest request, HttpServletResponse response, PCY_PersonalBean loginuser)
        throws NamingException, CreateException, RemoteException, PCY_WarningException {
        /* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
        Log.method( loginuser.getSimeiNo(), "IN", "" );
        Log.performance( loginuser.getSimeiNo(), true, "" );

        PCY_ClassBean classBean = new PCY_ClassBean( request );

        String[] simeiNo = request.getParameterValues( "mousikomisya" );
      
        /** ���ߗ��R���͉�ʂ���Ă΂ꂽ�Ƃ��́AsimeiNo���擾����B*/
        if(simeiNo == null){
			Log.debug("simeiIndex �擾");
        	String simeiLengthStr = request.getParameter("simeiLength");
        	int length = (new Integer(simeiLengthStr)).intValue();
			String[] simeiNo_req = new String[length];
			simeiNo = new String[length];
        	for(int t = 0; t<length; t++){
        		simeiNo_req[t] = request.getParameter("simeiNo_" + Integer.toString(t));
				Log.debug("simeiNo: " + simeiNo_req[t]);
				simeiNo[t] = simeiNo_req[t]; 
        	}
			request.setAttribute( "riyu",request.getParameter("riyu"));
			request.setAttribute( "riyu_code",request.getParameter("riyu_code"));
        }

        if ( simeiNo != null ) {
            PCY_KensyuKanriJohoBean[]
                taisyosyaBeans = new PCY_KensyuKanriJohoBean[simeiNo.length];
            for ( int i = 0; i < simeiNo.length; i++ ) {
                taisyosyaBeans[i] = new PCY_KensyuKanriJohoBean();
                String index = simeiNo[i];

                PCY_PersonalBean personalBean = new PCY_PersonalBean();
                personalBean.setSimeiNo( request.getParameter( "simei_no_" + index ) );
                personalBean.setKanjiSimei( request.getParameter( "kanji_simei_" + index ) );
                personalBean.setSosikiCode( request.getParameter( "sosiki_code_" + index ) );

                PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean();
                mousikomiBean.setPersonalBean( personalBean );
                mousikomiBean.setMousikomibi( request.getParameter( "mousikomibi_" + index ) );
                mousikomiBean.setStatus( request.getParameter( "status_" + index ) );
                mousikomiBean.setKousinbi( request.getParameter( "kousinbi_" + index ) );
                mousikomiBean.setKousinjikoku( request.getParameter( "kousinjikoku_" + index ) );
                
                mousikomiBean.setMousikomibi( request.getParameter("mousikomibi_" + index));
				mousikomiBean.setMousikomijikoku( request.getParameter("mousikomijikoku_" + index));
				mousikomiBean.setMousikomisya( request.getParameter("mousikomisya_" + index));
				mousikomiBean.setSyoninbi1( request.getParameter("syoninbi1_" + index));
				mousikomiBean.setSyoninjikoku1( request.getParameter("syoninjikoku1_" + index));
				mousikomiBean.setSyoninsya1( request.getParameter("syoniinsya1_" + index));
				mousikomiBean.setSyoninbi2( request.getParameter("syoninbi2_" + index));
				mousikomiBean.setSyoninjikoku2( request.getParameter("syoninjikoku2_" + index));
				mousikomiBean.setSyoninsya2( request.getParameter("syoninsya2_" + index));
				mousikomiBean.setUketukebi( request.getParameter("uketukebi_" + index));
				mousikomiBean.setUketukejikoku( request.getParameter("uketukejikoku_" + index));
				mousikomiBean.setUketukesya( request.getParameter("uketukesya_" + index));
				
                
                taisyosyaBeans[i].setMousikomiBean( mousikomiBean );
                taisyosyaBeans[i].getTaisyousyaBean(  ).setTaisyoKubun( request.getParameter( "taisyokubun_" + index ) );

            }

            request.setAttribute( "taisyosyaBeans", taisyosyaBeans );
        }

        request.setAttribute( "classBean", classBean );
        request.setAttribute("simeiNoIndex",simeiNo);


        /* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
        Log.performance( loginuser.getSimeiNo(), false, "" );
        Log.method( loginuser.getSimeiNo(), "OUT", "" );

        return getForwardPath();
    }

}
