/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/01/27  01.00      �ⓡ�@������  �V�K�쐬
 *   2004/06/15              ����@���V�@ ��u�ꗗ�\�������ύX�̂���getJyukoJyokyoList���\�b�h�폜
 *   2004/06/19              ����@���V�@�@�񍐏�����̏�Ԃŕ񍐃J�������X�V���Ȃ��悤�ɏC��
 *   2004/06/19              ����@���V�@�@getListSaihyoji���\�b�h�폜�@getListWithSyoninsya�őΉ����邽��
 *   2004/06/20              ����@���V�@�@PCY_WarningException���������[���o�b�N����悤�ɏC��
 *   2004/06/20              ����@���V�@�@doInsert���\�b�h�@SQLException�������@EJBException���X���[����悤�ɏC��
 *   2004/06/22              ����@���V�@�@doSeisekiNyuryoku���\�b�h�@�x��ID���X���[����悤�ɏC��
 *   2004/06/22              ����@���V�@�@doSeisekiNyuryoku���\�b�h�@�J�Ï�Ԃɂ�����炸�A���ѓ��͂��s����悤�ɏC��
 *   2004/06/24              ����  ���V    Cosminexus�ŃG���[���o�邽�߁ATypes��java.sql.Types�ɕύX
 *   2004/06/26              ����  ���V    �N���X�I���@�@�R�����g�A�E�g����������
 *   2004/06/30              �n�Ӂ@��q    getListWithSyoninsya���s�Ώێ҂��擾����悤�C��
 *   2004/07/22              �n��  ��q    �\�[�g���C��(�Г��ŃJ�X�^�}�C�Y)
 *   2004/07/28              ���{�@�^��q  doHoukoku���\�b�h�ŁA�񍐎҂̏]���E��f�[�^�ƑΏێ҃f�[�^���擾����ۂ̃��\�b�h��ύX
 *   2004/08/09              ���{�@�^��q  doHoukoku���\�b�h�ɂŁA�񍐓��E�񍐎����E�񍐎҂̎擾��Bean��ύX
 *   2004/07/30              �n��  ��q    ��t��ԃt���O�X�V�����̒ǉ�(�Г��ŃJ�X�^�}�C�Y)
 *   2004/08/03              ����  ���V    doMousikomiWithKisyoIkkatsu���\�b�h�쐬�@�����ꊇ�N���X�ɑΉ��i�Г�Career@Net�Ή��j
 *   2004/08/03              ����  ���V    doCancel���\�b�h�����ꊇ�N���X�ɑΉ��i�Г�Career@Net�Ή��j
 *   2004/08/03              ���� ���V      ���猤�C���e�[�u�����ύX�i�Г�Career@Net�Ή��j
 *   2004/08/03              ����  ���V    doInsert���\�b�h�@�e�[�u�����C�A�E�g�ύX�Ή��i�Г�Career@Net�Ή��j
 *   2004/08/06              �n��  ��q    ���F�������A��t��ԃt���O���X�V�ΏۃJ�����ɒǉ�(�Г��ŃJ�X�^�}�C�Y)
 *   2004/08/18              �n��  ��q    doCancel���\�b�h �����̊����ꊇ�ȖڑΉ�(�Г��ŃJ�X�^�}�C�Y)  <B-ALC02-019>
 *   2004/08/20              ����  ���V    doInsert���\�b�h�@�����t���O���Z�b�g����Ă��Ȃ��ꍇ�A0�i�������j���Z�b�g����悤�ɏC���@B-ALC01-022
 *   2004/08/23              ����  ���V    �S�БΏۃt���O�Ή��@B-ALC01-030
 *   2005/12/03  01.00       �c�� ��`     �\���폜������p�~ BPX-0301J-0475
 *   2006/02/08              ���Y �T��     �S�БΏۂ̐\�����ɁAL14_�Ώێ҃e�[�u���̃`�F�b�N��ǉ� BPX-0301J-3021
 */
package jp.co.hisas.career.learning.base.ejb;

import jp.co.hisas.career.base.blob.ejb.*;
import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.bean.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.rmi.*;

import java.sql.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_KensyuRirekiEJBBean�N���X
 *
 * �@�\�����F
 *   ���猤�C�����玁��NO���L�[�ɗ��������擾���܂��B
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PCY_MousikomiJyokyoEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PCY_MousikomiJyokyoEJBBean implements SessionBean {
    private SessionContext context = null;

    /**
     * �S�БΏۃt���O�ɑΉ������\�����݂��s���B
     * �S�БΏۃt���O��0�̏ꍇ�A�\���̂�
     * �S�БΏۃt���O��1�̏ꍇ�A�\���{�ΏێҐݒ�i�C�Ӑݒ�j
     * @param mousikomiBean
     * @param loginuser
     * @return
     * @throws PCY_WarningException
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doMousikomiWithZensyaTaisyo( PCY_MousikomiJyokyoBean mousikomiBean, /* CHG#P-ALC01-030-004 */
        PCY_PersonalBean loginuser ) throws PCY_WarningException {
        try {
            int count = 0;

            /* �\�����݂��s�� */
            try {
                count = doInsert( mousikomiBean, loginuser );
            } catch ( PCY_WarningException e ) {
                throw e;
            }

            /* CHG#P-ALC01-030-004 */
            if ( "1".equals( mousikomiBean.getClassBean(  ).getZensyaTaisyoFlg(  ) ) ) {
                /* �S�БΏې\���N���X�̏ꍇ�A�Ώێ҃e�[�u���Ƀ��R�[�h��ǉ� */
                /* �T�[�r�X���P�[�^�[�̎擾 */
                PCY_ServiceLocator locator    = PCY_ServiceLocator.getInstance(  );
                PCY_TaisyoEJBHome taisyo_home = ( PCY_TaisyoEJBHome )locator.getServiceLocation( "PCY_TaisyoEJB",
                        PCY_TaisyoEJBHome.class );
                PCY_TaisyoEJB taisyo_ejb    = taisyo_home.create(  );
                PCY_TaisyosyaBean taisyosya = new PCY_TaisyosyaBean(  );
                taisyosya.setClassBean( mousikomiBean.getClassBean(  ) );
                taisyosya.setPersonalBean( mousikomiBean.getPersonalBean(  ) );
                taisyosya.setTaisyoKubun( "1" );

                // INS#P-BPX-0301J-3021-002-S
                /* L14_�Ώێ҃e�[�u���Ɋ��Ƀ��R�[�h���Ȃ����`�F�b�N���� */
                boolean taisyosyaInsertFlg = true;
                PCY_TaisyosyaBean[] taisyosyaBeans = taisyo_ejb.getTaisyosya( mousikomiBean.getClassBean().getKamokuBean().getKamokuCode(),
                    mousikomiBean.getClassBean().getClassCode(), loginuser );
                if ( taisyosyaBeans != null && taisyosyaBeans.length != 0 ) {
                    for ( int i = 0; i < taisyosyaBeans.length; i++ ) {
                        if ( taisyosya.getSimeiNo().equals( taisyosyaBeans[i].getSimeiNo() ) ){
                            taisyosyaInsertFlg = false;
                            break;
                        }
                    }
                }
                // INS#P-BPX-0301J-3021-002-E
                
                // CHG#P-BPX-0301J-3021-002-S
                /* L14_�Ώێ҃e�[�u���Ƀ��R�[�h�����݂��Ȃ��ꍇ�̂݃C���T�[�g */
                if ( taisyosyaInsertFlg ) {
                    int taisyo_count = taisyo_ejb.doInsertTaisyosya( new PCY_TaisyosyaBean[] { taisyosya },
                            loginuser );

                    if ( taisyo_count != 1 ) {
                        throw new EJBException( "�\�����ɁA�Ώێ҃e�[�u���ւ̃C���T�[�g�Ɏ��s���܂����B" );
                    }
                }
            }
            // CHG#P-BPX-0301J-3021-002-E

            return count;
        } catch ( NamingException e ) {
            context.setRollbackOnly(  );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            context.setRollbackOnly(  );
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            context.setRollbackOnly(  );
            throw new EJBException( e );
        } catch ( Exception e ) {
            context.setRollbackOnly(  );
            throw new EJBException( e );
        }
    }

    /**
     * ���ѓ��͂��s��
     * @param classBean
     * @param kensyukanrijohoBeans
     * @param loginuser
     * @return
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doSeisekiNyuryoku( PCY_ClassBean classBean,
        PCY_KensyuKanriJohoBean[] kensyukanrijohoBeans, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            /* �T�[�r�X���P�[�^�[�̎擾 */
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

            /* �N���X���ڍׂ��擾�i���b�N�j */
            PCY_ClassEJBHome class_home = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
                    PCY_ClassEJBHome.class );
            PCY_ClassEJB class_ejb     = class_home.create(  );
            PCY_ClassBean[] classBeans = class_ejb.doSelect( classBean, true, loginuser );

            //�������ʂ����݂��Ȃ�������Warning
            if ( classBeans.length < 1 ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            /* ���ѓ��͑Ώۃ��X�g���A�Ď擾���A�X�V����Ă��Ȃ����`�F�b�N���� */
            /* ���C�Ǘ����f�[�^���擾 */
            PCY_TaisyoEJBHome taisyo_home = ( PCY_TaisyoEJBHome )locator.getServiceLocation( "PCY_TaisyoEJB",
                    PCY_TaisyoEJBHome.class );
            PCY_TaisyoEJB taisyo_ejb = taisyo_home.create(  );

            /* �N���X��񂩂�Ώێҏ�񃊃X�g���擾���� */
            PCY_KensyuKanriJohoBean[] kensyukanrijohoBeans_tmp = taisyo_ejb
                .getSeisekiNyuryokuTaisyousyaInfo( classBeans[0], true, loginuser );
            HashMap kensyukanrijohoBeans_tmp_map = new HashMap(  );

            for ( int i = 0; i < kensyukanrijohoBeans_tmp.length; i++ ) {
                kensyukanrijohoBeans_tmp_map.put( kensyukanrijohoBeans_tmp[i].getPersonalBean(  )
                                                                             .getSimeiNo(  ),
                    kensyukanrijohoBeans_tmp[i] );
            }

            /*
             * �`�F�b�N�J�n
             * �\�����e�[�u���ɒǉ�����v�f�ԍ���ێ�
             */
            String[] mousikomiAddIndexNo = new String[kensyukanrijohoBeans.length];

            for ( int i = 0; i < kensyukanrijohoBeans.length; i++ ) {
                /* �\�����e�[�u���ɒǉ�����v�f�ԍ��������� */
                mousikomiAddIndexNo[i] = "0";

                /* ���ѓ��͂������ */
                PCY_KensyuKanriJohoBean taisyo_obj = kensyukanrijohoBeans[i];

                /* �V�K�ɂƂ��Ă������� */
                PCY_KensyuKanriJohoBean check_obj = ( PCY_KensyuKanriJohoBean )kensyukanrijohoBeans_tmp_map
                    .get( taisyo_obj.getPersonalBean(  ).getSimeiNo(  ) );

                String kousin_bi           = "";
                String kousin_jikoku       = "";
                String kousin_bi_check     = "";
                String kousin_jikoku_check = "";

                if ( taisyo_obj.getKensyurirekiBean(  ) != null ) {
                    kousin_bi               = taisyo_obj.getKensyurirekiBean(  ).getKousinbi(  );
                    kousin_jikoku           = taisyo_obj.getKensyurirekiBean(  ).getKousinjikoku(  );
                    kousin_bi_check         = check_obj.getKensyurirekiBean(  ).getKousinbi(  );
                    kousin_jikoku_check     = check_obj.getKensyurirekiBean(  ).getKousinjikoku(  );
                } else if ( taisyo_obj.getMousikomiBean(  ) != null ) {
                    if ( check_obj.getMousikomiBean(  ) != null ) {
                        /* �\���敪�s�v�A����v�łȂ��ꍇ */
                        kousin_bi               = taisyo_obj.getMousikomiBean(  ).getKousinbi(  );
                        kousin_jikoku           = taisyo_obj.getMousikomiBean(  ).getKousinjikoku(  );
                        kousin_bi_check         = check_obj.getMousikomiBean(  ).getKousinbi(  );
                        kousin_jikoku_check     = check_obj.getMousikomiBean(  ).getKousinjikoku(  );
                    } else {
                        /* �\���敪�s�v�A����v�̏ꍇ */
                        /* �_���A���сA�I������A��u�N�����ȊO���Z�b�g���� */
                        String now_day  = PZZ010_CharacterUtil.GetDay(  );
                        String now_time = PZZ010_CharacterUtil.GetTime(  );

                        kensyukanrijohoBeans[i].getMousikomiBean(  ).setClassBean( classBeans[0] );
                        kensyukanrijohoBeans[i].getMousikomiBean(  ).setPersonalBean( kensyukanrijohoBeans[i]
                            .getPersonalBean(  ) );

                        kensyukanrijohoBeans[i].getMousikomiBean(  ).setHanteibi( now_day );
                        kensyukanrijohoBeans[i].getMousikomiBean(  ).setHanteijikoku( now_time );
                        kensyukanrijohoBeans[i].getMousikomiBean(  ).setHanteisya( loginuser
                            .getSimeiNo(  ) );
                        kensyukanrijohoBeans[i].getMousikomiBean(  ).setTourokubi( now_day );
                        kensyukanrijohoBeans[i].getMousikomiBean(  ).setTourokujikoku( now_time );
                        kensyukanrijohoBeans[i].getMousikomiBean(  ).setTourokusya( loginuser
                            .getSimeiNo(  ) );

                        /* �\�����e�[�u���ɒǉ�����v�f�ԍ���ێ� */
                        mousikomiAddIndexNo[i] = "1";
                    }
                }

                if ( !kousin_bi.equals( kousin_bi_check )
                    || !kousin_jikoku.equals( kousin_jikoku_check ) ) {
                    /* ���ѓ��͒��Ƀf�[�^�X�V���s��ꂽ */
                    context.setRollbackOnly(  );
                    throw new PCY_WarningException(  );
                }
            }

            /* �f�[�^�̊i�[���s���B */
            /* �\���󋵃e�[�u���ɍX�V����f�[�^�̃s�b�N�A�b�v
             * ���猤�C���e�[�u���ɒǉ�/�X�V����f�[�^�̃s�b�N�A�b�v
             */
            ArrayList kensyurirekiAddList    = new ArrayList(  );
            ArrayList mousikomiDeleteList    = new ArrayList(  );
            ArrayList kensyurirekiUpdateList = new ArrayList(  );
            ArrayList mousikomiUpdateList    = new ArrayList(  );

            /* PYF_BlobDBAccessEJB�̃��b�N�A�b�v���s�� */
            String jdbcType = ( String )ReadFile.fileMapData.get( "AP_SERVER_JDBC_TYPE" );
            String jndiName = "";

            if ( jdbcType.equals( "DABROKER" ) ) {
                jndiName = "PYF_BlobDBAccessCosmiEJB";
            } else if ( jdbcType.equals( "ORACLE" ) ) {
                jndiName = "PYF_BlobDBAccessOracleEJB";
            }

            //JNDI���̃��b�N�A�b�v
            PYF_BlobDBAccessEJBHome blobHome = ( PYF_BlobDBAccessEJBHome )locator
                .getServiceLocation( jndiName, PYF_BlobDBAccessEJBHome.class );

            //EJBObject�̎擾
            PYF_BlobDBAccessEJB blobEjb = blobHome.create(  );

            for ( int i = 0; i < kensyukanrijohoBeans.length; i++ ) {
            	/* �\�����null����Ȃ��A�C�����肪�ݒ肳��Ă���΁A�\���󋵃e�[�u�����猤�C�����Ƀ��R�[�h���ړ�*/
                if ( kensyukanrijohoBeans[i].getMousikomiBean(  ) != null 
                       && (kensyukanrijohoBeans[i].getMousikomiBean().getSyuryoHantei() != null && !kensyukanrijohoBeans[i].getMousikomiBean().getSyuryoHantei().equals(""))) {
                    if ( mousikomiAddIndexNo[i].equals( "0" ) ) {
                        /* �\���󋵃e�[�u�����猤�C�����e�[�u���Ɉړ������郌�R�[�h */
                        /* BLOB�l���擾���� */
                        String[] primary_key = {
                            "KAMOKU_CODE", "CLASS_CODE", "SIMEI_NO", "STATUS"
                        };
                        String[] primary_value = {
                            kensyukanrijohoBeans[i].getMousikomiBean(  ).getKamokuCode(  ), kensyukanrijohoBeans[i].getMousikomiBean(  )
                                                                                                                   .getClassCode(  ), kensyukanrijohoBeans[i].getMousikomiBean(  )
                                                                                                                                                             .getSimeiNo(  ), kensyukanrijohoBeans[i].getMousikomiBean(  )
                                                                                                                                                                                                     .getStatus(  )
                        };
                        byte[] houkoku = blobEjb.SelectBLOB( loginuser.getSimeiNo(  ),
                                HcdbDef.L15_TBL, "HOUKOKU", primary_key, primary_value );

                        kensyukanrijohoBeans[i].getMousikomiBean(  ).setHoukoku( houkoku );
                        mousikomiDeleteList.add( kensyukanrijohoBeans[i].getMousikomiBean(  ) );
                    }

                    PCY_KensyuRirekiBean rirekibean = new PCY_KensyuRirekiBean( classBeans[0]
                            .getKamokuBean(  ), classBeans[0],
                            kensyukanrijohoBeans[i].getMousikomiBean(  ) );

                    /* �{�l�C���t���O�O�@�Œ� */
                    rirekibean.setHonninSyuseiFlg( "0" );

                    /* ���J����J�t���O */
                    rirekibean.setKokaiFlg( kensyukanrijohoBeans[i].getPersonalBean(  )
                                                                   .getKensyuRirekiKokaiFlg(  ) );

                    /* �Ώۋ敪�ݒ� */
                    rirekibean.setTaisyoKubun( kensyukanrijohoBeans[i].getTaisyousyaBean(  )
                                                                      .getTaisyoKubun(  ) );
                                                                      
                   /* ������E���莞���E������҂�ݒ�*/
                   rirekibean.setUketukebi(kensyukanrijohoBeans[i].getMousikomiBean().getUketukebi());
				   rirekibean.setUketukejikoku(kensyukanrijohoBeans[i].getMousikomiBean().getUketukejikoku());
				   rirekibean.setUketukesya(kensyukanrijohoBeans[i].getMousikomiBean().getUketukesya());
                   rirekibean.setHanteibi(PZZ010_CharacterUtil.GetDay());
                   rirekibean.setHanteijikoku(PZZ010_CharacterUtil.GetTime());
                   rirekibean.setHanteisya(loginuser.getSimeiNo());
                   
                    kensyurirekiAddList.add( rirekibean );
                } else if (kensyukanrijohoBeans[i].getMousikomiBean(  ) != null 
                             && (kensyukanrijohoBeans[i].getMousikomiBean().getSyuryoHantei() == null || kensyukanrijohoBeans[i].getMousikomiBean().getSyuryoHantei().equals(""))){
					mousikomiUpdateList.add(kensyukanrijohoBeans[i].getMousikomiBean());         	
                }else if ( kensyukanrijohoBeans[i].getKensyurirekiBean(  ) != null ) {
					/*������E���莞���E������҂�ݒ�*/
					PCY_KensyuRirekiBean kensyuRireki = kensyukanrijohoBeans[i].getKensyurirekiBean(  );
					kensyuRireki.setHanteibi(PZZ010_CharacterUtil.GetDay());
					kensyuRireki.setHanteijikoku(PZZ010_CharacterUtil.GetTime());
					kensyuRireki.setHanteisya(loginuser.getSimeiNo());
                    kensyurirekiUpdateList.add( kensyuRireki );
                }
            }

            /* ���ׂĂ̏�񂪃s�b�N�A�b�v���ꂽ���`�F�b�N���� */
            if ( kensyukanrijohoBeans.length != ( kensyurirekiAddList.size(  ) 
                + kensyurirekiUpdateList.size(  ) + mousikomiUpdateList.size())) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException( "���ׂĂ̏�񂪃s�b�N�A�b�v����܂���ł����B" );
            }

            /* �\���󋵂̍폜���s�� */
            int mousikomi_del_count = 0;

            if ( mousikomiDeleteList.size(  ) != 0 ) {
                PCY_MousikomiJyokyoBean[] mousikomiBeans_del = new PCY_MousikomiJyokyoBean[mousikomiDeleteList
                    .size(  )];
                mousikomiBeans_del     = ( PCY_MousikomiJyokyoBean[] )mousikomiDeleteList.toArray( mousikomiBeans_del );

                mousikomi_del_count = this.doDeleteByPrimaryKey( mousikomiBeans_del, loginuser );
            }

            /* �\���󋵍폜�������`�F�b�N���� */
            if ( mousikomiDeleteList.size(  ) != mousikomi_del_count ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException( "�\���󋵍폜�Ώې��ƁA�폜�������قȂ�܂��B" );
            }

            /* ���猤�C���̒ǉ����s�� */
            int kensyu_add_count = 0;

            if ( kensyurirekiAddList.size(  ) != 0 ) {
                PCY_KensyuRirekiEJBHome rirekiHome = ( PCY_KensyuRirekiEJBHome )locator
                    .getServiceLocation( "PCY_KensyuRirekiEJB", PCY_KensyuRirekiEJBHome.class );
                PCY_KensyuRirekiEJB rirekiEjb = rirekiHome.create(  );

                PCY_KensyuRirekiBean[] kensyurirekiBeans_insert = new PCY_KensyuRirekiBean[kensyurirekiAddList
                    .size(  )];
                kensyurirekiBeans_insert     = ( PCY_KensyuRirekiBean[] )kensyurirekiAddList
                    .toArray( kensyurirekiBeans_insert );

                kensyu_add_count = rirekiEjb.doInsert( kensyurirekiBeans_insert, loginuser );
            }

            /* �ǉ��������`�F�b�N���� */
            if ( kensyurirekiAddList.size(  ) != kensyu_add_count ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException( "���C����ǉ��Ώې��ƁA�ǉ��������قȂ�܂��B" );
            }

            /* ���猤�C���̍X�V���s�� */
            int kensyu_update_count = 0;

            if ( kensyurirekiUpdateList.size(  ) != 0 ) {
                PCY_KensyuRirekiEJBHome rirekiHome = ( PCY_KensyuRirekiEJBHome )locator
                    .getServiceLocation( "PCY_KensyuRirekiEJB", PCY_KensyuRirekiEJBHome.class );
                PCY_KensyuRirekiEJB rirekiEjb                   = rirekiHome.create(  );
                PCY_KensyuRirekiBean[] kensyurirekiBeans_update = new PCY_KensyuRirekiBean[kensyurirekiUpdateList
                    .size(  )];
                kensyurirekiBeans_update                        = ( PCY_KensyuRirekiBean[] )kensyurirekiUpdateList
                    .toArray( kensyurirekiBeans_update );

                kensyu_update_count = rirekiEjb.doUpdate( kensyurirekiBeans_update, loginuser );

                /* �_���J������Integer,�o�ȓ�����Float�ł���AdoUpdate���\�b�h�ł�Null�̏ꍇ�X�V���Ȃ����߁A*/
                /* �_���J�����Əo�ȓ����̍X�V���s���B */
                ArrayList update_tensu_seq = new ArrayList(  );
                ArrayList update_syuseki_seq = new ArrayList( );

                for ( int i = 0; i < kensyurirekiBeans_update.length; i++ ) {
                    if ( kensyurirekiBeans_update[i].getTensu(  ) == null ) {
                        update_tensu_seq.add( kensyurirekiBeans_update[i].getSeqNo(  ) );
                    }
                    if ( kensyurirekiBeans_update[i].getSyussekiNissuu(  ) == null ) {
						update_syuseki_seq.add( kensyurirekiBeans_update[i].getSeqNo(  ) );
                    }
                }

                con     = locator.getDataSource(  ).getConnection(  );  // INS 2007/2/2 s-hiura
                if ( update_tensu_seq.size(  ) > 0 ) {
                    StringBuffer sql = new StringBuffer(  );
                    sql.append( "UPDATE " );
                    sql.append( HcdbDef.L51_TBL ); /* For SAS */
                    sql.append( " SET TENSU=? " );

                    for ( int i = 0; i < update_tensu_seq.size(  ); i++ ) {
                        sql.append( " OR SEQ_NO=?" );
                    }

                    String sqlString = sql.toString(  ).replaceFirst( "OR", "WHERE" );

                    /* �f�o�b�O���O���o�� */
                    Log.debug( sqlString );

                    // DEL 2007/2/2 s-hiura
                    ps      = con.prepareStatement( sqlString );
                    ps.setNull( 1, java.sql.Types.INTEGER );

                    for ( int i = 0; i < update_tensu_seq.size(  ); i++ ) {
                        ps.setString( i + 2, ( String )update_tensu_seq.get( i ) );
                    }

                    int count = ps.executeUpdate(  );
                    ps.close();

                    if ( update_tensu_seq.size(  ) != count ) {
                        context.setRollbackOnly(  );
                        throw new PCY_WarningException(  );
                    }
                }
                
				if ( update_syuseki_seq.size(  ) > 0 ) {
					StringBuffer sql = new StringBuffer(  );
					sql.append( "UPDATE " );
					sql.append( HcdbDef.L51_TBL ); 
					sql.append( " SET SYUSSEKI_NISSUU=? " );

					for ( int i = 0; i < update_syuseki_seq.size(  ); i++ ) {
						sql.append( " OR SEQ_NO=?" );
					}

					String sqlString = sql.toString(  ).replaceFirst( "OR", "WHERE" );

					/* �f�o�b�O���O���o�� */
					Log.debug( sqlString );

					// DEL 2007/2/2 s-hiura
					ps      = con.prepareStatement( sqlString );
					ps.setNull( 1, java.sql.Types.FLOAT );

					for ( int i = 0; i < update_syuseki_seq.size(  ); i++ ) {
						ps.setString( i + 2, ( String )update_syuseki_seq.get( i ) );
					}

					int count = ps.executeUpdate(  );
					ps.close();

					if ( update_syuseki_seq.size(  ) != count ) {
						context.setRollbackOnly(  );
						throw new PCY_WarningException(  );
					}
				}
            }

            /* �X�V�������`�F�b�N���� */
            if ( kensyurirekiUpdateList.size(  ) != kensyu_update_count ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException( "���C�����X�V�Ώې��ƁA�X�V�������قȂ�܂��B" );
            }
            
            /*�@�\���󋵂̍X�V���s�Ȃ�*/
			int mousikomi_update_count = 0;

			if ( mousikomiUpdateList.size(  ) != 0 ) {
				
				PCY_MousikomiJyokyoBean[] mousikomiBeans_update = new PCY_MousikomiJyokyoBean[mousikomiUpdateList.size(  )];
				mousikomiBeans_update = ( PCY_MousikomiJyokyoBean[] )mousikomiUpdateList.toArray( mousikomiBeans_update );

				mousikomi_update_count = this.doUpdateSeiseki(mousikomiBeans_update,loginuser);
				
			}     
			/* �X�V�������`�F�b�N���� */
			if ( mousikomiUpdateList.size(  ) != mousikomi_update_count ) {
				context.setRollbackOnly(  );
				throw new PCY_WarningException( "�\���󋵍X�V�Ώې��ƁA�X�V�������قȂ�܂��B" );
			}      

            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return 0;
        } catch ( NamingException e ) {
            context.setRollbackOnly(  );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            context.setRollbackOnly(  );
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            context.setRollbackOnly(  );
            throw new EJBException( e );
        } catch ( Exception e ) {
            context.setRollbackOnly(  );
            throw new EJBException( e );
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * ����s�v�̃N���X�̕񍐂��s���܂��B
     *
     * @param mousikomiBean �\�����
     * @param rirekiBean �������
     * @param loginuser ���O�C�����[�U���
     * @param ninsyoBean ES�F�؏��
     * @throws PCY_WarningException �ȖځA�N���X�̏�񂪍X�V����Ă����ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public void doHoukoku( PCY_MousikomiJyokyoBean mousikomiBean, PCY_KensyuRirekiBean rirekiBean,
        PCY_EsNinsyoRirekiBean ninsyoBean, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            //�T�[�r�X���P�[�^�[�̃C���X�^���X���擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

            /* �Y���ȖځA�N���X���X�V����Ă��Ȃ����`�F�b�N����(���b�N�t��) */

            //JNDI���̃��b�N�A�b�v
            PCY_ClassEJBHome classHome = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
                    PCY_ClassEJBHome.class );

            //EJBObject�̎擾
            PCY_ClassEJB ejb2         = classHome.create(  );
            PCY_ClassBean[] classList = ejb2.doSelect( mousikomiBean.getClassBean(  ), true,
                    loginuser );

            //�������ʂ����݂��Ȃ�������Warning
            if ( classList.length < 1 ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            /* �\����DB�̃��R�[�h���擾���āADELETE */

            //�\����DB���烌�R�[�h�擾
            PCY_MousikomiJyokyoBean[] mousikomiList = this.getList( mousikomiBean, loginuser );

            /* �\���敪���v�̏ꍇ */
            if ( classList[0].getMousikomiKubun(  ).equals( "1" ) ) {
                //�\���v�̃N���X�ŁA�\����񂪂Ȃ�������Warning
                if ( mousikomiList.length < 1 ) {
                    context.setRollbackOnly(  );
                    throw new PCY_WarningException(  );
                }

                //�\����DB����DELETE
                this.doDeleteByPrimaryKey( new PCY_MousikomiJyokyoBean[] { mousikomiBean },
                    loginuser );
            }

            /* ���猤�C��DB�Ƀ��R�[�h���C���T�[�g */

            //�Ώۋ敪���擾
            //JNDI���̃��b�N�A�b�v
            PCY_TaisyoEJBHome taisyoHome = ( PCY_TaisyoEJBHome )locator.getServiceLocation( "PCY_TaisyoEJB",
                    PCY_TaisyoEJBHome.class );

            //EJBObject�̎擾
            PCY_TaisyoEJB taisyoEjb = taisyoHome.create(  );

            PCY_TaisyosyokusyuBean[] syokusyulist = taisyoEjb.getTaisyosyokusyu( loginuser,
                    mousikomiBean //CHG#P-PLI03-020-001
                .getKamokuCode(  ), mousikomiBean.getClassCode(  ), loginuser );
            PCY_TaisyososikiBean[] sosikilist = taisyoEjb.getTaisyososiki( loginuser,
                    mousikomiBean.getKamokuCode(  ), mousikomiBean.getClassCode(  ), loginuser );
            PCY_TaisyosyaBean[] taisyosyalist = taisyoEjb.getTaisyosya( mousikomiBean.getPersonalBean(  )
                                                                                     .getSimeiNo(  ),
                    loginuser ); //CHG#P-PLI03-020-001

            //DEL#P-PLI03-020-001 
            String taisyosyokusyu = null;

            if ( syokusyulist.length > 0 ) {
                for ( int i = 0; i < syokusyulist.length; i++ ) {
                    //INS#P-PLI03-020-001-S
                    if ( mousikomiBean.getKamokuCode(  ).equals( syokusyulist[i].getKamokuCode(  ) )
                        && mousikomiBean.getClassCode(  ).equals( syokusyulist[i].getClassCode(  ) ) ) {
                        //INS#P-PLI03-020-001-E
                        //CHG#P-PLI03-020-001-S
                        if ( syokusyulist[i].getTaisyoKubun(  ).equals( "0" ) ) {
                            taisyosyokusyu = syokusyulist[i].getTaisyoKubun(  );

                            break;
                        } else if ( syokusyulist[i].getTaisyoKubun(  ).equals( "1" ) ) {
                            taisyosyokusyu = syokusyulist[i].getTaisyoKubun(  );
                        }

                        //CHG#P-PLI03-020-001-E														
                    }

                    //INS#P-PLI03-020-001
                }
            }

            String taisyososiki = null;

            if ( sosikilist.length > 0 ) {
                taisyososiki = sosikilist[0].getTaisyoKubun(  );
            }

            String taisyosya = null;

            if ( taisyosyalist.length > 0 ) {
                //INS#P-PLI03-020-001-S
                for ( int i = 0; i < taisyosyalist.length; i++ ) {
                    if ( mousikomiBean.getKamokuCode(  ).equals( taisyosyalist[i].getKamokuCode(  ) )
                        && mousikomiBean.getClassCode(  ).equals( taisyosyalist[i].getClassCode(  ) ) ) {
                        //INS#P-PLI03-020-001-E
                        taisyosya = taisyosyalist[i].getTaisyoKubun(  ); //CHG#P-PLI03-020-001

                        //INS#P-PLI03-020-001-S							
                    }
                }

                //INS#P-PLI03-020-001-E
            }

            String taisyoKubun = PCY_TaisyoBeanImpl.getTaisyoKubun( taisyosyokusyu, taisyososiki,
                    taisyosya );

            //���猤�C����Bean�ɒl���Z�b�g
            PCY_KensyuRirekiBean rirekiInput = null;

            if ( mousikomiList.length != 0 ) {
                rirekiInput = new PCY_KensyuRirekiBean( classList[0].getKamokuBean(  ),
                        classList[0], mousikomiList[0] );
            } else {
                rirekiInput = new PCY_KensyuRirekiBean( classList[0].getKamokuBean(  ),
                        classList[0], mousikomiBean );
            }

            //�������i��u���j
            rirekiInput.setJyukoubi( rirekiBean.getJyukoubi(  ) );

            //���|�[�g�t�@�C����
            rirekiInput.setReportFilename( rirekiBean.getReportFilename(  ) );

            //���|�[�g�`��
            rirekiInput.setReportContentType( rirekiBean.getReportContentType(  ) );

            //��
            rirekiInput.setHoukoku( rirekiBean.getHoukoku(  ) );

            //�񍐓�
            rirekiInput.setHoukokubi( mousikomiBean.getHoukokubi(  ) ); //CHG#P-PLI03-030-001

            //�񍐎���
            rirekiInput.setHoukokujikoku( mousikomiBean.getHoukokujikoku(  ) ); //CHG#P-PLI03-030-001

            //�񍐎�
            rirekiInput.setHoukokusya( mousikomiBean.getHoukokusya(  ) ); //CHG#P-PLI03-030-001

            //�C������
            rirekiInput.setSyuryoHantei( rirekiBean.getSyuryoHantei(  ) );

            //�{�l�C���t���O
            rirekiInput.setHonninSyuseiFlg( rirekiBean.getHonninSyuseiFlg(  ) );

            //���J����J�t���O
            rirekiInput.setKokaiFlg( rirekiBean.getKokaiFlg(  ) );

            //�Ώۋ敪
            rirekiInput.setTaisyoKubun( taisyoKubun );

            //JNDI���̃��b�N�A�b�v
            PCY_KensyuRirekiEJBHome rirekiHome = ( PCY_KensyuRirekiEJBHome )locator
                .getServiceLocation( "PCY_KensyuRirekiEJB", PCY_KensyuRirekiEJBHome.class );

            //EJBObject�̎擾
            PCY_KensyuRirekiEJB rirekiEjb = rirekiHome.create(  );

            //���猤�C��DB�ɃC���T�[�g
            rirekiEjb.doInsert( new PCY_KensyuRirekiBean[] { rirekiInput }, loginuser );

            /* For Syanai */
            /* �\���敪���s�v�̏ꍇ */
            if ( classList[0].getMousikomiKubun(  ).equals( "0" ) ) { 
                /* �S�БΏې\���N���X�̏ꍇ�A�Ώێ҃e�[�u���Ƀ��R�[�h��ǉ� */
                if ( "1".equals( mousikomiBean.getClassBean(  ).getZensyaTaisyoFlg(  ) ) ) {
                    PCY_TaisyosyaBean taisyosyaBean = new PCY_TaisyosyaBean(  );
                    taisyosyaBean.setClassBean( mousikomiBean.getClassBean(  ) );
                    taisyosyaBean.setPersonalBean( mousikomiBean.getPersonalBean(  ) );
                    taisyosyaBean.setTaisyoKubun( "1" );
                    int taisyo_count = taisyoEjb.doInsertTaisyosya( new PCY_TaisyosyaBean[] { taisyosyaBean }, loginuser );

                    if ( taisyo_count != 1 ) {
                        throw new EJBException( "�񍐎��ɁA�Ώێ҃e�[�u���ւ̃C���T�[�g�Ɏ��s���܂����B" );
                    }
                }
            }

            /* ES�F�ؗv�̏ꍇ�ɂ�ES�F�ؗ������i�[���� */
            if ( mousikomiBean.getClassBean(  ).getNinsyoKubun(  ).equals( "1" ) ) {
                /* PCY_EsNinsyoRirekiEJB */
                PCY_EsNinsyoRirekiEJBHome ninsyoHome = ( PCY_EsNinsyoRirekiEJBHome )locator
                    .getServiceLocation( "PCY_EsNinsyoRirekiEJB", PCY_EsNinsyoRirekiEJBHome.class );
                PCY_EsNinsyoRirekiEJB ninsyoEjb = ninsyoHome.create(  );

                /* ES�F�ؗ����̊i�[ */
                ninsyoEjb.doInsert( new PCY_EsNinsyoRirekiBean[] { ninsyoBean }, loginuser );
            }

            /* ���\�b�h�g���[�X�o�� */
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * ���C�̎�����s���܂��B
     *
     * @param mousikomiBeans �\�����
     * @param loginuser ���O�C�����[�U���
     * @throws NamingException ���O������O
     * @throws RemoteException �����[�g��O
     * @throws PCY_WarningException �ȖځA�N���X�̏�񂪍X�V����Ă����ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public void doCancel( PCY_MousikomiJyokyoBean[] mousikomiBeans, PCY_PersonalBean loginuser )
        throws NamingException, RemoteException, PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			if ( ( mousikomiBeans != null ) && ( mousikomiBeans.length > 0 ) ) {
				//�T�[�r�X���P�[�^�[�̃C���X�^���X���擾
				PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

				//�Z�b�V�����r�[���ւ̃C���^�[�t�F�[�X���擾����
				Context initial = new InitialContext(  );

				//�Y���ȖځA�N���X���X�V����Ă��Ȃ����`�F�b�N����(���b�N�t��)
				//JNDI���̃��b�N�A�b�v
				PCY_ClassEJBHome classHome = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
						PCY_ClassEJBHome.class );

				//EJBObject�̎擾
				PCY_ClassEJB ejb2         = classHome.create(  );
				PCY_ClassBean[] classList = ejb2.doSelect( mousikomiBeans[0].getClassBean(  ),
						true, loginuser );

				//�������ʂ����݂��Ȃ�������Warning
				if ( classList.length < 1 ) {
					context.setRollbackOnly(  );
					throw new PCY_WarningException(  );
				}

				//�\����DB�̃��R�[�h��DELETE
				/* �\����DB����DELETE */
				this.doDeleteByPrimaryKey( mousikomiBeans, loginuser );

				/* For Syanai-S */


				PCY_TaisyoEJBHome taisyo_home = ( PCY_TaisyoEJBHome )locator.getServiceLocation( "PCY_TaisyoEJB",
						PCY_TaisyoEJBHome.class );
				PCY_TaisyoEJB taisyo_ejb = taisyo_home.create(  );

				// INS#P-ALC02-019-005-S
				ArrayList mousikomiBeanList = new ArrayList(  );

				for ( int i = 0; i < mousikomiBeans.length; i++ ) {
					/* CHG#P-ALC01-030-004 */
					if ( "1".equals( mousikomiBeans[i].getClassBean(  ).getZensyaTaisyoFlg(  ) ) ) {
						mousikomiBeanList.add( mousikomiBeans[i] );
					}
				}

				// CHG#P-ALC02-019-005-S
				PCY_TaisyosyaBean[] taisyosyaBeans = new PCY_TaisyosyaBean[mousikomiBeanList
					.size(  )];

				for ( int i = 0; i < mousikomiBeanList.size(  ); i++ ) {
					PCY_MousikomiJyokyoBean mousikomiBeanTemp = ( PCY_MousikomiJyokyoBean )mousikomiBeanList
						.get( i );
					taisyosyaBeans[i] = new PCY_TaisyosyaBean(  );
					taisyosyaBeans[i].setClassBean( mousikomiBeanTemp.getClassBean(  ) );
					taisyosyaBeans[i].setPersonalBean( mousikomiBeanTemp.getPersonalBean(  ) );
					taisyosyaBeans[i].setTaisyoKubun( "1" );
				}

				int taisyo_count = taisyo_ejb.doDeleteTaisyosya( taisyosyaBeans, loginuser );

				if ( taisyo_count != mousikomiBeanList.size(  ) ) {
					// CHG#P-ALC02-019-005-E
					throw new EJBException( "������ɁA�Ώێ҃e�[�u���̍폜�Ɏ��s���܂����B" );
				}

				/* For Syanai-E */
			}

            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

	/**
	 * ���C�̍��߂��A�\���폜�����ɑ}�����s���܂��B
	 *
	 * @param mousikomiBeans �\�����
	 * @param taisyosyaBeans �Ώۋ敪�݂̂������
	 * @param loginuser ���O�C�����[�U���
	 * @param code �폜�t���O
	 * @throws NamingException ���O������O
	 * @throws RemoteException �����[�g��O
	 * @throws PCY_WarningException �ȖځA�N���X�̏�񂪍X�V����Ă����ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public void doCancelAndRirekiInsert( PCY_MousikomiJyokyoBean[] mousikomiBeans, PCY_TaisyosyaBean[] taisyoBeans, PCY_PersonalBean loginuser ,String code)
		throws NamingException, RemoteException, PCY_WarningException {
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			if ( ( mousikomiBeans != null ) && ( mousikomiBeans.length > 0 ) ) {
				//�T�[�r�X���P�[�^�[�̃C���X�^���X���擾
				PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

				//�Z�b�V�����r�[���ւ̃C���^�[�t�F�[�X���擾����
				Context initial = new InitialContext(  );

				//�Y���ȖځA�N���X���X�V����Ă��Ȃ����`�F�b�N����(���b�N�t��)
				//JNDI���̃��b�N�A�b�v
				PCY_ClassEJBHome classHome = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
						PCY_ClassEJBHome.class );

				//EJBObject�̎擾
				PCY_ClassEJB ejb2         = classHome.create(  );
				PCY_ClassBean[] classList = ejb2.doSelect( mousikomiBeans[0].getClassBean(  ),
						true, loginuser );

				//�������ʂ����݂��Ȃ�������Warning
				if ( classList.length < 1 ) {
					context.setRollbackOnly(  );
					throw new PCY_WarningException(  );
				}

				//�\����DB�̃��R�[�h��DELETE
				/* �\����DB����DELETE */
				this.doDeleteByPrimaryKey( mousikomiBeans, loginuser );
				
				/* �\���폜�����ɍ폜������}�� */
				PCY_MousikomiSakujoRirekiEJBHome sakujyorireki_home = ( PCY_MousikomiSakujoRirekiEJBHome )locator.getServiceLocation( "PCY_MousikomiSakujoRirekiEJB",PCY_MousikomiSakujoRirekiEJBHome.class );
				PCY_MousikomiSakujoRirekiEJB sakujyorireki_ejb = sakujyorireki_home.create(  );
									
				PCY_MousikomiSakujoRirekiBean[] sakujoRirekiBeans = new PCY_MousikomiSakujoRirekiBean[mousikomiBeans.length];
				PCY_MousikomiJyokyoBean[] mousikomiTmps = new PCY_MousikomiJyokyoBean[mousikomiBeans.length];
				for(int t = 0; t < mousikomiBeans.length; t++ ){
					 mousikomiTmps[t] = mousikomiBeans[t];
					 mousikomiTmps[t].setClassBean(classList[0]);
					sakujoRirekiBeans[t] = new PCY_MousikomiSakujoRirekiBean(mousikomiTmps[t],taisyoBeans[t],loginuser,code);
				}						

				int sakujoRireki_count = sakujyorireki_ejb.doInsert(sakujoRirekiBeans,loginuser);
				if ( sakujoRireki_count != mousikomiBeans.length ) {
					throw new EJBException( "������ɁA�\���폜�����̒ǉ��Ɏ��s���܂����B" );
				}
				

				/* For Syanai-S */

				// INS#P-ALC02-019-005-S
				ArrayList mousikomiBeanList = new ArrayList(  );

				for ( int i = 0; i < mousikomiBeans.length; i++ ) {

					/* CHG#P-ALC01-030-004 */
					if ( "1".equals( mousikomiBeans[i].getClassBean(  ).getZensyaTaisyoFlg(  ) ) ) {
						mousikomiBeanList.add( mousikomiBeans[i] );
					}
				}

				// INS#P-ALC02-019-005-E
				if ( mousikomiBeanList.size(  ) != 0 ) { // CHG#P-ALC02-019-005

					/* �S�БΏۃN���X�̏ꍇ�A�Ώێ҃e�[�u���̃��R�[�h���폜 */
					PCY_TaisyoEJBHome taisyo_home = ( PCY_TaisyoEJBHome )locator.getServiceLocation( "PCY_TaisyoEJB",
							PCY_TaisyoEJBHome.class );
					PCY_TaisyoEJB taisyo_ejb = taisyo_home.create(  );

					// CHG#P-ALC02-019-005-S
					PCY_TaisyosyaBean[] taisyosyaBeans = new PCY_TaisyosyaBean[mousikomiBeanList
						.size(  )];
					
					for ( int i = 0; i < mousikomiBeanList.size(  ); i++ ) {
						PCY_MousikomiJyokyoBean mousikomiBeanTemp = ( PCY_MousikomiJyokyoBean )mousikomiBeanList
							.get( i );
						taisyosyaBeans[i] = new PCY_TaisyosyaBean(  );
						taisyosyaBeans[i].setClassBean( mousikomiBeanTemp.getClassBean(  ) );
						taisyosyaBeans[i].setPersonalBean( mousikomiBeanTemp.getPersonalBean(  ) );
						taisyosyaBeans[i].setTaisyoKubun( "1" );
						
					}

					int taisyo_count = taisyo_ejb.doDeleteTaisyosya( taisyosyaBeans, loginuser );

					if ( taisyo_count != mousikomiBeanList.size(  ) ) {
						// CHG#P-ALC02-019-005-E
						throw new EJBException( "������ɁA�Ώێ҃e�[�u���̍폜�Ɏ��s���܂����B" );
					}
				}

				/* For Syanai-E */
			}

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			throw new EJBException( e );
		} catch ( RemoteException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
			throw new EJBException( e );
		} catch ( CreateException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

    /**
     * ���F�҂̎���NO���L�[�ɐ\����DB����\�������擾���APCY_MousikomiJyokyoBean �Ɋi�[���܂��B
     * �\�����̈ꗗ��Ԃ��܂��B
     *
     * @param userId ���F�҂̎���NO
     * @param kensaku_mousikomiJyokyoBean ��������
     * @param loginuser ���O�C�����[�U���
     * @return �\�����ꗗ
     * @throws NamingException ���O������O
     * @throws RemoteException �����[�g��O
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_MousikomiJyokyoBean[] getListWithSyoninsya( String userId,
        PCY_MousikomiJyokyoBean kensaku_mousikomiJyokyoBean, PCY_PersonalBean loginuser )
        throws NamingException, RemoteException {
        Connection con       = null;
        PreparedStatement ps = null;
        int kaisibiNum       = 3; // CHG#P-PLP02-014-001
        int syuryobiNum;
        int simeiNoNum;
        int statusNum;
        int kamokuCodeNum;

        try {
            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "SELECT " + PCY_KamokuBean.getColumns( "KAMOKU" ) + ", " );
            sql.append( PCY_ClassBean.getColumns( "CLASS" ) + ", " );
            sql.append( PCY_PersonalBean.getColumns( "PERSONAL" ) + ", " );
            sql.append( PCY_MousikomiJyokyoBean.getColumns( "JYOKYO" ) + ", " ); // CHG#P-PLP02-014-001
            sql.append( PCY_SyoninsyaBean.getColumns( "SYONINSYA" ) ); // INS#P-PLP02-014-001
            sql.append( " FROM " );
            sql.append( HcdbDef.L01_TBL );
            sql.append( " KAMOKU, " );
            sql.append( HcdbDef.L02_TBL );
            sql.append( " CLASS, " );
            sql.append( HcdbDef.L15_TBL );
            sql.append( " JYOKYO, " );
            sql.append( HcdbDef.L16_TBL );
            sql.append( " SYONINSYA, " );
            sql.append( HcdbDef.personalTbl );
            sql.append( " PERSONAL" );
            sql.append( " WHERE ( SYONINSYA.SYONINSYA1    = ?" ); // CHG#P-PLP02-014-001

            // INS#P-PLP02-014-001-S
            sql.append( "   OR  ( SYONINSYA.SYONINSYA2    = ?" );
            sql.append( "     AND SYONINSYA.DAIKOUSYA_FLG = '1' ) )" );

            // INS#P-PLP02-014-001-E
            sql.append( "   AND JYOKYO.SIMEI_NO    = SYONINSYA.SIMEI_NO" );
            sql.append( "   AND JYOKYO.SIMEI_NO    = PERSONAL.SIMEI_NO" );
            sql.append( "   AND JYOKYO.KAMOKU_CODE = CLASS.KAMOKU_CODE" );
            sql.append( "   AND CLASS.KAMOKU_CODE  = KAMOKU.KAMOKU_CODE" );
            sql.append( "   AND JYOKYO.CLASS_CODE  = CLASS.CLASS_CODE" );
            sql.append( "   AND PERSONAL.HONMU_FLG = '" + HcdbDef.HONMU + "'" );
            sql.append( "   AND CLASS.SYONIN_KUBUN = '1' " );

            if ( ( kensaku_mousikomiJyokyoBean.getClassBean(  ).getKaisibi(  ) != null )
                && !kensaku_mousikomiJyokyoBean.getClassBean(  ).getKaisibi(  ).trim(  ).equals( "" ) ) {
                sql.append( "   AND CLASS.SYURYOBI >= ? " );

                /* �J�n���ƏI���������͂���Ă���ꍇ */
                if ( ( kensaku_mousikomiJyokyoBean.getClassBean(  ).getSyuryobi(  ) != null )
                    && !kensaku_mousikomiJyokyoBean.getClassBean(  ).getSyuryobi(  ).trim(  )
                                                   .equals( "" ) ) {
                    sql.append( "   AND CLASS.KAISIBI <= ? " );
                    syuryobiNum = kaisibiNum + 1;

                    /* �J�n���̂ݓ��͂���Ă���ꍇ */
                } else {
                    syuryobiNum = kaisibiNum;
                }

                simeiNoNum = syuryobiNum + 1;
            } else {
                /* �I�����̂ݓ��͂���Ă���ꍇ */
                if ( ( kensaku_mousikomiJyokyoBean.getClassBean(  ).getSyuryobi(  ) != null )
                    && !kensaku_mousikomiJyokyoBean.getClassBean(  ).getSyuryobi(  ).trim(  )
                                                   .equals( "" ) ) {
                    sql.append( "   AND CLASS.KAISIBI <= ? " );
                    simeiNoNum = kaisibiNum + 1;

                    /* �J�n�����I���������͂���Ă��Ȃ��ꍇ */
                } else {
                    simeiNoNum = kaisibiNum;
                }

                syuryobiNum = kaisibiNum;
            }

            if ( ( kensaku_mousikomiJyokyoBean.getSimeiNo(  ) != null )
                && !kensaku_mousikomiJyokyoBean.getSimeiNo(  ).equals( "all" ) ) {
                sql.append( "   AND JYOKYO.SIMEI_NO    = ?" );
                statusNum = simeiNoNum + 1;
            } else {
                statusNum = simeiNoNum;
            }

            if ( ( kensaku_mousikomiJyokyoBean.getStatus(  ) != null )
                && !kensaku_mousikomiJyokyoBean.getStatus(  ).equals( "all" ) ) {
                if ( kensaku_mousikomiJyokyoBean.getStatus(  ).equals( "0" ) ) {
                    sql.append( "   AND JYOKYO.STATUS = ?" );
                } else {
                    sql.append( "   AND JYOKYO.STATUS >= ?" );
                }

                kamokuCodeNum = statusNum + 1;
            } else {
                kamokuCodeNum = statusNum;
            }

            if ( ( kensaku_mousikomiJyokyoBean.getKamokuCode(  ) != null )
                && !kensaku_mousikomiJyokyoBean.getKamokuCode(  ).equals( "all" ) ) {
                sql.append( "   AND KAMOKU.KAMOKU_CODE = ?" );
            }

            sql.append( "   ORDER BY JYOKYO.MOUSIKOMIBI , JYOKYO.MOUSIKOMIJIKOKU , JYOKYO.SIMEI_NO" ); // For Syanai

            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );
            ps      = con.prepareStatement( sql.toString(  ) );
            ps.setString( 1, userId );
            ps.setString( 2, userId ); // INS#P-PLP02-014-001

            /* �J�n�������͂���Ă���ꍇ */
            if ( ( kensaku_mousikomiJyokyoBean.getClassBean(  ).getKaisibi(  ) != null )
                && !kensaku_mousikomiJyokyoBean.getClassBean(  ).getKaisibi(  ).trim(  ).equals( "" ) ) {
                ps.setString( kaisibiNum,
                    kensaku_mousikomiJyokyoBean.getClassBean(  ).getKaisibi(  ) );

                /* �I���������͂���Ă���ꍇ */
                if ( ( kensaku_mousikomiJyokyoBean.getClassBean(  ).getSyuryobi(  ) != null )
                    && !kensaku_mousikomiJyokyoBean.getClassBean(  ).getSyuryobi(  ).trim(  )
                                                   .equals( "" ) ) {
                    ps.setString( syuryobiNum,
                        kensaku_mousikomiJyokyoBean.getClassBean(  ).getSyuryobi(  ) );
                }
            } else {
                /* �I�����̂ݓ��͂���Ă���ꍇ */
                if ( ( kensaku_mousikomiJyokyoBean.getClassBean(  ).getSyuryobi(  ) != null )
                    && !kensaku_mousikomiJyokyoBean.getClassBean(  ).getSyuryobi(  ).trim(  )
                                                   .equals( "" ) ) {
                    ps.setString( syuryobiNum,
                        kensaku_mousikomiJyokyoBean.getClassBean(  ).getSyuryobi(  ) );
                }
            }

            if ( ( kensaku_mousikomiJyokyoBean.getSimeiNo(  ) != null )
                && !kensaku_mousikomiJyokyoBean.getSimeiNo(  ).equals( "all" ) ) {
                ps.setString( simeiNoNum, kensaku_mousikomiJyokyoBean.getSimeiNo(  ) );
            }

            if ( ( kensaku_mousikomiJyokyoBean.getStatus(  ) != null )
                && !kensaku_mousikomiJyokyoBean.getStatus(  ).equals( "all" ) ) {
                ps.setString( statusNum, kensaku_mousikomiJyokyoBean.getStatus(  ) );
            }

            if ( ( kensaku_mousikomiJyokyoBean.getKamokuCode(  ) != null )
                && !kensaku_mousikomiJyokyoBean.getKamokuCode(  ).equals( "all" ) ) {
                ps.setString( kamokuCodeNum, kensaku_mousikomiJyokyoBean.getKamokuCode(  ) );
            }

            ResultSet rs = ps.executeQuery(  );

            Vector ret = new Vector(  );

            while ( rs.next(  ) ) {
                // INS#P-PLP02-014-001-S
                PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean( rs, "KAMOKU",
                        "CLASS", "PERSONAL", "JYOKYO" );
                mousikomiBean.setSyoninsyaBean( new PCY_SyoninsyaBean( rs, "SYONINSYA" ) );

                // INS#P-PLP02-014-001-E
                ret.add( mousikomiBean ); // CHG#P-PLP02-014-001
            }

            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ( PCY_MousikomiJyokyoBean[] )ret.toArray( new PCY_MousikomiJyokyoBean[0] );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * ���͂��ꂽ���ڂ��L�[�ɐ\����DB����\�������擾���APCY_MousikomiJyokyoBean �Ɋi�[���܂��B
     * �\�����̈ꗗ��Ԃ��܂��B
     *
     * @param mousikomiBean ��������
     * @param loginuser ���O�C�����[�U���
     * @return �\�����ꗗ
     * @throws NamingException ���O������O
     * @throws RemoteException �����[�g��O
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_MousikomiJyokyoBean[] getList( PCY_MousikomiJyokyoBean mousikomiBean,
        PCY_PersonalBean loginuser ) throws NamingException, RemoteException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "SELECT " );
            sql.append( PCY_MousikomiJyokyoBean.getColumns( "L15" ) );
            sql.append( " FROM " );
            sql.append( HcdbDef.L15_TBL );
            sql.append( " L15 " );

            // �\����DB���������̍쐬
            Map mousikomiConditions = mousikomiBean.extractConditions(  );

            if ( mousikomiConditions.size(  ) > 0 ) {
                int i = 1;
                sql.append( " WHERE" );

                for ( Iterator ite = mousikomiConditions.keySet(  ).iterator(  ); ite.hasNext(  );
                    i++ ) {
                    Object column = ite.next(  );
                    sql.append( " " + column.toString(  ) + "=?" );

                    if ( i < mousikomiConditions.size(  ) ) {
                        sql.append( " AND" );
                    }
                }
            }

            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );
            ps      = con.prepareStatement( sql.toString(  ) );

            int j   = 1;

            for ( Iterator ite = mousikomiConditions.keySet(  ).iterator(  ); ite.hasNext(  );
                j++ ) {
                Object key = ite.next(  );

                if ( key.equals( "SIMEI_NO" ) ) {
                    String new_simei_no = PZZ010_CharacterUtil.changeSimeiNoLength( ( String )mousikomiConditions
                            .get( key ) );
                    mousikomiConditions.put( key, new_simei_no );
                }

                Log.debug( Integer.toString( j ) + ":" + key + ":" + mousikomiConditions.get( key ) );
                ps.setObject( j, mousikomiConditions.get( key ) );
            }

            ResultSet rs = ps.executeQuery(  );

            ArrayList ret = new ArrayList(  );

            while ( rs.next(  ) ) {
                PCY_MousikomiJyokyoBean mousikomi = null;
                mousikomi = new PCY_MousikomiJyokyoBean( rs, "L15" );
                ret.add( mousikomi );
            }

            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ( PCY_MousikomiJyokyoBean[] )ret.toArray( new PCY_MousikomiJyokyoBean[0] );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }
	/**
	 * ���͂��ꂽ���ڂ��L�[�ɋ��猤�C����DB���狳�痚�����擾���APCY_KensyuRirekiBean �Ɋi�[���܂��B
	 * �\�����̈ꗗ��Ԃ��܂��B
	 *
	 * @param rirekiBean ��������
	 * @param loginuser ���O�C�����[�U���
	 * @return �\�����ꗗ
	 * @throws NamingException ���O������O
	 * @throws RemoteException �����[�g��O
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_KensyuRirekiBean[] getListL51( PCY_KensyuRirekiBean rirekiBean,
		PCY_PersonalBean loginuser ) throws NamingException, RemoteException {
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			StringBuffer sql = new StringBuffer(  );
			sql.append( "SELECT " );
			sql.append( PCY_KensyuRirekiBean.getColumns( null ) );
			sql.append( " FROM " );
			sql.append( HcdbDef.L51_TBL );
			sql.append( " L51 " );

			// ���C����DB���������̍쐬
			Map rirekiConditions = rirekiBean.extractConditions(  );

			if ( rirekiConditions.size(  ) > 0 ) {
				int i = 1;
				sql.append( " WHERE" );

				for ( Iterator ite = rirekiConditions.keySet(  ).iterator(  ); ite.hasNext(  );
					i++ ) {
					Object column = ite.next(  );
					sql.append( " " + column.toString(  ) + "=?" );

					if ( i < rirekiConditions.size(  ) ) {
						sql.append( " AND" );
					}
				}
			}

			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con     = locator.getDataSource(  ).getConnection(  );
			ps      = con.prepareStatement( sql.toString(  ) );

			int j   = 1;

			for ( Iterator ite = rirekiConditions.keySet(  ).iterator(  ); ite.hasNext(  );
				j++ ) {
				Object key = ite.next(  );

				if ( key.equals( "SIMEI_NO" ) ) {
					String new_simei_no = PZZ010_CharacterUtil.changeSimeiNoLength( ( String )rirekiConditions
							.get( key ) );
					rirekiConditions.put( key, new_simei_no );
				}

				Log.debug( Integer.toString( j ) + ":" + key + ":" + rirekiConditions.get( key ) );
				ps.setObject( j, rirekiConditions.get( key ) );
			}

			ResultSet rs = ps.executeQuery(  );

			ArrayList ret = new ArrayList(  );

			while ( rs.next(  ) ) {
				PCY_KensyuRirekiBean rireki = null;
				rireki = new PCY_KensyuRirekiBean( rs, null );
				ret.add( rireki );
			}

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return ( PCY_KensyuRirekiBean[] )ret.toArray( new PCY_KensyuRirekiBean[0] );
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

    /**
     * �ȖڃR�[�h�ƃN���X�R�[�h���L�[�ɐ\���󋵃e�[�u������\�������擾���APCY_KensyuKanriJohoBean�Ɋi�[���܂��B
     * �\�����̈ꗗ��Ԃ��܂��B
     *
     * @param kamokuCode �ȖڃR�[�h
     * @param classCode �N���X�R�[�h
     * @param simeiNo ����No
     * @param loginuser ���O�C�����[�U���
     * @return �\�����ꗗ
     * @throws NamingException ���O������O
     * @throws RemoteException �����[�g��O
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_KensyuKanriJohoBean[] getListWithClass( String kamokuCode, String classCode,
        String[] simeiNo, PCY_PersonalBean loginuser )
        throws NamingException, RemoteException {
        Connection con       = null;
        PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		PreparedStatement ps_sakujo = null;

        try {
            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            String sql = "SELECT " + PCY_MousikomiJyokyoBean.getColumns( "mousikomi" ) + ", "
                + PCY_PersonalBean.getColumns( "personal" ) + ", "
// ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j START
                + PCY_SyokuiBean.getColumns( "syokui" ) + ", "
// ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j END
                + PCY_TaisyosyokusyuBean.getColumns( "syokusyu" ) + ", "
                + PCY_TaisyososikiBean.getColumns( "sosiki" ) + ", "
                + PCY_TaisyosyaBean.getColumns( "taisyosya" ) + ", "
                + PCY_KensyuRirekiBean.getColumns("rireki") 
                + " FROM " + HcdbDef.L15_TBL
                + " mousikomi" + " INNER JOIN " + HcdbDef.personalTbl + " personal"
                + "   ON personal.SIMEI_NO = mousikomi.SIMEI_NO" + " LEFT OUTER JOIN "
                + HcdbDef.L12_TBL + " syokusyu"
                + "   ON  mousikomi.KAMOKU_CODE = syokusyu.KAMOKU_CODE"
                + "   AND mousikomi.CLASS_CODE  = syokusyu.CLASS_CODE"
                + "   AND personal.SYOKU_CODE1  = syokusyu.SYOKU_CODE"
                + "   AND personal.SENMON_CODE1 = syokusyu.SENMON_CODE"
                + "   AND personal.LEVEL_CODE1  = syokusyu.LEVEL_CODE" + " LEFT OUTER JOIN "
                + HcdbDef.L13_TBL + " sosiki" + "   ON  mousikomi.KAMOKU_CODE = sosiki.KAMOKU_CODE"
                + "   AND mousikomi.CLASS_CODE  = sosiki.CLASS_CODE"
                + "   AND trim(personal.SOSIKI_CODE)  = sosiki.SOSIKI_CODE" + " LEFT OUTER JOIN "
                + HcdbDef.L14_TBL + " taisyosya"
                + "   ON  mousikomi.KAMOKU_CODE = taisyosya.KAMOKU_CODE"
                + "   AND mousikomi.CLASS_CODE  = taisyosya.CLASS_CODE"
                + "   AND personal.SIMEI_NO     = taisyosya.SIMEI_NO" + " LEFT OUTER JOIN "
                + HcdbDef.L51_TBL + " rireki"
                + "   ON rireki.KAMOKU_CODE = mousikomi.KAMOKU_CODE "
                + "   AND rireki.CLASS_CODE = mousikomi.CLASS_CODE "
                + "   AND rireki.SIMEI_NO = mousikomi.SIMEI_NO" 
// ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j START
                + " LEFT OUTER JOIN "
                + HcdbDef.T31_SYOKUI_TBL + " syokui"
                + "   ON personal.SYOKUI_CODE = syokui.SYOKUI_CODE "
// ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j END
                + " WHERE personal.HONMU_FLG    = '" + HcdbDef.HONMU + "' ";

			if(kamokuCode != null){
				sql = sql + "   AND mousikomi.KAMOKU_CODE = ?";
			}
			
			if(classCode != null){
				sql = sql + "   AND mousikomi.CLASS_CODE = ?";
			}

            if ( ( simeiNo != null ) && ( simeiNo.length > 0 ) ) {
                StringBuffer inPhrase = new StringBuffer( " AND mousikomi.SIMEI_NO IN (" );

                for ( int i = 0; i < simeiNo.length; i++ ) {
                    if ( i != 0 ) {
                        inPhrase.append( ", " );
                    }

                    inPhrase.append( "?" );
                }

                inPhrase.append( ")" );
                sql += inPhrase.toString(  );
            }

				sql = sql + " ORDER BY mousikomi.syoninbi1 asc ,mousikomi.syoninjikoku1 asc ,mousikomi.mousikomibi asc";

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            // �������s
            Log.debug( sql );
            ps = con.prepareStatement( sql );

			int psCount = 1;
			if(kamokuCode != null){
				ps.setString( psCount, kamokuCode );
				psCount++;
			}
			if(classCode != null){
				ps.setString( psCount, classCode );
				psCount++;
			}
            
            if ( simeiNo != null ) {
                for ( int i = 0; i < simeiNo.length; i++ ) {
                    ps.setString( psCount , simeiNo[i]);
                    psCount++;
                }
            }

            ResultSet rs = ps.executeQuery(  );

            List taisyosyaList = new ArrayList(  );

            while ( rs.next(  ) ) {
                PCY_KensyuKanriJohoBean taisyosya = new PCY_KensyuKanriJohoBean(  );

                PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean( rs, "mousikomi" );
                
                
                mousikomiBean.setPersonalBean( new PCY_PersonalBean( rs, "personal" ) );

// ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j START
                mousikomiBean.setSyokuiBean( new PCY_SyokuiBean( rs, "syokui" ) );
// ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j END

                //�\�����̃X�e�[�^�X
				String st = mousikomiBean.getStatus();
				String uk = mousikomiBean.getUketsukeJyotai();
				
				//���猤�C�����̗��C����
				//���猤�C�����̏C������
				PCY_KensyuRirekiBean kensyuBean = new PCY_KensyuRirekiBean(rs, "rireki" );
				String syu = kensyuBean.getSyuryoHantei();
								
				if( st == null && uk == null && syu == null ){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("0");
				}else if(st.equals("0") && uk == null && syu == null ){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("1");
				}else if(st.equals("1") && uk.equals("0") && syu == null){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("2");					
				}else if(st.equals("1") && uk.equals("1") && syu == null){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("3");					
				}else if(st.equals("1") && uk.equals("2") && syu == null){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("4");
				}else if(st.equals("1") && uk.equals("3") && syu == null){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("5");
				}else if(st.equals("1") && uk.equals("4") && syu == null){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("6");
				}else if(st.equals("2") && uk == null && syu == null ){
					mousikomiBean.setJyukoJyokyo("1");
					mousikomiBean.setMousikomijyokyo("");
				}else if(st.equals("3") && uk == null && syu == null ){
					mousikomiBean.setJyukoJyokyo("2");
					mousikomiBean.setMousikomijyokyo("");
				}else if(st == null && uk == null && syu.equals("0")){
					mousikomiBean.setJyukoJyokyo("3");
					mousikomiBean.setMousikomijyokyo("");
				}else if(st == null && uk == null && syu.equals("1") ){
					mousikomiBean.setJyukoJyokyo("4");
					mousikomiBean.setMousikomijyokyo("");
				}else{
					mousikomiBean.setJyukoJyokyo("");
					mousikomiBean.setMousikomijyokyo("");
				}
                taisyosya.setMousikomiBean( mousikomiBean );
                
                taisyosya.getTaisyousyaBean(  ).setTaisyoKubun( PCY_TaisyoBeanImpl.getTaisyoKubun( 
                        rs.getString( "syokusyu_taisyo_kubun" ),
                        rs.getString( "sosiki_taisyo_kubun" ),
                        rs.getString( "taisyosya_taisyo_kubun" ) ) );


				
                taisyosyaList.add( taisyosya );
            }

//          DEL#BPX-0301J-0475

			/*���C���E�C������������*/
			
			StringBuffer sql1 = new StringBuffer(  );
			sql1.append( "SELECT ");
			sql1.append(PCY_KensyuRirekiBean.getColumns( "rireki" ) + ",");
			sql1.append( PCY_PersonalBean.getColumns( "personal" ) + ", " );
// ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j START
            sql1.append(PCY_SyokuiBean.getColumns( "syokui" ) + ", ");
// ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j END
			sql1.append(PCY_TaisyosyokusyuBean.getColumns( "syokusyu" ) + ", ");
			sql1.append(PCY_TaisyososikiBean.getColumns( "sosiki" ) + ", ");
			sql1.append(PCY_TaisyosyaBean.getColumns( "taisyosya" ) );
			sql1.append(" FROM ");
			sql1.append( HcdbDef.L51_TBL + " rireki "); 
			sql1.append(" INNER JOIN " + HcdbDef.personalTbl + " personal");
			sql1.append("   ON personal.SIMEI_NO = rireki.SIMEI_NO" + " LEFT OUTER JOIN ");
			sql1.append(HcdbDef.L12_TBL + " syokusyu");
			sql1.append("   ON  rireki.KAMOKU_CODE = syokusyu.KAMOKU_CODE");
			sql1.append("   AND rireki.CLASS_CODE  = syokusyu.CLASS_CODE");
			sql1.append("   AND personal.SYOKU_CODE1  = syokusyu.SYOKU_CODE");
			sql1.append("   AND personal.SENMON_CODE1 = syokusyu.SENMON_CODE");
			sql1.append("   AND personal.LEVEL_CODE1  = syokusyu.LEVEL_CODE" + " LEFT OUTER JOIN ");
			sql1.append(HcdbDef.L13_TBL + " sosiki" + "   ON  rireki.KAMOKU_CODE = sosiki.KAMOKU_CODE");
			sql1.append("   AND rireki.CLASS_CODE  = sosiki.CLASS_CODE");
			sql1.append("   AND trim(personal.SOSIKI_CODE)  = sosiki.SOSIKI_CODE" + " LEFT OUTER JOIN ");
			sql1.append(HcdbDef.L14_TBL + " taisyosya");
			sql1.append("   ON  rireki.KAMOKU_CODE = taisyosya.KAMOKU_CODE");
			sql1.append("   AND rireki.CLASS_CODE  = taisyosya.CLASS_CODE");
			sql1.append("   AND personal.SIMEI_NO     = taisyosya.SIMEI_NO" );
// ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j START
            sql1.append(" LEFT OUTER JOIN ");
            sql1.append(HcdbDef.T31_SYOKUI_TBL + " syokui");
            sql1.append("   ON personal.SYOKUI_CODE = syokui.SYOKUI_CODE ");
//ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j END
			sql1.append("   WHERE personal.HONMU_FLG    = '" + HcdbDef.HONMU + "' " ) ;
			sql1.append( "      AND ( rireki.SYURYO_HANTEI='0' OR rireki.SYURYO_HANTEI='1' ) " );

			if(kamokuCode != null){
				sql1.append( "  AND rireki.KAMOKU_CODE=?" );
			}
			
			if(classCode != null){
				sql1.append( "  AND rireki.CLASS_CODE=?" );
			}
			
			if ( ( simeiNo != null ) && ( simeiNo.length > 0 ) ) {
				StringBuffer inPhrase = new StringBuffer( " AND rireki.SIMEI_NO IN (" );

				for ( int i = 0; i < simeiNo.length; i++ ) {
					if ( i != 0 ) {
						inPhrase.append( ", " );
					}

					inPhrase.append( "?" );
				}

				inPhrase.append( ")" );
				sql1.append(inPhrase.toString(  ));
			}
			
			Log.debug(sql1.toString());
			
			//�R�l�N�V�����̎擾
			ps1      = con.prepareStatement( sql1.toString(  ) );

			int ps1Count = 1;
			if(kamokuCode != null){
				ps1.setString( ps1Count, kamokuCode);
				ps1Count++;
			}
			if(classCode != null){
				ps1.setString( ps1Count,classCode);
				ps1Count++;
			}
            
			if ( simeiNo != null ) {
				for ( int i = 0; i < simeiNo.length; i++ ) {
					ps1.setString( ps1Count , simeiNo[i]);
					ps1Count++;
				}
			}
						
			ResultSet rs1 = ps1.executeQuery(  );

			while ( rs1.next(  ) ) {
				PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean();
				mousikomiBean.setPersonalBean( new PCY_PersonalBean( rs1, "personal" ) );				
				
// ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j START
                mousikomiBean.setSyokuiBean( new PCY_SyokuiBean( rs1, "syokui" ) );
// ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j END
				
				PCY_KensyuKanriJohoBean taisyosya1 = new PCY_KensyuKanriJohoBean(  );
				taisyosya1.setKensyurirekiBean(new PCY_KensyuRirekiBean( rs1, "rireki" ));
				taisyosya1.setMousikomiBean(mousikomiBean);
				taisyosya1.getTaisyousyaBean(  ).setTaisyoKubun( PCY_TaisyoBeanImpl.getTaisyoKubun( 
										rs1.getString( "syokusyu_taisyo_kubun" ),
										rs1.getString( "sosiki_taisyo_kubun" ),
										rs1.getString( "taisyosya_taisyo_kubun" ) ) );
										
				taisyosyaList.add( taisyosya1 );
			}

            PCY_KensyuKanriJohoBean[] ret = new PCY_KensyuKanriJohoBean[taisyosyaList.size(  )];
            
            ret = ( PCY_KensyuKanriJohoBean[] )taisyosyaList.toArray( ret );
            
            /*�\���󋵂Ń\�[�g����*/
			Arrays.sort( ret, new MousikomiJokyoComparator(  ) );

            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ret;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
			if ( ps1 != null ) {
				try {
					ps1.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
			if ( ps_sakujo != null ) {
				try {
					ps1.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				
				}
			}
			
            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

	/**
	 * �ȖڃR�[�h�ƃN���X�R�[�h�Ǝ�u�󋵂��L�[�ɐ\���󋵃e�[�u������\�������擾���APCY_KensyuKanriJohoBean�Ɋi�[���܂��B
	 * �\�����̈ꗗ��Ԃ��܂��B
	 *
	 * @param kamokuCode �ȖڃR�[�h
	 * @param classCode �N���X�R�[�h
	 * @param kensaku_class ��u�󋵂��������N���XBean
	 * @param simeiNo ����No
	 * @param loginuser ���O�C�����[�U���
	 * @return �\�����ꗗ
	 * @throws NamingException ���O������O
	 * @throws RemoteException �����[�g��O
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_KensyuKanriJohoBean[] getListWithClassL15( String kamokuCode, String classCode,PCY_ClassBean kensaku_class,
		 String[] simeiNo, PCY_PersonalBean loginuser )
		throws NamingException, RemoteException {
		Connection con       = null;
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		PreparedStatement ps_sakujo = null;

		try {
			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			String sql = "SELECT " + PCY_MousikomiJyokyoBean.getColumns( "mousikomi" ) + ", "
				+ PCY_PersonalBean.getColumns( "personal" ) + ", "
				+ PCY_TaisyosyokusyuBean.getColumns( "syokusyu" ) + ", "
				+ PCY_TaisyososikiBean.getColumns( "sosiki" ) + ", "
				+ PCY_TaisyosyaBean.getColumns( "taisyosya" ) + ", "
				+ PCY_KensyuRirekiBean.getColumns("rireki") 
				+ " FROM " + HcdbDef.L15_TBL
				+ " mousikomi" + " INNER JOIN " + HcdbDef.personalTbl + " personal"
				+ "   ON personal.SIMEI_NO = mousikomi.SIMEI_NO" + " LEFT OUTER JOIN "
				+ HcdbDef.L12_TBL + " syokusyu"
				+ "   ON  mousikomi.KAMOKU_CODE = syokusyu.KAMOKU_CODE"
				+ "   AND mousikomi.CLASS_CODE  = syokusyu.CLASS_CODE"
				+ "   AND personal.SYOKU_CODE1  = syokusyu.SYOKU_CODE"
				+ "   AND personal.SENMON_CODE1 = syokusyu.SENMON_CODE"
				+ "   AND personal.LEVEL_CODE1  = syokusyu.LEVEL_CODE" + " LEFT OUTER JOIN "
				+ HcdbDef.L13_TBL + " sosiki" + "   ON  mousikomi.KAMOKU_CODE = sosiki.KAMOKU_CODE"
				+ "   AND mousikomi.CLASS_CODE  = sosiki.CLASS_CODE"
				+ "   AND trim(personal.SOSIKI_CODE)  = sosiki.SOSIKI_CODE" + " LEFT OUTER JOIN "
				+ HcdbDef.L14_TBL + " taisyosya"
				+ "   ON  mousikomi.KAMOKU_CODE = taisyosya.KAMOKU_CODE"
				+ "   AND mousikomi.CLASS_CODE  = taisyosya.CLASS_CODE"
				+ "   AND personal.SIMEI_NO     = taisyosya.SIMEI_NO" + " LEFT OUTER JOIN "
				+ HcdbDef.L51_TBL + " rireki"
				+ "   ON rireki.KAMOKU_CODE = mousikomi.KAMOKU_CODE "
				+ "   AND rireki.CLASS_CODE = mousikomi.CLASS_CODE "
				+ "   AND rireki.SIMEI_NO = mousikomi.SIMEI_NO" 
				+ " WHERE personal.HONMU_FLG    = '" + HcdbDef.HONMU + "' ";

				if(kamokuCode != null){
					sql = sql +  "  AND mousikomi.KAMOKU_CODE=?" ;
				}
			
				if(classCode != null){
					sql = sql +  "  AND mousikomi.CLASS_CODE=?" ;
				}
			
				if ( ( simeiNo != null ) && ( simeiNo.length > 0 ) ) {
					StringBuffer inPhrase = new StringBuffer( " AND mousikomi.SIMEI_NO IN (" );

					for ( int i = 0; i < simeiNo.length; i++ ) {
						if ( i != 0 ) {
							inPhrase.append( ", " );
						}

						inPhrase.append( "?" );
					}

					inPhrase.append( ")" );
					sql = sql + inPhrase.toString(  );	
				}
				
				if(kensaku_class.getJyukoJyokyo() != null && kensaku_class.getJyukoJyokyo().equals("0")){
					sql = sql + "   AND ( mousikomi.status != ? AND mousikomi.status != ? ) ";
				}else if((kensaku_class.getMousikomiJyokyo() != null && kensaku_class.getMousikomiJyokyo().equals("1"))
				            || (kensaku_class.getJyukoJyokyo() != null && kensaku_class.getJyukoJyokyo().equals("1"))
				            || (kensaku_class.getJyukoJyokyo() != null && kensaku_class.getJyukoJyokyo().equals("2"))){
					sql = sql + "   AND mousikomi.status = ? AND mousikomi.uketsuke_jyotai is null";
				}else{
					sql = sql + "   AND mousikomi.status = ? AND mousikomi.uketsuke_jyotai = ?";
				}
				

				sql = sql + " ORDER BY mousikomi.syoninbi1 asc ,mousikomi.syoninjikoku1 desc ,mousikomi.mousikomibi asc";

			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con = locator.getDataSource(  ).getConnection(  );

			// �������s
			Log.debug( sql );
			ps = con.prepareStatement( sql );

			int psCount = 1;
			if(kamokuCode != null){
				ps.setString( psCount, kamokuCode);
				psCount++;
			}
			if(classCode != null){
				ps.setString( psCount,classCode);
				psCount++;
			}
            
			if ( simeiNo != null ) {
				for ( int i = 0; i < simeiNo.length; i++ ) {
					ps.setString( psCount , simeiNo[i]);
					psCount++;
				}
			}
			
			if(kensaku_class.getMousikomiJyokyo() != null && kensaku_class.getMousikomiJyokyo().equals("1")){
				ps.setString(psCount,"0");
				psCount++;
			}else if( kensaku_class.getMousikomiJyokyo() != null && kensaku_class.getMousikomiJyokyo().equals("2")){
				ps.setString(psCount,"1");
				psCount++;
				ps.setString(psCount,"0");
				psCount++;
			}else if( kensaku_class.getMousikomiJyokyo() != null && kensaku_class.getMousikomiJyokyo().equals("3")){	
				ps.setString(psCount,"1");
				psCount++;
				ps.setString(psCount,"1");
				psCount++;
			}else if( kensaku_class.getMousikomiJyokyo() != null && kensaku_class.getMousikomiJyokyo().equals("4")){
				ps.setString(psCount,"1");
				psCount++;
				ps.setString(psCount,"2");
				psCount++;
			}else if( kensaku_class.getMousikomiJyokyo() != null && kensaku_class.getMousikomiJyokyo().equals("5")){
				ps.setString(psCount,"1");
				psCount++;
				ps.setString(psCount,"3");
				psCount++;
			}else if( kensaku_class.getMousikomiJyokyo() != null && kensaku_class.getMousikomiJyokyo().equals("6")){
				ps.setString(psCount,"1");
				psCount++;
				ps.setString(psCount,"4");
				psCount++;
			}else if( kensaku_class.getJyukoJyokyo() != null && kensaku_class.getJyukoJyokyo().equals("0")){
				ps.setString(psCount,"2");
				psCount++;
				ps.setString(psCount,"3");
				psCount++;
			}else if( kensaku_class.getJyukoJyokyo() != null && kensaku_class.getJyukoJyokyo().equals("1")){
				ps.setString(psCount,"2");
				psCount++;
			}else if( kensaku_class.getJyukoJyokyo() != null && kensaku_class.getJyukoJyokyo().equals("2")){
				ps.setString(psCount,"3");
				psCount++;
			}
			
			ResultSet rs = ps.executeQuery(  );

			List taisyosyaList = new ArrayList(  );

			while ( rs.next(  ) ) {
				PCY_KensyuKanriJohoBean taisyosya = new PCY_KensyuKanriJohoBean(  );

				PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean( rs, "mousikomi" );
                
				
				mousikomiBean.setPersonalBean( new PCY_PersonalBean( rs, "personal" ) );

				//�\�����̃X�e�[�^�X
				String st = mousikomiBean.getStatus();
				String uk = mousikomiBean.getUketsukeJyotai();
				
				//���猤�C�����̗��C����
				//���猤�C�����̏C������
				PCY_KensyuRirekiBean kensyuBean = new PCY_KensyuRirekiBean(rs, "rireki" );
				String syu = kensyuBean.getSyuryoHantei();
								
				if( st == null && uk == null && syu == null ){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("0");
				}else if(st.equals("0") && uk == null && syu == null ){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("1");
				}else if(st.equals("1") && uk.equals("0") && syu == null){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("2");					
				}else if(st.equals("1") && uk.equals("1") && syu == null){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("3");					
				}else if(st.equals("1") && uk.equals("2") && syu == null){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("4");
				}else if(st.equals("1") && uk.equals("3") && syu == null){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("5");
				}else if(st.equals("1") && uk.equals("4") && syu == null){
					mousikomiBean.setJyukoJyokyo("0");
					mousikomiBean.setMousikomijyokyo("6");
				}else if(st.equals("2") && uk == null && syu == null ){
					mousikomiBean.setJyukoJyokyo("1");
					mousikomiBean.setMousikomijyokyo("");
				}else if(st.equals("3") && uk == null && syu == null ){
					mousikomiBean.setJyukoJyokyo("2");
					mousikomiBean.setMousikomijyokyo("");
				}else if(st == null && uk == null && syu.equals("0")){
					mousikomiBean.setJyukoJyokyo("3");
					mousikomiBean.setMousikomijyokyo("");
				}else if(st == null && uk == null && syu.equals("1") ){
					mousikomiBean.setJyukoJyokyo("4");
					mousikomiBean.setMousikomijyokyo("");
				}else{
					mousikomiBean.setJyukoJyokyo("");
					mousikomiBean.setMousikomijyokyo("");
				}
				taisyosya.setMousikomiBean( mousikomiBean );
                
				taisyosya.getTaisyousyaBean(  ).setTaisyoKubun( PCY_TaisyoBeanImpl.getTaisyoKubun( 
						rs.getString( "syokusyu_taisyo_kubun" ),
						rs.getString( "sosiki_taisyo_kubun" ),
						rs.getString( "taisyosya_taisyo_kubun" ) ) );


				
				taisyosyaList.add( taisyosya );
			}

			PCY_KensyuKanriJohoBean[] ret = new PCY_KensyuKanriJohoBean[taisyosyaList.size(  )];
            
			ret = ( PCY_KensyuKanriJohoBean[] )taisyosyaList.toArray( ret );
            
			/*�\���󋵂Ń\�[�g����*/
			Arrays.sort( ret, new MousikomiJokyoComparator(  ) );

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return ret;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}			
			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * �ȖڃR�[�h�ƃN���X�R�[�h�Ǝ�u�󋵂��L�[�ɋ��猤�C�����e�[�u�����痚�������擾���APCY_KensyuKanriJohoBean�Ɋi�[���܂��B
	 * �\�����̈ꗗ��Ԃ��܂��B
	 *
	 * @param kamokuCode �ȖڃR�[�h
	 * @param classCode �N���X�R�[�h
	 * @param kensaku_class ��u�󋵂��������N���XBean
	 * @param simeiNo ����No
	 * @param loginuser ���O�C�����[�U���
	 * @return �\�����ꗗ
	 * @throws NamingException ���O������O
	 * @throws RemoteException �����[�g��O
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_KensyuKanriJohoBean[] getListWithClassL51( String kamokuCode, String classCode,PCY_ClassBean kensaku_class,
		 String[] simeiNo, PCY_PersonalBean loginuser )
		throws NamingException, RemoteException {
		Connection con       = null;
		PreparedStatement ps = null;
		

		try {
			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			StringBuffer sql1 = new StringBuffer(  );
			sql1.append( "SELECT ");
			sql1.append(PCY_KensyuRirekiBean.getColumns( "rireki" ) + ",");
			sql1.append( PCY_PersonalBean.getColumns( "personal" ) + ", " );
			sql1.append(PCY_TaisyosyokusyuBean.getColumns( "syokusyu" ) + ", ");
			sql1.append(PCY_TaisyososikiBean.getColumns( "sosiki" ) + ", ");
			sql1.append(PCY_TaisyosyaBean.getColumns( "taisyosya" ) );
			sql1.append(" FROM ");
			sql1.append( HcdbDef.L51_TBL + " rireki "); 
			sql1.append(" INNER JOIN " + HcdbDef.personalTbl + " personal");
			sql1.append("   ON personal.SIMEI_NO = rireki.SIMEI_NO" + " LEFT OUTER JOIN ");
			sql1.append(HcdbDef.L12_TBL + " syokusyu");
			sql1.append("   ON  rireki.KAMOKU_CODE = syokusyu.KAMOKU_CODE");
			sql1.append("   AND rireki.CLASS_CODE  = syokusyu.CLASS_CODE");
			sql1.append("   AND personal.SYOKU_CODE1  = syokusyu.SYOKU_CODE");
			sql1.append("   AND personal.SENMON_CODE1 = syokusyu.SENMON_CODE");
			sql1.append("   AND personal.LEVEL_CODE1  = syokusyu.LEVEL_CODE" + " LEFT OUTER JOIN ");
			sql1.append(HcdbDef.L13_TBL + " sosiki" + "   ON  rireki.KAMOKU_CODE = sosiki.KAMOKU_CODE");
			sql1.append("   AND rireki.CLASS_CODE  = sosiki.CLASS_CODE");
			sql1.append("   AND trim(personal.SOSIKI_CODE)  = sosiki.SOSIKI_CODE" + " LEFT OUTER JOIN ");
			sql1.append(HcdbDef.L14_TBL + " taisyosya");
			sql1.append("   ON  rireki.KAMOKU_CODE = taisyosya.KAMOKU_CODE");
			sql1.append("   AND rireki.CLASS_CODE  = taisyosya.CLASS_CODE");
			sql1.append("   AND personal.SIMEI_NO     = taisyosya.SIMEI_NO" );
			sql1.append("   WHERE personal.HONMU_FLG    = '" + HcdbDef.HONMU + "' " ) ;

			if(kamokuCode != null){
				sql1.append("  AND rireki.KAMOKU_CODE=?" );
			}
			
			if(classCode != null){
				sql1.append("  AND rireki.CLASS_CODE=?" );
			}
			
			if ( ( simeiNo != null ) && ( simeiNo.length > 0 ) ) {
				StringBuffer inPhrase = new StringBuffer( " AND rireki.SIMEI_NO IN (" );

				for ( int i = 0; i < simeiNo.length; i++ ) {
					if ( i != 0 ) {
						inPhrase.append( ", " );
					}

					inPhrase.append( "?" );
				}

				inPhrase.append( ")" );
				sql1.append(inPhrase.toString(  ));	
			}

			sql1.append( "      AND  rireki.SYURYO_HANTEI=?  " );

			Log.debug(sql1.toString());
			
			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );			
			con = locator.getDataSource(  ).getConnection(  );
			ps      = con.prepareStatement( sql1.toString(  ) );

			int psCount = 1;
			if(kamokuCode != null){
				ps.setString( psCount, kamokuCode);
				psCount++;
			}
			if(classCode != null){
				ps.setString( psCount,classCode);
				psCount++;
			}
            
			if ( simeiNo != null ) {
				for ( int i = 0; i < simeiNo.length; i++ ) {
					ps.setString( psCount , simeiNo[i]);
					psCount++;
				}
			}
			
			if(kensaku_class.getJyukoJyokyo().equals("3")){
				ps.setString( psCount,"0");
				psCount++;
			}else if (kensaku_class.getJyukoJyokyo().equals("4")){
				ps.setString( psCount,"1");
				psCount++;
			}else if(kensaku_class.getJyukoJyokyo().equals("5")){
				ps.setString( psCount,"2");
				psCount++;
			}

			ResultSet rs = ps.executeQuery(  );
			List taisyosyaList = new ArrayList(  );

			while ( rs.next(  ) ) {
				PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean();
				mousikomiBean.setPersonalBean( new PCY_PersonalBean( rs, "personal" ) );				
				
				
				PCY_KensyuKanriJohoBean taisyosya1 = new PCY_KensyuKanriJohoBean(  );
				taisyosya1.setKensyurirekiBean(new PCY_KensyuRirekiBean( rs, "rireki" ));
				taisyosya1.setMousikomiBean(mousikomiBean);
				taisyosya1.getTaisyousyaBean(  ).setTaisyoKubun( PCY_TaisyoBeanImpl.getTaisyoKubun( 
										rs.getString( "syokusyu_taisyo_kubun" ),
										rs.getString( "sosiki_taisyo_kubun" ),
										rs.getString( "taisyosya_taisyo_kubun" ) ) );
										
				taisyosyaList.add( taisyosya1 );
			}

			PCY_KensyuKanriJohoBean[] ret = new PCY_KensyuKanriJohoBean[taisyosyaList.size(  )];
            
			ret = ( PCY_KensyuKanriJohoBean[] )taisyosyaList.toArray( ret );

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return ret;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}			
			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * �ȖڃR�[�h�ƃN���X�R�[�h�Ǝ�u�󋵂��L�[�ɐ\���폜�����e�[�u�����痚�������擾���APCY_KensyuKanriJohoBean�Ɋi�[���܂��B
	 * �\�����̈ꗗ��Ԃ��܂��B
	 *
	 * @param kamokuCode �ȖڃR�[�h
	 * @param classCode �N���X�R�[�h
	 * @param kensaku_class ��u�󋵂��������N���XBean
	 * @param simeiNo ����No
	 * @param loginuser ���O�C�����[�U���
	 * @return �\�����ꗗ
	 * @throws NamingException ���O������O
	 * @throws RemoteException �����[�g��O
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_KensyuKanriJohoBean[] getListWithClassL94( String kamokuCode, String classCode,PCY_ClassBean kensaku_class,
		 String[] simeiNo, PCY_PersonalBean loginuser )
		throws NamingException, RemoteException {
		Connection con       = null;
		PreparedStatement ps = null;
		

		try {
			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			StringBuffer sql_sakujo = new StringBuffer(  );
			sql_sakujo.append( "SELECT ");
			sql_sakujo.append(PCY_MousikomiSakujoRirekiBean.getColumns( "rireki" ) + ",");
			sql_sakujo.append( PCY_PersonalBean.getColumns( "personal" ) );
			sql_sakujo.append(" FROM ");
			sql_sakujo.append( HcdbDef.L94_TBL + " rireki ,"); 
			sql_sakujo.append( HcdbDef.personalTbl + " personal");
			sql_sakujo.append("   WHERE personal.SIMEI_NO = rireki.SIMEI_NO ");
			sql_sakujo.append("   AND personal.HONMU_FLG    = '" + HcdbDef.HONMU + "' " ) ;

			if(kamokuCode != null){
				sql_sakujo.append("  AND rireki.KAMOKU_CODE=?" );
			}
			
			if(classCode != null){
				sql_sakujo.append("  AND rireki.CLASS_CODE=?" );
			}
			
			if ( ( simeiNo != null ) && ( simeiNo.length > 0 ) ) {
				StringBuffer inPhrase = new StringBuffer( " AND rireki.SIMEI_NO IN (" );

				for ( int i = 0; i < simeiNo.length; i++ ) {
					if ( i != 0 ) {
						inPhrase.append( ", " );
					}

					inPhrase.append( "?" );
				}

				inPhrase.append( ")" );
				sql_sakujo.append(inPhrase.toString(  ));	
			}

			
			Log.debug(sql_sakujo.toString());
			
			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );	
			con = locator.getDataSource(  ).getConnection(  );					
			ps      = con.prepareStatement( sql_sakujo.toString(  ) );

			int psCount = 1;
			if(kamokuCode != null){
				ps.setString( psCount, kamokuCode);
				psCount++;
			}
			if(classCode != null){
				ps.setString( psCount,classCode);
				psCount++;
			}
            
			if ( simeiNo != null ) {
				for ( int i = 0; i < simeiNo.length; i++ ) {
					ps.setString( psCount , simeiNo[i]);
					psCount++;
				}
			}
			
			ResultSet rs_sakujo = ps.executeQuery(  );
			List taisyosyaList = new ArrayList(  );

			while ( rs_sakujo.next(  ) ) {
				PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean();
				mousikomiBean.setPersonalBean( new PCY_PersonalBean( rs_sakujo, "personal" ) );
				mousikomiBean.setMousikomijyokyo("7");
				
				PCY_MousikomiSakujoRirekiBean sakujoBean = new PCY_MousikomiSakujoRirekiBean( rs_sakujo, "rireki" );
				
				PCY_KensyuKanriJohoBean taisyosya_sakujo = new PCY_KensyuKanriJohoBean(  );
				taisyosya_sakujo.setSakujoRirekiBean(sakujoBean);
				taisyosya_sakujo.setMousikomiBean(mousikomiBean);
										
				taisyosyaList.add( taisyosya_sakujo );
			}
			
			PCY_KensyuKanriJohoBean[] ret = new PCY_KensyuKanriJohoBean[taisyosyaList.size(  )];
            
			ret = ( PCY_KensyuKanriJohoBean[] )taisyosyaList.toArray( ret );

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return ret;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}			
			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * �ȖڃR�[�h�ƃN���X�R�[�h���L�[�ɐ\���󋵃e�[�u������\�������擾���APCY_KensyuKanriJohoBean�Ɋi�[���܂��B
	 * �\�����̈ꗗ��Ԃ��܂��B
	 *
	 * @param kamokuCode �ȖڃR�[�h
	 * @param classCode �N���X�R�[�h
	 * @param simeiNo ����No
	 * @param loginuser ���O�C�����[�U���
	 * @return �\�����ꗗ
	 * @throws NamingException ���O������O
	 * @throws RemoteException �����[�g��O
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_KensyuKanriJohoBean[] getStatusListWithClass( String kamokuCode, String classCode,
		 PCY_PersonalBean loginuser )
		throws NamingException, RemoteException {
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			String sql = "SELECT " + PCY_MousikomiJyokyoBean.getStausColumns( "mousikomi" )  
				+ " FROM " + HcdbDef.L15_TBL
				+ " mousikomi" + " INNER JOIN " + HcdbDef.personalTbl + " personal"
				+ "   ON personal.SIMEI_NO = mousikomi.SIMEI_NO" + " LEFT OUTER JOIN "
				+ HcdbDef.L12_TBL + " syokusyu"
				+ "   ON  mousikomi.KAMOKU_CODE = syokusyu.KAMOKU_CODE"
				+ "   AND mousikomi.CLASS_CODE  = syokusyu.CLASS_CODE"
				+ "   AND personal.SYOKU_CODE1  = syokusyu.SYOKU_CODE"
				+ "   AND personal.SENMON_CODE1 = syokusyu.SENMON_CODE"
				+ "   AND personal.LEVEL_CODE1  = syokusyu.LEVEL_CODE" + " LEFT OUTER JOIN "
				+ HcdbDef.L13_TBL + " sosiki" + "   ON  mousikomi.KAMOKU_CODE = sosiki.KAMOKU_CODE"
				+ "   AND mousikomi.CLASS_CODE  = sosiki.CLASS_CODE"
				+ "   AND personal.SOSIKI_CODE  = sosiki.SOSIKI_CODE" + " LEFT OUTER JOIN "
				+ HcdbDef.L14_TBL + " taisyosya"
				+ "   ON  mousikomi.KAMOKU_CODE = taisyosya.KAMOKU_CODE"
				+ "   AND mousikomi.CLASS_CODE  = taisyosya.CLASS_CODE"
				+ "   AND personal.SIMEI_NO     = taisyosya.SIMEI_NO"
				+ " WHERE personal.HONMU_FLG    = '" + HcdbDef.HONMU + "' "
				+ "   AND mousikomi.KAMOKU_CODE = ? AND mousikomi.CLASS_CODE = ?";

			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con = locator.getDataSource(  ).getConnection(  );

			// �������s
			Log.debug( sql );
			ps = con.prepareStatement( sql );
			ps.setString( 1, kamokuCode );
			ps.setString( 2, classCode );

			ResultSet rs = ps.executeQuery(  );

			List taisyosyaList = new ArrayList(  );

			while ( rs.next(  ) ) {
				PCY_KensyuKanriJohoBean taisyosya = new PCY_KensyuKanriJohoBean(  );

				PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean();
				mousikomiBean.setStatus( rs, "mousikomi" );

				taisyosya.setMousikomiBean( mousikomiBean );
				taisyosyaList.add( taisyosya );
			}

			PCY_KensyuKanriJohoBean[] ret = new PCY_KensyuKanriJohoBean[taisyosyaList.size(  )];
			ret = ( PCY_KensyuKanriJohoBean[] )taisyosyaList.toArray( ret );

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return ret;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

    /**
     * �\����DB�ɐ\�������i�[���܂��B
     *
     * @param mousikomi �\����ValueBean
     * @param loginuser ���O�C�����[�U���
     * @return DB�ɃC���T�[�g��������
     * @throws PCY_WarningException PK���d�������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doInsert( PCY_MousikomiJyokyoBean mousikomi, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

            //�Y���ȖځA�N���X���X�V����Ă��Ȃ����`�F�b�N����(���b�N�t��)
            //JNDI���̃��b�N�A�b�v
            PCY_ClassEJBHome home2 = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
                    PCY_ClassEJBHome.class );

            //EJBObject�̎擾
            PCY_ClassEJB ejb2         = home2.create(  );
            PCY_ClassBean[] classList = ejb2.doSelect( mousikomi.getClassBean(  ), true, loginuser );

            //�������ʂ����݂��Ȃ�������Warning
            if ( classList.length < 1 ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            /* ����PK�̃��R�[�h�����݂��Ȃ����`�F�b�N���� */
            PCY_MousikomiJyokyoBean[] mousikomiBean = this.getList( mousikomi, loginuser );

            if ( mousikomiBean.length > 0 ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            /* INSERT���� */
            con = locator.getDataSource(  ).getConnection(  );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "INSERT INTO " );
            sql.append( HcdbDef.L15_TBL );
            sql.append( " ( " );
            sql.append( "KAMOKU_CODE, " );
            sql.append( "CLASS_CODE, " );
            sql.append( "SIMEI_NO, " );
            sql.append( "STATUS, " );

            /* For SAS-S */
            sql.append( "UKETSUKE_JYOTAI, " );

            /* For SAS-E */
            sql.append( "JYUKOUBI, " );
            sql.append( "REPORT_FILENAME, " );
            sql.append( "REPORT_CONTENT_TYPE, " );
            sql.append( "HOUKOKU, " );
            sql.append( "TENSU, " );

            /* For SAS-S */
            sql.append( "SYUSSEKI_NISSUU, " );

            /* For SAS-E */
            sql.append( "SEISEKI, " );
            sql.append( "SYURYO_HANTEI, " );
            sql.append( "MOUSIKOMIBI, " );
            sql.append( "MOUSIKOMIJIKOKU, " );
            sql.append( "MOUSIKOMISYA, " );
            sql.append( "SYONINBI1, " );
            sql.append( "SYONINJIKOKU1, " );
            sql.append( "SYONINSYA1, " );
            sql.append( "SYONINBI2, " );
            sql.append( "SYONINJIKOKU2, " );
            sql.append( "SYONINSYA2, " );
            sql.append( "UKETUKEBI, " );
            sql.append( "UKETUKEJIKOKU, " );
            sql.append( "UKETUKESYA, " );
            sql.append( "HOUKOKUBI, " );
            sql.append( "HOUKOKUJIKOKU, " );
            sql.append( "HOUKOKUSYA, " );

            /* For SAS-S */
            sql.append( "SEIKYU_FLG, " );

            /* For SAS-E */
            sql.append( "NINSYOBI, " );
            sql.append( "NINSYOJIKOKU, " );
            sql.append( "DOWNLOADBI, " );
            sql.append( "DOWNLOADJIKOKU, " );
            sql.append( "DOWNLOADSYA, " );
            sql.append( "HANTEIBI, " );
            sql.append( "HANTEIJIKOKU, " );
            sql.append( "HANTEISYA, " );
            sql.append( "TOUROKUBI, " );
            sql.append( "TOUROKUJIKOKU, " );
            sql.append( "TOUROKUSYA, " );
            sql.append( "KOUSINBI, " );
            sql.append( "KOUSINJIKOKU, " );
            sql.append( "KOUSINSYA " );
            sql.append( ") " );
            sql.append( "VALUES ( " );
            sql.append( 
                "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?" );
            sql.append( ")" );

            /* �f�o�b�OLog���o�� */
            Log.debug( sql.toString(  ) );

            /* �l�̃Z�b�g For SAS-S */
            ps = con.prepareStatement( sql.toString(  ) );
            ps.setString( 1, mousikomi.getClassBean(  ).getKamokuBean(  ).getKamokuCode(  ) );
            ps.setString( 2, mousikomi.getClassBean(  ).getClassCode(  ) );
            ps.setString( 3, mousikomi.getSimeiNo(  ) );
            ps.setString( 4, mousikomi.getStatus(  ) );
            ps.setString( 5, mousikomi.getUketsukeJyotai(  ) );
            ps.setString( 6, mousikomi.getJyukoubi(  ) );
            ps.setString( 7, mousikomi.getReportFilename(  ) );
            ps.setString( 8, mousikomi.getReportContentType(  ) );
            ps.setNull( 9, java.sql.Types.BLOB );

            if ( mousikomi.getTensu(  ) != null ) {
                ps.setInt( 10, mousikomi.getTensu(  ).intValue(  ) );
            } else {
                ps.setNull( 10, java.sql.Types.INTEGER );
            }

            if ( mousikomi.getSyussekiNissuu(  ) != null ) {
                ps.setFloat( 11, mousikomi.getSyussekiNissuu(  ).floatValue(  ) );
            } else {
                ps.setNull( 11, java.sql.Types.FLOAT );
            }

            ps.setString( 12, mousikomi.getSeiseki(  ) );
            ps.setString( 13, mousikomi.getSyuryoHantei(  ) );
            ps.setString( 14, mousikomi.getMousikomibi(  ) );
            ps.setString( 15, mousikomi.getMousikomijikoku(  ) );
            ps.setString( 16, mousikomi.getMousikomisya(  ) );
            ps.setString( 17, mousikomi.getSyoninbi1(  ) );
            ps.setString( 18, mousikomi.getSyoninjikoku1(  ) );
            ps.setString( 19, mousikomi.getSyoninsya1(  ) );
            ps.setString( 20, mousikomi.getSyoninbi2(  ) );
            ps.setString( 21, mousikomi.getSyoninjikoku2(  ) );
            ps.setString( 22, mousikomi.getSyoninsya2(  ) );
            ps.setString( 23, mousikomi.getUketukebi(  ) );
            ps.setString( 24, mousikomi.getUketukejikoku(  ) );
            ps.setString( 25, mousikomi.getUketukesya(  ) );
            ps.setString( 26, mousikomi.getHoukokubi(  ) );
            ps.setString( 27, mousikomi.getHoukokujikoku(  ) );
            ps.setString( 28, mousikomi.getHoukokusya(  ) );
            ps.setString( 29,
                ( mousikomi.getSeikyuFlg(  ) != null ) ? mousikomi.getSeikyuFlg(  ) : "0" ); /* CHG#P-ALC01-022-003 */
            ps.setString( 30, mousikomi.getNinsyobi(  ) );
            ps.setString( 31, mousikomi.getNinsyojikoku(  ) );
            ps.setString( 32, mousikomi.getDownloadbi(  ) );
            ps.setString( 33, mousikomi.getDownloadjikoku(  ) );
            ps.setString( 34, mousikomi.getDownloadsya(  ) );
            ps.setString( 35, mousikomi.getHanteibi(  ) );
            ps.setString( 36, mousikomi.getHanteijikoku(  ) );
            ps.setString( 37, mousikomi.getHanteisya(  ) );

            String now_day  = PZZ010_CharacterUtil.GetDay(  );
            String now_time = PZZ010_CharacterUtil.GetTime(  );
            ps.setString( 38, now_day );
            ps.setString( 39, now_time );
            ps.setString( 40, loginuser.getSimeiNo(  ) );
            ps.setString( 41, now_day );
            ps.setString( 42, now_time );
            ps.setString( 43, loginuser.getSimeiNo(  ) );

            /* For SAS-E */
            int count = ps.executeUpdate(  );

            /* �񍐏����������ꍇ */
            if ( mousikomi.getHoukoku(  ) != null ) {
                //JDBC�̃^�C�v���v���p�e�B�t�@�C������擾����
                String jdbcType = ( String )ReadFile.fileMapData.get( "AP_SERVER_JDBC_TYPE" );
                String jndiName = "";

                if ( jdbcType.equals( "DABROKER" ) ) {
                    jndiName = "PYF_BlobDBAccessCosmiEJB";
                } else if ( jdbcType.equals( "ORACLE" ) ) {
                    jndiName = "PYF_BlobDBAccessOracleEJB";
                }

                //JNDI���̃��b�N�A�b�v
                PYF_BlobDBAccessEJBHome blobHome = ( PYF_BlobDBAccessEJBHome )locator
                    .getServiceLocation( jndiName, PYF_BlobDBAccessEJBHome.class );

                //EJBObject�̎擾
                PYF_BlobDBAccessEJB blobEjb = blobHome.create(  );

                /* �J�����Z�b�g */
                String[] columns = { "HOUKOKU" };

                //�}���l�Z�b�g
                String[] values = { "BLOB_DATA" };

                //�L�[
                String[] primaryKey = { "kamoku_code", "class_code", "simei_no" };

                //�L�[�l
                String[] keyValue = { mousikomi.getClassBean(  ).getKamokuBean(  ).getKamokuCode(  ), mousikomi.getClassBean(  )
                                                                                                               .getClassCode(  ), mousikomi
                    .getSimeiNo(  ) };
                blobEjb.UpdateBLOB( loginuser.getSimeiNo(  ), HcdbDef.L15_TBL, columns, values,
                    mousikomi.getHoukoku(  ), primaryKey, keyValue );
            }

            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw e;
        } catch ( Exception e ) {
            throw new EJBException( e );
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �v���C�}���[�L�[���L�[�Ƃ��āA�\���󋵃e�[�u���̃X�e�[�^�X���X�V���܂��B
     *
     * @param mousikomiJyokyoBeans �X�V���e
     * @param loginuser ���O�C�����[�U
     * @param syoninFlg ���F�t���O(���F����(���F�E���F���)�̏ꍇ�� true, ����ȊO�� false )
     * @return �X�V����
     * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdateStatus( PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans,
        PCY_PersonalBean loginuser, boolean syoninFlg )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            int count = 0;

            if ( ( mousikomiJyokyoBeans != null ) && ( mousikomiJyokyoBeans.length > 0 ) ) {
                // �R�l�N�V�����擾
                PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
                con = locator.getDataSource(  ).getConnection(  );

                // �N���X���̎擾�i���R�[�h���b�N�j
                String queryClassSql = "SELECT " + PCY_KamokuBean.getColumns( "kamoku" ) + ", "
                    + PCY_ClassBean.getColumns( "class" ) + " FROM " + HcdbDef.L01_TBL
                    + " KAMOKU, " + HcdbDef.L02_TBL + " CLASS " + " WHERE KAMOKU.KAMOKU_CODE=?"
                    + " AND CLASS.CLASS_CODE=?" + " AND CLASS.KOUSINBI=?"
                    + " AND CLASS.KOUSINJIKOKU=?" + " AND KAMOKU.KAMOKU_CODE=CLASS.KAMOKU_CODE "
                    + PCY_DBUtils.getInstance(  ).getLock( true );
                ps = con.prepareStatement( queryClassSql );
                ps.setString( 1, mousikomiJyokyoBeans[0].getKamokuCode(  ) );
                ps.setString( 2, mousikomiJyokyoBeans[0].getClassCode(  ) );
                ps.setString( 3, mousikomiJyokyoBeans[0].getClassBean(  ).getKousinbi(  ) );
                ps.setString( 4, mousikomiJyokyoBeans[0].getClassBean(  ).getKousinjikoku(  ) );

                ResultSet rs            = ps.executeQuery(  );
                PCY_ClassBean classBean = null;

                if ( rs.next(  ) ) {
                    classBean = new PCY_ClassBean( rs, "kamoku", "class" );
                } else {
                    context.setRollbackOnly(  );
                    throw new PCY_WarningException(  );
                }
                rs.close();  // INS 2007/2/2 s-hiura
                ps.close();  // INS 2007/2/2 s-hiura

                for ( int i = 0; i < mousikomiJyokyoBeans.length; i++ ) {
                    /* �\���󋵃e�[�u���̃X�e�[�^�X���擾 */
                    String queryMousikomiSql = "SELECT "
                        + PCY_MousikomiJyokyoBean.getColumns( "mousikomi" ) + " FROM "
                        + HcdbDef.L15_TBL + " mousikomi"
                        + " WHERE SIMEI_NO=? AND KAMOKU_CODE=? AND CLASS_CODE=?"
                        + " AND KOUSINBI=? AND KOUSINJIKOKU=? "
                        + PCY_DBUtils.getInstance(  ).getLock( true );
                    ps = con.prepareStatement( queryMousikomiSql );
                    ps.setString( 1, mousikomiJyokyoBeans[i].getSimeiNo(  ) );
                    ps.setString( 2, mousikomiJyokyoBeans[i].getKamokuCode(  ) );
                    ps.setString( 3, mousikomiJyokyoBeans[i].getClassCode(  ) );
                    ps.setString( 4, mousikomiJyokyoBeans[i].getKousinbi(  ) );
                    ps.setString( 5, mousikomiJyokyoBeans[i].getKousinjikoku(  ) );

                    rs = ps.executeQuery(  );

                    PCY_MousikomiJyokyoBean mousikomi = null;

                    if ( rs.next(  ) ) {
                        mousikomi = new PCY_MousikomiJyokyoBean( rs, "mousikomi" );
                    } else {
                        context.setRollbackOnly(  );
                        throw new PCY_WarningException(  );
                    }
                    rs.close();  // INS 2007/2/2 s-hiura
                    ps.close();  // INS 2007/2/2 s-hiura

                    /* �\���󋵃e�[�u���̃X�e�[�^�X���X�V */
                    String updateMousikomiSql = "UPDATE " + HcdbDef.L15_TBL + " SET STATUS=?,";

                    /* ���F�����̏ꍇ�A�X�V����J�����𑝂₷ */
                    if ( syoninFlg ) {
                        updateMousikomiSql = updateMousikomiSql
                            + "SYONINBI1=?, SYONINJIKOKU1=?, SYONINSYA1=?, UKETSUKE_JYOTAI=?,"; // For Syanai
                    }

                    updateMousikomiSql     = updateMousikomiSql
                        + " KOUSINBI=?, KOUSINJIKOKU=?, KOUSINSYA=?"
                        + " WHERE SIMEI_NO=? AND KAMOKU_CODE=? AND CLASS_CODE=?";
                    ps = con.prepareStatement( updateMousikomiSql );
                    ps.setString( 1, mousikomiJyokyoBeans[i].getStatus(  ) );

                    /* ���F�����̏ꍇ */
                    if ( syoninFlg ) {
                        ps.setString( 2, mousikomiJyokyoBeans[i].getSyoninbi1(  ) );
                        ps.setString( 3, mousikomiJyokyoBeans[i].getSyoninjikoku1(  ) );
                        ps.setString( 4, mousikomiJyokyoBeans[i].getSyoninsya1(  ) );

                        // For Syanai-S
                        ps.setString( 5, mousikomiJyokyoBeans[i].getUketsukeJyotai(  ) );
                        ps.setString( 6, PZZ010_CharacterUtil.GetDay(  ) );
                        ps.setString( 7, PZZ010_CharacterUtil.GetTime(  ) );
                        ps.setString( 8, loginuser.getSimeiNo(  ) );
                        ps.setString( 9, mousikomiJyokyoBeans[i].getSimeiNo(  ) );
                        ps.setString( 10, mousikomiJyokyoBeans[i].getKamokuCode(  ) );
                        ps.setString( 11, mousikomiJyokyoBeans[i].getClassCode(  ) );

                        // For Syanai-E
                    } else {
                        ps.setString( 2, PZZ010_CharacterUtil.GetDay(  ) );
                        ps.setString( 3, PZZ010_CharacterUtil.GetTime(  ) );
                        ps.setString( 4, loginuser.getSimeiNo(  ) );
                        ps.setString( 5, mousikomiJyokyoBeans[i].getSimeiNo(  ) );
                        ps.setString( 6, mousikomiJyokyoBeans[i].getKamokuCode(  ) );
                        ps.setString( 7, mousikomiJyokyoBeans[i].getClassCode(  ) );
                    }

                    count += ps.executeUpdate(  );
                    ps.close(  );
                }

                if ( mousikomiJyokyoBeans.length != count ) {
                    context.setRollbackOnly(  );
                    throw new PCY_WarningException(  );
                }
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

	/**
	 * �v���C�}���[�L�[���L�[�Ƃ��āA�\���󋵃e�[�u���̃X�e�[�^�X�Ǝ�t��Ԃ��X�V���܂��B
	 *
	 * @param mousikomiJyokyoBeans �X�V���e
	 * @param loginuser ���O�C�����[�U
	 * @return �X�V����
	 * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdateStatusAndUketuke( PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans,
		PCY_PersonalBean loginuser)
		throws PCY_WarningException {
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			int count = 0;

			if ( ( mousikomiJyokyoBeans != null ) && ( mousikomiJyokyoBeans.length > 0 ) ) {
				// �R�l�N�V�����擾
				PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
				con = locator.getDataSource(  ).getConnection(  );

				// �N���X���̎擾�i���R�[�h���b�N�j
				String queryClassSql = "SELECT " + PCY_KamokuBean.getColumns( "kamoku" ) + ", "
					+ PCY_ClassBean.getColumns( "class" ) + " FROM " + HcdbDef.L01_TBL
					+ " KAMOKU, " + HcdbDef.L02_TBL + " CLASS " + " WHERE KAMOKU.KAMOKU_CODE=?"
					+ " AND CLASS.CLASS_CODE=?" + " AND CLASS.KOUSINBI=?"
					+ " AND CLASS.KOUSINJIKOKU=?" + " AND KAMOKU.KAMOKU_CODE=CLASS.KAMOKU_CODE "
					+ PCY_DBUtils.getInstance(  ).getLock( true );
				ps = con.prepareStatement( queryClassSql );
				ps.setString( 1, mousikomiJyokyoBeans[0].getKamokuCode(  ) );
				ps.setString( 2, mousikomiJyokyoBeans[0].getClassCode(  ) );
				ps.setString( 3, mousikomiJyokyoBeans[0].getClassBean(  ).getKousinbi(  ) );
				ps.setString( 4, mousikomiJyokyoBeans[0].getClassBean(  ).getKousinjikoku(  ) );

				ResultSet rs            = ps.executeQuery(  );
				PCY_ClassBean classBean = null;

				if ( rs.next(  ) ) {
					classBean = new PCY_ClassBean( rs, "kamoku", "class" );
				} else {
					context.setRollbackOnly(  );
					throw new PCY_WarningException(  );
				}
                rs.close();  // INS 2007/2/2 s-hiura
                ps.close();  // INS 2007/2/2 s-hiura

				for ( int i = 0; i < mousikomiJyokyoBeans.length; i++ ) {
					/* �\���󋵃e�[�u���̃X�e�[�^�X���擾 */
					String queryMousikomiSql = "SELECT "
						+ PCY_MousikomiJyokyoBean.getColumns( "mousikomi" ) + " FROM "
						+ HcdbDef.L15_TBL + " mousikomi"
						+ " WHERE SIMEI_NO=? AND KAMOKU_CODE=? AND CLASS_CODE=?"
						+ " AND KOUSINBI=? AND KOUSINJIKOKU=? "
						+ PCY_DBUtils.getInstance(  ).getLock( true );
					ps = con.prepareStatement( queryMousikomiSql );
					ps.setString( 1, mousikomiJyokyoBeans[i].getSimeiNo(  ) );
					ps.setString( 2, mousikomiJyokyoBeans[i].getKamokuCode(  ) );
					ps.setString( 3, mousikomiJyokyoBeans[i].getClassCode(  ) );
					ps.setString( 4, mousikomiJyokyoBeans[i].getKousinbi(  ) );
					ps.setString( 5, mousikomiJyokyoBeans[i].getKousinjikoku(  ) );

					rs = ps.executeQuery(  );

					PCY_MousikomiJyokyoBean mousikomi = null;

					if ( rs.next(  ) ) {
						mousikomi = new PCY_MousikomiJyokyoBean( rs, "mousikomi" );
					} else {
						context.setRollbackOnly(  );
						throw new PCY_WarningException(  );
					}
                    rs.close();  // INS 2007/2/2 s-hiura
                    ps.close();  // INS 2007/2/2 s-hiura

					/* �\���󋵃e�[�u���̃X�e�[�^�X���X�V */
					StringBuffer updateMousikomiSql = new StringBuffer();
					
					updateMousikomiSql.append("UPDATE ");
					updateMousikomiSql.append(HcdbDef.L15_TBL);
					updateMousikomiSql.append( " SET STATUS=?,UKETSUKE_JYOTAI=?,");

					if((mousikomi.getStatus().equals("1") && mousikomi.getUketsukeJyotai().equals("0"))
					     || (mousikomi.getStatus().equals("1") && mousikomi.getUketsukeJyotai().equals("1"))){
							updateMousikomiSql.append(" UKETUKEBI=?, UKETUKEJIKOKU=?, UKETUKESYA=?, ");
					}
					updateMousikomiSql.append(" KOUSINBI=?, KOUSINJIKOKU=?, KOUSINSYA=?");
					updateMousikomiSql.append(" WHERE SIMEI_NO=? AND KAMOKU_CODE=? AND CLASS_CODE=?");
					
					Log.debug(updateMousikomiSql.toString());
					
					ps = con.prepareStatement( updateMousikomiSql.toString() );

					ps.setString( 1, mousikomiJyokyoBeans[i].getStatus(  ) );
					ps.setString( 2, mousikomiJyokyoBeans[i].getUketsukeJyotai());
					int psCount = 3;
					if((mousikomi.getStatus().equals("1") && mousikomi.getUketsukeJyotai().equals("0"))
						 || (mousikomi.getStatus().equals("1") && mousikomi.getUketsukeJyotai().equals("1"))){
							ps.setString( psCount++, PZZ010_CharacterUtil.GetDay(  ) );
							ps.setString( psCount++, PZZ010_CharacterUtil.GetTime(  ) );
							ps.setString( psCount++, loginuser.getSimeiNo(  ) );
					}
					ps.setString( psCount++, PZZ010_CharacterUtil.GetDay(  ) );
					ps.setString( psCount++, PZZ010_CharacterUtil.GetTime(  ) );
					ps.setString( psCount++, loginuser.getSimeiNo(  ) );
					ps.setString( psCount++, mousikomiJyokyoBeans[i].getSimeiNo(  ) );
					ps.setString( psCount++, mousikomiJyokyoBeans[i].getKamokuCode(  ) );
					ps.setString( psCount++, mousikomiJyokyoBeans[i].getClassCode(  ) );

					count += ps.executeUpdate(  );
                    ps.close(  );
				}

				if ( mousikomiJyokyoBeans.length != count ) {
					context.setRollbackOnly(  );
					throw new PCY_WarningException(  );
				}
			}

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return count;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * �v���C�}���[�L�[���L�[�Ƃ��āA�\���󋵃e�[�u���̃X�e�[�^�X�Ǝ�t��Ԃ��ꊇ�X�V���܂��B
	 *
	 * @param mousikomiJyokyoBeans �X�V���e
	 * @param loginuser ���O�C�����[�U
	 * @return �X�V����
	 * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdateStatusAndUketukeIkkatu( PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans,
		PCY_PersonalBean loginuser)
		throws PCY_WarningException {
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			int count = 0;

			if ( ( mousikomiJyokyoBeans != null ) && ( mousikomiJyokyoBeans.length > 0 ) ) {
				// �R�l�N�V�����擾
				PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
				con = locator.getDataSource(  ).getConnection(  );

				for ( int i = 0; i < mousikomiJyokyoBeans.length; i++ ) {
					// �N���X���̎擾�i���R�[�h���b�N�j
					String queryClassSql = "SELECT " + PCY_KamokuBean.getColumns( "kamoku" ) + ", "
						+ PCY_ClassBean.getColumns( "class" ) + " FROM " + HcdbDef.L01_TBL
						+ " KAMOKU, " + HcdbDef.L02_TBL + " CLASS " + " WHERE KAMOKU.KAMOKU_CODE=?"
						+ " AND CLASS.CLASS_CODE=?" + " AND CLASS.KOUSINBI=?"
						+ " AND CLASS.KOUSINJIKOKU=?" + " AND KAMOKU.KAMOKU_CODE=CLASS.KAMOKU_CODE "
						+ PCY_DBUtils.getInstance(  ).getLock( true );
						
					Log.debug(queryClassSql);
					ps = con.prepareStatement( queryClassSql );
					ps.setString( 1, mousikomiJyokyoBeans[i].getKamokuCode(  ) );
					ps.setString( 2, mousikomiJyokyoBeans[i].getClassCode(  ) );
					ps.setString( 3, mousikomiJyokyoBeans[i].getClassBean(  ).getKousinbi(  ) );
					ps.setString( 4, mousikomiJyokyoBeans[i].getClassBean(  ).getKousinjikoku(  ) );
	
					ResultSet rs            = ps.executeQuery(  );
					PCY_ClassBean classBean = null;
	
					if ( rs.next(  ) ) {
						classBean = new PCY_ClassBean( rs, "kamoku", "class" );
					} else {
						context.setRollbackOnly(  );
						throw new PCY_WarningException(  );
					}
					ps.close();

					/* �\���󋵃e�[�u���̃X�e�[�^�X���擾 */
					String queryMousikomiSql = "SELECT "
						+ PCY_MousikomiJyokyoBean.getColumns( "mousikomi" ) + " FROM "
						+ HcdbDef.L15_TBL + " mousikomi"
						+ " WHERE SIMEI_NO=? AND KAMOKU_CODE=? AND CLASS_CODE=?"
						+ " AND KOUSINBI=? AND KOUSINJIKOKU=? "
						+ PCY_DBUtils.getInstance(  ).getLock( true );
					ps = con.prepareStatement( queryMousikomiSql );
					ps.setString( 1, mousikomiJyokyoBeans[i].getSimeiNo(  ) );
					ps.setString( 2, mousikomiJyokyoBeans[i].getKamokuCode(  ) );
					ps.setString( 3, mousikomiJyokyoBeans[i].getClassCode(  ) );
					ps.setString( 4, mousikomiJyokyoBeans[i].getKousinbi(  ) );
					ps.setString( 5, mousikomiJyokyoBeans[i].getKousinjikoku(  ) );

					rs = ps.executeQuery(  );
					
					PCY_MousikomiJyokyoBean mousikomi = null;

					if ( rs.next(  ) ) {
						mousikomi = new PCY_MousikomiJyokyoBean( rs, "mousikomi" );
					} else {
						context.setRollbackOnly(  );
						throw new PCY_WarningException(  );
					}
					ps.close();
					
					/* �\���󋵃e�[�u���̃X�e�[�^�X���X�V */
					StringBuffer updateMousikomiSql = new StringBuffer();
					
					updateMousikomiSql.append("UPDATE ");
					updateMousikomiSql.append(HcdbDef.L15_TBL);
					updateMousikomiSql.append( " SET STATUS=?,UKETSUKE_JYOTAI=?,");
					if((mousikomi.getStatus().equals("1") && mousikomi.getUketsukeJyotai().equals("0"))
						 || (mousikomi.getStatus().equals("1") && mousikomi.getUketsukeJyotai().equals("1"))){
							updateMousikomiSql.append(" UKETUKEBI=?, UKETUKEJIKOKU=?, UKETUKESYA=?, ");
					}
					updateMousikomiSql.append(" KOUSINBI=?, KOUSINJIKOKU=?, KOUSINSYA=?");
					updateMousikomiSql.append(" WHERE SIMEI_NO=? AND KAMOKU_CODE=? AND CLASS_CODE=?");
					
					Log.debug(updateMousikomiSql.toString());
					
					ps = con.prepareStatement( updateMousikomiSql.toString() );

					ps.setString( 1, mousikomiJyokyoBeans[i].getStatus(  ) );
					ps.setString( 2, mousikomiJyokyoBeans[i].getUketsukeJyotai());
					int psCount = 3;
					if((mousikomi.getStatus().equals("1") && mousikomi.getUketsukeJyotai().equals("0"))
						 || (mousikomi.getStatus().equals("1") && mousikomi.getUketsukeJyotai().equals("1"))){
							ps.setString( psCount++, PZZ010_CharacterUtil.GetDay(  ) );
							ps.setString( psCount++, PZZ010_CharacterUtil.GetTime(  ) );
							ps.setString( psCount++, loginuser.getSimeiNo(  ) );
					}
					ps.setString( psCount++, PZZ010_CharacterUtil.GetDay(  ) );
					ps.setString( psCount++, PZZ010_CharacterUtil.GetTime(  ) );
					ps.setString( psCount++, loginuser.getSimeiNo(  ) );
					ps.setString( psCount++, mousikomiJyokyoBeans[i].getSimeiNo(  ) );
					ps.setString( psCount++, mousikomiJyokyoBeans[i].getKamokuCode(  ) );
					ps.setString( psCount++, mousikomiJyokyoBeans[i].getClassCode(  ) );

					count += ps.executeUpdate(  );
                    ps.close();
				}

				if ( mousikomiJyokyoBeans.length != count ) {
					context.setRollbackOnly(  );
					throw new PCY_WarningException(  );
				}
			}

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return count;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

    /**
     * �v���C�}���[�L�[���L�[�Ƃ��Đ\���󋵃e�[�u�����X�V���܂��B
     *
     * @param mousikomiJyokyoBean �X�V���e
     * @param loginuser ���O�C�����[�U
     * @return �X�V����
     * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdate( PCY_MousikomiJyokyoBean mousikomiJyokyoBean, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            StringBuffer sql = new StringBuffer(  );
            sql.append( "UPDATE " );
            sql.append( HcdbDef.L15_TBL );
            sql.append( "    SET STATUS=?" );
            sql.append( "  WHERE SIMEI_NO=?" );
            sql.append( "    AND KAMOKU_CODE=?" );
            sql.append( "    AND CLASS_CODE=?" );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �X�V���s
            ps = con.prepareStatement( sql.toString(  ) );

            int count = 0;

            for ( int i = 0; i < mousikomiJyokyoBean.getSimeiNoArray(  ).length; i++ ) {
                ps.setString( 1, "2" );
                ps.setString( 2, mousikomiJyokyoBean.getSimeiNoArray(  )[i] );
                ps.setString( 3, mousikomiJyokyoBean.getKamokuCodeArray(  )[i] );
                ps.setString( 4, mousikomiJyokyoBean.getClassCodeArray(  )[i] );
                count += ps.executeUpdate(  );
            }

            if ( mousikomiJyokyoBean.getSimeiNoArray(  ).length != count ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �_�E�����[�h�X�V�����X�V����B
     * �X�V���A�X�V�����A�X�V�҂͍X�V���Ȃ��B
     * WHERE���PrimaryKey���w�肵�Ă��邽�߁A�Ώۃ��R�[�h��1���R�[�h�̂݁B
     *
     * @param mousikomiBean
     * @param loginuser
     * @return �X�V���R�[�h���i1�Œ�j
     * @throws PCY_WarningException
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdateDownLoadInfo( PCY_MousikomiJyokyoBean mousikomiBean,
        PCY_PersonalBean loginuser ) throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "UPDATE " );
            sql.append( HcdbDef.L15_TBL );
            sql.append( "   SET DOWNLOADBI=?" );
            sql.append( ",      DOWNLOADJIKOKU=?" );
            sql.append( ",      DOWNLOADSYA=?" );
            sql.append( "  WHERE SIMEI_NO=?" );
            sql.append( "    AND KAMOKU_CODE=?" );
            sql.append( "    AND CLASS_CODE=?" );

            /* �f�o�b�O���O�o�� */
            Log.debug( sql.toString(  ) );

            ps = con.prepareStatement( sql.toString(  ) );

            ps.setString( 1, mousikomiBean.getDownloadbi(  ) );
            ps.setString( 2, mousikomiBean.getDownloadjikoku(  ) );
            ps.setString( 3, mousikomiBean.getDownloadsya(  ) );
            ps.setString( 4, mousikomiBean.getSimeiNo(  ) );
            ps.setString( 5, mousikomiBean.getKamokuCode(  ) );
            ps.setString( 6, mousikomiBean.getClassCode(  ) );

            int count = ps.executeUpdate(  );

            if ( count != 1 ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �\���󋵃e�[�u���̕������R�[�h���X�V���܂��B
     *
     * @param mousikomiBeans �X�V���e
     * @param loginuser ���O�C�����[�U
     * @param houkokuUpdateFlg �񍐃A�b�v�f�[�g�t���O�itrue:�񍐂��X�V���܂��B false:�񍐂��X�V���܂���B)
     * @return �X�V����
     * @throws RemoteException EJB�Ăяo���Ɏ��s�����ꍇ
     * @throws Exception BLOB�����ŃG���[�����������ꍇ
     * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdateRecords( PCY_MousikomiJyokyoBean[] mousikomiBeans, boolean houkokuUpdateFlg,
        PCY_PersonalBean loginuser ) throws RemoteException, PCY_WarningException, Exception {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            int count = 0;

            for ( int i = 0; i < mousikomiBeans.length; i++ ) {
                StringBuffer sql = new StringBuffer(  );
                sql.append( "UPDATE " );
                sql.append( HcdbDef.L15_TBL );
                sql.append( "    SET KOUSINBI=?" );
                sql.append( "        ,KOUSINJIKOKU=?" );
                sql.append( "        ,KOUSINSYA=?" );

                Map update_column = mousikomiBeans[i].extractItem(  );

                for ( Iterator ite = update_column.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                    Object column = ite.next(  );
                    sql.append( " ," + column + "=?" );
                }

                sql.append( "  WHERE SIMEI_NO=?" );
                sql.append( "    AND KAMOKU_CODE=?" );
                sql.append( "    AND CLASS_CODE=?" );

                if ( mousikomiBeans[i].getKousinbi(  ) != null ) {
                    sql.append( "    AND KOUSINBI=?" );
                }

                if ( mousikomiBeans[i].getKousinjikoku(  ) != null ) {
                    sql.append( "    AND KOUSINJIKOKU=?" );
                }

                // �X�V���s
                ps = con.prepareStatement( sql.toString(  ) );
                ps.setString( 1, PZZ010_CharacterUtil.GetDay(  ) );
                ps.setString( 2, PZZ010_CharacterUtil.GetTime(  ) );
                ps.setString( 3, loginuser.getSimeiNo(  ) );

                int j = 4;

                for ( Iterator ite = update_column.keySet(  ).iterator(  ); ite.hasNext(  ); j++ ) {
                    Object key = ite.next(  );
                    Log.debug( Integer.toString( count ) + ":" + key + ":"
                        + update_column.get( key ) );

                    if ( "<null>".equals( update_column.get( key ) ) ) {
                        if ( key.equals( "REPORT_FILENAME" ) || key.equals( "REPORT_CONTENT_TYPE" ) ) {
                            ps.setNull( j, java.sql.Types.VARCHAR );
                        } else if ( key.equals( "TENSU" ) ) {
                            ps.setNull( j, java.sql.Types.INTEGER );
                        } else {
                            ps.setNull( j, java.sql.Types.CHAR );
                        }
                    } else {
                        ps.setObject( j, update_column.get( key ) );
                    }
                }

                ps.setString( j, mousikomiBeans[i].getSimeiNo(  ) );
                j++;
                ps.setString( j, mousikomiBeans[i].getKamokuCode(  ) );
                j++;
                ps.setString( j, mousikomiBeans[i].getClassCode(  ) );
                j++;

                if ( mousikomiBeans[i].getKousinbi(  ) != null ) {
                    ps.setString( j, mousikomiBeans[i].getKousinbi(  ) );
                    j++;
                }

                if ( mousikomiBeans[i].getKousinjikoku(  ) != null ) {
                    ps.setString( j, mousikomiBeans[i].getKousinjikoku(  ) );
                    j++;
                }

                int result = ps.executeUpdate(  );
                ps.close(  );
                count += result;

                if ( ( result != 0 )
                    && !mousikomiBeans[i].getClassBean(  ).getHoukokuKubun(  ).equals( "0" )
                    && !mousikomiBeans[i].getClassBean(  ).getHoukokuKubun(  ).equals( "4" )
                    && ( houkokuUpdateFlg == true ) ) {
                    /* <null>�@���@null �ɕϊ� */
                    if ( "<null>".getBytes(  ).equals( mousikomiBeans[i].getHoukoku(  ) ) ) {
                        mousikomiBeans[i].setHoukoku( null );
                    }

                    //�t�@�C����DB�Ɋi�[
                    //JDBC�̃^�C�v���v���p�e�B�t�@�C������擾����
                    String jdbcType = ( String )ReadFile.fileMapData.get( "AP_SERVER_JDBC_TYPE" );
                    String jndiName = "";

                    if ( jdbcType.equals( "DABROKER" ) ) {
                        jndiName = "PYF_BlobDBAccessCosmiEJB";
                    } else if ( jdbcType.equals( "ORACLE" ) ) {
                        jndiName = "PYF_BlobDBAccessOracleEJB";
                    }

                    //JNDI���̃��b�N�A�b�v
                    PYF_BlobDBAccessEJBHome blobHome = ( PYF_BlobDBAccessEJBHome )locator
                        .getServiceLocation( jndiName, PYF_BlobDBAccessEJBHome.class );

                    //EJBObject�̎擾
                    PYF_BlobDBAccessEJB blobEjb = blobHome.create(  );

                    /* �J�����Z�b�g */
                    String[] columns = { "HOUKOKU" };

                    //�}���l�Z�b�g
                    String[] values = { "BLOB_DATA" };

                    //�L�[
                    String[] primaryKey = { "kamoku_code", "class_code", "simei_no" };

                    //�L�[�l
                    String[] keyValue = { mousikomiBeans[i].getClassBean(  ).getKamokuBean(  )
                                                           .getKamokuCode(  ), mousikomiBeans[i].getClassBean(  )
                                                                                                .getClassCode(  ), mousikomiBeans[i]
                        .getSimeiNo(  ) };
                    blobEjb.UpdateBLOB( loginuser.getSimeiNo(  ), HcdbDef.L15_TBL, columns, values,
                        mousikomiBeans[i].getHoukoku(  ), primaryKey, keyValue );
                }
            }

            if ( mousikomiBeans.length != count ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

	/**
	 * �\���󋵃e�[�u���̕������R�[�h���X�V���܂��B(�o�ȓ����A�_���A���сA�����A���l)
	 *
	 * @param mousikomiBeans �X�V���e
	 * @param loginuser ���O�C�����[�U
	 * @return �X�V����
	 * @throws RemoteException EJB�Ăяo���Ɏ��s�����ꍇ
	 * @throws Exception ���̑��G���[�����������ꍇ
	 * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdateSeiseki( PCY_MousikomiJyokyoBean[] mousikomiBeans, 
		PCY_PersonalBean loginuser ) throws RemoteException, PCY_WarningException, Exception {
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con = locator.getDataSource(  ).getConnection(  );

			int count = 0;

			for ( int i = 0; i < mousikomiBeans.length; i++ ) {
				StringBuffer sql = new StringBuffer(  );
				sql.append( "UPDATE " );
				sql.append( HcdbDef.L15_TBL );
				sql.append( "    SET KOUSINBI=?" );
				sql.append( "        ,KOUSINJIKOKU=?" );
				sql.append( "        ,KOUSINSYA=?" );
				sql.append( "        ,TENSU=?" );
				sql.append( "        ,SEISEKI=?" );
				sql.append( "        ,SYUSSEKI_NISSUU=?" );
				sql.append( "        ,SEIKYU_FLG=?" );
				sql.append( "        ,SEISEKI_BIKOU=?");

				sql.append( "  WHERE SIMEI_NO=?" );
				sql.append( "    AND KAMOKU_CODE=?" );
				sql.append( "    AND CLASS_CODE=?" );

				if ( mousikomiBeans[i].getKousinbi(  ) != null ) {
					sql.append( "    AND KOUSINBI=?" );
				}

				if ( mousikomiBeans[i].getKousinjikoku(  ) != null ) {
					sql.append( "    AND KOUSINJIKOKU=?" );
				}

				Log.debug(sql.toString());
				
				// �X�V���s
				ps = con.prepareStatement( sql.toString(  ) );
				ps.setString( 1, PZZ010_CharacterUtil.GetDay(  ) );
				ps.setString( 2, PZZ010_CharacterUtil.GetTime(  ) );
				ps.setString( 3, loginuser.getSimeiNo(  ) );
				
				if(mousikomiBeans[i].getTensu() == null || mousikomiBeans[i].getTensu().toString().equals("")){
					ps.setNull( 4, java.sql.Types.INTEGER );
				}else{
					ps.setInt( 4, mousikomiBeans[i].getTensu().intValue() );
				}
				
				ps.setString( 5, mousikomiBeans[i].getSeiseki() );
				
				if(mousikomiBeans[i].getSyussekiNissuu() == null || mousikomiBeans[i].getSyussekiNissuu().toString().equals("")){
					ps.setNull( 6, java.sql.Types.FLOAT);	
				}else{
					ps.setFloat( 6, mousikomiBeans[i].getSyussekiNissuu().floatValue() );
				}
								
				ps.setString( 7, mousikomiBeans[i].getSeikyuFlg() );
				
				ps.setString(8,mousikomiBeans[i].getSeisekiBikou());
				
				ps.setString( 9, mousikomiBeans[i].getSimeiNo());
				ps.setString( 10, mousikomiBeans[i].getKamokuCode());
				ps.setString( 11, mousikomiBeans[i].getClassCode());
				
				int t = 12;
				if ( mousikomiBeans[i].getKousinbi(  ) != null ) {
					ps.setString( t, mousikomiBeans[i].getKousinbi());
					t++;
				}
				
				if ( mousikomiBeans[i].getKousinjikoku(  ) != null ) {
					ps.setString( t, mousikomiBeans[i].getKousinjikoku());
				}
				
				
				int result = ps.executeUpdate(  );
                ps.close(  );
				count += result;
			}

			if ( mousikomiBeans.length != count ) {
				context.setRollbackOnly(  );
				throw new PCY_WarningException(  );
			}

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return count;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

    /**
     * �\���󋵃e�[�u���̃��R�[�h�ǉ��A�y��ES�F�ؗ����̊i�[(�F�؋敪���v�̏ꍇ�̂�)���s���܂��B
     *
    * @param mousikomiBean �X�V���e
    * @param ninsyoBean �X�V���e
    * @param loginuser ���O�C�����[�U
    * @throws Exception �����Ɏ��s�����ꍇ
    * @ejb.interface-method
    * @ejb.transaction type="Required"
     */
    public void doInsertWithEsNinsyo( PCY_MousikomiJyokyoBean mousikomiBean,
        PCY_EsNinsyoRirekiBean ninsyoBean, PCY_PersonalBean loginuser )
        throws Exception {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

            /* PCY_ClassEJB�I�u�W�F�N�g�̐��� */
            PCY_ClassEJBHome classHome = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
                    PCY_ClassEJBHome.class );
            PCY_ClassEJB classEjb = classHome.create(  );

            /* �Y���N���X���X�V����Ă��Ȃ����`�F�b�N����(���b�N�t��) */
            PCY_ClassBean key = new PCY_ClassBean(  );

            PCY_ClassBean[] ret_class = classEjb.doSelect( mousikomiBean.getClassBean(  ), true,
                    loginuser );

            //�N���X�����݂��Ȃ��ꍇ�͌x����ʂ֑J��
            if ( ret_class.length != 1 ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            /* �\���󋵂c�a�̍X�V */
            /* For Syanai */
            //this.doInsert( mousikomiBean, loginuser );
            this.doMousikomiWithZensyaTaisyo( mousikomiBean, loginuser );

            /* ES�F�ؗv�̏ꍇ�ɂ�ES�F�ؗ������i�[���� */
            if ( mousikomiBean.getClassBean(  ).getNinsyoKubun(  ).equals( "1" ) ) {
                /* PCY_EsNinsyoRirekiEJB */
                PCY_EsNinsyoRirekiEJBHome ninsyoHome = ( PCY_EsNinsyoRirekiEJBHome )locator
                    .getServiceLocation( "PCY_EsNinsyoRirekiEJB", PCY_EsNinsyoRirekiEJBHome.class );
                PCY_EsNinsyoRirekiEJB ninsyoEjb = ninsyoHome.create(  );

                /* ES�F�ؗ����̊i�[ */
                ninsyoEjb.doInsert( new PCY_EsNinsyoRirekiBean[] { ninsyoBean }, loginuser );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �\���󋵃e�[�u���̕������R�[�h�X�V�A�y��ES�F�ؗ����̊i�[(�F�؋敪���v�̏ꍇ�̂�)���s���܂��B
     *
     * @param mousikomiBean �X�V���e
     * @param ninsyoBean �X�V���e
     * @param loginuser ���O�C�����[�U
     * @throws Exception �����Ɏ��s�����ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public void doUpdateWithEsNinsyo( PCY_MousikomiJyokyoBean mousikomiBean,
        PCY_EsNinsyoRirekiBean ninsyoBean, PCY_PersonalBean loginuser )
        throws Exception {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

            /* PCY_ClassEJB�I�u�W�F�N�g�̐��� */
            PCY_ClassEJBHome classHome = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
                    PCY_ClassEJBHome.class );
            PCY_ClassEJB classEjb = classHome.create(  );

            /* �Y���N���X���X�V����Ă��Ȃ����`�F�b�N����(���b�N�t��) */
            PCY_ClassBean[] ret_class = classEjb.doSelect( mousikomiBean.getClassBean(  ), true,
                    loginuser );

            //�N���X�����݂��Ȃ��ꍇ�͌x����ʂ֑J��
            if ( ret_class.length != 1 ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            /* �\���󋵂̒ǉ� */
            boolean houkoku_flg;

            if ( mousikomiBean.getHoukoku(  ) != null ) {
                houkoku_flg = true;
            } else {
                houkoku_flg = false;
            }

            this.doUpdateRecords( new PCY_MousikomiJyokyoBean[] { mousikomiBean }, houkoku_flg,
                loginuser );

            /* ES�F�ؗv�̏ꍇ�ɂ�ES�F�ؗ������i�[���� */
            if ( mousikomiBean.getClassBean(  ).getNinsyoKubun(  ).equals( "1" ) ) {
                /* PCY_EsNinsyoRirekiEJB */
                PCY_EsNinsyoRirekiEJBHome ninsyoHome = ( PCY_EsNinsyoRirekiEJBHome )locator
                    .getServiceLocation( "PCY_EsNinsyoRirekiEJB", PCY_EsNinsyoRirekiEJBHome.class );
                PCY_EsNinsyoRirekiEJB ninsyoEjb = ninsyoHome.create(  );

                /* ES�F�ؗ����̊i�[ */
                ninsyoEjb.doInsert( new PCY_EsNinsyoRirekiBean[] { ninsyoBean }, loginuser );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �v���C�}���[�L�[���L�[�Ƃ��Đ\���󋵃e�[�u�����폜���܂��B
     *
     * @param mousikomiJyokyoBean �폜����
     * @param loginuser ���O�C�����[�U
     * @return �폜����
     * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍ폜����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doDelete( PCY_MousikomiJyokyoBean mousikomiJyokyoBean, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            StringBuffer sql = new StringBuffer(  );
            sql.append( "DELETE FROM " );
            sql.append( HcdbDef.L15_TBL );
            sql.append( "  WHERE SIMEI_NO=?" );
            sql.append( "    AND KAMOKU_CODE=?" );
            sql.append( "    AND CLASS_CODE=?" );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �������s
            ps = con.prepareStatement( sql.toString(  ) );

            int count = 0;

            for ( int i = 0; i < mousikomiJyokyoBean.getSimeiNoArray(  ).length; i++ ) {
                ps.setString( 1, mousikomiJyokyoBean.getSimeiNoArray(  )[i] );
                ps.setString( 2, mousikomiJyokyoBean.getKamokuCodeArray(  )[i] );
                ps.setString( 3, mousikomiJyokyoBean.getClassCodeArray(  )[i] );
                count += ps.executeUpdate(  );
            }

            if ( mousikomiJyokyoBean.getSimeiNoArray(  ).length != count ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �v���C�}���[�L�[���L�[�Ƃ��Đ\���󋵃e�[�u�����폜���܂��B
     *
     * @param mousikomiBeans �폜�Ώۂ̐\�����
     * @param loginuser ���O�C�����[�U
     * @return �폜���R�[�h��
     * @throws PCY_WarningException �폜����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doDeleteByPrimaryKey( PCY_MousikomiJyokyoBean[] mousikomiBeans,
        PCY_PersonalBean loginuser ) throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            int total_count = 0;

            // �������s
            for ( int i = 0; i < mousikomiBeans.length; i++ ) {
                String kousinbi     = mousikomiBeans[i].getKousinbi(  );
                String kousinjikoku = mousikomiBeans[i].getKousinjikoku(  );

                StringBuffer sql = new StringBuffer(  );
                sql.append( "DELETE FROM " );
                sql.append( HcdbDef.L15_TBL );
                sql.append( "  WHERE SIMEI_NO=?" );
                sql.append( "    AND KAMOKU_CODE=?" );
                sql.append( "    AND CLASS_CODE=?" );

                if ( ( kousinbi != null ) && !kousinbi.equals( "" ) ) {
                    sql.append( "    AND KOUSINBI=?" );
                } else {
                    sql.append( "    AND KOUSINBI IS NULL" );
                }

                if ( ( kousinjikoku != null ) && !kousinjikoku.equals( "" ) ) {
                    sql.append( "    AND KOUSINJIKOKU=?" );
                } else {
                    sql.append( "    AND KOUSINJIKOKU IS NULL" );
                }

                // DEL#P-ALH41-001-005
                //                con     = locator.getDataSource(  ).getConnection(  );
                // �������s
                ps = con.prepareStatement( sql.toString(  ) );
                ps.setString( 1, mousikomiBeans[i].getSimeiNo(  ) );
                ps.setString( 2, mousikomiBeans[i].getKamokuCode(  ) );
                ps.setString( 3, mousikomiBeans[i].getClassCode(  ) );

                int idx = 4;

                if ( ( kousinbi != null ) && !kousinbi.equals( "" ) ) {
                    ps.setString( idx++, kousinbi );
                }

                if ( ( kousinjikoku != null ) && !kousinjikoku.equals( "" ) ) {
                    ps.setString( idx++, kousinjikoku );
                }

                int count = ps.executeUpdate(  );
                ps.close(  ); //INS##P-ALH41-001-005

                //��������������Ȃ��ꍇ�͌x��
                if ( count != 1 ) {
                    context.setRollbackOnly(  );
                    throw new PCY_WarningException(  );
                }

                total_count += count;
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return total_count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    // For Syanai-S

    /**
     * �v���C�}���[�L�[���L�[�Ƃ��āA�\���󋵃e�[�u���̎�t��ԃt���O���X�V���܂��B
     *
     * @param mousikomiJyokyoBeans  �X�V���e
     * @param loginuser             ���O�C�����[�U
     * @return                      �X�V����
     * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdateReceiptStatus( PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans,
        PCY_PersonalBean loginuser ) throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            int count = 0;

            if ( ( mousikomiJyokyoBeans != null ) && ( mousikomiJyokyoBeans.length > 0 ) ) {
                // �R�l�N�V�����擾
                PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
                con = locator.getDataSource(  ).getConnection(  );

                // �N���X���̎擾�i���R�[�h���b�N�j
                String queryClassSql = "SELECT " + PCY_KamokuBean.getColumns( "KAMOKU" ) + ", "
                    + PCY_ClassBean.getColumns( "CLASS" ) + " FROM " + HcdbDef.L01_TBL
                    + " KAMOKU, " + HcdbDef.L02_TBL + " CLASS " + " WHERE KAMOKU.KAMOKU_CODE=?"
                    + " AND CLASS.CLASS_CODE=?" + " AND CLASS.KOUSINBI=?"
                    + " AND CLASS.KOUSINJIKOKU=?" + " AND KAMOKU.KAMOKU_CODE=CLASS.KAMOKU_CODE "
                    + PCY_DBUtils.getInstance(  ).getLock( true );

                ps = con.prepareStatement( queryClassSql );
                ps.setString( 1, mousikomiJyokyoBeans[0].getKamokuCode(  ) );
                ps.setString( 2, mousikomiJyokyoBeans[0].getClassCode(  ) );
                ps.setString( 3, mousikomiJyokyoBeans[0].getClassBean(  ).getKousinbi(  ) );
                ps.setString( 4, mousikomiJyokyoBeans[0].getClassBean(  ).getKousinjikoku(  ) );
                Log.debug( "�N���X���擾:" + queryClassSql );
                Log.debug( "   �ȖڃR�[�h:" + mousikomiJyokyoBeans[0].getKamokuCode(  ) );
                Log.debug( " �N���X�R�[�h:" + mousikomiJyokyoBeans[0].getClassCode(  ) );
                Log.debug( "       �X�V��:" + mousikomiJyokyoBeans[0].getClassBean(  ).getKousinbi(  ) );
                Log.debug( "     �X�V����:"
                    + mousikomiJyokyoBeans[0].getClassBean(  ).getKousinjikoku(  ) );

                ResultSet rs            = ps.executeQuery(  );
                PCY_ClassBean classBean = null;

                if ( rs.next(  ) ) {
                    classBean = new PCY_ClassBean( rs, "KAMOKU", "CLASS" );
                } else {
                    context.setRollbackOnly(  );
                    throw new PCY_WarningException(  );
                }
                rs.close();  // INS 2007/2/2 s-hiura
                ps.close();  // INS 2007/2/2 s-hiura

                for ( int i = 0; i < mousikomiJyokyoBeans.length; i++ ) {
                    // �\���󋵃e�[�u���̃X�e�[�^�X���擾
                    String queryMousikomiSql = "SELECT "
                        + PCY_MousikomiJyokyoBean.getColumns( "MOUSIKOMI" ) + " FROM "
                        + HcdbDef.L15_TBL + " MOUSIKOMI" + " WHERE SIMEI_NO=?"
                        + " AND KAMOKU_CODE=?" + " AND CLASS_CODE=?" + " AND KOUSINBI=?"
                        + " AND KOUSINJIKOKU=? " + PCY_DBUtils.getInstance(  ).getLock( true );

                    ps = con.prepareStatement( queryMousikomiSql );
                    ps.setString( 1, mousikomiJyokyoBeans[i].getSimeiNo(  ) );
                    ps.setString( 2, mousikomiJyokyoBeans[i].getKamokuCode(  ) );
                    ps.setString( 3, mousikomiJyokyoBeans[i].getClassCode(  ) );
                    ps.setString( 4, mousikomiJyokyoBeans[i].getKousinbi(  ) );
                    ps.setString( 5, mousikomiJyokyoBeans[i].getKousinjikoku(  ) );
                    Log.debug( "�X�e�[�^�X�擾:" + queryMousikomiSql );
                    Log.debug( "       ����No:" + mousikomiJyokyoBeans[i].getSimeiNo(  ) );
                    Log.debug( "   �ȖڃR�[�h:" + mousikomiJyokyoBeans[i].getKamokuCode(  ) );
                    Log.debug( " �N���X�R�[�h:" + mousikomiJyokyoBeans[i].getClassCode(  ) );
                    Log.debug( "       �X�V��:" + mousikomiJyokyoBeans[i].getKousinbi(  ) );
                    Log.debug( "     �X�V����:" + mousikomiJyokyoBeans[i].getKousinjikoku(  ) );

                    rs = ps.executeQuery(  );

                    PCY_MousikomiJyokyoBean mousikomi = null;

                    if ( rs.next(  ) ) {
                        mousikomi = new PCY_MousikomiJyokyoBean( rs, "MOUSIKOMI" );
                    } else {
                        context.setRollbackOnly(  );
                        throw new PCY_WarningException(  );
                    }
                    rs.close();  // INS 2007/2/2 s-hiura
                    ps.close();  // INS 2007/2/2 s-hiura

                    // �\���󋵃e�[�u���̃X�e�[�^�X���X�V
                    String updateMousikomiSql = "UPDATE " + HcdbDef.L15_TBL
                        + " SET UKETSUKE_JYOTAI=?, KOUSINBI=?, KOUSINJIKOKU=?, KOUSINSYA=?"
                        + " WHERE SIMEI_NO=?" + " AND KAMOKU_CODE=?" + " AND CLASS_CODE=?"
                        + " AND KOUSINBI=?" + " AND KOUSINJIKOKU=? ";
                    ps = con.prepareStatement( updateMousikomiSql );

                    ps.setString( 1, mousikomiJyokyoBeans[i].getUketsukeJyotai(  ) );
                    ps.setString( 2, PZZ010_CharacterUtil.GetDay(  ) );
                    ps.setString( 3, PZZ010_CharacterUtil.GetTime(  ) );
                    ps.setString( 4, loginuser.getSimeiNo(  ) );
                    ps.setString( 5, mousikomiJyokyoBeans[i].getSimeiNo(  ) );
                    ps.setString( 6, mousikomiJyokyoBeans[i].getKamokuCode(  ) );
                    ps.setString( 7, mousikomiJyokyoBeans[i].getClassCode(  ) );
                    ps.setString( 8, mousikomiJyokyoBeans[i].getKousinbi(  ) );
                    ps.setString( 9, mousikomiJyokyoBeans[i].getKousinjikoku(  ) );
                    Log.debug( "�X�e�[�^�X�X�V:" + updateMousikomiSql );
                    Log.debug( "     ��t���:" + mousikomiJyokyoBeans[i].getUketsukeJyotai(  ) );
                    Log.debug( "       �X�V��:" + PZZ010_CharacterUtil.GetDay(  ) );
                    Log.debug( "     �X�V����:" + PZZ010_CharacterUtil.GetTime(  ) );
                    Log.debug( "       �X�V��:" + loginuser.getSimeiNo(  ) );
                    Log.debug( "       ����No:" + mousikomiJyokyoBeans[i].getSimeiNo(  ) );
                    Log.debug( "   �ȖڃR�[�h:" + mousikomiJyokyoBeans[i].getKamokuCode(  ) );
                    Log.debug( " �N���X�R�[�h:" + mousikomiJyokyoBeans[i].getClassCode(  ) );
                    Log.debug( "     ���X�V��:" + mousikomiJyokyoBeans[i].getKousinbi(  ) );
                    Log.debug( "   ���X�V����:" + mousikomiJyokyoBeans[i].getKousinjikoku(  ) );

                    count += ps.executeUpdate(  );
                    ps.close(  );
                }

                if ( mousikomiJyokyoBeans.length != count ) {
                    context.setRollbackOnly(  );
                    throw new PCY_WarningException(  );
                }
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    // For Syanai-E

	/**
	 * �\���Ґ����J�E���g���܂��B
	 * @param classBean
	 * @param loginuser
	 * @return classBean
	 * @throws PCY_WarningException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_ClassBean doCountMousikomisya( PCY_ClassBean classBean ,PCY_PersonalBean loginuser) {

			Connection con       = null;
			PreparedStatement ps = null;
			int kaisibiNum       = 3; // CHG#P-PLP02-014-001
			int syuryobiNum;
			int simeiNoNum;
			int statusNum;
			int kamokuCodeNum;

			try {
				/*���\�b�h�g���[�X�o��*/
				Log.method( loginuser.getSimeiNo(  ), "IN", "" );

				StringBuffer sql = new StringBuffer(  );
				sql.append( "SELECT COUNT(*) count"); 
				sql.append( " FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( " WHERE  MOUSIKOMI.KAMOKU_CODE    = ?" ); 
				sql.append( "   AND MOUSIKOMI.CLASS_CODE = ? "  );
				
				sql.append(" AND ( (MOUSIKOMI.STATUS = '1' AND MOUSIKOMI.UKETSUKE_JYOTAI = '0')");
				sql.append(" OR (MOUSIKOMI.STATUS = '1' AND MOUSIKOMI.UKETSUKE_JYOTAI = '1')");
				sql.append(" OR (MOUSIKOMI.STATUS = '1' AND MOUSIKOMI.UKETSUKE_JYOTAI = '2')");
				sql.append(" OR (MOUSIKOMI.STATUS = '1' AND MOUSIKOMI.UKETSUKE_JYOTAI = '3')");
				sql.append(" OR (MOUSIKOMI.STATUS = '1' AND MOUSIKOMI.UKETSUKE_JYOTAI = '4')) ");
				
				Log.debug(sql.toString());
				
				PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
				con     = locator.getDataSource(  ).getConnection(  );
				ps      = con.prepareStatement( sql.toString(  ) );
				
				ps.setString( 1, classBean.getKamokuBean().getKamokuCode() );
				ps.setString( 2, classBean.getClassCode());

				ResultSet rs = ps.executeQuery(  );

				Vector ret = new Vector(  );

				String count = null;
				while ( rs.next(  ) ) {
					count = rs.getString("count");
				}

				if(count == null || count.equals("")){
					count = "0";
				}
				
				Log.debug("count = " + count);
				classBean.setMousikomisya(count);
				
				/*���\�b�h�g���[�X�o��*/
				Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

				return classBean;
				
			} catch ( NamingException e ) {
				Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
				throw new EJBException( e );
			} catch ( SQLException e ) {
				Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
				throw new EJBException( e );
			} catch ( RuntimeException e ) {
				Log.error( loginuser.getSimeiNo(  ), "", e );
				throw e;
			} finally {
				if ( ps != null ) {
					try {
						ps.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}

				if ( con != null ) {
					try {
						con.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}
			}
	}

	/**
	 * ��u�Ґ����J�E���g���܂��B
	 * @param classBean
	 * @param loginuser
	 * @return classBean
	 * @throws PCY_WarningException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_ClassBean doCountJyukosya( PCY_ClassBean classBean ,PCY_PersonalBean loginuser){

			Connection con       = null;
			PreparedStatement ps = null;
		    PreparedStatement ps1 = null;
			int kaisibiNum       = 3; // CHG#P-PLP02-014-001
			int syuryobiNum;
			int simeiNoNum;
			int statusNum;
			int kamokuCodeNum;

			try {
				/*���\�b�h�g���[�X�o��*/
				Log.method( loginuser.getSimeiNo(  ), "IN", "" );

				StringBuffer sql = new StringBuffer(  );
				sql.append( "SELECT COUNT(*) count"); 
				sql.append( " FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( " WHERE  MOUSIKOMI.KAMOKU_CODE    = ?" ); 
				sql.append( "   AND MOUSIKOMI.CLASS_CODE = ? "  );
				
				sql.append(" AND ( (MOUSIKOMI.STATUS = '2' AND MOUSIKOMI.UKETSUKE_JYOTAI IS NULL)");
				sql.append(" OR (MOUSIKOMI.STATUS = '3' AND MOUSIKOMI.UKETSUKE_JYOTAI IS NULL))");
				Log.debug(sql.toString());
								
				PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
				con     = locator.getDataSource(  ).getConnection(  );
				ps      = con.prepareStatement( sql.toString(  ) );
				ps.setString( 1, classBean.getKamokuBean().getKamokuCode() );
				ps.setString( 2, classBean.getClassCode());

				ResultSet rs = ps.executeQuery(  );

				Vector ret = new Vector(  );

				String count = null;
				while ( rs.next(  ) ) {
					count = rs.getString("count");
				}
				
				if(count == null || count.equals("")){
					count = "0";
				}
				
				
				Log.debug("��u�� L15 count = " + count);
				
				StringBuffer sqlL51 = new StringBuffer(  );
				sqlL51.append( "SELECT COUNT(*) count"); 
				sqlL51.append( " FROM " );
				sqlL51.append( HcdbDef.L51_TBL + " ");
				sqlL51.append( " WHERE  KAMOKU_CODE    = ?" ); 
				sqlL51.append( "   AND CLASS_CODE = ? "  );
				sqlL51.append(" AND ( SYURYO_HANTEI = '0' ");
				sqlL51.append(" OR SYURYO_HANTEI = '1' )");
				
				Log.debug(sqlL51.toString());
				
				ps1      = con.prepareStatement( sqlL51.toString(  ) );
				ps1.setString( 1, classBean.getKamokuBean().getKamokuCode() );
				ps1.setString( 2, classBean.getClassCode());

				ResultSet rsL51 = ps1.executeQuery(  );

				Vector retL51 = new Vector(  );

				String countL51 = null;
				while ( rsL51.next(  ) ) {
					countL51 = rsL51.getString("count");
				}
				
				if(countL51 == null || countL51.equals("")){
					countL51 = "0";
				}
				
				Log.debug("��u�� L51 count = " + countL51);
				
				int countAll = Integer.valueOf(count).intValue() + Integer.valueOf(countL51).intValue(); 
				
				Log.debug("��u�� count = " + countAll);
				
				String countAllStr = (new Integer(countAll)).toString();
				classBean.setJyukosya(countAllStr);
				
				/*���\�b�h�g���[�X�o��*/
				Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

				return classBean;
				
			} catch ( NamingException e ) {
				Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
				throw new EJBException( e );
			} catch ( SQLException e ) {
				Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
				throw new EJBException( e );
			} catch ( RuntimeException e ) {
				Log.error( loginuser.getSimeiNo(  ), "", e );
				throw e;
			} finally {
				if ( ps != null ) {
					try {
						ps.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}
				if( ps1 != null ) {
					try{
						ps1.close();
						
					} catch ( SQLException e ) {
					// �������Ȃ�
					}
				}
				if ( con != null ) {
					try {
						con.close(  );
					} catch ( SQLException e ) {
						// �������Ȃ�
					}
				}
			}
	}

	/**
	 * �ȖڃR�[�h�ƃN���X�R�[�h���L�[�Ɍ��C�Ǘ������擾���A
	 * PCY_KensyuKanriJohoBean�Ɋi�[���܂��B
	 * �X�e�[�^�X�A��t��ԃL�[�̎w�肪����ꍇ�́A�w��L�[�Ő\�������擾���A
	 * PCY_KensyuKanriJohoBean�Ɋi�[���܂��B
	 * ���C�Ǘ����̈ꗗ��Ԃ��܂��B
	 *
	 * @param kamokuCode 		�ȖڃR�[�h
	 * @param classCode 		�N���X�R�[�h
	 * @param status 			�X�e�[�^�X
	 * @param uketsukeJyotai	��t���
	 * @param loginuser 		���O�C�����[�U���
	 * @return PCY_KensyuKanriJohoBean[] ���C�Ǘ����ꗗ
	 * @throws NamingException ���O������O
	 * @throws RemoteException �����[�g��O
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_KensyuKanriJohoBean[] getKensyuKanriJoho( 
		String kamokuCode, String classCode, String status, String uketsukeJyotai,
		PCY_PersonalBean loginuser )
		throws NamingException, RemoteException {
		Connection con       = null;
		PreparedStatement ps = null;
		Collection ret   = new ArrayList(  );

		try {
			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			String sql = "SELECT " + PCY_MousikomiJyokyoBean.getColumns( "mousikomi" ) + ", "
				+ PCY_PersonalBean.getColumns( "personal" ) + ", "
				+ PCY_TaisyosyokusyuBean.getColumns( "syokusyu" ) + ", "
				+ PCY_TaisyososikiBean.getColumns( "sosiki" ) + ", "
				+ PCY_TaisyosyaBean.getColumns( "taisyosya" ) + ", "
				+ PCY_KensyuRirekiBean.getSyuryoHanteiColumns("kyoikurireki") 
				+ " FROM " + HcdbDef.L15_TBL
				+ " mousikomi" + " INNER JOIN " + HcdbDef.personalTbl + " personal"
				+ "   ON personal.SIMEI_NO = mousikomi.SIMEI_NO" + " LEFT OUTER JOIN "
				+ HcdbDef.L12_TBL + " syokusyu"
				+ "   ON  mousikomi.KAMOKU_CODE = syokusyu.KAMOKU_CODE"
				+ "   AND mousikomi.CLASS_CODE  = syokusyu.CLASS_CODE"
				+ "   AND personal.SYOKU_CODE1  = syokusyu.SYOKU_CODE"
				+ "   AND personal.SENMON_CODE1 = syokusyu.SENMON_CODE"
				+ "   AND personal.LEVEL_CODE1  = syokusyu.LEVEL_CODE" + " LEFT OUTER JOIN "
				+ HcdbDef.L13_TBL + " sosiki" + "   ON  mousikomi.KAMOKU_CODE = sosiki.KAMOKU_CODE"
				+ "   AND mousikomi.CLASS_CODE  = sosiki.CLASS_CODE"
				+ "   AND trim(personal.SOSIKI_CODE)  = sosiki.SOSIKI_CODE" + " LEFT OUTER JOIN "
				+ HcdbDef.L14_TBL + " taisyosya"
				+ "   ON  mousikomi.KAMOKU_CODE = taisyosya.KAMOKU_CODE"
				+ "   AND mousikomi.CLASS_CODE  = taisyosya.CLASS_CODE"
				+ "   AND personal.SIMEI_NO     = taisyosya.SIMEI_NO" + " LEFT OUTER JOIN "
				+ HcdbDef.L51_TBL + " kyoikurireki"
				+ "   ON kyoikurireki.KAMOKU_CODE = mousikomi.KAMOKU_CODE "
				+ "   AND kyoikurireki.CLASS_CODE = mousikomi.CLASS_CODE "
				+ "   AND kyoikurireki.SIMEI_NO = mousikomi.SIMEI_NO" 
				+ " WHERE personal.HONMU_FLG    = '" + HcdbDef.HONMU + "' "
				+ "   AND mousikomi.KAMOKU_CODE = ? AND mousikomi.CLASS_CODE = ?";
			;
			if ( status !=  null && !status.equals("")){
				sql	= sql + "   AND mousikomi.STATUS  			= ? " ;
			}
			if ( uketsukeJyotai !=  null && !uketsukeJyotai.equals("")){
				sql	= sql + "   AND mousikomi.UKETSUKE_JYOTAI 	= ? " ;
			}

			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con = locator.getDataSource(  ).getConnection(  );

			// �������s
			Log.debug( sql );
			ps = con.prepareStatement( sql );
			ps.setString( 1, kamokuCode );
			ps.setString( 2, classCode );
			Log.debug( "kamokuCode:[" + kamokuCode + "] classCode:[" + classCode +"]");
			int index = 2;
			if ( status !=  null && !status.equals("")){
				index = index + 1 ;
				ps.setString( index , status );
				Log.debug( "status:[" + status + "]");
			}
			if ( uketsukeJyotai !=  null && !uketsukeJyotai.equals("")){
				index = index + 1 ;
				ps.setString( index , uketsukeJyotai );
				Log.debug( "uketsukeJyotai:[" + uketsukeJyotai + "]");
			}

			ResultSet rs = ps.executeQuery(  );

			List taisyosyaList = new ArrayList(  );

			while ( rs.next(  ) ) {
				PCY_KensyuKanriJohoBean taisyosya = new PCY_KensyuKanriJohoBean(  );

				PCY_MousikomiJyokyoBean mousikomiBean = new PCY_MousikomiJyokyoBean( rs, "mousikomi" );
				mousikomiBean.setPersonalBean( new PCY_PersonalBean( rs, "personal" ) );
				taisyosya.setMousikomiBean( mousikomiBean );
				taisyosya.getTaisyousyaBean(  ).setTaisyoKubun( PCY_TaisyoBeanImpl.getTaisyoKubun( 
						rs.getString( "syokusyu_taisyo_kubun" ),
						rs.getString( "sosiki_taisyo_kubun" ),
						rs.getString( "taisyosya_taisyo_kubun" ) ) );

				taisyosyaList.add( taisyosya );
			}

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            PCY_KensyuKanriJohoBean[] beans = new PCY_KensyuKanriJohoBean[taisyosyaList.size(  )];
            return ( PCY_KensyuKanriJohoBean[] )taisyosyaList.toArray( beans );
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * �ȖڃR�[�h�ƃN���X�R�[�h���L�[�ɐ\���󋵃e�[�u������\�������擾���A
	 * PCY_MousikomiJyokyoBean�Ɋi�[���܂��B
	 * �X�e�[�^�X�A��t��ԃL�[�̎w�肪����ꍇ�́A�w��L�[�Ő\�������擾���A
	 * PCY_MousikomiJyokyoBean�Ɋi�[���܂��B
	 * �\�����̈ꗗ��Ԃ��܂��B
	 *
	 * @param kamokuCode 		�ȖڃR�[�h
	 * @param classCode 		�N���X�R�[�h
	 * @param status 			�X�e�[�^�X
	 * @param uketsukeJyotai	��t���
	 * @param loginuser 		���O�C�����[�U���
	 * @return PCY_MousikomiJyokyoBean[] �\�����ꗗ
	 * @throws NamingException ���O������O
	 * @throws RemoteException �����[�g��O
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_MousikomiJyokyoBean[] getMousikomi( 
		String kamokuCode, String classCode, String status, String uketsukeJyotai,
		PCY_PersonalBean loginuser )
		throws NamingException, RemoteException {
		Connection con       = null;
		PreparedStatement ps = null;
		Collection ret   = new ArrayList(  );

		try {
			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			String sql = "SELECT " 
				+ PCY_MousikomiJyokyoBean.getColumns( "L15" )
				+ " FROM " + HcdbDef.L15_TBL + " L15 "
				+ " WHERE L15.KAMOKU_CODE	= ? "
				+ "   AND L15.CLASS_CODE	= ? "
			;
			if ( status !=  null && !status.equals("")){
				sql	= sql + "   AND L15.STATUS  			= ? " ;
			}
			if ( uketsukeJyotai !=  null && !uketsukeJyotai.equals("")){
				sql	= sql + "   AND L15.UKETSUKE_JYOTAI 	= ? " ;
			}

			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con = locator.getDataSource(  ).getConnection(  );

			// �������s
			Log.debug( sql );
			ps = con.prepareStatement( sql );
			ps.setString( 1, kamokuCode );
			ps.setString( 2, classCode );
			Log.debug( "kamokuCode:[" + kamokuCode + "] classCode:[" + classCode +"]");
			int index = 2;
			if ( status !=  null && !status.equals("")){
				index = index + 1 ;
				ps.setString( index , status );
				Log.debug( "status:[" + status + "]");
			}
			if ( uketsukeJyotai !=  null && !uketsukeJyotai.equals("")){
				index = index + 1 ;
				ps.setString( index , uketsukeJyotai );
				Log.debug( "uketsukeJyotai:[" + uketsukeJyotai + "]");
			}

			ResultSet rs = ps.executeQuery(  );

			while ( rs.next(  ) ) {
				ret.add( new PCY_MousikomiJyokyoBean( rs, "L15" ) );
			}

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return ( PCY_MousikomiJyokyoBean[] )ret.toArray( new PCY_MousikomiJyokyoBean[0] );
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * �ȖڃR�[�h�ƃN���X�R�[�h���L�[��L51_���猤�C���e�[�u�����̎�u�Ґ���Ԃ��܂��B
	 *
	 * @param kamokuCode �ȖڃR�[�h
	 * @param classCode �N���X�R�[�h
	 * @param loginuser ���O�C�����[�U���
	 * @return ��u�Ґ�
	 * @throws NamingException ���O������O
	 * @throws RemoteException �����[�g��O
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int countClassL51( String kamokuCode, String classCode, PCY_PersonalBean loginuser )
		throws NamingException, RemoteException {
		Connection con       = null;
		PreparedStatement ps = null;
		try {

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );
		
			int count = 0;
			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con = locator.getDataSource(  ).getConnection(  );

			// SQL�쐬
			StringBuffer sql = new StringBuffer(  );
			sql.append( "SELECT " );
			sql.append( "count(*) count");
			sql.append( " FROM ");
			sql.append( HcdbDef.L51_TBL );
			sql.append( " WHERE KAMOKU_CODE=?" );
			sql.append( " AND	 CLASS_CODE=?" );

			/* �f�o�b�O���O */
			Log.debug( sql.toString(  ) );

			ps = con.prepareStatement( sql.toString(  ) );

			ps.setString( 1, kamokuCode);
			ps.setString( 2, classCode);
			ResultSet rs = ps.executeQuery(  );
            
			rs.next(  );
			count = rs.getInt("count");
			Log.debug( "count:" + count );

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return count;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}			
			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * �ȖڃR�[�h�ƃN���X�R�[�h�A��t��ԁA�X�e�[�^�X���L�[��L15_�\���󋵃e�[�u�����̌��C�Ґ���Ԃ��܂��B
	 *
	 * @param kamokuCode �ȖڃR�[�h
	 * @param classCode �N���X�R�[�h
	 * @param loginuser ���O�C�����[�U���
	 * @return ���C�Ґ�
	 * @throws NamingException ���O������O
	 * @throws RemoteException �����[�g��O
     * @ejb.interface-method
     * @ejb.transaction type="Required"
	 */
	public int countClassL15( String kamokuCode, String classCode, String uketsukeJyotai, String status, PCY_PersonalBean loginuser )
		throws NamingException, RemoteException {
		Connection con       = null;
		PreparedStatement ps = null;
		try {

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );
		
			int count = 0;
			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con = locator.getDataSource(  ).getConnection(  );

			// SQL�쐬
			StringBuffer sql = new StringBuffer(  );
			sql.append( "SELECT " );
			sql.append( "count(*) count");
			sql.append( " FROM ");
			sql.append( HcdbDef.L15_TBL );
			sql.append( " WHERE KAMOKU_CODE=?" );
			sql.append( " AND	 CLASS_CODE=?" );
			if ( uketsukeJyotai != null && !uketsukeJyotai.equals("")){
				sql.append( " AND	 UKETSUKE_JYOTAI=?" );
			}
			if ( status != null && !status.equals("")){
				sql.append( " AND	 STATUS=?" );
			}

			/* �f�o�b�O���O */
			Log.debug( sql.toString(  ) );

			ps = con.prepareStatement( sql.toString(  ) );

			ps.setString( 1, kamokuCode);
			ps.setString( 2, classCode);
			int index = 2;
			if ( uketsukeJyotai != null && !uketsukeJyotai.equals("")){
				index = index + 1 ;
				ps.setString( index , uketsukeJyotai);
			}
			if ( status != null && !status.equals("")){
				index = index + 1 ;
				ps.setString( index , status);
			}
			ResultSet rs = ps.executeQuery(  );
            
			rs.next(  );
			count = rs.getInt("count");
			Log.debug( "count:" + count );

			/*���\�b�h�g���[�X�o��*/
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return count;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}			
			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * ���\���҂��������A�Ԃ��܂�
	 *
	 * @param PCY_ClassBean[] 		�N���XBeans
	 * @param loginuser 		���O�C�����[�U���
	 * @return PCY_ClassBean[] �N���XBeans
	 * @throws EJBException 
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_ClassBean[] getMiMousikomi( PCY_ClassBean[] classBeans,PCY_PersonalBean loginuser )
		throws EJBException {

			try {
				PCY_ClassBean[] ret_classBeans = null;
				PCY_MousikomiJyokyoBean kensaku_mousikomi = new PCY_MousikomiJyokyoBean();
				PCY_KensyuRirekiBean kensaku_rireki = new PCY_KensyuRirekiBean();
				
				ArrayList retClass = new ArrayList();
				
				PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
				PCY_TaisyoEJBHome home_taisyo = (PCY_TaisyoEJBHome)locator.getServiceLocation(
																"PCY_TaisyoEJB",
																 PCY_TaisyoEJBHome.class );
				PCY_TaisyoEJB ejb_taisyo = home_taisyo.create();
				
				
				for(int i=0 ; i < classBeans.length; i++){
					if(classBeans[i].getZensyaTaisyoFlg().equals("1")){//�S�БΏ�
						kensaku_mousikomi.setClassBean(classBeans[i]);
						kensaku_rireki.setClassCode(classBeans[i].getClassCode());
						kensaku_rireki.setKamokuCode(classBeans[i].getKamokuBean().getKamokuCode());
							
						PCY_MousikomiJyokyoBean[] mousikomiBeans = this.getList(kensaku_mousikomi,loginuser);
						PCY_KensyuRirekiBean[] rirekiBeans = this.getListL51(kensaku_rireki,loginuser);
						if((mousikomiBeans == null || mousikomiBeans.length == 0) && (rirekiBeans == null || rirekiBeans.length == 0)){
							//L15�AL51���e�[�u���Ƀf�[�^���ꌏ��������΁A�f�[�^�ێ�
							retClass.add(classBeans[i]);
						}
																
					}else{//��S�БΏ�
						PCY_TaisyosyaBean[] taisyo =  ejb_taisyo.getAllTaisyosya(classBeans[i],false,loginuser);
						for(int t = 0; t < taisyo.length ; t++){
								
							kensaku_mousikomi.setClassBean(taisyo[t].getClassBean());
							kensaku_mousikomi.setSimeiNo(taisyo[t].getSimeiNo());
							kensaku_rireki.setClassCode(taisyo[t].getClassBean().getClassCode());
							kensaku_rireki.setKamokuCode(taisyo[t].getClassBean().getKamokuBean().getKamokuCode());
							kensaku_rireki.setSimeiNo(taisyo[t].getSimeiNo());
								
							PCY_MousikomiJyokyoBean[] mousikomiBeans = this.getList(kensaku_mousikomi,loginuser);
							PCY_KensyuRirekiBean[] rirekiBeans = this.getListL51(kensaku_rireki,loginuser);
							if((mousikomiBeans == null || mousikomiBeans.length == 0) && (rirekiBeans == null || rirekiBeans.length == 0)){
								//L15�AL51���e�[�u���Ƀf�[�^���ꌏ�������A�ێ����Ă���List�Ƀf�[�^���Ȃ���΁A�f�[�^�ێ�
								if(!retClass.contains(classBeans[i])){
									retClass.add(classBeans[i]);
								}
									
							}
						}
							
					}
				}
				ret_classBeans = ( PCY_ClassBean[] )retClass.toArray( new PCY_ClassBean[0] );
				return ret_classBeans;
			} catch (RemoteException e) {
				throw new EJBException( e );
			} catch (NamingException e) {
				throw new EJBException( e );
			} catch (CreateException e) {
				throw new EJBException( e );
			}
	}

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }
    
    /* Comparator �\���󋵏����Ƀ\�[�g���܂��B*/
	private class MousikomiJokyoComparator implements Comparator {
		public int compare( Object o1, Object o2 ) {
			PCY_KensyuKanriJohoBean kensyukanrijoho1 = ( PCY_KensyuKanriJohoBean )o1;
			PCY_KensyuKanriJohoBean kensyukanrijoho2 = ( PCY_KensyuKanriJohoBean )o2;

			PCY_MousikomiJyokyoBean mousikomi1 = kensyukanrijoho1.getMousikomiBean();
			PCY_MousikomiJyokyoBean mousikomi2 = kensyukanrijoho2.getMousikomiBean();
			
			int ret = 0;
			if(mousikomi1 != null && mousikomi2 != null){
				String jyokyo1 = mousikomi1.getMousikomijyokyo();
				String jyokyo2 = mousikomi2.getMousikomijyokyo();
				if(jyokyo1 != null && jyokyo2 != null && (!jyokyo1.equals("") && !jyokyo2.equals(""))){
					//�\���󋵂Ń\�[�g����
					ret = jyokyo1.compareTo(jyokyo2);
				}else if(jyokyo1 != null && jyokyo2 != null && (jyokyo1.equals("") || jyokyo2.equals(""))){
					//�\���󋵂�""�̏ꍇ�͎�u�󋵂Ń\�[�g����(�񍐑ҁ������)
					
					String jyukojyokyo1 = mousikomi1.getJyukoJyokyo();
					String jyukojyokyo2 = mousikomi2.getJyukoJyokyo();
					if(jyukojyokyo1 != null && jyukojyokyo2 != null && (!jyukojyokyo1.equals("") && !jyukojyokyo2.equals(""))){
						ret = jyukojyokyo1.compareTo(jyukojyokyo2);
					}else if(jyukojyokyo1 != null && jyukojyokyo2 != null && (jyukojyokyo1.equals("") || jyukojyokyo2.equals(""))){
						ret = 1;
					}
				}else{
					//�C������Ń\�[�g
					String syuryoHantei1 = kensyukanrijoho1.getKensyurirekiBean().getSyuryoHantei();
					String syuryoHantei2 = kensyukanrijoho2.getKensyurirekiBean().getSyuryoHantei();
					
					if(syuryoHantei1 != null && syuryoHantei2 != null){
						ret = syuryoHantei1.compareTo(syuryoHantei2);
					}else if(syuryoHantei1 == null && syuryoHantei2 != null){
						ret = -1;
					}else if(syuryoHantei1 != null && syuryoHantei2 == null){
						ret=1;
					}


				}
			}else{
				ret = 1;
			}
			return ret;
		}
	}
}
