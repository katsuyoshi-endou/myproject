/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/04/14             ���Y�@�T��    �V�K�쐬
 *   2005/11/08             QUANLA       sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */
package jp.co.hisas.career.learning.base.servlet;

import com.lowagie.text.DocumentException;

import jp.co.hisas.career.base.sosiki.bean.SosikiBean;
import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.bean.PCY_CodeBean;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.pdf.PZE120_SyussekiMeiboPDF;
import jp.co.hisas.career.util.property.HcdbDef;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import java.rmi.*;

import java.util.Map;

import javax.ejb.*;

import javax.naming.*;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.*;


/**
 *<PRE>
 *
 * �T�v�F
 *   �o�ȎҖ����PDF�쐬���s���B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 *
 *</PRE>
 */
public class PCY172_SyussekiMeiboPdfServlet extends PCY010_ControllerServlet {
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PCY_PersonalBean loginuser )
        throws NamingException, CreateException, RemoteException, PCY_WarningException, IOException, 
            DocumentException, Exception {
        /*���\�b�h�g���[�X�o��*/
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );
        Log.performance( loginuser.getSimeiNo(  ), true, "" );

        try {
            /* �g�D�}�b�v�擾 */
            Map sosikiMap = PCY_CodeBean.getInstance(  ).getCodeMap( PCY_CodeBean.SOSIKI );

            PCY_ServiceLocator locator   = PCY_ServiceLocator.getInstance(  );
            PCY_TaisyoEJBHome taisyoHome = ( PCY_TaisyoEJBHome )locator.getServiceLocation( "PCY_TaisyoEJB",
                    PCY_TaisyoEJBHome.class );
            PCY_TaisyoEJB taisyoEJB = taisyoHome.create(  );

            PCY_ClassEJBHome classHome = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
                    PCY_ClassEJBHome.class );

            PCY_ClassEJB classEJB = classHome.create(  );

            PCY_ClassBean classBean = classEJB.doSelectByPrimaryKey( new PCY_ClassBean( request ),
                    loginuser );

            PCY_TaisyosyaBean[] taisyosyaBeans = taisyoEJB.getAllTaisyosya( classBean, false,
                    loginuser );

            String[] sosikiMei = new String[taisyosyaBeans.length];

            for ( int i = 0; i < taisyosyaBeans.length; i++ ) {
                sosikiMei[i] = SosikiBean.getSosikiKaisouNameByCode( taisyosyaBeans[i].getPersonalBean(  )
                                                                                      .getSosikiCode(  ),
                        loginuser.getSimeiNo(  ) );
            }

            /* �t�@�C���ǂݍ��ݗp�o�b�t�@ */
            byte[] buffer = new byte[4096];

            /* �t�@�C�����e�̏o�� */
            ServletOutputStream out = response.getOutputStream(  );

            /* PDF�쐬 */
            PZE120_SyussekiMeiboPDF pdf = new PZE120_SyussekiMeiboPDF(  );

            /* contentType���o�� */
            response.setContentType( "application/pdf" );

            /* �t�@�C�����̑��M(attachment������inline�ɕύX����΃C�����C���\��) */
            response.setHeader( "Content-Disposition", "inline;" );

            ByteArrayOutputStream baos = new ByteArrayOutputStream(  );
            boolean pdfOutput          = pdf.makePDF( baos, classBean, taisyosyaBeans, sosikiMei,
                    loginuser );
            ByteArrayInputStream bais  = new ByteArrayInputStream( baos.toByteArray(  ) );

            if ( !pdfOutput ) {
                /* �G���[��ʂɑJ�� */
                //response.sendRedirect( "/" + HcdbDef.root + "/view/Error.jsp" );	//2005/11/08_LYCE_R_QUANLA
                this.getServletConfig( ).getServletContext( ).getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            }

            if ( bais != null ) {
                int size;

                while ( ( size = bais.read( buffer ) ) != -1 ) {
                    out.write( buffer, 0, size );
                }

                bais.close(  );
            }

            out.close(  );
            response.flushBuffer(  );

            Log.performance( loginuser.getSimeiNo(  ), false, "" );

            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return null;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw e;
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } catch ( IOException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0012", e );
            throw e;
        } catch ( DocumentException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } catch ( Exception e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        }
    }
}
