/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 * 
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/07/30  01.00      �n�� ��q    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.*;
import javax.ejb.*;
import javax.naming.*;
import javax.servlet.http.*;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;

/**
 *<PRE>
 *
 * �N���X���F
 *   PCY301_MousikomiTorikesiServlet �N���X
 *
 * �@�\�����F
 *   �\������������s���܂��B
 *
 *</PRE>
 */
public class PCY301_MousikomiTorikesiServlet extends PCY010_ControllerServlet {

    protected String execute( HttpServletRequest request, HttpServletResponse response, PCY_PersonalBean loginuser )
        throws NamingException, CreateException, RemoteException, PCY_WarningException {

        // Log�o��
        Log.method     ( loginuser.getSimeiNo(), "IN", "" );
        Log.performance( loginuser.getSimeiNo(), true, "" );

        String kamokuCode     = ( String )request.getParameter( "kamoku_code"  );
        String classCode      = ( String )request.getParameter( "class_code"   );
        String simeiNo        = ( String )request.getParameter( "simei_no"     );
        String kousinbi       = ( String )request.getParameter( "kousinbi"     );
        String kousinjikoku   = ( String )request.getParameter( "kousinjikoku" );

        PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
        PCY_ClassEJBHome homeClass = (PCY_ClassEJBHome)locator.getServiceLocation(
                                     "PCY_ClassEJB", PCY_ClassEJBHome.class );
        PCY_ClassEJB ejbClass = homeClass.create();

        PCY_MousikomiJyokyoBean mousikomiJyokyoBean = new PCY_MousikomiJyokyoBean();
        PCY_ClassBean           classBeanDummy      = new PCY_ClassBean();

        classBeanDummy.getKamokuBean().setKamokuCode( kamokuCode );
        classBeanDummy.setClassCode( classCode );

        Log.transaction( loginuser.getSimeiNo(), true, ""  );
        PCY_ClassBean classBean = ejbClass.doSelectByPrimaryKey( classBeanDummy, loginuser );
        Log.transaction( loginuser.getSimeiNo(), false, "" );

        // �N���X��񂪌�����Ȃ������ꍇ
        if ( classBean == null ) {
            throw new PCY_WarningException();
        }

        mousikomiJyokyoBean.setClassBean     ( classBean    );
        mousikomiJyokyoBean.setKamokuCode    ( kamokuCode   );
        mousikomiJyokyoBean.setClassCode     ( classCode    );
        mousikomiJyokyoBean.setSimeiNo       ( simeiNo      );
        mousikomiJyokyoBean.setKousinbi      ( kousinbi     );
        mousikomiJyokyoBean.setKousinjikoku  ( kousinjikoku );
        mousikomiJyokyoBean.setStatus        ( "1" );
        mousikomiJyokyoBean.setUketsukeJyotai( "3" );

        PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome)locator.getServiceLocation(
                                           "PCY_MousikomiJyokyoEJB", PCY_MousikomiJyokyoEJBHome.class );
        PCY_MousikomiJyokyoEJB ejb = home.create();
        
        Log.transaction( loginuser.getSimeiNo(), true, "" );
        ejb.doUpdateReceiptStatus( new PCY_MousikomiJyokyoBean[] { mousikomiJyokyoBean }, loginuser );
        Log.transaction( loginuser.getSimeiNo(), false, "" );

        /*���\�b�h�g���[�X�o��*/
        Log.performance( loginuser.getSimeiNo(), false, "" );
        Log.method( loginuser.getSimeiNo(), "OUT", "" );

        return getForwardPath();
    }

}
