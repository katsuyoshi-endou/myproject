/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/04/19  01.00       ���� ����    �V�K�쐬
 *   2004/06/27              ���� ���V�@�@�e���v���[�g�C���Ή�
 *   2004/10/29              ���� ���V    �Ȗڏ��ێ��ɑΉ�
 *   2005/11/11              ���Y �T��    �N���X�̔��l����ǉ�
 */
package jp.co.hisas.career.learning.base.valuebean;

import jp.co.hisas.career.learning.base.bean.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.property.*;

import java.io.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_ClassBeanForMail �N���X
 *
 * �@�\�����F
 *   ���[���@�\�p�ɃN���X����ێ�����ValueBean�ł��B
 *
 *</PRE>
 */
public class PCY_ClassBeanForMail implements Serializable {
    private PCY_KamokuBeanForMail kamokuBeanForMail = null;
    private String classMei                         = null;
    private String kaisibi                          = null;
    private String syuryobi                         = null;
    private String kaisijikoku                      = null;
    private String syuryojikoku                     = null;
    private String chikuMei                         = null;
    private String kyosituMei                       = null;
    private String kousiMei                         = null;
    private String mousikomiKubun                   = null;
    private String mousikomiKubunMei                = null;
    private String mousikomiKaisibi                 = null;
    private String mousikomiSyuryobi                = null;
    private String teiin                            = null;
    private String houkokuKubunMei                  = null;
    private String syoninKubunMei                   = null;
    private String nissu							 = null;
    private String bikou                            = null;  // INS#P-A30AM1-004
    

    public PCY_ClassBeanForMail( PCY_ClassBean classBean ) {
        /* �Ȗڏ����Z�b�g���� */
        setKamokuBeanForMail( new PCY_KamokuBeanForMail( classBean.getKamokuBean(  ) ) );

        /* �N���X�����Z�b�g���� */
        setClassMei( classBean.getClassMei(  ) );

        /* �J�n�����Z�b�g���� */
        setKaisibi( PZZ010_CharacterUtil.ChangeYmd( classBean.getKaisibi(  ) ) );

        /* �I�������Z�b�g���� */
        setSyuryobi( PZZ010_CharacterUtil.ChangeYmd( classBean.getSyuryobi(  ) ) );

        /* �J�Î������Z�b�g���� */
        setKaisijikoku( PZZ010_CharacterUtil.ChangeHm( classBean.getKaisijikoku(  ) ) );

        /* �I���������Z�b�g���� */
        setSyuryojikoku( PZZ010_CharacterUtil.ChangeHm( classBean.getSyuryojikoku(  ) ) );

        /* �n�於���Z�b�g���� */
        setChikuMei( PCY_CodeBean.getInstance(  ).getValue( PCY_CodeBean.CHIKU,
                classBean.getChikuCode(  ) ) );

        if ( getChikuMei(  ) == null ) {
            setChikuMei( classBean.getChikuMei(  ) );
        }

        /* ���������Z�b�g���� */
        setKyosituMei( PCY_CodeBean.getInstance(  ).getValue( PCY_CodeBean.KYOSITU,
                classBean.getKyosituCode(  ) ) );

        if ( getKyosituMei(  ) == null ) {
            setKyosituMei( classBean.getKyosituMei(  ) );
        }

        /* �u�t�����Z�b�g���� */
        setKousiMei( PCY_CodeBean.getInstance(  ).getValue( PCY_CodeBean.KOUSI,
                classBean.getKousiCode(  ) ) );

        if ( getKousiMei(  ) == null ) {
            setKousiMei( classBean.getKousiMei(  ) );
        }

        /* �\���敪���Z�b�g���� */
        setMousikomiKubun( classBean.getMousikomiKubun(  ) );

        /* �\���敪�����Z�b�g���� */
        setMousikomiKubunMei( PCY_CodeBean.getInstance(  ).getValue( PCY_CodeBean.MOUSIKOMI_KUBUN,
                classBean.getMousikomiKubun(  ) ) );

        /* �\���J�n�����Z�b�g���� */
        setMousikomiKaisibi( PZZ010_CharacterUtil.ChangeYmd( classBean.getMousikomiKaisibi(  ) ) );

        /* �\���I�������Z�b�g���� */
        setMousikomiSyuryobi( PZZ010_CharacterUtil.ChangeYmd( classBean.getMousikomiSyuryobi(  ) ) );

        /* ������Z�b�g���� */
        setTeiin( ( classBean.getTeiin(  ) != null ) ? classBean.getTeiin(  ).toString(  ) : "" );

        /* �񍐋敪�����Z�b�g���� */
        setHoukokuKubunMei( PCY_CodeBean.getInstance(  ).getValue( PCY_CodeBean.HOUKOKU_KUBUN,
                classBean.getHoukokuKubun(  ) ) );

        /* ���F�敪�����Z�b�g���� */
        setSyoninKubunMei( PCY_CodeBean.getInstance(  ).getValue( PCY_CodeBean.SYONIN_KUBUN,
                classBean.getSyoninKubun(  ) ) );
                
        /* �������Z�b�g���� */
        setNissu(( classBean.getNissuu() != null ) ? classBean.getNinsyoKubun().toString() : "");
        
        // INS#P-A30AM1-004-S
        /* ���l���Z�b�g���� */
        setBikou( classBean.getBikou() );
        // INS#P-A30AM1-004-E
    }

    public static String getClassTitle(  ) {
        return ( String )ReadFile.paramMapData.get( "DZZ077" );
    }

    public static String getKaisaibiTitle(  ) {
        return ( String )ReadFile.paramMapData.get( "DZZ303" );
    }

    public static String getKaisaijikokuTitle(  ) {
        return ( String )ReadFile.paramMapData.get( "DZZ305" );
    }

    public static String getKaisaibasyoTitle(  ) {
        return ( String )ReadFile.paramMapData.get( "DZZ312" );
    }

    public static String getKyosituTitle(  ) {
        return ( String )ReadFile.paramMapData.get( "DZZ313" );
    }

    public static String getMousikomikubunTitle(  ) {
        return ( String )ReadFile.paramMapData.get( "DZZ317" );
    }

    public static String getMousikomikikanTitle(  ) {
        return ( String )ReadFile.paramMapData.get( "DZZ308" );
    }

    /**
     * @return
     */
    public String getChikuMei(  ) {
        return chikuMei;
    }

    /**
     * @return
     */
    public String getClassMei(  ) {
        return classMei;
    }

    /**
     * @return
     */
    public String getKaisibi(  ) {
        return kaisibi;
    }

    /**
     * @return
     */
    public String getKaisijikoku(  ) {
        return kaisijikoku;
    }

    /**
     * @return
     */
    public String getKousiMei(  ) {
        return kousiMei;
    }

    /**
     * @return
     */
    public String getKyosituMei(  ) {
        return kyosituMei;
    }

    /**
     * @return
     */
    public String getMousikomiKaisibi(  ) {
        return mousikomiKaisibi;
    }

    /**
     * @return
     */
    public String getMousikomiKubun(  ) {
        return mousikomiKubun;
    }

    /**
     * @return
     */
    public String getMousikomiSyuryobi(  ) {
        return mousikomiSyuryobi;
    }

    /**
     * @return
     */
    public String getSyuryobi(  ) {
        return syuryobi;
    }

    /**
     * @return
     */
    public String getSyuryojikoku(  ) {
        return syuryojikoku;
    }

    /**
     * @return
     */
    public String getTeiin(  ) {
        return teiin;
    }

    /**
     * @param string
     */
    public void setChikuMei( String string ) {
        chikuMei = string;
    }

    /**
     * @param string
     */
    public void setClassMei( String string ) {
        classMei = string;
    }

    /**
     * @param string
     */
    public void setKaisibi( String string ) {
        kaisibi = string;
    }

    /**
     * @param string
     */
    public void setKaisijikoku( String string ) {
        kaisijikoku = string;
    }

    /**
     * @param string
     */
    public void setKousiMei( String string ) {
        kousiMei = string;
    }

    /**
     * @param string
     */
    public void setKyosituMei( String string ) {
        kyosituMei = string;
    }

    /**
     * @param string
     */
    public void setMousikomiKaisibi( String string ) {
        mousikomiKaisibi = string;
    }

    /**
     * @param string
     */
    public void setMousikomiKubun( String string ) {
        mousikomiKubun = string;
    }

    /**
     * @param string
     */
    public void setMousikomiSyuryobi( String string ) {
        mousikomiSyuryobi = string;
    }

    /**
     * @param string
     */
    public void setSyuryobi( String string ) {
        syuryobi = string;
    }

    /**
     * @param string
     */
    public void setSyuryojikoku( String string ) {
        syuryojikoku = string;
    }

    /**
     * @param string
     */
    public void setTeiin( String string ) {
        teiin = string;
    }

    /**
     * @return
     */
    public String getHoukokuKubunMei(  ) {
        return houkokuKubunMei;
    }

    /**
     * @param string
     */
    public void setHoukokuKubunMei( String string ) {
        houkokuKubunMei = string;
    }

    /**
     * @return
     */
    public String getSyoninKubunMei(  ) {
        return syoninKubunMei;
    }

    /**
     * @param string
     */
    public void setSyoninKubunMei( String string ) {
        syoninKubunMei = string;
    }

    /**
     * @return
     */
    public String getMousikomiKubunMei(  ) {
        return mousikomiKubunMei;
    }

    /**
     * @param string
     */
    public void setMousikomiKubunMei( String string ) {
        mousikomiKubunMei = string;
    }

    /**
     * �Ȗڏ��ForMail���擾���܂��B
     * @return
     */
    public PCY_KamokuBeanForMail getKamokuBeanForMail(  ) {
        return kamokuBeanForMail;
    }

    /**
     * �Ȗڏ��ForMail��ݒ肵�܂��B
     * @param mail
     */
    public void setKamokuBeanForMail( PCY_KamokuBeanForMail mail ) {
        kamokuBeanForMail = mail;
    }
    
	/**
	 * �������擾���܂��B
	 * @return
	 */
	public String getNissu() {
		return nissu;
	}

	/**
	 * ������ݒ肵�܂��B
	 * @param string
	 */
	public void setNissu(String string) {
		nissu = string;
	}

    // INS#P-A30AM1-004-S
    /**
     * ���l���擾���܂��B
     * @return
     */
    public String getBikou() {
        return bikou;
    }

    /**
     * ���l��ݒ肵�܂��B
     * @param string
     */
    public void setBikou(String string) {
        bikou = string;
    }
    // INS#P-A30AM1-004-E
}
