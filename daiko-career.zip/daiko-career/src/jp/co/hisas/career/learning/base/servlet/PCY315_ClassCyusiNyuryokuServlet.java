/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/01/12  01.00       ���� ��F    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.bean.*;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJBHome;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;

import java.rmi.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;

import javax.servlet.http.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY315_ClassCyusiNyuryokuServlet �N���X
 *
 * �@�\�����F
 *   �N���X���~���͉�ʂ�\�����܂��B
 *
 *</PRE>
 */
public class PCY315_ClassCyusiNyuryokuServlet extends PCY010_ControllerServlet {
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PCY_PersonalBean loginuser )
        throws NamingException, CreateException, RemoteException, PCY_WarningException {
        /* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );
        Log.performance( loginuser.getSimeiNo(  ), true, "" );

        List taisyosyaList = new ArrayList(  );
        int index          = 0;

        while ( true ) {
            String simeiNo = request.getParameter( "simei_no_" + index );

            if ( ( simeiNo == null ) || ( simeiNo.length(  ) == 0 ) ) {
                break;
            }

            PCY_KensyuKanriJohoBean taisyosya = new PCY_KensyuKanriJohoBean(  );
            PCY_MousikomiJyokyoBean mousikomi = new PCY_MousikomiJyokyoBean(  );

            mousikomi.setSimeiNo( simeiNo );
            mousikomi.setKousinbi( request.getParameter( "kousinbi_" + index ) );
            mousikomi.setKousinjikoku( request.getParameter( "kousinjikoku_" + index ) );
            taisyosya.setMousikomiBean( mousikomi );

            taisyosyaList.add( taisyosya );
            index++;
        }

        PCY_KensyuKanriJohoBean[] taisyosyaBeans = new PCY_KensyuKanriJohoBean[taisyosyaList.size(  )];
        taisyosyaList.toArray( taisyosyaBeans );


		//�N���X���擾
		PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
		PCY_ClassEJBHome home = (PCY_ClassEJBHome)locator.getServiceLocation(
									"PCY_ClassEJB",
									PCY_ClassEJBHome.class );
		PCY_ClassEJB ejb = home.create();
		PCY_ClassBean classBean = ejb.doSelectByPrimaryKey( new PCY_ClassBean( request ),
															loginuser );

		//�Ȗڏ��擾
		PCY_KamokuEJBHome kamokuhome     = ( PCY_KamokuEJBHome )locator.getServiceLocation( 
									"PCY_KamokuEJB",
									PCY_KamokuEJBHome.class );
		PCY_KamokuEJB kamokuejb = kamokuhome.create(  );
		PCY_KamokuBean kamokuBean = kamokuejb.doSelectByPrimaryKey( new PCY_KamokuBean( request ), false,
				loginuser );

		request.setAttribute( "classBean", classBean );
		request.setAttribute( "kamokuBean", kamokuBean );
        request.setAttribute( "taisyosyaBeans", taisyosyaBeans );
		request.setAttribute( "MAILcomment", request.getParameter( "MAILcomment" ) );

        /* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
        Log.performance( loginuser.getSimeiNo(  ), false, "" );
        Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

        return getForwardPath(  );
    }
}
