/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/04/09  01.00       ���� ����    �V�K�쐬
 *   2004/06/20              ���� ���V�@�@���[�����M�G���[�̍ہA�x����ʂɑJ�ڂ���悤�ɏC��
 *   2004/06/24              ���� ���V    ���[�����M�@�\ �Ăяo���ύX�ɑΉ�
 */
package jp.co.hisas.career.learning.base.servlet;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.common.*;

import java.rmi.*;

import java.util.*;

import javax.ejb.*;

import javax.mail.internet.*;

import javax.naming.*;

import javax.servlet.http.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY152_ClassCyoseiServlet �N���X
 *
 * �@�\�����F
 *   �N���X�����ł̐\����t�E���߁E������s���܂��B
 *
 *</PRE>
 */
public class PCY152_ClassCyoseiServlet extends PCY010_ControllerServlet {
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PCY_PersonalBean loginuser )
        throws NamingException, CreateException, RemoteException, PCY_WarningException, Exception {
        /* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );
        Log.performance( loginuser.getSimeiNo(  ), true, "" );

        String command          = request.getParameter( "exec_command" );
        String riyu             = request.getParameter( "riyu" );
		if(riyu == null){
			riyu="";
		}
		        
        PCY_ClassBean classBean = new PCY_ClassBean( request );
        classBean.getKamokuBean(  ).setKousinbi( null ); //�Ȗڃ}�X�^�̍X�V���E�X�V�����̓`�F�b�N���Ȃ�
        classBean.getKamokuBean(  ).setKousinjikoku( null );
		String kubun = classBean.getAnnaiMailKubun();
        List mousikomisyaList = new ArrayList(  );
		List taisyosyaList = new ArrayList(  );
        int index             = 0;

		
		String[] simeiNo_req = null;
		if((command.equals("uketukesasimodosi") || command.equals("torikesisasimodosi")) && !kubun.equals("0")){
			Log.debug("simeiIndex �擾");
			String simeiLengthStr = request.getParameter("simeiLength");
			int length = (new Integer(simeiLengthStr)).intValue();
			simeiNo_req = new String[length];
			
			for(int t = 0; t<length; t++){
				simeiNo_req[t] = request.getParameter("simeiNo_" + Integer.toString(t));
								
				String simeiNo = request.getParameter( "simei_no_" + simeiNo_req[t] );
	
				if ( ( simeiNo == null ) || ( simeiNo.length(  ) == 0 ) ) {
					break;
				}

				PCY_MousikomiJyokyoBean mousikomi = new PCY_MousikomiJyokyoBean(  );
				mousikomi.setSimeiNo( simeiNo );
				mousikomi.setKamokuCode( classBean.getKamokuBean(  ).getKamokuCode(  ) );
				mousikomi.setClassCode( classBean.getClassCode(  ) );
				mousikomi.setKousinbi( request.getParameter( "kousinbi_" + simeiNo_req[t] ) );
				mousikomi.setKousinjikoku( request.getParameter( "kousinjikoku_" + simeiNo_req[t] ) );
				mousikomi.setClassBean( classBean );
				
				mousikomi.setMousikomibi( request.getParameter("mousikomibi_" + simeiNo_req[t]));
				mousikomi.setMousikomijikoku( request.getParameter("mousikomijikoku_" + simeiNo_req[t]));
				mousikomi.setMousikomisya( request.getParameter("mousikomisya_" + simeiNo_req[t]));
				mousikomi.setSyoninbi1( request.getParameter("syoninbi1_" + simeiNo_req[t]));
				mousikomi.setSyoninjikoku1( request.getParameter("syoninjikoku1_" + simeiNo_req[t]));
				mousikomi.setSyoninsya1( request.getParameter("syoniinsya1_" + simeiNo_req[t]));
				mousikomi.setSyoninbi2( request.getParameter("syoninbi2_" + simeiNo_req[t]));
				mousikomi.setSyoninjikoku2( request.getParameter("syoninjikoku2_" + simeiNo_req[t]));
				mousikomi.setSyoninsya2( request.getParameter("syoninsya2_" + simeiNo_req[t]));
				mousikomi.setUketukebi( request.getParameter("uketukebi_" + simeiNo_req[t]));
				mousikomi.setUketukejikoku( request.getParameter("uketukejikoku_" + simeiNo_req[t]));
				mousikomi.setUketukesya( request.getParameter("uketukesya_" + simeiNo_req[t]));
				

				mousikomisyaList.add( mousikomi );
				
				PCY_TaisyosyaBean taisyo = new PCY_TaisyosyaBean(  );
				taisyo.setTaisyoKubun( request.getParameter("taisyokubun_" + simeiNo_req[t]));
				
				taisyosyaList.add(taisyo);
				
			}

		}else{

        	while ( true ) {
            	String simeiNo = request.getParameter( "simei_no_" + index );
	
	            if ( ( simeiNo == null ) || ( simeiNo.length(  ) == 0 ) ) {
    	            break;
        	    }

        	    PCY_MousikomiJyokyoBean mousikomi = new PCY_MousikomiJyokyoBean(  );
        	    mousikomi.setSimeiNo( simeiNo );
				mousikomi.setKamokuCode( classBean.getKamokuBean(  ).getKamokuCode(  ) );
            	mousikomi.setClassCode( classBean.getClassCode(  ) );
            	mousikomi.setKousinbi( request.getParameter( "kousinbi_" + index ) );
            	mousikomi.setKousinjikoku( request.getParameter( "kousinjikoku_" + index ) );
            	mousikomi.setClassBean( classBean );

				mousikomi.setMousikomibi( request.getParameter("mousikomibi_" + index));
				mousikomi.setMousikomijikoku( request.getParameter("mousikomijikoku_" + index));
				mousikomi.setMousikomisya( request.getParameter("mousikomisya_" + index));
				mousikomi.setSyoninbi1( request.getParameter("syoninbi1_" + index));
				mousikomi.setSyoninjikoku1( request.getParameter("syoninjikoku1_" + index));
				mousikomi.setSyoninsya1( request.getParameter("syoniinsya1_" + index));
				mousikomi.setSyoninbi2( request.getParameter("syoninbi2_" + index));
				mousikomi.setSyoninjikoku2( request.getParameter("syoninjikoku2_" + index));
				mousikomi.setSyoninsya2( request.getParameter("syoninsya2_" + index));
				mousikomi.setUketukebi( request.getParameter("uketukebi_" + index));
				mousikomi.setUketukejikoku( request.getParameter("uketukejikoku_" + index));
				mousikomi.setUketukesya( request.getParameter("uketukesya_" + index));
				
	            mousikomisyaList.add( mousikomi );
	            
				PCY_TaisyosyaBean taisyo = new PCY_TaisyosyaBean(  );
				taisyo.setTaisyoKubun( request.getParameter("taisyokubun_" + index));
				
				taisyosyaList.add(taisyo);
				
	            index++;
        	}
		}

        PCY_MousikomiJyokyoBean[] mousikomiBeans = new PCY_MousikomiJyokyoBean[mousikomisyaList
            .size(  )];
        mousikomisyaList.toArray( mousikomiBeans );

		PCY_TaisyosyaBean[] taisyosyaBeans = new PCY_TaisyosyaBean[taisyosyaList.size(  )];
		taisyosyaList.toArray( taisyosyaBeans );
				
				
        PCY_ServiceLocator locator      = PCY_ServiceLocator.getInstance(  );
        PCY_MousikomiJyokyoEJBHome home = ( PCY_MousikomiJyokyoEJBHome )locator.getServiceLocation( "PCY_MousikomiJyokyoEJB",
                PCY_MousikomiJyokyoEJBHome.class );
        PCY_MousikomiJyokyoEJB ejb = home.create(  );
		
        if ( command.equals( "uketuke" ) ) {
            /* ��t�̏ꍇ */
            String nextStatus = null;

            if ( classBean.getHoukokuKubun(  ).equals( "0" ) ) {
                /* �N���X�}�X�^�̕񍐋敪���s�v�ł���ꍇ */
                nextStatus = "3"; /* ���̏�Ԃ́u����ҁv */
            } else {
                nextStatus = "2"; /* ���̏�Ԃ́u�񍐑ҁv */
            }

            for ( int i = 0; i < mousikomiBeans.length; i++ ) {
                mousikomiBeans[i].setStatus( nextStatus );
            }

            /* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
            Log.transaction( loginuser.getSimeiNo(  ), true, "" );
            ejb.doUpdateStatus( mousikomiBeans, loginuser, false );
            Log.transaction( loginuser.getSimeiNo(  ), false, "" );
        } else if ( command.equals( "sasimodosi" ) ) {
            /* ���߂̏ꍇ */
            /* �\���󋵃e�[�u���̃��R�[�h�폜 */
            Log.transaction( loginuser.getSimeiNo(  ), true, "" );
            ejb.doCancel( mousikomiBeans, loginuser );
            Log.transaction( loginuser.getSimeiNo(  ), false, "" );
        } else if ( command.equals( "torikesi" ) ) {
            /* ����̏ꍇ */
            for ( int i = 0; i < mousikomiBeans.length; i++ ) {
                mousikomiBeans[i].setStatus( "1" ); /* ���̏�Ԃ́u��t�ҁv */
            }

            /* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
            Log.transaction( loginuser.getSimeiNo(  ), true, "" );
            ejb.doUpdateStatus( mousikomiBeans, loginuser, false );
            Log.transaction( loginuser.getSimeiNo(  ), false, "" );
        }else if ( command.equals( "uketukekanryotorikesi" ) ) {
			for ( int i = 0; i < mousikomiBeans.length; i++ ) {
				mousikomiBeans[i].setStatus( "1" ); 
				mousikomiBeans[i].setUketsukeJyotai( "1" );
			}

			/* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
			Log.transaction( loginuser.getSimeiNo(  ), true, "" );
			ejb.doUpdateStatusAndUketuke( mousikomiBeans, loginuser);
			Log.transaction( loginuser.getSimeiNo(  ), false, "" );
        }else if(command.equals("uketukekaisi")){
			/* ��t�J�n */
			PCY_ClassCyouseiEJBHome home1 = ( PCY_ClassCyouseiEJBHome )locator.getServiceLocation( "PCY_ClassCyouseiEJB",
					PCY_ClassCyouseiEJBHome.class );
			PCY_ClassCyouseiEJB ejb1 = home1.create(  );
			
			PCY_ClassCyouseiBean[] classCyouseiBeans = new PCY_ClassCyouseiBean[mousikomiBeans.length];

			String now_day  = PZZ010_CharacterUtil.GetDay(  );
			String now_time = PZZ010_CharacterUtil.GetTime(  );

			for ( int i = 0; i < mousikomiBeans.length; i++ ) {
				PCY_MousikomiJyokyoBean[] mou = ejb.getList(mousikomiBeans[i],loginuser);
				
				mousikomiBeans[i].setStatus( "1" ); 
				mousikomiBeans[i].setUketsukeJyotai( "1" );
				
				PCY_ClassCyouseiBean classCyouseiBean = new PCY_ClassCyouseiBean();
				classCyouseiBean.setSyoribi(now_day);
				classCyouseiBean.setSyorijikoku(now_time);
				classCyouseiBean.setSyorisya(loginuser.getSimeiNo());
				classCyouseiBean.setSyoriFlg("0");
				classCyouseiBean.setDlKaisu(new Integer(0));
				classCyouseiBean.setKamokuCode(mou[0].getKamokuCode());
				classCyouseiBean.setClassCode(mou[0].getClassCode());
				classCyouseiBean.setSimeiNo(mou[0].getSimeiNo());
				classCyouseiBean.setAfterStatus("1");
				classCyouseiBean.setAfterUketukeJyotai("1");
				classCyouseiBean.setBeforeStatus("1");
				classCyouseiBean.setBeforeUketsukeJyotai("0");
				classCyouseiBean.setMousikomibi(mou[0].getMousikomibi());
				classCyouseiBean.setMousikomijikoku(mou[0].getMousikomijikoku());
				classCyouseiBean.setMousikomisya(mou[0].getMousikomisya());
				classCyouseiBean.setSyoninbi1(mou[0].getSyoninbi1());
				classCyouseiBean.setSyoninjikoku1(mou[0].getSyoninjikoku1());
				classCyouseiBean.setSyoninsya1(mou[0].getSyoninsya1());
				classCyouseiBean.setSyoninbi2(mou[0].getSyoninbi2());
				classCyouseiBean.setSyoninjikoku2(mou[0].getSyoninjikoku2());
				classCyouseiBean.setSyoninsya2(mou[0].getSyoninsya2());
				classCyouseiBean.setUketukebi(mou[0].getUketukebi());
				classCyouseiBean.setUketukejikoku(mou[0].getUketukejikoku());
				classCyouseiBean.setUketukesya(mou[0].getUketukesya());
				
				classCyouseiBeans[i] = classCyouseiBean;

			}
			/* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
			Log.transaction( loginuser.getSimeiNo(  ), true, "" );
			ejb.doUpdateStatusAndUketuke( mousikomiBeans, loginuser);
			ejb1.doInsert(classCyouseiBeans,loginuser);
			Log.transaction( loginuser.getSimeiNo(  ), false, "" );
		}else if(command.equals("syouninmachisasimodosi")){
			/* ���F�ҍ��߂� */
			for ( int i = 0; i < mousikomiBeans.length; i++ ) {
				mousikomiBeans[i].setStatus( "1" ); 
				mousikomiBeans[i].setUketsukeJyotai( "2" );
			}

			/* �\���󋵃e�[�u�����폜�X�V */
			Log.transaction( loginuser.getSimeiNo(  ), true, "" );
			ejb.doCancel( mousikomiBeans, loginuser );
			Log.transaction( loginuser.getSimeiNo(  ), false, "" );
        }else if(command.equals("uketukekanryo")){
			/* ��t���� */
			for ( int i = 0; i < mousikomiBeans.length; i++ ) {
				mousikomiBeans[i].setStatus( "1" ); 
				mousikomiBeans[i].setUketsukeJyotai( "2" );
			}

			/* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
			Log.transaction( loginuser.getSimeiNo(  ), true, "" );
			ejb.doUpdateStatusAndUketuke( mousikomiBeans, loginuser);
			Log.transaction( loginuser.getSimeiNo(  ), false, "" );
		}else if(command.equals("torikesikaisi")){
			/* ����J�n */
			PCY_ClassCyouseiEJBHome home1 = ( PCY_ClassCyouseiEJBHome )locator.getServiceLocation( "PCY_ClassCyouseiEJB",
					PCY_ClassCyouseiEJBHome.class );
			PCY_ClassCyouseiEJB ejb1 = home1.create(  );
			
			PCY_ClassCyouseiBean[] classCyouseiBeans = new PCY_ClassCyouseiBean[mousikomiBeans.length];
			String now_day  = PZZ010_CharacterUtil.GetDay(  );
			String now_time = PZZ010_CharacterUtil.GetTime(  );
			
			for ( int i = 0; i < mousikomiBeans.length; i++ ) {
				PCY_MousikomiJyokyoBean[] mou = ejb.getList(mousikomiBeans[i],loginuser);
				
				mousikomiBeans[i].setStatus( "1" ); 
				mousikomiBeans[i].setUketsukeJyotai( "4" );

				PCY_ClassCyouseiBean classCyouseiBean = new PCY_ClassCyouseiBean();
				classCyouseiBean.setSyoribi(now_day);
				classCyouseiBean.setSyorijikoku(now_time);
				classCyouseiBean.setSyorisya(loginuser.getSimeiNo());
				classCyouseiBean.setSyoriFlg("1");
				classCyouseiBean.setDlKaisu(new Integer(0));
				classCyouseiBean.setKamokuCode(mou[0].getKamokuCode());
				classCyouseiBean.setClassCode(mou[0].getClassCode());
				classCyouseiBean.setSimeiNo(mou[0].getSimeiNo());
				classCyouseiBean.setAfterStatus("1");
				classCyouseiBean.setAfterUketukeJyotai("4");
				classCyouseiBean.setBeforeStatus("1");
				classCyouseiBean.setBeforeUketsukeJyotai("3");
				classCyouseiBean.setMousikomibi(mou[0].getMousikomibi());
				classCyouseiBean.setMousikomijikoku(mou[0].getMousikomijikoku());
				classCyouseiBean.setMousikomisya(mou[0].getMousikomisya());
				classCyouseiBean.setSyoninbi1(mou[0].getSyoninbi1());
				classCyouseiBean.setSyoninjikoku1(mou[0].getSyoninjikoku1());
				classCyouseiBean.setSyoninsya1(mou[0].getSyoninsya1());
				classCyouseiBean.setSyoninbi2(mou[0].getSyoninbi2());
				classCyouseiBean.setSyoninjikoku2(mou[0].getSyoninjikoku2());
				classCyouseiBean.setSyoninsya2(mou[0].getSyoninsya2());
				classCyouseiBean.setUketukebi(mou[0].getUketukebi());
				classCyouseiBean.setUketukejikoku(mou[0].getUketukejikoku());
				classCyouseiBean.setUketukesya(mou[0].getUketukesya());
				
				classCyouseiBeans[i] = classCyouseiBean;
			}

			/* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
			Log.transaction( loginuser.getSimeiNo(  ), true, "" );
			ejb.doUpdateStatusAndUketuke( mousikomiBeans, loginuser);
			ejb1.doInsert(classCyouseiBeans,loginuser);
			Log.transaction( loginuser.getSimeiNo(  ), false, "" );
		}else if(command.equals("torikesisasimodosi")){
			/* ������� */
			for ( int i = 0; i < mousikomiBeans.length; i++ ) {
				mousikomiBeans[i].setStatus( "1" ); 
				mousikomiBeans[i].setUketsukeJyotai( "2" );
			}

			/* �\���󋵃e�[�u���̃X�e�[�^�X�X�V */
			Log.transaction( loginuser.getSimeiNo(  ), true, "" );
			ejb.doUpdateStatusAndUketuke( mousikomiBeans, loginuser);
			Log.transaction( loginuser.getSimeiNo(  ), false, "" );
		}else if(command.equals("uketukesasimodosi")){
			/* ��t���߂̏ꍇ */
			/* �\���󋵃e�[�u���̃��R�[�h�폜 */
			Log.transaction( loginuser.getSimeiNo(  ), true, "" );
			ejb.doCancelAndRirekiInsert( mousikomiBeans,  taisyosyaBeans, loginuser,"0");
			Log.transaction( loginuser.getSimeiNo(  ), false, "" );
		}else if(command.equals("torikesikanryo")){
			/* ��������̏ꍇ */
			/* �\���󋵃e�[�u���̃��R�[�h�폜 */
			Log.transaction( loginuser.getSimeiNo(  ), true, "" );
			ejb.doCancelAndRirekiInsert( mousikomiBeans, taisyosyaBeans, loginuser,"1");
			Log.transaction( loginuser.getSimeiNo(  ), false, "" );
        }
        
        /* �ȖځE�N���X��񌟍� */
        PCY_ClassEJBHome classHome = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
                PCY_ClassEJBHome.class );
        PCY_ClassEJB classEjb = classHome.create(  );

        Log.transaction( loginuser.getSimeiNo(  ), true, "" );
        classBean = classEjb.doSelectByPrimaryKey( classBean, loginuser );
        Log.transaction( loginuser.getSimeiNo(  ), false, "" );

        if ( classBean.getAnnaiMailKubun(  ).equals( "1" ) ) {
            /* �N���X�}�X�^�̈ē����[���敪���f�v�f�̏ꍇ�A���[���𑗐M���� */
            /* Mail���� */
            String[] simei_no = new String[mousikomisyaList.size(  )];

            for ( int i = 0; i < simei_no.length; i++ ) {
                simei_no[i] = mousikomiBeans[i].getSimeiNo(  );
            }

            PCY_PersonalEJBHome personalHome = ( PCY_PersonalEJBHome )locator.getServiceLocation( "PCY_PersonalEJB",
                    PCY_PersonalEJBHome.class );
            PCY_PersonalEJB personalEjb = personalHome.create(  );

            Log.transaction( loginuser.getSimeiNo(  ), true, "" );
             
			PCY_PersonalBean[] personalBeans = personalEjb.getPersonalInfo( simei_no, loginuser );
            Log.transaction( loginuser.getSimeiNo(  ), false, "" );

            if ( command.equals( "uketuke" ) ) {
                try {
                    /* ��t�̏ꍇ */
                    PCY_KensyuMailSender.sendKensyuKanrisyaUketuke( personalBeans, classBean,
                        loginuser );
                } catch ( AddressException e ) {
                    request.setAttribute( "warningID", "WCC110" );
                    throw new PCY_WarningException( e );
                } catch ( Exception e ) {
                    request.setAttribute( "warningID", "WCC110" );
                    throw new PCY_WarningException( e );
                }
            } else if ( command.equals( "sasimodosi" ) ) {
                try {
                    /* ���߂̏ꍇ */
                    PCY_KensyuMailSender.sendKensyuKanrisyaSasimodosi( personalBeans, classBean,
                        loginuser );
                } catch ( AddressException e ) {
                    request.setAttribute( "warningID", "WCC120" );
                    throw new PCY_WarningException( e );
                } catch ( Exception e ) {
                    request.setAttribute( "warningID", "WCC120" );
                    throw new PCY_WarningException( e );
                }
            } else if ( command.equals( "torikesi" ) ) {
                try {
                    /* ����̏ꍇ */
                    PCY_KensyuMailSender.sendKensyuKanrisyaTorikeshi( personalBeans, classBean,
                        loginuser );
                } catch ( AddressException e ) {
                    request.setAttribute( "warningID", "WCC130" );
                    throw new PCY_WarningException( e );
                } catch ( Exception e ) {
                    request.setAttribute( "warningID", "WCC130" );
                    throw new PCY_WarningException( e );
                }
            }else if(command.equals("syouninmachisasimodosi")){
				try {
					/* ���F�ҍ��߂̏ꍇ */	
					PCY_KensyuMailSender.sendKensyuKanrisyaSyouninMachiSasimodosi( personalBeans, classBean,
						loginuser );
				} catch ( AddressException e ) {
					request.setAttribute( "warningID", "WCC120" );
					throw new PCY_WarningException( e );
				} catch ( Exception e ) {
					request.setAttribute( "warningID", "WCC120" );
					throw new PCY_WarningException( e );
				}
            }else if(command.equals("uketukekanryo")){
                if ( "0".equals( classBean.getKisyoIkkatsuFlg(  ) ) ) {
    				try {
    					/* ��t�����̏ꍇ */
    					PCY_KensyuMailSender.sendKensyuKanrisyaUketukeKanryo( personalBeans, classBean,
    						loginuser );
    				} catch ( AddressException e ) {
    					request.setAttribute( "warningID", "WCC110" );
    					throw new PCY_WarningException( e );
    				} catch ( Exception e ) {
    					request.setAttribute( "warningID", "WCC110" );
    					throw new PCY_WarningException( e );
    				}
                }
			}else if(command.equals("uketukesasimodosi")){
                if ( "0".equals( classBean.getKisyoIkkatsuFlg(  ) ) ) {
    				try {
    					/* ��t���߂̏ꍇ */
    					PCY_KensyuMailSender.sendKensyuKanrisyaUketukeSasimodosi( personalBeans, classBean, riyu,
    						loginuser );
    				} catch ( AddressException e ) {
    					request.setAttribute( "warningID", "WCC120" );
    					throw new PCY_WarningException( e );
    				} catch ( Exception e ) {
    					request.setAttribute( "warningID", "WCC120" );
    					throw new PCY_WarningException( e );
    				}
                }
			}else if(command.equals("torikesisasimodosi")){
				try {
					/* ������߂̏ꍇ */
					PCY_KensyuMailSender.sendKensyuKanrisyaTorikesiSasimodosi( personalBeans, classBean, riyu,
						loginuser );
				} catch ( AddressException e ) {
					request.setAttribute( "warningID", "WCC120" );
					throw new PCY_WarningException( e );
				} catch ( Exception e ) {
					request.setAttribute( "warningID", "WCC120" );
					throw new PCY_WarningException( e );
				}
			}else if(command.equals("torikesikanryo")){
				try {
					/* ��������̏ꍇ */
					PCY_KensyuMailSender.sendKensyuKanrisyaTorikesiKanryo( personalBeans,classBean,
						loginuser );
				} catch ( AddressException e ) {
					request.setAttribute( "warningID", "WCC130" );
					throw new PCY_WarningException( e );
				} catch ( Exception e ) {
					request.setAttribute( "warningID", "WCC130" );
					throw new PCY_WarningException( e );
				}
			}
        }

        /* ���\�b�h�g���[�X�E���\����g���[�X�o�� */
        Log.performance( loginuser.getSimeiNo(  ), false, "" );
        Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

        return getForwardPath(  );
    }
}
