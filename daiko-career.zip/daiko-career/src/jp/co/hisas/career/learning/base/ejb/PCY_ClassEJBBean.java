/*
* All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
*
* �v���W�F�N�g���@�F
*   ���V�e�ACareer�i���C�Ǘ��@�\�j
*
* ���l�@�F
*   �Ȃ�
*
* �����@�F
*   ���t        �o�[�W����  ���O         ���e
*   2004/01/26  01.00       ���� �a��    �V�K�쐬
* �@2004/06/05              ���� ���V    ���\�b�h�C���^�[�t�F�C�X�ύX�iTPBroker�΍�j
*   2004/06/15              ���� ���V    ��u����NULL�Ή�
*   2004/06/16              ���� ���V    doSelectByPrimaryKey���\�b�h�ǉ�
*   2004/06/16              ���� ���V    doDelete�����ǉ�
*   2004/06/18              ���� ���V�@�@doInsert���\�b�h�@SQLException������ EJBException�@�X���[�ɕύX
*   2004/06/20              ���� ���V�@�@PCY_WarningException���������[���o�b�N����悤�ɏC��
*   2004/06/21              ���� ���V    doClassCyusi�ǉ�
*   2004/06/21              ���� ���V    �Ώېݒ���������\�b�h��private�ɕύX
*   2004/06/21              ���� ���V    ��s���̓e�[�u���Ƃ̘A�g�ɑΉ�
*   2004/06/21              ���� ���V   �N���X�I���`�F�b�N�Ώێ҂ɖ��\���҂��܂܂�Ă��Ȃ������̂ŏC��
*   2004/06/21              ���� ���V�@ �N���X�o�^���N���X�R�[�h�̍̔Ԃ�Servlet���ōs���悤�ɏC���B�ē����[���v���̃G���[�Ή��B
*   2004/06/24              ���� ���V   Cosminexus�ŃG���[���o�邽�߁ATypes��java.sql.Types�ɕύX
*   2004/06/27              ���� ���V   doDelete�x���X���[���b�Z�[�W��ID�ɕύX
*   2004/06/29              ���� ���V   �N���X���~���������ǉ�
*   2004/07/13              ���� ���V   doUpdate���\�b�h�@��u������Null����ɏC��
*   2004/07/28              �ԗ� ����   doDelete���\�b�h �폜�\�N���X�ł��邱�Ƃ𔻒肷��O�������C���i�o�C���h�ϐ��ւ̑�������j
*   2004/08/03              ���� ���V   �e�[�u�����C�A�E�g�ύX�Ή��i�Г�Career@Net�Ή��j
*   2004/08/03              ���� ���V   ���猤�C���e�[�u���ύX�Ή��i�Г�Career@Net�Ή��j
*   2004/08/23              ���� ���V   �S�БΏۃt���O�Ή��@B-ALC01-030
*   2004/09/27              ���� ���V   �����̐��x�ύX�ɑΉ��@C-ALH01-003
*   2005/12/03              �Β� �[     �񍐋敪2�ǉ��ɑΉ�
*   2005/12/03  01.00       �c�� ��`   �\���폜������p�~ BPX-0301J-0475
*   2006/02/08              ���Y �T��   �S�БΏېݒ莞�A�Ώێ҃e�[�u���̃��R�[�h���폜 BPX-0301J-3021
*   2006/03/06              ���Y �T��   BPX-0301J-3021�̃f�O���[�h�Ή�
*/
package jp.co.hisas.career.learning.base.ejb;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.bean.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.rmi.*;

import java.sql.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_ClassEJBBean�N���X
 *
 * �@�\�����F
 *   �N���X�}�X�^�ւ̑�����s���܂��B
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PCY_ClassEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PCY_ClassEJBBean implements SessionBean {
    private SessionContext context = null;

    /**
     * �N���X���~���s���B
     *
     * @param classBean
     * @param mousikomiBeans
     * @param loginuser
     * @throws PCY_WarningException
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public void doClassCyusi( PCY_ClassBean classBean, 
								PCY_MousikomiJyokyoBean[] mousikomiBeans,
								PCY_TaisyosyaBean[] taisyosyaBeans ,
						        PCY_PersonalBean loginuser ) throws PCY_WarningException {

        try {
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

            PCY_ClassBean[] classBeans = this.doSelect( classBean, true, loginuser );

            if ( classBeans.length == 0 ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            /* �N���X���~�������`�F�b�N���� */
            /* ���猤�C���Ɋ��ɗ��������݂��Ȃ����`�F�b�N���� */
            /* KensyuRirekiEJB */
            PCY_KensyuRirekiEJBHome kensyuRireki_home = ( PCY_KensyuRirekiEJBHome )locator
                .getServiceLocation( "PCY_KensyuRirekiEJB", PCY_KensyuRirekiEJBHome.class );
            PCY_KensyuRirekiEJB kensyuRireki_ejb    = kensyuRireki_home.create(  );
            PCY_KensyuRirekiBean kensaku_rirekiBean = new PCY_KensyuRirekiBean(  );
            kensaku_rirekiBean.setKamokuCode( classBean.getKamokuBean(  ).getKamokuCode(  ) );
            kensaku_rirekiBean.setClassCode( classBean.getClassCode(  ) );

            PCY_KensyuRirekiBean[] rirekiBeans = kensyuRireki_ejb.getList( new PCY_KensyuRirekiBean[] { kensaku_rirekiBean },
                    loginuser );

            if ( rirekiBeans.length > 0 ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException( "WCC230" );
            }
            
            /* �񍐋敪�v�̏ꍇ�񍐎҂����Ȃ����`�F�b�N���� */
            PCY_MousikomiJyokyoEJBHome mousikomiHome = ( PCY_MousikomiJyokyoEJBHome )locator
                .getServiceLocation( "PCY_MousikomiJyokyoEJB", PCY_MousikomiJyokyoEJBHome.class );
            PCY_MousikomiJyokyoEJB mousikomiEjb = mousikomiHome.create(  );

            if ( !classBeans[0].getHoukokuKubun(  ).equals( "0" ) ) {
                PCY_MousikomiJyokyoBean kensaku_mousikomiBean = new PCY_MousikomiJyokyoBean(  );
                kensaku_mousikomiBean.setKamokuCode( classBean.getKamokuBean(  ).getKamokuCode(  ) );
                kensaku_mousikomiBean.setClassCode( classBean.getClassCode(  ) );

                PCY_MousikomiJyokyoBean[] checkMousikomiBeans = mousikomiEjb.getList( kensaku_mousikomiBean,
                        loginuser );

                for ( int i = 0; i < checkMousikomiBeans.length; i++ ) {
                    if ( ( checkMousikomiBeans[i].getHoukokubi(  ) != null )
                        && !"".equals( checkMousikomiBeans[i].getHoukokubi(  ) ) ) {
                        context.setRollbackOnly(  );
                        throw new PCY_WarningException( "WCC250" );
                    }
                }
            }

            /* ��s���͎҂����݂��Ȃ����`�F�b�N���� */
            /* DaikoNyuryokuEJB */
            PCY_DaikoNyuryokuEJBHome daiko_home = ( PCY_DaikoNyuryokuEJBHome )locator
                .getServiceLocation( "PCY_DaikoNyuryokuEJB", PCY_DaikoNyuryokuEJBHome.class );
            PCY_DaikoNyuryokuEJB daiko_ejb          = daiko_home.create(  );
            PCY_DaikoNyuryokuBean kensaku_daikoBean = new PCY_DaikoNyuryokuBean(  );
            kensaku_daikoBean.setKamokuCode( classBean.getKamokuBean(  ).getKamokuCode(  ) );
            kensaku_daikoBean.setClassCode( classBean.getClassCode(  ) );

            PCY_DaikoNyuryokuBean[] daikoBeans = daiko_ejb.doSelect( kensaku_daikoBean, false,
                    loginuser );

            if ( daikoBeans.length > 0 ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException( "WCC240" );
            }

            /* �\���󋵃e�[�u���̊Y�����R�[�h���폜 */
			mousikomiEjb.doCancelAndRirekiInsert( mousikomiBeans , taisyosyaBeans , loginuser , "2") ;

            /* �J�Ï�Ԃ𒆎~�ɍX�V���� */
            classBean.setKaisaiJyotai( "1" );
            this.doUpdateKaisaiJyotai( classBean, loginuser );

            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            throw new EJBException( e );
        } catch ( PCY_WarningException e ) {
            context.setRollbackOnly(  );
            throw e;
        }
    }

    /**
     * �N���X�I�����s���B
     *
     * @param classBean
     * @param loginuser
     * @throws PCY_WarningException
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public void doClassSyuryo( PCY_ClassBean classBean, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        try {
            /* �T�[�r�X���P�[�^�[�̎擾 */
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

            /* �N���X���ڍׂ��擾�i���b�N�j */
            PCY_ClassBean[] classBeans = this.doSelect( classBean, true, loginuser );

            /* ��ʑJ�ڒ��A�N���X�̏�񂪍X�V����ĂȂ��� */
            if ( !( classBean.getKousinbi(  ).equals( classBeans[0].getKousinbi(  ) )
                && classBean.getKousinjikoku(  ).equals( classBeans[0].getKousinjikoku(  ) ) ) ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException( "�N���X�I���F�X�V���s��ꂽ���߁B" );
            }

            /* ���C�Ǘ����f�[�^���擾 */
            PCY_TaisyoEJBHome taisyo_home = ( PCY_TaisyoEJBHome )locator.getServiceLocation( "PCY_TaisyoEJB",
                    PCY_TaisyoEJBHome.class );
            PCY_TaisyoEJB taisyo_ejb = taisyo_home.create(  );

            /* �N���X��񂩂�Ώێҏ�񃊃X�g���擾���� */
            PCY_KensyuKanriJohoBean[] kensyukanrijohoBeans = taisyo_ejb
                .getSeisekiNyuryokuTaisyousyaInfo( classBeans[0], false, loginuser );

            /* �N���X�I�������`�F�b�N */
			int countA = 0;   // �\���󋵃e�[�u���Ƀ��R�[�h�����݂��Astatus��"0"�܂���"1"
			int countB = 0;   // �\���󋵃e�[�u���Ƀ��R�[�h�����݂��Astatus��"2"�܂���"3"
			int countC = 0;   // �\���󋵃e�[�u���A�������e�[�u���ɏ�񂪑��݂��Ȃ��B�Ώۋ敪���K�{
            for ( int i = 0; i < kensyukanrijohoBeans.length; i++ ) {
                PCY_KensyuKanriJohoBean kensyu_tmp = kensyukanrijohoBeans[i];

                //INS#P-BPX-0301J-0213 -S
                //�ސE�҂̓��[�v���΂��B
                if (kensyu_tmp.getPersonalBean() != null
                    && kensyu_tmp.getPersonalBean().getGensyokuTaisyokuFlg() != null
                    && kensyu_tmp.getPersonalBean().getGensyokuTaisyokuFlg().equals("2")) {
                	
                    continue;
                }
                //INS#P-BPX-0301J-0213 -E
                
				if ( kensyu_tmp.getMousikomiBean(  ) != null ) {
					if ( kensyu_tmp.getMousikomiBean(  ).getStatus() != null && 
						!kensyu_tmp.getMousikomiBean(  ).getStatus().equals("")){
						if(kensyu_tmp.getMousikomiBean().getStatus().equals("0") 
							|| kensyu_tmp.getMousikomiBean().getStatus().equals("1")){
								countA++;
						}else if(kensyu_tmp.getMousikomiBean().getStatus().equals("2") 
								   || kensyu_tmp.getMousikomiBean().getStatus().equals("3")){
								countB++;
						}
					}
				}

                if ( ( kensyu_tmp.getMousikomiBean(  ) == null )
                    && ( kensyu_tmp.getKensyurirekiBean(  ) == null )
                    && ( kensyu_tmp.getTaisyousyaBean(  ).getTaisyoKubun(  ).equals( "0" ) ) ) {
                    	countC++;
                }
            }

			if(countA > 0 && countB > 0){
				context.setRollbackOnly(  );
				throw new PCY_WarningException( "WCC163" );
			}else if(countA > 0){
				context.setRollbackOnly(  );
				throw new PCY_WarningException( "WCC161" );
			}else if(countB > 0){
				context.setRollbackOnly(  ); 
				throw new PCY_WarningException( "WCC162" );
			}else if(countC > 0){
				context.setRollbackOnly(  ); 
				throw new PCY_WarningException( "WCC170" );
			}
			
            /* �N���X�I�����s�� */
            classBeans[0].setKaisaiJyotai( "2" );
            this.doUpdateKaisaiJyotai( classBeans[0], loginuser );

            /* ��s�҃e�[�u������������ */
            this.doDeleteDaikoNyuryokuRecord( classBeans[0], new PCY_TaisyosyaBean[] {  }, loginuser );
        } catch ( NamingException e ) {
            new EJBException( e );
        } catch ( CreateException e ) {
            new EJBException( e );
        } catch ( RemoteException e ) {
            new EJBException( e );
        }
    }

    /**
     * �N���X�}�X�^���v���C�}���[�L�[�Ō������Č��ʂ�Ԃ��܂��B
     * classBeans�Ɋ܂܂��ȖڃR�[�h�A�N���X�R�[�h�����Ɍ������s���܂��B
     * �����̌����f�[�^�ɑ΂������̏ڍ׃f�[�^��߂��܂��B
     *
     * @param classBeans
     * @param loginuser
     * @return
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_ClassBean[] doSelectByPrimaryKey( PCY_ClassBean[] classBeans,
        PCY_PersonalBean loginuser ) {
        PCY_ClassBean[] retClassBeans = new PCY_ClassBean[classBeans.length];

        for ( int i = 0; i < classBeans.length; i++ ) {
            retClassBeans[i] = this.doSelectByPrimaryKey( classBeans[i], loginuser );
        }

        return retClassBeans;
    }

    /**
     * �N���X�}�X�^���v���C�}���[�L�[�Ō������Č��ʂ�Ԃ��܂��B
     * �������ʂ����������ꍇ�� null ��Ԃ��܂��B
     *
     * @param classBean ��������
     * @param loginuser ���O�C�����[�U
     * @return ��������
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_ClassBean doSelectByPrimaryKey( PCY_ClassBean classBean, PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            PCY_ClassBean ret = null;
            StringBuffer sql  = new StringBuffer(  );
            sql.append( "SELECT " + PCY_KamokuBean.getColumns( "kamoku" ) + ", " );
            sql.append( PCY_ClassBean.getColumns( "class" ) );
            sql.append( "  FROM " );
            sql.append( HcdbDef.L01_TBL );
            sql.append( " KAMOKU, " );
            sql.append( HcdbDef.L02_TBL );
            sql.append( " CLASS" );
            sql.append( "  WHERE KAMOKU.KAMOKU_CODE=?" );
            sql.append( "    AND KAMOKU.SAKUJYO_FLG='0'" );
            sql.append( "    AND CLASS.KAMOKU_CODE=?" );
            sql.append( "    AND CLASS.CLASS_CODE=?" );
            sql.append( "    AND CLASS.SAKUJYO_FLG='0'" );
            sql.append( "    AND KAMOKU.KAMOKU_CODE=CLASS.KAMOKU_CODE" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �������s
            ps = con.prepareStatement( sql.toString(  ) );
            ps.setString( 1, classBean.getKamokuBean(  ).getKamokuCode(  ) );
            ps.setString( 2, classBean.getKamokuBean(  ).getKamokuCode(  ) );
            ps.setString( 3, classBean.getClassCode(  ) );

            ResultSet rs = ps.executeQuery(  );

            if ( rs.next(  ) ) {
                ret = new PCY_ClassBean( rs, "KAMOKU", "CLASS" );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ret;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

// ADD 2010/02/01 COMTURE VCA060_�u���ڍׁi#13�j START
    /**
     * �u�t�����������Č��ʂ�Ԃ��܂��B
     * �������ʂ����������ꍇ�� null ��Ԃ��܂��B
     *
     * @param classBean ��������
     * @param loginuser ���O�C�����[�U
     * @return ��������
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_ClassBean doSelectKousi(PCY_ClassBean classBean,
			PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;

		try {
            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "IN", "");

			PCY_ClassBean ret = new PCY_ClassBean();
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT CLASS.KOUSI_CODE CLASS_KOUSI_CODE, CLASS.KOUSI_MEI CLASS_KOUSI_MEI, KOUSI.KOUSI_CODE KOUSI_KOUSI_CODE, KOUSI.KOUSI_MEI KOUSI_KOUSI_MEI");
			sql.append(" FROM ");
			sql.append(HcdbDef.L02_TBL);
			sql.append(" CLASS, ");
			sql.append(HcdbDef.L11_TBL);
			sql.append(" KOUSI");
			sql.append(" WHERE CLASS.KAMOKU_CODE=?");
			sql.append(" AND CLASS.CLASS_CODE=?");
			sql.append(" AND CLASS.SAKUJYO_FLG='0'");
			sql.append(" AND CLASS.KOUSI_CODE=KOUSI.KOUSI_CODE(+)");

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
			con = locator.getDataSource().getConnection();

            // �������s
            Log.debug( sql.toString(  ) );
            ps = con.prepareStatement(sql.toString());
			ps.setString(1, classBean.getKamokuBean().getKamokuCode());
			ps.setString(2, classBean.getClassCode());

			ResultSet rs = ps.executeQuery();
			String kousi_mei = "";

			while (rs.next()) {
				if (rs.getString("CLASS_KOUSI_CODE") == null) {
					kousi_mei = rs.getString("CLASS_KOUSI_MEI");
				} else {
					kousi_mei = rs.getString("KOUSI_KOUSI_MEI");
				}
				ret.setKousiMei(kousi_mei);
			}

            // ���\�b�h�g���[�X�o��
            Log.method(loginuser.getSimeiNo(), "OUT", "");

			return ret;
		} catch (NamingException e) {
			Log.error(loginuser.getSimeiNo(), "HJE-0002", e);
			throw new EJBException(e);
		} catch (SQLException e) {
			Log.error(loginuser.getSimeiNo(), "HJE-0001", e);
			throw new EJBException(e);
		} catch (RuntimeException e) {
			Log.error(loginuser.getSimeiNo(), "", e);
			throw e;
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
                    // �������Ȃ�
                }
			}

			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
                    // �������Ȃ�
                }
			}
		}
	}
// ADD 2010/02/01 COMTURE VCA060_�u���ڍׁi#13�j END
    
    /**
     * <pre>
     * �N���X�}�X�^���������Č��ʂ� PCY_ClassBean �̔z��Ƃ��ĕԂ��܂��B
     * �������ʂ����������ꍇ�͋�̔z���Ԃ��܂��B
     * �ȉ��̍��ڂ����������Ƃ��Ďg�p�ł��܂��B
     * �E�N���X�R�[�h
     * �E�o�[�W�����Ǘ�
     * �E�N���X�O���[�v
     * �E�J�e�S���R�[�h�P
     * �E�J�e�S���R�[�h�Q
     * �E�J�e�S���R�[�h�R
     * �E�J�e�S���R�[�h�S
     * </pre>
     *
     * @param classBean ��������
     * @param lock true�̏ꍇ���b�N����Afalse�̏ꍇ���b�N�Ȃ�
     * @param loginuser ���O�C�����[�U
     * @return ��������
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_ClassBean[] doSelect( PCY_ClassBean classBean, boolean lock,
        PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;
		PreparedStatement ps_mimousikomi = null;

        try {
            Collection ret   = new ArrayList(  );
            StringBuffer sql = new StringBuffer(  );
            sql.append( "SELECT " + PCY_KamokuBean.getColumns( "kamoku" ) + ", " );
            sql.append( PCY_ClassBean.getColumns( "class" ) );
            sql.append( "  FROM " );
            sql.append( HcdbDef.L01_TBL );
            sql.append( " KAMOKU, " );
            sql.append( HcdbDef.L02_TBL );
            sql.append( " CLASS" );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // ���������̍쐬
            StringBuffer where = new StringBuffer(  );

            // �Ȗڃ}�X�^
            Map kamokuConditions = classBean.getKamokuBean(  ).extractConditions(  );

            for ( Iterator ite = kamokuConditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                Object column = ite.next(  );

                if ( column.equals( "KAMOKU_MEI1" ) ) {
                    //where.append( " AND KAMOKU." + column + " LIKE ?" );
                	where.append( " AND UPPER(KAMOKU." + column + ") LIKE UPPER(?)" ); //CHG#0301L-0103
                } else if(column.equals( "KAMOKU_CODE" )){
                	String subStr = getSQLKamokuCode(kamokuConditions.get(column).toString(),"KAMOKU."+column);
					where.append(subStr);
                } else{
                    where.append( " AND KAMOKU." + column + "=?" );
                }
            }

            where.append( " AND KAMOKU.SAKUJYO_FLG='0'" );

            // �N���X�}�X�^
            Map classConditions = classBean.extractConditions(  );

            for ( Iterator ite = classConditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                Object column = ite.next(  );
                if ( column.equals( "SYURYOBI" ) ) {
                    where.append( " AND CLASS." + column + ">=?" );
                } else if ( column.equals( "KAISIBI" ) ) {
                    where.append( " AND CLASS." + column + "<=?" );
                } else if ( column.equals("MOUSIKOMI_JYOKYO")){ //�\���󋵂͖���
                } else	if (column.equals("JYUKO_JYOKYO")){      //��u�󋵂͖���
                } else {
                    where.append( " AND CLASS." + column + "=?" );
                }
            }
			
            where.append( " AND CLASS.SAKUJYO_FLG='0'" );
            where.append( " AND KAMOKU.KAMOKU_CODE=CLASS.KAMOKU_CODE" );
            
            sql.append( where.toString(  ).replaceFirst( "AND", "WHERE" ) );

			//�\����
			String mousikomi = classBean.getMousikomiJyokyo();
			if(mousikomi == null || mousikomi.equals("")){
				//���������ɐݒ肵�Ȃ�
			}else if(mousikomi.equals("1")){
				sql.append( " AND (CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( "WHERE MOUSIKOMI.STATUS = '0'" );
				sql.append( " AND MOUSIKOMI.UKETSUKE_JYOTAI IS NULL ) " );
			}else if(mousikomi.equals("2")){
				sql.append( " AND (CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( "WHERE MOUSIKOMI.STATUS = '1'" );
				sql.append( " AND MOUSIKOMI.UKETSUKE_JYOTAI = '0')" );
			}else if(mousikomi.equals("3")){
				sql.append( " AND (CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( "WHERE MOUSIKOMI.STATUS = '1'" );
				sql.append( " AND MOUSIKOMI.UKETSUKE_JYOTAI = '1')" );
			}else if(mousikomi.equals("4")){
				sql.append( " AND (CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( "WHERE MOUSIKOMI.STATUS = '1'" );
				sql.append( " AND MOUSIKOMI.UKETSUKE_JYOTAI = '2')" );
			}else if(mousikomi.equals("5")){
				sql.append( " AND (CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( "WHERE MOUSIKOMI.STATUS = '1'" );
				sql.append( " AND MOUSIKOMI.UKETSUKE_JYOTAI = '3')" );
			}else if(mousikomi.equals("6")){
				sql.append( " AND (CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( "WHERE MOUSIKOMI.STATUS = '1'" );
				sql.append( " AND MOUSIKOMI.UKETSUKE_JYOTAI = '4')" );
//              DEL#BPX-0301J-0475
			}
			
			//��u��
			String jyukojyokyo = classBean.getJyukoJyokyo();
			if(jyukojyokyo == null || jyukojyokyo.equals("")){
				//���������ɐݒ肵�Ȃ�
			}else if(jyukojyokyo.equals("0")){
				sql.append( " AND ((CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) NOT IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + ")" );
				sql.append( " AND (CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) NOT IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L51_TBL + ") OR " ); //CHG#BPX-0301J-0628
//              DEL#BPX-0301J-0475
				sql.append( " ((CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( "WHERE MOUSIKOMI.STATUS = '0'" );
				sql.append( " AND MOUSIKOMI.UKETSUKE_JYOTAI IS NULL)) OR " );				
				sql.append( " ((CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( "WHERE MOUSIKOMI.STATUS = '1'" );
				sql.append( " AND MOUSIKOMI.UKETSUKE_JYOTAI = '1')) OR " );				
				sql.append( " ((CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( "WHERE MOUSIKOMI.STATUS = '1'" );
				sql.append( " AND MOUSIKOMI.UKETSUKE_JYOTAI = '2')) OR " );				
				sql.append( " ((CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( "WHERE MOUSIKOMI.STATUS = '1'" );
				sql.append( " AND MOUSIKOMI.UKETSUKE_JYOTAI = '3')) OR " );				
				sql.append( " ((CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( "WHERE MOUSIKOMI.STATUS = '1'" );
				sql.append( " AND MOUSIKOMI.UKETSUKE_JYOTAI = '4'))) " );				
			}else if(jyukojyokyo.equals("1")){
				sql.append( " AND ((CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( "WHERE MOUSIKOMI.STATUS = '2'" );
				sql.append( " AND MOUSIKOMI.UKETSUKE_JYOTAI IS NULL)) " );	
			}else if(jyukojyokyo.equals("2")){
				sql.append( " AND ((CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L15_TBL + " MOUSIKOMI ");
				sql.append( "WHERE MOUSIKOMI.STATUS = '3'" );
				sql.append( " AND MOUSIKOMI.UKETSUKE_JYOTAI IS NULL)) " );
			}else if(jyukojyokyo.equals("3")){
				sql.append( " AND ((CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L51_TBL + " KYOIKU ");
				sql.append( "WHERE KYOIKU.SYURYO_HANTEI = '0'))" );	
			}else if(jyukojyokyo.equals("4")){
				sql.append( " AND ((CLASS.KAMOKU_CODE,CLASS.CLASS_CODE) IN " );
				sql.append( " ( SELECT KAMOKU_CODE,CLASS_CODE FROM " );
				sql.append( HcdbDef.L51_TBL + " KYOIKU ");
				sql.append( "WHERE KYOIKU.SYURYO_HANTEI = '1'))" );	
			}
            //�N���X�}�X�^�\�[�g���̍쐬
            String sort = classBean.getSort();
            if(sort == null || sort.equals("")) {
				sql.append( " ORDER BY CLASS.KAISIBI ASC,CLASS.KAMOKU_CODE ASC,CLASS.CLASS_CODE ASC" );
            }else if(sort.equals("0")){
				sql.append( " ORDER BY CLASS.KAMOKU_CODE ASC" );
            }else if(sort.equals("1")){
				sql.append( " ORDER BY CLASS.CLASS_CODE ASC" );
			}else if(sort.equals("2")){
				sql.append( " ORDER BY CLASS.KAISIBI ASC" );
            }else if(sort.equals("kamokuIchiran")){
            	sql.append( " ORDER BY CLASS.KAISIBI ASC,CLASS.SYURYOBI ASC,CLASS.CHIKU_CODE ASC");
            }
            
            //���b�N
            sql.append( PCY_DBUtils.getInstance(  ).getLock( lock ) );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            // �������s
            Log.debug( sql.toString(  ) );
            ps = con.prepareStatement( sql.toString(  ) );

            int count = 1;

            for ( Iterator ite = kamokuConditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                Object key = ite.next(  );
                Log.debug( Integer.toString( count ) + ":" + key + ":"
                    + kamokuConditions.get( key ) );
                if(key.equals("KAMOKU_CODE")){
					StringTokenizer st = new StringTokenizer((String)kamokuConditions.get( key ),",");
					int i = st.countTokens();
					while (st.hasMoreTokens()) {//�g�[�N���������J��Ԃ�
						ps.setObject( count,(st.nextToken()));
					   count++;
					}
                }else if(key.equals("KAMOKU_MEI1")){
                	String kamoku_mei1 = (String)kamokuConditions.get(key);
                	kamoku_mei1 = "%" + kamoku_mei1 + "%";
                	ps.setObject(count,kamoku_mei1);
					count++;
                }else{
					ps.setObject( count, kamokuConditions.get( key ) );
					count++;
                }
            }

            for ( Iterator ite = classConditions.keySet(  ).iterator(  ); ite.hasNext(  );
                count++ ) {
                Object key = ite.next(  );
                Log.debug( Integer.toString( count ) + ":" + key + ":" + classConditions.get( key ) );

				//�\���󋵂Ǝ�u�󋵂͖���
				if ( key.equals("MOUSIKOMI_JYOKYO")){
				} else	if (key.equals("JYUKO_JYOKYO")){
				}else{
                	ps.setObject( count, classConditions.get( key ) );
				}
            }

            ResultSet rs = ps.executeQuery(  );

            while ( rs.next(  ) ) {
                ret.add( new PCY_ClassBean( rs, "KAMOKU", "CLASS" ) );
            }

			/* ���\�������̏ꍇ�A���̌��������Ŏ擾�����N���X�̂��Ƃɂ���ɍi�荞��*/
			/* �擾�����N���X���S�БΏۂ̏ꍇ�AL15,L51�ɐ\�����������̂��Y��*/
			/* �擾�����N���X����S�БΏۂ̏ꍇ�A�ΏێҐݒ肳��Ă���l��L15,L51�ɖ����ꍇ�ɊY��*/
			
			PCY_ClassBean[] classBeans = ( PCY_ClassBean[] )ret.toArray( new PCY_ClassBean[0] );
			PCY_ClassBean[] ret_classBeans = null;
			PCY_MousikomiJyokyoBean kensaku_mousikomi = new PCY_MousikomiJyokyoBean();
			PCY_KensyuRirekiBean kensaku_rireki = new PCY_KensyuRirekiBean();
			
			ArrayList retClass = new ArrayList();
			
			if(mousikomi != null && mousikomi.equals("0")){//���������Ɂu���\���v�ݒ肠��
				
				PCY_MousikomiJyokyoEJBHome home_mousikomi = (PCY_MousikomiJyokyoEJBHome)locator.getServiceLocation(
												"PCY_MousikomiJyokyoEJB",
												 PCY_MousikomiJyokyoEJBHome.class );
				PCY_MousikomiJyokyoEJB ejb_mousikomi = home_mousikomi.create();
/* ���\��������EJB���� 2005.2.8 */
/*

				PCY_TaisyoEJBHome home_taisyo = (PCY_TaisyoEJBHome)locator.getServiceLocation(
																"PCY_TaisyoEJB",
																 PCY_TaisyoEJBHome.class );
				PCY_TaisyoEJB ejb_taisyo = home_taisyo.create();
				


				for(int i=0 ; i < classBeans.length; i++){
					if(classBeans[i].getZensyaTaisyoFlg().equals("1")){//�S�БΏ�
						kensaku_mousikomi.setClassBean(classBeans[i]);
						kensaku_rireki.setClassCode(classBeans[i].getClassCode());
						kensaku_rireki.setKamokuCode(classBeans[i].getKamokuBean().getKamokuCode());
						
						PCY_MousikomiJyokyoBean[] mousikomiBeans = ejb_mousikomi.getList(kensaku_mousikomi,loginuser);
						PCY_KensyuRirekiBean[] rirekiBeans = ejb_mousikomi.getListL51(kensaku_rireki,loginuser);
						if((mousikomiBeans == null || mousikomiBeans.length == 0) && (rirekiBeans == null || rirekiBeans.length == 0)){
							//L15�AL51���e�[�u���Ƀf�[�^���ꌏ��������΁A�f�[�^�ێ�
							retClass.add(classBeans[i]);
						}
															
					}else{//��S�БΏ�
						PCY_TaisyosyaBean[] taisyo =  ejb_taisyo.getAllTaisyosya(classBeans[i],false,loginuser);
						for(int t = 0; t < taisyo.length ; t++){
							
							kensaku_mousikomi.setClassBean(taisyo[t].getClassBean());
							kensaku_mousikomi.setSimeiNo(taisyo[t].getSimeiNo());
							kensaku_rireki.setClassCode(taisyo[t].getClassBean().getClassCode());
							kensaku_rireki.setKamokuCode(taisyo[t].getClassBean().getKamokuBean().getKamokuCode());
							kensaku_rireki.setSimeiNo(taisyo[t].getSimeiNo());
							
							PCY_MousikomiJyokyoBean[] mousikomiBeans = ejb_mousikomi.getList(kensaku_mousikomi,loginuser);
							PCY_KensyuRirekiBean[] rirekiBeans = ejb_mousikomi.getListL51(kensaku_rireki,loginuser);
							if((mousikomiBeans == null || mousikomiBeans.length == 0) && (rirekiBeans == null || rirekiBeans.length == 0)){
								//L15�AL51���e�[�u���Ƀf�[�^���ꌏ�������A�ێ����Ă���List�Ƀf�[�^���Ȃ���΁A�f�[�^�ێ�
								if(!retClass.contains(classBeans[i])){
									retClass.add(classBeans[i]);
								}
								
							}
						}
						
					}
				}
*/
				/* ���\��������EJB�����܂����B*/
				ret_classBeans = ejb_mousikomi.getMiMousikomi(classBeans,loginuser);
/* ���\��������EJB���� 2005.2.8 */

			}else{//���������Ɂu���\���v�ݒ�Ȃ��̏ꍇ�͂��̂܂ܕԂ�
				ret_classBeans = ( PCY_ClassBean[] )ret.toArray( new PCY_ClassBean[0] );
			}
			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return ret_classBeans;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		}catch (Exception e ){
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw new EJBException( e );
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
			if ( ps_mimousikomi != null ) {
				try {
					ps_mimousikomi.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * <pre>
	 * �N���X�}�X�^���������Č��ʂ� PCY_ClassBean �̔z��Ƃ��ĕԂ��܂��B
	 * �������ʂ����������ꍇ�͋�̔z���Ԃ��܂��B
	 * �ȉ��̍��ڂ����������Ƃ��Ďg�p�ł��܂��B
	 * �폜���ꂽ�N���X���܂݂܂�
	 * �E�N���X�R�[�h
	 * �E�o�[�W�����Ǘ�
	 * �E�N���X�O���[�v
	 * �E�J�e�S���R�[�h�P
	 * �E�J�e�S���R�[�h�Q
	 * �E�J�e�S���R�[�h�R
	 * �E�J�e�S���R�[�h�S
	 * </pre>
	 *
	 * @param classBean ��������
	 * @param lock true�̏ꍇ���b�N����Afalse�̏ꍇ���b�N�Ȃ�
	 * @param loginuser ���O�C�����[�U
	 * @return ��������
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_ClassBean[] doAllSelect( PCY_ClassBean classBean, boolean lock,
		PCY_PersonalBean loginuser ) {
		Connection con       = null;
		PreparedStatement ps = null;
		PreparedStatement ps_mimousikomi = null;

		try {
			Collection ret   = new ArrayList(  );
			StringBuffer sql = new StringBuffer(  );
			sql.append( "SELECT " + PCY_KamokuBean.getColumns( "kamoku" ) + ", " );
			sql.append( PCY_ClassBean.getColumns( "class" ) );
			sql.append( "  FROM " );
			sql.append( HcdbDef.L01_TBL );
			sql.append( " KAMOKU, " );
			sql.append( HcdbDef.L02_TBL );
			sql.append( " CLASS" );

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			// ���������̍쐬
			StringBuffer where = new StringBuffer(  );

			// �Ȗڃ}�X�^
			Map kamokuConditions = classBean.getKamokuBean(  ).extractConditions(  );

			for ( Iterator ite = kamokuConditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
				Object column = ite.next(  );

				if ( column.equals( "KAMOKU_MEI1" ) ) {
					where.append( " AND KAMOKU." + column + " LIKE ?" );
				} else if(column.equals( "KAMOKU_CODE" )){
					String subStr = getSQLKamokuCode(kamokuConditions.get(column).toString(),"KAMOKU."+column);
					where.append(subStr);
				} else{
					where.append( " AND KAMOKU." + column + "=?" );
				}
			}

			where.append( " AND KAMOKU.SAKUJYO_FLG='0'" );

			// �N���X�}�X�^
			Map classConditions = classBean.extractConditions(  );

			for ( Iterator ite = classConditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
				Object column = ite.next(  );
				if ( column.equals( "SYURYOBI" ) ) {
					where.append( " AND CLASS." + column + ">=?" );
				} else if ( column.equals( "KAISIBI" ) ) {
					where.append( " AND CLASS." + column + "<=?" );
				} else if ( column.equals("MOUSIKOMI_JYOKYO")){ //�\���󋵂͖���
				} else	if (column.equals("JYUKO_JYOKYO")){      //��u�󋵂͖���
				} else {
					where.append( " AND CLASS." + column + "=?" );
				}
			}
			
			where.append( " AND KAMOKU.KAMOKU_CODE=CLASS.KAMOKU_CODE" );
            
			sql.append( where.toString(  ).replaceFirst( "AND", "WHERE" ) );
            
			//���b�N
			sql.append( PCY_DBUtils.getInstance(  ).getLock( lock ) );

			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con = locator.getDataSource(  ).getConnection(  );

			// �������s
			Log.debug( sql.toString(  ) );
			ps = con.prepareStatement( sql.toString(  ) );

			int count = 1;

			for ( Iterator ite = kamokuConditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
				Object key = ite.next(  );
				Log.debug( Integer.toString( count ) + ":" + key + ":"
					+ kamokuConditions.get( key ) );
				if(key.equals("KAMOKU_CODE")){
					StringTokenizer st = new StringTokenizer((String)kamokuConditions.get( key ),",");
					int i = st.countTokens();
					while (st.hasMoreTokens()) {//�g�[�N���������J��Ԃ�
						ps.setObject( count,(st.nextToken()));
					   count++;
					}
				}else if(key.equals("KAMOKU_MEI1")){
					String kamoku_mei1 = (String)kamokuConditions.get(key);
					kamoku_mei1 = "%" + kamoku_mei1 + "%";
					ps.setObject(count,kamoku_mei1);
					count++;
				}else{
					ps.setObject( count, kamokuConditions.get( key ) );
					count++;
				}
			}

			for ( Iterator ite = classConditions.keySet(  ).iterator(  ); ite.hasNext(  );
				count++ ) {
				Object key = ite.next(  );
				Log.debug( Integer.toString( count ) + ":" + key + ":" + classConditions.get( key ) );

				ps.setObject( count, classConditions.get( key ) );
			}

			ResultSet rs = ps.executeQuery(  );

			while ( rs.next(  ) ) {
				ret.add( new PCY_ClassBean( rs, "KAMOKU", "CLASS" ) );
			}

			/* ���\�������̏ꍇ�A���̌��������Ŏ擾�����N���X�̂��Ƃɂ���ɍi�荞��*/
			/* �擾�����N���X���S�БΏۂ̏ꍇ�AL15,L51�ɐ\�����������̂��Y��*/
			/* �擾�����N���X����S�БΏۂ̏ꍇ�A�ΏێҐݒ肳��Ă���l��L15,L51�ɖ����ꍇ�ɊY��*/
			
			PCY_ClassBean[] classBeans = ( PCY_ClassBean[] )ret.toArray( new PCY_ClassBean[0] );

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return classBeans;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		}catch (Exception e ){
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw new EJBException( e );
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
			if ( ps_mimousikomi != null ) {
				try {
					ps_mimousikomi.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

    /**
     * <pre>
     * �N���X�}�X�^���������Č��ʂ� PCY_ClassBean �̔z��Ƃ��ĕԂ��܂��B
     * �������ʂ����������ꍇ�͋�̔z���Ԃ��܂��B
     * �ȉ��̍��ڂ����������Ƃ��Ďg�p�ł��܂��B
     * �E�E��
     * �E��啪��
     * �E���x��
     * �E�N���X�R�[�h
     * �E�N���X�X�V��
     * �E�N���X�X�V����
     * �E�J�n��
     * �E�I����
     * �E�n��
     * �E�ȖڃR�[�h
     * �E�Ȗږ��P
     * �E�o�[�W�����Ǘ�
     * �E�N���X�O���[�v
     * �E�J�e�S���R�[�h�P
     * �E�J�e�S���R�[�h�Q
     * �E�J�e�S���R�[�h�R
     * �E�J�e�S���R�[�h�S
     * �E�J�e�S���R�[�h�T
     * �E�Ǘ���
     * �\�[�g���͈ȉ��̂Ƃ���ł��B
     * 1.�ȖڃR�[�h
     * 2.�J�n��(�~��)
     * 3.�I����(�~��)
     * 4.�N���X��
     * </pre>
     *
     * @param classBean ��������
     * @param kanrenBean ��������
     * @param loginuser ���O�C�����[�U
     * @return ��������
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_ClassBean[] doSelectByKanrenKyoiku( PCY_ClassBean classBean,
        PCY_KanrenKyoikuKamokuBean kanrenBean, PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            Collection ret   = new ArrayList(  );
            StringBuffer sql = new StringBuffer(  );
            sql.append( "SELECT " + PCY_KamokuBean.getColumns( "kamoku" ) + ", " );
            sql.append( PCY_ClassBean.getColumns( "class" ) );
            sql.append( "  FROM " );
            sql.append( HcdbDef.p_kanren_kyoikuTbl );
            sql.append( " KANREN, " );
            sql.append( HcdbDef.L01_TBL );
            sql.append( " KAMOKU, " );
            sql.append( HcdbDef.L02_TBL );
            sql.append( " CLASS" );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // ���������̍쐬
            StringBuffer where = new StringBuffer(  );

            // �֘A����Ȗڃ}�X�^
            Map kanrenConditions = kanrenBean.extractConditions(  );

            for ( Iterator ite = kanrenConditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                Object column = ite.next(  );
                where.append( " AND KANREN." + column + "=?" );
            }

            // �Ȗڃ}�X�^
            Map kamokuConditions = classBean.getKamokuBean(  ).extractConditions(  );

            for ( Iterator ite = kamokuConditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                Object column = ite.next(  );

                if ( column.equals( "KAMOKU_MEI1" ) ) {
                    where.append( " AND KAMOKU." + column + " LIKE ?" );
                } else if ( column.equals( "KAMOKU_CODE" ) ) {
                    where.append( " AND KAMOKU." + column + " LIKE ?" );
                } else {
                    where.append( " AND KAMOKU." + column + "=?" );
                }
            }

            where.append( " AND KAMOKU.SAKUJYO_FLG='0'" );

            // �N���X�}�X�^
            Map classConditions = classBean.extractConditions(  );

            for ( Iterator ite = classConditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                Object column = ite.next(  );

                if ( column.equals( "SYURYOBI" ) ) {
                    where.append( " AND CLASS." + column + ">=?" );
                } else if ( column.equals( "KAISIBI" ) ) {
                    where.append( " AND CLASS." + column + "<=?" );
                } else {
                    where.append( " AND CLASS." + column + "=?" );
                }
            }

            where.append( " AND CLASS.SAKUJYO_FLG='0'" );
            where.append( " AND KANREN.KAMOKU_CODE=KAMOKU.KAMOKU_CODE" );
            where.append( " AND KAMOKU.KAMOKU_CODE=CLASS.KAMOKU_CODE" );
            sql.append( where.toString(  ).replaceFirst( "AND", "WHERE" ) );

            //�N���X�}�X�^�\�[�g���̍쐬
            sql.append( " ORDER BY CLASS.KAMOKU_CODE," );
            sql.append( "          CLASS.KAISIBI DESC," );
            sql.append( "          CLASS.SYURYOBI DESC," );
            sql.append( "          CLASS.CLASS_MEI" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            // �������s
            Log.debug( sql.toString(  ) );
            ps = con.prepareStatement( sql.toString(  ) );

            int count = 1;

            for ( Iterator ite = kanrenConditions.keySet(  ).iterator(  ); ite.hasNext(  );
                count++ ) {
                Object key = ite.next(  );
                Log.debug( Integer.toString( count ) + ":" + key + ":"
                    + kanrenConditions.get( key ) );
                ps.setObject( count, kanrenConditions.get( key ) );
            }

            for ( Iterator ite = kamokuConditions.keySet(  ).iterator(  ); ite.hasNext(  );
                count++ ) {
                Object key = ite.next(  );
                Log.debug( Integer.toString( count ) + ":" + key + ":"
                    + kamokuConditions.get( key ) );
                ps.setObject( count, kamokuConditions.get( key ) );
            }

            for ( Iterator ite = classConditions.keySet(  ).iterator(  ); ite.hasNext(  );
                count++ ) {
                Object key = ite.next(  );
                Log.debug( Integer.toString( count ) + ":" + key + ":" + classConditions.get( key ) );
                ps.setObject( count, classConditions.get( key ) );
            }

            ResultSet rs = ps.executeQuery(  );

            while ( rs.next(  ) ) {
                ret.add( new PCY_ClassBean( rs, "KAMOKU", "CLASS" ) );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ( PCY_ClassBean[] )ret.toArray( new PCY_ClassBean[0] );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �N���X�}�X�^���쐬���܂��B
     *
     * @param classBeans �쐬���e
     * @param taisyosyaBeans �Ώێҏ��
     * @param taisyososikiBeans �Ώۑg�D���
     * @param taisyosyokusyuBeans �ΏېE����
     * @param loginuser ���O�C�����[�U
     * @return �쐬����
     * @throws PCY_WarningException �C���T�[�g�� SQLException �����������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doInsert( PCY_ClassBean[] classBeans, PCY_TaisyosyaBean[] taisyosyaBeans,
        PCY_TaisyososikiBean[] taisyososikiBeans, PCY_TaisyosyokusyuBean[] taisyosyokusyuBeans,
        PCY_PersonalBean loginuser ) throws PCY_WarningException {
        Connection con           = null;
        PreparedStatement ps     = null;
        PreparedStatement saiban = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �ȖڃR�[�h�A�N���X�R�[�h���L�[�Ƀ\�[�g
            Arrays.sort( classBeans, new ClassCodeComparator(  ) );

            // SQL�쐬

            /* For SAS CHG#P-ALC01-030-002-S �V�����c�a���C�A�E�g�ɑΉ� */
            StringBuffer sql = new StringBuffer(  );
            sql.append( "INSERT INTO " );
            sql.append( HcdbDef.L02_TBL );
            sql.append( " (" );
            sql.append( "kamoku_code," );
            sql.append( "class_code," );
            sql.append( "class_mei," );
            sql.append( "nissuu," );
            sql.append( "kaisibi," );
            sql.append( "syuryobi," );
            sql.append( "kaisaijikan," );
            sql.append( "kaisijikoku," );
            sql.append( "syuryojikoku," );
            sql.append( "mousikomi_kaisibi," );
            sql.append( "mousikomi_syuryobi," );
            sql.append( "jyukou_kigen," );
            sql.append( "chiku_code," );
            sql.append( "chiku_mei," );
            sql.append( "kyositu_code," );
            sql.append( "kyositu_mei," );
            sql.append( "teiin," );
            sql.append( "kaisai_saisyo_ninzuu," );
            sql.append( "kousi_code," );
            sql.append( "kousi_mei," );
            sql.append( "kisyo_ikkatsu_flg," );
            sql.append( "zensya_taisyo_flg," );
            sql.append( "mousikomi_kubun," );
            sql.append( "syonin_kubun," );
            sql.append( "uketuke_kubun," );
            sql.append( "houkoku_kubun," );
            sql.append( "ninsyo_kubun," );
            sql.append( "hantei_kubun," );
            sql.append( "kaisai_jyotai," );
            sql.append( "manseki_flg," );
            sql.append( "annai_mail_kubun," );
            sql.append( "follow_mail_kubun," );
            sql.append( "follow_mail_nissuu1," );
            sql.append( "follow_mail_nissuu2," );
            sql.append( "bikou," );
            sql.append( "sakujyo_flg," );
            sql.append( "tourokubi," );
            sql.append( "tourokujikoku," );
            sql.append( "tourokusya," );
            sql.append( "kousinbi," );
            sql.append( "kousinjikoku," );
            sql.append( "kousinsya," );
			//CHG#B-A30AM2-007 -S
            //sql.append( "yoyaku" );
            sql.append( "yoyaku," );
            sql.append( "houkoku_kubun_2" );
            sql.append( ")  VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?," );
            sql.append( "            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?," );
            sql.append( "            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?," );
			sql.append( "            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?," );
			//sql.append( "            ?, ?, ?)" );
			sql.append( "            ?, ?, ?, ?)" ); 
            //CHG#B-A30AM2-007 -E

            /* CHG#P-ALC01-030-002-E */

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �X�V���s

            PCY_CounterEJBHome counterHome = ( PCY_CounterEJBHome )locator.getServiceLocation( "PCY_CounterEJB",
                    PCY_CounterEJBHome.class );
            PCY_CounterEJB counterEjb = counterHome.create(  );

            int count = 0;

            for ( int i = 0; i < classBeans.length; i++ ) {
				ps = con.prepareStatement( sql.toString(  ) );
				
                /* �̔Ԃ���Ă��Ȃ��ꍇ�����ŃN���X�R�[�h���Z�b�g���� */
                if ( classBeans[i].getClassCode(  ) == null ) {
                    classBeans[i].setClassCode( counterEjb.countClassCode(  ) );
                }

                /* INSERT�p�����[�^���Z�b�g���� */
                ps.setString( 1, classBeans[i].getKamokuBean(  ).getKamokuCode(  ) );
                ps.setString( 2, classBeans[i].getClassCode(  ) );
                ps.setString( 3, classBeans[i].getClassMei(  ) );

                if ( classBeans[i].getNissuu(  ) != null ) {
                    ps.setFloat( 4, classBeans[i].getNissuu(  ).floatValue(  ) ); //CHG#P-ALH01-003-002(C)
                } else {
                    ps.setNull( 4, java.sql.Types.FLOAT ); //CHG#P-ALH01-003-002(C)
                }

                ps.setString( 5, classBeans[i].getKaisibi(  ) );
                ps.setString( 6, classBeans[i].getSyuryobi(  ) );
                ps.setString( 7, classBeans[i].getKaisaijikan(  ) );
                ps.setString( 8, classBeans[i].getKaisijikoku(  ) );
                ps.setString( 9, classBeans[i].getSyuryojikoku(  ) );
                ps.setString( 10, classBeans[i].getMousikomiKaisibi(  ) );
                ps.setString( 11, classBeans[i].getMousikomiSyuryobi(  ) );

                if ( ( classBeans[i].getJyukouKigen(  ) == null )
                    || classBeans[i].getJyukouKigen(  ).equals( "" ) ) {
                    ps.setNull( 12, java.sql.Types.CHAR );
                } else {
                    ps.setString( 12, classBeans[i].getJyukouKigen(  ) );
                }

                ps.setString( 13, classBeans[i].getChikuCode(  ) );
                ps.setString( 14, classBeans[i].getChikuMei(  ) );
                ps.setString( 15, classBeans[i].getKyosituCode(  ) );
                ps.setString( 16, classBeans[i].getKyosituMei(  ) );

                if ( classBeans[i].getTeiin(  ) != null ) {
                    ps.setInt( 17, classBeans[i].getTeiin(  ).intValue(  ) );
                } else {
                    ps.setNull( 17, java.sql.Types.INTEGER );
                }

                if ( classBeans[i].getKaisaiSaisyoNinzuu(  ) != null ) {
                    ps.setInt( 18, classBeans[i].getKaisaiSaisyoNinzuu(  ).intValue(  ) );
                } else {
                    ps.setNull( 18, java.sql.Types.INTEGER );
                }

                ps.setString( 19, classBeans[i].getKousiCode(  ) );
                ps.setString( 20, classBeans[i].getKousiMei(  ) );

                /* CHG#P-ALC01-030-002-S */
                ps.setString( 21, classBeans[i].getKisyoIkkatsuFlg(  ) );
                ps.setString( 22, classBeans[i].getZensyaTaisyoFlg(  ) );
                ps.setString( 23, classBeans[i].getMousikomiKubun(  ) );
                ps.setString( 24, classBeans[i].getSyoninKubun(  ) );
                ps.setString( 25, classBeans[i].getUketukeKubun(  ) );
                ps.setString( 26, classBeans[i].getHoukokuKubun(  ) );
                ps.setString( 27, classBeans[i].getNinsyoKubun(  ) );
                ps.setString( 28, classBeans[i].getHanteiKubun(  ) );
                ps.setString( 29, classBeans[i].getKaisaiJyotai(  ) );
                ps.setString( 30, classBeans[i].getMansekiFlg(  ) );
                ps.setString( 31, classBeans[i].getAnnaiMailKubun(  ) );
                ps.setString( 32, classBeans[i].getFollowMailKubun(  ) );

                if ( classBeans[i].getFollowMailNissuu1(  ) != null ) {
                    try {
                        ps.setInt( 33, Integer.parseInt( classBeans[i].getFollowMailNissuu1(  ) ) );
                    } catch ( NumberFormatException e ) {
                        ps.setNull( 33, java.sql.Types.INTEGER );
                    }
                } else {
                    ps.setNull( 33, java.sql.Types.INTEGER );
                }

                if ( classBeans[i].getFollowMailNissuu2(  ) != null ) {
                    try {
                        ps.setInt( 34, Integer.parseInt( classBeans[i].getFollowMailNissuu2(  ) ) );
                    } catch ( NumberFormatException e ) {
                        ps.setNull( 34, java.sql.Types.INTEGER );
                    }
                } else {
                    ps.setNull( 34, java.sql.Types.INTEGER );
                }

                ps.setString( 35, classBeans[i].getBikou(  ) );
                ps.setString( 36, "0" );
                ps.setString( 37, PZZ010_CharacterUtil.GetDay(  ) );
                ps.setString( 38, PZZ010_CharacterUtil.GetTime(  ) );
                ps.setString( 39, loginuser.getSimeiNo(  ) );
                ps.setString( 40, "        " );
                ps.setString( 41, "      " );
                ps.setString( 42, "          " );

				if ( classBeans[i].getYoyaku(  ) != null ) {
					ps.setInt( 43, classBeans[i].getYoyaku(  ).intValue(  ) );
				} else {
					ps.setNull( 43, java.sql.Types.INTEGER );
				}

				ps.setString( 44, classBeans[i].getHoukokuKubun2() );//INS#B-A30AM2-007
                
				/* CHG#P-ALC01-030-002-E */
                count += ps.executeUpdate(  );
                ps.close();

                this.doUpdateTaisyo( classBeans[i], taisyosyaBeans, taisyososikiBeans,
                    taisyosyokusyuBeans, loginuser );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( saiban != null ) {
                try {
                    saiban.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �v���C�}���[�L�[���L�[�Ƃ��ăN���X�}�X�^�̊J�Ï�Ԃ��X�V���܂��B
     *
     * @param classBean �X�V���e
     * @param loginuser ���O�C�����[�U
     * @return �X�V����
     * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdateKaisaiJyotai( PCY_ClassBean classBean, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // SQL�쐬
            StringBuffer sql = new StringBuffer(  );
            sql.append( "UPDATE " + HcdbDef.L02_TBL );
            sql.append( " SET  KAISAI_JYOTAI=?," );
            sql.append( "      KOUSINBI=?," );
            sql.append( "      KOUSINJIKOKU=?," );
            sql.append( "      KOUSINSYA=?" );
            sql.append( " WHERE KAMOKU_CODE=?" );
            sql.append( "   AND CLASS_CODE=?" );
            sql.append( "   AND KOUSINBI=?" );
            sql.append( "   AND KOUSINJIKOKU=?" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �X�V���s
            ps = con.prepareStatement( sql.toString(  ) );
            ps.setString( 1, classBean.getKaisaiJyotai(  ) );
            ps.setString( 2, PZZ010_CharacterUtil.GetDay(  ) );
            ps.setString( 3, PZZ010_CharacterUtil.GetTime(  ) );
            ps.setString( 4, loginuser.getSimeiNo(  ) );
            ps.setString( 5, classBean.getKamokuBean(  ).getKamokuCode(  ) );
            ps.setString( 6, classBean.getClassCode(  ) );
            ps.setString( 7, classBean.getKousinbi(  ) );
            ps.setString( 8, classBean.getKousinjikoku(  ) );

            int ret = ps.executeUpdate(  );

            if ( ret != 1 ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ret;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �v���C�}���[�L�[���L�[�Ƃ��ăN���X�}�X�^���X�V���܂��B
     *
     * @param classBeans �X�V���e
     * @param taisyosyaBeans �Ώێҏ��
     * @param taisyososikiBeans �Ώۑg�D���
     * @param taisyosyokusyuBeans �ΏېE����
     * @param loginuser ���O�C�����[�U
     * @return �X�V����
     * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdate( PCY_ClassBean[] classBeans, PCY_TaisyosyaBean[] taisyosyaBeans,
        PCY_TaisyososikiBean[] taisyososikiBeans, PCY_TaisyosyokusyuBean[] taisyosyokusyuBeans,
        PCY_PersonalBean loginuser ) throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �ȖڃR�[�h�A�N���X�R�[�h���L�[�Ƀ\�[�g
            Arrays.sort( classBeans, new ClassCodeComparator(  ) );

            // SQL�쐬
            StringBuffer sql = new StringBuffer(  );
            sql.append( "UPDATE " );
            sql.append( HcdbDef.L02_TBL );
            sql.append( "    SET CLASS_MEI=?," );
            sql.append( "        KAISIBI=?," );
            sql.append( "        SYURYOBI=?," );
            sql.append( "        KAISAIJIKAN=?," );
            sql.append( "        KAISIJIKOKU=?," );
            sql.append( "        SYURYOJIKOKU=?," );
            sql.append( "        MOUSIKOMI_KAISIBI=?," );
            sql.append( "        MOUSIKOMI_SYURYOBI=?," );
            sql.append( "        JYUKOU_KIGEN=?," );
            sql.append( "        CHIKU_CODE=?," );
            sql.append( "        CHIKU_MEI=?," );
            sql.append( "        KYOSITU_CODE=?," );
            sql.append( "        KYOSITU_MEI=?," );
            sql.append( "        TEIIN=?," );
            sql.append( "        KAISAI_SAISYO_NINZUU=?," );
            sql.append( "        KOUSI_CODE=?," );
            sql.append( "        KOUSI_MEI=?," );
            sql.append( "        KAISAI_JYOTAI=?," );
            sql.append( "        ANNAI_MAIL_KUBUN=?," );
            sql.append( "        FOLLOW_MAIL_KUBUN=?," );
            sql.append( "        FOLLOW_MAIL_NISSUU1=?," );
            sql.append( "        FOLLOW_MAIL_NISSUU2=?," );
            sql.append( "        BIKOU=?," );
            sql.append( "        KOUSINBI=?," );
            sql.append( "        KOUSINJIKOKU=?," );
			sql.append( "        KOUSINSYA=?," );
			sql.append( "        YOYAKU=?," );
			sql.append( "        NISSUU=?," );
			sql.append( "        KISYO_IKKATSU_FLG=?," );
			sql.append( "        ZENSYA_TAISYO_FLG=?," );
			sql.append( "        MOUSIKOMI_KUBUN=?," );
			sql.append( "        SYONIN_KUBUN=?," );
			sql.append( "        UKETUKE_KUBUN=?," );
			sql.append( "        HOUKOKU_KUBUN=?," );
			sql.append( "        NINSYO_KUBUN=?," );
			sql.append( "        HANTEI_KUBUN=?," );
			//INS#B-A30AM2-007 -S
			//sql.append( "        MANSEKI_FLG=?" );
			sql.append( "        MANSEKI_FLG=?," );
			sql.append( "        HOUKOKU_KUBUN_2=?" );
			//INS#B-A30AM2-007 -E
            sql.append( "  WHERE KAMOKU_CODE=?" );
            sql.append( "    AND CLASS_CODE=?" );
            sql.append( "    AND SAKUJYO_FLG='0'" );
            sql.append( "    AND TOUROKUBI=?" );
            sql.append( "    AND TOUROKUJIKOKU=?" );
            sql.append( "    AND TOUROKUSYA=?" );
            sql.append( "    AND KOUSINBI=?" );
            sql.append( "    AND KOUSINJIKOKU=?" );
            sql.append( "    AND KOUSINSYA=?" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            /* �f�o�b�O���O�o�� */
            Log.debug( sql.toString(  ) );

            // �X�V���s

            int count = 0;

            for ( int i = 0; i < classBeans.length; i++ ) {
				ps = con.prepareStatement( sql.toString(  ) );
				
                ps.setString( 1, classBeans[i].getClassMei(  ) );
                ps.setString( 2, classBeans[i].getKaisibi(  ) );
                ps.setString( 3, classBeans[i].getSyuryobi(  ) );
                ps.setString( 4, classBeans[i].getKaisaijikan(  ) );
                ps.setString( 5, classBeans[i].getKaisijikoku(  ) );
                ps.setString( 6, classBeans[i].getSyuryojikoku(  ) );
                ps.setString( 7, classBeans[i].getMousikomiKaisibi(  ) );
                ps.setString( 8, classBeans[i].getMousikomiSyuryobi(  ) );

                if ( ( classBeans[i].getJyukouKigen(  ) == null )
                    || classBeans[i].getJyukouKigen(  ).equals( "" ) ) {
                    ps.setNull( 9, java.sql.Types.CHAR );
                } else {
                    ps.setString( 9, classBeans[i].getJyukouKigen(  ) );
                }

                ps.setString( 10, classBeans[i].getChikuCode(  ) );
                ps.setString( 11, classBeans[i].getChikuMei(  ) );
                ps.setString( 12, classBeans[i].getKyosituCode(  ) );
                ps.setString( 13, classBeans[i].getKyosituMei(  ) );

                if ( classBeans[i].getTeiin(  ) != null ) {
                    ps.setInt( 14, classBeans[i].getTeiin(  ).intValue(  ) );
                } else {
                    ps.setNull( 14, java.sql.Types.INTEGER );
                }

                if ( classBeans[i].getKaisaiSaisyoNinzuu(  ) != null ) {
                    ps.setInt( 15, classBeans[i].getKaisaiSaisyoNinzuu(  ).intValue(  ) );
                } else {
                    ps.setNull( 15, java.sql.Types.INTEGER );
                }

                ps.setString( 16, classBeans[i].getKousiCode(  ) );
                ps.setString( 17, classBeans[i].getKousiMei(  ) );
                ps.setString( 18, classBeans[i].getKaisaiJyotai(  ) );
                ps.setString( 19, classBeans[i].getAnnaiMailKubun(  ) );
                ps.setString( 20, classBeans[i].getFollowMailKubun(  ) );

                if ( classBeans[i].getFollowMailNissuu1(  ) != null ) {
                    try {
                        ps.setInt( 21, Integer.parseInt( classBeans[i].getFollowMailNissuu1(  ) ) );
                    } catch ( NumberFormatException e ) {
                        ps.setNull( 21, java.sql.Types.INTEGER );
                    }
                } else {
                    ps.setNull( 21, java.sql.Types.INTEGER );
                }

                if ( classBeans[i].getFollowMailNissuu2(  ) != null ) {
                    try {
                        ps.setInt( 22, Integer.parseInt( classBeans[i].getFollowMailNissuu2(  ) ) );
                    } catch ( NumberFormatException e ) {
                        ps.setNull( 22, java.sql.Types.INTEGER );
                    }
                } else {
                    ps.setNull( 22, java.sql.Types.INTEGER );
                }

                ps.setString( 23, classBeans[i].getBikou(  ) );
                ps.setString( 24, PZZ010_CharacterUtil.GetDay(  ) );
                ps.setString( 25, PZZ010_CharacterUtil.GetTime(  ) );
                ps.setString( 26, loginuser.getSimeiNo(  ) );

				if ( classBeans[i].getYoyaku(  ) != null ) {
					ps.setInt( 27, classBeans[i].getYoyaku(  ).intValue(  ) );
				} else {
					ps.setNull( 27, java.sql.Types.INTEGER );
				}

				if ( classBeans[i].getNissuu(  ) != null ) {
					ps.setFloat( 28, classBeans[i].getNissuu(  ).floatValue(  ) );
				} else {
					ps.setNull( 28 , java.sql.Types.FLOAT );
				}

				ps.setString( 29, classBeans[i].getKisyoIkkatsuFlg(  ) );
				ps.setString( 30, classBeans[i].getZensyaTaisyoFlg(  ) );
				ps.setString( 31, classBeans[i].getMousikomiKubun(  ) );
				ps.setString( 32, classBeans[i].getSyoninKubun(  ) );
				ps.setString( 33, classBeans[i].getUketukeKubun(  ) );
				ps.setString( 34, classBeans[i].getHoukokuKubun(  ) );
				ps.setString( 35, classBeans[i].getNinsyoKubun(  ) );
				ps.setString( 36, classBeans[i].getHanteiKubun(  ) );
				ps.setString( 37, classBeans[i].getMansekiFlg(  ) );

				//INS#B-A30AM2-007 -S
				ps.setString( 38, classBeans[i].getHoukokuKubun2() );
//                ps.setString( 38, classBeans[i].getKamokuBean(  ).getKamokuCode(  ) );
//                ps.setString( 39, classBeans[i].getClassCode(  ) );
//                ps.setString( 40, classBeans[i].getTourokubi(  ) );
//                ps.setString( 41, classBeans[i].getTourokujikoku(  ) );
//                ps.setString( 42, classBeans[i].getTourokusya(  ) );
//                ps.setString( 43, classBeans[i].getKousinbi(  ) );
//                ps.setString( 44, classBeans[i].getKousinjikoku(  ) );
//                ps.setString( 45, classBeans[i].getKousinsya(  ) );
                ps.setString( 39, classBeans[i].getKamokuBean(  ).getKamokuCode(  ) );
                ps.setString( 40, classBeans[i].getClassCode(  ) );
                ps.setString( 41, classBeans[i].getTourokubi(  ) );
                ps.setString( 42, classBeans[i].getTourokujikoku(  ) );
                ps.setString( 43, classBeans[i].getTourokusya(  ) );
                ps.setString( 44, classBeans[i].getKousinbi(  ) );
                ps.setString( 45, classBeans[i].getKousinjikoku(  ) );
                ps.setString( 46, classBeans[i].getKousinsya(  ) );
                //INS#B-A30AM2-007 -E
                
                count += ps.executeUpdate(  );
                ps.close();

                this.doUpdateTaisyo( classBeans[i], taisyosyaBeans, taisyososikiBeans,
                    taisyosyokusyuBeans, loginuser );
            }

            if ( classBeans.length != count ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �v���C�}���[�L�[���L�[�Ƃ��ăN���X�}�X�^���폜���܂��B
     *
     * @param classBeans �폜����
     * @param loginuser ���O�C�����[�U
     * @return �폜����
     * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍ폜����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doDelete( PCY_ClassBean[] classBeans, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �ȖڃR�[�h�A�N���X�R�[�h���L�[�Ƀ\�[�g
            Arrays.sort( classBeans, new ClassCodeComparator(  ) );

            /* �N���X�̊J�Ï�Ԃ��I���̂��̂��`�F�b�N���� */
            for ( int i = 0; i < classBeans.length; i++ ) {
                /* �J�Ï�Ԃ��I���łȂ������� */
                if ( !"2".equals( classBeans[i].getKaisaiJyotai(  ) ) ) {
                    context.setRollbackOnly(  );
                    throw new PCY_WarningException( "WCC080" );
                }
            }

            /* �N���X�폜�����𖞂������`�F�b�N���� */
            StringBuffer t05_checksql = new StringBuffer(  );
            t05_checksql.append( "SELECT COUNT(*) FROM " );
            t05_checksql.append( HcdbDef.L51_TBL ); /* For SAS */

            StringBuffer whereKu = new StringBuffer(  );

            for ( int i = 0; i < classBeans.length; i++ ) {
                whereKu.append( " OR ( KAMOKU_CODE=? AND CLASS_CODE=? )" );
            }

            t05_checksql.append( whereKu.toString(  ).replaceFirst( "OR", "WHERE" ) );

            /* �f�o�b�O���O���o�� */
            Log.debug( t05_checksql.toString(  ) );

            /* �R�l�N�V�����擾 */
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );
            ps      = con.prepareStatement( t05_checksql.toString(  ) );

            for ( int i = 0; i < classBeans.length; i++ ) {
                ps.setString( ( i * 2 ) + 1, classBeans[i].getKamokuBean(  ).getKamokuCode(  ) ); // CHG#P-PLI03-022-001
                ps.setString( ( i * 2 ) + 2, classBeans[i].getClassCode(  ) ); // CHG#P-PLI03-022-001
            }

            ResultSet rs = ps.executeQuery(  );
            rs.next(  );

            String t05_count = rs.getString( 1 ).trim(  );

            rs.close(  ); //INS#P-ALH41-001-001
            ps.close(  ); //INS#P-ALH41-001-001

            /* ���C�����e�[�u���ɍ폜�Ώۂ̉Ȗڂ�1���ł�����ꍇ�A�x����ʂɑJ�ڂ����� */
            if ( Integer.parseInt( t05_count ) > 0 ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException( "WCC010" );
            }

            // SQL�쐬
            StringBuffer sql = new StringBuffer(  );
            sql.append( "UPDATE " );
            sql.append( HcdbDef.L02_TBL );
            sql.append( "    SET SAKUJYO_FLG='1'," );
            sql.append( "        KOUSINBI=?," );
            sql.append( "        KOUSINJIKOKU=?," );
            sql.append( "        KOUSINSYA=?" );
            sql.append( "  WHERE KAMOKU_CODE=?" );
            sql.append( "    AND CLASS_CODE=?" );
            sql.append( "    AND KAISAI_JYOTAI IN ('1', '2')" );
            sql.append( "    AND SAKUJYO_FLG='0'" );
            sql.append( "    AND TOUROKUBI=?" );
            sql.append( "    AND TOUROKUJIKOKU=?" );
            sql.append( "    AND TOUROKUSYA=?" );
            sql.append( "    AND KOUSINBI=?" );
            sql.append( "    AND KOUSINJIKOKU=?" );
            sql.append( "    AND KOUSINSYA=?" );

            // �R�l�N�V�����擾
            // DEL#P-ALH41-001-XXX
            //            con     = locator.getDataSource(  ).getConnection(  );
            // �������s

            int count = 0;

            for ( int i = 0; i < classBeans.length; i++ ) {
				ps = con.prepareStatement( sql.toString(  ) );
				
                ps.setString( 1, PZZ010_CharacterUtil.GetDay(  ) );
                ps.setString( 2, PZZ010_CharacterUtil.GetTime(  ) );
                ps.setString( 3, loginuser.getSimeiNo(  ) );
                ps.setString( 4, classBeans[i].getKamokuBean(  ).getKamokuCode(  ) );
                ps.setString( 5, classBeans[i].getClassCode(  ) );
                ps.setString( 6, classBeans[i].getTourokubi(  ) );
                ps.setString( 7, classBeans[i].getTourokujikoku(  ) );
                ps.setString( 8, classBeans[i].getTourokusya(  ) );
                ps.setString( 9, classBeans[i].getKousinbi(  ) );
                ps.setString( 10, classBeans[i].getKousinjikoku(  ) );
                ps.setString( 11, classBeans[i].getKousinsya(  ) );
                count += ps.executeUpdate(  );
                ps.close();
            }

            if ( classBeans.length != count ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �Ώېݒ���X�V���܂��B
     *
     * @param classBean �X�V���e
     * @param taisyosyaBeans �Ώێҏ��
     * @param taisyososikiBeans �Ώۑg�D���
     * @param taisyosyokusyuBeans �ΏېE����
     * @param loginuser ���O�C�����[�U
     */
    private void doUpdateTaisyo( PCY_ClassBean classBean, PCY_TaisyosyaBean[] taisyosyaBeans,
        PCY_TaisyososikiBean[] taisyososikiBeans, PCY_TaisyosyokusyuBean[] taisyosyokusyuBeans,
        PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // CHG#P-BPX-0301J-3021-001-S
            // CHG#P-A30AH4-007-001-S
            // �Ώێ҃e�[�u���쐬
            if ( taisyosyaBeans != null ) {
                // �Ώێ҃e�[�u���폜
                PCY_TaisyosyaBean taisyosyaBean = new PCY_TaisyosyaBean(  );
                taisyosyaBean.setKamokuCode( classBean.getKamokuBean(  ).getKamokuCode(  ) );
                taisyosyaBean.setClassCode( classBean.getClassCode(  ) );
                this.doDeleteTaisyosya( new PCY_TaisyosyaBean[] { taisyosyaBean }, loginuser );

                /* ��s���̓e�[�u���ɑ��݂���΍폜���� */
                this.doDeleteDaikoNyuryokuRecord( classBean, taisyosyaBeans, loginuser );

                // �Ώێ҃e�[�u���쐬
                for ( int j = 0; j < taisyosyaBeans.length; j++ ) {
                    taisyosyaBeans[j].setKamokuCode( classBean.getKamokuBean(  ).getKamokuCode(  ) );
                    taisyosyaBeans[j].setClassCode( classBean.getClassCode(  ) );
                }

                this.doInsertTaisyosya( taisyosyaBeans, loginuser );
            }

            // �Ώۑg�D�e�[�u���쐬
            if ( taisyososikiBeans != null ) {
                // �Ώۑg�D�e�[�u���폜
                PCY_TaisyososikiBean taisyososikiBean = new PCY_TaisyososikiBean(  );
                taisyososikiBean.setKamokuCode( classBean.getKamokuBean(  ).getKamokuCode(  ) );
                taisyososikiBean.setClassCode( classBean.getClassCode(  ) );
                this.doDeleteTaisyososiki( new PCY_TaisyososikiBean[] { taisyososikiBean },
                    loginuser );

                // �Ώۑg�D�e�[�u���쐬
                for ( int j = 0; j < taisyososikiBeans.length; j++ ) {
                    taisyososikiBeans[j].setKamokuCode( classBean.getKamokuBean(  ).getKamokuCode(  ) );
                    taisyososikiBeans[j].setClassCode( classBean.getClassCode(  ) );
                }

                this.doInsertTaisyososiki( taisyososikiBeans, loginuser );
            }

            // �ΏېE��e�[�u���쐬
            if ( taisyosyokusyuBeans != null ) {
                // �ΏېE��e�[�u���폜
                PCY_TaisyosyokusyuBean taisyosyokusyuBean = new PCY_TaisyosyokusyuBean(  );
                taisyosyokusyuBean.setKamokuCode( classBean.getKamokuBean(  ).getKamokuCode(  ) );
                taisyosyokusyuBean.setClassCode( classBean.getClassCode(  ) );
                this.doDeleteTaisyosyokusyu( new PCY_TaisyosyokusyuBean[] { taisyosyokusyuBean },
                    loginuser );

                // �ΏېE��e�[�u���쐬
                for ( int j = 0; j < taisyosyokusyuBeans.length; j++ ) {
                    taisyosyokusyuBeans[j].setKamokuCode( classBean.getKamokuBean(  ).getKamokuCode(  ) );
                    taisyosyokusyuBeans[j].setClassCode( classBean.getClassCode(  ) );
                }

                this.doInsertTaisyosyokusyu( taisyosyokusyuBeans, loginuser );
            }
            // CHG#P-A30AH4-007-001-E
            // CHG#P-BPX-0301J-3021-001-E

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return;
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �ΏێҐݒ�Ɋ܂܂�ĂȂ���s���̓e�[�u�������폜����
     * @param taisyosyaBeans
     * @param loginuser
     * @return
     */
    private int doDeleteDaikoNyuryokuRecord( PCY_ClassBean classBean,
        PCY_TaisyosyaBean[] taisyosyaBeans, PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "DELETE FROM " );
            sql.append( HcdbDef.L17_TBL );
            sql.append( " WHERE KAMOKU_CODE=?" );
            sql.append( "   AND CLASS_CODE=?" );

            if ( taisyosyaBeans.length > 0 ) {
                sql.append( "   AND NOT SIMEI_NO IN ( " );

                String sql_in = "";

                for ( int i = 0; i < taisyosyaBeans.length; i++ ) {
                    sql_in += ", ?";
                }

                sql.append( sql_in.replaceFirst( ",", "" ) );
                sql.append( "    )" );
            }

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �X�V���s
            ps = con.prepareStatement( sql.toString(  ) );

            ps.setString( 1, classBean.getKamokuBean(  ).getKamokuCode(  ) );
            ps.setString( 2, classBean.getClassCode(  ) );

            for ( int i = 0; i < taisyosyaBeans.length; i++ ) {
                ps.setString( i + 3, taisyosyaBeans[i].getSimeiNo(  ) );
            }

            int count = ps.executeUpdate(  );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �Ώێ҃}�X�^���쐬���܂��B
     *
     * @param taisyosyaBeans �쐬���e
     * @param loginuser ���O�C�����[�U
     * @return �쐬����
     */
    private int doInsertTaisyosya( PCY_TaisyosyaBean[] taisyosyaBeans, PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            StringBuffer sql = new StringBuffer(  );
            sql.append( "INSERT INTO " );
            sql.append( HcdbDef.L14_TBL );
            sql.append( " (" );
            sql.append( "    KAMOKU_CODE," );
            sql.append( "    CLASS_CODE," );
            sql.append( "    SIMEI_NO," );
            sql.append( "    TAISYO_KUBUN," );
            sql.append( "    TOUROKUBI," );
            sql.append( "    TOUROKUJIKOKU," );
            sql.append( "    TOUROKUSYA," );
            sql.append( "    KOUSINBI," );
            sql.append( "    KOUSINJIKOKU," );
            sql.append( "    KOUSINSYA )" );
            sql.append( "  VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )" );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �X�V���s

            int count = 0;

            for ( int i = 0; i < taisyosyaBeans.length; i++ ) {
				ps = con.prepareStatement( sql.toString(  ) );
				
                ps.setString( 1, taisyosyaBeans[i].getKamokuCode(  ) );
                ps.setString( 2, taisyosyaBeans[i].getClassCode(  ) );
                ps.setString( 3, taisyosyaBeans[i].getPersonalBean(  ).getSimeiNo(  ) );
                ps.setString( 4, taisyosyaBeans[i].getTaisyoKubun(  ) );
                ps.setString( 5, PZZ010_CharacterUtil.GetDay(  ) );
                ps.setString( 6, PZZ010_CharacterUtil.GetTime(  ) );
                ps.setString( 7, loginuser.getSimeiNo(  ) );
                ps.setString( 8, "        " );
                ps.setString( 9, "      " );
                ps.setString( 10, "          " );
                count += ps.executeUpdate(  );
                ps.close();
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �ȖڃR�[�h�ƃN���X�R�[�h���L�[�Ƃ��đΏێ҃}�X�^���폜���܂��B
     *
     * @param taisyosyaBeans �폜����
     * @param loginuser ���O�C�����[�U
     * @return �폜����
     */
    private int doDeleteTaisyosya( PCY_TaisyosyaBean[] taisyosyaBeans, PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            StringBuffer sql = new StringBuffer(  );
            sql.append( "DELETE FROM " );
            sql.append( HcdbDef.L14_TBL );
            sql.append( "  WHERE KAMOKU_CODE=?" );
            sql.append( "    AND CLASS_CODE=?" );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �X�V���s

            int count = 0;

            for ( int i = 0; i < taisyosyaBeans.length; i++ ) {
				ps = con.prepareStatement( sql.toString(  ) );
                ps.setString( 1, taisyosyaBeans[i].getKamokuCode(  ) );
                ps.setString( 2, taisyosyaBeans[i].getClassCode(  ) );
                count += ps.executeUpdate(  );
                ps.close();
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �Ώۑg�D�}�X�^���쐬���܂��B
     *
     * @param taisyososikiBeans �쐬���e
     * @param loginuser ���O�C�����[�U
     * @return �쐬����
     */
    private int doInsertTaisyososiki( PCY_TaisyososikiBean[] taisyososikiBeans,
        PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "INSERT INTO " );
            sql.append( HcdbDef.L13_TBL );
            sql.append( " (" );
            sql.append( "    KAMOKU_CODE," );
            sql.append( "    CLASS_CODE," );
            sql.append( "    SOSIKI_CODE," );
            sql.append( "    TAISYO_KUBUN," );
            sql.append( "    TOUROKUBI," );
            sql.append( "    TOUROKUJIKOKU," );
            sql.append( "    TOUROKUSYA," );
            sql.append( "    KOUSINBI," );
            sql.append( "    KOUSINJIKOKU," );
            sql.append( "    KOUSINSYA )" );
            sql.append( "  VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            /* �f�o�b�O���O���o�� */
            Log.debug( sql.toString(  ) );

            // �X�V���s

            int count = 0;

            for ( int i = 0; i < taisyososikiBeans.length; i++ ) {
				ps = con.prepareStatement( sql.toString(  ) );
                ps.setString( 1, taisyososikiBeans[i].getKamokuCode(  ) );
                ps.setString( 2, taisyososikiBeans[i].getClassCode(  ) );
                ps.setString( 3, taisyososikiBeans[i].getSosikiCode(  ) );
                ps.setString( 4, taisyososikiBeans[i].getTaisyoKubun(  ) );
                ps.setString( 5, PZZ010_CharacterUtil.GetDay(  ) );
                ps.setString( 6, PZZ010_CharacterUtil.GetTime(  ) );
                ps.setString( 7, loginuser.getSimeiNo(  ) );
                ps.setString( 8, "        " );
                ps.setString( 9, "      " );
                ps.setString( 10, "          " );

                count += ps.executeUpdate(  );
				ps.close();
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �ȖڃR�[�h�ƃN���X�R�[�h���L�[�Ƃ��đΏۑg�D�}�X�^���폜���܂��B
     *
     * @param taisyososikiBeans �폜����
     * @param loginuser ���O�C�����[�U
     * @return �폜����
     */
    private int doDeleteTaisyososiki( PCY_TaisyososikiBean[] taisyososikiBeans,
        PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            StringBuffer sql = new StringBuffer(  );
            sql.append( "DELETE FROM " );
            sql.append( HcdbDef.L13_TBL );
            sql.append( "  WHERE KAMOKU_CODE=?" );
            sql.append( "    AND CLASS_CODE=?" );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �X�V���s

            int count = 0;

            for ( int i = 0; i < taisyososikiBeans.length; i++ ) {
				ps = con.prepareStatement( sql.toString(  ) );
                ps.setString( 1, taisyososikiBeans[i].getKamokuCode(  ) );
                ps.setString( 2, taisyososikiBeans[i].getClassCode(  ) );
                count += ps.executeUpdate(  );
                ps.close();
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �ΏېE��}�X�^���쐬���܂��B
     *
     * @param taisyosyokusyuBeans �쐬���e
     * @param loginuser ���O�C�����[�U
     * @return �쐬����
     */
    private int doInsertTaisyosyokusyu( PCY_TaisyosyokusyuBean[] taisyosyokusyuBeans,
        PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            StringBuffer sql = new StringBuffer(  );
            sql.append( "INSERT INTO " );
            sql.append( HcdbDef.L12_TBL );
            sql.append( " (" );
            sql.append( "    KAMOKU_CODE," );
            sql.append( "    CLASS_CODE," );
            sql.append( "    SYOKU_CODE," );
            sql.append( "    SENMON_CODE," );
            sql.append( "    LEVEL_CODE," );
            sql.append( "    TAISYO_KUBUN," );
            sql.append( "    TOUROKUBI," );
            sql.append( "    TOUROKUJIKOKU," );
            sql.append( "    TOUROKUSYA," );
            sql.append( "    KOUSINBI," );
            sql.append( "    KOUSINJIKOKU," );
            sql.append( "    KOUSINSYA )" );
            sql.append( "  VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?," );
            sql.append( "           ?, ? )" );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �X�V���s

            int count = 0;

            for ( int i = 0; i < taisyosyokusyuBeans.length; i++ ) {
				ps = con.prepareStatement( sql.toString(  ) );
                ps.setString( 1, taisyosyokusyuBeans[i].getKamokuCode(  ) );
                ps.setString( 2, taisyosyokusyuBeans[i].getClassCode(  ) );
                ps.setString( 3, taisyosyokusyuBeans[i].getSyokusyuCode(  ) );
                ps.setString( 4, taisyosyokusyuBeans[i].getSenmonCode(  ) );
                ps.setString( 5, taisyosyokusyuBeans[i].getLevelCode(  ) );
                ps.setString( 6, taisyosyokusyuBeans[i].getTaisyoKubun(  ) );
                ps.setString( 7, PZZ010_CharacterUtil.GetDay(  ) );
                ps.setString( 8, PZZ010_CharacterUtil.GetTime(  ) );
                ps.setString( 9, loginuser.getSimeiNo(  ) );
                ps.setString( 10, "        " );
                ps.setString( 11, "      " );
                ps.setString( 12, "          " );
                count += ps.executeUpdate(  );
                ps.close();
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �ȖڃR�[�h�ƃN���X�R�[�h���L�[�Ƃ��đΏېE��}�X�^���폜���܂��B
     *
     * @param taisyosyokusyuBeans �폜����
     * @param loginuser ���O�C�����[�U
     * @return �폜����
     */
    private int doDeleteTaisyosyokusyu( PCY_TaisyosyokusyuBean[] taisyosyokusyuBeans,
        PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "DELETE FROM " );
            sql.append( HcdbDef.L12_TBL );
            sql.append( "  WHERE KAMOKU_CODE=?" );
            sql.append( "    AND CLASS_CODE=?" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            /* �f�o�b�O���O���o�� */
            Log.debug( sql.toString(  ) );

            // �X�V���s

            int count = 0;

            for ( int i = 0; i < taisyosyokusyuBeans.length; i++ ) {
				ps = con.prepareStatement( sql.toString(  ) );
                ps.setString( 1, taisyosyokusyuBeans[i].getKamokuCode(  ) );
                ps.setString( 2, taisyosyokusyuBeans[i].getClassCode(  ) );
                count += ps.executeUpdate(  );
                ps.close();
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

	/**
	 * �����L�[�ɏ]���ȖځE�N���X�����擾����
	 *
	 * @param searchKey �����L�[
	 * @param loginuser ���O�C�����
	 * @return �N���X���
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
	 * @exception CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 * @throws NamingException, RemoteException, CreateException
	 * @return
	 * 
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_ClassBean[] getClassList( PCY_SearchKeyBean searchKey, PCY_PersonalBean loginuser )
		throws NamingException, RemoteException, CreateException {
		/* For SAS-S */
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			PCY_ClassBean kensaku_classBean = new PCY_ClassBean(  );
			kensaku_classBean.setKaisibi( searchKey.getKaisibi(  ) );
			kensaku_classBean.setSyuryobi( searchKey.getSyuryobi(  ) );
			kensaku_classBean.getKamokuBean(  ).setCategoryCode1( searchKey.getCategoryCode1(  ) );
			kensaku_classBean.getKamokuBean(  ).setCategoryCode2( searchKey.getCategoryCode2(  ) );
			kensaku_classBean.getKamokuBean(  ).setCategoryCode3( searchKey.getCategoryCode3(  ) );
			kensaku_classBean.getKamokuBean(  ).setCategoryCode4( searchKey.getCategoryCode4(  ) );
			kensaku_classBean.getKamokuBean(  ).setCategoryCode5( searchKey.getCategoryCode5(  ) );
			kensaku_classBean.getKamokuBean(  ).setKamokuGroup( searchKey.getKamokuGroupCode(  ) );
			kensaku_classBean.getKamokuBean(  ).setKamokuMei1( searchKey.getKamokuMei1(  ) );
			kensaku_classBean.getKamokuBean(  ).setKanrimotoCode( searchKey.getKanrimotoCode(  ) );
			kensaku_classBean.setChikuCode( searchKey.getChikuCode(  ) );
			Collection ret   = new ArrayList(  );
			StringBuffer sql = new StringBuffer(  );

			// ���������̍쐬
			StringBuffer where = new StringBuffer(  );

			sql.append( "SELECT " + PCY_KamokuBean.getColumns( "KAMOKU" ) );

			if ( !"3".equals( searchKey.getMousikomiJyokyo(  ) ) ) {
				sql.append( ", " + PCY_ClassBean.getColumns( "CLASS" ) );
			}

			sql.append( "  FROM " );

			if ( "3".equals( searchKey.getMousikomiJyokyo(  ) ) ) {
				sql.append( HcdbDef.L01_TBL + " KAMOKU" );
				where.append( " AND KAMOKU.KAMOKU_CODE NOT IN " );
				where.append( " ( SELECT DISTINCT(KAMOKU_CODE) FROM " + HcdbDef.L02_TBL + ") " );
			} else {
				sql.append( HcdbDef.L01_TBL + " KAMOKU" );
				sql.append( " LEFT OUTER JOIN " );
				sql.append( HcdbDef.L02_TBL + " CLASS" );
				sql.append( " ON KAMOKU.KAMOKU_CODE=CLASS.KAMOKU_CODE" );
			}

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			// �Ȗڃ}�X�^
			Map kamokuConditions = kensaku_classBean.getKamokuBean(  ).extractConditions(  );

			for ( Iterator ite = kamokuConditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
				Object column = ite.next(  );

				if ( column.equals( "KAMOKU_MEI1" ) ) {
					where.append( " AND KAMOKU." + column + " LIKE ?" );
				} else {
					where.append( " AND KAMOKU." + column + "=?" );
				}
			}

			String[] kamoku_codes = searchKey.getKamokuCodes(  );

			if ( ( kamoku_codes != null ) && ( kamoku_codes.length != 0 ) ) {
				StringBuffer kamokuCodeWhere = new StringBuffer(  );
				boolean appendFlg            = false;
				kamokuCodeWhere.append( " AND ( " );

				for ( int i = 0; i < kamoku_codes.length; i++ ) {
					if ( ( kamoku_codes[i] == null ) || kamoku_codes[i].equals( "" ) ) {
						continue;
					}

					kamokuCodeWhere.append( " KAMOKU.KAMOKU_CODE='" + kamoku_codes[i] + "'" );

					if ( i != ( kamoku_codes.length - 1 ) ) {
						kamokuCodeWhere.append( " OR " );
					} else {
						kamokuCodeWhere.append( ") " );
					}

					appendFlg = true;
				}

				if ( appendFlg ) {
					where.append( kamokuCodeWhere );
				}
			}

			if ( ( searchKey.getSakujyoFlg(  ) != null ) && !searchKey.getSakujyoFlg(  ).equals( "" ) ) {
				where.append( " AND KAMOKU.SAKUJYO_FLG='" + searchKey.getSakujyoFlg(  ) + "'" );
			}

			// �N���X�}�X�^
			Map classConditions = kensaku_classBean.extractConditions(  );

			for ( Iterator ite = classConditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
				Object column = ite.next(  );

				if ( column.equals( "SYURYOBI" ) ) {
					where.append( " AND CLASS." + column + ">=?" );
				} else if ( column.equals( "KAISIBI" ) ) {
					where.append( " AND CLASS." + column + "<=?" );
				} else {
					where.append( " AND CLASS." + column + "=?" );
				}
			}

			/* �E��E��啪��E���x�������������ɒǉ��iWHERE��ɏ����ǉ��j */
			if ( ( searchKey.getSyokusyuCode(  ) != null )
				&& !"".equals( searchKey.getSyokusyuCode(  ) ) ) {
				StringBuffer kanren_sql = new StringBuffer(  );

				if ( searchKey.getSyokusyuCode(  ).equals( "AllSyokusyu" ) ) {
					/* �S�E�틤�� */
					kanren_sql.append( "SELECT KAMOKU_CODE FROM " + HcdbDef.p_kanren_kyoikuTbl );

					where.append( " AND KAMOKU.KAMOKU_CODE NOT IN ( " );
					where.append( kanren_sql );
					where.append( " ) " );
				} else {
					kanren_sql.append( "SELECT KAMOKU_CODE FROM " + HcdbDef.p_kanren_kyoikuTbl );
					kanren_sql.append( " WHERE SYOKU_CODE=?" );

					if ( ( searchKey.getSenmonCode(  ) != null )
						&& !"".equals( searchKey.getSenmonCode(  ) ) ) {
						kanren_sql.append( " AND SENMON_CODE=?" );
					}

					if ( ( searchKey.getLevelCode(  ) != null )
						&& !"".equals( searchKey.getLevelCode(  ) ) ) {
						kanren_sql.append( " AND LEVEL_CODE=?" );
					}

					where.append( " AND KAMOKU.KAMOKU_CODE IN ( " );
					where.append( kanren_sql );
					where.append( " ) " );
				}
			}

			sql.append( where.toString(  ).replaceFirst( "AND", "WHERE" ) );

			//�Ȗڂ̏����̍쐬
			sql.append( " ORDER BY KAMOKU.KAMOKU_CODE ASC " );

			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con = locator.getDataSource(  ).getConnection(  );

			// �������s
			Log.debug( sql.toString(  ) );
			ps = con.prepareStatement( sql.toString(  ) );

			int count = 1;

			for ( Iterator ite = kamokuConditions.keySet(  ).iterator(  ); ite.hasNext(  );
				count++ ) {
				Object key = ite.next(  );
				Log.debug( Integer.toString( count ) + ":" + key + ":"
					+ kamokuConditions.get( key ) );

				if ( key.equals( "KAMOKU_MEI1" ) ) {
					ps.setObject( count, "%" + kamokuConditions.get( key ) + "%" );
				} else {
					ps.setObject( count, kamokuConditions.get( key ) );
				}
			}

			for ( Iterator ite = classConditions.keySet(  ).iterator(  ); ite.hasNext(  );
				count++ ) {
				Object key = ite.next(  );
				Log.debug( Integer.toString( count ) + ":" + key + ":" + classConditions.get( key ) );
				ps.setObject( count, classConditions.get( key ) );
			}

			/* �E��E��啪��E���x�������������ɒǉ��i�l���Z�b�g�j */
			if ( ( searchKey.getSyokusyuCode(  ) != null )
				&& !"".equals( searchKey.getSyokusyuCode(  ) ) ) {
				if ( searchKey.getSyokusyuCode(  ).equals( "AllSyokusyu" ) ) {
				} else {
					ps.setString( count++, searchKey.getSyokusyuCode(  ) );

					if ( ( searchKey.getSenmonCode(  ) != null )
						&& !"".equals( searchKey.getSenmonCode(  ) ) ) {
						ps.setString( count++, searchKey.getSenmonCode(  ) );
					}

					if ( ( searchKey.getLevelCode(  ) != null )
						&& !"".equals( searchKey.getLevelCode(  ) ) ) {
						ps.setString( count++, searchKey.getLevelCode(  ) );
					}
				}
			}

			ResultSet rs = ps.executeQuery(  );

			while ( rs.next(  ) ) {
				ret.add( new PCY_ClassBean( rs, "KAMOKU", "CLASS" ) );
			}

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return ( PCY_ClassBean[] )ret.toArray( new PCY_ClassBean[0] );
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * �����ꊇ�Ώۃf�[�^��
	 * �����L�[�A������ʂɏ]���ȖځE�N���X�����擾����
	 * ������ʁ@�O�@�̌�������
	 *  �����ꊇ�t���O=1�A�Ǘ����A���C���ނR�A�J�n��
	 *  �J�n�����w�肳�ꂽ�\���J�n�� ���� �I�������w�肳�ꂽ�\���I����
	 * ������ʁ@�P�@�̌�������
	 *  �����ꊇ�t���O=1�A�Ǘ����A���C���ނR�A�J�n��
 	 * @param searchKey �����L�[
	 * @param syori �������
	 * @param loginuser ���O�C�����
	 * @return �N���X���
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 * @exception RemoteException �����[�g���\�b�h�Ăяo���̎��s�Ɏ��s�����ꍇ
	 * @exception CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 * @throws NamingException, RemoteException, CreateException
	 * @return
	 * 
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_ClassBean[] getClassKisyoList( PCY_SearchKeyBean searchKey, String syori , PCY_PersonalBean loginuser )
		throws NamingException, RemoteException, CreateException {
		/* For SAS-S */
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			Collection ret   = new ArrayList(  );
			StringBuffer sql = new StringBuffer(  );

			sql.append( "SELECT " + PCY_KamokuBean.getColumns( "KAMOKU" ) );
			sql.append( ", " + PCY_ClassBean.getColumns( "CLASS" ) );
			sql.append( "  FROM " );
			sql.append( HcdbDef.L01_TBL + " KAMOKU" );
			sql.append( " LEFT OUTER JOIN " );
			sql.append( HcdbDef.L02_TBL + " CLASS" );
			sql.append( " ON KAMOKU.KAMOKU_CODE=CLASS.KAMOKU_CODE" );
			sql.append( " AND CLASS.KISYO_IKKATSU_FLG='1'" );
			sql.append( " WHERE KAMOKU.SAKUJYO_FLG='0'" );

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			// �Ȗڃ}�X�^
			//�Ǘ����R�[�h
			String kanrimotoCode = searchKey.getKanrimotoCode();
			if ( ( kanrimotoCode != null ) && ( kanrimotoCode.length() != 0 ) ) {
				sql.append( " AND KAMOKU.KANRIMOTO_CODE='" + kanrimotoCode + "'" );
			}
			//���C���ނR
			String categoryCode3 = searchKey.getCategoryCode3();
			if ( ( categoryCode3 != null ) && ( categoryCode3.length() != 0 ) ) {
				sql.append( " AND KAMOKU.CATEGORY_CODE3='" + categoryCode3 + "'" );
			}

			// �N���X�}�X�^
			//�J�n��
            String KaisibiKagen = searchKey.getKaisibiKagen(  );
            if ( KaisibiKagen != null && !KaisibiKagen.equals("") ){
                sql.append( " AND '" + KaisibiKagen + "' <= CLASS.KAISIBI");
            }
			String KaisibiJyougen = searchKey.getKaisibiJyougen(  );
            if ( KaisibiJyougen != null && !KaisibiJyougen.equals("") ){
                sql.append( " AND CLASS.KAISIBI <= '" + KaisibiJyougen + "'" );
            }
            //�\���J�n��
			String MousikomiKaisibi = searchKey.getMousikomiKaisibi(  );
			if ( syori.equals("0")){
				sql.append( " AND (");
				sql.append( " CLASS.KAISIBI < '" + MousikomiKaisibi + "'");
			} else if ( syori.equals("2")){
				sql.append( " AND '" + MousikomiKaisibi + "' <= CLASS.KAISIBI ");
			}
			//�\���I����
			String MousikomiSyuryobi = searchKey.getMousikomiSyuryobi(  );
			if ( syori.equals("0")){
				sql.append( " OR CLASS.SYURYOBI < '" + MousikomiSyuryobi + "'");
				sql.append( " ) ");
			} else if ( syori.equals("2")){
				sql.append( " AND '" + MousikomiSyuryobi + "' <= CLASS.SYURYOBI ");
			}

			//�Ȗڂ̏����̍쐬
			sql.append( " ORDER BY KAMOKU.KAMOKU_CODE ASC ,CLASS.CLASS_CODE ASC" );

			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con = locator.getDataSource(  ).getConnection(  );

			// �������s
			Log.debug( sql.toString(  ) );
			ps = con.prepareStatement( sql.toString(  ) );

			int count = 1;
			ResultSet rs = ps.executeQuery(  );

			while ( rs.next(  ) ) {
				ret.add( new PCY_ClassBean( rs, "KAMOKU", "CLASS" ) );
			}

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return ( PCY_ClassBean[] )ret.toArray( new PCY_ClassBean[0] );
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * �����ꊇ�Ώۃf�[�^��
	 * �����L�[�ɃN���X�}�X�^
	 * �\���J�n���A�\���I�����A�����ꊇ�t���O�A�X�V�������X�V����B
	 *
	 * @param searchKey �����L�[
	 * @param syori �������
	 * @param loginuser ���O�C�����[�U
	 * @return �X�V����
	 * @throws PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdateKisyo( PCY_SearchKeyBean searchKey , String syori , PCY_PersonalBean loginuser )
		throws PCY_WarningException , RemoteException, CreateException {
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			int count = 0;
			if ( syori.equals("0")){
				/**
				 * �ȉ��̌��������ŃN���X�}�X�^��SELECT���𔭍s����B
				 * �E	�����ꊇ�t���O�A�Ǘ����A���C���ނR�A�J�n��
				 * �E	�J�n�����w�肳�ꂽ�\���J�n�� ���� �I�������w�肳�ꂽ�\���I����
				 * �����Ɉ�v����N���X���������ꂽ�ꍇ�A���������[���o�b�N���A�G���[���b�Z�[�W��\������B
				 */
				PCY_ClassBean[] checkclassBeans = this.getClassKisyoList( searchKey, "0", loginuser ) ;
				if ( checkclassBeans != null && checkclassBeans.length > 0 ){
					throw new PCY_WarningException( "WCX100" );
				}
				/**
				 * �ȉ��̌��������ŃN���X�}�X�^��UPDATE���𔭍s���A�\���J�n���A�\���I�����A�X�V�������X�V����B
				 * �E	�����ꊇ�t���O�A�Ǘ����A���C���ނR�A�J�n��
				 * �E	�w�肳�ꂽ�\���J�n�����J�n�� ���� �w�肳�ꂽ�\���I�������I����
				 */
				//�X�V�ΏۃN���X�̎擾
				PCY_ClassBean[] classBeans = this.getClassKisyoList( searchKey, "2", loginuser ) ;
				/**
				 * �����ꊇ�t���O���I���̃N���X�ɑ΂��\���J�n���A�\���I�������w����t�ɍX�V����B
				 * �����ꊇ�t���O�̍X�V�͍s��Ȃ��B
				 */
				for ( int i = 0; i < classBeans.length; i++ ) {

					/* �N���X���ڍׂ��擾�i���b�N�j */
					PCY_ClassBean[] selectclassBeans = this.doSelect( classBeans[i] , true, loginuser );

					/* ��ʑJ�ڒ��A�N���X�̏�񂪍X�V����ĂȂ��� */
					if ( !( classBeans[i].getKousinbi(  ).equals( selectclassBeans[0].getKousinbi(  ) ) && 
							classBeans[i].getKousinjikoku(  ).equals( selectclassBeans[0].getKousinjikoku(  ) ) ) ) {
						context.setRollbackOnly(  );
						throw new PCY_WarningException( "WCX101" );
					}

					// SQL�쐬
					StringBuffer sql = new StringBuffer(  );
					sql.append( "UPDATE " + HcdbDef.L02_TBL );
					sql.append( " SET  MOUSIKOMI_KAISIBI=?," );
					sql.append( "      MOUSIKOMI_SYURYOBI=?," );
					sql.append( "      KOUSINBI=?," );
					sql.append( "      KOUSINJIKOKU=?," );
					sql.append( "      KOUSINSYA=?" );
					sql.append( " WHERE KAMOKU_CODE=?" );
					sql.append( "   AND CLASS_CODE=?" );
					sql.append( "   AND KOUSINBI=?" );
					sql.append( "   AND KOUSINJIKOKU=?" );

					// �R�l�N�V�����擾
					PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
					con     = locator.getDataSource(  ).getConnection(  );

					// �X�V���s
					ps = con.prepareStatement( sql.toString(  ) );
					ps.setString( 1, searchKey.getMousikomiKaisibi() );
					ps.setString( 2, searchKey.getMousikomiSyuryobi() );
					ps.setString( 3, PZZ010_CharacterUtil.GetDay(  ) );
					ps.setString( 4, PZZ010_CharacterUtil.GetTime(  ) );
					ps.setString( 5, loginuser.getSimeiNo(  ) );
					ps.setString( 6, classBeans[i].getKamokuBean(  ).getKamokuCode(  ) );
					ps.setString( 7, classBeans[i].getClassCode(  ) );
					ps.setString( 8, classBeans[i].getKousinbi(  ) );
					ps.setString( 9, classBeans[i].getKousinjikoku(  ) );

					count += ps.executeUpdate(  );
					ps.close();
			   }

			}else{
				/**
				 * �����ꊇ�t���O�y�юw�肳�ꂽ�Ǘ����A���C���ނR�A�J�n����
				 * ���������Ƃ��ăN���X�}�X�^��SELECT���i�X�V���b�N�j�𔭍s����B
				 */
				PCY_ClassBean[] classBeans = this.getClassKisyoList( searchKey, "1", loginuser ) ;
				//�擾�����N���X�̊J�n���Ǝw�肳�ꂽ�\���I�����i�c�Ɠ��w��j����\���I�������v�Z����B
				int eigyoubi = Integer.parseInt(searchKey.getMousikomiSyuryobieigyoubi());
				for ( int i = 0; i < classBeans.length; i++ ) {

					/* �N���X���ڍׂ��擾�i���b�N�j */
					PCY_ClassBean[] selectclassBeans = this.doSelect( classBeans[i] , true, loginuser );

					String Kaisibi = classBeans[i].getKaisibi();
					if(Kaisibi != null){
						
						String kaisanmousikomiSyuryoubi = GetLateWeekday( Kaisibi , eigyoubi );
	
						/**
						 * �J�n�����w�肳�ꂽ�\���J�n�� ���� �v�Z�����\���I�������w�肳�ꂽ�\���J�n���ł������ꍇ�A
						 * ���������[���o�b�N���A�G���[���b�Z�[�W��\������B
						 */
						//�擾�����N���X�̊J�n�����w�肳�ꂽ�\���J�n�� ���� 
						//�v�Z�����\���I�������w�肳�ꂽ�\���J�n��
						if( (Integer.parseInt(selectclassBeans[0].getKaisibi())<Integer.parseInt(searchKey.getMousikomiKaisibi())) ||
							(Integer.parseInt( kaisanmousikomiSyuryoubi )<Integer.parseInt(searchKey.getMousikomiKaisibi()))){
								context.setRollbackOnly(  );
							throw new PCY_WarningException( "WCX102" );
						}
						/**
						 * �ȖڃR�[�h�A�N���X�R�[�h�����������Ƃ��ăN���X�}�X�^��UPDATE���𔭍s���A
						 * �����ꊇ�t���O���I���̃N���X�ɑ΂��\���J�n�����w����t�ɁA
						 * �\���I�������J�n���̎w��c�Ɠ��i�y���ȊO�j�O�ɁA�����ꊇ�t���O���I�t�ɍX�V����B
						 */
						// SQL�쐬
						StringBuffer sql = new StringBuffer(  );
						sql.append( "UPDATE " + HcdbDef.L02_TBL );
						sql.append( " SET  MOUSIKOMI_KAISIBI=?," );
						sql.append( "      MOUSIKOMI_SYURYOBI=?," );
						sql.append( "      KISYO_IKKATSU_FLG=?," );
						sql.append( "      KOUSINBI=?," );
						sql.append( "      KOUSINJIKOKU=?," );
						sql.append( "      KOUSINSYA=?" );
						sql.append( " WHERE KAMOKU_CODE=?" );
						sql.append( "   AND CLASS_CODE=?" );
						sql.append( "   AND KOUSINBI=?" );
						sql.append( "   AND KOUSINJIKOKU=?" );
		
						// �R�l�N�V�����擾
						PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
						con     = locator.getDataSource(  ).getConnection(  );
		
						// �X�V���s
						ps = con.prepareStatement( sql.toString(  ) );
						ps.setString( 1, searchKey.getMousikomiKaisibi() );
						ps.setString( 2, kaisanmousikomiSyuryoubi );
						ps.setString( 3, "0" );
						ps.setString( 4, PZZ010_CharacterUtil.GetDay(  ) );
						ps.setString( 5, PZZ010_CharacterUtil.GetTime(  ) );
						ps.setString( 6, loginuser.getSimeiNo(  ) );
						ps.setString( 7, classBeans[i].getKamokuBean(  ).getKamokuCode(  ) );
						ps.setString( 8, classBeans[i].getClassCode(  ) );
						ps.setString( 9, classBeans[i].getKousinbi(  ) );
						ps.setString(10, classBeans[i].getKousinjikoku(  ) );
		
						count += ps.executeUpdate(  );
						ps.close();
					}
				}
			}

			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return count;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}


	/**
	 * �������ŗ^����ꂽ�������","�ŋ�؂�A
	 * ��؂�ꂽ�������ȉ��̂悤�ȕ�����𐶐����Ԃ��B
	 * ��؂�ꂽ����3�̏ꍇ
	 * "( ��2���� =? OR ��2���� =? OR ��2���� =?)"
	 * 
	 * @param kamokuCode
	 * @param column
	 * @return String
	 */
	private String getSQLKamokuCode(String kamokuCode,String column){
		StringTokenizer st = new StringTokenizer(kamokuCode,",");
		StringBuffer sb = new StringBuffer();
							
		//�擪�ɕ������ǉ�
		sb.append(" AND (");
							
		while (st.hasMoreTokens()) {//�g�[�N���������J��Ԃ�
		   sb.append(" OR KAMOKU.KAMOKU_CODE" + "=? ");
		   st.nextToken();
		}
		sb.append(") ");  //�Ō��")"��ǉ�
		String subStr = sb.toString().replaceFirst("OR","");//�ŏ���OR���폜
		
		return subStr;			
	}
    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }

    private class ClassCodeComparator implements Comparator {
        public int compare( Object o1, Object o2 ) {
            PCY_ClassBean class1 = ( PCY_ClassBean )o1;
            PCY_ClassBean class2 = ( PCY_ClassBean )o2;

            if ( class1.getKamokuBean(  ).getKamokuCode(  ).equals( class2.getKamokuBean(  )
                                                                          .getKamokuCode(  ) ) ) {
                return class1.getClassCode(  ).compareTo( class2.getClassCode(  ) );
            }

            return class1.getKamokuBean(  ).getKamokuCode(  ).compareTo( class2.getKamokuBean(  )
                                                                               .getKamokuCode(  ) );
        }
    }

	/*
	 * �w�肳�ꂽ���t��X������擾����
	 * @param  String  ���͓��t YYYYMMDD
	 * @param  int     �w���   X��
	 * @return String  �o�͓��t YYYYMMDD
	 */
	private static String GetLateDay(String StartDay, int date) { 
		int intStartYY = java.lang.Integer.parseInt(StartDay.substring(0,4));
		int intStartMM = java.lang.Integer.parseInt(StartDay.substring(4,6));
		int intStartDD = java.lang.Integer.parseInt(StartDay.substring(6,8));
		GregorianCalendar gc = new GregorianCalendar(intStartYY,intStartMM -1 ,intStartDD);
		gc.add(GregorianCalendar.DATE, date);
		int intTodayY = gc.get(GregorianCalendar.YEAR);
		int intTodayM = gc.get(GregorianCalendar.MONTH) + 1;
		int intTodayD = gc.get(GregorianCalendar.DAY_OF_MONTH);

		String strSdateYYYY = String.valueOf(intTodayY);

		String strSdateMM;
		if (intTodayM < 10)
		  {strSdateMM = "0" + String.valueOf(intTodayM);}
		else
		  {strSdateMM = String.valueOf(intTodayM);}

		String strSdateDD; 
		if (intTodayD < 10)
		  {strSdateDD = "0" + String.valueOf(intTodayD);}
		else
		  {strSdateDD = String.valueOf(intTodayD);}  
		return strSdateYYYY + strSdateMM + strSdateDD;
	}

	/*
	 * �w����̗j�����Z�o����
	 * @param   String    �w���(YYYYMMDD)
	 * @return  String    ��(1)�`�y(7)
	 */
	private static String DayOfWeek(String strDate) {

		String strYYYY = strDate.substring(0,4);
		String strMM = strDate.substring(4,6);
		String strDD = strDate.substring(6,8);
		String strDay = "";

		GregorianCalendar gc = new GregorianCalendar();
		gc.set(Integer.parseInt(strYYYY), Integer.parseInt(strMM)-1, Integer.parseInt(strDD));

		int intTodayW = gc.get(Calendar.DAY_OF_WEEK);

		switch(intTodayW) {
		  case Calendar.SUNDAY:     strDay = "1"; break;
		  case Calendar.MONDAY:     strDay = "2"; break;
		  case Calendar.TUESDAY:    strDay = "3"; break;
		  case Calendar.WEDNESDAY:  strDay = "4"; break;
		  case Calendar.THURSDAY:   strDay = "5"; break;
		  case Calendar.FRIDAY:     strDay = "6"; break;
		  case Calendar.SATURDAY:   strDay = "7"; break;
		}
		return  strDay;
	}

	/*
	 * �w�肳�ꂽ���t��X������擾����(�y���������j
	 * @param  String  ���͓��t YYYYMMDD
	 * @param  int     �w���   X��
	 * @return String  �o�͓��t YYYYMMDD
	 */
	private static String GetLateWeekday(String StartDay, int date) { 

		String getDate = StartDay ;
		for(int i=0 ; i<date ; ){
			String previousDay = GetLateDay( getDate , -1 );
			//�y���ȊO?
			if ( !DayOfWeek( previousDay ).equals("1") && !DayOfWeek( previousDay ).equals("7")) {
				i ++;
			}
			getDate = previousDay ;
		}

		return getDate ;
	}

}
