/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/03/17  01.00       ���� ��F    �V�K�쐬
 *   2005/12/03              �Β� �[      �񍐋敪2�ɑΉ�
 */
package jp.co.hisas.career.learning.base.valuebean;

import java.io.*;

import javax.servlet.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_DefaultBean �N���X
 *
 * �@�\�����F
 *   ���[�U�f�t�H���g��\��ValueBean�ł��B
 *
 *</PRE>
 */
public class PCY_DefaultBean extends PCY_ValueBean implements Serializable {

	//���[�U�f�t�H���g
	private String simeiNo					= null;
	private String gamenId					= null;
	private String koumokuId				= null;
	private String defaultValue			= null;

	//���C�Ǘ������
	private String categoryCode1			= null;
	private String categoryCode2			= null;
	private String categoryCode3			= null;
	private String sort					= null;
	private String chikuCode				= null;
	private String kanrimotoCode			= null;
	private String kisyoIkkatsuFlg			= null;

	//���ѓ��͉��
	private String kijyunten				= null;
	private String syuryoHantei			= null;

	//�Ȗړo�^���
	private String kamokuKanrimotoCode		= null;
	private String kamokuCategoryCode1		= null;
	private String kamokuCategoryCode2		= null;
	private String kamokuCategoryCode3		= null;

	//�N���X�o�^���
	private String classClassCode			= null;
	private String classMousikomiKubun		= null;
	private String classSyoninKubun		= null;
	private String classUketukeKubun		= null;
	private String classHoukokuKubun		= null;
	private String classHanteiKubun		= null;
	private String classKisyoIkkatsuFlg	= null;
	private String classZensyaTaisyoFlg	= null;
	private String classMansekiFlg			= null;
	private String classChikuCode			= null;
	private String classKousiCode			= null;
	private String classKyosituCode		= null;
	private String classAnnaiMailKubun		= null;
	private String classFollowMailKubun	= null;
	//INS#B-A30AM2-007 -S
	private String classHoukokuKubun2  = null;
	//INS#B-A30AM2-007 -E

	/**
	 * �f�t�H���g�̃R���X�g���N�^�ł��B
	 */
	public PCY_DefaultBean(  ) {
		super();
	}

	/**
	 * request ����l���擾���Č�������Bean���쐬���܂��B
	 *
	 * @param request �T�[�u���b�g���N�G�X�g
	 */
	public PCY_DefaultBean( ServletRequest request ) {

		setCategoryCode1( request.getParameter( "category_code1" ) );
		setCategoryCode2( request.getParameter( "category_code2" ) );
		setCategoryCode3( request.getParameter( "category_code3" ) );
		setSort( request.getParameter( "sort" ) );
		setChikuCode( request.getParameter( "chiku_code" ) );
		setKanrimotoCode( request.getParameter( "kanrimoto_code" ) );
		setKisyoIkkatsuFlg( request.getParameter( "kisyo_ikkatsu_flg" ) );

		setKijyunten( request.getParameter( "kijyunten" ) );
		setSyuryoHantei( request.getParameter( "syuryo_hantei" ) );

		setKamokuKanrimotoCode( request.getParameter( "kamoku_kanrimoto_code" ) );
		setKamokuCategoryCode1( request.getParameter( "kamoku_category_code1" ) );
		setKamokuCategoryCode2( request.getParameter( "kamoku_category_code2" ) );
		setKamokuCategoryCode3( request.getParameter( "kamoku_category_code3" ) );

		setClassClassCode( request.getParameter( "class_class_code" ) );
		setClassMousikomiKubun( request.getParameter( "class_mousikomi_kubun" ) );
		setClassSyoninKubun( request.getParameter( "class_syonin_kubun" ) );
		setClassUketukeKubun( request.getParameter( "class_uketuke_kubun" ) );
		setClassHoukokuKubun( request.getParameter( "class_houkoku_kubun" ) );
		setClassHanteiKubun( request.getParameter( "class_hantei_kubun" ) );
		setClassKisyoIkkatsuFlg( request.getParameter( "class_kisyo_ikkatsu_flg" ) );
		setClassZensyaTaisyoFlg( request.getParameter( "class_zensya_taisyo_flg" ) );
		setClassMansekiFlg( request.getParameter( "class_manseki_flg" ) );
		setClassChikuCode( request.getParameter( "class_chiku_code" ) );
		setClassKousiCode( request.getParameter( "class_kousi_code" ) );
		setClassKyosituCode( request.getParameter( "class_kyositu_code" ) );
		setClassAnnaiMailKubun( request.getParameter( "class_annai_mail_kubun" ) );
		setClassFollowMailKubun( request.getParameter( "class_follow_mail_kubun" ) );

		setSimeiNo( request.getParameter( "simei_no" ) );
		setGamenId( request.getParameter( "gamen_id" ) );
		setKoumokuId( request.getParameter( "koumoku_Id" ) );
		setDefaultValue( request.getParameter( "default_value" ) );
		
		//INS#B-A30AM2-007 -S
		setClassHoukokuKubun2( request.getParameter( "class_houkoku_kubun_2" ) );
		//INS#B-A30AM2-007 -E
	}

	/**
	 * @return
	 */
	public String getCategoryCode1() {
		return categoryCode1;
	}

	/**
	 * @return
	 */
	public String getCategoryCode2() {
		return categoryCode2;
	}

	/**
	 * @return
	 */
	public String getCategoryCode3() {
		return categoryCode3;
	}

	/**
	 * @return
	 */
	public String getChikuCode() {
		return chikuCode;
	}

	/**
	 * @return
	 */
	public String getClassAnnaiMailKubun() {
		return classAnnaiMailKubun;
	}

	/**
	 * @return
	 */
	public String getClassChikuCode() {
		return classChikuCode;
	}

	/**
	 * @return
	 */
	public String getClassClassCode() {
		return classClassCode;
	}

	/**
	 * @return
	 */
	public String getClassFollowMailKubun() {
		return classFollowMailKubun;
	}

	/**
	 * @return
	 */
	public String getClassHanteiKubun() {
		return classHanteiKubun;
	}

	/**
	 * @return
	 */
	public String getClassHoukokuKubun() {
		return classHoukokuKubun;
	}

	/**
	 * @return
	 */
	public String getClassKisyoIkkatsuFlg() {
		return classKisyoIkkatsuFlg;
	}

	/**
	 * @return
	 */
	public String getClassKousiCode() {
		return classKousiCode;
	}

	/**
	 * @return
	 */
	public String getClassKyosituCode() {
		return classKyosituCode;
	}

	/**
	 * @return
	 */
	public String getClassMansekiFlg() {
		return classMansekiFlg;
	}

	/**
	 * @return
	 */
	public String getClassMousikomiKubun() {
		return classMousikomiKubun;
	}

	/**
	 * @return
	 */
	public String getClassSyoninKubun() {
		return classSyoninKubun;
	}

	/**
	 * @return
	 */
	public String getClassUketukeKubun() {
		return classUketukeKubun;
	}

	/**
	 * @return
	 */
	public String getClassZensyaTaisyoFlg() {
		return classZensyaTaisyoFlg;
	}

	/**
	 * @return
	 */
	public String getDefaultValue() {
		return defaultValue;
	}

	/**
	 * @return
	 */
	public String getGamenId() {
		return gamenId;
	}

	/**
	 * @return
	 */
	public String getKamokuCategoryCode1() {
		return kamokuCategoryCode1;
	}

	/**
	 * @return
	 */
	public String getKamokuCategoryCode2() {
		return kamokuCategoryCode2;
	}

	/**
	 * @return
	 */
	public String getKamokuCategoryCode3() {
		return kamokuCategoryCode3;
	}

	/**
	 * @return
	 */
	public String getKamokuKanrimotoCode() {
		return kamokuKanrimotoCode;
	}

	/**
	 * @return
	 */
	public String getKanrimotoCode() {
		return kanrimotoCode;
	}

	/**
	 * @return
	 */
	public String getKijyunten() {
		return kijyunten;
	}

	/**
	 * @return
	 */
	public String getKisyoIkkatsuFlg() {
		return kisyoIkkatsuFlg;
	}

	/**
	 * @return
	 */
	public String getKoumokuId() {
		return koumokuId;
	}

	/**
	 * @return
	 */
	public String getSimeiNo() {
		return simeiNo;
	}

	/**
	 * @return
	 */
	public String getSort() {
		return sort;
	}

	/**
	 * @return
	 */
	public String getSyuryoHantei() {
		return syuryoHantei;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode1(String string) {
		categoryCode1 = string;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode2(String string) {
		categoryCode2 = string;
	}

	/**
	 * @param string
	 */
	public void setCategoryCode3(String string) {
		categoryCode3 = string;
	}

	/**
	 * @param string
	 */
	public void setChikuCode(String string) {
		chikuCode = string;
	}

	/**
	 * @param string
	 */
	public void setClassAnnaiMailKubun(String string) {
		classAnnaiMailKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassChikuCode(String string) {
		classChikuCode = string;
	}

	/**
	 * @param string
	 */
	public void setClassClassCode(String string) {
		classClassCode = string;
	}

	/**
	 * @param string
	 */
	public void setClassFollowMailKubun(String string) {
		classFollowMailKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassHanteiKubun(String string) {
		classHanteiKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassHoukokuKubun(String string) {
		classHoukokuKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassKisyoIkkatsuFlg(String string) {
		classKisyoIkkatsuFlg = string;
	}

	/**
	 * @param string
	 */
	public void setClassKousiCode(String string) {
		classKousiCode = string;
	}

	/**
	 * @param string
	 */
	public void setClassKyosituCode(String string) {
		classKyosituCode = string;
	}

	/**
	 * @param string
	 */
	public void setClassMansekiFlg(String string) {
		classMansekiFlg = string;
	}

	/**
	 * @param string
	 */
	public void setClassMousikomiKubun(String string) {
		classMousikomiKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassSyoninKubun(String string) {
		classSyoninKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassUketukeKubun(String string) {
		classUketukeKubun = string;
	}

	/**
	 * @param string
	 */
	public void setClassZensyaTaisyoFlg(String string) {
		classZensyaTaisyoFlg = string;
	}

	/**
	 * @param string
	 */
	public void setDefaultValue(String string) {
		defaultValue = string;
	}

	/**
	 * @param string
	 */
	public void setGamenId(String string) {
		gamenId = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuCategoryCode1(String string) {
		kamokuCategoryCode1 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuCategoryCode2(String string) {
		kamokuCategoryCode2 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuCategoryCode3(String string) {
		kamokuCategoryCode3 = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuKanrimotoCode(String string) {
		kamokuKanrimotoCode = string;
	}

	/**
	 * @param string
	 */
	public void setKanrimotoCode(String string) {
		kanrimotoCode = string;
	}

	/**
	 * @param string
	 */
	public void setKijyunten(String string) {
		kijyunten = string;
	}

	/**
	 * @param string
	 */
	public void setKisyoIkkatsuFlg(String string) {
		kisyoIkkatsuFlg = string;
	}

	/**
	 * @param string
	 */
	public void setKoumokuId(String string) {
		koumokuId = string;
	}

	/**
	 * @param string
	 */
	public void setSimeiNo(String string) {
		simeiNo = string;
	}

	/**
	 * @param string
	 */
	public void setSort(String string) {
		sort = string;
	}

	/**
	 * @param string
	 */
	public void setSyuryoHantei(String string) {
		syuryoHantei = string;
	}

	//INS#B-A30AM2-007 -S
	/**
	 * @param string
	 */
	public String getClassHoukokuKubun2() {
		return classHoukokuKubun2;
	}

	/**
	 * @param string
	 */
	public void setClassHoukokuKubun2(String string) {
		this.classHoukokuKubun2 = string;
	}
	//INS#B-A30AM2-007 -E
}
