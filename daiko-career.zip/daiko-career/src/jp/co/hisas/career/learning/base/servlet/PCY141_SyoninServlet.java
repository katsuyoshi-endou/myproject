/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 * 
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/03/03  01.00       ���Y�@�T��    �V�K�쐬
 *   2004/08/06              �n��  ��q    ��t��Ԃ̃Z�b�g������ǉ�(�Г��ŃJ�X�^�}�C�Y)
 *   2005/11/02              ���Y  �T��    ���C���O�o�͑Ή��i��L�a�����j [B-A30AM1-008]
 *   2005/11/19              ���c�@���V    �L�����Z���҂��̒ǉ��d�l�ɑΉ� [B-A30AM1-002]
 *   2005/11/22              ���c�@���V    �����null�̏ꍇ�ɑΉ� [B-A30AM1-030]
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.*;
import javax.ejb.*;
import javax.naming.*;
import javax.servlet.http.*;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.log.*;

import jp.co.hisas.career.util.property.*;       //INS#P-A30AM1-002-007
import jp.co.hisas.career.base.sosiki.bean.SosikiBean;//INS#P-A30AM1-002-007
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.base.mail.util.*;      //INS#P-A30AM1-002-007
import javax.mail.internet.*;					//INS#P-A30AM1-002-007

/**
 *<PRE>
 *
 * �N���X���F
 *   PCY141_SyoninServlet �N���X
 *
 * �@�\�����F
 *   ���F�������s���܂��B
 *
 *</PRE>
 */
public class PCY141_SyoninServlet extends PCY010_ControllerServlet {

    protected String execute( HttpServletRequest request, HttpServletResponse response, PCY_PersonalBean loginuser )
        throws NamingException, CreateException, RemoteException, PCY_WarningException, Exception {
        /*���\�b�h�g���[�X�o��*/
        Log.method( loginuser.getSimeiNo(), "IN", "" );
		Log.performance( loginuser.getSimeiNo(  ), true, "" );

		String[] kamokuCode     = (String[])request.getParameterValues( "kamoku_code_array" );
		String[] classCode      = (String[])request.getParameterValues( "class_code_array" );
		String[] simeiNo        = (String[])request.getParameterValues( "simei_no_array" );
		String[] kousinbi       = (String[])request.getParameterValues( "kousinbi" );
		String[] kousinjikoku   = (String[])request.getParameterValues( "kousinjikoku" );
		
		/* INS#P-A30AM1-002-007-S */
		String[] syoninzumiNinzu = new String[kamokuCode.length];				
		int cancelMachiClass = 0;
		int syoninzumiZyogenClass = 0;
		boolean nullMailFlg = false;	
		/* INS#P-A30AM1-002-007-E */

		PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
		PCY_ClassEJBHome homeClass = (PCY_ClassEJBHome)locator.getServiceLocation(
									 "PCY_ClassEJB", PCY_ClassEJBHome.class );
		PCY_ClassEJB ejbClass = homeClass.create();
		
		PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = new PCY_MousikomiJyokyoBean[kamokuCode.length];
		
		/* INS#P-A30AM1-002-007-S */
		/* VCA071_���C�\���Ċm�F����J�ڂ����ꍇ�̔���Ɏg�p */
		String req = request.getParameter( "Modoru" );
		if ( ( request.getParameter( "cancelMachiClass" ) != null ) && ( req != null ) ) {
			cancelMachiClass = Integer.parseInt( request.getParameter( "cancelMachiClass" ) );
		}
		/* INS#P-A30AM1-002-007-E */
		
		for( int i = 0; i < kamokuCode.length; i++ ) {
			PCY_ClassBean classBeanDummy = new PCY_ClassBean();
			classBeanDummy.getKamokuBean().setKamokuCode( kamokuCode[i] );
			classBeanDummy.setClassCode( classCode[i] );
			Log.transaction( loginuser.getSimeiNo(  ), true, "" );							
			PCY_ClassBean classBean = ejbClass.doSelectByPrimaryKey( classBeanDummy, loginuser );
			Log.transaction( loginuser.getSimeiNo(  ), false, "" );		
		
			PCY_MousikomiJyokyoBean mousikomiJyokyoBean = new PCY_MousikomiJyokyoBean(  );
			mousikomiJyokyoBean.setClassBean( classBean );
			mousikomiJyokyoBean.setKamokuCode( kamokuCode[i] );
			mousikomiJyokyoBean.setClassCode( classCode[i] );
			mousikomiJyokyoBean.setSimeiNo( simeiNo[i] );
			mousikomiJyokyoBean.setSyoninbi1( PZZ010_CharacterUtil.GetDay(  ) );
			mousikomiJyokyoBean.setSyoninjikoku1( PZZ010_CharacterUtil.GetTime(  ) );
			mousikomiJyokyoBean.setSyoninsya1( loginuser.getSimeiNo(  ) );
			mousikomiJyokyoBean.setKousinbi( kousinbi[i] );
			mousikomiJyokyoBean.setKousinjikoku( kousinjikoku[i] );			
			/* ��t�敪��"�v"�̏ꍇ */
			if( classBean.getUketukeKubun().equals( "1" ) ) {
				mousikomiJyokyoBean.setStatus( "1" );
                mousikomiJyokyoBean.setUketsukeJyotai( "0" );  // For Syanai
			/* �񍐋敪��"�v"�̏ꍇ */				
			} else if( !classBean.getHoukokuKubun().equals( "0" ) ) {
				mousikomiJyokyoBean.setStatus( "2" );
			/* ����敪��"�v"�̏ꍇ */	
			} else if( classBean.getHanteiKubun().equals( "1" ) ) {
				mousikomiJyokyoBean.setStatus( "3" );					
			}
			mousikomiJyokyoBean.setKousinbi( kousinbi[i] );
			mousikomiJyokyoBean.setKousinjikoku( kousinjikoku[i] );
			mousikomiJyokyoBeans[i] = mousikomiJyokyoBean;

			/* INS#P-A30AM1-002-007-S */
			/* VCA071_���C�\���Ċm�F����J�ڂ����ꍇ�͎��s���Ȃ� */
			if ( req == null ) {

				PCY_MousikomiJyokyoEJBHome home = ( PCY_MousikomiJyokyoEJBHome )locator.getServiceLocation( "PCY_MousikomiJyokyoEJB",
						PCY_MousikomiJyokyoEJBHome.class );
				PCY_MousikomiJyokyoEJB mousikomiJyokyoEjb = home.create(  );			
		
				/* ���Y�N���X�ŏ��F�ς̐l�����v�Z */
				int count1 = mousikomiJyokyoEjb.countClassL15( kamokuCode[i] , classCode[i] , null , "1" ,  loginuser ) ;
				int count2 = mousikomiJyokyoEjb.countClassL15( kamokuCode[i] , classCode[i] , null , "2" ,  loginuser ) ;
				int count3 = mousikomiJyokyoEjb.countClassL15( kamokuCode[i] , classCode[i] , null , "3" ,  loginuser ) ;
				int mousikomisya = count1 + count2 + count3;
				mousikomiJyokyoBean.getClassBean().setMousikomisya( String.valueOf(mousikomisya) );
				syoninzumiNinzu[i] = String.valueOf( mousikomisya );
				if ( classBean.getTeiin() != null ) {// INS#P-A30AM1-030-003
					int teiin = classBean.getTeiin().intValue();
					int cancelMachiNinzuu = 0;
					String str = (String)ReadFile.fileMapData.get("CANCEL_MACHI_NINZUU");
						if (str != null) {
						  cancelMachiNinzuu = Integer.parseInt(str);
						}
			
					if ( mousikomisya >= ( teiin + cancelMachiNinzuu ) ) {
						syoninzumiZyogenClass++;
					} else if ( mousikomisya >= teiin ) {
						cancelMachiClass++;
					}
				}// INS#P-A30AM1-030-003

			}
			/* INS#P-A30AM1-002-007-E */
			
			classBeanDummy      = null;
			classBean           = null;
			mousikomiJyokyoBean = null;					
		}

		/* INS#P-A30AM1-002-007-S */			
		if ( req == null ) {
			
			/* VCB020_���C�\���m�F��ʕ\�����ɃL�����Z���҂��E�ő咴�߃N���X���������ꍇ�̏��� */
			if ( syoninzumiZyogenClass != 0 ) {
				request.setAttribute( "warningID", "WCB160" );
				request.setAttribute( "mousikomiJyokyoBeans", mousikomiJyokyoBeans );
				request.setAttribute( "cancelMachiClass", String.valueOf(cancelMachiClass) );
				return getForwardPath( "failure" );
			} else if ( cancelMachiClass != 0 &&
						 cancelMachiClass > Integer.parseInt(request.getParameter( "cancelMachiClass" )) ) {
				request.setAttribute( "warningID", "WCB150" );
				request.setAttribute( "mousikomiJyokyoBeans", mousikomiJyokyoBeans );
				request.setAttribute( "cancelMachiClass", String.valueOf(cancelMachiClass) );
				return getForwardPath( "failure" );
			}
		}
		/* INS#P-A30AM1-002-007-E */
		
        PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome)locator.getServiceLocation(
                                     "PCY_MousikomiJyokyoEJB",
                                     PCY_MousikomiJyokyoEJBHome.class );
        PCY_MousikomiJyokyoEJB ejb = home.create();
        
		Log.transaction( loginuser.getSimeiNo(  ), true, "" );	
        ejb.doUpdateStatus( mousikomiJyokyoBeans, loginuser, true );
		Log.transaction( loginuser.getSimeiNo(  ), false, "" );	

        // INS#P-A30AM1-008-004-S
        PCY_PersonalEJBHome personalHome   = ( PCY_PersonalEJBHome )locator.getServiceLocation( "PCY_PersonalEJB",
                PCY_PersonalEJBHome.class );
        PCY_PersonalEJB personalEjb = personalHome.create(  );

        String jikkobi = PZZ010_CharacterUtil.GetDay();
        String jikkoJikoku = PZZ010_CharacterUtil.GetTime();

        /* ���F�Ώۂ̃��R�[�h�������[�v���A���C���O�o�͂��s�� */
        for ( int i = 0; i < mousikomiJyokyoBeans.length; i++ ) {

            /* ���F�Ώۂ̐\���󋵂��擾 */
            PCY_MousikomiJyokyoBean[] mousikomiFromTableBeans = ejb.getList( mousikomiJyokyoBeans[i], loginuser );

            /* �\���󋵂��擾�ł��Ȃ������ꍇ�i�ʏ킠�肦�Ȃ��j */
            if ( mousikomiFromTableBeans.length == 0 ) {
                mousikomiFromTableBeans = new PCY_MousikomiJyokyoBean[1];
            }
        
            PCY_PersonalBean jikkosya = personalEjb.getPersonalInfo( loginuser.getSimeiNo(), loginuser );
            PCY_PersonalBean mousikomisya = personalEjb.getPersonalInfo( mousikomiFromTableBeans[0].getMousikomisya(), loginuser );
            PCY_PersonalBean syoninsya = personalEjb.getPersonalInfo( mousikomiFromTableBeans[0].getSyoninsya1(), loginuser );

            /* ���O�o�͏��i�[�z�� */
            String[] out = new String[14];
            out[0]  = jikkobi;
            out[1]  = jikkoJikoku;
            out[2]  = jikkosya.getSimeiNo();
            out[3]  = jikkosya.getSosikiCode();
            /* �����敪�i���F��"3"�j */
            out[4]  = "3";
            out[5]  = mousikomiJyokyoBeans[i].getClassBean().getKamokuBean().getKamokuCode();
            out[6]  = mousikomiJyokyoBeans[i].getClassBean().getClassCode();
            out[7]  = mousikomiJyokyoBeans[i].getClassBean().getKaisibi();
            out[8]  = mousikomiFromTableBeans[0].getMousikomibi();
            out[9]  = mousikomiFromTableBeans[0].getMousikomijikoku();
            out[10] = mousikomiFromTableBeans[0].getMousikomisya();
            /* �\���҂��p�[�\�i���e�[�u���ɑ��݂��Ȃ��ꍇ */
            if ( mousikomisya != null ) {
                out[11] = mousikomisya.getSosikiCode();
            } else {
                out[11] = "";
            }
            out[12] = mousikomiFromTableBeans[0].getSyoninsya1();
            out[13] = syoninsya.getSosikiCode();

            /* ���C���O�o�� */
            Log.kensyu( out );        
        }
        // INS#P-A30AM1-008-004-E

		/* INS#P-A30AM1-002-007-S */
		// �L�����Z���҂����F���[�����M���e���쐬����
		if ( cancelMachiClass != 0 ) {
			MessageCreateHelper helper = MessageCreateHelper.createInstance( "XCB020" );

			for ( int i = 0; i < kamokuCode.length; i++ ) {

				if ( mousikomiJyokyoBeans[i].getClassBean().getTeiin() != null ) {// INS#P-A30AM1-030-003

					int teiin = mousikomiJyokyoBeans[i].getClassBean().getTeiin().intValue();
					int cancelMachiNinzuu = 0;
					String str = (String)ReadFile.fileMapData.get("CANCEL_MACHI_NINZUU");
						if (str != null) {
						  cancelMachiNinzuu = Integer.parseInt(str);
						}
				
					/* �x����ʂ���J�ڂ����ꍇ�A�e�N���X�̏��F�ςݐl�����擾 */	
					if ( req != null ) {		
						syoninzumiNinzu = (String[])request.getParameterValues( "syoninzumiNinzu" );
					}
				
					/* �L�����Z���҂��N���X�̐\���҂ɂ̂݃��[���𑗐M */	
					if ( ( Integer.parseInt(syoninzumiNinzu[i]) >= teiin )
						 && ( Integer.parseInt(syoninzumiNinzu[i]) < teiin + cancelMachiNinzuu ) ) {
			
						/* ����NO�擾 */
						PCY_PersonalEJBHome personalHome2   = ( PCY_PersonalEJBHome )locator.getServiceLocation( "PCY_PersonalEJB",
							PCY_PersonalEJBHome.class );
						PCY_PersonalEJB personalEjb2 = personalHome2.create(  );
						PCY_PersonalBean mousikomisya = personalEjb2.getPersonalInfo( mousikomiJyokyoBeans[i].getSimeiNo(), loginuser );

						/* �������̖����擾���APCY_PersonalBean���Z�b�g */
						String[] sosiki = SosikiBean.getSosikiByCode( mousikomisya.getSosikiCode().trim(), loginuser.getSimeiNo() );
						mousikomisya.setBusyoRyakusyoMei( sosiki[2] );
						helper.setParameter( "personal", mousikomisya );

						helper.setParameter( "class", new PCY_ClassBeanForMail( mousikomiJyokyoBeans[i].getClassBean() ) );
						helper.setParameter( "kamoku", new PCY_KamokuBeanForMail( mousikomiJyokyoBeans[i].getClassBean().getKamokuBean() ) );
						String mailContent = helper.getMessage();
						/* ���[���{���̓��e���Z�b�g */
						request.setAttribute( "mailContent", mailContent );
			
						try {
							/* ���C�҂Ƀ��[���𑗐M���� */
							PCY_KensyuMailSender.sendCancelMatiSyonin( mousikomiJyokyoBeans[i], mousikomisya,
								 mousikomiJyokyoBeans[i].getClassBean(), null, mailContent, loginuser );  // For Syanai
						} catch ( PCY_WarningException e ) {
							/* ���[���A�h���X��null�̏ꍇ */
							nullMailFlg = true;
						} catch ( AddressException e ) {
							request.setAttribute( "warningID", "WCB120" ); // CHG#P-A30AC4-010-001
							throw new PCY_WarningException( e );
						} catch ( Exception e ) {
							request.setAttribute( "warningID", "WCB120" ); // CHG#P-A30AC4-010-001
							throw new PCY_WarningException( e );
						}
					}
				}// INS#P-A30AM1-030-003
			}	
		
			if ( nullMailFlg == true ) {
				/* CHG#P-A30AS1-007-001-S */
				request.setAttribute( "warningID", "WCB120" );
				throw new PCY_WarningException( "WCB120" );
				/* CHG#P-A30AS1-007-001-E */			
			}
			
		}
		// For Syanai-E
		/* INS#P-A30AM1-002-007-E */
		
        /*���\�b�h�g���[�X�o��*/
		Log.performance( loginuser.getSimeiNo(  ), false, "" );
        Log.method( loginuser.getSimeiNo(), "OUT", "" );

        return getForwardPath();
    }

}
