/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/02/14              ���� ��F    �V�K�쐬
 *   2005/12/10              ���Y �T��    ����pgetWriter�ɕύX
 */
package jp.co.hisas.career.learning.base.servlet;

import com.lowagie.text.DocumentException;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.bean.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.HcdbDef;

import java.io.*;

import java.rmi.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;

import javax.servlet.http.*;


/**
 *<PRE>
 *
 * �T�v�F
 *   �����CVS�쐬���s���B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 *
 *</PRE>
 */
public class PCY330_MeiboDownLoadServlet extends PCY010_ControllerServlet {
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PCY_PersonalBean loginuser )
        throws NamingException, CreateException, RemoteException, PCY_WarningException, IOException, 
            DocumentException, Exception {
        /*���\�b�h�g���[�X�o��*/
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );
        Log.performance( loginuser.getSimeiNo(  ), true, "" );

        try {
            /* �g�D�}�b�v�擾 */
            Map sosikiMap = PCY_CodeBean.getInstance(  ).getCodeMap( PCY_CodeBean.SOSIKI );

            PCY_ServiceLocator locator   = PCY_ServiceLocator.getInstance(  );

			// �N���X���
			PCY_ClassEJBHome classHome = ( PCY_ClassEJBHome )locator.getServiceLocation( "PCY_ClassEJB",
					PCY_ClassEJBHome.class );
			PCY_ClassEJB classEJB = classHome.create(  );
			PCY_ClassBean classBean = classEJB.doSelectByPrimaryKey( new PCY_ClassBean( request ),
					loginuser );

			PCY_TaisyoEJBHome home_taisyo = (PCY_TaisyoEJBHome)locator.getServiceLocation(
																"PCY_TaisyoEJB",
																 PCY_TaisyoEJBHome.class );
			PCY_TaisyoEJB ejb_taisyo = home_taisyo.create();
			PCY_SosikiBean[] sosikiBeens = ejb_taisyo.getSosiki( loginuser );

            // �\����
			PCY_KensyuKanriJohoBean[] taisyosyaBeans = null;
			PCY_MousikomiJyokyoEJBHome mousikomihome = ( PCY_MousikomiJyokyoEJBHome )locator.getServiceLocation( 
															"PCY_MousikomiJyokyoEJB",
															PCY_MousikomiJyokyoEJBHome.class );
			PCY_MousikomiJyokyoEJB mousikomiejb = mousikomihome.create(  );
			taisyosyaBeans = mousikomiejb.getListWithClass( classBean.getKamokuBean().getKamokuCode(), 
															classBean.getClassCode(),null, loginuser );

			//�\�[�g
			List taisyosyaList = new ArrayList(  );
			for (int i = 0; i < taisyosyaBeans.length; i++) {
				taisyosyaList.add( taisyosyaBeans[i] );
			}
			PCY_KensyuKanriJohoBean[] SorttaisyosyaBeans = new PCY_KensyuKanriJohoBean[taisyosyaList.size(  )];
			SorttaisyosyaBeans = ( PCY_KensyuKanriJohoBean[] )taisyosyaList.toArray( SorttaisyosyaBeans );
			/* �g�D�R�[�h�A�����ԍ��̏��Ń\�[�g���� */
			Arrays.sort( SorttaisyosyaBeans, new SosikiSimeiComparator(  ) );

			Vector lines = new Vector();
			for (int i = 0; i < SorttaisyosyaBeans.length; i++) {
				Vector columns = new Vector();

				//�_�E�����[�h�ΏۃX�e�[�^�X  (��u�ҁA�񍐑ҁA����ҁA���C���A�C��)
					//��u��(�\���󋵃X�e�[�^�X1:��t���2)
				if( ( SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null && 
					  SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("1") && 
					  SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() != null &&
					  SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai().equals("2") ) ||
					//�񍐑�(�\���󋵃X�e�[�^�X2:��t���:NULL)
					( SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null && 
					  SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("2") && 
					  SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() == null ) ||
					//�����(�\���󋵃X�e�[�^�X3:��t���:NULL)
					( SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null && 
					  SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("3") && 
					  SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() == null ) ||
					//���C��(�C������:0)
					( SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei() != null && 
					  SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei().equals("0") ) ||
						//�C��(�C������:1)
					( SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei() != null && 
					  SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei().equals("1") ) ){

					/* �l���擾 */
					String busyoRyakusyo = "";
					for (int j = 0; j < sosikiBeens.length; j++) {
						if (sosikiBeens[j].getSosikiCode() != null &&
							SorttaisyosyaBeans[i].getMousikomiBean(  ).getPersonalBean(  ).getSosikiCode(  ) != null )
						{
							if (sosikiBeens[j].getSosikiCode().trim().equals( 
								SorttaisyosyaBeans[i].getMousikomiBean(  ).getPersonalBean(  ).getSosikiCode(  ).trim() ))
							{
								busyoRyakusyo = sosikiBeens[j].getBusyoRyakusyoMei();
								break;
							}
						}
					}
					//INS#0301K-0106-S
					//�\���Ώێ҂̌��E�ސE�t���O��2(�ސE)�ł���Ε\�����Ȃ�
					String gensyokuTaisyoku = SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getGensyokuTaisyokuFlg();
					if (gensyokuTaisyoku == null || gensyokuTaisyoku.equals("2") ) {
						continue;
					}
					columns.add( busyoRyakusyo);
					columns.add( SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSimeiNo() );
					columns.add( SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getKanjiSimei() );
					columns.add( SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getEigoSimei() );
					columns.add( SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getKanaSimei() );
					columns.add( PCY_CodeBean.getInstance(  ).getValue( PCY_CodeBean.TAISYO_KUBUN,
										SorttaisyosyaBeans[i].getTaisyousyaBean().getTaisyoKubun() ) );
					columns.add( SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getMail() );
					columns.add( SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSosikiCode() );
// ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j START
                    columns.add( SorttaisyosyaBeans[i].getMousikomiBean().getSyokuiBean().getSyokui() );
// ADD 2010/01/28 COMTURE ����[�o���h����]�iHTML�j.vm�i#11�j END
					lines.add(columns);
				}
			}

			//���݂̓��t�Ǝ���
			String dateTime = getNowTime(loginuser) ;
			//�_�E�����[�h�e���v���[�g��
			String tableName = (String)request.getParameter( "download_templete" );
			String DLtableName = "";
			if ( null != tableName && !tableName.equals("") && tableName.length() >= 4 ){
				if (tableName.indexOf("HTML") != -1) {
					DLtableName = "Template_HTML" ;
				} else if (tableName.indexOf("CVS") != -1) {
						DLtableName = "Template_CVS" ;
				}else{
					DLtableName = "Template" ;
				}
			}else{
				DLtableName = "Template" ;
			}
			
			//�t�@�C����
			String fileName = dateTime + "_" + DLtableName ;
			//�_�E�����[�h�`��
			String downloadKeisiki = (String)request.getParameter( "download_keisiki" );
			if (downloadKeisiki.equals("HTML")){
				fileName += ".html";
			}else{
				fileName += ".csv";
			}

			/* �w�b�_�������� */
			VelocityHelper vh = new VelocityHelper( tableName );

			vh.setParameter( "classBean",  new PCY_ClassBeanForDL( classBean ) );
			vh.setParameter( "kamokuBean", new PCY_KamokuBeanForDL( classBean.getKamokuBean(  ) ) );
			vh.setParameter( "lines", lines );
			vh.setParameter( "date", dateTime.substring( 0, 4 ) + "/" + 
									 dateTime.substring( 4, 6 ) + "/" + 
									 dateTime.substring( 6, 8 ) );
			vh.setParameter( "time", dateTime.substring( 8, 10) + ":" + 
									 dateTime.substring(10, 12) );
			Writer w = vh.getWriterMeibo();  // CHG#P-A30AH1-019-001
			ByteArrayInputStream bais = new ByteArrayInputStream(w.toString().getBytes());
			request.setAttribute("H080_FileName" ,fileName);
			request.setAttribute("H081_ContentType" ,HcdbDef.CONTENT_TYPE);
			request.setAttribute("STREAM" ,bais);

			Log.performance(loginuser.getSimeiNo(), false, "");
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return getForwardPath();

        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw e;
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } catch ( IOException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0012", e );
            throw e;
        } catch ( DocumentException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } catch ( Exception e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        }
    }

	/**
	 * ���݂̓��t�Ǝ����̕�������擾�����^�[������B
	 * 
	 * @return ���t�Ǝ����̕�����iyyyymmddhhmmss�j
	 */
	private String getNowTime(PCY_PersonalBean loginuser) {
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Calendar cal = Calendar.getInstance();
		String year = Integer.toString(cal.get(Calendar.YEAR));
		String month = Integer.toString(cal.get(Calendar.MONTH) + 1);
		if ( month.length() == 1 ) {
			month = "0" + month;
		}
		String day = Integer.toString(cal.get(Calendar.DAY_OF_MONTH));
		if ( day.length() == 1 ) {
			day = "0" + day;
		}
		String hour = Integer.toString(cal.get(Calendar.HOUR_OF_DAY));
		if ( hour.length() == 1 ) {
			hour = "0" + hour;
		}
		String minute = Integer.toString(cal.get(Calendar.MINUTE));
		if ( minute.length() == 1 ) {
			minute = "0" + minute;
		}
		String second = Integer.toString(cal.get(Calendar.SECOND));
		if ( second.length() == 1 ) {
			second = "0" + second;
		}

		Log.method(loginuser.getSimeiNo(), "OUT", "");
		return year + month + day + hour + minute + second;
	}

	/**
	 *   �g�D�R�[�h�A����No���L�[�Ƀ\�[�g���܂��B
	 */
	private class SosikiSimeiComparator implements Comparator {
		public int compare( Object o1, Object o2 ) {
			PCY_KensyuKanriJohoBean taisyou1 = ( PCY_KensyuKanriJohoBean )o1;
			PCY_KensyuKanriJohoBean taisyou2 = ( PCY_KensyuKanriJohoBean )o2;

			int ret = 0;

			/* ��P�\�[�g�L�[�@�g�D�R�[�h */
			if ( ( taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode(  ) != null ) && 
				 ( taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode(  ) != null ) ) {
				ret = taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode(  ).compareTo( 
					  taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode(  ) );
			} else if ( ( taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode(  ) == null ) && 
						 ( taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode(  )!= null ) ) {
				return 1;
			} else if ( ( taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode(  ) != null ) && 
						 ( taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode(  ) == null ) ) {
				return -1;
			}

			if ( ret != 0 ) {
				return ret;
			}

			/* ��Q�\�[�g�L�[�@����No */
			if ( ( taisyou1.getMousikomiBean().getPersonalBean().getSimeiNo() != null ) && 
				 ( taisyou2.getMousikomiBean().getPersonalBean().getSimeiNo(  ) != null ) ) {
				ret = taisyou1.getMousikomiBean().getPersonalBean().getSimeiNo(  ).compareTo( 
					  taisyou2.getMousikomiBean().getPersonalBean().getSimeiNo(  ) );
			} else if ( ( taisyou1.getMousikomiBean().getPersonalBean().getSimeiNo(  ) == null ) && 
						 ( taisyou2.getMousikomiBean().getPersonalBean().getSimeiNo(  )!= null ) ) {
				return 1;
			} else if ( ( taisyou1.getMousikomiBean().getPersonalBean().getSimeiNo(  ) != null ) && 
						 ( taisyou2.getMousikomiBean().getPersonalBean().getSimeiNo(  ) == null ) ) {
				return -1;
			}

			if ( ret != 0 ) {
				return ret;
			}

			return ret;
		}
	}
}
