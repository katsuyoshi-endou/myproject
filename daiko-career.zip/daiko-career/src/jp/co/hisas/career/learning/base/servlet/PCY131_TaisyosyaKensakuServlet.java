/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/02/19  01.00       ���Y�@�T��    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.common.*; //INS#0301L-0103

import java.rmi.*;

import javax.ejb.*;

import javax.naming.*;

import javax.servlet.http.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY131_TaisyosyaKensakuServlet �N���X
 *
 * �@�\�����F
 *   �Ώێ҂̌������s���܂��B
 *
 *</PRE>
 */
public class PCY131_TaisyosyaKensakuServlet extends PCY010_ControllerServlet {
    /**
     * �Ώێ҂̌������s���܂��B
     *
     * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
     */
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PCY_PersonalBean loginuser ) throws NamingException, CreateException, RemoteException {
        /*���\�b�h�g���[�X�o��*/
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );

        PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
        PCY_TaisyoEJBHome home     = ( PCY_TaisyoEJBHome )locator.getServiceLocation( "PCY_TaisyoEJB",
                PCY_TaisyoEJBHome.class );
        PCY_TaisyoEJB ejb          = home.create(  );

        PCY_TaisyosyaBean kensaku_taisyosyaBean = new PCY_TaisyosyaBean( request );
        kensaku_taisyosyaBean.getPersonalBean(  ).setSosikiCode( request.getParameter( 
                "sosiki_code" ) );
        //INS#0301L-0103 -S
        kensaku_taisyosyaBean.getPersonalBean(  ).setKanjiSimei( PZZ010_CharacterUtil
        		.convertHalfSizeKana( kensaku_taisyosyaBean.getPersonalBean(  ).getKanjiSimei(  ) ) );
        kensaku_taisyosyaBean.getPersonalBean(  ).setKanaSimei( PZZ010_CharacterUtil
        		.convertHalfSizeKana( kensaku_taisyosyaBean.getPersonalBean(  ).getKanaSimei(  ) ) );
        kensaku_taisyosyaBean.getPersonalBean(  ).setEigoSimei( PZZ010_CharacterUtil
        		.convertHalfSizeKana( kensaku_taisyosyaBean.getPersonalBean(  ).getEigoSimei(  ) ) );
        //INS#0301L-0103 -E
        request.setAttribute( "kensakuKekkaBeans",
            ejb.getTaisyosya( kensaku_taisyosyaBean, loginuser ) );

        /*���\�b�h�g���[�X�o��*/
        Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

        return getForwardPath(  );
    }
}
