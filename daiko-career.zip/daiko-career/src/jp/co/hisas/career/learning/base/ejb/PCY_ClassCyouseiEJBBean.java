/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/12/26  01.00      ��� �ӎ�   �V�K�쐬
 */
package jp.co.hisas.career.learning.base.ejb;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.rmi.*;

import java.sql.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_ClassCyouseiEJBBean�N���X
 *
 * �@�\�����F
 *   �N���X������e�[�u������ꗗ���擾���܂��B
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PCY_ClassCyouseiEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PCY_ClassCyouseiEJBBean implements SessionBean {
    private SessionContext context = null;

    /**
     * �N���X���������e�[�u���f�[�^�擾���s���B
     *
     * @param loginuser ���O�C�����[�U
     * @return �N���X���������f�[�^
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_ClassCyouseiBean[] doSelect(PCY_ClassCyouseiBean classCyousei,PCY_PersonalBean loginuser ){
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );
		
			Collection ret   = new ArrayList(  );
			
			
            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            // SQL�쐬
            StringBuffer sql = new StringBuffer(  );
            sql.append( "SELECT " );
            sql.append( PCY_ClassCyouseiBean.getColumns());
            sql.append(" FROM ");
            sql.append( HcdbDef.L93_TBL);
            sql.append( " WHERE ");
			sql.append( " SYORIBI = ? AND ");
			sql.append( " SYORIJIKOKU = ? AND");
			sql.append( " SYORISYA = ? AND ");
			sql.append( " SYORI_FLG = ? ");

			ps = con.prepareStatement( sql.toString(  ) );
			Log.debug( sql.toString(  ) );
			
			ps.setString( 1, classCyousei.getSyoribi() );
			ps.setString( 2, classCyousei.getSyorijikoku() );
			ps.setString( 3, classCyousei.getSyorisya() );
			ps.setString( 4, classCyousei.getSyoriFlg() );
		
			Log.debug("1:" + classCyousei.getSyoribi());
			Log.debug("2:" + classCyousei.getSyorijikoku());
			Log.debug("3:" + classCyousei.getSyorisya());
			Log.debug("4:" + classCyousei.getSyoriFlg());

			ResultSet rs = ps.executeQuery(  );
            
			while ( rs.next(  ) ) {
				ret.add( new PCY_ClassCyouseiBean( rs,"") );
			}
			
			// ���\�b�h�g���[�X�o��
		   Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

		   return ( PCY_ClassCyouseiBean[] )ret.toArray( new PCY_ClassCyouseiBean[0] );
		   
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
    }

	/**
	 * �N���X���������e�[�u���f�[�^�擾���s���B
	 * �������A���������A�����ҁA�����t���O�ADL�񐔂�Group By���s�Ȃ�
	 * @param loginuser ���O�C�����[�U
	 * @return �N���X���������f�[�^
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_ClassCyouseiBean[] doSelectGroupBy(PCY_PersonalBean loginuser ){
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );
		
			Collection ret   = new ArrayList(  );
			
			
			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con = locator.getDataSource(  ).getConnection(  );

			// SQL�쐬
			StringBuffer sql = new StringBuffer(  );
			sql.append( "SELECT " );
			sql.append( PCY_ClassCyouseiBean.getColumnsGroupBy());
			sql.append( " FROM ");
			sql.append( HcdbDef.L93_TBL );
			sql.append( " GROUP BY  ");
			sql.append( " SYORIBI, ");
			sql.append( " SYORIJIKOKU,  ");
			sql.append( " SYORISYA, ");
			sql.append( " SYORI_FLG, ");
			sql.append( " DL_KAISU ");
			sql.append( " ORDER BY ");
			sql.append( " SYORIBI DESC, ");
			sql.append( " SYORIJIKOKU DESC ");

			/* �f�o�b�O���O */
			Log.debug( sql.toString(  ) );
			ps = con.prepareStatement( sql.toString(  ) );

			ResultSet rs = ps.executeQuery(  );
            
			while ( rs.next(  ) ) {
				ret.add( new PCY_ClassCyouseiBean( rs,"groupBy") );
			}
			// ���\�b�h�g���[�X�o��
		   Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

		   return ( PCY_ClassCyouseiBean[] )ret.toArray( new PCY_ClassCyouseiBean[0] );
		   
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * �N���X���������e�[�u���̃f�[�^�����̎擾���s���B
	 * �������A���������A�����ҁA�����t���O�ADL�񐔂ł�����������Ԃ�
	 * @param classCyouseiBeans �N���X��������Beans
	 * @param loginuser ���O�C�����[�U
	 * @return �N���X���������f�[�^
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_ClassCyouseiBean[] doSelectCount(PCY_ClassCyouseiBean[] classCyouseiBeans, PCY_PersonalBean loginuser ){
		Connection con       = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );
		
			Integer count = null;
			
			
			// �R�l�N�V�����擾
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
			con = locator.getDataSource(  ).getConnection(  );

			// SQL�쐬
			StringBuffer sql = new StringBuffer(  );
			sql.append( "SELECT " );
			sql.append( "count(*) count");
			sql.append( " FROM ");
			sql.append( HcdbDef.L93_TBL );
			sql.append( " WHERE " );
			sql.append( " SYORIBI = ? ");
			sql.append( " AND " + " SYORIJIKOKU = ? ");
			sql.append( " AND " + " SYORISYA = ? ");
			sql.append( " AND " + " SYORI_FLG = ? ");
			sql.append( " AND " + " DL_KAISU = ? ");


			/* �f�o�b�O���O */
			Log.debug( sql.toString(  ) );

			ps = con.prepareStatement( sql.toString(  ) );

			for(int i = 0 ; i<classCyouseiBeans.length;i++){
			
				ps.setString( 1, classCyouseiBeans[i].getSyoribi() );
				ps.setString( 2, classCyouseiBeans[i].getSyorijikoku() );
				ps.setString( 3, classCyouseiBeans[i].getSyorisya() );
				ps.setString( 4, classCyouseiBeans[i].getSyoriFlg() );
				ps.setInt( 5, classCyouseiBeans[i].getDlKaisu().intValue() );
				
				Log.debug("1:" + classCyouseiBeans[i].getSyoribi());
				Log.debug("2:" + classCyouseiBeans[i].getSyorijikoku());
				Log.debug("3:" + classCyouseiBeans[i].getSyorisya());
				Log.debug("4:" + classCyouseiBeans[i].getSyoriFlg());
				Log.debug("5:" + classCyouseiBeans[i].getDlKaisu().toString());

				ResultSet rs = ps.executeQuery(  );
            
				while ( rs.next(  ) ) {
					count = new Integer(rs.getInt("count"));
					
				}
				classCyouseiBeans[i].setKensuu(count);
				Log.debug( "count:" + count.toString() );
			}

			// ���\�b�h�g���[�X�o��
		   Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

		   return classCyouseiBeans;
		   
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

    /**
     * �N���X���������e�[�u���̒ǉ����s��
     *
     * @param classCyouseiBeans �ǉ����
     * @param loginuser ���O�C�����[�U���
     * @return �ǉ�����
     * @exception PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doInsert( PCY_ClassCyouseiBean[] classCyouseiBeans, PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            int count = 0;

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            for ( int i = 0; i < classCyouseiBeans.length; i++ ) {
                // SQL�쐬
                StringBuffer sql = new StringBuffer(  );
                sql.append( "INSERT INTO " );
                sql.append( HcdbDef.L93_TBL );
                sql.append( " (" );
                sql.append( "    SYORIBI," );
                sql.append( "    SYORIJIKOKU," );
                sql.append( "    SYORISYA," );
                sql.append( "    SYORI_FLG," );
                sql.append( "    DL_KAISU," );
                sql.append( "    KAMOKU_CODE," );
                sql.append( "    CLASS_CODE," );
                sql.append( "    SIMEI_NO," );
                sql.append( "    BEFORE_STATUS," );
                sql.append( "    BEFORE_UKETSUKE_JYOTAI, " );
				sql.append( "    AFTER_STATUS, " );
				sql.append( "    AFTER_UKETUKE_JYOTAI, " );
				sql.append( "    MOUSIKOMIBI, " );
				sql.append( "    MOUSIKOMIJIKOKU, " );
				sql.append( "    MOUSIKOMISYA, " );
				sql.append( "    SYONINBI1, " );
				sql.append( "    SYONINJIKOKU1, " );
				sql.append( "    SYONINSYA1, " );
				sql.append( "    SYONINBI2, " );
				sql.append( "    SYONINJIKOKU2, " );
				sql.append( "    SYONINSYA2, " );
				sql.append( "    UKETUKEBI, " );
				sql.append( "    UKETUKEJIKOKU, " );
				sql.append( "    UKETUKESYA) " );
                sql.append( "  VALUES ( ?, ?, ?, ?, ?, ?, " );
                sql.append( "           ?, ?, ?, ?, ?, ? , " );
				sql.append( "           ?, ?, ?, ?, ?, ? , " );
				sql.append( "           ?, ?, ?, ?, ?, ? ) " );

                /* �f�o�b�O���O */
                Log.debug( sql.toString(  ) );

                ps = con.prepareStatement( sql.toString(  ) );

                ps.setString( 1, classCyouseiBeans[i].getSyoribi() );
                ps.setString( 2, classCyouseiBeans[i].getSyorijikoku() );
                ps.setString( 3, classCyouseiBeans[i].getSyorisya() );
                ps.setString( 4, classCyouseiBeans[i].getSyoriFlg() );
				ps.setInt( 5, classCyouseiBeans[i].getDlKaisu().intValue() );
				ps.setString( 6, classCyouseiBeans[i].getKamokuCode() );
				ps.setString( 7, classCyouseiBeans[i].getClassCode() );
				ps.setString( 8, classCyouseiBeans[i].getSimeiNo() );
				ps.setString( 9, classCyouseiBeans[i].getBeforeStatus() );
				ps.setString( 10, classCyouseiBeans[i].getBeforeUketsukeJyotai() );
				ps.setString( 11, classCyouseiBeans[i].getAfterStatus() );
				ps.setString( 12, classCyouseiBeans[i].getAfterUketukeJyotai() );
				ps.setString( 13, classCyouseiBeans[i].getMousikomibi() );
				ps.setString( 14, classCyouseiBeans[i].getMousikomijikoku() );
				ps.setString( 15, classCyouseiBeans[i].getMousikomisya() );
				ps.setString( 16, classCyouseiBeans[i].getSyoninbi1() );
				ps.setString( 17, classCyouseiBeans[i].getSyoninjikoku1() );
				ps.setString( 18, classCyouseiBeans[i].getSyoninsya1() );
				ps.setString( 19, classCyouseiBeans[i].getSyoninbi2());
				ps.setString( 20, classCyouseiBeans[i].getSyoninjikoku2() );
				ps.setString( 21, classCyouseiBeans[i].getSyoninsya2()  );
				ps.setString( 22, classCyouseiBeans[i].getUketukebi() );
				ps.setString( 23, classCyouseiBeans[i].getUketukejikoku() );
				ps.setString( 24, classCyouseiBeans[i].getUketukesya() );

                count += ps.executeUpdate(  );
                ps.close(  ); // INS#P-ALH41-001-006
            }

            if ( count != classCyouseiBeans.length ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException( "�ǉ��\�萔�ƁA�ǉ������������܂���ł����B" );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			context.setRollbackOnly(  );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			context.setRollbackOnly(  );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
			context.setRollbackOnly(  );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

    /**
     * �N���X�����e�[�u���̃_�E�����[�h�񐔂̍X�V���s���B
     *
     * @param classCyouseiBeans �X�V���
     * @param loginuser ���O�C�����[�U
     * @return �X�V����
     * @exception PCY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @throws SQLException
     * @throws PCY_WarningException
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdate( PCY_ClassCyouseiBean[] classCyouseiBeans,PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            int count = 0;

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            for ( int i = 0; i < classCyouseiBeans.length; i++ ) {
                // SQL�쐬
                StringBuffer sql = new StringBuffer(  );
                sql.append( "UPDATE " );
                sql.append( HcdbDef.L93_TBL );
                sql.append( " SET " );
                sql.append( "    DL_KAISU=? " );
				sql.append( " WHERE " );
				sql.append( " SYORIBI = ? ");
				sql.append( " AND " + " SYORIJIKOKU = ? ");
				sql.append( " AND " + " SYORISYA = ? ");
				sql.append( " AND " + " SYORI_FLG = ? ");
				sql.append( " AND " + " DL_KAISU = ? ");

                /* �f�o�b�O���O */
                Log.debug( sql.toString(  ) );

                ps = con.prepareStatement( sql.toString(  ) );

				int kaisuu = classCyouseiBeans[i].getDlKaisu(  ).intValue();
				kaisuu++;
                ps.setInt( 1,  kaisuu);
				ps.setString( 2, classCyouseiBeans[i].getSyoribi() );
				ps.setString( 3, classCyouseiBeans[i].getSyorijikoku() );
				ps.setString( 4, classCyouseiBeans[i].getSyorisya() );
				ps.setString( 5, classCyouseiBeans[i].getSyoriFlg() );
				ps.setInt( 6, classCyouseiBeans[i].getDlKaisu().intValue() );
				
				Log.debug("1:" + kaisuu);
				Log.debug("2:" + classCyouseiBeans[i].getSyoribi());
				Log.debug("3:" + classCyouseiBeans[i].getSyorijikoku());
				Log.debug("4:" + classCyouseiBeans[i].getSyorisya());
				Log.debug("5:" + classCyouseiBeans[i].getSyoriFlg());
				Log.debug("6:" + classCyouseiBeans[i].getDlKaisu().toString());


                count += ps.executeUpdate(  );
                ps.close(  ); // INS#P-ALH41-001-006
            }

            if ( count != classCyouseiBeans.length ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException( "�X�V�\�萔�ƁA�X�V�����������܂���ł����B" );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            context.setRollbackOnly(  );
            throw new PCY_WarningException(e);
        } catch ( SQLException e ) {
            context.setRollbackOnly(  );
            throw new PCY_WarningException(e);
        } catch ( RuntimeException e ) {
            context.setRollbackOnly(  );
            throw new PCY_WarningException(e);
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �N���X���������e�[�u���̍폜���s���B
     *
     * @param classCyuseiBeans �폜���
     * @param loginuser ���O�C�����[�U
     * @return �폜����
     * @throws PCY_WarningException
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doDelete( PCY_ClassCyouseiBean[] classCyouseiBeans,PCY_PersonalBean loginuser )
        throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            int count = 0;

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            for ( int i = 0; i < classCyouseiBeans.length; i++ ) {
                // SQL�쐬
                StringBuffer sql = new StringBuffer(  );
                sql.append( "DELETE FROM " );
                sql.append( HcdbDef.L93_TBL );
				sql.append( " WHERE " );
				sql.append( " SYORIBI = ? ");
				sql.append( " AND " + " SYORIJIKOKU = ? ");
				sql.append( " AND " + " SYORISYA = ? ");
				sql.append( " AND " + " SYORI_FLG = ? ");
				sql.append( " AND " + " DL_KAISU = ? ");
                /* �f�o�b�O���O */
                Log.debug( sql.toString(  ) );

                ps = con.prepareStatement( sql.toString(  ) );

				ps.setString( 1, classCyouseiBeans[i].getSyoribi() );
				ps.setString( 2, classCyouseiBeans[i].getSyorijikoku() );
				ps.setString( 3, classCyouseiBeans[i].getSyorisya() );
				ps.setString( 4, classCyouseiBeans[i].getSyoriFlg() );
				ps.setInt( 5, classCyouseiBeans[i].getDlKaisu().intValue() );
				
				Log.debug("1:" + classCyouseiBeans[i].getSyoribi());
				Log.debug("2:" + classCyouseiBeans[i].getSyorijikoku());
				Log.debug("3:" + classCyouseiBeans[i].getSyorisya());
				Log.debug("4:" + classCyouseiBeans[i].getSyoriFlg());
				Log.debug("5:" + classCyouseiBeans[i].getDlKaisu().toString());


                count += ps.executeUpdate(  );
                ps.close(  ); // INS#P-ALH41-001-006
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            context.setRollbackOnly(  );
            throw new PCY_WarningException(e);
        } catch ( SQLException e ) {
            context.setRollbackOnly(  );
            throw new PCY_WarningException(e);
        } catch ( RuntimeException e ) {
            context.setRollbackOnly(  );
            throw new PCY_WarningException(e);
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext( SessionContext context )
		throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 *
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate(  ) throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove(  ) throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate(  ) throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate(  ) throws EJBException, RemoteException {
	}

}
