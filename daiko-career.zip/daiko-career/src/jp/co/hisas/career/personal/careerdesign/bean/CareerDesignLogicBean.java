/*
 * Created on 2005/11/24
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package jp.co.hisas.career.personal.careerdesign.bean;

import java.util.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import jp.co.hisas.career.personal.careerdesign.ejb.*;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 *<PRE>
 * �T�v:
 *   �T�[�u���b�g����̗v�����󂯂�EJB�Ăяo�����s���A�擾�����l���i�[����B
 *
 * �g�p���@:
 *   �T�[�u���b�g�AJSP����Ăяo���B
 *</PRE>
 */
public class CareerDesignLogicBean {
	
	/** �萔�Q */
	private final String KANJI_SIMEI = "kanji_simei";
	private final String SIMEI_NO = "simei_no";
	private final String NENREI = "nenrei";
	private final String KINMUCHI = "kinmuchi";
	private final String NYUSYA_NENGETSU = "nyusya_nengetu";
	private final String BUSYO_RYAKUSYO_MEI = "busyo_ryakusyo_mei";
	private final String ZAISEKI_KIKAN_NEN = "zaiseki_kikan_nen";
	private final String ZAISEKI_KIKAN_TUKI = "zaiseki_kikan_tuki";
	private final String TOKUHITU_CAREER_REKI = "tokuhitu_career_reki";
	private final String SENMONSEI = "senmonsei";
	private final String SOZOSEI = "sozosei";
	private final String TAIJIN_NORYOKU = "taijin_noryoku";
	private final String SOSIKI_MANAGEMENT = "sosiki_management";
	private final String PC_SKILL = "pc_skill";
	private final String SONOTA_CAREER = "sonota_career";
	private final String NORYOKU_TUYOMI_HAKKI = "noryoku_tuyomi_hakki";
	private final String NORYOKU_TUYOMI_HAKKI_VALUE = "noryoku_tuyomi_hakki_value";
	private final String HAKKI_HUKA_RIYU_1 = "hakki_huka_riyu_1";
	private final String HAKKI_HUKA_RIYU_2 = "hakki_huka_riyu_2";
	private final String HAKKI_HUKA_RIYU_3 = "hakki_huka_riyu_3";
	private final String HAKKI_HUKA_RIYU_4 = "hakki_huka_riyu_4";
	private final String HAKKI_HUKA_RIYU_5 = "hakki_huka_riyu_5";
	private final String HAKKI_HUKA_RIYU_6 = "hakki_huka_riyu_6";
	private final String HAKKI_HUKA_RIYU_7 = "hakki_huka_riyu_7";
	private final String HAKKI_HUKA_RIYU_VALUE_1 = "hakki_huka_riyu_value_1";
	private final String HAKKI_HUKA_RIYU_VALUE_2 = "hakki_huka_riyu_value_2";
	private final String HAKKI_HUKA_RIYU_VALUE_3 = "hakki_huka_riyu_value_3";
	private final String HAKKI_HUKA_RIYU_VALUE_4 = "hakki_huka_riyu_value_4";
	private final String HAKKI_HUKA_RIYU_VALUE_5 = "hakki_huka_riyu_value_5";
	private final String HAKKI_HUKA_RIYU_VALUE_6 = "hakki_huka_riyu_value_6";
	private final String HAKKI_HUKA_RIYU_VALUE_7 = "hakki_huka_riyu_value_7";
       
	private final String HAKKI_HUKA_RIYU_SONOTA = "hakki_huka_riyu_sonota";
	private final String GEN_SYOZOKU_TANTO_1 = "gen_syozoku_tanto_1";
	private final String TUGI_KIBO_TEXT_1 = "tugi_kibo_text_1";
	private final String TUGI_KIBO_NENSU_1 = "tugi_kibo_nensu_1";
	private final String SONOTUGI_KIBO_TEXT_1 = "sonotugi_kibo_text_1";
	private final String SONOTUGI_KIBO_NENSU_1 = "sonotugi_kibo_nensu_1";
	private final String SAISYU_KIBO_1 = "saisyu_kibo_1";
	private final String KIBO_RIYU_VISION_1 = "kibo_riyu_vision_1";
	private final String GEN_SYOZOKU_TANTO_2 = "gen_syozoku_tanto_2";
	private final String TUGI_KIBO_TEXT_2 = "tugi_kibo_text_2";
	private final String TUGI_KIBO_NENSU_2 = "tugi_kibo_nensu_2";
	private final String SONOTUGI_KIBO_TEXT_2 = "sonotugi_kibo_text_2";
	private final String SONOTUGI_KIBO_NENSU_2 = "sonotugi_kibo_nensu_2";
	private final String SAISYU_KIBO_2 = "saisyu_kibo_2";
	private final String KIBO_RIYU_VISION_2 = "kibo_riyu_vision_2";
	private final String GEN_SYOZOKU_TANTO_3 = "gen_syozoku_tanto_3";
	private final String TUGI_KIBO_TEXT_3 = "tugi_kibo_text_3";
	private final String TUGI_KIBO_NENSU_3 = "tugi_kibo_nensu_3";
	private final String SONOTUGI_KIBO_TEXT_3 = "sonotugi_kibo_text_3";
	private final String SONOTUGI_KIBO_NENSU_3 = "sonotugi_kibo_nensu_3";
	private final String SAISYU_KIBO_3 = "saisyu_kibo_3";
	private final String KIBO_RIYU_VISION_3 = "kibo_riyu_vision_3";
	private final String JITUGEN_KADAI = "jitugen_kadai";
/* 2006/06/28 yoshida add start */
	private final String ACTION_PLAN = "action_plan";
/* 2006/06/28 yoshida add end */
	private final String KIBO_KINMUTI_1 = "kibo_kinmuti_1";
	private final String KIBO_KINMUTI_2 = "kibo_kinmuti_2";
	private final String KIBO_KINMUTI_3 = "kibo_kinmuti_3";
	private final String KIBO_BUMON_1 = "kibo_bumon_1";
	private final String KIBO_BUMON_2 = "kibo_bumon_2";
	private final String KIBO_BUMON_3 = "kibo_bumon_3";
	private final String HUNIN_KEITAI_1 = "hunin_keitai_1";
	private final String HUNIN_KEITAI_2 = "hunin_keitai_2";
	private final String HUNIN_KEITAI_3 = "hunin_keitai_3";
	private final String HUNIN_KEITAI_VALUE_1 = "hunin_keitai_value_1";
	private final String HUNIN_KEITAI_VALUE_2 = "hunin_keitai_value_2";
	private final String HUNIN_KEITAI_VALUE_3 = "hunin_keitai_value_3";
	private final String GUTAITEKI_BUSYO_KAISYA = "gutaiteki_busyo_kaisya";
	private final String SINPEN_JIJYO_1 = "sinpen_jijyo_1";
	private final String SINPEN_JIJYO_2 = "sinpen_jijyo_2";
	private final String SINPEN_JIJYO_3 = "sinpen_jijyo_3";
	private final String SINPEN_JIJYO_4 = "sinpen_jijyo_4";
	private final String SINPEN_JIJYO_5 = "sinpen_jijyo_5";
	private final String SINPEN_JIJYO_6 = "sinpen_jijyo_6";
	private final String SINPEN_JIJYO_7 = "sinpen_jijyo_7";
	private final String SINPEN_JIJYO_8 = "sinpen_jijyo_8";
	private final String SINPEN_JIJYO_9 = "sinpen_jijyo_9";
	private final String SINPEN_JIJYO_10 = "sinpen_jijyo_10";
	private final String SINPEN_JIJYO_VALUE_1 = "sinpen_jijyo_value_1";
	private final String SINPEN_JIJYO_VALUE_2 = "sinpen_jijyo_value_2";
	private final String SINPEN_JIJYO_VALUE_3 = "sinpen_jijyo_value_3";
	private final String SINPEN_JIJYO_VALUE_4 = "sinpen_jijyo_value_4";
	private final String SINPEN_JIJYO_VALUE_5 = "sinpen_jijyo_value_5";
	private final String SINPEN_JIJYO_VALUE_6 = "sinpen_jijyo_value_6";
	private final String SINPEN_JIJYO_VALUE_7 = "sinpen_jijyo_value_7";
	private final String SINPEN_JIJYO_VALUE_8 = "sinpen_jijyo_value_8";
	private final String SINPEN_JIJYO_VALUE_9 = "sinpen_jijyo_value_9";
	private final String SINPEN_JIJYO_VALUE_10 = "sinpen_jijyo_value_10";
	private final String SINPEN_JIJYO_SONOTA = "sinpen_jijyo_sonota";
	private final String JYUTAKU_JYOKYO = "jyutaku_jyokyo";
	private final String JYUTAKU_JYOKYO_VALUE = "jyutaku_jyokyo_value";
	private final String JYUTAKU_JYOKYO_SONOTA = "jyutaku_jyokyo_sonota";
	private final String NYUKYO_NENSU = "nyukyo_nensu";
	private final String MENDAN_JISSI_NENGAPPI = "mendan_jissi_nengappi";
	private final String MENDANSYA_SIMEI_NO = "mendansya_simei_no";
	private final String MENDANSYA_SIMEI = "mendansha_simei";	
	private final String MENDANSYA_COMMENT = "mendansya_comment";
	private final String HONNIN_KOUSIN_NENGAPPI = "honnin_kousin_nengappi";
	private final String MENDANSYA_KOUSIN_NENGAPPI = "mendansya_kousin_nengappi";
	private final String KAISI_NENGAPPI = "kaisi_nengappi";
	
	private final String T71_CAREER_DESIGN_MASTER_1_TBL = "1";
	private final String T72_CAREER_DESIGN_MASTER_2_TBL = "2";
	private final String T73_CAREER_DESIGN_MASTER_3_TBL = "3";
	private final String T74_CAREER_DESIGN_MASTER_4_TBL = "4";
	private final String T75_CAREER_DESIGN_MASTER_5_TBL = "5";
	
	private CareerDesignBean careerDesignData;
	/** �f�t�H���g�R���X�g���N�^ */
	public CareerDesignLogicBean(  ){
	}
	
	/**
	 * �L�����A�f�U�C�����擾	 
	 * @param loginNo �Ј��A��
	 * @return CareerDesignBean ��ʕ\���pBean
	 * @throws NamingException
	 * @throws ClassCastException
	 * @throws Exception
	 */
	public CareerDesignBean getCareerDesignData( String  loginNo, String shimeiNo) throws NamingException, ClassCastException, Exception{
		try{
			Log.method(loginNo,"IN","");
			
			HashMap careerDesignMap = new HashMap(  );
			/* �Z�b�V�����r�[���ւ̃C���^�[�t�F�[�X���擾���� */
			Context initial = new InitialContext();
			
			String setValueString = new String(  );
			
			/* JNDI���̃��b�N�A�b�v */
			CareerDesignEJBHome my_home
			  = (CareerDesignEJBHome) PortableRemoteObject.narrow
				  ( initial.lookup ( HcdbDef.jndi + "CareerDesignEJB" ), CareerDesignEJBHome.class );
			     
			/* EJBObject�̎擾 */ 
			CareerDesignEJB userSession = my_home.create();
			
			/* �f�U�C���p�^�[�����擾 */
			Log.transaction( loginNo, true, "");
			careerDesignMap = userSession.getCareerDesignSheetData(loginNo, shimeiNo);
			Log.transaction( loginNo, false, "");
			
			/* �p�[�\�i�����擾 */
			Log.transaction( loginNo, true, "");
			careerDesignMap.putAll( userSession.getPersonalData(loginNo, shimeiNo) );
			Log.transaction( loginNo, false, "");
			
			/* �L�����A�f�U�C���N�x�擾 */
			Log.transaction( loginNo, true, "");
			setValueString = userSession.getCareerDesignNendo(loginNo);
			Log.transaction( loginNo, false, "");
			careerDesignMap.put( KAISI_NENGAPPI, setValueString );
			
			/* �\�́E���݂��ǂ̒��x��������Ă��邩 */
			Log.transaction( loginNo, true, "");
			setValueString = userSession.getCareerDesignMasterValue( loginNo,
											( String )careerDesignMap.get( NORYOKU_TUYOMI_HAKKI ),
											T71_CAREER_DESIGN_MASTER_1_TBL);
			Log.transaction( loginNo, false, "");
			careerDesignMap.put( NORYOKU_TUYOMI_HAKKI_VALUE, setValueString );
			
			/* �\�͂��\���ɔ����ł��Ȃ����R1�`7 */
			for(int i = 1 ; i <= 7 ; i++){
				Log.transaction( loginNo, true, "");
				setValueString = userSession.getCareerDesignMasterValue( loginNo,
												( String )careerDesignMap.get( "hakki_huka_riyu_" + i ),
												T72_CAREER_DESIGN_MASTER_2_TBL);
				Log.transaction( loginNo, false, "");
				careerDesignMap.put( "hakki_huka_riyu_value_" + i, setValueString );
			}
			/* �Ζ��n�ٓ��̏ꍇ�̕��C�`��1�`3 */
			for(int i = 1 ; i <= 3 ; i++){
				Log.transaction( loginNo, true, "");
				setValueString = userSession.getCareerDesignMasterValue( loginNo,
												( String )careerDesignMap.get( "hunin_keitai_" + i ),
												T73_CAREER_DESIGN_MASTER_3_TBL );
				Log.transaction( loginNo, false, "");
				careerDesignMap.put( "hunin_keitai_value_" + i, setValueString );
			}
			
			/* �g�ӏ�̎���1�`10 */
			for(int i = 1 ; i <= 10 ; i++){
				Log.transaction( loginNo, true, "");
				setValueString = userSession.getCareerDesignMasterValue( loginNo,
												( String )careerDesignMap.get( "sinpen_jijyo_" + i ),
												T74_CAREER_DESIGN_MASTER_4_TBL);
				Log.transaction( loginNo, false, "");
				careerDesignMap.put( "sinpen_jijyo_value_" + i, setValueString );
			}						
			
			/* ���݂̏Z��� */
			Log.transaction( loginNo, true, "");
			setValueString = userSession.getCareerDesignMasterValue( loginNo,
											( String )careerDesignMap.get( JYUTAKU_JYOKYO ),
											T75_CAREER_DESIGN_MASTER_5_TBL);
			Log.transaction( loginNo, false, "");
			careerDesignMap.put( JYUTAKU_JYOKYO_VALUE, setValueString );
				
			/* �ҏW�{�^���\���s�t���O�擾 */
			Log.transaction( loginNo, true, "");
			boolean henshuFlg = userSession.getHenshuFlg( loginNo );
			Log.transaction( loginNo, false, "");
			
// ADD 2013/05/09 COMTURE VAL010_�L�����A�f�U�C���iVar.02-00�jSTART
			/* �l�������ێ��� */
			Log.transaction( loginNo, true, "");
			boolean jinjiKengenFlg = userSession.getJinjiKengenFlg( loginNo );
			Log.transaction( loginNo, false, "");
			careerDesignMap.put( "jinjiKengen_flg", jinjiKengenFlg );
// ADD 2013/05/09 COMTURE VAL010_�L�����A�f�U�C���iVar.02-00�jEND
			
			/* SQL����擾�������e��S��Bean�ɋl�߂� */ 
			careerDesignData = getCareerDesignBean( loginNo, careerDesignMap, henshuFlg );
			
			/* �S���Ɩ��ꗗ���擾 */
			Log.transaction( loginNo, true, "");
			careerDesignData.setTantoGyomuList( userSession.getTantoGyomuData( loginNo, shimeiNo ) );
			Log.transaction( loginNo, false, "");
			/* ���i�E���C���ꗗ���擾 */
			Log.transaction( loginNo, true, "");
			careerDesignData.setShikakuKensyuRekiList( userSession.getShikakuData( loginNo, shimeiNo ) );
			Log.transaction( loginNo, false, "");
			/* �Г����C���ꗗ���擾 */
			Log.transaction( loginNo, true, "");
			careerDesignData.setShanaiKensyuRekiList( userSession.getShanaiKensyuRekiData( loginNo, shimeiNo ) );
			Log.transaction( loginNo, false, "");
			/* �}�X�^�[�l�̎擾 �}�X�^�[�P*/
			Log.transaction( loginNo, true, "");
			careerDesignData.setCareerDesignMaster1List( userSession.getCareerDesingMasterItem( loginNo ,T71_CAREER_DESIGN_MASTER_1_TBL) );
			Log.transaction( loginNo, false, "");
			/* �}�X�^�[�l�̎擾 �}�X�^�[�Q*/
			Log.transaction( loginNo, true, "");
			careerDesignData.setCareerDesignMaster2List( userSession.getCareerDesingMasterItem( loginNo ,T72_CAREER_DESIGN_MASTER_2_TBL) );
			Log.transaction( loginNo, false, "");
			/* �}�X�^�[�l�̎擾 �}�X�^�[�R*/
			Log.transaction( loginNo, true, "");
			careerDesignData.setCareerDesignMaster3List( userSession.getCareerDesingMasterItem( loginNo ,T73_CAREER_DESIGN_MASTER_3_TBL) );
			Log.transaction( loginNo, false, "");
			/* �}�X�^�[�l�̎擾 �}�X�^�[�S*/
			Log.transaction( loginNo, true, "");
			careerDesignData.setCareerDesignMaster4List( userSession.getCareerDesingMasterItem( loginNo ,T74_CAREER_DESIGN_MASTER_4_TBL) );
			Log.transaction( loginNo, false, "");
			/* �}�X�^�[�l�̎擾 �}�X�^�[�T*/
			Log.transaction( loginNo, true, "");
			careerDesignData.setCareerDesignMaster5List( userSession.getCareerDesingMasterItem( loginNo ,T75_CAREER_DESIGN_MASTER_5_TBL) );
			Log.transaction( loginNo, false, "");
// ADD 2013/05/07 COMTURE VAL010_�L�����A�f�U�C���iVar.02-00�jSTART
			/* �������ꗗ���擾 */
			Log.transaction( loginNo, true, "");
			careerDesignData.setShozokuRekiList( userSession.getShozokuRekiData( loginNo, shimeiNo ) );
			Log.transaction( loginNo, false, "");
			/* �S�����C���N���C�A���g�ꗗ���擾 */
			Log.transaction( loginNo, true, "");
			careerDesignData.setTantoMainClientList( userSession.getTantoMainClientData( loginNo, shimeiNo ) );
			Log.transaction( loginNo, false, "");
			/* �o���Ɩ��̈�ꗗ���擾 */
			Log.transaction( loginNo, true, "");
			careerDesignData.setKeikenGyomuRyoikiList( userSession.getKeikenGyomuRyoikiData( loginNo, shimeiNo ) );
			Log.transaction( loginNo, false, "");
			/* �l���R�����g�ꗗ���擾 */
			Log.transaction( loginNo, true, "");
			careerDesignData.setJinjiCommentList( userSession.getJinjiCommentData( loginNo, shimeiNo ) );
			Log.transaction( loginNo, false, "");
			/* �}�X�^�[�l�̎擾 �}�X�^�[�U[�Ǝ�] */
			Log.transaction( loginNo, true, "");
			careerDesignData.setCareerDesignMaster6List( userSession.getCareerDesingMasterItem2( loginNo ,HcdbDef.T82_CAREER_DESIGN_MASTER_6_TBL) );
			Log.transaction( loginNo, false, "");
			/* �}�X�^�[�l�̎擾 �}�X�^�[�V[�����K��] */
			Log.transaction( loginNo, true, "");
			careerDesignData.setCareerDesignMaster7List( userSession.getCareerDesingMasterItem2( loginNo ,HcdbDef.T83_CAREER_DESIGN_MASTER_7_TBL) );
			Log.transaction( loginNo, false, "");
			/* �}�X�^�[�l�̎擾 �}�X�^�[�W[�`�[��] */
			Log.transaction( loginNo, true, "");
			careerDesignData.setCareerDesignMaster8List( userSession.getCareerDesingMasterItem2( loginNo ,HcdbDef.T84_CAREER_DESIGN_MASTER_8_TBL) );
			Log.transaction( loginNo, false, "");
			/* �}�X�^�[�l�̎擾 �}�X�^�[�X[����] */
			Log.transaction( loginNo, true, "");
			careerDesignData.setCareerDesignMaster9List( userSession.getCareerDesingMasterItem2( loginNo ,HcdbDef.T85_CAREER_DESIGN_MASTER_9_TBL) );
			Log.transaction( loginNo, false, "");
			/* �}�X�^�[�l�̎擾 �}�X�^�[10[�o���Ɩ��̈�i�]���j] */
			Log.transaction( loginNo, true, "");
			careerDesignData.setCareerDesignMaster10List( userSession.getCareerDesingMasterItem2( loginNo ,HcdbDef.T86_CAREER_DESIGN_MASTER_10_TBL) );
			Log.transaction( loginNo, false, "");
			/* �}�X�^�[�l�̎擾 �}�X�^�[11[�o���Ɩ��̈�i�Ɩ��̈�j] */
			Log.transaction( loginNo, true, "");
			careerDesignData.setCareerDesignMaster11List( userSession.getCareerDesingMasterItem2( loginNo ,HcdbDef.T87_CAREER_DESIGN_MASTER_11_TBL) );
			Log.transaction( loginNo, false, "");
			/* �}�X�^�[�l�̎擾 �}�X�^�[12[�r�W�l�X���] */
			Log.transaction( loginNo, true, "");
			careerDesignData.setCareerDesignMaster12List( userSession.getCareerDesingMasterItem2( loginNo ,HcdbDef.T88_CAREER_DESIGN_MASTER_12_TBL) );
			Log.transaction( loginNo, false, "");
// ADD 2013/05/07 COMTURE VAL010_�L�����A�f�U�C���iVar.02-00�jEND

			Log.method(loginNo,"OUT","");
			return careerDesignData;
		} catch (NamingException ne) {
			Log.error( loginNo, "HJE-0002", ne );
			throw ne;
		} catch (ClassCastException cce) {
			Log.error( loginNo, "HJE-0003", cce );
			throw cce;
		} catch (Exception e) {
			Log.error(loginNo, "HJE-0017", e);
			throw e;
		}
	}

	/**
	 * �L�����A�f�U�C���ꗗ���擾	 
	 * @param loginNo ���O�C���Ј��ԍ�
	 * @param kengenCode �����R�[�h
	 * @return CareerDesignBean ��ʕ\���pBean
	 * @throws NamingException
	 * @throws ClassCastException
	 * @throws Exception
	 */
	public CareerDesignBean getCareerDesignListData( String loginNo, String shimeiNo, String kengenCode, String sosikiCode ) throws NamingException, ClassCastException, Exception{  // CHG#P-A30AI3-006-004
		try{
			Log.method(loginNo,"IN","");
			CareerDesignBean cdBean = new CareerDesignBean(  );
			/* �Z�b�V�����r�[���ւ̃C���^�[�t�F�[�X���擾���� */
			Context initial = new InitialContext();
			
			String setValueString = new String(  );
			
			/* JNDI���̃��b�N�A�b�v */
			CareerDesignEJBHome my_home
			  = (CareerDesignEJBHome) PortableRemoteObject.narrow
				  ( initial.lookup ( HcdbDef.jndi + "CareerDesignEJB" ), CareerDesignEJBHome.class );
			     
			/* EJBObject�̎擾 */ 
			CareerDesignEJB userSession = my_home.create();
			
			ArrayList careerDesignListData = userSession.getCareerDesignDataList(loginNo, shimeiNo, kengenCode, sosikiCode );  // CHG#P-A30AI3-006-004
			cdBean.setCareerDesignDataList( careerDesignListData );
			return cdBean;
		} catch (NamingException ne) {
			Log.error( loginNo, "HJE-0002", ne );
			throw ne;
		} catch (ClassCastException cce) {
			Log.error( loginNo, "HJE-0003", cce );
			throw cce;
		} catch (Exception e) {
			Log.error(loginNo, "HJE-0017", e);
			throw e;
		}
	}

	/**
	 * SQL���ʂ�Bean�ɂ߂ĕԂ�
	 * 
	 * @param loginNo ���O�C���ԍ�
	 * @param careerDesignMap SQL���ʂ̋l�܂���MAP
	 * @param hensyuFlg �ҏW�̉ۃt���O
	 * @return CareerDesignBean 
	 */
	public CareerDesignBean getCareerDesignBean( String loginNo,HashMap cdMap ,boolean hensyuFlg){
		Log.method(loginNo,"IN","");
		CareerDesignBean cdDat = new CareerDesignBean();
		cdDat.setHonninKousinNengappi( ( String )cdMap.get( HONNIN_KOUSIN_NENGAPPI ) );
		cdDat.setMendansaKousinNengappi( ( String )cdMap.get( MENDANSYA_KOUSIN_NENGAPPI ) );
		cdDat.setShimei( ( String )cdMap.get( KANJI_SIMEI ) );
		cdDat.setSimeiNo( ( String )cdMap.get( SIMEI_NO ) );
		cdDat.setNenrei( ( String )cdMap.get( NENREI ) );
		cdDat.setNushaNengetsu( ( String )cdMap.get( NYUSYA_NENGETSU ) );
		cdDat.setSozoku( ( String )cdMap.get( BUSYO_RYAKUSYO_MEI )  );
		cdDat.setKinmuchi( ( String )cdMap.get( KINMUCHI )  );
		cdDat.setZaisekiKikanNen( ( String )cdMap.get( ZAISEKI_KIKAN_NEN ) );
		cdDat.setZaisekiKikanTsuki( ( String )cdMap.get(  ZAISEKI_KIKAN_TUKI) );
		cdDat.setTokuhituCareerReki( ( String )cdMap.get( TOKUHITU_CAREER_REKI ) );
		cdDat.setSenmonsei( ( String )cdMap.get( SENMONSEI ) );
		cdDat.setSozosei( ( String )cdMap.get( SOZOSEI ) );
		cdDat.setTaijinRoroku( ( String )cdMap.get( TAIJIN_NORYOKU ) );
		cdDat.setSosikiManagement( ( String )cdMap.get( SOSIKI_MANAGEMENT ) );
		cdDat.setPcSkill( ( String )cdMap.get( PC_SKILL ) );
		cdDat.setSonotaCareer( ( String )cdMap.get( SONOTA_CAREER ) );
		cdDat.setNorokuTuomiHakki( ( String )cdMap.get( NORYOKU_TUYOMI_HAKKI ) );
		cdDat.setNorokuTuomiHakkiValue( ( String )cdMap.get( NORYOKU_TUYOMI_HAKKI_VALUE ) );
		cdDat.setHakkiHukaRiu1( ( String )cdMap.get( HAKKI_HUKA_RIYU_1 ) );
		cdDat.setHakkiHukaRiu2( ( String )cdMap.get( HAKKI_HUKA_RIYU_2 ) );
		cdDat.setHakkiHukaRiu3( ( String )cdMap.get( HAKKI_HUKA_RIYU_3 ) );
		cdDat.setHakkiHukaRiu4( ( String )cdMap.get( HAKKI_HUKA_RIYU_4 ) );
		cdDat.setHakkiHukaRiu5( ( String )cdMap.get( HAKKI_HUKA_RIYU_5 ) );
		cdDat.setHakkiHukaRiu6( ( String )cdMap.get( HAKKI_HUKA_RIYU_6 ) );
		cdDat.setHakkiHukaRiu7( ( String )cdMap.get( HAKKI_HUKA_RIYU_7 ) );
		cdDat.setHakkiHukaRiuValue1( ( String )cdMap.get( HAKKI_HUKA_RIYU_VALUE_1 ) );
		cdDat.setHakkiHukaRiuValue2( ( String )cdMap.get( HAKKI_HUKA_RIYU_VALUE_2 ) );
		cdDat.setHakkiHukaRiuValue3( ( String )cdMap.get( HAKKI_HUKA_RIYU_VALUE_3 ) );
		cdDat.setHakkiHukaRiuValue4( ( String )cdMap.get( HAKKI_HUKA_RIYU_VALUE_4 ) );
		cdDat.setHakkiHukaRiuValue5( ( String )cdMap.get( HAKKI_HUKA_RIYU_VALUE_5 ) );
		cdDat.setHakkiHukaRiuValue6( ( String )cdMap.get( HAKKI_HUKA_RIYU_VALUE_6 ) );
		cdDat.setHakkiHukaRiuValue7( ( String )cdMap.get( HAKKI_HUKA_RIYU_VALUE_7 ) );
		cdDat.setHakkiHukaRiusonota(( String )cdMap.get( HAKKI_HUKA_RIYU_SONOTA ) );
		cdDat.setGenSozokuTanto1( ( String )cdMap.get( GEN_SYOZOKU_TANTO_1 ) );
		cdDat.setGenSozokuTanto2( ( String )cdMap.get( GEN_SYOZOKU_TANTO_2 ) );
		cdDat.setGenSozokuTanto3( ( String )cdMap.get( GEN_SYOZOKU_TANTO_3 ) );
		cdDat.setTugiKiboText1( ( String )cdMap.get( TUGI_KIBO_TEXT_1 ) );
		cdDat.setTugiKiboText2( ( String )cdMap.get( TUGI_KIBO_TEXT_2 ) );
		cdDat.setTugiKiboText3( ( String )cdMap.get( TUGI_KIBO_TEXT_3 ) );
		cdDat.setTugiKiboNensu1( ( String )cdMap.get( TUGI_KIBO_NENSU_1 ) );
		cdDat.setTugiKiboNensu2( ( String )cdMap.get( TUGI_KIBO_NENSU_2 ) );
		cdDat.setTugiKiboNensu3( ( String )cdMap.get( TUGI_KIBO_NENSU_3 ) );
		cdDat.setSonotugiKiboText1( ( String )cdMap.get( SONOTUGI_KIBO_TEXT_1 ) );
		cdDat.setSonotugiKiboText2( ( String )cdMap.get( SONOTUGI_KIBO_TEXT_2 ) );
		cdDat.setSonotugiKiboText3( ( String )cdMap.get( SONOTUGI_KIBO_TEXT_3 ) );
		cdDat.setSonotugiKiboNensu1( ( String )cdMap.get( SONOTUGI_KIBO_NENSU_1 ) );
		cdDat.setSonotugiKiboNensu2( ( String )cdMap.get( SONOTUGI_KIBO_NENSU_2 ) );
		cdDat.setSonotugiKiboNensu3( ( String )cdMap.get( SONOTUGI_KIBO_NENSU_3 ) );
		cdDat.setSaisuKibo1( ( String )cdMap.get( SAISYU_KIBO_1 ) );
		cdDat.setSaisuKibo2( ( String )cdMap.get( SAISYU_KIBO_2 ) );
		cdDat.setSaisuKibo3( ( String )cdMap.get( SAISYU_KIBO_3 ) );
		cdDat.setKiboRiuVision1( ( String )cdMap.get( KIBO_RIYU_VISION_1 ) );
		cdDat.setKiboRiuVision2( ( String )cdMap.get( KIBO_RIYU_VISION_2 ) );
		cdDat.setKiboRiuVision3( ( String )cdMap.get( KIBO_RIYU_VISION_3 ) );
		cdDat.setJitugenKadai( ( String )cdMap.get( JITUGEN_KADAI) );
/* 2006/06/28 yoshida add start */
		cdDat.setActionPlan( ( String )cdMap.get( ACTION_PLAN ) );
/* 2006/06/28 yoshida add end */
		cdDat.setKiboKinmuti1( ( String )cdMap.get( KIBO_KINMUTI_1 ) );
		cdDat.setKiboKinmuti2( ( String )cdMap.get( KIBO_KINMUTI_2 ) );
		cdDat.setKiboKinmuti3( ( String )cdMap.get( KIBO_KINMUTI_3 ) );
		cdDat.setKiboBumon1( ( String )cdMap.get( KIBO_BUMON_1 ) );
		cdDat.setKiboBumon2( ( String )cdMap.get( KIBO_BUMON_2 ) );
		cdDat.setKiboBumon3( ( String )cdMap.get( KIBO_BUMON_3 ) );
		cdDat.setHuninKeitai1( ( String )cdMap.get( HUNIN_KEITAI_1 ) );
		cdDat.setHuninKeitai2( ( String )cdMap.get( HUNIN_KEITAI_2 ) );
		cdDat.setHuninKeitai3( ( String )cdMap.get( HUNIN_KEITAI_3 ) );
		cdDat.setHuninKeitaiValue1( ( String )cdMap.get( HUNIN_KEITAI_VALUE_1 ) );
		cdDat.setHuninKeitaiValue2( ( String )cdMap.get( HUNIN_KEITAI_VALUE_2 ) );
		cdDat.setHuninKeitaiValue3( ( String )cdMap.get( HUNIN_KEITAI_VALUE_3 ) );
		cdDat.setGutaitekiBusoKaisa( ( String )cdMap.get( GUTAITEKI_BUSYO_KAISYA ) );
		cdDat.setSinpenJijo1( ( String )cdMap.get( SINPEN_JIJYO_1 ) );
		cdDat.setSinpenJijo2( ( String )cdMap.get( SINPEN_JIJYO_2 ) );
		cdDat.setSinpenJijo3( ( String )cdMap.get( SINPEN_JIJYO_3 ) );
		cdDat.setSinpenJijo4( ( String )cdMap.get( SINPEN_JIJYO_4 ) );
		cdDat.setSinpenJijo5( ( String )cdMap.get( SINPEN_JIJYO_5 ) );
		cdDat.setSinpenJijo6( ( String )cdMap.get( SINPEN_JIJYO_6 ) );
		cdDat.setSinpenJijo7( ( String )cdMap.get( SINPEN_JIJYO_7 ) );
		cdDat.setSinpenJijo8( ( String )cdMap.get( SINPEN_JIJYO_8) );
		cdDat.setSinpenJijo9( ( String )cdMap.get( SINPEN_JIJYO_9) );
		cdDat.setSinpenJijo10( ( String )cdMap.get( SINPEN_JIJYO_10) );
		cdDat.setSinpenJijoValue1( ( String )cdMap.get( SINPEN_JIJYO_VALUE_1 ) );
		cdDat.setSinpenJijoValue2( ( String )cdMap.get( SINPEN_JIJYO_VALUE_2 ) );
		cdDat.setSinpenJijoValue3( ( String )cdMap.get( SINPEN_JIJYO_VALUE_3 ) );
		cdDat.setSinpenJijoValue4( ( String )cdMap.get( SINPEN_JIJYO_VALUE_4 ) );
		cdDat.setSinpenJijoValue5( ( String )cdMap.get( SINPEN_JIJYO_VALUE_5 ) );
		cdDat.setSinpenJijoValue6( ( String )cdMap.get( SINPEN_JIJYO_VALUE_6 ) );
		cdDat.setSinpenJijoValue7( ( String )cdMap.get( SINPEN_JIJYO_VALUE_7 ) );
		cdDat.setSinpenJijoValue8( ( String )cdMap.get( SINPEN_JIJYO_VALUE_8) );
		cdDat.setSinpenJijoValue9( ( String )cdMap.get( SINPEN_JIJYO_VALUE_9) );
		cdDat.setSinpenJijoValue10( ( String )cdMap.get( SINPEN_JIJYO_VALUE_10) );
		cdDat.setSinpenJijosonota( ( String )cdMap.get( SINPEN_JIJYO_SONOTA) );
		cdDat.setJutakuJoko( ( String )cdMap.get( JYUTAKU_JYOKYO ) );
		cdDat.setJutakuJokoValue( ( String )cdMap.get( JYUTAKU_JYOKYO_VALUE ) );
		cdDat.setJutakuJokosonota( ( String )cdMap.get( JYUTAKU_JYOKYO_SONOTA ) );
		cdDat.setNukoNensu( ( String )cdMap.get( NYUKYO_NENSU ) );
		cdDat.setMendanJissiNengappi( ( String )cdMap.get( MENDAN_JISSI_NENGAPPI ) );
		cdDat.setMendansaSimei(  ( String )cdMap.get( MENDANSYA_SIMEI )  );
		cdDat.setMendansaComment( ( String )cdMap.get( MENDANSYA_COMMENT ) );
		cdDat.setNendo( ( String )cdMap.get( KAISI_NENGAPPI ) );
// ADD 2013/05/09 COMTURE VAL010_�L�����A�f�U�C���iVar.02-00�jSTART
		cdDat.setJinjiKengenFlg( (Boolean)cdMap.get( "jinjiKengen_flg" ));
// ADD 2013/05/09 COMTURE VAL010_�L�����A�f�U�C���iVar.02-00�jEND
		cdDat.setHensyuFlg( hensyuFlg );
		Log.method(loginNo,"OUT","");
		return cdDat;
	}
	
	/**
	 * �L�����A�f�U�C���}�b�v�̃A�b�v�f�[�g�������s���B
	 * 
	 * @param loginNo ���O�C���Ј��ԍ�
	 * @param cdDat CareerDesignBean���
	 * @throws NamingException
	 * @throws ClassCastException
	 * @throws Exception
	 */
	public void updateCareerDesignBeanData(String loginNo,CareerDesignBean cdDat) throws NamingException, ClassCastException, Exception{
		try{
			Log.method(loginNo,"IN","");
			/* �Z�b�V�����r�[���ւ̃C���^�[�t�F�[�X���擾���� */
			Context initial = new InitialContext();
				
			String setValueString = new String(  );
				
			/* JNDI���̃��b�N�A�b�v */
			CareerDesignEJBHome my_home
			  = (CareerDesignEJBHome) PortableRemoteObject.narrow
				  ( initial.lookup ( HcdbDef.jndi + "CareerDesignEJB" ), CareerDesignEJBHome.class );
				     
			/* EJBObject�̎擾 */ 
			CareerDesignEJB userSession = my_home.create();
			HashMap updateColumnMap = new HashMap(  );
			/* Bean����HashMap�ɋl�߂� */
			updateColumnMap = getCareerDesignBean(loginNo,cdDat);
			/* �X�V�������s�� */
			Log.transaction( loginNo, true, "");
			userSession.updateCareerDesignData( loginNo, loginNo, updateColumnMap);
			Log.transaction( loginNo, false, "");
// ADD 2013/05/14 COMTURE VAL023_�L�����A�f�U�C���ҏW�i���͓��e�m�F�j�iVar.02-00�jSTART
			/* �S�����C���N���C�A���g�X�V�������s�� */
			Log.transaction( loginNo, true, "");
			userSession.updateTantoMeinClientData( loginNo, loginNo, cdDat.getTantoMainClientList());
			Log.transaction( loginNo, false, "");
			/* �o���Ɩ��̈�X�V�������s�� */
			Log.transaction( loginNo, true, "");
			userSession.updateKeikenGyomuRyoikiData( loginNo, loginNo, cdDat.getKeikenGyomuRyoikiList());
			Log.transaction( loginNo, false, "");
// ADD 2013/05/14 COMTURE VAL023_�L�����A�f�U�C���ҏW�i���͓��e�m�F�j�iVar.02-00�jEND
			
			Log.method(loginNo,"OUT","");
		} catch (NamingException ne) {
			Log.error( loginNo, "HJE-0002", ne );
			throw ne;
		} catch (ClassCastException cce) {
			Log.error( loginNo, "HJE-0003", cce );
			throw cce;
		} catch (Exception e) {
			Log.error(loginNo, "HJE-0017", e);
			throw e;
		}
	}
	
	/**
	 * �L�����A�f�U�C�� �ʒk�p�f�[�^�̃A�b�v�f�[�g�������s���B
	 * 
	 * @param loginNo ���O�C���Ј��ԍ�
	 * @param mendanDataMap �ʒk���
	 * @throws NamingException
	 * @throws ClassCastException
	 * @throws Exception
	 */
	public void updateCareerDesignMendanData(String loginNo, String shimeiNo, HashMap mendanDataMap) throws NamingException, ClassCastException, Exception{
		try{
			Log.method(loginNo,"IN","");
			/* �Z�b�V�����r�[���ւ̃C���^�[�t�F�[�X���擾���� */
			Context initial = new InitialContext();
				
			String setValueString = new String(  );
				
			/* JNDI���̃��b�N�A�b�v */
			CareerDesignEJBHome my_home
			  = (CareerDesignEJBHome) PortableRemoteObject.narrow
				  ( initial.lookup ( HcdbDef.jndi + "CareerDesignEJB" ), CareerDesignEJBHome.class );
				     
			/* EJBObject�̎擾 */ 
			CareerDesignEJB userSession = my_home.create();
			HashMap updateColumnMap = new HashMap(  );
			/* �X�V�������s�� */
			Log.transaction( loginNo, true, "");
			userSession.updateCareerDesignMendanData( loginNo, shimeiNo, mendanDataMap);
			Log.transaction( loginNo, false, "");
			
			Log.method(loginNo,"OUT","");
		} catch (NamingException ne) {
			Log.error( loginNo, "HJE-0002", ne );
			throw ne;
		} catch (ClassCastException cce) {
			Log.error( loginNo, "HJE-0003", cce );
			throw cce;
		} catch (Exception e) {
			Log.error(loginNo, "HJE-0017", e);
			throw e;
		}
	}
	
// ADD 2013/05/10 COMTURE VAL060_�L�����A�f�U�C���ҏW�i�l���R�����g���́j�iVar.02-00�jSTART 
	/**
	 * �L�����A�f�U�C�� �l���p�f�[�^�̃A�b�v�f�[�g�������s���B
	 * 
	 * @param loginNo ���O�C���Ј��ԍ�
	 * @param jinjiDataMap �l�����
	 * @throws NamingException
	 * @throws ClassCastException
	 * @throws Exception
	 */
	public void updateCareerDesignJinjiData(String loginNo, String shimeiNo, HashMap jinjiDataMap) throws NamingException, ClassCastException, Exception{
		try{
			Log.method(loginNo,"IN","");
			/* �Z�b�V�����r�[���ւ̃C���^�[�t�F�[�X���擾���� */
			Context initial = new InitialContext();
				
			String setValueString = new String(  );
				
			/* JNDI���̃��b�N�A�b�v */
			CareerDesignEJBHome my_home
			  = (CareerDesignEJBHome) PortableRemoteObject.narrow
				  ( initial.lookup ( HcdbDef.jndi + "CareerDesignEJB" ), CareerDesignEJBHome.class );
				     
			/* EJBObject�̎擾 */ 
			CareerDesignEJB userSession = my_home.create();
			/* �X�V�������s�� */
			Log.transaction( loginNo, true, "");
			userSession.updateCareerDesignJinjiData( loginNo, shimeiNo, jinjiDataMap);
			Log.transaction( loginNo, false, "");
			Log.method(loginNo,"OUT","");
		} catch (NamingException ne) {
			Log.error( loginNo, "HJE-0002", ne );
			throw ne;
		} catch (ClassCastException cce) {
			Log.error( loginNo, "HJE-0003", cce );
			throw cce;
		} catch (Exception e) {
			Log.error(loginNo, "HJE-0017", e);
			throw e;
		}
	}
// ADD 2013/05/10 COMTURE VAL060_�L�����A�f�U�C���ҏW�i�l���R�����g���́j�iVar.02-00�jEND 
	
	/**
	 * Bean�ɋl�܂��Ă������Map�ɋl�߂ĕԂ�
	 * 
	 * @param loginNo ���O�C���Ј��ԍ�
	 * @param cdDat CareerDesignBean���
	 * @return Bean��񂪋l�܂���HashMap
	 */
	public HashMap getCareerDesignBean( String loginNo,CareerDesignBean cdDat ){
		Log.method(loginNo,"IN","");
		HashMap updateColumnMap = new HashMap(  );
		updateColumnMap.put( SIMEI_NO, loginNo);
		updateColumnMap.put( ZAISEKI_KIKAN_NEN, cdDat.getZaisekiKikanNen(  ) );
		updateColumnMap.put( ZAISEKI_KIKAN_TUKI, cdDat.getZaisekiKikanTsuki(  ) );
		updateColumnMap.put( TOKUHITU_CAREER_REKI, cdDat.getTokuhituCareerReki(  ) );
		updateColumnMap.put( SENMONSEI, cdDat.getSenmonsei(  ) );
		updateColumnMap.put( SOZOSEI, cdDat.getSozosei(  ) );
		updateColumnMap.put( TAIJIN_NORYOKU, cdDat.getTaijinRoroku(  ) );
		updateColumnMap.put( SOSIKI_MANAGEMENT, cdDat.getSosikiManagement( ) );
		updateColumnMap.put( PC_SKILL, cdDat.getPcSkill(  ) );
		updateColumnMap.put( SONOTA_CAREER, cdDat.getSonotaCareer(  ) );
		updateColumnMap.put( NORYOKU_TUYOMI_HAKKI, cdDat.getNorokuTuomiHakki(  ) ); 
		updateColumnMap.put( HAKKI_HUKA_RIYU_1, cdDat.getHakkiHukaRiu1(  ) );
		updateColumnMap.put( HAKKI_HUKA_RIYU_2, cdDat.getHakkiHukaRiu2(  ) );
		updateColumnMap.put( HAKKI_HUKA_RIYU_3, cdDat.getHakkiHukaRiu3(  ) );
		updateColumnMap.put( HAKKI_HUKA_RIYU_4, cdDat.getHakkiHukaRiu4(  ) );
		updateColumnMap.put( HAKKI_HUKA_RIYU_5, cdDat.getHakkiHukaRiu5(  ) );
		updateColumnMap.put( HAKKI_HUKA_RIYU_6, cdDat.getHakkiHukaRiu6(  ) );
		updateColumnMap.put( HAKKI_HUKA_RIYU_7, cdDat.getHakkiHukaRiu7(  ) );
		updateColumnMap.put( HAKKI_HUKA_RIYU_SONOTA, cdDat.getHakkiHukaRiusonota(  ) );
		updateColumnMap.put( GEN_SYOZOKU_TANTO_1, cdDat.getGenSozokuTanto1(  ) ); 
		updateColumnMap.put( TUGI_KIBO_TEXT_1, cdDat.getTugiKiboText1(  ) );
		updateColumnMap.put( TUGI_KIBO_NENSU_1, cdDat.getTugiKiboNensu1(  ) );
		updateColumnMap.put( SONOTUGI_KIBO_TEXT_1, cdDat.getSonotugiKiboText1(  ) );
		updateColumnMap.put( SONOTUGI_KIBO_NENSU_1, cdDat.getSonotugiKiboNensu1(  ) );
		updateColumnMap.put( SAISYU_KIBO_1, cdDat.getSaisuKibo1(  ) );
		updateColumnMap.put( KIBO_RIYU_VISION_1, cdDat.getKiboRiuVision1(  ) );
		updateColumnMap.put( GEN_SYOZOKU_TANTO_2, cdDat.getGenSozokuTanto2(  ) );
		updateColumnMap.put( TUGI_KIBO_TEXT_2, cdDat.getTugiKiboText2(  ) );
		updateColumnMap.put( TUGI_KIBO_NENSU_2, cdDat.getTugiKiboNensu2(  ) );
		updateColumnMap.put( SONOTUGI_KIBO_TEXT_2, cdDat.getSonotugiKiboText2(  ) );
		updateColumnMap.put( SONOTUGI_KIBO_NENSU_2, cdDat.getSonotugiKiboNensu2(  ) );
		updateColumnMap.put( SAISYU_KIBO_2, cdDat.getSaisuKibo2(  ) );
		updateColumnMap.put( KIBO_RIYU_VISION_2, cdDat.getKiboRiuVision2(  ) );
		updateColumnMap.put( GEN_SYOZOKU_TANTO_3, cdDat.getGenSozokuTanto3(  ) );
		updateColumnMap.put( TUGI_KIBO_TEXT_3, cdDat.getTugiKiboText3(  ) );
		updateColumnMap.put( TUGI_KIBO_NENSU_3, cdDat.getTugiKiboNensu3(  ) );
		updateColumnMap.put( SONOTUGI_KIBO_TEXT_3, cdDat.getSonotugiKiboText3(  ) );
		updateColumnMap.put( SONOTUGI_KIBO_NENSU_3, cdDat.getSonotugiKiboNensu3(  ) );
		updateColumnMap.put( SAISYU_KIBO_3, cdDat.getSaisuKibo3(  ) );
		updateColumnMap.put( KIBO_RIYU_VISION_3, cdDat.getKiboRiuVision3(  ) );
		updateColumnMap.put( JITUGEN_KADAI, cdDat.getJitugenKadai(  ) );
/* 2006/06/28 yoshida add start */
		updateColumnMap.put( ACTION_PLAN, cdDat.getActionPlan(  ) );
/* 2006/06/28 yoshida add end */
		updateColumnMap.put( KIBO_KINMUTI_1, cdDat.getKiboKinmuti1(  ) );
		updateColumnMap.put( KIBO_BUMON_1, cdDat.getKiboBumon1(  ) );
		updateColumnMap.put( HUNIN_KEITAI_1, cdDat.getHuninKeitai1(  ) );
		updateColumnMap.put( KIBO_KINMUTI_2, cdDat.getKiboKinmuti2(  ) );
		updateColumnMap.put( KIBO_BUMON_2, cdDat.getKiboBumon2(  ) );
		updateColumnMap.put( HUNIN_KEITAI_2, cdDat.getHuninKeitai2(  ) );
		updateColumnMap.put( KIBO_KINMUTI_3, cdDat.getKiboKinmuti3(  ) );
		updateColumnMap.put( KIBO_BUMON_3, cdDat.getKiboBumon3(  ) );
		updateColumnMap.put( HUNIN_KEITAI_3, cdDat.getHuninKeitai3(  ) );
		updateColumnMap.put( GUTAITEKI_BUSYO_KAISYA, cdDat.getGutaitekiBusoKaisa(  ) );
		updateColumnMap.put( SINPEN_JIJYO_1, cdDat.getSinpenJijo1(  ) );
		updateColumnMap.put( SINPEN_JIJYO_2, cdDat.getSinpenJijo2(  ) );
		updateColumnMap.put( SINPEN_JIJYO_3, cdDat.getSinpenJijo3(  ) );
		updateColumnMap.put( SINPEN_JIJYO_4, cdDat.getSinpenJijo4(  ) );
		updateColumnMap.put( SINPEN_JIJYO_5, cdDat.getSinpenJijo5(  ) );
		updateColumnMap.put( SINPEN_JIJYO_6, cdDat.getSinpenJijo6(  ) );
		updateColumnMap.put( SINPEN_JIJYO_7, cdDat.getSinpenJijo7(  ) );
		updateColumnMap.put( SINPEN_JIJYO_8, cdDat.getSinpenJijo8(  ) );
		updateColumnMap.put( SINPEN_JIJYO_9, cdDat.getSinpenJijo9(  ) );
		updateColumnMap.put( SINPEN_JIJYO_10, cdDat.getSinpenJijo10(  ) );
		updateColumnMap.put( SINPEN_JIJYO_SONOTA, cdDat.getSinpenJijosonota(  ) );
		updateColumnMap.put( JYUTAKU_JYOKYO, cdDat.getJutakuJoko(  ) );
		updateColumnMap.put( JYUTAKU_JYOKYO_SONOTA, cdDat.getJutakuJokosonota(  ) );
		updateColumnMap.put( NYUKYO_NENSU, cdDat.getNukoNensu(  ) );
		Log.method(loginNo,"OUT","");
		return updateColumnMap;
	}
	
	/**
	 * ���O�C���Ј��̊����������擾����B
	 * @param loginNo
	 * @return ��������
	 * @throws NamingException
	 * @throws ClassCastException
	 * @throws Exception
	 */
	public String getkanjiShimei( String loginNo ) throws NamingException, ClassCastException, Exception{
		try{
			Log.method(loginNo,"IN","");
			String kanziShimei = new String(  );
			
			Log.method(loginNo,"IN","");
			/* �Z�b�V�����r�[���ւ̃C���^�[�t�F�[�X���擾���� */
			Context initial = new InitialContext();
				
			/* JNDI���̃��b�N�A�b�v */
			CareerDesignEJBHome my_home
			  = (CareerDesignEJBHome) PortableRemoteObject.narrow
				  ( initial.lookup ( HcdbDef.jndi + "CareerDesignEJB" ), CareerDesignEJBHome.class );
				     
			/* EJBObject�̎擾 */ 
			CareerDesignEJB userSession = my_home.create();
			
			/* ���������擾 */
			Log.transaction( loginNo, true, "");
			kanziShimei = ( String )userSession.getMendanshaData( loginNo, loginNo ).get( 0 );
			Log.transaction( loginNo, false, "");
			
			Log.method(loginNo,"OUT","");
			return kanziShimei;
		} catch (NamingException ne) {
			Log.error( loginNo, "HJE-0002", ne );
			throw ne;
		} catch (ClassCastException cce) {
			Log.error( loginNo, "HJE-0003", cce );
			throw cce;
		} catch (Exception e) {
			Log.error(loginNo, "HJE-0017", e);
			throw e;
		}
	}
}
