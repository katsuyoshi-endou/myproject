/*
 * All Rights Reserved. Copyright (C) 2003, 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i���V�e�ACareer���ьn�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����
 *   2013/05/02  01.00     
 */
package jp.co.hisas.career.personal.careerdesign.servlet;

import java.io.IOException;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import jp.co.hisas.career.base.userinfo.bean.*;
import jp.co.hisas.career.personal.careerdesign.bean.*;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * �T�v:
 *   ��ʂɓ��͂��ꂽ�l���Z�b�V�����ɕێ�������
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 * </PRE>
 */
public class EditGyomuCareerDesignServlet extends HttpServlet{
	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;
	
	/** ���O�C��No */
	private String loginNo = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 *
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init( ServletConfig config ) {
		synchronized ( this ) {
			if ( ctx == null ) {
				ctx = config.getServletContext(  );
			}
		}
	}
	/**
	 * �u���E�U���瑗�M���ꂽ�l���󂯎��A�N���C�A���gBean�̒ǉ��������\�b�h���Ăяo���B
	 *
	 * @param request  �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
	 * @param response  Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException  ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException  Servlet�̐���ȏ������W����ꂽ���ɔ��������O
	 */
	public void service( HttpServletRequest request,
		HttpServletResponse response ) throws IOException, ServletException {
		/*���\�b�h�g���[�X�o��*/
		Log.method( loginNo, "IN", "" );
		Log.performance( loginNo, true, "" );
		
		try{
		
			loginNo = new String(  );
			/* session�X�R�[�v��Beans���擾���� */
			HttpSession session = request.getSession( false );
			/* Bean�̒��g��null�̏ꍇ */
			if ( session == null ) {
				ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp"  ).forward( request, response );
			/* Bean�̒��g��null�łȂ��ꍇ �����炪����*/ 
			} else {
				UserInfoBean bean = ( UserInfoBean ) session.getAttribute( "userinfo" );
				CareerDesignBean careerEditBean = ( CareerDesignBean )session.getAttribute( "careerDesignEdit" );
				CareerDesignBean careerBean = ( CareerDesignBean )session.getAttribute( "careerDesign" );
				ArrayList careerMastarItem6List = careerEditBean.getCareerDesignMaster6List();
				ArrayList careerMastarItem7List = careerEditBean.getCareerDesignMaster7List();
				ArrayList careerMastarItem8List = careerEditBean.getCareerDesignMaster8List();
				ArrayList careerMastarItem9List = careerEditBean.getCareerDesignMaster9List();
				ArrayList careerMastarItem10List = careerEditBean.getCareerDesignMaster10List();
				ArrayList careerMastarItem11List = careerEditBean.getCareerDesignMaster11List();
				ArrayList careerMastarItem12List = careerEditBean.getCareerDesignMaster12List();

				String nextPage = PZZ010_CharacterUtil.strEncode(request.getParameter( "nextPage" ) );
				int client = Integer.valueOf(request.getParameter( "client" ));
				
				String[] clientName = request.getParameterValues( "clientName" );
				String[] HENTorihikiCode = request.getParameterValues( "HENTorihikiCode" );
				String[] gyoshu = request.getParameterValues( "gyoshu" );
				String[] atsukaiKibo = request.getParameterValues( "atsukaiKibo" );
				String[] team = request.getParameterValues( "team" );
				String[] yakuwari = request.getParameterValues( "yakuwari" );
				String[] tantoKikanStart = request.getParameterValues( "tantoKikanStart" );
				String[] tantoKikanEnd = request.getParameterValues( "tantoKikanEnd" );
				String[] business = request.getParameterValues( "business" );
				String[] gyomuryoiki = request.getParameterValues( "gyomuryoiki" );
				String[] gyomuHyoka = request.getParameterValues( "gyomuHyoka" );
				String[] gyomuNaiyo = request.getParameterValues( "gyomuNaiyo" );
				String[] juyodo = request.getParameterValues( "juyodo" );
				
				int index = 0;
				ArrayList clientList = new ArrayList();
				ArrayList clientEditList = new ArrayList();
				
				for ( int i = 0; i < client; i++ ){
					HashMap clientMap = new HashMap();
					clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[0], careerBean.getSimeiNo() );
					String clientNo = "client" + String.format("%1$02d", i+1);
					clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[1], clientNo );
					clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[2], PZZ010_CharacterUtil.strEncode(clientName[i]) );
					clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[3], PZZ010_CharacterUtil.strEncode(HENTorihikiCode[i]) );
					clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[4], PZZ010_CharacterUtil.strEncode(gyoshu[i]) );
					clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[5], PZZ010_CharacterUtil.strEncode(atsukaiKibo[i]) );
					clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[6], PZZ010_CharacterUtil.strEncode(team[i]) );
					clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[7], PZZ010_CharacterUtil.strEncode(yakuwari[i]) );
					clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[8], PZZ010_CharacterUtil.strEncode(tantoKikanStart[i]) );
					clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[9], PZZ010_CharacterUtil.strEncode(tantoKikanEnd[i]) );
					clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[10], PZZ010_CharacterUtil.strEncode(business[i]) );
					clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[11], PZZ010_CharacterUtil.strEncode(gyomuNaiyo[i]) );
					clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[12], PZZ010_CharacterUtil.strEncode(juyodo[i]) );
					for ( index = 0; index < careerMastarItem6List.size(); index++ ){
						HashMap careerMastarItemMap = (HashMap)careerMastarItem6List.get(index);
						if ( careerMastarItemMap.get("list_6_code").equals(gyoshu[i]) ){
							clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[13], careerMastarItemMap.get("list_6_value") );
							break;
						}
					}
					for ( index = 0; index < careerMastarItem7List.size(); index++ ){
						HashMap careerMastarItemMap = (HashMap)careerMastarItem7List.get(index);
						if ( careerMastarItemMap.get("list_7_code").equals(atsukaiKibo[i]) ){
							clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[14], careerMastarItemMap.get("list_7_value") );
							break;
						}
					}
					for ( index = 0; index < careerMastarItem8List.size(); index++ ){
						HashMap careerMastarItemMap = (HashMap)careerMastarItem8List.get(index);
						if ( careerMastarItemMap.get("list_8_code").equals(team[i]) ){
							clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[15], careerMastarItemMap.get("list_8_value") );
							break;
						}
					}
					for ( index = 0; index < careerMastarItem9List.size(); index++ ){
						HashMap careerMastarItemMap = (HashMap)careerMastarItem9List.get(index);
						if ( careerMastarItemMap.get("list_9_code").equals(yakuwari[i]) ){
							clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[16], careerMastarItemMap.get("list_9_value") );
							break;
						}
					}
					for ( index = 0; index < careerMastarItem12List.size(); index++ ){
						HashMap careerMastarItemMap = (HashMap)careerMastarItem12List.get(index);
						if ( careerMastarItemMap.get("list_12_code").equals(business[i]) ){
							clientMap.put( HcdbDef.TANTO_MAIN_CLIENT_LIST[17], careerMastarItemMap.get("list_12_value") );
							break;
						}
					}
					clientList.add(clientMap);
				}
				
				ArrayList gyomuList = new ArrayList();
				ArrayList gyomuEditList = new ArrayList();
				for ( int i = 0; i < client; i++ ){
					int num = i * careerMastarItem11List.size();
					for ( int j = num; j < num + careerMastarItem11List.size(); j++ ){
// DEL 2013/06/03 COMTURE B-CT1-019 START
//						if ( !"".equals(gyomuryoiki[j]) ){
// DEL 2013/06/03 COMTURE B-CT1-019 END
// ADD 2013/06/03 COMTURE B-CT1-019 START
						if ( !"".equals(gyomuHyoka[j]) ){
// ADD 2013/06/03 COMTURE B-CT1-019 END
							HashMap gyomuMap = new HashMap();
							gyomuMap.put(HcdbDef.KEIKEN_GYOMU_RYOIKI_LIST[0], careerBean.getSimeiNo());
							String clientNo = "client" + String.format("%1$02d", i+1);
							gyomuMap.put( HcdbDef.KEIKEN_GYOMU_RYOIKI_LIST[1], clientNo );
							gyomuMap.put(HcdbDef.KEIKEN_GYOMU_RYOIKI_LIST[2], PZZ010_CharacterUtil.strEncode(gyomuryoiki[j]));
							gyomuMap.put(HcdbDef.KEIKEN_GYOMU_RYOIKI_LIST[3], PZZ010_CharacterUtil.strEncode(gyomuHyoka[j]));
							for ( index = 0; index < careerMastarItem11List.size(); index++ ){
								HashMap careerMastarItemMap = (HashMap)careerMastarItem11List.get(index);
								if ( careerMastarItemMap.get("list_11_code").equals(gyomuryoiki[j]) ){
									gyomuMap.put( HcdbDef.KEIKEN_GYOMU_RYOIKI_LIST[4], careerMastarItemMap.get("list_11_value") );
									break;
								}
							}
							for ( index = 0; index < careerMastarItem10List.size(); index++ ){
								HashMap careerMastarItemMap = (HashMap)careerMastarItem10List.get(index);
								if ( careerMastarItemMap.get("list_10_code").equals(gyomuHyoka[j]) ){
									gyomuMap.put( HcdbDef.KEIKEN_GYOMU_RYOIKI_LIST[5], careerMastarItemMap.get("list_10_value") );
									break;
								}
							}
							gyomuList.add(gyomuMap);
						}
					}
				}
				
				
				loginNo = bean.getLogin_no(  );
				
				CareerDesignLogicBean careerDesignLogicBean = new CareerDesignLogicBean(  );
				CareerDesignBean careerDesignBean = new CareerDesignBean(  );
				/* �S�����C���N���C�A���g�ǉ��{�^�������� */
				if ( nextPage.equals("clientAdd") ){
					int clientLine = Integer.valueOf(request.getParameter( "clientLine" ));
					int line = 0;
					for ( int i = 0; i < client + 1; i++ ){
						String clientNo = "client" + String.format("%1$02d", i+1);
						if ( i == clientLine + 1 ){
							clientEditList.add( new HashMap() );
						} else {
							clientEditList.add( clientList.get(line) );
// DEL 2013/05/31 COMTURE B-CT1-018 START
//							for ( int j = 0; j < gyomuList.size(); j++){
//								HashMap gyomuMap = (HashMap)gyomuList.get(j);
//								if ( (clientNo).equals((String)gyomuMap.get( HcdbDef.KEIKEN_GYOMU_RYOIKI_LIST[1])) ){
//									gyomuEditList.add( gyomuList.get(j) );
//								}
//							}
// DEL 2013/05/31 COMTURE B-CT1-018 END
							line++;
						}
					}
					careerEditBean.setTantoMainClientList(clientEditList);
// DEL 2013/05/31 COMTURE B-CT1-018 START
//					careerEditBean.setKeikenGyomuRyoikiList(gyomuEditList);
// DEL 2013/05/31 COMTURE B-CT1-018 END
// ADD 2013/05/31 COMTURE B-CT1-018 START
					careerEditBean.setKeikenGyomuRyoikiList(gyomuList);
// ADD 2013/05/31 COMTURE B-CT1-018 END

					/* �Z�b�V�����E�I�u�W�F�N�g���i�[������Bean�̃C���X�^���X���i�[���� */
					session.setAttribute("careerDesignEdit",careerEditBean);
					
					/* JSP�y�[�W���Ăяo�� */
					RequestDispatcher rd = ctx.getRequestDispatcher( "/view/personal/careerdesign/VAL026_CareerDesignEdit.jsp" );
					rd.forward( request, response );
				}
				/* �S�����C���N���C�A���g�폜�{�^�������� */
				if ( nextPage.equals("clientDel") ){
					int clientLine = Integer.valueOf(request.getParameter( "clientLine" ));
					for ( int i = 0; i < client; i++ ){
						String clientNo = "client" + String.format("%1$02d", i+1);
						if ( i != clientLine ){
							clientEditList.add( clientList.get(i) );
							for ( int j = 0; j < gyomuList.size(); j++){
								HashMap gyomuMap = (HashMap)gyomuList.get(j);
								if ( (clientNo).equals((String)gyomuMap.get( HcdbDef.KEIKEN_GYOMU_RYOIKI_LIST[1])) ){
									gyomuEditList.add( gyomuList.get(j) );
								}
							}
						}
					}
					careerEditBean.setTantoMainClientList(clientEditList);
					careerEditBean.setKeikenGyomuRyoikiList(gyomuEditList);

					/* �Z�b�V�����E�I�u�W�F�N�g���i�[������Bean�̃C���X�^���X���i�[���� */
					session.setAttribute("careerDesignEdit",careerEditBean);
					
					/* JSP�y�[�W���Ăяo�� */
					RequestDispatcher rd = ctx.getRequestDispatcher( "/view/personal/careerdesign/VAL026_CareerDesignEdit.jsp" );
					rd.forward( request, response );
				}
				/* �ҏW�{�^�������� */
				if( nextPage.equals( "edit" ) ) {
					ArrayList gyomuSortList = new ArrayList();
					for (int i = 0; i < careerMastarItem10List.size(); i++ ){
						HashMap careerMasterItemMap = (HashMap)careerMastarItem10List.get(i);
						for ( int j = 0; j < gyomuList.size(); j++ ){
							HashMap gyomuMap = (HashMap)gyomuList.get(j);
							if ( gyomuMap.get(HcdbDef.KEIKEN_GYOMU_RYOIKI_LIST[3]).equals(careerMasterItemMap.get("list_10_code")) ){
								gyomuSortList.add(gyomuMap);
							}
						}
					}
					
					careerEditBean.setTantoMainClientList(clientList);
					careerEditBean.setKeikenGyomuRyoikiList(gyomuSortList);
						
					/* �Z�b�V�����E�I�u�W�F�N�g���i�[������Bean�̃C���X�^���X���i�[���� */
					session.setAttribute("careerDesignEdit",careerEditBean);
					
					/* JSP�y�[�W���Ăяo�� */
					RequestDispatcher rd = ctx.getRequestDispatcher( "/view/personal/careerdesign/VAL023_CareerDesignEdit.jsp" );
					rd.forward( request, response );
				}
				
				/* �L�����Z���{�^�� */
				else if( nextPage.equals( "cancel" ) ){
					/* �Z�b�V�����E�I�u�W�F�N�g���i�[ */
					session.setAttribute("careerDesignEdit",careerBean);
				}
				/*���\�b�h�g���[�X�o��*/
				Log.performance( loginNo, false, "" );
				Log.method( loginNo, "OUT", "" );	
			}
		} catch ( IllegalStateException e ) {
			Log.error( loginNo, "HJE-0010", e );
			ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response );
		} catch ( IOException e ) {
			Log.error( loginNo, "HJE-0012", e );
			ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response );
		} catch ( ServletException e ) {
			Log.error( loginNo, "HJE-0015", e );
			ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response );
		} catch ( Exception e ) {
			Log.error( loginNo, "HJE-0017", e );
			ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp"  ).forward( request, response );
		}
	}
}
