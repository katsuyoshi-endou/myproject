/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�v��nHCDB�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/04/01  01.00       ����@���V�@�@�V�K�쐬
 */
 
package jp.co.hisas.career.util.pdf;

import java.awt.Color;
import java.io.*;

import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

public class PZE010_SyokusyuSetumeiPDF{
	/* ���O�C��No */
	private String login_no;
	
	/* PDF��� */
	private String str_file;
	private String[] syoku_yakuwari;
	private String[][] senmon_yakuwari;

	/* �O��������ږ� */
	private String pram_syokusyu     = (String)ReadFile.paramMapData.get("DZZ008");
	private String pram_senmon_bunya = (String)ReadFile.paramMapData.get("DZZ009");
	
	/**
	 * �R���X�g���N�^
	 * @param login_no
	 */
	public PZE010_SyokusyuSetumeiPDF( String login_no ) {
		this.login_no = login_no;
	}
	
	/**
	 * �o�͏����i�[����
	 * @param syoku_yakuwari
	 * @param senmon_yakuwari
	 */
	public void setData( String[] syoku_yakuwari, String[][] senmon_yakuwari ){
		this.syoku_yakuwari = syoku_yakuwari;
		this.senmon_yakuwari = senmon_yakuwari;
	}
	
	/**
	 * PDF���쐬����
	 * @param ops
	 * @throws Exception
	 */
	public void executePDF( OutputStream ops ) throws Exception{
		Log.method( login_no, "IN", "");
		/* �f�t�H���g�e�[�u���̐ݒ� */
		class MyTable extends Table {

			/**
			 * @param arg0
			 * @throws BadElementException
			 */
			public MyTable(int arg0) throws BadElementException {
				super( arg0 );
				setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
				setDefaultVerticalAlignment( Element.ALIGN_MIDDLE );
				
				setPadding( 2 );
			}
		
		}

		/*
		 * Document�I�u�W�F�N�g�̐���
		 *  A4�c�́A Document document = new Document(PageSize.A4);
		 *  A4���́ADocument document = new Document(PageSize.A4.rotate());
		 */ 
		Document document = new Document( PageSize.A4 );
		PdfWriter pw = null;
			
		try {
			/* PdfWriter�I�u�W�F�N�g�̐��� */
			pw = PdfWriter.getInstance( document, ops );
			pw.setCloseStream(true);
			
			/* �w�i�F */
			Color BackColor = Color.white;
			
			/* �h�L�������g��OPEN */
			HeaderFooter footer = new HeaderFooter(new Phrase("- "), new Phrase(" -"));
			footer.setBorderColor( BackColor );
			footer.setAlignment( Element.ALIGN_CENTER );
			document.setFooter(footer);
			document.open();
		
			/* �t�H���g�̐ݒ� */
			float default_font_size = 10;
			BaseFont bf = BaseFont.createFont( "HeiseiMin-W3", "UniJIS-UCS2-HW-H", false );
			Font font = new Font( bf, default_font_size );			
	
			/* �P�s�X�y�[�X�̒�` */
			Table space = new MyTable( 1 );
			space.setBorderColor( BackColor );
			space.addCell("");
	
			/* �e�e�[�u���̕� */
			int TableWidthTop = 90;
			int TableWidth    = 100;
	
			/* �R���e���c�̋L�q */
			MyTable table;
			Cell  cell;
			
			/* �E�� */
			table = new MyTable( 2 );
			table.setBorderColor( BackColor );
			table.setWidth( TableWidthTop );
			int[] syokusyu_widths = { 20, 80 }; 
			table.setWidths( syokusyu_widths );
			
			cell = new Cell( new Phrase( pram_syokusyu, font ) );
			cell.setBorderColor( BackColor );
			cell.setHorizontalAlignment( Element.ALIGN_CENTER );
			table.addCell( cell );
			
			cell = new Cell( new Phrase( syoku_yakuwari[0] + "\n\n", font ) );
			cell.setBorderColor( BackColor );
			table.addCell( cell );			
			document.add( table );

			/* �� */
			document.add( space );
						
			/* �E������ */
			table = new MyTable( 1 );
			table.setBorderColor( BackColor );
			table.setWidth( TableWidth );
			cell = new Cell( new Phrase( syoku_yakuwari[1], font ) );
			cell.setBorderColor( BackColor );
			table.addCell( cell );
			
			document.add( table );
			
			/* �� */
			document.add( space );
			
			/* ���� */
			table = new MyTable( 1 );
			table.setBorderColor( BackColor );
			table.setWidth( TableWidth );
			cell = new Cell( new Phrase( "���Y" + pram_syokusyu + "�͈ȉ���" + pram_senmon_bunya + "�ɋ敪�����" ,font ) );
			cell.setBorderColor( BackColor );
			table.addCell( cell );
			
			document.add( table );
			
			/* �� */
			document.add( space );
			
			/* ��啪����� */
			for ( int i = 0; i < senmon_yakuwari.length; i++ ){
				/* �f�o�b�O���O���o�� */
				Log.debug( senmon_yakuwari[i][0] + ":" + senmon_yakuwari[i][1] );
				
				table = new MyTable(2);
				table.setBorderColor( BackColor );
				table.setWidth( TableWidth );
				int[] senmon_setumei_widths = { 5, 95 }; 
				table.setWidths( senmon_setumei_widths );
				
				cell = new Cell( new Phrase( "��", font ) );
				cell.setBorderColor( BackColor );
				table.addCell( cell );
				
				cell = new Cell( new Phrase( senmon_yakuwari[i][0], font ) );
				cell.setBorderColor( BackColor );
				table.addCell( cell );
				
				cell = new Cell( new Phrase( "", font ) );
				cell.setBorderColor( BackColor );
				table.addCell( cell );
				
				cell = new Cell( new Phrase( senmon_yakuwari[i][1], font ) );
				cell.setBorderColor( BackColor );
				table.addCell( cell );
				
				document.add( table );
				
				/* �� */
				document.add( space );
			}	
			
		} catch (BadElementException e) {
			Log.error( login_no, "HJE-0017", e);
			throw (Exception)e;
		} catch (DocumentException e) {
			Log.error( login_no, "HJE-0017", e );
			throw (Exception)e;
		} catch (IOException e) {
			Log.error( login_no, "HJE-0017", e );
			throw (Exception)e;
		} catch ( Exception e ) {
			Log.error( login_no, "HJE-0017", e );
			throw e;
		} finally {
			/* �h�L�������g����� */
			if (document != null) {
				try {
					document.close();
				} catch (Exception e) {
					Log.error( login_no, "HJE-0017", e );
					throw e;
				}
			}
			if (pw != null) {
				try {
					pw.close();
				} catch (Exception e) {
					Log.error( login_no, "HJE-0017", e );
					throw e;
				}
			}
		}
	}
}

