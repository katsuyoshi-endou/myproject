package jp.co.hisas.career.util.pdf;

import java.awt.Color;
import java.io.*;

import jp.co.hisas.career.util.log.Log;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

public class PZE040_SkillStandardPDF{

	/* ���O�C��No */
	private String login_no;

	/**
	 * �R���X�g���N�^
	 * @param login_no
	 */
	public PZE040_SkillStandardPDF( String login_no ) {
		this.login_no = login_no;
	}
		
	/*PDF���*/	
	private String str_file;
	private String syoku_header;
	private String senmon_header;
	private String level_header;
	private String[] level_name_header;
	private String[][] skill;
	
	
	/**
	 * �X�L���X�^���_�[�h�����擾����
	 * 
	 * @param syoku_header
	 * @param senmon_header
	 * @param level_header
	 * @param level_name_header
	 * @param skill
	 */
	public void setSkill(String syoku_header,String senmon_header,String level_header,String[] level_name_header,String[][] skill){
		this.syoku_header = syoku_header;
		this.senmon_header = senmon_header;
		this.level_header = level_header;
		this.level_name_header = level_name_header;
		this.skill = skill;
	}
	
	/**
	 * PDF���쐬����
	 * @param ops
	 * @throws Exception
	 */
	public void executePDF( OutputStream ops ) throws Exception{
		Log.method( login_no, "IN", "");
		/* �f�t�H���g�e�[�u���̐ݒ� */
		class MyTable extends Table {

			/**
			 * @param arg0
			 * @throws BadElementException
			 */
			public MyTable(int arg0) throws BadElementException {
				super( arg0 );
				setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
				setDefaultVerticalAlignment( Element.ALIGN_MIDDLE );
				
				setPadding( 2 );
			}
		
		}

		/*
		 * Document�I�u�W�F�N�g�̐���
		 *  A4�c�́A Document document = new Document(PageSize.A4);
		 *  A4���́ADocument document = new Document(PageSize.A4.rotate());
		 */ 
		Document document = new Document( PageSize.A4 );
		PdfWriter pw = null;
			
		try {
			/* PdfWriter�I�u�W�F�N�g�̐��� */
			pw = PdfWriter.getInstance( document, ops );
			pw.setCloseStream(true);
			
			/* �w�i�F */
			Color BackColor = Color.white;
			
			/* �h�L�������g��OPEN */
			HeaderFooter footer = new HeaderFooter(new Phrase("- "), new Phrase(" -"));
			footer.setBorderColor( BackColor );
			footer.setAlignment( Element.ALIGN_CENTER );
			document.setFooter(footer);
			document.open();
		
			/* �t�H���g�̐ݒ� */
			float default_font_size = 10;
			BaseFont bf = BaseFont.createFont( "HeiseiMin-W3", "UniJIS-UCS2-HW-H", false );
			Font font = new Font( bf, default_font_size );

            /* �������p�t�H���g�ݒ� */
			Font font_white = new Font( bf, default_font_size );
			font_white.setColor( 255, 255, 255 );			
	
			/* �P�s�X�y�[�X�̒�` */
			Table space = new MyTable( 1 );
			space.setBorderColor( BackColor );
			space.addCell("");
	
			/* �e�[�u���̕� */
			int TableWidth    = 100;
	
			/* �R���e���c�̋L�q */
			MyTable table;
			Cell  cell;

			/* �w�b�_�[�o�� */
			
			/* �P�s�̃Z���� */
			int cell_count = level_name_header.length + 2;
			Log.debug("�P�s�̃Z�����F"+cell_count);
			
			int[] header_widths = new int[cell_count];
			/* ���x�������̕���ݒ� */
			int level_width = (int)35/level_name_header.length;
			
			header_widths[0] = 20;
			header_widths[1] = 45;			
			for( int i = 2; i < cell_count; i++ ){
			Log.debug("�J�E���g�F"+ i +", ���x�������̃w�b�_�[�Z�����F"+level_width);
				header_widths[i] = level_width;
			}

			table = new MyTable( cell_count );

			table.setWidths( header_widths );						
			table.setWidth( TableWidth );
			table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );

			cell = new Cell( new Phrase( syoku_header, font_white ) );
			cell.setRowspan( 2 );
			cell.setColspan( 1 );
			cell.setBackgroundColor( new Color( 39, 64, 139 ) );
			table.addCell( cell );
			table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
			cell = new Cell( new Phrase( senmon_header, font_white ) );
			cell.setRowspan( 2 );
			cell.setColspan( 1 );
			cell.setBackgroundColor( new Color( 39, 64, 139 ) );
			table.addCell( cell );
			table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
			cell = new Cell( new Phrase( level_header, font_white ) );
			cell.setRowspan( 1 );
			cell.setColspan( level_name_header.length );
			cell.setBackgroundColor( new Color( 39, 64, 139 ) );
			table.addCell( cell );
			table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
			for(int i=0; i<level_name_header.length;i++){
				cell = new Cell( new Phrase( level_name_header[i], font_white ) );
				cell.setRowspan( 1 );
				cell.setColspan( 1 );
				cell.setBackgroundColor( new Color( 39, 64, 139 ) );
				table.addCell( cell );
				table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );				
			}
			
			/* �h�L�������g�ɒǉ� */
			table.endHeaders();

			
			/* �f�[�^���o�� */

				
			/* �f�[�^���Ȃ��Ȃ�܂Ń��[�v */
			for( int i = 0 ; i < skill.length; i ++ ){
				/* ��啪�쐔�𐔂���i�E��̃Z�������ɗp����j */
				int count = 1;
				int j = i;	
				while ( true ) {
					/* ���[�v�I������ */
					if ( j + 1 == skill.length ){
						break;
					} else if ( !skill[j][0].equals(skill[j+1][0]) ){
						break;
					}
					j++;
					count++;
				}

				/* �E�햼�̏o�� */
				cell = new Cell( new Phrase( skill[i][1], font ) );
				cell.setRowspan( count );
				cell.setColspan( 1 );
				table.addCell( cell );
				table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
				
				while ( true ) {
					cell = new Cell( new Phrase( skill[i][3], font ) );
					cell.setRowspan( 1 );
					cell.setColspan( 1 );
					table.addCell( cell );
					table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
					/* ���x���o�� */
					for(int m = 4; m < level_name_header.length + 4; m++){				
						cell = new Cell( new Phrase( "", font ) );
						cell.setRowspan( 1 );
						cell.setColspan( 1 );												
						/* ���x�������݂���ꍇ */
						if(skill[i][m].equals("1")){
							cell.setBackgroundColor( new Color( 124, 125, 191 ) );
						}					
						table.addCell( cell );
						table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );

					}
					/* ���[�v�I������ */
					if ( i+1 == skill.length ){
						break;
					} else if ( !skill[i][0].equals(skill[i+1][0]) ){
						break;
					}
					i++;
				}								
			}
						
			/* �h�L�������g�ɒǉ� */
			document.add( table );						
											
		} catch (BadElementException e) {
			Log.error( login_no, "HJE-0017", e);
			throw (Exception)e;
		} catch (DocumentException e) {
			Log.error( login_no, "HJE-0017", e );
			throw (Exception)e;
		} catch (IOException e) {
			Log.error( login_no, "HJE-0017", e );
			throw (Exception)e;
		} catch ( Exception e ) {
			Log.error( login_no, "HJE-0017", e );
			throw e;
		} finally {
			/* �h�L�������g����� */
			if (document != null) {
				try {
					document.close();
				} catch (Exception e) {
					Log.error( login_no, "HJE-0017", e );
					throw e;
				}
			}
			if (pw != null) {
				try {
					pw.close();
				} catch (Exception e) {
					Log.error( login_no, "HJE-0017", e );
					throw e;
				}
			}
		}
	}
}


