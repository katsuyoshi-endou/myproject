/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i���V�e�ACareer�v��n�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2005/02/24  01.00       �떓�M�L  �@�@�V�K�쐬
 *   2005/11/08              QUANLA        sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */
package jp.co.hisas.career.plan.careernavi.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Writer;
import java.util.Calendar;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.plan.base.VelocityHelper;
import jp.co.hisas.career.plan.careernavi.bean.PBC_DownloadNaviBeanList;
import jp.co.hisas.career.plan.careernavi.ejb.PBC_DownloadNaviEJB;
import jp.co.hisas.career.plan.careernavi.ejb.PBC_DownloadNaviEJBHome;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �T�v: �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B
 * 
 * �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PBC200_CSVOutputServlet extends HttpServlet{
    
    /** ServletContext�I�u�W�F�N�g */
    private ServletContext ctx = null;

    /** ���O�C��No */
    private String login_no    = null;
    
    /**
     * ServletContext�I�u�W�F�N�g���擾����B
     * 
     * @param config   Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
     */
    public void init(ServletConfig config) {
        synchronized(this) {
            if(ctx == null) {
                ctx = config.getServletContext();
            }
        }
    }

    /**
     * �u���E�U���瑗�M���ꂽ�l���󂯎��A���������s����B
     * 
     * @param request   �N���C�A���g�̃��N�G�X�g��\��HttpServletRequest�I�u�W�F�N�g
     * @param response   Servlet ����̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
     * @exception IOException   ���o�͊֘A�����Ŕ��������O
     * @exception ServletException   Servlet �̐���ȏ������W����ꂽ�Ƃ��ɔ��������O
     */    
    public void service(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException{
            
        try {
           
            HttpSession session = request.getSession(false);
            if ( session == null ) {
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } else {                
                UserInfoBean bean = (UserInfoBean)session.getAttribute("userinfo");
                login_no = bean.getLogin_no();

                Log.method(login_no,"IN","");
                Log.performance(login_no,true,"");
                
                PBC_DownloadNaviBeanList list = null;
                
                Context initial = new InitialContext();
                PBC_DownloadNaviEJBHome my_home = (PBC_DownloadNaviEJBHome) PortableRemoteObject.narrow
                    ( initial.lookup ( HcdbDef.jndi + "PBC_DownloadNaviEJB" )
                    , PBC_DownloadNaviEJBHome.class );
                PBC_DownloadNaviEJB ejb = my_home.create();
                
                String senimoto_id = request.getParameter( "senimoto_id" );
                if("VBC200_IKKATU".equals(senimoto_id)){
                    String sosiki_code = request.getParameter( "S001_sosiki_code" );
                               
                    Log.transaction( login_no , true , "" );
                    list = ejb.getNavigationList( login_no , sosiki_code );
                    Log.transaction( login_no , false , "" );
                } else if("Sample".equals(senimoto_id)) {
                    String syoku_code = request.getParameter( "S001_syoku_code" );
                    String senmon_code = request.getParameter( "S002_senmon_code" );
                    String level_code = request.getParameter( "S003_level_code" );
                    
                    Log.transaction( login_no , true , "" );
                    list = ejb.getNavigationList( login_no , syoku_code, senmon_code, level_code );
                    Log.transaction( login_no , false , "" );
                }


                StringBuffer fileName = new StringBuffer();
                fileName.append(getNowTime());
                fileName.append("_");
                fileName.append("P13_GYOMU_KEIKEN_NAVI_TBL");
                fileName.append(".csv");

                VelocityHelper vh = new VelocityHelper("VBC010");
                vh.setParameter("BeanList", list);
                Writer w = vh.getWriter();
                ByteArrayInputStream bais = new ByteArrayInputStream(w.toString().getBytes());
                request.setAttribute("H080_FileName" ,fileName.toString());
                request.setAttribute("H081_ContentType" ,HcdbDef.CONTENT_TYPE);
                request.setAttribute("STREAM" ,bais);
                
                RequestDispatcher rd = ctx.getRequestDispatcher( "/servlet/PYE010_FileDownloadServlet" );
                rd.forward( request , response );
               
                Log.performance(login_no,false,"");
                Log.method(login_no,"OUT","");
            }
        } catch ( IllegalStateException e ){
            Log.error(login_no, "HJE-0010", e);
            //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( IOException e ){
            Log.error(login_no, "HJE-0012", e);
            //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( ServletException e ){
            Log.error(login_no, "HJE-0015", e);
            //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( Exception e) {
            Log.error(login_no, "HJE-0017", e);
            //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        }
    }
    
    /**
     * ���݂̓��t�Ǝ����̕�������擾�����^�[������B
     * 
     * @return ���t�Ǝ����̕�����iyyyymmddhhmmss�j
     */
    private String getNowTime() {
        
        Log.method(login_no, "IN", "");
        
        Calendar cal = Calendar.getInstance();
        String year = Integer.toString(cal.get(Calendar.YEAR));
        String month = Integer.toString(cal.get(Calendar.MONTH) + 1);
        if ( month.length() == 1 ) {
            month = "0" + month;
        }
        String day = Integer.toString(cal.get(Calendar.DAY_OF_MONTH));
        if ( day.length() == 1 ) {
            day = "0" + day;
        }
        String hour = Integer.toString(cal.get(Calendar.HOUR_OF_DAY));
        if ( hour.length() == 1 ) {
            hour = "0" + hour;
        }
        String minute = Integer.toString(cal.get(Calendar.MINUTE));
        if ( minute.length() == 1 ) {
            minute = "0" + minute;
        }
        String second = Integer.toString(cal.get(Calendar.SECOND));
        if ( second.length() == 1 ) {
            second = "0" + second;
        }

        Log.method(login_no, "OUT", "");
        return year + month + day + hour + minute + second;
    }
}
