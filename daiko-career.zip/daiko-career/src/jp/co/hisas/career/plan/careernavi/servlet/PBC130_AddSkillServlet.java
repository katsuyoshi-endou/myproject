/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i���V�e�ACareer�v��n�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/04/01  01.00       �n�� ��q    �V�K�쐬
 *   2005/11/08              QUANLA        sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */

package jp.co.hisas.career.plan.careernavi.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.property.*;
import jp.co.hisas.career.plan.careernavi.bean.*;
import jp.co.hisas.career.base.userinfo.bean.*;

/**
 *<PRE>
 * �T�v:
 *   �u���E�U���瑗�M���ꂽ�l���󂯎��A�N���C�A���gBean�̃X�L���ʋƖ��o���i�r�Q�[�V�����\�����\�b�h���Ăяo���B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 *</PRE>
 */
public class PBC130_AddSkillServlet extends HttpServlet{

    // ServletContext�I�u�W�F�N�g
    private ServletContext ctx = null;

    // ���O�C��No
    private String login_no    = null;

    /**
     * ServletContext�I�u�W�F�N�g���擾����B
     *
     * @param config   Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
     */
    public void init(ServletConfig config) {
        synchronized(this) {
            if(ctx == null) {
                ctx = config.getServletContext();
            }
        }
    }


    /**
     * �u���E�U���瑗�M���ꂽ�l���󂯎��A�N���C�A���gBean�̃X�L���ʋƖ��o���i�r�Q�[�V�����\�����\�b�h���Ăяo���B
     *
     * @param request   �N���C�A���g�̃��N�G�X�g��\��HttpServletRequest�I�u�W�F�N�g
     * @param response   Servlet ����̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
     * @exception IOException   ���o�͊֘A�����Ŕ��������O
     * @exception ServletException   Servlet �̐���ȏ������W����ꂽ�Ƃ��ɔ��������O
     */
    public void service(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException {
            try {

                HttpSession session = request.getSession(false);

                if ( session == null ) {
                    //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                    ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
                } else {
                    /* ******************** */
                    /*  ���͏��擾����    */
                    /* ******************** */

                    // UserInfoBean�Ăяo��
                    UserInfoBean bean  = (UserInfoBean)session.getAttribute("userinfo");
                    login_no = bean.getLogin_no();

                    // Log�o��
                    Log.method(login_no,"IN","");
                    Log.performance( login_no, true, "");

					// ���O�C���҂̊��������A�����������́A���������̑g�D�R�[�h���擾
                    String kousinsha_kanji = bean.getKanji_Login().substring(1);
                    //String busyo_ryakusyo  = bean.getBusyo_ryakusyo_mei().substring(1);   //2005/11/11_LYCE_R_QUANLA
                    String busyo_ryakusyo  = bean.getBusyo_ryakusyo_mei2().substring(1);     //2005/11/11_LYCE_A_QUANLA
                    String sosiki_code
                    = bean.getSyozokuCodeNavi( Integer.parseInt((String)ReadFile.fileMapData.get( HcdbDef.busyo_code ) ) ) ;

                    // ����NavigationBean�Ăяo��
                    PBC_NavigationBean navigationBean = (PBC_NavigationBean)session.getAttribute("navigation");
                    if ( navigationBean == null ) {
                        navigationBean = new PBC_NavigationBean( login_no );
						session.setAttribute("navigation",navigationBean);
                    }

                    // ���p�����ڂ̎擾
                    String syokusyu_code = request.getParameter("H001_syokusyu_code");
                    String senmon_code   = request.getParameter("H002_senmon_code");
                    String level_code    = request.getParameter("H005_reberu_code");

                    String[] updateneeds = request.getParameterValues("C003_Update");
                    String[] skill_code  = request.getParameterValues("H041_SkillCode");
                    String[] skill_name  = request.getParameterValues("H091_SkillName");
                    String[] skill_navi  = request.getParameterValues("A008_SkillNavi");

                    String skill_label   = (String)ReadFile.paramMapData.get( "DZZ012" );

                    /* ******************** */
                    /*      �Ɩ�����        */
                    /* ******************** */

                    int cnt;
                    if ( updateneeds == null ) {
                        cnt = 0;
                    } else {
                        cnt = updateneeds.length;
                    }

                    String kubun_skill = "2";
                    String error_url   = "/view/plan/careernavi/VBC090_UpdateErrorMsg.jsp";

                    // Bean�ւ̈��n�����ݒ�
                    int Itemcnt = HcdbDef.p13_column.length - 3;
                    int precnt  = 4;
                    String[][] updateItems  = new String[cnt][Itemcnt];
                    String[][] predataItems = new String[cnt][precnt];

                    for ( int i = 0 ; i < cnt ; i++ ) {

                        int index               = Integer.parseInt(updateneeds[i]);
                        String target_skillcode = (String)skill_code[index];
                        String target_skillnavi = PZZ010_CharacterUtil.strEncode((String)skill_navi[index]);

                        updateItems[i][0]  = syokusyu_code;
                        updateItems[i][1]  = senmon_code;
                        updateItems[i][2]  = level_code;
                        updateItems[i][3]  = kubun_skill;
                        updateItems[i][4]  = target_skillcode;
                        updateItems[i][5]  = sosiki_code;
                        updateItems[i][6]  = PZZ010_CharacterUtil.changeQuotation( target_skillnavi );
                        updateItems[i][7]  = PZZ010_CharacterUtil.GetDay();
                        updateItems[i][8]  = PZZ010_CharacterUtil.GetTime();
                        updateItems[i][9]  = login_no;
                        updateItems[i][10] = kousinsha_kanji;
                        updateItems[i][11] = busyo_ryakusyo;
                        // where��p�o�^�����A�X�V�������
                        predataItems[i][0] = navigationBean.getTorokubiPerSkill(target_skillcode);
                        predataItems[i][1] = navigationBean.getTorokujiPerSkill(target_skillcode);
                        predataItems[i][2] = navigationBean.getKousinbiPerSkill(target_skillcode);
                        predataItems[i][3] = navigationBean.getKousinjiPerSkill(target_skillcode);

                    }

                    if ( cnt > 0 ) {
                        int res = navigationBean.update_navi( updateItems , predataItems );

                        if ( res != 0 ) {

                            int index               = Integer.parseInt(updateneeds[ res - 1 ]);
                            String error_skill      = PZZ010_CharacterUtil.strEncode((String)skill_name[index]);

                            session.setAttribute( "mainte_kbn" , kubun_skill );
                            session.setAttribute( "errtitle"   , skill_label );
                            session.setAttribute( "err_skill"  , error_skill );
    
                            // JSP�y�[�W���Ăяo��
                            RequestDispatcher rd = ctx.getRequestDispatcher( error_url );
                            rd.forward(request, response);
    
                            // Log�o��
                            Log.performance(login_no,false,"");
                            Log.method(login_no,"OUT","");
                            return;
                        }
                    }


                    /* ******************** */
                    /*      �o�͏���        */
                    /* ******************** */

                    // �T�[�u���b�g���Ăяo��
                    RequestDispatcher rd = ctx.getRequestDispatcher("/servlet/PBC100_NaviMaintenanceServlet");
                    rd.forward(request, response);

                    // Log�o��
                    Log.performance(login_no,false,"");
                    Log.method(login_no,"OUT","");

                }

            } catch ( IllegalStateException e ){
                Log.error( login_no , "HJE-0010" , e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( IOException e ){
                Log.error( login_no , "HJE-0012" , e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( ServletException e ){
                Log.error( login_no , "HJE-0015" , e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( Exception e) {
                Log.error( login_no , "HJE-0017" , e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            }
    }
}
