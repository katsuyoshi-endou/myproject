/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i���V�e�ACareer�v��n�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/04/01  01.00       �n�� ��q    �V�K�쐬
 *   2005/11/08              QUANLA        sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */

package jp.co.hisas.career.plan.careernavi.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.property.*;
import jp.co.hisas.career.util.pdf.*;
import jp.co.hisas.career.plan.base.bean.*;
import jp.co.hisas.career.base.userinfo.bean.*;


/**
 *<PRE>
 * �T�v:
 *   �u���E�U����̌����v�����󂯎��A�N���C�A���gBean�̌����������\�b�h���Ăяo���B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 *</PRE>
 */
public class PBC140_DownloadLevelNaviServlet extends HttpServlet{

    /** ServletContext�I�u�W�F�N�g */
    private ServletContext ctx = null;

    /** ���O�C��No */
    private String login_no    = null;

    /**
     * ServletContext�I�u�W�F�N�g���擾����B
     *
     * @param config   Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
     */
    public void init(ServletConfig config) {
        synchronized(this) {
            if(ctx == null) {
                ctx = config.getServletContext();
            }
        }
    }

    /**
     * �u���E�U����̌����v�����󂯎��A�N���C�A���gBean�̌����������\�b�h���Ăяo���B
     *
     * @param     request            �N���C�A���g�̃��N�G�X�g��\��HttpServletRequest�I�u�W�F�N�g
     * @param     response           Servlet ����̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
     * @exception IOException        ���o�͊֘A�����Ŕ��������O
     * @exception ServletException   Servlet �̐���ȏ������W����ꂽ�Ƃ��ɔ��������O
     */
    public void service(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException{
            try {
                /* session�X�R�[�v��Beans���擾���� */
                HttpSession session = request.getSession(false);
                if ( session == null ) {
                    //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                    ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
                } else {

                    // UserInfoBean�ďo
                    UserInfoBean bean = (UserInfoBean)session.getAttribute("userinfo");
                    login_no = bean.getLogin_no();

                    // Log�o��
                    Log.method(login_no,"IN","");
                    Log.performance( login_no, true, "");
    
                    /* ******************** */
                    /*  ���͏��擾����    */
                    /* ******************** */
    
                    // �O����`����
                    String SenteItem1 = (String)ReadFile.announceMapData.get("AZZ007");
                    String SenteItem2 = (String)ReadFile.announceMapData.get("AZZ008");
                    String labelItem1 = (String)ReadFile.paramMapData.get("DZZ001");
                    String labelItem2 = (String)ReadFile.paramMapData.get("DZZ007");
                    String labelItem3 = (String)ReadFile.paramMapData.get("DZZ008");
                    String labelItem4 = (String)ReadFile.paramMapData.get("DZZ009");
                    String labelItem5 = (String)ReadFile.paramMapData.get("DZZ010");
                    String labelItem6 = (String)ReadFile.paramMapData.get("DZZ011");
    
                    String [] outDefItem = {
                        labelItem3,         labelItem4,
                        labelItem5,         labelItem6,
                        SenteItem1,         SenteItem2,
                        labelItem2,         labelItem1
                    };
    
    
                    // ���p������
                    String syokusyu_code = (String)request.getParameter("H001_syokusyu_code");
                    String senmon_code   = (String)request.getParameter("H002_senmon_code");
                    String level_code    = (String)request.getParameter("H005_reberu_code");
                    String simei_kanji   = PZZ010_CharacterUtil.strEncode((String)request.getParameter("H020_SimeiKanji"));
                    String busyo         = PZZ010_CharacterUtil.strEncode((String)request.getParameter("H022_Busyo"));
                    String last_uptime   = PZZ010_CharacterUtil.strEncode((String)request.getParameter("H105_LastUpTime"));
                    String gyomukeiken   = PZZ010_CharacterUtil.strEncode((String)request.getParameter("A007_LevelNavi"));
                    String updateneeds   = (String)request.getParameter("C003_Update");
    
                    String updatekbn     = "";
                    if ( updateneeds == null ) {
                        updatekbn = "�X�V���e��\n��ۑ�";
                    } else {
                        updatekbn = "�X�V���e��\n�ۑ�";
                    }
    
                    // ���̍��ڎ擾
                    String syokusyu_name = PBY_SkillStandardBean.getSyokuName( syokusyu_code );
                    String senmon_name   = PBY_SkillStandardBean.getSenmonName( syokusyu_code , senmon_code );
                    String level_name    = PBY_SkillStandardBean.getLevelName( syokusyu_code , senmon_code , level_code );
    
                    PBY_SkillSetumeiBean setumeiBean = new PBY_SkillSetumeiBean();
                    // �E��E��啪�������񌟍�
                    setumeiBean.SearchSyokusyuSetumei( login_no , syokusyu_code );
                    // ���x��������񌟍�
                    setumeiBean.SearchLevelSetumei( login_no , syokusyu_code, senmon_code, level_code );
     
                    // ��`���ڎ擾
                    String[]   syokusyu_def = setumeiBean.getSyokusyuYakuwari();
                    String     senmon_def   = setumeiBean.getSenmonYakuwari( senmon_code );
                    String[][] level_def    = setumeiBean.getTasseidoSetumei();
    
                    String[] outputItem = {
                        syokusyu_name,          senmon_name,
                        level_name,             syokusyu_def[1],
                        senmon_def,             gyomukeiken,
                        updatekbn,              busyo,
                        simei_kanji,            last_uptime
                    };


                    /******************************
                     * �Ɩ�����
                     ******************************/
                    /* PDF�t�@�C���� */
                    String pdf_name = login_no
                                    + PZZ010_CharacterUtil.GetDay()
                                    + PZZ010_CharacterUtil.GetTime()
                                    + "_NavigationLevel.pdf";
    
                    /* PDF�쐬 */
                    PZE050_CareerNaviLevelPDF pdf = new PZE050_CareerNaviLevelPDF( login_no );
    
                    pdf.setLevelNavi( outDefItem , outputItem , level_def );
    
                    ByteArrayOutputStream baos    = new ByteArrayOutputStream();
                    pdf.executePDF( baos );
                    ByteArrayInputStream bais     = new ByteArrayInputStream( baos.toByteArray() );
    
                    request.setAttribute( "STREAM", bais );
                    request.setAttribute( "H080_FileName", pdf_name );

                    /* ******************** */
                    /*      �o�͏���        */
                    /* ******************** */
                    /* JSP�y�[�W���Ăяo�� */
                    RequestDispatcher rd = ctx.getRequestDispatcher( "/servlet/PYE010_FileDownloadServlet" );
                    rd.forward( request , response );
    
                    Log.performance( login_no , false, "" );
                    Log.method( login_no ,"OUT" , "" );
    
                }
            } catch ( IllegalStateException e ){
                Log.error( login_no , "HJE-0010" , e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( IOException e ){
                Log.error( login_no , "HJE-0012" , e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( ServletException e ){
                Log.error( login_no , "HJE-0015" , e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( Exception e) {
                Log.error( login_no , "HJE-0017" , e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            }
        }
}
