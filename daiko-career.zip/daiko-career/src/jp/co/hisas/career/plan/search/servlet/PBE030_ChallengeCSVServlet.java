/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i���V�e�ACareer�v��n�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/04/01  01.00       �n�� ��q    �V�K�쐬
 *   2005/11/08              QUANLA        sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */

package jp.co.hisas.career.plan.search.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.property.*;
import jp.co.hisas.career.base.userinfo.bean.*;
import jp.co.hisas.career.search.kojin.bean.*;
import jp.co.hisas.career.plan.search.bean.*;
import jp.co.hisas.career.base.sosiki.bean.*;


/**
 * <PRE>
 * �T�v:
 *   �u���E�U���猟���������s�v�����󂯎��A�N���C�A���gBean�̕������̈ꗗ�擾���\�b�h���Ăяo���B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 * </PRE>
 */
public class PBE030_ChallengeCSVServlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

    /** ���O�C��No */
    private String login_no = null;

    /**
     * ServletContext�I�u�W�F�N�g���擾����B
     *
     * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
     */
    public void init(ServletConfig config) {
        synchronized(this) {
            if(ctx == null) {
                ctx = config.getServletContext();
            }
        }
    }

    /**
     * �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B
     *
     * @param      request           �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
     * @param      response          Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
     * @exception IOException       ���o�͊֘A�����Ŕ��������O
     * @exception ServletException  Servlet�̐���ȏ������W����ꂽ���ɔ��������O
     */
    public void service(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException{

            try {

                HttpSession session = request.getSession(false);
                if ( session == null ) {
                    //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                    ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
                } else {
                    UserInfoBean bean = (UserInfoBean)session.getAttribute("userinfo");
        
                    login_no = bean.getLogin_no();
        
                    Log.method( login_no, "IN", "" );
                    Log.performance( login_no, true, "" );
        
                    // ����SearchChallengeBean�Ăяo��
                    PBE_SearchChallengeBean challenge = (PBE_SearchChallengeBean)session.getAttribute("searchChallenge");
                    if ( challenge == null ) {
                        challenge = new PBE_SearchChallengeBean( login_no );
                        session.setAttribute( "searchChallenge" , challenge );
                    }
                    SearchKojinBean kojin = (SearchKojinBean)session.getAttribute("kojin");
                    if ( kojin == null ) {
                        kojin = new SearchKojinBean();
                        session.setAttribute( "kojin" , kojin );
                    }
    
                    // �O����`�l�̎擾
                    String engName    = (String)ReadFile.fileMapData.get( HcdbDef.searchParam1 );
                    String jinRyaku   = (String)ReadFile.fileMapData.get( HcdbDef.searchParam2 );
                    String yakuMaster = (String)ReadFile.fileMapData.get( HcdbDef.yakusyoku_master );
                    String labelItem1 = (String)ReadFile.paramMapData.get("DZZ001");
                    String labelItem2 = (String)ReadFile.paramMapData.get("DZZ004");
                    String labelItem3 = (String)ReadFile.paramMapData.get("DZZ005");
                    String labelItem4 = (String)ReadFile.paramMapData.get("DZZ006");
                    String labelItem5 = (String)ReadFile.paramMapData.get("DZZ014");
                    String labelItem6 = (String)ReadFile.paramMapData.get("DZZ017");
    
                    // �������ʂ̎擾
                    int rescnt               = challenge.getCount();
                    String search_cnd        = (String)session.getAttribute( "searchCondition" );
                    String[][] challengeList = challenge.getChallengeList();
        
                    // �o�͏��Z�b�g�p�ϐ�
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    byte[] add;
    
                    /* �w�b�_���o�� */
                    String header = "";
                    int addIndex  = 0;
    
                    header = "���������F," + search_cnd.replaceAll( "<br>" , "�A" ) + "\n";
                    header = header
                           + "�������ʁF," + rescnt + "��" + "\n";
        
                    header = header
                           + "\n"
                           + labelItem1 + ","
                           + labelItem2 + ",";
                    if ( engName.equals( "1" ) ) {
                        header = header
                               + labelItem3 + ",";
                        addIndex++;
                    }
                    if ( jinRyaku.equals( "1" ) ) {
                        header = header
                               + labelItem4 + ",";
                    } else {
                        header = header
                               + labelItem6 + ",";
                    }
                    header = header
                           + labelItem5 + ","
							+ "���Ԗ�" + ","
                           + "���с^�v��" + ","
                           + "�i����";
    
                    add = header.getBytes();
                    baos.write( add );
    
                    String data = "";
                    for ( int i = 0 ; i < challengeList.length ; i++ ) {
                        data = data + "\n"
                             + challengeList[i][1].substring(1) + ","
                             + challengeList[i][2].substring(1) + ",";
                        if ( engName.equals( "1" ) ) {
                            data = data
                                 + challengeList[i][3].substring(1) + ",";
                        }
						if ( jinRyaku.equals( "2" ) 
						&& ( yakuMaster.equals( "0" ) ) ) {
                            data = data
							     + challengeList[i][3+addIndex].substring(1) + ",";
                        } else {
                            data = data
							     + challengeList[i][3+addIndex] + ",";
                        }
                        data = data
                             + SosikiBean.getSosikiByCode( challengeList[i][4+addIndex].trim() , login_no )[2] + ","
                             + challengeList[i][5+addIndex] + ",";
                        if ( challengeList[i][7+addIndex].equals( HcdbDef.plan ) ) {
                            data = data
                                 + "�v��" + ",";
                        } else {
                            data = data
                                 + "����" + ",";
                        }
                        for ( int j = 0 ; j < HcdbDef.sinchoku.length ; j++ ) {
                            if ( challengeList[i][8+addIndex].equals( HcdbDef.sinchoku[j][2] )
                            &&   challengeList[i][9+addIndex].equals( HcdbDef.sinchoku[j][3] ) ) {
                                data = data
                                     + HcdbDef.sinchoku[j][1];
                            }
                        }
                    }
                    add = data.getBytes();
                    baos.write( add );
                    baos.close();
    
                    ByteArrayInputStream bais = new ByteArrayInputStream( baos.toByteArray() );
                    String curTime  = PZZ010_CharacterUtil.GetDay() + PZZ010_CharacterUtil.GetTime();
                    String csv_name = login_no + curTime + "_ChallengeList.csv";
                    request.setAttribute( "STREAM", bais );
                    request.setAttribute( "H080_FileName", csv_name );
        
                    RequestDispatcher rd = ctx.getRequestDispatcher( "/servlet/PYE010_FileDownloadServlet" );
                    rd.forward(request, response);
        
                    Log.performance( login_no, false, "");
                    Log.method(login_no,"OUT","");
                }

            } catch ( UnsupportedEncodingException e ){
                Log.error( login_no , "HJE-0007", e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( IllegalStateException e ){
                Log.error( login_no , "HJE-0010", e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( IndexOutOfBoundsException e ){
                Log.error( login_no , "HJE-0011", e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( IOException e ){
                Log.error( login_no , "HJE-0012", e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( ServletException e ) {
                Log.error( login_no , "HJE-0015", e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( Exception e) {
                Log.error( login_no , "HJE-0017", e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            }
        }
}

