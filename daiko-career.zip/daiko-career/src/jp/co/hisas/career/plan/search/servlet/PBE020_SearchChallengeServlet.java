/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i���V�e�ACareer�v��n�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/04/01  01.00       �n�� ��q    �V�K�쐬
 *   2004/09/27              �n�� ��q    �g�D�R�[�h��Trim�Ή�      <B-AJH02-001>
 *   2005/08/09  03.00       �͏@�@���s   �L�����A�`�������W���Ԃɂ�錟���Ή�
 *   2005/10/08  03.00       ���c�@���V   Oracle10gAS�Ή�
 *   2005/11/08              QUANLA        sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */

package jp.co.hisas.career.plan.search.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.property.*;
import jp.co.hisas.career.base.userinfo.bean.*;
import jp.co.hisas.career.search.kojin.bean.*;
import jp.co.hisas.career.plan.search.bean.*;
import jp.co.hisas.career.base.sosiki.bean.*;  // INS#P-PPH00-005-010


/**
 * <PRE>
 * �T�v:
 *   �u���E�U���猟���������s�v�����󂯎��A�N���C�A���gBean�̕������̈ꗗ�擾���\�b�h���Ăяo���B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 * </PRE>
 */
public class PBE020_SearchChallengeServlet extends HttpServlet {

    /** ServletContext�I�u�W�F�N�g */
    private ServletContext ctx = null;

    /** ���O�C��No */
    private String login_no = null;

    /**
     * ServletContext�I�u�W�F�N�g���擾����B
     *
     * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
     */
    public void init(ServletConfig config) {
        synchronized(this) {
            if(ctx == null) {
                ctx = config.getServletContext();
            }
        }
    }

    /**
     * �u���E�U���猟���������s�v�����󂯎��A�N���C�A���gBean�̃L�����A�`�������W���ꗗ�擾���\�b�h���Ăяo���B
     *
     * @param request  �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
     * @param response  Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
     * @exception IOException  ���o�͊֘A�����Ŕ��������O
     * @exception ServletException  Servlet�̐���ȏ������W����ꂽ���ɔ��������O
     */
    public void service(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException{

        try {

            HttpSession session = request.getSession(false);
			
            if ( session == null ) {
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } else {
                UserInfoBean bean = (UserInfoBean)session.getAttribute("userinfo");
                login_no = bean.getLogin_no();
    
                Log.method( login_no, "IN", "" );
                Log.performance( login_no, true, "" );
    
                // ����SearchChallengeBean�Ăяo��
                PBE_SearchChallengeBean challenge = (PBE_SearchChallengeBean)session.getAttribute("searchChallenge");
                if ( challenge == null ) {
                    challenge = new PBE_SearchChallengeBean( login_no );
                    session.setAttribute( "searchChallenge" , challenge );
                }
                SearchKojinBean kojin = (SearchKojinBean)session.getAttribute("kojin");
                if ( kojin == null ) {
                    kojin = new SearchKojinBean();
                    session.setAttribute( "kojin" , kojin );
                }
                // �����ꗗ���擾����
                String buRyakusyo[][] = kojin.getBusyo();

                // ���p�����ځA�O����`�l�̎擾
                String search_kbn  = request.getParameter("H101_Kensaku");
                String engName     = (String)ReadFile.fileMapData.get( HcdbDef.searchParam1 );
                String jinRyaku    = (String)ReadFile.fileMapData.get( HcdbDef.searchParam2 );
                String yakuMaster  = (String)ReadFile.fileMapData.get( HcdbDef.yakusyoku_master );
                String busyoPos    = (String)ReadFile.fileMapData.get( HcdbDef.busyo_code );
                String labelItem1  = (String)ReadFile.paramMapData.get( "DZZ002" );
                String labelItem2  = (String)ReadFile.paramMapData.get( "DZZ003" );
                String labelItem3  = (String)ReadFile.paramMapData.get( "DZZ004" );
                String labelItem4  = (String)ReadFile.paramMapData.get( "DZZ005" );
                String labelItem5  = (String)ReadFile.paramMapData.get( "DZZ011" );
                String labelItem6  = (String)ReadFile.paramMapData.get( "DZZ014" );
                String labelItem7  = (String)ReadFile.paramMapData.get( "DZZ114" );
                String labelItem8  = (String)ReadFile.paramMapData.get( "DZZ116" );
                String labelItem9  = (String)ReadFile.paramMapData.get( "DZZ117" );
                String labelItem10 = (String)ReadFile.paramMapData.get( "DZZ118" );
                String labelItem11 = (String)ReadFile.paramMapData.get( "DZZ119" );
                String labelItem12 = (String)ReadFile.paramMapData.get( "DZZ120" );


                // �J���v�敶��
                String[][] kaihatuPlan = {
                    { "1" , labelItem5  },
                    { "2" , labelItem7  },
                    { "3" , labelItem8  },
                    { "4" , labelItem9  },
                    { "5" , labelItem10 },
                    { "6" , labelItem11 },
                    { "7" , labelItem12 }
                };

                // ��������
                String[] search_cnd;
                int   search_cnd_num = 0;
                String search_condition = "";

                int cndnum;
                // �Z�b�V�����E�I�u�W�F�N�g�ɈȑO�̌�����������������폜����
                
                /* 2005.08.09 �͏@�@���s */
                session.removeAttribute( "Kikan_1" );
                session.removeAttribute( "Kubun_1" );
                session.removeAttribute( "Sinchoku" );
                session.removeAttribute( "Busyo_1" );
                /* 2005.08.09 �͏@�@���s */
				session.removeAttribute( "Kikan_2" );
                session.removeAttribute( "Kubun_2" );
                session.removeAttribute( "KaihatuKeikaku" );
                session.removeAttribute( "Umu" );
                session.removeAttribute( "Busyo_2" );
                session.removeAttribute( "SimeiNo" );
                session.removeAttribute( "SimeiKanji" );
                session.removeAttribute( "SimeiKana" );
                session.removeAttribute( "SimeiEiji" );
                session.removeAttribute( "Busyo_3" );

                switch ( Integer.parseInt( search_kbn ) ) {
                case 1:
				/* 2005.08.09 �͏@�@���s */
                    cndnum        = 8;

                    search_cnd    = new String[cndnum];

                    // INS#P-PPH00-005-010-S
                    if ( request.getParameter( "S012_Busyo_1" ) != null && !request.getParameter( "S012_Busyo_1" ).equals( "" ) ) {
                        busyoPos = SosikiBean.getSosikiByCode( (String)request.getParameter( "S012_Busyo_1" ).trim() , login_no )[4];  // CHG#P-AJH02-001-001
                    }
                    // INS#P-PPH00-005-010-E

                    search_cnd[0] = engName;
                    search_cnd[1] = jinRyaku;
                    search_cnd[2] = yakuMaster;
                    search_cnd[3] = busyoPos;

					/* 2005.08.09 �͏@�@���s */
					/* ���������̕ύX */
					search_cnd[4] = PZZ010_CharacterUtil.strEncode((String)request.getParameter( "S003_Kikan_1" ));
					search_cnd[5] = (String)request.getParameter( "S013_Kubun_1" );
					search_cnd[6] = (String)request.getParameter( "S014_Sinchoku" );
					search_cnd[7] = (String)request.getParameter( "S012_Busyo_1" );
					
					session.setAttribute( "Kikan_1"  , search_cnd[4] );
					session.setAttribute( "Kubun_1"  , search_cnd[5] );
					session.setAttribute( "Sinchoku" , search_cnd[6] );
					session.setAttribute( "Busyo_1"  , search_cnd[7] );
				
					/* 2005.08.09 �͏@�@���s */
					/* 						*/
					search_condition = search_cnd[4]
                                     + "��";
					/* 2005.08.09 �͏@�@���s */
                    if ( search_cnd[5].equals( HcdbDef.plan ) ) {
                        search_condition = search_condition
                                         + "�v��";
                    } else {
                        search_condition = search_condition
                                         + "����";
                    }
                    search_condition = search_condition
                                     + "��";
					/* 2005.08.09 �͏@�@���s */
					int ind = Integer.parseInt( search_cnd[6] ) - 1;
                    search_condition = search_condition
                                     + HcdbDef.sinchoku[ind][1];
                    if ( !search_cnd[7].equals( "" ) ) {
                        search_condition = search_condition
                                         + "��<br>����";
                        int i;
                        for ( i = 0 ; i < buRyakusyo.length ; i++ ) {
                            if ( buRyakusyo[i][0].equals( search_cnd[7] ) ) {
                                break;
                            }
                        }
                        search_condition = search_condition
                                         + labelItem6 + "��"
                                         + buRyakusyo[i][1];
                    }
                    search_condition = search_condition
                                     + "�ł���";
                    break;
                case 2:
                	/* 2005.08.09 �͏@ ���s */
                    cndnum        = 9;
                    search_cnd    = new String[cndnum];

                    // INS#P-PPH00-005-010-S
                    if ( request.getParameter( "S012_Busyo_2" ) != null && !request.getParameter( "S012_Busyo_2" ).equals( "" ) ) {
                        busyoPos = SosikiBean.getSosikiByCode( (String)request.getParameter( "S012_Busyo_2" ).trim() , login_no )[4];  // CHG#P-AJH02-001-001
                    }
                    // INS#P-PPH00-005-010-E

                    search_cnd[0] = engName;
                    search_cnd[1] = jinRyaku;
                    search_cnd[2] = yakuMaster;
                    search_cnd[3] = busyoPos;

					/* 2005.08.09 �͏@�@���s */
                    search_cnd[4] = PZZ010_CharacterUtil.strEncode((String)request.getParameter("S003_Kikan_2"));
                    search_cnd[5] = (String)request.getParameter("S013_Kubun_2");
                    search_cnd[6] = (String)request.getParameter("S015_KaihatuKeikaku");
                    search_cnd[7] = (String)request.getParameter("S016_Umu");
                    search_cnd[8] = (String)request.getParameter("S012_Busyo_2");

					/* 2005.08.09 �͏@�@���s */
                    session.setAttribute( "kikan_2"        , search_cnd[4] );
                    session.setAttribute( "Kubun_2"        , search_cnd[5] );
                    session.setAttribute( "KaihatuKeikaku" , search_cnd[6] );
                    session.setAttribute( "Umu"            , search_cnd[7] );
                    session.setAttribute( "Busyo_2"        , search_cnd[8] );

					/* 2005.08.09 �͏@�@���s */
                    search_condition = search_cnd[4]
                                     + "��";
                    if ( search_cnd[5].equals( HcdbDef.plan ) ) {
                        search_condition = search_condition
                                         + "�v��";
                    } else {
                        search_condition = search_condition
                                         + "����";
                    }
                    search_condition = search_condition
                                     + "��";
                    ind = Integer.parseInt( search_cnd[6] ) - 1;
                    search_condition = search_condition
                                     + ( kaihatuPlan[ind][1] )
                                     + "��";
                    if ( search_cnd[7].equals( "1" ) ) {
                        search_condition = search_condition
                                         + "����";
                    } else {
                        search_condition = search_condition
                                         + "�Ȃ�";
                    }
                    if ( !search_cnd[8].equals( "" ) ) {
                        search_condition = search_condition
                                         + "<br>����";
                        int i;
                        for ( i = 0 ; i < buRyakusyo.length ; i++ ) {
                            if ( buRyakusyo[i][0].equals( search_cnd[8] ) ) {
                                break;
                            }
                        }
                        search_condition = search_condition
                                         + labelItem6 + "��"
                                         + buRyakusyo[i][1]
                                         + "�ł���";
                    }
                    break;
                case 3:
                    cndnum        = 9;
                    search_cnd    = new String[cndnum];

                    // INS#P-PPH00-005-010-S
                    if ( request.getParameter( "S012_Busyo_3" ) != null && !request.getParameter( "S012_Busyo_3" ).equals( "" ) ) {
                        busyoPos = SosikiBean.getSosikiByCode( (String)request.getParameter( "S012_Busyo_3" ).trim() , login_no )[4];  // CHG#P-AJH02-001-001
                    }
                    // INS#P-PPH00-005-010-E

                    search_cnd[0] = engName;
                    search_cnd[1] = jinRyaku;
                    search_cnd[2] = yakuMaster;
                    search_cnd[3] = busyoPos;
                    search_cnd[4] = PZZ010_CharacterUtil.changeQuotation( PZZ010_CharacterUtil.strEncode( (String)request.getParameter("T001_SimeiNo") ) );
                    search_cnd[5] = PZZ010_CharacterUtil.changeQuotation( PZZ010_CharacterUtil.strEncode( (String)request.getParameter("T002_SimeiKanji") ) );
                    search_cnd[6] = PZZ010_CharacterUtil.changeQuotation( PZZ010_CharacterUtil.strEncode( (String)request.getParameter("T003_SimeiKana") ) );
                    search_cnd[7] = "";
                    search_cnd[8] = (String)request.getParameter("S012_Busyo_3");
                    String snoOut = PZZ010_CharacterUtil.strEncode( (String)request.getParameter("T001_SimeiNo") );
                    String skjOut = PZZ010_CharacterUtil.strEncode( (String)request.getParameter("T002_SimeiKanji") );
                    String sknOut = PZZ010_CharacterUtil.strEncode( (String)request.getParameter("T003_SimeiKana") );
                    String senOut = "";

                    if ( engName.equals( "1" ) ) {
                        /* ���������w���ʂœ��͂��������p�����擾���� */
                        search_cnd[7] = PZZ010_CharacterUtil.changeQuotation( PZZ010_CharacterUtil.strEncode( (String)request.getParameter("T014_SimeiEiji") ) );
                        senOut        = PZZ010_CharacterUtil.strEncode( (String)request.getParameter("T014_SimeiEiji") );
                    }

                    session.setAttribute( "SimeiNo"    , search_cnd[4] );
                    session.setAttribute( "SimeiKanji" , search_cnd[5] );
                    session.setAttribute( "SimeiKana"  , search_cnd[6] );
                    session.setAttribute( "SimeiEiji"  , search_cnd[7] );
                    session.setAttribute( "Busyo_3"    , search_cnd[8] );

                    if ( !search_cnd[4].equals( "" ) ) {
                        search_condition = labelItem1 + "��" + snoOut + "�Ŏn�܂�";
                    }
                    if ( !search_cnd[5].equals( "" ) ) {
                        if ( !search_condition.equals( "" ) ) {
                            search_condition = search_condition
                                             + " ���� ";
                        }
                        search_condition = search_condition
                                         + labelItem2 + "��" + skjOut + "�Ŏn�܂�";
                    }
                    if ( !search_cnd[6].equals( "" ) ) {
                        if ( !search_condition.equals( "" ) ) {
                            search_condition = search_condition
                                             + " ���� ";
                        }
                        search_condition = search_condition
                                         + labelItem3 + "��" + sknOut + "�Ŏn�܂�";
                    }
                    if ( engName.equals( "1" ) && !search_cnd[7].equals( "" ) ) {
                        if ( !search_condition.equals( "" ) ) {
                            search_condition = search_condition
                                             + " ���� ";
                        }
                        search_condition = search_condition
                                         + labelItem4 + "��" + senOut + "�Ŏn�܂�";
                    }
                    if ( !search_cnd[8].equals( "" ) ) {
                        if ( !search_condition.equals( "" ) ) {
                            search_condition = search_condition
                                             + "<br>����";
                        }
                        int i;
                        for ( i = 0 ; i < buRyakusyo.length ; i++ ) {
                            if ( buRyakusyo[i][0].equals( search_cnd[8] ) ) {
                                break;
                            }
                        }
                        search_condition = search_condition
                                         + labelItem6 + "��"
                                         + buRyakusyo[i][1]
                                         + "�ł���";
                    }
                    break;
                default:
					RequestDispatcher rd = ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" );
					rd.forward( request , response );
                    return;
                }

                if ( search_condition.equals( "" ) ) {
                    search_condition = "�Ȃ�";
                } else {
                    search_condition = search_condition + "�B";
                }

                // �����������s��
                /* ���������̎��s */
                challenge.search_challenge_list( search_kbn , search_cnd );
    
                // �Z�b�V�����E�I�u�W�F�N�g���i�[����
                session.setAttribute( "searchCondition" , search_condition );
    
                // JSP�y�[�W���Ăяo��
                RequestDispatcher rd = ctx.getRequestDispatcher( "/view/plan/search/VBE030_ChallengeResMain.jsp" );
                rd.forward( request , response );
    
                // Log�o��
                Log.performance( login_no, false, "");
                Log.method(login_no,"OUT","");
            }

        } catch ( UnsupportedEncodingException e ){
            Log.error( login_no , "HJE-0007", e );
            //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( IllegalStateException e ){
            Log.error( login_no , "HJE-0010", e );
            //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( IndexOutOfBoundsException e ){
            Log.error( login_no , "HJE-0011", e );
            //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( IOException e ){
            Log.error( login_no , "HJE-0012", e );
            //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( Exception e) {
            Log.error( login_no , "HJE-0017", e );
            //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
            ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        }
    }
}
