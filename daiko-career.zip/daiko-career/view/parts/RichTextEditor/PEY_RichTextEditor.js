var imagesPath   = "./img/";
var includesPath = "./palette/";
var cssFile      = "";
var selRange;
function initRTE(imgPath, incPath, css) {
    imagesPath = imgPath;
    includesPath = incPath;
    cssFile = css;
}


function writeRTE(rteId, contentHtml, frameWidth, frameHeight) {
    document.writeln('<style type="text/css">');
    document.writeln('.btnImage {cursor: pointer; cursor: hand;}');
    document.writeln('</style>');
    document.writeln('<table id="Buttons1_' + rteId + '">');
    document.writeln('	<tr>');
    document.writeln('		<td>');
    document.writeln('			<select id="fontname_' + rteId + '" onchange="selectSelectboxItem(\'' + rteId + '\', this.id)">');
    document.writeln('				<option value="Font" selected>�t�H���g��</option>');
    document.writeln('				<option value="Arial, Helvetica, sans-serif">Arial</option>');
    document.writeln('				<option value="Courier New, Courier, mono">Courier New</option>');
    document.writeln('				<option value="Times New Roman, Times, serif">Times New Roman</option>');
    document.writeln('				<option value="Verdana, Arial, Helvetica, sans-serif">Verdana</option>');
    document.writeln('				<option value="�l�r ����, sans-serif">MS����</option>');
    document.writeln('				<option value="�l�r �o����, sans-serif">MS P����</option>');
    document.writeln('				<option value="�l�r �S�V�b�N, sans-serif">MS�S�V�b�N</option>');
    document.writeln('				<option value="�l�r �o�S�V�b�N, sans-serif">MS P�S�V�b�N</option>');
    document.writeln('			</select>');
    document.writeln('		</td>');
    document.writeln('		<td>');
    document.writeln('			<input type="button" value="�t�H���g��" id="fontbigger_' + rteId + '" onclick="changeFontSize(\'' + rteId + '\', \'font_bigger\')"');

//    document.writeln('			<select unselectable="on" id="fontsize_' + rteId + '" onchange="selectSelectboxItem(\'' + rteId + '\', this.id);">');
//    document.writeln('				<option value="Size">Size</option>');
//    document.writeln('				<option value="1">1</option>');
//    document.writeln('				<option value="2">2</option>');
//    document.writeln('				<option value="3">3</option>');
//    document.writeln('				<option value="4">4</option>');
//    document.writeln('				<option value="5">5</option>');
//    document.writeln('				<option value="6">6</option>');
//    document.writeln('				<option value="7">7</option>');
//    document.writeln('			</select>');
    document.writeln('		</td>');
    document.writeln('		<td>');
    document.writeln('			<input type="button" value="�t�H���g��" id="fontsmaller_' + rteId + '" onclick="changeFontSize(\'' + rteId + '\', \'font_smaller\')"');
    document.writeln('		</td>');
    document.writeln('		<td>&nbsp;</td>');
    document.writeln('		<td><img class="btnImage" src="' + imagesPath + 'bold.gif" width="25" height="24" alt="Bold" title="Bold" onClick="formatText(\'' + rteId + '\', \'bold\', \'\')"></td>');
    document.writeln('		<td><img class="btnImage" src="' + imagesPath + 'italic.gif" width="25" height="24" alt="Italic" title="Italic" onClick="formatText(\'' + rteId + '\', \'italic\', \'\')"></td>');
    document.writeln('		<td><img class="btnImage" src="' + imagesPath + 'underline.gif" width="25" height="24" alt="Underline" title="Underline" onClick="formatText(\'' + rteId + '\', \'underline\', \'\')"></td>');
    document.writeln('		<td>&nbsp;</td>');
    document.writeln('		<td><div id="forecolor_' + rteId + '"><img class="btnImage" src="' + imagesPath + 'textcolor.gif" width="25" height="24" alt="Text Color" title="Text Color" onClick="ShowColorPalette(\'' + rteId + '\', \'forecolor\')"></div></td>');
    document.writeln('	</tr>');
    document.writeln('</table>');

    document.writeln('<iframe id="' + rteId + '" name="' + rteId + '" width="' + frameWidth + 'px" height="' + frameHeight + 'px"></iframe>');
    document.writeln('<iframe width="144" height="103" id="colorpalette_' + rteId + '" src="' + includesPath + 'palette.html" marginwidth="0" marginheight="0" scrolling="no" style="visibility:hidden; display: none; position: absolute;"></iframe>');
    document.writeln('<input type="hidden" id="hdn' + rteId + '" name="' + rteId + '" value="">');
    document.getElementById('hdn' + rteId).value = contentHtml;


    writeInternalFrameContent(rteId, contentHtml);
}

function writeInternalFrameContent(rteId, contentHtml) {
    var frameHtml = "<html id=\"" + rteId + "\">\n";
    frameHtml += "<head>\n";
    //�X�^�C���V�[�g��K�p����
    if (cssFile.length > 0) {
        frameHtml += "<link media=\"all\" type=\"text/css\" href=\"" + cssFile + "\" rel=\"stylesheet\">\n";
    }
    frameHtml += "<style>\n";
    frameHtml += "body {\n";
    frameHtml += "	background: #FFFFFF;\n";
    frameHtml += "	margin: 0px;\n";
    frameHtml += "	padding: 0px;\n";
    frameHtml += "}\n";
    frameHtml += "</style>\n";
    frameHtml += "</head>\n";
    frameHtml += "<body>\n";
    frameHtml += contentHtml + "\n";
    frameHtml += "</body>\n";
    frameHtml += "</html>";

    var oRTE = frames[rteId].document;
    oRTE.open();
    oRTE.write(frameHtml);
    oRTE.close();
    oRTE.designMode = "On";
}


function selectSelectboxItem(rteId, selectElmId) {
    var oRTE = frames[rteId];

    //�I��͈͂��擾����
    var selection = oRTE.document.selection; 
    if (selection != null) {
        selRange = selection.createRange();
    }

    var index = document.getElementById(selectElmId).selectedIndex;
    //�C���f�b�N�X0�̓��x���Ȃ̂Ŗ�������
    if (index > 0) {
        var selected = document.getElementById(selectElmId).options[index].value;
        var cmd = selectElmId.replace('_' + rteId, '');
        oRTE.document.execCommand(cmd, false, selected);
        document.getElementById(selectElmId).selectedIndex = index;
    }
}


function formatText(rteId, command, option) {
    var oRTE = frames[rteId];

    //�I��͈͂��擾����
    var selection = oRTE.document.selection; 
    if (selection != null) {
        selRange = selection.createRange();
    }

    oRTE.document.execCommand(command, false, option);
}

function changeFontSize(rteId, command) {
    var oRTE = frames[rteId];

    //�I��͈͂��擾����
    var selection = oRTE.document.selection; 
    if (selection != null) {
        selRange = selection.createRange();
    }

    currentSize = oRTE.document.queryCommandValue("FontSize");
    changeSize = 0;
    if ( command == "font_bigger" ) {
        changeSize = currentSize + 1;
    } else if ( command == "font_smaller" ) {
        changeSize = currentSize - 1;
    }

    oRTE.document.execCommand("FontSize", false, changeSize);
}

function ShowColorPalette(rteId, command) {
    var oRTE = frames[rteId];

    //�I��͈͂��擾����
    var selection = oRTE.document.selection; 
    if (selection != null) {
        selRange = selection.createRange();
    }

    //���݂̒l��ێ�
    parent.command = command;
    currentRTE = rteId;

    //�J���[�p���b�g�̈ʒu���擾
    buttonElement = document.getElementById(command + '_' + rteId);
    paletteElement = document.getElementById('colorpalette_' + rteId);
    paletteElement.style.left = getOffsetLeft(buttonElement) + "px";
    paletteElement.style.top = (getOffsetTop(buttonElement) + buttonElement.offsetHeight) + "px";
    //�J���[�p���b�g�̕\���E��\������
    if ( paletteElement.style.visibility  == "hidden") {
        paletteElement.style.visibility = "visible";
        paletteElement.style.display = "inline";
    } else {
        paletteElement.style.visibility = "hidden";
        paletteElement.style.display = "none";
    }
}


//�t�H���g�F�ݒ�
function setColor(color) {
    var rteId = currentRTE;
    var oRTE = frames[rteId];

    var selection = oRTE.document.selection;
    if (selection != null) {
        var newRng = selection.createRange();
        newRng = selRange;
        newRng.select();
    }

    //�t�H���g�F�ݒ�
    oRTE.document.execCommand(parent.command, false, color);

    //�J���[�p���b�g��\��
    paletteElement = document.getElementById('colorpalette_' + rteId);
    paletteElement.style.visibility = "hidden";
    paletteElement.style.display = "none";
}

function getOffsetTop(elm) {
    var mOffsetTop = elm.offsetTop;
    var mOffsetParent = elm.offsetParent;

    while ( mOffsetParent ) {
        mOffsetTop += mOffsetParent.offsetTop;
        mOffsetParent = mOffsetParent.offsetParent;
    }

    return mOffsetTop;
}

function getOffsetLeft(elm) {
    var mOffsetLeft = elm.offsetLeft;
    var mOffsetParent = elm.offsetParent;

    while ( mOffsetParent ) {
        mOffsetLeft += mOffsetParent.offsetLeft;
        mOffsetParent = mOffsetParent.offsetParent;
    }

    return mOffsetLeft;
}
