package jp.co.hisas.career.app.batch.util.log;

public class Log {
	
}
