package jp.co.hisas.career.app.batch.jinik.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.batch.util.BatchConnectUtil;
import jp.co.hisas.career.app.sheet.dto.ZzJinikUploadReserveDto;

public class ZzJinikUploadReserveDao {

	private Connection conn = null;

	public ZzJinikUploadReserveDao( Connection conn ) {
		this.conn = conn;
	}

	public List<ZzJinikUploadReserveDto> selectDynamic( String sql, List<String> paramList ) throws SQLException {

		PreparedStatement stmt = null;

		try {
			stmt = BatchConnectUtil.getStatement( conn, sql, paramList );

			return selectDynamic( stmt );
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchConnectUtil.closeConnection( null, stmt, null);
		}
	}

	public List<ZzJinikUploadReserveDto> selectDynamic( PreparedStatement stmt ) throws SQLException {

		ResultSet rs = null;

		try {
			rs = stmt.executeQuery();

			List<ZzJinikUploadReserveDto> list = new ArrayList<ZzJinikUploadReserveDto>();
			while ( rs.next()) {
				list.add( transferRsToDto( rs ));
			}
			return list;
		} catch ( SQLException e ) {
			throw e;
		} finally {
			BatchConnectUtil.closeConnection( null, stmt, rs );
		}
	}

	private ZzJinikUploadReserveDto transferRsToDto( ResultSet rs ) throws SQLException {

		ZzJinikUploadReserveDto dto = new ZzJinikUploadReserveDto();
		dto.setRsvSeq( rs.getInt( "RSV_SEQ" ));
		dto.setRsvGuid( rs.getString( "RSV_GUID" ));
		dto.setRsvMailAddress( rs.getString( "RSV_MAIL_ADDRESS" ));
		dto.setRsvDate( rs.getString( "RSV_DATE" ));
		dto.setRsvStatus( rs.getString( "RSV_STATUS" ));
		dto.setUploadFileName( rs.getString( "UPLOAD_FILE_NAME" ));
		dto.setUploadContentType( rs.getString( "UPLOAD_CONTENT_TYPE" ));
		dto.setUploadBlobFile( rs.getBlob( "UPLOAD_FILE" ));
		dto.setUpdateStartDate( rs.getString( "UPDATE_START_DATE" ));
		dto.setUpdateFinishDate( rs.getString( "UPDATE_FINISH_DATE" ));

		return dto;
	}

    public void executeDynamic( PreparedStatement pstmt ) throws SQLException {
        try {
            pstmt.executeUpdate();
        } catch ( SQLException e) {
            throw e;
        } finally {
        }
    }

    public void executeDynamic( String sql ) throws SQLException {

        PreparedStatement pstmt = null;
        try {
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            throw e;
        } finally {
        	BatchConnectUtil.closeConnection( null, pstmt, null );
        }
    }
}
