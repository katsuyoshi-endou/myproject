package jp.co.hisas.career.app.sheet.command;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.CareerMenuBean;
import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.bean.CsFlowPtnBean;
import jp.co.hisas.career.app.sheet.dto.VCsmFlowStatusDto;
import jp.co.hisas.career.app.sheet.event.CsActorEventArg;
import jp.co.hisas.career.app.sheet.event.CsActorEventHandler;
import jp.co.hisas.career.app.sheet.event.CsActorEventResult;
import jp.co.hisas.career.app.sheet.event.CsFlowEvArg;
import jp.co.hisas.career.app.sheet.event.CsFlowEvHdlr;
import jp.co.hisas.career.app.sheet.event.CsFlowEvRslt;
import jp.co.hisas.career.app.sheet.event.CsProgressEventArg;
import jp.co.hisas.career.app.sheet.event.CsProgressEventHandler;
import jp.co.hisas.career.app.sheet.event.CsProgressEventResult;
import jp.co.hisas.career.app.sheet.event.CsSheetEventArg;
import jp.co.hisas.career.app.sheet.event.CsSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.CsSheetEventResult;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsSingleSheet;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.framework.trans.StateTransitionEvent;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class PHD010Command extends AbstractCommand {
	
	public static final String KINOU_ID = "VHD010";
	private HttpServletRequest request;
	private HttpSession session;
	private String state;
	private String operatorGuid;
	
	public PHD010Command() {
		super( PHD010Command.class, KINOU_ID, null );
	}
	
	public void init( StateTransitionEvent e ) {
		try {
			request = e.getRequest();
			session = request.getSession( false );
			/* Not Update Token While Single Sheet.
			CSRFTokenUtil.setNewTokenNo( request, e.getResponse() ); */
			state = request.getParameter( "state" );
			main();
		} catch (CareerException ex) {
			throw new CareerRuntimeException( ex );
		}
	}
	
	private void main() throws CareerException {
		
		execEventInit();
	}
	
	private void execEventInit() throws CareerException {
		
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( session, UserInfoBean.SESSION_KEY );
		this.operatorGuid = userInfo.getOperatorGuid();
		
		CareerMenuBean oneMenu = AU.getSessionAttr( session, AppSessionKey.CAREER_ONE_MENU );
		
		// set SheetID on Session.
		String sheetId = CsUtil.setSheetIdOnSession( request, session );
		
		// シート参照用（子画面）
		String actorCd = AU.getSessionAttr( session, CsSessionKey.CS_VIEW_SHEET_ACTOR_CD );
		
		/* Set Args */
		CsSheetEventArg arg = new CsSheetEventArg( super.getLoginNo(), this.operatorGuid );
		arg.sharp = "INIT";
		arg.mailSenderName = userInfo.getKanjiSimei();//TODO: 統合アカウントの名前であるべき
		arg.sheetId = sheetId;
		arg.actorCd = actorCd;
		arg.mokPrgrsPage = SU.toInt( AU.getRequestValue( request, "mokPrgrsPage" ), 1 );
		
		/* Execute Event */
		CsSheetEventResult result = CsSheetEventHandler.exec( arg );
		
		/* Return to session */
		// シングルシートオブジェクトをセッションにセット
		CsSingleSheet sheet = new CsSingleSheet();
		sheet.loginNo          = super.getLoginNo();
		sheet.langNo           = AU.getLangNo( session );
		sheet.sheetId          = sheetId;
		sheet.sheetInfo        = result.getSheetInfoDto();
		sheet.labelSetCd       = sheet.sheetInfo.getLabelSetCd();
		sheet.paramSetCd       = sheet.sheetInfo.getParamSetCd();
		sheet.sheetInfoAttr    = result.getInfoAttrDto();
		sheet.fillMap          = result.getFillMap();
		sheet.fillMaskMap      = result.getFillMaskMap();
		sheet.fillIdMasterList = result.getFillIdList();
		sheet.csNeighborList   = result.getNeighborList();
		sheet.csFlowStatusList = result.getFlowStatusList();
		sheet.flowInfo         = getFlowInfo( sheet.sheetInfo.getFlowCd() );
		sheet.flowPtnList      = getFlowPtnList( sheet.sheetInfo.getFlowCd() );
		sheet.actionList       = result.getActionList();
		sheet.layoutJsList     = result.getLayoutJsList();
		sheet.layoutPdList     = result.getLayoutPdList();
		sheet.exclusiveKey     = result.getExclusiveKey();
		sheet.actionLogList    = result.getActionLogList();
		sheet.usingActorCd     = result.usingActorCd;
		session.setAttribute( CsSessionKey.CS_SINGLE_SHEET, sheet );
		
		/* Actor */
		execListingActors();
		
		/* CsProgress#INIT */
		execCsProgress( "INIT", oneMenu.party, sheet.sheetInfo.getOperationCd() );
		
		/* 操作ログ */
		OutLogBean.outputLogSousa( request, KINOU_ID, sheetId, state );
	}
	
	private void execCsProgress( String sharp, String party, String opeCd ) throws CareerException {
		
		/* Set Args */
		CsProgressEventArg arg = new CsProgressEventArg( super.getLoginNo() );
		arg.sharp = sharp;
		arg.party = party;
		arg.operationCd = opeCd;
		arg.isActiveOnly = false;
		arg.isBindedOnly = false;
		arg.guid = super.getLoginNo();
		
		/* Execute Event */
		CsProgressEventResult result = CsProgressEventHandler.exec( arg );
		
		/* Return to session */
		session.setAttribute( CsSessionKey.CS_PROGRESS, result );
	}
	
	private void execListingActors() throws CareerException {
		
		// set SheetID on Session.
		String sheetId = CsUtil.setSheetIdOnSession( request, session );
		
		/* Set Args */
		CsActorEventArg arg = new CsActorEventArg( super.getLoginNo() );
		arg.sharp = "LIST_ACT";
		arg.sheetId = sheetId;
		
		/* Execute Event */
		CsActorEventResult result = CsActorEventHandler.exec( arg );
		
		/* Return to session */
		session.setAttribute( CsSessionKey.CS_ACTOR_LIST, result.getActorList() );
		session.setAttribute( CsSessionKey.CS_HOLD_ACTOR_LIST, result.getHoldActorList() );
	}
	
	private List<VCsmFlowStatusDto> getFlowInfo( String flowCd ) throws CareerException {
		CsFlowEvArg arg = new CsFlowEvArg( super.getLoginNo() );
		arg.sharp = "GET_ALL_STATUS";
		arg.flowCd = flowCd;
		CsFlowEvRslt result = CsFlowEvHdlr.exec( arg );
		return result.allStatuses;
	}
	
	private List<CsFlowPtnBean> getFlowPtnList( String flowCd ) throws CareerException {
		CsFlowEvArg arg = new CsFlowEvArg( super.getLoginNo() );
		arg.sharp = "GET_ALL_FLOWPTN_INFO";
		arg.flowCd = flowCd;
		CsFlowEvRslt result = CsFlowEvHdlr.exec( arg );
		return result.flowPtnList;
	}
	
}