/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CstSheetFillDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CSTシート回答 Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CstSheetFillDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " SHEET_ID as sheetId,"
                     + " FILL_ID as fillId,"
                     + " FILL_CONTENT as fillContent"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CstSheetFillDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CstSheetFillDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * Insert文を実行する。
     * @param dto CST_SHEET_FILLのデータ。
     */ 
    public void insert(CstSheetFillDto dto) {

        final String sql = "INSERT INTO CST_SHEET_FILL ("
                         + "SHEET_ID,"
                         + "FILL_ID,"
                         + "FILL_CONTENT"
                         + ")VALUES(?,?,? )"
                         ;
        Log.sql("【DaoMethod Call】 CstSheetFillDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getSheetId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getFillId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getFillContent());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * 全列update文を実行する。
     * @param dto CST_SHEET_FILLのレコード型データ。
     */
    public void update(CstSheetFillDto dto) {

        final String sql = "UPDATE CST_SHEET_FILL SET "
                         + "FILL_CONTENT = ?"
                         + " WHERE SHEET_ID = ?"
                         + " AND FILL_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstSheetFillDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getFillContent());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getSheetId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getFillId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してdelete文を実行する。
     * @param sheetId シートID
     * @param fillId 回答ID
     */ 
    public void delete(String sheetId, String fillId) {

        final String sql = "DELETE FROM CST_SHEET_FILL"
                         + " WHERE SHEET_ID = ?"
                         + " AND FILL_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstSheetFillDao.delete");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, fillId);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally { 
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param sheetId シートID
     * @param fillId 回答ID
     * @return CstSheetFillDto CST_SHEET_FILLのレコード型データ。
     */ 
    public CstSheetFillDto select(String sheetId, String fillId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CST_SHEET_FILL"
                         + " WHERE SHEET_ID = ?"
                         + " AND FILL_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 CstSheetFillDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, fillId);
            rs = pstmt.executeQuery();
            CstSheetFillDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<CstSheetFillDto> CST_SHEET_FILLのレコード型データのリスト。
     */ 
    public List<CstSheetFillDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CstSheetFillDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CstSheetFillDto> lst = new ArrayList<CstSheetFillDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CstSheetFillDto> CST_SHEET_FILLのレコード型データのリスト。
     */ 
    public List<CstSheetFillDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CstSheetFillDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * 動的SELECT COUNT 文を実行する。
     * @param pstmt PreparedStatement
     * @return レコード件数。
     */ 
    public int selectCountDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CstSheetFillDao.selectCountDynamic");
        ResultSet rs = null;
        int cnt = 0;
        try {
            rs = pstmt.executeQuery();
            if ( rs.next() ) {
                cnt = rs.getInt(1);
            }
            return cnt;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT COUNT 文を実行する。
     * @param sql SQL文
     * @return レコード件数。
     */ 
    public int selectCountDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CstSheetFillDao.selectCountDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectCountDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param pstmt PreparedStatement
     */ 
    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("【DaoMethod Call】 CstSheetFillDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param sql SQL文
     */ 
    public void executeDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CstSheetFillDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CstSheetFillDto transferRsToDto(ResultSet rs) throws SQLException {

        CstSheetFillDto dto = new CstSheetFillDto();
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setFillId(DaoUtil.convertNullToString(rs.getString("fillId")));
        dto.setFillContent(DaoUtil.convertNullToString(rs.getString("fillContent")));
        return dto;
    }

    /**
     * シートIDを指定して回答IDと回答内容をすべて取得する。
     * @param sheetId シートID
     * @return List<CstSheetFillDto> CST_SHEET_FILLのレコード型データのリスト。
     */
    public List<CstSheetFillDto> selectAllFillsBySheetId(String sheetId) {

        final String sql = "SELECT SHEET_ID as sheetId, FILL_ID as fillId, FILL_CONTENT as fillContent FROM V_CST_ALL_FILLS WHERE SHEET_ID=?";
        Log.sql("【DaoMethod Call】 CstSheetFillDao.selectAllFillsBySheetId");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            rs = pstmt.executeQuery();
            List<CstSheetFillDto> lst = new ArrayList<CstSheetFillDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

