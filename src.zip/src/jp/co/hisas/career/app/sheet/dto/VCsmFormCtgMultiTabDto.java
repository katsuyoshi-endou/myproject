/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * V_CSM_FORM_CTG_MULTI_TAB Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VCsmFormCtgMultiTabDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * FORM_GRP_CD
     */
    private String formGrpCd;
    /**
     * FORM_CTG_CD
     */
    private String formCtgCd;
    /**
     * SEQ_NO
     */
    private String seqNo;
    /**
     * STATUS_CD
     */
    private String statusCd;
    /**
     * MULTI_TAB
     */
    private String multiTab;

    /**
     * FORM_GRP_CDを取得する。
     * @return FORM_GRP_CD
     */
    public String getFormGrpCd() {
        return formGrpCd;
    }

    /**
     * FORM_GRP_CDを設定する。
     * @param formGrpCd FORM_GRP_CD
     */
    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    /**
     * FORM_CTG_CDを取得する。
     * @return FORM_CTG_CD
     */
    public String getFormCtgCd() {
        return formCtgCd;
    }

    /**
     * FORM_CTG_CDを設定する。
     * @param formCtgCd FORM_CTG_CD
     */
    public void setFormCtgCd(String formCtgCd) {
        this.formCtgCd = formCtgCd;
    }

    /**
     * SEQ_NOを取得する。
     * @return SEQ_NO
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * SEQ_NOを設定する。
     * @param seqNo SEQ_NO
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * STATUS_CDを取得する。
     * @return STATUS_CD
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * STATUS_CDを設定する。
     * @param statusCd STATUS_CD
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    /**
     * MULTI_TABを取得する。
     * @return MULTI_TAB
     */
    public String getMultiTab() {
        return multiTab;
    }

    /**
     * MULTI_TABを設定する。
     * @param multiTab MULTI_TAB
     */
    public void setMultiTab(String multiTab) {
        this.multiTab = multiTab;
    }

}

