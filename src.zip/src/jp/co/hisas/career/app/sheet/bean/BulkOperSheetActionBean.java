package jp.co.hisas.career.app.sheet.bean;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.CareerMenuBean;
import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.app.sheet.event.BulkOperSheetEventArg;
import jp.co.hisas.career.app.sheet.event.BulkOperSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.BulkOperSheetEventResult;
import jp.co.hisas.career.app.sheet.util.BulkOperSheet;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;

public class BulkOperSheetActionBean {

	private String loginNo;
	private String operatorGuid;
	private HttpServletRequest request;
	private HttpSession session;

	public BulkOperSheetActionBean(String loginNo, String operatorGuid) {
		this.loginNo = loginNo;
		this.operatorGuid = operatorGuid;
	}

	public void execBulkSheetAction( String state, final HttpServletRequest req, String opeType ) throws CareerException {
		this.request = req;
		this.session = request.getSession( false );

		CareerMenuBean oneMenu = AU.getSessionAttr( session, AppSessionKey.CAREER_ONE_MENU );
		String party = oneMenu.party;

		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( session, UserInfoBean.SESSION_KEY );
		this.operatorGuid = userInfo.getOperatorGuid();

		BulkOperSheet bulkOperSheet = AU.getSessionAttr( session, CsSessionKey.BULK_OPER_SHEET );
		bulkOperSheet = (bulkOperSheet != null) ? bulkOperSheet : new BulkOperSheet( loginNo, operatorGuid );

		/* Prepare */
		BulkOperSheetEventResult preRslt = execEventPrepare( party, opeType );
		bulkOperSheet.divList       = preRslt.divList;
		bulkOperSheet.operationList = preRslt.opeList;

		if ("INIT".equals( state )) {
			bulkOperSheet.gamenCondMap = makeSrchCondMap( party );
			// メニューから遷移時は先頭のオペレーションでデフォルト検索
			String latestOpeCd = null;
			if (bulkOperSheet.operationList.size() > 0) {
				latestOpeCd = bulkOperSheet.operationList.get( 0 ).getValue();
			}
			bulkOperSheet.gamenCondMap.put( "operationCd", latestOpeCd );
			session.setAttribute( CsSessionKey.BULK_OPER_SEARCH_OPER_CD, latestOpeCd );

//			//メニューから遷移した際ユーザが閲覧可能なオペレーションコードのlayouttemplateを初期表示するための設定
//			String formGrpCd = null;
//			formGrpCd = CsUtil.getOneFormGrpCd( loginNo, party, latestOpeCd );
//			bulkOperSheet.gamenCondMap.put( "formGrpCd", formGrpCd );
		} else if ("SEARCH".equals( state )) {
			bulkOperSheet.gamenCondMap = makeSrchCondMap( party );
		} else if ("CHANGE_OPERATION".equals( state )) {
			bulkOperSheet.gamenCondMap = makeSrchCondMap( party );
//			bulkOperSheet.gamenCondMap.put( "search_phase", "before_search" );

			BulkOperSheetEventResult searchResult = execEventChangeOperation( party, bulkOperSheet.gamenCondMap );
			bulkOperSheet.statusList = searchResult.statusList;

			// 500件OVERメッセージOFF
			bulkOperSheet.hitCnt = 0;

			session.setAttribute( CsSessionKey.BULK_OPER_SHEET, bulkOperSheet );

			return;
		} else if ("EXCEL_DL".equals( state )) {
			bulkOperSheet.gamenCondMap.put( "search_limit", "UNLIMITED" );
		} else if ( SU.matches( state, "CHG_STATUS ")) {
			execBulkChangeStatus( state, req );
		} else if ( SU.matches( state, "ACTOR_DEL" )) {
			execBulkDeleteActor( state, req );
		} else if ("CHG_ALL_ACT".equals( state )) {
			bulkOperSheet.gamenCondMap = makeSrchCondMap( party );
		} else {
		}

		String operationCd  = bulkOperSheet.gamenCondMap.get( "operationCd" );
//		String formGrpCd    = bulkOperSheet.gamenCondMap.get( "formGrpCd" );
//		if (SU.isBlank( formGrpCd )) {
//			formGrpCd = CsUtil.getOneFormGrpCd( loginNo, party, operationCd );
//		}
		String statusCd     = bulkOperSheet.gamenCondMap.get( "statusCd" );

		if (!SU.matches( state, "INIT|SEARCH|CHANGE_OPERATION" )) {
			operationCd = bulkOperSheet.gamenCondMap.get( "operationCd" );
//			formGrpCd   = CsUtil.getOneFormGrpCd( loginNo, party, operationCd );
			statusCd    = bulkOperSheet.gamenCondMap.get( "statusCd" );
		}

		// 自分がアクターに紐付けされているシートの一覧を取得 <<常に更新>>
//		BulkOperSheetEventResult searchResult = execEventSearch( party, operationCd, formGrpCd, statusCd, searchDiv, flowCd, bulkOperSheet.gamenCondMap, trans, opeType );
		BulkOperSheetEventResult searchResult = execEventSearch( party, operationCd, statusCd, bulkOperSheet.gamenCondMap, opeType );
		bulkOperSheet.bulkSheetList = searchResult.getSheetList();
		bulkOperSheet.statusList    = searchResult.statusList;
		bulkOperSheet.hitCnt        = searchResult.hitCnt;

		//検索されたステータスコードをセッションに格納
		session.setAttribute( CsSessionKey.BULK_OPER_SEARCH_STATUS_CD, statusCd );

		if ("EXCEL_DL".equals( state )) {
			/* CS_MULTI_SHEET (for Excel Download) */
			//session.setAttribute( CsSessionKey.CS_MULTI_SHEET_XL, bulkOperSheet );
		}
		else {
			/* CS_MULTI_SHEET */
			session.setAttribute( CsSessionKey.BULK_OPER_SHEET, bulkOperSheet );
		}
	}

	private HashMap<String, String> makeSrchCondMap( String party ) {

//		String operationCd = CsUtil.getRequestValue( request, "knskOperationCd" );
//		String operationNm = CsUtil.getCsmOperation( loginNo, party, operationCd ).getOperationNm();
//		String formGrpCd   = CsUtil.getOneFormGrpCd( loginNo, party, operationCd );
//		String formGrpNm   = CsUtil.getCsmFormGrp( loginNo, party, operationCd, formGrpCd ).getFormGrpNm();
//		String formCtgCd   = CsUtil.getRequestValue( request, "formCtgCd" );
//		String statusCd    = CsUtil.getRequestValue( request, "knskStatusCd" );
//		String tab         = CsUtil.getMultiTab( loginNo, formGrpCd, formCtgCd, statusCd );

		HashMap<String, String> srchCondMap = new HashMap<String, String>();
		srchCondMap.put( "deptNm",       CsUtil.getRequestValue( request, "knskDeptNm"       ) );
//		srchCondMap.put( "formCtgCd",    formCtgCd );
//		srchCondMap.put( "formGrpCd",    formGrpCd );
//		srchCondMap.put( "formGrpNm",    formGrpNm );
		srchCondMap.put( "operationCd",  CsUtil.getRequestValue( request, "knskOperationCd" ) );
//		srchCondMap.put( "operationNm",  operationNm );
		srchCondMap.put( "personId",     CsUtil.getRequestValue( request, "knskPersonId"     ) );
		srchCondMap.put( "personNm",     CsUtil.getRequestValue( request, "knskPersonNm"     ) );
		srchCondMap.put( "statusCd",     CsUtil.getRequestValue( request, "knskStatusCd" ) );
//		srchCondMap.put( "tab",          tab );
		srchCondMap.put( "clsCCd",       CsUtil.getRequestValue( request, "knskCmpaCd" ) );
		return srchCondMap;
	}

	private BulkOperSheetEventResult execEventPrepare( String party, String opeType ) throws CareerException {
		BulkOperSheetEventArg arg = new BulkOperSheetEventArg( loginNo, operatorGuid );
		arg.sharp = "PREPARE";
		arg.party = party;
		arg.opeType = opeType;
		arg.srchCondMap = new HashMap<String, String>();
		return BulkOperSheetEventHandler.exec( arg );
	}

	private BulkOperSheetEventResult execEventChangeOperation( String party, HashMap<String, String> srchCondMap ) throws CareerException {
		BulkOperSheetEventArg arg = new BulkOperSheetEventArg( loginNo, operatorGuid );
		arg.sharp = "CHANGE_OPERATION";
		arg.party = party;
//		arg.formGrps = null;
		arg.srchCondMap = srchCondMap; // needs operationCd
		return BulkOperSheetEventHandler.exec( arg );
	}

//	private BulkOperSheetEventResult execEventSearch( String companyCd, String operationCd, String formGrpCd, String statusCd, String searchDiv, String flowCd, HashMap<String, String> srchCondMap, String trans, String opeType ) throws CareerException {
	private BulkOperSheetEventResult execEventSearch( String companyCd, String operationCd, String statusCd, HashMap<String, String> srchCondMap, String opeType ) throws CareerException {
		BulkOperSheetEventArg arg = new BulkOperSheetEventArg( loginNo, operatorGuid );
		arg.setAll( "SEARCH", companyCd, operationCd, statusCd );
		arg.srchCondMap = srchCondMap;
//		arg.trans = trans;
		arg.opeType = opeType;
		return BulkOperSheetEventHandler.exec( arg );
	}

	private void execBulkChangeStatus( String state, final HttpServletRequest req ) throws CareerException {
		// 変更するステータス
		String operStatus = AU.getRequestValue( req, "bulk_operation_kind" );
		
		HashMap<String, String> chgStatRiyuMap = new HashMap<String, String>();
		chgStatRiyuMap.put( "change_status_reason", AU.getRequestValue( req, "Fill--change_status_reason" ));
		chgStatRiyuMap.put( "change_status_reason_text", AU.getRequestValue( req, "Fill--change_status_reason_text" ));
		
		if ( !SU.isEmpty( operStatus )) {
			HashMap<String, String> checkedMap = CsUtil.getRequestsWithRegex( req, "^multi_" );

			// チェックされているシートIDぶん、ステータス変更処理を実行
			for (String val : checkedMap.values()) {
				String[] d = val.split( "#" );
				String sheetId = d[0];
				String excKey = d[1];

				BulkOperSheetEventArg arg = new BulkOperSheetEventArg( loginNo, operatorGuid );
				arg.sharp = operStatus;
				arg.sheetId = sheetId;
				CstSheetExclusiveDto excDto = new CstSheetExclusiveDto();
				excDto.setSheetId( sheetId );
				Integer iExcKey = Integer.parseInt( CsUtil.bvl( excKey, "0" ) );
				excDto.setExclusiveKey( iExcKey );
				arg.exclusiveKey = excDto;
				arg.chgStatRiyuMap = chgStatRiyuMap;
				BulkOperSheetEventHandler.exec( arg );
			}
		}
	}

	private void execBulkDeleteActor( String state, final HttpServletRequest req ) throws CareerException {

		// 削除するアクターコード
		String delActorCd = AU.getRequestValue( req, "bulk_operation_kind" );

		if ( !SU.isEmpty( delActorCd )) {
			HashMap<String, String> checkedMap = CsUtil.getRequestsWithRegex( req, "^multi_" );

			// チェックされているシートIDぶん、評価者削除処理を実行
			for (String val : checkedMap.values()) {
				String[] d = val.split( "#" );
				String sheetId = d[0];
				String excKey = d[1];

				BulkOperSheetEventArg arg = new BulkOperSheetEventArg( loginNo, operatorGuid );
				arg.sharp = state;
				arg.sheetId = sheetId;
				arg.actorCd = delActorCd;
				CstSheetExclusiveDto excDto = new CstSheetExclusiveDto();
				excDto.setSheetId( sheetId );
				Integer iExcKey = Integer.parseInt( CsUtil.bvl( excKey, "0" ) );
				excDto.setExclusiveKey( iExcKey );
				arg.exclusiveKey = excDto;
				BulkOperSheetEventHandler.exec( arg );
			}
		}
	}
}
