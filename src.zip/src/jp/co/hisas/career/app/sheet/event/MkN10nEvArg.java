package jp.co.hisas.career.app.sheet.event;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

@SuppressWarnings("serial")
public class MkN10nEvArg extends AbstractEventArg {
	
	public String sharp = null;
	public String party = null;
	public String guid = null;
	public int seq;
	
	public MkN10nEvArg(String loginNo) throws CareerException {
		if (SU.isBlank( loginNo )) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		if (SU.isBlank( this.sharp )) {
			throw new CareerException( "Invalid Arg: sharp is null." );
		}
	}
	
}
