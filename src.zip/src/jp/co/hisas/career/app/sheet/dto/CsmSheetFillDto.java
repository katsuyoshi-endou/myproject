/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSMシート回答 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetFillDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * シートID
     */
    private String fillSetCd;
    /**
     * 会社コード
     */
    private String fillId;

    /**
     * シートIDを取得する。
     * @return シートID
     */
    public String getFillSetCd() {
        return fillSetCd;
    }

    /**
     * シートIDを設定する。
     * @param fillSetCd シートID
     */
    public void setFillSetCd(String fillSetCd) {
        this.fillSetCd = fillSetCd;
    }

    /**
     * 会社コードを取得する。
     * @return 会社コード
     */
    public String getFillId() {
        return fillId;
    }

    /**
     * 会社コードを設定する。
     * @param fillId 会社コード
     */
    public void setFillId(String fillId) {
        this.fillId = fillId;
    }

}

