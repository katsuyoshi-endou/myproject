package jp.co.hisas.career.app.sheet.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.CareerMenuBean;
import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.event.CsProgressEventArg;
import jp.co.hisas.career.app.sheet.event.CsProgressEventHandler;
import jp.co.hisas.career.app.sheet.event.CsProgressEventResult;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.framework.trans.StateTransitionEvent;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class PHD040Command extends AbstractCommand {
	
	public static final String KINOU_ID = "VHD040";
	private HttpServletRequest request;
	private HttpSession session;
	private String state;
	
	public PHD040Command() {
		super( PHD040Command.class, KINOU_ID, null );
	}
	
	public void init( StateTransitionEvent e ) {
		try {
			request = e.getRequest();
			session = request.getSession( false );
			/* Not Update Token While Single Sheet.
			CSRFTokenUtil.setNewTokenNo( request, e.getResponse() ); */
			state = request.getParameter( "state" );
			main();
		} catch (CareerException ex) {
			throw new CareerRuntimeException( ex );
		}
	}
	
	private void main() throws CareerException {
		
		if ("INIT".equals( state ) || "RESTORE".equals( state )) {
			execEventInit();
		}
		
		/* 操作ログ */
		OutLogBean.outputLogSousa( request, KINOU_ID, null, state );
	}
	
	private void execEventInit() throws CareerException {
		
		CareerMenuBean oneMenu = AU.getSessionAttr( session, AppSessionKey.CAREER_ONE_MENU );
		
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( session, UserInfoBean.SESSION_KEY );
		String operatorGuid = userInfo.getOperatorGuid();
		
		/* Set Args */
		CsProgressEventArg arg = new CsProgressEventArg( super.getLoginNo() );
		arg.sharp = "INIT";
		arg.party = oneMenu.party;
		arg.guid = operatorGuid;
		arg.isActiveOnly = true;
		arg.isBindedOnly = true;
		arg.opeType = "STAMP";
		
		/* Execute Event */
		CsProgressEventResult result = CsProgressEventHandler.exec( arg );
		
		/* Return to session */
		session.setAttribute( CsSessionKey.CS_PROGRESS, result );
		
		/* Refresh session */
		session.removeAttribute( CsSessionKey.VHD030_SRCH_COND );
	}
	
}