package jp.co.hisas.career.app.sheet.event;

import java.util.HashMap;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

@SuppressWarnings("serial")
public class MultiJinikPrepareEvRslt extends AbstractEventResult {

	private String resultMessage = null;
	private List<VCsInfoAttrDto> sheetList = null;
	private List<ValueTextSortDto> actorOptionList = null;
	private String actorCdTaskPrimary = null;
	private List<ValueTextSortDto> allowedActionList = null; 
	private HashMap<String, HashMap<String, String>> multiFillMap = null;
	private HashMap<String, HashMap<String, String>> multiFillMaskMap = null;
	public List<ValueTextSortDto> divList = null;
	public List<ValueTextSortDto> opeList = null;
	public List<ValueTextSortDto> staList = null;
	public int hitCnt;

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage( String resultMessage ) {
		this.resultMessage = resultMessage;
	}

	public List<VCsInfoAttrDto> getSheetList() {
		return sheetList;
	}

	public void setSheetList( List<VCsInfoAttrDto> sheetList ) {
		this.sheetList = sheetList;
	}

	public List<ValueTextSortDto> getActorOptionList() {
		return actorOptionList;
	}

	public void setActorOptionList( List<ValueTextSortDto> actorOptionList ) {
		this.actorOptionList = actorOptionList;
	}

	public String getActorCdTaskPrimary() {
		return actorCdTaskPrimary;
	}

	public void setActorCdTaskPrimary( String actorCdTaskPrimary ) {
		this.actorCdTaskPrimary = actorCdTaskPrimary;
	}

	public List<ValueTextSortDto> getAllowedActionList() {
		return allowedActionList;
	}

	public void setAllowedActionList( List<ValueTextSortDto> allowedActionList ) {
		this.allowedActionList = allowedActionList;
	}

	public HashMap<String, HashMap<String, String>> getMultiFillMap() {
		return multiFillMap;
	}

	public void setMultiFillMap( HashMap<String, HashMap<String, String>> multiFillMap ) {
		this.multiFillMap = multiFillMap;
	}

	public HashMap<String, HashMap<String, String>> getMultiFillMaskMap() {
		return multiFillMaskMap;
	}

	public void setMultiFillMaskMap( HashMap<String, HashMap<String, String>> multiFillMaskMap ) {
		this.multiFillMaskMap = multiFillMaskMap;
	}

}