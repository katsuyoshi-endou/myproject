package jp.co.hisas.career.app.sheet.servlet;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import org.apache.commons.fileupload.FileItem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.event.MultiEditJinikUploadEvArg;
import jp.co.hisas.career.app.sheet.event.MultiEditJinikUploadEvHdlr;
import jp.co.hisas.career.app.sheet.event.MultiEditJinikUploadEvRslt;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.FileUploadServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.CommonLabel;

public class MultiEditJinikUploadServlet extends FileUploadServlet {

	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "VSHJIN";
	private static final String FORWARD_PAGE = "/servlet/MultiEditJinikServlet";

	@Override
	public String serviceMain( Tray tray ) throws Exception {
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( tray.session, UserInfoBean.SESSION_KEY );
		tray.operatorGuid = userInfo.getOperatorGuid();

		@SuppressWarnings("unchecked")
		Map<String, FileItem> paramMap = (Map<String, FileItem>)tray.request.getAttribute( "paramMap" );

		MultiEditJinikUploadEvRslt result = reserveExcelUploadFile( tray, paramMap.get( "excelFile" ) );

		tray.request.setAttribute( CsSessionKey.VSHJIN_UPLOAD_RESULT_MSG, result.resultMsg );

		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, tray.state );

		// 「表示」ボタンを押下したときと同じ挙動にさせる（ STATE = 'SHOW'で呼び出さない ）
		tray.request.setAttribute( "state", "RELOAD" );

		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}

	private MultiEditJinikUploadEvRslt reserveExcelUploadFile( Tray tray, FileItem file ) throws  CareerException, IOException {

		MultiEditJinikUploadEvRslt result = new MultiEditJinikUploadEvRslt();

		InputStream fis = null;

		try {
			fis = file.getInputStream();

			Workbook workbook = WorkbookFactory.create( fis );

			Sheet sheet = workbook.getSheetAt( 1 );

			Row row = sheet.getRow( 3 );

			String chkStatus = SU.nvl( getStringValue( row.getCell( 1 )), "" );
			if ( SU.equals( chkStatus, "アップロード可" )) {
				execReserve( tray, file );
				result.resultMsg = CommonLabel.getLabel( "LSHJIN_MSG_ACCEPT_FILE_RESERVE" );
			} else {
				result.resultMsg = CommonLabel.getLabel( "LSHJIN_MSG_DISMISS_FILE_RESERVE" );
			}
		} catch ( CareerException e) {
			throw e;
		} catch( Exception e ) {
			throw new CareerException( e.getMessage());
		} finally {
			fis.close();
		}
		return result;
	}

	private MultiEditJinikUploadEvRslt execReserve( Tray tray, FileItem file) throws CareerException {

		MultiEditJinikUploadEvArg arg = new MultiEditJinikUploadEvArg( tray.loginNo );

		arg.sharp = "RESERVE";
		arg.rsvGuid = tray.loginNo;
		arg.rsvFileName= file.getName();
		arg.rsvFileContentType = file.getContentType();
		arg.rsvStatus = null;
		arg.uploadFile = new File( file.getName());

		return MultiEditJinikUploadEvHdlr.exec( arg );
	}

	private static String getStringValue( Cell cell ) throws CareerException {
		if (cell == null) {
			return null;
		}
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_NUMERIC:
			return Integer.toString( Integer.valueOf( (int)cell.getNumericCellValue() ) );
		case Cell.CELL_TYPE_STRING:
			return cell.getStringCellValue();
		case Cell.CELL_TYPE_FORMULA:
			throw new CareerException( "セルのタイプが式のものには対応していません。" );
		case Cell.CELL_TYPE_BLANK:
			return null;
		case Cell.CELL_TYPE_BOOLEAN:
			return Boolean.toString( cell.getBooleanCellValue() );
		case Cell.CELL_TYPE_ERROR:
			throw new CareerException( "セルにエラーがあります。" );
		default:
			return null;
		}
	}

}
