/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CsmSheetOperationDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * CSMシート運用 Data Access Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetOperationDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " PARTY as party,"
                     + " OPERATION_CD as operationCd,"
                     + " OPERATION_NM as operationNm,"
                     + " OPERATION_TYPE as operationType,"
                     + " LPAD_SORT as lpadSort,"
                     + " OPEN_FLG as openFlg,"
                     + " ACTIVE_FLG as activeFlg"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public CsmSheetOperationDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public CsmSheetOperationDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * 全列update文を実行する。
     * @param dto CSM_SHEET_OPERATIONのレコード型データ。
     */
    public void update(CsmSheetOperationDto dto) {

        final String sql = "UPDATE CSM_SHEET_OPERATION SET "
                         + "OPERATION_NM = ?,"
                         + "OPERATION_TYPE = ?,"
                         + "LPAD_SORT = ?,"
                         + "OPEN_FLG = ?,"
                         + "ACTIVE_FLG = ?"
                         + " WHERE PARTY = ?"
                         + " AND OPERATION_CD = ?"
                         ;
        Log.sql("【DaoMethod Call】 CsmSheetOperationDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getOperationNm());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getOperationType());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getLpadSort());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getOpenFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getActiveFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getParty());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getOperationCd());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param party PARTY
     * @param operationCd OPERATION_CD
     * @return CsmSheetOperationDto CSM_SHEET_OPERATIONのレコード型データ。
     */ 
    public CsmSheetOperationDto select(String party, String operationCd) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CSM_SHEET_OPERATION"
                         + " WHERE PARTY = ?"
                         + " AND OPERATION_CD = ?"
                         ;
        Log.sql("【DaoMethod Call】 CsmSheetOperationDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, party);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, operationCd);
            rs = pstmt.executeQuery();
            CsmSheetOperationDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<CsmSheetOperationDto> CSM_SHEET_OPERATIONのレコード型データのリスト。
     */ 
    public List<CsmSheetOperationDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 CsmSheetOperationDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CsmSheetOperationDto> lst = new ArrayList<CsmSheetOperationDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<CsmSheetOperationDto> CSM_SHEET_OPERATIONのレコード型データのリスト。
     */ 
    public List<CsmSheetOperationDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 CsmSheetOperationDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private CsmSheetOperationDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmSheetOperationDto dto = new CsmSheetOperationDto();
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setOperationCd(DaoUtil.convertNullToString(rs.getString("operationCd")));
        dto.setOperationNm(DaoUtil.convertNullToString(rs.getString("operationNm")));
        dto.setOperationType(DaoUtil.convertNullToString(rs.getString("operationType")));
        dto.setLpadSort(DaoUtil.convertNullToString(rs.getString("lpadSort")));
        dto.setOpenFlg(DaoUtil.convertNullToString(rs.getString("openFlg")));
        dto.setActiveFlg(DaoUtil.convertNullToString(rs.getString("activeFlg")));
        return dto;
    }

}

