package jp.co.hisas.career.app.sheet.event;

import java.util.HashMap;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;

@SuppressWarnings("serial")
public class MultiJinikPrepareEvArg extends AbstractEventArg {
	
	public String sharp = null;
	public String operatorGuid = null;
	public HashMap<String, String> srchCondMap = null;
	public String party = null;
	public String operationCd = null;
	public String opeType = null;
	
	public MultiJinikPrepareEvArg(String loginNo, String operatorGuid) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		if (operatorGuid == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
		this.operatorGuid = operatorGuid;
	}
	
	public void setAll( String sharp, String party, String operationCode ) {
		this.sharp = sharp;
		this.party = party;
		this.operationCd = operationCode;
	}
	
	public void validateArg() throws CareerException {
		if (this.sharp == null || "".equals( this.sharp.trim() )) {
			throw new CareerException( "Invalid Arg: state is null." );
		}
	}
	
}
