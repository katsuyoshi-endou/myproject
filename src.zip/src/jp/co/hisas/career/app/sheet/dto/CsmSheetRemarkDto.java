/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * CSM_SHEET_REMARK Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class CsmSheetRemarkDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * フローコード
     */
    private String rangeCd;
    /**
     * フローパターン
     */
    private Integer rangeFr;
    /**
     * ステータスコード
     */
    private Integer rangeTo;
    /**
     * アクターコード
     */
    private String remark;

    /**
     * フローコードを取得する。
     * @return フローコード
     */
    public String getRangeCd() {
        return rangeCd;
    }

    /**
     * フローコードを設定する。
     * @param rangeCd フローコード
     */
    public void setRangeCd(String rangeCd) {
        this.rangeCd = rangeCd;
    }

    /**
     * フローパターンを取得する。
     * @return フローパターン
     */
    public Integer getRangeFr() {
        return rangeFr;
    }

    /**
     * フローパターンを設定する。
     * @param rangeFr フローパターン
     */
    public void setRangeFr(Integer rangeFr) {
        this.rangeFr = rangeFr;
    }

    /**
     * ステータスコードを取得する。
     * @return ステータスコード
     */
    public Integer getRangeTo() {
        return rangeTo;
    }

    /**
     * ステータスコードを設定する。
     * @param rangeTo ステータスコード
     */
    public void setRangeTo(Integer rangeTo) {
        this.rangeTo = rangeTo;
    }

    /**
     * アクターコードを取得する。
     * @return アクターコード
     */
    public String getRemark() {
        return remark;
    }

    /**
     * アクターコードを設定する。
     * @param remark アクターコード
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

}

