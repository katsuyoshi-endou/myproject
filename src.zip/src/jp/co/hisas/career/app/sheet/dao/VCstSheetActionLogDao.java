/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dto.VCstSheetActionLogDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * V_CSTシートアクションログ Data Access Object。
 * @author CareerDaoTool.xla
*/
public class VCstSheetActionLogDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " TIMESTAMP as timestamp,"
                     + " SHEET_ID as sheetId,"
                     + " PERSON_NAME as personName,"
                     + " ACTOR_NM as actorNm,"
                     + " STATUS_NM as statusNm,"
                     + " ACTION_CD as actionCd,"
                     + " ACTION_NM as actionNm,"
                     + " DELIV_MSG as delivMsg"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public VCstSheetActionLogDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public VCstSheetActionLogDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private VCstSheetActionLogDto transferRsToDto(ResultSet rs) throws SQLException {

        VCstSheetActionLogDto dto = new VCstSheetActionLogDto();
        dto.setTimestamp(DaoUtil.convertNullToString(rs.getString("timestamp")));
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setPersonName(DaoUtil.convertNullToString(rs.getString("personName")));
        dto.setActorNm(DaoUtil.convertNullToString(rs.getString("actorNm")));
        dto.setStatusNm(DaoUtil.convertNullToString(rs.getString("statusNm")));
        dto.setActionCd(DaoUtil.convertNullToString(rs.getString("actionCd")));
        dto.setActionNm(DaoUtil.convertNullToString(rs.getString("actionNm")));
        dto.setDelivMsg(DaoUtil.convertNullToString(rs.getString("delivMsg")));
        return dto;
    }

    /**
     * シートIDを指定してアクションログを全て取得します。
     * @param sheetId シートID
     * @return List<VCstSheetActionLogDto> V_CST_SHEET_ACTION_LOGのレコード型データのリスト。
     */
    public List<VCstSheetActionLogDto> getActionLoglist(String sheetId) {

        final String sql = "select " + ALLCOLS + " from V_CST_SHEET_ACTION_LOG WHERE SHEET_ID = ? order by TIMESTAMP DESC";
        Log.sql("【DaoMethod Call】 VCstSheetActionLogDao.getActionLoglist");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            rs = pstmt.executeQuery();
            List<VCstSheetActionLogDto> lst = new ArrayList<VCstSheetActionLogDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

