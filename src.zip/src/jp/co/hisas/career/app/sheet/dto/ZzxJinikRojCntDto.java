/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

/**
 * ZZX_JINIK_ROJ_CNT Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class ZzxJinikRojCntDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ROJ_PTN
     */
    private String rojPtn;
    /**
     * ROJ_PTN_CNT
     */
    private Integer rojPtnCnt;

    /**
     * ROJ_PTNを取得する。
     * @return ROJ_PTN
     */
    public String getRojPtn() {
        return rojPtn;
    }

    /**
     * ROJ_PTNを設定する。
     * @param rojPtn ROJ_PTN
     */
    public void setRojPtn(String rojPtn) {
        this.rojPtn = rojPtn;
    }

    /**
     * ROJ_PTN_CNTを取得する。
     * @return ROJ_PTN_CNT
     */
    public Integer getRojPtnCnt() {
        return rojPtnCnt;
    }

    /**
     * ROJ_PTN_CNTを設定する。
     * @param rojPtnCnt ROJ_PTN_CNT
     */
    public void setRojPtnCnt(Integer rojPtnCnt) {
        this.rojPtnCnt = rojPtnCnt;
    }

}

