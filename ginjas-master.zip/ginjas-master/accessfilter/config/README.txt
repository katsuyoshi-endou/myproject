■$NEXUS_HOME/etc
・nexus-default.properties

■$NEXUS_HOME/etc/jetty
・jetty.xml
・nexus-web.xml

■$NEXUS_DATA/etc/logback
・logback-overrides.xml
