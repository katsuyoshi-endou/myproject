package jp.scsk.ginjas.filter.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.scsk.ginjas.filter.AccessFilter;

public class BlacklistDao {
    private static final Logger LOG = LoggerFactory.getLogger(AccessFilter.class);
    private static final String BLACKLIST_SQL = "SELECT path FROM access_blacklist";

    public static Map<String, Boolean> getBlacklist(String jdbcUrl, String dbUser, String dbPassword) {
	Map<String, Boolean> result = new HashMap<>();

	try (
		Connection con = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(BLACKLIST_SQL);
		) {
	    while (rs.next()) {
		result.put(rs.getString(1), Boolean.TRUE);
	    }
	} catch (SQLException e) {
	    LOG.error("DB access error", e);
	}
	return result;
    }

    private BlacklistDao() {
	super();
    }

}
