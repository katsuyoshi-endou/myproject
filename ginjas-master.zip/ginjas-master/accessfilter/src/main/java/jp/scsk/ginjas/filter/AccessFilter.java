package jp.scsk.ginjas.filter;

import java.io.IOException;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import jp.scsk.ginjas.filter.db.BlacklistDao;;

public class AccessFilter implements Filter {
    private static final Logger LOG = LoggerFactory.getLogger(AccessFilter.class);
    private long lastloadTimestamp;

    /**
     * 初期化パラメータ
     */
    public static final String PARAM_ADMIN_USER = "adminUser";
    public static final String PARAM_PATH_PREFIX = "pathPrefix";
    public static final String PARAM_JDBC_DRIVER = "jdbcDriver";
    public static final String PARAM_JDBC_URL = "jdbcUrl";
    public static final String PARAM_DB_USER = "dbUser";
    public static final String PARAM_DB_PASSWORD = "dbPassword";
    public static final String PARAM_UPDATE_BLACKLIST = "updateBlacklist";
    private String adminUser;
    private String pathPrefix;
    private String jdbcDriver;
    private String jdbcUrl;
    private String dbUser;
    private String dbPassword;
    private int updateBlacklist;

    private boolean initialized = false;
    private ConcurrentMap<String, Boolean> blacklsit = new ConcurrentHashMap<>();

    private void initializeBlacklist() {
	Map<String, Boolean> result = BlacklistDao.getBlacklist(this.jdbcUrl, this.dbUser, this.dbPassword);
	if (!result.isEmpty()) {
	    blacklsit.clear();
	    blacklsit.putAll(result);
	    this.lastloadTimestamp = System.currentTimeMillis();
	    this.initialized = true;

	    LOG.info("Blacklist Loaded");

	}
    }

    @Override
    /**
     * アクセス制御フィルタの初期設定を行う
     *
     * ・管理者ユーザ: adminUser ・対象パス: pathPrefix ・DB設定（jdbcUrl, dbUser, dbPassword)
     *
     * @param config
     * @throws ServletException
     */
    public void init(FilterConfig config) throws ServletException {
	this.adminUser = config.getInitParameter(PARAM_ADMIN_USER);
	this.pathPrefix = config.getInitParameter(PARAM_PATH_PREFIX);
	this.jdbcUrl = config.getInitParameter(PARAM_JDBC_URL);
	this.jdbcDriver = config.getInitParameter(PARAM_JDBC_DRIVER);
	this.dbUser = config.getInitParameter(PARAM_DB_USER);
	this.dbPassword = config.getInitParameter(PARAM_DB_PASSWORD);
	this.updateBlacklist = Integer.parseInt(config.getInitParameter(PARAM_UPDATE_BLACKLIST));

	if (LOG.isDebugEnabled()) {
	    LOG.debug("adminUser: " + this.adminUser);
	    LOG.debug("pathPrefix: " + this.pathPrefix);
	    LOG.debug("jdbcUrl: " + this.jdbcUrl);
	    LOG.debug("jdbcDriver: " + this.jdbcDriver);
	    LOG.debug("dbUser: " + this.dbUser);
	    LOG.debug("dbPassword: " + this.dbPassword);
	    LOG.debug("updateBlacklist: " + this.updateBlacklist);
	}

	try {
	    Class.forName(jdbcDriver);
	    LOG.info("JDBC Driver Loaded: " + jdbcDriver);

	    initializeBlacklist();

	} catch (ClassNotFoundException e) {
	    LOG.error("JDBC Driver CANNOT load: " + jdbcDriver, e);
	}

    }

    @Override
    public void destroy() {
	blacklsit.clear();
	initialized = false;
    }

    /**
     * Authorization: ヘッダからユーザ名を取得。
     *
     * @param authorization
     * @return
     */
    private String getUser(String authorization) {
	String result = "";
	if (authorization != null && !authorization.isEmpty()) {
	    authorization = authorization.replace("Basic ", "");
	    String credential = new String(Base64.getDecoder().decode(authorization));
	    result = credential.split(":")[0];
	}
	return result;

    }

    @Override
    /**
     * アクセス制御を行う。
     *
     * 1. Authorizationヘッダが無ければ何もしない
     * 2. 管理者ユーザの場合何もしない
     * 3. パス(URLからスキーマ、ホスト名、ポート番号を除いたもの)がDBに登録されていればHTTP 403 Forbiddenを返す
     * 4. 次のフィルタに処理を移譲
     *
     * ※検討課題 ログ出力、DB登録情報のアップデート、特定のユーザだけ
     *
     * @param req
     * @param res
     * @param chain
     * @throws IOException
     * @throws ServletException
     */
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
	    throws IOException, ServletException {
	try {
	    if (!this.initialized || doAccessCheck(req, res)) {
		chain.doFilter(req, res);
	    }
	} finally {
	    MDC.remove("ginjasUserId");
	}
    }

    private boolean containsBlacklist(String path) {
	if (System.currentTimeMillis() > (this.lastloadTimestamp + this.updateBlacklist)) {
	    initializeBlacklist();
	}
	return Boolean.TRUE == blacklsit.get(path);
    }
    private boolean doAccessCheck(ServletRequest req, ServletResponse res) throws IOException {
	if (initialized && req instanceof HttpServletRequest && res instanceof HttpServletResponse) {
	    HttpServletRequest request = (HttpServletRequest) req;
	    HttpServletResponse response = (HttpServletResponse) res;
	    String header = request.getHeader("Authorization");
	    if (header != null) {
		// String userName = request.getRemoteUser();
		// System.out.println("USER: " + request.getRemoteUser());
		String user = getUser(header);
		if (user != null && !user.isEmpty()) {
		    MDC.put("ginjasUserId", user);
		}
		String url = request.getRequestURL().toString();
		String path = url.replaceFirst("https?://[^/]+", "");
		if (LOG.isDebugEnabled()) {
		    LOG.debug("User: " + user);
		    LOG.debug("URL: " + url);
		    LOG.debug("Path: " + path);
		}
		if (!this.adminUser.equals(user) && path.startsWith(this.pathPrefix) && containsBlacklist(path)) {
		    LOG.warn("Access denied: [" + path + "]");
		    response.sendError(HttpServletResponse.SC_FORBIDDEN, "Forbidden / Access denied by Ginjas");
		    return false;
		}
	    }
	}
	return true;
    }

}
