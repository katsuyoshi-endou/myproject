package jp.scsk.ginjas.filter.db;

import java.util.Map;

import junit.framework.TestCase;

public class BlacklistDaoTest extends TestCase {

    protected void setUp() throws Exception {
	super.setUp();
	Class.forName("org.postgresql.Driver");
    }

    protected void tearDown() throws Exception {
	super.tearDown();
    }

    public void testGetBlacklist() {
	Map<String, Boolean> result = BlacklistDao.getBlacklist("jdbc:postgresql://localhost:5432/appdb", "postgres", "passw0rd");
	assertNotNull(result);
	for (Map.Entry<String, Boolean> entry : result.entrySet()) {
	    System.out.println(entry.getKey());
	}
    }

}
