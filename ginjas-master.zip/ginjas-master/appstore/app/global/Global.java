package global;

import javax.inject.Inject;

import play.api.inject.ApplicationLifecycle;

public class Global {
	//TODO: どうやって移行するか
//public class Global extends GlobalSettings {

//	@Override
//	public void onStart(Application app) {
//		Logger.info("アプリケーション起動しました");
//	}

	/*
	 * @Override public <T extends EssentialFilter> Class<T>[] filters() {
	 * return new Class[]{ CSRFFilter.class }; }
	 */

	@Inject
	public Global(ApplicationLifecycle lifecycle) {
//		lifecycle.addStopHook(new CompletableFuture()) {
//
//			@Override
//			public Promise<Void> call() throws Exception {
//				Logger.info("アプリケーション停止します");
//				return null;
//			}
//		});
	}
//	@Override
//	public void onStop(Application app) {
//		Logger.info("アプリケーション停止します");
//	}
/*
	@Override
	public Action<?> onRequest(Request request, Method method) {
		if (Play.isProd()) {
			return new BasicAuthAction(super.onRequest(request, method));
		} else {
			return super.onRequest(request, method);
		}
	}
*/
}
