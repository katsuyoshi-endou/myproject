package models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Model;
import com.avaje.ebean.SqlRow;
import com.avaje.ebean.annotation.Where;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
public class Dept extends Model {
	@JsonProperty("id")
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dept_id_seq")
	public Long id;

	@JsonProperty("text")
	public String name;

	@JsonProperty("fullText")
	public String fullName;

	@JsonIgnore
	@ManyToOne///*(cascade = CascadeType.ALL)*/(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	@JoinColumn(name = "parent_id")
	public Dept parent;

	@JsonProperty("children")
//	@OneToMany(cascade = CascadeType.ALL, mappedBy = "parent")
	@OneToMany(mappedBy = "parent")
	@Where(clause="not (name like '%ＡＣ%' or name like '%Ａ／Ｃ%')")
	public List<Dept> childs = new ArrayList<>();

	@JsonIgnore
	@ManyToMany(cascade = CascadeType.ALL,
			mappedBy = "depts")
	public List<User> users;

	@JsonIgnore
	@OneToMany(cascade = CascadeType.ALL,
		mappedBy = "dept")
	public List<Project> projects = new ArrayList<>();

	public static Finder<Long, Dept> find = new Finder<Long, Dept>(Dept.class);

	public void dump() {
		System.out.println(name + " " + fullName + ": [" + (parent != null ? parent.name: "親なし") + "] "+ childs.size() + ": " + users.size());
		for (Dept d: childs) {
			d.dump();
		}
	}

	public static Dept findByDeptId(Long deptId){
		return Dept.find.where().eq("id", deptId).findList().get(0);
	}

	public static List<SqlRow> findByUser(Long userid) {
		String sql = "select dept.full_name, dept.id, udept.is_primary_dept from user_dept as udept, dept where udept.dept_id = dept.id and udept.user_id = :userid";

		List<SqlRow> sqlrows = Ebean.createSqlQuery(sql).setParameter("userid", userid).findList();

		return sqlrows;
	}

	/**
	 * 指定したユーザの一番の所属部署を返す</br>
	 * 複数設定されていることはないが、見つかったデータの１番目を返す。
	 *
	 * @param uid ユーザID
	 * @return　所属部署ID</br>見つからなかった場合は 0を返す
	 */
	public static Long getPrimaryDeptId(Long uid) {
		String sql = "select udept.dept_id from user_dept as udept where udept.user_id =:userid and udept.is_primary_dept = true";

		List<SqlRow> result = Ebean.createSqlQuery(sql).setParameter("userid", uid).findList();

		Long ret = (long)0;
		if(result.size() > 0) {
			ret = result.get(0).getLong("dept_id");
		}
		return ret;
	}

	/**
	 * 指定したユーザーIDにもとづいて参照可能な部門を取得する。
	 *
	 * @param userid
	 * @return
	 */
	public static List<SqlRow> getSelectableSection(Long userid) {
		StringBuilder sb = new StringBuilder();

		sb.append("select ");
		sb.append("  dept.id, ");
		sb.append("  case ");
		sb.append("    when dept.parent_id is not null then dept.parent_id ");
		sb.append("    else 1 ");
		sb.append("  end as parent_id, ");
		sb.append("  dept.full_name, ");
		sb.append("  dept.code ");
		sb.append("from dept, ");
		sb.append("( ");
		sb.append("  select dept.id, dept.code, substr(dept.code, 1, 6) as dept_code from dept where dept.id in ( ");
		sb.append("    select dept_id from user_dept as a where a.user_id = :user_id ");
		sb.append("  ) ");
		sb.append(") as a ");
		sb.append("where dept.code = a.dept_code ");
		sb.append("group by dept.id, parent_id ");

//		sb.append("with recursive ancestor (depth, id, parent_id) as ( ");
//		sb.append("  select 0, dept.id, dept.parent_id, dept.full_name, dept.code from dept where dept.id in ( ");
//		sb.append("    select dept_id from user_dept as a where a.user_id = :user_id ");
//		sb.append("  ) ");
//		sb.append("  union all ");
//		sb.append("    select ");
//		sb.append("      ancestor.depth + 1, ");
//		sb.append("      dept.id, ");
//		sb.append("      dept.parent_id, ");
//		sb.append("      dept.full_name, ");
//		sb.append("      dept.code ");
//		sb.append("    from ancestor, dept ");
//		sb.append("    where ancestor.parent_id = dept.id ");
//		sb.append(") ");
//		sb.append("select depth, id, full_name, code from ancestor ");
//		sb.append("where depth = 3 ");
//		sb.append("and id <> 1 ");
//		sb.append("order by depth; ");

		String sql = sb.toString();
		return Ebean.createSqlQuery(sql).setParameter("user_id", userid).findList();
	}
}

