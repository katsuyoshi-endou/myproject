package models;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Model;
import com.avaje.ebean.SqlQuery;
import com.avaje.ebean.SqlRow;

import controllers.Application;
import play.Logger;
import play.data.validation.Constraints;

@Entity
public class Project extends Model {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "project_seq")
    public Long id;

    @Constraints.Required
    public String trueName; /*
			     * In reality, this would be something cryptic such
			     * as "project code" or "project ID"
			     */

    public String nickName;
    public String description;
    public Date startedOn;
    public Date endedOn;
    public boolean hasRetired;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "dept_id")
    public Dept dept;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "project_manager",
		joinColumns = { @JoinColumn(name = "project_id", referencedColumnName = "id") },
		inverseJoinColumns = { @JoinColumn(name = "user_id", referencedColumnName = "id") }
	)
    public List<User> managers;

    public static Finder<Long, Project> find = new Finder<Long, Project>(Project.class);

    public static Project findById(Long id) {
        return find.byId(id);
    }

    /**
     * プロジェクト情報(project, project_user)を新規作成する
     *
     * @param prjName プロジェクト名
     * @param prjDesc プロジェクトに関する説明
     * @param deptId 所属部署ID
     * @param lUserId ユーザID
     */
    public static int saveProject( String prjName, String prjDesc, Long deptId, Long lUserId, String[] managers) {
    	Ebean.beginTransaction();

    	int nRet =0;
    	try {
    		String sql = "select count(*) as cnt from project as prj where prj.dept_id = :deptid and prj.nick_name = :prjname";
    		SqlQuery query = Ebean.createSqlQuery(sql);
    		query.setParameter("deptid", deptId);
    		query.setParameter("prjname", prjName);
    		List<SqlRow> result = query.findList();

    		if(result.get(0).getInteger("cnt") != 0) {
    			nRet = 1;
    			return nRet;
    		}

    		Project newPrj = new Project();

			newPrj.trueName = prjName;
			newPrj.nickName = prjName;
			newPrj.description = prjDesc;
			newPrj.startedOn = new Date();
			newPrj.endedOn = null;
			newPrj.hasRetired = false;
			newPrj.dept = Dept.findByDeptId((deptId));

			newPrj.managers = new ArrayList<User>();
			for(String id : managers) {
				Long uid = Long.valueOf(id);

				User user = User.findById(uid);
				newPrj.managers.add(user);
			}

			newPrj.save();

			Ebean.commitTransaction();
		} catch(Exception ex) {
    	    Logger.info(ex.getMessage());

    	    Ebean.rollbackTransaction();
    	    nRet = -1;
		} finally {
			Ebean.endTransaction();
		}
    	return nRet;
    }

	/**
	 * プロジェクト情報を検索する</br>
	 * 指定したユーザが参加設定をしているプロジェクト情報を取得する
	 *
	 * @param userId ユーザID
	 * @return　みつかったプロジェクト情報
	 */
	public static List<SqlRow> getUserProject(Long userId) {
		StringBuilder sb = new StringBuilder();

		sb.append("select ");
		sb.append("  join_prj.id, ");
		sb.append("  join_prj.nick_name, ");
		sb.append("  join_prj.description, ");
		sb.append("  join_prj.full_name, ");
		sb.append("  case ");
		sb.append("    when a.is_primary_dept = true then '2' ");
		sb.append("    when a.is_primary_dept = false then '1' ");
		sb.append("    else '0' ");
		sb.append("  end as is_primary_dept, ");
		sb.append("  '1' as joined ");
		sb.append("from ");
		sb.append("( ");
		sb.append("  select * from user_dept where user_dept.user_id = :userid ");
		sb.append(") as a right join ");
		sb.append("( ");
		sb.append("  select pu.*, prj.id, prj.nick_name, prj.description, prj.dept_id, prj.full_name, prj.code ");
		sb.append("  from project_user as pu ");
		sb.append("    left join ");
		sb.append("    ( ");
		sb.append("      select project.id, project.nick_name, project.description, project.dept_id, dept.full_name, dept.code from project left join dept on project.dept_id = dept.id ");
		sb.append("    ) as prj on pu.project_id = prj.id ");
		sb.append("  where user_id = :userid ");
		sb.append(") as join_prj on a.dept_id = join_prj.dept_id ");
		sb.append("order by joined desc, is_primary_dept desc, code asc, nick_name asc ");


//		sb.append("select ");
//		sb.append("  a.project_id as id, ");
//		sb.append("  a.nick_name, ");
//		sb.append("  a.description, ");
//		sb.append("  a.full_name, ");
//		sb.append("  a.code, ");
//		sb.append("  case ");
//		sb.append("    when ud.is_primary_dept = true then '2' ");
//		sb.append("    when ud.is_primary_dept = false then '1' ");
//		sb.append("    else '0' ");
//		sb.append("  end as is_primary_dept, ");
//		sb.append("  '1' as joined ");
//		sb.append("from user_dept as ud right join ");
//		sb.append("( ");
//		sb.append("  select pu.user_id, pu.project_id, prj.id, prj.nick_name, prj.description, prj.dept_id, prj.full_name, prj.code from project_user as pu left join ");
//		sb.append("  ( ");
//		sb.append("    select p.id, p.nick_name, p.description, p.dept_id, d.full_name, d.code from project as p ");
//		sb.append("      left join dept as d on p.dept_id = d.id ");
//		sb.append("  ) as prj on pu.project_id = prj.id ");
//		sb.append("  where pu.user_id = :userid ");
//		sb.append(") as a on ud.dept_id = a.dept_id ");
//		sb.append("where (ud.user_id = :userid or ud.user_id is null) ");
//		sb.append("order by joined desc, is_primary_dept desc, code asc, nick_name asc ");

		String sql = sb.toString();

		List<SqlRow> sqlrows = Ebean.createSqlQuery(sql).setParameter("userid", userId).findList();

		return sqlrows;
	}

	/**
	 * プロジェクト情報を検索する</br>
	 * 指定したユーザが所属する部署内の参加設定をしているプロジェクト情報を取得する</br>
	 *
	 *
	 * @param userid ユーザID
	 * @param deptid 所属部署ID
	 * @return 見つかったプロジェクト情報
	 */
	public static List<SqlRow> getProjectByUser(Long userid, Long deptid) {
		String sql = "select prj.id, prj.nick_name, prj.description, COALESCE(puser.project_id,0) as joined from project as prj full outer join project_user as puser on prj.id = puser.project_id where puser.user_id = :userid and prj.dept_id = :deptid order by prj.id";

		SqlQuery query = Ebean.createSqlQuery(sql);
		query.setParameter("userid", userid);
		query.setParameter("deptid", deptid);

		return query.findList();
	}

	/**
	 *
	 *
	 * @param uid
	 * @return
	 */
	public static List<SqlRow> getJoinProjectByUser(Long uid) {
		String sql = "select guser.current_project_id, puser.project_id, prj.nick_name from ginjasuser as guser, project_user as puser, project as prj where guser.id = :userid and guser.id = puser.user_id and puser.project_id = prj.id order by puser.project_id";

		List<SqlRow> result = Ebean.createSqlQuery(sql).setParameter("userid", uid).findList();

		return result;
	}

	/**
	 * プロジェクト情報を検索する</br>
	 * 指定したユーザが所属する部署配下にプロジェクト名が（部分）一致するプロジェクト情報を参加設定の有無にかかわらず取得する
	 *
	 * @param userid ユーザID
	 * @param deptid 所属部署ID
	 * @param srchStr （プロジェクト名）検索文字列
	 * @return 見つかったプロジェクト情報の一覧をList<SqlRow>で返す
	 */
	public static List<SqlRow> getProjectByName(Long userid, Long deptid, String srchStr) {
		StringBuilder sb = new StringBuilder();

//		String sql = "select prj.id, prj.nick_name, prj.description, COALESCE(puser.project_id,0) as joined from project as prj full outer join project_user as puser on prj.id = puser.project_id and puser.user_id = :userid where prj.dept_id = :deptid and prj.nick_name like :nickname order by prj.id";

//		sb.append(" select a.id, a.nick_name, a.full_name, a.description, a.dept_id, COALESCE(pu.user_id, 0) as joined ");
//		sb.append(" from project_user as pu right outer join ");
//		sb.append(" ( ");
//		sb.append("   select p.id, p.true_name, p.nick_name, d.full_name, p.description, p.dept_id from project as p, dept as d where p.dept_id = d.id and p.dept_id in ");
//		sb.append("   ( ");
//		sb.append("     with recursive r as ");
//		sb.append("     ( ");
//		sb.append("       select * from dept where dept.id = :deptid ");
//		sb.append("         union all ");
//		sb.append("           select dept.* from dept, r where dept.parent_id = r.id ");
//		sb.append("     )  select r.id from r ");
//		sb.append("     where not(r.name like '%ＡＣ%' or r.name like '%Ａ／Ｃ%' or r.name like '%賃貸家賃%') ");
//		sb.append("     order by id ");
//		sb.append("   ) ");
//		sb.append(" ) as a ");
//		sb.append(" on pu.project_id = a.id and pu.user_id = :uid ");
//		sb.append(" where a.nick_name like :nick_name escape '#' ");
//		sb.append(" order by id desc ");


		sb.append("select ");
		sb.append("  p.id, ");
		sb.append("  p.nick_name, ");
		sb.append("  p.description, ");
		sb.append("  p.full_name, ");
		sb.append("  p.dept_id, ");
		sb.append("  p.dept_code, ");
		sb.append("  p.is_primary_dept, ");
		sb.append("  case ");
		sb.append("    when pu.user_id is null then '0' ");
		sb.append("    else '1' ");
		sb.append("  end as joined ");
		sb.append("from ");
		sb.append("( ");
		sb.append("  select * from project_user where project_user.user_id = :uid ");
		sb.append(") as pu right join ");
		sb.append("( ");
		sb.append("  select ");
		sb.append("    prj.id, ");
		sb.append("    prj.nick_name, ");
		sb.append("    prj.description, ");
		sb.append("    prj.full_name, ");
		sb.append("    prj.dept_id, ");
		sb.append("    prj.dept_code, ");
		sb.append("    case ");
		sb.append("      when ud.is_primary_dept = true then 2 ");
		sb.append("      when ud.is_primary_dept = false then 1 ");
		sb.append("      else 0 ");
		sb.append("    end as is_primary_dept ");
		sb.append("  from ");
		sb.append("  ( ");
		sb.append("    select * from user_dept where user_dept.user_id = :uid ");
		sb.append("  ) as ud right join ");
		sb.append("  ( ");
		sb.append("    select ");
		sb.append("      prj.id as id, ");
		sb.append("      prj.nick_name as nick_name, ");
		sb.append("      prj.description as description, ");
		sb.append("      sec.id as dept_id, ");
		sb.append("      sec.full_name as full_name, ");
		sb.append("      sec.code as dept_code ");
		sb.append("    from project as prj, ");
		sb.append("    ( ");
		sb.append("      with recursive r as ");
		sb.append("      ( ");
		sb.append("        select * from dept where dept.id = :deptid ");
		sb.append("        union all ");
		sb.append("          select dept.* from dept, r where dept.parent_id = r.id ");
		sb.append("      ) ");
		sb.append("      select r.id, r.full_name, r.code from r ");
		sb.append("      where not(r.name like '%ＡＣ%' or r.name like '%Ａ／Ｃ%' or r.name like '%賃貸家賃%') ");
		sb.append("    ) as sec where prj.dept_id = sec.id ");
		sb.append("  )as prj on ud.dept_id = prj.dept_id ");
		sb.append(") as p on pu.project_id = p.id ");
		sb.append("where nick_name like :nick_name escape '#' ");
		sb.append("order by joined desc, is_primary_dept desc, dept_code asc, nick_name asc ");

		String sql = sb.toString();

		String nickName = srchStr.replaceAll("[_%\\[#]", "#$0");

		SqlQuery query = Ebean.createSqlQuery(sql);
		query.setParameter("deptid", deptid);
		query.setParameter("uid", userid);
		query.setParameter("nick_name", "%" + nickName + "%");

		return query.findList();
	}

	/**
	 * プロジェクト情報(project, project_user)を更新する<br/>
	 * 第２引数に指定された部門IDに一致するプロジェクトをいったんすべて削除し、第３引数で指定されたプロジェクトID（編集画面でチェックされたプロジェクト）に一致する情報を設定しなおす<br/>
	 * また、カレントプロジェクト（ginjasuser.current_project_id）に設定されているプロジェクトが参加解除された場合にはカレントプロジェクトの値を０に設定する。
	 *
	 * @param userid ユーザID
	 * @param deptid 所属部署ID
	 * @param rgstPrjIds 参加設定したプロジェクトIDの配列
	 */
	public static int updateProject(Long userid, String[] joinId, String[] joinType) {
		Ebean.beginTransaction();

		int nRet = 0;
		try {
			StringBuilder info = new StringBuilder();
			// いまログインしているユーザの情報を取得する
			User curUser = User.find.where().eq("id", userid).findUnique();

			for(int i = 0; i < joinId.length; i++) {
				Long projectId = Long.valueOf(joinId[i]);

				boolean bFind = false;
				Iterator<Project> iter = curUser.projects.iterator();
				while(iter.hasNext()){
					Project prj = iter.next();

					if(projectId.equals(prj.id)) {
						// 一致するプロジェクトが見つかった、かつ一覧でチェックがはずされた（→ project_userから消す）
						if("0".equals(joinType[i])) {
							iter.remove();
							info.append("【削除】").append(prj.nickName).append(" ");
						}
						bFind = true;
						break;
					}
				}

				// 一致するプロジェクトが見つからなかった、かつ一覧でチェックがつけられた（→ project_userに追加する）
				if(!bFind && "1".equals(joinType[i])) {
					Project addPrj = Project.find.byId(projectId);

					curUser.projects.add(addPrj);
					info.append("【追加】").append(addPrj.nickName).append(" ");
				}
			}

			// カレントプロジェクトに指定しているプロジェクトが参加解除された場合、もしくは参加プロジェクトがなくなった場合、カレントプロジェクトのIDをnullにもどす
			Long curProjId = (long)0;
			if(curUser.currentProjectId != null){
				curProjId = curUser.currentProjectId;
			}

			boolean bFound = false;
			for(int i= 0; i < curUser.projects.size(); i++ ){
				if(curProjId.equals(curUser.projects.get(i).id)) {
					bFound = true;
					break;
				}
			}

			if(!bFound) {
				curUser.currentProjectId = null;
			}

			// セッション(isJoinProject)の状態を更新
			Application.setSessionValue("isJoinProject", curUser.projects.size() == 0 ? Application.NON_JOIN_PROJECT : Application.JOIN_PROJECT);

//			curUser.save();
			curUser.update();

			// 活動履歴の保存
			ActivityRecord.saveActivity(info.toString(), curUser, ActivityRecord.ActivityType.JOINPROJECT);

			Ebean.commitTransaction();
		} catch(Exception ex) {
    	    Logger.info(ex.getMessage());

			Ebean.rollbackTransaction();
			nRet = -1;
		} finally {
			Ebean.endTransaction();
		}
		return nRet;

/*
			// そのユーザにひもづく同一部署のプロジェクト情報(project_user)だけをすべて削除する
			Iterator<Project> itr = curUser.projects.iterator();
			while(itr.hasNext()){
				Project prj = itr.next();

//				if((long)(prj.dept.id) == (long)deptid) {
				if(deptid.equals(prj.dept.id)) {
					itr.remove();
				}
			}

			// 参加設定したプロジェクト情報を取得し、設定する
			if(rgstPrjIds != null) {
				for(int i = 0; i < rgstPrjIds.length; i++) {
					Project addPrj = Project.find.byId(Long.parseLong(rgstPrjIds[i]));

					curUser.projects.add(addPrj);
				}
			}

			// カレントプロジェクトに指定しているプロジェクトが参加解除された場合、カレントプロジェクトのIDを０にする
			boolean bFound = false;
			for(int i= 0; i < curUser.projects.size(); i++ ){
//				if((long)(curUser.currentProjectId) == (long)(curUser.projects.get(i).id)) {
				if(curUser.currentProjectId.equals(curUser.projects.get(i).id)) {
					bFound = true;
					break;
				}
			}

			if(!bFound) {
				curUser.currentProjectId = (long)0;
			}

			// セッション(isJoinProject)の状態を更新
			Application.setSessionValue("isJoinProject", curUser.projects.size() == 0 ? Application.NON_JOIN_PROJECT : Application.JOIN_PROJECT);

			curUser.save();

			Ebean.commitTransaction();
		} catch(Exception ex) {
    	    Logger.info(ex.getMessage());

			Ebean.rollbackTransaction();
			nRet = -1;
		} finally {
			Ebean.endTransaction();
		}
		return nRet;
*/
	}

	/**
	 * 自部署でユーザーの参加しているプロジェクトの情報を取得する
	 *
	 * @param id ユーザーＩＤ
	 * @return
	 */
	public static List<SqlRow> getJoinProjectByUserSection(Long uid) {
		StringBuilder sb = new StringBuilder();

//		sb.append("select p.id, p.nick_name, p.description, d.full_name, p.dept_id, 1 as joined ");
//		sb.append(" from project as p, project_user as pu, dept as d ");
//		sb.append(" where p.id = pu.project_id ");
//		sb.append(" and p.dept_id = d.id ");
//		sb.append(" and pu.user_id = :uid ");
//		sb.append(" and p.dept_id = :deptid ");
//		sb.append(" order by p.id desc");

		sb.append("select ");
		sb.append("  a.id, ");
		sb.append("  a.true_name, ");
		sb.append("  a.nick_name, ");
		sb.append("  a.description, ");
		sb.append("  a.dept_id, ");
		sb.append("  a.full_name, ");
		sb.append("  a.is_primary_dept, ");
		sb.append("  a.user_id, ");
		sb.append("  a.code, ");
		sb.append("  '1' as joined ");
		sb.append("from project_user as pu ");
		sb.append("  left join ");
		sb.append("( ");
		sb.append("  select ");
		sb.append("    prj.id, ");
		sb.append("    prj.true_name, ");
		sb.append("    prj.nick_name, ");
		sb.append("    prj.description, ");
		sb.append("    prj.dept_id, ");
		sb.append("    prj.full_name, ");
		sb.append("    prj.code, ");
		sb.append("    ud.is_primary_dept, ");
		sb.append("    ud.user_id ");
		sb.append("  from user_dept as ud ");
		sb.append("    left join ");
		sb.append("    ( ");
		sb.append("      select p.id, p.true_name, p.nick_name, p.description, p.dept_id, d.full_name, d.code ");
		sb.append("      from project as p ");
		sb.append("        left join dept as d on p.dept_id = d.id ");
		sb.append("    ) as prj on ud.dept_id = prj.dept_id ");
		sb.append(") as a ");
		sb.append("on pu.project_id = a.id and pu.user_id = a.user_id ");
		sb.append("where pu.user_id = :user_id ");
		sb.append("and a.id is not null ");
		sb.append("order by joined desc, a.is_primary_dept desc, a.code asc, a.nick_name asc ");

		String sql = sb.toString();

		SqlQuery query = Ebean.createSqlQuery(sql);
		query.setParameter("user_id", uid);
//		query.setParameter("deptid", deptid);

		return query.findList();
	}

	/**
	 * 他部署でユーザーが参加しているプロジェクトの情報を取得する
	 *
	 * @param id ユーザーＩＤ
	 * @return
	 */
	public static List<SqlRow> getJoinProjectByOtherSection(Long uid) {
		StringBuilder sb = new StringBuilder();

//		sb.append("select p.id, p.nick_name, p.description, d.full_name, p.dept_id, 1 as joined ");
//		sb.append(" from project as p, project_user as pu, dept as d ");
//		sb.append(" where p.id = pu.project_id ");
//		sb.append(" and p.dept_id = d.id ");
//		sb.append(" and pu.user_id = :uid ");
//		sb.append(" and p.dept_id <> :deptid ");
//		sb.append(" order by p.id desc");

		sb.append("select ");
		sb.append("  prj.id, ");
		sb.append("  prj.nick_name, ");
		sb.append("  prj.description, ");
		sb.append("  prj.dept_id, ");
		sb.append("  prj.full_name, ");
		sb.append("  prj.code, ");
		sb.append("  pu.user_id, ");
		sb.append("  '0' as is_primary_dept, ");
		sb.append("  '1' as joined ");
		sb.append("from project_user as pu ");
		sb.append("  left join ");
		sb.append("  ( ");
		sb.append("    select ");
		sb.append("      p.id, ");
		sb.append("      p.nick_name, ");
		sb.append("      p.description, ");
		sb.append("      p.dept_id, ");
		sb.append("      d.code, ");
		sb.append("      d.full_name ");
		sb.append("    from project as p ");
		sb.append("      left join dept as d on p.dept_id = d.id ");
		sb.append("  ) as prj on pu.project_id = prj.id ");
		sb.append("where pu.user_id = :user_id ");
		sb.append("and not(prj.dept_id in (select dept_id from user_dept where user_id = :user_id)) ");
		sb.append("order by joined desc, is_primary_dept desc, prj.code asc, prj.nick_name asc ");

		String sql = sb.toString();

		SqlQuery query = Ebean.createSqlQuery(sql);
		query.setParameter("user_id", uid);
//		query.setParameter("deptid", deptid);

		return query.findList();
	}

	/**
	 * 自部署のユーザーが参加していないプロジェクトの情報を取得する
	 *
	 * @param uid ユーザーＩＤ
	 * @return
	 */
	public static List<SqlRow> getNotJoinProjectByUserSection(Long uid) {
		StringBuilder sb = new StringBuilder();

//		sb.append("select project.id, project.nick_name, project.description, d.full_name, project.dept_id, 0 as joined ");
//		sb.append(" from project left outer join ");
//		sb.append(" ( select pu.user_id, pu.project_id ");
//		sb.append("  from project_user as pu, project as p ");
//		sb.append("  where pu.project_id = p.id ");
//		sb.append("  and p.dept_id = :deptid ");
//		sb.append("  and pu.user_id = :uid ");
//		sb.append(" ) as a on project.id = a.project_id, dept as d ");
//		sb.append(" where project.dept_id = :deptid ");
//		sb.append(" and a.user_id is null ");
//		sb.append(" and project.dept_id = d.id ");
//		sb.append(" order by project.id desc");

		sb.append("select ");
		sb.append("  a.id, ");
		sb.append("  a.nick_name, ");
		sb.append("  a.description, ");
		sb.append("  a.dept_id, ");
		sb.append("  a.full_name, ");
		sb.append("  a.is_primary_dept, ");
		sb.append("  a.user_id, ");
		sb.append("  a.code, ");
		sb.append("  '0' as joined ");
		sb.append("from project_user as pu ");
		sb.append("  right join ");
		sb.append("  ( ");
		sb.append("    select ");
		sb.append("      prj.id, ");
		sb.append("      prj.nick_name, ");
		sb.append("      prj.description, ");
		sb.append("      prj.dept_id, ");
		sb.append("      prj.full_name, ");
		sb.append("      prj.code, ");
		sb.append("      ud.is_primary_dept, ");
		sb.append("      ud.user_id ");
		sb.append("    from user_dept as ud ");
		sb.append("      left join ");
		sb.append("      ( ");
		sb.append("        select p.id, p.true_name, p.nick_name, p.description, p.dept_id, d.full_name, d.code ");
		sb.append("        from project as p ");
		sb.append("          left join dept as d on p.dept_id = d.id ");
		sb.append("      ) as prj on ud.dept_id = prj.dept_id ");
		sb.append("  ) as a on pu.user_id = a.user_id and pu.project_id = a.id ");
		sb.append("where a.user_id = :user_id ");
		sb.append("and pu.user_id is null ");
		sb.append("and a.id is not null ");
		sb.append("order by joined desc, a.is_primary_dept desc, a.code asc, a.nick_name asc ");

		String sql = sb.toString();

		SqlQuery query = Ebean.createSqlQuery(sql);
		query.setParameter("user_id", uid);
//		query.setParameter("deptid", deptid);

		return query.findList();
	}

    /**
     * 指定したユーザーが過去に参加していたプロジェクトの情報を取得する<br/>
     * ※過去に参加していたプロジェクトとは、ダウンロードを行ったことがあるプロジェクトでいまは参加解除しているもの
     *
     * @return
     */
    public static List<SqlRow> getJoinedProjectByUser(Long userid) {
		StringBuilder sb = new StringBuilder();

		sb.append("select a.id, a.nick_name from ");
		sb.append("( ");
		sb.append("  select distinct(up.project_id), p.id, p.nick_name ");
		sb.append("  from user_product as up, project as p ");
		sb.append("  where up.user_id = :userid ");
		sb.append("  and up.project_id = p.id ");
		sb.append(") as a left join ");
		sb.append("( ");
		sb.append("  select p.id, p.nick_name ");
		sb.append("  from project_user as pu ");
		sb.append("    left join project as p on pu.project_id = p.id ");
		sb.append("  where pu.user_id = :userid ");
		sb.append(") as b on a.id = b.id ");
		sb.append("where b.id is null ");

		String sql = sb.toString();
		try {
			SqlQuery query = Ebean.createSqlQuery(sql);
			query.setParameter("userid", userid);

			return query.findList();
		} catch(Exception e) {
			Logger.info(e.getMessage());
			return null;
		}
	}

    /**
     * 指定したプロジェクトのプロジェクト責任者（社員番号・氏名・所属部門名）を取得する
     *
     * @param pid プロジェクトID
     * @return
     */
    public static List<SqlRow> getProjectManager(Long pid) {
		StringBuilder sb = new StringBuilder();

		sb.append("select ");
		sb.append("  ginjasuser.id, ");
		sb.append("  ginjasuser.username, ");
		sb.append("  (ginjasuser.family_name || ' ' || ginjasuser.first_name) as manager_name, ");
		sb.append("  dept_info.full_name ");
		sb.append("from project_manager ");
		sb.append("  left join ginjasuser on project_manager.user_id = ginjasuser.id ");
		sb.append("  left join ");
		sb.append("  ( ");
		sb.append("    select user_dept.user_id, dept.full_name from user_dept, dept where user_dept.dept_id = dept.id and user_dept.is_primary_dept = true ");
		sb.append("  ) as dept_info on project_manager.user_id = dept_info.user_id ");
		sb.append("where project_id = :projectId ");
		sb.append("order by ginjasuser.username ");

		String sql = sb.toString();

		try {
			SqlQuery query = Ebean.createSqlQuery(sql);
			query.setParameter("projectId", pid);

			return query.findList();
		} catch(Exception e) {
			Logger.info("Exception occurred in Project.getProjectManager() method.");
			Logger.info(e.getMessage());

			return new ArrayList<SqlRow>();
		}
	}

    /**
     * 指定されたプロジェクトのプロジェクト責任者の情報を更新する
     *
     * @param projectId プロジェクトID
     * @param userIds プロジェクト責任者（ユーザーID）の配列
     */
    public static void updateProjectManager(Long projectId, String[] userIds) {
		try {
			Project project = find.byId(projectId);

			// いったんすべての要素を削除
			project.managers.clear();

			for(String id : userIds) {
				User user = User.findById(Long.valueOf(id));

				project.managers.add(user);
			}
			project.update();
		} catch(Exception e) {
			Logger.info("Exception occurred in Project.updateProjectManager() method.");
			Logger.info(e.getMessage());
		}
	}

	/**
	 * 指定されたユーザーが関係するプロジェクトの情報を取得する。<br>
	 * 　関係するプロジェクトの情報とは、自身が参加するプロジェクトおよび自身が責任者となっているプロジェクトを含めたもの
	 *
	 * @param uid ユーザーID
	 * @return
	 */
	public static List<SqlRow> getRelatedUserProject(Long uid) {
		StringBuilder sb = new StringBuilder();

		sb.append("select ");
		sb.append("  id, ");
		sb.append("  true_name, ");
		sb.append("  nick_name, ");
		sb.append("  description, ");
		sb.append("  started_on, ");
		sb.append("  ended_on, ");
		sb.append("  has_retired, ");
		sb.append("  dept_id ");
		sb.append("from ");
		sb.append("  project ");
		sb.append("where project.id in ");
		sb.append("( ");
		sb.append("  select project_id from project_manager where user_id = :userid ");
		sb.append("  union ");
		sb.append("  select project_id from project_user where user_id = :userid ");
		sb.append(") ");
		sb.append("order by id ");

		String sql = sb.toString();

		return Ebean.createSqlQuery(sql).setParameter("userid", uid).findList();
	}
}
