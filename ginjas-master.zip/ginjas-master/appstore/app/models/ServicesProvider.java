package models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ServicesProvider extends AbstractOrganization {
	/**
	 * @Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
	 *
	 * 本来は上記のように指定して、AbstractOrganizationの定義をOraganizationに持たせて、
	 * AbstractOrganizationクラスを使わず、ServicesProviderはOrganizationを継承すべきだが、
	 * Ebeanの制限でTABLE_SINGLEしかサポートしていないために、やむなく現状の継承関係にしてある。
	 *
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "services_provider_seq")
	Long id;

}
