package models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.avaje.ebean.Model;

@Entity
public class License extends Model {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "license_seq")
	public Long id;
	public String fullname;
	public String nickname;
	public String url;
	public String overview;
	public String fulltext;
	public Boolean isOSIApproved;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "license")
	public List<LicenseTerm> termsAndConditions;
	@ManyToMany(cascade = CascadeType.ALL,
			mappedBy = "declaredLicenses")
	public List<Product> products;

	public static Finder<Long, License> find = new Finder<Long, License>(License.class);

	public static List<License> findAll() {
		return find.findList();
	}

	public static License findById(Long id) {
		return find.byId(id);
	}

        public static void addLicense(String fullname, String nickname, String url, String overview, String fulltext, Boolean isOSIApproved) {
            License lic = new License();
            lic.fullname      = fullname;
            lic.nickname      = nickname;
            lic.url           = url;
            lic.overview      = overview;
            lic.fulltext      = fulltext;
            lic.isOSIApproved = isOSIApproved;
            lic.save();

        }

        public static void updateLicense(Long id, String fullname, String nickname, String url, String overview, String fulltext, Boolean isOSIApproved) {
            License lic = License.findById(id);
            lic.fullname      = fullname;
            lic.nickname      = nickname;
            lic.url           = url;
            lic.overview      = overview;
            lic.fulltext      = fulltext;
            lic.isOSIApproved = isOSIApproved;
            lic.update();

        }
         
        public static void deleteLicense(Long id) {
            License lic = License.findById(id);
            lic.delete();
        }

}
