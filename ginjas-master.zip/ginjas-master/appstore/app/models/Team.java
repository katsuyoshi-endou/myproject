package models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import play.data.validation.Constraints;
import com.avaje.ebean.Model;

@Entity
public class Team extends Model {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "team_seq")
	public Long id;

	@Constraints.Required
	public String name;

	@ManyToOne
	public Team parent = null;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "parent")
	public List<Team> children = new ArrayList<Team>();

	public boolean isTagified; /*
								 * set to true only for those with
								 * __distinguishable__ names
								 */

	public String getFullname(String rest) {
		String sofar = rest + " " + this.name;
		if (parent != null) {
			return parent.getFullname(sofar);
		} else {
			return sofar;
		}
	}

	public static Finder<Long, Team> find = new Finder<Long, Team>(Team.class);
}
