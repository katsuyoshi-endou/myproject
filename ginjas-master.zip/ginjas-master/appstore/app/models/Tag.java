package models;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.avaje.ebean.Model;

@Entity
public class Tag extends Model {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "tag_seq")
	public String symbol;
	public String explanatoryName;
	public Boolean isPrimary;

	public static Finder<Long, Tag> find = new Finder<Long, Tag>(Tag.class);

	public static List<Tag> findAll() {
		return find.findList();
	}

	public static Tag findBySymbol(String symbol) {
		Tag result = find.where().eq("symbol", symbol).findUnique();
		return result;
	}

        public static void addTag(String symbol, String explanatoryName, Boolean isPrimary) {
            Tag tag = new Tag();
            tag.symbol          = symbol;
            tag.explanatoryName = explanatoryName;
            tag.isPrimary       = isPrimary;
            tag.save();

        }

        public static void updateTag(String symbol, String explanatoryName, Boolean isPrimary) {
            Tag tag = Tag.findBySymbol(symbol);
            tag.explanatoryName = explanatoryName;
            tag.isPrimary       = isPrimary;
            tag.update();

        }
         
        public static void deleteTag(String symbol) {
            Tag tag = Tag.findBySymbol(symbol);
            tag.delete();
        }

        public static void deleteTagWithProductRelationship(String symbol) {
            Tag tag = Tag.findBySymbol(symbol);
            List<Product> products = Product.findProductsWithTag(symbol);
            products.forEach(p -> {
                p.tags.remove(tag);
                p.update();
            });
            tag.delete();
        }
}
