package models;

import play.mvc.Http.Context;
import play.mvc.Result;
import play.mvc.Security;

public class Authenticator extends Security.Authenticator {
	@Override
	public String getUsername(Context ctx) {
		return ctx.session().get("username");
	}

	@Override
	public Result onUnauthorized(Context ctx) {
		String urlToGo = ctx.request().uri();
		urlToGo = (urlToGo == null) ? "/" : urlToGo;
		ctx.session().put("urlToGo", urlToGo);
		return redirect(controllers.routes.Application.login());
	}
}
