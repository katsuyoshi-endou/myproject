package models;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.avaje.ebean.Model;

@Entity
public class ProductRelationship extends Model {
	public enum Relationship {
		RESEMBLES("類似する"), CONNECTS("接続できる"), FORKED("フォークした"), INCLUDES("包含する");
		private String name;

		Relationship(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}
	}

	@ManyToOne
	@JoinColumn(name = "subjective")
	public Product subjective;
	public Relationship verb;
	@ManyToOne
	@JoinColumn(name = "objective")
	public Product objective;
}
