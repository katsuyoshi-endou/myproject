package models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.avaje.ebean.Model;

@Entity
public class Medium extends Model {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "medium_seq")
	public Long seq;

	public String packageType;
	public String url;
	public String platform;
	public Long checksum;

	@ManyToOne
	@JoinColumn(name = "release_id")
	public Release release;

	public static Finder<Long, Medium> find = new Finder<Long, Medium>(Medium.class);

	public static Medium findById(Long id) {
		return find.byId(id);
	}

        public static void addMedium(String  packageType 
                                    ,String  url
                                    ,String  platform
                                    ,Long    checksum
                                    ,Release release ) {
            Medium medium = new Medium();
            medium.packageType = packageType;
            medium.url = url;
            medium.platform = platform;
            medium.checksum = checksum;
            medium.release = release;
            medium.save();

        }

        public static void updateMedium(Long    seq
                                       ,String  packageType 
                                       ,String  url
                                       ,String  platform
                                       ,Long    checksum
                                       ,Release release ) {
            Medium medium = Medium.findById(seq);
            medium.packageType = packageType;
            medium.url = url;
            medium.platform = platform;
            medium.checksum = checksum;
            medium.release = release;
            medium.update();

        }

        public static void deleteMedium(Long seq) {
            Medium medium = Medium.findById(seq);
            medium.delete();
        }
}
