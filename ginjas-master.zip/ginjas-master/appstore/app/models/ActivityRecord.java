package models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Model;
import com.avaje.ebean.PagedList;
import com.avaje.ebean.SqlQuery;
import com.avaje.ebean.SqlRow;

import play.Logger;

/**
 * ActivityRecord: ユーザーによるProductに関する活動履歴。次の活動が記録される：
 * カタログページの閲覧、ソフトウェアの入手およびダウンロード、ソフトウェアに対するレーティングおよびレビュー
 */
@Entity
public class ActivityRecord extends Model {

	public enum ActivityType {
		SIGNON("サインオン"), LOGIN("ログイン"), LOGOUT("ログアウト"), BROWSE("閲覧"), ACQUIRE("入手"), REVIEW("レビュー"), REQUEST("リクエスト"),
		ADDPROJECT("プロジェクト追加"), JOINPROJECT("プロジェクト参加"), SELECTPROJECT("プロジェクト選択"), CANCELREQUEST("リクエスト取消"), UPDATEUSE("利用状況更新");

		private String name;

		ActivityType(String name) {
			this.name = name;
		}

		public String getName() {
			return this.name;
		}
	}

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "activity_record_seq")
	public Long id;
	public Long userId;
	public Long productId;
	public String objective;
	public Date date;
	public ActivityType activityType;

	public static Finder<Long, ActivityRecord> find = new Finder<Long, ActivityRecord>(ActivityRecord.class);

	public Product getProduct() {
		return (null == productId) ? (Product) null : Product.find.byId(productId);
	}

	/* a coulple of stat functions... */
	public static Integer count(Product product, ActivityType type) {
		List<ActivityRecord> entries = find.where().eq("product_id", product.id).eq("activity_type", type).findList();
		return entries.size();
	}

	public static PagedList<ActivityRecord> page(int nth, int pageSize, User u, boolean verbose) {
		PagedList<ActivityRecord> entries = verbose
				? find.where().eq("user_id", u.id).orderBy("date desc").findPagedList(nth, pageSize)
				: find.where().eq("user_id", u).eq("activity_type", ActivityType.ACQUIRE).orderBy("date desc")
						.findPagedList(nth, pageSize);
		return entries;
	}

	public static List<ActivityRecord> getActivitiesBy(User user) {
		List<ActivityRecord> entries = find.where().eq("user_id", user.id).findList();
		return entries;
	}

	public static List<ActivityRecord> getActivitiesBy(User user, ActivityType type) {
		List<ActivityRecord> entries = find.where().eq("user_id", user.id).eq("activity_type", type).findList();
		return entries;
	}

	public static void saveActivity(Product product, String version, User user, ActivityType type) {
		ActivityRecord newOne = new ActivityRecord();
		newOne.userId = user.id;
		if (product != null) {
		    	newOne.productId = product.id;
		    	String objective;
		    	if (version != null && !version.isEmpty()) {
		    	    objective = String.format("OSS名: %s, バージョン: %s", product.name, version);
		    	} else {
		    	    objective = String.format("OSS名: %s", product.name);
		    	}
			newOne.objective = objective;
		} else {
		    	newOne.productId = null;
			newOne.objective = "";
		}
		newOne.productId = (null == product) ? null : product.id;
		newOne.date = new Date();
		newOne.activityType = type;
		newOne.save();
	}

	public static void saveActivity(String objective, User user, ActivityType type) {
		ActivityRecord newOne = new ActivityRecord();
		newOne.productId = null;
		newOne.objective = objective;
		newOne.userId = user.id;
		newOne.date = new Date();

		// プロジェクトに関わる活動履歴
		switch (type) {
		case ADDPROJECT:
		case JOINPROJECT:
		case SELECTPROJECT:
		    objective = "PRJ: " + objective;
		    break;
		default:
		}
		newOne.objective = objective != null ? objective: "";
		newOne.activityType = type;
		newOne.save();
	}
	/** TODO: still more stat functions to come... */

	/**
	 * 指定された条件で活動履歴の情報を取得する<br>
	 * 第2引数の内容により、発行するSQLをふりわける。<br>
	 * 　1. 値がnullの場合、すべての部門を対象に検索する<br>
	 * 　2. 値がnull以外の場合、指定された部門の灰化に所属するユーザーを対象に検索する<br>
	 * 　※「root」ユーザーなどの所属を設定していないユーザーは1.の条件でしかひっかかりません。
	 *
	 * @param actType 活動タイプ
	 * @param deptId 部署ID
	 * @param userName ユーザー名
	 * @param startDate 日時（開始）
	 * @param endDate 日時（終了）
	 * @param productId OSS製品ID
	 * @param objective 「対象」の検索文字列
	 * @return
	 */
	public static List<SqlRow> getActiviesByCondition(String actType, Long deptId, String userName, String startDate, String endDate, Long productId, String objective) {
		StringBuilder sb = new StringBuilder();

		// 部署選択が行われたかによりSQLをふりわける
		if(deptId == null){
			sb.append("select ");
			sb.append("  act_date, ");
			sb.append("  srch_date, ");
			sb.append("  user_name, ");
			sb.append("  full_name, ");
			sb.append("  activity_name, ");
			sb.append("  activity_type, ");
			sb.append("  product_id, ");
			sb.append("  objective ");
			sb.append("from ");
			sb.append("( ");
			sb.append("  select ");
			sb.append("    to_char(date, 'yyyy-mm-dd HH24:MI:SS') as act_date, ");
			sb.append("    to_char(date, 'yyyy-mm-dd') as srch_date, ");
			sb.append("    trim(ginjasuser.family_name || ' ' || ginjasuser.first_name) as user_name, ");
			sb.append("    dept_info.full_name, ");
			sb.append("    case ");
			sb.append("      when activity_type = 0 then 'サインオン' ");
			sb.append("      when activity_type = 1 then 'ログイン' ");
			sb.append("      when activity_type = 2 then 'ログアウト' ");
			sb.append("      when activity_type = 3 then '閲覧' ");
			sb.append("      when activity_type = 4 then '入手' ");
			sb.append("      when activity_type = 5 then 'レビュー' ");
			sb.append("      when activity_type = 6 then 'リクエスト' ");
			sb.append("      when activity_type = 7 then 'プロジェクト追加' ");
			sb.append("      when activity_type = 8 then 'プロジェクト参加' ");
			sb.append("      when activity_type = 9 then 'プロジェクト選択' ");
			sb.append("      when activity_type = 10 then 'リクエスト取消' ");
			sb.append("      when activity_type = 11 then '利用状況更新' ");
			sb.append("      else '' ");
			sb.append("    end as activity_name, ");
			sb.append("    activity_type, ");
			sb.append("    product_id, ");
			sb.append("    objective ");
			sb.append("  from activity_record ");
			sb.append("    left join ginjasuser on activity_record.user_id = ginjasuser.id ");
			sb.append("    left join ");
			sb.append("    ( ");
			sb.append("      select ");
			sb.append("        user_dept.user_id, ");
			sb.append("        dept.id, ");
			sb.append("        dept.full_name ");
			sb.append("      from user_dept left join dept on user_dept.dept_id = dept.id ");
			sb.append("      where user_dept.is_primary_dept = true ");
			sb.append("    ) dept_info on activity_record.user_id = dept_info.user_id ");
			sb.append(") as xx ");
			sb.append("where 1=1 ");
		} else {
			sb.append("select ");
			sb.append("  act_date, ");
			sb.append("  srch_date, ");
			sb.append("  user_name, ");
			sb.append("  full_name, ");
			sb.append("  activity_name, ");
			sb.append("  activity_type, ");
			sb.append("  product_id, ");
			sb.append("  objective ");
			sb.append("from ");
			sb.append("( ");
			sb.append("  select ");
			sb.append("    to_char(date, 'yyyy-mm-dd HH24:MI:SS') as act_date, ");
			sb.append("    to_char(date, 'yyyy-mm-dd') as srch_date, ");
			sb.append("    case ");
			sb.append("      when activity_type = 0 then 'サインオン' ");
			sb.append("      when activity_type = 1 then 'ログイン' ");
			sb.append("      when activity_type = 2 then 'ログアウト' ");
			sb.append("      when activity_type = 3 then '閲覧' ");
			sb.append("      when activity_type = 4 then '入手' ");
			sb.append("      when activity_type = 5 then 'レビュー' ");
			sb.append("      when activity_type = 6 then 'リクエスト' ");
			sb.append("      when activity_type = 7 then 'プロジェクト追加' ");
			sb.append("      when activity_type = 8 then 'プロジェクト参加' ");
			sb.append("      when activity_type = 9 then 'プロジェクト選択' ");
			sb.append("      when activity_type = 10 then 'リクエスト取消' ");
			sb.append("      when activity_type = 11 then '利用状況更新' ");
			sb.append("      else '' ");
			sb.append("    end as activity_name, ");
			sb.append("    activity_type, ");
			sb.append("    product_id, ");
			sb.append("    objective, ");
			sb.append("    user_info.user_name, ");
			sb.append("    user_info.full_name ");
			sb.append("  from activity_record, ");
			sb.append("  ( ");
			sb.append("    select ");
			sb.append("      user_dept.user_id, ");
			sb.append("      trim(ginjasuser.family_name || ' ' || ginjasuser.first_name) as user_name, ");
			sb.append("      dept_info.id, ");
			sb.append("      dept_info.full_name ");
			sb.append("    from user_dept left join ginjasuser on user_dept.user_id = ginjasuser.id, ");
			sb.append("    ( ");
			sb.append("      with recursive r as ");
			sb.append("      ( ");
			sb.append("        select * from dept where dept.id = :deptId ");
			sb.append("          union all ");
			sb.append("          select dept.* from dept, r where dept.parent_id = r.id ");
			sb.append("      ) ");
			sb.append("      select r.id, r.full_name from r ");
			sb.append("      where not(r.name like '%ＡＣ%' or r.name like '%Ａ／Ｃ%' or r.name like '%賃貸家賃%') ");
			sb.append("    ) as dept_info ");
			sb.append("    where user_dept.dept_id = dept_info.id ");
			sb.append("    and user_dept.is_primary_dept = true ");
			sb.append("  ) as user_info ");
			sb.append("  where activity_record.user_id = user_info.user_id ");
			sb.append(") as xx ");
			sb.append("where 1=1 ");
		}

		// 活動タイプ
		if(!"".equals(actType) || actType.length() != 0) {
			sb.append("and xx.activity_type in(" + actType + ") ");
		}

		// 氏名
		if(!"".equals(userName) || userName.length() != 0) {
			sb.append("and xx.user_name like :username escape '#' ");
		}

		// OSS名
		if(productId != null) {
			sb.append("and xx.product_id = :productId ");
		}

		// 対象
		if(!"".equals(objective) || objective.length() != 0) {
			sb.append("and upper(xx.objective) like upper(:objective) escape '#' ");
		}

		// 利用開始日
		if(!"".equals(startDate) || startDate.length() != 0) {
			sb.append(" and (xx.srch_date >= :startdate and xx.srch_date <= :enddate) ");
		}

		sb.append("order by xx.act_date desc ");

		String sql = sb.toString();

		try {
			SqlQuery query = Ebean.createSqlQuery(sql);
			query.setParameter("deptId", deptId);
			query.setParameter("username", "%" + userName + "%");
			query.setParameter("productId", productId);
			query.setParameter("objective", "%" + objective + "%");
			query.setParameter("startdate", startDate);
			query.setParameter("enddate", endDate);

			return query.findList();
		} catch(Exception e) {
			Logger.info(e.getMessage());
			return new ArrayList<SqlRow>();
		}
	}
}
