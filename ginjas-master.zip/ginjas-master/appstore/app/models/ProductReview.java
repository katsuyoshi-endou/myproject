package models;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.avaje.ebean.Model;

/**
 * Productに対する評価。
 */
@Entity
public class ProductReview extends Model {
	@ManyToOne
	@JoinColumn(name = "product_id")
	public Product product;

	@ManyToOne
	@JoinColumn(name = "user_id")
	public User user;

	public Date postDate;
	public Double rate = 0D; // 0.0 - 5.0
	public String usageCode;
	public String otherUsage;
	public String comment;
	public Boolean isAnonymous;

	public static Finder<Long, ProductReview> find = new Finder<Long, ProductReview>(ProductReview.class);

	public static List<ProductReview> findReviewsFor(Product p) {
		List<ProductReview> reviews = find.where().eq("product_id", p.id).findList();
		return reviews;
	}
}
