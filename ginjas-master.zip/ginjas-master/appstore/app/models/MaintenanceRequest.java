package models;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Model;
import com.avaje.ebean.SqlQuery;
import com.avaje.ebean.SqlRow;

import play.Logger;

@Entity
public class MaintenanceRequest extends Model {
	public enum RequestType {
		NEWVERSION("新バージョン登録要求"), FIXTYPO("誤植の修正要求"), NEWPRODUCT("未掲載OSS及び新バージョンの登録要求"), OTHER("その他の要求"), UNREGPRODUCT("未登録OSSの登録要求");
		private String name;

		RequestType(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}

		/**
		 * リクエストのタイプをDBの区分値で取得する。</br>
		 * 例）パラメータに「0」を指定すれば、戻り値に「NEWVERSION」を文字列で返す。</br>
		 * 　※定数配列で実装してもよいが、記述があちこちになるのを防ぐため</br>
		 * 　　なお、区分値が0始まりで順に定義されている場合のみ有効、「0,1,2,4」などと定義されていると無効です。
		 *
		 * @param code maintenance_requestテーブルのreq_type値
		 * @return
		 */
		public static String getReqTypeCodeByDBValue(final int code) {
			return codeToEnum.get(String.valueOf(code)).toString();
		}

		private static final Map<String, RequestType> codeToEnum = new HashMap<String, RequestType>() {{
			int code = 0;
			for(RequestType reqType: RequestType.values()){
				put(String.valueOf(code), reqType);
				code++;
			}
		}};
	}

	public enum Progress {
		OPEN("オープン"), ACCEPTED("受理済"), REJECTED("却下済"), ASSIGNED("担当決定"), PROCESSING("処理中"), COMPLETED("完了"), CANCELED("取消");
		private String name;

		Progress(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}

		/**
		 * 登録リクエストの状態をDBの区分値で取得する。</br>
		 * 例）パラメータに「0」を指定すれば、戻り値に「OPEN」を文字列で返す。</br>
		 * 　※定数配列で実装してもよいが、記述があちこちになるのを防ぐため</br>
		 * 　　なお、区分値が0始まりで順に定義されている場合のみ有効、「0,1,2,4」などと定義されていると無効です。
		 *
		 * @param code maintenance_requestテーブルのstatus値
		 * @return
		 */
		public static String getStatusCodeByDBValue(final int code) {
			return codeToEnum.get(String.valueOf(code)).toString();
		}

		private static final Map<String, Progress> codeToEnum = new HashMap<String, Progress>() {{
			int code = 0;
			for(Progress progress: Progress.values()){
				put(String.valueOf(code), progress);
				code++;
			}
		}};
	}

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "maintenance_request_seq")
	public Long id;
	@ManyToOne
	@JoinColumn(name = "user_id")
	public User user;
    public Product product; // this could be null for new product
	public String productName;
	public String version;
	public Date preferedDate;
	public RequestType reqType;
	public Date issueDate;
	public Progress status = Progress.OPEN;
	public Date lastUpdateDate;
	public String comments;			// ユーザー向け通信欄
	public Date approveDate;
	public String admComments;		// 管理者向け通信欄

	@ManyToOne
	@JoinColumn(name = "project_id")
	public Project project;

	public static Finder<Long, MaintenanceRequest> find = new Finder<Long, MaintenanceRequest>(
			MaintenanceRequest.class);

	/**
	 * 登録承認画面もしくは照会画面にて処理（承認・却下・取消）され登録リクエストの情報を更新する。</br>
	 * 承認・却下対象は申請中の登録リクエストのみのため申請中以外の登録リクエストがあった場合には処理をスキップする。</br>
	 * なお、更新は一括で行うため、１件でもエラーがあった場合にはトランザクションはロールバックされる。
	 *
	 * @param status 処理ステータス（承認・却下・取消）
	 * @param requestid 処理対象のリクエストID
	 * @return
	 */
	public static boolean updateMatenanceRequest(String status, String[] requestid) {
		Ebean.beginTransaction();

		try {
			for(int i = 0; i < requestid.length; i++){
				Date today = new Date();

				Long reqid = Long.parseLong(requestid[i]);

				MaintenanceRequest request = MaintenanceRequest.find.where().eq("id", reqid).findUnique();
				if(request.status == Progress.ACCEPTED || request.status == Progress.REJECTED){
					Logger.info("リクエストID：" + request.id + " はすでに承認もしくは却下されています。処理をスキップしました。");
					continue;
				}
				switch(status) {
				case "ACCEPTED" :
					request.status = Progress.ACCEPTED;
					request.approveDate = today;
					break;
				case "REJECTED" :
					request.status = Progress.REJECTED;
					request.approveDate = today;
					break;
				case "CANCELED" :
					request.status = Progress.CANCELED;

					// 活動履歴の保存
					ActivityRecord.saveActivity(String.format("OSS名: %s, バージョン: %s", request.productName, request.version), request.user, ActivityRecord.ActivityType.CANCELREQUEST);

					break;
				}
				request.lastUpdateDate = today;

				request.save();
			}
			Ebean.commitTransaction();
		} catch(Exception ex) {
			Ebean.rollbackTransaction();
			return false;
		} finally{
			Ebean.endTransaction();
		}
		return true;
	}

	/**
	 * 登録照会画面で表示するためのユーザーごとのリクエスト情報を取得する。
	 *
	 * @param userid ユーザーID
	 * @return
	 */
	public static List<SqlRow> getMaintenanceRequestByUserid(Long userid) {
		StringBuilder sb = new StringBuilder();

		sb.append("select ");
		sb.append("   req.id, ");
		sb.append("   req.product_name, ");
		sb.append("   req.version, ");
		sb.append("   to_char(req.prefered_date, 'yyyy-mm-dd') as prefered_date, ");
		sb.append("   req.req_type, ");
		sb.append("   case ");
		sb.append("     when req.req_type = '0' then '新バージョン登録要求' ");
		sb.append("     when req.req_type = '1' then '誤植の修正要求' ");
		sb.append("     when req.req_type = '2' then '未掲載OSS及び新バージョンの登録要求' ");
		sb.append("     when req.req_type = '3' then 'その他の要求' ");
		sb.append("     when req.req_type = '4' then '未登録OSSの登録要求' ");
		sb.append("     else '' ");
		sb.append("   end as request_str, ");
		sb.append("   to_char(req.issue_date, 'yyyy-mm-dd') as issue_date, ");
		sb.append("   to_char(req.approve_date, 'yyyy-mm-dd' ) as approve_date, ");
		sb.append("   req.status, ");
		sb.append("   case ");
		sb.append("     when req.status = '0' then '申請中' ");
		sb.append("     when req.status = '1' then '承認済' ");
		sb.append("     when req.status = '2' then '却下済' ");
		sb.append("     when req.status = '3' then '担当決定' ");
		sb.append("     when req.status = '4' then '処理中' ");
		sb.append("     when req.status = '5' then '完了' ");
		sb.append("     when req.status = '6' then '申請取消済' ");
		sb.append("     else '' ");
		sb.append("   end as status_str, ");
		sb.append("   req.comments, ");
		sb.append("   req.adm_comments, ");
		sb.append("   guser.family_name, ");
		sb.append("   prj.nick_name ");
		sb.append(" from maintenance_request as req ");
		sb.append("   left join ginjasuser as guser on req.user_id = guser.id ");
		sb.append("   left join project as prj on req.project_id = prj.id ");
		sb.append(" where req.user_id = :userid ");
		sb.append(" order by prefered_date asc, issue_date asc, req.product_name asc, req.version asc ");

//    	sb.append("select req.id, req.product_name, req.version, req.prefered_date, req.req_type, req.issue_date, req.approve_date, req.status,req.comments, guser.family_name, prj.nick_name");
//    	sb.append(" from maintenance_request as req, ginjasuser as guser, project as prj");
//    	sb.append(" where req.user_id = :userid and  req.user_id = guser.id and req.project_id = prj.id order by req.issue_date desc");

    	String sql = sb.toString();

    	SqlQuery query = Ebean.createSqlQuery(sql);
    	query.setParameter("userid", userid);

    	return query.findList();
	}

	/**
	 * 登録リクエストのデータベース登録前チェックを行う。</br>
	 * チェック内容は以下のとおり</br>
	 * ・未掲載製品及び新バージョンの登録要求の場合、すでに同じ製品名・バージョンで登録されていないか？</br>
	 * ・新規バージョン登録要求の場合、すでに同じ製品名・バージョンで登録されていないか？</br>
	 * ・同じ製品名・同じバージョンの登録リクエスト（申請中）がされていないか？
	 *
	 * @param newRequest チェックする登録リクエスト情報
	 * @return
	 */
	public static String checkBeforeRegistration(MaintenanceRequest newRequest) {
//		final String ERR_SAME_PRODUCT_NAME = "すでに同じ名称のOSS製品が登録されています。";
		final String ERR_SAME_PRODUCT_VERSION= "すでに同じバージョンが登録されています。";
		final String ERR_SAME_PRODUCT_NAME_VERSION= "同じOSS・バージョンで申請されています。";

		String sql;
		SqlQuery query;
		List<SqlRow> result;

		// 製品名比較用（前後の空白削除・大文字変換）
		String newProductName = newRequest.productName.trim().toUpperCase();

		// 未掲載製品及び新バージョンの登録要求または新規バージョン登録の登録要求の場合
		if(newRequest.reqType == RequestType.NEWPRODUCT || newRequest.reqType == RequestType.NEWVERSION) {
			// 同じ製品名・バージョンは登録不可
			sql = "select p.id from product as p, release as r where p.id = r.product_id and upper(p.name) = upper(:pname) and r.version = :version";

			query = Ebean.createSqlQuery(sql);
			query.setParameter("pname", newRequest.productName);
			query.setParameter("version", newRequest.version);

			result = query.findList();

			if(result.size() > 0) {
				return ERR_SAME_PRODUCT_VERSION;
			}
		}
//		// 新規バージョン登録の登録要求の場合
//		} else if(newRequest.reqType == RequestType.NEWVERSION){
//			sql = "select p.id from product as p, release as r where p.id = r.product_id and p.name = :pname and r.version = :version";
//
//			SqlQuery query = Ebean.createSqlQuery(sql);
//			query.setParameter("pname", newRequest.productName);
//			query.setParameter("version", newRequest.version);
//
//			result = query.findList();
//
//			if(result.size() > 0) {
//				return ERR_SAME_PRODUCT_VERSION;
//			}
//		}

		// 同じ製品名・バージョンで申請がされているか？
		sql = "select req.id from maintenance_request as req where upper(req.product_name) = upper(:pname) and req.version = :version and req.status = :status";

		query = Ebean.createSqlQuery(sql);
		query.setParameter("pname", newProductName);
		query.setParameter("version", newRequest.version);
		query.setParameter("status", Progress.OPEN);

		result = query.findList();

		if(result.size() > 0) {
			return ERR_SAME_PRODUCT_NAME_VERSION;
		}
		return null;
	}

	/**
	 * 登録リクエストを検索条件にしたがって取得する
	 *
	 * @param type 申請タイプ
	 * @param status ステータス
	 * @param oss OSS名
	 * @param version バージョン
	 * @param section 部署名
	 * @param username 申請者名
	 * @param startDate 申請日（開始）
	 * @param endDate 申請日（終了）
	 * @param prefStartDate 希望納期（開始）
	 * @param prefEndDate 希望納期（終了）
	 * @return
	 */
	public static List<SqlRow> getConditionedMaintenanceRequest(String type,
																String status,
																String oss,
																String version,
																String section,
																String username,
																String startDate,
																String endDate,
																String prefStartDate,
																String prefEndDate) {
		StringBuilder sb = new StringBuilder();

		sb.append("select ");
		sb.append("  a.id, ");
		sb.append("  a.product_name, ");
		sb.append("  a.version, ");
		sb.append("  a.prefered_date, ");
		sb.append("  a.req_type, ");
		sb.append("  a.request_str, ");
		sb.append("  a.issue_date, ");
		sb.append("  a.status, ");
		sb.append("  a.status_str, ");
		sb.append("  a.comments, ");
		sb.append("  a.project_id, ");
		sb.append("  a.approve_date, ");
		sb.append("  a.adm_comments, ");
		sb.append("  a.nick_name, ");
		sb.append("  a.user_name, ");
		sb.append("  a.full_name ");
		sb.append("from ");
		sb.append("( ");
		sb.append("  select ");
		sb.append("    req.id, ");
		sb.append("    req.product_name, ");
		sb.append("    req.version, ");
		sb.append("    to_char(req.prefered_date, 'yyyy-mm-dd') as prefered_date, ");
		sb.append("    req.req_type, ");
		sb.append("    case ");
		sb.append("      when req.req_type = '0' then '新バージョン登録要求' ");
		sb.append("      when req.req_type = '1' then '誤植の修正要求' ");
		sb.append("      when req.req_type = '2' then '未掲載OSS及び新バージョンの登録要求' ");
		sb.append("      when req.req_type = '3' then 'その他の要求' ");
		sb.append("      when req.req_type = '4' then '未登録OSSの登録要求' ");
		sb.append("      else '' ");
		sb.append("    end as request_str, ");
		sb.append("    to_char(req.issue_date, 'yyyy-mm-dd') as issue_date, ");
		sb.append("    req.status, ");
		sb.append("    case ");
		sb.append("      when req.status = '0' then '申請中' ");
		sb.append("      when req.status = '1' then '承認済' ");
		sb.append("      when req.status = '2' then '却下済' ");
		sb.append("      when req.status = '3' then '担当決定' ");
		sb.append("      when req.status = '4' then '処理中' ");
		sb.append("      when req.status = '5' then '完了' ");
		sb.append("      when req.status = '6' then '申請取消済' ");
		sb.append("      else '' ");
		sb.append("    end as status_str, ");
		sb.append("    req.comments, ");
		sb.append("    req.project_id, ");
		sb.append("    to_char(req.approve_date, 'yyyy-mm-dd') as approve_date, ");
		sb.append("    req.adm_comments, ");
		sb.append("    prj_inf.nick_name, ");
		sb.append("    (u.family_name || ' ' || u.first_name) as user_name, ");
		sb.append("    prj_inf.full_name ");
		sb.append("  from maintenance_request as req ");
		sb.append("    left join ");
		sb.append("    ( ");
		sb.append("      select p.id, p.nick_name, dept.full_name ");
		sb.append("      from project as p left join dept on p.dept_id = dept.id ");
		sb.append("    ) as prj_inf on req.project_id = prj_inf.id ");
		sb.append("    left join ginjasuser as u on req.user_id = u.id ");
		sb.append(") as a ");
		sb.append("where 1 = 1 ");

		// 引数により条件式をセットする
		if(!"".equals(type) || type.length() != 0) {
			sb.append(" and a.req_type in (" + type + ")");
		}

		if(!"".equals(status) || status.length() != 0) {
			sb.append(" and a.status in (" + status + ")");
		}

		if(!"".equals(oss) || oss.length() != 0) {
			sb.append(" and upper(a.product_name) like upper(:product_name) escape '#'");
		}

		if(!"".equals(version) || version.length() != 0) {
			sb.append(" and a.version = :version");
		}

		if(!"".equals(section) || section.length() != 0) {
			sb.append(" and a.full_name like :section escape '#'");
		}

		if(!"".equals(username) || username.length() != 0) {
			sb.append(" and a.user_name like :username escape '#'");
		}

		if(!"".equals(startDate) || startDate.length() != 0) {
			sb.append(" and (a.issue_date >= to_char(to_date(:start_date, 'yyyy-mm-dd'), 'yyyy-mm-dd') and a.issue_date <= to_char(to_date(:end_date, 'yyyy-mm-dd'), 'yyyy-mm-dd'))");
		}

		if(!"".equals(prefStartDate) || prefStartDate.length() != 0) {
			sb.append(" and (a.prefered_date >= to_char(to_date(:pref_start_date, 'yyyy-mm-dd'), 'yyyy-mm-dd') and a.prefered_date <= to_char(to_date(:pref_end_date, 'yyyy-mm-dd'), 'yyyy-mm-dd'))");
		}

		sb.append("order by prefered_date asc, issue_date asc, product_name asc, version asc ");

		String sql = sb.toString();

		SqlQuery query = Ebean.createSqlQuery(sql);

		query.setParameter("product_name", "%" + oss + "%");
		query.setParameter("version", version);
		query.setParameter("section", "%" + section + "%");
		query.setParameter("username", "%" + username + "%");
		query.setParameter("start_date", startDate);
		query.setParameter("end_date", endDate);
		query.setParameter("pref_start_date", prefStartDate);
		query.setParameter("pref_end_date", prefEndDate);

		return query.findList();
	}

	/**
	 * 管理者向けコメントを更新する
	 *
	 * @param id 更新リクエストID
	 * @param comment コメント内容
	 */
	public static void updateAdminComment(Long id, String comment) {
		MaintenanceRequest req = find.byId(id);
		Date today = new Date();

		req.admComments = comment;
		req.lastUpdateDate = today;

		req.update();
	}
}
