package models;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Expr;
import com.avaje.ebean.Model;
import com.avaje.ebean.PagedList;
import com.avaje.ebean.SqlQuery;
import com.avaje.ebean.SqlRow;
import com.typesafe.config.ConfigFactory;

import controllers.Application;
import play.api.Play;

@Entity
public class Product extends Model {
    	// 本番環境用ロゴ画像ディレクトリ
    	public static final String LOGOS_PATH = ConfigFactory.load().getString("logos.path");

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "product_seq")
	public Long id;
	public String name;
	public String description;
	public String projectUrl;
	public String logo;
	public String repository;
	public Date lastUpdate;

	@ManyToOne
	public Organization developedBy;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "product_tag")
	public List<Tag> tags;

	//	@ManyToMany(cascade = CascadeType.ALL)
//	@JoinTable(name = "product_license")
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "product_license",
		joinColumns = { @JoinColumn(name = "product_id", referencedColumnName =	"id") },
		inverseJoinColumns = { @JoinColumn(name = "license_id", referencedColumnName = "id") }
	)
	public List<License> declaredLicenses;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "product")
	public List<Release> releases = new ArrayList<Release>();
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "product")
	public List<ProductTopic> topics = new ArrayList<ProductTopic>();
	public Boolean isAvailableForStore;


        public static final String DEFAULT_IMAGE_PATH = "/assets/images/openhub/default.png";

	public static Finder<Long, Product> find = new Finder<Long, Product>(Product.class);

	public static List<Product> findAll() {
		return find.findList();
	}

	public static Product findById(Long id) {
		return find.byId(id);
	}

	public static PagedList<Product> page(int nth, int pageSize, String sortCol, String order) {
//		PagedList<Product> products = find.orderBy(sortCol + " " + order).findPagedList(nth, pageSize);

		// デフォルトは登録・未登録、OSS製品名をソートキー
		String orderBy = "is_available_for_store desc, name asc";

		// ソートの指定があればそれを第1キーに指定
		if(!"".equals(sortCol) || sortCol.length() != 0) {
			orderBy = sortCol + " " + order + ", " + orderBy;
		}

		PagedList<Product> products;
		if(Application.isAdminUser()) {
			products = find.orderBy(orderBy).findPagedList(nth, pageSize);
		} else {
			products = find.where().eq("is_available_for_store", true).orderBy(orderBy).findPagedList(nth, pageSize);
		}
		return products;
	}

	public static PagedList<Product> findWithCategoryName(String categoryName, int nth, int pageSize) {
		PagedList<Product> products;
		if(Application.isAdminUser()) {
			products = find.where().eq("tags.symbol", categoryName).findPagedList(nth, pageSize);
		} else {
			products = find.where().eq("tags.symbol", categoryName)
									.eq("is_available_for_store", true)
									.findPagedList(nth, pageSize);
		}
		return products;
	}

	public static List<Product> findAllOrderByDate() {
		List<Product> products;
		if(Application.isAdminUser()) {
			products = find.orderBy("last_update desc").findList();
		} else {
			products = find.where().eq("is_available_for_store", true).orderBy("last_update desc").findList();
		}
		return products;
	}

	public static PagedList<Product> findMatches(String match, int nth, int pageSize) {
		String orderby = "is_available_for_store desc, name asc";

		PagedList<Product> products;

		if(Application.isAdminUser()) {
			products = find.where().disjunction()
										.like("UPPER(name)", "%" + match.toUpperCase() + "%")
										.like("UPPER(description)", "%" + match.toUpperCase() + "%")
										.like("UPPER(tags.symbol)", "%" + match.toUpperCase() + "%")
									.endJunction()
									.orderBy(orderby)
									.findPagedList(nth, pageSize);
		} else {
			products = find.where().disjunction()
					.like("UPPER(name)", "%" + match.toUpperCase() + "%")
					.like("UPPER(description)", "%" + match.toUpperCase() + "%")
					.like("UPPER(tags.symbol)", "%" + match.toUpperCase() + "%")
				.endJunction()
				.eq("is_available_for_store", true)
				.orderBy(orderby)
				.findPagedList(nth, pageSize);
		}
		return products;
	}

	public static List<Product> findMatchingProducts(String match, Boolean isExactMatchOnly) {
		List<Product> products;
		if (isExactMatchOnly) {
			products = find.where().ilike("name", match).findList();
		} else {
			products = find.where().or(Expr.ilike("name", "%" + match.trim() + "%"),
					Expr.ilike("description", "%" + match.trim() + "%")).findList();
		}
		return products;
	}

	public static List<Product> findProductsWithTag(String tagname) {
		List<Product> products = find.where().or(Expr.ilike("tags.symbol", "%" + tagname + "%"),
				Expr.ilike("tags.explanatoryName", "%" + tagname + "%")).findList();
		return products;
	}
	public static List<Product> findProductsWithOrganization(Long orgid) {
		List<Product> products = find.where().eq("developed_by_id", orgid).findList();
		return products;
	}

	public List<ProductReview> getReviews() {
		List<ProductReview> results = ProductReview.findReviewsFor(this);
		return results;
	}

	public List<ProductTopic> getTopics() {
		List<ProductTopic> topics = ProductTopic.findTopics(this, 0);
		return topics;
	}

        public static List<String> getLogoFileNames() {
            	final java.io.File root;
            	if (Play.isProd(Play.current()) && LOGOS_PATH != null) {
            	    root = new java.io.File(LOGOS_PATH);
            	} else {
            	    root = Play.current().getFile("public/images/openhub/");
            	}

                List<String> names = new java.util.LinkedList<String>();
                for ( java.io.File file : root.listFiles()) {
                    names.add(file.getName());
                }
                return names;
        }
	public void removeLicense(Long lid) {
		this.declaredLicenses.remove(License.find.ref(lid));
		Ebean.saveManyToManyAssociations(this, "declaredLicenses");
	}

	public void addLicense(Long lid) {
	        this.declaredLicenses.add(License.find.ref(lid));
		Ebean.saveManyToManyAssociations(this, "declaredLicenses");
	}

	/**
	 * 検索文字列に一致する件数を返す
	 *
	 * @param word
	 * @return
	 */
	public static int getSearchCount(String word, boolean isAdmin) {
		int nRet = 0;

		StringBuilder sb = new StringBuilder();
		sb.append("select count(*) as cnt from ");
		sb.append(" ( ");
		sb.append("   select distinct(p.id) ");
		sb.append("   from product as p left join product_tag as t on p.id = t.product_id ");
		sb.append("   where 1=1 ");

		if(!isAdmin) {
			sb.append("   and p.is_available_for_store = true ");
		}

		sb.append("   and( ");
		sb.append("     UPPER(p.name) like :pname or ");
		sb.append("     UPPER(p.description) like :desc or ");
		sb.append("     UPPER(t.tag_symbol) like :symbol ");
		sb.append("   ) ");
		sb.append(" ) as a");

		String sql = sb.toString();

		SqlQuery query = Ebean.createSqlQuery(sql);
		query.setParameter("pname", "%" + word.toUpperCase() + "%");
		query.setParameter("desc", "%" + word.toUpperCase() + "%");
		query.setParameter("symbol", "%" + word.toUpperCase() + "%");

		List<SqlRow> result = query.findList();

		if(!result.isEmpty()) {
			nRet = result.get(0).getInteger("cnt");
		}
		return nRet;
	}

        public static Long addProduct(String             name
                                     ,String             description
                                     ,String             projectUrl
                                     ,String             logo
                                     ,String             repository
                                     ,Organization       developedBy
                                     ,List<Tag>          tags
                                     ,List<License>      declaredLicenses
                                     ,List<ProductTopic> topics
                                     ,Boolean            isAvailableForStore) {
            Product product = new Product();
            product.name                = name;
            product.description         = description;
            product.projectUrl          = projectUrl;
            product.logo                = logo;
            product.repository          = repository;
            product.developedBy         = developedBy;
            product.tags                = tags;
            product.declaredLicenses    = declaredLicenses;
//            product.topics              = topics;
            product.isAvailableForStore = isAvailableForStore;
            product.lastUpdate          = new Date();

            product.save();

            return product.id;
        }

        public static void updateProduct(Long               id
                                        ,String             name
                                        ,String             description
                                        ,String             projectUrl
                                        ,String             logo
                                        ,String             repository
                                        ,Organization       developedBy
                                        ,List<Tag>          tags
                                        ,List<License>      declaredLicenses
                                        ,List<ProductTopic> topics
                                        ,Boolean            isAvailableForStore) {
            Product product = Product.findById(id);
            System.out.println(product.releases);
            product.name                = name;
            product.description         = description;
            product.projectUrl          = projectUrl;
            product.logo                = logo;
            product.repository          = repository;
            product.developedBy         = developedBy;
            product.tags                = tags;
            product.declaredLicenses    = declaredLicenses;
//            product.topics              = topics;
            product.isAvailableForStore = isAvailableForStore;
            product.lastUpdate          = new Date();

            product.update();

        }

        public static void deleteProduct(Long id) {
            Product product = Product.findById(id);
            product.delete();
        }

        // カタログでNEWアイコンを表示するために使用
        public boolean isNew() {
        	if (this.lastUpdate == null)
        	    return false;
        	ZonedDateTime oneMonthBefore = ZonedDateTime.now().minusMonths(1);
        	ZonedDateTime lastUpdate = ZonedDateTime.ofInstant(Instant.ofEpochMilli(this.lastUpdate.getTime()),
        		ZoneId.systemDefault());
        	return lastUpdate.isAfter(oneMonthBefore);
        }

        /**
         * Ginjasカタログでダウンロード可能かどうかを返す<br/>
         * ※媒体種別がmaven2のものはダウンロード可能としない
         * @return
         */
        public boolean isDownloadAvailable() {
    		if (this.releases.isEmpty()) {
    		    return false;
    		}
    		for (Release release : releases) {
		    for (Medium medium : release.media) {
			if (!"maven2".equals(medium.packageType)) {
			    return true;
			}
		    }
		}
    		return false;
        }

    /**
     * カテゴリに一致するOSS製品の件数を返す
     *
     * @param name カテゴリ名
     * @return
     */
	public static int getCounWithCategoryName(String name, boolean isAdmin) {

		List<Product> result;
		if(!isAdmin) {
			result = find.where().eq("tags.symbol", name).eq("is_available_for_store", true).findList();
		} else {
			result = find.where().eq("tags.symbol", name).findList();
		}
		return result.size();
	}
}
