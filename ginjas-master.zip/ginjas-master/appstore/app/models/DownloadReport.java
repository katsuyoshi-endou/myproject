package models;

import java.util.ArrayList;
import java.util.List;

import com.avaje.ebean.SqlRow;

public class DownloadReport {
	private String projectName;

	public List<DownloadInfo> details;

	public DownloadReport() {
		details = new ArrayList<DownloadInfo>();
	}

	public void setDownloadDetail(SqlRow row) {
		DownloadInfo dl = new DownloadInfo();
		dl.setDownloadDetail(row);

		details.add(dl);
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String pname) {
		this.projectName = pname;
	}

	public class DownloadInfo {
		private String userName;
		private String productName;
		private String productVersion;
		private String userSection;
		private String license;
		private String downloadDate;
		private String notes;

		public DownloadInfo() {
			userName = "";
			productName = "";
			productVersion = "";
			userSection = "";
			license = "";
			downloadDate = "";
			notes = "";
		}

		public String getUserName() {
			return userName;
		}

		public void setUserName(String uname) {
			this.userName = uname;
		}

		public String getProductName() {
			return productName;
		}

		public void setProductName(String pname) {
			this.productName = pname;
		}

		public String getProductVersion() {
			return productVersion;
		}

		public void setProductVersion(String version) {
			this.productVersion = version;
		}

		public String getUserSection() {
			return userSection;
		}

		public void setUserSection(String section) {
			this.userSection = section;
		}

		public String getLicense() {
			return license;
		}

		public void setLicense(String license) {
			this.license = license;
		}

		public String getDownloadDate() {
			return downloadDate;
		}

		public void setDownloadDate(String date) {
			this.downloadDate = date;
		}

		public String getNotes() {
			return notes;
		}

		public void setNotes(String notes) {
			this.notes = notes;
		}

		private void setDownloadDetail(SqlRow row) {
			this.setUserName(row.getString("user_name"));
			this.setProductName(row.getString("name"));
			this.setProductVersion(row.getString("version"));
			this.setUserSection(row.getString("full_name"));
			this.setLicense(row.getString("licenses"));
			this.setDownloadDate(row.getString("dl_date"));

			// 注意書きとして GPL, AGPL, LGPLを含んだライセンスか？
			if("1".equals(row.getString("warn_flg"))) {
				String[] license = row.getString("licenses").split(",");
				String check = "";
				for(String l: license) {
					if(l.toUpperCase().indexOf("LGPL") >= 0) {
						check = l;
						break;
					} else if(l.toUpperCase().indexOf("AGPL") >= 0) {
						check = l;
						break;
					} else if(l.toUpperCase().indexOf("GPL") >= 0) {
						check = l;
						break;
					}
				}
				this.setNotes(String.format("※本OSSは%sライセンスです。　使用条件を十分に理解の上、ご利用ください。", check));
			}
		}
	}
}
