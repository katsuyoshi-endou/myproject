package models;

import java.util.List;

import javax.persistence.MappedSuperclass;

import com.avaje.ebean.Model;

/**
 * Development Organization of Open Source Software Products
 */

@MappedSuperclass
public abstract class AbstractOrganization extends Model {
	/**
	 * @Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
	 *
	 * 本来は上記のように指定して、AbstractOrganizationの定義をOraganizationに持たせて、
	 * AbstractOrganizationクラスを使わず、ServicesProviderはOrganizationを継承すべきだが、
	 * Ebeanの制限でTABLE_SINGLEしかサポートしていないために、やむなく現状の継承関係にしてある。
	 *
	 */

	public enum OrganizationType {
		COMMERCIAL("営利企業"), UMBRELLA_FOUNDATION("大規模基金"), DEDICATED_FOUNDATION("専用基金"), OTHER_NPO(
				"その他の非営利組織"), VOLUNTEERS("流動的な開発者集団"), ACADEMIA("学術研究機関"), INDIVIDUAL("個人");

		private String name;

		OrganizationType(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}
	}

	// シーケンスを使うため、@Idは各クラスで定義する
	// @Id
	// Long id;
	public String fullname;
	public String url;
	public OrganizationType orgType; // TODO: elaborated analysis required ...

	public static Finder<Long, AbstractOrganization> find = new Finder<Long, AbstractOrganization>(
			AbstractOrganization.class);

	public static List<AbstractOrganization> findAll() {
		return find.findList();
	}
}
