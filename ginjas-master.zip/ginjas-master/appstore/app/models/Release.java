package models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.avaje.ebean.Model;

@Entity
public class Release extends Model {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "release_seq")
	public Long seq;

	public String version;
	public String description;

	@ManyToOne
	@JoinColumn(name = "product_id")
	public Product product;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "release")
	public List<Medium> media = new ArrayList<Medium>();

	public Date releasedDate;
	/*
	 * let 'isStable' be false for releases like development release, RC
	 * milestones, nightly builds, etc
	 */
	public Boolean isStable;
	/*
	 * let 'isActive' be false for obsolete releases, including those superseded
	 * by significant vulnerability fixes, as well as abandoned releases without
	 * further community support.
	 */
	public Boolean isActive;
	/*
	 * 'isUptodate' should indicate the newest stable release in a version
	 * series. so there can be more than one `up-to-date` releases.
	 */
	public Boolean isUptodate;

	public static Finder<Long, Release> find = new Finder<Long, Release>(Release.class);

	public static Release findById(Long id) {
		return find.byId(id);
	}

	public static List<Release> findAll() {
		return find.findList();
	}

	public static List<Release> findCurrentReleases() {
		List<Release> matched = find.where().eq("is_stable", true).eq("is_active", true).eq("is_uptodate", true)
				.orderBy("releasedDate desc").findList();
		return matched;
	}

        public static void addRelease(String  version
                                     ,String  description
                                     ,Product product
                                     ,Date    releasedDate
                                     ,Boolean isStable
                                     ,Boolean isActive
                                     ,Boolean isUptodate) {
            Release release = new Release();
            release.version      = version;
            release.description  = description;
            release.product      = product;
            release.releasedDate = releasedDate;
            release.isStable     = isStable;
            release.isActive     = isActive;
            release.isUptodate   = isUptodate;
            release.save();

        }

        public static void updateRelease(Long    seq
                                        ,String  version
                                        ,String  description
                                        ,Product product
                                        ,Date    releasedDate
                                        ,Boolean isStable
                                        ,Boolean isActive
                                        ,Boolean isUptodate) {
            Release release = Release.findById(seq);
            release.version      = version;
            release.description  = description;
            release.product      = product;
            release.releasedDate = releasedDate;
            release.isStable     = isStable;
            release.isActive     = isActive;
            release.isUptodate   = isUptodate;
            release.update();

        }

        public static void deleteRelease(Long seq) {
            Release release = Release.findById(seq);
            release.delete();
        }
}
