package models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityNotFoundException;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Model;
import com.avaje.ebean.SqlQuery;
import com.avaje.ebean.SqlRow;

import play.Logger;


/**
 * UserProduct: ユーザーの利用中OSSが記録される
 */
@Entity
public class UserProduct extends Model {

        @Id
        @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_product_seq")

        public Long seq;
	@ManyToOne
	@JoinColumn(name = "user_id")
        public User user;
	@ManyToOne
	@JoinColumn(name = "project_id")
        public Project project;
	@ManyToOne
	@JoinColumn(name = "product_id")
        public Product product;
	@ManyToOne
	@JoinColumn(name = "release_seq")
        public Release release;
        public Date startedOn;
        public Date endedOn;
        public String notes;

        public static Finder<Long, UserProduct> find = new Finder<Long, UserProduct>(UserProduct.class);

        public static void addRelease(User user, Project project, Release release) {
                List<UserProduct> entries = find.where().eq("user_id", user.id)
                                                         .eq("project_id", project.id)
                                                         .eq("release_seq", release.seq)
                                                         .findList();

                if (entries.size() > 0) {
                        return;
                }

                UserProduct up = new UserProduct();

                up.user         = user;
                up.project      = project;
                up.product      = release.product;
                up.release      = release;
                up.startedOn    = new Date();
                up.endedOn      = null;
                up.notes		= null;
                up.save();
	}

    /**
     * 利用OSS情報更新処理<br/>
     * 第３引数の状態により、利用開始日。停止日の更新を行います。<br/>
     * 　０：「利用中」のチェックボタンに対してなんのアクションもしていない（プロジェクト名の更新と予想）<br/>
     * 　１：「更新」ボタンを押したときの「利用中」のチェックボタンの状態がチェックONだった（利用を再開する）<br/>
     * 　２：「更新」ボタンを押したときの「利用中」のチェックボタンの状態がチェックOFFだった（今日で利用を停止する）<br/>
     * 　※基本的に「更新」ボタンを押したときのチェックボタンの状態がどうであったかで処理を判定しています（途中にチェックのON/OFFを繰り返しても関係なし）。
     *
     * @param seqs 更新対象となるuser_productテーブルのid
     * @param projectIds 更新するプロジェクトID
     * @param useStatus OSS利用状態（０：利用中の更新なし、１：利用開始、２：利用停止）
     * @param notes 備考
     */
    public static void updateUserProduct(String[] seqs, String[] projectIds, String[] useStatus, String[] notes) {
    	// まとめて更新をかけるためトランザクションの開始を定義
    	Ebean.beginTransaction();

    	try {
    	    	StringBuilder info = new StringBuilder();
    		for(int i = 0; i < seqs.length; i++) {
    			UserProduct userProduct = UserProduct.find.byId(Long.parseLong(seqs[i]));
    			Project prj = Project.findById(Long.parseLong(projectIds[i]));

    			// 変更前のプロジェクト情報を取っておく
    			// ginjas以外で取得した場合、UserProductのproject_idにはなにも入っていないか、存在しないid？
    			// このとき、プロジェクトの情報はnullではなく、EntityNotFoundExceptionを発生させる
				// ログのデータで更新をすべてロールバックさせないように例外を捕らえて、固定文字列をセット
    			String oldNickName = "";
    			try {
    				Project oldPrj = userProduct.project;
    				oldNickName = oldPrj.nickName;
    			} catch(EntityNotFoundException e) {
    				oldNickName = "未設定";
    			}

    			// プロジェクトＩＤをセット
    			userProduct.project = prj;
    			userProduct.notes = notes[i] == "" ? null : notes[i];

    			// 利用開始日・停止日の変更なし（プロジェクト名の変更もしくはただ「更新」をチェックした？）
    			if("0".equals(useStatus[i])) {
//    				System.out.println(String.format("【PRJ変更】PRJ: %s → %s, %s-%s ", oldPrj.nickName, prj.nickName, userProduct.product.name, userProduct.release.version));
//    				if (!oldPrj.nickName.equals(prj.nickName)) {
//    			        info.append(String.format("【PRJ変更】PRJ: %s → %s, %s-%s ", oldPrj.nickName, prj.nickName, userProduct.product.name, userProduct.release.version));
//    			    }
    				if (!oldNickName.equals(prj.nickName)) {
    			        info.append(String.format("【PRJ変更】PRJ: %s → %s, %s-%s ", oldNickName, prj.nickName, userProduct.product.name, userProduct.release.version));
    			    }
    				// 基本何もしない
    			} else if("1".equals(useStatus[i])) {
    				// 利用開始（再開）
    				userProduct.endedOn = null;

    				info.append(String.format("【利用開始】PRJ: %s, %s-%s ", prj.nickName, userProduct.product.name, userProduct.release.version));
    			} else if("2".equals(useStatus[i])) {
    				// 利用停止
    				userProduct.endedOn = new Date();

    				info.append(String.format("【利用停止】PRJ: %s, %s-%s ", prj.nickName, userProduct.product.name, userProduct.release.version));
    			} else {
    				continue;
    			}
//    			userProduct.save();
    			userProduct.update();

			// 活動履歴の保存
			ActivityRecord.saveActivity(info.toString(), userProduct.user, ActivityRecord.ActivityType.UPDATEUSE);
    		}
        	Ebean.commitTransaction();
    	} catch(Exception e) {
    	    Logger.info("Exception occurred in UserProduct.updateUserProduct() method. message : " + e.getMessage());
    		Ebean.rollbackTransaction();
    	} finally {
        	Ebean.endTransaction();
    	}
    }

    /**
     * 利用中OSSの情報をユーザー、OSS製品名、バージョンをキーにして取得する。
     *
     * @param userId
     * @param productId
     * @param version
     * @return
     */
    public static List<SqlRow> getUseOssList(Long userId, Long productId, String ver) {
		StringBuilder sb= new StringBuilder();

		sb.append("select ");
		sb.append("  oss.seq, ");
		sb.append("  oss.project_id, ");
		sb.append("  prj.nick_name, ");
		sb.append("  prj.full_name, ");
		sb.append("  trim(guser.family_name || ' ' || guser.first_name) as user_name, ");
		sb.append("  prd.name, ");
		sb.append("  rel.version, ");
		sb.append("  case ");
		sb.append("    when oss.ended_on is null then '1' ");
		sb.append("    else '0' ");
		sb.append("  end as in_use, ");
		sb.append("  oss.started_on, ");
		sb.append("  oss.ended_on ");
		sb.append("from (((( user_product as oss ");
		sb.append("  left join ( select p.id, p.nick_name, dept.full_name from project as p left join dept on p.dept_id = dept.id ) as prj on oss.project_id = prj.id ) ");
		sb.append("  left join ginjasuser as guser on oss.user_id = guser.id ) ");
		sb.append("  left join product as prd on oss.product_id = prd.id ) ");
		sb.append("  left join release as rel on oss.release_seq = rel.seq ) ");
		sb.append("where 1 = 1 ");

		if(userId != null) {
			sb.append(" and guser.id = :userid");
		}

		if(productId != null) {
			sb.append(" and oss.product_id = :productid");
		}

		if(!"".equals(ver) || ver.length() > 0) {
			sb.append(" and rel.version = :version ");
		}

//		sb.append(" order by in_use desc, started_on asc");
		sb.append(" order by in_use desc, started_on asc, prd.name asc, rel.version asc, prj.full_name asc, user_name asc");

		String sql = sb.toString();

		SqlQuery query = Ebean.createSqlQuery(sql);
		query.setParameter("userid", userId);
		query.setParameter("productid", productId);
		query.setParameter("version", ver);

		return query.findList();
    }

    /**
     * 条件に一致する利用中OSS情報を取得する（管理者向け）
     *
     * @param status 利用中 or 利用停止
     * @param productId OSS製品ID
     * @param version バージョン
     * @param useStartDate 利用開始日（開始）
     * @param useEndDate 利用開始日（終了）
     * @param stopStartDate 利用停止日（開始）
     * @param stopEndDate 利用停止日（終了）
     * @return
     */
    public static List<SqlRow> getUseOSSListByCondition(String[] status, Long productId, String version, String useStartDate, String useEndDate, String stopStartDate, String stopEndDate) {
    	StringBuilder sb = new StringBuilder();

    	sb.append("select ");
    	sb.append("   a.seq, ");
    	sb.append("   a.product_id, ");
    	sb.append("   a.nick_name, ");
    	sb.append("   a.full_name, ");
    	sb.append("   a.user_name, ");
    	sb.append("   a.name, ");
    	sb.append("   a.version, ");
    	sb.append("   a.in_use, ");
    	sb.append("   a.started_on, ");
    	sb.append("   a.ended_on ");
    	sb.append(" from ");
    	sb.append(" ( ");
    	sb.append("   select ");
    	sb.append("     oss.seq, ");
    	sb.append("     oss.product_id, ");
    	sb.append("     prj.nick_name, ");
    	sb.append("     prj.full_name, ");
    	sb.append("     trim (guser.family_name || ' ' || guser.first_name) as user_name, ");
    	sb.append("     prd.name, ");
    	sb.append("     rel.version, ");
    	sb.append("     case ");
    	sb.append("       when oss.ended_on is null then '1' ");
    	sb.append("       else '0' ");
    	sb.append("     end as in_use, ");
    	sb.append("     to_char(oss.started_on, 'yyyy-mm-dd') as started_on, ");
    	sb.append("     to_char(oss.ended_on, 'yyyy-mm-dd' ) as ended_on ");
    	sb.append("   from (((( user_product as oss ");
    	sb.append("     left join ( select p.id, p.nick_name, dept.full_name from project as p left join dept on p.dept_id = dept.id ) as prj on oss.project_id = prj.id ) ");
    	sb.append("     left join ginjasuser as guser on oss.user_id = guser.id ) ");
    	sb.append("     left join product as prd on oss.product_id = prd.id ) ");
    	sb.append("     left join release as rel on oss.release_seq = rel.seq ) ");
    	sb.append(" ) as a ");
		sb.append("where 1 = 1 ");

		// 引数の値を条件に設定する
		try {
			// 利用区分
			if(status.length == 1 && "0".equals(status[0])) {
				// どちらか一方しかチェックされていなくて、「0（利用中）」のとき
				sb.append(" and a.ended_on IS NULL");
			} else if(status.length == 1 && "1".equals(status[0])) {
				// どちらか一方しかチェックされていなくて、「1（利用停止）」のとき
				sb.append(" and a.ended_on IS NOT NULL");
			}

			if(productId != null) {
				sb.append(" and a.product_id = :productid");
			}

			if(!"".equals(version)) {
				sb.append(" and a.version = :version");
			}

			sb.append(" and (a.started_on >= to_char(to_date(:useStartDate, 'yyyy-mm-dd'), 'yyyy-mm-dd') and a.started_on <= to_char(to_date(:useEndDate, 'yyyy-mm-dd'), 'yyyy-mm-dd'))");

			// 利用停止日については日付の指定がなければ条件に入れない
			if(!"1900-01-01".equals(stopStartDate) || !"9999-12-31".equals(stopEndDate)) {
				sb.append(" and (a.ended_on >= to_char(to_date(:stopStartDate, 'yyyy-mm-dd'), 'yyyy-mm-dd') and a.ended_on <= to_char(to_date(:stopEndDate, 'yyyy-mm-dd'), 'yyyy-mm-dd'))");
			}
//			sb.append(" order by in_use desc, started_on asc");
			sb.append(" order by in_use desc, started_on asc, name asc, version asc, full_name asc, user_name asc");

			String sql = sb.toString();

			SqlQuery query = Ebean.createSqlQuery(sql);
			query.setParameter("productid", productId);
			query.setParameter("version", version);
			query.setParameter("useStartDate", useStartDate);
			query.setParameter("useEndDate", useEndDate);
			query.setParameter("stopStartDate", stopStartDate);
			query.setParameter("stopEndDate", stopEndDate);

			return query.findList();
		} catch(Exception e) {
			Logger.info(e.getMessage());
			return null;
		}
    }

    /**
     * 利用OSSの情報を検索条件に従って取得する（一般ユーザー向け）
     *
     * @param uid ユーザーID
     * @param status 利用状況
     * @param projectId プロジェクトID
     * @param section 利用部署名
     * @param username 利用者名
     * @param startDate 利用開始日（開始）
     * @param endDate 利用開始日（終了）
     * @param option オプション
     * @return
     */
    public static List<SqlRow> getUseOssListByUserCondition(Long uid, String status, Long projectId, Long productId, String section, String username, String startDate, String endDate, String option) {
    	StringBuilder sb = new StringBuilder();

		// 自分が取得したOSSのみ
		if("1".equals(option)) {
			sb.append("select ");
			sb.append("  list.seq, ");
			sb.append("  list.project_id, ");
			sb.append("  list.product_id, ");
			sb.append("  list.nick_name, ");
			sb.append("  list.full_name, ");
			sb.append("  list.user_name, ");
			sb.append("  list.name, ");
			sb.append("  list.version, ");
			sb.append("  list.notes, ");
			sb.append("  list.in_use, ");
			sb.append("  list.own_use, ");
			sb.append("  list.started_on, ");
			sb.append("  list.ended_on ");
			sb.append("from ");
			sb.append("( ");
			sb.append("  select ");
			sb.append("    oss.seq, ");
			sb.append("    oss.project_id, ");
			sb.append("    oss.product_id, ");
			sb.append("    prj.nick_name, ");
			sb.append("    prj.full_name, ");
			sb.append("    trim(guser.family_name || ' ' || guser.first_name) as user_name, ");
			sb.append("    prd.name, ");
			sb.append("    rel.version, ");
			sb.append("    oss.notes, ");
			sb.append("    case ");
			sb.append("      when oss.ended_on is null then '1' ");
			sb.append("      else '0' ");
			sb.append("    end as in_use, ");
			sb.append("    0 as own_use, ");
			sb.append("    to_char(oss.started_on, 'yyyy-mm-dd') as started_on, ");
			sb.append("    to_char(oss.ended_on, 'yyyy-mm-dd') as ended_on ");
			sb.append("  from (((( user_product as oss ");
			sb.append("    left join ( select p.id, p.nick_name, dept.full_name from project as p left join dept on p.dept_id = dept.id ) as prj on oss.project_id = prj.id ) ");
			sb.append("    left join ginjasuser as guser on oss.user_id = guser.id ) ");
			sb.append("    left join product as prd on oss.product_id = prd.id ) ");
			sb.append("    left join release as rel on oss.release_seq = rel.seq ) ");
			sb.append("  where guser.id = :userid ");
			sb.append(") as list ");
			sb.append("where 1 = 1 ");
		} else if("0".equals(option)) {
			// 自分が参加するプロジェクト経由で利用OSS情報を取得する
			sb.append("select ");
			sb.append("  b.seq, ");
			sb.append("  b.project_id, ");
			sb.append("  prj.nick_name, ");
			sb.append("  prj.full_name, ");
			sb.append("  b.user_name, ");
			sb.append("  b.product_id, ");
			sb.append("  prd.name, ");
			sb.append("  b.release_seq, ");
			sb.append("  rel.version, ");
			sb.append("  b.started_on, ");
			sb.append("  b.ended_on, ");
			sb.append("  b.notes, ");
			sb.append("  b.own_use, ");
			sb.append("  b.in_use ");
			sb.append("from ");
			sb.append("( ");
			sb.append("  select ");
			sb.append("    up.seq, ");
			sb.append("    up.project_id, ");
			sb.append("    up.product_id, ");
			sb.append("    up.release_seq, ");
			sb.append("    to_char(up.started_on, 'yyyy-mm-dd') as started_on, ");
			sb.append("    to_char(up.ended_on, 'yyyy-mm-dd') as ended_on, ");
			sb.append("    up.notes, ");
			sb.append("    case ");
			sb.append("      when up.user_id = a.user_id then '0' ");
			sb.append("      else '1' ");
			sb.append("    end as own_use, ");
			sb.append("    case ");
			sb.append("      when up.ended_on is null then '1' ");
			sb.append("      else '0' ");
			sb.append("    end as in_use, ");
			sb.append("    trim(gu.family_name || ' ' || gu.first_name) as user_name, ");
			sb.append("    up.user_id ");
			sb.append("  from user_product as up ");
			sb.append("  left join ginjasuser as gu on up.user_id = gu.id, ");
			sb.append("  ( ");
			sb.append("    select user_id, project_id from project_user as pu where pu.user_id = :userid ");
			sb.append("  ) as a ");
			sb.append("  where up.project_id = a.project_id ");
			sb.append(") as b ");
			sb.append("left join ");
			sb.append("( ");
			sb.append("  select p.id, p.nick_name, dept.full_name from project as p left join dept on p.dept_id = dept.id ");
			sb.append(") as prj on b.project_id = prj.id ");
			sb.append("left join product as prd on b.product_id = prd.id ");
			sb.append("left join release as rel on b.release_seq = rel.seq ");
			sb.append("where 1 = 1 ");
		}

		// 引数の値を条件に設定する
		try {
			// OSS名
			if(productId != null) {
				sb.append(" and b.product_id = :product_id ");
			}

			// 利用プロジェクト
			if(projectId != null) {
				sb.append(" and project_id = :project_id ");
			}

			// 利用状況
			if(!"".equals(status) && status.length() != 0) {
				sb.append(" and in_use = :status ");
			}

			// 利用部門
			if(!"".equals(section) && section.length() != 0) {
				sb.append(" and full_name like :section escape '#' ");
			}

			// 利用者名
			if(!"".equals(username) && username.length() != 0){
				sb.append(" and user_name like :username escape '#' ");
			}

			// 利用開始日
			if(!"".equals(startDate) || startDate.length() != 0) {
				sb.append(" and (started_on >= to_char(to_date(:started_on, 'yyyy-mm-dd'), 'yyyy-mm-dd') and started_on <= to_char(to_date(:ended_on, 'yyyy-mm-dd'), 'yyyy-mm-dd')) ");
			}

			sb.append("order by own_use asc, in_use desc, started_on asc, nick_name asc, name asc, version asc ");

			String sql = sb.toString();

			SqlQuery query = Ebean.createSqlQuery(sql);
			query.setParameter("userid", uid);
			query.setParameter("project_id", projectId);
			query.setParameter("product_id", productId);
			query.setParameter("status", status);
			query.setParameter("section", "%" + section + "%");
			query.setParameter("username", "%" + username + "%");
			query.setParameter("started_on", startDate);
			query.setParameter("ended_on", endDate);

			return query.findList();
		} catch(Exception e) {
			Logger.info(e.getMessage());
			return null;
		}
    }

    /**
     * 自身がプロジェクト責任者となっている利用中OSS情報を取得する。<br>
     * 本処理が呼び出されるのは「自分のみ」チェックが外れているとき<br>
     * 　※自身が参加も兼ねているプロジェクトは除く。
     *
     * @param uid ユーザーID
     * @param status 利用状況
     * @param projectId プロジェクトID
     * @param productId OSS製品ID
     * @param section 部門名
     * @param username 氏名
     * @param startDate 利用開始日（開始）
     * @param endDate 利用開始日（終了）
     * @return
     */
    public static List<SqlRow> getUseOSSListByManager(Long uid, String status, Long projectId, Long productId, String section, String username, String startDate, String endDate) {
		List<SqlRow> result = new ArrayList<SqlRow>();

		StringBuilder sb = new StringBuilder();

		sb.append("select ");
		sb.append("  oss_list.seq as seq, ");
		sb.append("  oss_list.user_id as user_id, ");
		sb.append("  oss_list.user_name, ");
		sb.append("  oss_list.project_id, ");
		sb.append("  oss_list.nick_name, ");
		sb.append("  oss_list.full_name, ");
		sb.append("  oss_list.product_id, ");
		sb.append("  oss_list.name, ");
		sb.append("  oss_list.release_seq, ");
		sb.append("  oss_list.version, ");
		sb.append("  oss_list.started_on, ");
		sb.append("  oss_list.ended_on, ");
		sb.append("  oss_list.in_use, ");
		sb.append("  oss_list.own_use, ");
		sb.append("  oss_list.notes ");
		sb.append("from ");
		sb.append("( ");
		sb.append("  select ");
		sb.append("    user_product.seq as seq, ");
		sb.append("    user_product.user_id as user_id, ");
		sb.append("    trim(ginjasuser.family_name || ' ' || ginjasuser.first_name) as user_name, ");
		sb.append("    user_product.project_id as project_id, ");
		sb.append("    prj_info.nick_name as nick_name, ");
		sb.append("    prj_info.full_name as full_name, ");
		sb.append("    user_product.product_id as product_id, ");
		sb.append("    product.name as name, ");
		sb.append("    user_product.release_seq as release_seq, ");
		sb.append("    release.version as version, ");
		sb.append("    to_char(user_product.started_on, 'yyyy-mm-dd') as started_on, ");
		sb.append("    to_char(user_product.ended_on, 'yyyy-mm-dd') as ended_on, ");
		sb.append("    case ");
		sb.append("      when user_product.ended_on is null then '1' ");
		sb.append("      else '0' ");
		sb.append("    end as in_use, ");
		sb.append("    1 as own_use, ");
		sb.append("    user_product.notes as notes ");
		sb.append("  from user_product ");
		sb.append("    left join ginjasuser on user_product.user_id = ginjasuser.id ");
		sb.append("    left join product on user_product.product_id = product.id ");
		sb.append("    left join release on user_product.release_seq = release.seq ");
		sb.append("    left join ");
		sb.append("    ( ");
		sb.append("      select project.id, project.nick_name, dept.full_name ");
		sb.append("      from project ");
		sb.append("        left join dept on project.dept_id = dept.id ");
		sb.append("        where project.id in ");
		sb.append("        ( ");
		sb.append("          select project_id from project_manager where user_id = :userid ");
		sb.append("          except ");
		sb.append("          select project_id from project_user where user_id = :userid ");
		sb.append("        ) ");
		sb.append("    ) as prj_info on user_product.project_id = prj_info.id ");
		sb.append("  where project_id in ");
		sb.append("  ( ");
		sb.append("    select project_id from project_manager where user_id = :userid ");
		sb.append("    except ");
		sb.append("    select project_id from project_user where user_id = :userid ");
		sb.append("  ) ");
		sb.append(") as oss_list ");
		sb.append("where 1 = 1 ");

		// 引数の値を条件に設定する
		try{
			// OSS名
			if(productId != null) {
				sb.append("and oss_list.product_id = :product_id ");
			}

			// 利用プロジェクト
			if(projectId != null) {
				sb.append("and oss_list.project_id = :project_id ");
			}

			// 利用状況
			if(!"".equals(status) && status.length() != 0) {
				sb.append("and oss_list.in_use = :status ");
			}

			// 利用部門
			if(!"".equals(section) && section.length() != 0) {
				sb.append("and oss_list.full_name like :section escape '#' ");
			}

			// 利用者名
			if(!"".equals(username) && username.length() != 0){
				sb.append("and oss_list.user_name like :username escape '#' ");
			}

			// 利用開始日
			if(!"".equals(startDate) || startDate.length() != 0) {
				sb.append("and (oss_list.started_on >= :started_on and oss_list.started_on <= :ended_on) ");
			}
			sb.append("order by oss_list.own_use asc, oss_list.in_use desc, oss_list.started_on asc, oss_list.nick_name asc, oss_list.name asc, oss_list.version asc ");

			String sql = sb.toString();

			SqlQuery query = Ebean.createSqlQuery(sql);
			query.setParameter("userid", uid);
			query.setParameter("project_id", projectId);
			query.setParameter("product_id", productId);
			query.setParameter("status", status);
			query.setParameter("section", "%" + section + "%");
			query.setParameter("username", "%" + username + "%");
			query.setParameter("started_on", startDate);
			query.setParameter("ended_on", endDate);

			return query.findList();
		} catch(Exception e) {
			Logger.info(e.getMessage());
			return result;
		}
	}
}
