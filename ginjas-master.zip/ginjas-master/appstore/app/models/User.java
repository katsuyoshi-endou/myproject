package models;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.codec.digest.Sha2Crypt;
import org.apache.commons.lang3.StringUtils;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Model;
import com.avaje.ebean.SqlQuery;
import com.avaje.ebean.SqlRow;

import auth.LdapAuth;
import play.Logger;
import play.data.validation.Constraints;

@Entity
@Table(name = "GinjasUser")
public class User extends Model {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_seq")
    public Long id;

    @Constraints.Required
    public String username;

    public String password;
    public String familyName;
    public String firstName;
    public String nickname;
    public String email;
    public Boolean isAdmin;
    @ManyToOne
    @JoinColumn(name = "team_id")
    public Team team;
    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "project_user",
		joinColumns = { @JoinColumn(name = "user_id", referencedColumnName = "id") },
		inverseJoinColumns = { @JoinColumn(name = "project_id", referencedColumnName = "id") }
	)
    public List<Project> projects;
    // CAUTION: this is one of the ugliest part in the prototype.
    // The right thing to do here should be to define a relational entity
    // `project_user`
    // and have each record hold a bool field `isCurrent`.
    public Long currentProjectId;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "user_dept", joinColumns = {
	    @JoinColumn(name = "user_id", referencedColumnName = "id") }, inverseJoinColumns = {
		    @JoinColumn(name = "dept_id", referencedColumnName = "id") })
    public List<Dept> depts;

    public static Finder<Long, User> find = new Finder<Long, User>(User.class);

    public String validate() {
    	return authenticate(username, password) ? null : "ユーザーIDまたはパスワードが違います";
//	return authenticate(username, password) ? null : "Invalid username or password";
    }

    private boolean authenticate(String username, String password) {
	// ユーザマスタから取り込み時はパスワードが空となっている
	User user = find.where().eq("username", username).findUnique();
	if (user != null && StringUtils.isNotBlank(user.password)) {
	    // DBに保存されたパスワードで認証。
	    if (verifyPassword(user.password, password)) {
		return true;
	    }
	}

	// LDAP認証を行い、氏名を取得(TODO:これはマスタを取得するから要らなくなったはず)
	Map<String, String> result = LdapAuth.authenticate(username, password);
	if (result == null) {
	    return false;
	} else {
	    User curUser = find.where().eq("username", username).findUnique();
	    if (curUser == null) {
		// DBに未登録の場合、ここで登録
		User u = new User();
		u.username = username;
		u.password = encrypt(password); // LDAPのパスワードはDBに保存しない方がいい？
		u.isAdmin = false;
		u.familyName = result.get(LdapAuth.ATTR_FAMILY_NAME);
		u.firstName = result.get(LdapAuth.ATTR_FIRST_NAME);
		u.save();
	    } else {
		// DB登録済みの場合、ここでパスワードを更新。氏名はユーザマスタから取り込むため書き換えない。
		curUser.password = encrypt(password);
		// curUser.familyName = result.get(LdapAuth.ATTR_FAMILY_NAME);
		// curUser.firstName = result.get(LdapAuth.ATTR_FIRST_NAME);
		curUser.update();
	    }
	    return true;
	}
    }

    /**
     * DB保存用にパスワードを暗号化する。暗号化形式はlibc crypt() 互換の "$6$" ハッシュ文字列
     *
     * @param password
     *            元パスワード
     * @return 暗号化されたパスワード
     */
    public static String encrypt(String password) {
	return Sha2Crypt.sha512Crypt(password.getBytes());
    }

    /**
     * 暗号化されたパスワードとの照合。暗号化形式はlibc crypt() 互換の "$6$" ハッシュ文字列
     *
     * @param encryptPassword
     *            暗号化されたパスワード
     * @param password
     *            元パスワード
     * @return 暗号化されたパスワード
     */
    public static boolean verifyPassword(String encryptPassword, String password) {
	return encryptPassword.equals(Sha2Crypt.sha512Crypt(password.getBytes(), encryptPassword));
    }

    public static Boolean add(String name, String password) {
	return add(name, password, false);
    }

    public static Boolean add(String name, String password, Boolean asAdmin) {
	if (null != find.where().eq("username", name).findUnique())
	    return false;
	User u = new User();
	u.username = name;
	u.password = encrypt(password);
	u.isAdmin = asAdmin;
	try {
	    u.save();
	    return true;
	} catch (Exception ex) { // TODO: change to most specific exception
	    // TODO: signal a failure to user
	    Logger.info("Exception occurred in User.add() method.");
	    return false;
	}
    }

    public static User findById(Long id) {
	return find.byId(id);
    }

    // カレントプロジェクトのIDを設定する

    /**
     * ログインしているユーザのカレントプロジェクトのIDを更新する
     *
     * @param prjid プロジェクトID
     * @param userid ユーザID
     * @return
     */
    public static Boolean updateCurrentProjectId(Long prjid, Long userid) {
    	User curUser = User.find.where().eq("id", userid).findUnique();
    	curUser.currentProjectId = prjid;
    	Project curPrj = Project.findById(prjid);

    	try {
    		curUser.save();

    		// 活動履歴の設定
    		ActivityRecord.saveActivity(curPrj.nickName, curUser, ActivityRecord.ActivityType.SELECTPROJECT);
    		return true;
    	} catch(Exception ex) {
    	    Logger.info("Exception occurred in User.updateCurrentProjectId() method.");
    	    return false;
    	}
    }

    /**
     * 指定された条件に一致するユーザーの情報を取得する
     *
     * @param empNum 社員番号（前方一致）
     * @param username ユーザー名（部分一致）
     * @return
     */
    public static List<SqlRow> searchUser(String empNum, String username) {
		StringBuilder sb = new StringBuilder();

		sb.append("select ");
		sb.append("  id, ");
		sb.append("  username, ");
		sb.append("  emp_name, ");
		sb.append("  full_name ");
		sb.append("from ");
		sb.append("( ");
		sb.append("select ");
		sb.append("  ginjasuser.id, ");
		sb.append("  ginjasuser.username, ");
		sb.append("  (ginjasuser.family_name || ' ' || ginjasuser.first_name) as emp_name, ");
		sb.append("  dept.full_name, ");
		sb.append("  user_dept.is_primary_dept ");
		sb.append("from user_dept ");
		sb.append("  left join ginjasuser on user_dept.user_id = ginjasuser.id ");
		sb.append("  left join dept on user_dept.dept_id = dept.id ");
		sb.append(") as user_info ");
		sb.append("where 1=1 ");
		sb.append("and user_info.is_primary_dept = true ");

		if(!"".equals(empNum) || empNum.length() != 0) {
			sb.append("and upper(user_info.username) like upper(:empNum) escape '#' ");
		}

		if(!"".equals(username) || username.length() != 0) {
			sb.append("and upper(user_info.emp_name) like upper(:username) escape '#' ");
		}
		sb.append("order by user_info.username ");

		String sql = sb.toString();

		SqlQuery query = Ebean.createSqlQuery(sql);
		query.setParameter("empNum", empNum + "%");
		query.setParameter("username", "%" + username + "%");

		return query.findList();
	}

    /**
     * IDの一致するユーザー情報（社員番号・氏名・所属部門名）を取得する
     *
     * @param userid ユーザーIDの配列
     * @return
     */
    public static List<SqlRow> getUserInfoById(String[] userid) {
		StringBuilder sb = new StringBuilder();

		String param = "";
		for(String uid : userid) {
			param = param + uid + ",";
		}

		if("".equals(param) || param.length() == 0) {
			return new ArrayList<SqlRow>();
		}

		param = param.substring(0, param.length() - 1);

		sb.append("select ");
		sb.append("  ginjasuser.id, ");
		sb.append("  ginjasuser.username, ");
		sb.append("  trim(ginjasuser.family_name || ' ' || ginjasuser.first_name) as manager_name, ");
		sb.append("  dept.full_name ");
		sb.append("from user_dept ");
		sb.append("  left join ginjasuser on user_dept.user_id = ginjasuser.id ");
		sb.append("  left join dept on user_dept.dept_id = dept.id ");
		sb.append("where user_dept.is_primary_dept = true ");
		sb.append("and user_dept.user_id in (" + param + ") ");

		String sql = sb.toString();

		return Ebean.createSqlQuery(sql).findList();
	}
}
