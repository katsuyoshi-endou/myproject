package models;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import models.CpeInfo;
import models.License;
import models.Tag;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.SqlQuery;
import com.avaje.ebean.SqlRow;

/**
 * データメンテナンス画面の各種jsonを作成するためのクラス
 */

public class DataMaintenance {

    public static class OrganizationData {
        public String  id;
        public String  name;
    
        public OrganizationData(String id, String name) {
            this.id   = id;
            this.name = name;
        }
    }

    public static class LicenseData {
        public String  id;
        public String  fullname;
        public String  nickname;
        public String  url;
        public String  overview;
        public String  fulltext;
        public String  isOSIApproved;
    
        public LicenseData(String id, String fullname, String nickname, String url, String overivew, String fulltext, String isOSIApproved) {
            this.id             = id;
            this.fullname       = fullname;
            this.nickname       = nickname;
            this.url            = url;
            this.overview       = overview;
            this.fulltext       = fulltext;
            this.isOSIApproved  = isOSIApproved;
        }

        public LicenseData(License lic) {
            this.id             = lic.id.toString();
            this.fullname       = lic.fullname;
            this.nickname       = lic.nickname;
            this.url            = lic.url;
            this.overview       = lic.overview;
            this.fulltext       = lic.fulltext;
            this.isOSIApproved  = lic.isOSIApproved.toString();
        }
    }

    public static class TagData {
        public String symbol;
        public String explanatoryName;
        public String isPrimary;
    
        public TagData(String symbol, String explanatoryName, String isPrimary) {
            this.symbol          = symbol;
            this.explanatoryName = explanatoryName;
            this.isPrimary       = isPrimary;
        }

        public TagData(Tag tag) {
            this.symbol          = tag.symbol;
            this.explanatoryName = tag.explanatoryName;
            this.isPrimary       = tag.isPrimary.toString();
        }
    }

    public static class ReleaseData {
        public String seq;
        public String version;
        public String description;
        public String productId;
        public String releasedDate;
        public String isStable;
        public String isActive;
        public String isUptodate;
    
        public ReleaseData(String seq
                          ,String version
                          ,String description
                          ,String productId
                          ,String releasedDate
                          ,String isStable
                          ,String isActive
                          ,String isUptodate) {
            this.seq          = seq;
            this.version      = version;
            this.description  = description;
            this.productId    = productId;
            this.releasedDate = releasedDate;
            this.isStable    = isStable;
            this.isActive    = isActive;
            this.isUptodate  = isUptodate;

        }

        public ReleaseData(Release release) {
            this.seq          = release.seq.toString();
            this.version      = release.version;
            this.description  = release.description;
            this.productId    = release.product.id.toString();
            this.releasedDate = new SimpleDateFormat("yyyy-MM-dd").format(release.releasedDate);
            this.isStable    = release.isStable.toString();
            this.isActive    = release.isActive.toString();
            this.isUptodate  = release.isUptodate.toString();

        }
    }

    public static class MediumData {
        public String seq;
        public String packageType;
        public String url;
        public String platform;
        public String checksum;
        public String releaseId;
    
        public MediumData(String seq
                         ,String packageType
                         ,String url
                         ,String platform
                         ,String checksum
                         ,String releaseId) {
            this.seq         = seq;
            this.packageType = packageType;
            this.url         = url;
            this.platform    = platform;
            this.checksum    = checksum;
            this.releaseId   = releaseId;

        }

        public MediumData(Medium medium) {
            this.seq         = medium.seq.toString();
            this.packageType = medium.packageType;
            this.url         = medium.url;
            this.platform    = medium.platform;
            this.checksum    = medium.checksum.toString();
            this.releaseId   = medium.release.seq.toString();

        }
    }

    public static class CpeInfoData {
        public String id;
        public String productId;
        public String vender;
        public String product;
    
        public CpeInfoData(String id, String productId, String vender, String product) {
            this.id        = id;
            this.productId = productId;
            this.vender    = vender;
            this.product   = product;
        }

        public CpeInfoData(CpeInfo cpeinfo) {
            this.id        = cpeinfo.id.toString();
            this.productId = cpeinfo.productId.toString();
            this.vender    = cpeinfo.vender;
            this.product   = cpeinfo.product;
        }
    }

    public static List<OrganizationData> getOrganizationData() {

        List<OrganizationData> od = Organization.find
                                             .orderBy("fullname")
                                             .findList()
                                             .stream()
                                             .map(o -> new OrganizationData(o.id.toString(), o.fullname))
                                             .collect(Collectors.toList());
        return od;
    }
}
