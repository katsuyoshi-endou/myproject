package models;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.avaje.ebean.Model;

@Entity
public class CpeInfo extends Model {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cpe_info_id_seq")
	public Long id;
	public Long productId;
	public String vender;
	public String product;

	public static Finder<Long, CpeInfo> find = new Finder<Long, CpeInfo>(CpeInfo.class);

	public static List<CpeInfo> findAll() {
		return find.findList();
	}

	public static CpeInfo findId(Long id) {
		return find.byId(id);
	}

	public static List<CpeInfo> findByProductId(Long productId) {
		List<CpeInfo> result = find.where().eq("product_id", productId).findList();
		return result;
	}

	public static CpeInfo findUnique(Long productId, String vender, String product) {
		CpeInfo result = find.where().eq("product_id", productId).eq("vender", vender).eq("product", product).findUnique();
		return result;
	}

        public static void addCpeInfo(Long productId, String vender, String product) {
            CpeInfo cpeinfo = new CpeInfo();
            cpeinfo.productId = productId;
            cpeinfo.vender    = vender;
            cpeinfo.product   = product;
            cpeinfo.save();

        }

        public static void updateCpeInfo(Long id, Long productId, String vender, String product) {
            CpeInfo cpeinfo = CpeInfo.findId(id);
            cpeinfo.productId = productId;
            cpeinfo.vender    = vender;
            cpeinfo.product   = product;
            cpeinfo.update();

        }

        public static void deleteCpeInfo(Long id) {
            CpeInfo cpeinfo = CpeInfo.findId(id);
            cpeinfo.delete();
        }

        public static void deleteCpeInfo(Long productId, String vender, String product) {
            CpeInfo cpeinfo = CpeInfo.findUnique(productId, vender, product);
            cpeinfo.delete();
        }

}
