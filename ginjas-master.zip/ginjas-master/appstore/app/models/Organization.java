package models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import play.libs.F;
import play.libs.Scala;

/**
 * Development Organization of Open Source Software Products
 */

@Entity
public class Organization extends AbstractOrganization {
	/**
	 * @Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
	 *
	 * 本来は上記のように指定して、AbstractOrganizationの定義をOraganizationに持たせて、
	 * AbstractOrganizationクラスを使わず、ServicesProviderはOrganizationを継承すべきだが、
	 * Ebeanの制限でTABLE_SINGLEしかサポートしていないために、やむなく現状の継承関係にしてある。
	 *
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "organization_seq")
	public Long id;

	public static Finder<Long, Organization> find = new Finder<Long, Organization>(Organization.class);

	public static Organization findById(Long id) {
		return find.byId(id);
	}
        
        public static void addOrganization(String fullname, String url, OrganizationType orgType) {
            Organization org = new Organization();
            org.fullname = fullname;
            org.url      = url;
            org.orgType  = orgType;
            org.save();

        }

        public static void updateOrganization(Long id, String fullname, String url, OrganizationType orgType) {
            Organization org = Organization.findById(id);
            org.fullname = fullname;
            org.url      = url;
            org.orgType  = orgType;
            org.update();

        }
         
        public static void deleteOrganization(Long id) {
            Organization org = Organization.findById(id);
            org.delete();
        }

        public static void deleteOrganizationWithProductDevByCol(Long id) {
            List<Product> assoProds = Product.findProductsWithOrganization(id);
            assoProds.forEach(p -> {
                p.developedBy = Organization.findById(new Long(-1)); // 不明
                p.update();
            });

            Organization org = Organization.findById(id);
            org.delete();
        }

        /**
         * 組織IDと組織名のシーケンス出力 (@helper.selectのオプション用)
         */
	public static scala.collection.Seq<scala.Tuple2<String, String>> options() {
                List<scala.Tuple2<String, String>> options = new ArrayList<>();
                for (Organization o : Organization.find.orderBy("fullname").findList()) {
                        options.add(Scala.Tuple(o.id.toString(), o.fullname));
                }
		return Scala.toSeq(options);
	}
}
