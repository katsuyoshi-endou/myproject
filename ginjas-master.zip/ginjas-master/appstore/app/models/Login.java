package models;

import java.security.NoSuchAlgorithmException;

import play.data.validation.Constraints;
import com.avaje.ebean.Model;

public class Login {
	@Constraints.Required
	private String username;
	@Constraints.Required
	private String password;

	public String getUsername() {
		return this.username;
	}

	public String getPassword() {
		return this.password;
	}

	public String validate() throws NoSuchAlgorithmException {
		if (authenticate(username, password) == null) {
			return "Invalid credential";
		}
		return null;
	}

	public static User authenticate(String username, String password) throws NoSuchAlgorithmException {
		Model.Finder<Long, User> find = new Model.Finder<Long, User>(User.class);
		String hashedPassword = "";
		if (password != null) {
			hashedPassword = sha512(password);
		}
		return find.where().eq("username", username).eq("password", hashedPassword).findUnique();
	}

	public static String sha512(String msg) throws NoSuchAlgorithmException {
		/**
		 * StringBuilder sb = new StringBuilder(); java.security.MessageDigest
		 * md = java.security.MessageDigest.getInstance("SHA-512");
		 * md.update(msg.getBytes()); byte[] mb = md.digest(); for (byte b : mb)
		 * { String hex = String.format("%02x", b); sb.append(hex); } return
		 * sb.toString();
		 */
		return msg;
	}
}
