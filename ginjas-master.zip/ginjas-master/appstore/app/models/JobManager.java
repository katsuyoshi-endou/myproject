package models;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Model;
import com.avaje.ebean.SqlQuery;
import com.avaje.ebean.SqlRow;

@Entity
public class JobManager extends Model {
	public enum ExecType {
		VULS_REPOT_MAIL("脆弱性情報通知メール"), DOWNLOAD_REPORT_MAIL("ダウンロード状況通知メール");
		private String name;

		ExecType(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}
	}

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "job_manager_seq")
	public Long id;
	public ExecType execType;
	public Date execDate;
	public String execParam1;
	public String execParam2;
	public String execParam3;
    public Long userId;

	public Long id1;
	public Long id2;
	public String strValue1;
	public String strValue2;
	public String remarks;

	public static Finder<Long, JobManager> find = new Finder<Long, JobManager>(JobManager.class);

	/**
	 * ジョブの実行ログを保存する
	 */
	public static void saveExecuteLog(ExecType type, String param, Long uid) {
		JobManager log = new JobManager();
		log.execType = type;
		log.execDate = new Date();
		log.execParam1 = param;
		log.userId = uid;

		log.save();
	}

	/**
	 * 脆弱性情報メールを通知する対象のユーザーを取得する <br>
	 * 　OSSを利用している（use_productに存在、かつそのOSSを利用中）ユーザーから基準日（実行日）のバッチが実行されていないユーザを取得する
	 *
	 * @param date 基準日（実行日）
	 * @return
	 */
	public static List<SqlRow> getVulsReportTarget(String date) {
		StringBuilder sb = new StringBuilder();

		sb.append("select distinct(user_id) from user_product where ended_on is null ");
		sb.append("except ");
		sb.append("select user_id from job_manager where exec_type = :type and exec_param1 = :date ");

		String sql = sb.toString();

		SqlQuery query = Ebean.createSqlQuery(sql);
		query.setParameter("type", ExecType.VULS_REPOT_MAIL);
		query.setParameter("summarydate", date);

		return query.findList();
	}

	/**
	 *
	 * @param summaryDate
	 * @return
	 */
	public static List<SqlRow> getDownloadReportTarget(String summaryDate) {
		StringBuilder sb = new StringBuilder();

		sb.append("select distinct(user_id) from project_manager ");
		sb.append("except ");
		sb.append("select user_id from job_manager where exec_type = :type and exec_param1 = :summarydate ");

		String sql = sb.toString();

		SqlQuery query = Ebean.createSqlQuery(sql);
		query.setParameter("type", ExecType.DOWNLOAD_REPORT_MAIL);
		query.setParameter("summarydate", summaryDate);

		return query.findList();
	}
}
