package models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.avaje.ebean.Model;

@Entity
public class LicenseTerm extends Model {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "license_term_seq")
	public Long id;
	@ManyToOne
	@JoinColumn(name = "license_id")
	public License license;
	public String category;
	public String summary;
	public String annotation;

	public static Finder<Long, LicenseTerm> find = new Finder<Long, LicenseTerm>(LicenseTerm.class);

}
