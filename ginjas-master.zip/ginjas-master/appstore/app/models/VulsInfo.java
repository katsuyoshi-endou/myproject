package models;

import java.util.List;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.SqlQuery;
import com.avaje.ebean.SqlRow;

import play.Logger;

/**
 * 脆弱性情報関連のテーブルにアクセスするためのクラス<br/>
 * 脆弱性情報関連のテーブルにひもづくモデルクラスではありません（脆弱性情報取得のためのメソッドをまとめたクラスです）
 *
 * @author scsk-endo
 *
 */
public class VulsInfo {
	/**
	 * 自身がダウンロードしたOSSに関する脆弱性情報を取得する
	 */
	public static final String USER_DOWNLOAD_OSS = "1";

	/**
	 * 自身が参加するプロジェクトでダウンロードされたOSSに関する脆弱性情報を取得する
	 */
	public static final String JOIN_PROJECT_OSS = "2";

	/**
	 * ユーザーが参加しているプロジェクトで利用されているOSS製品の脆弱性情報を取得する。<br/>
	 * 第９引数の状態により、取得する範囲が異なる。<br/>
	 * 　"1":ユーザーがダウンロードしたOSS製品に関する脆弱性情報を対象<br/>
	 * 　"2":ユーザーが参加するプロジェクにおいてダウンロードされたOSS製品に関する脆弱性情報を対象<br/>
	 * 　　　　（自分がダウンロードしていなくても同じプロジェクトに参加しているほかのユーザーがダウンロードした製品を含む）
	 *
	 * @param userid ユーザーID
	 * @param score スコア
	 * @param productid OSS製品ID
	 * @param version バージョン
	 * @param cveid CVE-ID
	 * @param pubStartDate 公開日（開始）
	 * @param pubEndDate 公開日（終了）
	 * @param projectid プロジェクトID
	 * @param option 取得対象（上記参照）
	 * @return
	 */
	public static List<SqlRow> getVulsListByUser(Long userid, Double score, Long productid, String version, String cveid, String pubStartDate, String pubEndDate, Long projectid, String option) {
		StringBuilder sb = new StringBuilder();

		sb.append("select ");
		sb.append("  cve_detail_id, ");
		sb.append("   cve_id, ");
		sb.append("   project_id, ");
		sb.append("   product_id, ");
		sb.append("   product_name, ");
		sb.append("   product_version, ");
		sb.append("   project_name, ");
		sb.append("   dept_name, ");
		sb.append("   vuls_title, ");
		sb.append("   score, ");
		sb.append("   case ");
		sb.append("     when score >= 9.0 then '緊急' ");
		sb.append("     when score >= 7.0 and score <= 8.9 then '重要' ");
		sb.append("     when score >= 4.0 and score <= 6.9 then '警告' ");
		sb.append("     when score >= 0.1 and score <= 3.9 then '注意' ");
		sb.append("     when score = 0.0 then 'なし' ");
		sb.append("     else '' ");
		sb.append("   end as score_name, ");
		sb.append("   published_date, ");
		sb.append("   last_modified_date ");
		sb.append(" from ");
		sb.append(" ( ");
		sb.append("   select ");
		sb.append("     cve_details.id as cve_detail_id, ");
		sb.append("     cve_details.cve_id as cve_id, ");
		sb.append("     a.project_id as project_id, ");
		sb.append("     a.product_id as product_id, ");
		sb.append("     a.product_name as product_name, ");
		sb.append("     a.product_version as product_version, ");
		sb.append("     a.project_name as project_name, ");
		sb.append("     a.dept_name as dept_name, ");
		sb.append("     jvns.title as vuls_title, ");
		sb.append("     COALESCE(jvns.score, nvds.score) as score, ");
		sb.append("     to_char(jvns.published_date, 'yyyy-mm-dd') as published_date, ");
		sb.append("     to_char(jvns.last_modified_date, 'yyyy-mm-dd') as last_modified_date ");
		sb.append("   from ");
		sb.append("     vuls.cve_details ");
		sb.append("       left join vuls.jvns on jvns.cve_detail_id = cve_details.id ");
		sb.append("       left join vuls.nvds on cve_details.id = nvds.id, ");
		sb.append("     ( ");
		if(USER_DOWNLOAD_OSS.equals(option)) {
			sb.append("       select  vuls.cve_details_id, ");
			sb.append("               up.project_id as project_id, ");
			sb.append("               prj.nick_name as project_name, ");
			sb.append("               p.id as product_id, ");
			sb.append("               p.name as product_name, ");
			sb.append("               r.version as product_version, ");
			sb.append("               d.full_name as dept_name, ");
			sb.append("               r.seq as rel_seq ");
			sb.append("       from user_product as up ");
			sb.append("         left join product as p on p.id = up.product_id ");
			sb.append("           left join project as prj on prj.id = up.project_id ");
			sb.append("         left join dept as d on d.id = prj.dept_id ");
			sb.append("         left join release as r on r.seq = up.release_seq, ");
			sb.append("         vulnerability as vuls ");
			sb.append("       where up.user_id = :userid ");
			sb.append("       and up.ended_on is null ");
			sb.append("       and r.seq = vuls.release_id ");
			sb.append("       and vuls.release_id = r.seq ");
		} else {
			// 自分が参加するプロジェクトでダウロードされたすべての製品の脆弱性情報を表示する
			sb.append("       select ");
			sb.append("         vulnerability.cve_details_id, ");
			sb.append("         base_info.project_id, ");
			sb.append("         base_info.product_id, ");
			sb.append("         base_info.release_seq, ");
			sb.append("         project_info.nick_name as project_name, ");
			sb.append("         project_info.full_name as dept_name, ");
			sb.append("         product.name as product_name, ");
			sb.append("         release.version as product_version ");
			sb.append("       from ");
			sb.append("       ( ");
			sb.append("         select ");
			sb.append("           user_product.project_id, ");
			sb.append("           user_product.product_id, ");
			sb.append("           user_product.release_seq ");
			sb.append("         from user_product ");
			sb.append("         where project_id in ");
			sb.append("         ( ");
			sb.append("           select project_id from project_user where user_id = :userid ");
			sb.append("           union ");
			sb.append("           select project_id from project_manager where user_id = :userid ");
			sb.append("         ) ");
			sb.append("         and user_product.ended_on is null ");
			sb.append("         group by user_product.project_id, user_product.product_id, user_product.release_seq ");
			sb.append("       ) as base_info ");
			sb.append("         left join ");
			sb.append("           ( ");
			sb.append("             select project.id, project.nick_name, dept.full_name from project left join dept on project.dept_id = dept.id ");
			sb.append("           ) as project_info on base_info.project_id = project_info.id ");
			sb.append("         left join product on base_info.product_id = product.id ");
			sb.append("         left join release on base_info.release_seq = release.seq, ");
			sb.append("       vulnerability ");
			sb.append("       where base_info.release_seq = vulnerability.release_id ");


//			sb.append("       select  vuls.cve_details_id, ");
//			sb.append("               up.project_id as project_id, ");
//			sb.append("               max(prj.nick_name) as project_name, ");
//			sb.append("               p.id as product_id, ");
//			sb.append("               p.name as product_name, ");
//			sb.append("               r.version as product_version, ");
//			sb.append("               max(d.full_name) as dept_name ");
//			sb.append("       from  project_user as pu, ");
//			sb.append("             user_product as up ");
//			sb.append("               left join release as r on up.release_seq = r.seq ");
//			sb.append("               left join project as prj on up.project_id = prj.id ");
//			sb.append("               left join product as p on up.product_id = p.id, ");
//			sb.append("             dept as d, ");
//			sb.append("             vulnerability as vuls ");
//			sb.append("       where pu.user_id = :userid ");
//			sb.append("       and up.project_id = pu.project_id ");
//			sb.append("       and prj.dept_id = d.id ");
//			sb.append("       and r.seq = vuls.release_id ");
//			sb.append("       and up.ended_on is null ");
//			sb.append("       group by vuls.cve_details_id, up.project_id, p.id, r.version ");
		}
		sb.append("     ) as a ");
		sb.append("   where cve_details.id = a.cve_details_id ");
		sb.append(" ) as zz ");
		sb.append(" where 1=1 ");

		try {
			// 引数の値を条件に追加する
			if(score != null) {
				sb.append(" and score >= :score ");
			}

			if(productid != null) {
				sb.append(" and product_id = :productid ");
			}

			if(!"".equals(version)) {
				sb.append(" and product_version = :version ");
			}

			if(!"".equals(cveid)) {
				cveid = cveid.replaceAll("[_%\\[#]", "#$0");
				sb.append(" and cve_id like :cveid escape '#' ");
			}

			if(!"".equals(pubStartDate) || pubStartDate.length() != 0) {
				sb.append(" and (published_date >= to_char(to_date(:pubStartDate, 'yyyy-mm-dd'), 'yyyy-mm-dd') and published_date <= to_char(to_date(:pubEndDate, 'yyyy-mm-dd'), 'yyyy-mm-dd')) ");
			}

			if(projectid != null) {
				sb.append(" and project_id = :projectid ");
			}

//			sb.append(" order by score desc, product_name ");
			sb.append(" order by score desc, product_name asc, product_version, published_date desc, cve_id asc ");

			String sql = sb.toString();

			SqlQuery query = Ebean.createSqlQuery(sql);
			query.setParameter("userid", userid);
			query.setParameter("score", score);
			query.setParameter("productid", productid);
			query.setParameter("version", version);
			query.setParameter("cveid", "%" + cveid + "%");
			query.setParameter("pubStartDate", pubStartDate);
			query.setParameter("pubEndDate", pubEndDate);
			query.setParameter("projectid", projectid);

			List<SqlRow> result = query.findList();
			return result;
		} catch(Exception e) {
			Logger.info(e.getMessage());
			return null;
		}
	}

	/**
	 * 指定されたOSS製品の脆弱性情報を取得する<br/>
	 * ただし、本システムで利用されていないバージョンの脆弱性情報は対象外
	 *
	 * @param productId OSS製品ID
	 * @return
	 */
	public static List<SqlRow> getVulsListPerProduct(Long productId) {
		StringBuilder sb = new StringBuilder();

		sb.append("select ");
		sb.append("    cve_details.id, ");
		sb.append("    cve_details.cve_id, ");
		sb.append("    a.product_id, ");
		sb.append("    a.product_name, ");
		sb.append("    a.product_version, ");
		sb.append("    jvns.title, ");
		sb.append("    COALESCE(jvns.score, nvds.score) as score, ");
		sb.append("    case ");
		sb.append("      when COALESCE(jvns.score, nvds.score) >= 9.0 then '緊急' ");
		sb.append("      when COALESCE(jvns.score, nvds.score) >= 7.0 and COALESCE(jvns.score, nvds.score) <= 8.9 then '重要' ");
		sb.append("      when COALESCE(jvns.score, nvds.score) >= 4.0 and COALESCE(jvns.score, nvds.score) <= 6.9 then '警告' ");
		sb.append("      when COALESCE(jvns.score, nvds.score) >= 0.1 and COALESCE(jvns.score, nvds.score) <= 3.9 then '注意' ");
		sb.append("      when COALESCE(jvns.score, nvds.score) = 0.0 then 'なし' ");
		sb.append("      else '' ");
		sb.append("    end as score_name, ");
		sb.append("    to_char(jvns.published_date, 'yyyy-mm-dd') as published_date, ");
		sb.append("    to_char(jvns.last_modified_date, 'yyyy-mm-dd') as last_modified_date ");
		sb.append(" from ");
		sb.append("    vuls.cve_details ");
		sb.append("      left join vuls.jvns on jvns.cve_detail_id = cve_details.id ");
		sb.append("      left join vuls.nvds on cve_details.id = nvds.id, ");
		sb.append("   ( ");
		sb.append("     select vuls.cve_details_id as cve_detail_id, p.name as product_name, r.version as product_version, p.id as product_id ");
		sb.append("     from  vulnerability as vuls, ");
		sb.append("           release as r ");
		sb.append("           left join product as p on p.id = r.product_id ");
		sb.append("     where vuls.release_id = r.seq ");
		sb.append("     and r.product_id = :productid ");
		sb.append("   ) as a ");
		sb.append(" where cve_details.id = a.cve_detail_id ");
		sb.append(" order by last_modified_date desc, product_name asc, product_version asc, score desc, cve_id asc");

		try {
			String sql = sb.toString();

			List<SqlRow> result = Ebean.createSqlQuery(sql).setParameter("productid", productId).findList();

			return result;
		} catch(Exception e) {
			Logger.info(e.getMessage());
			return null;
		}
	}

	/**
	 * 脆弱性情報の詳細を取得する（脆弱性情報一覧照会の「詳細」リンク押下）
	 *
	 * @param productName OSS製品名
	 * @param productVer OSS製品バージョン
	 * @param id データ取得時に先頭に持ってくるID
	 * @return
	 */
	public static List<SqlRow> getVulsDetail(String productName, String productVer, Long id) {
		StringBuilder sb = new StringBuilder();

		sb.append("select ");
		sb.append("  cve_details.id, ");
		sb.append("  cve_details.cve_id, ");
		sb.append("  jvns.jvn_id, ");
		sb.append("  jvns.title, ");
		sb.append("  COALESCE(jvns.score, nvds.score) as score, ");
		sb.append("  case ");
		sb.append("    when COALESCE(jvns.score, nvds.score) >= 9.0 then '緊急' ");
		sb.append("    when COALESCE(jvns.score, nvds.score) >= 7.0 and COALESCE(jvns.score, nvds.score) <= 8.9 then '重要' ");
		sb.append("    when COALESCE(jvns.score, nvds.score) >= 4.0 and COALESCE(jvns.score, nvds.score) <= 6.9 then '警告' ");
		sb.append("    when COALESCE(jvns.score, nvds.score) >= 0.1 and COALESCE(jvns.score, nvds.score) <= 3.9 then '注意' ");
		sb.append("    when COALESCE(jvns.score, nvds.score) = 0.0 then 'なし' ");
		sb.append("    else '' ");
		sb.append("  end as score_name, ");
		sb.append("  jvns.severity, ");
		sb.append("  refs.source, ");
		sb.append("  refs.link, ");
		sb.append("  jvns.jvn_link ");
		sb.append("from ");
		sb.append("  vuls.cve_details ");
		sb.append("  left join vuls.jvns on jvns.cve_detail_id = cve_details.id ");
		sb.append("  left join vuls.nvds on cve_details.id = nvds.id ");
		sb.append("  left join vuls.references as refs on jvns.id = refs.jvn_id or nvds.id = refs.nvd_id ");
		sb.append("where cve_details.id in ");
		sb.append("( ");
		sb.append("  select vuls.cve_details_id ");
		sb.append("  from vulnerability as vuls, release as r, product as p ");
		sb.append("  where p.name = :product_name ");
		sb.append("  and r.version = :product_ver ");
		sb.append("  and vuls.release_id = r.seq ");
		sb.append("  and r.product_id = p.id ");
		sb.append(") ");
		sb.append("order by cve_details.id = :id desc, score desc, cve_id ");

		try {
			String sql = sb.toString();

			SqlQuery query = Ebean.createSqlQuery(sql);
			query.setParameter("product_name", productName);
			query.setParameter("product_ver", productVer);
			query.setParameter("id", id);

			return query.findList();
		} catch(Exception e) {
			Logger.info(e.getMessage());
			return null;
		}
	}

	/**
	 * 本システムで利用されているOSS製品（バージョン）の脆弱性情報を取得する。
	 *
	 * @param productid OSS製品ID
	 * @param version バージョン
	 * @param score スコア
	 * @param cveid CVE-ID
	 * @param pubStartDate 公開日（開始）
	 * @param pubEndDate 公開日（終了）
	 * @return
	 */
	public static List<SqlRow> getVulsListByAdmin(Long productId, String version, Double score, String cveId, String pubStartDate, String pubEndDate) {
		StringBuilder sb = new StringBuilder();

		sb.append("select ");
		sb.append("  id, ");
		sb.append("  cve_id, ");
		sb.append("  product_id, ");
		sb.append("  product_name, ");
		sb.append("  product_version, ");
		sb.append("  vuls_title, ");
		sb.append("  score, ");
		sb.append("  case ");
		sb.append("    when score >= 9.0 then '緊急' ");
		sb.append("    when score >= 7.0 and score <= 8.9 then '重要' ");
		sb.append("    when score >= 4.0 and score <= 6.9 then '警告' ");
		sb.append("    when score >= 0.1 and score <= 3.9 then '注意' ");
		sb.append("    when score = 0.0 then 'なし' ");
		sb.append("  end as score_name, ");
		sb.append("  published_date, ");
		sb.append("  last_modified_date ");
		sb.append("from ");
		sb.append("( ");
		sb.append("  select ");
		sb.append("    cve_details.id as id, ");
		sb.append("    cve_details.cve_id as cve_id, ");
		sb.append("    b.product_id as product_id, ");
		sb.append("    b.product_name as product_name, ");
		sb.append("    b.product_version as product_version, ");
		sb.append("    jvns.title as vuls_title, ");
		sb.append("    COALESCE(jvns.score, nvds.score) as score, ");
		sb.append("    to_char(jvns.published_date, 'yyyy-mm-dd') as published_date, ");
		sb.append("    to_char(jvns.last_modified_date, 'yyyy-mm-dd') as last_modified_date ");
		sb.append("  from ");
		sb.append("    vuls.cve_details ");
		sb.append("      left join vuls.jvns on jvns.cve_detail_id = cve_details.id ");
		sb.append("      left join vuls.nvds on cve_details.id = nvds.id, ");
		sb.append("    ( ");
		sb.append("      select  v.cve_details_id as cve_details_id, ");
		sb.append("              a.id as product_id, ");
		sb.append("              a.name as product_name, ");
		sb.append("              a.version as product_version ");
		sb.append("      from vulnerability as v, ");
		sb.append("		      ( ");
		sb.append("        select p.id, p.name, r.version, max(r.seq) as rel_seq ");
		sb.append("        from  release as r, ");
		sb.append("              user_product as up, ");
		sb.append("              product as p ");
		sb.append("        where up.release_seq = r.seq ");
		sb.append("        and r.product_id = p.id ");
		sb.append("        and up.ended_on is null ");
		sb.append("        group by p.id, p.name, r.version ");
		sb.append("      ) as a ");
		sb.append("      where v.release_id = a.rel_seq ");
		sb.append("  ) as b ");
		sb.append("  where cve_details.id = b.cve_details_id ");
		sb.append(") as zz ");
		sb.append("where 1=1 ");

		try {
			// 引数の値を条件に追加する
			if(score != null) {
				sb.append(" and score >= :score ");
			}

			if(productId != null) {
				sb.append(" and product_id = :productid ");
			}

			if(!"".equals(version)) {
				sb.append(" and product_version = :version ");
			}

			if(!"".equals(cveId)) {
				cveId = cveId.replaceAll("[_%\\[#]", "#$0");
				sb.append(" and cve_id like :cveid escape '#' ");
			}

			if(!"".equals(pubStartDate) || pubStartDate.length() != 0) {
				sb.append(" and (published_date >= to_char(to_date(:pubStartDate, 'yyyy-mm-dd'), 'yyyy-mm-dd') and published_date <= to_char(to_date(:pubEndDate, 'yyyy-mm-dd'), 'yyyy-mm-dd')) ");
			}

//			sb.append("order by score desc, product_name ");
			sb.append("order by score desc, product_name asc, product_version, last_modified_date desc, cve_id asc ");

			String sql = sb.toString();

			SqlQuery query = Ebean.createSqlQuery(sql);
			query.setParameter("score", score);
			query.setParameter("productid", productId);
			query.setParameter("version", version);
			query.setParameter("cveid", "%" + cveId + "%");
			query.setParameter("pubStartDate", pubStartDate);
			query.setParameter("pubEndDate", pubEndDate);

			return query.findList();
		} catch(Exception e) {
			Logger.info(e.getMessage());
			return null;
		}
	}
}
