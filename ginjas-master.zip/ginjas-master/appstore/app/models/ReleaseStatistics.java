package models;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.SqlQuery;
import com.avaje.ebean.SqlRow;

/**
 * OSS(バージョン込み)についての統計情報のjsonを作成するためのクラス
 */
public class ReleaseStatistics {

    public String productId;
    public String ossname;
    public String version;
    public String genre;
    public String project;
    public String download;

    public ReleaseStatistics() {
        this.productId = "";
        this.ossname   = "";
        this.version   = "";
        this.genre     = "";
        this.project   = "";
        this.download  = "";
    }

    public ReleaseStatistics(Long release_seq, String genre, Long project_count, Long download_count) {
        this.productId = Release.findById(release_seq).product.id.toString();
        this.ossname   = Release.findById(release_seq).product.name;
        this.version   = Release.findById(release_seq).version;
        this.genre     = genre;
        this.project   = project_count.toString();
        this.download  = download_count.toString();
    }

    public ReleaseStatistics(String productId, String ossname, String genre, String version, String project, String download) {
        this.productId = productId;
        this.ossname   = ossname;
        this.version   = version;
        this.genre     = genre;
        this.project   = project;
        this.download  = download;
    }

    public static class ProductData implements Comparable{
        public String  id;
        public String  name;
    
        public ProductData(String id, String name) {
            this.id   = id;
            this.name = name;
        }

        public int compareTo(Object other) {
            ProductData o = (ProductData) other;
            return this.name.compareToIgnoreCase(o.name);
        }
    }

    public static List<ReleaseStatistics> getReleasesStats(List<Product> products) {
        String sql = " select                                                            "
                   + "     release.product_id          as product_id                     "
                   + "   , release.seq                 as release_seq                    "
                   + "   , array_to_string(array(                                        "
                   + "         select                                                    "
                   + "             tag.explanatory_name                                  "
                   + "         from                                                      "
                   + "             product_tag                                           "
                   + "             inner join tag on product_tag.tag_symbol = tag.symbol "
                   + "         where                                                     "
                   + "             product_tag.product_id = release.product_id           "
                   + "     ), ', ')                    as product_genre                  "
                   + "   , coalesce(project.count, 0)  as project_count                  "
                   + "   , coalesce(download.count, 0) as download_count                 "
                   + " from release                                                      "
                   + "     left outer join (                                             "
                   + "         select                                                    "
                   + "             release_seq                                           "
                   + "           , count(distinct project_id)                            "
                   + "         from user_product                                         "
                   + "         where ended_on is null                                    "
                   + "         group by release_seq                                      "
                   + "     ) project on release.seq = project.release_seq                "
                   + "     left outer join (                                             "
                   + "         select                                                    "
                   + "             release_seq                                           "
                   + "           , count(*)                                              "
                   + "         from download_history                                     "
                   + "         group by release_seq                                      "
                   + "     ) download on release.seq = download.release_seq              "
                   + " where release.product_id in (:pids)                               "
                   + " ;                                                                 "
        ;

        List<Long> pids = new ArrayList<Long>();
        for (Product p : products) {
            pids.add(p.id);
        }

        SqlQuery query = Ebean.createSqlQuery(sql);

        query.setParameter("pids", pids);
        List<SqlRow> result = query.findList();

        List<ReleaseStatistics> releaseUse = new ArrayList<ReleaseStatistics>();
        for (SqlRow r : result) {
            ReleaseStatistics stats = new ReleaseStatistics(
                                          r.getLong("release_seq")
                                         ,r.getString("product_genre")
                                         ,r.getLong("project_count")
                                         ,r.getLong("download_count")
                                      );
            releaseUse.add(stats);
        }
        return  releaseUse;
    }

    public static List<ReleaseStatistics> getReleasesStats(Product product) {
        String sql = " select                                                            "
                   + "     release.product_id          as product_id                     "
                   + "   , release.seq                 as release_seq                    "
                   + "   , array_to_string(array(                                        "
                   + "         select                                                    "
                   + "             tag.explanatory_name                                  "
                   + "         from                                                      "
                   + "             product_tag                                           "
                   + "             inner join tag on product_tag.tag_symbol = tag.symbol "
                   + "         where                                                     "
                   + "             product_tag.product_id = release.product_id           "
                   + "     ), ', ')                    as product_genre                  "
                   + "   , coalesce(project.count, 0)  as project_count                  "
                   + "   , coalesce(download.count, 0) as download_count                 "
                   + " from release                                                      "
                   + "     left outer join (                                             "
                   + "         select                                                    "
                   + "             release_seq                                           "
                   + "           , count(distinct project_id)                            "
                   + "         from user_product                                         "
                   + "         where ended_on is null                                    "
                   + "         group by release_seq                                      "
                   + "     ) project on release.seq = project.release_seq                "
                   + "     left outer join (                                             "
                   + "         select                                                    "
                   + "             release_seq                                           "
                   + "           , count(*)                                              "
                   + "         from download_history                                     "
                   + "         group by release_seq                                      "
                   + "     ) download on release.seq = download.release_seq              "
                   + " where release.product_id = (:pid)                                 "
                   + " ;                                                                 "
        ;

        SqlQuery query = Ebean.createSqlQuery(sql);
        query.setParameter("pid", product.id);
        List<SqlRow> result = query.findList();

        List<ReleaseStatistics> releaseUse = new ArrayList<ReleaseStatistics>();
        for (SqlRow r : result) {
            ReleaseStatistics stats = new ReleaseStatistics(
                                          r.getLong("release_seq")
                                         ,r.getString("product_genre")
                                         ,r.getLong("project_count")
                                         ,r.getLong("download_count")
                                      );
            releaseUse.add(stats);
        }
        return  releaseUse;
    }

    public static List<ReleaseStatistics> getReleasesStats(Release release) {
        String sql = " select                                                            "
                   + "     release.product_id          as product_id                     "
                   + "   , release.seq                 as release_seq                    "
                   + "   , array_to_string(array(                                        "
                   + "         select                                                    "
                   + "             tag.explanatory_name                                  "
                   + "         from                                                      "
                   + "             product_tag                                           "
                   + "             inner join tag on product_tag.tag_symbol = tag.symbol "
                   + "         where                                                     "
                   + "             product_tag.product_id = release.product_id           "
                   + "     ), ', ')                    as product_genre                  "
                   + "   , coalesce(project.count, 0)  as project_count                  "
                   + "   , coalesce(download.count, 0) as download_count                 "
                   + " from release                                                      "
                   + "     left outer join (                                             "
                   + "         select                                                    "
                   + "             release_seq                                           "
                   + "           , count(distinct project_id)                            "
                   + "         from user_product                                         "
                   + "         where ended_on is null                                    "
                   + "         group by release_seq                                      "
                   + "     ) project on release.seq = project.release_seq                "
                   + "     left outer join (                                             "
                   + "         select                                                    "
                   + "             release_seq                                           "
                   + "           , count(*)                                              "
                   + "         from download_history                                     "
                   + "         group by release_seq                                      "
                   + "     ) download on release.seq = download.release_seq              "
                   + " where release.seq = (:rseq)                                       "
                   + " ;                                                                 "
        ;

        SqlQuery query = Ebean.createSqlQuery(sql);
        query.setParameter("rseq", release.seq);
        List<SqlRow> result = query.findList();

        List<ReleaseStatistics> releaseUse = new ArrayList<ReleaseStatistics>();
        for (SqlRow r : result) {
            ReleaseStatistics stats = new ReleaseStatistics(
                                          r.getLong("release_seq")
                                         ,r.getString("product_genre")
                                         ,r.getLong("project_count")
                                         ,r.getLong("download_count")
                                      );
            releaseUse.add(stats);
        }
        return  releaseUse;
    }
}
