package models;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.avaje.ebean.Model;

/**
 * Productに関するトピックス。次の情報が記録されるべきである：
 * ①バージョンアップ／パッチリリースの情報、②脆弱性情報、③コミュニティサポートの終了等に関する情報
 */
@Entity
public class ProductTopic extends Model {
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "product_topic_seq")
	@Id
	public Long id;
	@ManyToOne
	@JoinColumn(name = "product_id")
	public Product product;
	public Long releaseId; /*
							 * this could be null for entries common among
							 * releases....
							 */
	public Date postDate;
	public Integer topicType; /*
								 * 0: release information, 1: vulnerability alert,
								 * 2: support information, 3: other
								 * miscellaneous topic
								 */
	public String title;
	public String description;
	public String url;
	public Boolean isActive; /* could be used to exclude obsolete info ... */

	public static Finder<Long, ProductTopic> find = new Finder<Long, ProductTopic>(ProductTopic.class);

	public static List<ProductTopic> findTopicsFor(Long productId, Long releaseId) {
		List<ProductTopic> topics;
		if (releaseId < 0) {
			topics = find.where().eq("product_id", productId).orderBy("post_date desc").findList();
		} else {
			topics = find.where().eq("product_id", productId).eq("release_id", releaseId).orderBy("post_date desc")
					.findList();
		}
		return topics;
	}

	public static List<ProductTopic> findTopics(Product p) {
		return findTopicsFor(p.id, new Long((long) -1));
	}

	public static List<ProductTopic> findTopics(Product p, int n) {
		return find.where().eq("product_id", p.id).orderBy("post_date desc").findPagedList(n, 4).getList();
	}
}
