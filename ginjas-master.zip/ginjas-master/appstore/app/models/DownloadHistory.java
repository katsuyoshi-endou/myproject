package models;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Model;
import com.avaje.ebean.SqlQuery;
import com.avaje.ebean.SqlRow;

import play.Logger;

/**
 * DownloadHistory: ユーザーによるOSSのダウンロード情報が記録される
 */
@Entity
public class DownloadHistory extends Model {

	public enum PurposeType{
                OTHER("その他"),REDISTRIBUTE("顧客に提供する成果物の一部として使用"),PRIVATEUSE("開発ツールなど社内での個人的な使用"),EVALUATION("技術検証やOSS評価");

		private String name;

		PurposeType(String name) {
			this.name = name;
		}

		public String getName() {
			return this.name;
		}
	}

        @Id
        @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "download_history_seq")

        public Long seq;
	@ManyToOne
	@JoinColumn(name = "product_id")
        public Product product;
	@ManyToOne
	@JoinColumn(name = "release_seq")
        public Release release;
	@ManyToOne
	@JoinColumn(name = "medium_seq")
        public Medium  medium;
	@ManyToOne
	@JoinColumn(name = "user_id")
        public User    user;
	@ManyToOne
	@JoinColumn(name = "project_id")
        public Project project;
        public PurposeType purpose;
        public String text;
        public Date downloadDate;
        public Date lastUpdate;

        public static Finder<Long, DownloadHistory> find = new Finder<Long, DownloadHistory>(DownloadHistory.class);

        public static void addHistory(Medium medium, User user, Project project, PurposeType purpose, String text) {
                DownloadHistory dh = new DownloadHistory();

                dh.product      = medium.release.product;
                dh.release      = medium.release;
                dh.medium       = medium;
                dh.user         = user;
                dh.project      = project;
                dh.purpose      = purpose;
                dh.text         = text;
                dh.downloadDate = new Date();
                dh.lastUpdate   = new Date();
                dh.save();
	}

    /**
     * 指定されたユーザーが責任者となっているプロジェクトで指定期間内にダウンロードされたOSSの情報を取得する。
     *
     * @param uid ユーザーID
     * @param startDate 取得期間の開始
     * @param endDate 取得期間の終了
     * @return
     * @throws Exception
     */
	public static List<SqlRow> getDownloadReport(Long uid, String startDate, String endDate) throws Exception {
		StringBuilder sb = new StringBuilder();

		sb.append("select ");
		sb.append("  pm_info.user_id, ");
		sb.append("  pm_info.pm_name, ");
		sb.append("  project.id as project_id, ");
		sb.append("  project.nick_name, ");
		sb.append("  download_history.seq, ");
		sb.append("  trim(ginjasuser.family_name || ' '  || ginjasuser.first_name) as user_name, ");
		sb.append("  product.name, ");
		sb.append("  release.version, ");
		sb.append("  dept_info.full_name, ");
		sb.append("  license_info.licenses, ");
		sb.append("  to_char(download_history.download_date,'yyyy-mm-dd hh24:MI') as dl_date, ");
		sb.append("  case ");
		sb.append("    when upper(license_info.licenses) like '%AGPL%' then '1' ");
		sb.append("    when upper(license_info.licenses) like '%LGPL%' then '1' ");
		sb.append("    when upper(license_info.licenses) like '%GPL%' then '1' ");
		sb.append("    else '0' ");
		sb.append("  end as warn_flg ");
		sb.append("from download_history ");
		sb.append("  left join ginjasuser on download_history.user_id = ginjasuser.id ");
		sb.append("  left join product on download_history.product_id = product.id ");
		sb.append("  left join release on download_history.release_seq = release.seq ");
		sb.append("  left join ");
		sb.append("  ( ");
		sb.append("    select user_dept.user_id, dept.full_name from user_dept left join dept on user_dept.dept_id = dept.id ");
		sb.append("    where user_dept.is_primary_dept = true ");
		sb.append("  ) as dept_info on download_history.user_id = dept_info.user_id ");
		sb.append("  left join project on download_history.project_id = project.id ");
		sb.append("  left join ");
		sb.append("  ( ");
		sb.append("    select ");
		sb.append("      t2.product_id, ");
		sb.append("      array_to_string(array(select license.nickname from product_license t1, license where t1.license_id = license.id and t1.product_id = t2.product_id), ',') as licenses ");
		sb.append("    from product_license t2 ");
		sb.append("    group by t2.product_id ");
		sb.append("  ) as license_info on download_history.product_id = license_info.product_id, ");
		sb.append("  ( ");
		sb.append("    select ");
		sb.append("      project_manager.project_id, ");
		sb.append("      project_manager.user_id, ");
		sb.append("      trim(ginjasuser.family_name || ' ' || ginjasuser.first_name) as pm_name ");
		sb.append("    from project_manager left join ginjasuser on project_manager.user_id = ginjasuser.id ");
		sb.append("  ) as pm_info ");
		sb.append("where download_history.project_id = pm_info.project_id ");
		sb.append("and (download_history.download_date  >= to_date(:startdate, 'yyyy-mm-dd') and download_history.download_date <= to_date(:enddate, 'yyyy-mm-dd')) ");
		sb.append("and pm_info.user_id = :userid ");
		sb.append("order by project_id asc, warn_flg desc, download_date asc, name asc ");

		String sql = sb.toString();
		try {
			SqlQuery query = Ebean.createSqlQuery(sql);
			query.setParameter("userid", uid);
			query.setParameter("startdate", startDate);
			query.setParameter("enddate", endDate);

			return query.findList();
		} catch(Exception e) {
			Logger.info("Exception occurred in DownloadHistory.getDownloadReport() method.");
			Logger.info(e.getMessage());

			throw e;
		}
	}
}
