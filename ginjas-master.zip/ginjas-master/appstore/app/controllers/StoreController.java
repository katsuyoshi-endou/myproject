package controllers;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.inject.Inject;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.SqlRow;
import com.fasterxml.jackson.databind.JsonNode;
import models.ActivityRecord;
import models.CpeInfo;
import models.DataMaintenance;
import models.Dept;
import models.DownloadHistory;
import models.License;
import models.MaintenanceRequest;
import models.Medium;
import models.Organization;
import models.Product;
import models.ProductReview;
import models.Project;
import models.Release;
import models.ReleaseStatistics;
import models.Tag;
import models.User;
import models.UserProduct;
import models.VulsInfo;
import play.Configuration;
import play.data.DynamicForm;
import play.data.Form;
import play.data.FormFactory;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import play.mvc.Security;
import play.mvc.With;
import views.html.activities;
import views.html.adminactrecord;
import views.html.adminosslist;
import views.html.adminvulnlist;
import views.html.download;
import views.html.editmanager;
import views.html.editproject;
import views.html.item;
import views.html.logo;
import views.html.mailcontent;
import views.html.maintitem;
import views.html.maintlicense;
import views.html.maintorganization;
import views.html.mainttag;
import views.html.preference;
import views.html.project;
import views.html.request;
import views.html.requestapprove;
import views.html.requestlist;
import views.html.review;
import views.html.statistics;
import views.html.storefront;
import views.html.userosslist;
import views.html.uservulnlist;
import views.html.vulndetail;
public class StoreController extends Controller {
	@Inject
	private Configuration config;

	private final DynamicForm dForm;
        private final Form<Product> pForm;

        @Inject
        public StoreController(FormFactory formFactory) {
                this.dForm = formFactory.form();
                this.pForm = formFactory.form(Product.class);
        }


	private static DateTimeFormatter YYYY_MM_DD = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	@With(ActionReminder.class)
	public Result listProducts(int pageNumber, int itemsPerPage, String sortBy, String order) {
		ctx().session().put("category", "");

		int pubCount = Product.getSearchCount("", Application.isAdminUser());

		return ok(storefront.render(Product.page(pageNumber, itemsPerPage, "", ""), null, pageNumber,
				itemsPerPage, "", "", pubCount, pubCount, ""));
//		return ok(storefront.render(Product.page(pageNumber, itemsPerPage, sortBy, order), null, pageNumber,
//				itemsPerPage, sortBy, order));
	}

	@With(ActionReminder.class)
	public Result listProductsOf(String category, int pageNumber, int itemsPerPage) {
		String sortBy = "name", order = "asc";
		ctx().session().put("category", category);

		int pubCount = Product.getSearchCount("", Application.isAdminUser());
		int srchCount = Product.getCounWithCategoryName(category, Application.isAdminUser());

		return ok(storefront.render(Product.findWithCategoryName(category, pageNumber, itemsPerPage), null, pageNumber,
				itemsPerPage, sortBy, order, pubCount, srchCount, category.toUpperCase()));
	}

	@With(ActionReminder.class)
	public Result listProductsByDate(int pageNumber, int itemsPerPage) {
		String sortBy = "last_update", order = "desc";
		ctx().session().put("category", "");

		int pubCount = Product.getSearchCount("", Application.isAdminUser());

		return ok(storefront.render(Product.page(pageNumber, itemsPerPage, sortBy, order), null, pageNumber,
				itemsPerPage, sortBy, order, pubCount, pubCount, ""));
	}

	@With(ActionReminder.class)
	public Result listSearchResult(String word, int pageNumber, int itemsPerPage) {
		ctx().session().put("category", "");

		int pubCount = Product.getSearchCount("", Application.isAdminUser());

		int srchCount = Product.getSearchCount(word, Application.isAdminUser());

		return ok(storefront.render(Product.findMatches(word, pageNumber, itemsPerPage), word, pageNumber, itemsPerPage,
				"", "", pubCount, srchCount, ""));
	}

	@With(ActionReminder.class)
	public Result maintenanceItem(Long id) {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

		Product product;
                if (id <= 0) {
                    product = new Product();
                    product.logo = Product.DEFAULT_IMAGE_PATH;
                    // is_available_for_store のデフォルトをtrueにセット
                    product.isAvailableForStore = true;
                } else {
                    product = Product.findById(id);
                }

                if (product == null) {
                    return badRequest("nonexistent product.");
                }

                Form<Product> productForm = pForm.fill(product);
		return ok(maintitem.render(product, productForm));
	}

	@Security.Authenticated(Secured.class)
	public Result showLogoPicker() {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

		Long uid = new Long(ctx().session().get("userId"));
		return ok(logo.render(uid));
	}

        @Security.Authenticated(Secured.class)
        public Result getReleaseData(Long productId) {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

		Product product;
                product = Product.findById(productId);
                if (product == null) {
                    return badRequest("nonexistent product.");
                }

                if (product.releases.size() <= 0) {
                    return ok(Json.toJson(product.releases));
                }

                return ok(Json.toJson(product.releases.stream()
                                                      .map(r -> new DataMaintenance.ReleaseData(r))
                                                      .collect(Collectors.toList())
                       ));
        }

        @Security.Authenticated(Secured.class)
        public Result getMediumData(Long releaseSeq) {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                if (releaseSeq == -1) {
                    List<DataMaintenance.MediumData> empty;
                    empty = new ArrayList<DataMaintenance.MediumData>();
                    return ok(Json.toJson(empty));
                }

		Release release;
                release = Release.findById(releaseSeq);
                if (release == null) {
                    return badRequest("nonexistent release.");
                }

                if (release.media.size() <= 0) {
                    return ok(Json.toJson(release.media));
                }

                return ok(Json.toJson(release.media.stream()
                                                   .map(r -> new DataMaintenance.MediumData(r))
                                                   .collect(Collectors.toList())
                       ));
        }

        @Security.Authenticated(Secured.class)
        public Result editVersion() {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                JsonNode result;
                JsonNode post = request().body().asJson();
                if (post == null) {
                    return badRequest("Unxpected Json data. (null)");
                }

                List<JsonNode> insertedReleaseList = new ArrayList<JsonNode>();
                List<JsonNode> insertedMediumList  = new ArrayList<JsonNode>();
                List<JsonNode> updatedReleaseList  = new ArrayList<JsonNode>();
                List<JsonNode> updatedMediumList   = new ArrayList<JsonNode>();
                List<JsonNode> deletedReleaseList  = new ArrayList<JsonNode>();
                List<JsonNode> deletedMediumList   = new ArrayList<JsonNode>();

                post.get("inserted").get("releases").elements().forEachRemaining(e -> {
                    insertedReleaseList.add(e);
                });
                post.get("inserted").get("medium").elements().forEachRemaining(e -> {
                    insertedMediumList.add(e);
                });
                post.get("updated").get("releases").elements().forEachRemaining(e -> {
                    // クライアント側のeasyui datagrid('getChanges')で
                    // updatedにinsertedであるべきデータが含まれる場合があるため分別(DetailViewExtensionの影響？)
                    if(e.get("seq") == null) {
                        insertedReleaseList.add(e);
                    } else {
                        updatedReleaseList.add(e);
                    }
                });
                post.get("updated").get("medium").elements().forEachRemaining(e -> {
                    // クライアント側のeasyui datagrid('getChanges')で
                    // updatedにinsertedであるべきデータが含まれる場合があるため分別(DetailViewExtensionの影響？)
                    if(e.get("seq") == null) {
                        insertedMediumList.add(e);
                    } else {
                        updatedMediumList.add(e);
                    }
                });
                post.get("deleted").get("releases").elements().forEachRemaining(e -> {
                    deletedReleaseList.add(e);
                });
                post.get("deleted").get("medium").elements().forEachRemaining(e -> {
                    deletedMediumList.add(e);
                });

                Ebean.execute(() -> {
                    deletedMediumList.forEach(e -> {
                        Medium.deleteMedium(new Long(e.get("seq").asText()));
                    });
                    deletedReleaseList.forEach(e -> {
                        Release.deleteRelease(new Long(e.get("seq").asText()));
                    });
                    updatedMediumList.forEach(e -> {
                        Medium.updateMedium(
                            new Long(e.get("seq").asText())
                           ,e.get("packageType").asText()
                           ,e.get("url").asText()
                           ,e.get("platform").asText()
                           ,new Long(e.get("checksum").asText())
                           ,Release.findById(new Long(e.get("releaseId").asText()))
                        );
                    });
                    updatedReleaseList.forEach(e -> {
                        Date releasedDate;
                        try {
                            releasedDate = new SimpleDateFormat("yyyy-MM-dd").parse(e.get("releasedDate").asText());
                        } catch(java.text.ParseException pe) {
                            releasedDate = new Date();
                        }

                        Release.updateRelease(
                            new Long(e.get("seq").asText())
                           ,e.get("version").asText()
                           ,e.get("description").asText()
                           ,Product.findById(new Long(e.get("productId").asText()))
                           ,releasedDate
                           ,new Boolean(e.get("isStable").asText())
                           ,new Boolean(e.get("isActive").asText())
                           ,new Boolean(e.get("isUptodate").asText())
                        );
                    });
                    insertedMediumList.forEach(e -> {
                        Medium.addMedium(
                            e.get("packageType").asText()
                           ,e.get("url").asText()
                           ,e.get("platform").asText()
                           ,new Long(e.get("checksum").asText())
                           ,Release.findById(new Long(e.get("releaseId").asText()))
                        );
                    });
                    insertedReleaseList.forEach(e -> {
                        Date releasedDate;
                        try {
                            releasedDate = new SimpleDateFormat("yyyy-MM-dd").parse(e.get("releasedDate").asText());
                        } catch(java.text.ParseException pe) {
                            releasedDate = new Date();
                        }

                        Release.addRelease(
                            e.get("version").asText()
                           ,e.get("description").asText()
                           ,Product.findById(new Long(e.get("productId").asText()))
                           ,releasedDate
                           ,new Boolean(e.get("isStable").asText())
                           ,new Boolean(e.get("isActive").asText())
                           ,new Boolean(e.get("isUptodate").asText())
                        );
                    });
                });

                result = Json.toJson("true");
                return ok(result);
        }

        @Security.Authenticated(Secured.class)
        public Result getCpeInfoData(Long productId) {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                List<CpeInfo> cpeinfo;
                cpeinfo = CpeInfo.findByProductId(productId);

                if (cpeinfo.size() <= 0) {
                    return ok(Json.toJson(cpeinfo));
                }

                return ok(Json.toJson(cpeinfo.stream()
                                             .map(i -> new DataMaintenance.CpeInfoData(i))
                                             .collect(Collectors.toList())
                       ));
        }

        @Security.Authenticated(Secured.class)
        public Result editCpeInfo() {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                JsonNode result;
                JsonNode post = request().body().asJson();
                if (post == null) {
                    return badRequest("Unxpected Json data. (null)");
                }

                post.get("deleted").elements().forEachRemaining(e -> {
                    CpeInfo.deleteCpeInfo(new Long(e.get("id").asText()));
                });
                post.get("updated").elements().forEachRemaining(e -> {
                    CpeInfo.updateCpeInfo(
                        new Long(e.get("id").asText())
                       ,new Long(e.get("productId").asText())
                       ,e.get("vender").asText()
                       ,e.get("product").asText()
                    );
                });
                post.get("inserted").elements().forEachRemaining(e -> {
                    CpeInfo.addCpeInfo(
                        new Long(e.get("productId").asText())
                       ,e.get("vender").asText()
                       ,e.get("product").asText()
                    );
                });

                result = Json.toJson("true");
                return ok(result);
        }

        @Security.Authenticated(Secured.class)
        public Result showTagEditor() {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                return ok(mainttag.render());
        }

        @Security.Authenticated(Secured.class)
        public Result getTagData(String symbol) {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                Tag tag;
                tag = Tag.findBySymbol(symbol);

                if (tag == null) {
                    return badRequest("nonexistent tag.");
                }

                return ok(Json.toJson(new DataMaintenance.TagData(tag)));
        }

        @Security.Authenticated(Secured.class)
        public Result editTag() {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                JsonNode result;
                JsonNode post = request().body().asJson();

                if (post == null) {
                    return badRequest("Unxpected Json data. (null)");
                }

                switch (post.get("method").asText()) {
                case "add":
                    if (Tag.findBySymbol(post.get("symbol").asText()) != null) {
                        result = Json.toJson("false");
                        break;
                    }

                    Tag.addTag(
                        post.get("symbol").asText()
                       ,post.get("explanatoryName").asText()
                       ,new Boolean(post.get("isPrimary").asText())
                    );
                    result = Json.toJson("true");
                    break;

                case "update":
                    Tag.updateTag(
                        post.get("symbol").asText()
                       ,post.get("explanatoryName").asText()
                       ,new Boolean(post.get("isPrimary").asText())
                    );
                    result = Json.toJson("true");
                    break;

                case "delete":
                    Tag.deleteTagWithProductRelationship(post.get("symbol").asText());
                    result = Json.toJson("true");
                    break;

                default:
                    return badRequest("Unexpected Json data. (method:" + post.get("method").asText() +")");
                }

                return ok(result);
        }

        @Security.Authenticated(Secured.class)
        public Result showLicenseEditor() {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                return ok(maintlicense.render());
        }

        @Security.Authenticated(Secured.class)
        public Result getLicenseData(Long id) {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                if (id < 0) {
                    return badRequest("wrong id.");
                }

                License lic;
                lic = License.findById(id);

                return ok(Json.toJson(new DataMaintenance.LicenseData(lic)));
        }

        @Security.Authenticated(Secured.class)
        public Result editLicense() {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                JsonNode result;
                JsonNode post = request().body().asJson();

                Long delLicid;

                if (post == null) {
                    return badRequest("Unxpected Json data. (null)");
                }

                switch (post.get("method").asText()) {
                case "add":
                    License.addLicense(
                        post.get("fullname").asText()
                       ,post.get("nickname").asText()
                       ,post.get("url").asText()
                       ,post.get("overview").asText()
                       ,post.get("fulltext").asText()
                       ,new Boolean(post.get("isOSIApproved").asText())
                    );
                    result = Json.toJson("true");
                    break;

                case "update":
                    License.updateLicense(
                        new Long(post.get("id").asText())
                       ,post.get("fullname").asText()
                       ,post.get("nickname").asText()
                       ,post.get("url").asText()
                       ,post.get("overview").asText()
                       ,post.get("fulltext").asText()
                       ,new Boolean(post.get("isOSIApproved").asText())
                    );
                    result = Json.toJson("true");
                    break;

                case "delete":
                    delLicid = new Long(post.get("id").asText());
                    License.deleteLicense(delLicid);
                    result = Json.toJson("true");
                    break;

                default:
                    return badRequest("Unexpected Json data. (method:" + post.get("method").asText() +")");
                }

                return ok(result);
        }

        @Security.Authenticated(Secured.class)
        public Result getOrganizationData() {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                return ok(Json.toJson(DataMaintenance.getOrganizationData()));
        }

        @Security.Authenticated(Secured.class)
        public Result showOrganizationEditor(Long orgid) {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                String mode;
                Organization org;

                if (orgid == 0) {
                    mode = "add";
                    org  = new Organization();
                } else {
                    mode = "update";
                    org = Organization.findById(orgid);
                }

                return ok(maintorganization.render(mode, org));
        }

        @Security.Authenticated(Secured.class)
        public Result editOrganization() {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                JsonNode result;
                JsonNode post = request().body().asJson();

                Long delOrgid;
                List<Product> assoProds;

                if (post == null) {
                    return badRequest("Unxpected Json data. (null)");
                }

                switch (post.get("method").asText()) {
                case "add":
                    Organization.addOrganization(
                        post.get("fullname").asText()
                       ,post.get("url").asText()
                       ,Organization.OrganizationType.valueOf(post.get("orgType").asText())
                    );
                    result = Json.toJson("true");
                    break;

                case "update":
                    // 組織「不明」の編集はしない
                    if (post.get("id").asText().equals("-1")) {
                        return badRequest("Unexpected Json data. (id:-1)");
                    }

                    Organization.updateOrganization(
                        new Long(post.get("id").asText())
                       ,post.get("fullname").asText()
                       ,post.get("url").asText()
                       ,Organization.OrganizationType.valueOf(post.get("orgType").asText())
                    );
                    result = Json.toJson("true");
                    break;

                case "delete":
                    delOrgid = new Long(post.get("id").asText());

                    // 組織「不明」の削除はしない
                    if (delOrgid == -1) {
                        return badRequest("Unexpected Json data. (id:-1)");
                    }

                    // 対象組織を参照しているOSSを検索
                    assoProds = Product.findProductsWithOrganization(delOrgid);
                    if (assoProds.size() == 0) {
                        Organization.deleteOrganization(delOrgid);
                        result = Json.toJson("true");

                    } else {
                        result = Json.toJson(
                                     assoProds.stream()
                                              .map(p -> new DataMaintenance.OrganizationData(p.id.toString(), p.name))
                                              .collect(Collectors.toList())
                                 );
                    }
                    break;

                case "assodelete":
                    delOrgid = new Long(post.get("id").asText());

                    // 組織「不明」の削除はしない
                    if (delOrgid == -1) {
                        return badRequest("Unexpected Json data. (id:-1)");
                    }

                    // 対象組織を参照しているOSSを検索
                    assoProds = Product.findProductsWithOrganization(delOrgid);
                    if (assoProds == null ) {
                        Organization.deleteOrganization(delOrgid);
                        result = Json.toJson("true");

                    } else {
                        Organization.deleteOrganizationWithProductDevByCol(delOrgid);
                        result = Json.toJson("true");
                    }

                    break;

                default:
                    return badRequest("Unexpected Json data. (method:" + post.get("method").asText() +")");
                }

                return ok(result);
        }

        @Security.Authenticated(Secured.class)
        public Result editItem() {
                if (ctx().session().get("isAdmin").equals("0")) {
                    return badRequest("Admin Required");
                }

                JsonNode result;
                JsonNode post = request().body().asJson();

                if (post == null) {
                    return badRequest("Unxpected Json data. (null)");
                }
                System.out.println(post);

                switch (post.get("method").asText()) {
                case "add":
                    Long productId =
                        Product.addProduct(
                            post.get("name").asText()
                           ,post.get("description").asText()
                           ,post.get("projectUrl").asText()
                           ,post.get("logo").asText()
                           ,post.get("repository").asText()
                           ,Organization.findById(new Long(post.get("developedBy").asText()))
                           ,StreamSupport.stream(Spliterators.spliteratorUnknownSize(post.get("tags").elements(), Spliterator.ORDERED) ,false)
                                         .map(e -> Tag.findBySymbol(e.asText()))
                                         .collect(Collectors.toList())
                           ,StreamSupport.stream(Spliterators.spliteratorUnknownSize(post.get("declaredLicenses").elements(), Spliterator.ORDERED) ,false)
                                         .map(e -> License.findById(new Long(e.asText())))
                                         .collect(Collectors.toList())
                           ,null
                           ,new Boolean(post.get("isOSSDisplay").asText())
                        );

                    result = Json.parse("{\"result\":\"true\", \"productId\":\"" + productId.toString() + "\"}");
                    break;

                case "update":
                    Product.updateProduct(
                        new Long(post.get("id").asText())
                       ,post.get("name").asText()
                       ,post.get("description").asText()
                       ,post.get("projectUrl").asText()
                       ,post.get("logo").asText()
                       ,post.get("repository").asText()
                       ,Organization.findById(new Long(post.get("developedBy").asText()))
                       ,StreamSupport.stream(Spliterators.spliteratorUnknownSize(post.get("tags").elements(), Spliterator.ORDERED) ,false)
                                     .map(e -> Tag.findBySymbol(e.asText()))
                                     .collect(Collectors.toList())
                       ,StreamSupport.stream(Spliterators.spliteratorUnknownSize(post.get("declaredLicenses").elements(), Spliterator.ORDERED) ,false)
                                     .map(e -> License.findById(new Long(e.asText())))
                                     .collect(Collectors.toList())
                       ,null
                       ,new Boolean(post.get("isOSSDisplay").asText())
                    );

                    result = Json.parse("{\"result\":\"true\", \"productId\":\"" + post.get("id").asText() + "\"}");
                    break;

                case "delete":
                    Product.deleteProduct(
                        new Long(post.get("id").asText())
                    );

                    result = Json.parse("{\"result\":\"true\"}");
                    break;

                default:
                    return badRequest("Unexpected Json data. (method:" + post.get("method").asText() +")");
                }

                return ok(result);
        }

	@With(ActionReminder.class)
	public Result showItem(Long id) {
		Product product = Product.findById(id);

		List<SqlRow> vulsList = VulsInfo.getVulsListPerProduct(id);

		// String uid = ctx().session().get("userId");
		// ActivityRecord.saveActivity(product.id, (null==uid ||
		// "".equals(uid))? null : new Long(uid),
		// ActivityRecord.ActivityType.BROWSE);
		return ok(item.render(product, vulsList));
	}

	@Security.Authenticated(Secured.class)
	public Result procureItem(Long id) {
		Long uid = new Long(ctx().session().get("userId")); // danger...
		User currentUser = User.findById(uid);
		Product product = Product.findById(id);
		return ok(download.render(currentUser, product));
	}

	@Security.Authenticated(Secured.class)
	public Result downloadItem(Long id) {
		User currentUser = User.findById(new Long(ctx().session().get("userId"))); // danger...
		Product product = Product.findById(id);

                DynamicForm dynamicForm = dForm.bindFromRequest();
                //for debug
                //Map<String, String> map = dynamicForm.data();
                //System.out.println("--------------");
                //map.forEach((k, v) -> System.out.println(k + ":" + v));
                //System.out.println("--------------");

                if (dynamicForm.get("project") == null ) {
                    return badRequest("\"Project\" is Required.");
                }

                Medium medium = Medium.findById(new Long(dynamicForm.get("mediumSelect")));
                Project project = Project.findById(new Long(dynamicForm.get("project")));

                DownloadHistory.PurposeType purposeType;
                String text;
                switch (dynamicForm.get("usageSelect")) {
                case "redistribute":
                	purposeType = DownloadHistory.PurposeType.REDISTRIBUTE;
                        text        = "";
                	break;
                case "privateuse":
                        purposeType = DownloadHistory.PurposeType.PRIVATEUSE;
                        text        = "";
                	break;
                case "evaluation":
                        purposeType = DownloadHistory.PurposeType.EVALUATION;
                        text        = "";
                	break;
                default:
                        purposeType = DownloadHistory.PurposeType.OTHER;
                        text        = dynamicForm.get("otherReason");
                	break;
                }

                Ebean.execute(() -> {
		    ActivityRecord.saveActivity(product, medium.release.version, currentUser, ActivityRecord.ActivityType.ACQUIRE);
                    DownloadHistory.addHistory(medium, currentUser, project, purposeType, text);
                    UserProduct.addRelease(currentUser, project, medium.release);
                });

		return redirect(medium.url);

	}

	@With(ActionReminder.class)
	public Result showStatistics() {
		return ok(statistics.render());
	}

	@With(ActionReminder.class)
	public Result getProducts(String symbol) {
                List<Product> products;
                List<ReleaseStatistics.ProductData> result;

                if ("all".equals(symbol)) {
                    products = Product.findAll();
                } else {
		    products = Product.findProductsWithTag(symbol);
                }

                result = products.stream()
                                 .map(p -> new ReleaseStatistics.ProductData(p.id.toString(), p.name))
                                 .sorted()
                                 .collect(Collectors.toList());
                result.add(0, new ReleaseStatistics.ProductData("-1", "OSSの指定なし"));

                return ok(Json.toJson(result));
        }

	@With(ActionReminder.class)
	public Result getStatisticsTable() {
                DynamicForm dynamicForm = dForm.bindFromRequest();

                //for debug
                //Map<String, String> map = dynamicForm.data();
                //System.out.println("--------------");
                //map.forEach((k, v) -> System.out.println(k + ":" + v));
                //System.out.println("--------------");

                List<ReleaseStatistics> list = new java.util.LinkedList<ReleaseStatistics>();

                if (dynamicForm.get("product") == null || dynamicForm.get("category") == null) {
                    // NOP

                } else if (dynamicForm.get("product").equals("-1")) {
                    List<Product> productsList = dynamicForm.get("category").equals("all")
                        ? Product.findAll()
                        : Product.findProductsWithTag(dynamicForm.get("category"))
                    ;
                    if (productsList.size() != 0) {
                        List<ReleaseStatistics> stats = ReleaseStatistics.getReleasesStats(productsList);
                        Collections.sort(stats, (a, b) -> a.version.compareToIgnoreCase(b.version));
                        Collections.sort(stats, (a, b) -> a.ossname.compareToIgnoreCase(b.ossname));
                        Collections.sort(stats,
                            (a, b) -> Long.parseLong(a.download) > Long.parseLong(b.download) ? -1 :
                                                                a.download.equals(b.download) ?  0 :
                                                                                                 1
                        );
                        Collections.sort(stats,
                            (a, b) -> Long.parseLong(a.project) > Long.parseLong(b.project) ? -1 :
                                                                a.project.equals(b.project) ?  0 :
                                                                                               1
                        );
                        list.addAll(stats);
                    }

                } else {
                    Product product = Product.findById(new Long(dynamicForm.get("product")));
                    List<ReleaseStatistics> stats = ReleaseStatistics.getReleasesStats(product);
                    Collections.sort(stats, (a, b) -> a.version.compareToIgnoreCase(b.version));
                    Collections.sort(stats, (a, b) -> a.ossname.compareToIgnoreCase(b.ossname));
                    Collections.sort(stats,
                        (a, b) -> Long.parseLong(a.download) > Long.parseLong(b.download) ? -1 :
                                                            a.download.equals(b.download) ?  0 :
                                                                                             1
                    );
                    Collections.sort(stats,
                        (a, b) -> Long.parseLong(a.project) > Long.parseLong(b.project) ? -1 :
                                                            a.project.equals(b.project) ?  0 :
                                                                                           1
                    );
                    list.addAll(stats);
                }

                if (list.size() == 0) {
                    ReleaseStatistics rs = new ReleaseStatistics("", "条件に一致する結果は見つかりませんでした。", "", "", "", "");
                    list.add(rs);
                }

		return ok(Json.toJson(list));
	}

	@Security.Authenticated(Secured.class)
	public Result showReviewForm(Long id) {
		Product product = Product.findById(id);
		Long uid = new Long(ctx().session().get("userId"));
		return ok(review.render(product, uid));
	}

	@Security.Authenticated(Secured.class)
	public Result postReviewForm() {
		Map<String, String[]> form = request().body().asFormUrlEncoded();

		ProductReview newReview = new ProductReview();
		newReview.postDate = new Date();

		for (String k : form.keySet()) {
			String v = form.get(k)[0];
			if (null == v || "".equals(v)) {
			} else {
				switch (k) {
				case "productId":
					newReview.product = Product.findById(new Long(v));
					break;
				case "userId":
					newReview.user = User.findById(new Long(v));
					break;
				case "score":
					newReview.rate = new Double(v);
					break;
				case "usageSelect":
					newReview.usageCode = v;
					break;
				case "otherReason":
					newReview.otherUsage = v;
					break;
				case "comments":
					newReview.comment = v;
					break;
				case "isAnonymous":
					newReview.isAnonymous= new Boolean(v);
					break;
				default:
					break;
				}
			}
		}

                Ebean.execute(() -> {
                    newReview.save();
                    // userId must be present in session.
                    ActivityRecord.saveActivity(newReview.product, null, User.find.byId(new Long(ctx().session().get("userId"))),
				ActivityRecord.ActivityType.REVIEW);
                });

		return Application.pageToGo();
	}

	@Security.Authenticated(Secured.class)
	public Result showRequestForm(Long productId, String mode) {
		Long uid = new Long(ctx().session().get("userId"));

		User user = User.findById(uid);

		return ok(request.render(mode, ((null != productId) ? Product.findById(productId) : null), user, null));
	}

	/**
	 * 新規リクエスト登録画面にて「送信」ボタンが押下されたときの登録処理</br>
	 * 登録チェックエラーの場合、自画面に入力内容・メッセージを返す。
	 *
	 * @return
	 * @throws Exception
	 */
	@Security.Authenticated(Secured.class)
	public Result postRequestForm() throws Exception /* ugg */ {
		MaintenanceRequest newRequest = new MaintenanceRequest();
		newRequest.issueDate = new Date();
		newRequest.lastUpdateDate = newRequest.issueDate;
		newRequest.status = MaintenanceRequest.Progress.OPEN;
		User u = User.find.byId(new Long(ctx().session().get("userId")));
		newRequest.user = u;

		Map<String, String[]> form = request().body().asFormUrlEncoded();
		for (String k : form.keySet()) {
			String v = form.get(k)[0];
			if (null == v || "".equals(v)) {
			} else {
				switch (k) {
				case "requestType":
					switch (v) {
					case "NEWVERSION":
						newRequest.reqType = MaintenanceRequest.RequestType.NEWVERSION;
						break;
					case "NEWPRODUCT":
						newRequest.reqType = MaintenanceRequest.RequestType.NEWPRODUCT;
						break;
					case "FIXTYPO":
						newRequest.reqType = MaintenanceRequest.RequestType.FIXTYPO;
						break;
					case "OTHER":
						newRequest.reqType = MaintenanceRequest.RequestType.OTHER;
						break;
					case "UNREGPRODUCT":
						newRequest.reqType = MaintenanceRequest.RequestType.UNREGPRODUCT;
						break;
					default:
						break;
					}
					break;
				case "product":
					newRequest.productName = v;
					break;
				case "productId":
					newRequest.product = Product.find.byId(new Long(v));
					break;
				case "version":
					newRequest.version = v;
					break;
				case "preferedDate":
					// newRequest.preferedDate =
					// DateFormat.getDateInstance().parse(v);
					newRequest.preferedDate = Date.from(LocalDate.parse(v, YYYY_MM_DD).atTime(0, 0, 0)
							.atZone(ZoneOffset.systemDefault()).toInstant());
					break;
				case "comments":
					newRequest.comments = v;
					break;
				case "use_prj":
					newRequest.project = Project.find.where().eq("id", Long.parseLong(v)).findUnique();
					break;
				default:
					break;
				}
			}
		}

		// 入力された内容をチェックする
		String message = MaintenanceRequest.checkBeforeRegistration(newRequest);
		if(message != null) {
			return badRequest(request.render(newRequest.reqType.toString(), newRequest.product, u, message));
		} else {
		    // リクエストを登録

			Ebean.execute(() -> {

			newRequest.save();

			// メール送信
			sendRequestMail(newRequest.id);

			ActivityRecord.saveActivity(String.format("OSS名: %s, バージョン: %s", newRequest.productName, newRequest.version),
				u, ActivityRecord.ActivityType.REQUEST);
			});
	    }
		return Application.pageToGo();
	}

	@Security.Authenticated(Secured.class)
	public Result listActivities(int pageNumber, int itemsPerPage) {
		Long uid = new Long(ctx().session().get("userId")); // danger...
		User currentUser = User.findById(uid);
		return ok(activities.render(ActivityRecord.page(pageNumber, itemsPerPage, currentUser, true), pageNumber,
				itemsPerPage));
	}

	@Security.Authenticated(Secured.class)
	public Result showPreference() {
		Long uid = new Long(ctx().session().get("userId")); // danger...
		User currentUser = User.findById(uid);
		List<Project> projects = currentUser.projects;
		Project currentPrj = currentUser.currentProjectId != null ? Project.find.byId(currentUser.currentProjectId)
				: null;
		String mavenRepositoryUrl = config.getString(
			"maven.repository.url", "http://10.34.16.21/raw/repository/maven-public/");


		return ok(preference.render(currentUser, currentPrj, projects, mavenRepositoryUrl));
	}

	@Security.Authenticated(Secured.class)
	public Result updatePreference() {
		Long uid = new Long(ctx().session().get("userId")); // danger...
                // TODO: collect the form value and save changes, presumably the current
		// project.
		return Application.pageToGo();
	}

	public Result encryptPassword(String password) {
		return ok(password + ":" +User.encrypt(password));
	}

	/**
	 * 参加プロジェクト画面を表示する。
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result showJoinProject() {
		Long uid = new Long(ctx().session().get("userId"));

		User curUser = User.findById(uid);
		Long curPrjId = curUser.currentProjectId == null ? 0L : curUser.currentProjectId;

		List<SqlRow> sqlrows = Project.getUserProject(uid);

		List<Project> projects = curUser.projects;

		return ok(project.render(sqlrows, curPrjId, projects));
	}

	/**
	 * 参加プロジェクト編集画面を表示する。
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result showEditProject() {
		Long uid = new Long(ctx().session().get("userId"));
		User user = User.findById(uid);

		Long deptid = Dept.getPrimaryDeptId(uid);
//		List<SqlRow> prjList = Project.getProjectByName(uid, deptid, "");

		List<Project> managers = new ArrayList<Project>();

		// プロジェクト責任者の取得をプロジェクト本体の情報とは別に取得する
		List<SqlRow> joinPrj = Project.getJoinProjectByUserSection(uid);
		for(SqlRow row : joinPrj) {
			Project prj = Project.findById(row.getLong("id"));
			managers.add(prj);
		}

		List<SqlRow> otherSectPrj = Project.getJoinProjectByOtherSection(uid);
		for(SqlRow row : otherSectPrj) {
			Project prj = Project.findById(row.getLong("id"));
			managers.add(prj);
		}

		List<SqlRow> notJoinPrj = Project.getNotJoinProjectByUserSection(uid);
		for(SqlRow row : notJoinPrj) {
			Project prj = Project.findById(row.getLong("id"));
			managers.add(prj);
		}

		return ok(editproject.render(joinPrj, otherSectPrj, notJoinPrj, user, deptid, "", managers, "0", ""));
	}

	/**
	 * 参加プロジェクト編集画面の「検索」、「新規追加」、「反映」ボタン押下時の処理</br>
	 * 　フォームデータの処理タイプ（operType）により処理を振り分ける
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result controlProject() {
		Long uid = new Long(ctx().session().get("userId"));
		User curUser = User.findById(uid);

		List<SqlRow> joinPrj = new ArrayList<SqlRow>();
		List<SqlRow> otherSectPrj = new ArrayList<SqlRow>();
		List<SqlRow> notJoinPrj = new ArrayList<SqlRow>();

		Map<String, String[]> form = request().body().asFormUrlEncoded();

		Long deptid = null;
		String srchPrjName = "";
		String message = "";
		String updated = "0";

		if(form != null) {
			updated = "1";
			String strOperType = (form.get("operType"))[0];

			deptid = Long.parseLong((form.get("dept_id"))[0]);

			// 「検索」ボタン押下時
			if("1".equals(strOperType)) {
				// 検索文字列
				srchPrjName = (form.get("srch_proj"))[0];

				if(srchPrjName == null || srchPrjName.length() == 0) {
					srchPrjName = "";
				}

				joinPrj = Project.getProjectByName(uid, deptid, srchPrjName);

				// 「新規作成」ボタン押下時
			} else if("2".equals(strOperType)) {
				// プロジェクト名
				String prjName = (form.get("prj_name"))[0];

				// 説明
				String prjDesc = "";
				if((form.get("prj_desc")[0]) != null || (form.get("prj_desc")[0]).length() > 0){
					prjDesc = (form.get("prj_desc"))[0];
				}

				// プロジェクト責任者
				String[] managers = (form.get("managers")[0]).split(",");

				int nRet = Project.saveProject(prjName, prjDesc, deptid, uid, managers);
				if(nRet == 1){
					message = "同一名のプロジェクトがすでに登録されています。";
				} else if(nRet == -1) {
					message = "システムエラーが発生しました。<br/>管理者に連絡してください。";
				}

				joinPrj = Project.getProjectByName(uid, deptid, "");
//				joinPrj = Project.getJoinProjectByUserSection(uid, deptid);
//				otherSectPrj = Project.getJoinProjectByOtherSection(uid, deptid);
//				notJoinPrj = Project.getNotJoinProjectByUserSection(uid, deptid);

				// 活動履歴の保存
				ActivityRecord.saveActivity(prjName, curUser, ActivityRecord.ActivityType.ADDPROJECT);

				// 「参加」ボタン押下時
			} else if("3".equals(strOperType)) {
				String[] joinId = (form.get("join_id")[0]).split(",");
				String[] joinType = (form.get("join_type")[0]).split(",");

				int nRet = Project.updateProject(uid, joinId, joinType);
				if(nRet != 0) {
					message = "システムエラーが発生しました。<br/>管理者に連絡してください。";
				}

				List<SqlRow> sqlrows = Project.getUserProject(uid);

				Long curPrjId = curUser.currentProjectId == null ? 0L : curUser.currentProjectId;

				// カレントプロジェクト名称を履歴に残す（※プロジェクトの参加解除によってカレントプロジェクトがなくなることもある）
				// 活動履歴の保存
				if(curPrjId == 0L) {
					ActivityRecord.saveActivity("", curUser, ActivityRecord.ActivityType.SELECTPROJECT);
				} else {
					ActivityRecord.saveActivity(Project.findById(curPrjId).nickName, curUser, ActivityRecord.ActivityType.SELECTPROJECT);
				}

				return ok(project.render(sqlrows, curPrjId, curUser.projects));
				// ここは基本的には通らない
			} else {
//				prjList = Project.getProjectByName(uid, deptid, "");
				joinPrj = Project.getJoinProjectByUserSection(uid);
				otherSectPrj = Project.getJoinProjectByOtherSection(uid);
				notJoinPrj = Project.getNotJoinProjectByUserSection(uid);

			}
		} else {
			deptid = Dept.getPrimaryDeptId(uid);
//			prjList = Project.getProjectByName(uid, deptid, "");
			joinPrj = Project.getJoinProjectByUserSection(uid);
			otherSectPrj = Project.getJoinProjectByOtherSection(uid);
			notJoinPrj = Project.getNotJoinProjectByUserSection(uid);
		}

		List<Project> managers = new ArrayList<Project>();
		// それぞれのプロジェクト情報からプロジェクトの責任者をとってくる
		for(SqlRow row : joinPrj) {
			Project prj = Project.findById(row.getLong("id"));
			managers.add(prj);
		}

		for(SqlRow row : otherSectPrj) {
			Project prj = Project.findById(row.getLong("id"));
			managers.add(prj);
		}

		for(SqlRow row : notJoinPrj) {
			Project prj = Project.findById(row.getLong("id"));
			managers.add(prj);
		}

		return ok(editproject.render(joinPrj, otherSectPrj, notJoinPrj, curUser, deptid, srchPrjName, managers, updated, message));
	}

	/**
	 * 参加プロジェクト設定画面の「設定」ボタン押下時の処理</br>
	 * 　選択されたプロジェクトIDを取得し、ginjauser.current_project_idを更新する</br>
	 * 　更新処理後、ホーム画面に遷移する
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result setProject() {
		String backUrl = "/store";
		if(ctx().session().get("urlToGo") != null) {
			backUrl = ctx().session().get("urlToGo");
		}

		Long uid = new Long(ctx().session().get("userId"));

		Map<String, String[]> form = request().body().asFormUrlEncoded();

		Long prjid = Long.parseLong((form.get("selPrjId"))[0]);

		// 現在のプロジェクトIDを更新する
		User.updateCurrentProjectId(prjid, uid);

		return redirect(backUrl);
	}

	/**
	 * 「OSS登録申請照会」メニュー選択時の処理</br>
	 * OSS登録申請照会画面を表示する
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result showRequestList() {

		Long uid = new Long(ctx().session().get("userId")); // danger...

		List<SqlRow> result = MaintenanceRequest.getMaintenanceRequestByUserid(uid);

		return ok(requestlist.render(result, null));
	}

	/**
	 * 「OSS登録申請」メニュー選択時の処理</br>
	 * OSS登録申請画面を表示する
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result showRequestApprove(){
		// 検索オプションに使用するOSS製品名のリスト
		List<Product> products = Product.find.where().orderBy("name").findList();

		// 初期表示は「申請中」もののみ
		List<SqlRow> requests = MaintenanceRequest.getConditionedMaintenanceRequest("0,2,4", "0", "", "", "", "", "", "", "", "");
		return ok(requestapprove.render(requests, products));
	}

	/**
	 * 登録承認画面表示時（初期表示・「検索」or「承認」or「却下」ボタン押下時の画面再描画）の登録リクエスト更新・取得処理</br>
	 * 登録リクエスト内容を取得する際にSqlRow型で結果を受け取っていますが、そのままではJSON形式に変換できないため、いったんUserRequestオブジェクトに保持してから変換をかけています。
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result postRequestApprove() {
    	Map<String, String[]> form = request().body().asFormUrlEncoded();

		List<Product> products = Product.find.where().orderBy("name").findList();

		List<SqlRow> requests = null;
    	if(form != null) {
			// 呼び出し元の画面でセットされている検索条件で登録情報を取得しなおす
			String reqStatus = "";
			String reqType = "";
			String ossName = "";
			String ossVersion = "";
			String sectionName = "";
			String reqUser = "";
			String startDate = "1900-01-01";
			String endDate = "9999-12-31";
			String prefStartDate = "1900-01-01";
			String prefEndDate = "9999-12-31";

			String mode = form.get("mode")[0];
			String[] requestId = (form.get("req_id")[0]).split(",");
			// 「承認」 or 「却下」ボタン押下
			if("ACCEPTED".equals(mode) || "REJECTED".equals(mode)) {

				// 承認・却下処理
				boolean bRet = MaintenanceRequest.updateMatenanceRequest(mode, requestId);
				if(bRet) {
					for(String id : requestId) {
						sendRequestMail(Long.valueOf(id));
					}
				}
			} else if("UPDATE".equals(mode)) {
				Long id = Long.valueOf(requestId[0]);
				String comment = form.get("adm_comment")[0];

				MaintenanceRequest.updateAdminComment(id, comment);

				// 画面は更新せずにそのまま
				return ok();
			}

			if(!"UPDATE".equals(mode)) {
				// 検索条件（hiddenフィールドで保持している値）で値を取り直し
				for (String key : form.keySet()) {
					String value = form.get(key)[0];
					switch (key) {
					case "req_type" :
						reqType = value;
						break;
					case "req_status" :
						reqStatus = value;
						break;
					case "oss" :
						if(!"".equals(value) || value.length() != 0) {
							ossName = value.replaceAll("[_%\\[#]", "#$0");
						}
						break;
					case "version" :
						if(!"".equals(value) || value.length() != 0) {
							ossVersion = value;
						}
						break;
					case "req_section" :
						if(!"".equals(value) || value.length() != 0) {
							sectionName = value.replaceAll("[_%\\[#]", "#$0");
						}
						break;
					case "req_user" :
						if(!"".equals(value) || value.length() != 0) {
							reqUser = value.replaceAll("[_%\\[#]", "#$0");
						}
						break;
					case "req_startdate" :
						if(!"".equals(value) || value.length() != 0) {
							startDate = value;
						}
						break;
					case "req_enddate" :
						if(!"".equals(value) || value.length() != 0) {
							endDate = value;
						}
						break;
					case "req_pref_startdate" :
						if(!"".equals(value) || value.length() != 0) {
							prefStartDate = value;
						}
						break;
					case "req_pref_enddate" :
						if(!"".equals(value) || value.length() != 0) {
							prefEndDate = value;
						}
						break;
					}
				}
		    	requests = MaintenanceRequest.getConditionedMaintenanceRequest(reqType, reqStatus, ossName, ossVersion, sectionName, reqUser, startDate, endDate, prefStartDate, prefEndDate);
			}
		} else {
			// 初期表示時は「申請中」を表示させる
			requests = MaintenanceRequest.getConditionedMaintenanceRequest("0,2,4", "0", "", "", "", "", "", "", "", "");
		}
		return ok(requestapprove.render(requests, products));
    }

	/**
	 * OSS登録照会画面表示時（「取消」ボタン押下時の画面再描画）の登録リクエスト更新・取得処理</br>
	 * 登録リクエストを取得する際にSqlRow型で結果を受け取っていますが、そのままではJSON形式に変換できないため、いったんUserRequestオブジェクトに保持してから変換をかけています。
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
    public Result postRequestList() {
		Long uid = new Long(ctx().session().get("userId")); // danger...

		String[] requestId = null;

		Map<String, String[]> form = request().body().asFormUrlEncoded();
		if(form != null){
			requestId = (form.get("req_id")[0]).split(",");

			// 「取消」ボタンが押されたとき
			boolean bRet = MaintenanceRequest.updateMatenanceRequest("CANCELED", requestId);
			if(bRet) {
				// 取消処理（DB更新）が正常に行われた場合にメールを送信する
				for(String id : requestId) {
					sendRequestMail(Long.valueOf(id));
				}
			}
		}

		List<SqlRow> result = MaintenanceRequest.getMaintenanceRequestByUserid(uid);

		return ok(requestlist.render(result, requestId));
    }

	/**
	 * 一般ユーザー向け利用中OSS一覧画面を表示する
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result showUserOSSList(String pid, String ver) {
		Long uid = new Long(ctx().session().get("userId")); // danger...

		Long productId = null;
		if(!"".equals(pid) || pid.length() > 0) {
			productId = Long.parseLong(pid);
		}

		User curUser = User.findById(uid);
		Long selPrjId = curUser.currentProjectId;

		//		List<SqlRow> ossList = UserProduct.getUseOssList(uid, productId, ver);

		List<SqlRow> ossList = UserProduct.getUseOssListByUserCondition(uid, "", selPrjId, productId, "", "", "", "", "0");

		List<SqlRow> rows = UserProduct.getUseOSSListByManager(uid, "", selPrjId, productId, "", "", "", "");
		for(SqlRow row : rows) {
			ossList.add(row);
		}

		// 現在参加中のプロジェクトと参加解除した（過去にOSSをダウンロードした）プロジェクトのリストを取得
		List<Project> projects = curUser.projects;
		List<SqlRow> joinedPrj = Project.getJoinedProjectByUser(uid);

		// 自身が責任者となっているプロジェクトのリスト
		List<SqlRow> managedPrj = Project.getRelatedUserProject(uid);

		return ok(userosslist.render(projects, ossList, joinedPrj, managedPrj, selPrjId, null));
	}

	/**
	 * 管理者向け利用中OSS一覧画面を表示する
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result showAdminOssList(String pid, String ver) {

		List<Product> products = Product.find.where().orderBy("name").findList();

		String mode = "0";
		List<SqlRow> osslist = null;
		// 脆弱性情報照会画面から呼び出されるときは、OSS製品IDとバージョンがついている
		if(!"".equals(pid) && !"".equals(ver)) {
			osslist = UserProduct.getUseOssList(null, Long.parseLong(pid), ver);
			mode = "1";
		}

		return ok(adminosslist.render(products, osslist, mode));
	}

	/**
	 * 利用中OSS一覧画面表示処理<br/>
	 * 「検索」ボタン押下時のデータ取得処理からの再描画で呼び出されます。<br/>
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result postAdminOssList() {
		Map<String, String[]> form = request().body().asFormUrlEncoded();

		List<SqlRow> result = null;

		if(form != null){
    		// 「検索」ボタン押下時
			// 呼び出し元の画面でセットされている検索条件で登録情報を取得しなおす
			String[] useStatus = null;
			Long productId = null;
			String version = "";
    		String useStartDate = "";
			String useEndDate = "";
			String stopStartDate = "";
			String stopEndDate = "";
			for (String key : form.keySet()) {
				String value = form.get(key)[0];
				switch (key) {
				case "use_status" :
					useStatus = form.get("use_status");
					break;
				case "product" :
					try {
						productId = Long.parseLong(value);
						if(productId == 0) {
							productId = null;
						}
					} catch(NumberFormatException e) {
						productId = null;
					}
					break;
				case "version" :
					version = value;
					break;
				case "use_startdate" :
					if(value == null || value.length() == 0) {
						useStartDate = "1900-01-01";
					} else {
						useStartDate = value;
					}
					break;
				case "use_enddate" :
					if(value == null || value.length() == 0) {
						useEndDate = "9999-12-31";
					} else {
						useEndDate = value;
					}
					break;
				case "stop_startdate" :
					if(value == null || value.length() == 0) {
						stopStartDate = "1900-01-01";
					} else {
						stopStartDate = value;
					}
					break;
				case "stop_enddate" :
					if(value == null || value.length() == 0) {
						stopEndDate = "9999-12-31";
					} else {
						stopEndDate = value;
					}
					break;
				}
			}
			result = UserProduct.getUseOSSListByCondition(useStatus, productId, version, useStartDate, useEndDate, stopStartDate, stopEndDate);
    	} else {
    		result = UserProduct.getUseOssList(null, null, "");
    	}

		List<Product> products = Product.find.where().orderBy("name").findList();

		return ok(adminosslist.render(products, result, "0"));
	}

	/**
	 * 利用OSS一覧画面の「更新」ボタン押下時の更新と画面再描画のデータ取得処理
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result postUserOssList() {

		Long uid = new Long(ctx().session().get("userId")); // danger...

    	Map<String, String[]> form = request().body().asFormUrlEncoded();

    	String[] seq = null;
    	List<SqlRow> ossList = null;

    	if(form != null) {
    		String mode = form.get("mode")[0];

    		if("UPDATE".equals(mode)) {
    			seq = (form.get("seq")[0]).split(",");
    			String[] projectId = (form.get("project_id")[0]).split(",");
    			String[] useStatus = (form.get("upd_kind")[0]).split(",");

    			String[] notes = new String[seq.length];
    			for(int i = 0; i < seq.length; i++){
    				String control = "notes_" + seq[i];

    				String comments = form.get(control)[0] == null ? "" : form.get(control)[0];
    				notes[i] = comments;
    			}

    			// 更新処理
    			UserProduct.updateUserProduct(seq, projectId, useStatus, notes);
    		}

    		String status = "";
    		Long projectId = null;
    		String section = "";
    		String username = "";
    		String startDate = "1900-01-01";
    		String endDate = "9999-12-31";
    		String option = "";
    		for(String key : form.keySet()) {
    			String value = form.get(key)[0];

    			switch(key) {
    			case "req_status" :
    				status = value;
    				break;
    			case "req_project" :
    				if(!"".equals(value) && !"0".equals(value)) {
        				projectId = Long.valueOf(value);
    				}
    				break;
    			case "req_section" :
    				if(!"".equals(value) || value.length() != 0) {
						section = value.replaceAll("[_%\\[#]", "#$0");
    				}
    				break;
    			case "req_user" :
    				if(!"".equals(value) || value.length() != 0) {
						username = value.replaceAll("[_%\\[#]", "#$0");
    				}
    				break;
				case "req_startdate" :
					if(!"".equals(value) || value.length() != 0) {
						startDate = value;
					}
					break;
				case "req_enddate" :
					if(!"".equals(value) || value.length() != 0) {
						endDate = value;
					}
					break;
				case "req_option" :
					option = value;
					break;
				}
			}
//    		ossList = UserProduct.getUseOssList(uid, null, "");
			ossList = UserProduct.getUseOssListByUserCondition(uid, status, projectId, null, section, username, startDate, endDate, option);
			if("0".equals(option)) {
				List<SqlRow> rows = UserProduct.getUseOSSListByManager(uid, status, projectId, null, section, username, startDate, endDate);

				for(SqlRow row : rows) {
					ossList.add(row);
				}
			}
		}

		User curUser = User.findById(uid);

		List<Project> projects = curUser.projects;
		List<SqlRow> joinedPrj = Project.getJoinedProjectByUser(uid);

		// 自身が責任者となっているプロジェクトのリスト
		List<SqlRow> managedPrj = Project.getRelatedUserProject(uid);

		return ok(userosslist.render(projects, ossList, joinedPrj, managedPrj, curUser.currentProjectId, seq));
	}

	/**
	 * 一般ユーザー向け脆弱性情報照会画面を表示する。<br/>
	 * ここでは取得範囲はユーザーがダウンロードした製品に関する脆弱性情報
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result showUserVulnList() {
		Long uid = new Long(ctx().session().get("userId")); // danger...

		Long curPrjId = User.findById(uid).currentProjectId;

		// 初期表示は自身が参加するプロジェクト経由および自身が責任者となっているプロジェクトでダウンロードされたOSSに関する脆弱性情報
		List<SqlRow> rows = VulsInfo.getVulsListByUser(uid, null, null, "", "", "", "", curPrjId, VulsInfo.JOIN_PROJECT_OSS);

		List<Product> products = Product.find.where().orderBy("name").findList();

		List<SqlRow> projects = Project.getRelatedUserProject(uid);

		// 脆弱性情報を取得するメソッドを呼ぶ（取得キーはユーザーID）

		return ok(uservulnlist.render(projects, products, rows, curPrjId));
	}

	/**
	 * 「検索」ボタン押下時のデータ取得処理
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result postUserVulnList() {
		Long uid = new Long(ctx().session().get("userId")); // danger...
		Long selPrjId = null;

		Map<String, String[]> form = request().body().asFormUrlEncoded();

		List<SqlRow> vulnNotes = null;
		if(form != null) {
			Long productId = null;
			String version = "";
			Double score = null;
			String cveId = "";
			String startDate = "1900-01-01";
			String endDate = "9999-12-31";
			Long projectId = null;
			String option = VulsInfo.JOIN_PROJECT_OSS;

			for (String key : form.keySet()) {
				String value = form.get(key)[0];
				switch (key) {
				case "prj_chk" :
					option = VulsInfo.USER_DOWNLOAD_OSS;
					break;
				case "product_id" :
					// OSS製品名はIDの一致するもの
					try {
						productId = Long.parseLong(value);
						if(productId == 0) {
							productId = null;
						}
					} catch(NumberFormatException e) {
						productId = null;
					}
					break;
				case "project" :
					// プロジェクトはIDの一致するもの
					if(!"0".equals(value)) {
						projectId = Long.parseLong(value);
						selPrjId  = projectId;

					}
					break;
				case "oss_version" :
					// バージョンは完全一致
					if(!"".equals(value) || value.length() != 0) {
						version = value;
					}
					break;
				case "score" :
					// スコアは完全一致
					if(!"".equals(value) || value.length() != 0) {
						score = Double.valueOf(value);
					}
					break;
				case "cve_id" :
					// CVE識別番号は前方一致
					if(!"".equals(value) || value.length() != 0) {
						cveId = value;
					}
					break;
				case "startdate" :
					if(!"".equals(value) || value.length() != 0) {
						startDate = value;
					}
					break;
				case "enddate" :
					if(!"".equals(value) || value.length() != 0) {
						endDate = value;
					}
					break;
				}
			}
			vulnNotes = VulsInfo.getVulsListByUser(uid, score, productId, version, cveId, startDate, endDate, projectId, option);
    	} else {
    		// この処理は基本的にはありえない（ねんのため、ユーザIDで全件）
			vulnNotes = VulsInfo.getVulsListByUser(uid, null, null, "", "", "", "", null, VulsInfo.USER_DOWNLOAD_OSS);
    	}
		List<Product> products = Product.find.where().orderBy("name").findList();

		List<SqlRow> projects = Project.getRelatedUserProject(uid);

		return ok(uservulnlist.render(projects, products, vulnNotes, selPrjId));
	}

	/**
	 * 管理者向け脆弱性情報照会画面を表示する
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result showAdminVulnList() {
		// 管理者で初期表示は何も表示させない
		List<SqlRow> vulsList = VulsInfo.getVulsListByAdmin(null, "", null, "", "", "");

    	List<Product> products = Product.find.where().orderBy("name").findList();

		return ok(adminvulnlist.render(products, vulsList));
	}

	/**
	 * 「検索」ボタン押下時のデータ取得処理
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result postAdminVulnList() {
		Map<String, String[]> form = request().body().asFormUrlEncoded();

		List<SqlRow> vulsList = null;
    	if(form != null) {
    		Long productId = null;
    		String version = "";
    		Double score = null;
    		String cveId = "";
    		String startDate = "1900-01-01";
    		String endDate = "9999-12-31";

			for (String key : form.keySet()) {
				String value = form.get(key)[0];
				switch (key) {
				case "product_id" :
					// OSS製品名はIDの一致するもの
					// OSS製品コンボボックスは製品名の一部入力でヒットさせることができるが、不用意な入力を防ぐためわざと例外を発生させてid(数値)に変換できなかったものはnullにしている
					try {
						productId = Long.parseLong(value);
						if(productId == 0) {
							productId = null;
						}
					} catch(NumberFormatException e) {
						productId = null;
					}
					break;
				case "oss_version" :
					// バージョンは完全一致
					if(!"".equals(value) || value.length() != 0) {
						version = value;
					}
					break;
				case "score" :
					// スコアは完全一致
					if(!"".equals(value) || value.length() != 0) {
						score = Double.valueOf(value);
					}
					break;
				case "cve_id" :
					// CVE識別番号は前方一致
					if(!"".equals(value) || value.length() != 0) {
						cveId = value;
					}
					break;
				case "startdate" :
					if(!"".equals(value) || value.length() != 0) {
						startDate = value;
					}
					break;
				case "enddate" :
					if(!"".equals(value) || value.length() != 0) {
						endDate = value;
					}
					break;
				}
			}
	    	vulsList = VulsInfo.getVulsListByAdmin(productId, version, score, cveId, startDate, endDate);
    	} else {
    		// この処理は基本的にはありえない（ねんのため、0件でヒットさせる）
    		vulsList = VulsInfo.getVulsListByAdmin(null, "", null, "", "", "");
    	}

		List<Product> products = Product.find.where().orderBy("name").findList();

		return ok(adminvulnlist.render(products, vulsList));
	}

	/**
	 * 「詳細」リンククリック時の詳細情報表示処理
	 *
	 * @param name OSS製品名
	 * @param version バージョン
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result showVulnDetail(String name, String version, String id) {
		List<SqlRow> vulsList = VulsInfo.getVulsDetail(name, version, Long.valueOf(id));

		return ok(vulndetail.render(name, version, vulsList));
	}

	// リクエストのメールを送信する
	public void sendRequestMail(Long requestId) {
		SendMailController mail = SendMailController.getInstance();

		MaintenanceRequest req = MaintenanceRequest.find.byId(requestId);

		mail.setMailRequest(req);
		mail.start();
	}

	/**
	 * 管理者向け活動履歴照会画面を表示する
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result showAdminActRecord() {
		List<SqlRow> result = new ArrayList<SqlRow>();
		List<Product> products = Product.find.orderBy("name").findList();

		return ok(adminactrecord.render(result, products));
	}

	/**
	 * 「検索」ボタン押下時の活動履歴照会画面を表示する
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result postAdminActRecord() {
		Map<String, String[]> form = request().body().asFormUrlEncoded();

		List<SqlRow> result = new ArrayList<SqlRow>();
		List<Product> products = Product.find.orderBy("name").findList();

		if(form != null) {
			String actType = "";
			Long deptId = null;
			String userName = "";
			String startDate = "1900-01-01";
			String endDate = "9999-12-31";
			Long productId = null;
			String objective = "";
			for (String key : form.keySet()) {
				String value = form.get(key)[0];
				switch (key) {
				case "chk_type" :
					actType = value;
					break;
				case "dept_id" :
					if(!"".equals(value)) {
						deptId = Long.valueOf(value);
					}
					break;
				case "username" :
					if(!"".equals(value) || value.length() != 0) {
						userName = value;
					}
					break;
				case "startdate" :
					if(!"".equals(value) || value.length() != 0) {
						startDate = value;
					}
					break;
				case "enddate" :
					if(!"".equals(value) || value.length() != 0) {
						endDate = value;
					}
					break;
				case "product" :
					if(!"0".equals(value)) {
						productId = Long.valueOf(value);
					}
					break;
				case "objective" :
					if(!"".equals(value) || value.length() != 0) {
						objective = value;
					}
					break;
				}
			}
			result = ActivityRecord.getActiviesByCondition(actType, deptId, userName, startDate, endDate, productId, objective);
		}
		return ok(adminactrecord.render(result, products));
	}

	/**
	 * プロジェクト責任者編集画面を表示する<br>
	 * 　呼び出しもとの画面の操作により処理を振り分ける。<br>
	 * 　　0 : 参加プロジェクト設定画面からの責任者更新<br>
	 * 　　1 : 参加プロジェクト編集画面の既存プロジェクトの責任者更新<br>
	 * 　　2 : 参加プロジェクト編集画面の新規プロジェクト作成での責任者更新<br>
	 *
	 * @param proc 呼び出し元からどんな操作で当該画面が呼び出されたか？
	 * @param projectId プロジェクトID
	 * @param uids
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result showEditManager(String proc, String projectId, String updated, String deptid, String userid) {
		List<SqlRow> users = new ArrayList<SqlRow>();

		Long pid = new Long(projectId);

		List<SqlRow> managers = new ArrayList<SqlRow>();
		if(!pid.equals(0L)) {
			managers = Project.getProjectManager(pid);
		} else {
			if(!"".equals(userid) || userid.length() != 0) {
				managers = User.getUserInfoById(userid.split(","));
			}
		}
		return ok(editmanager.render(users, managers, pid, Long.parseLong(deptid), proc, updated));
	}

	/**
	 * プロジェクト責任者編集画面の「検索」・「更新」ボタン押下時の処理
	 *
	 * @return
	 */
	@Security.Authenticated(Secured.class)
	public Result postEditManager() {
		Long uid = new Long(ctx().session().get("userId"));

		User curUser = User.findById(uid);

		List<SqlRow> users = new ArrayList<SqlRow>();
		List<SqlRow> managers = new ArrayList<SqlRow>();

		String method = request().method().toUpperCase();
		if("POST".equals(method)) {
			Map<String, String[]> form = request().body().asFormUrlEncoded();

			if(form != null) {
				String operate = form.get("operate")[0];

				if("ADD".equals(operate)) {
					// プロジェクトID
					Long projectId = Long.valueOf(form.get("project_id")[0]);

					// ユーザーID
					String[] userIds = (form.get("user_id")[0]).split(",");

					// プロジェクト責任者の更新処理
					Project.updateProjectManager(projectId, userIds);

					String mode = form.get("mode")[0];
					// 参加プロジェクト設定画面へ戻る
					if("0".equals(mode)) {

						Long curPrjId = curUser.currentProjectId == null ? 0L : curUser.currentProjectId;

						List<SqlRow> sqlrows = Project.getUserProject(uid);

						List<Project> projects = curUser.projects;

						return ok(project.render(sqlrows, curPrjId, projects));
					} else if("1".equals(mode)) {
						// 参加プロジェクト編集画面へ戻る
						String updated = form.get("updated")[0];
						Long deptid = Long.parseLong((form.get("dept_id"))[0]);

						List<SqlRow> joinPrj = new ArrayList<SqlRow>();
						List<SqlRow> otherSectPrj = new ArrayList<SqlRow>();
						List<SqlRow> notJoinPrj = new ArrayList<SqlRow>();
						if("0".equals(updated)) {
							joinPrj = Project.getJoinProjectByUserSection(uid);
							otherSectPrj = Project.getJoinProjectByOtherSection(uid);
							notJoinPrj = Project.getNotJoinProjectByUserSection(uid);
						} else {
							joinPrj = Project.getProjectByName(uid, deptid, "");
						}

						List<Project> projects = new ArrayList<Project>();
						// それぞれのプロジェクト情報からプロジェクトの責任者をとってくる
						for(SqlRow row : joinPrj) {
							Project prj = Project.findById(row.getLong("id"));
							projects.add(prj);
						}

						for(SqlRow row : otherSectPrj) {
							Project prj = Project.findById(row.getLong("id"));
							projects.add(prj);
						}

						for(SqlRow row : notJoinPrj) {
							Project prj = Project.findById(row.getLong("id"));
							projects.add(prj);
						}
						return ok(editproject.render(joinPrj, otherSectPrj, notJoinPrj, curUser, null, "", projects, "0", ""));
					}
				} else if("SEARCH".equals(operate)) {
					// 「検索」ボタン押下時は自身の画面に留まる
					String empNum = "";
					String username = "";

					for (String key : form.keySet()) {
						String value = form.get(key)[0];
						switch (key) {
						case "emp_num" :
							empNum = value.replaceAll("[_%\\[#]", "#$0");
							break;
						case "emp_name" :
							username = value.replaceAll("[_%\\[#]", "#$0");
							break;
						}
					}
					users = User.searchUser(empNum, username);
					return ok(editmanager.render(users, managers, null, null, "", ""));
				}
			}
		}
		return ok(editmanager.render(users, managers, null, null, "", ""));
	}

	public Result showMailContent() {
//		freemarker.template.Configuration cfg = new freemarker.template.Configuration(freemarker.template.Configuration.VERSION_2_3_23);
//
//		String templateDir = ConfigFactory.load().getString("mail.template.dir");
//		if("".equals(templateDir) || templateDir.length() == 0) {
//			Logger.info("テンプレートのディレクトリが取得できませんでした。");
//			return null;
//		}
//
//		cfg.setTemplateLoader(new ClassTemplateLoader(this.getClass(), templateDir));
//		cfg.setDefaultEncoding("UTF-8");
//
//		Writer out = new StringWriter();
//		try {
//			String startDate = "2017-02-27";
//			String endDate = "2017-03-05";
//
//			List<DownloadReport> dlArray = new ArrayList<DownloadReport>();
//
//			List<SqlRow> rows = DownloadHistory.getDownloadReport(1L, startDate, endDate);
////			for(SqlRow row: rows) {
////				DownloadReport dr = new DownloadReport();
////
////				dr.setDownloadInfo(row);
////
////				dlArray.add(dr);
////			}
//
//			DownloadReport dr = null;
//			for(int i = 0; i < rows.size(); i++) {
//				if(i == 0) {
//					dr = new DownloadReport();
//
//					dr.setProjectName(rows.get(i).getString("nick_name"));
//					dr.setDownloadDetail(rows.get(i));
//				} else if(i != 0 && rows.get(i-1).getString("nick_name").equals(rows.get(i).getString("nick_name"))) {
//					dr.setDownloadDetail(rows.get(i));
//				} else if(i != 0 && (rows.get(i-1).getString("nick_name").equals(rows.get(i).getString("nick_name"))) == false) {
//					dlArray.add(dr);
//
//					dr = new DownloadReport();
//
//					dr.setProjectName(rows.get(i).getString("nick_name"));
//					dr.setDownloadDetail(rows.get(i));
//				}
//			}
//			if(dr != null) {
//				dlArray.add(dr);
//			}
//
//			Template temp = cfg.getTemplate("download_report.ftl");
//
//			if(dlArray.size() > 0) {
//				Map<String, Object> context = new HashMap<String, Object>();
//
//				// プロジェクト責任者名
//				User user = User.findById(1L);
//				String manager = (user.familyName + " " + user.firstName).trim();
//
//				context.put("user_name", manager);
//				context.put("start_date", startDate);
//				context.put("end_date", endDate);
//
//				context.put("downloads", dlArray);
//
//				temp.process(context, out);
//			}
//		} catch (TemplateNotFoundException e) {
//			e.printStackTrace();
//		} catch (MalformedTemplateNameException e) {
//			e.printStackTrace();
//		} catch (ParseException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		} catch (TemplateException e) {
//			e.printStackTrace();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return ok(mailcontent.render(out.toString()));
		return ok(mailcontent.render("メールテスト"));
	}

	public Result postMailContent() throws Exception {
		String summaryDate = "2017-03-11";

		if("".equals(summaryDate) || summaryDate.length() == 0) {
			return ok(mailcontent.render("集計を指定してください。　やりなおし！！"));
		}
		MailScheduler.start(summaryDate);

		return ok(mailcontent.render("メール送信完了"));
	}
}
