package controllers;

import java.util.concurrent.CompletionStage;

import play.mvc.Http;
import play.mvc.Result;

public class ActionReminder extends play.mvc.Action.Simple {
    public CompletionStage<Result> call(Http.Context ctx) {
	ctx.session().put("urlToGo", ctx.request().uri());
	ctx.session().put("refererPath", ctx.request().path());
	return delegate.call(ctx);
    }
}
