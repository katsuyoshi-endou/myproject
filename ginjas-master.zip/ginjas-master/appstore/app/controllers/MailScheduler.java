package controllers;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.PoisonPill;
import akka.actor.Props;
import akka.actor.UntypedActor;
import akka.dispatch.MessageDispatcher;
import akka.routing.ActorRefRoutee;
import akka.routing.RoundRobinPool;
import akka.routing.RoundRobinRoutingLogic;
import akka.routing.Routee;
import akka.routing.Router;

import com.avaje.ebean.SqlRow;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import freemarker.cache.ClassTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;
import models.DownloadHistory;
import models.DownloadReport;
import models.JobManager;
import models.JobManager.ExecType;
import models.Project;
import models.User;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import play.Logger;
import play.libs.Akka;

import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;

class VulnMailCreator extends UntypedActor {
    @Override
    public void onReceive(Object message) throws Exception {
        Config cfg = ConfigFactory.load();

        String fromAddress = "";
        String toAddress = "";
        String template = "";
        String mailSubject = "";
        //template = REQUEST_TEMPLATE_FILE_NAME;
        //mailSubject = REQUEST_MAIL_SUBJECT;
        mailSubject = "test mail";
        toAddress = "nakatsu@scsk.jp";
        fromAddress = cfg.getString("admin.mail.address");

        SimpleEmail mail = new SimpleEmail();
        mail.setCharset("UTF-8");
        mail.setSSLOnConnect(cfg.getBoolean("play.mailer.ssl"));
        mail.setHostName(cfg.getString("play.mailer.host"));
        mail.setSmtpPort(cfg.getInt("play.mailer.port"));
        mail.setAuthentication(cfg.getString("play.mailer.user"), cfg.getString("play.mailer.password"));
        mail.setFrom(fromAddress);

        // メールタイトル設定
        mail.setSubject(mailSubject);

        //String mailContent = setMailContent(template);
        String mailContent = "Test Content [vuln]";
        if(mailContent == null) {
            return;
        }
        mail.setMsg(mailContent);

        mail.addTo(toAddress);
//        getSender().tell("vuln", getSelf());
        System.out.println("v");
        getSender().tell(mail, getSelf());
    }
}

class ReportMailCreator extends UntypedActor {
    private Long managerId;
    private String summaryDate;

    ReportMailCreator(Long id, String date) {
        managerId = id;
        summaryDate = date;
    }

    public static Props props(Long id, String date) {
        return Props.create(ReportMailCreator.class, id, date);
    }

    @Override
    public void onReceive(Object message) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        Config cfg = ConfigFactory.load();

//          // バッチでもこの設定はみるか？
//          String sendMail = (cfg.getString("mail.send")).toUpperCase();
//          if("NO".equals(sendMail)) {
//              // メールを送信しない設定なら以降の処理は何もしない
//              return;
//          }

        // 集計日を設定する（パラメータで指定された日付の前日までの1週間）
        String startDate;
        String endDate;
        try {
            if("".equals(summaryDate) || summaryDate.length() == 0) {
                summaryDate = sdf.format(new Date());
            }

            // 集計の基準日を設定する
            Date date = sdf.parse(summaryDate);
            Calendar cal = Calendar.getInstance();

            cal.setTime(date);

            // データ取得開始日
            cal.add(Calendar.DATE, -7);
            startDate = sdf.format(cal.getTime());

            // データ取得終了日
            cal.add(Calendar.DATE, 6);
            endDate = sdf.format(cal.getTime());
        } catch(ParseException e) {
            Logger.info("集計日の設定エラーです。 ユーザーID >> " + managerId + ", 集計日 >> " + summaryDate);
            return;
        }
        String fromAddress = "";
        String toAddress = "";

        // あて先はプロジェクト責任者、送信元はGinjas管理者
        toAddress = User.findById(managerId).email;
        if(toAddress == null || "".equals(toAddress) || toAddress.length() == 0) {
            Logger.info("送信先メールアドレスがありません。 ユーザーID >> " + managerId + ", 集計日 >> " + summaryDate);
            return;
        }

        // 送信元アドレス確認
        fromAddress = cfg.getString("admin.mail.address");
        if(fromAddress == null || "".equals(fromAddress) || fromAddress.length() == 0) {
            Logger.info("送信元メールアドレスがありません。 ユーザーID >> " + managerId + ", 集計日 >> " + summaryDate);
            return;
        }

        try {
            SimpleEmail mail = new SimpleEmail();
            mail.setCharset("UTF-8");
            mail.setSSLOnConnect(cfg.getBoolean("play.mailer.ssl"));
            mail.setHostName(cfg.getString("play.mailer.host"));
            mail.setSmtpPort(cfg.getInt("play.mailer.port"));
            mail.setAuthentication(cfg.getString("play.mailer.user"), cfg.getString("play.mailer.password"));
            mail.setFrom(fromAddress);

            // メールタイトル設定
            mail.setSubject(String.format("【Ginjas】ダウンロード通知メール(%s ～)", startDate));

            String mailContent = getDownloadReportContent("download_report.ftl", startDate, endDate);
            if(mailContent == null) {
                return;
            }
            mail.setMsg(mailContent);
            mail.addTo(toAddress);

            getSender().tell(mail, getSelf());
        } catch(EmailException e) {
            Logger.info("メールの設定に失敗しました。 ユーザーID >> " + managerId + ", 集計日 >> " + summaryDate);
            return;
        }
    }

    private String getDownloadReportContent(String template, String startDate, String endDate) {
        Configuration cfg = new Configuration(Configuration.VERSION_2_3_23);

        String templateDir = ConfigFactory.load().getString("mail.template.dir");
        if("".equals(templateDir) || templateDir.length() == 0) {
            Logger.info("テンプレートのディレクトリが取得できませんでした。 ユーザーID >> " + managerId + ", 集計日 >> " + summaryDate);
            return null;
        }

        cfg.setTemplateLoader(new ClassTemplateLoader(this.getClass(), templateDir));
        cfg.setDefaultEncoding("UTF-8");

        List<DownloadReport> dlArray = new ArrayList<DownloadReport>();

        List<SqlRow> rows = new ArrayList<SqlRow>();
        try {
            rows = DownloadHistory.getDownloadReport(managerId, startDate, endDate);
        } catch(Exception e) {
            Logger.info("データの取得処理でエラーが発生しました。 ユーザーID >> " + managerId + ", 集計日 >> " + summaryDate);
            return null;
        }

        DownloadReport dr = null;
        for(int i = 0; i < rows.size(); i++) {
            if(i == 0) {
                dr = new DownloadReport();

                dr.setProjectName(rows.get(i).getString("nick_name"));
                dr.setDownloadDetail(rows.get(i));
            } else if(i != 0 && rows.get(i-1).getString("nick_name").equals(rows.get(i).getString("nick_name"))) {
                dr.setDownloadDetail(rows.get(i));
            } else if(i != 0 && (rows.get(i-1).getString("nick_name").equals(rows.get(i).getString("nick_name"))) == false) {
                dlArray.add(dr);

                dr = new DownloadReport();

                dr.setProjectName(rows.get(i).getString("nick_name"));
                dr.setDownloadDetail(rows.get(i));
            }
        }
        if(dr != null) {
            dlArray.add(dr);
        }

        try {
            Writer out = new StringWriter();
            Template temp = cfg.getTemplate(template);

            Map<String, Object> context = new HashMap<String, Object>();

            // プロジェクト責任者名
            User user = User.findById(managerId);
            String manager = (user.familyName + " " + user.firstName).trim();

            context.put("user_name", manager);
            context.put("start_date", startDate);
            context.put("end_date", endDate);

            context.put("downloads", dlArray);

            temp.process(context, out);

            return out.toString();
        } catch (TemplateNotFoundException e) {
            Logger.info("テンプレートファイルが見つかりません。 ユーザーID >> " + managerId + ", 集計日 >> " + summaryDate);
            Logger.info("エラー内容 : " + e.getMessage());
            return null;
        } catch (IOException e) {
            Logger.info("メール本文作成に失敗しました。 ユーザーID >> " + managerId + ", 集計日 >> " + summaryDate);
            Logger.info("エラー内容 : " + e.getMessage());
            return null;
        } catch (TemplateException e) {
            Logger.info("メールのテンプレート作成処理で失敗しました。 ユーザーID >> " + managerId + ", 集計日 >> " + summaryDate);
            Logger.info("エラー内容 : " + e.getMessage());
            return null;
        }
    }
}

class MailSender extends UntypedActor {
    private Long managerId;
    private String summaryDate;

    MailSender(Long id, String date) {
        managerId = id;
        summaryDate = date;
    }

    public static Props props(Long id, String date) {
        return Props.create(MailSender.class, id, date);
    }

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof MessageCarrier) {
            if (((MessageCarrier)message).type.equals("v")) {
                ActorRef creator = getContext().actorOf(Props.create(VulnMailCreator.class)
                                                             .withDispatcher("mail-sender-dispatcher")
                                                       );
                creator.tell(message, getSelf());
            } else {
                ActorRef creator = getContext().actorOf(ReportMailCreator.props(managerId, summaryDate).withDispatcher("mail-sender-dispatcher"));

                creator.tell(message, getSelf());
            }

        } else if (message instanceof SimpleEmail) {
            try {
//                ((SimpleEmail)message).send();

                // メールの送信までできたものだけログに格納する
                JobManager.saveExecuteLog(ExecType.DOWNLOAD_REPORT_MAIL, summaryDate, managerId);
//            } catch(EmailException e) {
            } catch(Exception e) {
                Logger.info("メールの送信に失敗しました。 ユーザーID >> " + managerId + ", 集計日 >> " + summaryDate);
            } finally {
                getSender().tell(PoisonPill.getInstance(), getSelf());
            }
        } else {
            getSender().tell(PoisonPill.getInstance(), getSelf());
        }
    }
}

class MessageCarrier {
    public static String type;
}

public class MailScheduler {
    private static final int NR_OF_INSTANCE = 8;

    public static void start(String summaryDate) {
        final MessageCarrier mc = new MessageCarrier();
        mc.type = "repo";

        List<SqlRow> managers = JobManager.getDownloadReportTarget(summaryDate);
        for(SqlRow manager: managers) {
            final ActorRef mailSender = Akka.system().actorOf(new RoundRobinPool(NR_OF_INSTANCE)
                                        .props(MailSender.props(manager.getLong("user_id"), summaryDate)
                                        .withDispatcher("mail-sender-dispatcher")));

            mailSender.tell(mc, ActorRef.noSender());
        }
//        // 送信対象者がいれば、成功数を報告する？
//        if(managers.size() > 0) {
//           	List<JobManager> success = JobManager.find.where().eq("exec_param1", summaryDate).findList();
//
//           	String contents = String.format("%s/%s 送信しました", success.size(), managers.size());
//           	Logger.info(contents);
//        }
    }
}
