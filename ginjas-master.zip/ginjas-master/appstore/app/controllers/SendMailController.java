package controllers;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import freemarker.cache.ClassTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import models.MaintenanceRequest;
import models.MaintenanceRequest.Progress;
import play.Logger;

/**
 * メール送信クラス<br/>
 * 　メール本文の作成、メールの送信をスレッドで行っています。
 *
 * @author scsk-endo
 *
 */
public class SendMailController extends Thread {
	/**
	 * リクエストの情報
	 */
	private MaintenanceRequest request;

	/**
	 * メールタイトル
	 */
	private static final String REQUEST_MAIL_SUBJECT = "[申請管理No%s] 【Ginjas Admin】 OSS新規登録 申請通知";
	private static final String CANCEL_MAIL_SUBJECT = "[申請管理No%s] 【Ginjas Admin】 OSS新規登録 取消通知";
	private static final String ACCEPTED_MAIL_SUBJECT = "[申請管理%s] 【Ginjas】 OSS登録申請結果通知：登録OK";
	private static final String REJECTED_MAIL_SUBJECT = "[申請管理%s] 【Ginjas】 OSS登録申請結果通知：登録NG";

	/**
	 * テンプレートのファイル
	 */
	private static final String REQUEST_TEMPLATE_FILE_NAME = "request_mail.ftl";
	private static final String CANCEL_TEMPLATE_FILE_NAME = "cancel_mail.ftl";
	private static final String ACCEPTED_TEMPLATE_FILE_NAME = "approve_mail.ftl";
	private static final String REJECTED_TEMPLATE_FILE_NAME = "reject_mail.ftl";

	/**
	 * スレッドのクラスを生成し、生成したインスタンスを返す
	 *
	 * @return
	 */
	public static SendMailController getInstance() {
		return new SendMailController();
	}

	public void run() {
		// メール送信
		sendMail();
	}

	/**
	 * メール送信処理
	 */
	private void sendMail() {
		// メールを送信する
		Config cfg = ConfigFactory.load();

		try {
			String sendMail = (cfg.getString("mail.send")).toUpperCase();
			if("NO".equals(sendMail)) {
				// メールを送信しない設定なら以降の処理は何もしない
				Logger.info("【メール未送信】メールを送信しない設定のため、処理をスキップしました。申請ID : " + request.id);
				return;
			}

			String fromAddress = "";
			String toAddress = "";
			String template = "";
			String mailSubject = "";
			if(request.status == Progress.OPEN) {
				// 申請(ユーザーから管理者)
				template = REQUEST_TEMPLATE_FILE_NAME;
				mailSubject = REQUEST_MAIL_SUBJECT;
				toAddress = cfg.getString("admin.mail.address");
				fromAddress = request.user.email;
			} else if(request.status == Progress.ACCEPTED) {
				// 承認(管理者からユーザー)
				template = ACCEPTED_TEMPLATE_FILE_NAME;
				mailSubject = ACCEPTED_MAIL_SUBJECT;
				toAddress = request.user.email;
				fromAddress = cfg.getString("admin.mail.address");
			} else if(request.status == Progress.REJECTED) {
				// 却下(管理者からユーザー)
				template = REJECTED_TEMPLATE_FILE_NAME;
				mailSubject = REJECTED_MAIL_SUBJECT;
				toAddress = request.user.email;
				fromAddress = cfg.getString("admin.mail.address");
			} else if(request.status == Progress.CANCELED) {
				// 取消(ユーザーから管理者)
				template = CANCEL_TEMPLATE_FILE_NAME;
				mailSubject = CANCEL_MAIL_SUBJECT;
				toAddress = cfg.getString("admin.mail.address");
				fromAddress = request.user.email;
			} else {
				Logger.info("メールの種別がわかりません。");
				Logger.info("申請ID : " + request.id + ", ユーザーID : " + request.user.username);
				return;
			}

			if(toAddress == null || "".equals(toAddress) || toAddress.length() == 0) {
				Logger.info("送信先メールアドレスがありません。");
				Logger.info("申請ID : " + request.id + ", ユーザーID : " + request.user.username);
				return;
			}

			// 送信元アドレス確認
			if(fromAddress == null || "".equals(fromAddress) || fromAddress.length() == 0) {
				Logger.info("送信元メールアドレスがありません。");
				Logger.info("申請ID : " + request.id + ", ユーザーID : " + request.user.username);
				return;
			}

			SimpleEmail mail = new SimpleEmail();
			mail.setCharset("UTF-8");
			mail.setSSLOnConnect(cfg.getBoolean("play.mailer.ssl"));
			mail.setHostName(cfg.getString("play.mailer.host"));
			mail.setSmtpPort(cfg.getInt("play.mailer.port"));
			mail.setAuthentication(cfg.getString("play.mailer.user"), cfg.getString("play.mailer.password"));
			mail.setFrom(fromAddress);

			// メールタイトル設定
			mail.setSubject(String.format(mailSubject, String.valueOf(request.id)));

			String mailContent = setMailContent(template);
			if(mailContent == null) {
				return;
			}
			mail.setMsg(mailContent);

			mail.addTo(toAddress);
			mail.send();

			Logger.info("メールを送信しました。　申請ID : " + request.id + ", 種別 : " + request.status.getName());
		} catch(EmailException e) {
			Logger.info("メールの送信に失敗しました。 エラーの内容 : " + e.getMessage());
			Logger.info("申請ID : " + request.id);
		} catch(Exception e) {
			Logger.info("メールの送信に失敗しました。 エラーの内容 : " + e.getMessage());
			Logger.info("申請ID : " + request.id);
		}
	}

	private String setMailContent(String template) {
		try {
			Configuration cfg = new Configuration(Configuration.VERSION_2_3_23);

//			String templateDir = Play.current().path().getPath() + ConfigFactory.load().getString("mail.template.dir");
			String templateDir = ConfigFactory.load().getString("mail.template.dir");
			if("".equals(templateDir) || templateDir.length() == 0) {
				Logger.info("テンプレートのディレクトリが取得できませんでした。");
				Logger.info("申請ID : " + request.id);
				return null;
			}

			cfg.setTemplateLoader(new ClassTemplateLoader(this.getClass(), templateDir));
//			cfg.setDirectoryForTemplateLoading(new File(templateDir));
			cfg.setDefaultEncoding("UTF-8");

			Writer out = new StringWriter();
			Template temp = cfg.getTemplate(template);

			Map<String, String> context = new HashMap<String,String>();

			context.put("user_id", request.user.username);
			context.put("user_name", request.user.familyName + " " + request.user.firstName);
			context.put("project_name", request.project.nickName);
			context.put("oss_name", request.productName);
			context.put("oss_version", request.version);
			context.put("prefered_date", new SimpleDateFormat("yyyy-MM-dd").format(request.preferedDate));
			context.put("comment", request.comments == null ? "" : request.comments);
			context.put("adm_comment", request.admComments == null ? "" : request.admComments);

			temp.process(context, out);

			return out.toString();
		} catch(IOException e) {
			Logger.info("メール本文作成に失敗しました。 エラー内容 : " + e.getMessage());
			Logger.info("申請ID : " + request.id);

			return null;
		} catch (TemplateException e) {
			Logger.info("メールのテンプレート作成処理で失敗しました。 エラー内容 : " + e.getMessage());
			Logger.info("申請ID : " + request.id);

			return null;
		}
	}

	public void setMailRequest(MaintenanceRequest req) {
		this.request = req;
	}
}
