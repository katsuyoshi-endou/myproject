package controllers;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Inject;

import com.avaje.ebean.SqlRow;

import models.ActivityRecord;
import models.Dept;
import models.User;
import play.Logger;
import play.data.Form;
import play.data.FormFactory;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import views.html.index;
import views.html.login;
import views.html.signup;

public class Application extends Controller {
    	@Inject FormFactory formFactory;

    	/**
	 * 参加プロジェクトなし
	 */
	public static final String NON_JOIN_PROJECT = "0";

	/**
	 * 参加プロジェクトあり
	 */
	public static final String JOIN_PROJECT = "1";

	/**
	 * 一般ユーザー
	 */
	public static final String COMMON_USER = "0";

	/**
	 * 管理者ユーザー
	 */
	public static final String ADMIN_USER = "1";

	public Result index() {
        return ok(index.render("Your new application is ready."));
    }

    public Result login() {
	return ok(login.render(formFactory.form(User.class)));
    }

    public Result authenticate() {
	Form<User> loginForm = formFactory.form(User.class).bindFromRequest();

	if (loginForm.hasErrors()) {
	    Logger.error("[Bad Request in authenticate() method]");
	    session().clear();
	    return badRequest(login.render(loginForm));
	} else {
	    // ログイン時にセッション情報をクリアしておく
	    String urlToGo = session().get("urlToGo");
	    session().clear();
	    if (urlToGo != null) {
		session("urlToGo", urlToGo);
	    }
	    session("username", loginForm.get().username);
	    User u = User.find.where().eq("username", loginForm.get().username).findUnique();
	    session("realname", u.familyName + " " + u.firstName);
	    session("userId", u.id.toString());

	    // OSS承認登録（管理者権限）メニューの表示可否を制御するための管理者フラグをセッションにセットする
	    session("isAdmin", u.isAdmin ? ADMIN_USER : COMMON_USER);

	    // 参加プロジェクトを設定していないユーザはOSS新規リクエストができないようにセッションにフラグをセットする
	    session("isJoinProject", u.projects.size() == 0 ? NON_JOIN_PROJECT : JOIN_PROJECT);

	    ActivityRecord.saveActivity("", u, ActivityRecord.ActivityType.LOGIN);
	    return pageToGo();
	}
    }

    public Result logout() {
	ActivityRecord.saveActivity("", User.find.byId(new Long(ctx().session().get("userId"))), ActivityRecord.ActivityType.LOGOUT);
	session().clear();
	return pageToGo().withCookies(new Http.Cookie("PLAY_SESSION", "", -1, "/", "", false, true));
    }

    /* signup() and addUser() are just tentative utilities for demo purpose */
    public Result signup() {
	return ok(signup.render(""));
    }

    /* signup() and addUser() are just tentative utilities for demo purpose */
    public Result addUser() {
	boolean dup = false;
	Map<String, String[]> form = request().body().asFormUrlEncoded();
	User newUser = new User();
	String username1 = "";
	for (String k: form.keySet()) {
	    String v = form.get(k)[0];
	    if (null == v || "".equals(v)) {
	    } else {
		switch(k) {
		case "username0":
		    dup = (null != User.find.where().eq("username", v).findUnique());
		    newUser.username = v;
		    break;
		case "username1":
		    username1 = v;
		    break;
		case "password":
		    newUser.password = v;
		    break;
		case "surname":
		    newUser.familyName = v;
		    break;
		case "firstname":
		    newUser.firstName = v;
		    break;
		case "nickname":
		    newUser.nickname = v;
		    break;
		default:
		    break;
		}
	    }
	}
	if (!newUser.username.equals(username1)) {
	    return ok(signup.render("メールアドレスの入力をチェックしてください"));
	}
	if (dup) {
	    return ok(signup.render("メールアドレス["+newUser.username+"]は登録済です"));
	}
	newUser.save();
	return pageToGo();
    }

    public static Result pageToGo() {
	String urlToGo = session().get("urlToGo");
	if (urlToGo == null || "".equals(urlToGo)) {
	    // This is supposed to be the *homepage* of the application...
	    urlToGo = routes.StoreController.listProducts(0, 24, "", "").url();
	}
	return redirect(urlToGo);
    }

    public void pageToGo(String url) {
	session("urlToGo", url);
    }

    public Result getDeptTree() {
//    	List<Dept> depts = Dept.find.where().eq("parent_id", 1).findList().stream()
//    			.filter(d -> !d.childs.isEmpty() && !"賃貸家賃".equals(d.name)).collect(Collectors.toList());

		if(isAdminUser()) {
			List<Dept> depts = Dept.find.where().eq("parent_id", 1).findList().stream()
			.filter(d -> !d.childs.isEmpty() && !"賃貸家賃".equals(d.name)).collect(Collectors.toList());

			return ok(Json.toJson(depts));
		}

		Long uid = new Long(ctx().session().get("userId"));

		List<SqlRow> sections = Dept.getSelectableSection(uid);

		List<Dept> dept = Dept.find.where().eq("parent_id", 1).findList();

		// 表示する部門の親IDをCollection型に格納
		Set<Long> ids = new HashSet<Long>();
		Set<Long> parents = new HashSet<Long>();
		for(SqlRow sec : sections) {
			parents.add(sec.getLong("parent_id"));
			if((long)sec.getLong("id") == (long)1) {
				for(Dept d : dept) {
					ids.add(d.id);
				}

				// 「全社」所属の場合、すべてを見せるためそれまでのデータを消去、部門コード「1」だけセット
				parents.clear();
				parents.add((long)1);
				break;
			}
			ids.add(sec.getLong("id"));
		}

		List<Dept> depts = Dept.find.where()
    			.conjunction()
    				.in("parent_id", parents)
    				.in("id", ids)
    			.endJunction()
    			.findList().stream()
    			.filter(d -> !d.childs.isEmpty() && !"賃貸家賃".equals(d.name)).collect(Collectors.toList());
    	return ok(Json.toJson(depts));
    }

    /**
     * セッションに指定した値を保持します。
     *
     * @param key 登録キー
     * @param value 登録値
     */
    public static void setSessionValue(String key, String value) {
    	session(key, value);
    }

    /**
     * ログインユーザーが管理者ユーザーかどうか？<br/>
     * 　管理者ユーザーの場合、trueを返す<br/>
     * 　一般ユーザーの場合、falseを返す
     *
     * @return
     */
    public static boolean isAdminUser() {
    	String admin = ctx().session().get("isAdmin");
    	if(admin == null) {
			String uid = ctx().session().get("userId");

			if(uid != null) {
				User user = User.findById(Long.valueOf(uid));
				return user.isAdmin;
			} else {
				return false;
			}
		} else {
			return ADMIN_USER.equals(admin);
		}
    }
}