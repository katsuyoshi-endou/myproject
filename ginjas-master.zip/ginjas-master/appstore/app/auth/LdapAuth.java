package auth;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import play.Configuration;
import play.api.Play;

;

public class LdapAuth {
	//@Injectだと上手く行かないため、明示的にInjectする。
	private static Configuration config = Play.current().injector().instanceOf(Configuration .class);

	public static final String LDAP_PROVIDER = config.getString(
			"auth.ldapauth.provider", "ldap://localhost:389");
	public static final String LDAP_BASE = config.getString(
			"auth.ldapauth.base", "dc=example,dc=com");
	public static final String SECURITY_PRINCIPAL_PATTERN = config.getString(
			"auth.ldapauth.security.principal",
			"cn=%s,ou=People,dc=example,dc=com");
	public static final String ATTR_USERNAME = config.getString(
			"auth.ldapauth.attr.username", "cn");
	public static final String ATTR_FIRST_NAME = config.getString(
			"auth.ldapauth.attr.first.name", "givenName");
	public static final String ATTR_FAMILY_NAME = config.getString(
			"auth.ldapauth.attr.family.name", "sn");

	private static Properties defaults = new Properties();
	static {
		System.setProperty("com.sun.jndi.ldap.connect.pool.debug", "fine");
		defaults.put(Context.INITIAL_CONTEXT_FACTORY,
				"com.sun.jndi.ldap.LdapCtxFactory");
		defaults.put(Context.PROVIDER_URL, LDAP_PROVIDER);
		defaults.put(Context.REFERRAL, "ignore");
		defaults.put("com.sun.jndi.ldap.connect.pool", "true");

	}

	// TODO: LDAPエラー処理
	public static Map<String, String> authenticate(String username,
			String password) {
		Properties env = new Properties();
		env.putAll(defaults);
		env.put(Context.SECURITY_PRINCIPAL,
				String.format(SECURITY_PRINCIPAL_PATTERN, username));
		env.put(Context.SECURITY_CREDENTIALS, password);

		try {
			InitialDirContext context = new InitialDirContext(env);

			SearchControls searchCtls = new SearchControls();

			searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);

			String searchFilter = String.format(
					"(&(objectClass=person)(%s=%s))", ATTR_USERNAME, username);

			String returnedAtts[] = { ATTR_FIRST_NAME, ATTR_FAMILY_NAME };
			searchCtls.setReturningAttributes(returnedAtts);

			NamingEnumeration<SearchResult> answer = context.search(LDAP_BASE,
					searchFilter, searchCtls);
			SearchResult searchResult = answer.next();
			Attributes attributes = searchResult.getAttributes();
			Map<String, String> result = new HashMap<String, String>();
			for (String returnedAttr : returnedAtts) {
				Attribute attribute = attributes.get(returnedAttr);

				if (attribute != null) {
					result.put(returnedAttr, (String) attributes.get(returnedAttr).get(0));
				}
			}

			answer.close();
			context.close();

			return result;
		} catch (AuthenticationException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		}
		return null;
	}
}
