/**
 Here's a dozen of application specific kludges.
*/

/**
 flipPackageTypeSelection
 - invoked as an onChange handler for _select_ element (`me'),
 picking a node under `srcId' element whose id matched the changed value,
 with which to  replace the `destId' subsediary.
*/
function flipPackageTypeSelection(me, destId, srcId) {
    var newSelection = me.options[me.selectedIndex].value;
    var placeholder = document.getElementById(destId);
    while (placeholder.firstChild) { placeholder.removeChild(placeholder.firstChild); }
    var candidates = document.getElementById(srcId).childNodes;
    for (var i = 0; i < candidates.length; i++) {
	if (candidates[i].id == newSelection) {
	    for (var j= 0; j <  candidates[i].children.length; j++) {
		placeholder.appendChild(candidates[i].children[j].cloneNode(true));
	    }
	    break;
	}
    }
}

function tweakInput(me) {
    var currentSelection = me.options[me.selectedIndex]  .value;
    var textBox= document.getElementById("optText");
    textBox.style.display = (currentSelection == "other")? "inline" : "none";
}

function showLoader() {
    if ($("#loaderContainer").size() == 0) {
        $("body").append('<div id="loaderContainer"></div>');
    }
}

function hideLoader() {
    $("#loaderContainer").remove();
}

var currentDialog = null;
/* this toplevel thunk sets click handler for .modal links so they invoke the link in jQuery UI dialog.

 TODO: improve the way how attribute values are passed to the dialog on click, instead of using ad-hoc markup.
 */
$(function() {
	// TODO: EasyUI対応で.not('disabled')を加えたが見た目が無効になっていない。きちんとしたEasyUI対応をすべき
    $('.modal').not('.disabled').click(
	function() {
	    var me = $(this);
	    // jQuery Easy UI版
	    var w = (me.attr('w') ? me.attr('w') : 720),
        h = (me.attr('h') ? me.attr('h') : 640),
        title = "Dialog";
	    if (me.text() != null) title = me.text();
	    if (me.attr('caption') != null) title = me.attr('caption');
	    scope = this;
	    var l = $(window).scrollLeft() + ($(window).width() - w)/2;
        var t = $(window).scrollTop() + ($(window).height() - h)/2;
        if (t < 0) { t = 0; }
	    currentDialog = $('#dlg').dialog({ title: title, href: me.attr('href'), modal: true, left: l, top: t, width: w, height: h, closeText:"閉じる",close: function(){scope.onClose()}, onLoadError: function(XMLHttpRequest, textStatus, errorThrown){$('#dlg').html(XMLHttpRequest.responseText);}});
	    //$('input, textarea').placeholder(); // IE用
	    this.onClose=function(){
	    	currentDialog.dialog("destroy");
	    	//currentDialog.dialog("widget").remove();
	    }
	    /* jQuery UI版
	    $.get(me.attr('href')).done(
		function(data) {
		    var w = (me.attr('w') ? me.attr('w') : 720),
	                               h = (me.attr('h') ? me.attr('h') : 640),
	                               title = "Dialog";
		    if (me.text() != null) title = me.text();
		    if (me.attr('caption') != null) title = me.attr('caption');
		    scope = this;
		    currentDialog = $(data).dialog({ modal: true, autoOpen: true, width: w, height: h, title: title, closeText:"閉じる",close: function(){scope.onClose()} });
			$('input, textarea').placeholder(); // IE用
		    this.onClose=function(){
		    	currentDialog.dialog("destroy");
//		    	currentDialog.dialog("widget").remove();
		    }
		}
	    );
	    */
	}
    );
});;
