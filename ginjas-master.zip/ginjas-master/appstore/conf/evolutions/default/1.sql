# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table activity_record (
  id                            bigint not null,
  user_id                       bigint,
  product_id                    bigint,
  objective                     varchar(255),
  date                          timestamp,
  activity_type                 integer,
  constraint ck_activity_record_activity_type check (activity_type in (0,1,2,3,4,5,6,7,8,9,10,11)),
  constraint pk_activity_record primary key (id)
);
create sequence activity_record_seq;

create table cpe_info (
  id                            bigint not null,
  product_id                    bigint,
  vender                        varchar(255),
  product                       varchar(255),
  constraint pk_cpe_info primary key (id)
);
create sequence cpe_info_id_seq;

create table dept (
  id                            bigint not null,
  name                          varchar(255),
  full_name                     varchar(255),
  parent_id                     bigint,
  constraint pk_dept primary key (id)
);
create sequence dept_id_seq;

create table download_history (
  seq                           bigint not null,
  product_id                    bigint,
  release_seq                   bigint,
  medium_seq                    bigint,
  user_id                       bigint,
  project_id                    bigint,
  purpose                       integer,
  text                          varchar(255),
  download_date                 timestamp,
  last_update                   timestamp,
  constraint ck_download_history_purpose check (purpose in (0,1,2,3)),
  constraint pk_download_history primary key (seq)
);
create sequence download_history_seq;

create table license (
  id                            bigint not null,
  fullname                      varchar(255),
  nickname                      varchar(255),
  url                           varchar(255),
  overview                      varchar(255),
  fulltext                      varchar(255),
  is_osiapproved                boolean,
  constraint pk_license primary key (id)
);
create sequence license_seq;

create table license_term (
  id                            bigint not null,
  license_id                    bigint,
  category                      varchar(255),
  summary                       varchar(255),
  annotation                    varchar(255),
  constraint pk_license_term primary key (id)
);
create sequence license_term_seq;

create table maintenance_request (
  id                            bigint not null,
  user_id                       bigint,
  product_name                  varchar(255),
  version                       varchar(255),
  prefered_date                 timestamp,
  req_type                      integer,
  issue_date                    timestamp,
  status                        integer,
  last_update_date              timestamp,
  comments                      varchar(255),
  approve_date                  timestamp,
  adm_comments                  varchar(255),
  project_id                    bigint,
  constraint ck_maintenance_request_req_type check (req_type in (0,1,2,3,4)),
  constraint ck_maintenance_request_status check (status in (0,1,2,3,4,5,6)),
  constraint pk_maintenance_request primary key (id)
);
create sequence maintenance_request_seq;

create table medium (
  seq                           bigint not null,
  package_type                  varchar(255),
  url                           varchar(255),
  platform                      varchar(255),
  checksum                      bigint,
  release_id                    bigint,
  constraint pk_medium primary key (seq)
);
create sequence medium_seq;

create table organization (
  id                            bigint not null,
  fullname                      varchar(255),
  url                           varchar(255),
  org_type                      integer,
  constraint ck_organization_org_type check (org_type in (0,1,2,3,4,5,6)),
  constraint pk_organization primary key (id)
);
create sequence organization_seq;

create table product (
  id                            bigint not null,
  name                          varchar(255),
  description                   varchar(255),
  project_url                   varchar(255),
  logo                          varchar(255),
  repository                    varchar(255),
  last_update                   timestamp,
  developed_by_id               bigint,
  is_available_for_store        boolean,
  constraint pk_product primary key (id)
);
create sequence product_seq;

create table product_tag (
  product_id                    bigint not null,
  tag_symbol                    varchar(255) not null,
  constraint pk_product_tag primary key (product_id,tag_symbol)
);

create table product_license (
  product_id                    bigint not null,
  license_id                    bigint not null,
  constraint pk_product_license primary key (product_id,license_id)
);

create table product_relationship (
  subjective                    bigint,
  verb                          integer,
  objective                     bigint,
  constraint ck_product_relationship_verb check (verb in (0,1,2,3))
);

create table product_review (
  product_id                    bigint,
  user_id                       bigint,
  post_date                     timestamp,
  rate                          float,
  usage_code                    varchar(255),
  other_usage                   varchar(255),
  comment                       varchar(255),
  is_anonymous                  boolean
);

create table product_topic (
  id                            bigint not null,
  product_id                    bigint,
  release_id                    bigint,
  post_date                     timestamp,
  topic_type                    integer,
  title                         varchar(255),
  description                   varchar(255),
  url                           varchar(255),
  is_active                     boolean,
  constraint pk_product_topic primary key (id)
);
create sequence product_topic_seq;

create table project (
  id                            bigint not null,
  true_name                     varchar(255),
  nick_name                     varchar(255),
  description                   varchar(255),
  started_on                    timestamp,
  ended_on                      timestamp,
  has_retired                   boolean,
  dept_id                       bigint,
  constraint pk_project primary key (id)
);
create sequence project_seq;

create table release (
  seq                           bigint not null,
  version                       varchar(255),
  description                   varchar(255),
  product_id                    bigint,
  released_date                 timestamp,
  is_stable                     boolean,
  is_active                     boolean,
  is_uptodate                   boolean,
  constraint pk_release primary key (seq)
);
create sequence release_seq;

create table services_provider (
  id                            bigint not null,
  fullname                      varchar(255),
  url                           varchar(255),
  org_type                      integer,
  constraint ck_services_provider_org_type check (org_type in (0,1,2,3,4,5,6)),
  constraint pk_services_provider primary key (id)
);
create sequence services_provider_seq;

create table tag (
  symbol                        varchar(255) not null,
  explanatory_name              varchar(255),
  is_primary                    boolean,
  constraint pk_tag primary key (symbol)
);
create sequence tag_seq;

create table team (
  id                            bigint not null,
  name                          varchar(255),
  parent_id                     bigint,
  is_tagified                   boolean,
  constraint pk_team primary key (id)
);
create sequence team_seq;

create table ginjasuser (
  id                            bigint not null,
  username                      varchar(255),
  password                      varchar(255),
  family_name                   varchar(255),
  first_name                    varchar(255),
  nickname                      varchar(255),
  email                         varchar(255),
  is_admin                      boolean,
  team_id                       bigint,
  current_project_id            bigint,
  constraint pk_ginjasuser primary key (id)
);
create sequence user_seq;

create table project_user (
  user_id                       bigint not null,
  project_id                    bigint not null,
  constraint pk_project_user primary key (user_id,project_id)
);

create table user_dept (
  user_id                       bigint not null,
  dept_id                       bigint not null,
  constraint pk_user_dept primary key (user_id,dept_id)
);

create table user_product (
  seq                           bigint not null,
  user_id                       bigint,
  project_id                    bigint,
  product_id                    bigint,
  release_seq                   bigint,
  started_on                    timestamp,
  ended_on                      timestamp,
  notes                         varchar(255),
  constraint pk_user_product primary key (seq)
);
create sequence user_product_seq;

alter table dept add constraint fk_dept_parent_id foreign key (parent_id) references dept (id) on delete restrict on update restrict;
create index ix_dept_parent_id on dept (parent_id);

alter table download_history add constraint fk_download_history_product_id foreign key (product_id) references product (id) on delete restrict on update restrict;
create index ix_download_history_product_id on download_history (product_id);

alter table download_history add constraint fk_download_history_release_seq foreign key (release_seq) references release (seq) on delete restrict on update restrict;
create index ix_download_history_release_seq on download_history (release_seq);

alter table download_history add constraint fk_download_history_medium_seq foreign key (medium_seq) references medium (seq) on delete restrict on update restrict;
create index ix_download_history_medium_seq on download_history (medium_seq);

alter table download_history add constraint fk_download_history_user_id foreign key (user_id) references ginjasuser (id) on delete restrict on update restrict;
create index ix_download_history_user_id on download_history (user_id);

alter table download_history add constraint fk_download_history_project_id foreign key (project_id) references project (id) on delete restrict on update restrict;
create index ix_download_history_project_id on download_history (project_id);

alter table license_term add constraint fk_license_term_license_id foreign key (license_id) references license (id) on delete restrict on update restrict;
create index ix_license_term_license_id on license_term (license_id);

alter table maintenance_request add constraint fk_maintenance_request_user_id foreign key (user_id) references ginjasuser (id) on delete restrict on update restrict;
create index ix_maintenance_request_user_id on maintenance_request (user_id);

alter table maintenance_request add constraint fk_maintenance_request_project_id foreign key (project_id) references project (id) on delete restrict on update restrict;
create index ix_maintenance_request_project_id on maintenance_request (project_id);

alter table medium add constraint fk_medium_release_id foreign key (release_id) references release (seq) on delete restrict on update restrict;
create index ix_medium_release_id on medium (release_id);

alter table product add constraint fk_product_developed_by_id foreign key (developed_by_id) references organization (id) on delete restrict on update restrict;
create index ix_product_developed_by_id on product (developed_by_id);

alter table product_tag add constraint fk_product_tag_product foreign key (product_id) references product (id) on delete restrict on update restrict;
create index ix_product_tag_product on product_tag (product_id);

alter table product_tag add constraint fk_product_tag_tag foreign key (tag_symbol) references tag (symbol) on delete restrict on update restrict;
create index ix_product_tag_tag on product_tag (tag_symbol);

alter table product_license add constraint fk_product_license_product foreign key (product_id) references product (id) on delete restrict on update restrict;
create index ix_product_license_product on product_license (product_id);

alter table product_license add constraint fk_product_license_license foreign key (license_id) references license (id) on delete restrict on update restrict;
create index ix_product_license_license on product_license (license_id);

alter table product_relationship add constraint fk_product_relationship_subjective foreign key (subjective) references product (id) on delete restrict on update restrict;
create index ix_product_relationship_subjective on product_relationship (subjective);

alter table product_relationship add constraint fk_product_relationship_objective foreign key (objective) references product (id) on delete restrict on update restrict;
create index ix_product_relationship_objective on product_relationship (objective);

alter table product_review add constraint fk_product_review_product_id foreign key (product_id) references product (id) on delete restrict on update restrict;
create index ix_product_review_product_id on product_review (product_id);

alter table product_review add constraint fk_product_review_user_id foreign key (user_id) references ginjasuser (id) on delete restrict on update restrict;
create index ix_product_review_user_id on product_review (user_id);

alter table product_topic add constraint fk_product_topic_product_id foreign key (product_id) references product (id) on delete restrict on update restrict;
create index ix_product_topic_product_id on product_topic (product_id);

alter table project add constraint fk_project_dept_id foreign key (dept_id) references dept (id) on delete restrict on update restrict;
create index ix_project_dept_id on project (dept_id);

alter table release add constraint fk_release_product_id foreign key (product_id) references product (id) on delete restrict on update restrict;
create index ix_release_product_id on release (product_id);

alter table team add constraint fk_team_parent_id foreign key (parent_id) references team (id) on delete restrict on update restrict;
create index ix_team_parent_id on team (parent_id);

alter table ginjasuser add constraint fk_ginjasuser_team_id foreign key (team_id) references team (id) on delete restrict on update restrict;
create index ix_ginjasuser_team_id on ginjasuser (team_id);

alter table project_user add constraint fk_project_user_ginjasuser foreign key (user_id) references ginjasuser (id) on delete restrict on update restrict;
create index ix_project_user_ginjasuser on project_user (user_id);

alter table project_user add constraint fk_project_user_project foreign key (project_id) references project (id) on delete restrict on update restrict;
create index ix_project_user_project on project_user (project_id);

alter table user_dept add constraint fk_user_dept_ginjasuser foreign key (user_id) references ginjasuser (id) on delete restrict on update restrict;
create index ix_user_dept_ginjasuser on user_dept (user_id);

alter table user_dept add constraint fk_user_dept_dept foreign key (dept_id) references dept (id) on delete restrict on update restrict;
create index ix_user_dept_dept on user_dept (dept_id);

alter table user_product add constraint fk_user_product_user_id foreign key (user_id) references ginjasuser (id) on delete restrict on update restrict;
create index ix_user_product_user_id on user_product (user_id);

alter table user_product add constraint fk_user_product_project_id foreign key (project_id) references project (id) on delete restrict on update restrict;
create index ix_user_product_project_id on user_product (project_id);

alter table user_product add constraint fk_user_product_product_id foreign key (product_id) references product (id) on delete restrict on update restrict;
create index ix_user_product_product_id on user_product (product_id);

alter table user_product add constraint fk_user_product_release_seq foreign key (release_seq) references release (seq) on delete restrict on update restrict;
create index ix_user_product_release_seq on user_product (release_seq);


# --- !Downs

alter table if exists dept drop constraint if exists fk_dept_parent_id;
drop index if exists ix_dept_parent_id;

alter table if exists download_history drop constraint if exists fk_download_history_product_id;
drop index if exists ix_download_history_product_id;

alter table if exists download_history drop constraint if exists fk_download_history_release_seq;
drop index if exists ix_download_history_release_seq;

alter table if exists download_history drop constraint if exists fk_download_history_medium_seq;
drop index if exists ix_download_history_medium_seq;

alter table if exists download_history drop constraint if exists fk_download_history_user_id;
drop index if exists ix_download_history_user_id;

alter table if exists download_history drop constraint if exists fk_download_history_project_id;
drop index if exists ix_download_history_project_id;

alter table if exists license_term drop constraint if exists fk_license_term_license_id;
drop index if exists ix_license_term_license_id;

alter table if exists maintenance_request drop constraint if exists fk_maintenance_request_user_id;
drop index if exists ix_maintenance_request_user_id;

alter table if exists maintenance_request drop constraint if exists fk_maintenance_request_project_id;
drop index if exists ix_maintenance_request_project_id;

alter table if exists medium drop constraint if exists fk_medium_release_id;
drop index if exists ix_medium_release_id;

alter table if exists product drop constraint if exists fk_product_developed_by_id;
drop index if exists ix_product_developed_by_id;

alter table if exists product_tag drop constraint if exists fk_product_tag_product;
drop index if exists ix_product_tag_product;

alter table if exists product_tag drop constraint if exists fk_product_tag_tag;
drop index if exists ix_product_tag_tag;

alter table if exists product_license drop constraint if exists fk_product_license_product;
drop index if exists ix_product_license_product;

alter table if exists product_license drop constraint if exists fk_product_license_license;
drop index if exists ix_product_license_license;

alter table if exists product_relationship drop constraint if exists fk_product_relationship_subjective;
drop index if exists ix_product_relationship_subjective;

alter table if exists product_relationship drop constraint if exists fk_product_relationship_objective;
drop index if exists ix_product_relationship_objective;

alter table if exists product_review drop constraint if exists fk_product_review_product_id;
drop index if exists ix_product_review_product_id;

alter table if exists product_review drop constraint if exists fk_product_review_user_id;
drop index if exists ix_product_review_user_id;

alter table if exists product_topic drop constraint if exists fk_product_topic_product_id;
drop index if exists ix_product_topic_product_id;

alter table if exists project drop constraint if exists fk_project_dept_id;
drop index if exists ix_project_dept_id;

alter table if exists release drop constraint if exists fk_release_product_id;
drop index if exists ix_release_product_id;

alter table if exists team drop constraint if exists fk_team_parent_id;
drop index if exists ix_team_parent_id;

alter table if exists ginjasuser drop constraint if exists fk_ginjasuser_team_id;
drop index if exists ix_ginjasuser_team_id;

alter table if exists project_user drop constraint if exists fk_project_user_ginjasuser;
drop index if exists ix_project_user_ginjasuser;

alter table if exists project_user drop constraint if exists fk_project_user_project;
drop index if exists ix_project_user_project;

alter table if exists user_dept drop constraint if exists fk_user_dept_ginjasuser;
drop index if exists ix_user_dept_ginjasuser;

alter table if exists user_dept drop constraint if exists fk_user_dept_dept;
drop index if exists ix_user_dept_dept;

alter table if exists user_product drop constraint if exists fk_user_product_user_id;
drop index if exists ix_user_product_user_id;

alter table if exists user_product drop constraint if exists fk_user_product_project_id;
drop index if exists ix_user_product_project_id;

alter table if exists user_product drop constraint if exists fk_user_product_product_id;
drop index if exists ix_user_product_product_id;

alter table if exists user_product drop constraint if exists fk_user_product_release_seq;
drop index if exists ix_user_product_release_seq;

drop table if exists activity_record cascade;
drop sequence if exists activity_record_seq;

drop table if exists cpe_info cascade;
drop sequence if exists cpe_info_id_seq;

drop table if exists dept cascade;
drop sequence if exists dept_id_seq;

drop table if exists download_history cascade;
drop sequence if exists download_history_seq;

drop table if exists license cascade;
drop sequence if exists license_seq;

drop table if exists license_term cascade;
drop sequence if exists license_term_seq;

drop table if exists maintenance_request cascade;
drop sequence if exists maintenance_request_seq;

drop table if exists medium cascade;
drop sequence if exists medium_seq;

drop table if exists organization cascade;
drop sequence if exists organization_seq;

drop table if exists product cascade;
drop sequence if exists product_seq;

drop table if exists product_tag cascade;

drop table if exists product_license cascade;

drop table if exists product_relationship cascade;

drop table if exists product_review cascade;

drop table if exists product_topic cascade;
drop sequence if exists product_topic_seq;

drop table if exists project cascade;
drop sequence if exists project_seq;

drop table if exists release cascade;
drop sequence if exists release_seq;

drop table if exists services_provider cascade;
drop sequence if exists services_provider_seq;

drop table if exists tag cascade;
drop sequence if exists tag_seq;

drop table if exists team cascade;
drop sequence if exists team_seq;

drop table if exists ginjasuser cascade;
drop sequence if exists user_seq;

drop table if exists project_user cascade;

drop table if exists user_dept cascade;

drop table if exists user_product cascade;
drop sequence if exists user_product_seq;

