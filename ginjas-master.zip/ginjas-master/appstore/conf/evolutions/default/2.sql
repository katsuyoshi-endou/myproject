# --- Sample dataset

# --- !Ups
insert into organization values (1, 'The PostgreSQL Global Development Group', 'http://www.postgresql.org/', 0);
insert into organization values (2, 'The FreeBSD Foundation', 'https://www.freebsd.org/', 2);
insert into organization values (3, 'the Moodle Trust', 'https://moodle.org/', 2);
insert into organization values (4, 'Software in the Public Interest Inc', 'https://www.debian.org/', 0);
insert into organization values (5, 'Apache Software Foundation', 'http://apache.org/', 1);
insert into organization values (6, 'Nagios Enterprises, LLC', 'http://www.nagios.org/', 0);
insert into organization values (7, 'The Samba Team', 'http://www.samba.org/', 6);
insert into organization values (8, '一般社団法人 日本Rubyの会','http://ruby-no-kai.org/', 3);
insert into organization values (9, 'CentOS project', '', 2);
insert into organization values (10, 'Citrix Systems Inc.', '', 0);
insert into organization values (11, 'Compiere Inc', '', 0);
insert into organization values (12, 'Danga Interactive', '', 6);
insert into organization values (13, 'Digium', '', 0);
insert into organization values (14, 'Django Software Foundation', '', 2);
insert into organization values (15, 'Drupal Project', '', 2);
insert into organization values (16, 'Edgewall Software.', '', 0);
insert into organization values (17, 'Eucalyptus Systems Inc', '', 0);
insert into organization values (18, 'Fermi National Accelerator Laboratory', '', 5);
insert into organization values (19, 'Firebird Project', '', 2);
insert into organization values (20, 'ForgeRock', '', 0);
insert into organization values (21, 'Gordon Lyon', '', 6);
insert into organization values (22, 'GroundWork, Inc.', '', 0);
insert into organization values (23, 'Igor Sysoev', '', 6);
insert into organization values (24, 'ImageMagick Studio LLC', '', 0);
insert into organization values (25, 'Jan Kneschke', '', 6);
insert into organization values (26, 'JasperForge', '', 0);
insert into organization values (27, 'JBoss Community', '', 0);
insert into organization values (28, 'Jean-Philippe Lang', '', 6);
insert into organization values (29, 'Joyent Inc.', '', 0);
insert into organization values (30, 'jQuery project', '', 2);
insert into organization values (31, 'Junio C Hamano', '', 6);
insert into organization values (32, 'Liferay Inc.', '', 0);
insert into organization values (33, 'LINBIT', '', 0);
insert into organization values (34, 'Machine Learning Group at University of Waikato', '', 5);
insert into organization values (35, 'Marc OBrien, Howard Katz, Laurent Chretienneau', '', 6);
insert into organization values (36, 'Meteor Development Group', '', 4);
insert into organization values (37, 'Monty Program Ab', '', 0);
insert into organization values (38, 'Mort Bay Consulting', '', 0);
insert into organization values (39, 'MyBatis Project', '', 4);
insert into organization values (41, 'Nokia', '', 0);
insert into organization values (42, 'Novell Inc.', '', 0);
insert into organization values (43, 'NTT Data', '', 0);
insert into organization values (44, 'Open Source Matters Inc.', '', 0);
insert into organization values (45, 'OpenBSD', '', 2);
insert into organization values (46, 'OpenLDAP Foundation', '', 2);
insert into organization values (47, 'OpenVPN Technologies Inc.', '', 0);
insert into organization values (48, 'Opsview Ltd.', '', 0);
insert into organization values (49, 'Oracle', '', 0);
insert into organization values (50, 'OTRS Group', '', 0);
insert into organization values (51, 'Pentaho Corporation', '', 0);
insert into organization values (52, 'Puppet Labs', '', 0);
insert into organization values (53, 'R Foundation', '', 2);
insert into organization values (54, 'Rackspace Cloud', '', 0);
insert into organization values (55, 'Sauce Labs Inc.', '', 0);
insert into organization values (57, 'Sourcefire Inc', '', 0);
insert into organization values (58, 'SpringSource ', '', 0);
insert into organization values (59, 'SpringSource ', '', 0);
insert into organization values (60, 'Squid Project', '', 4);
insert into organization values (61, 'SugarCRM Inc.', '', 0);
insert into organization values (62, 'Talend', '', 0);
insert into organization values (63, 'The Cacti Group Inc.', '', 0);
insert into organization values (64, 'The Document Foundation', '', 2);
insert into organization values (65, 'The Dojo Foundation', '', 2);
insert into organization values (67, 'The GIMP Team', '', 4);
insert into organization values (69, 'The OpenSSL project', '', 4);
insert into organization values (72, 'The Seasar Foundation', '', 2);
insert into organization values (73, 'Timo Sirainen', '', 6);
insert into organization values (74, 'Tobi Oetiker', '', 6);
insert into organization values (75, 'UltraMonkey-L7 Project', '', 4);
insert into organization values (76, 'Vyatta Inc.', '', 0);
insert into organization values (77, 'Wietse Venema', '', 6);
insert into organization values (78, 'Wireshark Foundation', '', 2);
insert into organization values (79, 'WordPress.com', '', 0);
insert into organization values (80, 'Xamarin', '', 0);
insert into organization values (81, 'Xymon Monitor project', '', 4);
insert into organization values (82, 'Yahoo! Inc.', '', 0);
insert into organization values (83, 'Zabbix SIA', '', 0);
insert into organization values (84, 'Zend Technologies Ltd.', '', 0);
insert into organization values (85, 'Zmanda', '', 0);
insert into organization values (86, 'Alkacon Software GmbH', '', 0);
insert into organization values (87, 'Cake Software Foundation, Inc.', '', 0);
insert into organization values (88, 'D. J. Bernstein', '', 6);
insert into organization values (89, 'Eclipse Foundation', '', 2);
insert into organization values (90, 'EllisLab, Inc.', '', 0);
insert into organization values (91, 'eZ Systems', '', 0);
insert into organization values (92, 'Fedora Project', '', 0);
insert into organization values (93, 'Internet Systems Consortium', '', 3);
insert into organization values (94, 'Mercurial project', '', 4);
insert into organization values (95, 'MIT Kerberos Consortium', '', 5);
insert into organization values (97, 'OpenFlowHub.org', '', 2);
insert into organization values (98, 'PgPool Global Development Group', '', 4);
insert into organization values (99, 'Plone Foundation', '', 2);
insert into organization values (100, 'Sendmail, Inc.', '', 0);
insert into organization values (101, 'SQLite Consortium', '', 4);
insert into organization values (102, 'Trema', '', 4);
insert into organization values (103, 'Twitter', '', 0);
insert into organization values (104, 'Typesafe, Inc. ', '', 0);
insert into organization values (105, 'XOOPS Project', '', 4);
insert into organization values (106, '国立情報学研究所NetCommonsプロジェクト', '', 5);
insert into organization values (107, 'Free Software Foundation',  '', 1);
insert into organization values (108, 'Apache Harmony プロジェクト', '', 4);
insert into organization values (109, 'Python Software Foundation', '', 2);
insert into organization values (110, 'Mozilla Foundation', '', 1);
insert into organization values (111, '川合史朗', '', 6);
insert into organization values (113, 'リオデジャネイロ・カトリカ大学の情報工学科コンピュータグラフィックステクノロジーグループ', '', 5);
insert into organization values (126, 'Telefonaktiebolaget LM Ericsson', '', 0);
insert into organization values (127, 'TeCGraf ', '', 5);
insert into organization values (128, 'The PHP Group', '', 2);
insert into organization values (129, 'The Scala Development Team', '', 4);
insert into organization values (130, 'Well-Typed LLP', '', 0);
insert into organization values (146, 'Red Hat, Inc.', '', 0);
insert into organization values (147, 'Linux-HA Project', '', 4);
insert into organization values (148, 'Couchbase Inc', '', 0);
insert into organization values (149, 'VMware, Inc', '', 0);
insert into organization values (150, 'Carnegie Mellon University', '', 5);
insert into organization values (151, 'OpenVAS Steering Team', '', 4);
insert into organization values (152, 'Cacti Group, Inc', '', 0);
insert into organization values (153, 'Software- und Organisations-Service GmbH', '', 0);
insert into organization values (154, 'Opscode, Inc', '', 0);
insert into organization values (155, 'CVS Team', '', 4);
insert into organization values (156, 'Mantis Team', '', 4);
insert into organization values (157, 'OpenPNEプロジェクト', '', 4);
insert into organization values (158, 'MIND CO.,LTD', '', 0);
insert into organization values (159, 'vitger', '', 0);
insert into organization values (160, 'Aimluck,Inc', '', 0);
insert into organization values (206, 'Greenbone Networks', '', 0);
insert into organization values (70,'10gen', '', 0);
insert into organization values (66, '37 signals', '', 0);
insert into organization values (68, 'ADempiere ERP Bazaar', '', 4);
insert into organization values (112, 'Canonical Ltd.', '', 0);
insert into organization values (71, 'Artica ST', '', 0);
insert into organization values (40, 'Alfresco Software Inc', '', 0);
insert into organization values (56, 'Adobe Systems Inc.', '', 0);
insert into organization values (999, '不明', '', 0);

insert into tag values('platform', 'プラットフォーム', true);
insert into tag values ('os', 'OS', false);
insert into tag values('network', 'ネットワーク', false);
insert into tag values('loadbalancer', 'ロードバランサー', false);
insert into tag values ('directory', 'ディレクトリサービス', false);
insert into tag values ('clustering', 'クラスタリングソフト', false);
insert into tag values ('mail', 'メール', false);
insert into tag values ('virtualization', '仮想化基盤', false);
insert into tag values ('cloud', 'クラウド基盤', false);
insert into tag values ('middleware', 'ミドルウェア', true);
insert into tag values ('webserver', 'Webサーバー', false);
insert into tag values ('apserver', 'アプリケーションサーバー', false);
insert into tag values ('dbms', 'DBMS', false);
insert into tag values ('cache', 'ストレージキャッシュ', false);
insert into tag values ('sql', 'SQL', false);
insert into tag values ('nosql', 'NoSQL', false);
insert into tag values ('tool', 'ツール', true);
insert into tag values ('operations', '運用管理', true);
insert into tag values ('backup', 'バックアップ', true);
insert into tag values ('monitoring', '監視系', false);
insert into tag values ('config', '構成管理', false);
insert into tag values ('devenv', '開発環境', false);
insert into tag values ('testing', 'テストツール', false);
insert into tag values ('language', '言語', true);
insert into tag values ('object-oriented', 'オブジェクト指向', false);
insert into tag values ('functional', '関数型', false);
insert into tag values ('scripting', 'スクリプト言語', false);
insert into tag values ('jvm', 'JVM言語', false);
insert into tag values ('library', 'ライブラリ／フレームワーク', true);
insert into tag values ('framework', 'フレームワーク', true);
insert into tag values ('uitoolkit', 'UIツールキット', true);
insert into tag values ('application', 'アプリケーション', true);
insert into tag values ('cms', 'CMS', false);
insert into tag values ('erp', 'ERP', false);
insert into tag values ('crm', 'CRM', false);
insert into tag values ('officesuite', 'オフィススイート', false);
insert into tag values ('groupware', 'グループウェア', false);
insert into tag values ('bi', 'BI', false);
insert into tag values ('stat-analysis', '統計解析', false);
insert into tag values ('search', '検索エンジン', false);
insert into tag values ('graphics', 'グラフィックス', false);
insert into tag values ('communication', 'コミュニケーション', false);
insert into tag values ('fileserver', 'ファイルサーバー', false);
insert into tag values ('filesystem', 'ファイルシステム', false);
insert into tag values ('distro', 'Linuxディストリビューション', false);
insert into tag values ('education', '教育', false);
insert into tag values ('bsd', 'BSD系ライセンス', false);
insert into tag values ('gpl2', 'GPLバージョン2', false);
insert into tag values ('gpl3', 'GPLバージョン3', false);
insert into tag values ('agpl', 'Affero GPL', false);
insert into tag values ('lgpl', 'LGPL', false);
insert into tag values ('mit', 'MITライセンス', false);
insert into tag values ('apache', 'Apacheライセンス', false);
insert into tag values ('publicdomain', 'パブリックドメイン', false);
insert into tag values ('java', 'Java', false);
insert into tag values ('scala', 'Scala', false);
insert into tag values ('php', 'PHP', false);
insert into tag values ('ruby', 'Ruby', false);
insert into tag values ('python', 'Python', false);
insert into tag values ('javascript', 'Javascript', false);
insert into tag values ('security', 'セキュリティ', false);
insert into tag values ('openflow', 'OpenFlow', false);

insert into license values (0, '商用ライセンス', 'PROPRIETARY', '', '', '', false);
insert into license values (1, 'GNU General Public License version 2', 'GPL-2.0', 'http://opensource.org/licenses/GPL-2.0', '"コピーレフト"型ライセンスの代表格。このライセンスを持つライブラリやフレームワークの応用プログラムには独自の配布条件を設けることができないので要注意！', '', true);
insert into license values (2, 'GNU General Public License version 3', 'GPL-3.0', 'http://opensource.org/licenses/GPL-3.0', 'コピーレフト"型ライセンスの代表格。このライセンスを持つライブラリやフレームワークの応用プログラムには独自の配布条件を設けることができないので要注意！', '', true);
insert into license values (3, 'GNU Affero General Public License version 3', 'AGPL-3.0', 'http://opensource.org/licenses/AGPL-3.0', '地上最強のコピーレフト型ライセンス。原則として自社製品／サービスの部品として使うのはライセンス上困難', '', true);
insert into license values (4, 'GNU Lesser General Public License version 2.1', 'LGPL-2.1', 'http://opensource.org/licenses/LGPL-2.1', '限定的なコピーレフトライセンス。', '', true);
insert into license values (5, 'GNU Lesser General Public License version 3', 'LGPL-3.0', 'http://opensource.org/licenses/LGPL-3.0', '限定的なコピーレフトライセンス。', '', true);
insert into license values (6, 'Apache License 2.0', 'Apache-2.0', 'http://opensource.org/licenses/Apache-2.0', '寛容な条件を持つライセンス', '', true);
insert into license values (7, 'MIT X License', 'MIT', 'http://opensource.org/licenses/MIT', '最も寛容な条件を持つライセンスのひとつ', '', true);
insert into license values (8, 'Mozilla Public License 2.0', 'MPL-2.0', 'http://opensource.org/licenses/MPL-2.0', '限定的なコピーレフトライセンス。エンジン部分のソース転用といった使い方をしてはいけません', '', true);
insert into license values (9, 'Eclipse Public License 1.0', 'EPL-1.0', 'http://opensource.org/licenses/EPL-1.0', '限定的なコピーレフトライセンス。エンジン部分のソース転用といった使い方をしてはいけません', '', true);
insert into license values (10, 'Common Development and Distribution License', 'CDDL', 'http://opensource.org/licenses/CDDL-1.0', '限定的なコピーレフトライセンス。エンジン部分のソース転用といった使い方をしてはいけません', '', true);
insert into license values (11, 'BSD 3-Clause License', 'BSD-3-Clause', 'http://opensource.org/licenses/BSD-3-Clause', '寛容な条件を持つライセンス', '', true);
insert into license values (12, 'BSD 2-Clause License', 'BSD-2-Clause', 'http://opensource.org/licenses/BSD-2-Clause', '寛容な条件を持つライセンス', '', true);
insert into license values (13, 'The PostgreSQL License', 'PostgreSQL', 'http://opensource.org/licenses/PostgreSQL', '内容的にはBSDライセンスと同じです', '', true);
insert into license values (14, 'Python License', 'Python-2.0', 'http://opensource.org/licenses/Python-2.0', '', '', true);
insert into license values (15, 'Artistic License 2.0', 'Artistic-2.0', 'http://opensource.org/licenses/Artistic-2.0', '', '', true);
insert into license values (16, 'European Union Public License, version 1.1', 'EUPL-1.1', 'http://opensource.org/licenses/EUPL-1.1', '', '', true);
insert into license values (17, 'Common Public Attribution License 1.0', 'CPAL-1.0', 'http://opensource.org/licenses/CPAL-1.0', '', '', true);
insert into license values (18, 'IBM Public License 1.0', 'IPL-1.0', 'http://opensource.org/licenses/IPL-1.0', '', '', true);
insert into license values (19, 'Microsoft Public License', 'MS-PL', 'http://opensource.org/licenses/MS-PL', '', '', true);
insert into license values (20, 'PHP License 3.0', 'PHP-3.0', 'http://opensource.org/licenses/PHP-3.0', '', '', true);
insert into license values (21, 'Ruby License', 'Ruby', '', '', '', false);
insert into license values (22, 'GNU General Public License version 2 with CLASSPATH exception', 'GPL-2.0wCPE', 'http://opensource.org/licenses/GPL-2.0', 'GPLに例外条項を設けて、ライブラリとして商用ソフトウェアにリンク可能にしたもの', '', true);
insert into license values (23, 'Sendmail License', 'sendmail', 'http://www.sendmail.com/pdfs/open_source/sendmail_license.pdf', '', '', false);
insert into license values (24, 'OpenSSH License', 'OpenSSH', 'http://rc.quest.com/topics/openssh/license.php#openssh', '', '', false);
insert into license values (25, 'OpenSSL License', 'OpenSSL', 'https://www.openssl.org/source/license.html', '', '', false);
insert into license values (26, 'Zimbra Public License', 'Zimbra', 'http://www.zimbra.com/legal/zimbra-public-license-1-4', '', '', false);
insert into license values (9999, 'パブリックドメイン', 'publicdomain', '', '', '', false);


insert into product values (1, 'PostgreSQL', 'オープンソースのORDBMS（オブジェクト関係データベースシステム)実装。IllustraやInfomixを起源に持つ', 'http://www.postgresql.org/', '/assets/images/openhub/pgsql_med.png', 'http://www.postgresql.org/download/', '2013-07-27 00:00:00', 1, true);
insert into product_license values(13, 1);
insert into product_tag values(1, 'middleware');
insert into product_tag values(1, 'dbms');
insert into product_tag values(1, 'bsd');

insert into product values (2, 'FreeBSD','オープンソースのBSD子孫のUNIX系OS（オペレーティングシステム）',  'http://www.freebsd.org/', '/assets/images/openhub/freebsd_med.png', 'http://www.freebsd.org/where.html', '2013-08-15 00:00:00', 2, true);
insert into product_license values(12, 2);
insert into product_tag values(2, 'platform');
insert into product_tag values(2, 'os');
insert into product_tag values(2, 'bsd');

insert into product values (3, 'Moodle','eラーニングプラットフォーム。教育者が質の高いオンライン学習過程（コース）を作ることを支援する', 'http://moodle.org/', '/assets/images/openhub/moodle_core_med_med.png', 'http://download.moodle.org/', '2013-09-10 00:00:00', 3, true);
insert into product_license values(1, 3);
insert into product_tag values(3, 'application');
insert into product_tag values(3, 'cms');
insert into product_tag values(3, 'education');
insert into product_tag values(3, 'gpl2');

insert into product values (4, 'Debian','Debian Projectにより開発・提供されているLinuxディストリビューションの一つ', 'http://www.debian.org/',  '/assets/images/openhub/openlogo-nd-100_med.png','http://www.debian.org/distrib/netinst', '2013-07-27 00:00:00', 4, true);
insert into product_license values(1, 4);
insert into product_tag values(4, 'platform');
insert into product_tag values(4, 'os');
insert into product_tag values(4, 'gpl2');
insert into product_tag values(4, 'distro');

insert into product values (5, 'Apache HTTP Server','世界中で一番利用されているWebサーバ', 'http://httpd.apache.org/', '/assets/images/openhub/apache_med.png', 'http://httpd.apache.org/download.cgi', '2013-08-15 00:00:00', 5, true);
insert into product_license values(6, 5);
insert into product_tag values(5, 'middleware');
insert into product_tag values(5, 'webserver');
insert into product_tag values(5, 'apache');

insert into product values (6, 'Apache Open Office','オープンソースで開発されているオフィススィート。Oracleから寄贈されたOpenOffice.orgを元にApache Software Foundationで開発されている', 'http://openoffice.apache.org/', '/assets/images/openhub/image_med.jpg','http://www.openoffice.org/ja/download/', '2013-09-10 00:00:00', 5, true);
insert into product_license values(6, 6);
insert into product_tag values(6, 'application');
insert into product_tag values(6, 'officesuite');
insert into product_tag values(6, 'apache');

insert into product values (7, 'Nagios','運用監視ツール。 プラグインを利用して、様々な対象を監視することができる。', 'http://www.nagios.org/', '/assets/images/openhub/smalllogo7_med.gif', 'http://www.nagios.org/download','2013-09-10 00:00:00', 6, true);
insert into product_license values(1, 7);
insert into product_tag values(7, 'tool');
insert into product_tag values(7, 'monitoring');
insert into product_tag values(7, 'gpl2');

insert into product values (8, 'Samba','Windowsのファイルサーバ、プリントサービス、ドメイン機能などを実装したもの', 'http://www.samba.org/',  '/assets/images/openhub/samba_2010_logo_transparent_151x151_med.png','http://www.samba.org/samba/download/', '2013-10-12 00:00:00', 7, true);
insert into product_license values(2, 8);
insert into product_tag values(8, 'platform');
insert into product_tag values(8, 'gpl3');
insert into product_tag values(8, 'fileserver');

insert into product values (9, 'Ruby','まつもとゆきひろ（通称 Matz）により開発されたオブジェクト指向スクリプト言語', 'http://www.ruby-lang.org/ja/', '/assets/images/openhub/ruby_med.png','https://www.ruby-lang.org/ja/downloads/', '2013-12-31', 8, true);
insert into product_license values(12, 9);
insert into product_license values(21, 9);
insert into product_tag values(9, 'language');
insert into product_tag values(9, 'object-oriented');
insert into product_tag values(9, 'bsd');

insert into product values (10, 'Wordpress', ' PHPをベースとしたブログソフトウェア。CMSとしても利用可能', 'http://wordpress.org/', '/assets/images/openhub/wordpress.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(10, 'cms');
insert into product_tag values(10, 'application');
insert into product_tag values(10, 'gpl2');
insert into product_license values(1, 10);

insert into product values (11, 'MariaDB', ' MySQL派生のオープンソースな関係データベース管理システム（RDBMS）。MySQLの作者であるMichael \"Monty\" Wideniusがプロジェクトを立ち上げた', 'https://mariadb.org/', '/assets/images/openhub/MariaDB-seal_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(11, 'middleware');
insert into product_tag values(11, 'dbms');
insert into product_tag values(11, 'gpl2');
insert into product_license values(1, 11);

insert into product values (12, 'Qt', ' C++で記述されたGUIツールキット。X Window System、Windows、Mac OS Xなどさまざまなプラットフォーム上で動作するアプリケーションの開発が可能', 'http://qt-project.org/', '/assets/images/openhub/qt-logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(12, 'library');
insert into product_tag values(12, 'gpl2');
insert into product_tag values(12, 'lgpl');
insert into product_tag values(12, 'uitoolkit');
insert into product_license values(1, 12);
insert into product_license values(4, 12);

insert into product values (13, 'Dojo Toolkit', ' クロスブラウザに対応したJavaScript/Ajaxアプリケーションを迅速に開発するためのJavaScriptライブラリ', 'http://dojotoolkit.org/', '/assets/images/openhub/dojoToolkitLogo64Black_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(13, 'library');
insert into product_tag values(13, 'javascript');
insert into product_tag values(13, 'bsd');
insert into product_license values(11, 13);

insert into product values (14, 'Ubuntu', ' Debian GNU/LinuxをベースとしたLinuxディストリビューションの一つ', 'http://www.ubuntu.com', '/assets/images/openhub/ubuntu_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(14, 'platform');
insert into product_tag values(14, 'os');
insert into product_tag values(14, 'distro');
insert into product_tag values(14, 'gpl2');
insert into product_license values(1, 14);

insert into product values (15, 'Apache Hadoop', ' Javaベースの大規模分散バッチ処理向けフレームワーク', 'http://hadoop.apache.org/', '/assets/images/openhub/hadoop_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(15, 'library');
insert into product_tag values(15, 'apache');
insert into product_license values(6, 15);

insert into product values (16, 'eZ Publish', ' eZ Systems社が開発提供するエンタープライズ・オープンソースPHPコンテンツマネジメントシステム(CMS) ', 'http://ez.no/', '/assets/images/openhub/ezpublish_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(16, 'application');
insert into product_tag values(16, 'cms');
insert into product_tag values(16, 'gpl2');
insert into product_license values(1, 16);

insert into product values (17, 'Apache Lucene', ' Javaベースの全文検索ソフトウェア', 'http://lucene.apache.org/', '/assets/images/openhub/lucene_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_license values(6, 17);
insert into product_tag values(17, 'middleware');
insert into product_tag values(17, 'apache');
insert into product_tag values(17, 'java');
insert into product_tag values(17, 'search');

insert into product values (19, 'Apache Cassandra', 'キー・バリュー型分散データベース管理システム', 'http://cassandra.apache.org/', '/assets/images/openhub/cassandra-eye-square_med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(19, 'middleware');
insert into product_tag values(19, 'dbms');
insert into product_tag values(19, 'nosql');
insert into product_license values(6, 19);

insert into product values (20, 'GCC', ' GNU Compiler Collection（グニューコンパイラコレクション）の略称。GNUのコンパイラ群', 'http://gcc.gnu.org/', '/assets/images/openhub/gcc_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(20, 'tool');
insert into product_tag values(20, 'language');
insert into product_tag values(20, 'gpl2');
insert into product_license values(1, 20);

insert into product values (21, 'Alfresco', ' 企業規模の文書管理・コンテンツ管理システム。商用製品 Documentumからのスピンアウト', 'http://www.alfresco.com/community/', '/assets/images/openhub/alf_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(21, 'cms');
insert into product_tag values(21, 'application');
insert into product_tag values(21, 'gpl2');
insert into product_license values(1, 21);

insert into product values (22, 'Apache Tomcat', ' JavaベースのWebアプリケーションサーバ。Java ServletやJSP（JavaServer Pagesの）参照実装でもある', 'http://tomcat.apache.org/', '/assets/images/openhub/tomcat_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(22, 'middleware');
insert into product_tag values(22, 'apserver');
insert into product_tag values(22, 'apache');
insert into product_tag values(22, 'java');
insert into product_license values(6, 22);

insert into product values (23, 'OpenAM', ' 認証基盤となるソフトウェアでSSO（シングルサインオン）、アクセス制御などの機能を提供する。Sunが開発していたOpenSSOを起源に持つ', 'http://openam.forgerock.org/', '/assets/images/openhub/OpenAM_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(23, 'middleware');
insert into product_tag values(23, 'security');
insert into product_tag values(23, 'java');
insert into product_license values(10, 23);

insert into product values (24, 'Apache Axis2/Java', ' JavaベースのWebサービスのためのフレームワーク', 'http://ws.apache.org/axis2', '/assets/images/openhub/axis3_med.jpg', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(24, 'library');
insert into product_tag values(24, 'apache');
insert into product_tag values(24, 'java');
insert into product_license values(6, 24);

insert into product values (25, 'OpenLDAP', ' OpenLDAP Projectが開発するLDAP(Lightweight Directory Access Protocol)のオープンソース実装', 'http://www.openldap.org/', '/assets/images/openhub/openldap_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(25, 'platform');
insert into product_tag values(25, 'directory');

insert into product values (26, 'Redmine', ' Webベースのプロジェクト管理ソフトウェア。バグ管理システム、ガントチャートなどの機能を提供し、複数のプロジェクトに対応していることが特徴。Ruby on Railsで開発されている', 'http://www.redmine.org/', '/assets/images/openhub/redmine_fluid_icon_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(26, 'tool');
insert into product_tag values(26, 'devenv');
insert into product_tag values(26, 'gpl2');
insert into product_tag values(26, 'ruby');
insert into product_license values(1, 26);

insert into product values (27, 'Postfix', ' オープンソースのメール転送エージェント(MTA)。Sendmail互換でありながら管理の容易性、高速・安全であることを目指して開発 ', 'http://www.postfix.org/', '/assets/images/openhub/postfix_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_license values(18, 27);
insert into product_tag values(27, 'platform');
insert into product_tag values(27, 'mail');

insert into product values (28, 'Zabbix', ' 統合運用監視ツール。 エージェントを利用した監視は、多くの種類のOSに対応している。 また、SNMP、IPMI、SSH、telnetなどを利用した監視も可能である。 Webブラウザを利用して監視の設定ができ、グラフ化の機能も備えている。', 'http://www.zabbix.com/', '/assets/images/openhub/zabbix_med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_license values(1, 28);
insert into product_tag values(28, 'tool');
insert into product_tag values(28, 'monitoring');
insert into product_tag values(28, 'gpl2');

insert into product values (29, 'Apache Struts', ' JavaベースのWebアプリケーションフレームワーク。MVC（Model View Controler)アーキテクチャを採用している', 'http://struts.apache.org/', '/assets/images/openhub/struts_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(29, 'library');
insert into product_tag values(29, 'apache');
insert into product_license values(6, 29);

insert into product values (30, 'CentOS', ' Red Hat Enterprise Linuxとの完全互換を期するLinuxディストリビューション ', 'http://www.centos.org/', '/assets/images/openhub/centos-logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(30, 'platform');
insert into product_tag values(30, 'os');
insert into product_tag values(30, 'distro');
insert into product_tag values(30, 'gpl2');
insert into product_license values(1, 30);

insert into product values (31, 'JasperReports', ' Javaベースの帳票ツール', 'http://jasperforge.org/', '/assets/images/openhub/Jasper_med.PNG', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(31, 'application');
insert into product_tag values(31, 'bi');
insert into product_tag values(31, 'lgpl');
insert into product_license values(4, 31);

insert into product values (32, 'Apache CloudStack', ' IaaS（Infrastructure as a Service)ベースとなるクラウドインフラストラクチャ構築ソフトウェア。Citrix SystemsからApache Software Foundationへ移管された。', 'http://cloudstack.apache.org/index.html', '/assets/images/openhub/cloudstack_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(32, 'platform');
insert into product_tag values(32, 'cloud');
insert into product_tag values(32, 'apache');
insert into product_license values(6, 32);

insert into product values (33, 'JBoss Application Server', ' JBoss.orgにより開発されている、JavaベースのWebアプリケーションサーバ ', 'http://jboss.org/jbossas', '/assets/images/openhub/jbossas7_ligature_64px_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(33, 'middleware');
insert into product_tag values(33, 'apserver');
insert into product_tag values(33, 'java');
insert into product_tag values(33, 'lgpl');
insert into product_license values(4, 33);
insert into product values (34, 'CakePHP', ' PHPを用いて動的Webサイトを構築するために利用するオープンソースのWebアプリケーションフレームワーク', 'http://cakephp.org/', '/assets/images/openhub/cake2000_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(34, 'php');
insert into product_tag values(34, 'library');
insert into product_tag values(34, 'mit');
insert into product_tag values(34, 'framework');
insert into product_license values(7, 34);

insert into product values (35, 'R', '統計解析用言語および開発／実行ツール', 'http://www.r-project.org/', '/assets/images/openhub/Rlogo-5_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(35, 'language');
insert into product_tag values(35, 'tool');
insert into product_tag values(35, 'stat-analysis');
insert into product_tag values(35, 'gpl2');
insert into product_license values(1, 35);

insert into product values (36, 'Pentaho Business Intelligence Server', ' ビジネスインテリジェンス(BI) ソリューションを提供するソフトウェア', 'http://www.pentaho.com/', '/assets/images/openhub/pentaho-logo-small_med_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(36, 'application');
insert into product_tag values(36, 'bi');
insert into product_tag values(36, 'gpl2');
insert into product_license values(1, 36);

insert into product values (37, 'OpenJDK', ' プログラミング言語Javaのフリーかつオープンソースの実装である', 'http://openjdk.java.net/', '/assets/images/openhub/openjdk_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(37, 'language');
insert into product_tag values(37, 'tool');
insert into product_tag values(37, 'java');
insert into product_tag values(37, 'gpl2');
insert into product_license values(22, 37);

insert into product values (38, 'Spring Framework', ' Javaベースのアプリケーションフレームワーク。IoC/DI（依存性の注入)やAOP（アスペクト指向）などが特徴', 'http://www.springsource.org/', '/assets/images/openhub/SpringFramework_Twitter_Avatar-NoBorder_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(38, 'library');
insert into product_tag values(38, 'framework');
insert into product_tag values(38, 'java');
insert into product_tag values(38, 'apache');
insert into product_license values(6, 38);

insert into product values (39, 'Talend Open Studio', ' データ統合ソフトウェア。業務システムからETL（Extract/Transform/Load)までのデータ統合に利用できる', 'http://www.talendforge.org/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 


insert into product values (40, 'ADempiere ERP Business Suite', ' ERP、CRM、SCM等のアプリケーションパッケージ。Compiereから分岐', 'http://www.adempiere.com/ADempiere_ERP', '/assets/images/openhub/adempiere-ico-64x64_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(40, 'application');
insert into product_tag values(40, 'erp');
insert into product_tag values(40, 'gpl2');
insert into product_license values(1, 40);

insert into product values (41, 'Squid', 'プロキシサーバ、ウェブキャッシュサーバの機能を提供するソフトウェア', 'http://www.squid-cache.org/', '/assets/images/openhub/Squid1_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(41, 'middleware');
insert into product_tag values(41, 'webserver');
insert into product_tag values(41, 'gpl2');
insert into product_license values(1, 41);

insert into product values (42, 'Cacti', ' グラフツール。SNMPエージェントが取得した値や、プログラム/スクリプトの出力結果をグラフ化することが可能', 'http://www.cacti.net', '/assets/images/openhub/cacti_med.Png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(42, 'tool');
insert into product_tag values(42, 'monitoring');
insert into product_tag values(42, 'gpl2');
insert into product_license values(1, 42);

insert into product values (43, 'Zend Framework', ' PHP5ベースのWebアプリケーションフレームワーク', 'http://framework.zend.com/community/overview', '/assets/images/openhub/zend_med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(43, 'library');
insert into product_tag values(43, 'bsd');
insert into product_tag values(43, 'php');
insert into product_tag values(43, 'framework');
insert into product_license values(11, 43);

insert into product values (44, 'SugarCRM', ' CRM(顧客関係管理)ソフトウェア。', 'http://www.sugarforge.org/', '/assets/images/openhub/logo_sugarcrm_cube_med.jpg', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(44, 'application');
insert into product_tag values(44, 'crm');
insert into product_tag values(44, 'gpl2');
insert into product_license values(1, 44);

insert into product values (45, 'Drupal', ' コンテンツ管理システム(CMS)であり、PHPで実装されている', 'http://drupal.org/', '/assets/images/openhub/druplicon.large_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(45, 'application');
insert into product_tag values(45, 'cms');
insert into product_tag values(45, 'gpl2');
insert into product_license values(1, 45);

insert into product values (46, 'Apache Maven', ' Javaベースの開発支援ツール。プロジェクトの構成管理機能を提供する。', 'http://maven.apache.org/', '/assets/images/openhub/maven-icon_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(46, 'tool');
insert into product_tag values(46, 'devenv');
insert into product_tag values(46, 'apache');
insert into product_license values(6, 46);

insert into product values (47, 'MySQL', ' オープンソースのRDBMS（リレーショナルデータベースシステム)実装。現在はOracleが所有している', 'http://www.mysql.com/', '/assets/images/openhub/MySQL_white_64x64_med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(47, 'middleware');
insert into product_tag values(47, 'dbms');
insert into product_tag values(47, 'gpl2');
insert into product_license values(1, 47);
insert into product_license values(0, 47);

insert into product values (48, 'Trac', ' Webベースのプロジェクト管理ソフトウェア。チケットベースのバグ管理システムの他プラグインも合わせてさまざまな機能を提供する。Pythonをベースに実装されている', 'http://trac.edgewall.org/', '/assets/images/openhub/Trac_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(48, 'tool');
insert into product_tag values(48, 'devenv');
insert into product_license values(11, 48);

insert into product values (49, 'Apache OpenMeetings', ' Webベース会議用ソフトウェアプラットフォーム ', 'http://openmeetings.apache.org/', '/assets/images/openhub/Openmeetings_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(49, 'application');
insert into product_tag values(49, 'communication');
insert into product_tag values(49, 'apache');
insert into product_license values(6, 49);

insert into product values (50, 'openSUSE', ' SUSE Linuxを起源に持つ、コミュニティベースのLinuxディストリビューション', 'http://www.opensuse.org/en/', '/assets/images/openhub/openSUSE_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(50, 'platform');
insert into product_tag values(50, 'os');
insert into product_tag values(50, 'gpl2');
insert into product_tag values(50, 'distro');
insert into product_license values(1, 50);

insert into product values (51, 'VirtualBox', ' x86仮想化ソフトウェア・パッケージ', 'http://www.virtualbox.org/wiki/VirtualBox', '/assets/images/openhub/virtualbox_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(51, 'platform');
insert into product_tag values(51, 'virtualization');
insert into product_tag values(51, 'gpl2');
insert into product_license values(1, 51);

insert into product values (52, 'git', 'プログラムなどのソースコード管理を行う、分散バージョン管理システム。', 'http://git-scm.com/', '/assets/images/openhub/Git-Icon-1788C_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(52, 'tool');
insert into product_tag values(52, 'devenv');
insert into product_tag values(52, 'gpl2');
insert into product_license values(1, 52);

insert into product values (53, 'Hibernate', ' JavaベースのORM（オブジェクト関係マッピング）フレームワーク', 'http://hibernate.org/', '/assets/images/openhub/hibernate_icon_med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(53, 'library');
insert into product_tag values(53, 'java');
insert into product_tag values(53, 'lgpl');
insert into product_license values(4, 52);

insert into product values (55, 'Puppet', ' Rubyベースのシステム自動管理ツール', 'http://www.puppetlabs.com/', '/assets/images/openhub/puppet_logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(55, 'tool');
insert into product_tag values(55, 'config');
insert into product_tag values(55, 'apache');
insert into product_license values(6, 55);

insert into product values (56, 'Xen Hypervisor', ' Xenコミュニティにより開発されている、仮想マシンモニタ（Hypervisor）', 'http://www.xenproject.org/', '/assets/images/openhub/XenProject_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(56, 'platform');
insert into product_tag values(56, 'virtualization');
insert into product_tag values(56, 'gpl2');
insert into product_license values(1, 56);
insert into product_license values(12, 56);

insert into product values (57, 'Clam Antivirus', 'クロスプラットフォームのアンチウィルスソフトウェア', 'http://www.clamav.net/lang/en/', '/assets/images/openhub/clamav_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(57, 'tool');
insert into product_tag values(57, 'security');
insert into product_tag values(57, 'gpl2');
insert into product_license values(1, 57);

insert into product values (58, 'MRTG', ' MRTG (Multi Router Traffic Grapher) は、ルータなどネットワーク機器が送受信したデータの量（トラフィック）をグラフによって可視化するプログラム。', 'http://oss.oetiker.ch/mrtg/index.en.html', '/assets/images/openhub/mrtg-logo_med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_license values(1, 58);
insert into product_tag values(58, 'tool');
insert into product_tag values(58, 'gpl2');

insert into product values (59, 'Django Framework', ' PythonベースのWebアプリケーションフレームワーク。', 'https://www.djangoproject.com/', '/assets/images/openhub/django-logo-positive-scaled_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(59, 'library');
insert into product_tag values(59, 'framework');
insert into product_tag values(59, 'python');
insert into product_tag values(59, 'bsd');
insert into product_license values(11, 59);

insert into product values (60, 'Mono', ' Microsoft .NET Framework互換の環境を実現するためのオープンソースソフトウェア。共通言語基盤 (CLI) の実装やC#のコンパイラなどが含まれる', 'http://www.mono-project.com/Main_Page', '/assets/images/openhub/mono_logo_64_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(60, 'library');
insert into product_tag values(60, 'framework');
insert into product_tag values(60, 'gpl2');
insert into product_tag values(60, 'lgpl');
insert into product_tag values(60, 'mit');
insert into product_license values(1, 60);
insert into product_license values(4, 60);
insert into product_license values(7, 60);

insert into product values (61, 'CodeIgniter', ' PHPを用いて動的Webサイトを構築するために利用するWebアプリケーションフレームワーク', 'http://ellislab.com/codeigniter', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(61, 'library');
insert into product_tag values(61, 'framework');
insert into product_tag values(61, 'php');

insert into product values (62, 'DRBD', ' Linuxプラットフォームにおける分散ストレージシステム', 'http://www.drbd.org/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(62, 'platform');
insert into product_tag values(62, 'filesystem');
insert into product_tag values(62, 'clustering');
insert into product_tag values(62, 'gpl2');
insert into product_license values(1, 62);

insert into product values (63, 'Apache Ant', ' Javaベースのビルドツール。XML文書でビルドのためのルールを記述することが特徴', 'http://ant.apache.org/', '/assets/images/openhub/ant_logo_large_square_med.PNG', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(63, 'tool');
insert into product_tag values(63, 'devenv');
insert into product_tag values(63, 'apache');
insert into product_license values(6, 63);

insert into product values (64, 'lighttpd', ' 軽量・高速・安全性を重視して設計されたWebサーバ。静的なコンテンツの配布に適している', 'http://www.lighttpd.net/', '/assets/images/openhub/light_logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(64, 'middleware');
insert into product_tag values(64, 'webserver');

insert into product values (65, 'Oracle Berkeley DB', 'アプリケーション組み込み型のデータベースライブラリである。現在はオラクルの製品であり、またオープンソースとして公開されている。', 'http://www.oracle.com/technetwork/products/berkeleydb/overview/index.html', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(65, 'library');
insert into product_tag values(65, 'dbms');
insert into product_tag values(65, 'agpl');
insert into product_license values(0, 65);
insert into product_license values(3, 65);

insert into product values (66, 'Amanda Community', 'クロスプラットフォームで動作するバックアップ／リカバリソフトウェア', 'http://www.amanda.org/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(66, 'tool');
insert into product_tag values(66, 'operations');
insert into product_tag values(66, 'backup');
insert into product_tag values(66, 'gpl2');
insert into product_license values(1, 66);

insert into product values (67, 'Compiere Community Edition', ' ERP、CRM、SCM等のアプリケーションパッケージ ', 'http://www.compiere.com/', '/assets/images/openhub/compiere_med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(67, 'application');
insert into product_tag values(67, 'erp');
insert into product_tag values(67, 'gpl2');
insert into product_license values(1, 67);

insert into product values (68, 'OpenVPN', ' 暗号化通信のためのVPN(Virtual Private Network）ソフトウェア', 'http://openvpn.net/', '/assets/images/openhub/openvpn_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_license values(0, 68);
insert into product_license values(1, 68);
insert into product_tag values(68, 'tool');
insert into product_tag values(68, 'security');
insert into product_tag values(68, 'network');
insert into product_tag values(68, 'gpl2');

insert into product values (69, 'Seasar2', ' Javaベースの日本発のアプリケーションフレームワーク。DI（依存性の注入)やAOP（アスペクト指向）などが特徴', 'http://s2container.seasar.org/2.4/ja/index.html', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(69, 'library');
insert into product_tag values(69, 'framework');
insert into product_tag values(69, 'java');
insert into product_tag values(69, 'apache');
insert into product_license values(6, 69);

insert into product values (70, 'OpenSSH', ' SSHプロトコルを実装するソフトウェアで、SSHサーバおよびSSHクライアント。OpenBSDプロジェクトにより開発されている', 'http://www.openssh.org/', '/assets/images/openhub/OpenSSH_logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(70, 'tool');
insert into product_tag values(70, 'security');
insert into product_tag values(70, 'bsd');
insert into product_license values(24, 70);

insert into product values (71, 'Nmap', ' セキュリティスキャナ。ポートスキャン、OSおよびバージョン検出、サービスおよびバージョン検出などの機能を提供する', 'http://nmap.org/', '/assets/images/openhub/nmap-eye1_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(71, 'tool');
insert into product_tag values(71, 'security');
insert into product_tag values(71, 'testing');
insert into product_tag values(71, 'gpl2');
insert into product_license values(1, 71);

insert into product values (72, 'Dovecot', ' Timo Sirainenが開発・公開をしている、UNIXライクなOS上で動作する、POP3サーバおよびIMAPサーバ', 'http://www.dovecot.org/index.html', '/assets/images/openhub/dovecot-64x64_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(72, 'platform');
insert into product_tag values(72, 'mail');
insert into product_tag values(72, 'mit');
insert into product_license values(7, 72);
insert into product_license values(4, 72);

insert into product values (73, 'Apache CouchDB', 'ドキュメント指向データベース管理システム', 'http://couchdb.apache.org/', '/assets/images/openhub/couchdb_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(73, 'middleware');
insert into product_tag values(73, 'dbms');
insert into product_tag values(73, 'apache');
insert into product_license values(6, 73);

insert into product values (75, 'JBoss Seam', ' JavaベースのWebアプリケーションフレームワーク。JSF、Web Beans(JSR-299)など新しい技術仕様が採用されている', 'http://www.seamframework.org/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(75, 'library');
insert into product_tag values(75, 'lgpl');
insert into product_tag values(75, 'java');

insert into product values (76, 'LibreOffice', ' OpenOffice.orgから派生した、オープンソースのオフィススィート', 'http://www.libreoffice.org/', '/assets/images/openhub/LibreOffice_logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(76, 'application');
insert into product_tag values(76, 'officesuite');

insert into product values (77, 'YUI library', ' Yahoo! User Interface Library（略称：YUI）はDOMスクリプティング、DHTMLやAJAXを利用した高機能なWebアプリケーションの開発に用いられる、JavaScriptとCSSで記述されたユーティリティ群', 'http://yuilibrary.com/', '/assets/images/openhub/yui_logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(77, 'library');
insert into product_tag values(77, 'uitoolkit');
insert into product_tag values(77, 'javascript');

insert into product values (78, 'OpenProj', ' Microsoft Projectの代替となるデスクトップアプリケーション。既存のMS Projectファイルを開くことも可能', 'http://sourceforge.net/projects/openproj/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(78, 'application');

insert into product values (79, 'Firebird', ' InterBaseから派生したオープンソースのリレーショナルデータベース管理システム', 'http://www.firebirdsql.org/', '/assets/images/openhub/firebird-logo-64_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(79, 'middleware');
insert into product_tag values(79, 'dbms');

insert into product values (80, 'Scientific Linux', ' フェルミ研究所 (Fermi National Accelerator Laboratory) 及び欧州原子核研究機構 (CERN) によるLinuxディストリビューション。Red Hat Enterprise Linux (RHEL) をベースとしており、高い互換性を持つ。', 'http://www.scientificlinux.org/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(80, 'platform');
insert into product_tag values(80, 'os');
insert into product_tag values(80, 'gpl2');
insert into product_tag values(80, 'distro');
insert into product_license values(1, 80);

insert into product values (81, 'GroundWork Monitor', ' 運用監視ツール。 Nagiosをベースに、GUIでの設定や操作ができたり、取得したリソースデータのグラフ化などの機能が拡張されている。', 'http://www.gwos.com/', '/assets/images/openhub/groundwork_med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(81, 'tool');
insert into product_tag values(81, 'monitoring');

insert into product values (82, 'Pacemaker', ' オープンソースのHA（High Availability 高可用性）クラスタソフトウェア', 'http://www.clusterlabs.org/', '/assets/images/openhub/pacemaker_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(82, 'platform');
insert into product_tag values(82, 'clustering');
insert into product_tag values(82, 'gpl2');
insert into product_tag values(82, 'lgpl');
insert into product_license values(1, 82);
insert into product_license values(4, 82);

insert into product values (83, 'Weka', 'データマイニング／統計解析ツール', 'http://www.cs.waikato.ac.nz/ml/weka/', '/assets/images/openhub/weka_64_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(83, 'application');
insert into product_tag values(83, 'stat-analysis');

insert into product values (84, 'GIMP', ' グラフィック編集ソフト。新規に画像を描くこともできるが、写真の修整や色調変更、合成なども容易に行うことができる。', 'http://www.gimp.org/', '/assets/images/openhub/gimp_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(84, 'application');
insert into product_tag values(84, 'graphics');
insert into product_tag values(84, 'gpl2');
insert into product_license values(1, 84);

insert into product values (85, 'Wireshark', ' Etherealを起源に持つネットワーク・アナライザ・ソフトウェア。', 'http://www.wireshark.org', '/assets/images/openhub/wireshark_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(85, 'tool');
insert into product_tag values(85, 'network');
insert into product_tag values(85, 'gpl2');
insert into product_license values(1, 85);

insert into product values (86, 'jQuery', ' JavaScriptとHTMLの開発を強化するJavaScriptライブラリ', 'http://jquery.com/', '/assets/images/openhub/jquery_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(86, 'library');
insert into product_tag values(86, 'javascript');
insert into product_tag values(86, 'mit');
insert into product_tag values(86, 'uitoolkit');
insert into product_license values(7, 86);

insert into product values (87, 'OpenSSL', ' SSLプロトコル・TLSプロトコルのオープンソース実装。ライブラリとユーティリティを提供している', 'http://www.openssl.org/', '/assets/images/openhub/openssl_button_med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(87, 'tool');
insert into product_tag values(87, 'security');
insert into product_license values(25, 87);

insert into product values (88, 'UltraMonkey-L7', ' 負荷分散機能を提供するソフトウェア。OS7階層モデルの第4層（Layer4）までの情報に基づいた負荷分散ソリューションである従来のUltraMonkeyを応用して、第7層（Layer7）までの情報に基づいた負荷分散機能を実現する。', 'http://sourceforge.jp/projects/ultramonkey-l7/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(88, 'platform');
insert into product_tag values(88, 'network');
insert into product_tag values(88, 'loadbalancer');
insert into product_tag values(88, 'gpl2');
insert into product_tag values(88, 'lgpl');
insert into product_license values(1, 88);
insert into product_license values(4, 88);

insert into product values (89, 'OTRS', ' オープンソース・チケット・リクエスト・システム（Open-source Ticket Request System）。', 'http://otrs.org', '/assets/images/openhub/otrs_twitter_logo_med.jpg', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(89, 'application');
insert into product_tag values(89, 'operations');
insert into product_tag values(89, 'agpl');
insert into product_license values(3, 89);

insert into product values (90, 'Jetty', ' JavaベースのWebアプリケーションサーバ。軽量でありながらWebSocketのようなプロトコルもサポートしている', 'http://www.eclipse.org/jetty/', '/assets/images/openhub/jetty-avatar-64_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(90, 'middleware');
insert into product_tag values(90, 'apserver');
insert into product_tag values(90, 'apache');
insert into product_license values(6, 90);

insert into product values (91, 'OpenStack', ' Rackspace CloudとNASAによって始められたIaaSクラウドコンピューティングプロジェクト', 'http://www.openstack.org/', '/assets/images/openhub/os64_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(91, 'platform');
insert into product_tag values(91, 'cloud');
insert into product_tag values(91, 'apache');
insert into product_license values(6, 91);

insert into product values (92, 'NginX', ' Webサーバ、リバースプロキシサーバ。軽量であることから特にリバースプロキシとしてApache HTTPサーバの代替として導入が進みつつある', 'http://nginx.org/', '/assets/images/openhub/nginx_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(92, 'middleware');
insert into product_tag values(92, 'webserver');
insert into product_tag values(92, 'bsd');
insert into product_license values(12, 92);

insert into product values (93, 'OpsView', ' 運用監視ツール。 Nagiosをベースに、GUIでの設定や操作ができたり、取得したリソースデータのグラフ化などの機能が拡張されている。', 'http://www.opsview.com/', '/assets/images/openhub/OpsView_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(93, 'tool');
insert into product_tag values(93, 'monitoring');
insert into product_tag values(93, 'gpl2');
insert into product_license values(1, 93);

insert into product values (94, 'Pandora FMS', '運用監視ツール。', 'http://pandorafms.com/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(94, 'tool');
insert into product_tag values(94, 'monitoring');
insert into product_tag values(94, 'gpl2');
insert into product_license values(1, 94);

insert into product values (95, 'Fedora', ' Red Hatが支援するコミュニティー「Fedora Project」によって開発されているRPM系Linuxディストリビューション ', 'http://fedoraproject.org/', '/assets/images/openhub/fedora_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(95, 'platform');
insert into product_tag values(95, 'os');
insert into product_tag values(95, 'distro');
insert into product_tag values(95, 'gpl2');
insert into product_license values(1, 95);

insert into product values (96, 'Play framework', ' サーバサイドJavaとScalaのためのMVCフレームワーク', 'http://www.playframework.com/', '/assets/images/openhub/play-icon_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(96, 'library');
insert into product_tag values(96, 'framework');
insert into product_tag values(96, 'java');
insert into product_tag values(96, 'scala');
insert into product_tag values(96, 'apache');
insert into product_license values(6, 96);

insert into product values (97, 'BIND', ' インターネットでもっとも利用されているDNSサーバ', 'https://www.isc.org/software/bind', '/assets/images/openhub/bind_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(97, 'platform');
insert into product_tag values(97, 'network');

insert into product values (98, 'Plone', ' Zopeアプリケーションサーバ上に構築されたフリーかつオープンなコンテンツマネジメントシステム（CMS）', 'http://plone.org/', '/assets/images/openhub/plone-icon-64_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(98, 'application');
insert into product_tag values(98, 'cms');
insert into product_tag values(98, 'python');
insert into product_tag values(98, 'gpl2');
insert into product_license values(1, 98);

insert into product values (99, 'Apache Hbase', 'オープンソースの列指向、分散データベース', 'http://hbase.apache.org/', '/assets/images/openhub/HBase_Logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_license values(6, 99);
insert into product_tag values(99, 'middleware');
insert into product_tag values(99, 'dbms');
insert into product_tag values(99, 'nosql');
insert into product_tag values(99, 'apache');

insert into product values (100, 'Ryu', ' オープンソース実装のOpenFlowコントローラ', 'http://osrg.github.com/ryu/', '/assets/images/openhub/ryu_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(100, 'platform');
insert into product_tag values(100, 'network');
insert into product_tag values(100, 'mit');
insert into product_tag values(100, 'openflow');
insert into product_license values(7, 100);

insert into product values (101, 'Kerberos', ' マサチューセッツ工科大学（MIT） で開発された暗号方式を用いた認証システム', 'http://www.kerberos.org/', '/assets/images/openhub/kerberos_med.jpg', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(101, 'middleware');
insert into product_tag values(101, 'security');
insert into product_license values(7, 101);

insert into product values (102, 'Apache Log4J', ' Javaのロギングユーティリティ', 'http://logging.apache.org/log4j/2.x/', '/assets/images/openhub/log4j-logo_med.jpg', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(102, 'library');
insert into product_tag values(102, 'apache');
insert into product_license values(6, 102);

insert into product values (103, 'Hinemos', ' 運用監視ツール。他の運用監視ツールと比較してジョブ管理まで統合している。', 'http://www.hinemos.info/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(103, 'tool');
insert into product_tag values(103, 'monitoring');
insert into product_tag values(103, 'gpl2');
insert into product_license values(1, 103);

insert into product values (104, 'OpenCms', ' XMLとJavaベースのオープンソースのコンテンツマネージメントシステム (CMS) ', 'http://www.opencms.org', '/assets/images/openhub/OpenCms_Punkt_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(104, 'application');
insert into product_tag values(104, 'cms');
insert into product_tag values(104, 'lgpl');
insert into product_license values(4, 104);

insert into product values (105, 'pgpool-II', ' PostgreSQL対応の多機能クラスタソフトウェア', 'http://www.pgpool.net/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(105, 'middleware');
insert into product_tag values(105, 'clustering');
insert into product_license values(7, 105);

insert into product values (106, 'XOOPS', ' PHPで記載された コンテンツマネージメントシステム(CMS) ', 'http://xoops.org/', '/assets/images/openhub/xoops_med.jpg', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(106, 'application');
insert into product_tag values(106, 'cms');
insert into product_tag values(106, 'php');
insert into product_tag values(106, 'gpl2');
insert into product_license values(1, 106);

insert into product values (107, 'SQLite', 'アプリケーションに組み込んで利用される軽量のデータベース管理システム', 'http://www.sqlite.org/', '/assets/images/openhub/sqlite_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(107, 'middleware');
insert into product_tag values(107, 'dbms');
insert into product_tag values(107, 'publicdomain');
insert into product_license values(9999, 107);

insert into product values (108, 'Trema', ' OpenFlowコントローラを開発するためのRubyおよびC用のプログラミングフレームワーク', 'http://trema.github.com/trema/', '/assets/images/openhub/torema_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(108, 'platform');
insert into product_tag values(108, 'network');
insert into product_tag values(108, 'gpl2');
insert into product_tag values(108, 'openflow');
insert into product_license values(1, 108);

insert into product values (109, 'qmail', ' Unix系オペレーティングシステム (OS) で動作するメール転送エージェント (MTA)', 'http://cr.yp.to/qmail.html', '/assets/images/openhub/qmail_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(109, 'platform');
insert into product_tag values(109, 'mail');
insert into product_license values(9999, 109);

insert into product values (110, 'memcached', '分散型メモリキャッシュシステム', 'http://memcached.org/', '/assets/images/openhub/memcache_logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(110, 'middleware');
insert into product_tag values(110, 'cache');
insert into product_tag values(110, 'nosql');
insert into product_tag values(110, 'bsd');
insert into product_license values(11, 110);

insert into product values (111, 'Xymon', ' 運用監視ツール。 Hobbitから名称が変更されたプロジェクト。', 'http://xymon.sourceforge.net/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(111, 'tool');
insert into product_tag values(111, 'monitoring');
insert into product_tag values(111, 'gpl2');
insert into product_license values(1, 111);

insert into product values (112, 'Selenium IDE', ' Webアプリケーションのためのテスト自動化ツールSeleniumのためのIDE（統合開発環境）。Firefoxのプラグインとして動作する', 'http://seleniumhq.org/', '/assets/images/openhub/selenium-logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(112, 'tool');
insert into product_tag values(112, 'testing');
insert into product_tag values(112, 'apache');
insert into product_license values(6, 112);

insert into product values (113, 'Scala', 'オブジェクト指向言語と関数型言語の特徴を統合したマルチパラダイムのプログラミング言語', 'http://www.scala-lang.org/', '/assets/images/openhub/scala-logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(113, 'language');
insert into product_tag values(113, 'functional');
insert into product_tag values(113, 'object-oriented');
insert into product_tag values(113, 'jvm');
insert into product_license values(11, 113);

insert into product values (114, 'Erlang', '汎用的な用途に使うことができる並行処理指向のプログラミング言語および実行環境。', 'http://www.erlang.org/', '/assets/images/openhub/erlang2_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(114, 'language');
insert into product_tag values(114, 'functional');

insert into product values (115, 'Lua', ' リオデジャネイロ・カトリカ大学の情報工学科コンピュータグラフィックステクノロジーグループ TeCGraf によって設計開発されたスクリプト言語', 'http://www.lua.org/', '/assets/images/openhub/Lua_logo_med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(115, 'language');
insert into product_tag values(115, 'scripting');
insert into product_tag values(115, 'mit');
insert into product_license values(7, 115);

insert into product values (116, 'Perl', ' ラリー・ウォールによって開発されたプログラミング言語。実用性と多様性を重視しており、Cやsed、awk、シェルスクリプトなど他のプログラミング言語の優れた機能を取り入れている ', 'http://www.perl.org/', '/assets/images/openhub/perl_onion_64x64_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(116, 'language');
insert into product_tag values(116, 'scripting');
insert into product_license values(15, 116);
insert into product_license values(1, 116);

insert into product values (117, 'RRDtool', ' 「RRD（Round Robin Database）」と呼ばれるデータベースに時系列のデータを格納し、それをグラフ化するツール', 'http://oss.oetiker.ch/rrdtool/', '/assets/images/openhub/rrdtool-logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_license values(1, 117);
insert into product_tag values(117, 'tool');
insert into product_tag values(117, 'gpl2');

insert into product values (118, 'Bootstrap', ' 米Twitterが公開したCSSおよびJavaScriptから構成されているWebフレームワーク', 'http://getbootstrap.com/', '/assets/images/openhub/twitter-bootstrap_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(118, 'library');
insert into product_tag values(118, 'javascript');
insert into product_tag values(118, 'uitoolkit');
insert into product_tag values(118, 'mit');
insert into product_license values(7, 118);

insert into product values (119, 'Grails', ' プログラミング言語 Groovy をベースにしたWebアプリケーションフレームワーク。', 'http://grails.org/', '/assets/images/openhub/Grail_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(119, 'library');
insert into product_tag values(119, 'jvm');
insert into product_tag values(119, 'apache');
insert into product_license values(6, 119);

insert into product values (120, 'Sendmail', ' UNIX で使われてきたメールサーバソフトウェア', 'http://www.sendmail.com/sm/open_source/', '/assets/images/openhub/sendmail_logo_med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(120, 'platform');
insert into product_tag values(120, 'mail');
insert into product_license values(23, 120);

insert into product values (121, 'Bugzilla', ' Webベースのバグ管理システム', 'http://www.bugzilla.org/', '/assets/images/openhub/Buggie64x64_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(121, 'tool');
insert into product_tag values(121, 'devenv');

insert into product values (122, 'Eclipse', ' Javaで記述されている統合開発環境', 'http://www.eclipse.org/', '/assets/images/openhub/eclipse64_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(122, 'tool');
insert into product_tag values(122, 'devenv');

insert into product values (123, 'Haskell', '非正格な評価を特徴とする純粋関数型プログラミング言語', 'http://www.haskell.org/haskellwiki/Haskell', '/assets/images/openhub/HaskellLogoStyPreview-1_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(123, 'language');
insert into product_tag values(123, 'functional');

insert into product values (124, 'Python', ' オランダ人のグイド・ヴァンロッサムが作ったオープンソースのプログラミング言語。オブジェクト指向スクリプト言語の一種であり、Perlとともに欧米で広く普及している。', 'http://www.python.org/', '/assets/images/openhub/python_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(124, 'language');
insert into product_tag values(124, 'object-oriented');
insert into product_license values(14, 124);

insert into product values (125, 'MongoDB', ' NoSQLの一種である、ドキュメント指向データベース', 'http://www.mongodb.org/', '/assets/images/openhub/mongo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(125, 'middleware');
insert into product_tag values(125, 'dbms');
insert into product_tag values(125, 'agpl');
insert into product_license values(3, 125);

insert into product values (126, 'Meteor', ' Node.jsをベースとし、JavaScriptとHTML+CSSだけでアプリケーションを記述できるWebアプリケーション開発プラットフォーム ', 'http://meteor.com/', '/assets/images/openhub/meteorjs_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(126, 'library');
insert into product_tag values(126, 'framework');
insert into product_tag values(126, 'javascript');
insert into product_tag values(126, 'mit');
insert into product_license values(7, 126);

insert into product values (127, 'Mercurial', 'クロスプラットフォームの分散型バージョン管理システム', 'http://mercurial.selenic.com/', '/assets/images/openhub/mercurial-logo-droplets-150_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(127, 'tool');
insert into product_tag values(127, 'devenv');
insert into product_tag values(127, 'gpl2');
insert into product_license values(1, 127);

insert into product values (128, 'SpiderMonkey', ' 世界初のJavaScriptエンジンのコード名', 'https://developer.mozilla.org/en-US/docs/SpiderMonkey', '/assets/images/openhub/spidermonkey_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(128, 'language');
insert into product_tag values(128, 'javascript');
insert into product_license values(8, 128);
insert into product_license values(1, 128);
insert into product_license values(4, 128);

insert into product values (129, 'Joomla', ' PHPベースのコンテンツマネージメントシステム(CMS)。Mamboから派生', 'http://www.joomla.org/', '/assets/images/openhub/joomla_logo_symbol_50_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(129, 'application');
insert into product_tag values(129, 'cms');
insert into product_tag values(129, 'gpl2');
insert into product_license values(1, 129);

insert into product values (130, 'PHP', ' 動的にHTMLデータを生成することによって、動的なウェブページを実現することを主な目的としたプログラミング言語', 'http://www.php.net/', '/assets/images/openhub/php_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(130, 'language');
insert into product_license values(20, 130);

insert into product values (131, 'NetCommons', ' PHP、MySQLなどの上で動作するコンテンツマネージメントシステム(CMS)であり、国立情報学研究所NetCommonsプロジェクトが開発している', 'http://www.netcommons.org/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(131, 'application');
insert into product_tag values(131, 'cms');
insert into product_tag values(131, 'php');
insert into product_tag values(131, 'bsd');
insert into product_license values(12, 131);

insert into product values (132, 'LifeRay Portal Community Edition', ' 企業ポータル(EIP)を実現するための基盤となるソフトウェア', 'http://www.liferay.com/community/welcome/dashboard', '/assets/images/openhub/liferay_med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(132, 'application');
insert into product_tag values(132, 'cms');
insert into product_tag values(132, 'php');
insert into product_tag values(132, 'lgpl');
insert into product_license values(4, 132);

insert into product values (133, 'node.js', ' イベント化された入出力を扱うUNIX系プラットフォーム上のサーバーサイドJavaScript環境。', 'http://nodejs.org/', '/assets/images/openhub/nodejs_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(133, 'middleware');
insert into product_tag values(133, 'apserver');
insert into product_tag values(133, 'javascript');
insert into product_license values(7, 133);

insert into product values (134, 'MyBATIS', ' JavaベースのORM（オブジェクト関係マッピング）フレームワーク。一時期、Apache Software Foundationで提供されていたiBATISから、プロジェクトが移行された。', 'http://blog.mybatis.org/', '/assets/images/openhub/mybatis_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(134, 'library');
insert into product_tag values(134, 'java');
insert into product_tag values(134, 'lgpl');
insert into product_license values(6, 134);

insert into product values (135, 'Eucalyptus', ' Eucalyptus Systemsが開発する、プライベートクラウド向けクラウド基盤ソフトウェア。IaaS（インフラ・アズ・ア・サービス）に分類される', 'http://www.eucalyptus.com/participate', '/assets/images/openhub/eucalyptus-64x64_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(135, 'platform');
insert into product_tag values(135, 'cloud');
insert into product_tag values(135, 'gpl2');
insert into product_license values(1, 135);

insert into product values (136, 'ImageMagick', ' グラフィック変換ソフト。コマンドラインを利用して、各種フォーマット間の変換や、拡大・縮小・各種フィルタによる効果の追加などを行うことができる。', 'http://www.imagemagick.org/', '/assets/images/openhub/ImageMagick_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(136, 'tool');
insert into product_tag values(136, 'graphics');
insert into product_tag values(136, 'gpl2');
insert into product_license values(1, 136);

insert into product values (137, 'Floodlight', ' 米Big Switch Networksが開発したOpenFlowコントローラ', 'http://floodlight.openflowhub.org/', '/assets/images/openhub/floodlight_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(137, 'platform');
insert into product_tag values(137, 'network');
insert into product_tag values(137, 'apache');
insert into product_tag values(137, 'openflow');
insert into product_license values(6, 137);

insert into product values (138, 'Ruby on Rails', ' RubyベースのWebアプリケーションフレームワーク。MVC（Model View Controler)アーキテクチャを採用している', 'http://rubyonrails.org/', '/assets/images/openhub/rails_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(138, 'library');
insert into product_tag values(138, 'framework');
insert into product_tag values(138, 'ruby');
insert into product_tag values(138, 'mit');
insert into product_license values(7, 138);

insert into product values (139, 'PhoneGap', ' モバイルアプリケーション開発フレームワーク。JavaScript、HTML、CSSを使って、iPhone、Android、Windows Mobileなどさまざまな端末用のモバイルアプリを開発することができる', 'http://phonegap.com/', '/assets/images/openhub/PhoneGap_med.jpeg', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(139, 'library');
insert into product_tag values(139, 'uitoolkit');
insert into product_tag values(139, 'bsd');
insert into product_tag values(139, 'mit');
insert into product_license values(7, 139);
insert into product_license values(11, 139);

insert into product values (140, 'Kernel-based Virtual Machine', ' Linuxカーネル仮想化基盤', 'http://www.linux-kvm.org/page/Main_Page', '/assets/images/openhub/kvm2_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(140, 'platform');
insert into product_tag values(140, 'virtualization');
insert into product_tag values(140, 'gpl2');
insert into product_tag values(140, 'lgpl');
insert into product_license values(1, 140);
insert into product_license values(4, 140);

insert into product values (141, 'GlusterFS', 'スケーラブルなストレージのための汎用分散ファイルシステム。', 'http://www.gluster.org/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(141, 'platform');
insert into product_tag values(141, 'filesystem');
insert into product_tag values(141, 'gpl3');
insert into product_license values(2, 141);

insert into product values (142, 'Heartbeat', ' Linux用高可用クラスター用クラスタ管理プログラム。v2.1.4までは、クラスタリソース制御機能(CRM)も含んでいたが、v3以降は基盤レイヤのみ。CRMとしてPacemakerを組み合わせて使用する。', 'http://www.linux-ha.org/wiki/Main_Page', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(142, 'platform');
insert into product_tag values(142, 'clustering');
insert into product_tag values(142, 'gpl2');
insert into product_tag values(142, 'lgpl');
insert into product_license values(1, 142);
insert into product_license values(4, 142);

insert into product values (143, 'OpenPNE', ' SNSをベースとしたコミュニケーション基盤', 'http://www.openpne.jp/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(143, 'application');
insert into product_tag values(143, 'communication');
insert into product_tag values(143, 'apache');
insert into product_license values(6, 143);

insert into product values (144, 'Infinispan', ' Infinispanは、極めてスケーラブルで高可用性なKey/Value型NoSQLデータストア・分散データグリッドプラットフォーム。JBoss Cache 3.2を起源にするため、最初のリリースバージョンは4.0となっている。', 'https://www.jboss.org/infinispan', '/assets/images/openhub/infinispan_iconupdate_64x_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(144, 'middleware');
insert into product_tag values(144, 'apache');
insert into product_tag values(144, 'cache');
insert into product_tag values(144, 'nosql');
insert into product_license values(6, 144);

insert into product values (145, 'Cyrus IMAP Server', ' カーネギーメロン大学(CMU)で開発されたIMAP準拠のメールおよびニュースサーバ。IMAP、IMAPS、POP3、POP3S、NNTP、TLSなどに対応している。', 'http://cyrusimap.web.cmu.edu/', '/assets/images/openhub/cyrustiny2_1__med.jpg', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(145, 'platform');
insert into product_tag values(145, 'mail');
insert into product_tag values(145, 'gpl2');
insert into product_license values(1, 145);

insert into product values (146, 'Chef', ' サーバの構成管理を容易に反映するためのツール。RubyとErlangで実装されている。', 'http://www.opscode.com/chef/', '/assets/images/openhub/chef_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(146, 'tool');
insert into product_tag values(146, 'config');
insert into product_tag values(146, 'apache');
insert into product_license values(6, 146);

insert into product values (147, 'CVS', ' Concurrent Versions System（コンカレント・バージョンズ・システム、並行バージョンシステム）は、ネットワークでの利用、複数ファイルを対象とした最初のバージョン管理システム。元々は単一のファイルを対象としたRCSをベースとしていたが、現在は依存が無い。', 'http://cvs.nongnu.org/', '/assets/images/openhub/cvs_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(147, 'tool');
insert into product_tag values(147, 'devenv');
insert into product_tag values(147, 'gpl2');
insert into product_tag values(147, 'lgpl');
insert into product_license values(1, 147);
insert into product_license values(4, 147);

insert into product values (148, 'Mantis', ' Kenzaburo Ito氏が開発し、Mantisチームにより開発、メンテナンスされているWebベースのバグ管理システム', 'http://www.mantisbt.org/', '/assets/images/openhub/mantis3_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(148, 'tool');
insert into product_tag values(148, 'devenv');
insert into product_tag values(148, 'gpl2');
insert into product_license values(1, 148);

insert into product values (149, 'Aipo', ' ToDO整理、スケジュール管理、ニュース配信、ブログなどの機能を提供するグループウェア。', 'http://www.aipo.com/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(149, 'application');
insert into product_tag values(149, 'groupware');

insert into product values (150, 'Jaspersoft Studio', ' JasperReportsやJasperReports Serverのための、eclipseベースの帳票デザイナ。', 'http://community.jaspersoft.com/project/jaspersoft-studio', '/assets/images/openhub/Jasper_med.PNG', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(150, 'tool');
insert into product_tag values(150, 'bi');

insert into product values (151, 'Drools Expert', ' Droolsコミュニティで開発されているルールエンジン。製品版としてはJBoss Enterprise BRMSが提供されている。', 'https://www.jboss.org/drools/', '/assets/images/openhub/drools-face-only-logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(151, 'application');
insert into product_tag values(151, 'apache');
insert into product_tag values(151, 'java');
insert into product_license values(6, 151);

insert into product values (152, 'SOS JobScheduler', 'ジョブ管理ソフトウェア', 'http://www.sos-berlin.com/modules/cjaycontent/index.php?id=62&page=osource_scheduler_introduction_en.htm', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(152, 'tool');
insert into product_tag values(152, 'monitoring');
insert into product_tag values(152, 'gpl2');
insert into product_license values(1, 152);

insert into product values (153, 'GateIn Portal', ' エンタープライズWebポータルおよびWebポータルFramework。 製品はJBoss Enterprise Portal Platform。', 'http://www.jboss.org/gatein', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(153, 'application');
insert into product_tag values(153, 'cms');
insert into product_tag values(153, 'lgpl');
insert into product_license values(4, 153);

insert into product values (154, 'vtiger CRM', ' vtiger社が中心となり開発が進められているコミュニティ駆動型 オープンソースCRMソフトウェア。', 'https://www.vtiger.com/crm/', '/assets/images/openhub/vtiger_med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(154, 'application');
insert into product_tag values(154, 'crm');
insert into product_license values(8, 154);

insert into product values (155, 'MosP', ' Web勤怠管理・人事給与システム ', 'http://www.mosp.jp/', '/assets/images/openhub/default.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_license values(3, 155);
insert into product_tag values(155, 'application');

insert into product values (156, 'OpenVAS', ' OpenVAS（Open Vulnerability Assessment System）は、脆弱性スキャン機能や脆弱性管理機能をもつ複数のサービスやツールから構成される脆弱性評価フレームワーク。Nessusから派生。', 'http://www.openvas.org/', '/assets/images/openhub/openvas_logo_med.png', '', '2014-12-09 00:00:00', 999, true); 
insert into product_license values(1, 156);
insert into product_tag values(156, 'tool');
insert into product_tag values(156, 'security');
insert into product_tag values(156, 'gpl2');

insert into product values (157, 'Zimbra Collaboration Server', ' 企業・サービスプロバイダ向け次世代型メールプラットフォーム。 電子メールやアドレス帳、スケジューラー、ドキュメントなどを標準装備するとともに、外部アプリケーションなどとのWeb上での統合や連携を実現するマッシュアップ機能を備えた、操作性の高いWeb統合コラボレーションスイートであり、 Webメールでありながら、Ajax技術の採用により、ドラッグ&ドロップ、右クリックメニュー、マウスオーバーなど、一般的なメールソフトと同等の操作性を実現。', 'http://www.zimbra.com/', '/assets/images/openhub/zimbra__med.gif', '', '2014-12-09 00:00:00', 999, true); 
insert into product_tag values(157, 'application');
insert into product_tag values(157, 'groupware');
insert into product_tag values(157, 'mail');
insert into product_license values(26, 157);

insert into release values (1, '9.3.4', 'バージョン9.3.4の概要', 1, '2014-09-09', true, true, false);
insert into release values (16, '9.3.5', 'バージョン9.3.5の概要', 1, '2014-07-24', true, true, true);
insert into release values (17, '9.4 Beta 3', 'バージョン9.4 Beta3の概要', 1, '2014-10-09', false, true, true);
insert into release values (18, '9.2.9', 'バージョン9.2.9です', 1, '2014-07-24', true, true, true);
insert into release values (19, '9.1.14', 'バージョン9.1.14です', 1, '2014-07-24', true, true, true);
insert into release values (20, '9.0.18', 'バージョン9.0.18です', 1, '2014-07-24', true, true, true);
insert into release values (21, '8.4.22', 'バージョン8.4.22です', 1, '2014-07-24', true, true, true);

insert into release values (2, '10.0', 'バージョン10.0の概要', 2, '2014-09-09', true, true, true);
insert into release values (3, '2.2', 'バージョン２.２の概要', 3, '2014-09-09', true, true, true);
insert into release values (4, '7.5', 'バージョン7.5の概要', 4, '2014-09-09', true, true, true);
insert into release values (5, '2.2.27', 'バージョン2.2.27の概要', 5, '2014-09-09', true, true, false);
insert into release values (6, '2.4.9', 'バージョン2.4.9の概要', 5, '2014-09-09', true, true, true);
insert into release values (7, '4.1.0', 'バージョン4.1.0の概要', 6, '2014-09-09', true, true, true);
insert into release values (8, '4.0.6', 'バージョン4.0.6の概要', 7, '2014-09-09', true, true, true);
insert into release values (9, '3.5.1', 'バージョン3.5.1の概要', 7, '2014-09-09', true, true, false);
insert into release values (10, '4.1.17', 'バージョン4.1.17の概要', 8, '2014-09-09', true, true, true);
insert into release values (11, '4.0.17', '4.0.17バージョン概要', 8, '2014-09-09', true, true, false);
insert into release values (12, '3.6.23', 'バージョン3.6.23の概要', 8, '2014-09-09', true, true, true);
insert into release values (13, '2.1.2', 'バージョン2.1.2の概要', 9, '2014-09-09', true, true, true);
insert into release values (14, '2.0.0-p481', 'バージョン2.0.0-p481の概要', 9, '2014-09-09', true, true, true);
insert into release values (15, '1.9.3-p547', 'バージョン1.9.3-p547の概要', 9, '2014-09-09', true, true, true);

insert into medium values (1, 'binary installer', 'http://www.enterprisedb.com/postgresql-9351-installers-win64?ls=Crossover&type=Crossover', 'Windows(64bit)', 0, 1);
insert into medium values (2, 'binary installer', 'http://www.enterprisedb.com/postgresql-9351-installers-win32?ls=Crossover&type=Crossover', 'Windows(32bit)', 0, 1);
insert into medium values (3, 'ISO image', 'ftp://ftp.freebsd.org/pub/FreeBSD/releases/i386/i386/ISO-IMAGES/10.0/', 'Intel 32bit', 0, 2);
insert into medium values (4, 'ISO image', 'ftp://ftp.freebsd.org/pub/FreeBSD/releases/ia64/ia64/ISO-IMAGES/10.0/', 'Intel 64bit', 0, 2);
insert into medium values (5, 'ISO image', 'ftp://ftp.freebsd.org/pub/FreeBSD/releases/amd64/amd64/ISO-IMAGES/10.0/', 'AMD 64bit', 0, 2);
insert into medium values (6, 'gzipped tar', 'https://download.moodle.org/download.php/stable27/moodle-latest-27.tgz', 'generic', 0, 3);
insert into medium values (7, 'zip', 'https://download.moodle.org/download.php/stable27/moodle-latest-27.zip', 'generic', 0, 3);
insert into medium values (8, 'netinst ISO image', 'http://cdimage.debian.org/debian-cd/7.6.0/i386/iso-cd/debian-7.6.0-i386-netinst.iso', 'Intel 32bit', 0, 4);
insert into medium values (9, 'netinst ISO image', 'http://cdimage.debian.org/debian-cd/7.6.0/ia64/iso-cd/debian-7.6.0-ia64-netinst.iso', 'Intel 64bit', 0, 4);
insert into medium values (10, 'netinst ISO image', 'http://cdimage.debian.org/debian-cd/7.6.0/amd64/iso-cd/debian-7.6.0-amd64-netinst.iso', 'AMD 64bit', 0, 4);
insert into medium values (11, 'ISO image', 'http://cdimage.debian.org/debian-cd/7.6.0/ia64/iso-cd/debian-7.6.0-ia64.iso', 'Intel 64bit', 0, 4);
insert into medium values (12, 'ISO image', 'http://cdimage.debian.org/debian-cd/7.6.0/amd64/iso-cd/debian-7.6.0-amd64.iso', 'AMD 64bit', 0, 4);
insert into medium values (13, 'ISO image', 'http://cdimage.debian.org/debian-cd/7.6.0/i386/iso-cd/debian-7.6.0-i386.iso', 'Intel 32bit', 0, 4);
insert into medium values (14, 'source tarball', 'http://ftp.kddilabs.jp/infosystems/apache//httpd/httpd-2.4.10.tar.gz', 'generic', 0, 5);
insert into medium values (15, 'binary installer', 'http://ftp.kddilabs.jp/infosystems/apache//httpd/binaries/win32/httpd-2.2.25-win32-x86-no_ssl.msi', 'Windows 32bit', 0, 5);
insert into medium values (16, 'binary installer', 'http://sourceforge.net/projects/openofficeorg.mirror/files/4.1.1/binaries/ja/Apache_OpenOffice_4.1.1_Win_x86_install_ja.exe/download', 'Windows', 0, 6);
insert into medium values (17, 'source tarball', 'http://www.samba.org/samba/ftp/samba-latest.tar.gz', 'generic', 0, 8);
insert into medium values (18, 'source tarball', 'http://cache.ruby-lang.org/pub/ruby/2.1/ruby-2.1.2.tar.gz', 'generic', 0, 13);
insert into medium values (19, 'binary MSI', 'http://www.artonx.org/data/asr/Ruby-2.1.msi', 'Windows 32', 0, 13);
insert into medium values (20, 'binary exe', 'http://dl.bintray.com/oneclick/rubyinstaller/rubyinstaller-2.0.0-p481.exe?direct', 'mingw32', 0, 14);
insert into medium values (21, 'source tarball', 'http://cache.ruby-lang.org/pub/ruby/2.0/ruby-2.0.0-p481.tar.gz', 'generic', 0, 14);
insert into medium values (22, 'binary exe', 'http://dl.bintray.com/oneclick/rubyinstaller/rubyinstaller-1.9.3-p545.exe?direct', 'mingw32', 0, 15);
insert into medium values (23, 'binary exe', 'https://s3.amazonaws.com/railsinstaller/Windows/railsinstaller-2.2.4.exe', 'win32', 0, 15);
insert into medium values (24, 'binary app', 'https://s3.amazonaws.com/railsinstaller/OSX/RailsInstaller-1.0.4-osx-10.7.app.tgz', 'Mac OS X', 0, 15);
insert into medium values (25, 'source tarball', 'http://cache.ruby-lang.org/pub/ruby/1.9/ruby-1.9.3-p547.tar.gz', 'generic', 0, 15);

insert into license_term values(1, 1, '義務', '再配布時に同じライセンスを用いること', '再配布先がソースコードを入手できるようにする必要があります'); 
insert into license_term values(2, 1, '義務', 'リンクするプログラムの再配布時に同じライセンスを用いること', '逆に言うならば、独自のライセンスで配布したいプログラムはこのOSSをリンクしてはいけません'); 

insert into license_term values(3, 2, '義務', '再配布時に同じライセンスを用いること', '再配布先がソースコードを入手できるようにする必要があります'); 
insert into license_term values(4, 2, '義務', 'リンクするプログラムの再配布時に同じライセンスを用いること', '逆に言うならば、独自のライセンスで配布したいプログラムはこのOSSをリンクしてはいけません'); 
insert into license_term values(5, 2, '禁止', 'デジタル著作権管理（DRM）機能の組み込み', ''); 
insert into license_term values(6, 3, '義務', 'ネット上で公開するサービスのユーザーにも同じライセンスで許諾すること', '逆に言うならば、独自のライセンスでサービス提供したいプログラムはこのOSSをリンクしてはいけません'); 
insert into license_term values(7, 4, '義務', 'このOSSのデバッグ目的での対向プログラムのリバースエンジニアリングを許可すること', ''); 
insert into license_term values(8, 5,  '義務', 'このOSSのデバッグ目的での対向プログラムのリバースエンジニアリングを許可すること', ''); 
insert into license_term values(9, 1, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(10, 2, '権利', '用途を問わず、コピー・改変・再配布すること','ただし再配布時の条件を順守すること'); 
insert into license_term values(11, 3, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(12, 4, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(13, 5, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(14, 6, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(15, 7, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(16, 8, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(17, 10, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(18, 11, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(19, 12, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(20, 13, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(21, 14, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(22, 15, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(23, 16, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(24, 17, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(25, 18, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(26, 19, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(27, 20, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  
insert into license_term values(28, 21, '権利', '用途を問わず、コピー・改変・再配布すること', 'ただし再配布時の条件を順守すること');  

# --- !Downs
delete from product_tag;
delete from product_license;
delete from product;
delete from license;
delete from tag;
delete from organization;
delete from release;
delete from product_history;
delete from license_term;
delete from services_provider;
delete from maintenance_request;
