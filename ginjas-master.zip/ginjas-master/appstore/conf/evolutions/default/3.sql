# ---  crude test/stub data to be removed in production

# --- !Ups
insert into team values (0, '', 0, false);
insert into team values (1, '金融事業部門', 0, true);
insert into team values (2, '産業事業部門', 0, true);
insert into team values (3, 'コーポレート部門', 0, true);
insert into team values (4, '金融システム第1事業本部', 1, true);
insert into team values (5, '第1開発部', 4, false);
insert into team values (6, '第2開発部', 4, false);
insert into team values (7, '第3開発部', 4, false);
insert into team values (8, 'R&Dセンター', 3, true);
insert into team values (9, 'OSS戦略企画室', 8, true);

alter sequence team_seq restart with 10 increment by 1;

insert into GinjasUser values (0, 'root', 'passw0rd', 'ginjas', 'administrator', 'admin', true, 9, 0);
insert into GinjasUser values (1, 'user0', 'password0', '勇座', '一郎', '名無しさん', false, 5, 1);
insert into GinjasUser values (2, 'user1', 'password1',  '有座', '二郎', 'オレオレ、オレだよ、名無しだよ', false, 6, 0);
insert into GinjasUser values (3, 'user2', 'password2', '夕座', '三郎', '名無しさん＠オープン', false, 7, 0);
insert into GinjasUser values (4, 'user3@example.com', 'password3', 'foo', 'bar', 'user3@example.com', false, 0, 0);

alter sequence user_seq restart with 5 increment by 1;

insert into project values (1, 'F2015BK001', '海外送金管理システム開発', 'あれこれなにそれ', '2014-10-01 00:00:00', '2015-10-01 00:00:00', false);
insert into project values (2, 'F2015IS002', '9Lives生命様向け保険設計システム開発', 'あれこれなにそれ', '2012-09-01 00:00:00', '2013-6-30 00:00:00', false);
insert into project values (3, 'F2015NB003', 'オレオレファイナンス様向け限度額判定システム', 'あれこれなにそれ', '2010-09-01 00:00:00', '2014-6-30 00:00:00', false);
insert into project values (4, 'R2015PH001', 'ヤケタ製薬MRaid', 'あれこれなにそれ', '2011-04-01 00:00:00', '2012-10-01 00:00:00', true);
insert into project values (5, 'R2015CT001', '真鶴ケーブルTV基幹システム再構築', 'あれこれなにそれ', '2013-04-01 00:00:00', '2016-03-31 00:00:00', false);
alter sequence project_seq restart with 6 increment by 1;

insert into project_user values(1, 3);
insert into project_user values(1, 2);
insert into project_user values(1, 1);
insert into project_user values(1, 4);
insert into project_user values(1, 5);

insert into product_topic values (1, 9, 14, '2014-10-01', 0, 'Ruby 2.0.0-p576 リリース', '現在、日本では RubyKaigi2014 が開催されていますが、それに合わせて Ruby 2.0.0-p576 がリリースされました。', 'https://www.ruby-lang.org/ja/news/2014/09/19/ruby-2-0-0-p576-is-released/', true);
insert into product_topic values (2, 9, 15, '2014-09-18', 0, 'Ruby 1.9.2-p330 リリース', 'Ruby 1.9.2-p330 がリリースされました。これは 1.9.2 系列の最後のリリースになるでしょう。', 'https://www.ruby-lang.org/ja/news/2014/08/19/ruby-1-9-2-p330-released/', true);
insert into product_topic values (3, 1, 1, '2014-10-09', 0, '9.4 beta3リリース', 'The PostgreSQL Global Development Group is pleased to announce the availability of PostgreSQL 9.4 Beta 3, the third beta release of the upcoming 9.4 version.', 'http://www.postgresql.org/about/news/1547/', true);
insert into product_topic values (4, 2, 2, '2014-09-16', 1, 'FreeBSD-SA-14:19.tcp', '', 'https://security.freebsd.org/advisories/FreeBSD-SA-14:19.tcp.asc', true);
insert into product_topic values (5, 2, 2, '2014-09-09', 1, 'FreeBSD-SA-14:18.openssl', '', 'https://security.freebsd.org/advisories/FreeBSD-SA-14:18.openssl.asc', true);
insert into product_topic values (6, 2, 2, '2014-07-08', 1, 'FreeBSD-SA-14:17.kmem', '', 'https://security.freebsd.org/advisories/FreeBSD-SA-14:17.kmem.asc', true);
insert into product_topic values (7, 2, 2, '2014-10-13', 0, 'FreeBSD 10.1-RC2 Available', '', 'https://www.freebsd.org/ja/news/newsflash.html#event20141013:01', true);
insert into product_topic values (8, 2, 2, '2014-10-04', 0, 'FreeBSD 10.1-RC1 公開', '', 'https://www.freebsd.org/ja/news/newsflash.html#event20141004:01', true);
insert into product_topic values (9, 3, 3, '2014-06-16', 2, 'Debian 6 が初めて長期サポート期間に入りました', 'Debian プロジェクトは、Debian GNU/Linux 6.0 (コード名 squeeze) 向けのセキュリティ更新を2016年2月まで提供するための長期サポート (Long Term Support、LTS)基盤が始まったことを発表できて嬉しく思います。 このバージョンのユーザは LTS wiki ページの指示に従ってLTSセキュリティ更新を確実に取得できるようにしてください。', 'https://www.debian.org/News/2014/20140616', true);
insert into product_topic values (10, 3, 3, '2014-10-08', 1, 'DSA-3048 apt', '', 'https://www.debian.org/security/2014/dsa-3048', true);
insert into product_topic values (11, 3, 3, '2014-10-08', 1, 'DSA-3047 rsyslog ', '', 'https://www.debian.org/security/2014/dsa-3047', true);
insert into product_topic values (12, 3, 3, '2014-09-08', 3, 'FSF and Debian join forces to help free software users find the hardware they need', '', 'https://www.debian.org/News/2014/20140908', true);
insert into product_topic values (13, 3, 3, '2014-07-12', 0, 'Debian 7 更新: 7.6 リリース', '', 'https://www.debian.org/News/2014/20140712', true);
insert into product_topic values (14, 3, 3, '2014-07-19', 0, 'Debian 6.0 更新: 6.0.10 リリース', '', 'https://www.debian.org/News/2014/20140719', true);

insert into product_review values (1, 1, '2014-10-14', 5.0, 'redistribute', '', '最近のバージョンの性能には満足しています。これでJSONサポートが充実すれば、Mongoに逃げてる部分を巻き取れるかも');
insert into product_review values (1, 2, '2014-10-01', 3.0, 'redistribute', '', 'わたなべさんて人からMySQL5.5のバンドル駄目出しされて乗り換えたけどパラメータ設定ややこしすぎ');
insert into product_review values (1, 1, '2013-02-09', 4.0, 'privateuse', '', '勉強がてらのOracle技術者です。かなりいいかんじになってきています');
insert into product_review values (1, 2, '2011-03-11', 3.0, 'redistribute', '', 'パッケージの不具合究明のために入手しました。再現できなくて困っています');
insert into product_review values (1, 3, '2009-12-22', 2.5, 'redistribute', '', 'オートバキュームってかえってややこしい');
insert into product_review values (1, 3, '2003-01-19', 0.5, 'redistribute', '', '夜間バッチ後にバキュームかけたら開局時刻はみでた。殺す');
insert into product_review values (3, 1, '2012-05-29', 3.5, 'privateuse', '', '教授から無茶振りされた素人のポスドクですが、2時間で立ち上げられました');
insert into product_review values (4, 1, '2014-06-22', 5.0, 'privateuse', '', 'Debian以外のdistroは糞です');
insert into product_review values (5, 2, '2014-08-05', 4.0, 'privateuse', '', 'まったく不満なし');
insert into product_review values (5, 3, '2014-08-05', 3.5, 'redistribute', '', 'コンフィグのサンプルとかあればいいのに…');
insert into product_review values (6, 3, '2014-02-28', 5.0, 'privateuse', '', 'Officeスイートの最高峰です');
insert into product_review values (6, 3, '2014-02-27', 0.0, 'privateuse', '', 'LibreOfficeだけでいい');

# --- !Downs
delete from GinjasUser;
delete from product_topic;
delete from product_review;
delete from team;
delete from project;
