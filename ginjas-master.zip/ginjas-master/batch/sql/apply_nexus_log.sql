\encoding utf8

WITH data AS (
SELECT
  nexus_log.id as id, 
  product.id as product_id, 
  release.seq as release_seq, 
  medium.seq as medium_seq, 
--  medium.url, 
--  product.name, 
--  release.version, 
--  release.description,
  ginjasuser.id as user_id,
  CASE WHEN ginjasuser.current_project_id is null THEN -1 ELSE ginjasuser.current_project_id END as project_id,
  0 as purpose,
  'maven2ダウンロード' as text,
  time as download_date,
  time as last_update
FROM 
  public.product, 
  public.release, 
  public.medium, 
  public.nexus_log,
  ginjasuser
WHERE 
  product.id = release.product_id AND
  release.seq = medium.release_id AND
  medium.url = record->0->>'path' AND
  ginjasuser.username = record->0->>'user' AND
  imported = false
), update_id AS (
UPDATE nexus_log SET imported = true FROM (SELECT id FROM data) data WHERE nexus_log.id = data.id
RETURNING nexus_log.id
), insert_data AS (
INSERT INTO download_history (product_id, release_seq, medium_seq, user_id, project_id, purpose, text, download_date, last_update)
SELECT product_id, release_seq, medium_seq, user_id, project_id, purpose, text, download_date, last_update FROM data
RETURNING user_id, project_id, product_id, release_seq, download_date
)
INSERT INTO user_product (user_id, project_id, product_id, release_seq, started_on)
SELECT user_id, project_id, product_id, release_seq, min(download_date) FROM insert_data i
WHERE /* project_id <> -1 AND */ 
NOT EXISTS (SELECT user_id, project_id, product_id, release_seq FROM user_product WHERE user_id = i.user_id AND project_id = i.project_id AND product_id = i.product_id AND release_seq =i.release_seq)
GROUP BY user_id, project_id, product_id, release_seq
