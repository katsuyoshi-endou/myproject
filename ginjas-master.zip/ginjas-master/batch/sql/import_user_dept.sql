-- \set dept_csvfile 'd:\\dev\\PostgreSQL\\9.4\\data\\dept.csv'
-- \set emp_csvfile 'd:\\dev\\PostgreSQL\\9.4\\data\\emp.csv'
\encoding utf8

-- ユーザと部署との関連を一旦削除
DELETE FROM user_dept;

-- 部門CSVファイルからdeptをUPSERT
CREATE TEMP TABLE tdept (code text, name1 text, name2 text, name3 text, name4 text, name5 text, name6 text, name7 text, name8 text, date1 text, date2 text);
COPY tdept FROM :'dept_csv' (FORMAT CSV, NULL '', HEADER true, ENCODING 'utf-8');

WITH data AS (
	SELECT code,
	  CASE length(code) WHEN 2 THEN name1
	                    WHEN 4 THEN name1
	                    WHEN 6 THEN name2
	                    WHEN 8 THEN name3
	                    ELSE name4 END AS name,
	  CASE WHEN name1 = name2 AND name2 = name3 THEN name1 || ' ' || name4
	       WHEN name1 = name2 THEN name1 || ' ' || name3 || ' ' || name4
	       WHEN name2 = name3 THEN name1 || ' ' || name2 || ' ' || name4
	       ELSE name1 || ' ' || name2 || ' ' || name3 || ' ' || name4 END AS full_name
	FROM tdept ORDER BY code
) , update_result AS (
    UPDATE dept SET name = data.name, full_name = trim(data.full_name), is_available = true FROM data
      WHERE dept.code = data.code RETURNING dept.code, dept.name
)
    INSERT INTO dept (code, name, full_name)
        SELECT data.code, data.name, data.full_name FROM data
          WHERE data.code NOT IN (SELECT code from update_result)
;

-- 組織階層の設定
UPDATE dept AS d SET parent_id = (SELECT id FROM dept WHERE dept.code = substr(d.code, 1,2)) WHERE length(code) = 4;
UPDATE dept AS d SET parent_id = (SELECT id FROM dept WHERE dept.code = substr(d.code, 1,4)) WHERE length(code) = 6;
UPDATE dept AS d SET parent_id = (SELECT id FROM dept WHERE dept.code = substr(d.code, 1,6)) WHERE length(code) = 8;
UPDATE dept AS d SET parent_id = (SELECT id FROM dept WHERE dept.code = substr(d.code, 1,8)) WHERE length(code) = 10;

-- 社員CSVからginjasuserをUPSERT
CREATE TEMP TABLE emp (cd text, name text, email text, dept text, kubun text, d1 text, d2 text, d3 text, d4 text, d5 text, d6 text, d7 text);

COPY emp from :'emp_csv' (FORMAT CSV, NULL '', HEADER true, ENCODING 'utf-8');

WITH data as (
	 SELECT DISTINCT cd, split_part(name, ' ', 1) as family_name, split_part(name, ' ', 2) as first_name, email FROM emp ORDER BY cd
), update_result as (
	 UPDATE ginjasuser SET username = data.cd, family_name = data.family_name, first_name = data.first_name, email = data.email, is_available = true FROM data
	   WHERE ginjasuser.username = data.cd RETURNING username
)
	INSERT INTO ginjasuser (id, username, family_name, first_name, email)
		SELECT nextval('user_seq'), data.cd, data.family_name, data.first_name, data.email FROM data
		  WHERE data.cd NOT IN (SELECT username FROM update_result)
;

-- ユーザと部署との関連定義
INSERT INTO user_dept (user_id, dept_id, is_primary_dept)
SELECT u.id, d.id, CASE e.kubun WHEN '主務' THEN true ELSE false END FROM ginjasuser u, dept d, emp e
WHERE u.username = e.cd AND d.code = e.dept;
