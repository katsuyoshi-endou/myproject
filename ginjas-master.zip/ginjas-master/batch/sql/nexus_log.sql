-- Sequence: public.nexus_log_id_seq

-- DROP SEQUENCE public.nexus_log_id_seq;

CREATE SEQUENCE public.nexus_log_id_seq
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
ALTER TABLE public.nexus_log_id_seq
  OWNER TO postgres;

-- Table: public.nexus_log

-- DROP TABLE public.nexus_log;

CREATE TABLE public.nexus_log
(
  id bigint NOT NULL DEFAULT nextval('nexus_log_id_seq'::regclass),
  tag text,
  record jsonb,
  "time" timestamp with time zone,
  imported boolean NOT NULL DEFAULT false,
  CONSTRAINT json_test_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.nexus_log
  OWNER TO postgres;
