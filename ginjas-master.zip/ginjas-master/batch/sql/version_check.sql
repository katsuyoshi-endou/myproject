-- Function: public.version_check(text, text)

-- DROP FUNCTION public.version_check(text, text);

CREATE OR REPLACE FUNCTION public.version_check(
    v1 text,
    v2 text)
  RETURNS boolean AS
$BODY$
BEGIN
	IF v1 = v2 THEN
		RETURN True;
	ELSIF lower(translate(v1, '-_ ', '')) = lower(translate(v2, '-_ ', '')) THEN
		RETURN True;
	ELSE
		RETURN False;
	END IF;
END;$BODY$
LANGUAGE plpgsql;