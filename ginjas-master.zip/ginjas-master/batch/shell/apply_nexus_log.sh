#! /bin/sh
PSQL=/cygdrive/d/dev/PostgreSQL/9.6/bin/psql
$PSQL \
    -X \
    -U postgres \
#    -h localhsot \
    -f ../sql/apply_nexus_log.sql \
    --echo-all \
    --single-transaction \
    --set AUTOCOMMIT=off \
    --set ON_ERROR_STOP=on \
    appdb
