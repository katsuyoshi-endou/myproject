#! /bin/sh
DEPT_CSV='d:/dev/PostgreSQL/9.4/data/dept.csv'
EMP_CSV= 'd:/dev/PostgreSQL/9.4/data/emp.csv'
PSQL=/cygdrive/d/dev/PostgreSQL/9.4/bin/psql
$PSQL \
    -X \
    -U postgres \
#    -h localhsot \
    -f ../sql/import_user_dept.sql \
    --echo-all \
    --single-transaction \
    --set AUTOCOMMIT=off \
    --set ON_ERROR_STOP=on \
    --variable=dept_csv=$DEPT_CSV \
    --variable=emp_csv=$EMP_CSV \
    appdb


