/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CstSheetSrchRsltDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String loginPersonId;
    private String sheetId;
    private String ownGuid;

    public String getLoginPersonId() {
        return loginPersonId;
    }

    public void setLoginPersonId(String loginPersonId) {
        this.loginPersonId = loginPersonId;
    }

    public String getSheetId() {
        return sheetId;
    }

    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    public String getOwnGuid() {
        return ownGuid;
    }

    public void setOwnGuid(String ownGuid) {
        this.ownGuid = ownGuid;
    }

}

