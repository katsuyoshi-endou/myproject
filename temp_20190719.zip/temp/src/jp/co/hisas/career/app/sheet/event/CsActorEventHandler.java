package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.dao.CsmSheetActorDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetActorDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetActorRefDao;
import jp.co.hisas.career.app.sheet.dao.CstSheetDao;
import jp.co.hisas.career.app.sheet.dao.VCstSheetActorAndRefDao;
import jp.co.hisas.career.app.sheet.dto.CsmSheetActorDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetActorDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetActorRefDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActorAndRefDto;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.OneColumnDao;
import jp.co.hisas.career.util.log.Log;

public class CsActorEventHandler extends AbstractEventHandler<CsActorEventArg, CsActorEventResult> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static CsActorEventResult exec( CsActorEventArg arg ) throws CareerException {
		CsActorEventHandler handler = new CsActorEventHandler();
		return handler.call( arg );
	}
	
	public CsActorEventResult call( CsActorEventArg arg ) throws CareerException {
		CsActorEventResult result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CsActorEventResult execute( CsActorEventArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		CsActorEventResult result = new CsActorEventResult();
		
		try {
			
			if ("LIST_ACT".equals( arg.sharp )) {
				
				List<VCstSheetActorAndRefDto> actorList = selectActors( arg.sheetId );
				List<String> holdActorList = selectHoldActors( arg.sheetId );
				result.setActorList( actorList );
				result.setHoldActorList( holdActorList );
			}
			else if ("LIST_REF".equals( arg.sharp )) {
				
				List<VCstSheetActorAndRefDto> refererList = selectReferers( arg.sheetId );
				List<CsmSheetActorDto> refererMasterList = selectRefMasterList( arg.sheetId );
				Map<Integer, VCstSheetActorAndRefDto> refererMap = new LinkedHashMap<Integer, VCstSheetActorAndRefDto>();
				// 画面からどのデータに対して変更をするのかを特定するためにインデックスを付加
				for (int i = 0 ; i < refererList.size() ; i++ ) {
					refererMap.put( i, refererList.get( i ) );
				}
				result.setRefererMap( refererMap );
				result.setRefererMasterList( refererMasterList );
			}
			else if ("LIST_ACTREF".equals( arg.sharp )) {
				
				List<VCstSheetActorAndRefDto> actorList = selectActAndRef( arg.sheetId );
				result.setActorList( actorList );
			}
			else if ("CHG_ACT".equals( arg.sharp )) {
				
				CstSheetActorDao dao1 = new CstSheetActorDao( this.loginNo );
				dao1.delete( arg.sheetId, arg.actorCd );
				CstSheetActorDao dao2 = new CstSheetActorDao( this.loginNo );
				CstSheetActorDto dto = new CstSheetActorDto();
				dto.setSheetId( arg.sheetId );
				dto.setActorCd( arg.actorCd );
				dto.setGuid( arg.personId );
				dto.setAutoFlg( "0" );
				dao2.insert( dto );
			}
			else if ("DEL_ACT".equals( arg.sharp )) {
				CstSheetActorDao dao = new CstSheetActorDao( this.loginNo );
				CstSheetActorDto dto = new CstSheetActorDto();
				dto.setSheetId( arg.sheetId );
				dto.setActorCd( arg.actorCd );
				dto.setGuid( null );
				dto.setAutoFlg( "0" );
				dao.update( dto );
			}
			else if ("ADD_REF".equals( arg.sharp )) {
				CstSheetActorRefDao dao = new CstSheetActorRefDao( this.loginNo );
				CstSheetActorRefDto existDto = dao.select( arg.sheetId, arg.actorCd, arg.personId );
				if (existDto != null) {
					// すでに登録されています。
					result.resultMessageId = "LSHSAR_MSG_ALREADY_REGISTERED";
				} else {
					CstSheetActorRefDto dto = new CstSheetActorRefDto();
					dto.setSheetId( arg.sheetId );
					dto.setActorCd( arg.actorCd );
					dto.setGuid( arg.personId );
					dto.setAutoFlg( "0" );
					dao.insert( dto );
				}
			}
			else if ("DEL_REF".equals( arg.sharp )) {
				CstSheetActorRefDao dao = new CstSheetActorRefDao( this.loginNo );
				dao.delete( arg.sheetId, arg.actorCd, arg.personId );
			}
			else if ("UPD_ALL_ACT".equals( arg.sharp )) {
				clearAllActorsExceptJinji( arg.sheetId );
				CstSheetActorDao dao = new CstSheetActorDao( this.loginNo );
				for (CstSheetActorDto dto : arg.actorList) {
					dao.insert( dto );
				}
				changeSheetFlowPtn( arg.sheetId, arg.flowptn );
				changeSheetStatus( arg.sheetId, arg.flowCd, arg.flowptn );
				
				// 変更しました。
				result.resultMessageId = "LSHSAR_MSG_UPD_ALL_ACT_DONE";
			}
			
			return result;
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
	}
	
	private void clearAllActorsExceptJinji( String sheetId ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " delete from CST_SHEET_ACTOR where SHEET_ID = ? and ACTOR_CD <> 'act-jinji' " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		
		CstSheetActorDao dao = new CstSheetActorDao( this.loginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private void changeSheetFlowPtn( String sheetId, String flowPtn ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " update CST_SHEET set FLOW_PTN = ? where SHEET_ID = ? " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( flowPtn );
		paramList.add( sheetId );
		
		CstSheetDao dao = new CstSheetDao( this.loginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private void changeSheetStatus( String sheetId, String flowCd, String flowPtn ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " update CST_SHEET " );
		sql.append( "    set STATUS_CD = ( " );
		sql.append( "          select RECEIVE_STATUS_CD from CSM_FLOW_PTN " );
		sql.append( "           where FLOW_CD = ? and FLOW_PTN = ? " );
		sql.append( "        ) " );
		sql.append( "  where SHEET_ID = ? " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( flowCd );
		paramList.add( flowPtn );
		paramList.add( sheetId );
		
		CstSheetDao dao = new CstSheetDao( this.loginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<VCstSheetActorAndRefDto> selectActors( String sheetId ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select '' as actOrRef, '' as sheetId, CSM.ACTOR_CD as actorCd, CSM.ACTOR_NM as actorNm, '' as actorSort, VA.GUID as guid, VA.PERSON_NAME as personName, '' as mainActorCd, '' as holdGuid " );
		sql.append( "   from CSM_SHEET_ACTOR CSM " );
		sql.append( "        left outer join  ( select GUID, ACTOR_CD, PERSON_NAME" );
		sql.append( "                             from V_CST_SHEET_ACTOR_AND_REF " );
		sql.append( "                            where SHEET_ID = ? ) VA " );
		sql.append( "                     on VA.ACTOR_CD = CSM.ACTOR_CD " );
		sql.append( "            inner join ( select FLOW_CD " );
		sql.append( "                           from  V_CST_SHEET_INFO " );
		sql.append( "                          where SHEET_ID = ? ) VI " );
		sql.append( "                     on VI.FLOW_CD = CSM.FLOW_CD " );
		sql.append( "  where CSM.ACT_OR_REF = 'ACT' " );
		sql.append( "    and CSM.ACTOR_CD <> 'act-jinji' " );
		sql.append( " order by CSM.LPAD_SORT " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		paramList.add( sheetId );
		VCstSheetActorAndRefDao dao = new VCstSheetActorAndRefDao( this.loginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}

	private List<VCstSheetActorAndRefDto> selectActAndRef( String sheetId ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + VCstSheetActorAndRefDao.ALLCOLS );
		sql.append( "   from V_CST_SHEET_ACTOR_AND_REF AR ");
		sql.append( "  where SHEET_ID = ? ");
		sql.append( " order by ACTOR_SORT, GUID ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		
		VCstSheetActorAndRefDao dao = new VCstSheetActorAndRefDao( this.loginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}

	private List<String> selectHoldActors( String sheetId ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select distinct CSM.MAIN_ACTOR_CD as text " );
		sql.append( "   from CSM_SHEET_FLOW CSM " );
		sql.append( "        inner join ( select FLOW_CD " );
		sql.append( "                       from V_CST_SHEET_INFO " );
		sql.append( "                      where sheet_id = ? ) VI " );
		sql.append( "                on VI.FLOW_CD = CSM.FLOW_CD " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		OneColumnDao dao = new OneColumnDao( this.loginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}

	private List<VCstSheetActorAndRefDto> selectReferers( String sheetId ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + VCstSheetActorAndRefDao.ALLCOLS );
		sql.append( "   from V_CST_SHEET_ACTOR_AND_REF AR ");
		sql.append( "  where AR.ACT_OR_REF = 'REF' and SHEET_ID = ? ");
		sql.append( " order by ACTOR_SORT, GUID ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		
		VCstSheetActorAndRefDao dao = new VCstSheetActorAndRefDao( this.loginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	private List<CsmSheetActorDto> selectRefMasterList( String sheetId ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select distinct CSM.FLOW_CD as flowCd, CSM.ACT_OR_REF as actOrRef, CSM.ACTOR_CD as actorCd, CSM.ACTOR_NM as actorNm, CSM.LPAD_SORT as lpadSort " );
		sql.append( "   from CSM_SHEET_ACTOR CSM " );
		sql.append( "        inner join ( select FLOW_CD " );
		sql.append( "                       from V_CST_SHEET_INFO " );
		sql.append( "                      where sheet_id = ? ) VI " );
		sql.append( "                on VI.FLOW_CD = CSM.FLOW_CD " );
		sql.append( "  where CSM.ACT_OR_REF = 'REF' " );
		sql.append( "  order by CSM.LPAD_SORT " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		
		CsmSheetActorDao dao = new CsmSheetActorDao( this.loginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
}
