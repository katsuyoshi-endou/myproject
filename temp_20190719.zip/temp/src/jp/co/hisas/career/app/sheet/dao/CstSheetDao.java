/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jp.co.hisas.career.app.sheet.dto.CstSheetDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CstSheetDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " SHEET_ID as sheetId,"
                     + " PARTY as party,"
                     + " OPERATION_CD as operationCd,"
                     + " FORM_CD as formCd,"
                     + " OWN_GUID as ownGuid,"
                     + " STATUS_CD as statusCd,"
                     + " FLOW_PTN as flowPtn"
                     ;

    public CstSheetDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CstSheetDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public void insert(CstSheetDto dto) {

        final String sql = "INSERT INTO CST_SHEET ("
                         + "SHEET_ID,"
                         + "PARTY,"
                         + "OPERATION_CD,"
                         + "FORM_CD,"
                         + "OWN_GUID,"
                         + "STATUS_CD,"
                         + "FLOW_PTN"
                         + ")VALUES(?,?,?,?,?,?,? )"
                         ;
        Log.sql("[DaoMethod Call] CstSheetDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getSheetId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getParty());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getOperationCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getFormCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getOwnGuid());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getStatusCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getFlowPtn());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void update(CstSheetDto dto) {

        final String sql = "UPDATE CST_SHEET SET "
                         + "PARTY = ?,"
                         + "OPERATION_CD = ?,"
                         + "FORM_CD = ?,"
                         + "OWN_GUID = ?,"
                         + "STATUS_CD = ?,"
                         + "FLOW_PTN = ?"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CstSheetDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getParty());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getOperationCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getFormCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getOwnGuid());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getStatusCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getFlowPtn());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getSheetId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void delete(String sheetId) {

        final String sql = "DELETE FROM CST_SHEET"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CstSheetDao.delete");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally { 
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public CstSheetDto select(String sheetId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CST_SHEET"
                         + " WHERE SHEET_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CstSheetDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sheetId);
            rs = pstmt.executeQuery();
            CstSheetDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("[DaoMethod Call] CstSheetDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void executeDynamic(String sql) {

        Log.sql("[DaoMethod Call] CstSheetDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    private CstSheetDto transferRsToDto(ResultSet rs) throws SQLException {

        CstSheetDto dto = new CstSheetDto();
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setOperationCd(DaoUtil.convertNullToString(rs.getString("operationCd")));
        dto.setFormCd(DaoUtil.convertNullToString(rs.getString("formCd")));
        dto.setOwnGuid(DaoUtil.convertNullToString(rs.getString("ownGuid")));
        dto.setStatusCd(DaoUtil.convertNullToString(rs.getString("statusCd")));
        dto.setFlowPtn(DaoUtil.convertNullToString(rs.getString("flowPtn")));
        return dto;
    }

}

