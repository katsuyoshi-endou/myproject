package jp.co.hisas.career.app.sheet.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.hisas.career.app.sheet.dto.CsmSheetRemarkDto;
import jp.co.hisas.career.app.sheet.dto.CstSheetActorDto;
import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.dto.useful.ValueTextSortDto;

public class CsMultiSheet {
	
	public String daoLoginNo;
	public String operatorGuid;
	public List<VCsInfoAttrDto> multiCsList;
	public HashMap<String, HashMap<String, String>> multiCsFillMap;
	public HashMap<String, HashMap<String, String>> multiFillMaskMap;
	public HashMap<String, CstSheetActorDto> bindedMap;
	public List<ValueTextSortDto> actionList;
	public HashMap<String, String> gamenCondMap;
	public List<ValueTextSortDto> actorOptionList;
	public List<ValueTextSortDto> divList;
	public List<ValueTextSortDto> operationList;
	public List<ValueTextSortDto> statusList;
	public List<ValueTextSortDto> deptOptionList;
	public String mode; // R or SR
	public int hitCnt;
	
	public CsMultiSheet( String daoLoginNo, String operatorGuid ) {
		this.daoLoginNo = daoLoginNo;
		this.operatorGuid = operatorGuid;
	}
	
	public String getFillContent( VCsInfoAttrDto sheetDto, String fillId, String escape ) {
		String sheetId = sheetDto.getSheetId();
		String fc = null;
		HashMap<String, String> fillMap = multiCsFillMap.get( sheetId );
		if ( fillMap != null && isVisible(sheetDto, fillId) ) {
			if ("JS".equals( escape )) {
				fc = CsUtil.escapeForJS( fillMap.get( fillId ) );
			}
			else if ("HTML".equals( escape )) {
				fc = CsUtil.escapeForHTML( fillMap.get( fillId ) );
			}
			else {
				// RAW
				fc = fillMap.get( fillId );
			}
		}
		return (fc != null) ? fc : "" ;
	}
	
	public String getFillContent( VCsInfoAttrDto sheetDto, String fillId ) {
		return getFillContent( sheetDto, fillId, "" );
	}
	
	public boolean isVisible( VCsInfoAttrDto sheetDto, String fillId ) {
		// MODE is read or write -> true
		String actorCd = CsUtil.autoDetectActorCdForMulti( operatorGuid, sheetDto.getSheetId() );
		String maskMapKey = sheetDto.getMaskCd() + "$" + sheetDto.getStatusCd() + "$" + actorCd;
		HashMap<String, String> fillMaskMap = multiFillMaskMap.get( maskMapKey );
		if (fillMaskMap == null) {
			return false;
		}
		return fillMaskMap.containsKey( fillId );
	}
	
	public boolean isWritable( VCsInfoAttrDto sheetDto, String fillId ) {
		// MODE is write -> true
		//TODO: "$actorCd"が必要（for一括編集画面）
		HashMap<String, String> fillMaskMap = multiFillMaskMap.get( sheetDto.getMaskCd() + "$" + sheetDto.getStatusCd() );
		if (fillMaskMap == null) {
			return false;
		}
		return "write".equals( fillMaskMap.get( fillId ) );
	}
	
	/**
	 * For Excel Download
	 */
	public static String getFillContentStatic( String loginNo, VCsInfoAttrDto sheetDto, HashMap<String, HashMap<String, String>> multiCsFillMap, String fillId, HashMap<String, HashMap<String, String>> multiFillMaskMap ) {
		String sheetId = sheetDto.getSheetId();
		String fc = null;
		HashMap<String, String> fillMap = multiCsFillMap.get( sheetId );
		String actorCd = CsUtil.autoDetectActorCdForMulti( loginNo, sheetId );
		if (fillMap != null && isVisibleStatic( sheetDto, fillId, multiFillMaskMap, actorCd )) {
			fc = fillMap.get( fillId );
		}
		return (fc != null) ? fc : "" ;
	}
	
	public static boolean isVisibleStatic( VCsInfoAttrDto sheetDto, String fillId, HashMap<String, HashMap<String, String>> multiFillMaskMap, String actorCd ) {
		// MODE is read or write -> true
		String maskMapKey = sheetDto.getMaskCd() + "$" + sheetDto.getStatusCd() + "$" + actorCd;
		HashMap<String, String> fillMaskMap = multiFillMaskMap.get( maskMapKey );
		return fillMaskMap.containsKey( fillId );
	}
	
	public String makeFillCell( VCsInfoAttrDto sheetDto, String fillId, boolean isEditable, String type ) {
		String sheetId = sheetDto.getSheetId();
		String fc = this.getFillContent( sheetDto, fillId );
		boolean isWritable = isWritable( sheetDto, fillId );
		if (isEditable && isWritable) {
			fc = PZZ010_CharacterUtil.sanitizeStrData( fc );
			String name = sheetId + "--Fill--" + fillId;
			if ("textarea".equals( type )) {
				fc = "<textarea rows=3 name='" + name + "' >" + fc + "</textarea>";
			}
			else if ("input-num".equals( type )) {
				fc = "<input type=\"text\" name='" + name + "' class=\"textBox num right\" value=\"" + fc + "\" size=\"4\"/>";
			}
			else if ("input-int3".equals( type )) {
				fc = "<input type=\"text\" name='" + name + "' class=\"textBox num int right\" value=\"" + fc + "\" size=\"4\" maxlength=\"3\"/>";
			}
			else if (type.matches( "^pulldown-\\[.*?\\]$" )) {
				String pulldownType = CsUtil.extractWithRegex( type, "^pulldown-\\[(.*?)\\]$" );
				String pulldownHtml = makePulldownHtml( pulldownType, fc );
				fc = "<select name='" + name + "'>" + pulldownHtml + "</select>";
			}
			else if ("autocalc".equals( type )) {
				String id = sheetId + "--autocalc-" + fillId;
				fc = "<span id='" + id + "'>" + fc + "</span>";
			}
		} else {
			fc = CsUtil.escapeForHTML( fc );
			if ("input-num".equals( type )) {
				String id = sheetId + "--autocalc-" + fillId;
				fc = "<span id='" + id + "'>" + fc + "</span>";
			}
			else if ("autocalc".equals( type )) {
				String id = sheetId + "--autocalc-" + fillId;
				fc = "<span id='" + id + "'>" + fc + "</span>";
			}
			else if ("readonly".equals( type )) {
				fc = "<span>" + fc + "</span>";
			}
		}
		return fc;
	}
	
	public String makePulldownHtml( String pulldownType, String valueForSelected ) {
		String pulldownHtml = "";
		LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
		if ("0-10".equals( pulldownType )) {
			map.put( "", "" ); map.put( "0", "0" ); map.put( "1", "1" ); map.put( "2", "2" ); map.put( "3", "3" ); map.put( "4", "4" ); map.put( "5", "5" ); map.put( "6", "6" ); map.put( "7", "7" ); map.put( "8", "8" ); map.put( "9", "9" ); map.put( "10", "10" );
		}
		else if ("1.5-0.5".equals( pulldownType )) {
			map.put( "", "" ); map.put( "1.5", "1.5" ); map.put( "1.4", "1.4" ); map.put( "1.3", "1.3" ); map.put( "1.2", "1.2" ); map.put( "1.1", "1.1" ); map.put( "1.0", "1.0" ); map.put( "0.9", "0.9" ); map.put( "0.8", "0.8" ); map.put( "0.7", "0.7" ); map.put( "0.6", "0.6" ); map.put( "0.5", "0.5" );
		}
		else if ("15.0-5.0".equals( pulldownType )) {
			map.put( "", "" ); map.put( "15.0", "15.0" ); map.put( "14.5", "14.5" ); map.put( "14.0", "14.0" ); map.put( "13.5", "13.5" ); map.put( "13.0", "13.0" ); map.put( "12.5", "12.5" ); map.put( "12.0", "12.0" ); map.put( "11.5", "11.5" ); map.put( "11.0", "11.0" ); map.put( "10.5", "10.5" ); map.put( "10.0", "10.0" ); map.put( "9.5", "9.5" ); map.put( "9.0", "9.0" ); map.put( "8.5", "8.5" ); map.put( "8.0", "8.0" ); map.put( "7.5", "7.5" ); map.put( "7.0", "7.0" ); map.put( "6.5", "6.5" ); map.put( "6.0", "6.0" ); map.put( "5.5", "5.5" ); map.put( "5.0", "5.0" );
		}
		else if ("10-50".equals( pulldownType )) {
			map.put( "", "" ); map.put( "10", "10" ); map.put( "20", "20" ); map.put( "30", "30" ); map.put( "40", "40" ); map.put( "50", "50" );
		}
		else if ("shok-R-tensu".equals( pulldownType )) {
			map.put( "", "" ); map.put( "120", "120" ); map.put( "100", "100" ); map.put( "80", "80" ); map.put( "60", "60" ); map.put( "40", "40" );
		}
		else if ("shok-SR-tensu".equals( pulldownType )) {
			map.put( "", "" ); map.put( "110", "110" ); map.put( "100", "100" ); map.put( "90", "90" ); map.put( "80", "80" ); map.put( "70", "70" ); map.put( "60", "60" ); map.put( "50", "50" );
		}
		
		for (Map.Entry<String, String> entry : map.entrySet()) {
			String selected = "";
			if (entry.getKey().equals( valueForSelected )) {
				selected = " selected";
			}
			pulldownHtml += "<option value='" + entry.getKey() + "'" + selected + ">" + entry.getValue() + "</option>";
		}
		return pulldownHtml;
	}
	
	public static boolean is0( BigDecimal val ) {
		BigDecimal zero = new BigDecimal( 0 );
		if (zero.compareTo( val ) == 0) {
			return true;
		} else {
			return false;
		}
	}
	
	public BigDecimal calcGyos( VCsInfoAttrDto sheetDto, String calcName ) {
		return calcGyos( sheetDto, calcName, false, null );
	}
	
	public BigDecimal calcGyos( VCsInfoAttrDto sheetDto, String calcName, boolean isRequestMode, HashMap<String, String> fillReqMap ) {
		BigDecimal result = null;
		if (calcName == null || "".equals( calcName )) {
		}
		else if (calcName.matches( "calc_gyos_mok[1-4]_?(kek|kod)?_hyokaten" )) {
			/* 評価点合計 */
			String prefix = "gyos_mok" + CsUtil.extractWithRegex( calcName, "calc_gyos_mok([1-4])_?(kek|kod)?_hyokaten" );
			String subPrefix = CsUtil.extractWithRegex( calcName, "calc_gyos_mok[1-4]_?(kek|kod)?_hyokaten" );
			boolean shainMode = (subPrefix != null);
			subPrefix = shainMode ? "_" + subPrefix : "";
			String _weight, _kekkod, _nanido, _kankyo, _kijunt;
			if (isRequestMode) {
				String fid;
				fid = prefix + "_weight";
				_weight = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
				fid = prefix + subPrefix + "_kekkakodo";
				_kekkod = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
				fid = prefix + subPrefix + "_nanido";
				_nanido = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
				fid = prefix + subPrefix + "_kankyoyoin";
				_kankyo = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
				fid = prefix + subPrefix + "_kijunten";
				_kijunt = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
			}
			else {
				_weight = getFillContent( sheetDto, prefix + "_weight" );
				_kekkod = getFillContent( sheetDto, prefix + subPrefix + "_kekkakodo" );
				_nanido = getFillContent( sheetDto, prefix + subPrefix + "_nanido" );
				_kankyo = getFillContent( sheetDto, prefix + subPrefix + "_kankyoyoin" );
				_kijunt = getFillContent( sheetDto, prefix + subPrefix + "_kijunten" );
			}
			BigDecimal weight = CsUtil.blankToZero( _weight );
			BigDecimal kekkod = CsUtil.blankToZero( _kekkod );
			           kekkod = (shainMode) ? kekkod.multiply( new BigDecimal( 0.1 ) ) : new BigDecimal( 1 );
			BigDecimal nanido = CsUtil.blankToZero( _nanido );
			BigDecimal kankyo = CsUtil.blankToZero( _kankyo );
			BigDecimal kijunt = CsUtil.blankToZero( _kijunt );
			BigDecimal calced = weight.multiply( new BigDecimal( 0.1 ) ).multiply( kekkod ).multiply( nanido ).multiply( kankyo ).multiply( kijunt );
			result = calced;
		}
		else if ("calc_gyos_hyokaten_total_shain".equals( calcName )) {
			BigDecimal bdMok1KekTen = this.calcGyos( sheetDto, "calc_gyos_mok1_kek_hyokaten", isRequestMode, fillReqMap );
			BigDecimal bdMok2KekTen = this.calcGyos( sheetDto, "calc_gyos_mok2_kek_hyokaten", isRequestMode, fillReqMap );
			BigDecimal bdMok3KekTen = this.calcGyos( sheetDto, "calc_gyos_mok3_kek_hyokaten", isRequestMode, fillReqMap );
			BigDecimal bdMok4KekTen = this.calcGyos( sheetDto, "calc_gyos_mok4_kek_hyokaten", isRequestMode, fillReqMap );
			BigDecimal bdMok1KodTen = this.calcGyos( sheetDto, "calc_gyos_mok1_kod_hyokaten", isRequestMode, fillReqMap );
			BigDecimal bdMok2KodTen = this.calcGyos( sheetDto, "calc_gyos_mok2_kod_hyokaten", isRequestMode, fillReqMap );
			BigDecimal bdMok3KodTen = this.calcGyos( sheetDto, "calc_gyos_mok3_kod_hyokaten", isRequestMode, fillReqMap );
			BigDecimal bdMok4KodTen = this.calcGyos( sheetDto, "calc_gyos_mok4_kod_hyokaten", isRequestMode, fillReqMap );
			BigDecimal bdMokHyokSum = bdMok1KekTen.add( bdMok2KekTen ).add( bdMok3KekTen ).add( bdMok4KekTen ).add( bdMok1KodTen ).add( bdMok2KodTen ).add( bdMok3KodTen ).add( bdMok4KodTen );
			result = bdMokHyokSum;
		}
		else if ("calc_gyos_gyosekiten_shain".equals( calcName )) {
			BigDecimal bdMokHyokSum = this.calcGyos( sheetDto, "calc_gyos_hyokaten_total_shain", isRequestMode, fillReqMap );
			BigDecimal tmp = bdMokHyokSum.divide( new BigDecimal(10), 1, BigDecimal.ROUND_HALF_UP );
			tmp = CsUtil.floorHalf( tmp.add( new BigDecimal(0.2) ) );
			result = tmp;
		}
		else if ("calc_gyos_hyokaten_total_ks".equals( calcName )) {
			BigDecimal bdMok1Ten = this.calcGyos( sheetDto, "calc_gyos_mok1_hyokaten", isRequestMode, fillReqMap );
			BigDecimal bdMok2Ten = this.calcGyos( sheetDto, "calc_gyos_mok2_hyokaten", isRequestMode, fillReqMap );
			BigDecimal bdMok3Ten = this.calcGyos( sheetDto, "calc_gyos_mok3_hyokaten", isRequestMode, fillReqMap );
			BigDecimal bdMok4Ten = this.calcGyos( sheetDto, "calc_gyos_mok4_hyokaten", isRequestMode, fillReqMap );
			BigDecimal bdMokHyokSum = bdMok1Ten.add( bdMok2Ten ).add( bdMok3Ten ).add( bdMok4Ten );
			result = bdMokHyokSum;
		}
		else if ("calc_gyos_gyosekiten_ks".equals( calcName )) {
			BigDecimal bdMokHyokSum = this.calcGyos( sheetDto, "calc_gyos_hyokaten_total_ks", isRequestMode, fillReqMap );
			BigDecimal tmp = bdMokHyokSum.divide( new BigDecimal(10), 1, BigDecimal.ROUND_HALF_UP );
			tmp = CsUtil.floorHalf( tmp.add( new BigDecimal(0.2) ) );
			result = tmp;
		}
		else {
			result = null;
		}
		return result;
	}
	
	public String calcShok( VCsInfoAttrDto sheetDto, String calcName ) {
		return calcShok( sheetDto, calcName, false, null );
	}
	
	public String calcShok( VCsInfoAttrDto sheetDto, String calcName, boolean isRequestMode, HashMap<String, String> fillReqMap ) {
		String result = "";
		boolean isSetsumon6 = sheetDto.getFormCd().matches("^.*-R[5-6]$");
		if (calcName == null || "".equals( calcName )) {
		}
		else if ("calc_shok_total".equals( calcName )) {
			if (!isVisible( sheetDto, "shok_hk1_tensu" )) {
				return "";
			}
			/* 合計 */
			String _hk1, _hk2, _hk3, _hk4, _hk5, _hk6, _hk7;
			if (isRequestMode) {
				String fid;
				fid = "shok_hk1_tensu";
				_hk1 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
				fid = "shok_hk2_tensu";
				_hk2 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
				fid = "shok_hk3_tensu";
				_hk3 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
				fid = "shok_hk4_tensu";
				_hk4 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
				fid = "shok_hk5_tensu";
				_hk5 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
				fid = "shok_hk6_tensu";
				_hk6 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
				fid = "shok_hk7_tensu";
				_hk7 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
			}
			else {
				_hk1 = getFillContent( sheetDto, "shok_hk1_tensu" );
				_hk2 = getFillContent( sheetDto, "shok_hk2_tensu" );
				_hk3 = getFillContent( sheetDto, "shok_hk3_tensu" );
				_hk4 = getFillContent( sheetDto, "shok_hk4_tensu" );
				_hk5 = getFillContent( sheetDto, "shok_hk5_tensu" );
				_hk6 = getFillContent( sheetDto, "shok_hk6_tensu" );
				_hk7 = getFillContent( sheetDto, "shok_hk7_tensu" );
			}
			if (CsUtil.isBlank( _hk1 )) { return ""; }
			if (CsUtil.isBlank( _hk2 )) { return ""; }
			if (CsUtil.isBlank( _hk3 )) { return ""; }
			if (CsUtil.isBlank( _hk4 )) { return ""; }
			if ("R".equals( this.mode )) {
				if (CsUtil.isBlank( _hk5 )) { return ""; }
				if (CsUtil.isBlank( _hk6 )) { return ""; }
				if (!isSetsumon6) {
					if (CsUtil.isBlank( _hk7 )) { return ""; }
				}
			}
			BigDecimal hk1 = CsUtil.blankToZero( _hk1 );
			BigDecimal hk2 = CsUtil.blankToZero( _hk2 );
			BigDecimal hk3 = CsUtil.blankToZero( _hk3 );
			BigDecimal hk4 = CsUtil.blankToZero( _hk4 );
			BigDecimal hk5 = CsUtil.blankToZero( _hk5 );
			BigDecimal hk6 = CsUtil.blankToZero( _hk6 );
			BigDecimal hk7 = CsUtil.blankToZero( _hk7 );
			BigDecimal total = hk1.add( hk2 ).add( hk3 ).add( hk4 ).add( hk5 ).add( hk6 ).add( hk7 );
			result = is0( total ) ? "" : total.toString();
		}
		else if ("calc_shok_rank".equals( calcName )) {
			if (!isVisible( sheetDto, "shok_hk1_tensu" )) {
				return "";
			}
			String rangeCd = "rank_" + sheetDto.getFormCd();
			int point = CsUtil.blankToZero( this.calcShok( sheetDto, "calc_shok_total", isRequestMode, fillReqMap ) ).intValue();
			CsmSheetRemarkDto dto = (point != 0) ? CsUtil.getRemarkByPoint( "", rangeCd, point ) : null;
			result = (dto != null) ? dto.getRemark() : "";
		}
		else if ("calc_shok_shokakuKokaku".equals( calcName )) {
			boolean modeR = (sheetDto.getFormCd().matches("^.*-R[1-6]$"));
			String shokakuKokaku = "";
			boolean isKimatsu = sheetDto.getOperationCd().endsWith( "S" );
			if (isKimatsu) {
				String _hk1, _hk2, _hk3, _hk4, _hk5, _hk6, _hk7;
				if (isRequestMode) {
					String fid;
					fid = "shok_hk1_tensu";
					_hk1 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
					fid = "shok_hk2_tensu";
					_hk2 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
					fid = "shok_hk3_tensu";
					_hk3 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
					fid = "shok_hk4_tensu";
					_hk4 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
					fid = "shok_hk5_tensu";
					_hk5 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
					fid = "shok_hk6_tensu";
					_hk6 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
					fid = "shok_hk7_tensu";
					_hk7 = fillReqMap.containsKey( fid ) ? fillReqMap.get( fid ) : getFillContent( sheetDto, fid );
				}
				else {
					_hk1 = getFillContent( sheetDto, "shok_hk1_tensu" );
					_hk2 = getFillContent( sheetDto, "shok_hk2_tensu" );
					_hk3 = getFillContent( sheetDto, "shok_hk3_tensu" );
					_hk4 = getFillContent( sheetDto, "shok_hk4_tensu" );
					_hk5 = getFillContent( sheetDto, "shok_hk5_tensu" );
					_hk6 = getFillContent( sheetDto, "shok_hk6_tensu" );
					_hk7 = getFillContent( sheetDto, "shok_hk7_tensu" );
				}
				BigDecimal hk1 = CsUtil.blankToZero( _hk1 );
				BigDecimal hk2 = CsUtil.blankToZero( _hk2 );
				BigDecimal hk3 = CsUtil.blankToZero( _hk3 );
				BigDecimal hk4 = CsUtil.blankToZero( _hk4 );
				BigDecimal hk5 = CsUtil.blankToZero( _hk5 );
				BigDecimal hk6 = CsUtil.blankToZero( _hk6 );
				BigDecimal hk7 = CsUtil.blankToZero( _hk7 );
				int hkCnt = 0;
				if (hk1.intValue() > 0) { hkCnt++; }
				if (hk2.intValue() > 0) { hkCnt++; }
				if (hk3.intValue() > 0) { hkCnt++; }
				if (hk4.intValue() > 0) { hkCnt++; }
				if (hk5.intValue() > 0) { hkCnt++; }
				if (hk6.intValue() > 0) { hkCnt++; }
				if (hk7.intValue() > 0) { hkCnt++; }
				BigDecimal hkAve = new BigDecimal( 0 );
				String total = this.calcShok( sheetDto, "calc_shok_total", isRequestMode, fillReqMap );
				if (hkCnt > 0) { hkAve = CsUtil.blankToZero( total ).divide( new BigDecimal( hkCnt ), 2, BigDecimal.ROUND_HALF_UP ); }
				if (hkAve.compareTo( new BigDecimal(100) ) >= 0) { shokakuKokaku = "昇格"; }
			}
			String newRank = this.calcShok( sheetDto, "calc_shok_rank", isRequestMode, fillReqMap );
			String senkiRank = getFillContent( sheetDto, "shok_senkimatsu_rank" );
			if (modeR && newRank.equals( "D" ) && senkiRank.equals( "D" )) {
				shokakuKokaku = "降格";
			}
			result = shokakuKokaku;
		}
		else if ("calc_shok_rank_diff".equals( calcName )) {
			boolean modeR = (sheetDto.getFormCd().matches("^.*-R[1-6]$"));
			String shokakuKokaku = this.calcShok( sheetDto, "calc_shok_shokakuKokaku", isRequestMode, fillReqMap );
			String newRank;
			if (!CsUtil.isBlank( shokakuKokaku )) {
				newRank = shokakuKokaku;
			} else {
				newRank = this.calcShok( sheetDto, "calc_shok_rank", isRequestMode, fillReqMap );
			}
			String clsDCd = sheetDto.getClsDCd();
			if (CsUtil.isBlank( newRank ) || CsUtil.isBlank( clsDCd )) {
				return "";
			}
			if (modeR) {
				HashMap<String, Integer> map = new HashMap<String, Integer>();
				map.put( "昇格", 7 );
				map.put(    "S", 5 );  map.put( "3011", 5 );
				map.put(    "A", 4 );  map.put( "3012", 4 );
				map.put(    "B", 3 );  map.put( "3013", 3 );
				map.put(    "C", 2 );  map.put( "3014", 2 );
				map.put(    "D", 1 );  map.put( "3015", 1 );
				map.put( "降格", 0 );
				int ptNow  = map.get( newRank ).intValue();
				int ptClsD = map.get( clsDCd ).intValue();
				result = (ptNow - ptClsD) + "";
			}
			else {
				HashMap<String, Integer> map = new HashMap<String, Integer>();
				map.put( "昇格", 8 );
				map.put(    "S", 7 );  map.put( "4111", 7 );
				map.put(    "A", 6 );  map.put( "4112", 6 );
				map.put(    "B", 5 );  map.put( "4113", 5 );
				map.put(    "C", 4 );  map.put( "4114", 4 );
				map.put(    "D", 3 );  map.put( "4115", 3 );
				map.put(    "E", 2 );  map.put( "4116", 2 );
				map.put(    "F", 1 );  map.put( "4117", 1 );
				map.put( "降格", 0 );
				int ptNow  = map.get( newRank ).intValue();
				int ptClsD = map.get( clsDCd ).intValue();
				result = (ptNow - ptClsD) + "";
			}
		}
		else {
			result = "未実装";
		}
		return result;
	}
	
	/**
	 *  ※Multi用
	 *  指定した文字列に一致するvalueを持つkeyを"(sheetId)--Fill--"をつけて配列形式のシングルクォートカンマ区切りで連結して返す。
	 */
	public String getMapKeysForJSArray( VCsInfoAttrDto sheetDto, String valueMatchStr ) {
		String resultStr = "";
		String sheetId = sheetDto.getSheetId();
		HashMap<String, String> map = multiFillMaskMap.get( sheetDto.getMaskCd() + "$" + sheetDto.getStatusCd() );
		if (map == null) {
			return "";
		}
		for (Map.Entry<String, String> entry : map.entrySet()) {
			String val = entry.getValue();
			if (valueMatchStr.equals(val)) {
				resultStr += ", '" + sheetId + "--Fill--" + entry.getKey() + "'";
			}
		}
		return resultStr;
	}
	
	public HashMap<String, List<String>> checkRequestFills( VCsInfoAttrDto sheetDto, final HttpServletRequest request, HashMap<String, String> fillReqMap) {
		HashMap<String, List<String>> result = new HashMap<String, List<String>>();
		String formGrpCd = request.getParameter( "formGrpCd" );
		if      ("grp-cstp".equals( formGrpCd )) { ; }
		else if ("grp-gyos".equals( formGrpCd )) { result = checkGyos( sheetDto, fillReqMap ); }
		else if ("grp-shok".equals( formGrpCd )) { result = checkShok( sheetDto, fillReqMap ); }
		return result;
	}
	
	public HashMap<String, List<String>> checkGyos( VCsInfoAttrDto sheetDto, HashMap<String, String> fillReqMap ) {
		HashMap<String, List<String>> result = new HashMap<String, List<String>>();
		boolean isShainMode = "frm-gyos-SHAIN".equals( sheetDto.getFormCd() );
		List<String> checkFillIdList = null;
		
		/* 「目標ウエイト」合計 : 10 */
		checkFillIdList = new ArrayList<String>();
		checkFillIdList.add( "gyos_mok1_weight" );
		checkFillIdList.add( "gyos_mok2_weight" );
		checkFillIdList.add( "gyos_mok3_weight" );
		checkFillIdList.add( "gyos_mok4_weight" );
		List<String> wtNgList = checkSumZeroOrTen( fillReqMap, checkFillIdList );
		if (wtNgList.size() > 0) {
			result.put( "「目標ウエイト」の合計を 10 にしてください。", wtNgList );
		}
		
		/* 「結果：行動」の合計 : 10 */
		if (isShainMode) {
			List<String> kekkodNgList = new ArrayList<String>();
			checkFillIdList = new ArrayList<String>();
			checkFillIdList.add( "gyos_mok1_kek_kekkakodo" );
			checkFillIdList.add( "gyos_mok1_kod_kekkakodo" );
			kekkodNgList.addAll( checkSumZeroOrTen( fillReqMap, checkFillIdList ) );
			checkFillIdList = new ArrayList<String>();
			checkFillIdList.add( "gyos_mok2_kek_kekkakodo" );
			checkFillIdList.add( "gyos_mok2_kod_kekkakodo" );
			kekkodNgList.addAll( checkSumZeroOrTen( fillReqMap, checkFillIdList ) );
			checkFillIdList = new ArrayList<String>();
			checkFillIdList.add( "gyos_mok3_kek_kekkakodo" );
			checkFillIdList.add( "gyos_mok3_kod_kekkakodo" );
			kekkodNgList.addAll( checkSumZeroOrTen( fillReqMap, checkFillIdList ) );
			checkFillIdList = new ArrayList<String>();
			checkFillIdList.add( "gyos_mok4_kek_kekkakodo" );
			checkFillIdList.add( "gyos_mok4_kod_kekkakodo" );
			kekkodNgList.addAll( checkSumZeroOrTen( fillReqMap, checkFillIdList ) );
			if (kekkodNgList.size() > 0) {
				result.put( "「結果：行動」の合計を 10 にしてください。", kekkodNgList );
			}
		}
		
		/* 業績点 入力可能時 必須入力 */
		List<String> tenNgList = new ArrayList<String>();
		tenNgList.addAll( checkNecessary( fillReqMap, "gyos_gyosekiten" ) );
		if (tenNgList.size() > 0) {
			result.put( "業績点を入力してください。", tenNgList );
		}
		
		/* 「業績点(自動)」と「業績点」の乖離チェック : 0.5 */
		BigDecimal gyosekitenAuto = null;
		if (isShainMode) {
			gyosekitenAuto = this.calcGyos( sheetDto, "calc_gyos_gyosekiten_shain", true, fillReqMap );
		} else {
			gyosekitenAuto = this.calcGyos( sheetDto, "calc_gyos_gyosekiten_ks", true, fillReqMap );
		}
		// 画面で入力状態ではない（＝リクエストに乗ってこない）ときにも比較対象にする必要がある
		String tmpGyosekiten = fillReqMap.get( "gyos_gyosekiten" );
		tmpGyosekiten = CsUtil.isBlank(tmpGyosekiten) ? this.getFillContent( sheetDto, "gyos_gyosekiten" ) : tmpGyosekiten;
		BigDecimal gyosekitenManu = CsUtil.blankToZero( tmpGyosekiten );
		BigDecimal kairi = gyosekitenAuto.subtract( gyosekitenManu );
		if (kairi.abs().compareTo( new BigDecimal(0.5) ) == 1) {
			List<String> kairiNgList = new ArrayList<String>();
			kairiNgList.add( "gyos_gyosekiten" );
			result.put( "業績点の自動計算結果と手入力した点数に乖離があります。正しい場合はシート画面に移動し個別に承認してください。", kairiNgList );
		}
		
		/* 特賞申請理由 必須入力（特賞入力ありの場合） */
		List<String> tokNgList = new ArrayList<String>();
		tokNgList.addAll( checkNecessaryRelated( fillReqMap, "gyos_tokusho", "gyos_tokusho_riyu" ) );
		if (tokNgList.size() > 0) {
			result.put( "特賞の入力がある場合、特賞申請理由を入力してください。", tokNgList );
		}
		
		return result;
	}
	
	public HashMap<String, List<String>> checkShok( VCsInfoAttrDto sheetDto, HashMap<String, String> fillReqMap ) {
		HashMap<String, List<String>> result = new HashMap<String, List<String>>();
		
		/* 点数 入力可能時 必須入力 */
		List<String> hkNgList = new ArrayList<String>();
		hkNgList.addAll( checkNecessary( fillReqMap, "shok_hk1_tensu" ) );
		hkNgList.addAll( checkNecessary( fillReqMap, "shok_hk2_tensu" ) );
		hkNgList.addAll( checkNecessary( fillReqMap, "shok_hk3_tensu" ) );
		hkNgList.addAll( checkNecessary( fillReqMap, "shok_hk4_tensu" ) );
		hkNgList.addAll( checkNecessary( fillReqMap, "shok_hk5_tensu" ) );
		hkNgList.addAll( checkNecessary( fillReqMap, "shok_hk6_tensu" ) );
		hkNgList.addAll( checkNecessary( fillReqMap, "shok_hk7_tensu" ) );
		if (hkNgList.size() > 0) {
			result.put( "点数を入力してください。", hkNgList );
		}
		
		/* 昇格・降格コメント 必須入力（昇格・降格が空欄以外の場合） */
		List<String> cmtNgList = new ArrayList<String>();
		String shokakukokaku = this.calcShok( sheetDto, "calc_shok_shokakuKokaku", true, fillReqMap );
		if (!CsUtil.isBlank( shokakukokaku )) {
			cmtNgList.addAll( checkNecessary( fillReqMap, "shok_shokaku_comment" ) );
			if (cmtNgList.size() > 0) {
				result.put( "昇格・降格判定がある場合、コメントの入力は必須です。", cmtNgList );
			}
		}
		
		return result;
	}
	
	public static List<String> checkSumZeroOrTen( HashMap<String, String> fillReqMap, List<String> fillIdList ) {
		HashMap<String, BigDecimal> targets = new HashMap<String, BigDecimal>();
		for (String fillId : fillIdList) {
			targets.put( fillId, CsUtil.blankToZero( fillReqMap.get( fillId ) ) );
		}
		BigDecimal total = new BigDecimal( 0 );
		for (BigDecimal num : targets.values()) {
			total = total.add( num );
		}
		if (total.compareTo( new BigDecimal( 0 ) ) != 0 && total.compareTo( new BigDecimal( 10 ) ) != 0) {
			// Check NG
			return fillIdList;
		} else {
			// Check OK
			return new ArrayList<String>();
		}
	}
	
	public static List<String> checkNecessary( HashMap<String, String> fillReqMap, String fillId ) {
		List<String> ngFillIdList = new ArrayList<String>();
		if (fillReqMap.containsKey( fillId )) {
			String s = fillReqMap.get( fillId );
			if (CsUtil.isBlank( s )) {
				ngFillIdList.add( fillId );
			}
		}
		return ngFillIdList;
	}
	
	public static List<String> checkNecessaryRelated( HashMap<String, String> fillReqMap, String relatedFillId, String targetFillId ) {
		List<String> ngFillIdList = new ArrayList<String>();
		if (fillReqMap.containsKey( relatedFillId )) {
			String s = fillReqMap.get( relatedFillId );
			if (!CsUtil.isBlank( s )) {
				ngFillIdList = checkNecessary( fillReqMap, targetFillId );
			}
		}
		return ngFillIdList;
	}
}
