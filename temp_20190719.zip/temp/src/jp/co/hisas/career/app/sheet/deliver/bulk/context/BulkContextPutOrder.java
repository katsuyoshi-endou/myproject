package jp.co.hisas.career.app.sheet.deliver.bulk.context;

import jp.co.hisas.career.app.sheet.api.mold.BulkPageState;
import jp.co.hisas.career.app.sheet.deliver.DeliverOrder;
import jp.co.hisas.career.util.Tray;

public class BulkContextPutOrder extends DeliverOrder {
	
	public BulkPageState pageState;
	
	public BulkContextPutOrder(Tray tray) {
		super( tray );
	}
}
