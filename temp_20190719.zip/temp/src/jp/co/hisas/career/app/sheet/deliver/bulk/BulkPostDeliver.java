package jp.co.hisas.career.app.sheet.deliver.bulk;

import jp.co.hisas.career.app.sheet.api.bulk.BulkEvArg;
import jp.co.hisas.career.app.sheet.api.bulk.BulkEvHdlr;
import jp.co.hisas.career.app.sheet.api.bulk.BulkEvRslt;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Tray;

public class BulkPostDeliver {
	
	public static BulkEvRslt go( Tray tray, BulkPostOrder order ) throws CareerException {
		BulkEvArg arg = new BulkEvArg( tray.loginNo );
		arg.sharp = "POST";
		arg.orderPOST = order;
		BulkEvRslt rslt = BulkEvHdlr.exec( arg );
		return rslt;
	}
	
}
