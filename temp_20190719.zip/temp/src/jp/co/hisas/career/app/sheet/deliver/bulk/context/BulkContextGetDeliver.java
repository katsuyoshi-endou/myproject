package jp.co.hisas.career.app.sheet.deliver.bulk.context;

import jp.co.hisas.career.app.sheet.api.bulk.context.BulkContextEvArg;
import jp.co.hisas.career.app.sheet.api.bulk.context.BulkContextEvHdlr;
import jp.co.hisas.career.app.sheet.api.bulk.context.BulkContextEvRslt;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Tray;

public class BulkContextGetDeliver {
	
	public static BulkContextEvRslt go( Tray tray, BulkContextGetOrder order ) throws CareerException {
		BulkContextEvArg arg = new BulkContextEvArg( tray.loginNo );
		arg.sharp = "GET";
		arg.orderGET = order;
		BulkContextEvRslt rslt = BulkContextEvHdlr.exec( arg );
		return rslt;
	}
	
}
