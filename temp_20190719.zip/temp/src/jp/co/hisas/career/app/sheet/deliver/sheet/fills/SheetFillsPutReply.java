package jp.co.hisas.career.app.sheet.deliver.sheet.fills;

public class SheetFillsPutReply {
	
	public boolean errorExclusive;
}
