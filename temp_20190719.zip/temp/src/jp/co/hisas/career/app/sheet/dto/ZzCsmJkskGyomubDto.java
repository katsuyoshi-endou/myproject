/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class ZzCsmJkskGyomubDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String party;
    private String sort;
    private String shokushuNm;
    private String shokushuNm2;
    private String gyomuBunrui;
    private String shokushuDesc;

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public String getShokushuNm() {
        return shokushuNm;
    }

    public void setShokushuNm(String shokushuNm) {
        this.shokushuNm = shokushuNm;
    }

    public String getShokushuNm2() {
        return shokushuNm2;
    }

    public void setShokushuNm2(String shokushuNm2) {
        this.shokushuNm2 = shokushuNm2;
    }

    public String getGyomuBunrui() {
        return gyomuBunrui;
    }

    public void setGyomuBunrui(String gyomuBunrui) {
        this.gyomuBunrui = gyomuBunrui;
    }

    public String getShokushuDesc() {
        return shokushuDesc;
    }

    public void setShokushuDesc(String shokushuDesc) {
        this.shokushuDesc = shokushuDesc;
    }

}

