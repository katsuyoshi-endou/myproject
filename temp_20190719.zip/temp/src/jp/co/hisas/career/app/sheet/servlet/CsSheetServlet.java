package jp.co.hisas.career.app.sheet.servlet;

import java.util.List;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.sheet.dto.CsmSheetLayoutDto;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActorAndRefDto;
import jp.co.hisas.career.app.sheet.event.CsActorEventArg;
import jp.co.hisas.career.app.sheet.event.CsActorEventHandler;
import jp.co.hisas.career.app.sheet.event.CsActorEventResult;
import jp.co.hisas.career.app.sheet.event.CsSheetEventArg;
import jp.co.hisas.career.app.sheet.event.CsSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.CsSheetEventResult;
import jp.co.hisas.career.app.sheet.event.CsSheetPastEvArg;
import jp.co.hisas.career.app.sheet.event.CsSheetPastEvHdlr;
import jp.co.hisas.career.app.sheet.event.CsSheetPastEvRslt;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.KeepTokenServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.cache.CsTemplateCache;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class CsSheetServlet extends KeepTokenServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "CsSheet";
	private static final String FORWARD_PAGE = "/view/sheet/VHD010_CareerSheet.jsp";
	
	public String serviceMain( Tray tray ) throws CareerException {
		
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( tray.session, UserInfoBean.SESSION_KEY );
		tray.operatorGuid = userInfo.getOperatorGuid();
		
		// set SheetID on Session.
		String sheetId = CsUtil.setSheetIdOnSession( tray.request, tray.session );
		String actorCd = null;
		
		
		// Security check: Is the login user registered as actor/referer?
		if (!isRegisteredAsActor( tray, sheetId )) {
			if (!SU.equals( tray.state, "PAST" )) {
				throw new CareerException( "HJE-1001" );
			}
		}
		
		if (SU.equals( tray.state, "INIT" )) {
			tray.session.removeAttribute( CsSessionKey.CS_VIEW_SHEET_ACTOR_CD );
		}
		if (SU.equals( tray.state, "SWITCH_ACTOR" )) {
			// TODO: リクエスト改変に備えること
			actorCd = AU.getRequestValue( tray.request, "switchActorCd" );
			tray.session.setAttribute( CsSessionKey.CS_VIEW_SHEET_ACTOR_CD, actorCd );
		}
		if (SU.equals( tray.state, "EDIT" )) {
			// 部分編集モード
			tray.forwardUrl = "/view/sheet/CsPe-PartialEdit.jsp";
			String cspe = AU.getRequestValue( tray.request, "csPartialEdit" );
			String filename = "CsPe-" + cspe + ".html";
			String dirPath = AU.getSessionAttr( tray.session, CsSessionKey.CS_SHEET_TEMPLATE_DIR );
			String cspeTemplateData = getSheetTemplateData( dirPath + "partial_edit/" + filename );
			tray.session.setAttribute( CsSessionKey.CS_SHEET_TEMPLATE_CSPE, cspeTemplateData );
		}
		if (SU.equals( tray.state, "VIEW" )) {
			// 表示ONLYモード（子画面）
			actorCd = AU.getRequestValue( tray.request, "actorCd" );
			tray.session.setAttribute( CsSessionKey.CS_VIEW_SHEET_ACTOR_CD, actorCd );
		}
		if (SU.equals( tray.state, "RESTORE" )) {
			// 何もしない
		}
		if (SU.equals( tray.state, "PAST" )) {
			
			//過去シートID取得
			sheetId = getRelatedSheetId( tray, sheetId );
			
			//過去シート存在チェック
			boolean relatedSheetExists = sheetExistChk( tray, sheetId );
			if( !relatedSheetExists ) {
				//該当シートは存在しません。
				String msg = AU.getCommonLabel( tray, "LSHSHT_MSG_SHEET_NOT_EXIST" );
				tray.session.setAttribute( AppSessionKey.RESULT_MSG_ERROR, msg );
				throw new CareerException( "" );
			}
			
			//PHD010Command実行時に過去シードIDを取得するためにセッションに格納
			tray.session.setAttribute( CsSessionKey.CS_RELATED_SHEET_ID, sheetId );
			
			//過去シート用アクターコード取得
			getRelatedSheetActorCd( tray, sheetId );
			
		}
		
		// シートテンプレート・スクリプト TODO: Cache
		CsmSheetLayoutDto layoutDto = getSheetLayoutDto( tray, sheetId );
		String dirPath = getTemplateFileDir( layoutDto );
		String templateData = getSheetTemplateData( dirPath + layoutDto.getTemplateFile() );
		String templateDataJs = getSheetTemplateData( dirPath + layoutDto.getTemplateJsFile() );
		String CommonDataJs = getSheetTemplateData( dirPath + "common_script.js" );
		tray.session.setAttribute( CsSessionKey.CS_SHEET_TEMPLATE, templateData );
		tray.session.setAttribute( CsSessionKey.CS_SHEET_TEMPLATE_JS, templateDataJs );
		tray.session.setAttribute( CsSessionKey.CS_SHEET_COMMON_JS, CommonDataJs );
		tray.session.setAttribute( CsSessionKey.CS_SHEET_TEMPLATE_DIR, dirPath );
		
		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, sheetId, tray.state );
		
		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}
	
	private boolean sheetExistChk( Tray tray, String sheetId ) throws CareerException {
		
		CsSheetPastEvArg arg = new CsSheetPastEvArg( tray.loginNo );
		arg.sharp = "SHEET_EXISTANCE";
		arg.sheetId = sheetId;
		CsSheetPastEvRslt result = CsSheetPastEvHdlr.exec( arg );
		return result.sheetExistance;
		
	}

	private void getRelatedSheetActorCd( Tray tray, String sheetId ) throws CareerException {
		
		CsSheetPastEvArg arg = new CsSheetPastEvArg( tray.loginNo );
		arg.sharp = "PAST_ACTOR";
		arg.sheetId = sheetId;
		arg.operatorGuid = tray.operatorGuid;
		CsSheetPastEvRslt result = CsSheetPastEvHdlr.exec( arg );
		List<VCstSheetActorAndRefDto> actorCdList = result.actorCdList;
		
		if (actorCdList != null && actorCdList.size() > 0) {
			String actorCd = actorCdList.get( 0 ).getActorCd();
			tray.request.setAttribute( CsSessionKey.CS_VIEW_SHEET_ACTOR_CD, actorCd );
			//PHD010Command実行時に過去シード用アクターコードを取得するためにセッションに格納
			tray.session.setAttribute( CsSessionKey.CS_RELATED_ACTOR_CD, actorCd );
		} else {
			tray.request.setAttribute( CsSessionKey.CS_VIEW_SHEET_ACTOR_CD, "ref-other" );
			//PHD010Command実行時に過去シード用アクターコードを取得するためにセッションに格納
			tray.session.setAttribute( CsSessionKey.CS_RELATED_ACTOR_CD, "ref-other" );
		}
	}

	private String getRelatedSheetId ( Tray tray, String sheetId ) throws CareerException {
		
		String relatedId = AU.getRequestValue( tray.request, "relatedId" );
		CsSheetPastEvArg arg = new CsSheetPastEvArg( tray.loginNo );
		arg.relatedId = relatedId;
		arg.sharp = "PAST_SHEET_ID";
		arg.sheetId = sheetId;
		CsSheetPastEvRslt result = CsSheetPastEvHdlr.exec( arg );
		sheetId = result.relatedSheetId;
		return sheetId;
	}

	private boolean isRegisteredAsActor( Tray tray, String sheetId ) throws CareerException {
		CsActorEventArg arg = new CsActorEventArg( tray.loginNo );
		arg.sharp = "LIST_ACTREF";
		arg.sheetId = sheetId;
		CsActorEventResult result = CsActorEventHandler.exec( arg );
		List<VCstSheetActorAndRefDto> actorList = result.getActorList();
		for (VCstSheetActorAndRefDto dto : actorList) {
			if (tray.operatorGuid.equals( dto.getGuid() )) {
				return true;
			}
		}
		return false;
	}
	
	private CsmSheetLayoutDto getSheetLayoutDto( Tray tray, String sheetId ) throws CareerException {
		CsSheetEventArg arg = new CsSheetEventArg( tray.loginNo, tray.operatorGuid );
		arg.sharp = "LAYOUT_TEMPLATE";
		arg.sheetId = sheetId;
		arg.actorCd = AU.getReqSesVal( tray.request, CsSessionKey.CS_VIEW_SHEET_ACTOR_CD );
		CsSheetEventResult result = CsSheetEventHandler.exec( arg );
		CsmSheetLayoutDto dto = result.layoutTemplateDto;
		if ( dto == null ) {
			// レイアウト情報が取得できなかったため、汎用レイアウトで表示しています。
			String msg = AU.getCommonLabel( tray, "LSHSHT_MSG_GENERAL_LAYOUT" );
			tray.session.setAttribute( AppSessionKey.RESULT_MSG_WARN, msg );
			dto = new CsmSheetLayoutDto();
			dto.setTemplateFile( "pkg_default.html" );
		}
		return dto;
	}
	
	private String getSheetTemplateData( String path ) {
		String templateData = CsTemplateCache.getTemplate( path );
		return templateData;
	}
	
	private String getTemplateFileDir( CsmSheetLayoutDto dto ) {
		String dirPath = "";
		if (SU.isNotBlank( dto.getParty() )) {
			dirPath += dto.getParty() + "/";
		}
		if (SU.isNotBlank( dto.getVersion() )) {
			dirPath += dto.getVersion() + "/";
		}
		return dirPath;
	}
	
}
