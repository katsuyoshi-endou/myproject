/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.ZzCsmJkskGyomubDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class ZzCsmJkskGyomubDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " PARTY as party,"
                     + " SORT as sort,"
                     + " SHOKUSHU_NM as shokushuNm,"
                     + " SHOKUSHU_NM_2 as shokushuNm2,"
                     + " GYOMU_BUNRUI as gyomuBunrui,"
                     + " SHOKUSHU_DESC as shokushuDesc"
                     ;

    public ZzCsmJkskGyomubDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public ZzCsmJkskGyomubDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public ZzCsmJkskGyomubDto select(String party, String sort) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM ZZ_CSM_JKSK_GYOMUB"
                         + " WHERE PARTY = ?"
                         + " AND SORT = ?"
                         ;
        Log.sql("[DaoMethod Call] ZzCsmJkskGyomubDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, party);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, sort);
            rs = pstmt.executeQuery();
            ZzCsmJkskGyomubDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<ZzCsmJkskGyomubDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] ZzCsmJkskGyomubDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<ZzCsmJkskGyomubDto> lst = new ArrayList<ZzCsmJkskGyomubDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<ZzCsmJkskGyomubDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] ZzCsmJkskGyomubDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("[DaoMethod Call] ZzCsmJkskGyomubDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void executeDynamic(String sql) {

        Log.sql("[DaoMethod Call] ZzCsmJkskGyomubDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    private ZzCsmJkskGyomubDto transferRsToDto(ResultSet rs) throws SQLException {

        ZzCsmJkskGyomubDto dto = new ZzCsmJkskGyomubDto();
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setSort(DaoUtil.convertNullToString(rs.getString("sort")));
        dto.setShokushuNm(DaoUtil.convertNullToString(rs.getString("shokushuNm")));
        dto.setShokushuNm2(DaoUtil.convertNullToString(rs.getString("shokushuNm2")));
        dto.setGyomuBunrui(DaoUtil.convertNullToString(rs.getString("gyomuBunrui")));
        dto.setShokushuDesc(DaoUtil.convertNullToString(rs.getString("shokushuDesc")));
        return dto;
    }

}

