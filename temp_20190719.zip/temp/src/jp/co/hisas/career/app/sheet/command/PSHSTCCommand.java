package jp.co.hisas.career.app.sheet.command;

import jp.co.hisas.career.app.sheet.vm.VmVSHSTC;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.framework.trans.StateTransitionEvent;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class PSHSTCCommand extends AbstractCommand {
	
	public static final String KINOU_ID = "VSHSTC";
	private Tray tray;
	
	public PSHSTCCommand() {
		super( PSHSTCCommand.class, KINOU_ID, null );
	}
	
	public void init( StateTransitionEvent e ) {
		try {
			this.tray = new Tray( e );
			/* Not Update Token While Single Sheet.
			CSRFTokenUtil.setNewTokenNo( request, e.getResponse() ); */
			main();
		} catch (CareerException ex) {
			throw new CareerRuntimeException(ex);
		}
	}
	
	private void main() throws CareerException {
		
		VmVSHSTC vm = new VmVSHSTC( tray );
		tray.session.setAttribute( VmVSHSTC.VMID, vm );
		AU.setReqAttr( tray.request, "vm", vm );
		
		/* 操作ログ */
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, tray.state );
	}
	
}
