package jp.co.hisas.career.app.sheet.api.bulk.export;

import jp.co.hisas.career.app.sheet.api.Butler;
import jp.co.hisas.career.app.sheet.deliver.bulk.export.BulkExportGetDeliver;
import jp.co.hisas.career.app.sheet.deliver.bulk.export.BulkExportGetOrder;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.Tray;

public class BulkExportButler extends Butler {
	
	@Override
	public String takeGET( Tray tray ) throws CareerException {
		
		BulkExportGetOrder order = new BulkExportGetOrder( tray );
		order.instCd = tray.getSessionAttr( CsSessionKey.CS_BULK_INST_CD );
		order.scene = AU.getRequestValue( tray.request, "scene" );
		
		BulkExportEvRslt rslt = BulkExportGetDeliver.go( tray, order );
		
		AU.setReqAttr( tray.request, "dlFileName", "SheetList.csv" );
		AU.setReqAttr( tray.request, "dlCsvHeader", rslt.dlCsvHeader );
		AU.setReqAttr( tray.request, "dlCsvRows", rslt.dlCsvRows );
		
		return null;
	}
	
	@Override
	public String takePOST( Tray tray ) throws CareerException {
		return null;
	}
	
	@Override
	public String takePUT( Tray tray ) throws CareerException {
		return null;
	}
	
	@Override
	public String takeDELETE( Tray tray ) throws CareerException {
		return null;
	}
}
