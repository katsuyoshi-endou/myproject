package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.VZzCsmJkskSikakuDto;
import jp.co.hisas.career.ejb.AbstractEventResult;

public class JkskShikakuEventResult extends AbstractEventResult {
	
	private List<VZzCsmJkskSikakuDto> sikakuList = null;

	public List<VZzCsmJkskSikakuDto> getSikakuList() {
		return sikakuList;
	}

	public void setSikakuList( List<VZzCsmJkskSikakuDto> list ) {
		this.sikakuList = list;
	}
}
