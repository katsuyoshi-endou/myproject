package jp.co.hisas.career.app.sheet.event;

import java.util.List;

import jp.co.hisas.career.app.sheet.dao.MktNotificationDao;
import jp.co.hisas.career.app.sheet.dto.MktNotificationDto;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.log.Log;

public class MkN10nEvHdlr extends AbstractEventHandler<MkN10nEvArg, MkN10nEvRslt> {
	
	private String daoLoginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static MkN10nEvRslt exec( MkN10nEvArg arg ) throws CareerException {
		MkN10nEvHdlr handler = new MkN10nEvHdlr();
		return handler.call( arg );
	}
	
	public MkN10nEvRslt call( MkN10nEvArg arg ) throws CareerException {
		MkN10nEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		}
		else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected MkN10nEvRslt execute( MkN10nEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.daoLoginNo = arg.getLoginNo();
		
		MkN10nEvRslt result = new MkN10nEvRslt();
		
		if (SU.equals( arg.sharp, "GET_ALL_UNREAD_N10NS" )) {
			result.mkN10nList = getAllUnreadN10ns( arg );
		}
		else if (SU.equals( arg.sharp, "READ_N10N" )) {
			readNotification( arg );
		}
		
		return result;
	}
	
	private List<MktNotificationDto> getAllUnreadN10ns( MkN10nEvArg arg ) {
		MktNotificationDao dao = new MktNotificationDao( daoLoginNo );
		return dao.selectUnreadN10ns( arg.party, arg.guid );
	}
	
	private void readNotification( MkN10nEvArg arg ) {
		MktNotificationDao dao = new MktNotificationDao( daoLoginNo );
		MktNotificationDto dto = dao.select( arg.seq );
		if (dto == null) {
			return;
		}
		if (!SU.equals( dto.getParty(), arg.party ) ) {
			return;
		}
		if (!SU.equals( dto.getGuid(), arg.guid ) ) {
			return;
		}
		dto.setReadFlg( 1 );
		dao.update( dto );
	}
}
