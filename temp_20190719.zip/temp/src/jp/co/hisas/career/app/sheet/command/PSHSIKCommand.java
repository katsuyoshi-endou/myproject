package jp.co.hisas.career.app.sheet.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.sheet.event.JkskShikakuEventArg;
import jp.co.hisas.career.app.sheet.event.JkskShikakuEventHandler;
import jp.co.hisas.career.app.sheet.event.JkskShikakuEventResult;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.app.sheet.util.CsUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.framework.trans.StateTransitionEvent;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class PSHSIKCommand extends AbstractCommand {
	
	public static final String KINOU_ID = "VSHSIK";

	private HttpServletRequest request;
	private HttpSession session;
	private String state;
	
	public PSHSIKCommand() {
		super(PSHSIKCommand.class, KINOU_ID, null);
	}
	
	public void init( StateTransitionEvent e ) {
		try {
			request = e.getRequest();
			session = request.getSession( false );
			/* Not Update Token While Single Sheet.
			CSRFTokenUtil.setNewTokenNo( request, e.getResponse() ); */
			state = request.getParameter( "state" );
			main();
		} catch (CareerException ex) {
			throw new CareerRuntimeException( ex );
		}
	}
	
	private void main() throws CareerException {
		
		if ("INIT".equals( state )) {
			execEventInit();
		}
		
		/* 操作ログ */
		OutLogBean.outputLogSousa( request, KINOU_ID, (String)AU.getSessionAttr( session, CsSessionKey.CS_SHEET_ID ), state );
	}
	
	private void execEventInit() throws CareerException {
		
		String sheetId = CsUtil.setSheetIdOnSession( request, session );

		/* Set Args */
		JkskShikakuEventArg arg = new JkskShikakuEventArg( super.getLoginNo() );
		
		arg.sharp = "INIT";
		arg.sheetId = sheetId;
		
		/* Execute Event */
		JkskShikakuEventResult result = JkskShikakuEventHandler.exec( arg );
		
		/* Return to session */
		session.setAttribute( CsSessionKey.JKSK_SIKAKU_LIST, result.getSikakuList());
	}
}
