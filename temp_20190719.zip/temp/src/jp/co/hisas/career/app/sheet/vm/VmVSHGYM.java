package jp.co.hisas.career.app.sheet.vm;

import jp.co.hisas.career.framework.trans.ViewModel;
import jp.co.hisas.career.util.Tray;

public class VmVSHGYM extends ViewModel {
	
	public static String VMID = VmVSHGYM.class.getSimpleName();

	public VmVSHGYM(Tray tray) {
		super( tray );
	}
}
