/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CsmSheetLayoutJsDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String layoutCd;
    private String lineNo;
    private String script;

    public String getLayoutCd() {
        return layoutCd;
    }

    public void setLayoutCd(String layoutCd) {
        this.layoutCd = layoutCd;
    }

    public String getLineNo() {
        return lineNo;
    }

    public void setLineNo(String lineNo) {
        this.lineNo = lineNo;
    }

    public String getScript() {
        return script;
    }

    public void setScript(String script) {
        this.script = script;
    }

}

