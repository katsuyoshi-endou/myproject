package jp.co.hisas.career.app.sheet.event;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dao.VCsInfoAttrDao;
import jp.co.hisas.career.app.sheet.dao.VZzCsmJkskSikakuDao;
import jp.co.hisas.career.app.sheet.dto.VCsInfoAttrDto;
import jp.co.hisas.career.app.sheet.dto.VZzCsmJkskSikakuDto;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

public class JkskShikakuEventHandler extends AbstractEventHandler<JkskShikakuEventArg, JkskShikakuEventResult> {

	private String loginNo;

	public static JkskShikakuEventResult exec( JkskShikakuEventArg arg ) throws CareerException {
		JkskShikakuEventHandler handler = new JkskShikakuEventHandler();
		return handler.call( arg );
	}

	@Override
	public JkskShikakuEventResult call( JkskShikakuEventArg arg ) throws CareerException {
		JkskShikakuEventResult result = null;

		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );

		return result;
	}

	@Override
	protected JkskShikakuEventResult execute( JkskShikakuEventArg arg ) throws CareerException {
		arg.validateArg();
		this.loginNo = arg.getLoginNo();

		JkskShikakuEventResult result = new JkskShikakuEventResult();

		try {
			// 原籍会社コードの取得
			arg.clsHCode = getGensekiCompanyCode( arg );
			
			// 資格マスタ情報の取得
			result.setSikakuList( getShikakuList( arg ));
			
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
		return result;
	}
	

	/**
	 * 資格マスタリストを取得する
	 * 
	 * @param arg
	 * @return
	 */
	private List<VZzCsmJkskSikakuDto> getShikakuList( JkskShikakuEventArg arg ) {
		StringBuilder sql = new StringBuilder();
		sql.append( "SELECT " + VZzCsmJkskSikakuDao.ALLCOLS + " FROM V_ZZ_CSM_JKSK_SIKAKU " );
		sql.append( "WHERE GNSK_COMP_CD = ? " );
		sql.append( "ORDER BY SIKAKU_CD" );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( arg.clsHCode );

		VZzCsmJkskSikakuDao dao = new VZzCsmJkskSikakuDao( loginNo );
		List<VZzCsmJkskSikakuDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ));
		if ( list == null) {
			list = new ArrayList<VZzCsmJkskSikakuDto>();
		}
		return list;
	}
	
	/**
	 * 原籍会社コードを取得する
	 * 
	 * @param arg
	 * @return 原籍会社コード
	 */
	private String getGensekiCompanyCode( JkskShikakuEventArg arg ) {
		VCsInfoAttrDao dao = new VCsInfoAttrDao( loginNo );
		VCsInfoAttrDto dto = dao.select( arg.sheetId );
		if ( dto == null ) {
			dto = new VCsInfoAttrDto();
		}
		return dto.getClsHCd();
	}
}
