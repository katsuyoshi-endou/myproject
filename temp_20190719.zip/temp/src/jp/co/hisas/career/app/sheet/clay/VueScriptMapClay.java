package jp.co.hisas.career.app.sheet.clay;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.app.sheet.util.CsSessionKey;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.Log;

public class VueScriptMapClay extends HttpServlet {
	
	protected ServletContext ctx = null;
	private static final long serialVersionUID = 1L;
	
	public void init( ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	@Override
	public void service( HttpServletRequest req, HttpServletResponse res ) throws IOException, ServletException {
		try {
			Object userinfo = req.getSession( false ).getAttribute( "userinfo" );
			if (userinfo == null) {
				res.getWriter().write( "" );
				return;
			}
			Tray tray = new Tray( req, res );
			AU.setReqAttr( tray.request, "tray", tray );
			
			String buff = getSourceMap( tray );
			
			res.setContentType( "text/javascript; charset=UTF-8" );
			res.getWriter().write( buff );
			
		} catch (Exception e) {
			Log.error( req, e );
		}
	}
	
	/**
	 * vue-script.js から参照されるソースマップを返す。<br>
	 * ソースマップは固定で vue-script.bundle.js.map を探しに行くので、
	 * どの INST のものなのかを特定するためにセッションを利用する。
	 */
	private static String getSourceMap( Tray tray ) {
		try {
			String inst = AU.getSessionAttr( tray.session, CsSessionKey.CS_BULK_INST_CD );
			String fullPath = AppDef.APP_DIR + "/clay/" + inst + "/" + "vue-script.bundle.js.map";
			String template = FileUtils.readFileToString( new File( fullPath ), "utf-8" );
			return template;
		} catch (IOException e) {
			Log.warn( e.getLocalizedMessage() );
			return null;
		}
	}
	
}
