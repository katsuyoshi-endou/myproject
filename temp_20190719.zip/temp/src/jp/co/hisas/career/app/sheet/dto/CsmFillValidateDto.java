/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CsmFillValidateDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String fillValidateId;
    private String formatRegex;
    private String msgId;

    public String getFillValidateId() {
        return fillValidateId;
    }

    public void setFillValidateId(String fillValidateId) {
        this.fillValidateId = fillValidateId;
    }

    public String getFormatRegex() {
        return formatRegex;
    }

    public void setFormatRegex(String formatRegex) {
        this.formatRegex = formatRegex;
    }

    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

}

