package jp.co.hisas.career.app.sheet.deliver.sheet;

import java.util.List;

import jp.co.hisas.career.app.sheet.dto.CsmSheetOperationDto;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Tray;

public class SheetDeliver {
	
	public static CsmSheetOperationDto getOperation( Tray tray, String operationCd ) throws CareerException {
		SheetEvArg arg = new SheetEvArg( tray.loginNo );
		arg.sharp = "GetOperation";
		arg.party = tray.party;
		arg.operationCd = operationCd;
		SheetEvRslt result = SheetEvHdlr.exec( arg );
		return result.operation;
	}
	
	public static CsmSheetOperationDto getFirstOperation( Tray tray ) throws CareerException {
		SheetEvArg arg = new SheetEvArg( tray.loginNo );
		arg.sharp = "GetFirstOperation";
		arg.party = tray.party;
		SheetEvRslt result = SheetEvHdlr.exec( arg );
		return result.operation;
	}
	
	public static List<String> getFillIdList( String daoLoginNo, String fillSetCd ) throws CareerException {
		SheetEvArg arg = new SheetEvArg( daoLoginNo );
		arg.sharp = "GetFillIdList";
		arg.fillSetCd = fillSetCd;
		SheetEvRslt result = SheetEvHdlr.exec( arg );
		return result.fillIdList;
	}
	
}
