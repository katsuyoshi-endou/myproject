/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CsmSheetFormGrpDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String party;
    private String operationCd;
    private String formGrpCd;
    private String formGrpNm;

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getOperationCd() {
        return operationCd;
    }

    public void setOperationCd(String operationCd) {
        this.operationCd = operationCd;
    }

    public String getFormGrpCd() {
        return formGrpCd;
    }

    public void setFormGrpCd(String formGrpCd) {
        this.formGrpCd = formGrpCd;
    }

    public String getFormGrpNm() {
        return formGrpNm;
    }

    public void setFormGrpNm(String formGrpNm) {
        this.formGrpNm = formGrpNm;
    }

}

