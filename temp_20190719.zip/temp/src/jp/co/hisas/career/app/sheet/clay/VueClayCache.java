package jp.co.hisas.career.app.sheet.clay;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.io.FileUtils;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.util.log.Log;

public final class VueClayCache {
	
	private ConcurrentHashMap<String, String> map = new ConcurrentHashMap<String, String>();
	
	/**
	 * Singleton パターン - Wikipedia
	 * https://ja.wikipedia.org/wiki/Singleton_パターン
	 */
	private VueClayCache() {
	}
	
	private static class CsTemplateCacheHolder {
		private static final VueClayCache instance = new VueClayCache();
	}
	
	private static VueClayCache getInstance() {
		return CsTemplateCacheHolder.instance;
	}
	
	public static String getTemplate( String templateId ) {
		VueClayCache instance = VueClayCache.getInstance();
		return instance.getTemplateData( templateId );
	}
	
	private String getTemplateData( String templateId ) {
		if (!map.containsKey( templateId )) {
			addCache( templateId );
		}
		return map.get( templateId );
	}
	
	private void addCache( String templatePath ) {
		try {
			String fullPath = AppDef.APP_DIR + "/clay/" + templatePath;
			String template = FileUtils.readFileToString( new File( fullPath ), "utf-8" );
			map.put( templatePath, template );
		} catch (IOException e) {
			Log.warn( e.getLocalizedMessage() );
			map.put( templatePath, null );
		}
	}
	
	public static void clearCache() {
		VueClayCache instance = VueClayCache.getInstance();
		instance.clearCacheData();
	}
	
	private void clearCacheData() {
		map = new ConcurrentHashMap<String, String>();
	}
	
}
