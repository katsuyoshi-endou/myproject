/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.CsxSheetStatusDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CsxSheetStatusDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " SHEET_ID as sheetId,"
                     + " FLOW_CD as flowCd,"
                     + " SEQ_NO as seqNo,"
                     + " STATUS_CD as statusCd,"
                     + " STATUS_NM as statusNm,"
                     + " MAIN_ACTOR_CD as mainActorCd,"
                     + " MAIN_PERSON_ID as mainPersonId,"
                     + " MAIN_PERSON_NAME as mainPersonName,"
                     + " DONE_PERSON_ID as donePersonId,"
                     + " DONE_PERSON_NAME as donePersonName,"
                     + " TIMESTAMP as timestamp"
                     ;

    public CsxSheetStatusDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CsxSheetStatusDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public List<CsxSheetStatusDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CsxSheetStatusDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CsxSheetStatusDto> lst = new ArrayList<CsxSheetStatusDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CsxSheetStatusDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CsxSheetStatusDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private CsxSheetStatusDto transferRsToDto(ResultSet rs) throws SQLException {

        CsxSheetStatusDto dto = new CsxSheetStatusDto();
        dto.setSheetId(DaoUtil.convertNullToString(rs.getString("sheetId")));
        dto.setFlowCd(DaoUtil.convertNullToString(rs.getString("flowCd")));
        dto.setSeqNo(DaoUtil.convertNullToString(rs.getString("seqNo")));
        dto.setStatusCd(DaoUtil.convertNullToString(rs.getString("statusCd")));
        dto.setStatusNm(DaoUtil.convertNullToString(rs.getString("statusNm")));
        dto.setMainActorCd(DaoUtil.convertNullToString(rs.getString("mainActorCd")));
        dto.setMainPersonId(DaoUtil.convertNullToString(rs.getString("mainPersonId")));
        dto.setMainPersonName(DaoUtil.convertNullToString(rs.getString("mainPersonName")));
        dto.setDonePersonId(DaoUtil.convertNullToString(rs.getString("donePersonId")));
        dto.setDonePersonName(DaoUtil.convertNullToString(rs.getString("donePersonName")));
        dto.setTimestamp(DaoUtil.convertNullToString(rs.getString("timestamp")));
        return dto;
    }

}

