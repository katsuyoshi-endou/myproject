/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.CsmExcelFillMapDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CsmExcelFillMapDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " PARTY as party,"
                     + " LAYOUT_CD as layoutCd,"
                     + " FILL_ID as fillId,"
                     + " SHEET as sheet,"
                     + " CELL as cell"
                     ;

    public CsmExcelFillMapDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CsmExcelFillMapDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public CsmExcelFillMapDto select(String party, String layoutCd, String fillId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CSM_EXCEL_FILL_MAP"
                         + " WHERE PARTY = ?"
                         + " AND LAYOUT_CD = ?"
                         + " AND FILL_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CsmExcelFillMapDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, party);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, layoutCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, fillId);
            rs = pstmt.executeQuery();
            CsmExcelFillMapDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    private CsmExcelFillMapDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmExcelFillMapDto dto = new CsmExcelFillMapDto();
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setLayoutCd(DaoUtil.convertNullToString(rs.getString("layoutCd")));
        dto.setFillId(DaoUtil.convertNullToString(rs.getString("fillId")));
        dto.setSheet(DaoUtil.convertNullToString(rs.getString("sheet")));
        dto.setCell(DaoUtil.convertNullToString(rs.getString("cell")));
        return dto;
    }

    public List<CsmExcelFillMapDto> selectFillIds(String party, String layoutCd) {

        final String sql = "select " + ALLCOLS + " from CSM_EXCEL_FILL_MAP where PARTY = ? and LAYOUT_CD = ?";
        Log.sql("[DaoMethod Call] CsmExcelFillMapDao.selectFillIds");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, party);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, layoutCd);
            rs = pstmt.executeQuery();
            List<CsmExcelFillMapDto> lst = new ArrayList<CsmExcelFillMapDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

