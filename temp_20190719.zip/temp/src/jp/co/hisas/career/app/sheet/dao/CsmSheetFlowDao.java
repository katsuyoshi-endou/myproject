/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.app.sheet.dto.CsmSheetFlowDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CsmSheetFlowDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " FLOW_CD as flowCd,"
                     + " SEQ_NO as seqNo,"
                     + " STATUS_CD as statusCd,"
                     + " STATUS_NM as statusNm,"
                     + " STATUS_GRP_CD as statusGrpCd,"
                     + " MAIN_ACTOR_CD as mainActorCd"
                     ;

    public CsmSheetFlowDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CsmSheetFlowDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public List<CsmSheetFlowDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CsmSheetFlowDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CsmSheetFlowDto> lst = new ArrayList<CsmSheetFlowDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CsmSheetFlowDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CsmSheetFlowDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private CsmSheetFlowDto transferRsToDto(ResultSet rs) throws SQLException {

        CsmSheetFlowDto dto = new CsmSheetFlowDto();
        dto.setFlowCd(DaoUtil.convertNullToString(rs.getString("flowCd")));
        dto.setSeqNo(DaoUtil.convertNullToString(rs.getString("seqNo")));
        dto.setStatusCd(DaoUtil.convertNullToString(rs.getString("statusCd")));
        dto.setStatusNm(DaoUtil.convertNullToString(rs.getString("statusNm")));
        dto.setStatusGrpCd(DaoUtil.convertNullToString(rs.getString("statusGrpCd")));
        dto.setMainActorCd(DaoUtil.convertNullToString(rs.getString("mainActorCd")));
        return dto;
    }

}

