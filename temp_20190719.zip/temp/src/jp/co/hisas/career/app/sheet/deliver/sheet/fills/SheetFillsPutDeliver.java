package jp.co.hisas.career.app.sheet.deliver.sheet.fills;

import java.util.Map;

import jp.co.hisas.career.app.sheet.dto.CstSheetExclusiveDto;
import jp.co.hisas.career.app.sheet.event.CsSheetEventArg;
import jp.co.hisas.career.app.sheet.event.CsSheetEventHandler;
import jp.co.hisas.career.app.sheet.event.CsSheetEventResult;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class SheetFillsPutDeliver {
	
	public static SheetFillsPutReply go( Tray tray, SheetFillsPutOrder order ) throws CareerException {
		SheetFillsPutReply rep = new SheetFillsPutReply();
		
		CsSheetEventArg arg = new CsSheetEventArg( tray.loginNo, tray.operatorGuid );
		arg.sharp = "STAY";
		arg.sheetId = order.sheetId;
		arg.actorCd = order.actorCd;
		CstSheetExclusiveDto exc = new CstSheetExclusiveDto();
		exc.setSheetId( order.sheetId );
		exc.setExclusiveKey( SU.toInt( order.exclusiveKey, 0 ) );
		arg.exclusiveKey = exc;
		arg.fillReqMap = (Map<String, String>)order.fills;
		CsSheetEventResult rslt = CsSheetEventHandler.exec( arg );
		
		rep.errorExclusive = rslt.getResultErrorMessage() != null;
		return rep;
	}
	
}
