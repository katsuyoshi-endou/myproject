package jp.co.hisas.career.app.sheet.garage;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.app.sheet.dao.VCstSheetActorAndRefDao;
import jp.co.hisas.career.app.sheet.dto.VCstSheetActorAndRefDto;
import jp.co.hisas.career.util.dao.DaoUtil;

public class GetActorListGarage extends Garage {
	
	public GetActorListGarage(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public List<VCstSheetActorAndRefDto> getActorList( String sheetId, String operatorGuid ) throws Exception {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select" + VCstSheetActorAndRefDao.ALLCOLS );
		sql.append( "   from V_CST_SHEET_ACTOR_AND_REF ");
		sql.append( "  where SHEET_ID = ? and GUID = ? ");
		sql.append( "  order by case when ACTOR_CD = MAIN_ACTOR_CD then '999' else ACTOR_SORT end desc ");
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( sheetId );
		paramList.add( operatorGuid );
		
		VCstSheetActorAndRefDao dao = new VCstSheetActorAndRefDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
}
