/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class VCstSheetActorAndRefDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String actOrRef;
    private String sheetId;
    private String actorCd;
    private String actorNm;
    private String actorSort;
    private String guid;
    private String personName;
    private String mainActorCd;
    private String holdGuid;

    public String getActOrRef() {
        return actOrRef;
    }

    public void setActOrRef(String actOrRef) {
        this.actOrRef = actOrRef;
    }

    public String getSheetId() {
        return sheetId;
    }

    public void setSheetId(String sheetId) {
        this.sheetId = sheetId;
    }

    public String getActorCd() {
        return actorCd;
    }

    public void setActorCd(String actorCd) {
        this.actorCd = actorCd;
    }

    public String getActorNm() {
        return actorNm;
    }

    public void setActorNm(String actorNm) {
        this.actorNm = actorNm;
    }

    public String getActorSort() {
        return actorSort;
    }

    public void setActorSort(String actorSort) {
        this.actorSort = actorSort;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getMainActorCd() {
        return mainActorCd;
    }

    public void setMainActorCd(String mainActorCd) {
        this.mainActorCd = mainActorCd;
    }

    public String getHoldGuid() {
        return holdGuid;
    }

    public void setHoldGuid(String holdGuid) {
        this.holdGuid = holdGuid;
    }

}

