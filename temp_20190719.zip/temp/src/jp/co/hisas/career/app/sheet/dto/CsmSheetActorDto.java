/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class CsmSheetActorDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String flowCd;
    private String actOrRef;
    private String actorCd;
    private String actorNm;
    private String lpadSort;

    public String getFlowCd() {
        return flowCd;
    }

    public void setFlowCd(String flowCd) {
        this.flowCd = flowCd;
    }

    public String getActOrRef() {
        return actOrRef;
    }

    public void setActOrRef(String actOrRef) {
        this.actOrRef = actOrRef;
    }

    public String getActorCd() {
        return actorCd;
    }

    public void setActorCd(String actorCd) {
        this.actorCd = actorCd;
    }

    public String getActorNm() {
        return actorNm;
    }

    public void setActorNm(String actorNm) {
        this.actorNm = actorNm;
    }

    public String getLpadSort() {
        return lpadSort;
    }

    public void setLpadSort(String lpadSort) {
        this.lpadSort = lpadSort;
    }

}

