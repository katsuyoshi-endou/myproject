/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jp.co.hisas.career.app.sheet.dto.CstSheetActionLogDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

public class CstSheetActionLogDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " TIMESTAMP as timestamp,"
                     + " SHEET_ID as sheetId,"
                     + " FLOW_CD as flowCd,"
                     + " FLOW_PTN as flowPtn,"
                     + " STATUS_CD as statusCd,"
                     + " ACTOR_CD as actorCd,"
                     + " LOGIN_PERSON_ID as loginPersonId,"
                     + " ACTION_CD as actionCd,"
                     + " AFTER_STATUS_CD as afterStatusCd,"
                     + " DELIV_MSG as delivMsg"
                     ;

    public CstSheetActionLogDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CstSheetActionLogDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public void insert(CstSheetActionLogDto dto) {

        final String sql = "INSERT INTO CST_SHEET_ACTION_LOG ("
                         + "TIMESTAMP,"
                         + "SHEET_ID,"
                         + "FLOW_CD,"
                         + "FLOW_PTN,"
                         + "STATUS_CD,"
                         + "ACTOR_CD,"
                         + "LOGIN_PERSON_ID,"
                         + "ACTION_CD,"
                         + "AFTER_STATUS_CD,"
                         + "DELIV_MSG"
                         + ")VALUES(?,?,?,?,?,?,?,?,?,? )"
                         ;
        Log.sql("[DaoMethod Call] CstSheetActionLogDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getTimestamp());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getSheetId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getFlowCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getFlowPtn());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getStatusCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getActorCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getLoginPersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 8, dto.getActionCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 9, dto.getAfterStatusCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 10, dto.getDelivMsg());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

}

