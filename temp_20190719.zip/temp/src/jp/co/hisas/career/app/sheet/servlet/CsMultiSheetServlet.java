package jp.co.hisas.career.app.sheet.servlet;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.KeepTokenServlet;
import jp.co.hisas.career.app.sheet.bean.CsMultiSheetActionBean;
import jp.co.hisas.career.app.sheet.bean.CsMultiSheetSearchBean;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class CsMultiSheetServlet extends KeepTokenServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "CsMulti";
	private static final String FORWARD_PAGE = "/view/sheet/layout_multi/Multi_Stamp.jsp";
	
	public String serviceMain( Tray tray ) throws CareerException {
		
		// if 業務アカウント → 統合アカウントに変換
		UserInfoBean userInfo = AU.getSessionAttr( tray.session, UserInfoBean.SESSION_KEY );
		tray.operatorGuid = userInfo.getOperatorGuid();
		
		if (SU.matches( tray.state, "STAY|FORWARD|BACKWARD|RESUME|SKIP" )) {
			execMultiSheetAction( tray );
			tray.forwardUrl = "/view/sheet/layout_multi/Multi_Stamp.jsp";
		}
		else if (SU.equals( tray.state, "EXCEL_DL" )) {
			execMultiSheetSearch( tray );
			String xlTemplateType = AU.getRequestValue( tray.request, "xlTemplateType" );
			String xlTemplateId   = AU.getRequestValue( tray.request, "xlTemplateId" );
			Map<Integer, List<String>> rows = getExcelDlRows( tray, xlTemplateId );
			tray.session.setAttribute( "EXCEL_DL_ROWS", rows );
			tray.forwardUrl = "/servlet/ExcelDownloadServlet?state=" + xlTemplateType;
		}
		else {
			execMultiSheetSearch( tray );
			tray.forwardUrl = "/view/sheet/layout_multi/Multi_Stamp.jsp";
		}
		
		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, tray.state );
		
		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}
	
	private void execMultiSheetAction( Tray tray ) throws CareerException {
		CsMultiSheetActionBean bean = new CsMultiSheetActionBean( tray.loginNo, tray.operatorGuid );
		bean.execMultiSheetAction( tray.state, tray.request );
	}
	
	private void execMultiSheetSearch( Tray tray ) throws CareerException {
		CsMultiSheetSearchBean bean = new CsMultiSheetSearchBean( tray.loginNo, tray.operatorGuid );
		bean.execMultiSheetSearch( tray.state, tray.request, "STAMP" );
	}
	
	private Map<Integer, List<String>> getExcelDlRows( Tray tray, String xlTemplateId ) throws CareerException {
		Map<Integer, List<String>> rows = new LinkedHashMap<Integer, List<String>>();
		return rows;
	}
	
}
