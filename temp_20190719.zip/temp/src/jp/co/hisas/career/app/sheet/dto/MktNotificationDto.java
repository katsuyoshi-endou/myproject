/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.app.sheet.dto;

import java.io.Serializable;

public class MktNotificationDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer n10nSeq;
    private String party;
    private String guid;
    private String n10nText;
    private Integer readFlg;
    private String sender;
    private String sentAt;

    public Integer getN10nSeq() {
        return n10nSeq;
    }

    public void setN10nSeq(Integer n10nSeq) {
        this.n10nSeq = n10nSeq;
    }

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getN10nText() {
        return n10nText;
    }

    public void setN10nText(String n10nText) {
        this.n10nText = n10nText;
    }

    public Integer getReadFlg() {
        return readFlg;
    }

    public void setReadFlg(Integer readFlg) {
        this.readFlg = readFlg;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getSentAt() {
        return sentAt;
    }

    public void setSentAt(String sentAt) {
        this.sentAt = sentAt;
    }

}

