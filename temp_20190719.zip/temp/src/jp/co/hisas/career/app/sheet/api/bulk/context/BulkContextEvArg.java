package jp.co.hisas.career.app.sheet.api.bulk.context;

import jp.co.hisas.career.app.sheet.deliver.bulk.context.BulkContextGetOrder;
import jp.co.hisas.career.app.sheet.deliver.bulk.context.BulkContextPutOrder;
import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class BulkContextEvArg extends AbstractEventArg {
	
	public String sharp = null;
	public BulkContextGetOrder orderGET;
	public BulkContextPutOrder orderPUT;
	
	public BulkContextEvArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: loginNo is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		String className = BulkContextEvArg.class.getName();
		if (SU.isBlank( sharp )) {
			throw new CareerException( className + "Invalid: sharp is null." );
		}
		// TODO: リクエストチェック機構
	}
	
}
