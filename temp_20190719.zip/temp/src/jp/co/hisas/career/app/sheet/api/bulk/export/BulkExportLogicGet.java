package jp.co.hisas.career.app.sheet.api.bulk.export;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.sheet.api.bulk.BulkEvRslt;
import jp.co.hisas.career.app.sheet.api.bulk.BulkLogicGet;
import jp.co.hisas.career.app.sheet.api.bulk.BulkSheet;
import jp.co.hisas.career.app.sheet.api.bulk.BulkSheetColumn;
import jp.co.hisas.career.app.sheet.deliver.bulk.export.BulkExportGetOrder;
import jp.co.hisas.career.util.property.CommonLabel;

public class BulkExportLogicGet {
	
	private String daoLoginNo;
	
	public BulkExportLogicGet(String daoLoginNo) {
		this.daoLoginNo = daoLoginNo;
	}
	
	protected BulkExportEvRslt main( BulkExportGetOrder o ) {
		BulkExportEvRslt evRslt = new BulkExportEvRslt();
		
		BulkLogicGet logic = new BulkLogicGet( daoLoginNo );
		BulkEvRslt rslt = logic.makeSheetListForCsv( o );
		
		List<String> csvHeader = new ArrayList<String>();
		for (Map<String, String> d : rslt.colDefMap) {
			String seqNo = d.get( "SEQ_NO" );
			String labelId = String.format( "LSHBLK_HEADER.%s.%s.col%s", o.instCd, o.scene, seqNo );
			String label = CommonLabel.getLabel( o.party, labelId );
			csvHeader.add( label );
		}
		evRslt.dlCsvHeader = csvHeader;
		
		List<List<String>> csvRows = new ArrayList<List<String>>();
		for (BulkSheet s : rslt.bulkSheetSet.values()) {
			List<String> r = new ArrayList<String>();
			for (Map<String, String> d : rslt.colDefMap) {
				BulkSheetColumn c = s.cols.get( "col" + d.get( "SEQ_NO" ) );
				String text = c.fill != null ? c.fill.content : c.text;
				r.add( text );
			}
			csvRows.add( r );
		}
		evRslt.dlCsvRows = csvRows;
		
		return evRslt;
	}
	
}
