package jp.co.hisas.career.app;

import jp.co.hisas.career.util.property.ReadFile;

public class AppDef {
	
	public static final String APP_ID;
	public static final String CTX_ROOT;
	public static final String HOME_JSP; // for only HomeServlet
	public static final String HOME_URL;
	
	/** アプリケーションディレクトリ <code>C:/Lysithea/Career/AppId</code> */
	public static final String APP_DIR;
	
	private AppDef() {
		/** Singleton */
	}
	
	/**
	 * Static Initializer
	 */
	static {
		APP_ID = getFieldValueFromThisApp( "APP_ID" );
		CTX_ROOT = getFieldValueFromThisApp( "CTX_ROOT" );
		HOME_JSP = getFieldValueFromThisApp( "HOME_JSP" );
		HOME_URL = "/servlet/HomeServlet";
		APP_DIR = ReadFile.getCareerBaseDir() + "/" + APP_ID;
	}
	
	private static String getFieldValueFromThisApp( String fieldName ) {
		String fieldValue = null;
		try {
			Class<?> cls = Class.forName( "jp.co.hisas.career.app.ThisApp" );
			fieldValue = (String)cls.getField( fieldName ).get( null );
		} catch (ClassNotFoundException | IllegalArgumentException | IllegalAccessException |
				 NoSuchFieldException | SecurityException e) {
			e.printStackTrace( System.err );
		}
		return fieldValue;
	}
}
