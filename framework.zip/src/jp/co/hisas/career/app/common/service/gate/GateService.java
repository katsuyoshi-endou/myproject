package jp.co.hisas.career.app.common.service.gate;

import java.util.Map;

import jp.co.hisas.career.app.common.bean.UserBean;
import jp.co.hisas.career.app.common.service.gate.auth.GateAuthEvArg;
import jp.co.hisas.career.app.common.service.gate.auth.GateAuthEvHdlr;
import jp.co.hisas.career.app.common.service.gate.auth.GateAuthEvRslt;
import jp.co.hisas.career.app.common.service.gate.auth.GateAuthOrder;
import jp.co.hisas.career.app.common.service.gate.auth.GateReceiveOrder;
import jp.co.hisas.career.app.common.service.gate.auth.GateSecretOrder;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Line;

public class GateService {
	
	public static GateAuthEvRslt auth( Line line, GateAuthOrder order ) throws CareerException {
		GateAuthEvArg arg = new GateAuthEvArg( line.tracer );
		arg.sharp = "AUTH";
		arg.authOrder = order;
		return GateAuthEvHdlr.exec( arg );
	}
	
	public static GateAuthEvRslt getSecret( Line line, GateSecretOrder order ) throws CareerException {
		
		UserBean user = line.getUser();
		
		order.pid = user.getPid();
		order.party = user.getParty();
		
		GateAuthEvArg arg = new GateAuthEvArg( line.tracer );
		arg.sharp = "SECRET";
		arg.secretOrder = order;
		return GateAuthEvHdlr.exec( arg );
	}
	
	public static Map<String, String> receive( GateReceiveOrder order ) throws CareerException {
		GateAuthEvArg arg = new GateAuthEvArg( order.tracer );
		arg.sharp = "RECEIVE";
		arg.receiveOrder = order;
		GateAuthEvRslt rslt = GateAuthEvHdlr.exec( arg );
		return rslt.gateArgs;
	}
}
