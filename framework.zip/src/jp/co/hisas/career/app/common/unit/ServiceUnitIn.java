package jp.co.hisas.career.app.common.unit;

public class ServiceUnitIn {
	
	public String tracer;
	
	public ServiceUnitIn(String daoLoginNo) {
		this.tracer = daoLoginNo;
	}
	
}
