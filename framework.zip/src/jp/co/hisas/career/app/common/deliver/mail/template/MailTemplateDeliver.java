package jp.co.hisas.career.app.common.deliver.mail.template;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Tray;

public class MailTemplateDeliver {
	
	public static MailTemplateEvRslt go( Tray tray, MailTemplateGetOrder order ) throws CareerException {
		order.validate();
		
		MailTemplateEvArg arg = new MailTemplateEvArg( tray.loginNo );
		arg.sharp = "GET";
		arg.orderGET = order;
		return MailTemplateEvHdlr.exec( arg );
	}
}
