package jp.co.hisas.career.app.common.servlet;

import jp.co.hisas.career.framework.trans.NoTokenServlet;
import jp.co.hisas.career.util.Tray;

public class HomeServlet extends NoTokenServlet {
	
	private static final long serialVersionUID = 1L;
	
	@Override
	public String serviceMain( Tray tray ) throws Exception {
		
		return "/servlet/AppFrontServlet";
	}
	
}
