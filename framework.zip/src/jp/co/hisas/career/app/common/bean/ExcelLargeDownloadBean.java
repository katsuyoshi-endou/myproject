package jp.co.hisas.career.app.common.bean;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.useful.SqlPropDao;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

public class ExcelLargeDownloadBean implements Serializable {
	
	HttpServletRequest	request;
	HttpSession			session;
	String				loginNo;
	
	public Workbook createWorkbook( HttpServletRequest req, HttpSession ses, String sharp, String templateFileName ) throws Exception {
		this.request = req;
		this.session = ses;
		final UserInfoBean userinfo = (UserInfoBean)session.getAttribute( "userinfo" );
		this.loginNo = (userinfo != null) ? userinfo.getLogin_no() : "";
		
		/*
		 * XSSFはメモリを大量消費するので、SXSSFを利用する。書き込み専用になるが、テンプレートファイルの利用は可能
		 * https://poi.apache
		 * .org/apidocs/org/apache/poi/xssf/streaming/SXSSFWorkbook.html
		 */
		XSSFWorkbook template = readTemplate( templateFileName );
		SXSSFWorkbook workbook = new SXSSFWorkbook( template );
		
		/*
		 * メモリの都合上、結果セットに紐付く全ての値をまとめて保持することができない。
		 * コネクションを開いたまま、結果セットから値を取りつつExcel出力→メモリ解放する。 直列化の都合上、ここからDaoを呼び出す
		 */
		String sql = getPreformattedSql( ReadFile.sqlProperties.getProperty( AU.getRequestValue( req, "sqlPropKey" ) ), req );
		Connection conn = PZZ040_SQLUtility.getConnection( this.loginNo );
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement( sql );
		} catch (SQLException e) {
			PZZ040_SQLUtility.removeCachedConnection();
			throw new CareerSQLException( e );
		}
		// フェッチサイズ調整
		pstmt.setFetchSize( 100 );
		SqlPropDao dao = new SqlPropDao( this.loginNo );
		ResultSet rs = dao.getResulSet( pstmt );
		
		Sheet sheet = workbook.getSheetAt( 0 );
		Integer[] offsetRC = getOffsetRC( template.getSheetAt( 0 ) );
		int offsetR = offsetRC[0];
		int offsetC = offsetRC[1];
		
		try {
			//カラム情報取得
			ResultSetMetaData rsmd = rs.getMetaData();
			int colCnt = rsmd.getColumnCount();
			List<String> colNameList = new ArrayList<String>();
			for (int k = 1; k <= colCnt; k++) {
				colNameList.add( rsmd.getColumnName( k ) );
			}
			int rowNo = 1;
			while (rs.next()) {
				List<String> datalist = new ArrayList<String>();
				Row row = sheet.createRow( rowNo + offsetR );
				datalist = dao.transferRsToDto( colNameList, rs );
				for (int j = 0; j < colNameList.size(); j++) {
					Cell cell = row.getCell( offsetC + j );
					cell = (cell != null) ? cell : row.createCell( offsetC + j );
					String data = datalist.get( j );
					data = SU.isBlank( data ) ? null : data;
					cell.setCellValue( data );
				}
				rowNo++;
			}
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, rs );
		}
		return workbook;
	}
	
	/**
	 * テンプレートの読み込み
	 * 
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	private XSSFWorkbook readTemplate( String templateFileName ) throws FileNotFoundException, IOException {
		String templateFile = templateFileName + ".xlsx";
		String fullPath = AppDef.APP_DIR + "/exceltemplate/" + templateFile;
		XSSFWorkbook workbook = new XSSFWorkbook( new FileInputStream( fullPath ) );
		return workbook;
	}
	
	/**
	 * SQL整形
	 */
	private String getPreformattedSql( String sql, HttpServletRequest req ) {
		try {
			sql = new String( sql.getBytes( "ISO-8859-1" ), "Windows-31J" );
		} catch (UnsupportedEncodingException e) {
		}
		sql = SU.replaceAll( sql, ":OPERATION_CD", quoting( AU.getRequestValue( req, "opeCd" ) ) );
		sql = SU.replaceAll( sql, ":LOGIN_GUID", quoting( this.loginNo ) );
		return sql;
	}
	
	private String quoting( String str ) {
		return "'" + str + "'";
	}
	
	/**
	 * テンプレートに記載のセルをすべて探索して埋め込み開始位置を取得
	 */
	private Integer[] getOffsetRC( Sheet sheet ) {
		for (Row row : sheet) {
			for (Cell cell : row) {
				if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
					String cellValue = cell.getStringCellValue();
					if (SU.equals( cellValue, "$START" )) {
						cell.setCellValue( "" );
						return new Integer[] { row.getRowNum(), cell.getColumnIndex() };
					}
				}
			}
		}
		return new Integer[] { 0, 0 };
	}
}
