package jp.co.hisas.career.app.common.deliver.mail.template.one;

import jp.co.hisas.career.app.common.unit.MailTemplateOneLogicGet;
import jp.co.hisas.career.app.common.unit.MailTemplateOneLogicPut;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class MailTemplateOneEvHdlr extends AbstractEventHandler<MailTemplateOneEvArg, MailTemplateOneEvRslt> {
	
	public static MailTemplateOneEvRslt exec( MailTemplateOneEvArg arg ) throws CareerException {
		MailTemplateOneEvHdlr handler = new MailTemplateOneEvHdlr();
		return handler.call( arg );
	}
	
	public MailTemplateOneEvRslt call( MailTemplateOneEvArg arg ) throws CareerException {
		return this.callEjb( arg );
	}
	
	protected MailTemplateOneEvRslt execute( MailTemplateOneEvArg arg ) throws CareerException {
		arg.validateArg();
		String daoLoginNo = arg.getLoginNo();
		MailTemplateOneEvRslt result = new MailTemplateOneEvRslt();
		
		if (SU.equals( "GET", arg.sharp )) {
			
			MailTemplateOneLogicGet logic = new MailTemplateOneLogicGet( daoLoginNo );
			result = logic.main( arg.orderGET );
		}
		else if (SU.equals( "PUT", arg.sharp )) {
			
			MailTemplateOneLogicPut logic = new MailTemplateOneLogicPut( daoLoginNo );
			result = logic.main( arg.orderPUT );
		}
		
		return result;
	}
	
}
