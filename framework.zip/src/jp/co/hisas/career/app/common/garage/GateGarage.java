package jp.co.hisas.career.app.common.garage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.CaGateAuthfailedDao;
import jp.co.hisas.career.util.dao.CaGateCheckDao;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.ExecuteDao;
import jp.co.hisas.career.util.dao.useful.GeneralMapDao;
import jp.co.hisas.career.util.dao.useful.OneColumnDao;
import jp.co.hisas.career.util.dto.CaGateAuthfailedDto;
import jp.co.hisas.career.util.dto.CaGateCheckDto;

public class GateGarage extends Garage {
	
	public GateGarage(String tracer) {
		super( tracer );
	}
	
	public String renewSecret( int aid, String party ) {
		
		StringBuilder sql1 = new StringBuilder();
		sql1.append( "delete from CA_GATE_SECRET where PID = ?" );
		
		List<String> p1 = new ArrayList<String>();
		p1.add( aid + "" );
		
		ExecuteDao dao1 = new ExecuteDao( daoLoginNo );
		dao1.executeDynamic( DaoUtil.getPstmt( sql1, p1 ) );
		
		String secret = UUID.randomUUID().toString();
		
		StringBuilder sql2 = new StringBuilder();
		sql2.append( "insert into CA_GATE_SECRET values (?, ?, ?)" );
		
		List<String> p2 = new ArrayList<String>();
		p2.add( aid + "" );
		p2.add( secret );
		p2.add( party );
		
		ExecuteDao dao2 = new ExecuteDao( daoLoginNo );
		dao2.executeDynamic( DaoUtil.getPstmt( sql2, p2 ) );
		
		return secret;
	}
	
	public Map<String, String> resolveBySecret( String secret ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select se.PARTY, rg.GUID, pi.CMPA_CD, pi.STF_NO, pi.DISPLAY_NAME, pi.LANG " );
		sql.append( " from CA_GATE_SECRET se" );
		sql.append( " inner join CA_PID pi on (pi.PID = se.PID) " );
		sql.append( " inner join CA_REGIST_MAIN rg on (rg.CMPA_CD = pi.CMPA_CD and rg.STF_NO = pi.STF_NO) " );
		sql.append( " where SECRET = ? " );
		
		List<String> p = new ArrayList<String>();
		p.add( secret );
		
		String[] cols = { "PARTY", "GUID", "CMPA_CD", "STF_NO", "DISPLAY_NAME", "LANG" };
		String[] keys = { "party", "guid", "cmpaCd", "stfNo", "displayName", "lang" };
		
		GeneralMapDao dao = new GeneralMapDao( this.daoLoginNo );
		List<Map<String, String>> results = dao.select( cols, keys, DaoUtil.getPstmt( sql, p ) );
		if (results.size() > 0) {
			return results.get( 0 );
		}
		return null;
	}
	
	public String getLatestHashedPassword( int pid ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select PASSWORD_HASHED as text from ( " );
		sql.append( "   select PASSWORD_HASHED from CA_GATE_PASSWORD where PID = ? " );
		sql.append( "    order by TIMESTAMP desc " );
		sql.append( " ) " );
		sql.append( " where ROWNUM = 1 " );
		
		List<String> p = new ArrayList<String>();
		p.add( pid + "" );
		
		OneColumnDao dao = new OneColumnDao( daoLoginNo );
		String hashedPassword = dao.selectDynamicFirst( DaoUtil.getPstmt( sql, p ) );
		
		return hashedPassword;
	}
	
	public void changePassword( int pid, String newPassword ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( "insert into CA_GATE_PASSWORD values (" );
		sql.append( "  to_number(?)," );
		sql.append( "  TO_CHAR(SYSDATE, 'yyyymmddhh24miss')," );
		sql.append( "  ?" );
		sql.append( ")" );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( pid + "" );
		paramList.add( newPassword );
		
		ExecuteDao dao = new ExecuteDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public CaGateCheckDto selectGateCheck( int pid ) {
		CaGateCheckDao dao = new CaGateCheckDao( daoLoginNo );
		return dao.select( pid );
	}
	
	public void updateGateCheckNeedsReset( int pid, int flg ) {
		CaGateCheckDao dao = new CaGateCheckDao( daoLoginNo );
		CaGateCheckDto dto = dao.select( pid );
		if (dto != null) {
			dto.setNeedsResetFlg( flg );
			dao.update( dto );
		}
		else {
			dto = new CaGateCheckDto();
			dto.setPid( pid );
			dto.setNeedsResetFlg( flg );
			dto.setLockedFlg( 0 );
			dao.insert( dto );
		}
	}
	
	public void updateAccountLocked( int pid ) {
		CaGateCheckDao dao = new CaGateCheckDao( daoLoginNo );
		CaGateCheckDto dto = dao.select( pid );
		if (dto == null) {
			dto = new CaGateCheckDto();
			dto.setPid( pid );
			dto.setNeedsResetFlg( 0 );
			dto.setLockedFlg( 1 );
			dao.insert( dto );
		}
		else {
			dto.setLockedFlg( 1 );
			dao.update( dto );
		}
	}
	
	public int getAuthFailedCount( int pid ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select sum(COUNTING_FLG) as text " );
		sql.append( " from CA_GATE_AUTHFAILED " );
		sql.append( " where PID = ? " );
		sql.append( " group by PID " );
		
		List<String> p = new ArrayList<String>();
		p.add( pid + "" );
		
		OneColumnDao dao = new OneColumnDao( daoLoginNo );
		String failedCount = dao.selectDynamicFirst( DaoUtil.getPstmt( sql, p ) );
		return SU.toInt( failedCount, 0 );
	}
	
	public void insertAuthFailed( int pid ) {
		CaGateAuthfailedDao dao = new CaGateAuthfailedDao( daoLoginNo );
		CaGateAuthfailedDto dto = new CaGateAuthfailedDto();
		dto.setPid( pid );
		dto.setTimestamp( AU.getTimestamp( "yyyyMMddHHmmssSSS" ) );
		dto.setCountingFlg( 1 );
		dao.insert( dto );
	}
	
	public void resetAuthFailedCounting( int pid ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( "update CA_GATE_AUTHFAILED set COUNTING_FLG = 0 where PID = ? " );
		
		List<String> p = new ArrayList<String>();
		p.add( pid + "" );
		
		CaGateAuthfailedDao dao = new CaGateAuthfailedDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, p ) );
	}
}
