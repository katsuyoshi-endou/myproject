package jp.co.hisas.career.app.common.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.app.common.bean.CareerMenuBean;
import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.framework.def.AC;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.NewTokenServlet;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class MenuTransServlet extends NewTokenServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String KINOU_ID = "MenuTrans";
	
	@Override
	public void service( final HttpServletRequest req, final HttpServletResponse res ) throws IOException, ServletException {
		/* Arranged for MenuTrans */
		try {
			Tray tray = new Tray( req, res );
			CareerMenuBean.init( tray );
			
			Log.method( tray.loginNo, "IN", "" );
			Log.performance( tray.loginNo, true, "" );
			
			CSRFTokenUtil.checkTokenNo( tray.request );
			String fPath = serviceMain( tray );
			CSRFTokenUtil.setNewTokenNo( tray.request, tray.response, fPath );
			
			final RequestDispatcher rd = this.ctx.getRequestDispatcher( fPath );
			rd.forward( tray.request, tray.response );
			
			Log.performance( tray.loginNo, false, "" );
			Log.method( tray.loginNo, "OUT", "" );
		} catch (final Exception e) {
			Log.error( req, e );
			this.ctx.getRequestDispatcher( AC.ERROR_PAGE ).forward( req, res );
		}
	}
	
	public String serviceMain( Tray tray ) throws CareerException {
		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, KINOU_ID, null, tray.state + ", MenuGrp：" + tray.menu.menuGrp + ", MenuId：" + tray.menu.menuId );
		return tray.menu.menuPath;
	}
	
}
