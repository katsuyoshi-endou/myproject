package jp.co.hisas.career.app.common.event;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.CaRegistDao;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dto.CaRegistDto;
import jp.co.hisas.career.util.log.Log;

public class CaRegistEvHdlr extends AbstractEventHandler<CaRegistEvArg, CaRegistEvRslt> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static CaRegistEvRslt exec( CaRegistEvArg arg ) throws CareerException {
		CaRegistEvHdlr handler = new CaRegistEvHdlr();
		return handler.call( arg );
	}
	
	public CaRegistEvRslt call( CaRegistEvArg arg ) throws CareerException {
		CaRegistEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CaRegistEvRslt execute( CaRegistEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		CaRegistEvRslt result = new CaRegistEvRslt();
		
		if (SU.equals( "GET_GNSK_REGIST", arg.sharp )) {
			result.caRegistDto = getGnskRegist( arg.guid );
		}
		else if (SU.equals( "GET_BY_CMPA_STF", arg.sharp )) {
			result.caRegistDto = getByCmpaStf( arg.cmpaCd, arg.stfNo );
		}
		
		return result;
	}
	
	private CaRegistDto getByCmpaStf( String cmpaCd, String stfNo ) {
		CaRegistDao dao = new CaRegistDao( this.loginNo );
		return dao.select( cmpaCd, stfNo );
	}
	
	private CaRegistDto getGnskRegist( String guid ) {
		
		/* Dynamic SQL */
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + CaRegistDao.ALLCOLS );
		sql.append( "   from CA_REGIST " );
		sql.append( "  where GUID = ? " );
		sql.append( "    and GNSK_FLG = '1' " );
		
		/* Parameter List */
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( guid );
		
		CaRegistDao dao = new CaRegistDao( this.loginNo );
		List<CaRegistDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		CaRegistDto result = new CaRegistDto();
		if (list.size() > 0) {
			result = list.get( 0 );
		}
		return result;
	}
	
}
