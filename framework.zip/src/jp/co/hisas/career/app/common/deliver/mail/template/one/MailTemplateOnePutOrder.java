package jp.co.hisas.career.app.common.deliver.mail.template.one;

import jp.co.hisas.career.app.common.deliver.DeliveryOrder;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class MailTemplateOnePutOrder extends DeliveryOrder {
	
	public String templateId;
	public String subject;
	public String body;
	
	public MailTemplateOnePutOrder(Tray tray) {
		super( tray );
	}
	
	public void validate() throws CareerBusinessException {
		if (SU.isBlank( this.templateId )) {
			throw new CareerBusinessException( CareerBusinessException.INVALID_ORDER );
		}
	}
}
