package jp.co.hisas.career.app.common.garage;

import java.util.ArrayList;

import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.CaUserDao;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.OneColumnDao;
import jp.co.hisas.career.util.dto.CaUserDto;

public class UserGarage extends Garage {
	
	public UserGarage(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public CaUserDto selectBySign( String sign ) {
		CaUserDao dao = new CaUserDao( daoLoginNo );
		CaUserDto dto = dao.select( sign );
		return dto;
	}
	
	public boolean isOperator( String party, int pid ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select '1' as text " );
		sql.append( " from CA_GUID " );
		sql.append( " where PARTY = ? and PID = ? and OPERATOR_FLG = '1' " );
		
		ArrayList<String> p = new ArrayList<String>();
		p.add( party );
		p.add( pid + "" );
		
		OneColumnDao dao = new OneColumnDao( daoLoginNo );
		String flag = dao.selectDynamicFirst( DaoUtil.getPstmt( sql, p ) );
		
		return SU.judge( flag );
	}
	
}
