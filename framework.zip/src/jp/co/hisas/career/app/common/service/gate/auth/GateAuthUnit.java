package jp.co.hisas.career.app.common.service.gate.auth;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import jp.co.hisas.career.app.common.garage.GateGarage;
import jp.co.hisas.career.app.common.garage.PasswordGarage;
import jp.co.hisas.career.app.common.garage.SignGarage;
import jp.co.hisas.career.app.common.service.ServiceUnit;
import jp.co.hisas.career.app.common.service.util.PasswordUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dto.CaGateCheckDto;
import jp.co.hisas.career.util.dto.CaGatePasswordDto;

public class GateAuthUnit extends ServiceUnit {
	
	public GateAuthUnit(String tracer) {
		super( tracer );
	}
	
	public GateAuthUnitOut auth( GateAuthUnitIn in ) {
		GateAuthUnitOut out = new GateAuthUnitOut();
		try {
			SignGarage ggSg = new SignGarage( this.tracer );
			PasswordGarage ggPw = new PasswordGarage( this.tracer );
			GateGarage ggGg = new GateGarage( this.tracer );
			
			int pid = ggSg.getPid( in.sign );
			
			CaGateCheckDto checkDto = selectGateCheck( pid );
			
			/* パスワード認証の前にアカウントがロックされていないか確認 */
			boolean isAccountLocked = checkAccountLocked( checkDto );
			if (isAccountLocked) {
				out.success = false;
				out.isAccountLocked = isAccountLocked;
				return out;
			}
			
			/* DB内の最新パスワードハッシュを取得 */
			CaGatePasswordDto pwDto = ggPw.getLatestHashedPassword( pid );
			
			// TODO: 【仮】パスワード認証強行突破
			if (AU.isDebugMode() && pwDto == null) {
				out.success = true;
				out.pid = pid;
				return out;
			}
			
			if (pwDto == null) {
				out.success = false;
				return out;
			}
			
			/* ログインフォームで入力したパスワードのハッシュを取得 */
			String orderHash = PasswordUtil.makeHashedString( in.password, pid );
			String serverHash = pwDto.getPasswordHashed();
			
			/* ハッシュが一致する場合は認証成功、不一致の場合は失敗記録を追加 */
			if (SU.equals( orderHash, serverHash )) {
				
				// 過去の失敗記録をカウント対象外にする
				ggGg.resetAuthFailedCounting( pid );
				
				out.success = true;
				out.pid = pid;
				out.needsReset = checkPasswordNeedsReset( checkDto );
				out.isExpired = checkPasswordExpired( pwDto.getTimestamp() );
			}
			else {
				ggGg.insertAuthFailed( pid );
				out.isAccountLocked = updateAccountLockedFlag( pid );
			}
		} catch (CareerException e) {
			out.success = false;
		}
		
		return out;
	}
	
	private CaGateCheckDto selectGateCheck( int pid ) {
		GateGarage ggGg = new GateGarage( this.tracer );
		CaGateCheckDto dto = ggGg.selectGateCheck( pid );
		return dto;
	}
	
	private boolean checkAccountLocked( CaGateCheckDto dto ) {
		if (dto == null) {
			return false;
		}
		return SU.judge( dto.getLockedFlg() );
	}
	
	private boolean checkPasswordNeedsReset( CaGateCheckDto dto ) {
		if (dto == null) {
			return false;
		}
		return SU.judge( dto.getNeedsResetFlg() );
	}
	
	private boolean checkPasswordExpired( String timestamp ) {
		boolean isExpired = false;
		try {
			Calendar todayCal = Calendar.getInstance();
			todayCal.setTime( new Date() );
			
			Calendar expireCal = Calendar.getInstance();
			SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyyMMddHHmmss" );
			Date lastChanged = dateFormat.parse( timestamp );
			expireCal.setTime( lastChanged );
			String expiredDays = AU.getCareerProperty( "PASSWORD_POLICY_EXPIRED_DAYS" );
			expireCal.add( Calendar.DAY_OF_MONTH, SU.toInt( expiredDays, 180 ) );
			
			isExpired = todayCal.compareTo( expireCal ) > 0;
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return isExpired;
	}
	
	private boolean updateAccountLockedFlag( int pid ) {
		GateGarage ggGg = new GateGarage( this.tracer );
		int failedCount = ggGg.getAuthFailedCount( pid );
		int accountLockCount = SU.toInt( AU.getCareerProperty( "ACCOUNT_LOCK_AUTH_FAILED_COUNT" ), 0 );
		boolean isLocked = failedCount >= accountLockCount;
		if (isLocked) {
			ggGg.updateAccountLocked( pid );
		}
		return isLocked;
	}
	
	public String prepareSecret( GateSecretOrder secretOrder ) {
		GateGarage ggGt = new GateGarage( this.tracer );
		String secret = ggGt.renewSecret( secretOrder.pid, secretOrder.party );
		return secret;
	}
	
	public Map<String, String> receive( GateReceiveOrder order ) {
		GateGarage ggGt = new GateGarage( this.tracer );
		Map<String, String> record = ggGt.resolveBySecret( order.secret );
		return record;
	}
}
