package jp.co.hisas.career.app.common.garage;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.CaGatePasswordDao;
import jp.co.hisas.career.util.dao.CaGatePasswordResetDao;
import jp.co.hisas.career.util.dao.CaRegistMainDao;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dto.CaGatePasswordDto;
import jp.co.hisas.career.util.dto.CaGatePasswordResetDto;
import jp.co.hisas.career.util.dto.CaRegistMainDto;

public class PasswordGarage extends Garage {
	
	public PasswordGarage(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public CaGatePasswordDto getLatestHashedPassword( int pid ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + CaGatePasswordDao.ALLCOLS + " from (" );
		sql.append( "   select PID, TIMESTAMP, PASSWORD_HASHED " );
		sql.append( "     from CA_GATE_PASSWORD p" );
		sql.append( "    where p.PID = ? " );
		sql.append( "    order by TIMESTAMP desc" );
		sql.append( " )" );
		sql.append( " where ROWNUM = 1" );
		
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.add( pid + "" );
		
		CaGatePasswordDao dao = new CaGatePasswordDao( daoLoginNo );
		List<CaGatePasswordDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
		
		for (CaGatePasswordDto dto : list) {
			return dto;
		}
		
		return null;
	}
	
	public CaRegistMainDto getRegistBySign( String sign ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + SU.addPrefixOnDaoAllCols( "rg", CaRegistMainDao.ALLCOLS ) );
		sql.append( " from CA_SIGN sn " );
		sql.append( "      inner join CA_PID pi " );
		sql.append( "        on (pi.PID = sn.PID) " );
		sql.append( "      inner join CA_REGIST_MAIN rg " );
		sql.append( "        on (rg.CMPA_CD = pi.CMPA_CD and rg.STF_NO = pi.STF_NO) " );
		sql.append( " where sn.SIGN = ? " );
		
		List<String> p = new ArrayList<String>();
		p.add( sign );
		
		CaRegistMainDao dao = new CaRegistMainDao( daoLoginNo );
		List<CaRegistMainDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, p ) );
		if (list.size() > 0) {
			return list.get( 0 );
		}
		return null;
	}
	
	public void insertResetToken( String sign, int pid, String resetToken ) {
		CaGatePasswordResetDto dto = new CaGatePasswordResetDto();
		dto.setSign( sign );
		dto.setPid( pid );
		dto.setTimestamp( AU.getTimestamp( "yyyyMMddHHmmssSSS" ) );
		dto.setResetToken( resetToken );
		dto.setAvailFlg( 1 );
		CaGatePasswordResetDao dao = new CaGatePasswordResetDao( daoLoginNo );
		dao.insert( dto );
	}
	
	public CaGatePasswordResetDto selectPasswordResetByToken( String token ) {
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + CaGatePasswordResetDao.ALLCOLS );
		sql.append( " from CA_GATE_PASSWORD_RESET " );
		sql.append( " where RESET_TOKEN = ? " );
		sql.append( " and AVAIL_FLG = 1 " );
		sql.append( " and substr(TIMESTAMP, 1, 14) > to_char(sysdate - 3/24, 'yyyymmddhh24miss') " ); // 3時間以内
		
		List<String> p = new ArrayList<String>();
		p.add( token );
		
		CaGatePasswordResetDao dao = new CaGatePasswordResetDao( daoLoginNo );
		List<CaGatePasswordResetDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, p ) );
		CaGatePasswordResetDto dto = null;
		if (list.size() > 0) {
			dto = list.get( 0 );
		}
		return dto;
	}
	
	public void updatePasswordResetToUnavailable( int pid ) {
		StringBuilder sql = new StringBuilder();
		sql.append( " update CA_GATE_PASSWORD_RESET " );
		sql.append( " set AVAIL_FLG = 0 " );
		sql.append( " where PID = ? " );
		
		List<String> p = new ArrayList<String>();
		p.add( pid + "" );
		
		CaGatePasswordResetDao dao = new CaGatePasswordResetDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, p ) );
	}
	
	public boolean checkUntimelyChange( int pid ) {
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + CaGatePasswordDao.ALLCOLS );
		sql.append( " from CA_GATE_PASSWORD " );
		sql.append( " where PID = ? " );
		sql.append( " and substr(TIMESTAMP, 1, 14) > to_char(sysdate - 1, 'yyyymmddhh24miss')" ); // 1日以内
		
		List<String> p = new ArrayList<String>();
		p.add( pid + "" );
		
		CaGatePasswordDao dao = new CaGatePasswordDao( daoLoginNo );
		List<CaGatePasswordDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, p ) );
		if (list.size() > 0) {
			return false;
		}
		return true;
	}
	
	public boolean checkRecentUnique( int pid, String hashedPassword ) {
		
		int historyCount = 3;
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + SU.addPrefixOnDaoAllCols( "sub", CaGatePasswordDao.ALLCOLS ) );
		sql.append( " from ( " );
		sql.append( "   select t.* " );
		sql.append( "        , row_number() over (partition by PID order by TIMESTAMP desc) as RN " );
		sql.append( "   from CA_GATE_PASSWORD t " );
		sql.append( "   where PID = ? " );
		sql.append( " ) sub " );
		sql.append( " where RN <= ? " );
		sql.append( " and PASSWORD_HASHED = ? " );
		
		List<String> p = new ArrayList<String>();
		p.add( pid + "" );
		p.add( historyCount + "" );
		p.add( hashedPassword );
		
		CaGatePasswordDao dao = new CaGatePasswordDao( daoLoginNo );
		List<CaGatePasswordDto> list = dao.selectDynamic( DaoUtil.getPstmt( sql, p ) );
		if (list.size() > 0) {
			return false;
		}
		return true;
	}
}
