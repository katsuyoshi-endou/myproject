package jp.co.hisas.career.app.common.service;

public class ServiceUnit {
	
	public String tracer;
	
	public ServiceUnit(String tracer) {
		this.tracer = tracer;
	}
}
