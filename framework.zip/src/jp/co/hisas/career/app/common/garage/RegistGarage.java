package jp.co.hisas.career.app.common.garage;

import jp.co.hisas.career.util.dao.CaRegistDao;
import jp.co.hisas.career.util.dao.CaRegistMainDao;
import jp.co.hisas.career.util.dto.CaRegistDto;
import jp.co.hisas.career.util.dto.CaRegistMainDto;

public class RegistGarage extends Garage {
	
	public RegistGarage(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public CaRegistDto getByCmpaStf( String cmpaCd, String stfNo ) {
		CaRegistDao dao = new CaRegistDao( daoLoginNo );
		return dao.select( cmpaCd, stfNo );
	}
	
	public CaRegistMainDto getByGuid( String party, String guid ) {
		CaRegistMainDao dao = new CaRegistMainDao( daoLoginNo );
		return dao.select( party, guid );
	}
}
