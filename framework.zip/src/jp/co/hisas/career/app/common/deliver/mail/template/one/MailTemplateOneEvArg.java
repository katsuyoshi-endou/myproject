package jp.co.hisas.career.app.common.deliver.mail.template.one;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class MailTemplateOneEvArg extends AbstractEventArg {
	
	public String sharp = null;
	public MailTemplateOneGetOrder orderGET;
	public MailTemplateOnePutOrder orderPUT;
	
	public MailTemplateOneEvArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: loginNo is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		String className = MailTemplateOneEvArg.class.getName();
		if (SU.isBlank( sharp )) {
			throw new CareerException( className + "Invalid: sharp is null." );
		}
	}
	
}
