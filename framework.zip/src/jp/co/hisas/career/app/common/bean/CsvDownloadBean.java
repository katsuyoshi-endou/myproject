package jp.co.hisas.career.app.common.bean;

import java.io.IOException;
import java.io.StringWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;

public class CsvDownloadBean {
	
	HttpServletRequest request;
	HttpSession session;
	String loginNo;
	
	public CsvDownloadBean(HttpServletRequest req, HttpSession ses) {
		this.request = req;
		this.session = ses;
		final UserInfoBean userinfo = (UserInfoBean)session.getAttribute( "userinfo" );
		this.loginNo = (userinfo != null) ? userinfo.getLogin_no() : "";
	}
	
	public String createCsvData( List<String> headerList, List<List<String>> rows ) throws IOException {
		StringWriter writer = new StringWriter();
		String[] header = headerList.toArray( new String[headerList.size()] );
		CSVFormat cf = CSVFormat.EXCEL.withQuoteMode( QuoteMode.ALL ).withHeader( header );
		try (CSVPrinter csvPrinter = new CSVPrinter( writer, cf );) {
			csvPrinter.printRecords( rows );
			csvPrinter.flush();
		}
		return writer.toString();
	}
}
