package jp.co.hisas.career.app.common.garage;

public class Garage {
	
	public String daoLoginNo;
	
	public Garage(String daoLoginNo) {
		this.daoLoginNo = daoLoginNo;
	}
	
}
