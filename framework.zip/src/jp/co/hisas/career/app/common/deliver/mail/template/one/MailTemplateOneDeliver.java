package jp.co.hisas.career.app.common.deliver.mail.template.one;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Tray;

public class MailTemplateOneDeliver {
	
	public static MailTemplateOneEvRslt get( Tray tray, MailTemplateOneGetOrder order ) throws CareerException {
		order.validate();
		
		MailTemplateOneEvArg arg = new MailTemplateOneEvArg( tray.loginNo );
		arg.sharp = "GET";
		arg.orderGET = order;
		return MailTemplateOneEvHdlr.exec( arg );
	}
	
	public static MailTemplateOneEvRslt put( Tray tray, MailTemplateOnePutOrder order ) throws CareerException {
		order.validate();
		
		MailTemplateOneEvArg arg = new MailTemplateOneEvArg( tray.loginNo );
		arg.sharp = "PUT";
		arg.orderPUT = order;
		return MailTemplateOneEvHdlr.exec( arg );
	}
}
