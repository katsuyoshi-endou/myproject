package jp.co.hisas.career.app.common.unit;

import java.util.Map;

public class MailQueueUnitIn extends ServiceUnitIn {
	
	public String party;
	public String loginGuid;
	
	public String templateId;
	public Map<String, String> replaceMap;
	public String toGuid;
	public String toCmpaCd;
	public String toStfNo;
	public String ccGuid;
	public String actionPersonId;
	
	public MailQueueUnitIn(String daoLoginNo) {
		super( daoLoginNo );
	}
}
