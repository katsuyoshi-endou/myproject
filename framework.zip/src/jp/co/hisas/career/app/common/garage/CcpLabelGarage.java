package jp.co.hisas.career.app.common.garage;

import jp.co.hisas.career.util.dao.CcpLabelDao;
import jp.co.hisas.career.util.dto.CcpLabelDto;

public class CcpLabelGarage extends Garage {
	
	public CcpLabelGarage(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public void delins( String party, String labelId, String labelText ) {
		CcpLabelDao dao = new CcpLabelDao( daoLoginNo );
		CcpLabelDto dto = dao.select( party, labelId );
		if (dto == null) {
			dto = new CcpLabelDto();
			dto.setParty( party );
			dto.setLabelId( labelId );
			dto.setLabelText( labelText );
			dao.insert( dto );
		}
		else {
			dto.setLabelText( labelText );
			dao.update( dto );
		}
	}
}
