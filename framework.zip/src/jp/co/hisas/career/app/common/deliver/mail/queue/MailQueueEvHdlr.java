package jp.co.hisas.career.app.common.deliver.mail.queue;

import jp.co.hisas.career.app.common.unit.MailQueueUnit;
import jp.co.hisas.career.app.common.unit.MailQueueUnitIn;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class MailQueueEvHdlr extends AbstractEventHandler<MailQueueEvArg, MailQueueEvRslt> {
	
	public static MailQueueEvRslt exec( MailQueueEvArg arg ) throws CareerException {
		MailQueueEvHdlr handler = new MailQueueEvHdlr();
		return handler.call( arg );
	}
	
	public MailQueueEvRslt call( MailQueueEvArg arg ) throws CareerException {
		return this.callEjb( arg );
	}
	
	protected MailQueueEvRslt execute( MailQueueEvArg arg ) throws CareerException {
		arg.validateArg();
		String daoLoginNo = arg.getLoginNo();
		MailQueueEvRslt result = new MailQueueEvRslt();
		
		if (SU.equals( "SEND_FROM_USER", arg.sharp )) {
			
			MailQueueUnitIn in = new MailQueueUnitIn( daoLoginNo );
			in.party = arg.order.party;
			in.loginGuid = arg.order.loginGuid;
			in.templateId = arg.order.templateId;
			in.replaceMap = arg.order.replaceMap;
			in.toGuid = arg.order.toGuid;
			in.toCmpaCd = arg.order.toCmpaCd;
			in.toStfNo = arg.order.toStfNo;
			in.ccGuid = arg.order.ccGuid;
			in.actionPersonId = arg.order.actionPersonId;
			MailQueueUnit.sendFromUser( in );
		}
		
		return result;
	}
	
}
