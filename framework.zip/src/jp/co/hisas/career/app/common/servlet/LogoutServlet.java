package jp.co.hisas.career.app.common.servlet;

import jp.co.hisas.career.framework.trans.NoTokenServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class LogoutServlet extends NoTokenServlet {
	
	private static final String FORWARD_PAGE = "/view/auth/VYA_AppLogout.jsp";
	
	public String serviceMain( Tray tray ) throws Exception {
		
		String msg = AU.getCommonLabel( tray, "FW_MSG_LOGOUT_DONE" );
		AU.setReqAttr( tray.request, "logout_message", msg );
		
		tray.session.invalidate();
		
		return SU.bvl( tray.forwardUrl, FORWARD_PAGE );
	}
}
