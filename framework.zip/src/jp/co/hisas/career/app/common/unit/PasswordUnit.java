package jp.co.hisas.career.app.common.unit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;

import jp.co.hisas.career.app.common.garage.GateGarage;
import jp.co.hisas.career.app.common.garage.PasswordGarage;
import jp.co.hisas.career.app.common.garage.SignGarage;
import jp.co.hisas.career.app.common.service.util.PasswordUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dto.CaGatePasswordResetDto;
import jp.co.hisas.career.util.dto.CaRegistMainDto;

public class PasswordUnit {
	
	public static PasswordUnitOut check( PasswordUnitIn in ) {
		PasswordUnitOut out = new PasswordUnitOut();
		PasswordGarage ggPw = new PasswordGarage( in.tracer );
		
		List<PasswordRule> rules = new ArrayList<PasswordRule>();
		
		String hashedPassword = PasswordUtil.makeHashedString( in.newPassword, in.pid );
		
		/* Ｎ文字以上 */
		PasswordRule rlMin = new PasswordRule();
		String minLen = SU.bvl( AU.getCareerProperty( "PASSWORD_POLICY_MINLEN" ), "8" );
		rlMin.label = minLen + "文字以上";
		rlMin.isValid = in.newPassword.length() >= 8;
		rules.add( rlMin );
		
		/* Ｎ文字以内 */
		PasswordRule rlMax = new PasswordRule();
		String maxLen = SU.bvl( AU.getCareerProperty( "PASSWORD_POLICY_MAXLEN" ), "20" );
		rlMax.label = maxLen + "文字以内";
		rlMax.isValid = in.newPassword.length() <= 20;
		rules.add( rlMax );
		
		/* 利用可能な文字のみ */
		PasswordRule rlChar = new PasswordRule();
		rlChar.label = "利用可能な文字のみ";
		rlChar.isValid = SU.matches( in.newPassword, "^[a-zA-Z0-9\\!\"#\\$%&'\\(\\)\\*\\+,-.\\/:;<=>\\?@\\[\\\\\\]\\^\\_`\\{\\|\\}~]+$" );
		rlChar.desc = "利用可能な文字 … 半角英数字（大文字・小文字）、記号 ! \" # $ % & ' ( ) * + , - . / : ; < = > ? @ [ \\ ] ^ _ ` { | } ~";
		rules.add( rlChar );
		
		/* 前回の変更から24時間以上経過している */
		PasswordRule rlTimely = new PasswordRule();
		rlTimely.label = "前回の変更から24時間以上経過している";
		rlTimely.isValid = ggPw.checkUntimelyChange( in.pid );
		rules.add( rlTimely );
		
		/* 過去3回以内に同じパスワードを使っていない */
		PasswordRule rlUniq = new PasswordRule();
		rlUniq.label = "過去3回以内に同じパスワードを使っていない";
		rlUniq.isValid = ggPw.checkRecentUnique( in.pid, hashedPassword );
		rules.add( rlUniq );
		
		out.rules = rules;
		return out;
	}
	
	public static class PasswordRule implements Serializable {
		public String label;
		public String desc;
		public boolean isValid;
		
		public PasswordRule() {
		}
	}
	
	/**
	 * パスワード変更の適用<br>
	 * ※サーバーサイドでのチェックは済んでいる前提とする
	 */
	public static PasswordUnitOut changePassword( PasswordUnitIn in ) throws CareerException {
		PasswordUnitOut out = new PasswordUnitOut();
		SignGarage ggSn = new SignGarage( in.tracer );
		GateGarage ggGt = new GateGarage( in.tracer );
		PasswordGarage ggPw = new PasswordGarage( in.tracer );
		
		int pid = ggSn.getPid( in.sign );
		
		/* Change Password */
		String hashedPassword = PasswordUtil.makeHashedString( in.newPassword, pid );
		ggGt.changePassword( pid, hashedPassword );
		
		/* Update Check State */
		ggGt.updateGateCheckNeedsReset( pid, 0 );
		ggPw.updatePasswordResetToUnavailable( pid );
		
		out.isSuccess = true;
		return out;
	}
	
	public static PasswordUnitOut prepareToken( PasswordUnitIn in ) throws CareerException {
		PasswordUnitOut out = new PasswordUnitOut();
		PasswordGarage ggPw = new PasswordGarage( in.tracer );
		CaRegistMainDto dto = ggPw.getRegistBySign( in.sign );
		
		if (dto == null) {
			// Error: Sign not found.
			out.isCheckOK = false;
			return out;
		}
		
		boolean isCheckOK = SU.equals( in.email, dto.getMailAddress() );
		if (!isCheckOK) {
			out.isCheckOK = false;
			return out;
		}
		
		SignGarage ggSn = new SignGarage( in.tracer );
		GateGarage ggGg = new GateGarage( in.tracer );
		int pid = ggSn.getPid( in.sign );
		Map<String, String> replaceMap = new HashMap<String, String>();
		String token = RandomStringUtils.randomAlphanumeric( 36 );
		replaceMap.put( "token", token );
		
		// TODO: update AVAIL_FLG = 0 for old records.
		ggPw.insertResetToken( in.sign, pid, token );
		ggGg.updateGateCheckNeedsReset( pid, 1 );
		
		MailQueueUnitIn inM = new MailQueueUnitIn( in.tracer );
		inM.party = "UNKNOWN";
		inM.templateId = "HubPasswordResetToken";
		inM.toCmpaCd = dto.getCmpaCd();
		inM.toStfNo = dto.getStfNo();
		inM.replaceMap = replaceMap;
		MailQueueUnit.sendFromSystem( inM );
		
		out.isCheckOK = true;
		return out;
	}
	
	public static PasswordUnitOut confirmToken( PasswordUnitIn in ) {
		PasswordUnitOut out = new PasswordUnitOut();
		PasswordGarage ggPw = new PasswordGarage( in.tracer );
		CaGatePasswordResetDto dto = ggPw.selectPasswordResetByToken( in.token );
		if (dto == null) {
			// Error
			out.isVerifyOK = false;
		}
		else {
			out.isVerifyOK = true;
			out.sign = dto.getSign();
		}
		return out;
	}
}
