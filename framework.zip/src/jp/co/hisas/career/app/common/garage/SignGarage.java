package jp.co.hisas.career.app.common.garage;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.dao.CaSignDao;
import jp.co.hisas.career.util.dto.CaSignDto;

public class SignGarage extends Garage {
	
	public SignGarage(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public Integer getPid( String sign ) throws CareerException {
		CaSignDao dao = new CaSignDao( daoLoginNo );
		CaSignDto dto = dao.select( sign );
		if (dto == null) {
			throw new CareerException( "Unknown sign." );
		}
		return dto.getPid();
	}
	
}
