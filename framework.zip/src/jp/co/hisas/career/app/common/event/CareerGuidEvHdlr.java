package jp.co.hisas.career.app.common.event;

import java.util.List;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.CareerGuidDao;
import jp.co.hisas.career.util.dto.CareerGuidDto;
import jp.co.hisas.career.util.log.Log;

public class CareerGuidEvHdlr extends AbstractEventHandler<CareerGuidEvArg, CareerGuidEvRslt> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static CareerGuidEvRslt exec( CareerGuidEvArg arg ) throws CareerException {
		CareerGuidEvHdlr handler = new CareerGuidEvHdlr();
		return handler.call( arg );
	}
	
	public CareerGuidEvRslt call( CareerGuidEvArg arg ) throws CareerException {
		CareerGuidEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected CareerGuidEvRslt execute( CareerGuidEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		CareerGuidEvRslt result = new CareerGuidEvRslt();
		
		if (SU.equals( "INIT", arg.sharp )) {
			result.careerGuidDto = getCareerGuid( arg );
		}
		
		return result;
	}
	
	private CareerGuidDto getCareerGuid( CareerGuidEvArg arg ) {
		CareerGuidDao dao = new CareerGuidDao( this.loginNo );
		List<CareerGuidDto> list = dao.selectGuidByAvailFlg( arg.guid );
		CareerGuidDto result = null;
		if (list.size() > 0) {
			result = list.get( 0 );
		}
		return result;
	}
	
}
