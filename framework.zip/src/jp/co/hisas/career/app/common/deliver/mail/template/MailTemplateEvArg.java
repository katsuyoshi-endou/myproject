package jp.co.hisas.career.app.common.deliver.mail.template;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class MailTemplateEvArg extends AbstractEventArg {
	
	public String sharp = null;
	public MailTemplateGetOrder orderGET;
	
	public MailTemplateEvArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: loginNo is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		String className = MailTemplateEvArg.class.getName();
		if (SU.isBlank( sharp )) {
			throw new CareerException( className + "Invalid: sharp is null." );
		}
	}
	
}
