package jp.co.hisas.career.app.common.bean;

import java.io.FileInputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import jp.co.hisas.career.app.common.event.SelectWithSqlPropEvArg;
import jp.co.hisas.career.app.common.event.SelectWithSqlPropEvHdlr;
import jp.co.hisas.career.app.common.event.SelectWithSqlPropEvRslt;
import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;

public class ExcelDownloadBean {
	
	HttpServletRequest request;
	HttpSession session;
	String loginNo;
	private Workbook workbook;
	private Map<Integer, List<String>> rows;
	
	public Workbook createWorkbook( HttpServletRequest req, HttpSession ses, String sharp, String templateFileName ) throws Exception {
		this.request = req;
		this.session = ses;
		final UserInfoBean userinfo = (UserInfoBean)session.getAttribute( "userinfo" );
		this.loginNo = (userinfo != null) ? userinfo.getLogin_no() : "";
		
		if (SU.equals( sharp, "SQLPROP" )) {
			this.getDataFromSqlProp();
		}
		else if (SU.equals( sharp, "SESSION" )) {
			this.getDataFromSession();
		}
		
		String templateFile = templateFileName + ".xlsx";
		String fullPath = AppDef.APP_DIR + "/exceltemplate/" + templateFile;
		FileInputStream fis = new FileInputStream( fullPath );
		this.workbook = WorkbookFactory.create( fis );
		this.writeSheetOnTemplate();
		return workbook;
	}
	
	private void getDataFromSqlProp() throws CareerException {
		SelectWithSqlPropEvArg arg = new SelectWithSqlPropEvArg( this.loginNo );
		arg.sharp = "SELECT";
		arg.sqlPropKey = AU.getRequestValue( request, "sqlPropKey" );
		SelectWithSqlPropEvRslt result = SelectWithSqlPropEvHdlr.exec( arg );
		this.rows = result.rows;
	}
	
	private void getDataFromSession() throws CareerException {
		this.rows = AU.getSessionAttr( session, "EXCEL_DL_ROWS" );
	}
	
	private void writeSheetOnTemplate() {
		
		Sheet sheet = workbook.getSheet( "Sheet1" );
		
		Integer[] offsetRC = getOffsetRC( sheet );
		int offsetR = offsetRC[0];
		int offsetC = offsetRC[1];
		
		Row preRow = null;
		boolean newRow = false;
		
		for (int i = 1; i <= rows.size(); i++) {
			List<String> dataList = rows.get( i );
			Row row = sheet.getRow( offsetR + i - 1 );
			if (row == null) {
				row = sheet.createRow( offsetR + i - 1 );
				newRow = true;
			}
			for (int j = 0; j < dataList.size(); j++) {
				Cell cell = row.getCell( offsetC + j );
				cell = (cell != null) ? cell : row.createCell( offsetC + j );
				String data = dataList.get( j );
				data = SU.isBlank( data ) ? null : data;
				if (newRow) {
					// createRow をするとスタイルなしの行となるので１行目のものを適用
					cell.setCellStyle( preRow.getCell( offsetC + j ).getCellStyle() );
				}
				cell.setCellValue( data );
			}
			if (i == 1) {
				preRow = row;
			}
		}
	}
	
	/**
	 * テンプレートに記載のセルをすべて探索して埋め込み開始位置を取得
	 */
	private Integer[] getOffsetRC( Sheet sheet ) {
		for (Row row : sheet) {
			for (Cell cell : row) {
				if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
					String cellValue = cell.getStringCellValue();
					if (SU.equals( cellValue, "$START" )) {
						cell.setCellValue( "" );
						return new Integer[] { row.getRowNum(), cell.getColumnIndex() };
					}
				}
			}
		}
		return new Integer[] { 0, 0 };
	}
	
}
