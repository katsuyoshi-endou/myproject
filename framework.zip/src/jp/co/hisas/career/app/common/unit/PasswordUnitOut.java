package jp.co.hisas.career.app.common.unit;

import java.util.List;

import jp.co.hisas.career.app.common.unit.PasswordUnit.PasswordRule;

public class PasswordUnitOut {
	
	public boolean isCheckOK;
	public boolean isVerifyOK;
	public boolean isSuccess;
	public String sign;
	public List<PasswordRule> rules;
}
