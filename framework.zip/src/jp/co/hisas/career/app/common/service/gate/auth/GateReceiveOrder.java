package jp.co.hisas.career.app.common.service.gate.auth;

import jp.co.hisas.career.app.common.service.OrderMaker;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.SU;

public class GateReceiveOrder extends OrderMaker {
	
	public String secret;
	
	public GateReceiveOrder(Line line) {
		super( line );
	}
	
	public void validate() throws CareerBusinessException {
		if (SU.isBlank( this.secret )) {
			throw new CareerBusinessException( CareerBusinessException.INVALID_ORDER );
		}
	}
}
