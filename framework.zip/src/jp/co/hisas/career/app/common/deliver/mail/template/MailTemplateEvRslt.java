package jp.co.hisas.career.app.common.deliver.mail.template;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.CaMailTemplateDto;

public class MailTemplateEvRslt extends AbstractEventResult {
	
	public Map<String, String> uiLabelSet;
	public List<CaMailTemplateDto> templates;
}
