package jp.co.hisas.career.app.common.deliver.mail.template;

import jp.co.hisas.career.app.common.unit.MailTemplateLogicGet;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class MailTemplateEvHdlr extends AbstractEventHandler<MailTemplateEvArg, MailTemplateEvRslt> {
	
	public static MailTemplateEvRslt exec( MailTemplateEvArg arg ) throws CareerException {
		MailTemplateEvHdlr handler = new MailTemplateEvHdlr();
		return handler.call( arg );
	}
	
	public MailTemplateEvRslt call( MailTemplateEvArg arg ) throws CareerException {
		return this.callEjb( arg );
	}
	
	protected MailTemplateEvRslt execute( MailTemplateEvArg arg ) throws CareerException {
		arg.validateArg();
		String daoLoginNo = arg.getLoginNo();
		MailTemplateEvRslt result = new MailTemplateEvRslt();
		
		if (SU.equals( "GET", arg.sharp )) {
			
			MailTemplateLogicGet logic = new MailTemplateLogicGet( daoLoginNo );
			result = logic.main( arg.orderGET );
		}
		else if (SU.equals( "PUT", arg.sharp )) {
			
//			MailTemplateLogicPut logic = new MailTemplateLogicPut( daoLoginNo );
//			result = logic.main( arg.orderPUT );
		}
		
		return result;
	}
	
}
