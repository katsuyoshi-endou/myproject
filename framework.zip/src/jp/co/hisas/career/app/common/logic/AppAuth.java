package jp.co.hisas.career.app.common.logic;

import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.property.CommonLabel;

public class AppAuth {
	
	public static String authByTray( Tray tray ) throws Exception {
		String reqId = SU.trim( AU.getRequestValue( tray.request, "guid" ) );
		String reqPw = AU.getRequestValue( tray.request, "password" );
		if (authCore( reqPw )) {
			return reqId;
		}
		else {
			String msg = CommonLabel.getLabel( "FW_MSG_ADMIN_PASSWORD_NG" );
			throw new CareerRuntimeException( msg );
		}
	}
	
	private static boolean authCore( String password ) throws Exception {
		// From Property for admin only
		String pw = AU.getCareerProperty( "ADMIN_PASSWORD" );
		return SU.equals( pw, password );
	}
	
}
