package jp.co.hisas.career.app.common.garage;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.util.dao.CaMailTemplateDao;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dto.CaMailTemplateDto;

public class MailTemplateGarage extends Garage {
	
	public MailTemplateGarage(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public List<CaMailTemplateDto> selectAllMailTemplates( String party ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select " + CaMailTemplateDao.ALLCOLS );
		sql.append( "   from CA_MAIL_TEMPLATE " );
		sql.append( "  where PARTY = ? " );
		sql.append( "  order by TEMPLATE_ID " );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( party );
		
		CaMailTemplateDao dao = new CaMailTemplateDao( daoLoginNo );
		return dao.selectDynamic( DaoUtil.getPstmt( sql, paramList ) );
	}
	
	public CaMailTemplateDto selectMailTemplateOne( String party, String templateId ) {
		CaMailTemplateDao dao = new CaMailTemplateDao( daoLoginNo );
		CaMailTemplateDto dto = dao.select( party, templateId );
		return dto != null ? dto : new CaMailTemplateDto();
	}
	
	public void update( String party, String templateId, String subject, String body ) {
		CaMailTemplateDao dao = new CaMailTemplateDao( daoLoginNo );
		CaMailTemplateDto dto = new CaMailTemplateDto();
		dto.setParty( party );
		dto.setTemplateId( templateId );
		dto.setSubject( subject );
		dto.setBody( body );
		dao.update( dto );
	}
	
}
