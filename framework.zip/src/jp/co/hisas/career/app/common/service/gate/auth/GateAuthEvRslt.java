package jp.co.hisas.career.app.common.service.gate.auth;

import java.util.Map;

import jp.co.hisas.career.ejb.AbstractEventResult;

public class GateAuthEvRslt extends AbstractEventResult {
	
	public String sign;
	public int pid;
	public boolean success = false;
	public String secret;
	public Map<String, String> gateArgs;
	public boolean isExpired;
	public boolean isAccountLocked;
	public boolean needsReset;
}
