package jp.co.hisas.career.app.common.event;

import java.util.List;

import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.CareerMenuActiveDto;

@SuppressWarnings("serial")
public class CareerMenuEvRslt extends AbstractEventResult {

	public List<CareerMenuActiveDto> careerMenuList;
	public String careerMenuPtn;
	public CareerMenuActiveDto oneMenu;
	public String baseRoleId;
	public String planRoleId;
}