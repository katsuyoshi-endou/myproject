package jp.co.hisas.career.app.common.service.df;

import jp.co.hisas.career.app.common.garage.CcpLabelGarage;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class CcpLabelEvHdlr extends AbstractEventHandler<CcpLabelEvArg, CcpLabelEvRslt> {
	
	private String daoLoginNo;
	
	public static CcpLabelEvRslt exec( CcpLabelEvArg arg ) throws CareerException {
		CcpLabelEvHdlr handler = new CcpLabelEvHdlr();
		return handler.call( arg );
	}
	
	public CcpLabelEvRslt call( CcpLabelEvArg arg ) throws CareerException {
		return this.callEjb( arg );
	}
	
	protected CcpLabelEvRslt execute( CcpLabelEvArg arg ) throws CareerException {
		arg.validateArg();
		this.daoLoginNo = arg.getLoginNo();
		CcpLabelEvRslt result = new CcpLabelEvRslt();
		
		if (SU.equals( "CHANGE", arg.sharp )) {
			CcpLabelGarage ggLb = new CcpLabelGarage( daoLoginNo );
			ggLb.delins( arg.party, arg.labelId, arg.labelText );
		}
		
		return result;
	}
	
}
