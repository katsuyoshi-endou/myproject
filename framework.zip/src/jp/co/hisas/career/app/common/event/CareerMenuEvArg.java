package jp.co.hisas.career.app.common.event;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

@SuppressWarnings("serial")
public class CareerMenuEvArg extends AbstractEventArg {
	
	public String sharp = null;
	public String menuGrp;
	public String menuId;
	public String party;
	public String guid;
	public String operatorGuid;
	
	public CareerMenuEvArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid CareerMenuEvArg: loginNo is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		if (SU.isBlank( sharp )) {
			throw new CareerException( "Invalid CareerMenuEvArg: sharp is null." );
		}
	}
	
}
