package jp.co.hisas.career.app.common.unit;

import jp.co.hisas.career.app.common.deliver.mail.template.one.MailTemplateOneEvRslt;
import jp.co.hisas.career.app.common.deliver.mail.template.one.MailTemplateOnePutOrder;
import jp.co.hisas.career.app.common.garage.MailTemplateGarage;

public class MailTemplateOneLogicPut {
	
	private String daoLoginNo;
	
	public MailTemplateOneLogicPut(String daoLoginNo) {
		this.daoLoginNo = daoLoginNo;
	}
	
	public MailTemplateOneEvRslt main( MailTemplateOnePutOrder orderPUT ) {
		MailTemplateOneEvRslt r = new MailTemplateOneEvRslt();
		MailTemplateGarage ggMT = new MailTemplateGarage( daoLoginNo );
		
		ggMT.update( orderPUT.party, orderPUT.templateId, orderPUT.subject, orderPUT.body );
		
		return r;
	}
	
}
