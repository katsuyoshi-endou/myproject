package jp.co.hisas.career.app.common.deliver.mail.template;

import jp.co.hisas.career.app.common.deliver.DeliveryOrder;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.util.Tray;

public class MailTemplateGetOrder extends DeliveryOrder {
	
	public MailTemplateGetOrder(Tray tray) {
		super( tray );
	}
	
	public void validate() throws CareerBusinessException {
	}
}
