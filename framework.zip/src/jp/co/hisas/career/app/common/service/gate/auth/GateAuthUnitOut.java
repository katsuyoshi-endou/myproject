package jp.co.hisas.career.app.common.service.gate.auth;

public class GateAuthUnitOut {
	
	public boolean success = false;
	public int pid;
	public String password;
	public boolean isExpired;
	public boolean isAccountLocked;
	public boolean needsReset;
}
