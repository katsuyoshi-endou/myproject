package jp.co.hisas.career.app.common.service.gate.auth;

import java.util.Map;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.log.Log;

public class GateAuthEvHdlr extends AbstractEventHandler<GateAuthEvArg, GateAuthEvRslt> {
	
	public static GateAuthEvRslt exec( GateAuthEvArg arg ) throws CareerException {
		GateAuthEvHdlr handler = new GateAuthEvHdlr();
		return handler.call( arg );
	}
	
	public GateAuthEvRslt call( GateAuthEvArg arg ) throws CareerException {
		return this.callEjb( arg );
	}
	
	protected GateAuthEvRslt execute( GateAuthEvArg arg ) throws CareerException {
		Log.method( arg.getLoginNo(), "IN", "" );
		arg.validateArg();
		String tracer = arg.getLoginNo();
		GateAuthEvRslt result = new GateAuthEvRslt();
		try {
			
			if (SU.equals( arg.sharp, "AUTH" )) {
				GateAuthUnit u = new GateAuthUnit( tracer );
				GateAuthUnitIn in = new GateAuthUnitIn( tracer );
				in.sign = arg.authOrder.sign;
				in.password = arg.authOrder.password;
				GateAuthUnitOut out = u.auth( in );
				result.success = out.success;
				result.sign = arg.authOrder.sign;
				result.pid = out.pid;
				result.isExpired = out.isExpired;
				result.isAccountLocked = out.isAccountLocked;
				result.needsReset = out.needsReset;
			}
			else if (SU.equals( arg.sharp, "SECRET" )) {
				GateAuthUnit u = new GateAuthUnit( tracer );
				String secret = u.prepareSecret( arg.secretOrder );
				result.secret = secret;
			}
			else if (SU.equals( arg.sharp, "RECEIVE" )) {
				GateAuthUnit u = new GateAuthUnit( tracer );
				Map<String, String> args = u.receive( arg.receiveOrder );
				result.gateArgs = args;
			}
			
			return result;
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
	}
	
}
