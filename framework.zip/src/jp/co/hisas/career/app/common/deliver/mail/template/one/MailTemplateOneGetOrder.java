package jp.co.hisas.career.app.common.deliver.mail.template.one;

import jp.co.hisas.career.app.common.deliver.DeliveryOrder;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.util.Tray;

public class MailTemplateOneGetOrder extends DeliveryOrder {
	
	public String templateId;
	
	public MailTemplateOneGetOrder(Tray tray) {
		super( tray );
	}
	
	public void validate() throws CareerBusinessException {
	}
}
