package jp.co.hisas.career.app.common.service;

import java.io.IOException;
import java.io.Serializable;

import org.apache.commons.io.IOUtils;

import com.google.gson.Gson;

import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.SU;

public class OrderMaker implements Serializable {
	
	public String tracer;
	
	public OrderMaker(Line line) {
		this.init( line );
	}
	
	public void init( Line line ) {
		this.tracer = line.tracer;
	}
	
	public static <T> T fromJson( Line line, Class<T> cls ) {
		Gson gson = new Gson();
		String json = getRequestBody( line );
		T order = gson.fromJson( SU.bvl( json, "{}" ), cls );
		return order;
	}
	
	private static String getRequestBody( Line line ) {
		try {
			return IOUtils.toString( line.request.getInputStream(), "UTF-8" );
		} catch (IOException e) {
			return null;
		}
	}
}
