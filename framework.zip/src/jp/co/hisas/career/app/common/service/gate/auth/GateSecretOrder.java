package jp.co.hisas.career.app.common.service.gate.auth;

import jp.co.hisas.career.app.common.service.OrderMaker;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.SU;

public class GateSecretOrder extends OrderMaker {
	
	public int pid;
	public String party;
	
	public GateSecretOrder(Line line) {
		super( line );
	}
	
	public void validate() throws CareerBusinessException {
		if (SU.isBlank( this.pid + "" )) {
			throw new CareerBusinessException( CareerBusinessException.INVALID_ORDER );
		}
	}
}
