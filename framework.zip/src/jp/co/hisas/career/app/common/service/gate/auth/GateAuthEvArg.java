package jp.co.hisas.career.app.common.service.gate.auth;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;

public class GateAuthEvArg extends AbstractEventArg {
	
	public String sharp;
	public GateAuthOrder authOrder;
	public GateSecretOrder secretOrder;
	public GateReceiveOrder receiveOrder;
	
	public GateAuthEvArg(String loginNo) throws CareerException {
		// TODO: loginNo → tracer
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: loginNo is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		// TODO: オーダーチェック機構
	}
	
}
