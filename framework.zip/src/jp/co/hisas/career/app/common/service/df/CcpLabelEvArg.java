package jp.co.hisas.career.app.common.service.df;

import jp.co.hisas.career.ejb.AbstractEventArg;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;

public class CcpLabelEvArg extends AbstractEventArg {
	
	public String sharp = null;
	public String party;
	public String labelId;
	public String labelText;
	
	public CcpLabelEvArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid CcpLabelEvArg: loginNo is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		if (SU.isBlank( sharp )) {
			throw new CareerException( "Invalid CcpLabelEvArg: sharp is null." );
		}
	}
}
