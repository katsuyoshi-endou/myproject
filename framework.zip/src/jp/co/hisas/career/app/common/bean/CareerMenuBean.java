package jp.co.hisas.career.app.common.bean;

import java.io.Serializable;

import jp.co.hisas.career.app.common.event.CareerMenuEvArg;
import jp.co.hisas.career.app.common.event.CareerMenuEvHdlr;
import jp.co.hisas.career.app.common.event.CareerMenuEvRslt;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.dto.CareerMenuActiveDto;

public class CareerMenuBean implements Serializable {
	
	public String guid;
	public String menuGrp;
	public String menuId;
	public String menuLabel;
	public String menuPath;
	public String menuTrans;
	public String party;
	public String partyLabel;
	public String lpadSort;
	public String availFlg;
	public String menuPtn;
	
	public CareerMenuBean() {
	}
	
	public static void init( Tray tray ) throws CareerException {
		
		String selectedMenuGrp = AU.getSessionAttr( tray.session, AppSessionKey.CAREER_MENU_GRP );
		String selectedMenuId = AU.getRequestValue( tray.request, "selectedMenuId" );
		
		CareerMenuEvArg arg = new CareerMenuEvArg( tray.loginNo );
		arg.sharp = "ONE_MENU";
		arg.party = tray.party;
		arg.guid = tray.loginNo;
		arg.operatorGuid = tray.operatorGuid;
		arg.menuGrp = selectedMenuGrp;
		arg.menuId = selectedMenuId;
		CareerMenuEvRslt result = CareerMenuEvHdlr.exec( arg );
		
		CareerMenuBean bean = convDto2Bean( result.oneMenu );
		tray.session.setAttribute( AppSessionKey.CAREER_ONE_MENU, bean );
		
		tray.menu = bean;
	}
	
	private static CareerMenuBean convDto2Bean( CareerMenuActiveDto dto ) {
		CareerMenuBean bean = new CareerMenuBean();
		bean.guid = dto.getGuid();
		bean.menuGrp = dto.getMenuGrp();
		bean.menuId = dto.getMenuId();
		bean.menuLabel = dto.getMenuLabel();
		bean.menuPath = dto.getMenuPath();
		bean.menuTrans = dto.getMenuTrans();
		bean.party = dto.getParty();
		bean.partyLabel = dto.getPartyLabel();
		bean.lpadSort = dto.getLpadSort();
		bean.availFlg = dto.getAvailFlg();
		bean.menuPtn = dto.getMenuPtn();
		return bean;
	}
}
