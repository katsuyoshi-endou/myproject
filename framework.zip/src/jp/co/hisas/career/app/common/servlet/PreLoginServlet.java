package jp.co.hisas.career.app.common.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.app.common.event.DualEvArg;
import jp.co.hisas.career.app.common.event.DualEvHdlr;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

public class PreLoginServlet extends HttpServlet {
	
	ServletContext ctx = null;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	public void service( final HttpServletRequest request, final HttpServletResponse response ) throws IOException, ServletException {
		try {
			/* ログ出力クラス初回呼び出し HCDB定義ファイル、Log4J定義ファイルの 読み込みが行われる */
			Log.method( "", "IN", "" );
			Log.performance( "", true, "" );
			
			/* Check DB access */
			DualEvHdlr.exec( new DualEvArg( "PreLogin" ) );
			
			/* プロパティファイル読込 */
			ReadFile.loadIfNotCached();
			
			/* リシテアCareer アプリ認証画面に遷移 */
			final RequestDispatcher rd = this.ctx.getRequestDispatcher( "/view/auth/VYA_AppLogin.jsp" );
			rd.forward( request, response );
			
			Log.performance( "", false, "" );
			Log.method( "", "OUT", "" );
		} catch (final Exception e) {
			Log.error( "", e );
			request.setAttribute( "Exception", e );
			this.ctx.getRequestDispatcher( "/view/error.jsp" ).forward( request, response );
		}
	}
	
}
