package jp.co.hisas.career.app.common.service.gate.auth;

import jp.co.hisas.career.app.common.unit.ServiceUnitIn;

public class GateAuthUnitIn extends ServiceUnitIn {
	
	public String sign;
	public String password;
	
	public GateAuthUnitIn(String daoLoginNo) {
		super( daoLoginNo );
	}
}
