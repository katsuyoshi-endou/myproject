package jp.co.hisas.career.app.common.deliver.mail.queue;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Tray;

public class MailQueueDeliver {
	
	public static MailQueueEvRslt sendFromUser( Tray tray, MailQueueOrder order ) throws CareerException {
		order.validate();
		
		MailQueueEvArg arg = new MailQueueEvArg( tray.loginNo );
		arg.sharp = "SEND_FROM_USER";
		arg.order = order;
		return MailQueueEvHdlr.exec( arg );
	}
}
