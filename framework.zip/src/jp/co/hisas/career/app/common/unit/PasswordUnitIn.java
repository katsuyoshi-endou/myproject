package jp.co.hisas.career.app.common.unit;

public class PasswordUnitIn extends ServiceUnitIn {
	
	public String sign;
	public String email;
	public String token;
	public int pid;
	public String newPassword;
	
	public PasswordUnitIn(String tracer) {
		super( tracer );
	}
}
