package jp.co.hisas.career.app.common.unit;

import java.util.Map;

import jp.co.hisas.career.app.common.garage.MailQueueGarage;
import jp.co.hisas.career.app.common.garage.MailTemplateGarage;
import jp.co.hisas.career.app.common.garage.RegistGarage;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dto.CaMailTemplateDto;
import jp.co.hisas.career.util.dto.CaRegistDto;
import jp.co.hisas.career.util.dto.CaRegistMainDto;

public class MailQueueUnit {
	
	public static void sendFromSystem( MailQueueUnitIn in ) {
		MailTemplateGarage ggMT = new MailTemplateGarage( in.tracer );
		MailQueueGarage ggMQ = new MailQueueGarage( in.tracer );
		RegistGarage ggRG = new RegistGarage( in.tracer );
		
		/* メールテンプレートの取得 */
		CaMailTemplateDto template = ggMT.selectMailTemplateOne( in.party, in.templateId );
		
		/* テンプレート本文の変数を置換 */
		String replacedBody = makeReplacedBody( template.getBody(), in.replaceMap );
		
		/* FROMアドレスの取得 */
		String fromAddress = AU.getCareerProperty( "LYSITHEA_SENDMAIL_FROM" );
		
		/* TOアドレスにTO用GUIDから導いたメールアドレスを設定 */
		String toAddress = null;
		if (SU.isNotBlank( in.toGuid )) {
			// TO用GUIDから導く
			CaRegistMainDto dtoTo = ggRG.getByGuid( in.party, in.toGuid );
			toAddress = dtoTo.getMailAddress();
		}
		else {
			// TO用会社コード・社員番号から導く
			CaRegistDto dtoTo = ggRG.getByCmpaStf( in.toCmpaCd, in.toStfNo );
			toAddress = dtoTo.getMailAddress();
		}
		
		/* CCアドレスにCC用GUIDから導いたメールアドレスを設定 */
		String ccAddress = null;
		if (SU.isNotBlank( in.ccGuid )) {
			CaRegistMainDto dtoCc = ggRG.getByGuid( in.party, in.ccGuid );
			ccAddress = dtoCc.getMailAddress();
		}
		
		/* [MAIL_INFO]テーブルに追加 */
		ggMQ.insertMailInfo( fromAddress, toAddress, ccAddress, template.getSubject(), replacedBody, in.actionPersonId );
	}
	
	public static void sendFromUser( MailQueueUnitIn in ) {
		MailTemplateGarage ggMT = new MailTemplateGarage( in.tracer );
		MailQueueGarage ggMQ = new MailQueueGarage( in.tracer );
		RegistGarage ggRG = new RegistGarage( in.tracer );
		
		/* メールテンプレートの取得 */
		CaMailTemplateDto template = ggMT.selectMailTemplateOne( in.party, in.templateId );
		
		/* テンプレート本文の変数を置換 */
		String replacedBody = makeReplacedBody( template.getBody(), in.replaceMap );
		
		/* Fromアドレスにログインユーザのメールアドレスを設定 */
		CaRegistMainDto dtoFr = ggRG.getByGuid( in.party, in.loginGuid );
		String fromAddress = dtoFr.getMailAddress();
		
		/* TOアドレスにTO用GUIDから導いたメールアドレスを設定 */
		String toAddress = null;
		if (SU.isNotBlank( in.toGuid )) {
			// TO用GUIDから導く
			CaRegistMainDto dtoTo = ggRG.getByGuid( in.party, in.toGuid );
			toAddress = dtoTo.getMailAddress();
		}
		else {
			// TO用会社コード・社員番号から導く
			CaRegistDto dtoTo = ggRG.getByCmpaStf( in.toCmpaCd, in.toStfNo );
			toAddress = dtoTo.getMailAddress();
		}
		
		/* CCアドレスにCC用GUIDから導いたメールアドレスを設定 */
		String ccAddress = null;
		if (SU.isNotBlank( in.ccGuid )) {
			CaRegistMainDto dtoCc = ggRG.getByGuid( in.party, in.ccGuid );
			ccAddress = dtoCc.getMailAddress();
		}
		
		/* [MAIL_INFO]テーブルに追加 ※CC */
		ggMQ.insertMailInfo( fromAddress, toAddress, ccAddress, template.getSubject(), replacedBody, in.actionPersonId );
	}
	
	private static String makeReplacedBody( String body, Map<String, String> replaceMap ) {
		if (replaceMap == null) {
			return body;
		}
		String replacedBody = SU.ntb( body );
		for (Map.Entry<String, String> entry : replaceMap.entrySet()) {
			String key = entry.getKey();
			String val = SU.ntb( entry.getValue() );
			// #{key} -> val
			replacedBody = replacedBody.replaceAll( "\\#\\{" + key + "\\}", val );
		}
		return replacedBody;
	}
}
