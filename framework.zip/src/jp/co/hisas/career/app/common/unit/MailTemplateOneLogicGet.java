package jp.co.hisas.career.app.common.unit;

import jp.co.hisas.career.app.common.deliver.mail.template.one.MailTemplateOneEvRslt;
import jp.co.hisas.career.app.common.deliver.mail.template.one.MailTemplateOneGetOrder;
import jp.co.hisas.career.app.common.garage.MailTemplateGarage;

public class MailTemplateOneLogicGet {
	
	private String daoLoginNo;
	
	public MailTemplateOneLogicGet(String daoLoginNo) {
		this.daoLoginNo = daoLoginNo;
	}
	
	public MailTemplateOneEvRslt main( MailTemplateOneGetOrder o ) {
		MailTemplateOneEvRslt r = new MailTemplateOneEvRslt();
		MailTemplateGarage ggMT = new MailTemplateGarage( daoLoginNo );
		
		r.template = ggMT.selectMailTemplateOne( o.party, o.templateId );
		
		return r;
	}
	
}
