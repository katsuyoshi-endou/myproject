package jp.co.hisas.career.app.common.event;

import jp.co.hisas.career.app.common.garage.UserGarage;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dto.CaUserDto;

public class UserEvHdlr extends AbstractEventHandler<UserEvArg, UserEvRslt> {
	
	private String daoLoginNo;
	
	public static UserEvRslt exec( UserEvArg arg ) throws CareerException {
		UserEvHdlr handler = new UserEvHdlr();
		return handler.call( arg );
	}
	
	public UserEvRslt call( UserEvArg arg ) throws CareerException {
		return this.callEjb( arg );
	}
	
	protected UserEvRslt execute( UserEvArg arg ) throws CareerException {
		arg.validateArg();
		this.daoLoginNo = arg.getLoginNo();
		UserEvRslt result = new UserEvRslt();
		
		if (SU.equals( "SELECT_BY_SIGN", arg.sharp )) {
			UserGarage ggUs = new UserGarage( daoLoginNo );
			CaUserDto caUserDto = ggUs.selectBySign( arg.sign );
			result.caUserDto = caUserDto;
			if (caUserDto != null) {
				result.isOperator = ggUs.isOperator( caUserDto.getParty(), caUserDto.getPid() );
			}
		}
		
		return result;
	}
}
