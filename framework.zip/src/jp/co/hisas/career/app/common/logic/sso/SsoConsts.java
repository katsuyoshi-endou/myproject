package jp.co.hisas.career.app.common.logic.sso;

/**
 * 本アプリケーションで使用する定数を定義します。
 */
public class SsoConsts {

	/**
	 * GUIDのクッキー名を表す定数
	 */
	public static final String GUID_COOKIE_NAME = "LYSITHEA_ID";
}
