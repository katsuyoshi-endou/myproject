package jp.co.hisas.career.app.common.unit;

import java.util.Map;

import jp.co.hisas.career.app.common.deliver.mail.template.MailTemplateEvRslt;
import jp.co.hisas.career.app.common.deliver.mail.template.MailTemplateGetOrder;
import jp.co.hisas.career.app.common.garage.MailTemplateGarage;
import jp.co.hisas.career.util.property.CommonLabel;

public class MailTemplateLogicGet {
	
	private String daoLoginNo;
	
	public MailTemplateLogicGet(String daoLoginNo) {
		this.daoLoginNo = daoLoginNo;
	}
	
	public MailTemplateEvRslt main( MailTemplateGetOrder o ) {
		MailTemplateEvRslt r = new MailTemplateEvRslt();
		MailTemplateGarage ggMT = new MailTemplateGarage( daoLoginNo );
		
		r.uiLabelSet = getUiLabelSet( o.party, o.langNo );
		r.templates = ggMT.selectAllMailTemplates( o.party );
		
		return r;
	}
	
	private Map<String, String> getUiLabelSet( String party, int langNo ) {
		return CommonLabel.getLabelsWithRegex( party, langNo, "LSHMLT_UI\\..*" );
	}
	
}
