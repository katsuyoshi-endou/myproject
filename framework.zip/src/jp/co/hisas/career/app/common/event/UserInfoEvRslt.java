package jp.co.hisas.career.app.common.event;

import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.CareerGuidDto;

@SuppressWarnings("serial")
public class UserInfoEvRslt extends AbstractEventResult {

	public CareerGuidDto careerGuidDto;
}