package jp.co.hisas.career.app.common.deliver.mail.queue;

import java.util.Map;

import jp.co.hisas.career.app.common.deliver.DeliveryOrder;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class MailQueueOrder extends DeliveryOrder {
	
	public String loginGuid;
	public String templateId;
	public Map<String, String> replaceMap;
	
	public String toGuid;
	public String toCmpaCd;
	public String toStfNo;
	public String ccGuid;
	public String actionPersonId;
	
	public MailQueueOrder(Tray tray) {
		super( tray );
		
		this.actionPersonId = tray.loginNo;
	}
	
	public void validate() throws CareerBusinessException {
		if (SU.isBlank( this.actionPersonId )) {
			throw new CareerBusinessException( CareerBusinessException.INVALID_ORDER );
		}
	}
}
