package jp.co.hisas.career.app.common.servlet;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import jp.co.hisas.career.app.common.bean.CareerMenuBean;
import jp.co.hisas.career.app.common.bean.ExcelDownloadBean;
import jp.co.hisas.career.app.common.bean.ExcelLargeDownloadBean;
import jp.co.hisas.career.framework.trans.ResponsedServlet;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.AppSessionKey;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.bean.OutLogBean;

public class ExcelDownloadServlet extends ResponsedServlet {
	
	private static final long serialVersionUID = 1L;
	
	public void serviceMain( Tray tray ) throws Exception {
		
		CareerMenuBean oneMenu = AU.getSessionAttr( tray.session, AppSessionKey.CAREER_ONE_MENU );
		
		String xlTemplatePrefix = AU.getRequestValue( tray.request, "xlTemplatePrefix" );
		String xlTemplateId = AU.getRequestValue( tray.request, "xlTemplateId" );
		String templateFileId = xlTemplatePrefix + "_" + xlTemplateId;
		String templateFileName = "";
		String dlFileName = "download.xlsx";
		
		if (SU.matches( tray.state, "SOMETHING" )) {
			dlFileName = "thebook.xlsx";
			FileInputStream fis = new FileInputStream( "c:\\tmp\\thebook.xlsx" );
			Workbook workbook = WorkbookFactory.create( fis );
			dlFileName = getOutputFileName( templateFileId );
			httpxlFileDl( tray.response, workbook, dlFileName );
		} else if (SU.matches( tray.state, "SQLPROP" )) {
			ExcelDownloadBean bean = new ExcelDownloadBean();
			templateFileName = "SqlProp-" + oneMenu.party + "-" + templateFileId;
			Workbook workbook = bean.createWorkbook( tray.request, tray.session, tray.state, templateFileName );
			dlFileName = getOutputFileName( templateFileId );
			httpxlFileDl( tray.response, workbook, dlFileName );
		} else if (SU.matches( tray.state, "SQLPROP_LARGE" )) {
			ExcelLargeDownloadBean lbean = new ExcelLargeDownloadBean();
			templateFileName = "SqlProp-" + oneMenu.party + "-" + templateFileId;
			// メモリ不足のため別ルート
			Workbook workbook = lbean.createWorkbook( tray.request, tray.session, tray.state, templateFileName );
			dlFileName = getOutputFileName( templateFileId );
			// メモリ不足のため別ルート
			httpxlLargeFileDl( tray.response, workbook, dlFileName );
			if (workbook instanceof SXSSFWorkbook) {
				((SXSSFWorkbook)workbook).dispose();
			}
		} else if (SU.matches( tray.state, "SESSION" )) {
			ExcelDownloadBean bean = new ExcelDownloadBean();
			templateFileName = "DataList-" + oneMenu.party + "-" + templateFileId;
			Workbook workbook = bean.createWorkbook( tray.request, tray.session, tray.state, templateFileName );
			dlFileName = getOutputFileName( templateFileId );
			httpxlFileDl( tray.response, workbook, dlFileName );
		}
		// 操作ログ
		OutLogBean.outputLogSousa( tray.request, "EXCEL_DL", templateFileName );
	}
	
	private String getOutputFileName( String fileNamePrefix ) {
		String timestamp = AU.getTimestamp( "yyyyMMddHHmmss" );
		return fileNamePrefix + "_" + timestamp + ".xlsx";
	}
	
	private void httpxlFileDl( final HttpServletResponse response, Workbook workbook, String dlFileName ) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			workbook.write( baos );
			byte[] dlByteArr = baos.toByteArray();
			AU.httpExcelFileDownload( response, dlByteArr, dlFileName );
		} finally {
			baos.close();
		}
	}

	private void httpxlLargeFileDl( final HttpServletResponse response, Workbook workbook, String dlFileName ) throws IOException {
		response.setContentType( "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" );
		response.setHeader( "Content-Disposition", "attachment; filename=\"" + dlFileName + "\"" );
		final ServletOutputStream out = response.getOutputStream();
		workbook.write( out );
	}
}
