package jp.co.hisas.career.app.common.logic;

import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.app.common.event.CareerGuidEvArg;
import jp.co.hisas.career.app.common.event.CareerGuidEvHdlr;
import jp.co.hisas.career.app.common.event.CareerGuidEvRslt;
import jp.co.hisas.career.app.common.event.DualEvArg;
import jp.co.hisas.career.app.common.event.DualEvHdlr;
import jp.co.hisas.career.app.common.logic.sso.AccountResult;
import jp.co.hisas.career.app.common.logic.sso.LysitheaSso;
import jp.co.hisas.career.app.common.service.gate.GateService;
import jp.co.hisas.career.app.common.service.gate.auth.GateReceiveOrder;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.dto.CareerGuidDto;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.CommonLabel;
import jp.co.hisas.career.util.property.ReadFile;

public class LoginLogic {
	
	/**
	 * Lysithea Portal SSO Module (LysitheaSsoModule.jar)
	 */
	public static String authSSO( HttpServletRequest request ) {
		String guid = null;
		
		try {
			AccountResult accountInfo = LysitheaSso.auth( request );
			if (accountInfo.isAuthed()) {
				guid = accountInfo.getGuid();
			}
		} catch (CareerException e) {
			String msg_unexceptedError = CommonLabel.getLabel( "FW_MSG_LOGIN_UNEXPECTED_ERR" );
			throw new CareerRuntimeException( msg_unexceptedError );
		}
		return guid;
	}
	
	/**
	 * via Guild SSO [CA_GATE_SECRET]
	 */
	public static Map<String, String> authGateSecret( Line line ) {
		Map<String, String> args = null;
		try {
			String secret = AU.getRequestValue( line.request, "secret" );
			GateReceiveOrder order = new GateReceiveOrder( line );
			order.secret = secret;
			args = GateService.receive( order );
		} catch (Exception e) {
			Log.error( line.request, e );
			String msg_unexceptedError = CommonLabel.getLabel( "FW_MSG_LOGIN_UNEXPECTED_ERR" );
			throw new CareerRuntimeException( msg_unexceptedError );
		}
		return args;
	}
	
	public static void prepareLoginBefore( Tray tray, String funcName ) throws CareerException {
		/* Check DB access */
		DualEvHdlr.exec( new DualEvArg( funcName ) );
		
		/* Read property files and DB parameters */
		ReadFile.loadIfNotCached();
		
		/* セッション管理 */
		tray.session = makeSession( tray.request );
	}
	
	public static void prepareLoginBefore( Tray tray, Line line, String funcName ) throws CareerException {
		/* Check DB access */
		DualEvHdlr.exec( new DualEvArg( funcName ) );
		
		/* Read property files and DB parameters */
		ReadFile.loadIfNotCached();
		
		/* セッション管理 */
		tray.session = makeSession( tray.request );
		line.session = tray.session;
	}
	
	public static void prepareLoginAfter( Tray tray, String guid ) throws CareerException {
		/* Check account exists */
		boolean accountExists = checkAccount( guid );
		if (!accountExists) {
			String msg_accountNotExists = CommonLabel.getLabel( "FW_MSG_LOGIN_OUTOFSERVICE" );
			throw new CareerRuntimeException( msg_accountNotExists );
		}
		
		/* Detect Request Parameter */
		String party = AU.getReqParaAttrVal( tray.request, "p" );
		String lang  = AU.getReqParaAttrVal( tray.request, "lang" );
		
		/* Set UserInfo */
		UserInfoBean userInfo = new UserInfoBean();
		userInfo.setLogin_no( guid );
		userInfo.loadLangNo( lang );
		userInfo.loadParty( party );
		tray.session.setAttribute( UserInfoBean.SESSION_KEY, userInfo );
		
		/*
		 * ログイン時にキーを生成しsessionとcookieに格納。
		 * ブラウザ側でsessionから取得したキーとcookieを比較し、
		 * 一致しなければウィンドウを閉じる（JavaScript）。
		 */
		String windowKey = String.valueOf( System.currentTimeMillis() );
		tray.session.setAttribute( "WindowKey", windowKey );
		Cookie cookie = new Cookie( "WindowKey", windowKey );
		cookie.setPath( "/" + AppDef.CTX_ROOT );
		tray.response.addCookie( cookie );
	}
	
	private static boolean checkAccount( String guid ) throws CareerException {
		
		/* Set Args */
		CareerGuidEvArg arg = new CareerGuidEvArg( guid );
		arg.sharp = "INIT";
		arg.guid = guid;
		
		/* Execute Event */
		CareerGuidEvRslt result = CareerGuidEvHdlr.exec( arg );
		CareerGuidDto dto = result.careerGuidDto;
		
		return (dto != null);
	}
	
	private static HttpSession makeSession( final HttpServletRequest request ) {
		HttpSession beforeSession = request.getSession( false );
		if (beforeSession != null) {
			if (Log.isSecurityDebugOn()) {
				Log.security( null, "既存のセッション「" + beforeSession.getId() + "」を破棄しました。" );
			}
			beforeSession.invalidate();
		}
		/*
		 * # getSession( arg ) ##########
		 * true : Generate if not exists
		 * false: Get if exists else null
		 */
		final HttpSession session = request.getSession( true );
		if (Log.isSecurityDebugOn()) {
			Log.security( null, "セッション「" + session.getId() + "」を新規作成しました。" );
		}
		return session;
	}
	
}
