package jp.co.hisas.career.app.common.event;

import jp.co.hisas.career.ejb.AbstractEventResult;
import jp.co.hisas.career.util.dto.CaUserDto;

@SuppressWarnings("serial")
public class UserEvRslt extends AbstractEventResult {
	
	public CaUserDto caUserDto;
	public boolean isOperator;
}
