package jp.co.hisas.career.app.common.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.app.common.logic.AppAuth;
import jp.co.hisas.career.app.common.logic.LoginLogic;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.CommonLabel;

public class LoginServlet extends HttpServlet {
	
	private ServletContext ctx = null;
	boolean isAppAuth;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	public void service( final HttpServletRequest req, final HttpServletResponse res ) throws ServletException, IOException  {
		
		Log.method( "", "IN", "" );
		Log.performance( "", true, "" );
		
		String guid = null;
		try {
			Tray tray = new Tray( req, res, false );
			
			// ログイン前処理
			LoginLogic.prepareLoginBefore( tray, "Login" );
			
			isAppAuth = SU.equals( "appAuth", (String)tray.request.getParameter( "authType" ) );
			if (isAppAuth) {
				/* Careerアプリ認証 */
				guid = AppAuth.authByTray( tray );
			}
			else {
				/* メンテナンス中 */
				String msg = CommonLabel.getLabel( "FW_MSG_SERVER_MAINTENANCE" );
				throw new CareerRuntimeException( msg );
			}
			
			// ログイン後処理
			LoginLogic.prepareLoginAfter( tray, guid );
			
			/* ホームにリダイレクト */
			res.sendRedirect( "/" + AppDef.CTX_ROOT + AppDef.HOME_URL );
			
			Log.performance( guid, false, "" );
			Log.method( guid, "OUT", "" );
			
		} catch (final CareerRuntimeException e) {
			Log.error( guid, e );
			/* 認証失敗 */
			forwardToErrorPage( req, res, e, e.getMessage() );
			
		} catch (final Exception e) {
			Log.error( guid, e );
			/* 認証処理で予期せぬエラー発生 */
			String label = CommonLabel.getLabel( "FW_MSG_AUTH_UNEXPECTED_ERR" );
			String msg = SU.isNotBlank( label ) ? label : "認証処理で予期せぬエラーが発生しました。";
			forwardToErrorPage( req, res, e, msg );
		}
	}
	
	private void forwardToErrorPage( HttpServletRequest req, HttpServletResponse res, Exception e, String msg ) throws ServletException, IOException {
		req.setAttribute( "DB_ERR_MSG", msg );
		req.setAttribute( "Exception", e );
		String nextPage = "";
		if (isAppAuth) {
			nextPage = "/view/auth/VYA_AppLogin.jsp";
		} else {
			nextPage = "/view/error.jsp";
		}
		this.ctx.getRequestDispatcher( nextPage ).forward( req, res );
	}
	
}
