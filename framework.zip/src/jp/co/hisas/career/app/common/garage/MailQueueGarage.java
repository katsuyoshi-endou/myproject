package jp.co.hisas.career.app.common.garage;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.MailInfoDao;

public class MailQueueGarage extends Garage {
	
	public MailQueueGarage(String daoLoginNo) {
		super( daoLoginNo );
	}
	
	public void insertMailInfo( String fromAddress, String toAddress, String ccAddress, String title, String body, String actionPersonId ) {
		
		String sendTimestamp = AU.getTimestamp( "yyyy/MM/dd HH:mm:ss" );
		
		StringBuilder sql = new StringBuilder();
		sql.append( " insert into MAIL_INFO (SEND_NO, STATUS, FROM_ADDRESS, TO_ADDRESS, CC_ADDRESS, TITLE, BODY, ACTION_PERSON_ID, UPDATE_DATE) " );
		sql.append( " select (select nvl( MAX(SEND_NO), 0 ) + 1 from MAIL_INFO) as SEND_NO " );
		sql.append( "      , 0 as STATUS " );
		sql.append( "      , ? as FROM_ADDRESS " );
		sql.append( "      , ? as TO_ADDRESS " );
		sql.append( "      , ? as CC_ADDRESS " );
		sql.append( "      , ? as TITLE " );
		sql.append( "      , ? as BODY " );
		sql.append( "      , ? as ACTION_PERSON_ID " );
		sql.append( "      , to_date(?,'YYYY/MM/DD HH24:MI:SS') as UPDATE_DATE " );
		sql.append( "   from DUAL " );
		
		List<String> p = new ArrayList<String>();
		p.add( fromAddress );
		p.add( toAddress );
		p.add( ccAddress );
		p.add( title );
		p.add( body );
		p.add( actionPersonId );
		p.add( sendTimestamp );
		
		MailInfoDao dao = new MailInfoDao( daoLoginNo );
		dao.executeDynamic( DaoUtil.getPstmt( sql, p ) );
	}
}
