package jp.co.hisas.career.app.common.deliver;

import java.io.IOException;
import java.io.Serializable;

import org.apache.commons.io.IOUtils;

import com.google.gson.Gson;

import jp.co.hisas.career.app.common.bean.UserBean;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.Line;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;

public class DeliveryOrder implements Serializable {
	
	public String tracer;
	
	public String party;
	public int langNo;
	public String sessionId;
	public String operatorGuid;
	
	public DeliveryOrder(Line line) throws CareerException {
		this.init( line );
	}
	
	public DeliveryOrder(Tray tray) {
		this.init( tray );
	}
	
	public void init( Line line ) {
		UserBean user = line.getUser();
		this.tracer = line.tracer;
		this.party = (user != null) ? user.getParty() : null;
		this.langNo = 1;
		this.sessionId = line.session != null ? line.session.getId() : null;
	}
	
	public void init( Tray tray ) {
		this.tracer = tray.loginNo;
		this.party = tray.party;
		this.langNo = tray.langNo;
		this.sessionId = tray.session != null ? tray.session.getId() : null;
		this.operatorGuid = tray.operatorGuid;
	}
	
	public static <T> T fromJson( Tray tray, Class<T> cls ) {
		Gson gson = new Gson();
		String json = getRequestBody( tray );
		T order = gson.fromJson( SU.bvl( json, "{}" ), cls );
		return order;
	}
	
	private static String getRequestBody( Tray tray ) {
		try {
			return IOUtils.toString( tray.request.getInputStream(), "UTF-8" );
		} catch (IOException e) {
			return null;
		}
	}
}
