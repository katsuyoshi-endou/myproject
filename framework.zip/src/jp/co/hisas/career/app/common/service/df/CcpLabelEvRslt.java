package jp.co.hisas.career.app.common.service.df;

import jp.co.hisas.career.ejb.AbstractEventResult;

public class CcpLabelEvRslt extends AbstractEventResult {
}
