package jp.co.hisas.career.app.common.event;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.dao.CareerMenuActiveDao;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.dao.useful.OneColumnDao;
import jp.co.hisas.career.util.dto.CareerMenuActiveDto;

public class CareerMenuEvHdlr extends AbstractEventHandler<CareerMenuEvArg, CareerMenuEvRslt> {
	
	private String daoLoginNo;
	
	public static CareerMenuEvRslt exec( CareerMenuEvArg arg ) throws CareerException {
		CareerMenuEvHdlr handler = new CareerMenuEvHdlr();
		return handler.call( arg );
	}
	
	public CareerMenuEvRslt call( CareerMenuEvArg arg ) throws CareerException {
		return this.callEjb( arg );
	}
	
	protected CareerMenuEvRslt execute( CareerMenuEvArg arg ) throws CareerException {
		arg.validateArg();
		this.daoLoginNo = arg.getLoginNo();
		CareerMenuEvRslt result = new CareerMenuEvRslt();
		
		if (SU.equals( "INIT", arg.sharp )) {
			result.careerMenuList = getActiveCareerMenuList( arg );
			result.careerMenuPtn = getMenuPtn( result.careerMenuList );
		}
		else if (SU.equals( "ONE_MENU", arg.sharp )) {
			result.oneMenu = getOneMenu( arg );
		}
		
		return result;
	}
	
	private String getMenuPtn( List<CareerMenuActiveDto> careerMenuList ) {
		return (careerMenuList.size() > 0) ? careerMenuList.get( 0 ).getMenuPtn() : null;
	}
	
	private List<CareerMenuActiveDto> getActiveCareerMenuList( CareerMenuEvArg arg ) {
		CareerMenuActiveDao dao = new CareerMenuActiveDao( daoLoginNo );
		List<CareerMenuActiveDto> list = dao.selectMenuByGrp( arg.guid, arg.menuGrp );
		int stmpCnt = getSheetBindCnt( arg.party, arg.operatorGuid, "STAMP" );
		int cascCnt = getSheetBindCnt( arg.party, arg.operatorGuid, "CASCADE" );
		List<CareerMenuActiveDto> deleteList = new ArrayList<CareerMenuActiveDto>();
		for (CareerMenuActiveDto dto : list) {
			if ("hasCsBindStamp".equals( dto.getShowIf() )) {
				if (stmpCnt == 0) {
					deleteList.add( dto );
				}
			}
			if ("hasCsBindCascade".equals( dto.getShowIf() )) {
				if (cascCnt == 0) {
					deleteList.add( dto );
				}
			}
		}
		list.removeAll( deleteList );
		return list;
	}
	
	private int getSheetBindCnt( String party, String operatorGuid, String opeType ) {
		
		StringBuilder sql = new StringBuilder();
		sql.append( " select CNT as text " );
		sql.append( "   from CS_SHEET_BIND_CNT " );
		sql.append( "  where PARTY = ? " );
		sql.append( "    and GUID = ? " );
		sql.append( "    and OPERATION_TYPE = ? " );
		
		List<String> paramList = new ArrayList<String>();
		paramList.add( party );
		paramList.add( operatorGuid );
		paramList.add( opeType );
		
		OneColumnDao dao = new OneColumnDao( daoLoginNo );
		String cnt = dao.selectDynamicFirst( DaoUtil.getPstmt( sql, paramList ) );
		return SU.toInt( cnt, 0 );
	}
	
	private CareerMenuActiveDto getOneMenu( CareerMenuEvArg arg ) {
		CareerMenuActiveDao dao = new CareerMenuActiveDao( daoLoginNo );
		List<CareerMenuActiveDto> list = dao.selectOneMenu( arg.guid, arg.menuGrp, arg.menuId );
		CareerMenuActiveDto oneMenu = list.get( 0 );
		return oneMenu;
	}
	
}
