/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
 * <PRE>
 * 
 * クラス名：PZE_ExcelHanyoDownloadEJBHome クラス
 * 機能説明: クライアントがSessionBeanを生成、検索、削除するためのホームインタフェース。
 * 
 * </PRE>
 */
public interface PZE_ExcelHanyoDownloadEJBHome extends EJBHome {

	/**
	 * SessionBeanを生成、検索、削除する。
	 * @return リモートインタフェース
	 * @exception CreateException SQLエラーが発生した場合
	 * @exception RemoteException リモートメソッド呼び出しの実行中に発生する例外
	 */
	PZE_ExcelHanyoDownloadEJB create() throws CreateException, RemoteException;

}
