/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.ejb.EJBObject;
import javax.naming.NamingException;

public interface OutLogEJB extends EJBObject {

	/**
	 * ログインユーザ以外のユーザ情報の参照を行った場合、操作ログに内容を記録する。
	 * @param kinou_ID 実行機能ID
	 * @param simei_no 実行氏名No
	 * @param taisyou 対象氏名No(対象操作が1ユーザーの場合)
	 * @param jouken 対象操作が複数ユーザの場合、対象となる情報を絞り込むための条件
	 * @exception SQLException SQLエラーが発生した場合
	 * @exception NamingException データソースの参照取得に失敗した場合
	 */
	public void sousaKojinJohoLog(String kinou_ID, String simei_no, String taisyou, String jouken) throws NamingException, SQLException, RemoteException;

	/**
	 * メンテナンス権限を付与した場合に、権限変更ログテーブルに操作内容を記録する。
	 * @param kinou_ID 実行機能ID
	 * @param simei_no 実行氏名No
	 * @param taisyo 対象氏名No
	 * @param syubetsu 変更種別(0：登録 1:削除)
	 * @param kengenName 権限種別
	 * @exception SQLException SQLエラーが発生した場合
	 * @exception NamingException データソースの参照取得に失敗した場合
	 */
	public void sousaChangeKengenLog(String kinou_ID, String simei_no, String taisyo, int syubetsu, String kengenName) throws NamingException, SQLException, RemoteException;

}
