/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.HashMap;

import javax.ejb.EJBObject;
import javax.naming.NamingException;

/**
 * <PRE>
 * 
 * クラス名：PZE_ExcelHanyoDownloadEJB クラス
 * 機能説明: クライアントからSessionBeanを呼び出すためのリモートインタフェース。
 * 
 * </PRE>
 */
public interface PZE_ExcelHanyoDownloadEJB extends EJBObject {


	/**
	 * 対象のSQLから結果を取得する。
	 * 	<dl>※戻り値のキーについて
	 * 		<dt>singleItem: true</dt><dd>→ "defKey"</dd>
	 * 		<dt>singleItem: false</dt><dd>→ "defKey_ColNm_1" (※ColNm: targetSQLのSELECT句のAS)</dd>
	 * 	</dl>
	 * 
	 * @param loginNo ログオン社員
	 * @param targetSQL 対象のSQL
	 * @param defKey 定義名
	 * @param singleItem 単一項目かどうか
	 * @return 取得結果
	 * @exception SQLException SQLエラーが発生した場合
	 * @exception NamingException データソースの参照取得に失敗した場合
	 */
	public HashMap<String, String> getResultMapByTargetSql(String loginNo, String targetSQL, String mapKey, boolean singleItem)
			throws RemoteException, SQLException, NamingException;
}
