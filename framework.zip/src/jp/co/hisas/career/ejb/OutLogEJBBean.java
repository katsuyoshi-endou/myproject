/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;

public class OutLogEJBBean implements SessionBean {

	/* 操作ログテーブル */
	private static final String tbl1 = "CJS_LOG_SOUSA";

	/* 権限変更ログテーブル */
	private static final String tbl2 = "CJS_LOG_KENGEN";

	/* 発行SQL文 */
	private static final String sql1 = "INSERT INTO " + OutLogEJBBean.tbl1 + "( JIKKOU_HIDUKE, JIKKOU_JIKOKU, JIKKOU_KINOU_ID, JIKKOU_SIMEI_NO, TAISYOU_SIMEI_NO, JOUKEN ) VALUES( ?, ?, ?, ?, ?, ? )";

	private static final String sql2 = "INSERT INTO " + OutLogEJBBean.tbl2
			+ "( JIKKOU_HIDUKE, JIKKOU_JIKOKU, JIKKOU_KINOU_ID, JIKKOU_SIMEI_NO, TAISYO_SIMEI_NO, HENKOU_SYUBETSU, KENGEN_MEI ) VALUES( ?, ?, ?, ?, ?, ?, ? )";

	private SessionContext context = null;

	/**
	 * ログインユーザ以外のユーザ情報の参照を行った場合、操作ログに内容を記録する。
	 * @param kinou_ID 実行機能ID
	 * @param simei_no 実行氏名No
	 * @param taisyou 対象氏名No(対象操作が1ユーザーの場合)
	 * @param jouken 対象操作が複数ユーザの場合、対象となる情報を絞り込むための条件
	 * @exception SQLException SQLエラーが発生した場合
	 * @exception NamingException データソースの参照取得に失敗した場合
	 */
	public void sousaKojinJohoLog(final String kinou_ID, final String simei_no, final String taisyou, final String jouken) throws NamingException, SQLException {

		Log.method(simei_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement stmt = null;
		try {

			/* DB接続オブジェクトの獲得 */
			dbConn = PZZ040_SQLUtility.getConnection(simei_no);

			/* データベース接続を取得し、CJS_LOG_SOUSAテーブルに対してupdate文を発行 */
			stmt = dbConn.prepareStatement(OutLogEJBBean.sql1);
			stmt.clearParameters();

			/* データセット */
			stmt.setString(1, PZZ010_CharacterUtil.GetDay());
			stmt.setString(2, PZZ010_CharacterUtil.GetTime());
			stmt.setString(3, kinou_ID);
			stmt.setString(4, simei_no);
			stmt.setString(5, taisyou);
			stmt.setString(6, jouken);

			/* INSERT文発行 */
			stmt.executeUpdate();

			Log.method(simei_no, "OUT", "");

		} catch (final SQLException sqle) {
			Log.error(simei_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(simei_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(simei_no, dbConn, stmt, null);
		}
	}

	/**
	 * メンテナンス権限を付与した場合に、権限変更ログテーブルに操作内容を記録する。
	 * @param kinou_ID 実行機能ID
	 * @param simei_no 実行氏名No
	 * @param taisyo 対象氏名No
	 * @param syubetsu 変更種別(0：登録 1:削除)
	 * @param kengenName 権限種別
	 * @exception SQLException SQLエラーが発生した場合
	 * @exception NamingException データソースの参照取得に失敗した場合
	 */
	public void sousaChangeKengenLog(final String kinou_ID, final String simei_no, final String taisyo, final int syubetsu, final String kengenName) throws NamingException, SQLException {

		Log.method(simei_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement stmt = null;

		try {
			/* DB接続オブジェクトの獲得 */
			dbConn = PZZ040_SQLUtility.getConnection(simei_no);

			/* データベース接続を取得し、CJS_LOG_KENGENテーブルに対してupdate文を発行 */
			stmt = dbConn.prepareStatement(OutLogEJBBean.sql2);
			stmt.clearParameters();

			/* データセット */
			stmt.setString(1, PZZ010_CharacterUtil.GetDay());
			stmt.setString(2, PZZ010_CharacterUtil.GetTime());
			stmt.setString(3, kinou_ID);
			stmt.setString(4, simei_no);
			stmt.setString(5, taisyo);
			stmt.setInt(6, syubetsu);
			stmt.setString(7, kengenName);

			/* INSERT文発行 */
			stmt.executeUpdate();

			Log.method(simei_no, "OUT", "");

		} catch (final SQLException sqle) {
			Log.error(simei_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(simei_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(simei_no, dbConn, stmt, null);
		}
	}

	/**
	 * 何もしない。
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException {/* 何もしません */
	}

	/**
	 * 何もしない。
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException {/* 何もしません */
	}

	/**
	 * 何もしない。
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException {/* 何もしません */
	}

	/**
	 * 何もしない。
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException {/* 何もしません */
	}

	/**
	 * SessionContext情報を取得する。
	 * @return SessionContext情報
	 */
	public SessionContext getSessionContext() {
		return this.context;
	}

	/**
	 * EJBコンテナが管理するSessionContext情報をSessionBeanに渡す。SessionBeanの作成時に呼び出される。
	 * @param val SessionContext情報
	 * @exception RemoteException
	 */
	public void setSessionContext(final SessionContext val) throws RemoteException {
		this.context = val;
	}

}
