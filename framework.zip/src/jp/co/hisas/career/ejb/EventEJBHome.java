/*
 * All Rights Reserved. Copyright (C) 2004,2008, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

import jp.co.hisas.career.ejb.EventEJB;

/**
 * 概要: クライアントがSessionBeanを生成、検索、削除するためのホームインタフェース。
 * 
 * @author kats-watanabe
 */
public interface EventEJBHome extends EJBHome {
	
	/**
	 * SessionBeanを生成、検索、削除する。
	 * 
	 * @return リモートインタフェース
	 * @exception CreateException EJBオブジェクトの生成が失敗した場合
	 * @exception RemoteException リモートメソッド呼び出しの実行中に発生する例外
	 */
	EventEJB create() throws CreateException, RemoteException;
	
}
