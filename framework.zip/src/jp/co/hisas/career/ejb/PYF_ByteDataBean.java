/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * プロジェクト名　：
 *   リシテアCareer
 *
 * 備考　：
 *   なし
 *
 * 履歴　：
 *   日付        バージョン  名前         内容
 *   2005/02/10  01.00      城間 意樹    新規作成
 */
package jp.co.hisas.career.ejb;

import java.io.Serializable;

/**
 * <PRE>
 * 
 * クラス名： PCY_ByteDataBean クラス 機能説明： バイナリデータを保持するBeanです。
 * 
 * </PRE>
 */
public class PYF_ByteDataBean implements Serializable {

	private byte[] data;

	public PYF_ByteDataBean() {
	}

	/**
	 * バイトデータを取得する
	 * @return
	 */
	public byte[] getData() {
		return this.data;
	}

	/**
	 * バイトデータを設定する
	 * @param bs
	 */
	public void setData(final byte[] bs) {
		this.data = bs;
	}

}
