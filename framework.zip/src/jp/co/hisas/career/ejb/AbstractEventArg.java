/*
 * All Rights Reserved. Copyright (C) 2004,2008, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.ejb;

import java.io.Serializable;

/**
 * ビジネスロジックを呼び出すときの引数の基底クラス。
 * 
 * @author kats-watanabe
 */
public abstract class AbstractEventArg implements Serializable {
	
	/** ログインしている社員の社員NO */
	private String loginNo;
	
	/** 遷移後ヘッダ表示文言 */
	String headerLabelAfterTrans;
	
	/**
	 * ログインしている社員の社員NOを取得する。
	 */
	public String getLoginNo() {
		return loginNo;
	}
	
	/**
	 * ログインしている社員の社員NOを設定する。
	 */
	public void setLoginNo( String loginNo ) {
		this.loginNo = loginNo;
	}
	
	/**
	 * 遷移後ヘッダ表示文言を取得します。
	 */
	public String getHeaderLabelAfterTrans() {
		return headerLabelAfterTrans;
	}
	
	/**
	 * 遷移後ヘッダ表示文言を設定します。
	 */
	public void setHeaderLabelAfterTrans( String headerLabelAfterTrans ) {
		this.headerLabelAfterTrans = headerLabelAfterTrans;
	}
}
