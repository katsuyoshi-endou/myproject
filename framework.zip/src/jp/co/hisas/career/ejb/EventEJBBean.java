/*
 * All Rights Reserved. Copyright (C) 2004,2008, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;

import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.dao.LocalConnectionManager;
import jp.co.hisas.career.util.log.Log;

/**
 * 概要: 各種ビジネスロジックを呼び出すステートレスSessionBean。 使用方法: リモートインタフェースを介して、クライアントBeanから呼び出す。
 * 
 * @author kats-watanabe
 * 
 */
public class EventEJBBean implements SessionBean {
	
	private SessionContext sessionContext = null;
	
	@SuppressWarnings("unchecked")
	public AbstractEventResult callHanlder( Class<?> handlerClass, AbstractEventArg arg ) throws EJBException {
		LocalConnectionManager connMan = new LocalConnectionManager( arg.getLoginNo() );
		try {
			return ((AbstractEventHandler<AbstractEventArg, ?>)handlerClass.newInstance()).execute( arg );
		} catch (InstantiationException e) {
			Log.error( arg.getLoginNo(), e );
			this.sessionContext.setRollbackOnly();
			throw new EJBException( new CareerRuntimeException( e ) );
		} catch (IllegalAccessException e) {
			Log.error( arg.getLoginNo(), e );
			this.sessionContext.setRollbackOnly();
			throw new EJBException( new CareerRuntimeException( e ) );
		} catch (CareerSQLException ex) {
			// 既にdaoでログを出力した後なので出力しない
			this.sessionContext.setRollbackOnly();
			throw new EJBException( new CareerRuntimeException( ex ) );
		} catch (CareerException ex) {
			// ユーザ定義例外なので、ログ出力不要
			this.sessionContext.setRollbackOnly();
			throw new EJBException( ex );
		} finally {
			connMan.releaseConnection();
		}
	}
	
	/**
	 * {@inheritDoc}
	 */
	public void ejbCreate() throws EJBException, RemoteException {
	}
	
	/**
	 * {@inheritDoc}
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}
	
	/**
	 * {@inheritDoc}
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
	
	/**
	 * {@inheritDoc}
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}
	
	/**
	 * {@inheritDoc}
	 */
	public void setSessionContext( SessionContext sessionContext ) throws EJBException, RemoteException {
		this.sessionContext = sessionContext;
	}
	
	/**
	 * セッションコンテキストを取得する。
	 * 
	 * @return セッションコンテキスト
	 */
	public SessionContext getSessionContext() {
		return this.sessionContext;
	}
	
}
