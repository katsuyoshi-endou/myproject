/*
 * All Rights Reserved. Copyright (C) 2004,2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.ejb;

import java.io.Serializable;

/**
 * ビジネスロジックを呼び出した結果を返すためのクラスの基底クラス。
 * 
 * @author kats-watanabe
 */
@SuppressWarnings("serial")
public abstract class AbstractEventResult implements Serializable {
}
