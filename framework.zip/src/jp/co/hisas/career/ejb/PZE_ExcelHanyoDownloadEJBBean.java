/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * クラス名：PZE_ExcelHanyoDownloadEJBBean クラス
 * 機能説明: DBアクセスを行い、対象SQLから結果を取得する。
 * 使用方法: リモートインタフェースを介して、クライアントBeanから呼び出す。ステートレスSessionBean。
 * 
 * </PRE>
 */
public class PZE_ExcelHanyoDownloadEJBBean implements SessionBean {
	
	/** SessionContextオブジェクト */
	@SuppressWarnings("unused")
	private SessionContext context = null;


	/**
	 * 対象のSQLから結果を取得する。
	 * 	<dl>※戻り値のキーについて
	 * 		<dt>singleItem: true</dt><dd>→ "defKey"</dd>
	 * 		<dt>singleItem: false</dt><dd>→ "defKey_ColNm_1" (※ColNm: targetSQLのSELECT句のAS)</dd>
	 * 	</dl>
	 * 
	 * @param loginNo ログオン社員
	 * @param targetSQL 対象のSQL
	 * @param defKey 定義名
	 * @param singleItem 単一項目かどうか
	 * @return 取得結果
	 * @exception SQLException SQLエラーが発生した場合
	 * @exception NamingException データソースの参照取得に失敗した場合
	 */
	public HashMap<String, String> getResultMapByTargetSql(String loginNo, String targetSQL, String defKey, boolean singleItem)
			throws SQLException, NamingException {

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			Log.method(loginNo, "IN", "");
			
			// 共通クラスを用いて、コネクションの取得
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			pstmt = dbConn.prepareStatement(targetSQL);

			// 検索実行
			rs = pstmt.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			int colomnCount = rsmd.getColumnCount();
			
			ArrayList<String> colomnNameList = new ArrayList<String>();
			
			// 取得したカラム名のリストを作成
			for (int i = 0 ; i < colomnCount ; i++) {
				// カラム名を小文字に変換しリストに格納
				String colomnName = rsmd.getColumnName(i+1);
				colomnNameList.add(colomnName.toLowerCase());
			}
			
			HashMap<String, String> resultMap = new HashMap<String, String>();
			
			while (rs.next()) {
				// 行番号を取得
				int row = rs.getRow();
				
				for (String tempColomnName : colomnNameList) {
					// 対象カラムをセットする
					String tempKey = "";
					if (singleItem) {
						// キー(定義名)
						tempKey = defKey;
					} else {
						// キー(定義名_カラム名(小文字)_行番号)
						tempKey = defKey + "_" + tempColomnName + "_" + String.valueOf(row);
					}
					// 対象カラムに対する値
					String tempValue = "";
					Object temp = rs.getObject(tempColomnName);
					if (temp != null) {
						tempValue = String.valueOf(temp);
					}
					
					resultMap.put(tempKey, tempValue);
				}
			}

			Log.method(loginNo, "OUT", "");

			// 戻り値に設定
			return resultMap;

		} catch (final SQLException sqle) {
			Log.error("", sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error("", ne);
			throw ne;
		} finally {
			// 共通クラスを用いて、コネクションのクローズ
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, pstmt, rs);
		}
	}
	
	/**
	 * 何もしない。
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException {
	}

	/**
	 * 何もしない。
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException {
	}

	/**
	 * 何もしない。
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException {
	}

	/**
	 * 何もしない。
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException {
	}

	/**
	 * EJBコンテナが管理するSessionContext情報をSessionBeanに渡す。SessionBeanの作成時に呼び出される。
	 * @param context SessionContext情報
	 * @exception RemoteException
	 */
	public void setSessionContext(final SessionContext context) throws RemoteException {
		this.context = context;
	}
}