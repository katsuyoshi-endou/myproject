/*
 * All Rights Reserved. Copyright (C) 2004,2008, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

/**
 * 概要: クライアントからSessionBeanを呼び出すためのリモートインタフェース。
 * 
 * @author kats-watanabe
 */
public interface EventEJB extends EJBObject {
	
	public AbstractEventResult callHanlder( Class<?> handlerClass, AbstractEventArg arg ) throws RemoteException;
	
}
