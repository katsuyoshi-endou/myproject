/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
 * <PRE>
 * 
 * 概要: クライアントがSessionBeanを生成、検索、削除するためのホームインタフェース。
 * 
 * </PRE>
 */
public interface CommonParameterEJBHome extends EJBHome {

	/**
	 * SessionBeanを生成、検索、削除する。
	 * @return リモートインタフェース
	 * @exception CreateException SQLエラーが発生した場合
	 * @exception RemoteException リモートメソッド呼び出しの実行中に発生する例外
	 */
	CommonParameterEJB create() throws CreateException, RemoteException;
}
