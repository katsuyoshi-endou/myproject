/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.HashMap;

import javax.ejb.EJBObject;
import javax.naming.NamingException;

public interface CommonParameterEJB extends EJBObject {
	
	/**
	 * 汎用パラメータの全ての値を取得する。
	 */
	@SuppressWarnings("rawtypes")
	public HashMap find() throws NamingException, SQLException, RemoteException;
	
}
