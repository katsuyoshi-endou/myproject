/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * プロジェクト名　：
 *   人材戦略システム（リシテアCareer計画系）
 *
 * 備考　：
 *   なし
 *
 * 履歴　：
 *   日付        バージョン   名前　　　　　内容
 *   2004/04/01  01.00       小野　隆之　　新規作成
 *   2005/10/21  01.01       QUANLA        Add 2 UpdateBLOB methods from Career@Net
 */
package jp.co.hisas.career.ejb;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.ejb.EJBObject;
import javax.naming.NamingException;

/**
 * <PRE>
 * 
 * 概要: クライアントからSessionBeanを呼び出すためのリモートインタフェース。
 * 
 * </PRE>
 */
public interface PYF_BlobDBAccessEJB extends EJBObject {
	/**
	 * BLOB型をインサートする
	 * @param login_no
	 * @param table
	 * @param column
	 * @param save
	 * @param blob
	 * @param primary_key
	 * @param primary_value
	 * @return 追加レコード数
	 * @throws RemoteException
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public int InsertBLOB(String login_no, String table, String[] column, String[] save, byte[] blob, String[] primary_key, String[] primary_value) throws RemoteException, SQLException,
			NamingException, Exception;

	/**
	 * BLOB型をアップデートする
	 * @param login_no
	 * @param table
	 * @param column
	 * @param save
	 * @param blob
	 * @param primary_key
	 * @param primary_value
	 * @return 更新レコード数
	 * @throws RemoteException
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */

	// 2005/10/21_LYCE_A_QUANLA START
	/**
	 * BLOB型をアップデートする
	 * @param login_no
	 * @param table
	 * @param column
	 * @param save
	 * @param blob
	 * @param primary_key
	 * @param primary_value
	 * @return 更新レコード数
	 * @throws RemoteException
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public int UpdateBLOB(String login_no, String table, String[] column, String[] save, byte[] blob, String[] primary_key, String[] primary_value) throws RemoteException, SQLException,
			NamingException, Exception;

	/**
	 * BLOB型をアップデートする String配列strBlobに与えられたデータをすべてアップデートする
	 * @param login_no
	 * @param table
	 * @param column
	 * @param save
	 * @param byteDataBeans
	 * @param primary_key
	 * @param primary_value
	 * @return 更新レコード数
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public int UpdateBLOB(String login_no, String table, String[] column, String[] save, PYF_ByteDataBean[] byteDataBeans, String[] primary_key, String[] primary_value) throws RemoteException,
			SQLException, NamingException, Exception;

	// 2005/10/21_LYCE_A_QUANLA END

	/**
	 * BLOBをセレクトする
	 * @param login_no
	 * @param table
	 * @param blob_colum
	 * @param primary_key
	 * @param primary_value
	 * @return BOLBデータ
	 * @throws RemoteException
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public byte[] SelectBLOB(String login_no, String table, String blob_colum, String[] primary_key, String[] primary_value) throws RemoteException, SQLException, NamingException, Exception;

	/**
	 * BLOBをセレクトする(メンテナンス用)
	 * @param login_no
	 * @param table
	 * @param blob_colum
	 * @param primary_key
	 * @param primary_value
	 * @return BOLBデータ
	 * @throws RemoteException
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public byte[] SelectBLOB1(String login_no, String table, String blob_colum, String[] primary_key, String[] primary_value) throws RemoteException, SQLException, NamingException;
}
