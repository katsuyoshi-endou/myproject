package jp.co.hisas.career.util;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import jp.co.hisas.career.app.common.bean.CareerMenuBean;
import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.trans.StateTransitionEvent;

/**
 * サーブレット内データやりとりクラス for スレッドセーフ <br>
 * ※サーブレットのメンバ変数はスレッド間で共有されるため、明示的に本クラスを new
 * でインスタンス化してスレッド内のローカル変数としてデータをやりとりするために使います。
 */
public class Tray {
	
	public HttpServletRequest request;
	public HttpServletResponse response;
	public HttpSession session;
	public String forwardUrl;
	public UserInfoBean userinfo;
	public String loginNo;
	public String operatorGuid;
	public String state;
	public String party;
	public int langNo;
	public CareerMenuBean menu;
	
	public Tray(HttpServletRequest req, HttpServletResponse res) throws CareerException {
		init( req, res, true );
	}
	
	public Tray(HttpServletRequest req, HttpServletResponse res, boolean doSessionChk) throws CareerException {
		init( req, res, doSessionChk );
	}
	
	public Tray(StateTransitionEvent e) throws CareerException {
		HttpServletRequest req = e.getRequest();
		HttpServletResponse res = e.getResponse();
		init( req, res, true );
	}
	
	public Line getLine() throws CareerException {
		return new Line( request, response );
	}
	
	public void init( HttpServletRequest req, HttpServletResponse res, boolean doSessionChk ) throws CareerException {
		if (req == null || res == null) {
			throw new CareerException( "Invalid Request" );
		}
		request = req;
		response = res;
		session = req.getSession( false );
		if (doSessionChk && session == null) {
			throw new CareerBusinessException( CareerBusinessException.INVALID_SESSION );
		}
		
		// 処理分岐用の状態変数をセット
		state = AU.getReqParaAttrVal( request, "state" );
		
		// ユーザ情報
		userinfo = AU.getSessionAttr( session, UserInfoBean.SESSION_KEY );
		if (doSessionChk && userinfo == null) {
			throw new CareerBusinessException( CareerBusinessException.INVALID_SESSION );
		}
		if (userinfo != null) {
			loginNo = SU.ntb( userinfo.getLogin_no() );
			party = userinfo.getParty();
			langNo = userinfo.getLangNo();
			operatorGuid = userinfo.getOperatorGuid();
		}
	}
	
	public String getRequestValue( String parameterName ) {
		return AU.getRequestValue( this.request, parameterName );
	}
	
	public Map<String, String> convertPostRequestBodyToMap() {
		return this.getRequestBodyAsJSON();
	}
	
	/**
	 * リクエストメソッド POST or PUT のボディ部を JSON として取得する
	 * ( Content-Type: application/json )
	 */
	public Map<String, String> getRequestBodyAsJSON() {
		Map<String, String> map = new HashMap<String, String>();
		try {
			String jsonString = IOUtils.toString( this.request.getInputStream() );
			if (SU.isBlank( jsonString )) {
				@SuppressWarnings("unchecked")
				Map<String, Object> pMap = this.request.getParameterMap();
				for (Entry<String, Object> e : pMap.entrySet()) {
					String key = e.getKey();
					Object val = e.getValue();
					if (val instanceof String) {
						map.put( key, (String)e.getValue() );
					}
					else if (val instanceof String[]) {
						String[] arr = (String[])e.getValue();
						map.put( key, arr[0] );
					}
				}
			}
			else {
				Type stringStringMap = new TypeToken<Map<String, String>>(){}.getType();
				Gson gson = new Gson();
				map = gson.fromJson( jsonString, stringStringMap );
			}
		} catch (IOException e) {
		}
		return map;
	}
	
	/**
	 * リクエストメソッド POST or PUT のボディ部をフォームパラメータとして取得する
	 * ( Content-Type: application/x-www-form-urlencoded )
	 */
	public Map<String, String> getRequestBodyAsFormUrlencoded() {
		Map<String, String> map = new HashMap<String, String>();
		try {
			String body = IOUtils.toString( this.request.getInputStream() );
			if (SU.isNotBlank( body )) {
				String[] pairs = body.split( "\\&" );
				for (int i = 0; i < pairs.length; i++) {
					String[] fields = pairs[i].split( "=" );
					String name = URLDecoder.decode( fields[0], "UTF-8" );
					String value = URLDecoder.decode( fields[1], "UTF-8" );
					map.put( name, value );
				}
			}
		} catch (IOException e) {
		}
		return map;
	}
	
	public <T> T getSessionAttr( String sessionKey ) {
		return AU.getSessionAttr( session, sessionKey );
	}
	
}
