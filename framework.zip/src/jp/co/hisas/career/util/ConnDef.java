package jp.co.hisas.career.util;

public class ConnDef {

	public static final String DATASOURCE_NAME = "java:comp/env/jdbc/HCDB";

}
