/*
 * ExceptionUtility.java LYSITHEA例外の共通処理を提供する。
 */
package jp.co.hisas.career.util.common;

import java.rmi.RemoteException;

import javax.ejb.EJBException;

import jp.co.hisas.career.framework.exception.CareerException;

/**
 * ExceptionUtility.java LYSITHEA例外の共通処理を提供する。
 */
public class ExceptionUtility {

    /**
     * 例外クラス(Exception)から LYSITHEA例外クラス(CareerException)を取り出す。
     * 
     * @param e_Exception (Exception) 例外クラス
     * @return (CareerException) LYSITHEA例外クラス 存在しなかった場合、nullを返す。
     * 
     * <pre>CareerException以外の例外クラスがあった場合 → 挿入文字列に引数に指定されたEJBExceptionをセット
     * 
     * <pre>nullだった(何もラップしていなかった)場合 → nullを返す
     */
    public static CareerException getCareerException( Exception e_Exception ) {

        if ( e_Exception == null ) {

            return null;

        } else if ( e_Exception instanceof CareerException ) {
            return (CareerException)e_Exception;

        } else if ( e_Exception instanceof RemoteException ) {
            return getCareerException( (RemoteException)e_Exception );

        } else if ( e_Exception instanceof EJBException ) {
            return getCareerException( (EJBException)e_Exception );
        }
        return null;
    }
    /**
     * getCareerException
     * EJB通信例外クラス(RemoteException)から
     * LYSITHEA例外クラス(CareerException)を取り出す。
     * @param  remoteException (RemoteException) EJB通信例外クラス
     * @return (CareerException) LYSITHEA例外クラス
     *         存在しなかった場合、システムエラーのCareerExceptionを返す。
     *         ・CareerException以外の例外クラスがあった場合
     *            → 挿入文字列に引数に指定されたRemoteExceptionをセット
     *         ・nullだった(RemoteException以外、何もなかった)場合
     *            → 挿入文字列にエラーメッセージをセット
     */
    public static CareerException getCareerException(RemoteException remoteException) {

        /*
         * RemoteExceptionでなくなるまで入れ子の例外を遡って(detailを繰り返す)
         * CareerExceptionを探し出す。
         */
        RemoteException re = remoteException;
        Throwable t = null;
        t = re.detail;
        while (t != null) {

            /* 入れ子の例外クラスはRemoteExceptionか？ */
            try {
                re = (RemoteException)t;

                /* RemoteException以外を発見 */
            } catch (ClassCastException cce) {

                /* CareerExceptionを発見 */
                if (t instanceof CareerException) {
                    return (CareerException)t;

                    /* CareerException以外を発見 */
                } else if (t instanceof EJBException) {
                    return getCareerException((EJBException)t);
                } else {
                    return new CareerException("");
                }
            }

            /* 次の入れ子を取り出す */
            t = re.detail;

        }

        return new CareerException("");

    }
    /**
     * getCareerException
     * EJB例外クラス(EJBException)から
     * LYSITHEA例外クラス(CareerException)を取り出す。
     * @param  ejbException (EJBException) EJB例外クラス
     * @return (CareerException) LYSITHEA例外クラス
     *         存在しなかった場合、システムエラーのCareerExceptionを返す。
     *         ・CareerException以外の例外クラスがあった場合
     *            → 挿入文字列に引数に指定されたEJBExceptionをセット
     *         ・nullだった(何もラップしていなかった)場合
     *            → 挿入文字列にエラーメッセージをセット
     */
    public static CareerException getCareerException(EJBException ejbException) {

        /* ラップされている例外クラスを取り出す */
        Exception t = ejbException.getCausedByException();

        /* CareerExceptionだった場合 */
        if (t instanceof CareerException) {
            return (CareerException)t;

            /* RemoteExceptionだった場合 */
        } else if (t instanceof RemoteException) {
            return getCareerException((RemoteException)t);

            /* nullだった場合 */
        } else if (t == null) {
            CareerException le =
                    new CareerException("");
            return le;
        } else {
            return new CareerException("");
        }

    }
}
