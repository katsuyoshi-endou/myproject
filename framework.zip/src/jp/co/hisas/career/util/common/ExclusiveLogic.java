/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.util.common;

/**
 * 排他制御ロジック
 */
public interface ExclusiveLogic {
	/** ロックを取得する */
	public boolean getExclusiveLock(Object key);

	/** ロックを解放する */
	public void releaseExclusiveLock(Object key);

	/** キーが有効なキーかどうかを判定する */
	public boolean checkKey(Object key);
}
