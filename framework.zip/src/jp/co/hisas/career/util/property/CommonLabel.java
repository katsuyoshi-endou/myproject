package jp.co.hisas.career.util.property;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.app.common.event.DualEvArg;
import jp.co.hisas.career.app.common.event.DualEvHdlr;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.VCcpLabelDao;
import jp.co.hisas.career.util.dto.VCcpLabelDto;
import jp.co.hisas.career.util.log.Log;

/**
 * ラベル
 */
public class CommonLabel {

	private static final String DEFAULT = "Default";
	private static final String PACKAGE = "Package";

	/** Partyをキーとするマップ */
	private static HashMap<String, HashMap<String, VCcpLabelDto>> ccpLabelDataMap = new HashMap<String, HashMap<String, VCcpLabelDto>>();

	/**
	 * 呼び出し時の処理
	 */
	static {
		Connection conn = null;
		try {
			/* Check DB access */
			DualEvHdlr.exec( new DualEvArg( "CommonLabel" ) );
			/** 値を取得する */
			conn = PZZ040_SQLUtility.getConnection( "" );
			CommonLabel.find( conn );
		} catch (final Exception e) {
			Log.error( "", e );
		} finally {
			PZZ040_SQLUtility.close( conn );
		}
	}

	/**
	 * コンストラクタ
	 */
	private CommonLabel() {
	}

	/**
	 * データベースからラベルの値を取得しなおす。
	 */
	public static void find( Connection conn ) {
		
		ccpLabelDataMap = new HashMap<String, HashMap<String, VCcpLabelDto>>();
		
		VCcpLabelDao dao = new VCcpLabelDao( conn );
		List<VCcpLabelDto> result = dao.selectAll();
		
		for (VCcpLabelDto vccpLabelDto : result) {
			String partyCd   = vccpLabelDto.getParty();
			String labelId   = vccpLabelDto.getLabelId();
			HashMap<String, VCcpLabelDto> partyLabelMap = null;
			if (ccpLabelDataMap.containsKey( partyCd )) {
				partyLabelMap = ccpLabelDataMap.get( partyCd );
			} else {
				partyLabelMap = new HashMap<String, VCcpLabelDto>();
			}
			partyLabelMap.put( labelId, vccpLabelDto );
			ccpLabelDataMap.put( partyCd, partyLabelMap );
		}
	}

	public static String getLabel( final String party, final String labelId ) {
		return getLabel( party, labelId, 1 );
	}
	
	public static Map<String, String> getLabelsWithRegex( String party, int langNo, String regex ) {
		Map<String, String> result = new HashMap<String, String>();
		HashMap<String, VCcpLabelDto> packageLabelMap = ccpLabelDataMap.get( PACKAGE );
		if (packageLabelMap != null) {
			for (String labelId : packageLabelMap.keySet()) {
				if (SU.matches( labelId, regex )) {
					String val = getLabel( party, labelId, langNo );
					result.put( labelId, val );
				}
			}
		}
		HashMap<String, VCcpLabelDto> defaultLabelMap = ccpLabelDataMap.get( DEFAULT );
		if (defaultLabelMap != null) {
			for (String labelId : defaultLabelMap.keySet()) {
				if (SU.matches( labelId, regex )) {
					String val = getLabel( party, labelId, langNo );
					result.put( labelId, val );
				}
			}
		}
		HashMap<String, VCcpLabelDto> partyLabelMap = ccpLabelDataMap.get( party );
		if (partyLabelMap != null) {
			for (String labelId : partyLabelMap.keySet()) {
				if (SU.matches( labelId, regex )) {
					String val = getLabel( party, labelId, langNo );
					result.put( labelId, val );
				}
			}
		}
		return result;
	}
	
	/**
	 * 指定したPARTY、ラベルID、言語Noに該当するラベルを返す。
	 * 取得できなかった場合は会社コード:"Default"、"Package"の順で再取得する。
	 * 
	 * @param PARTY
	 * @param ラベルID
	 * @param 言語No
	 * @return ラベル
	 */
	public static String getLabel( final String party, final String labelId, final int langNo ) {
		final HashMap<String, VCcpLabelDto> partyLabelMap = CommonLabel.ccpLabelDataMap.get( party );
		// 引数.会社コードのラベルデータが存在するか
		if (partyLabelMap == null || !partyLabelMap.containsKey( labelId )) {
			if (!DEFAULT.equals( party ) && CommonLabel.ccpLabelDataMap.containsKey( DEFAULT ) && !PACKAGE.equals( party )) {
				// 取得できなかった場合は"Default"を使用
				return getLabel( DEFAULT, labelId, langNo );
			} else if (!PACKAGE.equals( party ) && CommonLabel.ccpLabelDataMap.containsKey( PACKAGE )) {
				// 更に取得できなかった場合は"Package"を使用
				return getLabel( PACKAGE, labelId, langNo );
			}
			return "";
		}
		String result = "";
		VCcpLabelDto dto = partyLabelMap.get( labelId );
		if (langNo == 1) {
			result = dto.getLabelText();
		} else if (langNo == 2) {
			result = dto.getLabelTextL2();
		} else if (langNo == 3) {
			result = dto.getLabelTextL3();
		}
		return result;
	}

	/**
	 * 指定した会社コード、ラベルIDに該当するラベルを返す。
	 * 値が全て表示対象外の場合はラベルをNULLで返す。
	 * 
	 * @param 会社コード
	 * @param ラベルID
	 * @param 表示
	 * @return ラベル
	 */
	public static String getLabel( final String companyCode, final String labelId, boolean display ) {
		if (display) {
			return getLabel( companyCode, labelId );
		}
		return null;
	}

	/**
	 * 会社コード:"Default"の指定したラベルIDに該当するラベルを返す。
	 * 取得できなかった場合は会社コード:"Package"で再取得する。
	 * 
	 * @param ラベルID
	 * @return ラベル
	 */
	public static String getLabel( final String labelId ) {
		return getLabel( "Default", labelId );
	}
	
	public static String getLabelWithHelp( String party, String labelId ) {
		String labelText = getLabel( party, labelId );
		String helpText = getLabel( party, labelId + "_HELP" );
		if (SU.isNotBlank( helpText )) {
			String tagLeft  = "<span style=\"font-weight:normal;\">[<span class=\"popSwitch\">？</span>]</span><div class=\"popInfoWrap\"><span class=\"popInfo\">";
			String tagRight = "</span></div>";
			return labelText + tagLeft + helpText + tagRight;
		} else {
			return labelText;
		}
	}
	
}