/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.util.property;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.naming.NamingException;

import jp.co.hisas.career.app.common.event.DualEvArg;
import jp.co.hisas.career.app.common.event.DualEvHdlr;
import jp.co.hisas.career.ejb.CommonParameterEJB;
import jp.co.hisas.career.ejb.CommonParameterEJBHome;
import jp.co.hisas.career.framework.EJBHomeFactory;
import jp.co.hisas.career.util.log.Log;

/**
 * 汎用パラメータ
 */
public class CommonParameter {
	
	/** パラメータ分類 機能名 */
	public static final String BUNRUI_FUNC = "FuncName";
	
	/** パラメータ分類 ベースモジュール */
	public static final String BUNRUI_BASE = "Base";
	
	/** パラメータ分類 プランモジュール */
	public static final String BUNRUI_PLAN = "Plan";
	
	/** パラメータ分類 パフォーマンスモジュール */
	public static final String BUNRUI_PERFORMANCE = "Performance";
	
	/** パラメータ分類 メニューseigyo */
	public static final String BUNRUI_MENU = "Menu";
	
	/** CCP_PARAMテーブルの列数 */
	public static final int ccpParamColumnSize = 5;
	
	/** パラメータ分類をキーとするマップ */
	@SuppressWarnings("rawtypes")
	private static HashMap categoryMap = null;
	
	/**
	 * 呼び出し時の処理
	 */
	static {
		try {
			/* Check DB access */
			DualEvHdlr.exec( new DualEvArg( "CommonParameter" ) );
			/** ファイルから値を取得する */
			CommonParameter.find();
		} catch (final Exception e) {
			Log.error( "", e );
		}
	}
	
	/**
	 * コンストラクタ
	 */
	private CommonParameter() {
	}
	
	/**
	 * データベースから汎用パラメータの値を取得しなおす。
	 * 
	 * @throws RemoteException
	 * @throws NamingException
	 * @throws CreateException
	 * @throws SQLException
	 */
	public static void find() throws RemoteException, NamingException, CreateException, SQLException {
		Log.method( "", "IN", "" );
		try {
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final CommonParameterEJBHome my_home = (CommonParameterEJBHome)fact.lookup( CommonParameterEJBHome.class );
			/** EJBObjectの取得 */
			final CommonParameterEJB usersession = my_home.create();
			
			/** 値の格納 */
			CommonParameter.categoryMap = usersession.find();
			
			/** ログの出力 */
			Log.method( "", "OUT", "" );
		} catch (final RemoteException e) {
			Log.error( "", e );
			throw e;
		} catch (final NamingException e) {
			Log.error( "", e );
			throw e;
		} catch (final CreateException e) {
			Log.error( "", e );
			throw e;
		} catch (final SQLException e) {
			Log.error( "", e );
			throw e;
		}
		
	}
	
	/**
	 * 指定した分類、IDに該当するパラメータ値を返す。
	 * 
	 * @param パラメータ分類
	 * @param パラメータID
	 * @return パラメータ値 該当するパラメータ値が存在しない場合はnullを返す
	 */
	@SuppressWarnings("rawtypes")
	public static String getValue( final String category, final String id ) {
		final HashMap categoryMap = (HashMap)CommonParameter.categoryMap.get( category );
		if (categoryMap == null) {
			return null;
		}
		final ArrayList valueList = (ArrayList)categoryMap.get( id );
		if (valueList == null || valueList.size() != CommonParameter.ccpParamColumnSize) {
			return null;
		}
		return (String)valueList.get( 2 );
	}
	
	/**
	 * 指定した分類、IDに該当するパラメータ名称を返す。
	 * 
	 * @param パラメータ分類
	 * @param パラメータID
	 * @return パラメータ名称 該当するパラメータ名称が存在しない場合はnullを返す
	 */
	@SuppressWarnings("rawtypes")
	public static String getName( final String category, final String id ) {
		final HashMap categoryMap = (HashMap)CommonParameter.categoryMap.get( category );
		if (categoryMap == null) {
			return null;
		}
		final ArrayList valueList = (ArrayList)categoryMap.get( id );
		if (valueList == null || valueList.size() != CommonParameter.ccpParamColumnSize) {
			return null;
		}
		return (String)valueList.get( 3 );
	}
	
	/**
	 * 指定した分類、IDに該当するパラメータ備考を返す。
	 * 
	 * @param パラメータ分類
	 * @param パラメータID
	 * @return パラメータ備考 該当するパラメータ備考が存在しない場合はnullを返す
	 */
	@SuppressWarnings("rawtypes")
	public static String getNotes( final String category, final String id ) {
		final HashMap categoryMap = (HashMap)CommonParameter.categoryMap.get( category );
		if (categoryMap == null) {
			return null;
		}
		final ArrayList valueList = (ArrayList)categoryMap.get( id );
		if (valueList == null || valueList.size() != CommonParameter.ccpParamColumnSize) {
			return null;
		}
		return (String)valueList.get( 4 );
	}
	
	/**
	 * 指定した分類、IDに該当するパラメータ値を返す。 XXXXXXで定義個数を指定しているXXXXXX_nをリストで取得 　
	 * 
	 * @param パラメータ分類
	 * @param パラメータID XXXXXXの部分を指定
	 * @return パラメータ値 該当するパラメータ値が存在しない場合はnullを返す
	 */
	@SuppressWarnings("rawtypes")
	public static ArrayList<String> getValues( final String category, final String id ) {
		final HashMap categoryMap = (HashMap)CommonParameter.categoryMap.get( category );
		if (categoryMap == null) {
			return null;
		}
		final ArrayList valueList = (ArrayList)categoryMap.get( id );
		if (valueList == null || valueList.size() != CommonParameter.ccpParamColumnSize) {
			return null;
		}
		int num = Integer.parseInt( (String)valueList.get( 2 ) );
		
		ArrayList<String> result = new ArrayList<String>();
		for (int i = 1; i <= num; i++) {
			result.add( CommonParameter.getValue( category, id + "_" + String.valueOf( i ) ) );
		}
		return result;
	}
	
	/**
	 * 画面IDに該当するパラメータ値（機能名）を返す。
	 * 
	 * @param パラメータID
	 * @return パラメータ値 該当するパラメータ値が存在しない場合はnullを返す
	 */
	@SuppressWarnings("rawtypes")
	public static String getFuncName( final String id ) {
		final HashMap categoryMap = (HashMap)CommonParameter.categoryMap.get( CommonParameter.BUNRUI_FUNC );
		if (categoryMap == null) {
			return null;
		}
		final ArrayList valueList = (ArrayList)categoryMap.get( id );
		if (valueList == null || valueList.size() != CommonParameter.ccpParamColumnSize) {
			return null;
		}
		return (String)valueList.get( 2 );
	}
	
}