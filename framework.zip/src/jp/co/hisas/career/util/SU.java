package jp.co.hisas.career.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.google.gson.Gson;

import jp.co.hisas.career.framework.exception.CareerSecurityException;

/**
 * Alias of StringUtils (Apache Commons)
 * http://commons.apache.org/proper/commons-lang/javadocs/api-release/index.html
 */
public class SU extends StringUtils {
	
	/**
	 * Returns a default value if the passed str is null.
	 */
	public static String nvl( String str, String defaultValue ) {
		return str != null ? str : defaultValue;
	}
	public static <T> String nvl( T obj, String defaultValue ) {
		return (obj != null) ? obj.toString() : defaultValue;
	}
	
	/**
	 * Returns a default value if the passed str is blank.
	 */
	public static String bvl( String str, String defaultValue ) {
		return isNotBlank( str ) ? str : defaultValue;
	}
	
	/**
	 * Returns a blank if the passed str is null.
	 */
	public static String ntb( String str ) {
		return nvl( str, "" );
	}
	
	/**
	 * Returns true if the passed array is null or length 0.
	 */
	public static boolean isBlank( String[] array ) {
		if (array == null || array.length == 0) {
			return true;
		}
		return false;
	}
	
	/**
	 * Judge flag from string for request value
	 * true: "true" or "yes" or "1"
	 * false: else
	 */
	public static boolean judge( String arg ) {
		if (SU.matches( arg, "true|yes|1" )) {
			return true;
		}
		return false;
	}
	
	public static boolean judge( int arg ) {
		return arg == 1;
	}
	
	/**
	 * Convert string to int if it can, else defaultValue.
	 */
	public static int toInt( String str, int defaultValue ) {
		int result = defaultValue;
		try {
			result = Integer.parseInt( str );
		} catch (Exception e) {
		}
		return result;
	}
	
	/**
	 * Convert List to Comma separated value string.
	 */
	public static String toCsv( List<String> list ) {
		String result = "";
		try {
			String[] arr = (String[])list.toArray();
			result = SU.join( arr, "," );
		} catch (Exception e) {
		}
		return result;
	}
	
	/**
	 * Convert object into JSON
	 */
	public static String toJson( Object obj ) {
		Gson gson = new Gson();
		String json = gson.toJson( obj );
		return json;
	}
	
	/**
	 * Extract target with regex.<br>
	 * Example: <code>SU.extract( "the_item_01", "item_([0-9]{2})$" ) //returns "01"</code>
	 */
	public static String extract( String target, String regex ) {
		String result = "";
		target = (target != null) ? target : "";
		Pattern pattern = Pattern.compile( regex );
		Matcher matcher = pattern.matcher( target );
		if (matcher.find()) {
			result = matcher.group( 1 );
		}
		return result;
	}
	
 	public static String replaceAll( String target, String regex, String after ) {
 		target = (target != null) ? target : "";
 		Pattern p = Pattern.compile( regex );
		Matcher m = p.matcher( target );
		return m.replaceAll( after );
	}
	
	public static String getCookieValue( HttpServletRequest request, String name ) {
		if (request == null || name == null) {
			return null;
		}
		for (Cookie c : request.getCookies()) {
			if (name.equals( c.getName() )) {
				return c.getValue();
			}
		}
		return null;
	}
	
	public static String cnvFormat00( int num ) {
		String numstr = "00" + num;
		String result = extractWithRegex( numstr, "([0-9][0-9]$)" );
		return result;
	}
	
	public static String extractWithRegex( String target, String regex ) {
		String result = "";
		target = (target != null) ? target : "";
		Pattern pattern = Pattern.compile( regex );
		Matcher matcher = pattern.matcher( target );
		if (matcher.find()) {
			result = matcher.group(1);
		}
		return result;
	}
	
	/**
	 * Null Safe version of String.matches()
	 */
	public static boolean matches( String str, String regex ) {
		if (str == null || regex == null) { return false; }
		return str.matches( regex );
	}
	
	public static boolean isOnlyCode( String str, boolean isBlankOk ) {
		if (SU.isBlank( str ) && isBlankOk) {
			return true;
		}
		if (SU.matches( str, "^[a-zA-Z0-9_-]*$" )) {
			return true;
		}
		return false;
	}
	
	/**
	 * Allows Only Code for Security ( Alphabet, Underscore, Hyphen )
	 */
	public static void allowsOnlyCode( String str ) {
		if (SU.matches( str, "^[a-zA-Z0-9_-]*$" )) {
			return;
		}
		throw new CareerSecurityException( "allowsOnlyCode: " + str );
	}
	
	public static void allowsOnlyCode( String[] array ) {
		if (array == null || array.length == 0) { return; }
		for (String str : array) {
			allowsOnlyCode( str );
		}
	}
	
	public static void allowsOnlyCode( List<String> list ) {
		if (list == null || list.size() == 0) { return; }
		for (String str : list) {
			allowsOnlyCode( str );
		}
	}
	
	public static List<String> toList( String csv ) {
		if (csv == null) { return new ArrayList<String>(); }
		String[] arr = csv.split( "," );
		List <String> list = new ArrayList<String>();
		for (String str : arr) {
			list.add( str );
		}
		return list;
	}
	
	public static List<String> arrayToList( String[] array ) {
		if (array == null) {
			return new ArrayList<String>();
		}
		return Arrays.asList( array );
	}
	
	/**
	 * SQL の IN 句をリストから生成する。
	 * THE_ITEM in ( + result + ) というように直接埋め込んで使う。
	 */
	public static String convListToSqlInVal( List<String> inList ) {
		if (inList == null || inList.size() == 0) {
			return "''";
		}
		StringBuilder sql = new StringBuilder();
		for (int i = 0; i < inList.size(); i++) {
			String val = inList.get( i );
			//TODO: SQL Injection
			SU.replaceAll( val, "'", "''" );
			if (i == 0) {
				sql.append( "'" + val + "'" );
			}
			else {
				sql.append( ",'" + val + "'" );
			}
		}
		return sql.toString();
	}
	
	public static String addPrefixOnDaoAllCols( String prefix, String daoAllCols ) {
		return daoAllCols.replaceAll( "(\\w+) as", prefix + ".$1 as" );
	}
	
	public static String addPrefixOnDaoAllColsNonAS( String prefix, String daoAllCols ) {
		return daoAllCols.replaceAll( " (\\w+) as \\w+", prefix + ".$1" );
	}
	
}
