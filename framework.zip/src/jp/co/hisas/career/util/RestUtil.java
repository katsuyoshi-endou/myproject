package jp.co.hisas.career.util;

import java.util.List;
import java.util.Map;

import jp.co.hisas.career.framework.event.DynamicSqlSelectEvArg;
import jp.co.hisas.career.framework.event.DynamicSqlSelectEvHdlr;
import jp.co.hisas.career.framework.event.DynamicSqlSelectEvRslt;
import jp.co.hisas.career.framework.exception.CareerException;

public class RestUtil {
	
	public static List<Map<String, String>> dynamicSelect( String loginNo ) throws CareerException {
		
		/* Set Args */
		DynamicSqlSelectEvArg arg = new DynamicSqlSelectEvArg( loginNo );
		arg.sharp = "DYNAMIC_SELECT";
		arg.sql = "select * from menu order by 1,2";
		
		/* Execute Event */
		DynamicSqlSelectEvRslt rslt = DynamicSqlSelectEvHdlr.exec( arg );
		
		/* Return */
		return rslt.dataList;
	}
	
}
