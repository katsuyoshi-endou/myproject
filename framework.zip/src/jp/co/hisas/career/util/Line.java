package jp.co.hisas.career.util;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import jp.co.hisas.career.app.common.bean.UserBean;
import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerSecurityException;
import jp.co.hisas.career.util.log.Log;

/**
 * HTTPリクエスト・レスポンス・セッションやりとりクラス for スレッドセーフ <br>
 * ※サーブレットのメンバ変数はスレッド間で共有されるため、明示的に本クラスを new
 * でインスタンス化してスレッド内のローカル変数としてデータをやりとりするために使います。
 */
public class Line {
	
	public HttpServletRequest request;
	public HttpServletResponse response;
	public HttpSession session;
	public String tracer;
	
	public Line(HttpServletRequest req, HttpServletResponse res) throws CareerException {
		init( req, res );
	}
	
	public void init( HttpServletRequest req, HttpServletResponse res ) throws CareerException {
		if (req == null || res == null) {
			throw new CareerException( "Invalid Request" );
		}
		request = req;
		response = res;
		session = req.getSession( false );
		tracer = req.getRequestedSessionId();
	}
	
	public Tray getTray() throws CareerException {
		return new Tray( request, response, false );
	}
	
	public UserBean getUser() {
		UserBean user = getSessionAttr( UserBean.SESSION_KEY );
		return user;
	}
	
	public void resetSession() {
		HttpSession beforeSession = request.getSession( false );
		if (beforeSession != null) {
			if (Log.isSecurityDebugOn()) {
				Log.security( null, "既存のセッション「" + beforeSession.getId() + "」を破棄しました。" );
			}
			beforeSession.invalidate();
		}
		/*
		 * # getSession( arg ) ##########
		 * true : Generate if not exists
		 * false: Get if exists else null
		 */
		session = request.getSession( true );
		tracer = session.getId();
		if (Log.isSecurityDebugOn()) {
			Log.security( null, "セッション「" + session.getId() + "」を新規作成しました。" );
		}
	}
	
	public void checkToken() {
		CSRFTokenUtil.logRequest( request, "[Line#checkToken]" );
		
		String sessionTokenNo = AU.getSessionAttr( session, "tokenNo" );
		String tokenNo = AU.getReqParaAttrVal( request, "tokenNo" );
		if (!SU.equals( sessionTokenNo, tokenNo )) {
			tokenNo = SU.getCookieValue( request, "token" );
		}
		
		String reqUrl = request.getRequestURL().toString();
		
		if (sessionTokenNo == null) {
			Log.securityError( tracer, "[" + reqUrl + "]" + "sessionTokenNo-トークン番号がNullです。" );
			throw new CareerSecurityException( "Token Error" );
		}
		else if (tokenNo == null) {
			Log.securityError( tracer, "[" + reqUrl + "]" + "tokenNo-トークン番号がNullです。" );
			throw new CareerSecurityException( "Token Error" );
		}
		else {
			if (sessionTokenNo.equals( tokenNo )) {
				if (Log.isSecurityDebugOn()) {
					Log.security( tracer, "[" + reqUrl + "]" + "トークン番号一致" );
					Log.security( tracer, "[" + reqUrl + "][tokenNo]" + tokenNo );
					Log.security( tracer, "[" + reqUrl + "][sessionTokenNo]" + sessionTokenNo );
				}
			}
			else {
				Log.securityError( tracer, "[" + reqUrl + "]" + "トークン番号不一致" );
				Log.securityError( tracer, "[" + reqUrl + "][tokenNo]" + tokenNo );
				Log.securityError( tracer, "[" + reqUrl + "][sessionTokenNo]" + sessionTokenNo );
				throw new CareerSecurityException( "Token Error" );
			}
		}
	}
	
	public Map<String, String> convertPostRequestBodyToMap() {
		return this.getRequestBodyAsJSON();
	}
	
	public static String getCookie( HttpServletRequest request, String name ) {
		String result = null;
		
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (name.equals( cookie.getName() )) {
					result = cookie.getValue();
					break;
				}
			}
		}
		
		return result;
	}
	
	/**
	 * リクエストメソッド POST or PUT のボディ部を JSON として取得する
	 * ( Content-Type: application/json )
	 */
	public Map<String, String> getRequestBodyAsJSON() {
		Map<String, String> map = new HashMap<String, String>();
		try {
			String jsonString = IOUtils.toString( this.request.getInputStream() );
			if (SU.isBlank( jsonString )) {
				@SuppressWarnings("unchecked")
				Map<String, Object> pMap = this.request.getParameterMap();
				for (Entry<String, Object> e : pMap.entrySet()) {
					String key = e.getKey();
					Object val = e.getValue();
					if (val instanceof String) {
						map.put( key, (String)e.getValue() );
					}
					else if (val instanceof String[]) {
						String[] arr = (String[])e.getValue();
						map.put( key, arr[0] );
					}
				}
			}
			else {
				Type stringStringMap = new TypeToken<Map<String, String>>(){}.getType();
				Gson gson = new Gson();
				map = gson.fromJson( jsonString, stringStringMap );
			}
		} catch (IOException e) {
		}
		return map;
	}
	
	/**
	 * リクエストメソッド POST or PUT のボディ部をフォームパラメータとして取得する
	 * ( Content-Type: application/x-www-form-urlencoded )
	 */
	public Map<String, String> getRequestBodyAsFormUrlencoded() {
		Map<String, String> map = new HashMap<String, String>();
		try {
			String body = IOUtils.toString( this.request.getInputStream() );
			if (SU.isNotBlank( body )) {
				String[] pairs = body.split( "\\&" );
				for (int i = 0; i < pairs.length; i++) {
					String[] fields = pairs[i].split( "=" );
					String name = URLDecoder.decode( fields[0], "UTF-8" );
					String value = URLDecoder.decode( fields[1], "UTF-8" );
					map.put( name, value );
				}
			}
		} catch (IOException e) {
		}
		return map;
	}
	
	public <T> T getSessionAttr( String sessionKey ) {
		return AU.getSessionAttr( session, sessionKey );
	}
	
}
