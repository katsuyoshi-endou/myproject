package jp.co.hisas.career.util;

public class JspUtil {
	
	public static String toPlainText( String str ) {
		return str.replaceAll( "</?[A-Za-z].*?>", "" );
	}
}
