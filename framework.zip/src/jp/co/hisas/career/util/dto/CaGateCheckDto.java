/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class CaGateCheckDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer pid;
    private Integer needsResetFlg;
    private Integer lockedFlg;

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public Integer getNeedsResetFlg() {
        return needsResetFlg;
    }

    public void setNeedsResetFlg(Integer needsResetFlg) {
        this.needsResetFlg = needsResetFlg;
    }

    public Integer getLockedFlg() {
        return lockedFlg;
    }

    public void setLockedFlg(Integer lockedFlg) {
        this.lockedFlg = lockedFlg;
    }

}

