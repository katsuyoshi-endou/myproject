/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class CjsLogSousaDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String jikkouHiduke;
    private String jikkouJikoku;
    private String jikkouKinouId;
    private String jikkouSimeiNo;
    private String taisyouSimeiNo;
    private String jouken;

    public String getJikkouHiduke() {
        return jikkouHiduke;
    }

    public void setJikkouHiduke(String jikkouHiduke) {
        this.jikkouHiduke = jikkouHiduke;
    }

    public String getJikkouJikoku() {
        return jikkouJikoku;
    }

    public void setJikkouJikoku(String jikkouJikoku) {
        this.jikkouJikoku = jikkouJikoku;
    }

    public String getJikkouKinouId() {
        return jikkouKinouId;
    }

    public void setJikkouKinouId(String jikkouKinouId) {
        this.jikkouKinouId = jikkouKinouId;
    }

    public String getJikkouSimeiNo() {
        return jikkouSimeiNo;
    }

    public void setJikkouSimeiNo(String jikkouSimeiNo) {
        this.jikkouSimeiNo = jikkouSimeiNo;
    }

    public String getTaisyouSimeiNo() {
        return taisyouSimeiNo;
    }

    public void setTaisyouSimeiNo(String taisyouSimeiNo) {
        this.taisyouSimeiNo = taisyouSimeiNo;
    }

    public String getJouken() {
        return jouken;
    }

    public void setJouken(String jouken) {
        this.jouken = jouken;
    }

}

