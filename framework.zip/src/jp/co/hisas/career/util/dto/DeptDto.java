/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class DeptDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String cmpaCd;
    private String deptCd;
    private String deptNm;
    private String parentDeptCd;
    private String fullDeptCd;
    private String fullDeptNm;
    private Integer hierarchy;
    private String lpadSort;
    private String chiefStfNo;

    public String getCmpaCd() {
        return cmpaCd;
    }

    public void setCmpaCd(String cmpaCd) {
        this.cmpaCd = cmpaCd;
    }

    public String getDeptCd() {
        return deptCd;
    }

    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    public String getDeptNm() {
        return deptNm;
    }

    public void setDeptNm(String deptNm) {
        this.deptNm = deptNm;
    }

    public String getParentDeptCd() {
        return parentDeptCd;
    }

    public void setParentDeptCd(String parentDeptCd) {
        this.parentDeptCd = parentDeptCd;
    }

    public String getFullDeptCd() {
        return fullDeptCd;
    }

    public void setFullDeptCd(String fullDeptCd) {
        this.fullDeptCd = fullDeptCd;
    }

    public String getFullDeptNm() {
        return fullDeptNm;
    }

    public void setFullDeptNm(String fullDeptNm) {
        this.fullDeptNm = fullDeptNm;
    }

    public Integer getHierarchy() {
        return hierarchy;
    }

    public void setHierarchy(Integer hierarchy) {
        this.hierarchy = hierarchy;
    }

    public String getLpadSort() {
        return lpadSort;
    }

    public void setLpadSort(String lpadSort) {
        this.lpadSort = lpadSort;
    }

    public String getChiefStfNo() {
        return chiefStfNo;
    }

    public void setChiefStfNo(String chiefStfNo) {
        this.chiefStfNo = chiefStfNo;
    }

}

