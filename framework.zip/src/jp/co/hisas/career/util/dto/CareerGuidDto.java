/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class CareerGuidDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String guid;
    private String gunm;
    private String availFlg;
    private String operatorFlg;

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getGunm() {
        return gunm;
    }

    public void setGunm(String gunm) {
        this.gunm = gunm;
    }

    public String getAvailFlg() {
        return availFlg;
    }

    public void setAvailFlg(String availFlg) {
        this.availFlg = availFlg;
    }

    public String getOperatorFlg() {
        return operatorFlg;
    }

    public void setOperatorFlg(String operatorFlg) {
        this.operatorFlg = operatorFlg;
    }

}

