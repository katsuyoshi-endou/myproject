/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class CaPidDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer pid;
    private String displayName;
    private String lang;
    private String cmpaCd;
    private String stfNo;

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getCmpaCd() {
        return cmpaCd;
    }

    public void setCmpaCd(String cmpaCd) {
        this.cmpaCd = cmpaCd;
    }

    public String getStfNo() {
        return stfNo;
    }

    public void setStfNo(String stfNo) {
        this.stfNo = stfNo;
    }

}

