/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * V_人所属本務兼務 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class VPersonBelongUnionExDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * GUID
     */
    private String guid;
    /**
     * 会社コード
     */
    private String cmpaCd;
    /**
     * 従業員番号
     */
    private String stfNo;
    /**
     * 氏名
     */
    private String personName;
    /**
     * 本務フラグ
     */
    private String honmuFlg;
    /**
     * 部署ソート
     */
    private String belSort;
    /**
     * 部署コード
     */
    private String deptCd;
    /**
     * 部署名称
     */
    private String deptNm;
    /**
     * クラスＡコード
     */
    private String clsACd;
    /**
     * クラスＡ名称
     */
    private String clsANm;
    /**
     * クラスＢコード
     */
    private String clsBCd;
    /**
     * クラスＢ名称
     */
    private String clsBNm;
    /**
     * クラスＣコード
     */
    private String clsCCd;
    /**
     * クラスＣ名称
     */
    private String clsCNm;
    /**
     * クラスＤコード
     */
    private String clsDCd;
    /**
     * クラスＤ名称
     */
    private String clsDNm;
    /**
     * クラスＥコード
     */
    private String clsECd;
    /**
     * クラスＥ名称
     */
    private String clsENm;
    /**
     * クラスＦコード
     */
    private String clsFCd;
    /**
     * クラスＦ名称
     */
    private String clsFNm;
    /**
     * クラスＧコード
     */
    private String clsGCd;
    /**
     * クラスＧ名称
     */
    private String clsGNm;
    /**
     * クラスＨコード
     */
    private String clsHCd;
    /**
     * クラスＨ名称
     */
    private String clsHNm;
    /**
     * クラスＩコード
     */
    private String clsICd;
    /**
     * クラスＩ名称
     */
    private String clsINm;
    /**
     * クラスＪコード
     */
    private String clsJCd;
    /**
     * クラスＪ名称
     */
    private String clsJNm;
    /**
     * クラスＫコード
     */
    private String clsKCd;
    /**
     * クラスＫ名称
     */
    private String clsKNm;
    /**
     * クラスＬコード
     */
    private String clsLCd;
    /**
     * クラスＬ名称
     */
    private String clsLNm;
    /**
     * クラスＭコード
     */
    private String clsMCd;
    /**
     * クラスＭ名称
     */
    private String clsMNm;
    /**
     * クラスＮコード
     */
    private String clsNCd;
    /**
     * クラスＮ名称
     */
    private String clsNNm;
    /**
     * テキストＡ
     */
    private String txtA;
    /**
     * テキストＢ
     */
    private String txtB;
    /**
     * テキストＣ
     */
    private String txtC;
    /**
     * テキストＤ
     */
    private String txtD;
    /**
     * テキストＥ
     */
    private String txtE;
    /**
     * テキストＦ
     */
    private String txtF;
    /**
     * テキストＧ
     */
    private String txtG;
    /**
     * テキストＨ
     */
    private String txtH;
    /**
     * テキストＩ
     */
    private String txtI;
    /**
     * テキストＪ
     */
    private String txtJ;
    /**
     * テキストＫ
     */
    private String txtK;
    /**
     * テキストＬ
     */
    private String txtL;
    /**
     * テキストＭ
     */
    private String txtM;
    /**
     * テキストＮ
     */
    private String txtN;

    /**
     * GUIDを取得する。
     * @return GUID
     */
    public String getGuid() {
        return guid;
    }

    /**
     * GUIDを設定する。
     * @param guid GUID
     */
    public void setGuid(String guid) {
        this.guid = guid;
    }

    /**
     * 会社コードを取得する。
     * @return 会社コード
     */
    public String getCmpaCd() {
        return cmpaCd;
    }

    /**
     * 会社コードを設定する。
     * @param cmpaCd 会社コード
     */
    public void setCmpaCd(String cmpaCd) {
        this.cmpaCd = cmpaCd;
    }

    /**
     * 従業員番号を取得する。
     * @return 従業員番号
     */
    public String getStfNo() {
        return stfNo;
    }

    /**
     * 従業員番号を設定する。
     * @param stfNo 従業員番号
     */
    public void setStfNo(String stfNo) {
        this.stfNo = stfNo;
    }

    /**
     * 氏名を取得する。
     * @return 氏名
     */
    public String getPersonName() {
        return personName;
    }

    /**
     * 氏名を設定する。
     * @param personName 氏名
     */
    public void setPersonName(String personName) {
        this.personName = personName;
    }

    /**
     * 本務フラグを取得する。
     * @return 本務フラグ
     */
    public String getHonmuFlg() {
        return honmuFlg;
    }

    /**
     * 本務フラグを設定する。
     * @param honmuFlg 本務フラグ
     */
    public void setHonmuFlg(String honmuFlg) {
        this.honmuFlg = honmuFlg;
    }

    /**
     * 部署ソートを取得する。
     * @return 部署ソート
     */
    public String getBelSort() {
        return belSort;
    }

    /**
     * 部署ソートを設定する。
     * @param belSort 部署ソート
     */
    public void setBelSort(String belSort) {
        this.belSort = belSort;
    }

    /**
     * 部署コードを取得する。
     * @return 部署コード
     */
    public String getDeptCd() {
        return deptCd;
    }

    /**
     * 部署コードを設定する。
     * @param deptCd 部署コード
     */
    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    /**
     * 部署名称を取得する。
     * @return 部署名称
     */
    public String getDeptNm() {
        return deptNm;
    }

    /**
     * 部署名称を設定する。
     * @param deptNm 部署名称
     */
    public void setDeptNm(String deptNm) {
        this.deptNm = deptNm;
    }

    /**
     * クラスＡコードを取得する。
     * @return クラスＡコード
     */
    public String getClsACd() {
        return clsACd;
    }

    /**
     * クラスＡコードを設定する。
     * @param clsACd クラスＡコード
     */
    public void setClsACd(String clsACd) {
        this.clsACd = clsACd;
    }

    /**
     * クラスＡ名称を取得する。
     * @return クラスＡ名称
     */
    public String getClsANm() {
        return clsANm;
    }

    /**
     * クラスＡ名称を設定する。
     * @param clsANm クラスＡ名称
     */
    public void setClsANm(String clsANm) {
        this.clsANm = clsANm;
    }

    /**
     * クラスＢコードを取得する。
     * @return クラスＢコード
     */
    public String getClsBCd() {
        return clsBCd;
    }

    /**
     * クラスＢコードを設定する。
     * @param clsBCd クラスＢコード
     */
    public void setClsBCd(String clsBCd) {
        this.clsBCd = clsBCd;
    }

    /**
     * クラスＢ名称を取得する。
     * @return クラスＢ名称
     */
    public String getClsBNm() {
        return clsBNm;
    }

    /**
     * クラスＢ名称を設定する。
     * @param clsBNm クラスＢ名称
     */
    public void setClsBNm(String clsBNm) {
        this.clsBNm = clsBNm;
    }

    /**
     * クラスＣコードを取得する。
     * @return クラスＣコード
     */
    public String getClsCCd() {
        return clsCCd;
    }

    /**
     * クラスＣコードを設定する。
     * @param clsCCd クラスＣコード
     */
    public void setClsCCd(String clsCCd) {
        this.clsCCd = clsCCd;
    }

    /**
     * クラスＣ名称を取得する。
     * @return クラスＣ名称
     */
    public String getClsCNm() {
        return clsCNm;
    }

    /**
     * クラスＣ名称を設定する。
     * @param clsCNm クラスＣ名称
     */
    public void setClsCNm(String clsCNm) {
        this.clsCNm = clsCNm;
    }

    /**
     * クラスＤコードを取得する。
     * @return クラスＤコード
     */
    public String getClsDCd() {
        return clsDCd;
    }

    /**
     * クラスＤコードを設定する。
     * @param clsDCd クラスＤコード
     */
    public void setClsDCd(String clsDCd) {
        this.clsDCd = clsDCd;
    }

    /**
     * クラスＤ名称を取得する。
     * @return クラスＤ名称
     */
    public String getClsDNm() {
        return clsDNm;
    }

    /**
     * クラスＤ名称を設定する。
     * @param clsDNm クラスＤ名称
     */
    public void setClsDNm(String clsDNm) {
        this.clsDNm = clsDNm;
    }

    /**
     * クラスＥコードを取得する。
     * @return クラスＥコード
     */
    public String getClsECd() {
        return clsECd;
    }

    /**
     * クラスＥコードを設定する。
     * @param clsECd クラスＥコード
     */
    public void setClsECd(String clsECd) {
        this.clsECd = clsECd;
    }

    /**
     * クラスＥ名称を取得する。
     * @return クラスＥ名称
     */
    public String getClsENm() {
        return clsENm;
    }

    /**
     * クラスＥ名称を設定する。
     * @param clsENm クラスＥ名称
     */
    public void setClsENm(String clsENm) {
        this.clsENm = clsENm;
    }

    /**
     * クラスＦコードを取得する。
     * @return クラスＦコード
     */
    public String getClsFCd() {
        return clsFCd;
    }

    /**
     * クラスＦコードを設定する。
     * @param clsFCd クラスＦコード
     */
    public void setClsFCd(String clsFCd) {
        this.clsFCd = clsFCd;
    }

    /**
     * クラスＦ名称を取得する。
     * @return クラスＦ名称
     */
    public String getClsFNm() {
        return clsFNm;
    }

    /**
     * クラスＦ名称を設定する。
     * @param clsFNm クラスＦ名称
     */
    public void setClsFNm(String clsFNm) {
        this.clsFNm = clsFNm;
    }

    /**
     * クラスＧコードを取得する。
     * @return クラスＧコード
     */
    public String getClsGCd() {
        return clsGCd;
    }

    /**
     * クラスＧコードを設定する。
     * @param clsGCd クラスＧコード
     */
    public void setClsGCd(String clsGCd) {
        this.clsGCd = clsGCd;
    }

    /**
     * クラスＧ名称を取得する。
     * @return クラスＧ名称
     */
    public String getClsGNm() {
        return clsGNm;
    }

    /**
     * クラスＧ名称を設定する。
     * @param clsGNm クラスＧ名称
     */
    public void setClsGNm(String clsGNm) {
        this.clsGNm = clsGNm;
    }

    /**
     * クラスＨコードを取得する。
     * @return クラスＨコード
     */
    public String getClsHCd() {
        return clsHCd;
    }

    /**
     * クラスＨコードを設定する。
     * @param clsHCd クラスＨコード
     */
    public void setClsHCd(String clsHCd) {
        this.clsHCd = clsHCd;
    }

    /**
     * クラスＨ名称を取得する。
     * @return クラスＨ名称
     */
    public String getClsHNm() {
        return clsHNm;
    }

    /**
     * クラスＨ名称を設定する。
     * @param clsHNm クラスＨ名称
     */
    public void setClsHNm(String clsHNm) {
        this.clsHNm = clsHNm;
    }

    /**
     * クラスＩコードを取得する。
     * @return クラスＩコード
     */
    public String getClsICd() {
        return clsICd;
    }

    /**
     * クラスＩコードを設定する。
     * @param clsICd クラスＩコード
     */
    public void setClsICd(String clsICd) {
        this.clsICd = clsICd;
    }

    /**
     * クラスＩ名称を取得する。
     * @return クラスＩ名称
     */
    public String getClsINm() {
        return clsINm;
    }

    /**
     * クラスＩ名称を設定する。
     * @param clsINm クラスＩ名称
     */
    public void setClsINm(String clsINm) {
        this.clsINm = clsINm;
    }

    /**
     * クラスＪコードを取得する。
     * @return クラスＪコード
     */
    public String getClsJCd() {
        return clsJCd;
    }

    /**
     * クラスＪコードを設定する。
     * @param clsJCd クラスＪコード
     */
    public void setClsJCd(String clsJCd) {
        this.clsJCd = clsJCd;
    }

    /**
     * クラスＪ名称を取得する。
     * @return クラスＪ名称
     */
    public String getClsJNm() {
        return clsJNm;
    }

    /**
     * クラスＪ名称を設定する。
     * @param clsJNm クラスＪ名称
     */
    public void setClsJNm(String clsJNm) {
        this.clsJNm = clsJNm;
    }

    /**
     * クラスＫコードを取得する。
     * @return クラスＫコード
     */
    public String getClsKCd() {
        return clsKCd;
    }

    /**
     * クラスＫコードを設定する。
     * @param clsKCd クラスＫコード
     */
    public void setClsKCd(String clsKCd) {
        this.clsKCd = clsKCd;
    }

    /**
     * クラスＫ名称を取得する。
     * @return クラスＫ名称
     */
    public String getClsKNm() {
        return clsKNm;
    }

    /**
     * クラスＫ名称を設定する。
     * @param clsKNm クラスＫ名称
     */
    public void setClsKNm(String clsKNm) {
        this.clsKNm = clsKNm;
    }

    /**
     * クラスＬコードを取得する。
     * @return クラスＬコード
     */
    public String getClsLCd() {
        return clsLCd;
    }

    /**
     * クラスＬコードを設定する。
     * @param clsLCd クラスＬコード
     */
    public void setClsLCd(String clsLCd) {
        this.clsLCd = clsLCd;
    }

    /**
     * クラスＬ名称を取得する。
     * @return クラスＬ名称
     */
    public String getClsLNm() {
        return clsLNm;
    }

    /**
     * クラスＬ名称を設定する。
     * @param clsLNm クラスＬ名称
     */
    public void setClsLNm(String clsLNm) {
        this.clsLNm = clsLNm;
    }

    /**
     * クラスＭコードを取得する。
     * @return クラスＭコード
     */
    public String getClsMCd() {
        return clsMCd;
    }

    /**
     * クラスＭコードを設定する。
     * @param clsMCd クラスＭコード
     */
    public void setClsMCd(String clsMCd) {
        this.clsMCd = clsMCd;
    }

    /**
     * クラスＭ名称を取得する。
     * @return クラスＭ名称
     */
    public String getClsMNm() {
        return clsMNm;
    }

    /**
     * クラスＭ名称を設定する。
     * @param clsMNm クラスＭ名称
     */
    public void setClsMNm(String clsMNm) {
        this.clsMNm = clsMNm;
    }

    /**
     * クラスＮコードを取得する。
     * @return クラスＮコード
     */
    public String getClsNCd() {
        return clsNCd;
    }

    /**
     * クラスＮコードを設定する。
     * @param clsNCd クラスＮコード
     */
    public void setClsNCd(String clsNCd) {
        this.clsNCd = clsNCd;
    }

    /**
     * クラスＮ名称を取得する。
     * @return クラスＮ名称
     */
    public String getClsNNm() {
        return clsNNm;
    }

    /**
     * クラスＮ名称を設定する。
     * @param clsNNm クラスＮ名称
     */
    public void setClsNNm(String clsNNm) {
        this.clsNNm = clsNNm;
    }

    /**
     * テキストＡを取得する。
     * @return テキストＡ
     */
    public String getTxtA() {
        return txtA;
    }

    /**
     * テキストＡを設定する。
     * @param txtA テキストＡ
     */
    public void setTxtA(String txtA) {
        this.txtA = txtA;
    }

    /**
     * テキストＢを取得する。
     * @return テキストＢ
     */
    public String getTxtB() {
        return txtB;
    }

    /**
     * テキストＢを設定する。
     * @param txtB テキストＢ
     */
    public void setTxtB(String txtB) {
        this.txtB = txtB;
    }

    /**
     * テキストＣを取得する。
     * @return テキストＣ
     */
    public String getTxtC() {
        return txtC;
    }

    /**
     * テキストＣを設定する。
     * @param txtC テキストＣ
     */
    public void setTxtC(String txtC) {
        this.txtC = txtC;
    }

    /**
     * テキストＤを取得する。
     * @return テキストＤ
     */
    public String getTxtD() {
        return txtD;
    }

    /**
     * テキストＤを設定する。
     * @param txtD テキストＤ
     */
    public void setTxtD(String txtD) {
        this.txtD = txtD;
    }

    /**
     * テキストＥを取得する。
     * @return テキストＥ
     */
    public String getTxtE() {
        return txtE;
    }

    /**
     * テキストＥを設定する。
     * @param txtE テキストＥ
     */
    public void setTxtE(String txtE) {
        this.txtE = txtE;
    }

    /**
     * テキストＦを取得する。
     * @return テキストＦ
     */
    public String getTxtF() {
        return txtF;
    }

    /**
     * テキストＦを設定する。
     * @param txtF テキストＦ
     */
    public void setTxtF(String txtF) {
        this.txtF = txtF;
    }

    /**
     * テキストＧを取得する。
     * @return テキストＧ
     */
    public String getTxtG() {
        return txtG;
    }

    /**
     * テキストＧを設定する。
     * @param txtG テキストＧ
     */
    public void setTxtG(String txtG) {
        this.txtG = txtG;
    }

    /**
     * テキストＨを取得する。
     * @return テキストＨ
     */
    public String getTxtH() {
        return txtH;
    }

    /**
     * テキストＨを設定する。
     * @param txtH テキストＨ
     */
    public void setTxtH(String txtH) {
        this.txtH = txtH;
    }

    /**
     * テキストＩを取得する。
     * @return テキストＩ
     */
    public String getTxtI() {
        return txtI;
    }

    /**
     * テキストＩを設定する。
     * @param txtI テキストＩ
     */
    public void setTxtI(String txtI) {
        this.txtI = txtI;
    }

    /**
     * テキストＪを取得する。
     * @return テキストＪ
     */
    public String getTxtJ() {
        return txtJ;
    }

    /**
     * テキストＪを設定する。
     * @param txtJ テキストＪ
     */
    public void setTxtJ(String txtJ) {
        this.txtJ = txtJ;
    }

    /**
     * テキストＫを取得する。
     * @return テキストＫ
     */
    public String getTxtK() {
        return txtK;
    }

    /**
     * テキストＫを設定する。
     * @param txtK テキストＫ
     */
    public void setTxtK(String txtK) {
        this.txtK = txtK;
    }

    /**
     * テキストＬを取得する。
     * @return テキストＬ
     */
    public String getTxtL() {
        return txtL;
    }

    /**
     * テキストＬを設定する。
     * @param txtL テキストＬ
     */
    public void setTxtL(String txtL) {
        this.txtL = txtL;
    }

    /**
     * テキストＭを取得する。
     * @return テキストＭ
     */
    public String getTxtM() {
        return txtM;
    }

    /**
     * テキストＭを設定する。
     * @param txtM テキストＭ
     */
    public void setTxtM(String txtM) {
        this.txtM = txtM;
    }

    /**
     * テキストＮを取得する。
     * @return テキストＮ
     */
    public String getTxtN() {
        return txtN;
    }

    /**
     * テキストＮを設定する。
     * @param txtN テキストＮ
     */
    public void setTxtN(String txtN) {
        this.txtN = txtN;
    }

}

