/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto.useful;

import java.io.Serializable;

/**
 * VALUE_TEXT_SORT Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class ValueTextSortDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * VALUE
     */
    private String value;
    /**
     * TEXT
     */
    private String text;
    /**
     * SORT
     */
    private String sort;

    /**
     * VALUEを取得する。
     * @return VALUE
     */
    public String getValue() {
        return value;
    }

    /**
     * VALUEを設定する。
     * @param value VALUE
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * TEXTを取得する。
     * @return TEXT
     */
    public String getText() {
        return text;
    }

    /**
     * TEXTを設定する。
     * @param text TEXT
     */
    public void setText(String text) {
        this.text = text;
    }

    /**
     * SORTを取得する。
     * @return SORT
     */
    public String getSort() {
        return sort;
    }

    /**
     * SORTを設定する。
     * @param sort SORT
     */
    public void setSort(String sort) {
        this.sort = sort;
    }

}

