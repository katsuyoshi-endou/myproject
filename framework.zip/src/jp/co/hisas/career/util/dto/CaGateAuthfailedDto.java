/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class CaGateAuthfailedDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer pid;
    private String timestamp;
    private Integer countingFlg;

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public Integer getCountingFlg() {
        return countingFlg;
    }

    public void setCountingFlg(Integer countingFlg) {
        this.countingFlg = countingFlg;
    }

}

