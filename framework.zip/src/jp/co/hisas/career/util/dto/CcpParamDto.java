/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class CcpParamDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String paramBunruiNm;
    private String paramId;
    private String paramValue;
    private String paramNm;
    private String paramBiko;

    public String getParamBunruiNm() {
        return paramBunruiNm;
    }

    public void setParamBunruiNm(String paramBunruiNm) {
        this.paramBunruiNm = paramBunruiNm;
    }

    public String getParamId() {
        return paramId;
    }

    public void setParamId(String paramId) {
        this.paramId = paramId;
    }

    public String getParamValue() {
        return paramValue;
    }

    public void setParamValue(String paramValue) {
        this.paramValue = paramValue;
    }

    public String getParamNm() {
        return paramNm;
    }

    public void setParamNm(String paramNm) {
        this.paramNm = paramNm;
    }

    public String getParamBiko() {
        return paramBiko;
    }

    public void setParamBiko(String paramBiko) {
        this.paramBiko = paramBiko;
    }

}

