/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class LygLoginDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String guid;
    private String accountId;
    private String loginDatetime;
    private String lastOperationDatetime;
    private String logoutRedirectTarget;
    private String tokenForXsrfMeasure;

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getLoginDatetime() {
        return loginDatetime;
    }

    public void setLoginDatetime(String loginDatetime) {
        this.loginDatetime = loginDatetime;
    }

    public String getLastOperationDatetime() {
        return lastOperationDatetime;
    }

    public void setLastOperationDatetime(String lastOperationDatetime) {
        this.lastOperationDatetime = lastOperationDatetime;
    }

    public String getLogoutRedirectTarget() {
        return logoutRedirectTarget;
    }

    public void setLogoutRedirectTarget(String logoutRedirectTarget) {
        this.logoutRedirectTarget = logoutRedirectTarget;
    }

    public String getTokenForXsrfMeasure() {
        return tokenForXsrfMeasure;
    }

    public void setTokenForXsrfMeasure(String tokenForXsrfMeasure) {
        this.tokenForXsrfMeasure = tokenForXsrfMeasure;
    }

}

