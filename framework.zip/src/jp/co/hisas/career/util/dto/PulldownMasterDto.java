/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class PulldownMasterDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String pdSetCd;
    private String pdValue;
    private String pdText;
    private String lpadSort;

    public String getPdSetCd() {
        return pdSetCd;
    }

    public void setPdSetCd(String pdSetCd) {
        this.pdSetCd = pdSetCd;
    }

    public String getPdValue() {
        return pdValue;
    }

    public void setPdValue(String pdValue) {
        this.pdValue = pdValue;
    }

    public String getPdText() {
        return pdText;
    }

    public void setPdText(String pdText) {
        this.pdText = pdText;
    }

    public String getLpadSort() {
        return lpadSort;
    }

    public void setLpadSort(String lpadSort) {
        this.lpadSort = lpadSort;
    }

}

