/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class CjsNinsyouRsvDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String simeiNo;
    private String password;

    public String getSimeiNo() {
        return simeiNo;
    }

    public void setSimeiNo(String simeiNo) {
        this.simeiNo = simeiNo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}

