/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

/**
 * PORTALアカウント属性 Data Transfer Object。
 * @author CareerDaoTool.xla
*/
public class LygAccountPropertyDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * アカウントID
     */
    private String accountId;
    /**
     * 最終ログイン日時
     */
    private String lastLoginDatetime;
    /**
     * 最終操作日時
     */
    private String lastOperationDatetime;
    /**
     * 最終ログアウト日時
     */
    private String lastLogoutDatetime;
    /**
     * 選択言語ID
     */
    private String selectedLanguageId;

    /**
     * アカウントIDを取得する。
     * @return アカウントID
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * アカウントIDを設定する。
     * @param accountId アカウントID
     */
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     * 最終ログイン日時を取得する。
     * @return 最終ログイン日時
     */
    public String getLastLoginDatetime() {
        return lastLoginDatetime;
    }

    /**
     * 最終ログイン日時を設定する。
     * @param lastLoginDatetime 最終ログイン日時
     */
    public void setLastLoginDatetime(String lastLoginDatetime) {
        this.lastLoginDatetime = lastLoginDatetime;
    }

    /**
     * 最終操作日時を取得する。
     * @return 最終操作日時
     */
    public String getLastOperationDatetime() {
        return lastOperationDatetime;
    }

    /**
     * 最終操作日時を設定する。
     * @param lastOperationDatetime 最終操作日時
     */
    public void setLastOperationDatetime(String lastOperationDatetime) {
        this.lastOperationDatetime = lastOperationDatetime;
    }

    /**
     * 最終ログアウト日時を取得する。
     * @return 最終ログアウト日時
     */
    public String getLastLogoutDatetime() {
        return lastLogoutDatetime;
    }

    /**
     * 最終ログアウト日時を設定する。
     * @param lastLogoutDatetime 最終ログアウト日時
     */
    public void setLastLogoutDatetime(String lastLogoutDatetime) {
        this.lastLogoutDatetime = lastLogoutDatetime;
    }

    /**
     * 選択言語IDを取得する。
     * @return 選択言語ID
     */
    public String getSelectedLanguageId() {
        return selectedLanguageId;
    }

    /**
     * 選択言語IDを設定する。
     * @param selectedLanguageId 選択言語ID
     */
    public void setSelectedLanguageId(String selectedLanguageId) {
        this.selectedLanguageId = selectedLanguageId;
    }

}

