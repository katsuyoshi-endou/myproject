/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class CareerPersonRsvDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String personId;
    private String personName;
    private String mailAddress;
    private String hiredDate;
    private String retireDate;
    private String registFlg;
    private Integer deptHierRank;

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getMailAddress() {
        return mailAddress;
    }

    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    public String getHiredDate() {
        return hiredDate;
    }

    public void setHiredDate(String hiredDate) {
        this.hiredDate = hiredDate;
    }

    public String getRetireDate() {
        return retireDate;
    }

    public void setRetireDate(String retireDate) {
        this.retireDate = retireDate;
    }

    public String getRegistFlg() {
        return registFlg;
    }

    public void setRegistFlg(String registFlg) {
        this.registFlg = registFlg;
    }

    public Integer getDeptHierRank() {
        return deptHierRank;
    }

    public void setDeptHierRank(Integer deptHierRank) {
        this.deptHierRank = deptHierRank;
    }

}

