/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class VDeptConnectDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String cmpaCd;
    private String startDeptCd;
    private String tgtDeptCd;
    private String tgtDeptNm;
    private String parentDeptCd;
    private Integer hierarchy;
    private String root;

    public String getCmpaCd() {
        return cmpaCd;
    }

    public void setCmpaCd(String cmpaCd) {
        this.cmpaCd = cmpaCd;
    }

    public String getStartDeptCd() {
        return startDeptCd;
    }

    public void setStartDeptCd(String startDeptCd) {
        this.startDeptCd = startDeptCd;
    }

    public String getTgtDeptCd() {
        return tgtDeptCd;
    }

    public void setTgtDeptCd(String tgtDeptCd) {
        this.tgtDeptCd = tgtDeptCd;
    }

    public String getTgtDeptNm() {
        return tgtDeptNm;
    }

    public void setTgtDeptNm(String tgtDeptNm) {
        this.tgtDeptNm = tgtDeptNm;
    }

    public String getParentDeptCd() {
        return parentDeptCd;
    }

    public void setParentDeptCd(String parentDeptCd) {
        this.parentDeptCd = parentDeptCd;
    }

    public Integer getHierarchy() {
        return hierarchy;
    }

    public void setHierarchy(Integer hierarchy) {
        this.hierarchy = hierarchy;
    }

    public String getRoot() {
        return root;
    }

    public void setRoot(String root) {
        this.root = root;
    }

}

