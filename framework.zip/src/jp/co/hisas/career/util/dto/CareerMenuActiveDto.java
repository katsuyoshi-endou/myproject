/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class CareerMenuActiveDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String guid;
    private String menuGrp;
    private String menuId;
    private String menuLabel;
    private String menuPath;
    private String menuTrans;
    private String party;
    private String partyLabel;
    private String lpadSort;
    private String availFlg;
    private String showIf;
    private String menuPtn;

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getMenuGrp() {
        return menuGrp;
    }

    public void setMenuGrp(String menuGrp) {
        this.menuGrp = menuGrp;
    }

    public String getMenuId() {
        return menuId;
    }

    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    public String getMenuLabel() {
        return menuLabel;
    }

    public void setMenuLabel(String menuLabel) {
        this.menuLabel = menuLabel;
    }

    public String getMenuPath() {
        return menuPath;
    }

    public void setMenuPath(String menuPath) {
        this.menuPath = menuPath;
    }

    public String getMenuTrans() {
        return menuTrans;
    }

    public void setMenuTrans(String menuTrans) {
        this.menuTrans = menuTrans;
    }

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getPartyLabel() {
        return partyLabel;
    }

    public void setPartyLabel(String partyLabel) {
        this.partyLabel = partyLabel;
    }

    public String getLpadSort() {
        return lpadSort;
    }

    public void setLpadSort(String lpadSort) {
        this.lpadSort = lpadSort;
    }

    public String getAvailFlg() {
        return availFlg;
    }

    public void setAvailFlg(String availFlg) {
        this.availFlg = availFlg;
    }

    public String getShowIf() {
        return showIf;
    }

    public void setShowIf(String showIf) {
        this.showIf = showIf;
    }

    public String getMenuPtn() {
        return menuPtn;
    }

    public void setMenuPtn(String menuPtn) {
        this.menuPtn = menuPtn;
    }

}

