/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class MailInfoDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer sendNo;
    private Integer status;
    private String fromAddress;
    private String toAddress;
    private String ccAddress;
    private String bccAddress;
    private String title;
    private String body;
    private String actionPersonId;
    private String kind;
    private String message;
    private String updateFunctionId;
    private String updateDate;
    private String reservedString1;
    private String reservedString2;
    private String reservedString3;
    private String reservedString4;
    private String reservedString5;
    private String reservedString6;
    private String reservedString7;
    private String reservedString8;
    private String reservedString9;
    private String reservedString10;

    public Integer getSendNo() {
        return sendNo;
    }

    public void setSendNo(Integer sendNo) {
        this.sendNo = sendNo;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getFromAddress() {
        return fromAddress;
    }

    public void setFromAddress(String fromAddress) {
        this.fromAddress = fromAddress;
    }

    public String getToAddress() {
        return toAddress;
    }

    public void setToAddress(String toAddress) {
        this.toAddress = toAddress;
    }

    public String getCcAddress() {
        return ccAddress;
    }

    public void setCcAddress(String ccAddress) {
        this.ccAddress = ccAddress;
    }

    public String getBccAddress() {
        return bccAddress;
    }

    public void setBccAddress(String bccAddress) {
        this.bccAddress = bccAddress;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getActionPersonId() {
        return actionPersonId;
    }

    public void setActionPersonId(String actionPersonId) {
        this.actionPersonId = actionPersonId;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUpdateFunctionId() {
        return updateFunctionId;
    }

    public void setUpdateFunctionId(String updateFunctionId) {
        this.updateFunctionId = updateFunctionId;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getReservedString1() {
        return reservedString1;
    }

    public void setReservedString1(String reservedString1) {
        this.reservedString1 = reservedString1;
    }

    public String getReservedString2() {
        return reservedString2;
    }

    public void setReservedString2(String reservedString2) {
        this.reservedString2 = reservedString2;
    }

    public String getReservedString3() {
        return reservedString3;
    }

    public void setReservedString3(String reservedString3) {
        this.reservedString3 = reservedString3;
    }

    public String getReservedString4() {
        return reservedString4;
    }

    public void setReservedString4(String reservedString4) {
        this.reservedString4 = reservedString4;
    }

    public String getReservedString5() {
        return reservedString5;
    }

    public void setReservedString5(String reservedString5) {
        this.reservedString5 = reservedString5;
    }

    public String getReservedString6() {
        return reservedString6;
    }

    public void setReservedString6(String reservedString6) {
        this.reservedString6 = reservedString6;
    }

    public String getReservedString7() {
        return reservedString7;
    }

    public void setReservedString7(String reservedString7) {
        this.reservedString7 = reservedString7;
    }

    public String getReservedString8() {
        return reservedString8;
    }

    public void setReservedString8(String reservedString8) {
        this.reservedString8 = reservedString8;
    }

    public String getReservedString9() {
        return reservedString9;
    }

    public void setReservedString9(String reservedString9) {
        this.reservedString9 = reservedString9;
    }

    public String getReservedString10() {
        return reservedString10;
    }

    public void setReservedString10(String reservedString10) {
        this.reservedString10 = reservedString10;
    }

}

