/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class CaUserDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sign;
    private Integer pid;
    private String displayName;
    private String lang;
    private String cmpaCd;
    private String stfNo;
    private String party;
    private String guid;
    private String personName;
    private String personNameKana;
    private String mailAddress;

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getCmpaCd() {
        return cmpaCd;
    }

    public void setCmpaCd(String cmpaCd) {
        this.cmpaCd = cmpaCd;
    }

    public String getStfNo() {
        return stfNo;
    }

    public void setStfNo(String stfNo) {
        this.stfNo = stfNo;
    }

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getPersonNameKana() {
        return personNameKana;
    }

    public void setPersonNameKana(String personNameKana) {
        this.personNameKana = personNameKana;
    }

    public String getMailAddress() {
        return mailAddress;
    }

    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

}

