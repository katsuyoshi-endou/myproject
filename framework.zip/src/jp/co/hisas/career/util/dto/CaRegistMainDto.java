/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class CaRegistMainDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String cmpaCd;
    private String stfNo;
    private String party;
    private String guid;
    private String personName;
    private String personNameKana;
    private String mailAddress;
    private String hiredDate;
    private String retireDate;
    private String registFlg;
    private String mainFlg;
    private String gnskFlg;
    private String followFlg;
    private Integer deptHierRank;

    public String getCmpaCd() {
        return cmpaCd;
    }

    public void setCmpaCd(String cmpaCd) {
        this.cmpaCd = cmpaCd;
    }

    public String getStfNo() {
        return stfNo;
    }

    public void setStfNo(String stfNo) {
        this.stfNo = stfNo;
    }

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getPersonNameKana() {
        return personNameKana;
    }

    public void setPersonNameKana(String personNameKana) {
        this.personNameKana = personNameKana;
    }

    public String getMailAddress() {
        return mailAddress;
    }

    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    public String getHiredDate() {
        return hiredDate;
    }

    public void setHiredDate(String hiredDate) {
        this.hiredDate = hiredDate;
    }

    public String getRetireDate() {
        return retireDate;
    }

    public void setRetireDate(String retireDate) {
        this.retireDate = retireDate;
    }

    public String getRegistFlg() {
        return registFlg;
    }

    public void setRegistFlg(String registFlg) {
        this.registFlg = registFlg;
    }

    public String getMainFlg() {
        return mainFlg;
    }

    public void setMainFlg(String mainFlg) {
        this.mainFlg = mainFlg;
    }

    public String getGnskFlg() {
        return gnskFlg;
    }

    public void setGnskFlg(String gnskFlg) {
        this.gnskFlg = gnskFlg;
    }

    public String getFollowFlg() {
        return followFlg;
    }

    public void setFollowFlg(String followFlg) {
        this.followFlg = followFlg;
    }

    public Integer getDeptHierRank() {
        return deptHierRank;
    }

    public void setDeptHierRank(Integer deptHierRank) {
        this.deptHierRank = deptHierRank;
    }

}

