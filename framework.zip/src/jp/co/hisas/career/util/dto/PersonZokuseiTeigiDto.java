/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class PersonZokuseiTeigiDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String personZokuseiId;
    private String personZokuseiBunrui3Id;
    private String personZokuseiName;
    private String personZokuseiHyojiName;
    private String butsuriKakunoSaki;
    private Integer ronriTableFlag;
    private String ronriTableName;
    private Integer rirekiKanriFlag;
    private Integer kokaiSeigenFlag;
    private Integer zokuseiType;
    private Integer masterType;
    private String masterId;
    private String updatePersonId;
    private String updateFunction;
    private String updateDate;
    private String updateTime;

    public String getPersonZokuseiId() {
        return personZokuseiId;
    }

    public void setPersonZokuseiId(String personZokuseiId) {
        this.personZokuseiId = personZokuseiId;
    }

    public String getPersonZokuseiBunrui3Id() {
        return personZokuseiBunrui3Id;
    }

    public void setPersonZokuseiBunrui3Id(String personZokuseiBunrui3Id) {
        this.personZokuseiBunrui3Id = personZokuseiBunrui3Id;
    }

    public String getPersonZokuseiName() {
        return personZokuseiName;
    }

    public void setPersonZokuseiName(String personZokuseiName) {
        this.personZokuseiName = personZokuseiName;
    }

    public String getPersonZokuseiHyojiName() {
        return personZokuseiHyojiName;
    }

    public void setPersonZokuseiHyojiName(String personZokuseiHyojiName) {
        this.personZokuseiHyojiName = personZokuseiHyojiName;
    }

    public String getButsuriKakunoSaki() {
        return butsuriKakunoSaki;
    }

    public void setButsuriKakunoSaki(String butsuriKakunoSaki) {
        this.butsuriKakunoSaki = butsuriKakunoSaki;
    }

    public Integer getRonriTableFlag() {
        return ronriTableFlag;
    }

    public void setRonriTableFlag(Integer ronriTableFlag) {
        this.ronriTableFlag = ronriTableFlag;
    }

    public String getRonriTableName() {
        return ronriTableName;
    }

    public void setRonriTableName(String ronriTableName) {
        this.ronriTableName = ronriTableName;
    }

    public Integer getRirekiKanriFlag() {
        return rirekiKanriFlag;
    }

    public void setRirekiKanriFlag(Integer rirekiKanriFlag) {
        this.rirekiKanriFlag = rirekiKanriFlag;
    }

    public Integer getKokaiSeigenFlag() {
        return kokaiSeigenFlag;
    }

    public void setKokaiSeigenFlag(Integer kokaiSeigenFlag) {
        this.kokaiSeigenFlag = kokaiSeigenFlag;
    }

    public Integer getZokuseiType() {
        return zokuseiType;
    }

    public void setZokuseiType(Integer zokuseiType) {
        this.zokuseiType = zokuseiType;
    }

    public Integer getMasterType() {
        return masterType;
    }

    public void setMasterType(Integer masterType) {
        this.masterType = masterType;
    }

    public String getMasterId() {
        return masterId;
    }

    public void setMasterId(String masterId) {
        this.masterId = masterId;
    }

    public String getUpdatePersonId() {
        return updatePersonId;
    }

    public void setUpdatePersonId(String updatePersonId) {
        this.updatePersonId = updatePersonId;
    }

    public String getUpdateFunction() {
        return updateFunction;
    }

    public void setUpdateFunction(String updateFunction) {
        this.updateFunction = updateFunction;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

}

