/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.                             
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dto;

import java.io.Serializable;

public class CodeMasterDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String masterId;
    private String masterCode;
    private String masterName;
    private String masterZokusei1;
    private String masterZokusei2;
    private String masterZokusei3;
    private String masterZokusei4;
    private String masterZokusei5;
    private String updatePersonId;
    private String updateFunction;
    private String updateDate;
    private String updateTime;

    public String getMasterId() {
        return masterId;
    }

    public void setMasterId(String masterId) {
        this.masterId = masterId;
    }

    public String getMasterCode() {
        return masterCode;
    }

    public void setMasterCode(String masterCode) {
        this.masterCode = masterCode;
    }

    public String getMasterName() {
        return masterName;
    }

    public void setMasterName(String masterName) {
        this.masterName = masterName;
    }

    public String getMasterZokusei1() {
        return masterZokusei1;
    }

    public void setMasterZokusei1(String masterZokusei1) {
        this.masterZokusei1 = masterZokusei1;
    }

    public String getMasterZokusei2() {
        return masterZokusei2;
    }

    public void setMasterZokusei2(String masterZokusei2) {
        this.masterZokusei2 = masterZokusei2;
    }

    public String getMasterZokusei3() {
        return masterZokusei3;
    }

    public void setMasterZokusei3(String masterZokusei3) {
        this.masterZokusei3 = masterZokusei3;
    }

    public String getMasterZokusei4() {
        return masterZokusei4;
    }

    public void setMasterZokusei4(String masterZokusei4) {
        this.masterZokusei4 = masterZokusei4;
    }

    public String getMasterZokusei5() {
        return masterZokusei5;
    }

    public void setMasterZokusei5(String masterZokusei5) {
        this.masterZokusei5 = masterZokusei5;
    }

    public String getUpdatePersonId() {
        return updatePersonId;
    }

    public void setUpdatePersonId(String updatePersonId) {
        this.updatePersonId = updatePersonId;
    }

    public String getUpdateFunction() {
        return updateFunction;
    }

    public void setUpdateFunction(String updateFunction) {
        this.updateFunction = updateFunction;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

}

