package jp.co.hisas.career.util.cache;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.io.FileUtils;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.util.log.Log;

public final class HtmlTemplateCache {
	
	private ConcurrentHashMap<String, String> map = new ConcurrentHashMap<String, String>();
	
	/**
	 * Singleton パターン - Wikipedia
	 * https://ja.wikipedia.org/wiki/Singleton_パターン
	 */
	private HtmlTemplateCache() {
	}
	
	private static class HtmlTemplateCacheHolder {
		private static final HtmlTemplateCache instance = new HtmlTemplateCache();
	}
	
	private static HtmlTemplateCache getInstance() {
		return HtmlTemplateCacheHolder.instance;
	}
	
	public static String getTemplate( String templateId ) {
		HtmlTemplateCache instance = HtmlTemplateCache.getInstance();
		return instance.getTemplateData( templateId );
	}
	
	private String getTemplateData( String templateId ) {
		// マップにすでにキーが存在するかどうかでキャッシュ済みかどうかを判断する
		if (!map.containsKey( templateId )) {
			// マップにキーがなければテンプレートファイルを読み込みに行く
			addCache( templateId );
		}
		return map.get( templateId );
	}
	
	private void addCache( String key ) {
		try {
			String filename = key + ".html";
			String fullPath = AppDef.APP_DIR + "/htmltemplate/" + filename;
			String template = FileUtils.readFileToString( new File( fullPath ), "utf-8" );
			map.put( key, template );
		} catch (IOException e) {
			Log.warn( e.getMessage() );
			map.put( key, "" );
		}
	}
	
	public static void clearCache() {
		HtmlTemplateCache instance = HtmlTemplateCache.getInstance();
		instance.clearCacheData();
	}
	
	private void clearCacheData() {
		map = new ConcurrentHashMap<String, String>();
	}
	
}
