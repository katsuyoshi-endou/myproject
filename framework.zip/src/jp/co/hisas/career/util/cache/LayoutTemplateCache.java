package jp.co.hisas.career.util.cache;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.io.FileUtils;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.util.log.Log;

public final class LayoutTemplateCache {
	
	private ConcurrentHashMap<String, String> map = new ConcurrentHashMap<String, String>();
	
	/**
	 * Singleton パターン - Wikipedia
	 * https://ja.wikipedia.org/wiki/Singleton_パターン
	 */
	private LayoutTemplateCache() {
	}
	
	private static class LayoutTemplateCacheHolder {
		private static final LayoutTemplateCache instance = new LayoutTemplateCache();
	}
	
	private static LayoutTemplateCache getInstance() {
		return LayoutTemplateCacheHolder.instance;
	}
	
	public static String getTemplate( String templateId ) {
		LayoutTemplateCache instance = LayoutTemplateCache.getInstance();
		return instance.getTemplateData( templateId );
	}
	
	private String getTemplateData( String templateId ) {
		// マップにすでにキーが存在するかどうかでキャッシュ済みかどうかを判断する
		if (!map.containsKey( templateId )) {
			// マップにキーがなければテンプレートファイルを読み込みに行く
			addCache( templateId );
		}
		return map.get( templateId );
	}
	
	private void addCache( String key ) {
		try {
			String filename = key + ".html";
			String fullPath = AppDef.APP_DIR + "/layouttemplate/" + filename;
			String template = FileUtils.readFileToString( new File( fullPath ), "utf-8" );
			map.put( key, template );
		} catch (IOException e) {
			Log.warn( e.getMessage() );
			map.put( key, "" );
		}
	}
	
	public static void clearCache() {
		LayoutTemplateCache instance = LayoutTemplateCache.getInstance();
		instance.clearCacheData();
	}
	
	private void clearCacheData() {
		map = new ConcurrentHashMap<String, String>();
	}
	
}
