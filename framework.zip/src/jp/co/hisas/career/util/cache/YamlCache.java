package jp.co.hisas.career.util.cache;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.io.FileUtils;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.util.log.Log;

public final class YamlCache {
	
	private ConcurrentHashMap<String, String> map = new ConcurrentHashMap<String, String>();
	
	/**
	 * Singleton パターン - Wikipedia
	 * https://ja.wikipedia.org/wiki/Singleton_パターン
	 */
	private YamlCache() {
	}
	
	private static class YamlCacheHolder {
		private static final YamlCache instance = new YamlCache();
	}
	
	private static YamlCache getInstance() {
		return YamlCacheHolder.instance;
	}
	
	public static String getSection( String filename ) {
		YamlCache instance = YamlCache.getInstance();
		return instance.getSectionData( filename );
	}
	
	private String getSectionData( String filename ) {
		if (!map.containsKey( filename )) {
			addCache( filename );
		}
		return map.get( filename );
	}
	
	private void addCache( String filename ) {
		try {
			String fullPath = AppDef.APP_DIR + "/config/" + filename;
			String document = FileUtils.readFileToString( new File( fullPath ), "utf-8" );
			map.put( filename, document );
		} catch (IOException e) {
			Log.warn( e.getLocalizedMessage() );
			map.put( filename, null );
		}
	}
	
	public static void clearCache() {
		YamlCache instance = YamlCache.getInstance();
		instance.clearCacheData();
	}
	
	private void clearCacheData() {
		map = new ConcurrentHashMap<String, String>();
	}
	
}
