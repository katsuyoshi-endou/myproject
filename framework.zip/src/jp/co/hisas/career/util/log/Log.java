/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.util.log;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.ejb.EJBException;
import javax.mail.MessagingException;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Category;
import org.apache.log4j.Level;
import org.apache.log4j.PropertyConfigurator;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * ログ出力クラス 概要: Log4Jを使用し、メソッド、トランザクション、性能の各種トレースとエラーログを出力する。 使用方法: 本クラス中の一般の利用者が使用するメソッドは全て静的であるため、 本クラス名.メソッド名 で呼び出す。 備考: 発行箇所情報はスタックトレースより自動取得を行う。
 * 
 * </PRE>
 */

public class Log {

	/**
	 * Log4Jに依存した定数定義
	 */

	/** Log4J-トランザクショントレース用カテゴリ名 */
	private final static String CATEGORY_TRANSACTION = "CTG_TRANSACTION";

	/** Log4J-メソッドトレース用カテゴリ名 */
	private final static String CATEGORY_METHOD = "CTG_METHOD";

	/** Log4J-性能測定トレース用カテゴリ名 */
	private final static String CATEGORY_PERFORMANCE = "CTG_PERFORMANCE";

	/** Log4J-デバッグトレース用カテゴリ名 */
	private final static String CATEGORY_DEBUG = "CTG_DEBUG";

    /** Log4J-SQLトレース用カテゴリ名 */
    private final static String CATEGORY_SQL = "CTG_SQL";
    
	/** Log4J-エラーログ用カテゴリ名 */
	private final static String CATEGORY_ERROR = "CTG_ERROR";

	/** エラーコード:SQLException */
	public static final String ERROR_CODE_0001 = "HJE-0001";

	/** エラーコード:NamingException */
	public static final String ERROR_CODE_0002 = "HJE-0002";

	/** エラーコード:ClassCastException */
	public static final String ERROR_CODE_0003 = "HJE-0003";

	/** エラーコード:ArrayIndexOutOfBoundsException */
	public static final String ERROR_CODE_0004 = "HJE-0004";

	/** エラーコード:FileNotFoundException */
	public static final String ERROR_CODE_0005 = "HJE-0005";

	/** エラーコード:IllegalThreadStateException */
	public static final String ERROR_CODE_0006 = "HJE-0006";

	/** エラーコード:UnsupportedEncodingException */
	public static final String ERROR_CODE_0007 = "HJE-0007";

	/** エラーコード:NumberFormatException */
	public static final String ERROR_CODE_0008 = "HJE-0008";

	/** エラーコード:IllegalArgumentException */
	public static final String ERROR_CODE_0009 = "HJE-0009";

	/** エラーコード:IllegalStateException */
	public static final String ERROR_CODE_0010 = "HJE-0010";

	/** エラーコード:IndexOutOfBoundsException */
	public static final String ERROR_CODE_0011 = "HJE-0011";

	/** エラーコード:IOException */
	public static final String ERROR_CODE_0012 = "HJE-0012";

	/** エラーコード:NullPointerException */
	public static final String ERROR_CODE_0013 = "HJE-0013";

	/** エラーコード:SecurityException */
	public static final String ERROR_CODE_0014 = "HJE-0014";

	/** エラーコード:ServletException */
	public static final String ERROR_CODE_0015 = "HJE-0015";

	/** エラーコード:Exception */
	public static final String ERROR_CODE_0017 = "HJE-0017";

	/** エラーコード:MessagingException */
	public static final String ERROR_CODE_0019 = "HJE-0019";

	/** エラーコード:RuntimeException */
	public static final String ERROR_CODE_0020 = "HJE-0020";

	// add 脆弱性対応 start
	/** Log4J-エラーログ用カテゴリ名 */
	private final static String CATEGORY_SECURITY = "CTG_SECURITY";
	// add 脆弱性対応 end
	
	/**
	 * データメンバ
	 */

	/** カテゴリ静的インスタンス(トランザクショントレース用) */
	private static Category _transactionCategory;

	/** カテゴリ静的インスタンス(メソッドトレース用) */
	private static Category _methodCategory;

	/** カテゴリ静的インスタンス(性能測定トレース用) */
	private static Category _performanceCategory;

	/** カテゴリ静的インスタンス(デバッグトレース用) */
	private static Category _debugCategory;

    /** カテゴリ静的インスタンス(SQLトレース用) */
    private static Category _sqlCategory;
    
	// add 脆弱性対応 start
	/** カテゴリ静的インスタンス(エラーログ用) */
	private static Category _securityCategory;
	// add 脆弱性対応 end
	
	/** カテゴリ静的インスタンス(エラーログ用) */
	private static Category _errorCategory;

	/** 初期化処理実行結果フラグ */
	private static boolean _initStatus = false;

	/** シングルトンモデル用静的インスタンス */
	@SuppressWarnings("unused")
	private static final Log _Log = new Log();

	/** ヘッダ文字列 */
	private static String _headerString;

	/** 行区切文字の設定 */
	private static final String _lineSeparator = System.getProperty("line.separator");

	/** メッセージ定義ファイルを格納するHashMap */
//	@SuppressWarnings("rawtypes")
//	private static HashMap _msgMapData = null;

	/** メッセージ定義ファイル読み込みフラグ */
	private static boolean msgFileFlg = false;

	/**
	 * コンストラクタ
	 */
	@SuppressWarnings("static-access")
	private Log() {
		this.init();
	}

	//c:\lysitheacareer変更対応 mod start
	public static synchronized void refresh() {
		init();
	}
	//c:\lysitheacareer変更対応 mod end
	
	/**
	 * 初期化処理
	 */
	synchronized private static void init() {

		String hostName = "";

		/* ログ設定の初期化を起点にプロパティも初期化 */
		ReadFile.refreshAllProperties();

		/* Log4J定義ファイル名取得 */
		final String log4jFileName = AU.getCareerProperty( "LOG4J" );

		/* Log4J定義ファイル名をセットし、全カテゴリのインスタンスを生成 */
		PropertyConfigurator.configure(log4jFileName);

		Log._transactionCategory = Category.getInstance(Log.CATEGORY_TRANSACTION);
		Log._methodCategory = Category.getInstance(Log.CATEGORY_METHOD);
		Log._performanceCategory = Category.getInstance(Log.CATEGORY_PERFORMANCE);
		Log._debugCategory = Category.getInstance(Log.CATEGORY_DEBUG);
		Log._errorCategory = Category.getInstance(Log.CATEGORY_ERROR);
		Log._sqlCategory = Category.getInstance(Log.CATEGORY_SQL);

// add 脆弱性対応 start
		Log._securityCategory = Category.getInstance(Log.CATEGORY_SECURITY);
// add 脆弱性対応 end
		
		try {
			hostName = InetAddress.getLocalHost().getHostName();

			/* ホスト名が取得できなかった場合 */
			if (hostName == null) {
				hostName = "";
			}
			/* ホストの IP アドレスが判定できなかった場合 ホスト名には半角スペースを１０文字入力 */
		} catch (final UnknownHostException e) {
			System.err.println("ホスト名の取得時に、エラーが発生しました。");

			/* 例外のスタックトレースを出力 */
			e.printStackTrace(System.err);

		}

		/* ヘッダ文字列の生成 */
		Log._headerString = "[HOST:" + hostName + "] ";

		/* 初期化処理正常終了 */
		Log._initStatus = true;

	}

	/**
	 * 場所情報取得<br>
	 * スタックトレースから場所情報を自動取得する。
	 * @return 連結文字列
	 */
	private static String getPos() {

		/* POS情報取得のため、例外を発生 */
		final Throwable _traceThrowable = new Throwable();

		/* スタックトレース取得 */
		final StackTraceElement[] element = _traceThrowable.getStackTrace();

		/* POS情報取得 */
		final String callerName = element[2].toString();

		return "[POS:" + callerName + "] ";
	}

	/**
	 * メソッドトレース<br>
	 * メソッドの呼び出し履歴を出力する。<br>
	 * @param ID LDAP ID
	 * @param inOut 発行個所種別（メソッド開始直後に配置の場合は"IN"を, 終了直前に配置の場合は"OUT"を指定）
	 * @param message 任意文字列（不要時は""（ダブルクォーテーション２つ）を設定）
	 */
	public static void method(String ID, String inOut, String message) {

		/* 初期化処理実行結果フラグチェック */
		if (Log._initStatus == false) {
			System.err.println("初期化処理が行われていません。");
			return;
		}

		/* nullチェック */
		if (ID == null) {
			ID = "";
		}
		if (inOut == null) {
			inOut = "";
		}
		if (message == null) {
			message = "";
		}

		/* ログ出力 */
		Log._methodCategory.info(Log._headerString + "[ID:" + ID + "] " + "[" + inOut + "] " + Log.getPos() + message);
	}

	/**
	 * トランザクショントレース<br>
	 * トランザクション開始、終了時の情報を出力する。<br>
	 * @param ID LDAP ID
	 * @param start 開始/終了種別（trueをセットした場合"START"、 falseをセットした場合"END"をログに出力）
	 * @param message 任意文字列 （不要時は""（ダブルクォーテーション２つ）を設定）
	 */
	public static void transaction(String ID, final boolean start, String message) {

		String startEnd = "";

		/* 初期化処理実行結果フラグチェック */
		if (Log._initStatus == false) {
			System.err.println("初期化処理が行われていません。");
			return;
		}

		/* nullチェック */
		if (ID == null) {
			ID = "";
		}
		if (message == null) {
			message = "";
		}

		/* 開始／終了種別判定 */
		if (start == true) {
			startEnd = "START";
		} else {
			startEnd = "END";
		}

		/* ログ出力 */
		Log._transactionCategory.info(Log._headerString + "[ID:" + ID + "] " + "[" + startEnd + "]" + Log.getPos() + message);
	}

	/**
	 * 性能測定トレース<br>
	 * 処理の性能測定のためにタイムスタンプと、VMの空きメモリ量・合計メモリ量を出力する。<br>
	 * @param ID LDAP ID
	 * @param start 開始/終了種別（trueをセットした場合"START"、 falseをセットした場合"END"をログに出力）
	 * @param message 任意文字列 （不要時は""（ダブルクォーテーション２つ）を設定）
	 */

	public static void performance(String ID, final boolean start, String message) {

		String startEnd = "";

		/* 初期化処理実行結果フラグチェック */
		if (Log._initStatus == false) {
			System.err.println("初期化処理が行われていません。");
			return;
		}

		/* nullチェック */
		if (ID == null) {
			ID = "";
		}
		if (message == null) {
			message = "";
		}

		/* 開始／終了種別判定 */
		if (start == true) {
			startEnd = "START";
		} else {
			startEnd = "END";
		}

		/* 現在のランタイムオブジェクトを取得 */
		final Runtime runtime = Runtime.getRuntime();

		Log._performanceCategory.info(Log._headerString + "[ID:" + ID + "] " + "[" + startEnd + "] " + "[FREE:" + runtime.freeMemory() + "] " + "[TOTAL:" + runtime.totalMemory() + "] " + Log.getPos()
				+ message);
	}

	/**
	 * デバッグトレース<br>
	 * デバッグ用に出したい情報を出力する。<br>
	 * @param message デバッグ用の情報 （不要時は""（ダブルクォーテーション２つ）を設定）
	 */

	public static void debug(String message) {

		/* 初期化処理実行結果フラグチェック */
		if (Log._initStatus == false) {
			System.err.println("初期化処理が行われていません。");
			return;
		}

		/* nullチェック */
		if (message == null) {
			message = "";
		}

		Log._debugCategory.debug(Log._headerString + Log.getPos() + "[" + message + "]");
	}

	/**
	 * ワーニングエラー（警告）<br>
	 * 想定外のロジックを明示的にＳＥや開発者に伝えたい場合に使用。
	 * データ不正やマスタ設定不正を気づかせる。出力先はエラーログ。
	 */
	public static void warn(final String msg) {
		Log._errorCategory.error( "▲警告▲ " + msg );
	}
	
	public static void investigate( final HttpServletRequest req, final HttpServletResponse res ) {
		StringBuilder sb = new StringBuilder();
		sb.append( "▽調査▽\r\n" );
		sb.append( "-- Request General --------\r\n" );
		sb.append( makeRequestGeneralInfo( req ) );
		sb.append( "-- Request Header --------\r\n" );
		sb.append( makeRequestHeaderInfo( req ) );
		sb.append( "-- Request Parameter --------\r\n" );
		sb.append( makeRequestParameterInfo( req ) );
		sb.append( "-- Request Attribute --------\r\n" );
		sb.append( makeRequestAttributeInfo( req ) );
		Log._errorCategory.error( sb.toString() );
	}
	
	private static String makeRequestGeneralInfo( final HttpServletRequest req ) {
		StringBuilder sb = new StringBuilder();
		sb.append( String.format( "[%s] %s\r\n", "RequestURI", req.getRequestURI() ) );
		sb.append( String.format( "[%s] %s\r\n", "RequestURL", req.getRequestURL() ) );
		sb.append( String.format( "[%s] %s\r\n", "Method", req.getMethod() ) );
		sb.append( String.format( "[%s] %s\r\n", "RemoteAddr", req.getRemoteAddr() ) );
		return sb.toString();
	}
	
	private static String makeRequestHeaderInfo( final HttpServletRequest req ) {
		StringBuilder sb = new StringBuilder();
		Enumeration<?> headerNames = req.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String name = (String)headerNames.nextElement();
			String value = req.getHeader( name );
			sb.append( String.format( "[%s] %s\r\n", name, value ) );
		}
		return sb.toString();
	}
	
	private static String makeRequestParameterInfo( final HttpServletRequest req ) {
		StringBuilder sb = new StringBuilder();
		Enumeration<?> paramNames = req.getParameterNames();
		while (paramNames.hasMoreElements()) {
			String name = (String)paramNames.nextElement();
			String value = req.getParameter( name );
			sb.append( String.format( "[%s] %s\r\n", name, value ) );
		}
		return sb.toString();
	}
	
	private static String makeRequestAttributeInfo( final HttpServletRequest req ) {
		StringBuilder sb = new StringBuilder();
		Enumeration<?> paramNames = req.getAttributeNames();
		while (paramNames.hasMoreElements()) {
			String name = (String)paramNames.nextElement();
			Object value = req.getAttribute( name );
			sb.append( String.format( "[%s] %s\r\n", name, value.toString() ) );
		}
		return sb.toString();
	}
	
	/**
	 * エラーログ<br>
	 * 指定されたエラーコードの内外コード変換を行い外部コードを取得し、<br>
	 * 引数で渡された例外の情報を出力する。<br>
	 * @param ID LDAP ID
	 * @param errorCode エラーメッセージの内部コード
	 * @param ex 例外オブジェクト
	 */
	public static void error(String ID, final String errorCode, final Throwable ex) {

		String tmpLinkMsg = null;
		String exMsg = null;
		String exStackTrace = "";
		StackTraceElement[] ste = null;
		String errorMessage = "";

		/* 初期化処理実行結果フラグチェック */
		if (Log._initStatus == false) {
			System.err.println("初期化処理が行われていません。");
			return;
		}

		/* nullチェック */
		if (ID == null) {
			ID = "";
		}
		if (errorCode == null) {
			System.err.println("エラーメッセージの内部コードが指定されていません。");
			return;
		}

		/* メッセージ定義ファイルが読み込まれていない場合 */
		if (Log.msgFileFlg == false) {
//			Log._msgMapData = ReadFile.messageMapData;
			Log.msgFileFlg = true;
		}

		/* メッセージ定義ファイルからエラーメッセージ取得 */
//		errorMessage = (String) Log._msgMapData.get(errorCode);

		/* メッセージが取得できなかった場合 */
//		if (errorMessage == null) {
//			errorMessage = "";
//		}

		/* 例外が引数で渡されていない場合 */
		if (ex == null) {

			tmpLinkMsg = errorMessage;

			/* 例外が引数で渡されている場合 */
		} else {

			/* ラッピング元のスタックトレース取得 */
			ste = ex.getStackTrace();

			/* 例外メッセージ取得 */
			exMsg = ex.toString();

			/* 例外メッセージ取得チェック */
			if (exMsg == null) {
				exMsg = "";
			}

			/* スタックトレースを取得できた場合 */
			if (ste != null) {

				/* 例外の詳細情報を出力する */
				for (int i = 0; i < ste.length; i++) {

					/* スタックトレース取得 */
					exStackTrace = exStackTrace + Log._lineSeparator + ste[i].toString();
				}
			}

			/* 文字列を連結 */
			if (tmpLinkMsg == null) {
				tmpLinkMsg = "";
			}

			tmpLinkMsg = errorMessage + "\r\n<<" + exMsg + ">>" + exStackTrace;
		}

		/* ログ出力 */
		StringBuilder sb = new StringBuilder();
		sb.append( Log._headerString );
		sb.append( "[ID:" + ID + "] " );
		sb.append( "[CODE:" + errorCode + "] " );
		sb.append( Log.getPos() );
		sb.append( tmpLinkMsg );
		Log._errorCategory.error( sb.toString() );
	}

	/**
	 * リクエストからログインユーザを割り出してエラーログを出力する。
	 * @param request
	 * @param ex
	 */
	public static void error( final HttpServletRequest request, final Throwable ex ) {
		String loginNo = "";
		try {
			final UserInfoBean userinfo = (UserInfoBean)request.getSession( false ).getAttribute( "userinfo" );
			loginNo = userinfo.getLogin_no();
		} catch (Exception e) {
		}
		error( loginNo, "", ex );
	}

	/**
	 * 渡されたエラー種別から自動でエラーコードを設定して{@link #error(String, String, Throwable)}を呼び出す。<br>
	 * EJBException、RemoteExceptionの場合、ネストされたExceptionでログ出力する。 <table>
	 * <tr>
	 * <th>Exception種別</th>
	 * <th>出力するエラーコード</th>
	 * </tr>
	 * <tr>
	 * <td>SQLException</td>
	 * <td>HJE-0001</td>
	 * </tr>
	 * <tr>
	 * <td>NamingException</td>
	 * <td>HJE-0002</td>
	 * </tr>
	 * <tr>
	 * <td>ClassCastException</td>
	 * <td>HJE-0003</td>
	 * </tr>
	 * <tr>
	 * <td>ArrayIndexOutOfBoundsException</td>
	 * <td>HJE-0004</td>
	 * </tr>
	 * <tr>
	 * <td>FileNotFoundException</td>
	 * <td>HJE-0005</td>
	 * </tr>
	 * <tr>
	 * <td>IllegalThreadStateException</td>
	 * <td>HJE-0006</td>
	 * </tr>
	 * <tr>
	 * <td>UnsupportedEncodingException</td>
	 * <td>HJE-0007</td>
	 * </tr>
	 * <tr>
	 * <td>NumberFormatException</td>
	 * <td>HJE-0008</td>
	 * </tr>
	 * <tr>
	 * <td>IllegalArgumentException</td>
	 * <td>HJE-0009</td>
	 * </tr>
	 * <tr>
	 * <td>IllegalStateException</td>
	 * <td>HJE-0010</td>
	 * </tr>
	 * <tr>
	 * <td>IndexOutOfBoundsException</td>
	 * <td>HJE-0011</td>
	 * </tr>
	 * <tr>
	 * <td>IOException</td>
	 * <td>HJE-0012</td>
	 * </tr>
	 * <tr>
	 * <td>NullPointerException</td>
	 * <td>HJE-0013</td>
	 * </tr>
	 * <tr>
	 * <td>SecurityException</td>
	 * <td>HJE-0014</td>
	 * </tr>
	 * <tr>
	 * <td>ServletException</td>
	 * <td>HJE-0015</td>
	 * </tr>
	 * <tr>
	 * <td>Exception</td>
	 * <td>HJE-0017</td>
	 * </tr>
	 * <tr>
	 * <td>MessagingException</td>
	 * <td>HJE-0019</td>
	 * </tr>
	 * <tr>
	 * <td>RuntimeException</td>
	 * <td>HJE-0020</td>
	 * </tr>
	 * </table>
	 * @param loginNo ログインユーザの氏名No
	 * @param e エラー出力したいException
	 */
	public static void error(final String loginNo, final Throwable e) {
		// エラーコード
		String errorCode = "";

		if (e == null) {
			return;
		}

		// ネストされている可能性の高いExceptionの処理
		if (e instanceof EJBException) {
			if (((EJBException) e).getCausedByException() != null) {
				// ネストされている場合再帰呼び出し
				Log.error(loginNo, ((EJBException) e).getCausedByException());
			} else {
				// ネストされていない場合、Exceptionとして処理
				Log.error(loginNo, Log.ERROR_CODE_0017, e);
			}
		} else if (e instanceof RemoteException) {
			if (((RemoteException) e).detail != null) {
				Log.error(loginNo, ((RemoteException) e).detail);
			} else {
				// ネストされていない場合、Exceptionとして処理
				Log.error(loginNo, Log.ERROR_CODE_0017, e);
			}
		} else {
			// Exceptionの種別ごとに分岐
			// Exceptionを追加する場合はExceptionの継承関係に注意して下さい
			// 例えばRemoteExceptionをIOExceptionより後ろの判定順にするとRemoteExceptionには絶対到達しません
			if (e instanceof SQLException) {
				errorCode = Log.ERROR_CODE_0001;
			} else if (e instanceof NamingException) {
				errorCode = Log.ERROR_CODE_0002;
			} else if (e instanceof ClassCastException) {
				errorCode = Log.ERROR_CODE_0003;
			} else if (e instanceof ArrayIndexOutOfBoundsException) {
				errorCode = Log.ERROR_CODE_0004;
			} else if (e instanceof FileNotFoundException) {
				errorCode = Log.ERROR_CODE_0005;
			} else if (e instanceof IllegalThreadStateException) {
				errorCode = Log.ERROR_CODE_0006;
			} else if (e instanceof UnsupportedEncodingException) {
				errorCode = Log.ERROR_CODE_0007;
			} else if (e instanceof NumberFormatException) {
				errorCode = Log.ERROR_CODE_0008;
			} else if (e instanceof IllegalArgumentException) {
				errorCode = Log.ERROR_CODE_0009;
			} else if (e instanceof IllegalStateException) {
				errorCode = Log.ERROR_CODE_0010;
			} else if (e instanceof IndexOutOfBoundsException) {
				errorCode = Log.ERROR_CODE_0011;
			} else if (e instanceof IOException) {
				errorCode = Log.ERROR_CODE_0012;
			} else if (e instanceof NullPointerException) {
				errorCode = Log.ERROR_CODE_0013;
			} else if (e instanceof SecurityException) {
				errorCode = Log.ERROR_CODE_0014;
			} else if (e instanceof ServletException) {
				errorCode = Log.ERROR_CODE_0015;
			} else if (e instanceof MessagingException) {
				errorCode = Log.ERROR_CODE_0019;
			} else if (e instanceof RuntimeException) { // 下から二番目
				errorCode = Log.ERROR_CODE_0020;
			} else if (e instanceof Exception) { // 一番最後
				errorCode = Log.ERROR_CODE_0017;
			}
			Log.error(loginNo, errorCode, e);
		}
	}
	
	public static boolean isSqlDebugOn() {
	    if (Log._sqlCategory.getLevel() == Level.DEBUG) {
	    	// k-nishihara del debugにですぎなので消す。
	    	//Log.debug("sqlLogLevel is debug then this application trace sql!");
	    	// k-nishihara deldebugにですぎなので消す。
	        return true;
	    } else {
	        return false;
	    }
	}
	
	public static boolean isSecurityDebugOn() {
	    if (Log._securityCategory.getLevel() == Level.DEBUG) {
	        return true;
	    } else {
	        return false;
	    }
	}
	
    public static void sql(String message) {

        /* 初期化処理実行結果フラグチェック */
        if (Log._initStatus == false) {
            System.err.println("初期化処理が行われていません。");
            return;
        }

        /* nullチェック */
        if (message == null) {
            message = "";
        }

        Log._sqlCategory.debug(Log._headerString  + message );

    }
    
	public static boolean isDebugMode() {
		return "1".equals(AU.getCareerProperty("CAREER_DEBUG"));
	}
	
// add 脆弱性対応 start
	/**
	 * セキュリティログ<br>
	 * 脆弱性対応のための情報を出力する。<br>
	 * @param ID
	 *            LDAP ID
	 * @param message
	 *            出力内容
	 */
	public static void security(String ID, String message) {

		/* 初期化処理実行結果フラグチェック */
		if (Log._initStatus == false) {
			System.err.println("初期化処理が行われていません。");
			return;
		}

		/* nullチェック */
		if (message == null) {
			message = "";
		}

		/* ログ出力 */
		Log._securityCategory.debug(Log._headerString + "[ID:" + ID + "] " + message);
	}
	
	public static void securityError(String ID, String message) {

		/* 初期化処理実行結果フラグチェック */
		if (Log._initStatus == false) {
			System.err.println("初期化処理が行われていません。");
			return;
		}

		/* nullチェック */
		if (message == null) {
			message = "";
		}

		/* ログ出力 */
		Log._securityCategory.error(Log._headerString + "[ID:" + ID + "] " + message);
	}
// add 脆弱性対応 end
	
}

