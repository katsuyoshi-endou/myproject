/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.CareerMenuActiveDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CareerMenuActiveDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " GUID as guid,"
                     + " MENU_GRP as menuGrp,"
                     + " MENU_ID as menuId,"
                     + " MENU_LABEL as menuLabel,"
                     + " MENU_PATH as menuPath,"
                     + " MENU_TRANS as menuTrans,"
                     + " PARTY as party,"
                     + " PARTY_LABEL as partyLabel,"
                     + " LPAD_SORT as lpadSort,"
                     + " AVAIL_FLG as availFlg,"
                     + " SHOW_IF as showIf,"
                     + " MENU_PTN as menuPtn"
                     ;

    public CareerMenuActiveDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CareerMenuActiveDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public CareerMenuActiveDto select(String guid, String menuGrp, String menuId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CAREER_MENU_ACTIVE"
                         + " WHERE GUID = ?"
                         + " AND MENU_GRP = ?"
                         + " AND MENU_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CareerMenuActiveDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, guid);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, menuGrp);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, menuId);
            rs = pstmt.executeQuery();
            CareerMenuActiveDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CareerMenuActiveDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CareerMenuActiveDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CareerMenuActiveDto> lst = new ArrayList<CareerMenuActiveDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CareerMenuActiveDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CareerMenuActiveDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private CareerMenuActiveDto transferRsToDto(ResultSet rs) throws SQLException {

        CareerMenuActiveDto dto = new CareerMenuActiveDto();
        dto.setGuid(DaoUtil.convertNullToString(rs.getString("guid")));
        dto.setMenuGrp(DaoUtil.convertNullToString(rs.getString("menuGrp")));
        dto.setMenuId(DaoUtil.convertNullToString(rs.getString("menuId")));
        dto.setMenuLabel(DaoUtil.convertNullToString(rs.getString("menuLabel")));
        dto.setMenuPath(DaoUtil.convertNullToString(rs.getString("menuPath")));
        dto.setMenuTrans(DaoUtil.convertNullToString(rs.getString("menuTrans")));
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setPartyLabel(DaoUtil.convertNullToString(rs.getString("partyLabel")));
        dto.setLpadSort(DaoUtil.convertNullToString(rs.getString("lpadSort")));
        dto.setAvailFlg(DaoUtil.convertNullToString(rs.getString("availFlg")));
        dto.setShowIf(DaoUtil.convertNullToString(rs.getString("showIf")));
        dto.setMenuPtn(DaoUtil.convertNullToString(rs.getString("menuPtn")));
        return dto;
    }

    public List<CareerMenuActiveDto> selectMenuByGrp(String menuGrp, String guid) {

        final String sql = "SELECT " + ALLCOLS + " FROM CAREER_MENU_ACTIVE WHERE GUID=? AND MENU_GRP=? ORDER BY LPAD_SORT";
        Log.sql("[DaoMethod Call] CareerMenuActiveDao.selectMenuByGrp");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, menuGrp);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, guid);
            rs = pstmt.executeQuery();
            List<CareerMenuActiveDto> lst = new ArrayList<CareerMenuActiveDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CareerMenuActiveDto> selectOneMenu(String guid, String menuGrp, String menuId) {

        final String sql = "SELECT " + ALLCOLS + " FROM CAREER_MENU_ACTIVE WHERE GUID=? AND MENU_GRP=? AND MENU_ID=?";
        Log.sql("[DaoMethod Call] CareerMenuActiveDao.selectOneMenu");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, guid);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, menuGrp);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, menuId);
            rs = pstmt.executeQuery();
            List<CareerMenuActiveDto> lst = new ArrayList<CareerMenuActiveDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

