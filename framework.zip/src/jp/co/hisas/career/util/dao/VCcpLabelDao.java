/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.VCcpLabelDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class VCcpLabelDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " PARTY as party,"
                     + " LABEL_ID as labelId,"
                     + " LABEL_TEXT as labelText,"
                     + " LABEL_TEXT_L2 as labelTextL2,"
                     + " LABEL_TEXT_L3 as labelTextL3"
                     ;

    public VCcpLabelDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public VCcpLabelDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public VCcpLabelDto select(String party, String labelId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM V_CCP_LABEL"
                         + " WHERE PARTY = ?"
                         + " AND LABEL_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] VCcpLabelDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, party);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, labelId);
            rs = pstmt.executeQuery();
            VCcpLabelDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    private VCcpLabelDto transferRsToDto(ResultSet rs) throws SQLException {

        VCcpLabelDto dto = new VCcpLabelDto();
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setLabelId(DaoUtil.convertNullToString(rs.getString("labelId")));
        dto.setLabelText(DaoUtil.convertNullToString(rs.getString("labelText")));
        dto.setLabelTextL2(DaoUtil.convertNullToString(rs.getString("labelTextL2")));
        dto.setLabelTextL3(DaoUtil.convertNullToString(rs.getString("labelTextL3")));
        return dto;
    }

    public List<VCcpLabelDto> selectAll() {

        final String sql = "SELECT " + ALLCOLS + " FROM V_CCP_LABEL";
        Log.sql("[DaoMethod Call] VCcpLabelDao.selectAll");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            List<VCcpLabelDto> lst = new ArrayList<VCcpLabelDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

