/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jp.co.hisas.career.util.dto.LygAccountPropertyDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

/**
 * PORTALアカウント属性 Data Access Object。
 * @author CareerDaoTool.xla
*/
public class LygAccountPropertyDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " ACCOUNT_ID as accountId,"
                     + " LAST_LOGIN_DATETIME as lastLoginDatetime,"
                     + " LAST_OPERATION_DATETIME as lastOperationDatetime,"
                     + " LAST_LOGOUT_DATETIME as lastLogoutDatetime,"
                     + " SELECTED_LANGUAGE_ID as selectedLanguageId"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public LygAccountPropertyDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public LygAccountPropertyDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param accountId アカウントID
     * @return LygAccountPropertyDto LYG_ACCOUNT_PROPERTYのレコード型データ。
     */ 
    public LygAccountPropertyDto select(String accountId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM LYG_ACCOUNT_PROPERTY"
                         + " WHERE ACCOUNT_ID = ?"
                         ;
        Log.sql("【DaoMethod Call】 LygAccountPropertyDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, accountId);
            rs = pstmt.executeQuery();
            LygAccountPropertyDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private LygAccountPropertyDto transferRsToDto(ResultSet rs) throws SQLException {

        LygAccountPropertyDto dto = new LygAccountPropertyDto();
        dto.setAccountId(DaoUtil.convertNullToString(rs.getString("accountId")));
        dto.setLastLoginDatetime(DaoUtil.convertNullToString(rs.getString("lastLoginDatetime")));
        dto.setLastOperationDatetime(DaoUtil.convertNullToString(rs.getString("lastOperationDatetime")));
        dto.setLastLogoutDatetime(DaoUtil.convertNullToString(rs.getString("lastLogoutDatetime")));
        dto.setSelectedLanguageId(DaoUtil.convertNullToString(rs.getString("selectedLanguageId")));
        return dto;
    }

}

