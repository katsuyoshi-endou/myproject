/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.CjsNinsyouRsvDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CjsNinsyouRsvDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " SIMEI_NO as simeiNo,"
                     + " PASSWORD as password"
                     ;

    public CjsNinsyouRsvDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CjsNinsyouRsvDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public void insert(CjsNinsyouRsvDto dto) {

        final String sql = "INSERT INTO CJS_NINSYOU_RSV ("
                         + "SIMEI_NO,"
                         + "PASSWORD"
                         + ")VALUES(?,? )"
                         ;
        Log.sql("[DaoMethod Call] CjsNinsyouRsvDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getSimeiNo());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getPassword());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void update(CjsNinsyouRsvDto dto) {

        final String sql = "UPDATE CJS_NINSYOU_RSV SET "
                         + "PASSWORD = ?"
                         + " WHERE SIMEI_NO = ?"
                         ;
        Log.sql("[DaoMethod Call] CjsNinsyouRsvDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getPassword());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getSimeiNo());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void delete(String simeiNo) {

        final String sql = "DELETE FROM CJS_NINSYOU_RSV"
                         + " WHERE SIMEI_NO = ?"
                         ;
        Log.sql("[DaoMethod Call] CjsNinsyouRsvDao.delete");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, simeiNo);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally { 
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public CjsNinsyouRsvDto select(String simeiNo) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CJS_NINSYOU_RSV"
                         + " WHERE SIMEI_NO = ?"
                         ;
        Log.sql("[DaoMethod Call] CjsNinsyouRsvDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, simeiNo);
            rs = pstmt.executeQuery();
            CjsNinsyouRsvDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CjsNinsyouRsvDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CjsNinsyouRsvDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CjsNinsyouRsvDto> lst = new ArrayList<CjsNinsyouRsvDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CjsNinsyouRsvDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CjsNinsyouRsvDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("[DaoMethod Call] CjsNinsyouRsvDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void executeDynamic(String sql) {

        Log.sql("[DaoMethod Call] CjsNinsyouRsvDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    private CjsNinsyouRsvDto transferRsToDto(ResultSet rs) throws SQLException {

        CjsNinsyouRsvDto dto = new CjsNinsyouRsvDto();
        dto.setSimeiNo(DaoUtil.convertNullToString(rs.getString("simeiNo")));
        dto.setPassword(DaoUtil.convertNullToString(rs.getString("password")));
        return dto;
    }

}

