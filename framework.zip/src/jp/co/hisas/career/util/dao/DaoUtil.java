/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.util.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;

/**
 * Daoから使用するユーティリティクラス。
 * @author k-nishihara
 */
public class DaoUtil {

    /**
     * SQLのLIKE検索でエスケープする文字列。
     */
    private static final char[] TARGET_TOKENS = {'\\', '%', '％', '_', '＿'};

    /**
     * Stringがnullの場合、空文字に置換する。
     * @param str 対象文字列。
     */
    public static String convertNullToString(final String str) {
        return str != null ? str : "";
    }

    /**
     * PreparedStatementにVarcharのパラメータを設定する(nullの場合を考慮)。
     * @param pstmt 設定対象のPreparedStatement。
     * @param index PreparedStatementに設定するindex。
     * @param str PreparedStatementに設定する文字列。
     */
    public static void setVarcharToPreparedStatement(PreparedStatement pstmt,
            int index, String str) throws SQLException {
        if (str == null) {
            pstmt.setNull(index, java.sql.Types.VARCHAR);
        } else {
            pstmt.setString(index, str);
        }
    }

    /**
     * PreparedStatementに前方一致用のVarcharのパラメータを設定する(nullの場合を考慮)。
     * @param pstmt 設定対象のPreparedStatement。
     * @param index PreparedStatementに設定するindex。
     * @param str PreparedStatementに設定する文字列。
     */
    public static void setVarcharToPreparedStatementForForwardSearch(PreparedStatement pstmt,
            int index, String str) throws SQLException {
        if (str == null) {
            pstmt.setNull(index, java.sql.Types.VARCHAR);
        } else {
            pstmt.setString(index, makeForwardSearchParameter(str));
        }
    }

    /**
     * PreparedStatementに後方一致用のVarcharのパラメータを設定する(nullの場合を考慮)。
     * @param pstmt 設定対象のPreparedStatement。
     * @param index PreparedStatementに設定するindex。
     * @param str PreparedStatementに設定する文字列。
     */
    public static void setVarcharToPreparedStatementForBackwardSearch(PreparedStatement pstmt,
            int index, String str) throws SQLException {
        if (str == null) {
            pstmt.setNull(index, java.sql.Types.VARCHAR);
        } else {
            pstmt.setString(index, makeBackwardSearchParameter(str));
        }
    }
    
    /**
     * PreparedStatementに前方後方一致用のVarcharのパラメータを設定する(nullの場合を考慮)。
     * @param pstmt 設定対象のPreparedStatement。
     * @param index PreparedStatementに設定するindex。
     * @param str PreparedStatementに設定する文字列。
     */
    public static void setVarcharToPreparedStatementForPartialSearch(PreparedStatement pstmt,
            int index, String str) throws SQLException {
        if (str == null) {
            pstmt.setNull(index, java.sql.Types.VARCHAR);
        } else {
            pstmt.setString(index, makePartialSearchParameter(str));
        }
    }

    /**
     * PreparedStatementにCharのパラメータを設定する(nullの場合を考慮)。
     * @param pstmt 設定対象のPreparedStatement。
     * @param index PreparedStatementに設定するindex。
     * @param str PreparedStatementに設定する文字列。
     */
    public static void setCharToPreparedStatement(PreparedStatement pstmt,
            int index, String str) throws SQLException {
        if (str == null) {
            pstmt.setNull(index, java.sql.Types.CHAR);
        } else {
            pstmt.setString(index, str);
        }
    }

    /**
     * PreparedStatementにIntegerのパラメータを設定する(nullの場合を考慮)。
     * @param pstmt 設定対象のPreparedStatement。
     * @param index PreparedStatementに設定するindex。
     * @param val PreparedStatementに設定するIntegerの値。
     */
    public static void setIntToPreparedStatement(PreparedStatement pstmt,
            int index, Integer val) throws SQLException {
        if (val == null) {
            pstmt.setNull(index, java.sql.Types.INTEGER);
        } else {
            pstmt.setInt(index, val.intValue()); // INT
        }
    }
    
// ADD 2010/08/05 y-yashiro getInt対応 START 
    /**
     * PreparedStatementにDoubleのパラメータを設定する(nullの場合を考慮)。
     * @param pstmt 設定対象のPreparedStatement。
     * @param index PreparedStatementに設定するindex。
     * @param val PreparedStatementに設定するDoubleの値。
     */
    public static void setDoubleToPreparedStatement(PreparedStatement pstmt,
            int index, Double val) throws SQLException {
        if (val == null) {
            pstmt.setNull(index, java.sql.Types.DOUBLE);
        } else {
            pstmt.setDouble(index, val.doubleValue()); 
        }
    }
// ADD 2010/08/05 y-yashiro getInt対応 END 

    /**
     * 前方一致の LIKE 文で使用するために、SQL の引数文字列の末尾に % を付加する。
     * 引数の内容にもとから % _ \ が含まれている場合、 \ を前置してエスケープする。
     * @param param SQL の実引数 (置換前)
     * @return SQL の実引数 (置換後)
     */
    public static String makeForwardSearchParameter(String param) {
        return (param == null) ? null : escapeLikeParameter(param) + '%';
    }

    /**
     * 後方一致の LIKE 文で使用するために、SQL の引数文字列の先頭に % を付加する。
     * 引数の内容にもとから % _ \ が含まれている場合、 \ を前置してエスケープする。
     * @param param SQL の実引数 (置換前)
     * @return SQL の実引数 (置換後)
     */
    public static String makeBackwardSearchParameter(String param) {
        return (param == null) ? null : '%' + escapeLikeParameter(param);
    }

    /**
     * 部分一致の LIKE 文で使用するために、SQL の引数文字列の先頭と末尾に % を付加する。
     * 引数の内容にもとから % _ \ が含まれている場合、 \ を前置してエスケープする。
     * @param param SQL の実引数 (置換前)
     * @return SQL の実引数 (置換後)
     */
    public static String makePartialSearchParameter(String param) {
        return (param == null) ? null : '%' + escapeLikeParameter(param) + '%';
    }

    /**
     * 引数の内容に % _ \ が含まれている場合、 \ を前置してエスケープする。
     * @param param SQL の実引数 (置換前)
     * @return SQL の実引数 (置換後)
     */
    public static String escapeLikeParameter(String param) {
        String result = param;
        if (result != null) {
            // result 内の % , _ , \ を、\% と \_ と \\ に置換する。
            for (char token : TARGET_TOKENS) {
                result = result.replace(String.valueOf(token), "\\" + token);
            }
        }
        return result;
    }
    
    /**
     * 'のエスケープ
     * @param 対象文字列
     * @return 変換後文字列
     */
    public static String escape(String str){
        return str.replaceAll("'", "''");
    }

    /**
     * 指定したExceptionがロック失敗の場合Trueを返す。Oracle用。
     * @param ex
     * @return
     */
    public static boolean isLockException(Exception ex){
        if (ex instanceof SQLException){
            int code = ((SQLException) ex).getErrorCode();
            if(code == 54 || code == 30006){
                return true;
            }
        }
        return false;
    }
    
    /**
     * 指定したExceptionがユニーク制約エラーの場合Trueを返す。Oracle用。
     * @param ex
     * @return
     */
    public static boolean isUniqueException(Exception ex){
        if (ex instanceof SQLException && ((SQLException) ex).getErrorCode() == 1){
                return true;
        }
        return false;
    }

	/**
	 * 動的生成したSQLと ? に入れるパラメータリスト(setVarchar限定)で作った pstmt を返す。
	 */
	public static PreparedStatement getPstmt( StringBuilder sql, List<String> paramList ) {
		return getPstmt( sql.toString(), paramList );
	}
	public static PreparedStatement getPstmt( String sql, List<String> paramList ) {
		Connection conn = PZZ040_SQLUtility.getCachedConnection();
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement( sql );
			for (int i = 0; i < paramList.size(); i++) {
				String param = (String)paramList.get( i );
				DaoUtil.setVarcharToPreparedStatement( pstmt, i + 1, param );
			}
		} catch (SQLException e) {
			PZZ040_SQLUtility.removeCachedConnection();
			throw new CareerSQLException( e );
		}
		return pstmt;
	}

}
