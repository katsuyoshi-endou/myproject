/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dto.CaGatePasswordResetDto;
import jp.co.hisas.career.util.log.Log;

public class CaGatePasswordResetDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " SIGN as sign,"
                     + " PID as pid,"
                     + " TIMESTAMP as timestamp,"
                     + " RESET_TOKEN as resetToken,"
                     + " AVAIL_FLG as availFlg"
                     ;

    public CaGatePasswordResetDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CaGatePasswordResetDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public void insert(CaGatePasswordResetDto dto) {

        final String sql = "INSERT INTO CA_GATE_PASSWORD_RESET ("
                         + "SIGN,"
                         + "PID,"
                         + "TIMESTAMP,"
                         + "RESET_TOKEN,"
                         + "AVAIL_FLG"
                         + ")VALUES(?,?,?,?,? )"
                         ;
        Log.sql("[DaoMethod Call] CaGatePasswordResetDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getSign());
            DaoUtil.setIntToPreparedStatement(pstmt, 2, dto.getPid());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getTimestamp());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getResetToken());
            DaoUtil.setIntToPreparedStatement(pstmt, 5, dto.getAvailFlg());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void update(CaGatePasswordResetDto dto) {

        final String sql = "UPDATE CA_GATE_PASSWORD_RESET SET "
                         + "PID = ?,"
                         + "RESET_TOKEN = ?,"
                         + "AVAIL_FLG = ?"
                         + " WHERE SIGN = ?"
                         + " AND TIMESTAMP = ?"
                         ;
        Log.sql("[DaoMethod Call] CaGatePasswordResetDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setIntToPreparedStatement(pstmt, 1, dto.getPid());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getResetToken());
            DaoUtil.setIntToPreparedStatement(pstmt, 3, dto.getAvailFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getSign());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getTimestamp());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public CaGatePasswordResetDto select(String sign, String timestamp) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CA_GATE_PASSWORD_RESET"
                         + " WHERE SIGN = ?"
                         + " AND TIMESTAMP = ?"
                         ;
        Log.sql("[DaoMethod Call] CaGatePasswordResetDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, sign);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, timestamp);
            rs = pstmt.executeQuery();
            CaGatePasswordResetDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CaGatePasswordResetDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CaGatePasswordResetDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CaGatePasswordResetDto> lst = new ArrayList<CaGatePasswordResetDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CaGatePasswordResetDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CaGatePasswordResetDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("[DaoMethod Call] CaGatePasswordResetDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void executeDynamic(String sql) {

        Log.sql("[DaoMethod Call] CaGatePasswordResetDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    private CaGatePasswordResetDto transferRsToDto(ResultSet rs) throws SQLException {

        CaGatePasswordResetDto dto = new CaGatePasswordResetDto();
        dto.setSign(DaoUtil.convertNullToString(rs.getString("sign")));
        dto.setPid(rs.getInt("pid"));
        dto.setTimestamp(DaoUtil.convertNullToString(rs.getString("timestamp")));
        dto.setResetToken(DaoUtil.convertNullToString(rs.getString("resetToken")));
        dto.setAvailFlg(rs.getInt("availFlg"));
        return dto;
    }

}

