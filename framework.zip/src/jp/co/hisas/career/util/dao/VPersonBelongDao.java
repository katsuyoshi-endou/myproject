/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.VPersonBelongDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class VPersonBelongDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " CMPA_CD as cmpaCd,"
                     + " STF_NO as stfNo,"
                     + " PERSON_NAME as personName,"
                     + " DEPT_CD as deptCd,"
                     + " DEPT_NM as deptNm,"
                     + " CLS_A_CD as clsACd,"
                     + " CLS_A_NM as clsANm,"
                     + " CLS_A_SORT as clsASort,"
                     + " CLS_B_CD as clsBCd,"
                     + " CLS_B_NM as clsBNm,"
                     + " CLS_B_SORT as clsBSort,"
                     + " CLS_C_CD as clsCCd,"
                     + " CLS_C_NM as clsCNm,"
                     + " CLS_C_SORT as clsCSort,"
                     + " CLS_D_CD as clsDCd,"
                     + " CLS_D_NM as clsDNm,"
                     + " CLS_D_SORT as clsDSort,"
                     + " CLS_E_CD as clsECd,"
                     + " CLS_E_NM as clsENm,"
                     + " CLS_E_SORT as clsESort,"
                     + " CLS_F_CD as clsFCd,"
                     + " CLS_F_NM as clsFNm,"
                     + " CLS_F_SORT as clsFSort,"
                     + " CLS_G_CD as clsGCd,"
                     + " CLS_G_NM as clsGNm,"
                     + " CLS_G_SORT as clsGSort,"
                     + " CLS_H_CD as clsHCd,"
                     + " CLS_H_NM as clsHNm,"
                     + " CLS_H_SORT as clsHSort,"
                     + " CLS_I_CD as clsICd,"
                     + " CLS_I_NM as clsINm,"
                     + " CLS_I_SORT as clsISort,"
                     + " CLS_J_CD as clsJCd,"
                     + " CLS_J_NM as clsJNm,"
                     + " CLS_J_SORT as clsJSort,"
                     + " CLS_K_CD as clsKCd,"
                     + " CLS_K_NM as clsKNm,"
                     + " CLS_K_SORT as clsKSort,"
                     + " CLS_L_CD as clsLCd,"
                     + " CLS_L_NM as clsLNm,"
                     + " CLS_L_SORT as clsLSort,"
                     + " CLS_M_CD as clsMCd,"
                     + " CLS_M_NM as clsMNm,"
                     + " CLS_M_SORT as clsMSort,"
                     + " CLS_N_CD as clsNCd,"
                     + " CLS_N_NM as clsNNm,"
                     + " CLS_N_SORT as clsNSort,"
                     + " TXT_A as txtA,"
                     + " TXT_B as txtB,"
                     + " TXT_C as txtC,"
                     + " TXT_D as txtD,"
                     + " TXT_E as txtE,"
                     + " TXT_F as txtF,"
                     + " TXT_G as txtG,"
                     + " TXT_H as txtH,"
                     + " TXT_I as txtI,"
                     + " TXT_J as txtJ,"
                     + " TXT_K as txtK,"
                     + " TXT_L as txtL,"
                     + " TXT_M as txtM,"
                     + " TXT_N as txtN"
                     ;

    public VPersonBelongDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public VPersonBelongDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public VPersonBelongDto select(String cmpaCd, String stfNo) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM V_PERSON_BELONG"
                         + " WHERE CMPA_CD = ?"
                         + " AND STF_NO = ?"
                         ;
        Log.sql("[DaoMethod Call] VPersonBelongDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, cmpaCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, stfNo);
            rs = pstmt.executeQuery();
            VPersonBelongDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<VPersonBelongDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] VPersonBelongDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<VPersonBelongDto> lst = new ArrayList<VPersonBelongDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<VPersonBelongDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] VPersonBelongDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private VPersonBelongDto transferRsToDto(ResultSet rs) throws SQLException {

        VPersonBelongDto dto = new VPersonBelongDto();
        dto.setCmpaCd(DaoUtil.convertNullToString(rs.getString("cmpaCd")));
        dto.setStfNo(DaoUtil.convertNullToString(rs.getString("stfNo")));
        dto.setPersonName(DaoUtil.convertNullToString(rs.getString("personName")));
        dto.setDeptCd(DaoUtil.convertNullToString(rs.getString("deptCd")));
        dto.setDeptNm(DaoUtil.convertNullToString(rs.getString("deptNm")));
        dto.setClsACd(DaoUtil.convertNullToString(rs.getString("clsACd")));
        dto.setClsANm(DaoUtil.convertNullToString(rs.getString("clsANm")));
        dto.setClsASort(DaoUtil.convertNullToString(rs.getString("clsASort")));
        dto.setClsBCd(DaoUtil.convertNullToString(rs.getString("clsBCd")));
        dto.setClsBNm(DaoUtil.convertNullToString(rs.getString("clsBNm")));
        dto.setClsBSort(DaoUtil.convertNullToString(rs.getString("clsBSort")));
        dto.setClsCCd(DaoUtil.convertNullToString(rs.getString("clsCCd")));
        dto.setClsCNm(DaoUtil.convertNullToString(rs.getString("clsCNm")));
        dto.setClsCSort(DaoUtil.convertNullToString(rs.getString("clsCSort")));
        dto.setClsDCd(DaoUtil.convertNullToString(rs.getString("clsDCd")));
        dto.setClsDNm(DaoUtil.convertNullToString(rs.getString("clsDNm")));
        dto.setClsDSort(DaoUtil.convertNullToString(rs.getString("clsDSort")));
        dto.setClsECd(DaoUtil.convertNullToString(rs.getString("clsECd")));
        dto.setClsENm(DaoUtil.convertNullToString(rs.getString("clsENm")));
        dto.setClsESort(DaoUtil.convertNullToString(rs.getString("clsESort")));
        dto.setClsFCd(DaoUtil.convertNullToString(rs.getString("clsFCd")));
        dto.setClsFNm(DaoUtil.convertNullToString(rs.getString("clsFNm")));
        dto.setClsFSort(DaoUtil.convertNullToString(rs.getString("clsFSort")));
        dto.setClsGCd(DaoUtil.convertNullToString(rs.getString("clsGCd")));
        dto.setClsGNm(DaoUtil.convertNullToString(rs.getString("clsGNm")));
        dto.setClsGSort(DaoUtil.convertNullToString(rs.getString("clsGSort")));
        dto.setClsHCd(DaoUtil.convertNullToString(rs.getString("clsHCd")));
        dto.setClsHNm(DaoUtil.convertNullToString(rs.getString("clsHNm")));
        dto.setClsHSort(DaoUtil.convertNullToString(rs.getString("clsHSort")));
        dto.setClsICd(DaoUtil.convertNullToString(rs.getString("clsICd")));
        dto.setClsINm(DaoUtil.convertNullToString(rs.getString("clsINm")));
        dto.setClsISort(DaoUtil.convertNullToString(rs.getString("clsISort")));
        dto.setClsJCd(DaoUtil.convertNullToString(rs.getString("clsJCd")));
        dto.setClsJNm(DaoUtil.convertNullToString(rs.getString("clsJNm")));
        dto.setClsJSort(DaoUtil.convertNullToString(rs.getString("clsJSort")));
        dto.setClsKCd(DaoUtil.convertNullToString(rs.getString("clsKCd")));
        dto.setClsKNm(DaoUtil.convertNullToString(rs.getString("clsKNm")));
        dto.setClsKSort(DaoUtil.convertNullToString(rs.getString("clsKSort")));
        dto.setClsLCd(DaoUtil.convertNullToString(rs.getString("clsLCd")));
        dto.setClsLNm(DaoUtil.convertNullToString(rs.getString("clsLNm")));
        dto.setClsLSort(DaoUtil.convertNullToString(rs.getString("clsLSort")));
        dto.setClsMCd(DaoUtil.convertNullToString(rs.getString("clsMCd")));
        dto.setClsMNm(DaoUtil.convertNullToString(rs.getString("clsMNm")));
        dto.setClsMSort(DaoUtil.convertNullToString(rs.getString("clsMSort")));
        dto.setClsNCd(DaoUtil.convertNullToString(rs.getString("clsNCd")));
        dto.setClsNNm(DaoUtil.convertNullToString(rs.getString("clsNNm")));
        dto.setClsNSort(DaoUtil.convertNullToString(rs.getString("clsNSort")));
        dto.setTxtA(DaoUtil.convertNullToString(rs.getString("txtA")));
        dto.setTxtB(DaoUtil.convertNullToString(rs.getString("txtB")));
        dto.setTxtC(DaoUtil.convertNullToString(rs.getString("txtC")));
        dto.setTxtD(DaoUtil.convertNullToString(rs.getString("txtD")));
        dto.setTxtE(DaoUtil.convertNullToString(rs.getString("txtE")));
        dto.setTxtF(DaoUtil.convertNullToString(rs.getString("txtF")));
        dto.setTxtG(DaoUtil.convertNullToString(rs.getString("txtG")));
        dto.setTxtH(DaoUtil.convertNullToString(rs.getString("txtH")));
        dto.setTxtI(DaoUtil.convertNullToString(rs.getString("txtI")));
        dto.setTxtJ(DaoUtil.convertNullToString(rs.getString("txtJ")));
        dto.setTxtK(DaoUtil.convertNullToString(rs.getString("txtK")));
        dto.setTxtL(DaoUtil.convertNullToString(rs.getString("txtL")));
        dto.setTxtM(DaoUtil.convertNullToString(rs.getString("txtM")));
        dto.setTxtN(DaoUtil.convertNullToString(rs.getString("txtN")));
        return dto;
    }

}

