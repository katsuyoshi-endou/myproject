/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.CaRegistDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CaRegistDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " CMPA_CD as cmpaCd,"
                     + " STF_NO as stfNo,"
                     + " GUID as guid,"
                     + " PERSON_NAME as personName,"
                     + " PERSON_NAME_L2 as personNameL2,"
                     + " PERSON_NAME_L3 as personNameL3,"
                     + " PERSON_NAME_KANA as personNameKana,"
                     + " MAIL_ADDRESS as mailAddress,"
                     + " HIRED_DATE as hiredDate,"
                     + " RETIRE_DATE as retireDate,"
                     + " REGIST_FLG as registFlg,"
                     + " MAIN_FLG as mainFlg,"
                     + " GNSK_FLG as gnskFlg,"
                     + " FOLLOW_FLG as followFlg,"
                     + " DEPT_HIER_RANK as deptHierRank"
                     ;

    public CaRegistDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CaRegistDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public void insert(CaRegistDto dto) {

        final String sql = "INSERT INTO CA_REGIST ("
                         + "CMPA_CD,"
                         + "STF_NO,"
                         + "GUID,"
                         + "PERSON_NAME,"
                         + "PERSON_NAME_L2,"
                         + "PERSON_NAME_L3,"
                         + "PERSON_NAME_KANA,"
                         + "MAIL_ADDRESS,"
                         + "HIRED_DATE,"
                         + "RETIRE_DATE,"
                         + "REGIST_FLG,"
                         + "MAIN_FLG,"
                         + "GNSK_FLG,"
                         + "FOLLOW_FLG,"
                         + "DEPT_HIER_RANK"
                         + ")VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,? )"
                         ;
        Log.sql("[DaoMethod Call] CaRegistDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getCmpaCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getStfNo());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getGuid());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getPersonName());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getPersonNameL2());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getPersonNameL3());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getPersonNameKana());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 8, dto.getMailAddress());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 9, dto.getHiredDate());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 10, dto.getRetireDate());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 11, dto.getRegistFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 12, dto.getMainFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 13, dto.getGnskFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 14, dto.getFollowFlg());
            DaoUtil.setIntToPreparedStatement(pstmt, 15, dto.getDeptHierRank());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void update(CaRegistDto dto) {

        final String sql = "UPDATE CA_REGIST SET "
                         + "GUID = ?,"
                         + "PERSON_NAME = ?,"
                         + "PERSON_NAME_L2 = ?,"
                         + "PERSON_NAME_L3 = ?,"
                         + "PERSON_NAME_KANA = ?,"
                         + "MAIL_ADDRESS = ?,"
                         + "HIRED_DATE = ?,"
                         + "RETIRE_DATE = ?,"
                         + "REGIST_FLG = ?,"
                         + "MAIN_FLG = ?,"
                         + "GNSK_FLG = ?,"
                         + "FOLLOW_FLG = ?,"
                         + "DEPT_HIER_RANK = ?"
                         + " WHERE CMPA_CD = ?"
                         + " AND STF_NO = ?"
                         ;
        Log.sql("[DaoMethod Call] CaRegistDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getGuid());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getPersonName());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getPersonNameL2());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getPersonNameL3());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getPersonNameKana());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getMailAddress());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getHiredDate());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 8, dto.getRetireDate());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 9, dto.getRegistFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 10, dto.getMainFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 11, dto.getGnskFlg());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 12, dto.getFollowFlg());
            DaoUtil.setIntToPreparedStatement(pstmt, 13, dto.getDeptHierRank());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 14, dto.getCmpaCd());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 15, dto.getStfNo());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public CaRegistDto select(String cmpaCd, String stfNo) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CA_REGIST"
                         + " WHERE CMPA_CD = ?"
                         + " AND STF_NO = ?"
                         ;
        Log.sql("[DaoMethod Call] CaRegistDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, cmpaCd);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, stfNo);
            rs = pstmt.executeQuery();
            CaRegistDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CaRegistDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CaRegistDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CaRegistDto> lst = new ArrayList<CaRegistDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CaRegistDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CaRegistDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("[DaoMethod Call] CaRegistDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void executeDynamic(String sql) {

        Log.sql("[DaoMethod Call] CaRegistDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    private CaRegistDto transferRsToDto(ResultSet rs) throws SQLException {

        CaRegistDto dto = new CaRegistDto();
        dto.setCmpaCd(DaoUtil.convertNullToString(rs.getString("cmpaCd")));
        dto.setStfNo(DaoUtil.convertNullToString(rs.getString("stfNo")));
        dto.setGuid(DaoUtil.convertNullToString(rs.getString("guid")));
        dto.setPersonName(DaoUtil.convertNullToString(rs.getString("personName")));
        dto.setPersonNameL2(DaoUtil.convertNullToString(rs.getString("personNameL2")));
        dto.setPersonNameL3(DaoUtil.convertNullToString(rs.getString("personNameL3")));
        dto.setPersonNameKana(DaoUtil.convertNullToString(rs.getString("personNameKana")));
        dto.setMailAddress(DaoUtil.convertNullToString(rs.getString("mailAddress")));
        dto.setHiredDate(DaoUtil.convertNullToString(rs.getString("hiredDate")));
        dto.setRetireDate(DaoUtil.convertNullToString(rs.getString("retireDate")));
        dto.setRegistFlg(DaoUtil.convertNullToString(rs.getString("registFlg")));
        dto.setMainFlg(DaoUtil.convertNullToString(rs.getString("mainFlg")));
        dto.setGnskFlg(DaoUtil.convertNullToString(rs.getString("gnskFlg")));
        dto.setFollowFlg(DaoUtil.convertNullToString(rs.getString("followFlg")));
        dto.setDeptHierRank(rs.getInt("deptHierRank"));
        return dto;
    }

}

