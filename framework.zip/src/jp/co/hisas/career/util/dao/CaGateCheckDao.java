/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.CaGateCheckDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CaGateCheckDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " PID as pid,"
                     + " NEEDS_RESET_FLG as needsResetFlg,"
                     + " LOCKED_FLG as lockedFlg"
                     ;

    public CaGateCheckDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CaGateCheckDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public void insert(CaGateCheckDto dto) {

        final String sql = "INSERT INTO CA_GATE_CHECK ("
                         + "PID,"
                         + "NEEDS_RESET_FLG,"
                         + "LOCKED_FLG"
                         + ")VALUES(?,?,? )"
                         ;
        Log.sql("[DaoMethod Call] CaGateCheckDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setIntToPreparedStatement(pstmt, 1, dto.getPid());
            DaoUtil.setIntToPreparedStatement(pstmt, 2, dto.getNeedsResetFlg());
            DaoUtil.setIntToPreparedStatement(pstmt, 3, dto.getLockedFlg());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void update(CaGateCheckDto dto) {

        final String sql = "UPDATE CA_GATE_CHECK SET "
                         + "NEEDS_RESET_FLG = ?,"
                         + "LOCKED_FLG = ?"
                         + " WHERE PID = ?"
                         ;
        Log.sql("[DaoMethod Call] CaGateCheckDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setIntToPreparedStatement(pstmt, 1, dto.getNeedsResetFlg());
            DaoUtil.setIntToPreparedStatement(pstmt, 2, dto.getLockedFlg());
            DaoUtil.setIntToPreparedStatement(pstmt, 3, dto.getPid());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void delete(Integer pid) {

        final String sql = "DELETE FROM CA_GATE_CHECK"
                         + " WHERE PID = ?"
                         ;
        Log.sql("[DaoMethod Call] CaGateCheckDao.delete");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setIntToPreparedStatement(pstmt, 1, pid);
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally { 
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public CaGateCheckDto select(Integer pid) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CA_GATE_CHECK"
                         + " WHERE PID = ?"
                         ;
        Log.sql("[DaoMethod Call] CaGateCheckDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setIntToPreparedStatement(pstmt, 1, pid);
            rs = pstmt.executeQuery();
            CaGateCheckDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CaGateCheckDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CaGateCheckDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CaGateCheckDto> lst = new ArrayList<CaGateCheckDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CaGateCheckDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CaGateCheckDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("[DaoMethod Call] CaGateCheckDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void executeDynamic(String sql) {

        Log.sql("[DaoMethod Call] CaGateCheckDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    private CaGateCheckDto transferRsToDto(ResultSet rs) throws SQLException {

        CaGateCheckDto dto = new CaGateCheckDto();
        dto.setPid(rs.getInt("pid"));
        dto.setNeedsResetFlg(rs.getInt("needsResetFlg"));
        dto.setLockedFlg(rs.getInt("lockedFlg"));
        return dto;
    }

}

