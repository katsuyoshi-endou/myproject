package jp.co.hisas.career.util.dao.useful;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;

public class SqlPropDao extends CoreDao {
	
	public SqlPropDao(String loginNo) {
		super( loginNo );
	}
	
	public Map<Integer, List<String>> select( PreparedStatement pstmt ) {
		
		Log.sql( "【DaoMethod Call】 " + Class.class.getName() + ".selectDynamic" );
		ResultSet rs = null;
		try {
			rs = pstmt.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			int colCnt = rsmd.getColumnCount();
			List<String> colNameList = new ArrayList<String>();
			for (int i = 1; i <= colCnt; i++) {
				colNameList.add( rsmd.getColumnName( i ) );
			}
			
			Map<Integer, List<String>> rows = new LinkedHashMap<Integer, List<String>>();
						
			int idx = 1;
			while (rs.next()) {
				rows.put( idx, transferRsToDto( colNameList, rs ) );
				idx++;
			}
			return rows;
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, rs );
		}
	}
	
	public List<String> transferRsToDto( List<String> colNameList, ResultSet rs ) throws SQLException {
		List<String> cols = new ArrayList<String>();
		for (String colName : colNameList) {
			cols.add( SU.ntb( rs.getString( colName ) ) );
		}
		return cols;
	}
	
	public ResultSet getResulSet( PreparedStatement pstmt ) {
		
		Log.sql( "【DaoMethod Call】 " + Class.class.getName() + ".selectDynamic" );
		ResultSet rs = null;
		try {
			rs = pstmt.executeQuery();						
			return rs;
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		}
	}
}
