/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.PulldownMasterDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class PulldownMasterDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " PD_SET_CD as pdSetCd,"
                     + " PD_VALUE as pdValue,"
                     + " PD_TEXT as pdText,"
                     + " LPAD_SORT as lpadSort"
                     ;

    public PulldownMasterDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public PulldownMasterDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public List<PulldownMasterDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] PulldownMasterDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<PulldownMasterDto> lst = new ArrayList<PulldownMasterDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<PulldownMasterDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] PulldownMasterDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private PulldownMasterDto transferRsToDto(ResultSet rs) throws SQLException {

        PulldownMasterDto dto = new PulldownMasterDto();
        dto.setPdSetCd(DaoUtil.convertNullToString(rs.getString("pdSetCd")));
        dto.setPdValue(DaoUtil.convertNullToString(rs.getString("pdValue")));
        dto.setPdText(DaoUtil.convertNullToString(rs.getString("pdText")));
        dto.setLpadSort(DaoUtil.convertNullToString(rs.getString("lpadSort")));
        return dto;
    }

}

