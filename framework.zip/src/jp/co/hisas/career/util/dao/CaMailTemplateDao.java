/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dto.CaMailTemplateDto;
import jp.co.hisas.career.util.log.Log;

public class CaMailTemplateDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " PARTY as party,"
                     + " TEMPLATE_ID as templateId,"
                     + " SUBJECT as subject,"
                     + " BODY as body"
                     ;

    public CaMailTemplateDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CaMailTemplateDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public void update(CaMailTemplateDto dto) {

        final String sql = "UPDATE CA_MAIL_TEMPLATE SET "
                         + "SUBJECT = ?,"
                         + "BODY = ?"
                         + " WHERE PARTY = ?"
                         + " AND TEMPLATE_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CaMailTemplateDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getSubject());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getBody());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getParty());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getTemplateId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public CaMailTemplateDto select(String party, String templateId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CA_MAIL_TEMPLATE"
                         + " WHERE PARTY = ?"
                         + " AND TEMPLATE_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CaMailTemplateDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, party);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, templateId);
            rs = pstmt.executeQuery();
            CaMailTemplateDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CaMailTemplateDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CaMailTemplateDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CaMailTemplateDto> lst = new ArrayList<CaMailTemplateDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CaMailTemplateDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CaMailTemplateDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    private CaMailTemplateDto transferRsToDto(ResultSet rs) throws SQLException {

        CaMailTemplateDto dto = new CaMailTemplateDto();
        dto.setParty(DaoUtil.convertNullToString(rs.getString("party")));
        dto.setTemplateId(DaoUtil.convertNullToString(rs.getString("templateId")));
        dto.setSubject(DaoUtil.convertNullToString(rs.getString("subject")));
        dto.setBody(DaoUtil.convertNullToString(rs.getString("body")));
        return dto;
    }

}

