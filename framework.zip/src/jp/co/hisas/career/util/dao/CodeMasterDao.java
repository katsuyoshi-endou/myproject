/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.CodeMasterDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CodeMasterDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " MASTER_ID as masterId,"
                     + " MASTER_CODE as masterCode,"
                     + " MASTER_NAME as masterName,"
                     + " MASTER_ZOKUSEI1 as masterZokusei1,"
                     + " MASTER_ZOKUSEI2 as masterZokusei2,"
                     + " MASTER_ZOKUSEI3 as masterZokusei3,"
                     + " MASTER_ZOKUSEI4 as masterZokusei4,"
                     + " MASTER_ZOKUSEI5 as masterZokusei5,"
                     + " UPDATE_PERSON_ID as updatePersonId,"
                     + " UPDATE_FUNCTION as updateFunction,"
                     + " UPDATE_DATE as updateDate,"
                     + " UPDATE_TIME as updateTime"
                     ;

    public CodeMasterDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CodeMasterDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    private CodeMasterDto transferRsToDto(ResultSet rs) throws SQLException {

        CodeMasterDto dto = new CodeMasterDto();
        dto.setMasterId(DaoUtil.convertNullToString(rs.getString("masterId")));
        dto.setMasterCode(DaoUtil.convertNullToString(rs.getString("masterCode")));
        dto.setMasterName(DaoUtil.convertNullToString(rs.getString("masterName")));
        dto.setMasterZokusei1(DaoUtil.convertNullToString(rs.getString("masterZokusei1")));
        dto.setMasterZokusei2(DaoUtil.convertNullToString(rs.getString("masterZokusei2")));
        dto.setMasterZokusei3(DaoUtil.convertNullToString(rs.getString("masterZokusei3")));
        dto.setMasterZokusei4(DaoUtil.convertNullToString(rs.getString("masterZokusei4")));
        dto.setMasterZokusei5(DaoUtil.convertNullToString(rs.getString("masterZokusei5")));
        dto.setUpdatePersonId(DaoUtil.convertNullToString(rs.getString("updatePersonId")));
        dto.setUpdateFunction(DaoUtil.convertNullToString(rs.getString("updateFunction")));
        dto.setUpdateDate(DaoUtil.convertNullToString(rs.getString("updateDate")));
        dto.setUpdateTime(DaoUtil.convertNullToString(rs.getString("updateTime")));
        return dto;
    }

    public List<CodeMasterDto> selectCodeMasterAll() {

        final String sql = "SELECT " + ALLCOLS + " FROM CODE_MASTER ORDER BY MASTER_ID, ROWNUM";
        Log.sql("[DaoMethod Call] CodeMasterDao.selectCodeMasterAll");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            List<CodeMasterDto> lst = new ArrayList<CodeMasterDto>();
            while ( rs.next() ) {
                lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

}

