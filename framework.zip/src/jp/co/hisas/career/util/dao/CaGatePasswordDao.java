/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dto.CaGatePasswordDto;
import jp.co.hisas.career.util.log.Log;

public class CaGatePasswordDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " PID as pid,"
                     + " TIMESTAMP as timestamp,"
                     + " PASSWORD_HASHED as passwordHashed"
                     ;

    public CaGatePasswordDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CaGatePasswordDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public void insert(CaGatePasswordDto dto) {

        final String sql = "INSERT INTO CA_GATE_PASSWORD ("
                         + "PID,"
                         + "TIMESTAMP,"
                         + "PASSWORD_HASHED"
                         + ")VALUES(?,?,? )"
                         ;
        Log.sql("[DaoMethod Call] CaGatePasswordDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setIntToPreparedStatement(pstmt, 1, dto.getPid());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getTimestamp());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getPasswordHashed());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public CaGatePasswordDto select(Integer pid, String timestamp) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CA_GATE_PASSWORD"
                         + " WHERE PID = ?"
                         + " AND TIMESTAMP = ?"
                         ;
        Log.sql("[DaoMethod Call] CaGatePasswordDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setIntToPreparedStatement(pstmt, 1, pid);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, timestamp);
            rs = pstmt.executeQuery();
            CaGatePasswordDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CaGatePasswordDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CaGatePasswordDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CaGatePasswordDto> lst = new ArrayList<CaGatePasswordDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CaGatePasswordDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CaGatePasswordDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("[DaoMethod Call] CaGatePasswordDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void executeDynamic(String sql) {

        Log.sql("[DaoMethod Call] CaGatePasswordDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    private CaGatePasswordDto transferRsToDto(ResultSet rs) throws SQLException {

        CaGatePasswordDto dto = new CaGatePasswordDto();
        dto.setPid(rs.getInt("pid"));
        dto.setTimestamp(DaoUtil.convertNullToString(rs.getString("timestamp")));
        dto.setPasswordHashed(DaoUtil.convertNullToString(rs.getString("passwordHashed")));
        return dto;
    }

}

