/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
 !!!!!このファイルは編集しないでください!!!!!
        自動生成されたソースコードです。
        Excelブックを編集してください。

       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.HierCodeMasterDto;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * 階層コードマスタ Data Access Object。
 * @author CareerDaoTool.xla
*/
public class HierCodeMasterDao {

    /** コネクション */
    Connection conn;
    /** コネクションがコンストラクタで渡されたかどうか */
    boolean isConnectionGiven = false;
    /** ログイン社員番号 */
    String loginNo; 

    /** SELECTするカラム。 */
    public static final String ALLCOLS = ""
                     + " MASTER_ID as masterId,"
                     + " MASTER_CODE as masterCode,"
                     + " MASTER_NAME as masterName,"
                     + " PARENT_MASTER_CODE as parentMasterCode,"
                     + " HIER as hier,"
                     + " LPAD_SORT as lpadSort"
                     ;

    /**
     * コンストラクタ
     * @param loginNo ログイン社員番号
     */
    public HierCodeMasterDao(String loginNo) {
        this.loginNo = loginNo;
    }

    /**
     * コンストラクタ
     * @param conn コネクション
     */
    public HierCodeMasterDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    /**
     * コネクションを取得します。
     * @return データベースへのコネクション
     */
    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    /**
     * Insert文を実行する。
     * @param dto HIER_CODE_MASTERのデータ。
     */ 
    public void insert(HierCodeMasterDto dto) {

        final String sql = "INSERT INTO HIER_CODE_MASTER ("
                         + "MASTER_ID,"
                         + "MASTER_CODE,"
                         + "MASTER_NAME,"
                         + "PARENT_MASTER_CODE,"
                         + "HIER,"
                         + "LPAD_SORT"
                         + ")VALUES(?,?,?,?,?,? )"
                         ;
        Log.sql("【DaoMethod Call】 HierCodeMasterDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getMasterId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getMasterCode());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getMasterName());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getParentMasterCode());
            DaoUtil.setIntToPreparedStatement(pstmt, 5, dto.getHier());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getLpadSort());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * 全列update文を実行する。
     * @param dto HIER_CODE_MASTERのレコード型データ。
     */
    public void update(HierCodeMasterDto dto) {

        final String sql = "UPDATE HIER_CODE_MASTER SET "
                         + "MASTER_NAME = ?,"
                         + "PARENT_MASTER_CODE = ?,"
                         + "HIER = ?,"
                         + "LPAD_SORT = ?"
                         + " WHERE MASTER_ID = ?"
                         + " AND MASTER_CODE = ?"
                         ;
        Log.sql("【DaoMethod Call】 HierCodeMasterDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getMasterName());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getParentMasterCode());
            DaoUtil.setIntToPreparedStatement(pstmt, 3, dto.getHier());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getLpadSort());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getMasterId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getMasterCode());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /**
     * プライマリキーを指定してselect文を実行する。
     * @param masterId マスタID
     * @param masterCode マスタコード
     * @return HierCodeMasterDto HIER_CODE_MASTERのレコード型データ。
     */ 
    public HierCodeMasterDto select(String masterId, String masterCode) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM HIER_CODE_MASTER"
                         + " WHERE MASTER_ID = ?"
                         + " AND MASTER_CODE = ?"
                         ;
        Log.sql("【DaoMethod Call】 HierCodeMasterDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, masterId);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, masterCode);
            rs = pstmt.executeQuery();
            HierCodeMasterDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param pstmt PreparedStatement
     * @return List<HierCodeMasterDto> HIER_CODE_MASTERのレコード型データのリスト。
     */ 
    public List<HierCodeMasterDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("【DaoMethod Call】 HierCodeMasterDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<HierCodeMasterDto> lst = new ArrayList<HierCodeMasterDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    /** 
     * 動的SELECT文を実行する。
     * @param sql SQL文
     * @return List<HierCodeMasterDto> HIER_CODE_MASTERのレコード型データのリスト。
     */ 
    public List<HierCodeMasterDto> selectDynamic(String sql) {

        Log.sql("【DaoMethod Call】 HierCodeMasterDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param pstmt PreparedStatement
     */ 
    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("【DaoMethod Call】 HierCodeMasterDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * 動的UPDATE DELETE文を実行する。
     * @param sql SQL文
     */ 
    public void executeDynamic(String sql) {

        Log.sql("【DaoMethod Call】 HierCodeMasterDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    /** 
     * ResultSetからData Transfer Objectへのデータ転送。
     * @param rs ResultSet カーソル位置はこのメソッドでは変更しません。
     * @return Data Transfer Object
     * @throws SQLException
     */
    private HierCodeMasterDto transferRsToDto(ResultSet rs) throws SQLException {

        HierCodeMasterDto dto = new HierCodeMasterDto();
        dto.setMasterId(DaoUtil.convertNullToString(rs.getString("masterId")));
        dto.setMasterCode(DaoUtil.convertNullToString(rs.getString("masterCode")));
        dto.setMasterName(DaoUtil.convertNullToString(rs.getString("masterName")));
        dto.setParentMasterCode(DaoUtil.convertNullToString(rs.getString("parentMasterCode")));
        dto.setHier(rs.getInt("hier"));
        dto.setLpadSort(DaoUtil.convertNullToString(rs.getString("lpadSort")));
        return dto;
    }

}

