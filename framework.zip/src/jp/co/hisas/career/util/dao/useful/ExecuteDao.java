package jp.co.hisas.career.util.dao.useful;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;

public class ExecuteDao extends CoreDao {
	
	public ExecuteDao(String loginNo) {
		super( loginNo );
	}
	
	public void executeDynamic( PreparedStatement pstmt ) {
		try {
			Log.sql( "[DaoMethod Call] MailInfoDao.executeDynamic" );
			pstmt.executeUpdate();
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, null );
		}
	}
	
	public void executeDynamic( String sql ) {
		
		Log.sql( "[DaoMethod Call] MailInfoDao.executeDynamic" );
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement( sql );
			executeDynamic( pstmt );
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, null );
		}
	}
	
}
