/*
 * All Rights Reserved.Copyright (C) 2008, Hitachi Systems & Services,Ltd.
 */
/**************************************************
       !!!!!DON'T EDIT THIS FILE!!!!!
 This source code is generated automatically.
 **************************************************/

package jp.co.hisas.career.util.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.hisas.career.util.dto.CareerPersonRsvDto;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log; 
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.exception.CareerSQLException;

public class CareerPersonRsvDao {

    Connection conn;
    boolean isConnectionGiven = false;
    String loginNo; 

    public static final String ALLCOLS = ""
                     + " PERSON_ID as personId,"
                     + " PERSON_NAME as personName,"
                     + " MAIL_ADDRESS as mailAddress,"
                     + " HIRED_DATE as hiredDate,"
                     + " RETIRE_DATE as retireDate,"
                     + " REGIST_FLG as registFlg,"
                     + " DEPT_HIER_RANK as deptHierRank"
                     ;

    public CareerPersonRsvDao(String loginNo) {
        this.loginNo = loginNo;
    }

    public CareerPersonRsvDao(Connection conn) {
        this.conn = conn;
        this.isConnectionGiven = true;
    }

    private Connection getConnection() {
        Connection connection =
                isConnectionGiven ? this.conn : PZZ040_SQLUtility.getCachedConnection();
        if ( connection == null ) {
            throw new CareerRuntimeException();
        }
        return connection;
    }

    public void insert(CareerPersonRsvDto dto) {

        final String sql = "INSERT INTO CAREER_PERSON_RSV ("
                         + "PERSON_ID,"
                         + "PERSON_NAME,"
                         + "MAIL_ADDRESS,"
                         + "HIRED_DATE,"
                         + "RETIRE_DATE,"
                         + "REGIST_FLG,"
                         + "DEPT_HIER_RANK"
                         + ")VALUES(?,?,?,?,?,?,? )"
                         ;
        Log.sql("[DaoMethod Call] CareerPersonRsvDao.insert");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getPersonId());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getPersonName());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getMailAddress());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getHiredDate());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getRetireDate());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 6, dto.getRegistFlg());
            DaoUtil.setIntToPreparedStatement(pstmt, 7, dto.getDeptHierRank());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void update(CareerPersonRsvDto dto) {

        final String sql = "UPDATE CAREER_PERSON_RSV SET "
                         + "PERSON_NAME = ?,"
                         + "MAIL_ADDRESS = ?,"
                         + "HIRED_DATE = ?,"
                         + "RETIRE_DATE = ?,"
                         + "REGIST_FLG = ?,"
                         + "DEPT_HIER_RANK = ?"
                         + " WHERE PERSON_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CareerPersonRsvDao.update");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, dto.getPersonName());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 2, dto.getMailAddress());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 3, dto.getHiredDate());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 4, dto.getRetireDate());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 5, dto.getRegistFlg());
            DaoUtil.setIntToPreparedStatement(pstmt, 6, dto.getDeptHierRank());
            DaoUtil.setVarcharToPreparedStatement(pstmt, 7, dto.getPersonId());
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public CareerPersonRsvDto select(String personId) {

        final String sql = "SELECT "
                         + "" + ALLCOLS + ""
                         + " FROM CAREER_PERSON_RSV"
                         + " WHERE PERSON_ID = ?"
                         ;
        Log.sql("[DaoMethod Call] CareerPersonRsvDao.select");
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            DaoUtil.setVarcharToPreparedStatement(pstmt, 1, personId);
            rs = pstmt.executeQuery();
            CareerPersonRsvDto dto = null;
            if ( rs.next() ) {
                dto = transferRsToDto(rs);
            }
            return dto;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CareerPersonRsvDto> selectDynamic(PreparedStatement pstmt) {

        Log.sql("[DaoMethod Call] CareerPersonRsvDao.selectDynamic");
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            List<CareerPersonRsvDto> lst = new ArrayList<CareerPersonRsvDto>();
            while ( rs.next() ) {
               lst.add(transferRsToDto(rs));
            }
            return lst;
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, rs);
        }
    }

    public List<CareerPersonRsvDto> selectDynamic(String sql) {

        Log.sql("[DaoMethod Call] CareerPersonRsvDao.selectDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            return selectDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }

     }

    public void executeDynamic(PreparedStatement pstmt) {
        try {
            Log.sql("[DaoMethod Call] CareerPersonRsvDao.executeDynamic");
            pstmt.executeUpdate();
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    public void executeDynamic(String sql) {

        Log.sql("[DaoMethod Call] CareerPersonRsvDao.executeDynamic");
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            executeDynamic(pstmt);
        } catch (final SQLException e) {
            Log.error(loginNo, e);
            throw new CareerSQLException(e);
        } finally {
            PZZ040_SQLUtility.closeConnection(loginNo, null, pstmt, null);
        }
    }

    private CareerPersonRsvDto transferRsToDto(ResultSet rs) throws SQLException {

        CareerPersonRsvDto dto = new CareerPersonRsvDto();
        dto.setPersonId(DaoUtil.convertNullToString(rs.getString("personId")));
        dto.setPersonName(DaoUtil.convertNullToString(rs.getString("personName")));
        dto.setMailAddress(DaoUtil.convertNullToString(rs.getString("mailAddress")));
        dto.setHiredDate(DaoUtil.convertNullToString(rs.getString("hiredDate")));
        dto.setRetireDate(DaoUtil.convertNullToString(rs.getString("retireDate")));
        dto.setRegistFlg(DaoUtil.convertNullToString(rs.getString("registFlg")));
        dto.setDeptHierRank(rs.getInt("deptHierRank"));
        return dto;
    }

}

