package jp.co.hisas.career.framework.trans;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.http.HTTPException;

import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.framework.exception.CareerBusinessException;
import jp.co.hisas.career.util.AU;
import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.Log;

public abstract class WebAPIServlet extends HttpServlet {
	
	protected ServletContext ctx = null;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	public void doGet( final HttpServletRequest req, final HttpServletResponse res ) throws IOException, ServletException {
		try {
			Tray tray = new Tray( req, res );
			
			Log.method( tray.loginNo, "IN", "" );
			Log.performance( tray.loginNo, true, "" );
			
			CSRFTokenUtil.checkTokenNo( tray.request );
			
			String json = doGetMain( tray );
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.getWriter().write( SU.ntb( json ) );
			
			/* Keep Token for random order access */
			
			Log.performance( tray.loginNo, false, "" );
			Log.method( tray.loginNo, "OUT", "" );
			
		} catch (final CareerBusinessException e) {
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.setStatus( 403 );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			res.getWriter().write( json );
			
		} catch (final HTTPException e) {
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.setStatus( e.getStatusCode() );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			res.getWriter().write( json );
			
		} catch (final Exception e) {
			Log.error( req, e );
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.setStatus( 500 );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			res.getWriter().write( json );
		}
	}
	
	public abstract String doGetMain( Tray tray ) throws Exception;
	
	public void doPost( HttpServletRequest req, HttpServletResponse res ) throws ServletException, IOException {
		try {
			Tray tray = new Tray( req, res );
			
			Log.method( tray.loginNo, "IN", "" );
			Log.performance( tray.loginNo, true, "" );
			
			CSRFTokenUtil.checkTokenNo( tray.request );
			
			String json = doPostMain( tray );
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.getWriter().write( SU.ntb( json ) );
			
			/* Keep Token for random order access */
			
			Log.performance( tray.loginNo, false, "" );
			Log.method( tray.loginNo, "OUT", "" );
			
		} catch (final CareerBusinessException e) {
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.setStatus( 403 );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			res.getWriter().write( json );
			
		} catch (final HTTPException e) {
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.setStatus( e.getStatusCode() );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			res.getWriter().write( json );
			
		} catch (final Exception e) {
			Log.error( req, e );
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.setStatus( 500 );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			res.getWriter().write( json );
		}
	}
	
	public abstract String doPostMain( Tray tray ) throws Exception;
	
	public void doPut( HttpServletRequest req, HttpServletResponse res ) throws ServletException, IOException {
		try {
			Tray tray = new Tray( req, res );
			
			Log.method( tray.loginNo, "IN", "" );
			Log.performance( tray.loginNo, true, "" );
			
			CSRFTokenUtil.checkTokenNo( tray.request );
			
			String json = doPutMain( tray );
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.getWriter().write( SU.ntb( json ) );
			
			/* Keep Token for random order access */
			
			Log.performance( tray.loginNo, false, "" );
			Log.method( tray.loginNo, "OUT", "" );
			
		} catch (final CareerBusinessException e) {
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.setStatus( 403 );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			res.getWriter().write( json );
			
		} catch (final HTTPException e) {
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.setStatus( e.getStatusCode() );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			res.getWriter().write( json );
			
		} catch (final Exception e) {
			Log.error( req, e );
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.setStatus( 500 );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			res.getWriter().write( json );
		}
	}
	
	public abstract String doPutMain( Tray tray ) throws Exception;
	
	public void doDelete( HttpServletRequest req, HttpServletResponse res ) throws ServletException, IOException {
		try {
			Tray tray = new Tray( req, res );
			
			Log.method( tray.loginNo, "IN", "" );
			Log.performance( tray.loginNo, true, "" );
			
			CSRFTokenUtil.checkTokenNo( tray.request );
			
			String json = doDeleteMain( tray );
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.getWriter().write( SU.ntb( json ) );
			
			/* Keep Token for random order access */
			
			Log.performance( tray.loginNo, false, "" );
			Log.method( tray.loginNo, "OUT", "" );
			
		} catch (final CareerBusinessException e) {
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.setStatus( 403 );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			res.getWriter().write( json );
			
		} catch (final HTTPException e) {
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.setStatus( e.getStatusCode() );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			res.getWriter().write( json );
			
		} catch (final Exception e) {
			Log.error( req, e );
			res.setContentType( "application/json" );
			res.setCharacterEncoding( "UTF-8" );
			res.setStatus( 500 );
			String json = AU.isDebugMode() ? SU.toJson( e ) : "";
			res.getWriter().write( json );
		}
	}
	
	public abstract String doDeleteMain( Tray tray ) throws Exception;
}
