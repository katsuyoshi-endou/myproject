/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.trans;

import java.util.LinkedList;

import javax.servlet.http.HttpSession;

import jp.co.hisas.career.framework.trans.AbstractCommand;

/**
 * initが呼び出されたコマンドを履歴として保持します。履歴の保持ルールはFIFOです。
 * @author kat-watanabe
 */
public class CommandHistory {

    private static final String SESSION_KEY = "_FW_COMMAND_HISTORY";

    /**
     * 履歴として保持する最大件数。
     */
    private static final int MAX_SIZE = 2;

    /**
     * コマンドのキュー。新しいものが先頭に格納されます。
     */
    LinkedList<Class<? extends AbstractCommand>> queue =
            new LinkedList<Class<? extends AbstractCommand>>();

    private CommandHistory() {
    }

    public static CommandHistory getInstance( HttpSession session ) {
        CommandHistory commandHistory = (CommandHistory) session.getAttribute( SESSION_KEY );
        if ( commandHistory == null ) {
            commandHistory = new CommandHistory();
            session.setAttribute( SESSION_KEY, commandHistory );
        }
        return commandHistory;
    }

    /**
     * コマンドクラスを履歴に格納します。履歴の最大サイズを超えたデータは古いほうから削除されます。
     * 前回と同じクラスのinitが呼び出された場合、履歴は変更しません。
     * @param commandClass 追加するコマンドクラス。
     */
    public void put( Class<? extends AbstractCommand> commandClass ) {
        if ( queue.isEmpty() || queue.getFirst() != commandClass ) {
            queue.addFirst( commandClass );
            if ( queue.size() > MAX_SIZE ) {
                queue.removeLast();
            }
        }
    }

    /**
     * 最新のコマンドクラスを取得します。
     * @return 最新のコマンドクラス
     */
    public Class<? extends AbstractCommand> getLast() {
        // メソッド名と実装が逆なので注意。このズレはgetPrevious()の簡潔さのため。
        return ( queue.isEmpty() ) ? null : queue.getFirst();
    }

    /**
     * ひとつ前のコマンドクラスを取得します。
     * @return 最新のコマンドクラス
     */
    public Class<? extends AbstractCommand> getPrevious() {
        return ( queue.size() < 2 ) ? null : queue.get( 1 );
    }

}
