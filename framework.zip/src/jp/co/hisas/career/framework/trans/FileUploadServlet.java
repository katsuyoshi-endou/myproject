package jp.co.hisas.career.framework.trans;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import jp.co.hisas.career.framework.CSRFTokenUtil;
import jp.co.hisas.career.framework.def.AC;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.Log;

/**
 * ファイルアップロードを伴うサーブレット向けの抽象クラス
 * - フォワード注意。
 * 
 * http://www.ne.jp/asahi/hishidama/home/tech/apache/commons/fileup.html
 */
public abstract class FileUploadServlet extends HttpServlet {
	
	protected ServletContext ctx = null;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	public void service( final HttpServletRequest req, final HttpServletResponse res ) throws IOException, ServletException {
		try {
			Tray tray = new Tray( req, res );
			
			Log.method( tray.loginNo, "IN", "" );
			Log.performance( tray.loginNo, true, "" );
			
			Map<String, FileItem> paramMap = getParamMap( tray.request );
			tray.request.setAttribute( "paramMap", paramMap );
			
			String tokenNo = paramMap.get( "tokenNo" ).getString();
			tray.request.setAttribute( "tokenNo", tokenNo );
			CSRFTokenUtil.checkTokenNo( tray.request );
			
			String fPath = serviceMain( tray );
			
			/* Keep Token */
			// CSRFTokenUtil.setNewTokenNo( tray.request, tray.response, fPath );
			
			final RequestDispatcher rd = this.ctx.getRequestDispatcher( fPath );
			rd.forward( tray.request, tray.response );
			
			Log.performance( tray.loginNo, false, "" );
			Log.method( tray.loginNo, "OUT", "" );
		} catch (final Exception e) {
			Log.error( req, e );
			this.ctx.getRequestDispatcher( AC.ERROR_PAGE ).forward( req, res );
		}
	}
	
	public abstract String serviceMain( Tray tray ) throws Exception;
	
	private Map<String, FileItem> getParamMap( HttpServletRequest request ) {
		Map<String, FileItem> paramMap = new HashMap<String, FileItem>();
		boolean isMultipart = ServletFileUpload.isMultipartContent( request );
		if (isMultipart) {
			DiskFileItemFactory factory = new DiskFileItemFactory();
			ServletContext servletContext = this.ctx;
			File repository = (File)servletContext.getAttribute( "javax.servlet.context.tempdir" );
			factory.setRepository( repository );
			ServletFileUpload upload = new ServletFileUpload( factory );
			List<FileItem> items = null;
			try {
				items = upload.parseRequest( request );
			} catch (FileUploadException e) {
				e.printStackTrace();
			}
			for (Object val : items) {
				FileItem item = (FileItem)val;
				paramMap.put( item.getFieldName(), item );
			}
		}
		return paramMap;
	}
	
}
