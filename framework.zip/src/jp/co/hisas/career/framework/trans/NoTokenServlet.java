package jp.co.hisas.career.framework.trans;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.framework.def.AC;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.log.Log;

public abstract class NoTokenServlet extends HttpServlet {
	
	protected ServletContext ctx = null;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	public void service( final HttpServletRequest req, final HttpServletResponse res ) throws IOException, ServletException {
		try {
			Tray tray = new Tray( req, res, false );
			
			Log.method( tray.loginNo, "IN", "" );
			Log.performance( tray.loginNo, true, "" );
			
			/* No Check Token */
			// CSRFTokenUtil.checkTokenNo( tray.request );
			String fPath = serviceMain( tray );
			/* Keep Token */
			// CSRFTokenUtil.setNewTokenNo( tray.request, tray.response, fPath );
			
			final RequestDispatcher rd = this.ctx.getRequestDispatcher( fPath );
			rd.forward( tray.request, tray.response );
			
			Log.performance( tray.loginNo, false, "" );
			Log.method( tray.loginNo, "OUT", "" );
		} catch (final Exception e) {
			Log.error( req, e );
			this.ctx.getRequestDispatcher( AC.ERROR_PAGE ).forward( req, res );
		}
	}
	
	public abstract String serviceMain( Tray tray ) throws Exception;
	
}
