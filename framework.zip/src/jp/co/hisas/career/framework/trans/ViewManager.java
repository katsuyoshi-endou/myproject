/*
 * All Rights Reserved. Copyright (C) 2004,2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.trans;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.util.log.Log;

/**
 * Commandクラスを管理するクラス。
 * @author kats-watanabe
 */
public class ViewManager {

    private static class Entry {
        public Class<? extends AbstractCommand> commandClass;
        public String jspPath = "";
        @SuppressWarnings("unused")
		public String frameJspPath = "";
    }

    private ViewManager() {
    }

    private static Map<String, Entry> map =
            Collections.synchronizedMap( new HashMap<String, Entry>() );

    public static void regist( Class<? extends AbstractCommand> commandClass, String kinouId,
            String jspPath ) {
        regist( commandClass, kinouId, jspPath, null );
    }

    public static void regist( Class<? extends AbstractCommand> commandClass, String kinouId,
            String jspPath, String frameJspPath ) {
        if ( map.containsKey( kinouId ) ) {
            return;
        }
        if ( !commandClass.getSimpleName().substring( 1, 6 ).equals( kinouId.substring( 1, 6 ) ) ) {
            throw new CareerRuntimeException( String.format(
                    "機能ID %s のコマンドクラスとして、%s は適切な名称ではありません。", kinouId, commandClass.getSimpleName() ) );
        }
        Entry entry = new Entry();
        entry.commandClass = commandClass;
        entry.jspPath = jspPath;
        entry.frameJspPath = ( frameJspPath == null ) ? "" : frameJspPath;
        map.put( kinouId, entry );
    }

    /**
    * 機能IDを指定してJSPのパスを取得します。
    * @param kinouId 機能ID
    * @return JSPのパス
    */
    public static String getJSPPath( String kinouId ) {
        Entry e = map.get( kinouId );
        return ( e == null ) ? "" : e.jspPath;
    }

    //    /**
    //     * 機能IDを指定してJSPのパスを取得します。
    //     * @param kinouId 機能ID
    //     * @param frameTop フレーム全体のパスを取得する場合、trueを指定する。(サポートしていない場合有り)
    //     * @return JSPのパス
    //     */
    //    public static String getJSPPath( String kinouId, boolean frameTop ) {
    //        String ret = "";
    //        Entry e = map.get( kinouId );
    //        if ( e != null ) {
    //            if ( frameTop ) {
    //                ret = e.frameJspPath;
    //                if ( "".equals( ret ) ) {
    //                    throw new CareerRuntimeException(kinouId + "のCommandではフレーム全体のJSPが定義されていません。");
    //                }
    //            } else {
    //                ret = e.jspPath;
    //            }
    //        }
    //        return ret;
    //    }

    public static Class<? extends AbstractCommand> getCommandClass( String kinouId ) {
        Entry e = map.get( kinouId );
        return ( e == null ) ? null : e.commandClass;
    }

    /**
     * コマンドクラスから機能IDを取得します。リフレクションにより取得します。
     * @param commandClass コマンドクラス。
     * @return 機能ID。メンバ定数 KINOU_ID の値を取得する。
     */
    public static String getKinouIdFromCommand( Class<? extends AbstractCommand> commandClass ) {
        try {
            return (String) commandClass.getField( "KINOU_ID" ).get( null );
        } catch ( IllegalArgumentException e ) {
            Log.error("", e);
            throw new CareerRuntimeException( e );
        } catch ( SecurityException e ) {
            Log.error("", e);
            throw new CareerRuntimeException( e );
        } catch ( IllegalAccessException e ) {
            Log.error("", e);
            throw new CareerRuntimeException( e );
        } catch ( NoSuchFieldException e ) {
            Log.error("", e);
            throw new CareerRuntimeException( e );
        }
    }

}
