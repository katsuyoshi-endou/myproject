/*
 * All Rights Reserved. Copyright (C) 2004,2009, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.trans;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.framework.SubApplicationScope;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.framework.trans.StateTransitionEvent.ForwardUri;
import jp.co.hisas.career.util.download.bean.DownloadFileBean;
import jp.co.hisas.career.util.log.Log;

/**
 * 共通で利用するサーブレット。
 * 
 * @author kats-watanabe
 */
public class CommonServlet extends HttpServlet {
	
	public static final String TRANSIT_ACTION = "_FW_TRANSIT_ACTION";
	
	public static final String TRANSIT_KINOU_ID = "_FW_TRANSIT_KINOU_ID";
	
	public static final String FILE_UPLOAD_REQUEST = "_FW_FILE_UPLOAD_REQUEST";
	
	/** エラーページ */
	private static final String ERROR_PAGE = "/view/error.jsp";
	
	/* ■注意■ このクラスにスレッドセーフでないフィールドを追加する場合は同期に注意すること */
	
	/** ServletContextオブジェクト */
	private ServletContext _ctx = null;
	
	/* ■注意■ このクラスにスレッドセーフでないフィールドを追加する場合は同期に注意すること */
	
	/**
	 * ServletContextオブジェクトを取得する。
	 * 
	 * @param config Servletの設定や初期化パラメータが含まれているServletConfigオブジェクト
	 */
	@Override
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this._ctx == null) {
				this._ctx = config.getServletContext();
			}
		}
	}
	
	/**
	 * ブラウザからの検索要求を受け取り、クライアントBeanの検索処理メソッドを呼び出す。
	 * 
	 * @param request クライアントのリクエストを表すHttpServletRequestオブジェクト
	 * @param response Servlet からのレスポンスを表すHttpServletResponseオブジェクト
	 * 
	 * @exception IOException 入出力関連処理で発生する例外
	 * @exception ServletException Servlet の正常な処理が妨げられたときに発生する例外
	 */
	@Override
	public void service( final HttpServletRequest request, final HttpServletResponse response ) throws IOException, ServletException {
		String loginNo = "";
		try {
			HttpSession session = request.getSession( false );
			if (session == null) {
				/* エラーページへ遷移 */
				this._ctx.getRequestDispatcher( ERROR_PAGE ).forward( request, response );
			} else {
				loginNo = getLoginNoFromSession( session );
				Log.method( loginNo, "IN", "" );
				Log.performance( loginNo, true, "" );
				
				// ここでEncoding指定しないとフォーム入力文字化ける
				request.setCharacterEncoding( "Windows-31J" );
				
				String kinouId = request.getParameter( TRANSIT_KINOU_ID ); // 機能ID
				String actionId = request.getParameter( TRANSIT_ACTION ); // 画面アクション
				
				if (request.getHeader( "Content-type" ).toLowerCase().indexOf( "multipart/form-data" ) != -1) {
//					PYF010_FileUploadBean bean = new PYF010_FileUploadBean( loginNo, request );
//					kinouId = (String)bean.getParameter( TRANSIT_KINOU_ID );
//					actionId = (String)bean.getParameter( TRANSIT_ACTION );
//					request.setAttribute( FILE_UPLOAD_REQUEST, bean );
				}
				
				// このへんの値はAbstractCommandから取れるようにすると便利？
				// sessionにセットすると、メモリのコピー処理が行われる？ だとすると全データコピーは重いかも。窓口だけを置くのが順当？
				//Map<String, String> msgMap = ReadFile.getMsgMapData( ReadFile.fileMapData.get( HcdbDef.msgCode ) );
				// メッセージのほかのリソースも参照できたほうがいいか？
				// パラメータの型は文字列にキャストしていい？ これをStateTransitionEventに持たせる必要があるかどうかは要検討。
				//Map<?, ?> paramMap = request.getParameterMap();
				//→ メッセージとパラメータについては、当面はfw:messageタグとfw:paramタグを使う。
				
				if ("init".equals( kinouId )) {
					throw new CareerRuntimeException( "機能IDにinitを指定することはできません。" );
				}
				
				// 機能IDでクラスを分けて、Actionでメソッドを分ける。
				// Actionメソッドが呼び出される対象のクラスは、initが呼び出されたクラスとは別インスタンス。
				// これは、既存のソースとの兼ね合いで、initとdoItが必ずしも対にならないため。
				ForwardUri forwardUri = dispatchMethod( request, response, kinouId, actionId, loginNo );
				
				if (forwardUri == null) {
					// 遷移先が未指定の場合は、自画面遷移する。
					forwardUri = ForwardUri.asJSP( ViewManager.getJSPPath( kinouId ) );
				}
				/* 該当JSPページへ遷移 */
				this._ctx.getRequestDispatcher( forwardUri.toString() ).forward( request, response );
				
				/* メソッドトレース出力 */
				Log.performance( loginNo, false, "" );
				Log.method( loginNo, "OUT", "" );
			}
		} catch (Exception e) {
			Log.error( loginNo, e );
			this._ctx.getRequestDispatcher( ERROR_PAGE ).forward( request, response );
		}
	}
	
	/**
	 * Commandクラスのinit()メソッドを呼び出します。 このメソッドはJSPに記述します。
	 * Commandクラスのinit()以外のメソッドを呼び出すためには、最初にこのメソッドを実行する必要があります。
	 * 
	 * @param request HTTPリクエスト
	 * @param response HTTPレスポンス
	 * @param commandClass CommandクラスのClassオブジェクト。
	 */
	public static void callInit( final HttpServletRequest request, final HttpServletResponse response, final Class<? extends AbstractCommand> commandClass ) {
		assert commandClass != null;
		String loginNo = "";
		try {
			HttpSession session = request.getSession( false );
			loginNo = getLoginNoFromSession( session );
			CommandHistory commandHistory = CommandHistory.getInstance( session );
			
			AbstractCommand command = commandClass.newInstance();
			
			StateTransitionEvent ste = new StateTransitionEvent();
			ste.setRequest( request );
			ste.setResponse( response );
			
// DEL 2016.09 リクスタログイン障害修正製品取込 start
//			// ここのへんは性能改善の余地あり。synchronized 不要？ init, doIt系は同期したほうが無難。
//			synchronized (CommonServlet.class) {
// DEL 2016.09 リクスタログイン障害修正製品取込 end
				
				// ヒストリからの最新取得は、現時点では同期が必要。
				ste.setPreviousCommand( commandHistory.getLast() );
				// downloadFileInfo は、DownloadServletの実行時にセッションから削除される。
				ste.setDownloadFileInfo( (DownloadFileBean)session.getAttribute( DownloadServlet.SESSION_KEY ) );
				
				setSessionValuesAndParamterValuesToCommand( session, request, command );
				command.setLoginNo( loginNo );
				command.init( ste );
				setCommandPropertiesToSessionAndRequest( session, request, command );
				
				// 子画面コマンドクラスの場合はヒストリに登録しない。
				if (!command.isChildCommand) {
					commandHistory.put( commandClass );
				}
				
// DEL 2014.01 CommonServletでは操作ログ出力しない start
//				/* 操作ログ出力(CJS_LOG_SOUSA) */
//				String kinouId = (String)commandClass.getField( "KINOU_ID" ).get( null );
//				String agencyShimeiNo = (String)session.getAttribute( "agencyShimeiNo" );
//				if (agencyShimeiNo != null && !"".equals( agencyShimeiNo )) {
//					// agencyShimeiNoに値が存在したら、ログインユーザと代行されるユーザを入れ替えることで
//					// 本来の代行ログイン機能を使った時の操作ログ出力を実現する
//					command.getSousaLogArg().setLogonShimeiNo( agencyShimeiNo );
//					command.getSousaLogArg().setProxyShimeiNo( loginNo );
//				}
//				command.getSousaLogArg().setSousa( "CommonInit" );
//				OutLogBean.outputLogSousa( kinouId, command.getSousaLogArg() );
// DEL 2014.01 CommonServletでは操作ログ出力しない end
// DEL 2016.09 リクスタログイン障害修正製品取込 start
//			}
// DEL 2016.09 リクスタログイン障害修正製品取込 end
		} catch (Exception e) {
			try {
				Log.investigate( request, response );
				Log.error( loginNo, e );
				request.setAttribute( "Exception", e ); // for viewing StackTrace in Error Page.
				request.getRequestDispatcher( ERROR_PAGE ).forward( request, response );
			} catch (ServletException e1) {
				Log.error( loginNo, e1 );
			} catch (IOException e1) {
				Log.error( loginNo, e1 );
			}
		}
	}
	
	public ForwardUri dispatchMethod( final HttpServletRequest request, final HttpServletResponse response, final String kinouId, final String actionId, final String loginNo ) throws CareerException {
		if (kinouId == null) {
			throw new CareerRuntimeException( "機能IDが設定されていません。このサーブレットを使用する場合、機能IDは必須です。" );
		}
		if (actionId == null) {
			throw new CareerRuntimeException( "アクションが設定されていません。このサーブレットを使用する場合、アクションは必須です。" );
		}
		
		Class<?> commandClass = ViewManager.getCommandClass( kinouId );
		if (commandClass == null) {
			throw new CareerRuntimeException( kinouId + "に対応するクラスが見つかりません。機能IDが間違っていないか、またはそのクラスに対してcallInit()メソッドが実行済みか確認してください。" );
		}
		
		HttpSession session = request.getSession( false );
		CommandHistory commandHistory = CommandHistory.getInstance( session );
		try {
			AbstractCommand command = (AbstractCommand)commandClass.newInstance();
			
			StateTransitionEvent ste = new StateTransitionEvent();
			ste.setRequest( request );
			ste.setResponse( response );
			
			// ここのへんは性能改善の余地あり。synchronized 不要？ init, doIt系は同期したほうが無難。
			synchronized (CommonServlet.class) {
				ste.setPreviousCommand( commandHistory.getPrevious() );
				
				// 実行前に、コマンドクラスのプロパティにattributeを設定する。
				setSessionValuesAndParamterValuesToCommand( session, request, command );
				
				// メソッドを実行する。
				Method actionMethod = commandClass.getMethod( actionId, StateTransitionEvent.class );
				
				command.setLoginNo( loginNo );
				invoke( actionMethod, command, ste );
				
				setCommandPropertiesToSessionAndRequest( session, request, command );
				
				if (ste.getDownloadFileInfo() != null) {
					session.setAttribute( DownloadServlet.SESSION_KEY, ste.getDownloadFileInfo() );
				}
			}
			
			return ste.getForwardUri();
			
		} catch (InstantiationException e) {
			Log.error( loginNo, e );
			throw new CareerRuntimeException( e );
		} catch (IllegalAccessException e) {
			Log.error( loginNo, e );
			throw new CareerRuntimeException( e );
		} catch (NoSuchMethodException e) {
			Log.error( loginNo, e );
			throw new CareerRuntimeException( String.format( "%sメソッドが%sに存在しません。", actionId, commandClass.getSimpleName() ), e );
		}
	}
	
	private static Object invoke( Method method, Object obj, Object... args ) throws CareerException {
		try {
			return method.invoke( obj, args );
		} catch (IllegalAccessException e) {
			Log.error( "", e );
			throw new CareerRuntimeException( e );
		} catch (InvocationTargetException e) {
			Log.error( "", e );
			pullTargetExcepion( e );
			throw new CareerRuntimeException( e ); // このコードが呼び出されることは無い。
		}
	}
	
	/**
	 * セッションから、ログインユーザの氏名NOを取得します。
	 * 
	 * @param session HTTPセッション
	 * @return ログインユーザの氏名NO。取得できなかったときは空文字列を返す。
	 */
	private static String getLoginNoFromSession( HttpSession session ) {
		String loginNo = "";
		UserInfoBean userInfoBean = (UserInfoBean)session.getAttribute( "userinfo" );
		if (userInfoBean != null && userInfoBean.getLogin_no() != null) {
			loginNo = userInfoBean.getLogin_no();
		}
		return loginNo;
	}
	
	private static boolean isMethodPublic( Method m ) {
		return (m != null) && ((m.getModifiers() & Modifier.PUBLIC) == Modifier.PUBLIC);
	}
	
	/**
	 * コマンドクラスのプロパティに設定されている値を、セッションとリクエストに設定する。
	 * 
	 * @param session HTTPセッション
	 * @param request HTTPサーブレットリクエスト。
	 * @param command コマンドクラスのインスタンス。
	 * @throws CareerException getterメソッド内部でCareerExceptionがスローされた場合。(通常は発生しない)
	 */
	private static void setCommandPropertiesToSessionAndRequest( HttpSession session, HttpServletRequest request, AbstractCommand command ) throws CareerException {
		// メニューから画面遷移したときにアプリケーションスコープの変数をクリアする処理が必要。
		try {
			for (PropertyDescriptor desc : Introspector.getBeanInfo( command.getClass() ).getPropertyDescriptors()) {
				Method getter = desc.getReadMethod();
				if (getter != null) {
					Object result = invoke( getter, command );
					SubApplicationScope sessionScope = getter.getAnnotation( SubApplicationScope.class );
					if (sessionScope != null) {
						sessionScope.value().setAttribute( session, desc.getName(), result );
					}
					request.setAttribute( desc.getName(), result );
				}
			}
		} catch (IntrospectionException e) {
			Log.error( "", e );
			throw new CareerRuntimeException( e );
		}
	}
	
	/**
	 * セッションとパラメータとリクエストに設定されている値をコマンドクラスのプロパティに設定する。
	 * 
	 * @param session HTTPセッション
	 * @param request HTTPサーブレットリクエスト。
	 * @param command コマンドクラスのインスタンス。
	 * @throws CareerException setterメソッド内部でCareerExceptionがスローされた場合。(通常は発生しない)
	 */
	private static void setSessionValuesAndParamterValuesToCommand( HttpSession session, HttpServletRequest request, AbstractCommand command ) throws CareerException {
		try {
			for (PropertyDescriptor desc : Introspector.getBeanInfo( command.getClass() ).getPropertyDescriptors()) {
				Method writeMethod = desc.getWriteMethod();
				if (isMethodPublic( writeMethod )) {
					SubApplicationScope sessionScope = writeMethod.getAnnotation( SubApplicationScope.class );
					
					if (sessionScope != null) {
						Map<String, Object> attributes = sessionScope.value().getAttributes( session );
						invoke( writeMethod, command, attributes.get( desc.getName() ) );
					} else {
						setParameterOrAttributeToCommand( command, writeMethod, request, desc.getName() );
					}
				}
			}
		} catch (IntrospectionException e) {
			Log.error( "", e );
			throw new CareerRuntimeException( e );
		}
	}
	
	/**
	 * JSPから渡されたパラメータ文字列をコマンドクラスのsetterに設定します。パラメータがない場合はリクエストの値を設定します。
	 * コマンドクラスのsetterの型に併せて型変換を行います。
	 * 変換できる型は、JSPからの値が単一の場合、String、boolean、Boolean
	 * 、int、Integer、long、Long、各種Enumです。
	 * JSPから複数の値が渡される場合、String[]、List＜String＞、Set
	 * ＜String＞に変換できます。（複数選択可能なリストボックス等で使用する） 単一値の型変換は、基本的に各クラスの valueOf
	 * メソッドを使用します。 したがって、型が boolean なら文字列値 "true" が true
	 * になり、列挙なら列挙値の名称が列挙値に変換されます。
	 * 
	 * @param command コマンドクラス。
	 * @param setter setterメソッド。
	 * @param request JSPから渡された値を保持するHTTPリクエスト。
	 * @param paramName 値を取り出す対象のパラメータ名。
	 * @throws CareerException setterメソッド内部でCareerExceptionがスローされた場合。(通常は発生しない)
	 */
	private static void setParameterOrAttributeToCommand( AbstractCommand command, Method setter, HttpServletRequest request, String paramName ) throws CareerException {
		// setterは第一引数しかないと仮定。「インデックス付きプロパティ」的なものには現時点では未対応。
		Class<?>[] parameterTypes = setter.getParameterTypes();
		assert parameterTypes.length > 0 : "setter メソッドに引数がありません。";
		assert parameterTypes.length <= 1 : "引数が複数ある setter メソッドには未対応です。";
		
		Class<?> fieldType = parameterTypes[0];
		if (fieldType.isArray()) {
			assert fieldType.isAssignableFrom( String[].class ) : "引数の型が配列である setter メソッドは、文字列の配列のみ対応しています。メソッド:" + setter.getName();
			// Javaの可変長引数の仕様の都合で、String[]ではなくObject[]として変数宣言する。
			Object values = request.getParameterValues( paramName );
			if (values == null) {
				values = request.getAttribute( paramName );
			}
			values = (values == null) ? new String[0] : values;
			invoke( setter, command, values );
		} else if (fieldType == List.class) {
			String[] values = request.getParameterValues( paramName );
			if (values == null) {
				Object attr = request.getAttribute( paramName );
				invoke( setter, command, (attr == null) ? Collections.emptyList() : attr );
			} else {
				invoke( setter, command, Arrays.asList( values ) );
			}
		} else if (fieldType == Set.class) {
			String[] values = request.getParameterValues( paramName );
			if (values == null) {
				Object attr = request.getAttribute( paramName );
				invoke( setter, command, (attr == null) ? Collections.emptySet() : attr );
			} else {
				invoke( setter, command, new HashSet<String>( Arrays.asList( values ) ) );
			}
		} else {
			String value = request.getParameter( paramName );
			Object obj;
			if (value == null || "".equals( value )) { // パラメータが無いとき、空文字列になる。
				obj = request.getAttribute( paramName );
			} else if (fieldType == String.class) {
				obj = value;
			} else if (fieldType == Integer.TYPE || fieldType == Integer.class) { // int or Integer
				obj = Integer.valueOf( value );
			} else if (fieldType == Long.TYPE || fieldType == Long.class) {
				obj = Long.valueOf( value );
			} else if (fieldType == Boolean.TYPE || fieldType == Boolean.class) {
				obj = Boolean.valueOf( value );
			} else if (fieldType.isEnum()) {
				obj = parseEnum( fieldType, value );
			} else {
				throw new CareerRuntimeException( "この setter メソッドに対する型変換は未対応です。メソッド:" + setter.getName() );
			}
			if (!(fieldType.isPrimitive() && obj == null)) {
				invoke( setter, command, obj );
			}
		}
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private static Enum<?> parseEnum( Class<?> enumType, String name ) {
		if ("".equals( name )) {
			return null;
		} else {
			return Enum.valueOf( (Class<Enum>)enumType, name );
		}
	}
	
	/**
	 * InvocationTargetException発生時に例外のネスト深度が冗長になるのを防ぐため、
	 * Careerの例外に由来している場合は、その例外を取り出して再スローする。
	 * 
	 * @param e
	 * @throws CareerException InvocationTargetException が CareerExceptionに由来している場合、その例外を出す。
	 * @throws RuntimeException InvocationTargetException が RuntimeExceptionに由来している場合、その例外を出す。
	 */
	private static void pullTargetExcepion( InvocationTargetException e ) throws CareerException {
		Throwable cause = e.getCause();
		if (cause == null) {
			throw new CareerRuntimeException( e );
		} else if (cause instanceof RuntimeException) { // CareerRuntimeExceptionを含む
			throw (RuntimeException)cause;
		} else if (cause instanceof CareerException) {
			throw (CareerException)cause;
		} else {
			throw new CareerRuntimeException( cause );
		}
	}
	
}
