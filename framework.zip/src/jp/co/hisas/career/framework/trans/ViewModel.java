package jp.co.hisas.career.framework.trans;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;

import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.Tray;
import jp.co.hisas.career.util.property.CommonLabel;

public class ViewModel {
	
	private String party;
	private int langNo;
	private Map<String, String> vlMap = new HashMap<String, String>();
	
	public ViewModel(Tray tray) {
		this.party = tray.party;
		this.langNo = tray.langNo;
	}
	
	/** Get Common Label (Not Escaped) */
	public String gCL( String labelId ) {
		String cl = CommonLabel.getLabel( this.party, labelId, this.langNo );
		//String esc = StringEscapeUtils.escapeXml( cl );
		return cl;
	}
	
	/** Escape for HTML (also input value & textarea) */
	public String escx( String str ) {
		String esc = StringEscapeUtils.escapeXml( str );
		return esc;
	}
	
	/** Escape for JS */
	public String escj( String str ) {
		String esc = StringEscapeUtils.escapeJavaScript( str );
		return esc;
	}
	
	/** Get View Label */
	public String gVL( String key ) {
		return SU.ntb( vlMap.get( key ) );
	}
	
	/** Put View Label */
	public void putVL( String key, String str ) {
		vlMap.put( key, str );
	}
	
	/** Put Common Label ID List to View Label Map */
	public void registerCommonLabels( List<String> list ) {
		for (String labelId : list) {
			putVL( labelId, gCL( labelId ) );
		}
	}
	
}
