/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.trans;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.framework.exception.CareerRuntimeException;
import jp.co.hisas.career.util.download.bean.DownloadFileBean;
import jp.co.hisas.career.util.log.Log;

/**
 * ファイルをダウンロードするためのクラス。
 * @author 王, kat-watanabe
 */
public class DownloadServlet extends HttpServlet {

    public static final String SESSION_KEY = "_FW_SESSION_DOWNLOAD_FILE_INFO";

    /** ログイン社員の氏名番号 */
    private String loginNo = "";

    /**
     * ブラウザからのダウンロードの要求を受け取る。
     * 
     * @param request クライアントのリクエストを表すHttpServletRequestオブジェクト
     * @param response Servlet からのレスポンスを表すHttpServletResponseオブジェクト
     * 
     * @exception IOException 入出力関連処理で発生する例外
     * @exception ServletException Servlet の正常な処理が妨げられたときに発生する例外
     */
    @Override
    public void service( final HttpServletRequest request, final HttpServletResponse response )
            throws IOException, ServletException {
        try {
            response.setCharacterEncoding( "Windows-31J" );

            HttpSession session = request.getSession( false );
            DownloadFileBean fileBean = (DownloadFileBean) session.getAttribute( SESSION_KEY );
            if (fileBean == null) {
                Log.debug( "ダウンロードするファイルはありません。ブラウザの戻るボタンが使用された可能性があります。" );
                response.getOutputStream().println("ブラウザの戻るボタンは使用できません。");
                return;
            }
            byte[] fileData = fileBean.getFlieData();
            session.removeAttribute( SESSION_KEY );

            String fileName = strEncode( fileBean.getFileName() );

            // contentTypeを出力
            response.setContentType( fileBean.getContentType() );

            // ファイル名の送信(attachment部分をinlineに変更すればインライン表示)
            response.setHeader( "Content-disposition", "attachment; "
                    + this.createHeaderFileName( fileName ) );

            // ファイル内容の出力
            ServletOutputStream out = response.getOutputStream();
            try {
                out.write( fileData );
            } finally {
                out.close();
            }

            response.flushBuffer();
        } catch ( IOException ex ) {
            Log.error( loginNo, ex );
            throw new CareerRuntimeException( ex );
        }
    }

    /**
     * 文字コードの変換を行う。
     * @param strVal 文字コードの変換を行う文字列
     * @exception CareerRuntimeException リシテアCareer用実行時Exceptio
     */
    public String strEncode( String strVal ) throws CareerRuntimeException {
        try {
            if ( strVal == null ) {
                return null;
            } else {
                return new String( strVal.getBytes( "Shift_JIS" ), "ISO-8859-1" );
            }
        } catch ( UnsupportedEncodingException ex ) {
            Log.error( loginNo, ex );
            throw new CareerRuntimeException( ex );
        }
    }

    /**
     * ファイル名から拡張子を取り出す
     * @param fileName ファイル名
     * @return ファイルの拡張子
     */
    public String getExtention( String fileName ) {
        if ( fileName != null ) {
            int idx = fileName.lastIndexOf( '.' );

            if ( idx != -1 ) {
                return fileName.substring( idx + 1 );
            }
        }
        return "";
    }

    /**
     * ファイル名からResponseのヘッダに設定する文字列を生成する
     * @param fileName ファイル名
     * @return ヘッダ設定用ファイル名
     */
    public String createHeaderFileName( String fileName ) {
        String headerFileName = "";
        if ( fileName != null && fileName.length() > 0 ) {
            headerFileName = "filename=\"" + fileName + "\"";
        }
        return headerFileName;
    }

}
