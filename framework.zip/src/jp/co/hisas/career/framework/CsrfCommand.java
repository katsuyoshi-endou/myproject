package jp.co.hisas.career.framework;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.app.common.bean.UserInfoBean;
import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.CommonParameter;

public class CsrfCommand {
	
	private String tokenNo = null;
	private static final String DONT_NEW_TOKEN_NO_GAMEN_ID = CommonParameter.getValue( "Base", "CsrfNoCheck" );
	
	public String getTokenNo() {
		return tokenNo;
	}
	
	public void setTokenNo( String tokenNo ) {
		this.tokenNo = tokenNo;
	}
	
	protected boolean requiredTokenCheck = false;
	
	private ServletContext ctx = null;
	
	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	public final void initToken( final String dispatch, final HttpServletRequest request ) {
		
		String login_no = null;
		try {
			HttpSession session = request.getSession();
			
			/* 新規採番する画面ID,Servletの組み合わせかを確認 */
			String servletName = dispatch.replaceAll( "/servlet/", "" );
			String gamenId = (String)session.getAttribute( "gamenId" );
			if (DONT_NEW_TOKEN_NO_GAMEN_ID.indexOf( gamenId + ":" + servletName ) != -1) {
				return;
			}
			
			final UserInfoBean userinfobean = (UserInfoBean)session.getAttribute( "userinfo" );
			login_no = userinfobean.getLogin_no();
			Log.security( login_no, "トークンNoを新規に採番します。" );
			session.setAttribute( "tokenNo", UUID.randomUUID().toString() );
			Log.security( login_no, "トークン番号：" + session.getAttribute( "tokenNo" ) );
			
		} catch (final Exception e) {
			Log.error( login_no, e );
			
		}
		
	}
	
	public void doItToken( final HttpServletRequest request, final HttpServletResponse response ) throws CareerException, IOException, ServletException {
		
		String login_no = null;
		HttpSession session = request.getSession();
		
		try {
			
			Log.security( login_no, "トークンNoチェック処理を開始します。" );
			final UserInfoBean userinfobean = (UserInfoBean)session.getAttribute( "userinfo" );
			login_no = userinfobean.getLogin_no();
			String gamenID = (String)session.getAttribute( "gamenId" );
			if (gamenID != null && DONT_NEW_TOKEN_NO_GAMEN_ID.indexOf( gamenID ) != -1 && DONT_NEW_TOKEN_NO_GAMEN_ID.indexOf( gamenID + ":" ) == -1) {
				Log.security( login_no, "トークンNoチェック対象外" );
				return;
			}
			
			String sessionTokenNo = (String)session.getAttribute( "tokenNo" );
			String tokenNo = (String)request.getParameter( "tokenNo" );
			
			if (sessionTokenNo != null && tokenNo != null) {
				if (sessionTokenNo.equals( tokenNo )) {
					
					Log.security( login_no, "トークン番号一致" );
				} else {
					Log.security( login_no, "トークン番号不一致" );
					throw new CareerException( "HJE-1001" );
				}
			} else {
				Log.security( login_no, "トークン番号がNullです。" );
				throw new CareerException( "HJE-1001" );
			}
			
		} catch (final Exception e) {
			Log.error( login_no, e );
			ctx.getRequestDispatcher( "/view/error.jsp" ).forward( request, response );
		}
		
	}
	
}
