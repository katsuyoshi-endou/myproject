/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.taglib;

import java.io.IOException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

import jp.co.hisas.career.framework.SimpleXmlBuilder;
import jp.co.hisas.career.util.log.Log;

/**
 * 
 * @author kat-watanabe
 *
 */
public class ScrollBodyTag extends BodyTagSupport {

    /**
     * {@inheritDoc}
     */
    @Override
    public int doStartTag() throws JspException {
        try {
            SimpleXmlBuilder html = new SimpleXmlBuilder();
            html.startElement( "div" );
            html.writeAttribute( "id", "scroller" );
            html.writeAttribute( "style", "overflow-y: scroll; overflow-x: hidden; width: 100%;" );
            html.finishStartTag();
            html.writeScriptElement( "_fw_registScrollAreaResizeEvent();" );
            pageContext.getOut().println( html.toString() );
        } catch ( IOException ex ) {
            Log.error( "", ex );
        }
        return BodyTagSupport.EVAL_BODY_BUFFERED;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int doEndTag() throws JspException {
        try {
            JspWriter out = pageContext.getOut();
            out.println( "</div>" );
        } catch ( IOException ex ) {
            Log.error( "", ex );
        }
        return BodyTagSupport.EVAL_PAGE;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int doAfterBody() throws JspException {
        try {
            BodyContent bodyContent = getBodyContent();
            JspWriter out = bodyContent.getEnclosingWriter();
            bodyContent.writeOut( out );
            bodyContent.clearBody();
        } catch ( IOException ex ) {
            Log.error( "", ex );
        }
        return BodyTagSupport.SKIP_BODY;
    }

}
