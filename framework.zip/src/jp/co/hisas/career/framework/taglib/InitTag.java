/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.framework.taglib;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import jp.co.hisas.career.framework.trans.AbstractCommand;
import jp.co.hisas.career.framework.trans.CommonServlet;
import jp.co.hisas.career.framework.trans.ViewManager;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;

/**
 * Commandクラスのinitを呼び出すカスタムタグ。
 * @author kat-watanabe
 */
public class InitTag extends SimpleTagSupport {

    private final String HTML_FORMAT =
            "<script type=\"text/javascript\"><!-- \r\n"
                    + "window.top.document.title=\"%s\";\r\n--></script>";

    private Class<?> commandClass;

    private String kinouTitle;

    /**
     * commandClass を取得します。
     * @return commandClass
     */
    public Class<?> getCommandClass() {
        return commandClass;
    }

    /**
     * commandClass を設定します。
     * @param commandClass commandClass に設定する値。
     */
    public void setCommandClass( Class<?> commandClass ) {
        this.commandClass = commandClass;
    }

    /**
     * kinouTitle を取得します。
     * @return kinouTitle
     */
    public String getKinouTitle() {
        return kinouTitle;
    }

    /**
     * kinouTitle を設定します。
     * @param kinouTitle kinouTitle に設定する値。
     */
    public void setKinouTitle( String kinouTitle ) {
        this.kinouTitle = kinouTitle;
    }

    /**
     * commandClass をキャストして取得します。
     * @return commandClass
     */
    @SuppressWarnings( "unchecked" )
    private Class<? extends AbstractCommand> getAbstractCommandClass() {
        return (Class<? extends AbstractCommand>) commandClass;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void doTag() throws JspException, IOException {
        PageContext pc = (PageContext) this.getJspContext();
        CommonServlet.callInit( (HttpServletRequest) pc.getRequest(),
                (HttpServletResponse) pc.getResponse(), getAbstractCommandClass() );
        if ( kinouTitle != null ) {
            @SuppressWarnings("unused")
			String kinouId = ViewManager.getKinouIdFromCommand( getAbstractCommandClass() );
            this.getJspContext().getOut().println( String.format( HTML_FORMAT,  PZZ010_CharacterUtil.convertCharCode(kinouTitle) ) );
        }
    }

}
