/*
 * All Rights Reserved. Copyright (C) 2008,2009, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.taglib;

import java.io.IOException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

import jp.co.hisas.career.framework.SimpleXmlBuilder;
import jp.co.hisas.career.framework.WebUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * リンクを表示するためのカスタムタグ。
 * actionId属性で指定した値が、コマンドクラスのメソッド名に対応する。
 * @author kat-watanabe
 */
public class AnchorTag extends BodyTagSupport {

    private String actionId;

    private String onclick;

    private String target;
    
    private String style = null;

    /**
     * target を取得します。
     * @return target
     */
    public String getTarget() {
        return target;
    }

    /**
     * target を設定します。
     * @param target target に設定する値。
     */
    public void setTarget( String target ) {
        this.target = target;
    }

    /**
     * onclick を取得します。
     * @return onclick
     */
    public String getOnclick() {
        return onclick;
    }

    /**
     * onclick を設定します。
     * @param onclick onclick に設定する値。
     */
    public void setOnclick( String onclick ) {
        this.onclick = onclick;
    }

    /**
     * actionId を取得します。
     * @return actionId
     */
    public String getActionId() {
        return actionId;
    }

    /**
     * actionId を設定します。
     * @param actionId actionId に設定する値。
     */
    public void setActionId( String actionId ) {
        this.actionId = actionId;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int doStartTag() throws JspException {
        if ( target == null ) {
            target = "_self";
        }
        SimpleXmlBuilder html = new SimpleXmlBuilder();
        html.startElement( "a" );
        html.writeAttribute( "href", "#" );
        html.formatAttribute( "onclick", TransitTag.ACTION_JSCRIPT, actionId, target,
                WebUtil.normalizeJavascript( onclick ) );
        html.writeAttribute( "alt", "" );
        html.writeAttribute("style", style);
        html.finishStartTag();
        try {
            pageContext.getOut().print( html.toString() );
        } catch ( IOException ex ) {
            Log.error( "", ex );
        }
        return BodyTagSupport.EVAL_BODY_BUFFERED;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int doEndTag() throws JspException {
        try {
            JspWriter out = pageContext.getOut();
            out.print( "</a>" );
        } catch ( IOException ex ) {
            Log.error( "", ex );
        }
        return BodyTagSupport.EVAL_PAGE;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int doAfterBody() throws JspException {
        try {
            BodyContent bodyContent = getBodyContent();
            JspWriter out = bodyContent.getEnclosingWriter();
            bodyContent.writeOut( out );
            bodyContent.clearBody();
        } catch ( IOException ex ) {
            Log.error( "", ex );
        }
        return BodyTagSupport.SKIP_BODY;
    }

    
    public String getStyle() {
        return style;
    }

    
    public void setStyle(String style) {
        this.style = style;
    }

}
