/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.framework.taglib;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;

/**
 * JSPにメッセージを表示するためのカスタムタグ。 実体は msgFile.properties に定義される。
 *
 * @author kats-watanabe
 */
public class OutTag extends SimpleTagSupport {

	private String value = null;
	private boolean sanitize = true;
	private boolean break2Html = false;

    public void doTag() throws JspException, IOException {

        this.value = PZZ010_CharacterUtil.convertCharCode( this.value );
        if( this.sanitize ){
        	this.value = PZZ010_CharacterUtil.sanitizeStrData(this.value);
        }
        if( this.break2Html ){
        	this.value = PZZ010_CharacterUtil.changeHTMLbr(this.value);
        }
        this.getJspContext().getOut().print( this.value );
    }

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public boolean isSanitize() {
		return sanitize;
	}

	public void setSanitize(boolean sanitize) {
		this.sanitize = sanitize;
	}

	public boolean isBreak2Html() {
		return break2Html;
	}

	public void setBreak2Html(boolean break2Html) {
		this.break2Html = break2Html;
	}

}
