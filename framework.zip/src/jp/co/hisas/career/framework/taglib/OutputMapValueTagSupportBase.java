/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.framework.taglib;

import java.io.IOException;
import java.util.Map;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * Map の値を出力するカスタムタグの基底クラス。
 * @author kats-watanabe
 *
 */
public abstract class OutputMapValueTagSupportBase extends SimpleTagSupport {

    private String id;

    private boolean sanitize = false;

    private boolean newLine = false;

    private String breakPositions = "";

    private boolean withBox = false;

    /**
     * breakPositions を取得します。
     * @return breakPositions
     */
    public String getBreakPositions() {
        return breakPositions;
    }

    /**
     * breakPositions を設定します。
     * @param breakPositions breakPositions に設定する値。
     */
    public void setBreakPositions( String breakPositions ) {
        this.breakPositions = breakPositions;
    }

    /**
     * 名称を取得します。
     * @return id 名称
     */
    public String getId() {
        return id;
    }

    /**
     * 名称を設定します。
     * @param id 名称に設定する値。
     */
    public void setId( String id ) {
        this.id = id;
    }

    /**
     * sanitize を設定します。
     * @param sanitize sanitize に設定する値。
     */
    public void setSanitize( boolean sanitize ) {
        this.sanitize = sanitize;
    }

    /**
     * sanitize を取得します。
     * @return sanitize
     */
    public boolean isSanitize() {
        return sanitize;
    }

    /**
     * newLine を設定します。
     * @param newLine newLine に設定する値。
     */
    public void setNewLine( boolean newLine ) {
        this.newLine = newLine;
    }

    /**
     * newLine を取得します。
     * @return newLine
     */
    public boolean isNewLine() {
        return newLine;
    }

    /**
     * このクラスに対応するマップを取得する。継承するクラスごとに指定する。
     * @return このクラスに対応するマップ。
     */
    protected abstract Map<String, String> getMap();

    /**
     * {@inheritDoc}
     */
    @Override
    public void doTag() throws JspException, IOException {
        if ( getMap() != null ) {
            String value = getMap().get( id );
            if ( value != null && !"".equals(value)) {
                if ( breakPositions != null && breakPositions.length() > 0 ) {
                    StringBuilder buf = new StringBuilder( value );
                    String[] breakPositionSplit = breakPositions.split( "," );
                    // 挿入するたびにインデックスがずれるので、降順に処理する。
                    for ( int i = breakPositionSplit.length - 1; i >= 0; i-- ) {
                        try {
                            int pos = Integer.parseInt( breakPositionSplit[i] );
                            buf.insert( pos, "\r\n" );
                        } catch ( Exception e ) {
                            Log.error("", e);
                            error( "Failed to insert break at position:%s.", breakPositionSplit[i] );
                        }
                    }
                    value = buf.toString();
                }
                if ( sanitize ) {
                    value =
                            PZZ010_CharacterUtil.changeHTMLbr( PZZ010_CharacterUtil.sanitizeStrAttribute( value ) );
                }
                if( withBox ){
	                value = "					<!-- メッセージ：ガイダンス -->" +
				                "					<div class=\"guidanceMessage\">" +
				                "						<ul>" +
				                "							<li>" + value +
				                "							</li>" +
				                "						</ul>" +
				                "					</div>";
                }
                if ( newLine ) {
                    this.getJspContext().getOut().println( value );
                } else {
                    this.getJspContext().getOut().print( value );
                }
            } else {
                error( "%s: id '%s' not found.", id );
            }
        } else {
            error( "%s: map not found for '%s'.", id );
        }
    }

    private void error( String messageFormat, String id ) {
        Log.debug( String.format( messageFormat, this.getClass().getSimpleName(), id ) );
    }

	public boolean isWithBox() {
		return withBox;
	}

	public void setWithBox(boolean withBox) {
		this.withBox = withBox;
	}

}
