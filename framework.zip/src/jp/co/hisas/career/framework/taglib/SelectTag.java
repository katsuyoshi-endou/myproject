/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.taglib;

import java.io.IOException;
import java.util.Arrays;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

import jp.co.hisas.career.framework.LabelValuePair;
import jp.co.hisas.career.framework.SimpleXmlBuilder;
import jp.co.hisas.career.framework.WebUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * JSPにリストボックスを表示するためのカスタムタグ。
 * リストボックスの選択変更時に画面遷移が発生する場合にこのタグを使用する。
 * actionId属性で指定した値が、コマンドクラスのメソッド名に対応する。
 * ただし、actionId属性を空文字列とした場合、画面遷移は発生しない。
 * @author kats-watanabe
 *
 */
public class SelectTag extends BodyTagSupport {

    private String actionId;

    private String name;

    private Integer size;

    private String nameOfItems;

    private boolean multiple = false;

    private String onchange;

    private String target;

    private String style = null;
    
    private String value = null;

    /**
     * style を取得します。
     * @return style
     */
    public String getStyle() {
        return style;
    }

    /**
     * style を設定します。
     * @param style style に設定する値。
     */
    public void setStyle( String style ) {
        this.style = style;
    }

    /**
     * target を取得します。
     * @return target
     */
    public String getTarget() {
        return target;
    }

    /**
     * target を設定します。
     * @param target target に設定する値。
     */
    public void setTarget( String target ) {
        this.target = target;
    }

    /**
     * onchange を取得します。
     * @return onchange
     */
    public String getOnchange() {
        return onchange;
    }

    /**
     * onchange を設定します。
     * @param onchange onchange に設定する値。
     */
    public void setOnchange( String onchange ) {
        this.onchange = onchange;
    }

    /**
     * name を取得します。
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * name を設定します。
     * @param name name に設定する値。
     */
    public void setName( String name ) {
        this.name = name;
    }

    /**
     * size を取得します。
     * @return size
     */
    public Integer getSize() {
        return size;
    }

    /**
     * size を設定します。
     * @param size size に設定する値。
     */
    public void setSize( Integer size ) {
        this.size = size;
    }

    /**
     * actionId を取得します。
     * @return actionId
     */
    public String getActionId() {
        return actionId;
    }

    /**
     * actionId を設定します。
     * @param actionId actionId に設定する値。
     */
    public void setActionId( String actionId ) {
        this.actionId = actionId;
    }

    /**
     * nameOfItems を取得します。
     * @return nameOfItems
     */
    public String getNameOfItems() {
        return nameOfItems;
    }

    /**
     * nameOfItems を設定します。
     * @param nameOfItems nameOfItems に設定する値。
     */
    public void setNameOfItems( String nameOfItems ) {
        this.nameOfItems = nameOfItems;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int doStartTag() throws JspException {
        if ( target == null ) {
            target = "_self";
        }
        try {
            SimpleXmlBuilder html = new SimpleXmlBuilder();
            html.startElement( "select" );
            html.writeAttribute( "name", name );
            html.writeOptionalAttribute( "size", size );
            if ( actionId != null && !"".equals( actionId ) ) {
                html.formatAttribute( "onchange", TransitTag.ACTION_JSCRIPT, actionId, target,
                        WebUtil.normalizeJavascript( onchange ) );
            } else if ( onchange != null ) {
                html.formatAttribute( "onchange", "JavaScript:if (!actionEnabled) { return; } %s",
                        WebUtil.normalizeJavascript( onchange ) );
            }
            if ( multiple ) {
                html.writeAttribute( "multiple", "multiple" );
            }
            html.writeOptionalAttribute( "style", style );
//            html.writeAttribute( "disabled", "disabled" );
            html.finishStartTag();

            // nameOfItems属性が設定されている場合、リストの内容も出力する。
            Iterable<LabelValuePair> itemCollection = getItemCollection();
            if ( itemCollection != null ) {
                String selectedValue = null;
                if ( this.value != null ) {
                    selectedValue = this.value;
                } else if ( this.name != null ) {
                    selectedValue = (String) pageContext.getRequest().getAttribute( this.name );
                }
                for ( LabelValuePair lv : itemCollection ) {
                    html.startElement( "option" );
                    html.writeAttribute( "value", lv.getValue() );
                    if ( selectedValue != null && selectedValue.equals( lv.getValue() ) ) {
                        html.writeAttribute( "selected", "selected" );
                    }
                    html.finishStartTag();
                    html.writeText( lv.getLabel() );
                    html.writeElementEndTag( "option" );
                }
            }

            pageContext.getOut().println( html.toString() );
        } catch ( IOException ex ) {
            Log.error( "", ex );
        }
        return BodyTagSupport.EVAL_BODY_BUFFERED;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int doEndTag() throws JspException {
        try {
            JspWriter out = pageContext.getOut();
            out.println( "</select>" );
        } catch ( IOException ex ) {
            Log.error( "", ex );
        }
        return BodyTagSupport.EVAL_PAGE;
    }

    @SuppressWarnings( "unchecked" )
    private Iterable<LabelValuePair> getItemCollection() {
        if ( nameOfItems == null ) {
            return null;
        }
        Object attribute = pageContext.getRequest().getAttribute( nameOfItems );
        if ( attribute instanceof LabelValuePair[] ) {
            attribute = Arrays.asList( (LabelValuePair[]) attribute );
        }
        return (Iterable<LabelValuePair>) attribute;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int doAfterBody() throws JspException {
        try {
            BodyContent bodyContent = getBodyContent();
            JspWriter out = bodyContent.getEnclosingWriter();
            bodyContent.writeOut( out );
            bodyContent.clearBody();
        } catch ( IOException ex ) {
            Log.error( "", ex );
        }
        return BodyTagSupport.SKIP_BODY;
    }

    /**
     * multiple を取得します。
     * @return multiple
     */
    public boolean isMultiple() {
        return multiple;
    }

    /**
     * multiple を設定します。
     * @param multiple multiple に設定する値。
     */
    public void setMultiple( boolean multiple ) {
        this.multiple = multiple;
    }

    
    /**
     * @return value
     */
    public String getValue() {
        return value;
    }

    
    /**
     * @param value 設定する value
     */
    public void setValue(String value) {
        this.value = value;
    }

}
