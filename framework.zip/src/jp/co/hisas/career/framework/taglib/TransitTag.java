package jp.co.hisas.career.framework.taglib;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

import jp.co.hisas.career.app.AppDef;
import jp.co.hisas.career.framework.SimpleXmlBuilder;
import jp.co.hisas.career.framework.trans.CommonServlet;
import jp.co.hisas.career.framework.trans.DownloadServlet;
import jp.co.hisas.career.util.log.Log;

/**
 * カスタムタグ fw:transit の動作を実装するクラス。 fw:transit は HTML の form タグの代替としてJSPで使用する。
 * 
 * @author kats-watanabe
 */
public class TransitTag extends BodyTagSupport {
	
	public static final String EVENT_OBJECT = "eventObj";
	/**
	 * fw:transit のアクションを実行するためのスクリプト。 ボタンやリンクなど、fw:transit タグの子のタグが使用する。
	 */
	static final String ACTION_JSCRIPT = "JavaScript:var " + TransitTag.EVENT_OBJECT + " = this; _fw_action('F001', '" + CommonServlet.TRANSIT_ACTION + "', '%s', '%s', function(){%s})";
	
	private String kinouId = "";
	
	private boolean downloadFormOnly = false;
	
	private String focusedElement = "";
	
	private boolean multipart = false;
	
	public String getKinouId() {
		return kinouId;
	}
	
	public void setKinouId( String kinouId ) {
		this.kinouId = kinouId;
	}
	
	public boolean isDownloadFormOnly() {
		return downloadFormOnly;
	}
	
	public void setDownloadFormOnly( boolean downloadFormOnly ) {
		this.downloadFormOnly = downloadFormOnly;
	}
	
	public String getFocusedElement() {
		return focusedElement;
	}
	
	public void setFocusedElement( String focusedElement ) {
		this.focusedElement = focusedElement;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public int doStartTag() throws JspException {
		try {
			SimpleXmlBuilder html = new SimpleXmlBuilder();
			
			// ダウンロードするデータが設定されている場合は、通常のformタグの前にダウンロード用のformタグを出力する。
			if (pageContext.getSession().getAttribute( DownloadServlet.SESSION_KEY ) != null) {
				html.startElement( "form" );
				html.writeAttribute( "name", "_FW_FORM_DOWNLOAD" );
				html.writeAttribute( "method", "post" );
				html.writeAttribute( "action", "/" + AppDef.CTX_ROOT + "/servlet/DownloadServlet" );
				html.writeAttribute( "enctype", "multipart/form-data" );
				html.finishStartTag();
				html.writeElementEndTag( "form" );
				html.writeText( "\r\n" );
			}
			
			if (!downloadFormOnly) {
				
				/* form tag */
				html.startElement( "form" );
				html.writeAttribute( "name", "F001" );
				html.writeAttribute( "method", "post" );
				html.writeAttribute( "action", "/" + AppDef.CTX_ROOT + "/servlet/CommonServlet" );
				html.writeAttribute( "target", "_self" );
				// フォーム内にテキストボックスが1つしかないときEnterキーでsubmitされるのを回避。
				html.writeAttribute( "onsubmit", "return false;" );
				if (multipart) {
					html.writeAttribute( "enctype", "multipart/form-data" );
				}
				html.finishStartTag();
				html.writeText( "\r\n" );
				
				/* _FW_TRANSIT_KINOU_ID */
				html.startElement( "input" );
				html.writeAttribute( "type", "hidden" );
				html.writeAttribute( "name", CommonServlet.TRANSIT_KINOU_ID );
				html.writeAttribute( "value", kinouId );
				html.finishEmptyElementTag();
				html.writeText( "\r\n" );
				
				/* _FW_TRANSIT_ACTION */
				html.startElement( "input" );
				html.writeAttribute( "type", "hidden" );
				html.writeAttribute( "name", CommonServlet.TRANSIT_ACTION );
				html.writeAttribute( "value", "" );
				html.finishEmptyElementTag();
				html.writeText( "\r\n" );
				
//				String script = "// 自フレームが読み込み完了したらtrueになる値\r\n" + "var documentLoaded = false;\r\n" + "// すべての兄弟フレームが読み込み完了したらtrueになる値。二度押し抑止にも使用。\r\n" + "var actionEnabled = false;\r\n" + "//自フレーム読み込み完了タイミングを親フレームに通知する。子フレームがすべて通知完了したらボタンを有効化する。\r\n" + "attachOnload(function() { documentLoaded = true; frameLoadedHandler(); } );";
//				if (!PZZ010_CharacterUtil.isEmpty( focusedElement )) {
//					script = String.format( "%s\r\nvar _fw_focusedElement = \"%s\"; ", script, focusedElement );
//				}
//				html.writeScriptElement( script );
			}
			
			html.writeText( "\r\n" );
			pageContext.getOut().println( html.toString() );
		} catch (IOException ex) {
			Log.error( "", ex );
		}
		return BodyTagSupport.EVAL_BODY_BUFFERED;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public int doEndTag() throws JspException {
		try {
			JspWriter out = pageContext.getOut();
			if (!downloadFormOnly) {
				out.println( "</form>" );
			}
		} catch (IOException ex) {
			Log.error( "", ex );
		}
		return BodyTagSupport.EVAL_PAGE;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public int doAfterBody() throws JspException {
		try {
			BodyContent bodyContent = getBodyContent();
			JspWriter out = bodyContent.getEnclosingWriter();
			bodyContent.writeOut( out );
			bodyContent.clearBody();
		} catch (IOException ex) {
			Log.error( "", ex );
		}
		return BodyTagSupport.SKIP_BODY;
	}
	
	public boolean isMultipart() {
		return multipart;
	}
	
	public void setMultipart( boolean multipart ) {
		this.multipart = multipart;
	}
	
}
