package jp.co.hisas.career.framework.event;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.ejb.AbstractEventHandler;
import jp.co.hisas.career.framework.exception.CareerSQLException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.dao.DaoUtil;
import jp.co.hisas.career.util.log.Log;

public class DynamicSqlSelectEvHdlr extends AbstractEventHandler<DynamicSqlSelectEvArg, DynamicSqlSelectEvRslt> {
	
	private String loginNo;
	
	/**
	 * Called from Servlet or Command Class.
	 */
	public static DynamicSqlSelectEvRslt exec( DynamicSqlSelectEvArg arg ) throws CareerException {
		DynamicSqlSelectEvHdlr handler = new DynamicSqlSelectEvHdlr();
		return handler.call( arg );
	}
	
	public DynamicSqlSelectEvRslt call( DynamicSqlSelectEvArg arg ) throws CareerException {
		DynamicSqlSelectEvRslt result = null;
		Log.method( arg.getLoginNo(), "IN", "" );
		if (Log.isDebugMode()) {
			result = this.execute( arg );
		} else {
			result = this.callEjb( arg );
		}
		Log.method( arg.getLoginNo(), "OUT", "" );
		return result;
	}
	
	protected DynamicSqlSelectEvRslt execute( DynamicSqlSelectEvArg arg ) throws CareerException {
		
		arg.validateArg();
		this.loginNo = arg.getLoginNo();
		
		DynamicSqlSelectEvRslt result = new DynamicSqlSelectEvRslt();
		
		try {
			
			if ("DYNAMIC_SELECT".equals( arg.sharp )) {
				
				result.dataList = getDataList( arg );
			}
			else if ("INIT".equals( arg.sharp )) {
				
			}
			
			return result;
		} catch (Exception e) {
			throw new CareerException( e.getMessage() );
		} finally {
			Log.method( arg.getLoginNo(), "OUT", "" );
		}
	}
	
	private List<Map<String, String>> getDataList( DynamicSqlSelectEvArg arg ) throws Exception {
		
		return this.executeDynamicSqlSelect( DaoUtil.getPstmt( arg.sql, arg.paramList ) );
	}
	
	public List<Map<String, String>> executeDynamicSqlSelect( PreparedStatement pstmt ) {
		
		Log.sql( "【DaoMethod Call】 DynamicSqlSelect" );
		ResultSet rs = null;
		try {
			rs = pstmt.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			int colCnt = rsmd.getColumnCount();
			List<String> colNameList = new ArrayList<String>();
			for (int i = 1; i <= colCnt; i++) {
				colNameList.add( rsmd.getColumnName( i ) );
				// String lbl = rsmd.getColumnLabel(i);
			}
			
			List<Map<String, String>> lst = new ArrayList<Map<String, String>>();
			Map<String, String> dataList = null;
			while (rs.next()) {
				dataList = new LinkedHashMap<String, String>();
				for (String colname : colNameList) {
					dataList.put( colname, DaoUtil.convertNullToString( rs.getString( colname ) ) );
				}
				lst.add( dataList );
			}
			return lst;
		} catch (final SQLException e) {
			Log.error( loginNo, e );
			throw new CareerSQLException( e );
		} finally {
			PZZ040_SQLUtility.closeConnection( loginNo, null, pstmt, rs );
		}
	}
}
