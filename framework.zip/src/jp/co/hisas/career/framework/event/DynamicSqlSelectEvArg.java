package jp.co.hisas.career.framework.event;

import java.util.ArrayList;
import java.util.List;

import jp.co.hisas.career.framework.exception.CareerException;
import jp.co.hisas.career.ejb.AbstractEventArg;

@SuppressWarnings("serial")
public class DynamicSqlSelectEvArg extends AbstractEventArg {
	
	public String sharp = null;
	public String sql = null;
	public List<String> paramList = new ArrayList<String>();
	
	public DynamicSqlSelectEvArg(String loginNo) throws CareerException {
		if (loginNo == null) {
			throw new CareerException( "Invalid Arg: arg is null." );
		}
		this.setLoginNo( loginNo );
	}
	
	public void validateArg() throws CareerException {
		if (this.sharp == null || "".equals( this.sharp.trim() )) {
			throw new CareerException( "Invalid Arg: sharp is null." );
		}
		if (this.sql == null || "".equals( this.sql.trim() )) {
			throw new CareerException( "Invalid Arg: sql is null." );
		}
	}
	
}
