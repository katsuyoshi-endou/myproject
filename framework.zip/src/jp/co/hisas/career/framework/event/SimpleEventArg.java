/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.event;

import jp.co.hisas.career.ejb.AbstractEventArg;

/**
 * 引数がないイベントに使用する EventArg クラス。
 * 
 * @author k-ozawa
 */
@SuppressWarnings("serial")
public final class SimpleEventArg extends AbstractEventArg {
	
	/**
	 * デフォルトコンストラクタ
	 */
	public SimpleEventArg() {
	}
	
	/**
	 * コンストラクタ。ログイン社員番号を引数に取る。
	 * 
	 * @param loginNo ログイン社員番号
	 */
	public SimpleEventArg(final String loginNo) {
		setLoginNo( loginNo );
	}
	
}
