package jp.co.hisas.career.framework;

import java.util.HashMap;

import javax.ejb.EJBHome;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import jp.co.hisas.career.util.SU;
import jp.co.hisas.career.util.log.Log;

public class EJBHomeFactory {
	
	/** このクラスのインスタンス */
	private static EJBHomeFactory instance = null;
	
	/** EJBHomeのMap */
	private HashMap<Class<?>, EJBHome> homeInterfaces = null;
	
	/** Context */
	private Context context = null;
	
	/** EJB検索URLprefix */
	private static final String JNDI_PREFIX = "";
	
	/** JDBC種別 */
	private static String JDBC_TYPE = "";
	private static final String JDBC_TYPE_COSMINEXUS = "DABroker";
	private static final String JDBC_TYPE_ORACLE_AS = "OracleAS";
	
	/**
	 * コンストラクタ
	 */
	private EJBHomeFactory() throws NamingException {
		this.homeInterfaces = new HashMap<Class<?>, EJBHome>();
		this.context = new InitialContext();
		EJBHomeFactory.JDBC_TYPE = JDBC_TYPE_ORACLE_AS;
	}
	
	/**
	 * このクラスのインスタンスを返す
	 * 
	 * @return EJBHomeFactoryのインスタンス
	 * @throws NamingException
	 */
	public static EJBHomeFactory getInstance() throws NamingException {
		try {
			if (EJBHomeFactory.instance == null) {
				EJBHomeFactory.instance = new EJBHomeFactory();
			}
		} catch (final NamingException e) {
			Log.error( "", e );
			throw e;
		}
		return EJBHomeFactory.instance;
	}
	
	/**
	 * 取得したいEJBHomeのクラスから対応するEJBHomeインタフェースを返す。<BR>
	 * PYF_BlobDBAccessEJBが引数に渡された場合、DB種別により取得するEJBHomeを切り替える
	 * 
	 * @param homeInterfaceClass 取得したいEJBHomeクラス
	 * @return EJBHomeインタフェース
	 * @throws NamingException JNDIのlookup失敗
	 */
	public EJBHome lookup( final Class<?> homeInterfaceClass ) throws NamingException {
		
		// クラス名を取得する
		// Example: "jp.co.hisas.career.common.event.EventEJBHome" → "EventEJB"
		String ejbClassName = SU.extract( homeInterfaceClass.getName(), "\\.(\\w+)Home$" );
		
		// BLob操作クラスの場合JDBC種別により取得する名称を切り替える
		if ("PYF_BlobDBAccessEJB".equals( ejbClassName )) {
			if (EJBHomeFactory.JDBC_TYPE.equals( JDBC_TYPE_COSMINEXUS )) {
				ejbClassName = "PYF_BlobDBAccessCosmiEJB";
			} else if (EJBHomeFactory.JDBC_TYPE.equals( JDBC_TYPE_ORACLE_AS )) {
				ejbClassName = "PYF_BlobDBAccessOracleEJB";
			}
		}
		
		// JNDI名
		final String jndiName = EJBHomeFactory.JNDI_PREFIX + ejbClassName;
		
		// 既に生成されているEJBHomeか調べる
		EJBHome homeInterface = (EJBHome)this.homeInterfaces.get( homeInterfaceClass );
		
		// まだ1度も生成されていなければEJBHomeを生成する
		if (homeInterface == null) {
			final Object obj = this.context.lookup( jndiName );
			homeInterface = (EJBHome)PortableRemoteObject.narrow( obj, homeInterfaceClass );
			// 生成したEJBHomeを格納する
			this.homeInterfaces.put( homeInterfaceClass, homeInterface );
		}
		
		// 引数のEJBHomeクラスに対応するHomeを返す
		return homeInterface;
	}
	
}
