/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.framework.exception;

/**
 * リシテアCareer用Exception アプリケーション定義の例外を表す。
 */
public class CareerException extends Exception {
	
	/** メッセージに挿入する文字列のリスト */
	private String[] messageParam = null;
	
	/**
	 * エラーメッセージを指定するコンストラクタ
	 * 
	 * @param message エラーメッセージ \@deprecated
	 *            メッセージIDのない予想外のエラーの場合、CareerRuntimeExceptionを使用してください。
	 */
	public CareerException(final String message) {
		super( message );
	}
	
	/**
	 * エラーメッセージを指定するコンストラクタ
	 * 
	 * @param message エラーメッセージ
	 * @param messageParam 置換文字リスト \@deprecated
	 *            メッセージIDのない予想外のエラーの場合、CareerRuntimeExceptionを使用してください。
	 */
	public CareerException(final String message, String[] messageParam) {
		super( message );
		this.messageParam = messageParam;
	}
	
	/**
	 * getMessagenParam メッセージの挿入文字列のリストを取得する。
	 * 
	 * @return (List) メッセージの挿入文字列のリスト
	 */
	public String[] getMessageParam() {
		return this.messageParam;
	}
}
