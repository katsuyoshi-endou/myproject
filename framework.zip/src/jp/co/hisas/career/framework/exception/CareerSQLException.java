/*
 * All Rights Reserved. Copyright (C) 2008, Hitachi Systems & Services, Ltd. 
 */
package jp.co.hisas.career.framework.exception;

/**
 * SQL例外をラップするための CareerRuntimeException
 * @author k-ozawa
 */
@SuppressWarnings( "serial" )
public class CareerSQLException extends CareerRuntimeException {

    /**
     * 詳細メッセージに null を使用して、CareerSQLException を生成します。
     */
    public CareerSQLException() {
    }

    /**
     * 指定された詳細メッセージを使用して、CareerSQLException を生成します。
     * @param message 詳細メッセージ。
     */
    public CareerSQLException( String message ) {
        super( message );
    }

    /**
     * (cause==null ? null : cause.toString()) の指定された原因および詳細メッセージを使用して
     * 新しい CareerSQLException を生成します。
     * 通常、(cause==null ? null : cause.toString()) には、cause のクラスおよび詳細メッセージが含まれます。
     * このコンストラクタは、実行時例外が他のスロー可能オブジェクトのラッパーである場合に有用です。 
     * @param cause 原因。
     */
    public CareerSQLException( Throwable cause ) {
        super( cause );
    }

    /**
     * 指定された詳細メッセージおよび原因を使用して、CareerSQLException を生成します。
     * @param message 詳細メッセージ。
     * @param cause 原因。
     */
    public CareerSQLException( String message, Throwable cause ) {
        super( message, cause );
    }

}
