package jp.co.hisas.career.framework.exception;

public class CareerSecurityException extends RuntimeException {
	
	public CareerSecurityException() {
	}
	
	public CareerSecurityException(String message) {
		super( message );
	}
	
	public CareerSecurityException(Throwable cause) {
		super( cause );
	}
	
	public CareerSecurityException(String message, Throwable cause) {
		super( message, cause );
	}
	
}
