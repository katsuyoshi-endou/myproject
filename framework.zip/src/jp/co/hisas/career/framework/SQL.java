package jp.co.hisas.career.framework;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import jp.co.hisas.career.util.log.Log;

public class SQL {
	
	String sqlString;
	String replaceSqlString;
	Map<String, SQLParameter> parameterMap = new HashMap<String, SQLParameter>();
	
	public SQL(String sql) {
		sqlString = sql.trim();
		replaceSqlString = replaceSpace( sqlString );
	}
	
	public void setParameter( int index, SQLParameter parameter ) {
		parameterMap.put( String.valueOf( index ), parameter );
	}
	
	public String getReplaceSpaceSQL() {
		return replaceSqlString;
	}
	
	private String replaceSpace( String str ) {
		// エラーはとりあえずもみ消す
		try {
			Pattern pattern = Pattern.compile( "[\\s]{1,}" );
			Matcher matcher = pattern.matcher( str );
			return matcher.replaceAll( " " );
		} catch (Exception ex) {
			Log.error( "", ex );
			return str;
		}
		
	}
	
	public String getExecutableSQL() {
		// エラーはとりあえずもみ消す
		try {
			StringBuffer buf = new StringBuffer( replaceSqlString );
			int index = 0;
			int pos;
			
			while (buf.indexOf( "?" ) > 0) {
				index++;
				pos = buf.indexOf( "?" );
				buf = new StringBuffer( buf.substring( 0, pos ) + getFormattedParameter( index ) + buf.substring( pos + 1 ) );
			}
			String ret = buf.toString();
			
			ret = ret.replaceAll( "=NULL", "IS NLLL" );
			ret = ret.replaceAll( "= NULL", "IS NULL" );
			
			return ret;
		} catch (Exception ex) {
			Log.error( "", ex );
			return replaceSqlString;
		}
	}
	
	private String getFormattedParameter( int index ) {
		try {
			return parameterMap.get( String.valueOf( index ) ).getFormatedParameter();
		} catch (Exception ex) {
			Log.error( "", ex );
			return "？"; // 全角です。
			
		}
	}
}
