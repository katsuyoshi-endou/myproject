/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/10/22  01.00      ���� ���V    �V�K�쐬
 */
package jp.co.hisas.addon.batch.learning.torikesisinsei.ejb;

import jp.co.hisas.addon.batch.learning.torikesisinsei.valuebean.*;
import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.rmi.*;

import java.sql.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_TorikesiUketukeDaoEJBBean�N���X
 *
 * �@�\�����F
 *   L55���[�N�e�[�u���̃f�[�^�A�N�Z�X���s���N���X
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PCY_TorikesiUketukeDaoEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PCY_TorikesiUketukeDaoEJBBean implements SessionBean {
    private SessionContext context = null;

    /**
     * L55�������\����t���[�N�e�[�u���������ɁA�����œn���ꂽ���������ɏ]��
     * �E�������\�����
     * �E�\����
     * �E�p�[�\�i�����
     * �E�Ȗڏ��
     * �E�N���X���
     * ���Z�b�g�����z����擾���܂��B
     *
     * @param torikesiBean
     * @param loginuser
     * @return
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_TorikesiSinseiWorkTableBean[] doSelectWithMousikomiJyokyo( 
        PCY_TorikesiSinseiWorkTableBean torikesiBean, PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            StringBuffer sql = new StringBuffer(  );
            sql.append( "SELECT " );
            sql.append( PCY_KamokuBean.getColumns( "KAMOKU" ) + ", " );
            sql.append( PCY_ClassBean.getColumns( "CLASS" ) + ", " );
            sql.append( PCY_MousikomiJyokyoBean.getColumns( "MOUSIKOMI" ) + ", " );
            sql.append( PCY_PersonalBean.getColumns( "PERSONAL" ) + ", " );
            sql.append( PCY_TorikesiSinseiWorkTableBean.getColumns( "TORIKESI" ) );
            sql.append( " FROM " );
            sql.append( HcdbDef.L01_TBL + " KAMOKU, " );
            sql.append( HcdbDef.L02_TBL + " CLASS, " );
            sql.append( HcdbDef.L15_TBL + " MOUSIKOMI, " );
            sql.append( HcdbDef.personalTbl + " PERSONAL, " );
            sql.append( HcdbDef.L55_TBL + " TORIKESI " );
            sql.append( " WHERE KAMOKU.KAMOKU_CODE = CLASS.KAMOKU_CODE" );
            sql.append( "   AND CLASS.KAMOKU_CODE  = MOUSIKOMI.KAMOKU_CODE" );
            sql.append( "   AND CLASS.CLASS_CODE   = MOUSIKOMI.CLASS_CODE" );
            sql.append( "   AND CLASS.KAMOKU_CODE  = TORIKESI.KAMOKU_CODE" );
            sql.append( "   AND CLASS.CLASS_CODE   = TORIKESI.CLASS_CODE" );
            sql.append( "   AND MOUSIKOMI.SIMEI_NO = TORIKESI.SIMEI_NO" );
            sql.append( "   AND MOUSIKOMI.SIMEI_NO = PERSONAL.SIMEI_NO" );
            sql.append( "   AND PERSONAL.HONMU_FLG = '" + HcdbDef.HONMU + "'" );

            Map extract = torikesiBean.extractConditions(  );

            for ( Iterator ite = extract.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                Object key = ite.next(  );
                sql.append( "   AND TORIKESI." + key.toString(  ) + "=?" );
            }

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            Log.debug( sql.toString(  ) );
            ps = con.prepareStatement( sql.toString(  ) );

            int ps_setCount = 1;

            for ( Iterator ite = extract.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                Object key = ite.next(  );
                ps.setObject( ps_setCount++, extract.get( key ) );
            }

            ResultSet rs  = ps.executeQuery(  );
            ArrayList ret = new ArrayList(  );

            while ( rs.next(  ) ) {
                PCY_TorikesiSinseiWorkTableBean torikesiBeanTemp = new PCY_TorikesiSinseiWorkTableBean( rs,
                        "TORIKESI" );
                torikesiBeanTemp.setMousikomiBean( new PCY_MousikomiJyokyoBean( rs, "KAMOKU",
                        "CLASS", "PERSONAL", "MOUSIKOMI" ) );

                ret.add( torikesiBeanTemp );
            }

            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ( PCY_TorikesiSinseiWorkTableBean[] )ret.toArray( new PCY_TorikesiSinseiWorkTableBean[0] );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            throw new EJBException( e );
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �ȖڃR�[�h�A�N���X�R�[�h�A�����ԍ��������Ƃ��āA���M�t���O���X�V����B
     * �����œn���ꂽ�z�񐔂ƍX�V�������قȂ�ꍇ�A���[���o�b�N���s���B
     *
     * @param modosiBeans
     * @param loginuser
     * @return
     * @throws PCY_WarningException
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdateSousinFlg( PCY_TorikesiSinseiWorkTableBean[] torikesiBeans,
        PCY_PersonalBean loginuser ) throws PCY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // SQL�쐬
            StringBuffer sql = new StringBuffer(  );
            sql.append( "UPDATE " + HcdbDef.L55_TBL );
            sql.append( " SET   SOUSIN_FLG=? " );
            sql.append( " WHERE KAMOKU_CODE=?" );
            sql.append( "   AND CLASS_CODE=?" );
            sql.append( "   AND SIMEI_NO=?" );

            // �R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �X�V���s
            ps = con.prepareStatement( sql.toString(  ) );

            int ret_count = 0;

            for ( int i = 0; i < torikesiBeans.length; i++ ) {
                ps.setString( 1, torikesiBeans[i].getSousinFlg(  ) );
                ps.setString( 2, torikesiBeans[i].getKamokuCode(  ) );
                ps.setString( 3, torikesiBeans[i].getClassCode(  ) );
                ps.setString( 4, torikesiBeans[i].getSimeiNo(  ) );

                ret_count += ps.executeUpdate(  );

                ps.clearParameters(  );
            }

            if ( ret_count != torikesiBeans.length ) {
                context.setRollbackOnly(  );
                throw new PCY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ret_count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }
}
