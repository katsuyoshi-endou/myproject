/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�g�D�o�b�`�@�\�j
 *
 * ���l�@�F
 *   �p�[�\�i���e�[�u���̂P���R�[�h�����i�[����f�[�^�N���X�B
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/10/30  01.00      TUANTT    �V�K�쐬
 *
 */
package jp.co.hisas.addon.batch.import_personal.record;

import java.util.Vector;

// ADD 2016/01/25 COMTURE �p�[�\�i���v���t�@�C���o�^�o�b�`�iver.11-00�j START
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
// ADD 2016/01/25 COMTURE �p�[�\�i���v���t�@�C���o�^�o�b�`�iver.11-00�j END

/**
 *
 * <PRE>
 *
 * �N���X���F PersonalRecord�N���X
 *
 * �@�\�����F �p�[�\�i���e�[�u���̂P���R�[�h�����i�[����f�[�^�N���X�B
 *
 * </PRE>
 */
public class PersonalRecord implements Record {

    /** ����NO */
    private String simei_no;

    /** �p�X���[�h */
    private String password;

    /** �{���^�����t���O */
    private String honmu_flg;

    /** ����NO�t���O */
    private String simei_no_flg;

    /** �������� */
    private String kanji_simei;

    /** �J�i�����i�S�p�j */
    private String kana_simei;

    /** �����i�p���j */
    private String eiji_simei;

    /** ���� */
    private String seibetu;

    /** ���N���� */
    private String seinengappi;

    /** �N���[�v���ДN�� */
    private String group_nyusya_nengetu;

    /** ���ДN�� */
    private String nyusya_nengetu;

    /** �g�D�R�[�h */
    private String sosiki_code;

    /** ��E�R�[�h */
    private String yakusyoku_code;

    /** �E�ʃR�[�h */
    private String syokui_code;

    /** �A������� */
    private String naisen;

    /** �A����O�� */
    private String gaisen;

    /** FAX�ԍ� */
    private String fax_no;

    /** Mail */
    private String mail;

    /** ����PR */
    private String jiko_pr;

    /** ���E�ސE�t���O */
    private String gensyoku_taisyoku_flg;

    /** �ސE�N���� */
    private String taisyoku_nengappi;

    /** �����R�[�h */
    private String kengen_code;

    /** �����R�[�h�P */
    private String syozoku_code_1;

    /** �����R�[�h�Q */
    private String syozoku_code_2;

    /** �����R�[�h�R */
    private String syozoku_code_3;

    /** �����R�[�h�S */
    private String syozoku_code_4;

    /** �����R�[�h�T */
    private String syozoku_code_5;

    /** �����R�[�h�U */
    private String syozoku_code_6;

    /** �����R�[�h�V */
    private String syozoku_code_7;

    /** �����R�[�h�W */
    private String syozoku_code_8;

    /** �����R�[�h�X */
    private String syozoku_code_9;

    /** �E��R�[�h�P */
    private String syoku_code1;

    /** ��啪��R�[�h�P */
    private String senmon_code1;

    /** ���x���R�[�h�P */
    private String level_code1;

    /** �����B���x�P */
    private String sougou_t_do1;

    /** �E��R�[�h�Q */
    private String syoku_code2;

    /** ��啪��R�[�h�Q */
    private String senmon_code2;

    /** ���x���R�[�h�Q */
    private String level_code2;

    /** �����B���x�Q */
    private String sougou_t_do2;

    /** �E��R�[�h�R */
    private String syoku_code3;

    /** ��啪��R�[�h�R */
    private String senmon_code3;

    /** ���x���R�[�h�R */
    private String level_code3;

    /** �����B���x�R */
    private String sougou_t_do3;

    /** �A�Z�X�����g���ʌ��J�t���O */
    private String assessment_kokai_flg;

    /** ���ʐ^���J�t���O */
    private String kao_kokai_flg;

    /** �X�L���Ǘ����J�t���O */
    private String skill_kokai_flg;

    /** �E�����e�����J�t���O */
    private String syokumu_kokai_flg;

    /** ���猤�C�����J�t���O */
    private String kyoiku_kokai_flg;

    /** ���i�Ƌ����J�t���O */
    private String sikaku_kokai_flg;

    /** �\�������J�t���O */
    private String hyosyo_kokai_flg;

    /** �_���E�u�������J�t���O */
    private String ronbun_kokai_flg;

    /** �ЊO���������J�t���O */
    private String syagai_kokai_flg;

    /** �w�����J�t���O */
    private String gakureki_kokai_flg;

    /** �Г������J�t���O */
    private String syanaireki_kokai_flg;

    /** �O�E�����J�t���O */
    private String zensyokureki_kokai_flg;

    /** �g�D���J�t���O */
    private String sosiki_kokai_flg;

    /** ��E���J�t���O */
    private String yakusyoku_kokai_flg;

    /** �E�ʌ��J�t���O */
    private String syokui_kokai_flg;

    /** �X�L���Z�b�g�����e�i���X�t���O */
    private String skill_mainte_flg;

    /** �֘A�Ɩ��o�^�\�t���O */
    private String kanren_gyomu_touroku_flg;

    /** �p�[�\�i���v���t�@�C�������e�i���X�t���O */
    private String personal_mainte_flg;

    /** �g�D�����e�i���X�t���O */
    private String sosiki_mainte_flg;

    /** ���猤�C�������e�i���X�t���O */
    private String kyoiku_mainte_flg;

    /** �_���E�u���������e�i���X�t���O */
    private String ronbun_mainte_flg;

    /** ���i�c�a�����e�t���O */
    private String sikaku_mainte_flg;

    /** �\�����c�a�����e�t���O */
    private String hyosyo_mainte_flg;

    /** �ЊO�u���E�_���������e�t���O */
    private String syagai_ronbun_mainte_flg;

    /** ���C�Ǘ��҃t���O */
    private String kenpo_mainte_flg;

    /** �ЊO�����������e�t���O */
    private String syagai_mainte_flg;

    /** ���O�C�����m�点��񃁃��e�t���O */
    private String login_osirase_mainte_flg;

    /** ���v�E���͏�񌟍����� */
    private String tokei_bunseki_kengen;

    /** �ސE�Ҍ��������t���O */
    private String taisyokusya_kensaku_kengen_flg;

    /** ����J���������t���O */
    private String hikoukai_kensaku_kengen_flg;

    /** ��ʌ��J�t���O�\���P */
    private String gamen_kokai_flg_yobi1;

    /** ��ʌ��J�t���O�\���Q */
    private String gamen_kokai_flg_yobi2;

    /** ��ʌ��J�t���O�\���R */
    private String gamen_kokai_flg_yobi3;

    /** ��ʌ��J�t���O�\���S */
    private String gamen_kokai_flg_yobi4;

    /** ��ʌ��J�t���O�\���T */
    private String gamen_kokai_flg_yobi5;

    /** ��ʌ��J�t���O�\���U */
    private String gamen_kokai_flg_yobi6;

    /** ��ʌ��J�t���O�\���V */
    private String gamen_kokai_flg_yobi7;

    /** ��ʌ��J�t���O�\���W */
    private String gamen_kokai_flg_yobi8;

    /** ��ʌ��J�t���O�\���X */
    private String gamen_kokai_flg_yobi9;

    /** ��ʌ��J�t���O�\���P�O */
    private String gamen_kokai_flg_yobi10;

    /** ��ʌ��J�t���O�\���P�P */
    private String gamen_kokai_flg_yobi11;

    /** ��ʌ��J�t���O�\���P�Q */
    private String gamen_kokai_flg_yobi12;

    /** �����e�t���O�\���P */
    private String mainte_flg_yobi1;

    /** �O���[�vID */
    private String yobi1;

    /** Job�i���{��j */
    private String yobi2;

    /** Job�i�p��j */
    private String yobi3;

    /** Supervisor�i���{��j */
    private String yobi4;

    /** Supervisor�i�p��j */
    private String yobi5;

    /** �\���U */
    private String yobi6;

    /** �\���V */
    private String yobi7;

    /** �\���W */
    private String yobi8;

    /** �\���X */
    private String yobi9;

    /** �\���P�O */
    private String yobi10;

    /** ��E */
    private String yakusyoku;

    /** �\���̈� */
    private String yobi_ryoiki;

    /** �C�O���������J�t���O */
    private String kaigai_kokai_flg;

    /** �C�O�����������e�t���O */
    private String kaigai_mainte_flg;

    /** �l������ */
    private String jinmei_ryakusyo;

    /** �������̖� */
    private String busyo_ryakusyo_mei;

    /** �ŏI�w���F�w�Z�� */
    private String gakureki_gakko_mei;

    /** �ŏI�w���F�w���� */
    private String gakureki_gakubu_mei;

    /** �ŏI�w���F�w�Ȗ� */
    private String gakureki_gakka_mei;

    /** �̎�w���F���ƔN�� */
    private String gakureki_sotugyo_nengetu;

    /** �Г��� */
    private String syanaibin;

    /**
     *�p�[�\�i���v���t�@�C�����R�[�h�̃R���X�g���N�^�B
     */
    public PersonalRecord() {
        simei_no = "";
        password = "";
        honmu_flg = "";
        simei_no_flg = "";
        kanji_simei = "";
        kana_simei = "";
        eiji_simei = "";
        seibetu = "";
        seinengappi = "";
        group_nyusya_nengetu = "";
        nyusya_nengetu = "";
        sosiki_code = "";
        yakusyoku_code = "";
        syokui_code = "";
        naisen = "";
        gaisen = "";
        fax_no = "";
        mail = "";
        jiko_pr = "";
        gensyoku_taisyoku_flg = "";
        taisyoku_nengappi = "";
        kengen_code = "";
        syozoku_code_1 = "";
        syozoku_code_2 = "";
        syozoku_code_3 = "";
        syozoku_code_4 = "";
        syozoku_code_5 = "";
        syozoku_code_6 = "";
        syozoku_code_7 = "";
        syozoku_code_8 = "";
        syozoku_code_9 = "";
        syoku_code1 = "";
        senmon_code1 = "";
        level_code1 = "";
        sougou_t_do1 = "";
        syoku_code2 = "";
        senmon_code2 = "";
        level_code2 = "";
        sougou_t_do2 = "";
        syoku_code3 = "";
        senmon_code3 = "";
        level_code3 = "";
        sougou_t_do3 = "";
        assessment_kokai_flg = "";
        kao_kokai_flg = "";
        skill_kokai_flg = "";
        syokumu_kokai_flg = "";
        kyoiku_kokai_flg = "";
        sikaku_kokai_flg = "";
        hyosyo_kokai_flg = "";
        ronbun_kokai_flg = "";
        syagai_kokai_flg = "";
        gakureki_kokai_flg = "";
        syanaireki_kokai_flg = "";
        zensyokureki_kokai_flg = "";
        sosiki_kokai_flg = "";
        yakusyoku_kokai_flg = "";
        syokui_kokai_flg = "";
        skill_mainte_flg = "";
        kanren_gyomu_touroku_flg = "";
        personal_mainte_flg = "";
        sosiki_mainte_flg = "";
        kyoiku_mainte_flg = "";
        ronbun_mainte_flg = "";
        sikaku_mainte_flg = "";
        hyosyo_mainte_flg = "";
        syagai_ronbun_mainte_flg = "";
        kenpo_mainte_flg = "";
        syagai_mainte_flg = "";
        login_osirase_mainte_flg = "";
        tokei_bunseki_kengen = "";
        taisyokusya_kensaku_kengen_flg = "";
        hikoukai_kensaku_kengen_flg = "";
        gamen_kokai_flg_yobi1 = "";
        gamen_kokai_flg_yobi2 = "";
        gamen_kokai_flg_yobi3 = "";
        gamen_kokai_flg_yobi4 = "";
        gamen_kokai_flg_yobi5 = "";
        gamen_kokai_flg_yobi6 = "";
        gamen_kokai_flg_yobi7 = "";
        gamen_kokai_flg_yobi8 = "";
        gamen_kokai_flg_yobi9 = "";
        gamen_kokai_flg_yobi10 = "";
        gamen_kokai_flg_yobi11 = "";
        gamen_kokai_flg_yobi12 = "";
        mainte_flg_yobi1 = "";
        yobi1 = "";
        yobi2 = "";
        yobi3 = "";
        yobi4 = "";
        yobi5 = "";
        yobi6 = "";
        yobi7 = "";
        yobi8 = "";
        yobi9 = "";
        yobi10 = "";
        yakusyoku = "";
        yobi_ryoiki = "";
        kaigai_kokai_flg = "";
        kaigai_mainte_flg = "";
        jinmei_ryakusyo = "";
        busyo_ryakusyo_mei = "";
        gakureki_gakko_mei = "";
        gakureki_gakubu_mei = "";
        gakureki_gakka_mei = "";
        gakureki_sotugyo_nengetu = "";
        syanaibin = "";

    }

    /**
     * �K�{�̃t�B�[���h��Null�ȊO�ł��邱�Ƃ��m�F����B
     * @return boolean �K�{�̃t�B�[���h���S��Null�ȊO�̏ꍇ��true��Ԃ��āA����ȊO�̏ꍇ��false��Ԃ��B
     */
    public boolean isRequiredNotNull() {
        if (getSimei_no( ) == null
                || getPassword( ) == null
                || getHonmu_flg( ) == null
                || getSimei_no_flg( ) == null
                || getKanji_simei( ) == null
                || getKana_simei( ) == null
                || getSeibetu( ) == null
                || getSeinengappi( ) == null
                || getNyusya_nengetu( ) == null
                || getYakusyoku_code( ) == null
                || getGensyoku_taisyoku_flg( ) == null
                || getKengen_code( ) == null
                || getAssessment_kokai_flg( ) == null
                || getKao_kokai_flg( ) == null
                || getSkill_kokai_flg( ) == null
                || getSyokumu_kokai_flg( ) == null
                || getKyoiku_kokai_flg( ) == null
                || getSikaku_kokai_flg( ) == null
                || getHyosyo_kokai_flg( ) == null
                || getRonbun_kokai_flg( ) == null
                || getSyagai_kokai_flg( ) == null
                || getGakureki_kokai_flg( ) == null
                || getSyanaireki_kokai_flg( ) == null
                || getZensyokureki_kokai_flg( ) == null
                || getSosiki_kokai_flg( ) == null
                || getYakusyoku_kokai_flg( ) == null
                || getSyokui_kokai_flg( ) == null
                || getSkill_mainte_flg( ) == null
                || getKanren_gyomu_touroku_flg( ) == null
                || getPersonal_mainte_flg( ) == null
                || getSosiki_mainte_flg( ) == null
                || getKyoiku_mainte_flg( ) == null
                || getRonbun_mainte_flg( ) == null
                || getSikaku_mainte_flg( ) == null
                || getHyosyo_mainte_flg( ) == null
                || getSyagai_ronbun_mainte_flg( ) == null
                || getKenpo_mainte_flg( ) == null
                || getSyagai_mainte_flg( ) == null
                || getLogin_osirase_mainte_flg( ) == null
                || getTokei_bunseki_kengen( ) == null
                || getTaisyokusya_kensaku_kengen_flg( ) == null
                || getHikoukai_kensaku_kengen_flg( ) == null) {

            return false;
        }

        return true;
    }

    /**
     * �p�[�\�i���e�[�u����1���̃��R�[�h��ǉ����邽�߁A�f�[�^���i�[����x�N�^�[���쐬����B
     * @return Vector �f�[�^��SQL���̂悤�ɊY�����鏇�ԂŃ\�[�g���ꂽ�B
     */
    public Vector createAddVector() {
        Vector data = new Vector( );
        data.add( getSimei_no( ) );
//����2005/11/24 ringou
//        data.addAll( createDataVector( ) );
        data.addAll( createDataVector( true ) );
//����2005/11/24 ringou
        return data;
    }


    /**
     * �p�[�\�i���e�[�u����1���̃��R�[�h���X�V���邽�߁A�f�[�^���i�[����x�N�^�[���쐬����B
     * @return Vector �f�[�^��SQL���̂悤�ɊY�����鏇�ԂŃ\�[�g���ꂽ�B
     */
    public Vector createUpdateVector() {
        Vector data = new Vector( );
//����2005/11/24 ringou
//        data.addAll( createDataVector( ) );
//        data.add( getSimei_no( ) );
        data.addAll( createDataVector( false ) );
        //�ȉ�����
        data.add( getSimei_no( ) );
        data.add( getHonmu_flg( ) );
        data.add( getSosiki_code( ) );
//����2005/11/24 ringou
        return data;
    }

//����2005/12/1 ringou
	/**
	 * �p�[�\�i���e�[�u��(�{��)�̃��R�[�h���X�V���邽�߁A�f�[�^���i�[����x�N�^�[���쐬����B
	 * @return Vector �f�[�^��SQL���̂悤�ɊY�����鏇�ԂŃ\�[�g���ꂽ�B
	 */
	public Vector createUpdateHonmuVector() {
		Vector data = new Vector( );

        data.add( getPassword( ) );
        data.add( getSimei_no_flg( ) );
        data.add( getKanji_simei( ) );
        data.add( getKana_simei( ) );
        data.add( getEiji_simei( ) );
        data.add( getSeibetu( ) );
        data.add( getSeinengappi( ) );
        data.add( getGroup_nyusya_nengetu( ) );
        data.add( getNyusya_nengetu( ) );
        data.add( getSosiki_code( ) );
        data.add( getYakusyoku_code( ) );
        data.add( getSyokui_code( ) );
        data.add( getNaisen( ) );
        data.add( getGaisen( ) );
        data.add( getFax_no( ) );
        data.add( getMail( ) );
        data.add( getJiko_pr( ) );
        data.add( getGensyoku_taisyoku_flg( ) );
        data.add( getTaisyoku_nengappi( ) );
        data.add( getKengen_code( ) );
        data.add( getSyozoku_code_1( ) );
        data.add( getSyozoku_code_2( ) );
        data.add( getSyozoku_code_3( ) );
        data.add( getSyozoku_code_4( ) );
        data.add( getSyozoku_code_5( ) );
        data.add( getSyozoku_code_6( ) );
        data.add( getSyozoku_code_7( ) );
        data.add( getSyozoku_code_8( ) );
        data.add( getSyozoku_code_9( ) );
        data.add( getSyoku_code1( ) );
        data.add( getSenmon_code1( ) );
        data.add( getLevel_code1( ) );
        try {
            data.add( new Double( getSougou_t_do1( ) ) );
        } catch (NumberFormatException ex) {
            data.add( "" );
        }
        data.add( getSyoku_code2( ) );
        data.add( getSenmon_code2( ) );
        data.add( getLevel_code2( ) );
        try {
            data.add( new Double( getSougou_t_do2( ) ) );
        } catch (NumberFormatException ex) {
            data.add( "" );
        }

        data.add( getSyoku_code3( ) );
        data.add( getSenmon_code3( ) );
        data.add( getLevel_code3( ) );
        try {
            data.add( new Double( getSougou_t_do3( ) ) );
        } catch (NumberFormatException ex) {
            data.add( "" );
        }

        data.add( getAssessment_kokai_flg( ) );
        data.add( getKao_kokai_flg( ) );
        data.add( getSkill_kokai_flg( ) );
        data.add( getSyokumu_kokai_flg( ) );
        data.add( getKyoiku_kokai_flg( ) );
        data.add( getSikaku_kokai_flg( ) );
        data.add( getHyosyo_kokai_flg( ) );
        data.add( getRonbun_kokai_flg( ) );
        data.add( getSyagai_kokai_flg( ) );
        data.add( getGakureki_kokai_flg( ) );
        data.add( getSyanaireki_kokai_flg( ) );
        data.add( getZensyokureki_kokai_flg( ) );
        data.add( getSosiki_kokai_flg( ) );
        data.add( getYakusyoku_kokai_flg( ) );
        data.add( getSyokui_kokai_flg( ) );
        data.add( getSkill_mainte_flg( ) );
        data.add( getKanren_gyomu_touroku_flg( ) );
        data.add( getPersonal_mainte_flg( ) );
        data.add( getSosiki_mainte_flg( ) );
        data.add( getKyoiku_mainte_flg( ) );
        data.add( getRonbun_mainte_flg( ) );
        data.add( getSikaku_mainte_flg( ) );
        data.add( getHyosyo_mainte_flg( ) );
        data.add( getSyagai_ronbun_mainte_flg( ) );
        data.add( getKenpo_mainte_flg( ) );
        data.add( getSyagai_mainte_flg( ) );
        data.add( getLogin_osirase_mainte_flg( ) );
        data.add( getTokei_bunseki_kengen( ) );
        data.add( getTaisyokusya_kensaku_kengen_flg( ) );
        data.add( getHikoukai_kensaku_kengen_flg( ) );
        data.add( getGamen_kokai_flg_yobi1( ) );
        data.add( getGamen_kokai_flg_yobi2( ) );
        data.add( getGamen_kokai_flg_yobi3( ) );
        data.add( getGamen_kokai_flg_yobi4( ) );
        data.add( getGamen_kokai_flg_yobi5( ) );
        data.add( getGamen_kokai_flg_yobi6( ) );
        data.add( getGamen_kokai_flg_yobi7( ) );
        data.add( getGamen_kokai_flg_yobi8( ) );
        data.add( getGamen_kokai_flg_yobi9( ) );
        data.add( getGamen_kokai_flg_yobi10( ) );
        data.add( getGamen_kokai_flg_yobi11( ) );
        data.add( getGamen_kokai_flg_yobi12( ) );
        data.add( getMainte_flg_yobi1( ) );
        data.add( getYobi1( ) );
        data.add( getYobi2( ) );
        data.add( getYobi3( ) );
        data.add( getYobi4( ) );
        data.add( getYobi5( ) );
        data.add( getYobi6( ) );
        data.add( getYobi7( ) );
        data.add( getYobi8( ) );
        data.add( getYobi9( ) );
        data.add( getYobi10( ) );
        data.add( getYakusyoku( ) );
        data.add( getYobi_ryoiki( ) );
        data.add( getKaigai_kokai_flg( ) );
        data.add( getKaigai_mainte_flg( ) );
        data.add( getJinmei_ryakusyo( ) );
        data.add( getBusyo_ryakusyo_mei( ) );
        data.add( getGakureki_gakko_mei( ) );
        data.add( getGakureki_gakubu_mei( ) );
        data.add( getGakureki_gakka_mei( ) );
        data.add( getGakureki_sotugyo_nengetu( ) );
        data.add( getSyanaibin( ) );

		//�ȉ�����
		data.add( getSimei_no( ) );
		data.add( getHonmu_flg( ) );

		return data;
	}
//����2005/12/1 ringou

//����2005/11/24 ringou
//    /**
//     * �x�N�^�[��1���̃��R�[�h�̃f�[�^���i�[���āAsimei_no�t�B�[���h���܂����݂��Ȃ��B
//     * @return Vector �f�[�^��SQL���̂悤�ɊY�����鏇�ԂŃ\�[�g���ꂽ�B
//     */
//    public Vector createDataVector() {
    /**
     * �x�N�^�[��1���̃��R�[�h�̃f�[�^���i�[���āAsimei_no�t�B�[���h���܂����݂��Ȃ��B
     * @param true: �ǉ���, false:�X�V��
     * @return Vector �f�[�^��SQL���̂悤�ɊY�����鏇�ԂŃ\�[�g���ꂽ�B
     */
    public Vector createDataVector(boolean flg) {
//����2005/11/24 ringou
        Vector data = new Vector( );
//����2005/11/24 ringou
        if(flg){
            //�ǉ���
            data.add( getSimei_no( ) );
        }
//����2005/11/24 ringou
        data.add( getPassword( ) );
//����2005/11/24 ringou
        if(flg){
            //�ǉ���
            data.add( getHonmu_flg( ) );
        }
//����2005/11/24 ringou
        data.add( getSimei_no_flg( ) );
        data.add( getKanji_simei( ) );
        data.add( getKana_simei( ) );
        data.add( getEiji_simei( ) );
        data.add( getSeibetu( ) );
        data.add( getSeinengappi( ) );
        data.add( getGroup_nyusya_nengetu( ) );
        data.add( getNyusya_nengetu( ) );
//����2005/11/24 ringou
        if(flg){
            //�ǉ���
            data.add( getSosiki_code( ) );
        }
//����2005/11/24 ringou

        data.add( getYakusyoku_code( ) );
        data.add( getSyokui_code( ) );
        data.add( getNaisen( ) );
        data.add( getGaisen( ) );
        data.add( getFax_no( ) );
        data.add( getMail( ) );
        data.add( getJiko_pr( ) );
        data.add( getGensyoku_taisyoku_flg( ) );
        data.add( getTaisyoku_nengappi( ) );
        data.add( getKengen_code( ) );
        data.add( getSyozoku_code_1( ) );
        data.add( getSyozoku_code_2( ) );
        data.add( getSyozoku_code_3( ) );
        data.add( getSyozoku_code_4( ) );
        data.add( getSyozoku_code_5( ) );
        data.add( getSyozoku_code_6( ) );
        data.add( getSyozoku_code_7( ) );
        data.add( getSyozoku_code_8( ) );
        data.add( getSyozoku_code_9( ) );
        data.add( getSyoku_code1( ) );
        data.add( getSenmon_code1( ) );
        data.add( getLevel_code1( ) );
        try {
            data.add( new Double( getSougou_t_do1( ) ) );
        } catch (NumberFormatException ex) {
            data.add( "" );
        }

        data.add( getSyoku_code2( ) );
        data.add( getSenmon_code2( ) );
        data.add( getLevel_code2( ) );
        try {
            data.add( new Double( getSougou_t_do2( ) ) );
        } catch (NumberFormatException ex) {
            data.add( "" );
        }

        data.add( getSyoku_code3( ) );
        data.add( getSenmon_code3( ) );
        data.add( getLevel_code3( ) );
        try {
            data.add( new Double( getSougou_t_do3( ) ) );
        } catch (NumberFormatException ex) {
            data.add( "" );
        }

        data.add( getAssessment_kokai_flg( ) );
        data.add( getKao_kokai_flg( ) );
        data.add( getSkill_kokai_flg( ) );
        data.add( getSyokumu_kokai_flg( ) );
        data.add( getKyoiku_kokai_flg( ) );
        data.add( getSikaku_kokai_flg( ) );
        data.add( getHyosyo_kokai_flg( ) );
        data.add( getRonbun_kokai_flg( ) );
        data.add( getSyagai_kokai_flg( ) );
        data.add( getGakureki_kokai_flg( ) );
        data.add( getSyanaireki_kokai_flg( ) );
        data.add( getZensyokureki_kokai_flg( ) );
        data.add( getSosiki_kokai_flg( ) );
        data.add( getYakusyoku_kokai_flg( ) );
        data.add( getSyokui_kokai_flg( ) );
        data.add( getSkill_mainte_flg( ) );
        data.add( getKanren_gyomu_touroku_flg( ) );
        data.add( getPersonal_mainte_flg( ) );
        data.add( getSosiki_mainte_flg( ) );
        data.add( getKyoiku_mainte_flg( ) );
        data.add( getRonbun_mainte_flg( ) );
        data.add( getSikaku_mainte_flg( ) );
        data.add( getHyosyo_mainte_flg( ) );
        data.add( getSyagai_ronbun_mainte_flg( ) );
        data.add( getKenpo_mainte_flg( ) );
        data.add( getSyagai_mainte_flg( ) );
        data.add( getLogin_osirase_mainte_flg( ) );
        data.add( getTokei_bunseki_kengen( ) );
        data.add( getTaisyokusya_kensaku_kengen_flg( ) );
        data.add( getHikoukai_kensaku_kengen_flg( ) );
        data.add( getGamen_kokai_flg_yobi1( ) );
        data.add( getGamen_kokai_flg_yobi2( ) );
        data.add( getGamen_kokai_flg_yobi3( ) );
        data.add( getGamen_kokai_flg_yobi4( ) );
        data.add( getGamen_kokai_flg_yobi5( ) );
        data.add( getGamen_kokai_flg_yobi6( ) );
        data.add( getGamen_kokai_flg_yobi7( ) );
        data.add( getGamen_kokai_flg_yobi8( ) );
        data.add( getGamen_kokai_flg_yobi9( ) );
        data.add( getGamen_kokai_flg_yobi10( ) );
        data.add( getGamen_kokai_flg_yobi11( ) );
        data.add( getGamen_kokai_flg_yobi12( ) );
        data.add( getMainte_flg_yobi1( ) );
        data.add( getYobi1( ) );
        data.add( getYobi2( ) );
        data.add( getYobi3( ) );
        data.add( getYobi4( ) );
        data.add( getYobi5( ) );
        data.add( getYobi6( ) );
        data.add( getYobi7( ) );
        data.add( getYobi8( ) );
        data.add( getYobi9( ) );
        data.add( getYobi10( ) );
        data.add( getYakusyoku( ) );
        data.add( getYobi_ryoiki( ) );
        data.add( getKaigai_kokai_flg( ) );
        data.add( getKaigai_mainte_flg( ) );
        data.add( getJinmei_ryakusyo( ) );
        data.add( getBusyo_ryakusyo_mei( ) );
        data.add( getGakureki_gakko_mei( ) );
        data.add( getGakureki_gakubu_mei( ) );
        data.add( getGakureki_gakka_mei( ) );
        data.add( getGakureki_sotugyo_nengetu( ) );
        data.add( getSyanaibin( ) );

        return data;
    }

// ADD 2016/01/25 COMTURE �p�[�\�i���v���t�@�C���o�^�o�b�`�iver.11-00�j START
    /**
     * �F�؃e�[�u���Ɋi�[����l���Z�b�g����B
     * @return data
     */
    public Vector createNinsyouDataVector() {
        final Vector data = new Vector();

        data.add( getSimei_no() );
        data.add( getPassword() );
        data.add( PZZ010_CharacterUtil.GetDay() );
        data.add( "0" );
        data.add( "1" );

        return data;
    }
// ADD 2016/01/25 COMTURE �p�[�\�i���v���t�@�C���o�^�o�b�`�iver.11-00�j END

    /**
     * assessment_kokai_flg���擾����B
     * @return String assessment_kokai_flg
     */
    public String getAssessment_kokai_flg() {
        return assessment_kokai_flg;
    }

    /**
     * assessment_kokai_flg��ݒ肷��B
     * @param assessment_kokai_flg assessment_kokai_flg
     */
    public void setAssessment_kokai_flg(String assessment_kokai_flg) {
        this.assessment_kokai_flg = assessment_kokai_flg;
    }

    /**
     * busyo_ryakusyo_mei���擾����B
     * @return String busyo_ryakusyo_mei
     */
    public String getBusyo_ryakusyo_mei() {
        return busyo_ryakusyo_mei;
    }

    /**
     * busyo_ryakusyo_mei��ݒ肷��B
     * @param busyo_ryakusyo_mei busyo_ryakusyo_mei
     */
    public void setBusyo_ryakusyo_mei(String busyo_ryakusyo_mei) {
        this.busyo_ryakusyo_mei = busyo_ryakusyo_mei;
    }

    /**
     * eiji_simei���擾����B
     * @return String eiji_simei
     */
    public String getEiji_simei() {
        return eiji_simei;
    }

    /**
     * eiji_simei��ݒ肷��B
     * @param eiji_simei eiji_simei
     */
    public void setEiji_simei(String eiji_simei) {
        this.eiji_simei = eiji_simei;
    }

    /**
     * fax_no���擾����B
     * @return String fax_no
     */
    public String getFax_no() {
        return fax_no;
    }

    /**
     * fax_no��ݒ肷��B
     * @param fax_no fax_no
     */
    public void setFax_no(String fax_no) {
        this.fax_no = fax_no;
    }

    /**
     * gaisen���擾����B
     * @return String gaisen
     */
    public String getGaisen() {
        return gaisen;
    }

    /**
     * gaisen��ݒ肷��B
     * @param gaisen gaisen
     */
    public void setGaisen(String gaisen) {
        this.gaisen = gaisen;
    }

    /**
     * gakureki_gakka_mei���擾����B
     * @return String gakureki_gakka_mei
     */
    public String getGakureki_gakka_mei() {
        return gakureki_gakka_mei;
    }

    /**
     * gakureki_gakka_mei��ݒ肷��B
     * @param gakureki_gakka_mei gakureki_gakka_mei
     */
    public void setGakureki_gakka_mei(String gakureki_gakka_mei) {
        this.gakureki_gakka_mei = gakureki_gakka_mei;
    }

    /**
     * gakureki_gakko_mei���擾����B
     * @return String gakureki_gakko_mei
     */
    public String getGakureki_gakko_mei() {
        return gakureki_gakko_mei;
    }

    /**
     * gakureki_gakko_mei��ݒ肷��B
     * @param gakureki_gakko_mei gakureki_gakko_mei
     */
    public void setGakureki_gakko_mei(String gakureki_gakko_mei) {
        this.gakureki_gakko_mei = gakureki_gakko_mei;
    }

    /**
     * gakureki_gakubu_mei���擾����B
     * @return String gakureki_gakubu_mei
     */
    public String getGakureki_gakubu_mei() {
        return gakureki_gakubu_mei;
    }

    /**
     * gakureki_gakubu_mei��ݒ肷��B
     * @param gakureki_gakubu_mei gakureki_gakubu_mei
     */
    public void setGakureki_gakubu_mei(String gakureki_gakubu_mei) {
        this.gakureki_gakubu_mei = gakureki_gakubu_mei;
    }

    /**
     * gakureki_kokai_flg���擾����B
     * @return String gakureki_kokai_flg
     */
    public String getGakureki_kokai_flg() {
        return gakureki_kokai_flg;
    }

    /**
     * gakureki_kokai_flg��ݒ肷��B
     * @param gakureki_kokai_flg gakureki_kokai_flg
     */
    public void setGakureki_kokai_flg(String gakureki_kokai_flg) {
        this.gakureki_kokai_flg = gakureki_kokai_flg;
    }

    /**
     * gakureki_sotugyo_nengetu���擾����B
     * @return String gakureki_sotugyo_nengetu
     */
    public String getGakureki_sotugyo_nengetu() {
        return gakureki_sotugyo_nengetu;
    }

    /**
     * gakureki_sotugyo_nengetu��ݒ肷��B
     * @param gakureki_sotugyo_nengetu gakureki_sotugyo_nengetu
     */
    public void setGakureki_sotugyo_nengetu(String gakureki_sotugyo_nengetu) {
        this.gakureki_sotugyo_nengetu = gakureki_sotugyo_nengetu;
    }

    /**
     * gamen_kokai_flg_yobi1���擾����B
     * @return String gamen_kokai_flg_yobi1
     */
    public String getGamen_kokai_flg_yobi1() {
        return gamen_kokai_flg_yobi1;
    }

    /**
     * gamen_kokai_flg_yobi1��ݒ肷��B
     * @param gamen_kokai_flg_yobi1 gamen_kokai_flg_yobi1
     */
    public void setGamen_kokai_flg_yobi1(String gamen_kokai_flg_yobi1) {
        this.gamen_kokai_flg_yobi1 = gamen_kokai_flg_yobi1;
    }

    /**
     * gamen_kokai_flg_yobi10���擾����B
     * @return String gamen_kokai_flg_yobi10
     */
    public String getGamen_kokai_flg_yobi10() {
        return gamen_kokai_flg_yobi10;
    }

    /**
     * gamen_kokai_flg_yobi10��ݒ肷��B
     * @param gamen_kokai_flg_yobi10 gamen_kokai_flg_yobi10
     */
    public void setGamen_kokai_flg_yobi10(String gamen_kokai_flg_yobi10) {
        this.gamen_kokai_flg_yobi10 = gamen_kokai_flg_yobi10;
    }

    /**
     * gamen_kokai_flg_yobi11���擾����B
     * @return String gamen_kokai_flg_yobi11
     */
    public String getGamen_kokai_flg_yobi11() {
        return gamen_kokai_flg_yobi11;
    }

    /**
     * gamen_kokai_flg_yobi11��ݒ肷��B
     * @param gamen_kokai_flg_yobi11 gamen_kokai_flg_yobi11
     */
    public void setGamen_kokai_flg_yobi11(String gamen_kokai_flg_yobi11) {
        this.gamen_kokai_flg_yobi11 = gamen_kokai_flg_yobi11;
    }

    /**
     * gamen_kokai_flg_yobi12���擾����B
     * @return String gamen_kokai_flg_yobi12
     */
    public String getGamen_kokai_flg_yobi12() {
        return gamen_kokai_flg_yobi12;
    }

    /**
     * gamen_kokai_flg_yobi12��ݒ肷��B
     * @param gamen_kokai_flg_yobi12 gamen_kokai_flg_yobi12
     */
    public void setGamen_kokai_flg_yobi12(String gamen_kokai_flg_yobi12) {
        this.gamen_kokai_flg_yobi12 = gamen_kokai_flg_yobi12;
    }

    /**
     * gamen_kokai_flg_yobi2���擾����B
     * @return String gamen_kokai_flg_yobi2
     */
    public String getGamen_kokai_flg_yobi2() {
        return gamen_kokai_flg_yobi2;
    }

    /**
     * gamen_kokai_flg_yobi2��ݒ肷��B
     * @param gamen_kokai_flg_yobi2 gamen_kokai_flg_yobi2
     */
    public void setGamen_kokai_flg_yobi2(String gamen_kokai_flg_yobi2) {
        this.gamen_kokai_flg_yobi2 = gamen_kokai_flg_yobi2;
    }

    /**
     * gamen_kokai_flg_yobi3���擾����B
     * @return String gamen_kokai_flg_yobi3
     */
    public String getGamen_kokai_flg_yobi3() {
        return gamen_kokai_flg_yobi3;
    }

    /**
     * gamen_kokai_flg_yobi3��ݒ肷��B
     * @param gamen_kokai_flg_yobi3 gamen_kokai_flg_yobi3
     */
    public void setGamen_kokai_flg_yobi3(String gamen_kokai_flg_yobi3) {
        this.gamen_kokai_flg_yobi3 = gamen_kokai_flg_yobi3;
    }

    /**
     * gamen_kokai_flg_yobi4���擾����B
     * @return String gamen_kokai_flg_yobi4
     */
    public String getGamen_kokai_flg_yobi4() {
        return gamen_kokai_flg_yobi4;
    }

    /**
     * gamen_kokai_flg_yobi4��ݒ肷��B
     * @param gamen_kokai_flg_yobi4 gamen_kokai_flg_yobi4
     */
    public void setGamen_kokai_flg_yobi4(String gamen_kokai_flg_yobi4) {
        this.gamen_kokai_flg_yobi4 = gamen_kokai_flg_yobi4;
    }

    /**
     * gamen_kokai_flg_yobi5���擾����B
     * @return String gamen_kokai_flg_yobi5
     */
    public String getGamen_kokai_flg_yobi5() {
        return gamen_kokai_flg_yobi5;
    }

    /**
     * gamen_kokai_flg_yobi5��ݒ肷��B
     * @param gamen_kokai_flg_yobi5 gamen_kokai_flg_yobi5
     */
    public void setGamen_kokai_flg_yobi5(String gamen_kokai_flg_yobi5) {
        this.gamen_kokai_flg_yobi5 = gamen_kokai_flg_yobi5;
    }

    /**
     * gamen_kokai_flg_yobi6���擾����B
     * @return String gamen_kokai_flg_yobi6
     */
    public String getGamen_kokai_flg_yobi6() {
        return gamen_kokai_flg_yobi6;
    }

    /**
     * gamen_kokai_flg_yobi6��ݒ肷��B
     * @param gamen_kokai_flg_yobi6 gamen_kokai_flg_yobi6
     */
    public void setGamen_kokai_flg_yobi6(String gamen_kokai_flg_yobi6) {
        this.gamen_kokai_flg_yobi6 = gamen_kokai_flg_yobi6;
    }

    /**
     * gamen_kokai_flg_yobi7���擾����B
     * @return String gamen_kokai_flg_yobi7
     */
    public String getGamen_kokai_flg_yobi7() {
        return gamen_kokai_flg_yobi7;
    }

    /**
     * gamen_kokai_flg_yobi7��ݒ肷��B
     * @param gamen_kokai_flg_yobi7 gamen_kokai_flg_yobi7
     */
    public void setGamen_kokai_flg_yobi7(String gamen_kokai_flg_yobi7) {
        this.gamen_kokai_flg_yobi7 = gamen_kokai_flg_yobi7;
    }

    /**
     * gamen_kokai_flg_yobi8���擾����B
     * @return String gamen_kokai_flg_yobi8
     */
    public String getGamen_kokai_flg_yobi8() {
        return gamen_kokai_flg_yobi8;
    }

    /**
     * gamen_kokai_flg_yobi8��ݒ肷��B
     * @param gamen_kokai_flg_yobi8 gamen_kokai_flg_yobi8
     */
    public void setGamen_kokai_flg_yobi8(String gamen_kokai_flg_yobi8) {
        this.gamen_kokai_flg_yobi8 = gamen_kokai_flg_yobi8;
    }

    /**
     * gamen_kokai_flg_yobi9���擾����B
     * @return String gamen_kokai_flg_yobi9
     */
    public String getGamen_kokai_flg_yobi9() {
        return gamen_kokai_flg_yobi9;
    }

    /**
     * gamen_kokai_flg_yobi9��ݒ肷��B
     * @param gamen_kokai_flg_yobi9 gamen_kokai_flg_yobi9
     */
    public void setGamen_kokai_flg_yobi9(String gamen_kokai_flg_yobi9) {
        this.gamen_kokai_flg_yobi9 = gamen_kokai_flg_yobi9;
    }

    /**
     * gensyoku_taisyoku_flg���擾����B
     * @return String gensyoku_taisyoku_flg
     */
    public String getGensyoku_taisyoku_flg() {
        return gensyoku_taisyoku_flg;
    }

    /**
     * gensyoku_taisyoku_flg��ݒ肷��B
     * @param gensyoku_taisyoku_flg gensyoku_taisyoku_flg
     */
    public void setGensyoku_taisyoku_flg(String gensyoku_taisyoku_flg) {
        this.gensyoku_taisyoku_flg = gensyoku_taisyoku_flg;
    }

    /**
     * group_nyusya_nengetu���擾����B
     * @return String group_nyusya_nengetu
     */
    public String getGroup_nyusya_nengetu() {
        return group_nyusya_nengetu;
    }

    /**
     * group_nyusya_nengetu��ݒ肷��B
     * @param group_nyusya_nengetu group_nyusya_nengetu
     */
    public void setGroup_nyusya_nengetu(String group_nyusya_nengetu) {
        this.group_nyusya_nengetu = group_nyusya_nengetu;
    }

    /**
     * hikoukai_kensaku_kengen_flg���擾����B
     * @return String hikoukai_kensaku_kengen_flg
     */
    public String getHikoukai_kensaku_kengen_flg() {
        return hikoukai_kensaku_kengen_flg;
    }

    /**
     * hikoukai_kensaku_kengen_flg��ݒ肷��B
     * @param hikoukai_kensaku_kengen_flg hikoukai_kensaku_kengen_flg
     */
    public void setHikoukai_kensaku_kengen_flg(String hikoukai_kensaku_kengen_flg) {
        this.hikoukai_kensaku_kengen_flg = hikoukai_kensaku_kengen_flg;
    }

    /**
     * honmu_flg���擾����B
     * @return String honmu_flg
     */
    public String getHonmu_flg() {
        return honmu_flg;
    }

    /**
     * honmu_flg��ݒ肷��B
     * @param honmu_flg honmu_flg
     */
    public void setHonmu_flg(String honmu_flg) {
        this.honmu_flg = honmu_flg;
    }

    /**
     * hyosyo_kokai_flg���擾����B
     * @return String hyosyo_kokai_flg
     */
    public String getHyosyo_kokai_flg() {
        return hyosyo_kokai_flg;
    }

    /**
     * hyosyo_kokai_flg��ݒ肷��B
     * @param hyosyo_kokai_flg hyosyo_kokai_flg
     */
    public void setHyosyo_kokai_flg(String hyosyo_kokai_flg) {
        this.hyosyo_kokai_flg = hyosyo_kokai_flg;
    }

    /**
     * hyosyo_mainte_flg���擾����B
     * @return String hyosyo_mainte_flg
     */
    public String getHyosyo_mainte_flg() {
        return hyosyo_mainte_flg;
    }

    /**
     * hyosyo_mainte_flg��ݒ肷��B
     * @param hyosyo_mainte_flg hyosyo_mainte_flg
     */
    public void setHyosyo_mainte_flg(String hyosyo_mainte_flg) {
        this.hyosyo_mainte_flg = hyosyo_mainte_flg;
    }

    /**
     * jiko_pr���擾����B
     * @return String jiko_pr
     */
    public String getJiko_pr() {
        return jiko_pr;
    }

    /**
     * jiko_pr��ݒ肷��B
     * @param jiko_pr jiko_pr
     */
    public void setJiko_pr(String jiko_pr) {
        this.jiko_pr = jiko_pr;
    }

    /**
     * jinmei_ryakusyo���擾����B
     * @return String jinmei_ryakusyo
     */
    public String getJinmei_ryakusyo() {
        return jinmei_ryakusyo;
    }

    /**
     * jinmei_ryakusyo��ݒ肷��B
     * @param jinmei_ryakusyo jinmei_ryakusyo
     */
    public void setJinmei_ryakusyo(String jinmei_ryakusyo) {
        this.jinmei_ryakusyo = jinmei_ryakusyo;
    }

    /**
     * kaigai_kokai_flg���擾����B
     * @return String kaigai_kokai_flg
     */
    public String getKaigai_kokai_flg() {
        return kaigai_kokai_flg;
    }

    /**
     * kaigai_kokai_flg��ݒ肷��B
     * @param kaigai_kokai_flg kaigai_kokai_flg
     */
    public void setKaigai_kokai_flg(String kaigai_kokai_flg) {
        this.kaigai_kokai_flg = kaigai_kokai_flg;
    }

    /**
     * kaigai_mainte_flg���擾����B
     * @return String kaigai_mainte_flg
     */
    public String getKaigai_mainte_flg() {
        return kaigai_mainte_flg;
    }

    /**
     * kaigai_mainte_flg��ݒ肷��B
     * @param kaigai_mainte_flg kaigai_mainte_flg
     */
    public void setKaigai_mainte_flg(String kaigai_mainte_flg) {
        this.kaigai_mainte_flg = kaigai_mainte_flg;
    }

    /**
     * kana_simei���擾����B
     * @return String kana_simei
     */
    public String getKana_simei() {
        return kana_simei;
    }

    /**
     * kana_simei��ݒ肷��B
     * @param kana_simei kana_simei
     */
    public void setKana_simei(String kana_simei) {
        this.kana_simei = kana_simei;
    }

    /**
     * kanji_simei���擾����B
     * @return String kanji_simei
     */
    public String getKanji_simei() {
        return kanji_simei;
    }

    /**
     * kanji_simei��ݒ肷��B
     * @param kanji_simei kanji_simei
     */
    public void setKanji_simei(String kanji_simei) {
        this.kanji_simei = kanji_simei;
    }

    /**
     * kanren_gyomu_touroku_flg���擾����B
     * @return String kanren_gyomu_touroku_flg
     */
    public String getKanren_gyomu_touroku_flg() {
        return kanren_gyomu_touroku_flg;
    }

    /**
     * kanren_gyomu_touroku_flg��ݒ肷��B
     * @param kanren_gyomu_touroku_flg kanren_gyomu_touroku_flg
     */
    public void setKanren_gyomu_touroku_flg(String kanren_gyomu_touroku_flg) {
        this.kanren_gyomu_touroku_flg = kanren_gyomu_touroku_flg;
    }

    /**
     * kao_kokai_flg���擾����B
     * @return String kao_kokai_flg
     */
    public String getKao_kokai_flg() {
        return kao_kokai_flg;
    }

    /**
     * kao_kokai_flg��ݒ肷��B
     * @param kao_kokai_flg kao_kokai_flg
     */
    public void setKao_kokai_flg(String kao_kokai_flg) {
        this.kao_kokai_flg = kao_kokai_flg;
    }

    /**
     * kengen_code���擾����B
     * @return String kengen_code
     */
    public String getKengen_code() {
        return kengen_code;
    }

    /**
     * kengen_code��ݒ肷��B
     * @param kengen_code kengen_code
     */
    public void setKengen_code(String kengen_code) {
        this.kengen_code = kengen_code;
    }

    /**
     * kenpo_mainte_flg���擾����B
     * @return String kenpo_mainte_flg
     */
    public String getKenpo_mainte_flg() {
        return kenpo_mainte_flg;
    }

    /**
     * kenpo_mainte_flg��ݒ肷��B
     * @param kenpo_mainte_flg kenpo_mainte_flg
     */
    public void setKenpo_mainte_flg(String kenpo_mainte_flg) {
        this.kenpo_mainte_flg = kenpo_mainte_flg;
    }

    /**
     * kyoiku_kokai_flg���擾����B
     * @return String kyoiku_kokai_flg
     */
    public String getKyoiku_kokai_flg() {
        return kyoiku_kokai_flg;
    }

    /**
     * kyoiku_kokai_flg��ݒ肷��B
     * @param kyoiku_kokai_flg kyoiku_kokai_flg
     */
    public void setKyoiku_kokai_flg(String kyoiku_kokai_flg) {
        this.kyoiku_kokai_flg = kyoiku_kokai_flg;
    }

    /**
     * kyoiku_mainte_flg���擾����B
     * @return String kyoiku_mainte_flg
     */
    public String getKyoiku_mainte_flg() {
        return kyoiku_mainte_flg;
    }

    /**
     * kyoiku_mainte_flg��ݒ肷��B
     * @param kyoiku_mainte_flg kyoiku_mainte_flg
     */
    public void setKyoiku_mainte_flg(String kyoiku_mainte_flg) {
        this.kyoiku_mainte_flg = kyoiku_mainte_flg;
    }

    /**
     * level_code1���擾����B
     * @return String level_code1
     */
    public String getLevel_code1() {
        return level_code1;
    }

    /**
     * level_code1��ݒ肷��B
     * @param level_code1 level_code1
     */
    public void setLevel_code1(String level_code1) {
        this.level_code1 = level_code1;
    }

    /**
     * level_code2���擾����B
     * @return String level_code2
     */
    public String getLevel_code2() {
        return level_code2;
    }

    /**
     * level_code2��ݒ肷��B
     * @param level_code2 level_code2
     */
    public void setLevel_code2(String level_code2) {
        this.level_code2 = level_code2;
    }

    /**
     * level_code3���擾����B
     * @return String level_code3
     */
    public String getLevel_code3() {
        return level_code3;
    }

    /**
     * level_code3��ݒ肷��B
     * @param level_code3 level_code3
     */
    public void setLevel_code3(String level_code3) {
        this.level_code3 = level_code3;
    }

    /**
     * login_osirase_mainte_flg���擾����B
     * @return String login_osirase_mainte_flg
     */
    public String getLogin_osirase_mainte_flg() {
        return login_osirase_mainte_flg;
    }

    /**
     * login_osirase_mainte_flg��ݒ肷��B
     * @param login_osirase_mainte_flg login_osirase_mainte_flg
     */
    public void setLogin_osirase_mainte_flg(String login_osirase_mainte_flg) {
        this.login_osirase_mainte_flg = login_osirase_mainte_flg;
    }

    /**
     * mail���擾����B
     * @return String mail
     */
    public String getMail() {
        return mail;
    }

    /**
     * mail��ݒ肷��B
     * @param mail mail
     */
    public void setMail(String mail) {
        this.mail = mail;
    }

    /**
     * mainte_flg_yobi1���擾����B
     * @return String mainte_flg_yobi1
     */
    public String getMainte_flg_yobi1() {
        return mainte_flg_yobi1;
    }

    /**
     * mainte_flg_yobi1��ݒ肷��B
     * @param mainte_flg_yobi1 mainte_flg_yobi1
     */
    public void setMainte_flg_yobi1(String mainte_flg_yobi1) {
        this.mainte_flg_yobi1 = mainte_flg_yobi1;
    }

    /**
     * naisen���擾����B
     * @return String naisen
     */
    public String getNaisen() {
        return naisen;
    }

    /**
     * naisen��ݒ肷��B
     * @param naisen naisen
     */
    public void setNaisen(String naisen) {
        this.naisen = naisen;
    }

    /**
     * nyusya_nengetu���擾����B
     * @return String nyusya_nengetu
     */
    public String getNyusya_nengetu() {
        return nyusya_nengetu;
    }

    /**
     * nyusya_nengetu��ݒ肷��B
     * @param nyusya_nengetu nyusya_nengetu
     */
    public void setNyusya_nengetu(String nyusya_nengetu) {
        this.nyusya_nengetu = nyusya_nengetu;
    }

    /**
     * password���擾����B
     * @return String password
     */
    public String getPassword() {
        return password;
    }

    /**
     * password��ݒ肷��B
     * @param password password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * personal_mainte_flg���擾����B
     * @return String personal_mainte_flg
     */
    public String getPersonal_mainte_flg() {
        return personal_mainte_flg;
    }

    /**
     * personal_mainte_flg��ݒ肷��B
     * @param personal_mainte_flg personal_mainte_flg
     */
    public void setPersonal_mainte_flg(String personal_mainte_flg) {
        this.personal_mainte_flg = personal_mainte_flg;
    }

    /**
     * ronbun_kokai_flg���擾����B
     * @return String ronbun_kokai_flg
     */
    public String getRonbun_kokai_flg() {
        return ronbun_kokai_flg;
    }

    /**
     * ronbun_kokai_flg��ݒ肷��B
     * @param ronbun_kokai_flg ronbun_kokai_flg
     */
    public void setRonbun_kokai_flg(String ronbun_kokai_flg) {
        this.ronbun_kokai_flg = ronbun_kokai_flg;
    }

    /**
     * ronbun_mainte_flg���擾����B
     * @return String ronbun_mainte_flg
     */
    public String getRonbun_mainte_flg() {
        return ronbun_mainte_flg;
    }

    /**
     * ronbun_mainte_flg��ݒ肷��B
     * @param ronbun_mainte_flg ronbun_mainte_flg
     */
    public void setRonbun_mainte_flg(String ronbun_mainte_flg) {
        this.ronbun_mainte_flg = ronbun_mainte_flg;
    }

    /**
     * seibetu���擾����B
     * @return String seibetu
     */
    public String getSeibetu() {
        return seibetu;
    }

    /**
     * seibetu��ݒ肷��B
     * @param seibetu seibetu
     */
    public void setSeibetu(String seibetu) {
        this.seibetu = seibetu;
    }

    /**
     * seinengappi���擾����B
     * @return String seinengappi
     */
    public String getSeinengappi() {
        return seinengappi;
    }

    /**
     * seinengappi��ݒ肷��B
     * @param seinengappi seinengappi
     */
    public void setSeinengappi(String seinengappi) {
        this.seinengappi = seinengappi;
    }

    /**
     * senmon_code1���擾����B
     * @return String senmon_code1
     */
    public String getSenmon_code1() {
        return senmon_code1;
    }

    /**
     * senmon_code1��ݒ肷��B
     * @param senmon_code1 senmon_code1
     */
    public void setSenmon_code1(String senmon_code1) {
        this.senmon_code1 = senmon_code1;
    }

    /**
     * senmon_code2���擾����B
     * @return String senmon_code2
     */
    public String getSenmon_code2() {
        return senmon_code2;
    }

    /**
     * senmon_code2��ݒ肷��B
     * @param senmon_code2 senmon_code2
     */
    public void setSenmon_code2(String senmon_code2) {
        this.senmon_code2 = senmon_code2;
    }

    /**
     * senmon_code3���擾����B
     * @return String senmon_code3
     */
    public String getSenmon_code3() {
        return senmon_code3;
    }

    /**
     * senmon_code3��ݒ肷��B
     * @param senmon_code3 senmon_code3
     */
    public void setSenmon_code3(String senmon_code3) {
        this.senmon_code3 = senmon_code3;
    }

    /**
     * sikaku_kokai_flg���擾����B
     * @return String sikaku_kokai_flg
     */
    public String getSikaku_kokai_flg() {
        return sikaku_kokai_flg;
    }

    /**
     * sikaku_kokai_flg��ݒ肷��B
     * @param sikaku_kokai_flg sikaku_kokai_flg
     */
    public void setSikaku_kokai_flg(String sikaku_kokai_flg) {
        this.sikaku_kokai_flg = sikaku_kokai_flg;
    }

    /**
     * sikaku_mainte_flg���擾����B
     * @return String sikaku_mainte_flg
     */
    public String getSikaku_mainte_flg() {
        return sikaku_mainte_flg;
    }

    /**
     * sikaku_mainte_flg��ݒ肷��B
     * @param sikaku_mainte_flg sikaku_mainte_flg
     */
    public void setSikaku_mainte_flg(String sikaku_mainte_flg) {
        this.sikaku_mainte_flg = sikaku_mainte_flg;
    }

    /**
     * simei_no���擾����B
     * @return String simei_no
     */
    public String getSimei_no() {
        return simei_no;
    }

    /**
     * simei_no��ݒ肷��B
     * @param simei_no simei_no
     */
    public void setSimei_no(String simei_no) {
        this.simei_no = simei_no;
    }

    /**
     * simei_no_flg���擾����B
     * @return String simei_no_flg
     */
    public String getSimei_no_flg() {
        return simei_no_flg;
    }

    /**
     * simei_no_flg��ݒ肷��B
     * @param simei_no_flg simei_no_flg
     */
    public void setSimei_no_flg(String simei_no_flg) {
        this.simei_no_flg = simei_no_flg;
    }

    /**
     * skill_kokai_flg���擾����B
     * @return String skill_kokai_flg
     */
    public String getSkill_kokai_flg() {
        return skill_kokai_flg;
    }

    /**
     * skill_kokai_flg��ݒ肷��B
     * @param skill_kokai_flg skill_kokai_flg
     */
    public void setSkill_kokai_flg(String skill_kokai_flg) {
        this.skill_kokai_flg = skill_kokai_flg;
    }

    /**
     * skill_mainte_flg���擾����B
     * @return String skill_mainte_flg
     */
    public String getSkill_mainte_flg() {
        return skill_mainte_flg;
    }

    /**
     * skill_mainte_flg��ݒ肷��B
     * @param skill_mainte_flg skill_mainte_flg
     */
    public void setSkill_mainte_flg(String skill_mainte_flg) {
        this.skill_mainte_flg = skill_mainte_flg;
    }

    /**
     * sosiki_code���擾����B
     * @return String sosiki_code
     */
    public String getSosiki_code() {
        return sosiki_code;
    }

    /**
     * sosiki_code��ݒ肷��B
     * @param sosiki_code sosiki_code
     */
    public void setSosiki_code(String sosiki_code) {
        this.sosiki_code = sosiki_code;
    }

    /**
     * sosiki_kokai_flg���擾����B
     * @return String sosiki_kokai_flg
     */
    public String getSosiki_kokai_flg() {
        return sosiki_kokai_flg;
    }

    /**
     * sosiki_kokai_flg��ݒ肷��B
     * @param sosiki_kokai_flg sosiki_kokai_flg
     */
    public void setSosiki_kokai_flg(String sosiki_kokai_flg) {
        this.sosiki_kokai_flg = sosiki_kokai_flg;
    }

    /**
     * sosiki_mainte_flg���擾����B
     * @return String sosiki_mainte_flg
     */
    public String getSosiki_mainte_flg() {
        return sosiki_mainte_flg;
    }

    /**
     * sosiki_mainte_flg��ݒ肷��B
     * @param sosiki_mainte_flg sosiki_mainte_flg
     */
    public void setSosiki_mainte_flg(String sosiki_mainte_flg) {
        this.sosiki_mainte_flg = sosiki_mainte_flg;
    }

    /**
     * sougou_t_do1���擾����B
     * @return String sougou_t_do1
     */
    public String getSougou_t_do1() {
        return sougou_t_do1;
    }

    /**
     * sougou_t_do1��ݒ肷��B
     * @param sougou_t_do1 sougou_t_do1
     */
    public void setSougou_t_do1(String sougou_t_do1) {
        this.sougou_t_do1 = sougou_t_do1;
    }

    /**
     * sougou_t_do2���擾����B
     * @return String sougou_t_do2
     */
    public String getSougou_t_do2() {
        return sougou_t_do2;
    }

    /**
     * sougou_t_do2��ݒ肷��B
     * @param sougou_t_do2 sougou_t_do2
     */
    public void setSougou_t_do2(String sougou_t_do2) {
        this.sougou_t_do2 = sougou_t_do2;
    }

    /**
     * sougou_t_do3���擾����B
     * @return String sougou_t_do3
     */
    public String getSougou_t_do3() {
        return sougou_t_do3;
    }

    /**
     * sougou_t_do3��ݒ肷��B
     * @param sougou_t_do3 sougou_t_do3
     */
    public void setSougou_t_do3(String sougou_t_do3) {
        this.sougou_t_do3 = sougou_t_do3;
    }

    /**
     * syagai_kokai_flg���擾����B
     * @return String syagai_kokai_flg
     */
    public String getSyagai_kokai_flg() {
        return syagai_kokai_flg;
    }

    /**
     * syagai_kokai_flg��ݒ肷��B
     * @param syagai_kokai_flg syagai_kokai_flg
     */
    public void setSyagai_kokai_flg(String syagai_kokai_flg) {
        this.syagai_kokai_flg = syagai_kokai_flg;
    }

    /**
     * syagai_mainte_flg���擾����B
     * @return String syagai_mainte_flg
     */
    public String getSyagai_mainte_flg() {
        return syagai_mainte_flg;
    }

    /**
     * syagai_mainte_flg��ݒ肷��B
     * @param syagai_mainte_flg syagai_mainte_flg
     */
    public void setSyagai_mainte_flg(String syagai_mainte_flg) {
        this.syagai_mainte_flg = syagai_mainte_flg;
    }

    /**
     * syagai_ronbun_mainte_flg���擾����B
     * @return String syagai_ronbun_mainte_flg
     */
    public String getSyagai_ronbun_mainte_flg() {
        return syagai_ronbun_mainte_flg;
    }

    /**
     * syagai_ronbun_mainte_flg��ݒ肷��B
     * @param syagai_ronbun_mainte_flg syagai_ronbun_mainte_flg
     */
    public void setSyagai_ronbun_mainte_flg(String syagai_ronbun_mainte_flg) {
        this.syagai_ronbun_mainte_flg = syagai_ronbun_mainte_flg;
    }

    /**
     * syanaibin���擾����B
     * @return String syanaibin
     */
    public String getSyanaibin() {
        return syanaibin;
    }

    /**
     * syanaibin��ݒ肷��B
     * @param syanaibin syanaibin
     */
    public void setSyanaibin(String syanaibin) {
        this.syanaibin = syanaibin;
    }

    /**
     * syanaireki_kokai_flg���擾����B
     * @return String syanaireki_kokai_flg
     */
    public String getSyanaireki_kokai_flg() {
        return syanaireki_kokai_flg;
    }

    /**
     * syanaireki_kokai_flg��ݒ肷��B
     * @param syanaireki_kokai_flg syanaireki_kokai_flg
     */
    public void setSyanaireki_kokai_flg(String syanaireki_kokai_flg) {
        this.syanaireki_kokai_flg = syanaireki_kokai_flg;
    }

    /**
     * syoku_code1���擾����B
     * @return String syoku_code1
     */
    public String getSyoku_code1() {
        return syoku_code1;
    }

    /**
     * syoku_code1��ݒ肷��B
     * @param syoku_code1 syoku_code1
     */
    public void setSyoku_code1(String syoku_code1) {
        this.syoku_code1 = syoku_code1;
    }

    /**
     * syoku_code2���擾����B
     * @return String syoku_code2
     */
    public String getSyoku_code2() {
        return syoku_code2;
    }

    /**
     * syoku_code2��ݒ肷��B
     * @param syoku_code2 syoku_code2
     */
    public void setSyoku_code2(String syoku_code2) {
        this.syoku_code2 = syoku_code2;
    }

    /**
     * syoku_code3���擾����B
     * @return String syoku_code3
     */
    public String getSyoku_code3() {
        return syoku_code3;
    }

    /**
     * syoku_code3��ݒ肷��B
     * @param syoku_code3 syoku_code3
     */
    public void setSyoku_code3(String syoku_code3) {
        this.syoku_code3 = syoku_code3;
    }

    /**
     * syokui_code���擾����B
     * @return String syokui_code
     */
    public String getSyokui_code() {
        return syokui_code;
    }

    /**
     * syokui_code��ݒ肷��B
     * @param syokui_code syokui_code
     */
    public void setSyokui_code(String syokui_code) {
        this.syokui_code = syokui_code;
    }

    /**
     * syokui_kokai_flg���擾����B
     * @return String syokui_kokai_flg
     */
    public String getSyokui_kokai_flg() {
        return syokui_kokai_flg;
    }

    /**
     * syokui_kokai_flg��ݒ肷��B
     * @param syokui_kokai_flg syokui_kokai_flg
     */
    public void setSyokui_kokai_flg(String syokui_kokai_flg) {
        this.syokui_kokai_flg = syokui_kokai_flg;
    }

    /**
     * syokumu_kokai_flg���擾����B
     * @return String syokumu_kokai_flg
     */
    public String getSyokumu_kokai_flg() {
        return syokumu_kokai_flg;
    }

    /**
     * syokumu_kokai_flg��ݒ肷��B
     * @param syokumu_kokai_flg syokumu_kokai_flg
     */
    public void setSyokumu_kokai_flg(String syokumu_kokai_flg) {
        this.syokumu_kokai_flg = syokumu_kokai_flg;
    }

    /**
     * syozoku_code_1���擾����B
     * @return String syozoku_code_1
     */
    public String getSyozoku_code_1() {
        return syozoku_code_1;
    }

    /**
     * syozoku_code_1��ݒ肷��B
     * @param syozoku_code_1 syozoku_code_1
     */
    public void setSyozoku_code_1(String syozoku_code_1) {
        this.syozoku_code_1 = syozoku_code_1;
    }

    /**
     * syozoku_code_2���擾����B
     * @return String syozoku_code_2
     */
    public String getSyozoku_code_2() {
        return syozoku_code_2;
    }

    /**
     * syozoku_code_2��ݒ肷��B
     * @param syozoku_code_2 syozoku_code_2
     */
    public void setSyozoku_code_2(String syozoku_code_2) {
        this.syozoku_code_2 = syozoku_code_2;
    }

    /**
     * syozoku_code_3���擾����B
     * @return String syozoku_code_3
     */
    public String getSyozoku_code_3() {
        return syozoku_code_3;
    }

    /**
     * syozoku_code_3��ݒ肷��B
     * @param syozoku_code_3 syozoku_code_3
     */
    public void setSyozoku_code_3(String syozoku_code_3) {
        this.syozoku_code_3 = syozoku_code_3;
    }

    /**
     * syozoku_code_4���擾����B
     * @return String syozoku_code_4
     */
    public String getSyozoku_code_4() {
        return syozoku_code_4;
    }

    /**
     * syozoku_code_4��ݒ肷��B
     * @param syozoku_code_4 syozoku_code_4
     */
    public void setSyozoku_code_4(String syozoku_code_4) {
        this.syozoku_code_4 = syozoku_code_4;
    }

    /**
     * syozoku_code_5���擾����B
     * @return String syozoku_code_5
     */
    public String getSyozoku_code_5() {
        return syozoku_code_5;
    }

    /**
     * syozoku_code_5��ݒ肷��B
     * @param syozoku_code_5 syozoku_code_5
     */
    public void setSyozoku_code_5(String syozoku_code_5) {
        this.syozoku_code_5 = syozoku_code_5;
    }

    /**
     * syozoku_code_6���擾����B
     * @return String syozoku_code_6
     */
    public String getSyozoku_code_6() {
        return syozoku_code_6;
    }

    /**
     * syozoku_code_6��ݒ肷��B
     * @param syozoku_code_6 syozoku_code_6
     */
    public void setSyozoku_code_6(String syozoku_code_6) {
        this.syozoku_code_6 = syozoku_code_6;
    }

    /**
     * syozoku_code_7���擾����B
     * @return String syozoku_code_7
     */
    public String getSyozoku_code_7() {
        return syozoku_code_7;
    }

    /**
     * syozoku_code_7��ݒ肷��B
     * @param syozoku_code_7 syozoku_code_7
     */
    public void setSyozoku_code_7(String syozoku_code_7) {
        this.syozoku_code_7 = syozoku_code_7;
    }

    /**
     * syozoku_code_8���擾����B
     * @return String syozoku_code_8
     */
    public String getSyozoku_code_8() {
        return syozoku_code_8;
    }

    /**
     * syozoku_code_8��ݒ肷��B
     * @param syozoku_code_8 syozoku_code_8
     */
    public void setSyozoku_code_8(String syozoku_code_8) {
        this.syozoku_code_8 = syozoku_code_8;
    }

    /**
     * syozoku_code_9���擾����B
     * @return String syozoku_code_9
     */
    public String getSyozoku_code_9() {
        return syozoku_code_9;
    }

    /**
     * syozoku_code_9��ݒ肷��B
     * @param syozoku_code_9 syozoku_code_9
     */
    public void setSyozoku_code_9(String syozoku_code_9) {
        this.syozoku_code_9 = syozoku_code_9;
    }

    /**
     * taisyoku_nengappi���擾����B
     * @return String taisyoku_nengappi
     */
    public String getTaisyoku_nengappi() {
        return taisyoku_nengappi;
    }

    /**
     * taisyoku_nengappi��ݒ肷��B
     * @param taisyoku_nengappi taisyoku_nengappi
     */
    public void setTaisyoku_nengappi(String taisyoku_nengappi) {
        this.taisyoku_nengappi = taisyoku_nengappi;
    }

    /**
     * taisyokusya_kensaku_kengen_flg���擾����B
     * @return String taisyokusya_kensaku_kengen_flg
     */
    public String getTaisyokusya_kensaku_kengen_flg() {
        return taisyokusya_kensaku_kengen_flg;
    }

    /**
     * taisyokusya_kensaku_kengen_flg��ݒ肷��B
     * @param taisyokusya_kensaku_kengen_flg taisyokusya_kensaku_kengen_flg
     */
    public void setTaisyokusya_kensaku_kengen_flg(String taisyokusya_kensaku_kengen_flg) {
        this.taisyokusya_kensaku_kengen_flg = taisyokusya_kensaku_kengen_flg;
    }

    /**
     * tokei_bunseki_kengen���擾����B
     * @return String tokei_bunseki_kengen
     */
    public String getTokei_bunseki_kengen() {
        return tokei_bunseki_kengen;
    }

    /**
     * tokei_bunseki_kengen��ݒ肷��B
     * @param tokei_bunseki_kengen tokei_bunseki_kengen
     */
    public void setTokei_bunseki_kengen(String tokei_bunseki_kengen) {
        this.tokei_bunseki_kengen = tokei_bunseki_kengen;
    }

    /**
     * yakusyoku���擾����B
     * @return String yakusyoku
     */
    public String getYakusyoku() {
        return yakusyoku;
    }

    /**
     * yakusyoku��ݒ肷��B
     * @param yakusyoku yakusyoku
     */
    public void setYakusyoku(String yakusyoku) {
        this.yakusyoku = yakusyoku;
    }

    /**
     * yakusyoku_code���擾����B
     * @return String yakusyoku_code
     */
    public String getYakusyoku_code() {
        return yakusyoku_code;
    }

    /**
     * yakusyoku_code��ݒ肷��B
     * @param yakusyoku_code yakusyoku_code
     */
    public void setYakusyoku_code(String yakusyoku_code) {
        this.yakusyoku_code = yakusyoku_code;
    }

    /**
     * yakusyoku_kokai_flg���擾����B
     * @return String yakusyoku_kokai_flg
     */
    public String getYakusyoku_kokai_flg() {
        return yakusyoku_kokai_flg;
    }

    /**
     * yakusyoku_kokai_flg��ݒ肷��B
     * @param yakusyoku_kokai_flg yakusyoku_kokai_flg
     */
    public void setYakusyoku_kokai_flg(String yakusyoku_kokai_flg) {
        this.yakusyoku_kokai_flg = yakusyoku_kokai_flg;
    }

    /**
     * yobi_ryoiki���擾����B
     * @return String yobi_ryoiki
     */
    public String getYobi_ryoiki() {
        return yobi_ryoiki;
    }

    /**
     * yobi_ryoiki��ݒ肷��B
     * @param yobi_ryoiki yobi_ryoiki
     */
    public void setYobi_ryoiki(String yobi_ryoiki) {
        this.yobi_ryoiki = yobi_ryoiki;
    }

    /**
     * yobi1���擾����B
     * @return String yobi1
     */
    public String getYobi1() {
        return yobi1;
    }

    /**
     * yobi1��ݒ肷��B
     * @param yobi1 yobi1
     */
    public void setYobi1(String yobi1) {
        this.yobi1 = yobi1;
    }

    /**
     * yobi10���擾����B
     * @return String yobi10
     */
    public String getYobi10() {
        return yobi10;
    }

    /**
     * yobi10��ݒ肷��B
     * @param yobi10 yobi10
     */
    public void setYobi10(String yobi10) {
        this.yobi10 = yobi10;
    }

    /**
     * yobi2���擾����B
     * @return String yobi2
     */
    public String getYobi2() {
        return yobi2;
    }

    /**
     * yobi2��ݒ肷��B
     * @param yobi2 yobi2
     */
    public void setYobi2(String yobi2) {
        this.yobi2 = yobi2;
    }

    /**
     * yobi3���擾����B
     * @return String yobi3
     */
    public String getYobi3() {
        return yobi3;
    }

    /**
     * yobi3��ݒ肷��B
     * @param yobi3 yobi3
     */
    public void setYobi3(String yobi3) {
        this.yobi3 = yobi3;
    }

    /**
     * yobi4���擾����B
     * @return String yobi4
     */
    public String getYobi4() {
        return yobi4;
    }

    /**
     * yobi4��ݒ肷��B
     * @param yobi4 yobi4
     */
    public void setYobi4(String yobi4) {
        this.yobi4 = yobi4;
    }

    /**
     * yobi5���擾����B
     * @return String yobi5
     */
    public String getYobi5() {
        return yobi5;
    }

    /**
     * yobi5��ݒ肷��B
     * @param yobi5 yobi5
     */
    public void setYobi5(String yobi5) {
        this.yobi5 = yobi5;
    }

    /**
     * yobi6���擾����B
     * @return String yobi6
     */
    public String getYobi6() {
        return yobi6;
    }

    /**
     * yobi6��ݒ肷��B
     * @param yobi6 yobi6
     */
    public void setYobi6(String yobi6) {
        this.yobi6 = yobi6;
    }

    /**
     * yobi7���擾����B
     * @return String yobi7
     */
    public String getYobi7() {
        return yobi7;
    }

    /**
     * yobi7��ݒ肷��B
     * @param yobi7 yobi7
     */
    public void setYobi7(String yobi7) {
        this.yobi7 = yobi7;
    }

    /**
     * yobi8���擾����B
     * @return String yobi8
     */
    public String getYobi8() {
        return yobi8;
    }

    /**
     * yobi8��ݒ肷��B
     * @param yobi8 yobi8
     */
    public void setYobi8(String yobi8) {
        this.yobi8 = yobi8;
    }

    /**
     * yobi9���擾����B
     * @return String yobi9
     */
    public String getYobi9() {
        return yobi9;
    }

    /**
     * yobi9��ݒ肷��B
     * @param yobi9 yobi9
     */
    public void setYobi9(String yobi9) {
        this.yobi9 = yobi9;
    }

    /**
     * zensyokureki_kokai_flg���擾����B
     * @return String zensyokureki_kokai_flg
     */
    public String getZensyokureki_kokai_flg() {
        return zensyokureki_kokai_flg;
    }

    /**
     * zensyokureki_kokai_flg��ݒ肷��B
     * @param zensyokureki_kokai_flg zensyokureki_kokai_flg
     */
    public void setZensyokureki_kokai_flg(String zensyokureki_kokai_flg) {
        this.zensyokureki_kokai_flg = zensyokureki_kokai_flg;
    }
}