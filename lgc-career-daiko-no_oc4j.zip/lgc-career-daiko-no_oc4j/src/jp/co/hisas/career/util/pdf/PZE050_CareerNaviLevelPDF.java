/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i�v��nCareer@Net�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 */

package jp.co.hisas.career.util.pdf;

import java.awt.Color;
import java.io.*;

import jp.co.hisas.career.util.log.Log;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

public class PZE050_CareerNaviLevelPDF{

    /* ���O�C��No */
    private String login_no;

    /*PDF���*/
    private String[]   outDefItem;
    private String[]   outputItem;
    private String[][] level_def;

    /**
     * �R���X�g���N�^
     *
     * @param login_no
     */
    public PZE050_CareerNaviLevelPDF( String login_no ) {
        this.login_no = login_no;
    }

    /**
     * ���x���ʋƖ��o���i�r�Q�[�V���������擾����
     *
     * @param outDefItem
     * @param outputItem
     * @param level_def
     */
    public void setLevelNavi( String[] outDefItem , String[] outputItem , String[][] level_def ){
        Log.method( login_no , "IN" , "" );
        this.outDefItem = outDefItem;
        this.outputItem = outputItem;
        this.level_def  = level_def;
        Log.method( login_no , "OUT" , "" );
    }


    /**
     * PDF���쐬����
     * @return
     */
    public void executePDF( OutputStream ops )
    throws Exception {
        Log.method( login_no , "IN" , "" );

        /* �f�t�H���g�e�[�u���̐ݒ� */
        class MyTable extends Table {
            /**
             * @param  arg0
             * @throws BadElementException
             */
            public MyTable( int arg0 ) throws BadElementException {
                super( arg0 );
                setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
                setDefaultVerticalAlignment( Element.ALIGN_MIDDLE );

                setPadding( 2 );
            }
        }


        /*
         * Document�I�u�W�F�N�g�̐���
         *  A4�c�́A Document document = new Document(PageSize.A4);
         *  A4���́ADocument document = new Document(PageSize.A4.rotate());
         */
        Document document = new Document( PageSize.A4 );
        PdfWriter pw      = null;

        try {
            /* PdfWriter�I�u�W�F�N�g�̐��� */
            pw = PdfWriter.getInstance( document, ops );
            pw.setCloseStream(true);

            /* �w�i�F */
            Color BackColor = Color.white;

            /* �h�L�������g��OPEN */
            HeaderFooter footer = new HeaderFooter( new Phrase( "- " ) , new Phrase( " -" ) );
            footer.setBorderColor( BackColor );
            footer.setAlignment( Element.ALIGN_CENTER );
            document.setFooter( footer );
            document.open();

            /* �t�H���g�̐ݒ� */
            float default_font_size = 10;
            BaseFont bf             = BaseFont.createFont( "HeiseiMin-W3", "UniJIS-UCS2-HW-H", false );
            Font font               = new Font( bf, default_font_size );

            /* �e�[�u���̕� */
            int TableWidthTop = 90;
            int TableWidth    = 100;

            /* �J�����̕� */
            int[] defLabel_widths = { 3 , 97 };

            /* �R���e���c�̋L�q */
            MyTable table;
            Cell    cell;

            // �E��A��啪��A���x���̑I�����
            table = new MyTable( 6 );
            int[] selectinfo_widths = { 8 , 22 , 12 , 40 , 10 , 8 };
            table.setWidths( selectinfo_widths );
            table.setWidth ( TableWidthTop );
            table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );

            /* �y�E��z */
            cell = new Cell( new Phrase( outDefItem[0] , font ) );
            cell.setBackgroundColor( new Color( 204 , 204 , 255 ) );
            table.addCell( cell );
            /* �E�� */
            cell = new Cell( new Phrase( outputItem[0] , font ) );
            cell.setBackgroundColor( BackColor );
            table.addCell( cell );

            /* �y��啪��z */
            cell = new Cell( new Phrase( outDefItem[1] , font ) );
            cell.setBackgroundColor( new Color( 204 , 204 , 255 ) );
            table.addCell( cell );
            /* ��啪�� */
            cell = new Cell( new Phrase( outputItem[1] , font ) );
            cell.setBackgroundColor( BackColor );
            table.addCell( cell );

            /* �y���x���z */
            cell = new Cell( new Phrase( outDefItem[2] , font ) );
            cell.setBackgroundColor( new Color( 204 , 204 , 255 ) );
            table.addCell( cell );
            /* ���x�� */
            cell = new Cell( new Phrase( outputItem[2] , font ) );
            cell.setBackgroundColor( BackColor );
            table.addCell( cell );

            /* �h�L�������g�ɒǉ� */
            document.add( table );


            // 1�s�X�y�[�X
            Table space = new MyTable( 1 );
            space.setBorderColor( BackColor );
            space.addCell("");

            /* �h�L�������g�ɒǉ� */
            document.add( space );


            // �Œ蕶��
            table = new MyTable( 1 );
            table.setWidth ( TableWidth );
            table.setBorderColor( BackColor );
            table.setBackgroundColor( new Color( 39 , 64 , 139 ) );
            String phrase1 = "���Y"
                           + outDefItem[0] + "�E"
                           + outDefItem[1] + "�E"
                           + outDefItem[2] + "��"
                           + outDefItem[3] + "�i�r�Q�[�V�����쐬";

            // �t�H���g�̐F�𔒂ɂ���
            font.setColor( 255 , 255 , 255 );
            cell  = new Cell ( new Phrase( phrase1 , font ) );
            table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            table.addCell( cell );

            /* �h�L�������g�ɒǉ� */
            document.add( table );


            // �O����`���b�Z�[�W
            table = new MyTable( 2 );
            table.setWidths( defLabel_widths );
            table.setWidth ( TableWidth );
            table.setBorderColor( BackColor );

            /* �A�i�E���X1 */
            // �t�H���g�̐F��Ԃɂ���
            font.setColor( 255 , 0 , 0 );
            cell = new Cell( new Phrase( "��" , font ) );
            cell.setBackgroundColor( BackColor );
            cell.setBorderColor( BackColor );
            table.setDefaultHorizontalAlignment( Element.ALIGN_RIGHT );
            table.addCell( cell );
            cell = new Cell( new Phrase( outDefItem[4] , font ) );
            cell.setBackgroundColor( BackColor );
            cell.setBorderColor( BackColor );
            table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            table.addCell( cell );

            /* �A�i�E���X2 */
            cell = new Cell( new Phrase( "��" , font ) );
            cell.setBackgroundColor( BackColor );
            cell.setBorderColor( BackColor );
            table.setDefaultHorizontalAlignment( Element.ALIGN_RIGHT );
            table.addCell( cell );
            cell = new Cell( new Phrase( outDefItem[5] , font ) );
            cell.setBackgroundColor( BackColor );
            cell.setBorderColor( BackColor );
            table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            table.addCell( cell );

            /* �h�L�������g�ɒǉ� */
            document.add( table );

            /* �h�L�������g�ɒǉ� */
            document.add( space );


            // ���x��
            table = new MyTable( 2 );
            table.setWidths( defLabel_widths );
            table.setWidth ( TableWidth );
            table.setBorderColor( BackColor );

            /* �y�E��z�̒�` */
            cell = new Cell( new Phrase( "��" , font ) );
            cell.setBackgroundColor( BackColor );
            cell.setBorderColor( BackColor );
            table.setDefaultHorizontalAlignment( Element.ALIGN_RIGHT );
            table.addCell( cell );
            cell = new Cell( new Phrase( outDefItem[0] + "�̒�`" , font ) );
            cell.setBackgroundColor( BackColor );
            cell.setBorderColor( BackColor );
            table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            table.addCell( cell );

            /* �h�L�������g�ɒǉ� */
            document.add( table );


            // �t�H���g�̐F�����ɖ߂�
            font.setColor( 0 , 0 , 0 );

            // �E��̒�`
            table = new MyTable( 1 );
            table.setWidth ( TableWidth );
            cell  = new Cell ( new Phrase( outputItem[3] , font ) );
            table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            table.addCell( cell );

            /* �h�L�������g�ɒǉ� */
            document.add( table );

            /* �h�L�������g�ɒǉ� */
            document.add( space );


            // ���x��
            table = new MyTable( 2 );
            table.setWidths( defLabel_widths );
            table.setWidth ( TableWidth );
            table.setBorderColor( BackColor );

            /* �y��啪��z�̒�` */
            // �t�H���g�̐F��Ԃɂ���
            font.setColor( 255 , 0 , 0 );
            cell = new Cell( new Phrase( "��" , font ) );
            cell.setBackgroundColor( BackColor );
            cell.setBorderColor( BackColor );
            table.setDefaultHorizontalAlignment( Element.ALIGN_RIGHT );
            table.addCell( cell );
            cell = new Cell( new Phrase( outDefItem[1] + "�̒�`" , font ) );
            cell.setBackgroundColor( BackColor );
            cell.setBorderColor( BackColor );
            table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            table.addCell( cell );

            /* �h�L�������g�ɒǉ� */
            document.add( table );


            // �t�H���g�̐F�����ɖ߂�
            font.setColor( 0 , 0 , 0 );

            // ��啪��̒�`
            table = new MyTable( 1 );
            table.setWidth ( TableWidth );
            cell  = new Cell ( new Phrase( outputItem[4] , font ) );
            table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            table.addCell( cell );

            /* �h�L�������g�ɒǉ� */
            document.add( table );

            /* �h�L�������g�ɒǉ� */
            document.add( space );


            // ���x��
            // �t�H���g�̐F��Ԃɂ���
            font.setColor( 255 , 0 , 0 );
            table = new MyTable( 2 );
            table.setWidths( defLabel_widths );
            table.setWidth ( TableWidth );
            table.setBorderColor( BackColor );

            /* �y���x���z�̒�` */
            cell = new Cell( new Phrase( "��" , font ) );
            cell.setBackgroundColor( BackColor );
            cell.setBorderColor( BackColor );
            table.setDefaultHorizontalAlignment( Element.ALIGN_RIGHT );
            table.addCell( cell );
            cell = new Cell( new Phrase( outDefItem[2] + "�̒�`" , font ) );
            cell.setBackgroundColor( BackColor );
            cell.setBorderColor( BackColor );
            table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            table.addCell( cell );

            /* �h�L�������g�ɒǉ� */
            document.add( table );


            // �t�H���g�̐F�����ɖ߂�
            font.setColor( 0 , 0 , 0 );

            // ���x���̒�`
            table = new MyTable( 2 );
            int[] level_widths = { 3 , 97 };
            table.setWidths( level_widths );
            table.setWidth ( TableWidth );

            for ( int i = 0 ; i < level_def.length ; i++ ){
                /* �B���x�敪 */
                cell  = new Cell ( new Phrase( "��" + level_def[i][2] , font ) );
                cell.setColspan( 2 );
                cell.setBackgroundColor( BackColor );
                cell.setBorderColor( BackColor );
                table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
                table.addCell( cell );

                /* �B���x���� */
                cell  = new Cell ( "" );
                cell.setBackgroundColor( BackColor );
                cell.setBorderColor( BackColor );
                table.addCell( cell );
                cell  = new Cell ( new Phrase ( level_def[i][3] , font ) );
                cell.setBackgroundColor( BackColor );
                cell.setBorderColor( BackColor );
                table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
                table.addCell( cell );

                /* �B���x�T�v */
                int j = i;
                for ( i = j ; i < level_def.length ; i ++ ) {
                    cell = new Cell ( "" );
                    cell.setBackgroundColor( BackColor );
                    cell.setBorderColor( BackColor );
                    table.addCell( cell );
                    cell = new Cell ( new Phrase ( level_def[i][4] , font ));
                    cell.setBackgroundColor( BackColor );
                    cell.setBorderColor( BackColor );
                    table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
                    table.addCell( cell );
                    if ( i + 1 == level_def.length 
                        || !level_def[i][0].equals(level_def[i+1][0] ) ) {
                        break;
                    }
                }
            }

            /* �h�L�������g�ɒǉ� */
            document.add( table );

            /* �h�L�������g�ɒǉ� */
            document.add( space );


            // ���x��
            table = new MyTable( 2 );
            table.setWidths( defLabel_widths );
            table.setWidth ( TableWidth );
            table.setBorderColor( BackColor );

            /* �Œ蕶�� */
            // �t�H���g�̐F��Ԃɂ���
            font.setColor( 255 , 0 , 0 );
            cell = new Cell( new Phrase( "��" , font ) );
            cell.setBackgroundColor( BackColor );
            cell.setBorderColor( BackColor );
            table.setDefaultHorizontalAlignment( Element.ALIGN_RIGHT );
            table.addCell( cell );
            String phrase2 = "���Y"
                           + outDefItem[0] + "�E"
                           + outDefItem[1] + "�E"
                           + outDefItem[2] + "��"
                           + outDefItem[3] + "�i�r�Q�[�V����";
            cell = new Cell ( new Phrase( phrase2 , font ) );
            cell.setBackgroundColor( BackColor );
            cell.setBorderColor( BackColor );
            table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            table.addCell( cell );

            /* �h�L�������g�ɒǉ� */
            document.add( table );


            // �t�H���g�̐F�����ɖ߂�
            font.setColor( 0 , 0 , 0 );

            // �i�r�Q�[�V�������
            /* �i�r�Q�[�V�����A�ۑ��A��ۑ� */
            table = new MyTable( 2 );
            int[] navi_widths = { 85 , 15 };
            table.setWidths( navi_widths );
            table.setWidth ( TableWidth );
            cell  = new Cell ( new Phrase( outputItem[5] , font ) );
            table.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            table.addCell( cell );
            cell  = new Cell ( new Phrase( outputItem[6] , font ) );
            table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
            table.setDefaultVerticalAlignment  ( Element.ALIGN_MIDDLE );
            table.addCell( cell );

            /* �h�L�������g�ɒǉ� */
            document.add( table );


            /* DB��̍ŏI�X�V��� */
            table = new MyTable( 7 );
            int[] lastupdate_widths = { 15 , 8 , 17 , 8 , 17 , 15 , 20 };
            table.setWidths( lastupdate_widths );
            table.setWidth ( TableWidth );
            table.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );

            cell  = new Cell ( new Phrase( "�ŏI�X�V��" , font ) );
            cell.setBackgroundColor( new Color( 204 , 204 , 255 ) );
            table.addCell( cell );
            cell  = new Cell ( new Phrase( outDefItem[6] , font ) );
            cell.setBackgroundColor( new Color( 204 , 204 , 255 ) );
            table.addCell( cell );
            cell  = new Cell ( new Phrase( outputItem[7] , font ) );
            table.addCell( cell );
            cell  = new Cell ( new Phrase( outDefItem[7] , font ) );
            cell.setBackgroundColor( new Color( 204 , 204 , 255 ) );
            table.addCell( cell );
            cell  = new Cell ( new Phrase( outputItem[8] , font ) );
            table.addCell( cell );
            cell  = new Cell ( new Phrase( "�ŏI�X�V����" , font ) );
            cell.setBackgroundColor( new Color( 204 , 204 , 255 ) );
            table.addCell( cell );
            cell  = new Cell ( new Phrase( outputItem[9] , font ) );
            table.addCell( cell );

            /* �h�L�������g�ɒǉ� */
            document.add( table );

            Log.method( login_no , "OUT" , "" );

        } catch ( BadElementException e ) {
            throw (Exception)e;
        } catch ( DocumentException e ) {
            throw (Exception)e;
        } catch ( IOException e ) {
            throw (Exception)e;
        } catch ( Exception e ){
            throw (Exception)e;
        } finally {
            /* �h�L�������g����� */
            if (document != null) {
                try {
                    document.close();
                } catch (Exception e) {
                    throw (Exception)e;
                }
            }
            if (pw != null) {
                try {
                    pw.close();
                } catch (Exception e) {
                    throw (Exception)e;
                }
            }
        }
    }
}
