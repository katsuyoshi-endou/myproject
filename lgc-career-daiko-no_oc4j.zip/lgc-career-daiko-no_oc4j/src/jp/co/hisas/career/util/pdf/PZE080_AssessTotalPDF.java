/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i�v��nCareer@Net�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/09/07  01.00       �n�� ��q     �V�K�쐬  <C-PPE02-004>
 *   2004/09/22              �n�� ��q     �o�͕s���C��  <B-PPE02-019>
 *   2004/09/22              �n�� ��q     PDF�\������   <B-PPE02-020>
 * 
 */

package jp.co.hisas.career.util.pdf;

import java.io.*;
import java.awt.Color;
import java.awt.Point;

import jp.co.hisas.career.util.log.Log;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

public class PZE080_AssessTotalPDF {


    // ���O�C��No
    private String login_no;

    // PDF���
    String[]   annoItem    = null;
    String[]   paraItem    = null;
    String[]   percentDef  = null;
    String[][] colorDef    = null;
    String     memberCnt   = null;
    String     matchTotal  = null;
    String[][] syoku_list  = null;
    String[][] senmon_list = null;
    String[][] level_list  = null;
    String     searchCnd   = null;  // INS#P-PPE02-019-004


    /**
     * �R���X�g���N�^
     *
     * @param login_no
     */
    public PZE080_AssessTotalPDF( String login_no ) {
        this.login_no = login_no;
    }

    /**
     * �A�i�E���X������ݒ肷��B
     * 
     * @param val
     * 
     */
    public void setAnnounce( String[] val ) {
        this.annoItem = val;
    }

    /**
     * �O����`���ڂ�ݒ肷��B
     * 
     * @param val
     * 
     */
    public void setParameter( String[] val ) {
        this.paraItem = val;
    }

    /**
     * �F��`��ݒ肷��B
     * 
     * @param val
     * 
     */
    public void setPercentDef( String[] val ) {
        this.percentDef = val;
    }

    /**
     * �F��`��ݒ肷��B
     * 
     * @param val
     * 
     */
    public void setColorDef( String[][] val ) {
        this.colorDef = val;
    }

    /**
     * ��������ݒ肷��B
     * 
     * @param val
     * 
     */
    public void setMemberCnt( String val ) {
        this.memberCnt = val;
    }

    /**
     * �W�v���ʐl����ݒ肷��B
     * 
     * @param val
     */
    public void setMatchTotal( String val ) {
        this.matchTotal = val;
    }

    /**
     * �E�탊�X�g��ݒ肷��B
     * 
     * @param val
     * 
     */
    public void setSyokuList( String[][] val ) {
        this.syoku_list = val;
    }

    /**
     * ��啪�샊�X�g��ݒ肷��B
     * 
     * @param val
     * 
     */
    public void setSenmonList( String[][] val ) {
        this.senmon_list = val;
    }

    /**
     * ���x�����X�g��ݒ肷��B
     * 
     * @param val
     * 
     */
    public void setLevelList( String[][] val ) {
        this.level_list = val;
    }

    // INS#P-PPE02-019-004-S
    /**
     * ����������ݒ肷��B
     * 
     * @param val
     * 
     */
    public void setSearchCnd( String val ) {
        this.searchCnd = val;
    }
    // INS#P-PPE02-019-004-E

    /**
     * PDF���쐬����
     * @return
     */
    public void executePDF ( OutputStream ops )
    throws Exception {
        Log.method( login_no, "IN", "" );

        // �f�t�H���g�e�[�u���̐ݒ�
        class MyTable extends Table {
            /**
             * @param  arg0
             * @throws BadElementException
             */
            public MyTable( int arg0 ) throws BadElementException {
                super( arg0 );
                setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
                setDefaultVerticalAlignment( Element.ALIGN_MIDDLE );

                setPadding( 1 );
            }

            /**
             * @param  arg0
             * @throws BadElementException
             */
            public MyTable( int arg0, int arg1 ) throws BadElementException {
                super( arg0, arg1 );
                setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
                setDefaultVerticalAlignment( Element.ALIGN_MIDDLE );

                setPadding( 1 );
            }

        }



        // null�`�F�b�N
        if ( annoItem == null    ) {
            throw new Exception( "PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B" );
        }
        if ( paraItem == null    ) {
            throw new Exception( "PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B" );
        }
        if ( percentDef == null    ) {
            throw new Exception( "PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B" );
        }
        if ( colorDef == null    ) {
            throw new Exception( "PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B" );
        }
        if ( memberCnt == null   ) {
            throw new Exception( "PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B" );
        }
        if ( matchTotal == null  ) {
            throw new Exception( "PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B" );
        }
        if ( syoku_list == null  ) {
            throw new Exception( "PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B" );
        }
        if ( senmon_list == null ) {
            throw new Exception( "PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B" );
        }
        if ( level_list == null  ) {
            throw new Exception( "PDF�쐬�ɕK�v�ȏ�񂪕s�����Ă��܂��B" );
        }

        /*
         * Document�I�u�W�F�N�g�̐���
         *  A4�c�́ADocument document = new Document( PageSize.A4 );
         *  A4���́ADocument document = new Document( PageSize.A4.rotate() );
         */

        Document document = new Document( PageSize.A4 );
        PdfWriter pw      = null;

        try {
            // PdfWriter�I�u�W�F�N�g�̐���
            pw = PdfWriter.getInstance( document, ops );
            pw.setCloseStream( true );

            // �w�i�F
            Color backColor   = Color.white;
            // ���F
            Color borderColor = Color.black;
            // �F�w��p�ݒ�
            Color CellColor1  = new Color( Integer.parseInt( colorDef[0][0] ),
                                           Integer.parseInt( colorDef[0][1] ),
                                           Integer.parseInt( colorDef[0][2] ),
                                           0 );

            Color CellColor2  = new Color( Integer.parseInt( colorDef[1][0] ),
                                           Integer.parseInt( colorDef[1][1] ),
                                           Integer.parseInt( colorDef[1][2] ),
                                           0 );

            Color CellColor3  = new Color( Integer.parseInt( colorDef[2][0] ),
                                           Integer.parseInt( colorDef[2][1] ),
                                           Integer.parseInt( colorDef[2][2] ),
                                           0 );

            Color CellColor4  = new Color( Integer.parseInt( colorDef[3][0] ),
                                           Integer.parseInt( colorDef[3][1] ),
                                           Integer.parseInt( colorDef[3][2] ),
                                           0 );

            Color CellColor5  = new Color( Integer.parseInt( colorDef[4][0] ),
                                           Integer.parseInt( colorDef[4][1] ),
                                           Integer.parseInt( colorDef[4][2] ),
                                           0 );
            // ���v���\���p
            Color backColorB  = new Color( 204, 204, 255 );

            // �\�w�b�_�\���p
            Color backColorT  = new Color(  39,  64, 139 );

            // �h�L�������g��OPEN
            HeaderFooter footer = new HeaderFooter( new Phrase( "- " ) , new Phrase( " -" ) );
            footer.setBorderColor( backColor );
            footer.setAlignment  ( Element.ALIGN_CENTER );
            document.setFooter   ( footer );
            document.setMargins  ( 18, 18, 30, 18 );  // CHG#P-PPE02-020-001
            document.open();

            // �t�H���g�̐ݒ�
            float default_font_size = 9;
            BaseFont bf             = BaseFont.createFont( "HeiseiMin-W3", "UniJIS-UCS2-HW-H", false );
            Font font               = new Font( bf, default_font_size );
            Font font_white         = new Font( bf, default_font_size );
            font_white.setColor( Color.white );
            // INS#P-PPE02-019-004-S
            Font font_red           = new Font( bf, default_font_size );
            font_red.setColor( Color.red );
            // INS#P-PPE02-019-004-E

            // �e�[�u���̕�
            int TableWidthTop = 100;
            int TableWidth    = 100;

            // �J�����̕�
            int[] topBaseWidths = { 25, 75 };
            int[] topLegWidths  = { 50, 50 };
            int[] topExpWidths  = {  3, 20, 10, 10, 22, 10, 15 };

            // �R���e���c�̋L�q
            MyTable table;
            Cell    cell;

            // ���Top����
            // INS#P-PPE02-019-004-S
            Table headTable = new MyTable( 1 );
            headTable.setWidth ( 100 );
            headTable.setBorderColor( backColor );
            cell = new Cell( new Phrase( "�� " + searchCnd, font_red ) );
            cell.setBorder ( 0 );
            headTable.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            headTable.addCell( cell );

            // document�ɔz�u
            document.add( headTable );
            // INS#P-PPE02-019-004-E

            Table baseTable = new MyTable( 2 );
            baseTable.setWidth ( 100 );
            baseTable.setWidths( topBaseWidths );
            baseTable.setBorderColor( backColor );

            // �}��\����
            String range1 = percentDef[1] + "% �` " + percentDef[0] + "% : ";
            String range2 = percentDef[2] + "% �` " + percentDef[1] + "% : ";
            String range3 = percentDef[3] + "% �` " + percentDef[2] + "% : ";
            String range4 = percentDef[4] + "% �` " + percentDef[3] + "% : ";
            String range5 =                "0% �` " + percentDef[4] + "% : ";

            Table legendTable = new MyTable( 2, 6 );
            legendTable.setWidth ( 100 );
            legendTable.setWidths( topLegWidths );
            legendTable.setBorderColor( backColor );

            // �}��
            Cell legCell = new Cell( new Phrase( "<<�}��>>", font ) );
            legCell.setBorderColor( backColor );
            legendTable.setDefaultVerticalAlignment  ( Element.ALIGN_BOTTOM );  // CHG#P-PPE02-020-001
            legendTable.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );  //  �}��͒�����
            legendTable.addCell( legCell , new Point( 0, 0 ) );
            legendTable.setDefaultVerticalAlignment  ( Element.ALIGN_MIDDLE );  // INS#P-PPE02-020-001
            legendTable.setDefaultHorizontalAlignment( Element.ALIGN_RIGHT );   // ����ȊO�͉E��
            // 8%�`10%
            legCell = new Cell( new Phrase( range1, font ) );
            legCell.setBorderColor( backColor );
            legendTable.addCell( legCell, new Point( 1, 0 ) );
            // 6%�`8%
            legCell = new Cell( new Phrase( range2, font ) );
            legCell.setBorderColor( backColor );
            legendTable.addCell( legCell, new Point( 2, 0 ) );
            // 4%�`6%
            legCell = new Cell( new Phrase( range3, font ) );
            legCell.setBorderColor( backColor );
            legendTable.addCell( legCell, new Point( 3, 0 ) );
            // 2%�`4%
            legCell = new Cell( new Phrase( range4, font ) );
            legCell.setBorderColor( backColor );
            legendTable.addCell( legCell, new Point( 4, 0 ) );
            // 0%�`2%
            legCell = new Cell( new Phrase( range5, font ) );
            legCell.setBorderColor( backColor );
            legendTable.addCell( legCell, new Point( 5, 0 ) );

            // �}��̐F��\��
            // 8%�`10%
            legCell = new Cell( new Phrase( "", font ) );
            legCell.setBorderColor( backColor );
            legCell.setBackgroundColor( CellColor1 );
            legendTable.addCell( legCell, new Point( 1, 1 ) );
            // 6%�`8%
            legCell = new Cell( new Phrase( "", font ) );
            legCell.setBorderColor( backColor );
            legCell.setBackgroundColor( CellColor2 );
            legendTable.addCell( legCell, new Point( 2, 1 ) );
            // 4%�`6%
            legCell = new Cell( new Phrase( "", font ) );
            legCell.setBorderColor( backColor );
            legCell.setBackgroundColor( CellColor3 );
            legendTable.addCell( legCell, new Point( 3, 1 ) );
            // 2%�`4%
            legCell = new Cell( new Phrase( "", font ) );
            legCell.setBorderColor( backColor );
            legCell.setBackgroundColor( CellColor4 );
            legendTable.addCell( legCell, new Point( 4, 1 ) );
            // 0%�`2%
            legCell = new Cell( new Phrase( "", font ) );
            legCell.setBorderColor( borderColor );
            legCell.setBackgroundColor( CellColor5 );
            legendTable.addCell( legCell, new Point( 5, 1 ) );


            // �A�i�E���X�\����
            Table expTable = new MyTable( 7, 6 );
            expTable.setWidth ( 90 );
            expTable.setWidths( topExpWidths );
            expTable.setBorderColor( backColor );
            expTable.setPadding( 0 );

            // �A�i�E���X����
            expTable.setDefaultVerticalAlignment  ( Element.ALIGN_MIDDLE );
            expTable.setDefaultHorizontalAlignment( Element.ALIGN_RIGHT );
            Cell expCell = new Cell( new Phrase( "��", font ) );
            expCell.setBorderColor( backColor );
            expTable.addCell( expCell, new Point( 0, 0 ) );
            expTable.addCell( expCell, new Point( 1, 0 ) );
            expCell = new Cell( new Phrase( "", font ) );
            expCell.setBorderColor( backColor );
            expTable.addCell( expCell, new Point( 5, 0 ) );

            expTable.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            expCell = new Cell( new Phrase( annoItem[0], font ) );
            expCell.setColspan( 6 );
            expCell.setBorderColor( backColor );
            expTable.addCell( expCell, new Point( 0, 1 ) );
            expCell = new Cell( new Phrase( annoItem[1], font ) );
            expCell.setColspan( 6 );
            expCell.setBorderColor( backColor );
            expTable.addCell( expCell, new Point( 1, 1 ) );
            expCell = new Cell( new Phrase( annoItem[2], font ) );  // CHG#P-PPE02-019-004 //CHG#BPX-0301J-1087
            expCell.setColspan( 6 );
            expCell.setBorderColor( backColor );
            expTable.addCell( expCell, new Point( 5, 1 ) );

            // �W�v���ʕ\��
            // ����(�E��)
            expTable.setDefaultHorizontalAlignment( Element.ALIGN_RIGHT );
            expCell = new Cell( new Phrase( "�W�v���� : ", font ) );
            expCell.setColspan( 2 );
            expCell.setBorderColor( backColorB );
            expCell.setBackgroundColor( backColorB );
            expTable.addCell( expCell, new Point( 3, 0 ) );
            expCell = new Cell( new Phrase( "�M" + paraItem[3] + "�l���v : ", font ) );
            expCell.setBorderColor( backColorB );
            expCell.setBackgroundColor( backColorB );
            expTable.addCell( expCell, new Point( 3, 4 ) );
            // ����(����)
            expTable.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            //CHG#BPX-0301J-1121 -S
            expCell = new Cell( new Phrase( "��", font ) );
            expCell.setBorderColor( backColorB );
            expCell.setBackgroundColor( backColorB );
            expTable.addCell( expCell, new Point( 3, 3 ) );
            expCell = new Cell( new Phrase( "��", font ) );
            expCell.setBorderColor( backColorB );
            expCell.setBackgroundColor( backColorB );
            expTable.addCell( expCell, new Point( 3, 6 ) );
            //CHG#BPX-0301J-1121 -E
            // ��s
            expCell = new Cell( new Phrase( "" , font ) );
            expCell.setColspan( 7 );
            expCell.setBorderColor( backColorB );
            expCell.setBackgroundColor( backColorB );
            expTable.addCell( expCell, new Point( 2, 0 ) );
            expTable.addCell( expCell, new Point( 4, 0 ) );

            // �W�v�l
            // �Y���l��
            expTable.setDefaultHorizontalAlignment( Element.ALIGN_RIGHT );
            expCell = new Cell( new Phrase( matchTotal, font ) );
            expCell.setBorderColor( borderColor );
            expTable.addCell( expCell, new Point( 3, 2 ) );
            // �����l�����v
            expCell = new Cell( new Phrase( memberCnt, font ) );
            expCell.setBorderColor( borderColor );
            expTable.addCell( expCell, new Point( 3, 5 ) );

            Cell nestCell1 = new Cell( "" );
            Cell nestCell2 = new Cell( "" );
            nestCell1.add( legendTable );
            nestCell2.add( expTable    );

            baseTable.addCell( nestCell1, new Point( 0, 0 ) );
            baseTable.addCell( nestCell2, new Point( 0, 1 ) );

            // document�ɔz�u
            document.add( baseTable );


            // �W�v���\��
            int   levelNum   = level_list.length / senmon_list.length;
            int[] sumWidths  = new int[levelNum + 2];
            int   levelWidth = 38 / levelNum;

            sumWidths[0] = 17;
            sumWidths[1] = 45;
            for ( int i = 0 ; i < levelNum ; i++ ) {
                sumWidths[2+i] = levelWidth;
            }

            // �w�b�_��
            Table sumTable  = new MyTable( levelNum + 2 );
            sumTable.setWidth( 100 );
            sumTable.setWidths( sumWidths );
            sumTable.setDefaultVerticalAlignment  ( Element.ALIGN_MIDDLE );
            sumTable.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
            // �E��Header
            Cell hedCell = new Cell( new Phrase( paraItem[0], font_white ) );
            hedCell.setRowspan( 2 );
            hedCell.setBackgroundColor( backColorT );
            sumTable.addCell( hedCell );
            // ��啪��Header
            hedCell = new Cell( new Phrase( paraItem[1], font_white ) );
            hedCell.setRowspan( 2 );
            hedCell.setBackgroundColor( backColorT );
            sumTable.addCell( hedCell );
            // ���x��Header
            hedCell = new Cell( new Phrase( paraItem[2], font_white ) );
            hedCell.setColspan( levelNum );
            hedCell.setBackgroundColor( backColorT );
            sumTable.addCell( hedCell );
            for ( int i = 0 ; i < levelNum ; i++ ) {
                hedCell = new Cell( new Phrase( level_list[i][3], font_white ) );
                hedCell.setBackgroundColor( backColorT );
                sumTable.addCell( hedCell );
            }
            // document�ɒǉ�
            sumTable.endHeaders();

            // �{��
            font.setColor( Color.black );

            for ( int i = 0 ; i < syoku_list.length ; i++ ) {
                sumTable.setDefaultVerticalAlignment  ( Element.ALIGN_MIDDLE );
                sumTable.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );

                // �E��ɑ΂����啪��̐�
                int senmon_cnt = 0;
                boolean flg = true;
                for ( int ind = 0 ; ind < senmon_list.length ; ind++ ) {
                    if ( senmon_list[ind][0].equals( syoku_list[i][0] ) ) {
                        senmon_cnt++;
                    }
                }

                // �E��
                Cell syokuCell = new Cell( new Phrase( syoku_list[i][1], font ) );
                if ( senmon_cnt > 1 ) {
                    syokuCell.setRowspan( senmon_cnt );
                }
                sumTable.addCell( syokuCell );

                for ( int j = 0 ; j < senmon_list.length ; j++ ) {
                    // ��啪��
                    if ( senmon_list[j][0].equals( syoku_list[i][0] ) ) {
                        Cell senmonCell = new Cell( new Phrase( senmon_list[j][2], font ) );
                        sumTable.addCell( senmonCell );

                            for ( int k = 0 ; k < levelNum ; k++ ) {
                            // ���x��
                            Cell levelCell = new Cell( new Phrase( level_list[ levelNum * j + k ][4], font ) );
                            if ( level_list[ levelNum * j + k ][5].equals( "1" ) ) {
                                levelCell = new Cell( new Phrase( level_list[ levelNum * j + k ][4], font_white ) );  // INS#P-PPE02-019-004
                                levelCell.setBackgroundColor( CellColor1 );
                            } else if ( level_list[ levelNum * j + k ][5].equals( "2" ) ) {
                                levelCell.setBackgroundColor( CellColor2 );
                            } else if ( level_list[ levelNum * j + k ][5].equals( "3" ) ) {
                                levelCell.setBackgroundColor( CellColor3 );
                            } else if ( level_list[ levelNum * j + k ][5].equals( "4" ) ) {
                                levelCell.setBackgroundColor( CellColor4 );
                            } else if ( level_list[ levelNum * j + k ][5].equals( "5" ) ) {
                                levelCell.setBackgroundColor( CellColor5 );
                            } else {
                                levelCell.setBackgroundColor( backColor );
                            }
                            sumTable.addCell( levelCell );
                        }
                    }
                }
            }
            // document�ɔz�u
            document.add( sumTable );

            // INS#P-PPE02-019-004-S
            Table footTable = new MyTable( 3 );
            footTable.setWidth ( 100 );
            int[] footWidths = { 80, 5, 15 };
            footTable.setWidths( footWidths );
            footTable.setBorderColor( backColor );
            footTable.setSpaceBetweenCells( 1 );
            cell = new Cell( new Phrase( "", font ) );
            cell.setBorder( 0 );
            footTable.addCell( cell );
            cell = new Cell( new Phrase( "����", font ) );
            cell.setBorderColor( borderColor );
            footTable.setDefaultHorizontalAlignment( Element.ALIGN_CENTER );
            footTable.addCell( cell );
            cell = new Cell( new Phrase( " : �Y�����x������", font ) );  // CHG#P-PPE02-020-001
            cell.setBorder( 0 );
            footTable.setDefaultHorizontalAlignment( Element.ALIGN_LEFT );
            footTable.addCell( cell );

            // document�ɔz�u
            document.add( footTable );

            // INS#P-PPE02-019-004-E

            Log.method( login_no, "OUT", "" );

        } catch ( BadElementException e ) {
            Log.error( login_no, "", e );
            throw ( Exception )e;
        } catch ( DocumentException e ) {
            Log.error( login_no, "", e );
            throw ( Exception)e;
        } catch ( IOException e ) {
            Log.error( login_no, "", e );
            throw ( Exception )e;
        } catch ( Exception e ) {
            Log.error( login_no, "", e );
            throw e;
        } finally {
            // �h�L�������g�����
            if (document != null) {
                try {
                    document.close();
                } catch ( Exception e ) {
                    Log.error( login_no, "", e );
                    throw e;
                }
            }
            if ( pw != null ) {
                try {
                    pw.close();
                } catch ( Exception e ) {
                    Log.error( login_no, "", e );
                    throw e;
                }
            }
        }
    }
}
