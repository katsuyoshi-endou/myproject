/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   �l�ސ헪�V�X�e���i���V�e�ACareer�v��n�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O�@�@�@�@�@���e
 *   2004/04/01  01.00       �n�� ��q    �V�K�쐬
 *   2004/08/26              �֓� ����    SAS���ДN���\���Ή�
 *   2004/09/27              �n�� ��q    �g�D�R�[�h��Trim�Ή�      <B-AJH02-001>
 *   2005/11/08              QUANLA        sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 *   2005/11/19  02.02-B     �Β� �[�@�@�@�����[���T�[�x�C���ڐ��g���i25��50�j�Ή�
 */

package jp.co.hisas.career.plan.search.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.property.*;
import jp.co.hisas.career.plan.careerchallenge.bean.*;
import jp.co.hisas.career.plan.search.bean.*;
import jp.co.hisas.career.base.userinfo.bean.*;
import jp.co.hisas.career.base.sosiki.bean.*;


/**
 * <PRE>
 * �T�v:
 *   �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B
 *
 * �g�p���@:
 *   JSP����Ăяo���B
 * </PRE>
 */
public class PBE050_SearchMoralServlet extends HttpServlet {

    /** ServletContext�I�u�W�F�N�g */
    private ServletContext ctx = null;

    /** ���O�C��No */
    private String login_no = null;


    /**
     * ServletContext�I�u�W�F�N�g���擾����B
     *
     * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
     */
    public void init(ServletConfig config) {
        synchronized(this) {
            if(ctx == null) {
                ctx = config.getServletContext();
            }
        }
    }

    /**
     * �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B
     *
     * @param      request           �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
     * @param      response          Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
     * @exception IOException       ���o�͊֘A�����Ŕ��������O
     * @exception ServletException  Servlet�̐���ȏ������W����ꂽ���ɔ��������O
     */
    public void service(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException{
            try {
    
                HttpSession session = request.getSession(false);

                if ( session == null ) {
                    //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                    ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
                } else {
                    UserInfoBean bean   = (UserInfoBean)session.getAttribute("userinfo");
    
                    login_no = bean.getLogin_no();
    
                    Log.method( login_no, "IN", "" );
                    Log.performance( login_no, true, "" );
    
                    // ����ChallengeBean�Ăяo��
                    PBB_ChallengeBean challengebean = (PBB_ChallengeBean)session.getAttribute("challenge");
    
                    if( challengebean == null) {
                        challengebean = new PBB_ChallengeBean( login_no );
                        session.setAttribute("challenge", challengebean);
                    }
    
                    /* �����[���T�[�x�C�}�X�^�R�[�h���擾 */
                    challengebean.SearchMoralCode();
                    String[][] moralcode;
                    moralcode         = challengebean.getMoralCodeData();
                    int moralCount    = moralcode.length;
    
    
                    // ����SearchBean�Ăяo��
                    PBE_SearchMoralBean searchmoralbean = (PBE_SearchMoralBean)session.getAttribute("searchmoral");
    
                    if( searchmoralbean == null) {
                        searchmoralbean = new PBE_SearchMoralBean( login_no );
                        session.setAttribute( "searchmoral" , searchmoralbean );
                    }
    
                    String engName    = (String)ReadFile.fileMapData.get( HcdbDef.searchParam1 );
                    String yakuMaster = (String)ReadFile.fileMapData.get( HcdbDef.yakusyoku_master );
                    String busyoPos   = (String)ReadFile.fileMapData.get( HcdbDef.busyo_code );
                    String idoKibou   = (String)request.getParameter("C004_IdoKibou");
    
                    if ( idoKibou == null ) {
                        idoKibou = "0";
                    } else {
                        idoKibou = "1"; 
                    }
    
                    /* ���������w���ʂőI�������������擾 */
                    String nendo      = PZZ010_CharacterUtil.strEncode((String)request.getParameter("S001_Kikan"));
                    String ki         = (String)request.getParameter("S002_Ki");
                    String simeino    = PZZ010_CharacterUtil.strEncode((String)request.getParameter("T001_SimeiNo"));
                    String simeikanji = PZZ010_CharacterUtil.strEncode((String)request.getParameter("T002_SimeiKanji"));
                    String simeikana  = PZZ010_CharacterUtil.strEncode((String)request.getParameter("T003_SimeiKana"));
                    String simeieiji  = "";
                    String buryakusyo = (String)request.getParameter("S012_Busyo").trim();  // CHG#P-AJH02-001-002
    
                    if ( engName.equals( "1" ) ) {
                        /* ���������w���ʂœ��͂��������p�����擾���� */
                        simeieiji = PZZ010_CharacterUtil.strEncode((String)request.getParameter("T014_SimeiEiji"));
                    }

                    // INS#P-PPH00-005-011-S
                    if ( !buryakusyo.equals( "" ) ) {
                        busyoPos = SosikiBean.getSosikiByCode( buryakusyo , login_no )[4];
                    }
                    // INS#P-PPH00-005-011-E

                    /* �������T�[�x�C�f�[�^���擾 */
                    String[][] moraldata;
                    String[] searchcnd = {
                        engName,            yakuMaster,
                        busyoPos,           idoKibou,
                        nendo,                ki,
                        PZZ010_CharacterUtil.changeQuotation( simeino ),
                        PZZ010_CharacterUtil.changeQuotation( simeikanji ),
                        PZZ010_CharacterUtil.changeQuotation( simeikana ),
                        PZZ010_CharacterUtil.changeQuotation( simeieiji ),
                        buryakusyo
                    };
                    searchmoralbean.search_moral_list( searchcnd );
                    moraldata = searchmoralbean.getMoralList();
    
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    
                    /* �ݖ���e�o�� */
                    String setumon  = "";
                    byte[] add;
                    for ( int i = 0; i < moralCount ; i++ ) {
                        setumon = "�ݖ�" + ( i + 1 ) +  "," + moralcode[i][1] + "\n";
                        add = setumon.getBytes();
                        baos.write( add );
                    }
                    /* �w�b�_���o�� */
                    String labelItem1  = (String)ReadFile.paramMapData.get("DZZ002");
                    String labelItem2  = (String)ReadFile.paramMapData.get("DZZ003");
                    String labelItem3  = (String)ReadFile.paramMapData.get("DZZ004");
                    String labelItem4  = (String)ReadFile.paramMapData.get("DZZ005");
                    String labelItem5  = (String)ReadFile.paramMapData.get("DZZ014");
                    String labelItem6  = (String)ReadFile.paramMapData.get("DZZ017");
                    String labelItem7  = (String)ReadFile.paramMapData.get("DZZ118");
                    String labelItem8  = (String)ReadFile.paramMapData.get("DZZ119");
                    String labelItem9  = (String)ReadFile.paramMapData.get("DZZ144");
                    String labelItem10 = (String)ReadFile.paramMapData.get("DZZ145");
    
                    String header = "";
    
                    header = "\n"
                           + labelItem1 + ","
                           + labelItem2 + ","
                           + labelItem3 + ",";
                    if ( engName.equals( "1" ) ){
                        header = header
                               + labelItem4 + ",";
                    }
                    header = header
                           + labelItem9  + ","
                           + labelItem5  + ","
                           + labelItem6  + ","
                           + "�N��,"
                           + labelItem10 + ","
                           + "���Ԗ�,";
    
                    for ( int i = 0 ; i < moralcode.length ; i++ ) {
                        header = header
                               + "�ݖ�" + ( i + 1 ) + ",";
                    }
                    header = header
                           + labelItem8;
                    if ( idoKibou.equals( "1" ) ) {
                        header = header
                               + "," + labelItem7;
                    }
    
                    header = header + "\n";
                    add = header.getBytes();
                    baos.write( add );
    
                    /* �f�[�^���o�� */
                    // �ݖ�ɑ΂���񓚂��O�̔z��i�[���ڐ�
                    int index  = 9;
                    int indadd = 0;
                    if ( engName.equals( "1" ) ) {
                        index += 1;
                        indadd = 1;
                    }
    
                    for ( int i = 0 ; i < moraldata.length ; i++ ) {
                        String data = "";
                        data = moraldata[i][0] + ",";
                        data = data + moraldata[i][1].substring(1) + ",";
                        data = data + moraldata[i][2].substring(1) + ",";
                        if ( engName.equals( "1" ) ) {
                            data = data + moraldata[i][3].substring(1) + ",";
                        }
                        data = data + moraldata[i][3+indadd] + ",";
                        data = data + SosikiBean.getSosikiByCode( moraldata[i][3+indadd].trim() , login_no )[2] + ",";
                        if ( yakuMaster.equals( "0" ) ) {
                            data = data + moraldata[i][4+indadd].substring(1) + ",";
                        } else {
                            data = data + moraldata[i][4+indadd] + ",";
                        }
                        int age = ( ( Integer.parseInt( PZZ010_CharacterUtil.GetDay() ) 
                                     - Integer.parseInt ( moraldata[i][5 + indadd].substring(1) ) ) / 10000 );
                        data = data + Integer.toString( age ) + ",";
                        data = data + moraldata[i][6+indadd].substring(1, 7) + ",";  // CHG#P-PPT00-038-001, CHG#P-PJH01-004-003
                        data = data + moraldata[i][7+indadd] + ",";
//20050824 ���H���G�F�@���Ԗ��ɏC��
    
                        int j;
                        for ( j = index ; j < index + moralCount ; j++ ) {
                        	//INS#BPX-0301J-0470 -S
                        	//�o�͍��ڐ���25�𒴂����ꍇ
                        	if (j - index >= 25) {
                        		break;
                        	}
                        	//INS#BPX-0301J-0470 -E
                            data = data + moraldata[i][j] + ",";
                        }
    
                        // �ǋL����
                        j    = HcdbDef.tuiki_pos + indadd;

                        //INS#BPX-0301J-0470 -S
                        //���ړ��e26�`50�o�͂̃��[�v
	                    for (int n = j + 1; n < index + moralCount + 1 ; n++) {
	                        data = data + "\"" + moraldata[i][n] + "\"" + ",";
	                    }
                        //INS#BPX-0301J-0470 -E

                        data = data + "\"" + moraldata[i][j] + "\"";
                        // �ٓ��Ɋւ����]
                        if ( idoKibou.equals( "1" ) ) {
                            data = data + ","
                                 + "\"" + moraldata[i][61] + "\""; //CHG#B-A22BT3-001
                        }
                        data = data + "\n";
                        add  = data.getBytes();
                        baos.write( add );
                    }
                    baos.close();
    
                    ByteArrayInputStream bais = new ByteArrayInputStream( baos.toByteArray() );
                    String curTime  = PZZ010_CharacterUtil.GetDay() + PZZ010_CharacterUtil.GetTime();
                    String csv_name = login_no + curTime + "_MoralSurveyList.csv";
                    request.setAttribute( "STREAM", bais );
                    request.setAttribute( "H080_FileName", csv_name );
    
                    RequestDispatcher rd = ctx.getRequestDispatcher( "/servlet/PYE010_FileDownloadServlet" );
                    rd.forward(request, response);
    
                }
                Log.performance( login_no, false, "");
                Log.method(login_no,"OUT","");
    
            } catch ( UnsupportedEncodingException e ){
                Log.error( login_no , "HJE-0007" , e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( IllegalStateException e ){
                Log.error( login_no , "HJE-0010" , e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( IndexOutOfBoundsException e ){
                Log.error( login_no , "HJE-0011" , e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( IOException e ){
                Log.error( login_no , "HJE-0012" , e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            } catch ( Exception e) {
                Log.error( login_no , "HJE-0017" , e );
                //response.sendRedirect("/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp");	//2005/11/08_LYCE_R_QUANLA
                ctx.getRequestDispatcher( "/view/base/error/VYY_Error.jsp" ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
            }
        }
}

