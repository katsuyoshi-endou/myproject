/*
 * All Rights Reserved, Copyright (C) 2004,Hitachi System & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�Г�����@�\�j
 *
 * ���l�@�F
 *
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/24  01.00      ���� ��         �V�K�쐬
 *
 */

package jp.co.hisas.career.department.offer.bean;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaAssessBean;

/**
 *<PRE>
 *
 * �N���X��:
 *   PEB_KouboKibouAssessmentBean �N���X
 *
 * �@�\����:
 *   �Г�����Č��̐E��f�[�^�A�]�������B���x��ێ�����B
 *
 *</PRE>
 */
public class PEB_KouboAssessmentRirekiBean extends PEY_KouboOubosyaAssessBean implements Serializable{

	private String KouboAnkenId	= null;
	private int seqNo 			= 0;
	private String syokuName		= null;
	private String senmonName		= null;
	private String levelName		= null;
	private String levelCode		= null;
	private int jikosougou		= 0;
	private int hyokasyasougou	= 0;

	
	public PEB_KouboAssessmentRirekiBean(ResultSet rs) throws SQLException {

		setSyokucode(rs.getString( getIdentifier(  ) +"SYOKU_CODE" ));
		setSenmoncode(rs.getString( getIdentifier(  ) +"SENMON_CODE" ));
		setLevelcode(rs.getString( getIdentifier(  ) +"LEVEL_CODE" ));
		setSyokuName(rs.getString( getIdentifier(  ) +"SYOKU_NAME" ));
		setSenmonName(rs.getString( getIdentifier(  ) +"SENMON_NAME" ));
		setLevelName(rs.getString( getIdentifier(  ) +"LEVEL_NAME" ));
	}
	
	/**
	 * @return
	 */
	public String getKouboAnkenId() {
		return KouboAnkenId;
	}

	/**
	 * @return
	 */
	public String getLevelCode() {
		return levelCode;
	}

	/**
	 * @return
	 */
	public String getSenmonName() {
		return senmonName;
	}

	/**
	 * @return
	 */
	public int getSeqNo() {
		return seqNo;
	}

	/**
	 * @return
	 */
	public String getSyokuName() {
		return syokuName;
	}

	/**
	 * @param string
	 */
	public void setKouboAnkenId(String string) {
		KouboAnkenId = string;
	}

	/**
	 * @param string
	 */
	public void setLevelCode(String string) {
		levelCode = string;
	}

	/**
	 * @param string
	 */
	public void setSenmonName(String string) {
		senmonName = string;
	}

	/**
	 * @param i
	 */
	public void setSeqNo(int i) {
		seqNo = i;
	}

	/**
	 * @param string
	 */
	public void setSyokuName(String string) {
		syokuName = string;
	}

	/**
	 * @return
	 */
	public int getHyokasyasougou() {
		return hyokasyasougou;
	}

	/**
	 * @return
	 */
	public int getJikosougou() {
		return jikosougou;
	}

	/**
	 * @param i
	 */
	public void setHyokasyasougou(int i) {
		hyokasyasougou = i;
	}

	/**
	 * @param i
	 */
	public void setJikosougou(int i) {
		jikosougou = i;
	}


    /**
     * @return
     */
    public String getLevelName() {
        return levelName;
    }

    /**
     * @param string
     */
    public void setLevelName(String string) {
        levelName = string;
    }

}
