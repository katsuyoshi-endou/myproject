/*
* All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
*
* �v���W�F�N�g���@�F
*   ���V�e�ACareer�i�Г�����@�\�j
*
* ���l�@�F
*   �Ȃ�
*
* �����@�F
*   ���t        �o�[�W����  ���O         ���e
*   2004/08/12  01.00       �c���@�N�W    �V�K�쐬
*/
package jp.co.hisas.career.department.base.ejb;

import jp.co.hisas.career.department.base.PEY_ServiceLocator;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

import java.rmi.RemoteException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import javax.naming.NamingException;


/**
 *<PRE>
 *
 * �N���X���F
 *   PEY_KouboOubosyaEJBBean �N���X
 *
 * �@�\�����F
 *   ������e�[�u���ւ̑�����s���܂��B
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PEY_KouboOubosyaEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PEY_KouboOubosyaEJBBean implements SessionBean {
    private SessionContext context = null;

    /**
     * ������e�[�u������f�[�^�擾���Ԃ��܂��B
     *
     * @param osiraseBean ��������
     * @param loginuser ���O�C�����[�U
     * @param moreconditions IN�匟������
     * @return PEY_KouboOubosyaBean[] �擾����
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PEY_KouboOubosyaBean[] doSelect( PEY_KouboOubosyaBean osiraseBean,
        PEY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;
        Vector appendvalue   = new Vector(  );

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // ���������̍쐬
            Map conditions = osiraseBean.extractConditions(  );

            PEY_KouboOubosyaBean[] kouboOubosyaBeans = null;
            StringBuffer sql                         = new StringBuffer(  );

            sql.append( "SELECT * " );
            sql.append( " FROM " + HcdbDef.D03_TBL );

            StringBuffer where = new StringBuffer(  );

            for ( Iterator ite = conditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                Object column = ite.next(  );
                where.append( " AND " + column + "=?" );
            }

            sql.append( where.toString(  ).replaceFirst( "AND", "WHERE" ) );

            // �\�[�g�����t���i�g�D�R�[�h�A�Ј��ԍ��j
            sql.append( " ORDER BY SOSIKI_CODE,SIMEI_NO" );

            // �f�o�b�O�̏o��
            Log.debug( sql.toString(  ) );

            // �R�l�N�V�����擾
            PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );

            // �������s
            ps = con.prepareStatement( sql.toString(  ) );

            List kouboOubosyaBeanList = new ArrayList(  );

            int count = 1;

            for ( Iterator ite = conditions.keySet(  ).iterator(  ); ite.hasNext(  ); count++ ) {
                Object key = ite.next(  );
                Log.debug( Integer.toString( count ) + ":" + key + ":" + conditions.get( key ) );
                ps.setObject( count, conditions.get( key ) );
            }

            ResultSet rs = ps.executeQuery(  );

            while ( rs.next(  ) ) {
                kouboOubosyaBeanList.add( new PEY_KouboOubosyaBean( rs, null ) );
            }

            rs.close(  );
            ps.clearParameters(  );
            kouboOubosyaBeans = new PEY_KouboOubosyaBean[kouboOubosyaBeanList.size(  )];
            kouboOubosyaBeanList.toArray( kouboOubosyaBeans );

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return kouboOubosyaBeans;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }
}
