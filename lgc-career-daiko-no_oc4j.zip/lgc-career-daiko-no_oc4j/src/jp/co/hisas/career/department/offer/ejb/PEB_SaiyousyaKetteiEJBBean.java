/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�Г�����@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/26  01.00       �����@��F   �V�K�쐬
 */
package jp.co.hisas.career.department.offer.ejb;

import java.rmi.*;
import java.sql.*;
import javax.ejb.*;
import javax.naming.*;

import jp.co.hisas.career.department.base.PEY_ServiceLocator;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;


/**
 *<PRE>
 *
 * �N���X���F
 *   PEB_SaiyousyaKetteiEJBBean�N���X
 *
 * �@�\�����F
 *   (�l��)�{�l�ʒm���c�a�Ɋi�[����@�\�ł��B
 *   �i�[����f�[�^�͍��ۃX�e�[�^�X
 *
 *</PRE>
 * @ejb.bean
 *   name="PEB_SaiyousyaKetteiEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PEB_SaiyousyaKetteiEJBBean implements SessionBean {
	 private SessionContext context = null;

	/**
	 * SAIYO_STATUS�ɑΉ����郌�R�[�h�̍X�V���s���܂��B
	 * @param koubooubosyaBean
	 * @param loginuser
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 *	 */
	public int doUpdate( PEY_KouboOubosyaBean koubooubosyaBean, PEY_PersonalBean loginuser )
		throws PEY_WarningException, RemoteException, NamingException, CreateException {
				Connection con		= null;
				PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );
			// SQL�쐬
			StringBuffer sql = new StringBuffer(  );
			sql.append( "UPDATE " );
			sql.append( HcdbDef.D03_TBL );
			sql.append( " SET " );
			sql.append( "SAIYO_STATUS ='" );
			sql.append( koubooubosyaBean.getSaiyostatus().trim() );
			sql.append( "',");
			sql.append( " KOUSINBI ='" );
			sql.append( PZZ010_CharacterUtil.GetDay());
			sql.append( "',");
			sql.append( " KOUSINJIKOKU ='" );
			sql.append( PZZ010_CharacterUtil.GetTime());
			sql.append( "',");
			sql.append( " KOUSINSYA ='" );
			sql.append( loginuser.getSimeiNo(  ));
			sql.append( "'");
			sql.append( " WHERE KOUBO_ANKEN_ID ='");
			sql.append( koubooubosyaBean.getKouboankenid());
			sql.append("' AND SIMEI_NO ='");
			sql.append( koubooubosyaBean.getSimeino());
			sql.append("' AND KOUSINBI ='");
			sql.append( koubooubosyaBean.getKousinbi());
			sql.append("' AND KOUSINJIKOKU ='");
			sql.append( koubooubosyaBean.getKousinjikoku());
			sql.append("'");
			

			// �R�l�N�V�����擾
			PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance();
			con = locator.getDataSource().getConnection();

			//�f�o�b�O���O���o��
			Log.debug(sql.toString());

			// �X�V���s
			ps = con.prepareStatement(sql.toString());
			int count = ps.executeUpdate();					
			// ���\�b�h�g���[�X�o��
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );
			
			if ( count != 1 ) {
			context.setRollbackOnly(  );
			throw new PEY_WarningException();
			}					
			return count;

		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext( SessionContext context )
		throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 *
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate(  ) throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove(  ) throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate(  ) throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate(  ) throws EJBException, RemoteException {
	}
}
