/*
 * All Rights Reserved, Copyright (C) 2004,Hitachi System & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�Г�����@�\�j
 *
 * ���l�@�F
 *
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/11  01.00       �y��         �V�K�쐬
 *
 */

package jp.co.hisas.career.department.offer.bean;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *<PRE>
 *
 * �N���X��:
 *   PEB_KouboKibouSyokusyuBean �N���X
 *
 * �@�\����:
 *   �Г�����Č�PDF�o�͗p��]�E��f�[�^��ێ�����B
 *
 *</PRE>
 */
public class PEB_KouboKibouSyokusyuBean implements Serializable{
	private String KouboAnkenId = null;
	private int seqNo = 0;
	private String syokuName = null;
	private String senmonName = null;
	private String levelCode = null;
	private String syokuCode = null;
	private String senmonCode = null;
	private String kousinbi = null;
	private String kousinjikoku = null;
	
	
	/**
	 * 
	 */
	public PEB_KouboKibouSyokusyuBean() {

	}

	public PEB_KouboKibouSyokusyuBean(ResultSet rs) throws SQLException {
		parseKibouSyokusyuResultSet(rs);
	}
	
	/**
	 * @return
	 */
	public String getKouboAnkenId() {
		return KouboAnkenId;
	}

	/**
	 * @return
	 */
	public String getLevelCode() {
		return levelCode;
	}

	/**
	 * @return
	 */
	public String getSenmonName() {
		return senmonName;
	}

	/**
	 * @return
	 */
	public int getSeqNo() {
		return seqNo;
	}

	/**
	 * @return
	 */
	public String getSyokuName() {
		return syokuName;
	}

	/**
	 * @param string
	 */
	public void setKouboAnkenId(String string) {
		KouboAnkenId = string;
	}

	/**
	 * @param string
	 */
	public void setLevelCode(String string) {
		levelCode = string;
	}

	/**
	 * @param string
	 */
	public void setSenmonName(String string) {
		senmonName = string;
	}

	/**
	 * @param i
	 */
	public void setSeqNo(int i) {
		seqNo = i;
	}

	/**
	 * @param string
	 */
	public void setSyokuName(String string) {
		syokuName = string;
	}
	
	/**
	 * �����]�E��₢���킹���ʂ�Bean�ɐݒ肷��B
	 * @param rs �����]�E��₢���킹���ʁB
	 * @return �����]�E���Bean�B
	 */
	public void parseKibouSyokusyuResultSet(ResultSet rs) throws SQLException{
		setKouboAnkenId(rs.getString("KOUBO_ANKEN_ID"));	
		setSeqNo(rs.getInt("SEQ_NO"));	
		setSyokuName(rs.getString("SYOKU_NAME"));	
		setSenmonName(rs.getString("SENMON_NAME"));
		setLevelCode(rs.getString("LEVEL_CODE"));
		setSenmonCode(rs.getString("SENMON_CODE"));
		setSyokuCode(rs.getString("SYOKU_CODE"));
		setKousinbi(rs.getString("KOUSINBI"));
		setKousinjikoku(rs.getString("KOUSINJIKOKU"));
	}

	/**
	 * @return
	 */
	public String getSenmonCode() {
		return senmonCode;
	}

	/**
	 * @return
	 */
	public String getSyokuCode() {
		return syokuCode;
	}

	/**
	 * @param string
	 */
	public void setSenmonCode(String string) {
		senmonCode = string;
	}

	/**
	 * @param string
	 */
	public void setSyokuCode(String string) {
		syokuCode = string;
	}

	/**
	 * @return
	 */
	public String getKousinbi() {
		return kousinbi;
	}

	/**
	 * @return
	 */
	public String getKousinjikoku() {
		return kousinjikoku;
	}

	/**
	 * @param string
	 */
	public void setKousinbi(String string) {
		kousinbi = string;
	}

	/**
	 * @param string
	 */
	public void setKousinjikoku(String string) {
		kousinjikoku = string;
	}

}
