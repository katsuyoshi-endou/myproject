/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�Г�����@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/10  01.00      �@�c��     �V�K�쐬
 *   2004/10/11  01.01        �ѓ��@�@ �Г�T01�e�[�u���̃����e�i���X�����X�V�p��doUpdateMainte���\�b�h��ǉ��B
 *   2005/11/09  01.02        THANHLVT Change MAINTE_FLG_10 to MAINTE_FLG_YOBI1 in doUpdateMainte method
 */
package jp.co.hisas.career.department.base.ejb;

import jp.co.hisas.career.department.base.*;
import jp.co.hisas.career.department.base.valuebean.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.rmi.*;

import java.sql.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PEY_PersonalEJBBean�N���X
 *
 * �@�\�����F
 *   �p�[�\�i���v���t�@�C�����烆�[�U�̑������擾���܂��B
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PEY_PersonalEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PEY_PersonalEJBBean implements SessionBean {
    private SessionContext context = null;

    /**
     * �p�[�\�i���v���t�@�C�����烆�[�U�����擾���APEY_PersonalBean �Ɋi�[���ĕԂ��܂��B
     *
     * @param userId ����NO
     * @param loginuser ���O�C�����[�U���
     *
     * @return ���[�U���
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PEY_PersonalBean getPersonalInfo( String userId, PEY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );
            ps      = con.prepareStatement( "SELECT * FROM " + HcdbDef.personalTbl
                    + " WHERE SIMEI_NO=? and HONMU_FLG='" + HcdbDef.HONMU + "' " );

            userId = PZZ010_CharacterUtil.changeSimeiNoLength( userId );

            ps.setString( 1, userId );

            ResultSet rs              = ps.executeQuery(  );
            PEY_PersonalBean personal = null;

            while ( rs.next(  ) ) {
                personal = new PEY_PersonalBean( rs, null );
            }

            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return personal;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �p�[�\�i���v���t�@�C�����烆�[�U�����擾���APEY_PersonalBean �Ɋi�[���ĕԂ��܂��B
     *
     * @param userId ����NO
     * @param loginuser ���O�C�����[�U���
     *
     * @return ���[�U���
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PEY_PersonalBean[] getPersonalInfo( String[] userId, PEY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            PEY_PersonalBean[] personalBeans = null;

            if ( ( userId != null ) && ( userId.length != 0 ) ) {
                PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
                con = locator.getDataSource(  ).getConnection(  );

                StringBuffer sql = new StringBuffer( "SELECT * FROM " + HcdbDef.personalTbl );
                sql.append( " WHERE SIMEI_NO=?  AND HONMU_FLG='" + HcdbDef.HONMU + "' " );

                /* �f�o�b�O���O�̏o�� */
                Log.debug( sql.toString(  ) );

                ps = con.prepareStatement( sql.toString(  ) );

                List personalBeanList = new ArrayList(  );

                for ( int i = 0; i < userId.length; i++ ) {
                    ps.setString( 1, PZZ010_CharacterUtil.changeSimeiNoLength( userId[i] ) );

                    ResultSet rs = ps.executeQuery(  );

                    while ( rs.next(  ) ) {
                        personalBeanList.add( new PEY_PersonalBean( rs, null ) );
                    }

                    rs.close(  );
                    ps.clearParameters(  );
                }

                personalBeans = new PEY_PersonalBean[personalBeanList.size(  )];
                personalBeanList.toArray( personalBeans );
            } else {
                personalBeans = new PEY_PersonalBean[0];
            }

            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return personalBeans;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �p�[�\�i���v���t�@�C������S�Ẵ��[�U�����擾���APEY_PersonalBean �Ɋi�[���ĕԂ��܂��B
     *
     * @param userId ����NO
     * @param loginuser ���O�C�����[�U���
     *
     * @return ���[�U���
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PEY_PersonalBean getAllPersonalInfo( String userId, PEY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );
            ps      = con.prepareStatement( "SELECT * FROM " + HcdbDef.personalTbl
                    + " WHERE SIMEI_NO=? and HONMU_FLG='" + HcdbDef.HONMU + "' " );

            userId = PZZ010_CharacterUtil.changeSimeiNoLength( userId );

            ps.setString( 1, userId );

            ResultSet rs              = ps.executeQuery(  );
            PEY_PersonalBean personal = null;

            while ( rs.next(  ) ) {
                personal     = new PEY_PersonalBean( rs, null );
                personal     = new PEY_PersonalBean(  );
                personal.setAllData( rs, null );
            }

            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return personal;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-XXXX", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �����������L�[�Ƃ��ăp�[�\�i���v���t�@�C������ꗗ���擾���܂��B
     * �߂�l�͌��������Ƀq�b�g�����p�[�\�i���v���t�@�C�����i�[���ꂽ �p�[�\�i�� ValueBean �ł��B
     *
     * @param personalBean �Ώێ�Bean
     * @param loginuser ���O�C�����[�U���
     * @return �p�[�\�i���v���t�@�C���̈ꗗ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PEY_PersonalBean[] doSelect( PEY_PersonalBean personalBean, PEY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // SQL���̍쐬
            StringBuffer sql = new StringBuffer(  );
            sql.append( "SELECT * FROM " );
            sql.append( HcdbDef.personalTbl );

            // ���������̍쐬
            StringBuffer where     = new StringBuffer(  );
            Map personalConditions = personalBean.extractConditions(  );

            for ( Iterator ite = personalConditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                Object column = ite.next(  );

                if ( column.equals( "SIMEI_NO" ) ) {
                    where.append( " AND " + column + " LIKE ?" );
                } else if ( column.equals( "KANJI_SIMEI" ) ) {
                    where.append( " AND " + column + " LIKE ?" );
                } else if ( column.equals( "KANA_SIMEI" ) ) {
                    where.append( " AND " + column + " LIKE ?" );
                } else if ( column.equals( "EIJI_SIMEI" ) ) {
                    where.append( " AND " + column + " LIKE ?" );
                } else {
                    where.append( " AND " + column + "=?" );
                }
            }

            where.append( " AND HONMU_FLG='" + HcdbDef.HONMU + "' " );
            sql.append( where.toString(  ).replaceFirst( "AND", "WHERE" ) );

            // �R�l�N�V�����̎擾
            PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );
            ps      = con.prepareStatement( sql.toString(  ) );

            int count = 1;

            for ( Iterator ite = personalConditions.keySet(  ).iterator(  ); ite.hasNext(  ); ) {
                Object key = ite.next(  );
                ps.setObject( count++, personalConditions.get( key ) );
            }

            // �������s
            ResultSet rs = ps.executeQuery(  );
            List ret     = new ArrayList(  );

            while ( rs.next(  ) ) {
                ret.add( new PEY_PersonalBean( rs, null ) );
            }

            /*���\�b�h�g���[�X�o��*/
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ( PEY_PersonalBean[] )ret.toArray( new PEY_PersonalBean[0] );
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-xxxx", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

	
	/**
	 * ����No���L�[�Ƃ��ăt�H�[�����Ǘ��Ҍ����ƎГ�����Ǘ��Ҍ������X�V���܂��B
	 *
	 * @param personalBean �X�V����PEY_PersonalBean
	 * @param loginuser ���O�C�����[�U
	 * @return �X�V����
	 * @throws PEY_WarningException �X�V������0���̏ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdateMainte( PEY_PersonalBean personalBean, PEY_PersonalBean loginuser )
		throws PEY_WarningException {
			
		Connection con        = null;
		PreparedStatement ps  = null;

		try {
			/* ���\�b�h�g���[�X�o�� */
			Log.method( loginuser.getSimeiNo(  ), "IN", "" );

			/* SQL�쐬 */
			StringBuffer sql = new StringBuffer(  );
			sql.append( "UPDATE " );
			sql.append( HcdbDef.personalTbl );
			sql.append( "    SET " );
			//sql.append( "        MAINTE_FLG_10=?, " ); //2005/11/9_LYCE_D_THANHLVT
			sql.append( "        MAINTE_FLG_YOBI1=?, " ); //2005/11/9_LYCE_A_THANHLVT
			sql.append( "        SYAGAI_RONBUN_MAINTE_FLG=? " );
			sql.append( "  WHERE SIMEI_NO=? " );

			/* �R�l�N�V�����擾 */
			PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
			con = locator.getDataSource(  ).getConnection(  );

            /* EJB���� */
			PEY_PersonalEJBHome home = ( PEY_PersonalEJBHome )locator.getServiceLocation( "PEY_PersonalEJB",
					PEY_PersonalEJBHome.class );
			PEY_PersonalEJB ejb = home.create(  );

			/* �X�V�p�����[�^�ݒ� */
			ps = con.prepareStatement( sql.toString(  ) );
            ps.setString( 1, checkData( personalBean.getMainteFlg10(  ) ) );
            ps.setString( 2, checkData( personalBean.getSyagaiRonbunMainteFlg(  )));
		    ps.setString( 3, checkData( personalBean.getSimeiNo(  ) ) );
			
			/* �X�V���s */
			int count = ps.executeUpdate(  );

            /* �X�V�����̃`�F�b�N */
			if ( count == 0) {
				context.setRollbackOnly(  );
				throw new PEY_WarningException(  );
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

			return count;
			
		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw new EJBException( e );
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw new EJBException( e );
		} catch ( CreateException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw new EJBException( e );
		} catch ( RemoteException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw new EJBException( e );
		} catch ( RuntimeException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} finally {
			if ( ps != null ) {
				try {
					ps.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}

			if ( con != null ) {
				try {
					con.close(  );
				} catch ( SQLException e ) {
					// �������Ȃ�
				}
			}
		}
	}


    /**
     * �v���C�}���[�L�[���L�[�Ƃ��ăp�[�\�i���v���t�@�C�����X�V���܂��B
     *
     * @param personalBeans �X�V����PBF_PersonalBean�̔z��
     * @param loginuser ���O�C�����[�U
     * @return �X�V����
     * @throws PBF_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdate( PEY_PersonalBean[] personalBeans, PEY_PersonalBean loginuser )
        throws PEY_WarningException {
        Connection con        = null;
        PreparedStatement ps  = null;
        boolean updateFlg     = false;
        boolean simeiNoFlg    = false;
        boolean sosikiCodeFlg = false;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // ����No.���L�[�Ƀ\�[�g
            Arrays.sort( personalBeans, new ClassCodeComparator(  ) );

            // SQL�쐬
            StringBuffer sql = new StringBuffer(  );
            sql.append( "UPDATE " );
            sql.append( HcdbDef.personalTbl );
            sql.append( "    SET " );

            sql.append( "        PASSWORD=?, " );
            sql.append( "        HONMU_FLG=?, " );
            sql.append( "        SIMEI_NO_FLG=?, " );
            sql.append( "        KANJI_SIMEI=?, " );
            sql.append( "        KANA_SIMEI=?, " );
            sql.append( "        EIJI_SIMEI=?, " );
            sql.append( "        SEIBETU=?, " );
            sql.append( "        SEINENGAPPI=?, " );
            sql.append( "        GROUP_NYUSYA_NENGETU=?, " );
            sql.append( "        NYUSYA_NENGETU=?, " );

            sql.append( "        YAKUSYOKU_CODE=?, " );
            sql.append( "        SYOKUI_CODE=?, " );
            sql.append( "        NAISEN=?, " );
            sql.append( "        GAISEN=?, " );
            sql.append( "        FAX_NO=?, " );
            sql.append( "        MAIL=?, " );
            sql.append( "        JIKO_PR=?, " );
            sql.append( "        GENSYOKU_TAISYOKU_FLG=?, " );
            sql.append( "        TAISYOKU_NENGAPPI=?, " );
            sql.append( "        KENGEN_CODE=?, " );
            sql.append( "        SYOZOKU_CODE_1=?, " );
            sql.append( "        SYOZOKU_CODE_2=?, " );
            sql.append( "        SYOZOKU_CODE_3=?, " );
            sql.append( "        SYOZOKU_CODE_4=?, " );
            sql.append( "        SYOZOKU_CODE_5=?, " );
            sql.append( "        SYOZOKU_CODE_6=?, " );
            sql.append( "        SYOZOKU_CODE_7=?, " );
            sql.append( "        SYOZOKU_CODE_8=?, " );
            sql.append( "        SYOZOKU_CODE_9=?, " );
            sql.append( "        SYOKU_CODE1=?, " );
            sql.append( "        SENMON_CODE1=?, " );
            sql.append( "        LEVEL_CODE1=?, " );
            sql.append( "        SOUGOU_T_DO1=?, " );
            sql.append( "        SYOKU_CODE2=?, " );
            sql.append( "        SENMON_CODE2=?, " );
            sql.append( "        LEVEL_CODE2=?, " );
            sql.append( "        SOUGOU_T_DO2=?, " );
            sql.append( "        SYOKU_CODE3=?, " );
            sql.append( "        SENMON_CODE3=?, " );
            sql.append( "        LEVEL_CODE3=?, " );
            sql.append( "        SOUGOU_T_DO3=?, " );
            sql.append( "        ASSESSMENT_KOKAI_FLG=?, " );
            sql.append( "        KAO_KOKAI_FLG=?, " );
            sql.append( "        SKILL_KOKAI_FLG=?, " );
            sql.append( "        SYOKUMU_KOKAI_FLG=?, " );
            sql.append( "        KYOIKU_KOKAI_FLG=?, " );
            sql.append( "        SIKAKU_KOKAI_FLG=?, " );
            sql.append( "        HYOSYO_KOKAI_FLG=?, " );
            sql.append( "        RONBUN_KOKAI_FLG=?, " );
            sql.append( "        SYAGAI_KOKAI_FLG=?, " );
            sql.append( "        GAKUREKI_KOKAI_FLG=?, " );
            sql.append( "        SYANAIREKI_KOKAI_FLG=?, " );
            sql.append( "        ZENSYOKUREKI_KOKAI_FLG=?, " );
            sql.append( "        SOSIKI_KOKAI_FLG=?, " );
            sql.append( "        YAKUSYOKU_KOKAI_FLG=?, " );
            sql.append( "        SYOKUI_KOKAI_FLG=?, " );
            sql.append( "        SKILL_MAINTE_FLG=?, " );
            sql.append( "        KANREN_GYOMU_TOUROKU_FLG=?, " );
            sql.append( "        PERSONAL_MAINTE_FLG=?, " );
            sql.append( "        SOSIKI_MAINTE_FLG=?, " );
            sql.append( "        KYOIKU_MAINTE_FLG=?, " );
            sql.append( "        RONBUN_MAINTE_FLG=?, " );
            sql.append( "        SIKAKU_MAINTE_FLG=?, " );
            sql.append( "        HYOSYO_MAINTE_FLG=?, " );
            sql.append( "        SYAGAI_RONBUN_MAINTE_FLG=?, " );
            sql.append( "        KENPO_MAINTE_FLG=?, " );
            sql.append( "        SYAGAI_MAINTE_FLG=?, " );
            sql.append( "        LOGIN_OSIRASE_MAINTE_FLG=?, " );
            sql.append( "        TOKEI_BUNSEKI_KENGEN=?, " );
            sql.append( "        TAISYOKUSYA_KENSAKU_KENGEN_FLG=?, " );
            sql.append( "        HIKOUKAI_KENSAKU_KENGEN_FLG=?, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI1=?, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI2=?, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI3=?, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI4=?, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI5=?, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI6=?, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI7=?, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI8=?, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI9=?, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI10=?, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI11=?, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI12=?, " );
            sql.append( "        MAINTE_FLG_YOBI1=?, " );
            sql.append( "        YOBI1=?, " );
            sql.append( "        YOBI2=?, " );
            sql.append( "        YOBI3=?, " );
            sql.append( "        YOBI4=?, " );
            sql.append( "        YOBI5=?, " );
            sql.append( "        YOBI6=?, " );
            sql.append( "        YOBI7=?, " );
            sql.append( "        YOBI8=?, " );
            sql.append( "        YOBI9=?, " );
            sql.append( "        YOBI10=?, " );
            sql.append( "        YAKUSYOKU=?, " );
            sql.append( "        YOBI_RYOIKI=?, " );
            sql.append( "        KAIGAI_KOKAI_FLG=?, " );
            sql.append( "        KAIGAI_MAINTE_FLG=?, " );
            sql.append( "        JINMEI_RYAKUSYO=?, " );
            sql.append( "        BUSYO_RYAKUSYO_MEI=?, " );
            sql.append( "        GAKUREKI_GAKKO_MEI=?, " );
            sql.append( "        GAKUREKI_GAKUBU_MEI=?, " );
            sql.append( "        GAKUREKI_GAKKA_MEI=?, " );
            sql.append( "        GAKUREKI_SOTUGYO_NENGETU=? " );

            sql.append( "  WHERE SIMEI_NO=? " );
            sql.append( "    AND SOSIKI_CODE=? " );

            // �R�l�N�V�����擾
            PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            PEY_PersonalEJBHome home = ( PEY_PersonalEJBHome )locator.getServiceLocation( "PEY_PersonalEJB",
                    PEY_PersonalEJBHome.class );
            PEY_PersonalEJB ejb = home.create(  );

            // �X�V���s
            ps = con.prepareStatement( sql.toString(  ) );

            int count = 0;

            for ( int i = 0; i < personalBeans.length; i++ ) {
                ps.setString( 1, checkData( personalBeans[i].getPassword(  ) ) );
                ps.setString( 2, checkData( personalBeans[i].getHonmuFlg(  ) ) );
                ps.setString( 3,
                    checkData( personalBeans[i].getSimeiNoFlgPublic(  ) )
                    + checkData( personalBeans[i].getSimeiNoFlg(  ) ) );
                ps.setString( 4,
                    checkData( personalBeans[i].getKanjiSimeiPublic(  ) )
                    + checkData( personalBeans[i].getKanjiSimei(  ) ) );
                ps.setString( 5,
                    checkData( personalBeans[i].getKanaSimeiPublic(  ) )
                    + checkData( personalBeans[i].getKanaSimei(  ) ) );

                //				ps.setString( 6, personalBeans[i].getEijiSimei() );
                ps.setString( 6,
                    checkData( personalBeans[i].getEigoSimeiPublic(  ) )
                    + checkData( personalBeans[i].getEigoSimei(  ) ) );
                ps.setString( 7,
                    checkData( personalBeans[i].getSeibetuPublic(  ) )
                    + checkData( personalBeans[i].getSeibetu(  ) ) );
                ps.setString( 8,
                    checkData( personalBeans[i].getSeinengappiPublic(  ) )
                    + checkData( personalBeans[i].getSeinengappi(  ) ) );
                ps.setString( 9,
                    checkData( personalBeans[i].getGroupNyusyaNengetuPublic(  ) )
                    + checkData( personalBeans[i].getGroupNyusyaNengetu(  ) ) );
                ps.setString( 10,
                    checkData( personalBeans[i].getNyusyaNengetuPublic(  ) )
                    + checkData( personalBeans[i].getNyusyaNengetu(  ) ) );
                ps.setString( 11, checkData( personalBeans[i].getYakusyokuCode(  ) ) );
                ps.setString( 12, checkData( personalBeans[i].getSyokuiCode(  ) ) );
                ps.setString( 13, checkData( personalBeans[i].getNaisen(  ) ) );
                ps.setString( 14, checkData( personalBeans[i].getGaisen(  ) ) );
                ps.setString( 15, checkData( personalBeans[i].getFaxNo(  ) ) );
                ps.setString( 16, checkData( personalBeans[i].getMail(  ) ) );
                ps.setString( 17,
                    checkData( personalBeans[i].getJikoPrPublic(  ) )
                    + checkData( personalBeans[i].getJikoPr(  ) ) );
                ps.setString( 18, checkData( personalBeans[i].getGensyokuTaisyokuFlg(  ) ) );
                ps.setString( 19, checkData( personalBeans[i].getTaisyokuNengappi(  ) ) );
                ps.setString( 20, checkData( personalBeans[i].getKengenCode(  ) ) );
                ps.setString( 21, checkData( personalBeans[i].getSyozokuCode1(  ) ) );
                ps.setString( 22, checkData( personalBeans[i].getSyozokuCode2(  ) ) );
                ps.setString( 23, checkData( personalBeans[i].getSyozokuCode3(  ) ) );
                ps.setString( 24, checkData( personalBeans[i].getSyozokuCode4(  ) ) );
                ps.setString( 25, checkData( personalBeans[i].getSyozokuCode5(  ) ) );
                ps.setString( 26, checkData( personalBeans[i].getSyozokuCode6(  ) ) );
                ps.setString( 27, checkData( personalBeans[i].getSyozokuCode7(  ) ) );
                ps.setString( 28, checkData( personalBeans[i].getSyozokuCode8(  ) ) );
                ps.setString( 29, checkData( personalBeans[i].getSyozokuCode9(  ) ) );
                ps.setString( 30, checkData( personalBeans[i].getSyokuCode1(  ) ) );
                ps.setString( 31, checkData( personalBeans[i].getSenmonCode1(  ) ) );
                ps.setString( 32, checkData( personalBeans[i].getLevelCode1(  ) ) );
                ps.setString( 33, checkData( personalBeans[i].getSougouTDo1(  ) ) );
                ps.setString( 34, checkData( personalBeans[i].getSyokuCode2(  ) ) );
                ps.setString( 35, checkData( personalBeans[i].getSenmonCode2(  ) ) );
                ps.setString( 36, checkData( personalBeans[i].getLevelCode2(  ) ) );
                ps.setString( 37, checkData( personalBeans[i].getSougouTDo2(  ) ) );
                ps.setString( 38, checkData( personalBeans[i].getSyokuCode3(  ) ) );
                ps.setString( 39, checkData( personalBeans[i].getSenmonCode3(  ) ) );
                ps.setString( 40, checkData( personalBeans[i].getLevelCode3(  ) ) );
                ps.setString( 41, checkData( personalBeans[i].getSougouTDo3(  ) ) );
                ps.setString( 42, checkData( personalBeans[i].getAssessmentKokaiFlg(  ) ) );
                ps.setString( 43, checkData( personalBeans[i].getKaoKokaiFlg(  ) ) );
                ps.setString( 44, checkData( personalBeans[i].getSkillKokaiFlg(  ) ) );
                ps.setString( 45, checkData( personalBeans[i].getSyokumuKokaiFlg(  ) ) );
                ps.setString( 46, checkData( personalBeans[i].getKyoikuKokaiFlg(  ) ) );
                ps.setString( 47, checkData( personalBeans[i].getSikakuKokaiFlg(  ) ) );
                ps.setString( 48, checkData( personalBeans[i].getHyosyoKokaiFlg(  ) ) );
                ps.setString( 49, checkData( personalBeans[i].getRonbunKokaiFlg(  ) ) );
                ps.setString( 50, checkData( personalBeans[i].getSyagaiKokaiFlg(  ) ) );
                ps.setString( 51, checkData( personalBeans[i].getGakurekiKokaiFlg(  ) ) );
                ps.setString( 52, checkData( personalBeans[i].getSyanairekiKokaiFlg(  ) ) );
                ps.setString( 53, checkData( personalBeans[i].getZensyokurekiKokaiFlg(  ) ) );
                ps.setString( 54, checkData( personalBeans[i].getSosikiKokaiFlg(  ) ) );
                ps.setString( 55, checkData( personalBeans[i].getYakusyokuKokaiFlg(  ) ) );
                ps.setString( 56, checkData( personalBeans[i].getSyokuiKokaiFlg(  ) ) );
                ps.setString( 57, checkData( personalBeans[i].getSkillMainteFlg(  ) ) );
                ps.setString( 58, checkData( personalBeans[i].getKanrenGyomuTourokuFlg(  ) ) );
                ps.setString( 59, checkData( personalBeans[i].getPersonalMainteFlg(  ) ) );
                ps.setString( 60, checkData( personalBeans[i].getSosikiMainteFlg(  ) ) );
                ps.setString( 61, checkData( personalBeans[i].getKyoikuMainteFlg(  ) ) );
                ps.setString( 62, checkData( personalBeans[i].getRonbunMainteFlg(  ) ) );
                ps.setString( 63, checkData( personalBeans[i].getSikakuMainteFlg(  ) ) );
                ps.setString( 64, checkData( personalBeans[i].getHyosyoMainteFlg(  ) ) );
                ps.setString( 65, checkData( personalBeans[i].getSyagaiRonbunMainteFlg(  ) ) );
                ps.setString( 66, checkData( personalBeans[i].getKenpoMainteFlg(  ) ) );
                ps.setString( 67, checkData( personalBeans[i].getSyagaiMainteFlg(  ) ) );
                ps.setString( 68, checkData( personalBeans[i].getLoginOsiraseMainteFlg(  ) ) );
                ps.setString( 69, checkData( personalBeans[i].getTokeiBunsekiKengen(  ) ) );
                ps.setString( 70, checkData( personalBeans[i].getTaisyokusyaKensakuKengenFlg(  ) ) );
                ps.setString( 71, checkData( personalBeans[i].getHikoukaiKensakuKengenFlg(  ) ) );
                ps.setString( 72, checkData( personalBeans[i].getGamenKokaiFlgYobi1(  ) ) );
                ps.setString( 73, checkData( personalBeans[i].getGamenKokaiFlgYobi2(  ) ) );
                ps.setString( 74, checkData( personalBeans[i].getGamenKokaiFlgYobi3(  ) ) );
                ps.setString( 75, checkData( personalBeans[i].getGamenKokaiFlgYobi4(  ) ) );
                ps.setString( 76, checkData( personalBeans[i].getGamenKokaiFlgYobi5(  ) ) );
                ps.setString( 77, checkData( personalBeans[i].getGamenKokaiFlgYobi6(  ) ) );
                ps.setString( 78, checkData( personalBeans[i].getGamenKokaiFlgYobi7(  ) ) );
                ps.setString( 79, checkData( personalBeans[i].getGamenKokaiFlgYobi8(  ) ) );
                ps.setString( 80, checkData( personalBeans[i].getGamenKokaiFlgYobi9(  ) ) );
                ps.setString( 81, checkData( personalBeans[i].getGamenKokaiFlgYobi10(  ) ) );
                ps.setString( 82, checkData( personalBeans[i].getGamenKokaiFlgYobi11(  ) ) );
                ps.setString( 83, checkData( personalBeans[i].getGamenKokaiFlgYobi12(  ) ) );
                ps.setString( 84, checkData( personalBeans[i].getMainteFlgYobi1(  ) ) );
                ps.setString( 85,
                    checkData( personalBeans[i].getYobi1Public(  ) )
                    + checkData( personalBeans[i].getYobi1(  ) ) );
                ps.setString( 86,
                    checkData( personalBeans[i].getYobi2Public(  ) )
                    + checkData( personalBeans[i].getYobi2(  ) ) );
                ps.setString( 87,
                    checkData( personalBeans[i].getYobi3Public(  ) )
                    + checkData( personalBeans[i].getYobi3(  ) ) );
                ps.setString( 88,
                    checkData( personalBeans[i].getYobi4Public(  ) )
                    + checkData( personalBeans[i].getYobi4(  ) ) );
                ps.setString( 89,
                    checkData( personalBeans[i].getYobi5Public(  ) )
                    + checkData( personalBeans[i].getYobi5(  ) ) );
                ps.setString( 90, checkData( personalBeans[i].getYobi6(  ) ) );
                ps.setString( 91, checkData( personalBeans[i].getYobi7(  ) ) );
                ps.setString( 92, checkData( personalBeans[i].getYobi8(  ) ) );
                ps.setString( 93, checkData( personalBeans[i].getYobi9(  ) ) );
                ps.setString( 94, checkData( personalBeans[i].getYobi10(  ) ) );
                ps.setString( 95, checkData( personalBeans[i].getYakusyoku(  ) ) );
                ps.setString( 96, checkData( personalBeans[i].getYobiRyoiki(  ) ) );
                ps.setString( 97, checkData( personalBeans[i].getKaigaiKokaiFlg(  ) ) );
                ps.setString( 98, checkData( personalBeans[i].getKaigaiMainteFlg(  ) ) );
                ps.setString( 99, checkData( personalBeans[i].getJinmeiRyakusyo(  ) ) );
                ps.setString( 100,
                    checkData( personalBeans[i].getBusyoRyakusyoMeiPublic(  ) )
                    + checkData( personalBeans[i].getBusyoRyakusyoMei(  ) ) );
                ps.setString( 101, checkData( personalBeans[i].getGakurekiGakkoMei(  ) ) );
                ps.setString( 102, checkData( personalBeans[i].getGakurekiGakubuMei(  ) ) );
                ps.setString( 103, checkData( personalBeans[i].getGakurekiGakkaMei(  ) ) );
                ps.setString( 104, checkData( personalBeans[i].getGakurekiSotugyoNengetu(  ) ) );
                ps.setString( 105, checkData( personalBeans[i].getSimeiNo(  ) ) );
                ps.setString( 106, checkData( personalBeans[i].getSosikiCode(  ) ) );

                count += ps.executeUpdate(  );
            }

            if ( personalBeans.length != count ) {
                context.setRollbackOnly(  );
                throw new PEY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �v���C�}���[�L�[���L�[�Ƃ��ăp�[�\�i���v���t�@�C�����X�V���܂��B
     *
     * @param personalBeans �X�V����PEY_PersonalBean
     * @param loginuser ���O�C�����[�U
     * @return �X�V����
     * @throws PEY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doUpdate( PEY_PersonalBean personalBean, PEY_PersonalBean loginuser )
        throws PEY_WarningException {
        return doUpdate( new PEY_PersonalBean[] { personalBean }, loginuser );
    }

    /**
     * �p�[�\�i���v���t�@�C����}�����܂��B
     *
     * @param personalBeans �X�V����PEY_PersonalBean�̔z��
     * @param loginuser ���O�C�����[�U
     * @return �X�V����
     * @throws PEY_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doInsert( PEY_PersonalBean[] personalBeans, PEY_PersonalBean loginuser )
        throws PEY_WarningException {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            // ����No.���L�[�Ƀ\�[�g
            Arrays.sort( personalBeans, new ClassCodeComparator(  ) );

            // SQL�쐬
            StringBuffer sql = new StringBuffer(  );
            sql.append( "INSERT INTO " );
            sql.append( HcdbDef.personalTbl );
            sql.append( " (" );
            sql.append( "        SIMEI_NO, " );
            sql.append( "        PASSWORD, " );
            sql.append( "        HONMU_FLG, " );
            sql.append( "        SIMEI_NO_FLG, " );
            sql.append( "        KANJI_SIMEI, " );
            sql.append( "        KANA_SIMEI, " );
            sql.append( "        EIJI_SIMEI, " );
            sql.append( "        SEIBETU, " );
            sql.append( "        SEINENGAPPI, " );
            sql.append( "        GROUP_NYUSYA_NENGETU, " );
            sql.append( "        NYUSYA_NENGETU, " );
            sql.append( "        SOSIKI_CODE, " );
            sql.append( "        YAKUSYOKU_CODE, " );
            sql.append( "        SYOKUI_CODE, " );
            sql.append( "        NAISEN, " );
            sql.append( "        GAISEN, " );
            sql.append( "        FAX_NO, " );
            sql.append( "        MAIL, " );
            sql.append( "        JIKO_PR, " );
            sql.append( "        GENSYOKU_TAISYOKU_FLG, " );
            sql.append( "        TAISYOKU_NENGAPPI, " );
            sql.append( "        KENGEN_CODE, " );
            sql.append( "        SYOZOKU_CODE_1, " );
            sql.append( "        SYOZOKU_CODE_2, " );
            sql.append( "        SYOZOKU_CODE_3, " );
            sql.append( "        SYOZOKU_CODE_4, " );
            sql.append( "        SYOZOKU_CODE_5, " );
            sql.append( "        SYOZOKU_CODE_6, " );
            sql.append( "        SYOZOKU_CODE_7, " );
            sql.append( "        SYOZOKU_CODE_8, " );
            sql.append( "        SYOZOKU_CODE_9, " );
            sql.append( "        SYOKU_CODE1, " );
            sql.append( "        SENMON_CODE1, " );
            sql.append( "        LEVEL_CODE1, " );
            sql.append( "        SOUGOU_T_DO1, " );
            sql.append( "        SYOKU_CODE2, " );
            sql.append( "        SENMON_CODE2, " );
            sql.append( "        LEVEL_CODE2, " );
            sql.append( "        SOUGOU_T_DO2, " );
            sql.append( "        SYOKU_CODE3, " );
            sql.append( "        SENMON_CODE3, " );
            sql.append( "        LEVEL_CODE3, " );
            sql.append( "        SOUGOU_T_DO3, " );
            sql.append( "        ASSESSMENT_KOKAI_FLG, " );
            sql.append( "        KAO_KOKAI_FLG, " );
            sql.append( "        SKILL_KOKAI_FLG, " );
            sql.append( "        SYOKUMU_KOKAI_FLG, " );
            sql.append( "        KYOIKU_KOKAI_FLG, " );
            sql.append( "        SIKAKU_KOKAI_FLG, " );
            sql.append( "        HYOSYO_KOKAI_FLG, " );
            sql.append( "        RONBUN_KOKAI_FLG, " );
            sql.append( "        SYAGAI_KOKAI_FLG, " );
            sql.append( "        GAKUREKI_KOKAI_FLG, " );
            sql.append( "        SYANAIREKI_KOKAI_FLG, " );
            sql.append( "        ZENSYOKUREKI_KOKAI_FLG, " );
            sql.append( "        SOSIKI_KOKAI_FLG, " );
            sql.append( "        YAKUSYOKU_KOKAI_FLG, " );
            sql.append( "        SYOKUI_KOKAI_FLG, " );
            sql.append( "        SKILL_MAINTE_FLG, " );
            sql.append( "        KANREN_GYOMU_TOUROKU_FLG, " );
            sql.append( "        PERSONAL_MAINTE_FLG, " );
            sql.append( "        SOSIKI_MAINTE_FLG, " );
            sql.append( "        KYOIKU_MAINTE_FLG, " );
            sql.append( "        RONBUN_MAINTE_FLG, " );
            sql.append( "        SIKAKU_MAINTE_FLG, " );
            sql.append( "        HYOSYO_MAINTE_FLG, " );
            sql.append( "        SYAGAI_RONBUN_MAINTE_FLG, " );
            sql.append( "        KENPO_MAINTE_FLG, " );
            sql.append( "        SYAGAI_MAINTE_FLG, " );
            sql.append( "        LOGIN_OSIRASE_MAINTE_FLG, " );
            sql.append( "        TOKEI_BUNSEKI_KENGEN, " );
            sql.append( "        TAISYOKUSYA_KENSAKU_KENGEN_FLG, " );
            sql.append( "        HIKOUKAI_KENSAKU_KENGEN_FLG, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI1, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI2, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI3, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI4, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI5, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI6, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI7, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI8, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI9, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI10, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI11, " );
            sql.append( "        GAMEN_KOKAI_FLG_YOBI12, " );
            sql.append( "        MAINTE_FLG_YOBI1, " );
            sql.append( "        YOBI1, " );
            sql.append( "        YOBI2, " );
            sql.append( "        YOBI3, " );
            sql.append( "        YOBI4, " );
            sql.append( "        YOBI5, " );
            sql.append( "        YOBI6, " );
            sql.append( "        YOBI7, " );
            sql.append( "        YOBI8, " );
            sql.append( "        YOBI9, " );
            sql.append( "        YOBI10, " );
            sql.append( "        YAKUSYOKU, " );
            sql.append( "        YOBI_RYOIKI, " );
            sql.append( "        KAIGAI_KOKAI_FLG, " );
            sql.append( "        KAIGAI_MAINTE_FLG, " );
            sql.append( "        JINMEI_RYAKUSYO, " );
            sql.append( "        BUSYO_RYAKUSYO_MEI, " );
            sql.append( "        GAKUREKI_GAKKO_MEI, " );
            sql.append( "        GAKUREKI_GAKUBU_MEI, " );
            sql.append( "        GAKUREKI_GAKKA_MEI, " );
            sql.append( "        GAKUREKI_SOTUGYO_NENGETU ) " );
            sql.append( 
                "  VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)" );

            // �R�l�N�V�����擾
            PEY_ServiceLocator locator = PEY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            PEY_PersonalEJBHome home = ( PEY_PersonalEJBHome )locator.getServiceLocation( "PEY_PersonalEJB",
                    PEY_PersonalEJBHome.class );
            PEY_PersonalEJB ejb = home.create(  );

            // �X�V���s
            ps = con.prepareStatement( sql.toString(  ) );

            int count = 0;

            for ( int i = 0; i < personalBeans.length; i++ ) {
                ps.setString( 1, checkData( personalBeans[i].getSimeiNo(  ) ) );
                ps.setString( 2, checkData( personalBeans[i].getPassword(  ) ) );
                ps.setString( 3, checkData( personalBeans[i].getHonmuFlg(  ) ) );
                ps.setString( 4,
                    personalBeans[i].getSimeiNoFlgPublic(  ) + personalBeans[i].getSimeiNoFlg(  ) );
                ps.setString( 5,
                    personalBeans[i].getKanjiSimeiPublic(  ) + personalBeans[i].getKanjiSimei(  ) );
                ps.setString( 6,
                    personalBeans[i].getKanaSimeiPublic(  ) + personalBeans[i].getKanaSimei(  ) );

                //				ps.setString( 6, personalBeans[i].getEijiSimei() );
                ps.setString( 7,
                    personalBeans[i].getEigoSimeiPublic(  ) + personalBeans[i].getEigoSimei(  ) );
                ps.setString( 8,
                    personalBeans[i].getSeibetuPublic(  ) + personalBeans[i].getSeibetu(  ) );
                ps.setString( 9,
                    personalBeans[i].getSeinengappiPublic(  ) + personalBeans[i].getSeinengappi(  ) );
                ps.setString( 10,
                    personalBeans[i].getGroupNyusyaNengetuPublic(  )
                    + personalBeans[i].getGroupNyusyaNengetu(  ) );
                ps.setString( 11,
                    personalBeans[i].getNyusyaNengetuPublic(  )
                    + personalBeans[i].getNyusyaNengetu(  ) );
                ps.setString( 12, checkData( personalBeans[i].getSosikiCode(  ) ) );
                ps.setString( 13, checkData( personalBeans[i].getYakusyokuCode(  ) ) );
                ps.setString( 14, checkData( personalBeans[i].getSyokuiCode(  ) ) );
                ps.setString( 15, checkData( personalBeans[i].getNaisen(  ) ) );
                ps.setString( 16, checkData( personalBeans[i].getGaisen(  ) ) );
                ps.setString( 17, checkData( personalBeans[i].getFaxNo(  ) ) );
                ps.setString( 18, checkData( personalBeans[i].getMail(  ) ) );
                ps.setString( 19,
                    personalBeans[i].getJikoPrPublic(  ) + personalBeans[i].getJikoPr(  ) );
                ps.setString( 20, checkData( personalBeans[i].getGensyokuTaisyokuFlg(  ) ) );
                ps.setString( 21, checkData( personalBeans[i].getTaisyokuNengappi(  ) ) );
                ps.setString( 22, checkData( personalBeans[i].getKengenCode(  ) ) );
                ps.setString( 23, checkData( personalBeans[i].getSyozokuCode1(  ) ) );
                ps.setString( 24, checkData( personalBeans[i].getSyozokuCode2(  ) ) );
                ps.setString( 25, checkData( personalBeans[i].getSyozokuCode3(  ) ) );
                ps.setString( 26, checkData( personalBeans[i].getSyozokuCode4(  ) ) );
                ps.setString( 27, checkData( personalBeans[i].getSyozokuCode5(  ) ) );
                ps.setString( 28, checkData( personalBeans[i].getSyozokuCode6(  ) ) );
                ps.setString( 29, checkData( personalBeans[i].getSyozokuCode7(  ) ) );
                ps.setString( 30, checkData( personalBeans[i].getSyozokuCode8(  ) ) );
                ps.setString( 31, checkData( personalBeans[i].getSyozokuCode9(  ) ) );
                ps.setString( 32, checkData( personalBeans[i].getSyokuCode1(  ) ) );
                ps.setString( 33, checkData( personalBeans[i].getSenmonCode1(  ) ) );
                ps.setString( 34, checkData( personalBeans[i].getLevelCode1(  ) ) );
                ps.setString( 35, checkData( personalBeans[i].getSougouTDo1(  ) ) );
                ps.setString( 36, checkData( personalBeans[i].getSyokuCode2(  ) ) );
                ps.setString( 37, checkData( personalBeans[i].getSenmonCode2(  ) ) );
                ps.setString( 38, checkData( personalBeans[i].getLevelCode2(  ) ) );
                ps.setString( 39, checkData( personalBeans[i].getSougouTDo2(  ) ) );
                ps.setString( 40, checkData( personalBeans[i].getSyokuCode3(  ) ) );
                ps.setString( 41, checkData( personalBeans[i].getSenmonCode3(  ) ) );
                ps.setString( 42, checkData( personalBeans[i].getLevelCode3(  ) ) );
                ps.setString( 43, checkData( personalBeans[i].getSougouTDo3(  ) ) );
                ps.setString( 44, checkData( personalBeans[i].getAssessmentKokaiFlg(  ) ) );
                ps.setString( 45, checkData( personalBeans[i].getKaoKokaiFlg(  ) ) );
                ps.setString( 46, checkData( personalBeans[i].getSkillKokaiFlg(  ) ) );
                ps.setString( 47, checkData( personalBeans[i].getSyokumuKokaiFlg(  ) ) );
                ps.setString( 48, checkData( personalBeans[i].getKyoikuKokaiFlg(  ) ) );
                ps.setString( 49, checkData( personalBeans[i].getSikakuKokaiFlg(  ) ) );
                ps.setString( 50, checkData( personalBeans[i].getHyosyoKokaiFlg(  ) ) );
                ps.setString( 51, checkData( personalBeans[i].getRonbunKokaiFlg(  ) ) );
                ps.setString( 52, checkData( personalBeans[i].getSyagaiKokaiFlg(  ) ) );
                ps.setString( 53, checkData( personalBeans[i].getGakurekiKokaiFlg(  ) ) );
                ps.setString( 54, checkData( personalBeans[i].getSyanairekiKokaiFlg(  ) ) );
                ps.setString( 55, checkData( personalBeans[i].getZensyokurekiKokaiFlg(  ) ) );
                ps.setString( 56, checkData( personalBeans[i].getSosikiKokaiFlg(  ) ) );
                ps.setString( 57, checkData( personalBeans[i].getYakusyokuKokaiFlg(  ) ) );
                ps.setString( 58, checkData( personalBeans[i].getSyokuiKokaiFlg(  ) ) );
                ps.setString( 59, checkData( personalBeans[i].getSkillMainteFlg(  ) ) );
                ps.setString( 60, checkData( personalBeans[i].getKanrenGyomuTourokuFlg(  ) ) );
                ps.setString( 61, checkData( personalBeans[i].getPersonalMainteFlg(  ) ) );
                ps.setString( 62, checkData( personalBeans[i].getSosikiMainteFlg(  ) ) );
                ps.setString( 63, checkData( personalBeans[i].getKyoikuMainteFlg(  ) ) );
                ps.setString( 64, checkData( personalBeans[i].getRonbunMainteFlg(  ) ) );
                ps.setString( 65, checkData( personalBeans[i].getSikakuMainteFlg(  ) ) );
                ps.setString( 66, checkData( personalBeans[i].getHyosyoMainteFlg(  ) ) );
                ps.setString( 67, checkData( personalBeans[i].getSyagaiRonbunMainteFlg(  ) ) );
                ps.setString( 68, checkData( personalBeans[i].getKenpoMainteFlg(  ) ) );
                ps.setString( 69, checkData( personalBeans[i].getSyagaiMainteFlg(  ) ) );
                ps.setString( 70, checkData( personalBeans[i].getLoginOsiraseMainteFlg(  ) ) );
                ps.setString( 71, checkData( personalBeans[i].getTokeiBunsekiKengen(  ) ) );
                ps.setString( 72, checkData( personalBeans[i].getTaisyokusyaKensakuKengenFlg(  ) ) );
                ps.setString( 73, checkData( personalBeans[i].getHikoukaiKensakuKengenFlg(  ) ) );
                ps.setString( 74, checkData( personalBeans[i].getGamenKokaiFlgYobi1(  ) ) );
                ps.setString( 75, checkData( personalBeans[i].getGamenKokaiFlgYobi2(  ) ) );
                ps.setString( 76, checkData( personalBeans[i].getGamenKokaiFlgYobi3(  ) ) );
                ps.setString( 77, checkData( personalBeans[i].getGamenKokaiFlgYobi4(  ) ) );
                ps.setString( 78, checkData( personalBeans[i].getGamenKokaiFlgYobi5(  ) ) );
                ps.setString( 79, checkData( personalBeans[i].getGamenKokaiFlgYobi6(  ) ) );
                ps.setString( 80, checkData( personalBeans[i].getGamenKokaiFlgYobi7(  ) ) );
                ps.setString( 81, checkData( personalBeans[i].getGamenKokaiFlgYobi8(  ) ) );
                ps.setString( 82, checkData( personalBeans[i].getGamenKokaiFlgYobi9(  ) ) );
                ps.setString( 83, checkData( personalBeans[i].getGamenKokaiFlgYobi10(  ) ) );
                ps.setString( 84, checkData( personalBeans[i].getGamenKokaiFlgYobi11(  ) ) );
                ps.setString( 85, checkData( personalBeans[i].getGamenKokaiFlgYobi12(  ) ) );
                ps.setString( 86, checkData( personalBeans[i].getMainteFlgYobi1(  ) ) );
                ps.setString( 87,
                    personalBeans[i].getYobi1Public(  ) + personalBeans[i].getYobi1(  ) );
                ps.setString( 88,
                    personalBeans[i].getYobi2Public(  ) + personalBeans[i].getYobi2(  ) );
                ps.setString( 89,
                    personalBeans[i].getYobi3Public(  ) + personalBeans[i].getYobi3(  ) );
                ps.setString( 90,
                    personalBeans[i].getYobi4Public(  ) + personalBeans[i].getYobi4(  ) );
                ps.setString( 91,
                    personalBeans[i].getYobi5Public(  ) + personalBeans[i].getYobi5(  ) );
                ps.setString( 92, checkData( personalBeans[i].getYobi6(  ) ) );
                ps.setString( 93, checkData( personalBeans[i].getYobi7(  ) ) );
                ps.setString( 94, checkData( personalBeans[i].getYobi8(  ) ) );
                ps.setString( 95, checkData( personalBeans[i].getYobi9(  ) ) );
                ps.setString( 96, checkData( personalBeans[i].getYobi10(  ) ) );
                ps.setString( 97, checkData( personalBeans[i].getYakusyoku(  ) ) );
                ps.setString( 98, checkData( personalBeans[i].getYobiRyoiki(  ) ) );
                ps.setString( 99, checkData( personalBeans[i].getKaigaiKokaiFlg(  ) ) );
                ps.setString( 100, checkData( personalBeans[i].getKaigaiMainteFlg(  ) ) );
                ps.setString( 101, checkData( personalBeans[i].getJinmeiRyakusyo(  ) ) );
                ps.setString( 102,
                    personalBeans[i].getBusyoRyakusyoMeiPublic(  )
                    + personalBeans[i].getBusyoRyakusyoMei(  ) );
                ps.setString( 103, checkData( personalBeans[i].getGakurekiGakkoMei(  ) ) );
                ps.setString( 104, checkData( personalBeans[i].getGakurekiGakubuMei(  ) ) );
                ps.setString( 105, checkData( personalBeans[i].getGakurekiGakkaMei(  ) ) );
                ps.setString( 106, checkData( personalBeans[i].getGakurekiSotugyoNengetu(  ) ) );

                count += ps.executeUpdate(  );
            }

            if ( personalBeans.length != count ) {
                context.setRollbackOnly(  );
                throw new PEY_WarningException(  );
            }

            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( CreateException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw new EJBException( e );
        } catch ( RemoteException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �p�[�\�i���v���t�@�C����}�����܂��B
     *
     * @param personalBeans �X�V����PBF_PersonalBean
     * @param loginuser ���O�C�����[�U
     * @return �X�V����
     * @throws PBF_WarningException �����Ƃ��ēn���ꂽ�z��̃T�C�Y�ƍX�V����������Ȃ������ꍇ
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int doInsert( PEY_PersonalBean personalBean, PEY_PersonalBean loginuser )
        throws PEY_WarningException {
        return doInsert( new PEY_PersonalBean[] { personalBean }, loginuser );
    }

    /**
     * �擾�����f�[�^���`�F�b�N����
     *
     * @return �`�F�b�N�ςݕ�����
     */
    private static String checkData( String data ) {
        if ( data == null ) {
            return "";
        } else {
            return data;
        }
    }

    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }

    private class ClassCodeComparator implements Comparator {
        public int compare( Object o1, Object o2 ) {
            PEY_PersonalBean class1 = ( PEY_PersonalBean )o1;
            PEY_PersonalBean class2 = ( PEY_PersonalBean )o2;

            if ( class1.getSimeiNo(  ).equals( class2.getSimeiNo(  ) ) ) {
                return class1.getSosikiCode(  ).compareTo( class2.getSosikiCode(  ) );
            }

            return class1.getSimeiNo(  ).compareTo( class2.getSimeiNo(  ) );
        }
    }
}
