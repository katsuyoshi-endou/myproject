/*
 * All Rights Reserved, Copyright (C) 2004,Hitachi System & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   Career@Net�i�Г�����@�\�j
 *
 * ���l�@�F
 *
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/08/11  01.00      �c���@�N�W      �V�K�쐬
 *   2005/10/26  01.01      THANHLVT        �C���|�[�g���ꂽ�p�b�P�[�W��u��������B
 *
 */
package jp.co.hisas.career.department.base.valuebean;

//import jp.co.hisas.hcdb.personalsite.util.log.Log;//2005/10/26_LYCE_R_THANHLVT
import jp.co.hisas.career.util.log.Log;//2005/10/26_LYCE_A_THANHLVT

import java.io.Serializable;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.*;

import javax.servlet.ServletRequest;


/**
 *<PRE>
 *
 * �N���X��:
 *   PEY_KouboOubosyaAssessBean �N���X
 *
 * �@�\����:
 *   ����_�����_�A�Z�X�����g���ʃe�[�u���̃f�[�^�ێ����s���B
 *
 *</PRE>
 */
public class PEY_KouboOubosyaAssessBean extends PEY_MasterBean implements Serializable {
	private String kouboankenid          = null;
	private String simeino               = null;
	private String jissi_nengappi        = null;
	private String seqno                 = null;
	private String syokucode             = null;
	private String senmoncode            = null;
	private String levelcode             = null;
	private String syokuname             = null;
	private String senmonname            = null;
	private String levelname             = null;
	private String jikosougoutdo         = null;
	private String hyokasyasougoutdo     = null;
	private String tourokubi             = null;
	private String tourokujikoku         = null;
	private String tourokusya            = null;
	private String kousinbi              = null;
	private String kousinjikoku          = null;
	private String kousinsya             = null;

	/**
	 * �f�t�H���g�̃R���X�g���N�^
	 */
	public PEY_KouboOubosyaAssessBean() {
	}

	
	/**
	 * �f�t�H���g�̃R���X�g���N�^
	 */
	public PEY_KouboOubosyaAssessBean( ServletRequest request ) {
		setKouboankenid(request.getParameter( "koubo_anken_id" ));
		setSimeino(request.getParameter( "simei_no" ));
	}
	

	/**
	 * ResultSet ����l���擾���Č���_�����_�A�Z�X�����gValueBean���쐬���܂��B
	 *
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param TableName ���m�点���̃e�[�u����
	 *
	 */
	public PEY_KouboOubosyaAssessBean( ResultSet rs )
		throws SQLException {

		try {
//			setSimeino( rs.getString( getIdentifier(  ) +"SINDANSYA" ) );
			setJissi_nengappi( rs.getString( getIdentifier(  ) +"JISSI_NENGAPPI" ) );
			setSyokucode(rs.getString( getIdentifier(  ) +"SYOKU_CODE" ));
			setSenmoncode(rs.getString( getIdentifier(  ) +"SENMON_CODE" ));
			setLevelcode(rs.getString( getIdentifier(  ) +"LEVEL_CODE" ));
			setJikosougoutdo(rs.getString( getIdentifier(  ) +"JIKO_SOUGOU_T_DO" ));
			setSyokuname(rs.getString( getIdentifier(  ) +"SYOKU_NAME" ));
			setSenmonname(rs.getString( getIdentifier(  ) +"SENMON_NAME" ));
			setLevelname(rs.getString( getIdentifier(  ) +"LEVEL_NAME" ));
			setHyokasyasougoutdo(rs.getString( getIdentifier(  ) +"HYOKASYA_SOUGOU_T_DO" ));
		} catch ( SQLException e ) {
			Log.error( "", "HJE-0001", e );
			throw e;
		}
	}

	
	/**
	 * ResultSet ����l���擾���Č���_�����_�A�Z�X�����gValueBean���쐬���܂��B
	 *
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param TableName ���m�点���̃e�[�u����
	 *
	 */
	public PEY_KouboOubosyaAssessBean( ResultSet rs, String TableName )
		throws SQLException {

		super( rs, TableName );

		try {
			setKouboankenid(rs.getString( getIdentifier(  ) +"KOUBO_ANKEN_ID" ));
			setSimeino(rs.getString( getIdentifier(  ) +"SIMEI_NO" ));
			setSeqno(rs.getString( getIdentifier(  ) +"SEQ_NO" ));
			setSyokucode(rs.getString( getIdentifier(  ) +"SYOKU_CODE" ));
			setSenmoncode(rs.getString( getIdentifier(  ) +"SENMON_CODE" ));
			setLevelcode(rs.getString( getIdentifier(  ) +"LEVEL_CODE" ));
			setJikosougoutdo(rs.getString( getIdentifier(  ) +"JIKO_SOUGOU_T_DO" ));
			setHyokasyasougoutdo(rs.getString( getIdentifier(  ) +"HYOKASYA_SOUGOU_T_DO" ));
			setTourokubi(rs.getString( getIdentifier(  ) +"TOUROKUBI" ));
			setTourokujikoku(rs.getString( getIdentifier(  ) +"TOUROKUJIKOKU" ));
			setTourokusya(rs.getString( getIdentifier(  ) +"TOUROKUSYA" ));
			setKousinbi(rs.getString( getIdentifier(  ) +"KOUSINBI" ));
			setKousinjikoku(rs.getString( getIdentifier(  ) +"KOUSINJIKOKU" ));
			setKousinsya(rs.getString( getIdentifier(  ) +"KOUSINSYA" ));
		} catch ( SQLException e ) {
			Log.error( "", "HJE-0001", e );
			throw e;
		}
	}

	/**
	 * <pre>
	 * ����_�����_�A�Z�X�����g���ʃe�[�u���̌��������𒊏o���܂��B
	 * �ȉ��̍��ڂ����������Ƃ��Ďg�p�ł��܂��B
	 * �E����Č�ID
	 * </pre>
	 *
	 * @return ���o���ꂽ��������
	 */
	public Map extractConditions(  ) {
		Map conditions = new LinkedHashMap(  );
		
		if ( ( getKouboankenid(  ) != null ) && !getKouboankenid(  ).equals( "" ) ) {
			conditions.put( "KOUBO_ANKEN_ID", getKouboankenid(  ) );
		}
		if ( ( getSimeino(  ) != null ) && !getSimeino(  ).equals( "" ) ) {
			conditions.put( "SIMEI_NO", getSimeino(  ) );
		}

		return conditions;
	}

	/**
	 * @return
	 */
	public String getKouboankenid() {
		return kouboankenid;
	}

	/**
	 * @return
	 */
	public String getSimeino() {
		return simeino;
	}

	/**
	 * @return
	 */
	public String getSeqno() {
		return seqno;
	}

	/**
	 * @return
	 */
	public String getSyokucode() {
		return syokucode;
	}

	/**
	 * @return
	 */
	public String getSenmoncode() {
		return senmoncode;
	}

	/**
	 * @return
	 */
	public String getLevelcode() {
		return levelcode;
	}

	/**
	 * @return
	 */
	public String getJikosougoutdo() {
		return jikosougoutdo;
	}

	/**
	 * @return
	 */
	public String getHyokasyasougoutdo() {
		return hyokasyasougoutdo;
	}

	/**
	 * @return
	 */
	public String getTourokubi() {
		return tourokubi;
	}

	/**
	 * @return
	 */
	public String getTourokujikoku() {
		return tourokujikoku;
	}

	/**
	 * @return
	 */
	public String getTourokusya() {
		return tourokusya;
	}

	/**
	 * @return
	 */
	public String getKousinbi() {
		return kousinbi;
	}

	/**
	 * @return
	 */
	public String getKousinjikoku() {
		return kousinjikoku;
	}

	/**
	 * @return
	 */
	public String getKousinsya() {
		return kousinsya;
	}

	/**
	 * @param string
	 */
	public void setKouboankenid(String string) {
		kouboankenid = string;
	}

	/**
	 * @param string
	 */
	public void setSimeino(String string) {
		simeino = string;
	}

	/**
	 * @param string
	 */
	public void setSeqno(String string) {
		seqno = string;
	}

	/**
	 * @param string
	 */
	public void setSyokucode(String string) {
		syokucode = string;
	}

	/**
	 * @param string
	 */
	public void setSenmoncode(String string) {
		senmoncode = string;
	}

	/**
	 * @param string
	 */
	public void setLevelcode(String string) {
		levelcode = string;
	}

	/**
	 * @param string
	 */
	public void setJikosougoutdo(String string) {
		jikosougoutdo = string;
	}

	/**
	 * @param string
	 */
	public void setHyokasyasougoutdo(String string) {
		hyokasyasougoutdo = string;
	}

	/**
	 * @param string
	 */
	public void setTourokubi(String string) {
		tourokubi = string;
	}

	/**
	 * @param string
	 */
	public void setTourokujikoku(String string) {
		tourokujikoku = string;
	}

	/**
	 * @param string
	 */
	public void setTourokusya(String string) {
		tourokusya = string;
	}

	/**
	 * @param string
	 */
	public void setKousinbi(String string) {
		kousinbi = string;
	}

	/**
	 * @param string
	 */
	public void setKousinjikoku(String string) {
		kousinjikoku = string;
	}

	/**
	 * @param string
	 */
	public void setKousinsya(String string) {
		kousinsya = string;
	}
	
    /**
     * @return
     */
    public String getJissi_nengappi() {
        return jissi_nengappi;
    }

    /**
     * @param string
     */
    public void setJissi_nengappi(String string) {
        jissi_nengappi = string;
    }

    /**
     * @return
     */
    public String getLevelname() {
        return levelname;
    }

    /**
     * @return
     */
    public String getSenmonname() {
        return senmonname;
    }

    /**
     * @return
     */
    public String getSyokuname() {
        return syokuname;
    }

    /**
     * @param string
     */
    public void setLevelname(String string) {
        levelname = string;
    }

    /**
     * @param string
     */
    public void setSenmonname(String string) {
        senmonname = string;
    }

    /**
     * @param string
     */
    public void setSyokuname(String string) {
        syokuname = string;
    }

}