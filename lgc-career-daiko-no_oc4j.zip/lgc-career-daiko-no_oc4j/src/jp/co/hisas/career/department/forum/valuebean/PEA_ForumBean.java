/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 * 
 * �v���W�F�N�g���@�F
 *   Career@Net�i�g�D�n �t�H�[�����x���@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/09/17  02.00-A    �ԗ� ����    �V�K�쐬
 */
package jp.co.hisas.career.department.forum.valuebean;

import java.io.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import jp.co.hisas.career.util.log.*;
import javax.servlet.*;
import java.util.*;

/**
 *<PRE>
 *
 * �N���X���F
 *   PEA_ForumBean �N���X
 *
 * �@�\�����F
 *   �t�H�[��������ێ�����ValueBean�ł��B
 *
 *</PRE>
 */

public class PEA_ForumBean extends PEA_MasterBean implements Serializable {
	private String   forumId          = null;
	private String   forumMei         = null;
	private String   forumGaiyo       = null;
	private String   sankaJyokenFlg   = null;
	private String   syokui           = null;
	private String   syokuiHani       = null;
	private String[] syokuCodeArry    = new String[3];
	private String[] senmonCodeArry   = new String[3];
	private String[] levelCodeArry    = new String[3];
	private String[] skillHaniArry    = new String[3];
	private String[] hyokaTaisyoArry  = new String[3];
	private String[] sougouTDoArry    = new String[3];
	private String[] tDoHaniArry      = new String[3];
	private String   taisyosyaSimeiNo = null;
	private String   sankaJyoken      = null;
	private String   kanrisyaComment  = null;
	private String   announce         = null;
	private String   syoriJyokyoFlg   = null;
	private String   forumKaisetubi  = null;
	private String   simeiNo          = null;
	private String   kanjiSimei       = null;
	private String   syozoku          = null;
	private String   mail             = null;
	private String   sinseibi         = null;
	private String   sinseijikoku     = null;
	private String   kousinsya        = null;
	private String   kousinbi         = null;
	private String   kousinjikoku     = null;
	
	private String   id               = null;// �t�H�[����ID(SQL���p)
	private String   recent           = null;// �ŐV���e��
	private String   recentJikoku     = null;// �ŐV���e����
	private String   count            = null;// ���e��
	private String   permission       = null;// �A�N�Z�X���i����E�Ȃ��j
	private String   notKeep          = null;// �ۑ����ł͖�������\��
	
	/**
	 * �f�t�H���g�̃R���X�g���N�^�ł��B
	 */
	public PEA_ForumBean(  ) {
		super(  );
		
	}
	
	/**
	 * ResultSet ����l���擾���ăt�H�[����ValueBean���쐬���܂��B
	 *
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param forumTableName �t�H�[�����e�[�u���̕ʖ�
	 * @throws SQLException SQLException�����������ꍇ
	 */
	public PEA_ForumBean(ResultSet rs, String forumTableName)
		throws SQLException {
		super(rs, forumTableName);

		try {
			setForumId(rs.getString(getIdentifier() + "forum_id"));
			setForumMei(rs.getString(getIdentifier() + "forum_mei"));
			setForumGaiyo(rs.getString(getIdentifier() + "forum_gaiyo"));
			setSankaJyokenFlg(rs.getString(getIdentifier() + "sanka_jyoken_flg"));
			setSyokui(rs.getString(getIdentifier() + "syokui"));
			setSyokuiHani(rs.getString(getIdentifier() + "syokui_taisyo_hani"));
			setSyokuCode(0, rs.getString(getIdentifier() + "syoku_code1"));
			setSenmonCode(0, rs.getString(getIdentifier() + "senmon_code1"));
			setLevelCode(0, rs.getString(getIdentifier() + "level_code1"));
			setSkillHani(0, rs.getString(getIdentifier() + "skill_hani1"));
			setHyokaTaisyo(0, rs.getString(getIdentifier() + "hyoka_taisyo1"));
			setSougouTDo(0, rs.getString( getIdentifier() + "sougou_t_do1" ));
			setTDoHani(0, rs.getString(getIdentifier() + "t_do_hani1"));
			setSyokuCode(1, rs.getString(getIdentifier() + "syoku_code2"));
			setSenmonCode(1, rs.getString(getIdentifier() + "senmon_code2"));
			setLevelCode(1, rs.getString(getIdentifier() + "level_code2"));
			setSkillHani(1, rs.getString(getIdentifier() + "skill_hani2"));
			setHyokaTaisyo(1, rs.getString(getIdentifier() + "hyoka_taisyo2"));
			setSougouTDo(1,  rs.getString( getIdentifier() + "sougou_t_do2" ));
			setTDoHani(1, rs.getString(getIdentifier() + "t_do_hani2"));
			setSyokuCode(2, rs.getString(getIdentifier() + "syoku_code3"));
			setSenmonCode(2, rs.getString(getIdentifier() + "senmon_code3"));
			setLevelCode(2, rs.getString(getIdentifier() + "level_code3"));
			setSkillHani(2, rs.getString(getIdentifier() + "skill_hani3"));
			setHyokaTaisyo(2, rs.getString(getIdentifier() + "hyoka_taisyo3"));
			setSougouTDo(2, rs.getString( getIdentifier() + "sougou_t_do3" ));
			setTDoHani(2, rs.getString(getIdentifier() + "t_do_hani3"));
			setTaisyosyaSimeiNo(rs.getString(getIdentifier() + "taisyosya_simei_no"));
			setSankaJyoken(rs.getString(getIdentifier() + "sanka_jyoken"));
			setKanrisyaComment(rs.getString(getIdentifier() + "kanrisya_comment"));
			setAnnounce(rs.getString(getIdentifier() + "announce"));
			setSyoriJyokyoFlg(rs.getString(getIdentifier() + "syorijyokyo_flg"));
			setForumKaisetubi(rs.getString(getIdentifier() + "forum_kaisetubi"));
			setSimeiNo(rs.getString(getIdentifier() + "simei_no"));
			setKanjiSimei(rs.getString(getIdentifier() + "kanji_simei"));
			setSyozoku(rs.getString(getIdentifier() + "syozoku"));
			setMail(rs.getString(getIdentifier() + "mail"));
			setSinseibi(rs.getString(getIdentifier() + "sinseibi"));
			setSinseijikoku(rs.getString(getIdentifier() + "sinseijikoku"));
			setKousinsya(rs.getString(getIdentifier() + "kousinsya"));
			setKousinbi(rs.getString(getIdentifier() + "kousinbi"));
			setKousinjikoku(rs.getString(getIdentifier() + "kousinjikoku"));
			setId(rs.getString(getIdentifier() + "id"));
			setRecent(rs.getString(getIdentifier() + "recent"));
			setRecentJikoku(rs.getString(getIdentifier() + "recentjikoku"));
			setCount(rs.getString(getIdentifier() + "count"));
		} catch (SQLException e) {
			Log.error("", "HJE-0001", e);
			throw e;
		}

	}

	/**
	 * ResultSet ����l���擾���ăt�H�[����ValueBean���쐬���܂��B
	 *
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param forumTableName �t�H�[�����e�[�u���̕ʖ�
	 * @param flg �����p�J�����L���t���O�itrue�F�L false�F���j
	 * @throws SQLException SQLException�����������ꍇ
	 */
	public PEA_ForumBean( ResultSet rs, String forumTableName, boolean flg )
		throws SQLException {
		super( rs, forumTableName );

		try {
			setForumId( rs.getString( getIdentifier(  ) + "forum_id" ) );
			setForumMei( rs.getString( getIdentifier(  ) + "forum_mei" ) );
			setForumGaiyo( rs.getString( getIdentifier(  ) + "forum_gaiyo" ) );
			setSankaJyokenFlg( rs.getString( getIdentifier(  ) + "sanka_jyoken_flg" ) );
			setSyokui( rs.getString( getIdentifier(  ) + "syokui" ) );
			setSyokuiHani( rs.getString( getIdentifier(  ) + "syokui_taisyo_hani" ) );
			setSyokuCode( 0, rs.getString( getIdentifier(  ) + "syoku_code1" ) );
			setSenmonCode( 0, rs.getString( getIdentifier(  ) + "senmon_code1" ) );
			setLevelCode( 0, rs.getString( getIdentifier(  ) + "level_code1" ) );
			setSkillHani( 0, rs.getString( getIdentifier(  ) + "skill_hani1" ) );
			setHyokaTaisyo( 0, rs.getString( getIdentifier(  ) + "hyoka_taisyo1" ) );
			setSougouTDo( 0, rs.getString( getIdentifier(  ) + "sougou_t_do1" ) );
			setTDoHani( 0, rs.getString( getIdentifier(  ) + "t_do_hani1" ) );
			setSyokuCode( 1, rs.getString( getIdentifier(  ) + "syoku_code2" ) );
			setSenmonCode( 1, rs.getString( getIdentifier(  ) + "senmon_code2" ) );
			setLevelCode( 1, rs.getString( getIdentifier(  ) + "level_code2" ) );
			setSkillHani( 1, rs.getString( getIdentifier(  ) + "skill_hani2" ) );
			setHyokaTaisyo( 1, rs.getString( getIdentifier(  ) + "hyoka_taisyo2" ) );
			setSougouTDo( 1, rs.getString( getIdentifier(  ) + "sougou_t_do2" ) );
			setTDoHani( 1, rs.getString( getIdentifier(  ) + "t_do_hani2" ) );
			setSyokuCode( 2, rs.getString( getIdentifier(  ) + "syoku_code3" ) );
			setSenmonCode( 2, rs.getString( getIdentifier(  ) + "senmon_code3" ) );
			setLevelCode( 2, rs.getString( getIdentifier(  ) + "level_code3" ) );
			setSkillHani( 2, rs.getString( getIdentifier(  ) + "skill_hani3" ) );
			setHyokaTaisyo( 2, rs.getString( getIdentifier(  ) + "hyoka_taisyo3" ) );
			setSougouTDo( 2, rs.getString( getIdentifier(  ) + "sougou_t_do3" ) );
			setTDoHani( 2, rs.getString( getIdentifier(  ) + "t_do_hani3" ) );
			setTaisyosyaSimeiNo( rs.getString( getIdentifier(  ) + "taisyosya_simei_no" ) );
			setSankaJyoken( rs.getString( getIdentifier(  ) + "sanka_jyoken" ) );
			setKanrisyaComment( rs.getString( getIdentifier(  ) + "kanrisya_comment" ) );
			setAnnounce( rs.getString( getIdentifier(  ) + "announce" ) );
			setSyoriJyokyoFlg( rs.getString( getIdentifier(  ) + "syorijyokyo_flg" ) );
			setForumKaisetubi( rs.getString( getIdentifier(  ) + "forum_kaisetubi" ) );
			setSimeiNo( rs.getString( getIdentifier(  ) + "simei_no" ) );
			setKanjiSimei( rs.getString( getIdentifier(  ) + "kanji_simei" ) );
			setSyozoku( rs.getString( getIdentifier(  ) + "syozoku" ) );
			setMail( rs.getString( getIdentifier(  ) + "mail" ) );
			setSinseibi( rs.getString( getIdentifier(  ) + "sinseibi" ) );
			setSinseijikoku( rs.getString( getIdentifier(  ) + "sinseijikoku" ) );
			setKousinsya( rs.getString( getIdentifier(  ) + "kousinsya" ) );
			setKousinbi( rs.getString( getIdentifier(  ) + "kousinbi" ) );
			setKousinjikoku( rs.getString( getIdentifier(  ) + "kousinjikoku" ) );

			if(flg){
				// �e�[�u���ɑ��݂��Ȃ��J�����Ȃ̂ŕK�v�ȏꍇ�̂ݐݒ�
				setId( rs.getString( getIdentifier(  ) + "id" ) );
				setRecent( rs.getString( getIdentifier(  ) + "recent" ) );
				setRecentJikoku( rs.getString( getIdentifier(  ) + "recentjikoku" ) );
				setCount( rs.getString( getIdentifier(  ) + "count" ) );
			}
		} catch ( SQLException e ) {
			Log.error( "", "HJE-0001", e );
			throw e;
		}
	}
	
	/**
	 * ServletRequest ����l���擾���ăt�H�[����ValueBean���쐬���܂��B
	 *
	 * @param request ���N�G�X�g
	 */
	public PEA_ForumBean(ServletRequest request) {
		super(request);

		setForumId(request.getParameter("forum_id"));
		setForumMei(request.getParameter("forum_mei"));
		setForumGaiyo(request.getParameter("forum_gaiyo"));
		setSankaJyokenFlg(request.getParameter("sanka_jyoken_flg"));
		setSyokui(request.getParameter("syokui"));
		setSyokuiHani(request.getParameter("syokui_taisyo_hani"));
		setSyokuCode(0, request.getParameter("syoku_code1"));
		setSenmonCode(0, request.getParameter("senmon_code1"));
		setLevelCode(0, request.getParameter("level_code1"));
		setSkillHani(0, request.getParameter("skill_hani1"));
		setHyokaTaisyo(0, request.getParameter("hyoka_taisyo1"));
		setSougouTDo(0, request.getParameter("sougou_t_do1"));
		setTDoHani(0, request.getParameter("t_do_hani1"));
		setSyokuCode(1, request.getParameter("syoku_code2"));
		setSenmonCode(1, request.getParameter("senmon_code2"));
		setLevelCode(1, request.getParameter("level_code2"));
		setSkillHani(1, request.getParameter("skill_hani2"));
		setHyokaTaisyo(1, request.getParameter("hyoka_taisyo2"));
		setSougouTDo(1, request.getParameter("sougou_t_do2"));
		setTDoHani(1, request.getParameter("t_do_hani2"));
		setSyokuCode(2, request.getParameter("syoku_code3"));
		setSenmonCode(2, request.getParameter("senmon_code3"));
		setLevelCode(2, request.getParameter("level_code3"));
		setSkillHani(2, request.getParameter("skill_hani3"));
		setHyokaTaisyo(2, request.getParameter("hyoka_taisyo3"));
		setSougouTDo(2, request.getParameter("sougou_t_do3"));
		setTDoHani(2, request.getParameter("t_do_hani3"));
		setTaisyosyaSimeiNo(request.getParameter("taisyosya_simei_no"));
		setSankaJyoken(request.getParameter("sanka_jyoken"));
		setKanrisyaComment(request.getParameter("kanrisya_comment"));
		setAnnounce(request.getParameter("announce"));
		setSyoriJyokyoFlg(request.getParameter("syorijyokyo_flg"));
		setForumKaisetubi(request.getParameter("forum_kaisetubi"));
		setSimeiNo(request.getParameter("simei_no"));
		setKanjiSimei(request.getParameter("kanji_simei"));
		setSyozoku(request.getParameter("syozoku"));
		setMail(request.getParameter("mail"));
		setSinseibi(request.getParameter("sinseibi"));
		setSinseijikoku(request.getParameter("sinseijikoku"));
		setKousinsya(request.getParameter("kousinsya"));
		setKousinbi(request.getParameter("kousinbi"));
		setKousinjikoku(request.getParameter("kousinjikoku"));
	}
	
	/**
	 * �J�����̕ʖ����`���� SQL ����Ԃ��܂��B
	 * ���̃N���X�̃R���X�g���N�^�� ResultSet �������Ƃ��ēn�����ƂŁA
	 * �f�[�^���擾�ł��܂��B
	 *
	 * @param tableName �e�[�u���̕ʖ�
	 * @return �J�����̕ʖ����`���� SQL ��
	 * @see jp.co.hisas.career.learning.base.valuebean.PCY_MasterBean#getColumns(java.lang.String)
	 */
	public static String getColumns( String tableName ) {
		if ( tableName == null ) {
			return "*";
		}

		StringBuffer ret = new StringBuffer(  );
		ret.append( tableName + ".forum_id as " + tableName + "_forum_id, " );
		ret.append( tableName + ".forum_mei as " + tableName + "_forum_mei, " );
		ret.append( tableName + ".forum_gaiyo as " + tableName + "_forum_gaiyo, " );
		ret.append( tableName + ".sanka_jyoken_flg as " + tableName + "_sanka_jyoken_flg, " );
		ret.append( tableName + ".syokui as " + tableName + "_syokui, " );
		ret.append( tableName + ".syokui_taisyo_hani as " + tableName + "_syokui_taisyo_hani, " );
		ret.append( tableName + ".syoku_code1 as " + tableName + "_syoku_code1, " );
		ret.append( tableName + ".senmon_code1 as " + tableName + "_senmon_code1, " );
		ret.append( tableName + ".level_code1 as " + tableName + "_level_code1, " );
		ret.append( tableName + ".skill_hani1 as " + tableName + "_skill_hani1, " );
		ret.append( tableName + ".hyoka_taisyo1 as " + tableName + "_hyoka_taisyo1, " );
		ret.append( tableName + ".sougou_t_do1 as " + tableName + "_sougou_t_do1, " );
		ret.append( tableName + ".t_do_hani1 as " + tableName + "_t_do_hani1, " );
		ret.append( tableName + ".syoku_code2 as " + tableName + "_syoku_code2, " );
		ret.append( tableName + ".senmon_code2 as " + tableName + "_senmon_code2, " );
		ret.append( tableName + ".level_code2 as " + tableName + "_level_code2, " );
		ret.append( tableName + ".skill_hani2 as " + tableName + "_skill_hani2, " );
		ret.append( tableName + ".hyoka_taisyo2 as " + tableName + "_hyoka_taisyo2, " );
		ret.append( tableName + ".sougou_t_do2 as " + tableName + "_sougou_t_do2, " );
		ret.append( tableName + ".t_do_hani2 as " + tableName + "_t_do_hani2, " );
		ret.append( tableName + ".syoku_code3 as " + tableName + "_syoku_code3, " );
		ret.append( tableName + ".senmon_code3 as " + tableName + "_senmon_code3, " );
		ret.append( tableName + ".level_code3 as " + tableName + "_level_code3, " );
		ret.append( tableName + ".skill_hani3 as " + tableName + "_skill_hani3, " );
		ret.append( tableName + ".hyoka_taisyo3 as " + tableName + "_hyoka_taisyo3, " );
		ret.append( tableName + ".sougou_t_do3 as " + tableName + "_sougou_t_do3, " );
		ret.append( tableName + ".t_do_hani3 as " + tableName + "_t_do_hani3, " );
		ret.append( tableName + ".taisyosya_simei_no as " + tableName + "_taisyosya_simei_no, " );
		ret.append( tableName + ".sanka_jyoken as " + tableName + "_sanka_jyoken, " );
		ret.append( tableName + ".kanrisya_comment as " + tableName + "_kanrisya_comment, " );
		ret.append( tableName + ".announce as " + tableName + "_announce, " );
		ret.append( tableName + ".syorijyokyo_flg as " + tableName + "_syorijyokyo_flg, " );
		ret.append( tableName + ".forum_kaisetubi as " + tableName + "_forum_kaisetubi, " );
		ret.append( tableName + ".simei_no as " + tableName + "_simei_no, " );
		ret.append( tableName + ".kanji_simei as " + tableName + "_kanji_simei, " );
		ret.append( tableName + ".syozoku as " + tableName + "_syozoku, " );
		ret.append( tableName + ".mail as " + tableName + "_mail, " );
		ret.append( tableName + ".sinseibi as " + tableName + "_sinseibi, " );
		ret.append( tableName + ".sinseijikoku as " + tableName + "_sinseijikoku, " );
		ret.append( tableName + ".kousinsya as " + tableName + "_kousinsya, " );
		ret.append( tableName + ".kousinbi as " + tableName + "_kousinbi, " );
		ret.append( tableName + ".kousinjikoku as " + tableName + "_kousinjikoku, " );
		return ret.toString(  ) + PEA_MasterBean.getColumns( tableName );
		
	}
	
	/**
	 * <pre>
	 * �t�H�[�����̌��������𒊏o���܂��B
	 * �ȉ��̍��ڂ����������Ƃ��Ďg�p�ł��܂��B
	 * �E�t�H�[����ID
	 * �E�t�H�[������
	 * �E�폜�t���O
	 * �E����No
	 * </pre>
	 *
	 * @return ���o���ꂽ��������
	 */
	public Map extractConditions( ) {
		Map conditions = new LinkedHashMap( );
		
		if( ( getForumId( ) != null ) && !getForumId( ).equals( "" ) ) {
			conditions.put( "FORUM_ID", getForumId() );
		}
		
		if( ( getForumMei( ) != null ) && !getForumMei( ).equals( "" ) ) {
			conditions.put( "FORUM_MEI", getForumMei() );
		}
		
		if( ( getSyoriJyokyoFlg() != null) && !getSyoriJyokyoFlg().equals( "" ) ) {
			conditions.put( "SYORIJYOKYO_FLG", getSyoriJyokyoFlg() );
		}
		
		if( ( getSimeiNo() != null) && !getSimeiNo().equals( "" ) ) {
			conditions.put( "SIMEI_NO", getSimeiNo() );
		}
		
		return conditions;
	}

	
	/* �ȉ�Getter�ESetter */

	/**
	 * @return
	 */
	public String getAnnounce() {
		return announce;
	}

	/**
	 * @return
	 */
	public String getForumGaiyo() {
		return forumGaiyo;
	}

	/**
	 * @return
	 */
	public String getForumId() {
		return forumId;
	}

	/**
	 * @return
	 */
	public String getForumKaisetubi() {
		return forumKaisetubi;
	}

	/**
	 * @return
	 */
	public String getForumMei() {
		return forumMei;
	}

	/**
	 * @return
	 */
	public String getKanjiSimei() {
		return kanjiSimei;
	}

	/**
	 * @return
	 */
	public String getKanrisyaComment() {
		return kanrisyaComment;
	}

	/**
	 * @return
	 */
	public String getKousinbi() {
		return kousinbi;
	}

	/**
	 * @return
	 */
	public String getKousinjikoku() {
		return kousinjikoku;
	}

	/**
	 * @return
	 */
	public String getKousinsya() {
		return kousinsya;
	}

	/**
	 * @return
	 */
	public String getMail() {
		return mail;
	}

	/**
	 * @return
	 */
	public String getSankaJyoken() {
		return sankaJyoken;
	}

	/**
	 * @return
	 */
	public String getSankaJyokenFlg() {
		return sankaJyokenFlg;
	}

	/**
	 * @return
	 */
	public String getSimeiNo() {
		return simeiNo;
	}

	/**
	 * @return
	 */
	public String getSinseibi() {
		return sinseibi;
	}

	/**
	 * @return
	 */
	public String getSinseijikoku() {
		return sinseijikoku;
	}

	/**
	 * @return
	 */
	public String getSyokui() {
		return syokui;
	}

	/**
	 * @return
	 */
	public String getSyokuiHani() {
		return syokuiHani;
	}

	/**
	 * @return
	 */
	public String getSyoriJyokyoFlg() {
		return syoriJyokyoFlg;
	}

	/**
	 * @return
	 */
	public String getSyozoku() {
		return syozoku;
	}

	/**
	 * @return
	 */
	public String getTaisyosyaSimeiNo() {
		return taisyosyaSimeiNo;
	}

	/**
	 * @param string
	 */
	public void setAnnounce(String string) {
		announce = string;
	}

	/**
	 * @param string
	 */
	public void setForumGaiyo(String string) {
		forumGaiyo = string;
	}

	/**
	 * @param string
	 */
	public void setForumId(String string) {
		forumId = string;
	}

	/**
	 * @param string
	 */
	public void setForumKaisetubi(String string) {
		forumKaisetubi = string;
	}

	/**
	 * @param string
	 */
	public void setForumMei(String string) {
		forumMei = string;
	}

	/**
	 * @param string
	 */
	public void setKanjiSimei(String string) {
		kanjiSimei = string;
	}

	/**
	 * @param string
	 */
	public void setKanrisyaComment(String string) {
		kanrisyaComment = string;
	}

	/**
	 * @param string
	 */
	public void setKousinbi(String string) {
		kousinbi = string;
	}

	/**
	 * @param string
	 */
	public void setKousinjikoku(String string) {
		kousinjikoku = string;
	}

	/**
	 * @param string
	 */
	public void setKousinsya(String string) {
		kousinsya = string;
	}

	/**
	 * @param string
	 */
	public void setMail(String string) {
		mail = string;
	}

	/**
	 * @param string
	 */
	public void setSankaJyoken(String string) {
		sankaJyoken = string;
	}

	/**
	 * @param string
	 */
	public void setSankaJyokenFlg(String string) {
		sankaJyokenFlg = string;
	}

	/**
	 * @param string
	 */
	public void setSimeiNo(String string) {
		simeiNo = string;
	}

	/**
	 * @param string
	 */
	public void setSinseibi(String string) {
		sinseibi = string;
	}

	/**
	 * @param string
	 */
	public void setSinseijikoku(String string) {
		sinseijikoku = string;
	}

	/**
	 * @param string
	 */
	public void setSyokui(String string) {
		syokui = string;
	}

	/**
	 * @param string
	 */
	public void setSyokuiHani(String string) {
		syokuiHani = string;
	}

	/**
	 * @param string
	 */
	public void setSyoriJyokyoFlg(String string) {
		syoriJyokyoFlg = string;
	}

	/**
	 * @param string
	 */
	public void setSyozoku(String string) {
		syozoku = string;
	}

	/**
	 * @param string
	 */
	public void setTaisyosyaSimeiNo(String string) {
		taisyosyaSimeiNo = string;
	}

	/**
	 * @return
	 */
	public String[] getHyokaTaisyoArry() {
		return hyokaTaisyoArry;
	}

	/**
	 * @return
	 */
	public String[] getLevelCodeArry() {
		return levelCodeArry;
	}

	/**
	 * @return
	 */
	public String[] getSenmonCodeArry() {
		return senmonCodeArry;
	}

	/**
	 * @return
	 */
	public String[] getSkillHaniArry() {
		return skillHaniArry;
	}

	/**
	 * @return
	 */
	public String[] getSougouTDoArry() {
		return sougouTDoArry;
	}

	/**
	 * @return
	 */
	public String[] getSyokuCodeArry() {
		return syokuCodeArry;
	}

	/**
	 * @return
	 */
	public String[] getTDoHaniArry() {
		return tDoHaniArry;
	}

	/**
	 * @param strings
	 */
	public void setHyokaTaisyoArry(String[] strings) {
		hyokaTaisyoArry = strings;
	}

	/**
	 * @param strings
	 */
	public void setLevelCodeArry(String[] strings) {
		levelCodeArry = strings;
	}

	/**
	 * @param strings
	 */
	public void setSenmonCodeArry(String[] strings) {
		senmonCodeArry = strings;
	}

	/**
	 * @param strings
	 */
	public void setSkillHaniArry(String[] strings) {
		skillHaniArry = strings;
	}

	/**
	 * @param strings
	 */
	public void setSougouTDoArry(String[] strings) {
		sougouTDoArry = strings;
	}

	/**
	 * @param strings
	 */
	public void setSyokuCodeArry(String[] strings) {
		syokuCodeArry = strings;
	}

	/**
	 * @param strings
	 */
	public void setTDoHaniArry(String[] strings) {
		tDoHaniArry = strings;
	}

	/**
	 * @param index �Y��
	 * @param val �E��R�[�h
	 */
	public void setSyokuCode(int index, String val) {
		syokuCodeArry[index] = val;
	}
	
	/**
	 * @param index �Y��
	 * @param val ���R�[�h
	 */
	public void setSenmonCode(int index, String val) {
		senmonCodeArry[index] = val;
	}

	/**
	 * @param index �Y��
	 * @param val ���x���R�[�h
	 */
	public void setLevelCode(int index, String val) {
		levelCodeArry[index] = val;
	}

	/**
	 * @param index �Y��
	 * @param val �X�L���X�^���_�[�h����͈� 0�F�ȏ� 1�F���� 2�F�ȉ�
	 */
	public void setSkillHani(int index, String val) {
		skillHaniArry[index] = val;
	}

	/**
	 * @param index �Y��
	 * @param val �]���Ώ� 0�F���ȕ]�� 1�F�]���ҕ]��
	 */
	public void setHyokaTaisyo(int index, String val) {
		hyokaTaisyoArry[index] = val;
	}

	/**
	 * @param index �Y��
	 * @param val �����B���x
	 */
	public void setSougouTDo(int index, String val) {
		sougouTDoArry[index] = val;
	}
	
	/**
	 * @param index �Y��
	 * @param val �B���x�͈� 0�F�ȏ� 1�F���� 2�F�ȉ�
	 */
	public void setTDoHani(int index, String val) {
		tDoHaniArry[index] = val;
	}

	/**
	 * @param index �Y��
	 * @return �E��R�[�h
	 */
	public String getSyokuCode(int index) {
		return syokuCodeArry[index];
	}
	
	/**
	 * @param index �Y��
	 * @return ���R�[�h
	 */
	public String getSenmonCode(int index) {
		return senmonCodeArry[index];
	}

	/**
	 * @param index �Y��
	 * @return ���x���R�[�h
	 */
	public String getLevelCode(int index) {
		return levelCodeArry[index];
	}

	/**
	 * @param index �Y��
	 * @return �X�L���X�^���_�[�h����͈� 0�F�ȏ� 1�F���� 2�F�ȉ�
	 */
	public String getSkillHani(int index) {
		return skillHaniArry[index];
	}

	/**
	 * @param index �Y��
	 * @return �]���Ώ� 0�F���ȕ]�� 1�F�]���ҕ]��
	 */
	public String getHyokaTaisyo(int index) {
		return hyokaTaisyoArry[index];
	}

	/**
	 * @param index �Y��
	 * @return �����B���x
	 */
	public String getSougouTDo(int index) {
		return sougouTDoArry[index];
	}
	
	/**
	 * @param index �Y��
	 * @return �B���x�͈� 0�F�ȏ� 1�F���� 2�F�ȉ�
	 */
	public String getTDoHani(int index) {
		return tDoHaniArry[index];
	}


	/**
	 * @return
	 */
	public String getCount() {
		return count;
	}

	/**
	 * @return
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return
	 */
	public String getRecent() {
		return recent;
	}

	/**
	 * @param string
	 */
	public void setCount(String string) {
		count = string;
	}

	/**
	 * @param string
	 */
	public void setId(String string) {
		id = string;
	}

	/**
	 * @param string
	 */
	public void setRecent(String string) {
		recent = string;
	}

	/**
	 * @return
	 */
	public String getNotKeep() {
		return notKeep;
	}

	/**
	 * @return
	 */
	public String getPermission() {
		return permission;
	}

	/**
	 * @param string
	 */
	public void setNotKeep(String string) {
		notKeep = string;
	}

	/**
	 * @param string
	 */
	public void setPermission(String string) {
		permission = string;
	}

	/**
	 * @return
	 */
	public String getRecentJikoku() {
		return recentJikoku;
	}

	/**
	 * @param string
	 */
	public void setRecentJikoku(String string) {
		recentJikoku = string;
	}

}
	