/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/04/24  01.00      ���� ����    �V�K�쐬
 *   2005/11/04             ���Y �T��    ��u�t�H���[���[���p�̃��\�b�h�ǉ� B-A30AM1-009
 */
package jp.co.hisas.career.learning.base.ejb;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;

import java.rmi.RemoteException;

import java.sql.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.NamingException;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_JyukousyaKanriEJBBean�N���X
 *
 * �@�\�����F
 *   �Ȗځ^�N���X�̎�u�Ώێ҂��Ǘ�����B
 *
 *</PRE>
 * @ejb.bean
 *   name="PCY_JyukousyaKanriEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PCY_JyukousyaKanriEJBBean implements SessionBean {
    private SessionContext context = null;

    /**
     * ����u�҂̈ꗗ���������܂��B
     *
     * @param classBean �N���X���B�ȖڃR�[�h�ƃN���X�R�[�h���g�p���܂��B
     * @param loginuser ���O�C�����[�U�B
     * @throws NamingException ���O������O
     * @throws RemoteException �����[�g��O
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_PersonalBean[] getMijyukosyaList( PCY_ClassBean classBean, PCY_PersonalBean loginuser )
        throws NamingException, RemoteException, PCY_WarningException {
        String login_no = "";

        if ( loginuser != null ) {
            login_no = loginuser.getSimeiNo(  );
        }

        Log.method( login_no, "IN", "" );

        Connection con                        = null;
        PreparedStatement dutyStudentSqlPs    = null;
        PreparedStatement queryRirekiSqlPs    = null;
        PreparedStatement queryMousikomiSqlPs = null;

        try {
            //�R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            //��u�K�{�ґI��SQL����������
            String dutyStudentSql = "SELECT " + PCY_PersonalBean.getColumns( "PERSONAL" )
                + " FROM T01_PERSONAL_TBL PERSONAL" + " WHERE GENSYOKU_TAISYOKU_FLG='1' AND HONMU_FLG='1' " + " AND ("
                + " SIMEI_NO NOT IN"
                + " (SELECT SIMEI_NO FROM L14_TAISYOSYA_TBL WHERE KAMOKU_CODE=? AND CLASS_CODE=? AND TAISYO_KUBUN IN ('1', '2'))"
                + " ) AND (" + " SOSIKI_CODE IN"
                + " (SELECT SOSIKI_CODE FROM L13_TAISYOSOSIKI_TBL WHERE KAMOKU_CODE=? AND CLASS_CODE=? AND TAISYO_KUBUN='0')" //CHG#BPX-0301J-1034
                + " OR (" + " SYOKU_CODE1 IN"
                + " (SELECT SYOKU_CODE FROM L12_TAISYOSYOKUSYU_TBL WHERE KAMOKU_CODE=? AND CLASS_CODE=? AND TAISYO_KUBUN='0')"
                + " AND (SENMON_CODE1 IN"
                + " (SELECT SENMON_CODE FROM L12_TAISYOSYOKUSYU_TBL WHERE KAMOKU_CODE=? AND CLASS_CODE=? AND TAISYO_KUBUN='0')"
                + " OR SENMON_CODE1 IS NULL)" + " AND (LEVEL_CODE1 IN"
                + " (SELECT LEVEL_CODE FROM L12_TAISYOSYOKUSYU_TBL WHERE KAMOKU_CODE=? AND CLASS_CODE=? AND TAISYO_KUBUN='0')"
                + " OR LEVEL_CODE1 IS NULL)" + " ) OR (" + " SYOKU_CODE2 IN"
                + " (SELECT SYOKU_CODE FROM L12_TAISYOSYOKUSYU_TBL WHERE KAMOKU_CODE=? AND CLASS_CODE=? AND TAISYO_KUBUN='0')"
                + " AND (SENMON_CODE2 IN"
                + " (SELECT SENMON_CODE FROM L12_TAISYOSYOKUSYU_TBL WHERE KAMOKU_CODE=? AND CLASS_CODE=? AND TAISYO_KUBUN='0')"
                + " OR SENMON_CODE2 IS NULL)" + " AND (LEVEL_CODE2 IN"
                + " (SELECT LEVEL_CODE FROM L12_TAISYOSYOKUSYU_TBL WHERE KAMOKU_CODE=? AND CLASS_CODE=? AND TAISYO_KUBUN='0')"
                + " OR LEVEL_CODE2 IS NULL)" + " ) OR (" + " SYOKU_CODE3 IN"
                + " (SELECT SYOKU_CODE FROM L12_TAISYOSYOKUSYU_TBL WHERE KAMOKU_CODE=? AND CLASS_CODE=? AND TAISYO_KUBUN='0')"
                + " AND (SENMON_CODE3 IN"
                + " (SELECT SENMON_CODE FROM L12_TAISYOSYOKUSYU_TBL WHERE KAMOKU_CODE=? AND CLASS_CODE=? AND TAISYO_KUBUN='0')"
                + " OR SENMON_CODE3 IS NULL)" + " AND (LEVEL_CODE3 IN"
                + " (SELECT LEVEL_CODE FROM L12_TAISYOSYOKUSYU_TBL WHERE KAMOKU_CODE=? AND CLASS_CODE=? AND TAISYO_KUBUN='0')"
                + " OR LEVEL_CODE3 IS NULL)" + " ) OR" + " SIMEI_NO IN"
                + " (SELECT SIMEI_NO FROM L14_TAISYOSYA_TBL WHERE KAMOKU_CODE=? AND CLASS_CODE=? AND TAISYO_KUBUN='0')"
                + " )";
            dutyStudentSqlPs = con.prepareStatement( dutyStudentSql );

            //���猤�C������SQL����������
            String queryRirekiSql = "SELECT COUNT(*) AS RIREKI_COUNT FROM L51_KYOIKU_TBL"
                + " WHERE SIMEI_NO=? AND KAMOKU_CODE=? AND CLASS_CODE=?";
            queryRirekiSqlPs = con.prepareStatement( queryRirekiSql );

            //�\���󋵃e�[�u������SQL����������
            String queryMousikomiSql =
                "SELECT COUNT(*) AS MOUSIKOMI_COUNT FROM L15_MOUSIKOMI_JYOKYO_TBL"
                + " WHERE SIMEI_NO=? AND KAMOKU_CODE=? AND CLASS_CODE=?";
            queryMousikomiSqlPs = con.prepareStatement( queryMousikomiSql );

            String kamokuCode = classBean.getKamokuBean(  ).getKamokuCode(  );
            String classCode  = classBean.getClassCode(  );

            dutyStudentSqlPs.setString( 1, kamokuCode );
            dutyStudentSqlPs.setString( 2, classCode );
            dutyStudentSqlPs.setString( 3, kamokuCode );
            dutyStudentSqlPs.setString( 4, classCode );
            dutyStudentSqlPs.setString( 5, kamokuCode );
            dutyStudentSqlPs.setString( 6, classCode );
            dutyStudentSqlPs.setString( 7, kamokuCode );
            dutyStudentSqlPs.setString( 8, classCode );
            dutyStudentSqlPs.setString( 9, kamokuCode );
            dutyStudentSqlPs.setString( 10, classCode );
            dutyStudentSqlPs.setString( 11, kamokuCode );
            dutyStudentSqlPs.setString( 12, classCode );
            dutyStudentSqlPs.setString( 13, kamokuCode );
            dutyStudentSqlPs.setString( 14, classCode );
            dutyStudentSqlPs.setString( 15, kamokuCode );
            dutyStudentSqlPs.setString( 16, classCode );
            dutyStudentSqlPs.setString( 17, kamokuCode );
            dutyStudentSqlPs.setString( 18, classCode );
            dutyStudentSqlPs.setString( 19, kamokuCode );
            dutyStudentSqlPs.setString( 20, classCode );
            dutyStudentSqlPs.setString( 21, kamokuCode );
            dutyStudentSqlPs.setString( 22, classCode );
            dutyStudentSqlPs.setString( 23, kamokuCode );
            dutyStudentSqlPs.setString( 24, classCode );

            //�p�[�\�i���v���t�@�C���E�ΏېE��E�Ώۑg�D�E�Ώێ҃e�[�u������
            //��u���K�{�ł���҂���������
            ResultSet personalRs = dutyStudentSqlPs.executeQuery(  );

            //���u�҃��X�g
            List notAttendList = new ArrayList(  );

            try {
                while ( personalRs.next(  ) ) {
                    String simei_no = personalRs.getString( "PERSONAL_SIMEI_NO" );

                    queryRirekiSqlPs.setString( 1, simei_no );
                    queryRirekiSqlPs.setString( 2, kamokuCode );
                    queryRirekiSqlPs.setString( 3, classCode );

                    //���猤�C���e�[�u�����������A��u�ς݂ł��邩���肷��
                    ResultSet rs = queryRirekiSqlPs.executeQuery(  );

                    try {
                        int count = -1;

                        if ( rs.next(  ) ) {
                            count = rs.getInt( "RIREKI_COUNT" );
                        } else {
                            context.setRollbackOnly(  );
                            throw new PCY_WarningException(  );
                        }

                        if ( count > 0 ) {
                            //��u�ς݂Ɣ��肷��
                            continue;
                        }
                    } finally {
                        rs.close(  );
                    }

                    queryMousikomiSqlPs.setString( 1, simei_no );
                    queryMousikomiSqlPs.setString( 2, kamokuCode );
                    queryMousikomiSqlPs.setString( 3, classCode );

                    //�\���󋵃e�[�u�����������A��u�ς݂ł��邩���肷��
                    rs = queryMousikomiSqlPs.executeQuery(  );

                    try {
                        int count = -1;

                        if ( rs.next(  ) ) {
                            count = rs.getInt( "MOUSIKOMI_COUNT" );
                        } else {
                            context.setRollbackOnly(  );
                            throw new PCY_WarningException(  );
                        }

                        if ( count > 0 ) {
                            //��u�ς݂Ɣ��肷��
                            continue;
                        }
                    } finally {
                        rs.close(  );
                    }

                    //��u���Ă��Ȃ��Ɣ��肷��
                    PCY_PersonalBean personalBean = new PCY_PersonalBean( personalRs, "PERSONAL" );
                    notAttendList.add( personalBean );
                }
            } finally {
                personalRs.close(  );
            }

            PCY_PersonalBean[] notAttendPersonalBeans = new PCY_PersonalBean[notAttendList.size(  )];
            notAttendList.toArray( notAttendPersonalBeans );

            Log.method( login_no, "OUT", "" );

            return notAttendPersonalBeans;
        } catch ( SQLException e ) {
            Log.error( "", "HJE-0001", e );
            throw new EJBException( e );
        } finally {
            try {
                if ( dutyStudentSqlPs != null ) {
                    dutyStudentSqlPs.close(  );
                }

                if ( queryRirekiSqlPs != null ) {
                    queryRirekiSqlPs.close(  );
                }

                if ( queryMousikomiSqlPs != null ) {
                    queryMousikomiSqlPs.close(  );
                }
            } catch ( SQLException e ) {
                //�������Ȃ�
            } finally {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    //�������Ȃ�
                }
            }
        }
    }

    // INS#P-A30AM1-009-002-S
    /**
     * ��t�ςŎ�u�ςłȂ����C�҂̈ꗗ���������܂��B
     *
     * @param classBean �N���X���B�ȖڃR�[�h�ƃN���X�R�[�h���g�p���܂��B
     * @param loginuser ���O�C�����[�U�B
     * @throws NamingException ���O������O
     * @throws RemoteException �����[�g��O
     * @throws PCY_WarningException �x����O
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_PersonalBean[] getFollowList( PCY_ClassBean classBean, PCY_PersonalBean loginuser )
        throws NamingException, RemoteException, PCY_WarningException {

        String login_no = "";

        if ( loginuser != null ) {
            login_no = loginuser.getSimeiNo(  );
        }

        Log.method( login_no, "IN", "" );

        Connection con = null;
        PreparedStatement ps = null;

        try {
            /* �R�l�N�V�����擾 */
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con = locator.getDataSource(  ).getConnection(  );

            /* ��t�ςŎ�u�ρi����ҁA���C�ρj�łȂ����C�҂̒��o */
            String sql = "SELECT " + PCY_PersonalBean.getColumns( "T01" )
                + " FROM T01_PERSONAL_TBL T01 WHERE GENSYOKU_TAISYOKU_FLG = '1' AND HONMU_FLG = '1'"
                + " AND ( SIMEI_NO IN"
                + " ( SELECT SIMEI_NO FROM L15_MOUSIKOMI_JYOKYO_TBL WHERE KAMOKU_CODE = ? AND CLASS_CODE = ? AND"
                + " ( ( STATUS = '1' AND ( UKETSUKE_JYOTAI = '2' OR UKETSUKE_JYOTAI = '3' OR UKETSUKE_JYOTAI = '4' ) )"
                + " OR STATUS = '2' ) ) )";
                
            ps = con.prepareStatement( sql );

            String kamokuCode = classBean.getKamokuBean(  ).getKamokuCode(  );
            String classCode  = classBean.getClassCode(  );

            ps.setString( 1, kamokuCode );
            ps.setString( 2, classCode );

            /* SQL���s */
            ResultSet rs = ps.executeQuery(  );

            /* �t�H���[���[�����M�Ώێ҃��X�g */
            ArrayList list = new ArrayList(  );

            try {
                while ( rs.next(  ) ) {
                    PCY_PersonalBean personalBean = new PCY_PersonalBean( rs, "T01" );
                    list.add( personalBean );
                }
            } finally {
                rs.close(  );
            }

            PCY_PersonalBean[] followPersonalBeans = new PCY_PersonalBean[ list.size() ];
            list.toArray( followPersonalBeans );

            Log.method( login_no, "OUT", "" );

            return followPersonalBeans;
            
        } catch ( SQLException e ) {
            Log.error( "", "HJE-0001", e );
            throw new EJBException( e );
        } finally {
            try {
                if ( ps != null ) {
                    ps.close(  );
                }
            } catch ( SQLException e ) {
                //�������Ȃ�
            } finally {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    //�������Ȃ�
                }
            }
        }
    }
    // INS#P-A30AM1-009-002-E

    /**
     * �������Ȃ��B
     * @exception  RemoteException
     */
    public void ejbActivate(  ) throws RemoteException {
    }

    /**
     * �������Ȃ��B
     * @exception  CreateException
     * @exception  RemoteException
     */
    public void ejbCreate(  ) throws CreateException, RemoteException {
    }

    /**
     * �������Ȃ��B
     * @exception  RemoteException
     */
    public void ejbPassivate(  ) throws RemoteException {
    }

    /**
     * �������Ȃ��B
     * @exception  RemoteException
     */
    public void ejbRemove(  ) throws RemoteException {
    }

    /**
     * SessionContext�����擾����B
     * @return  SessionContext���
     */
    public SessionContext getSessionContext(  ) {
        return context;
    }

    /**
     * EJB�R���e�i���Ǘ�����SessionContext����SessionBean�ɓn���BSessionBean�̍쐬���ɌĂяo�����B
     * @param  context   SessionContext���
     * @exception  RemoteException
     */
    public void setSessionContext( SessionContext context )
        throws RemoteException {
        this.context = context;
    }
}
