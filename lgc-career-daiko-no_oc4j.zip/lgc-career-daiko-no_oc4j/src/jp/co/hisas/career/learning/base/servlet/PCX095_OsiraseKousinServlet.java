/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O            ���e
 *   2005/01/25  01.00       ��ԁ@�ӎ�      �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.hisas.career.learning.base.PCY_ServiceLocator;
import jp.co.hisas.career.learning.base.ejb.PCY_OsiraseEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_OsiraseEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_OsiraseBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.learning.base.PCY_WarningException;


/**
 *<PRE>
 *
 * �N���X���F
 *   ���m�点���T�[�u���b�g�N���X
 *
 * �@�\�����F
 *   ���m�点�e�[�u�����f�[�^���X�V����
 *
 *</PRE>
 */
public class PCX095_OsiraseKousinServlet extends PCY010_ControllerServlet {
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PCY_PersonalBean loginuser ) throws NamingException, CreateException, RemoteException,PCY_WarningException {

        /*���\�b�h�g���[�X�o��*/
        Log.method( "", "IN", "" );

        PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );

        PCY_OsiraseEJBHome home = ( PCY_OsiraseEJBHome )locator.getServiceLocation( "PCY_OsiraseEJB",
                PCY_OsiraseEJBHome.class );

        PCY_OsiraseEJB ejb = ( PCY_OsiraseEJB )home.create(  );

		/* �X�V�f�[�^���i�[���� */
		PCY_OsiraseBean osiraseBeans = new PCY_OsiraseBean();
		
		String editNo = request.getParameter( "editNo" );
		osiraseBeans.setHakkoubi( request.getParameter( "hiduke_"+ editNo ) );
		osiraseBeans.setHakkoujikoku( request.getParameter( "syori_jikan_" + editNo ) );
		osiraseBeans.setSyubetsuFlg( request.getParameter( "syubetu_" + editNo) );
		osiraseBeans.setKigenbi( request.getParameter( "kigen_" + editNo) );
		osiraseBeans.setNaiyou( request.getParameter( "HTMLcomment_" + editNo) );
		osiraseBeans.setTsuutatsu_page( request.getParameter( "tuutatu_" + editNo) );
		osiraseBeans.setHyoujiFlg( request.getParameter( "hyoji_flag_" + editNo) );
		osiraseBeans.setseqNo(request.getParameter( "seqNo_" + editNo));
		osiraseBeans.setKousinbi(request.getParameter( "kousinbi_" + editNo));
		osiraseBeans.setKousinjikoku(request.getParameter( "kousinjikoku_" + editNo));
		
		/*HTMLcomment���擾���A�G���R�[�h���ݒ肵�܂��B*/
		try {
			String comment = request.getParameter( "HTMLcomment_" + editNo );
			String encComment;
			encComment = new String(comment.getBytes("iso-8859-1"), "Shift_JIS");
			osiraseBeans.setNaiyou(encComment);
			
			String tuutatu = request.getParameter( "tuutatu_" + editNo );
			String encTuutatu = new String(tuutatu.getBytes("iso-8859-1"), "Shift_JIS");
			osiraseBeans.setTsuutatsu_page( encTuutatu );
			
		} catch (UnsupportedEncodingException e) {
			request.setAttribute( "warningID", "WCX070" );
			PCY_WarningException ex = new PCY_WarningException( e );
			throw ex;
		}
	
		/* �f�[�^���X�V���� */
        
		try {
			int count = ejb.doUpdate( osiraseBeans, loginuser );
		} catch ( PCY_WarningException e ) {
			request.setAttribute( "warningID", "WCX070" );
			throw e;
		}
		
        request.setAttribute( "osiraseBeans", osiraseBeans );

        /*���\�b�h�g���[�X�o��*/
        Log.method( "", "OUT", "" );

        return getForwardPath(  );
    }
}
