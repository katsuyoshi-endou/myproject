/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/03/17  01.00       ���� ��F    �V�K�쐬
 *   2005/12/03              �Β� �[      �A���P�[�g�e���v���[�g�擾�ɑΉ�
 */
package jp.co.hisas.career.learning.base.servlet;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;

import java.rmi.*;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.ejb.*;

import javax.naming.*;

import javax.servlet.http.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY401_DefaultSetteiKousinServlet �N���X
 *
 * �@�\�����F
 *   �f�t�H���g�ݒ�̍X�V���s���܂��B
 *
 *</PRE>
 */
public class PCY401_DefaultSetteiKousinServlet extends PCY010_ControllerServlet {
    /**
     * ���N�G�X�g����擾���A�f�t�H���g�ݒ���X�V���܂��B
     *
     * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(
     *          javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
     *          jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean
     *      )
     */
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PCY_PersonalBean loginuser )
        throws NamingException, CreateException, RemoteException, PCY_WarningException ,SQLException , Exception {
        /*���\�b�h�g���[�X�o��*/
        Log.method( loginuser.getSimeiNo(  ), "IN", "" );

		PCY_DefaultBean defaultBean = new PCY_DefaultBean( request );

        PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
        PCY_UserDefaultEJBHome home      = ( PCY_UserDefaultEJBHome )locator.getServiceLocation( "PCY_UserDefaultEJB",
                PCY_UserDefaultEJBHome.class );
        PCY_UserDefaultEJB ejb           = home.create(  );

		try {

			Log.transaction( loginuser.getSimeiNo(  ), true, "" );

			//���݂̃��O�C�����[�U�[�̏����J�E���g
			PCY_DefaultBean[] countUserDefault = ejb.doSelect( loginuser.getSimeiNo(  ) , loginuser );

			//���݂̃��O�C�����[�U�[�̏�񂪂���΍폜
			if ( countUserDefault != null && countUserDefault.length > 0){
				ejb.doDelete( loginuser.getSimeiNo(  ) , loginuser );
			}

			//���݂̃��O�C�����[�U�[�̏���ǉ�

			ArrayList ret = new ArrayList(  );

			//��ʖ��̏����eBean�ɐݒ�
			//�����C�Ǘ������
			//���{�`��
			if ( defaultBean.getCategoryCode1() != null && !defaultBean.getCategoryCode1().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC010" );
				UserDefaultBean.setKoumokuId( "1" );
				UserDefaultBean.setDefaultValue( defaultBean.getCategoryCode1() );
				ret.add( UserDefaultBean );
			}
			//����^�Վ�
			if ( defaultBean.getCategoryCode2() != null && !defaultBean.getCategoryCode2().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC010" );
				UserDefaultBean.setKoumokuId( "2" );
				UserDefaultBean.setDefaultValue( defaultBean.getCategoryCode2() );
				ret.add( UserDefaultBean );
			}
			//�\�[�g
			if ( defaultBean.getSort() != null && !defaultBean.getSort().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC010" );
				UserDefaultBean.setKoumokuId( "3" );
				UserDefaultBean.setDefaultValue( defaultBean.getSort() );
				ret.add( UserDefaultBean );
			}
			//�Ȗڕ��ނR
			if ( defaultBean.getCategoryCode3() != null && !defaultBean.getCategoryCode3().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC010" );
				UserDefaultBean.setKoumokuId( "4" );
				UserDefaultBean.setDefaultValue( defaultBean.getCategoryCode3() );
				ret.add( UserDefaultBean );
			}
			//�n��
			if ( defaultBean.getChikuCode() != null && !defaultBean.getChikuCode().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC010" );
				UserDefaultBean.setKoumokuId( "5" );
				UserDefaultBean.setDefaultValue( defaultBean.getChikuCode() );
				ret.add( UserDefaultBean );
			}
			//�Ǘ���
			if ( defaultBean.getKanrimotoCode() != null && !defaultBean.getKanrimotoCode().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC010" );
				UserDefaultBean.setKoumokuId( "6" );
				UserDefaultBean.setDefaultValue( defaultBean.getKanrimotoCode() );
				ret.add( UserDefaultBean );
			}
			//�����ꊇ
			if ( defaultBean.getKisyoIkkatsuFlg() != null && !defaultBean.getKisyoIkkatsuFlg().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC010" );
				UserDefaultBean.setKoumokuId( "7" );
				UserDefaultBean.setDefaultValue( defaultBean.getKisyoIkkatsuFlg() );
				ret.add( UserDefaultBean );
			}

			//�����ѓ��͉��
			//��_
			if ( defaultBean.getKijyunten() != null && !defaultBean.getKijyunten().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC070" );
				UserDefaultBean.setKoumokuId( "1" );
				UserDefaultBean.setDefaultValue( defaultBean.getKijyunten() );
				ret.add( UserDefaultBean );
			}
			//�C������
			if ( defaultBean.getSyuryoHantei() != null && !defaultBean.getSyuryoHantei().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC070" );
				UserDefaultBean.setKoumokuId( "2" );
				UserDefaultBean.setDefaultValue( defaultBean.getSyuryoHantei() );
				ret.add( UserDefaultBean );
			}

			//���Ȗړo�^��� 
			//�Ǘ���
			if ( defaultBean.getKamokuKanrimotoCode() != null && !defaultBean.getKamokuKanrimotoCode().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC080" );
				UserDefaultBean.setKoumokuId( "1" );
				UserDefaultBean.setDefaultValue( defaultBean.getKamokuKanrimotoCode() );
				ret.add( UserDefaultBean );
			}
			//���{�`��
			if ( defaultBean.getKamokuCategoryCode1() != null && !defaultBean.getKamokuCategoryCode1().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC080" );
				UserDefaultBean.setKoumokuId( "2" );
				UserDefaultBean.setDefaultValue( defaultBean.getKamokuCategoryCode1() );
				ret.add( UserDefaultBean );
			}
			//����^�Վ�
			if ( defaultBean.getKamokuCategoryCode2() != null && !defaultBean.getKamokuCategoryCode2().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC080" );
				UserDefaultBean.setKoumokuId( "3" );
				UserDefaultBean.setDefaultValue( defaultBean.getKamokuCategoryCode2() );
				ret.add( UserDefaultBean );
			}
			//�Ȗڕ��ނR
			if ( defaultBean.getKamokuCategoryCode3() != null && !defaultBean.getKamokuCategoryCode3().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC080" );
				UserDefaultBean.setKoumokuId( "4" );
				UserDefaultBean.setDefaultValue( defaultBean.getKamokuCategoryCode3() );
				ret.add( UserDefaultBean );
			}
    
			//���N���X�o�^���
			//�N���X�R�[�h
			if ( defaultBean.getClassClassCode() != null && !defaultBean.getClassClassCode().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "1" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassClassCode() );
				ret.add( UserDefaultBean );
			}
			//�\���敪
			if ( defaultBean.getClassMousikomiKubun() != null && !defaultBean.getClassMousikomiKubun().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "2" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassMousikomiKubun() );
				ret.add( UserDefaultBean );
			}
			//���F�敪
			if ( defaultBean.getClassSyoninKubun() != null && !defaultBean.getClassSyoninKubun().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "3" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassSyoninKubun() );
				ret.add( UserDefaultBean );
			}
			//��t�敪
			if ( defaultBean.getClassUketukeKubun() != null && !defaultBean.getClassUketukeKubun().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "4" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassUketukeKubun() );
				ret.add( UserDefaultBean );
			}
			//�񍐋敪
			if ( defaultBean.getClassHoukokuKubun() != null && !defaultBean.getClassHoukokuKubun().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "5" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassHoukokuKubun() );
				ret.add( UserDefaultBean );
			}
			//����敪
			if ( defaultBean.getClassHanteiKubun() != null && !defaultBean.getClassHanteiKubun().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "6" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassHanteiKubun() );
				ret.add( UserDefaultBean );
			}
			//�����ꊇ
			if ( defaultBean.getClassKisyoIkkatsuFlg() != null && !defaultBean.getClassKisyoIkkatsuFlg().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "7" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassKisyoIkkatsuFlg() );
				ret.add( UserDefaultBean );
			}
			//�S��
			if ( defaultBean.getClassZensyaTaisyoFlg() != null && !defaultBean.getClassZensyaTaisyoFlg().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "8" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassZensyaTaisyoFlg() );
				ret.add( UserDefaultBean );
			}
			//����
			if ( defaultBean.getClassMansekiFlg() != null && !defaultBean.getClassMansekiFlg().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "9" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassMansekiFlg() );
				ret.add( UserDefaultBean );
			}
			//�n��
			if ( defaultBean.getClassChikuCode() != null && !defaultBean.getClassChikuCode().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "10" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassChikuCode() );
				ret.add( UserDefaultBean );
			}
			//�u�t
			if ( defaultBean.getClassKousiCode() != null && !defaultBean.getClassKousiCode().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "11" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassKousiCode() );
				ret.add( UserDefaultBean );
			}
			//����
			if ( defaultBean.getClassKyosituCode() != null && !defaultBean.getClassKyosituCode().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "12" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassKyosituCode() );
				ret.add( UserDefaultBean );
			}
			//�ē����[��
			if ( defaultBean.getClassAnnaiMailKubun() != null && !defaultBean.getClassAnnaiMailKubun().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "13" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassAnnaiMailKubun() );
				ret.add( UserDefaultBean );
			}
			//�t�H���[���[��
			if ( defaultBean.getClassFollowMailKubun() != null && !defaultBean.getClassFollowMailKubun().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "14" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassFollowMailKubun() );
				ret.add( UserDefaultBean );
			}
			//INS#B-A30AM2-007 -S
			//�t�H���[�񍐋敪
			if ( defaultBean.getClassHoukokuKubun2() != null && !defaultBean.getClassHoukokuKubun2().equals("") ){
				PCY_DefaultBean UserDefaultBean = new PCY_DefaultBean();
				UserDefaultBean.setGamenId( "VCC090" );
				UserDefaultBean.setKoumokuId( "15" );
				UserDefaultBean.setDefaultValue( defaultBean.getClassHoukokuKubun2() );
				ret.add( UserDefaultBean );
			}
			//INS#B-A30AM2-007 -E

			PCY_DefaultBean[] UserDefaultBeans = ( PCY_DefaultBean[] )ret.toArray( new PCY_DefaultBean[0] );

			//����No�ݒ�
			for ( int i = 0; i < UserDefaultBeans.length; i++ ) {
				UserDefaultBeans[i].setSimeiNo( loginuser.getSimeiNo(  ) );
			}

			ejb.doInsert( UserDefaultBeans , loginuser );
			Log.transaction( loginuser.getSimeiNo(  ), false, "" );

			request.setAttribute( "defaultBean", defaultBean );

		} catch ( NamingException e ) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw e;
		} catch ( RemoteException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} catch ( PCY_WarningException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} catch ( SQLException e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		} catch ( Exception e ) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		}

		/*���\�b�h�g���[�X�o��*/
		Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

        return getForwardPath(  );
    }
}
