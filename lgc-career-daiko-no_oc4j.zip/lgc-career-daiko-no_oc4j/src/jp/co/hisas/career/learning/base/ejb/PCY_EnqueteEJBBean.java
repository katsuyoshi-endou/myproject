/*
* All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
*
* �v���W�F�N�g���@�F
*   ���V�e�ACareer
*
* ���l�@�F
*   �Ȃ�
*
* �����@�F
*   ���t        �o�[�W����  ���O         ���e
*   2005/12/03              �Β� �[     �V�K�쐬
*/
package jp.co.hisas.career.learning.base.ejb;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.bean.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.common.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.rmi.*;

import java.sql.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_EnqueteEJBBean�N���X
 *
 * �@�\�����F
 *   �A���P�[�g�e�[�u���ւ̑�����s���܂��B
 *
 *</PRE>
 *
 * @ejb.bean
 *   name="PCY_EnqueteEJB"
 *   type="Stateless"
 *   transaction-type="Container"
 *   view-type="remote"
 *
 * @ejb.resource-ref
 *   res-ref-name="jdbc/HCDB"
 *   res-type="javax.sql.DataSource"
 *   res-auth="Container"
 */
public class PCY_EnqueteEJBBean implements SessionBean {
    private SessionContext context = null;

    /**
     * �A���P�[�g�����擾���܂��B
     *
     * @param kaitouBean ��������
     * @param loginuser ���O�C�����[�U
     * @return ��������
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public PCY_EnqueteKaitouBean getEnqueteKaitou( PCY_EnqueteKaitouBean kaitouBean, PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            PCY_EnqueteKaitouBean ret = new PCY_EnqueteKaitouBean( );
            
            //SELECT���擾
            String sql = kaitouBean.getSelectSql();
            
            //�R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );
            
            //�������s
            ps = con.prepareStatement( sql );
            ps.setString( 1, kaitouBean.getKamokuCode() );
            ps.setString( 2, kaitouBean.getClassCode() );
            ps.setString( 3, kaitouBean.getSimeiNo() );
            
            ResultSet rs = ps.executeQuery( );
            
            if ( rs.next(  ) ) {
            	ret = new PCY_EnqueteKaitouBean( rs );
            }
            
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return ret;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �A���P�[�g�����擾���܂��B
     *
     * @param kaitouBean ��������
     * @param loginuser ���O�C�����[�U
     * @return ��������
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int countEnqueteKaitou( PCY_EnqueteKaitouBean kaitouBean, PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );

            //SELECT���擾
            String asCnt = "ENQ_CNT";
            String sql = kaitouBean.getCountSql( asCnt );
            
            //�R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );
            
            //�������s
            ps = con.prepareStatement( sql );
            ps.setString( 1, kaitouBean.getKamokuCode() );
            ps.setString( 2, kaitouBean.getClassCode() );
            ps.setString( 3, kaitouBean.getSimeiNo() );
            
            ResultSet rs = ps.executeQuery( );
            
            int count = 0;
            if ( rs.next(  ) ) {
            	count = rs.getInt(asCnt);
            }
            
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return count;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }
    
    /**
     * �A���P�[�g����o�^���܂��B
     *
     * @param kaitouBean �o�^����
     * @param loginuser ���O�C�����[�U
     * @return �o�^����
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int insertEnqueteKaitou( PCY_EnqueteKaitouBean kaitouBean, PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );
            
            //SELECT���擾
            String sql = kaitouBean.getInsertSql();
            
            //�R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );
            
            //�o�^���s
            ps = con.prepareStatement( sql );
            ps.setString( 1, kaitouBean.getKamokuCode() );
            ps.setString( 2, kaitouBean.getClassCode() );
            ps.setString( 3, kaitouBean.getSimeiNo() );
            ps.setString( 4, kaitouBean.getKaitou1() );
            ps.setString( 5, kaitouBean.getKaitou2() );
            ps.setString( 6, kaitouBean.getKaitou3() );
            ps.setString( 7, kaitouBean.getKaitou4() );
            ps.setString( 8, kaitouBean.getKaitou5() );
            ps.setString( 9, kaitouBean.getKaitou6() );
            ps.setString( 10, kaitouBean.getKaitou7() );
            ps.setString( 11, kaitouBean.getKaitou8() );
            ps.setString( 12, kaitouBean.getKaitou9() );
            ps.setString( 13, kaitouBean.getKaitou10() );
            
            int cnt = ps.executeUpdate( );
            ps.close();  // INS 2007/2/2 s-hiura

            //�X�e�[�^�X���ݒ肳��Ă���ꍇ�͍X�V���s���B
            if ( kaitouBean.getStatus() != null ) {
            	sql = kaitouBean.getStatusSql();
            	
            	ps = con.prepareStatement( sql );
            	ps.setString( 1, kaitouBean.getStatus() );
            	ps.setString( 2, PZZ010_CharacterUtil.GetDay() );
            	ps.setString( 3, PZZ010_CharacterUtil.GetTime() );
            	ps.setString( 4, loginuser.getSimeiNo() );
                ps.setString( 5, kaitouBean.getSimeiNo() );
                ps.setString( 6, kaitouBean.getKamokuCode() );
                ps.setString( 7, kaitouBean.getClassCode() );
                
                cnt += ps.executeUpdate( );
                ps.close();  // INS 2007/2/2 s-hiura
            }
            
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return cnt;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }
    
    /**
     * �A���P�[�g�����X�V���܂��B
     *
     * @param kaitouBean �X�V����
     * @param loginuser ���O�C�����[�U
     * @return �X�V����
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int updateEnqueteKaitou( PCY_EnqueteKaitouBean kaitouBean, PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );
            
            //SELECT���擾
            String sql = kaitouBean.getUpdateSql();
            
            //�R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );
            
            //�o�^���s
            ps = con.prepareStatement( sql );
            ps.setString( 1, kaitouBean.getKaitou1() );
            ps.setString( 2, kaitouBean.getKaitou2() );
            ps.setString( 3, kaitouBean.getKaitou3() );
            ps.setString( 4, kaitouBean.getKaitou4() );
            ps.setString( 5, kaitouBean.getKaitou5() );
            ps.setString( 6, kaitouBean.getKaitou6() );
            ps.setString( 7, kaitouBean.getKaitou7() );
            ps.setString( 8, kaitouBean.getKaitou8() );
            ps.setString( 9, kaitouBean.getKaitou9() );
            ps.setString( 10, kaitouBean.getKaitou10() );
            ps.setString( 11, kaitouBean.getKamokuCode() );
            ps.setString( 12, kaitouBean.getClassCode() );
            ps.setString( 13, kaitouBean.getSimeiNo() );
            
            int cnt = ps.executeUpdate( );
            ps.close();  // INS 2007/2/2 s-hiura
            
            //�X�e�[�^�X���ݒ肳��Ă���ꍇ�͍X�V���s���B
            if ( kaitouBean.getStatus() != null ) {
            	sql = kaitouBean.getStatusSql();
            	
            	ps = con.prepareStatement( sql );
            	ps.setString( 1, kaitouBean.getStatus() );
            	ps.setString( 2, PZZ010_CharacterUtil.GetDay() );
            	ps.setString( 3, PZZ010_CharacterUtil.GetTime() );
            	ps.setString( 4, loginuser.getSimeiNo() );
                ps.setString( 5, kaitouBean.getSimeiNo() );
                ps.setString( 6, kaitouBean.getKamokuCode() );
                ps.setString( 7, kaitouBean.getClassCode() );
                
                cnt += ps.executeUpdate( );
                ps.close();  // INS 2007/2/2 s-hiura
            }
            
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return cnt;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }

    /**
     * �A���P�[�g�����폜���܂��B
     *
     * @param kaitouBean �폜����
     * @param loginuser ���O�C�����[�U
     * @return �폜����
     * @ejb.interface-method
     * @ejb.transaction type="Required"
     */
    public int deleteEnqueteKaitou( PCY_EnqueteKaitouBean kaitouBean, PCY_PersonalBean loginuser ) {
        Connection con       = null;
        PreparedStatement ps = null;

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "IN", "" );
            
            //SELECT���擾
            String sql = kaitouBean.getDeleteSql();
            
            //�R�l�N�V�����擾
            PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
            con     = locator.getDataSource(  ).getConnection(  );
            
            //�o�^���s
            ps = con.prepareStatement( sql );
            ps.setString( 1, kaitouBean.getKamokuCode() );
            ps.setString( 2, kaitouBean.getClassCode() );
            ps.setString( 3, kaitouBean.getSimeiNo() );
            
            int cnt = ps.executeUpdate( );
            ps.close();  // INS 2007/2/2 s-hiura
            
            //�X�e�[�^�X���ݒ肳��Ă���ꍇ�͍X�V���s���B
            if ( kaitouBean.getStatus() != null ) {
            	sql = kaitouBean.getStatusSql();
            	
            	ps = con.prepareStatement( sql );
            	ps.setString( 1, kaitouBean.getStatus() );
            	ps.setString( 2, PZZ010_CharacterUtil.GetDay() );
            	ps.setString( 3, PZZ010_CharacterUtil.GetTime() );
            	ps.setString( 4, loginuser.getSimeiNo() );
                ps.setString( 5, kaitouBean.getSimeiNo() );
                ps.setString( 6, kaitouBean.getKamokuCode() );
                ps.setString( 7, kaitouBean.getClassCode() );
                
                cnt += ps.executeUpdate( );
                ps.close();  // INS 2007/2/2 s-hiura
            }
            
            // ���\�b�h�g���[�X�o��
            Log.method( loginuser.getSimeiNo(  ), "OUT", "" );

            return cnt;
        } catch ( NamingException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
            throw new EJBException( e );
        } catch ( SQLException e ) {
            Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
            throw new EJBException( e );
        } catch ( RuntimeException e ) {
            Log.error( loginuser.getSimeiNo(  ), "", e );
            throw e;
        } finally {
            if ( ps != null ) {
                try {
                    ps.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }

            if ( con != null ) {
                try {
                    con.close(  );
                } catch ( SQLException e ) {
                    // �������Ȃ�
                }
            }
        }
    }
    
    /**
     * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
     */
    public void setSessionContext( SessionContext context )
        throws EJBException, RemoteException {
        this.context = context;
    }

    /**
     * EJB�I�u�W�F�N�g�̐������s���܂��B
     *
     * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
     */
    public void ejbCreate(  ) throws CreateException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate(  ) throws EJBException, RemoteException {
    }

    /**
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate(  ) throws EJBException, RemoteException {
    }

}
