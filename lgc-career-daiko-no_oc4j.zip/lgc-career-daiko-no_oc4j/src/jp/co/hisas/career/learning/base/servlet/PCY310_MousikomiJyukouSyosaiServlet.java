/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O            ���e
 *   2005/01/05  01.00        �����@��F      �V�K�쐬
 *   2005/12/03  01.00        �c�� ��`       �\���폜������p�~ BPX-0301J-0475
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.*;
import java.util.*;

import javax.ejb.*;
import javax.naming.*;
import javax.servlet.http.*;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.bean.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;

/**
 *<PRE>
 *
 * �N���X���F
 *   �\���E��u�󋵏ڍ׃T�[�u���b�g�N���X
 *
 * �@�\�����F
 *   �J�ڌ��Ŏw�肳�ꂽ�\���E��u�󋵃X�e�[�^�X�ɕR�t���ڍ׎擾���s���܂��B
 *
 *</PRE>
 */
public class PCY310_MousikomiJyukouSyosaiServlet extends PCY010_ControllerServlet {


	/**
	 * ���N�G�X�g���猟���������擾���A���������Ɉ�v����N���X�����擾���܂��B
	 * �N���X���̓��N�G�X�g(�������F"classBeans")�Ɋi�[���܂��B
	 * �N���X��񂪑��݂��Ȃ��ꍇ�A���N�G�X�g�ɂ͋�̔z�񂪊i�[����܂��B
	 *
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(
	 *          javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 *          jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean
	 *      )
	 */
	protected String execute( HttpServletRequest request,
							   HttpServletResponse response,
							   PCY_PersonalBean loginuser )
		throws NamingException, CreateException, RemoteException {
		/*���\�b�h�g���[�X�o��*/
		Log.method( loginuser.getSimeiNo(), "IN", "" );

		String GamenID = (String)request.getParameter( "GamenID" );
		PCY_KensyuKanriJohoBean[] ret = null;

		//�N���X�����ꊇ
		if ( GamenID != null && GamenID.equals("VCC320")){

			PCY_ClassBean[] classBeans = null;
			List taisyosyaList = new ArrayList(  );
			PCY_ClassBean kensaku_class = new PCY_ClassBean(request);

			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
			PCY_ClassEJBHome home = (PCY_ClassEJBHome)locator.getServiceLocation(
										"PCY_ClassEJB",
										PCY_ClassEJBHome.class );
			PCY_ClassEJB ejb = home.create();
	
			classBeans = ejb.doSelect( kensaku_class, false, loginuser );
	
			
			PCY_MousikomiJyokyoEJBHome home1 = ( PCY_MousikomiJyokyoEJBHome )locator.getServiceLocation( "PCY_MousikomiJyokyoEJB",
					PCY_MousikomiJyokyoEJBHome.class );
			PCY_MousikomiJyokyoEJB ejb1 = home1.create(  );
			
			for(int i = 0;i < classBeans.length;i++){
			
				String kamokuCode = classBeans[i].getKamokuBean().getKamokuCode();
				String classCode  = classBeans[i].getClassCode();
				PCY_KensyuKanriJohoBean[] taisyosyaBeans = null;
				PCY_KensyuKanriJohoBean[] mimousikomi_taisyosyaBeans = null;

				if((kensaku_class.getMousikomiJyokyo() == null || kensaku_class.getMousikomiJyokyo().equals(""))
					&& (kensaku_class.getJyukoJyokyo() == null || kensaku_class.getJyukoJyokyo().equals(""))){
				/* ���������ɐ\���󋵁A��u�󋵂��ݒ肳��Ă��Ȃ���΁A�S�e�[�u���iL15,L51,L94�j������ */
					taisyosyaBeans = ejb1.getListWithClass( kamokuCode, classCode,null, loginuser );
					
					mimousikomi_taisyosyaBeans = getMimousikomi(locator,classBeans[i],loginuser);
					
					ArrayList retArray = new ArrayList();
					for(int s = 0 ; s < mimousikomi_taisyosyaBeans.length ; s++){
						retArray.add(mimousikomi_taisyosyaBeans[s]);	                
					}
					for(int t = 0; t < taisyosyaBeans.length; t++){
						retArray.add(taisyosyaBeans[t]);
					}
			
					taisyosyaBeans = ( PCY_KensyuKanriJohoBean[] )retArray.toArray( new PCY_KensyuKanriJohoBean[0] );					
					
				}else if(kensaku_class.getMousikomiJyokyo().equals("1") || kensaku_class.getMousikomiJyokyo().equals("2") || 
						  kensaku_class.getMousikomiJyokyo().equals("3") || kensaku_class.getMousikomiJyokyo().equals("4") ||
						  kensaku_class.getMousikomiJyokyo().equals("5") || kensaku_class.getMousikomiJyokyo().equals("6")){
					//���������ɐ\���󋵁i����ς͏����j���ݒ肳��Ă���΁AL15�e�[�u��������
				 	
					taisyosyaBeans = ejb1.getListWithClassL15(kamokuCode,classCode,kensaku_class,null,loginuser);         	
//                  DEL#BPX-0301J-0475
				}else if(kensaku_class.getJyukoJyokyo().equals("0") || kensaku_class.getJyukoJyokyo().equals("1") || kensaku_class.getJyukoJyokyo().equals("2")){
					//���������Ɏ�u�󋵁u�񍐑ҁv�A�u����ҁv���ݒ肳��Ă���΁AL15�e�[�u��������
					taisyosyaBeans = ejb1.getListWithClassL15(kamokuCode,classCode,kensaku_class,null,loginuser);
				}else if(kensaku_class.getJyukoJyokyo().equals("3") || kensaku_class.getJyukoJyokyo().equals("4")){
					//���������Ɏ�u�󋵁u���C���v�A�u�C���v���ݒ肳��Ă���΁AL51�e�[�u��������
					taisyosyaBeans = ejb1.getListWithClassL51(kamokuCode,classCode,kensaku_class,null,loginuser);
				}else if(kensaku_class.getMousikomiJyokyo().equals("0")){
					taisyosyaBeans = getMimousikomi(locator,classBeans[i],loginuser);
				}
				
				for(int t = 0;t < taisyosyaBeans.length;t++){
					taisyosyaBeans[t].getMousikomiBean().getClassBean().getKamokuBean().setKamokuCode(classBeans[i].getKamokuBean().getKamokuCode());
					taisyosyaBeans[t].getMousikomiBean().getClassBean().getKamokuBean().setKamokuMei1(classBeans[i].getKamokuBean().getKamokuMei1());
					taisyosyaBeans[t].getMousikomiBean().getClassBean().setClassMei(classBeans[i].getClassMei());
					taisyosyaBeans[t].getMousikomiBean().getClassBean().setKousinbi(classBeans[i].getKousinbi());
					taisyosyaBeans[t].getMousikomiBean().getClassBean().setKousinjikoku(classBeans[i].getKousinjikoku());
					taisyosyaList.add(taisyosyaBeans[t]);
				}			
			}
			ret = new PCY_KensyuKanriJohoBean[taisyosyaList.size(  )];
			ret = ( PCY_KensyuKanriJohoBean[] )taisyosyaList.toArray( ret );
								

			request.setAttribute( "classBean",kensaku_class);													
			request.setAttribute( "kensyukanriJohoBeans",ret);

		//��u�t�H���[
		}else if (( GamenID != null && GamenID.equals("VCC190")) ||
				   ( GamenID != null && GamenID.equals("VCC192")) || 
			       ( GamenID != null && GamenID.equals("VCC182"))){

			Log.transaction( loginuser.getSimeiNo(  ), true, "" );

			request.setAttribute( "GamenID",request.getParameter( "GamenID" ) );
			request.setAttribute( "jyokuo_kamoku_code",request.getParameter( "jyokuo_kamoku_code" ) );
			request.setAttribute( "jyokuo_class_code",request.getParameter( "jyokuo_class_code" ) );
			request.setAttribute( "jyokuo_simei_no",request.getParameter( "jyokuo_simei_no" ) );
			request.setAttribute( "Jyoukyou",request.getParameter( "Jyoukyou" ) );
			request.setAttribute( "Mousikomibi",request.getParameter( "Mousikomibi" ) );
			request.setAttribute( "Mousikomijikoku",request.getParameter( "Mousikomijikoku" ) );
			request.setAttribute( "Mousikomisya",request.getParameter( "Mousikomisya" ) );
			request.setAttribute( "Syouninbi",request.getParameter( "Syouninbi" ) );
			request.setAttribute( "Syouninjikoku",request.getParameter( "Syouninjikoku" ) );
			request.setAttribute( "Syouninsya",request.getParameter( "Syouninsya" ) );
			request.setAttribute( "Syouninbi2",request.getParameter( "Syouninbi2" ) );
			request.setAttribute( "Syouninjikoku2",request.getParameter( "Syouninjikoku2" ) );
			request.setAttribute( "Syouninsya2",request.getParameter( "Syouninsya2" ) );
			request.setAttribute( "Uketukebi",request.getParameter( "Uketukebi" ) );
			request.setAttribute( "Uketukejikoku",request.getParameter( "Uketukejikoku" ) );
			request.setAttribute( "Uketukesya",request.getParameter( "Uketukesya" ) );
			request.setAttribute( "Houkokubi",request.getParameter( "Houkokubi" ) );
			request.setAttribute( "Houkokujikoku",request.getParameter( "Houkokujikoku" ) );
			request.setAttribute( "Houkokusya",request.getParameter( "Houkokusya" ) );
			request.setAttribute( "Downloadbi",request.getParameter( "Downloadbi" ) );
			request.setAttribute( "Downloadjikoku",request.getParameter( "Downloadjikoku" ) );
			request.setAttribute( "Downloadsya",request.getParameter( "Downloadsya" ) );
			request.setAttribute( "Hanteibi",request.getParameter( "Hanteibi" ) );
			request.setAttribute( "Hanteijikoku",request.getParameter( "Hanteijikoku" ) );
			request.setAttribute( "Hanteisya",request.getParameter( "Hanteisya" ) );
			request.setAttribute( "kousinbi",request.getParameter( "kousinbi" ) );
			request.setAttribute( "kousinjikoku",request.getParameter( "kousinjikoku" ) );
			request.setAttribute( "kousinsya",request.getParameter( "kousinsya" ) );


			ret = new PCY_KensyuKanriJohoBean[1];
			List taisyosyaList = new ArrayList(  );
			ret = ( PCY_KensyuKanriJohoBean[] )taisyosyaList.toArray( ret );
			request.setAttribute( "kensyukanriJohoBeans", ret );

		//�N���X����
		}else{
			PCY_KensyuKanriJohoBean[] taisyosyaBeans = null;
			/* EJBObject�̎擾 */
			PCY_ServiceLocator locator      = PCY_ServiceLocator.getInstance(  );
			PCY_MousikomiJyokyoEJBHome home = ( PCY_MousikomiJyokyoEJBHome )locator.getServiceLocation( "PCY_MousikomiJyokyoEJB",
					PCY_MousikomiJyokyoEJBHome.class );
			PCY_MousikomiJyokyoEJB ejb = home.create(  );

			String kamokuCode = request.getParameter( "kamoku_code" );
			String classCode  = request.getParameter( "class_code" );

			/* EJB�Ăяo�� */
			Log.transaction( loginuser.getSimeiNo(  ), true, "" );

			taisyosyaBeans = ejb.getListWithClass( kamokuCode, classCode,
					null, loginuser );



			/* ���\���҂̌������s�Ȃ�*/
			/* �擾�����N���X���S�БΏۂ̏ꍇ�AL15,L51�ɐ\�����������̂��Y��*/
			/* �擾�����N���X����S�БΏۂ̏ꍇ�A�ΏێҐݒ肳��Ă���l��L15,L51�ɖ����ꍇ�ɊY��*/
		
			PCY_ClassBean[] ret_classBeans = null;
			PCY_MousikomiJyokyoBean kensaku_mousikomi = new PCY_MousikomiJyokyoBean();
			PCY_KensyuRirekiBean kensaku_rireki = new PCY_KensyuRirekiBean();
		
			ArrayList retKanri = new ArrayList();
		
			
			PCY_MousikomiJyokyoEJBHome home_mousikomi = (PCY_MousikomiJyokyoEJBHome)locator.getServiceLocation(
												"PCY_MousikomiJyokyoEJB",
												 PCY_MousikomiJyokyoEJBHome.class );
			PCY_MousikomiJyokyoEJB ejb_mousikomi = home_mousikomi.create();

			PCY_TaisyoEJBHome home_taisyo = (PCY_TaisyoEJBHome)locator.getServiceLocation(
																"PCY_TaisyoEJB",
																 PCY_TaisyoEJBHome.class );
			PCY_TaisyoEJB ejb_taisyo = home_taisyo.create();
		
			PCY_ClassEJBHome home_class = (PCY_ClassEJBHome)locator.getServiceLocation(
																"PCY_ClassEJB",
																 PCY_ClassEJBHome.class );
			PCY_ClassEJB ejb_class = home_class.create();

			//��S�БΏۂ̏ꍇ�̂�L15��L51������
			//�S�БΏۂ̏ꍇ�́u���\���v�̌����͂ł��Ȃ�
			//�Ȃ��Ȃ�΁AL15�ɂ��Ȃ�L51�ɂ��Ȃ��̂ŁA�o�̓f�[�^���Ȃ��B�܂�A0���ɂȂ�
			PCY_ClassBean classBean = new PCY_ClassBean();
			classBean.setClassCode(classCode);
			PCY_KamokuBean kamokuBean = new PCY_KamokuBean();
			kamokuBean.setKamokuCode(kamokuCode);
			classBean.setKamokuBean(kamokuBean);
			classBean = ejb_class.doSelectByPrimaryKey(classBean,loginuser);
			if(classBean.getZensyaTaisyoFlg().equals("0")){
				PCY_TaisyosyaBean[] taisyo =  ejb_taisyo.getAllTaisyosya(classBean,false,loginuser);
				for(int t = 0; t < taisyo.length ; t++){
				
					kensaku_mousikomi.setClassBean(taisyo[t].getClassBean());
					kensaku_mousikomi.setSimeiNo(taisyo[t].getSimeiNo());
					kensaku_rireki.setClassCode(taisyo[t].getClassBean().getClassCode());
					kensaku_rireki.setKamokuCode(taisyo[t].getClassBean().getKamokuBean().getKamokuCode());
					kensaku_rireki.setSimeiNo(taisyo[t].getSimeiNo());
				
					PCY_MousikomiJyokyoBean[] mousikomiBeans = ejb_mousikomi.getList(kensaku_mousikomi,loginuser);
					PCY_KensyuRirekiBean[] rirekiBeans = ejb_mousikomi.getListL51(kensaku_rireki,loginuser);
					if((mousikomiBeans == null || mousikomiBeans.length == 0) && (rirekiBeans == null || rirekiBeans.length == 0)){
						//L15�AL51���e�[�u���Ƀf�[�^���ꌏ��������΁A�f�[�^�ێ�
						PCY_KensyuKanriJohoBean kanriBean = new PCY_KensyuKanriJohoBean();
						PCY_MousikomiJyokyoBean mousikomi = new PCY_MousikomiJyokyoBean();
						mousikomi.setPersonalBean(taisyo[t].getPersonalBean());
						mousikomi.setClassBean(classBean);
						mousikomi.setMousikomijyokyo("0");
						kanriBean.setMousikomiBean(mousikomi);
						kanriBean.setTaisyousyaBean(taisyo[t]);
						retKanri.add(kanriBean);
					}
				}
			
			}
			PCY_KensyuKanriJohoBean[] taisyosyaBeans_mimousikomi = ( PCY_KensyuKanriJohoBean[] )retKanri.toArray( new PCY_KensyuKanriJohoBean[0] );
		
			//���������łЂ����������\�����ƁA���\���������̂�����
			ArrayList retArray = new ArrayList();
			for(int i = 0 ; i < taisyosyaBeans_mimousikomi.length ; i++){
				retArray.add(taisyosyaBeans_mimousikomi[i]);	                
			}
			for(int t = 0; t < taisyosyaBeans.length; t++){
				retArray.add(taisyosyaBeans[t]);
			}
			taisyosyaBeans = ( PCY_KensyuKanriJohoBean[] )retArray.toArray( new PCY_KensyuKanriJohoBean[0] );
			Log.transaction( loginuser.getSimeiNo(  ), false, "" );
			request.setAttribute( "kensyukanriJohoBeans",taisyosyaBeans);

		}

		request.setAttribute( "jyokuo_kamoku_code",request.getParameter( "jyokuo_kamoku_code" ));													
		request.setAttribute( "jyokuo_class_code",request.getParameter( "jyokuo_class_code" ));													
		request.setAttribute( "jyokuo_simei_no",request.getParameter( "jyokuo_simei_no" ));													

		/*���\�b�h�g���[�X�o��*/
		Log.method( loginuser.getSimeiNo(), "OUT", "" );

		return getForwardPath();
	}

	/**
	 * �\���Ҏ擾
	 * @param	PCY_ServiceLocator
	 * @param	PCY_ClassBean
	 * @param	PCY_PersonalBean
	 * @throws RemoteException,NamingException,CreateException
	 */
	private PCY_KensyuKanriJohoBean[] getMimousikomi(PCY_ServiceLocator locator,PCY_ClassBean classBean,PCY_PersonalBean loginuser)
	throws RemoteException, NamingException,CreateException{
		ArrayList retKanri;
		try {
			/* �擾�����N���X���S�БΏۂ̏ꍇ�AL15,L51�ɐ\�����������̂��Y��*/
			/* �擾�����N���X����S�БΏۂ̏ꍇ�A�ΏێҐݒ肳��Ă���l��L15,L51�ɖ����ꍇ�ɊY��*/
				
			PCY_ClassBean[] ret_classBeans = null;
			PCY_MousikomiJyokyoBean kensaku_mousikomi = new PCY_MousikomiJyokyoBean();
			PCY_KensyuRirekiBean kensaku_rireki = new PCY_KensyuRirekiBean();
				
			retKanri = new ArrayList();
				
					
			PCY_MousikomiJyokyoEJBHome home_mousikomi = (PCY_MousikomiJyokyoEJBHome)locator.getServiceLocation(
												"PCY_MousikomiJyokyoEJB",
												 PCY_MousikomiJyokyoEJBHome.class );
			PCY_MousikomiJyokyoEJB ejb_mousikomi = home_mousikomi.create();
			
			PCY_TaisyoEJBHome home_taisyo = (PCY_TaisyoEJBHome)locator.getServiceLocation(
																"PCY_TaisyoEJB",
																 PCY_TaisyoEJBHome.class );
			PCY_TaisyoEJB ejb_taisyo = home_taisyo.create();			
			
			//��S�БΏۂ̏ꍇ�̂�L15��L51������
			//�S�БΏۂ̏ꍇ�́u���\���v�̌����͂ł��Ȃ�
			//�Ȃ��Ȃ�΁AL15�ɂ��Ȃ�L51�ɂ��Ȃ��̂ŁA�o�̓f�[�^���Ȃ��B�܂�A0���ɂȂ�
			if(classBean.getZensyaTaisyoFlg().equals("0")){
				PCY_TaisyosyaBean[] taisyo =  ejb_taisyo.getAllTaisyosya(classBean,false,loginuser);
				for(int t = 0; t < taisyo.length ; t++){
						
					kensaku_mousikomi.setClassBean(taisyo[t].getClassBean());
					kensaku_mousikomi.setSimeiNo(taisyo[t].getSimeiNo());
					kensaku_rireki.setClassCode(taisyo[t].getClassBean().getClassCode());
					kensaku_rireki.setKamokuCode(taisyo[t].getClassBean().getKamokuBean().getKamokuCode());
					kensaku_rireki.setSimeiNo(taisyo[t].getSimeiNo());
						
					PCY_MousikomiJyokyoBean[] mousikomiBeans = ejb_mousikomi.getList(kensaku_mousikomi,loginuser);
					PCY_KensyuRirekiBean[] rirekiBeans = ejb_mousikomi.getListL51(kensaku_rireki,loginuser);
					if((mousikomiBeans == null || mousikomiBeans.length == 0) && (rirekiBeans == null || rirekiBeans.length == 0)){
						//L15�AL51���e�[�u���Ƀf�[�^���ꌏ��������΁A�f�[�^�ێ�
						PCY_KensyuKanriJohoBean kanriBean = new PCY_KensyuKanriJohoBean();
						PCY_MousikomiJyokyoBean mousikomi = new PCY_MousikomiJyokyoBean();
						mousikomi.setPersonalBean(taisyo[t].getPersonalBean());
						mousikomi.setMousikomijyokyo("0");
						kanriBean.setMousikomiBean(mousikomi);
						kanriBean.setTaisyousyaBean(taisyo[t]);
						retKanri.add(kanriBean);
					}
				}
					
			}
		return ( PCY_KensyuKanriJohoBean[] )retKanri.toArray( new PCY_KensyuKanriJohoBean[0] );
			
		} catch (RemoteException e) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0002", e );
			throw e;
		} catch (NamingException e) {
			Log.error( loginuser.getSimeiNo(  ), "HJE-0001", e );
			throw e;
		} catch (CreateException e) {
			Log.error( loginuser.getSimeiNo(  ), "", e );
			throw e;
		}	
		
	}

}