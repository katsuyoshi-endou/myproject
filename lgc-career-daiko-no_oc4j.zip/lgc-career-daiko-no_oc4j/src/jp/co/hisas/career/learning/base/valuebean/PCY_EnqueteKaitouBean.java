/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O            ���e
 *   2005/12/03              �Β�  �[        �V�K�쐬
 */
package jp.co.hisas.career.learning.base.valuebean;

import java.io.*;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.*;

import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_EnqueteKaitouBean �N���X
 *
 * �@�\�����F
 *   �A���P�[�g�񓚏���\��ValueBean�ł��B
 *
 *</PRE>
 */
public class PCY_EnqueteKaitouBean extends PCY_ValueBean implements Serializable {
	
	private String kamokuCode = null;
	private String classCode  = null;
	private String simeiNo    = null;
	private String kaitou1    = null;
	private String kaitou2    = null;
	private String kaitou3    = null;
	private String kaitou4    = null;
	private String kaitou5    = null;
	private String kaitou6    = null;
	private String kaitou7    = null;
	private String kaitou8    = null;
	private String kaitou9    = null;
	private String kaitou10   = null;
	
	//�\�����ݏ󋵕ύX�p�X�e�[�^�X
	private String status     = null;

	/**
	 * �f�t�H���g�̃R���X�g���N�^�ł��B
	 */
	public PCY_EnqueteKaitouBean(  ) {
		super();
	}

	/**
	 * request ����l���擾���Č�������Bean���쐬���܂��B
	 *
	 * @param request �T�[�u���b�g���N�G�X�g
	 */
	public PCY_EnqueteKaitouBean( ServletRequest request ) {
		
		setKamokuCode( request.getParameter( "kamoku_code" ) );
		setClassCode( request.getParameter( "class_code" ) );
		setSimeiNo( request.getParameter( "simei_no" ) );

		setKaitou1( request.getParameter( "kaitou1" ) );
		setKaitou2( request.getParameter( "kaitou2" ) );
		setKaitou3( request.getParameter( "kaitou3" ) );
		setKaitou4( request.getParameter( "kaitou4" ) );
		setKaitou5( request.getParameter( "kaitou5" ) );
		setKaitou6( request.getParameter( "kaitou6" ) );
		setKaitou7( request.getParameter( "kaitou7" ) );
		setKaitou8( request.getParameter( "kaitou8" ) );
		setKaitou9( request.getParameter( "kaitou9" ) );
		setKaitou10( request.getParameter( "kaitou10" ) );
		
	}

    /**
     * ResultSet ����l���擾���ăN���XValueBean���쐬���܂��B
     *
     * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
     * @throws SQLException SQLException�����������ꍇ
     */
    public PCY_EnqueteKaitouBean( ResultSet rs )
        throws SQLException {

        try {
        	setKamokuCode( rs.getString( "KAMOKU_CODE" ) );
            setClassCode( rs.getString( "CLASS_CODE" ) );
            setSimeiNo( rs.getString( "SIMEI_NO" ) );
            setKaitou1( rs.getString( "KAITOU1" ) );
            setKaitou2( rs.getString( "KAITOU2" ) );
            setKaitou3( rs.getString( "KAITOU3" ) );
            setKaitou4( rs.getString( "KAITOU4" ) );
            setKaitou5( rs.getString( "KAITOU5" ) );
            setKaitou6( rs.getString( "KAITOU6" ) );
            setKaitou7( rs.getString( "KAITOU7" ) );
            setKaitou8( rs.getString( "KAITOU8" ) );
            setKaitou9( rs.getString( "KAITOU9" ) );
            setKaitou10( rs.getString( "KAITOU10" ) );
			
        } catch ( SQLException e ) {
            Log.error( "", "HJE-0001", e );
            throw e;
        }
    }
    
	/**
	 * �e�[�u�����̂��ASelect���𐶐�����
	 * @return
	 */
	public String getSelectSql( ) {
		
		StringBuffer sql = new StringBuffer();
		
		sql.append( "SELECT " );
		sql.append( " KAMOKU_CODE, " );
		sql.append( " CLASS_CODE, " );
		sql.append( " SIMEI_NO, " );
		sql.append( " KAITOU1, " );
		sql.append( " KAITOU2, " );
		sql.append( " KAITOU3, " );
		sql.append( " KAITOU4, " );
		sql.append( " KAITOU5, " );
		sql.append( " KAITOU6, " );
		sql.append( " KAITOU7, " );
		sql.append( " KAITOU8, " );
		sql.append( " KAITOU9, " );
		sql.append( " KAITOU10 " );
		sql.append( "FROM " );
		sql.append( getTableName() + " " );
		sql.append( "WHERE " );
		sql.append( " KAMOKU_CODE=? ");
		sql.append( "AND " );
		sql.append( " CLASS_CODE=? ");
		sql.append( "AND " );
		sql.append( " SIMEI_NO=? ");
		
		return sql.toString();
	}

	/**
	 * �e�[�u�����̂��AInsert���𐶐�����
	 * @return
	 */
	public String getInsertSql( ) {
		
		StringBuffer sql = new StringBuffer();
		
		sql.append( "INSERT INTO " );
		sql.append( getTableName() + " " );
		sql.append( "( " );
		sql.append( " KAMOKU_CODE, " );
		sql.append( " CLASS_CODE, " );
		sql.append( " SIMEI_NO, " );
		sql.append( " KAITOU1, " );
		sql.append( " KAITOU2, " );
		sql.append( " KAITOU3, " );
		sql.append( " KAITOU4, " );
		sql.append( " KAITOU5, " );
		sql.append( " KAITOU6, " );
		sql.append( " KAITOU7, " );
		sql.append( " KAITOU8, " );
		sql.append( " KAITOU9, " );
		sql.append( " KAITOU10 " );
		sql.append( ") VALUES (" );
		sql.append( " ?, ?, ?, ?, " );
		sql.append( " ?, ?, ?, ?, " );
		sql.append( " ?, ?, ?, ?, " );
		sql.append( " ? " );
		sql.append( ") " );
		
		return sql.toString();
	}

	/**
	 * �e�[�u�����̂��AUpdate���𐶐�����
	 * @return
	 */
	public String getUpdateSql( ) {
		
		StringBuffer sql = new StringBuffer();
		
		sql.append( "UPDATE " );
		sql.append( getTableName() + " " );
		sql.append( "SET " );
		sql.append( " KAITOU1=?, " );
		sql.append( " KAITOU2=?, " );
		sql.append( " KAITOU3=?, " );
		sql.append( " KAITOU4=?, " );
		sql.append( " KAITOU5=?, " );
		sql.append( " KAITOU6=?, " );
		sql.append( " KAITOU7=?, " );
		sql.append( " KAITOU8=?, " );
		sql.append( " KAITOU9=?, " );
		sql.append( " KAITOU10=? " );
		sql.append( "WHERE " );
		sql.append( " KAMOKU_CODE=? ");
		sql.append( "AND " );
		sql.append( " CLASS_CODE=? ");
		sql.append( "AND " );
		sql.append( " SIMEI_NO=? ");
		
		return sql.toString();
	}

	/**
	 * �e�[�u�����̂��ADelete���𐶐�����
	 * @return
	 */
	public String getDeleteSql( ) {
		
		StringBuffer sql = new StringBuffer();
		
		sql.append( "DELETE FROM " );
		sql.append( getTableName() + " " );
		sql.append( "WHERE " );
		sql.append( " KAMOKU_CODE=? ");
		sql.append( "AND " );
		sql.append( " CLASS_CODE=? ");
		sql.append( "AND " );
		sql.append( " SIMEI_NO=? ");
		
		return sql.toString();
	}

	/**
	 * �\�����ݏ󋵃X�e�[�^�X�ύX�pSQL�𐶐�����
	 * @return
	 */
	public String getStatusSql( ) {
		
		StringBuffer sql = new StringBuffer();
		
		sql.append("UPDATE ");
		sql.append(HcdbDef.L15_TBL + " ");
		sql.append("SET ");
		sql.append(" STATUS=?, ");
		sql.append(" KOUSINBI=?, ");
		sql.append(" KOUSINJIKOKU=?, ");
		sql.append(" KOUSINSYA=? ");
		sql.append("WHERE ");
		sql.append(" SIMEI_NO=? ");
		sql.append("AND ");
		sql.append(" KAMOKU_CODE=? ");
		sql.append("AND ");
		sql.append(" CLASS_CODE=?");
		
		return sql.toString();
	}

	/**
	 * �e�[�u�����̂��A�����J�E���g��SQL���𐶐�����
	 * @param asCnt
	 * @return
	 */
	public String getCountSql( String asCnt ) {
		
		StringBuffer sql = new StringBuffer();
		
		sql.append( "SELECT " );
		sql.append( " COUNT(*) AS " + asCnt + " " );
		sql.append( "FROM " );
		sql.append( getTableName() + " " );
		sql.append( "WHERE " );
		sql.append( " KAMOKU_CODE=? ");
		sql.append( "AND " );
		sql.append( " CLASS_CODE=? ");
		sql.append( "AND " );
		sql.append( " SIMEI_NO=? ");
		
		return sql.toString();
	}

	/**
	 * �l��NULL�łȂ����`�F�b�N����B
	 * @return
	 */
	public boolean isKaitouExist() {
		
		if ( getKaitou1() != null ) {
			return true;
		}
		if ( getKaitou2() != null ) {
			return true;
		}
		if ( getKaitou3() != null ) {
			return true;
		}
		if ( getKaitou4() != null ) {
			return true;
		}
		if ( getKaitou5() != null ) {
			return true;
		}
		if ( getKaitou6() != null ) {
			return true;
		}
		if ( getKaitou7() != null ) {
			return true;
		}
		if ( getKaitou8() != null ) {
			return true;
		}
		if ( getKaitou9() != null ) {
			return true;
		}
		if ( getKaitou10() != null ) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * @return classCode ��߂��܂��B
	 */
	public String getClassCode() {
		return classCode;
	}

	/**
	 * @param classCode �ݒ肷�� classCode�B
	 */
	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}

	/**
	 * @return kaitou1 ��߂��܂��B
	 */
	public String getKaitou1() {
		return kaitou1;
	}

	/**
	 * @param kaitou1 �ݒ肷�� kaitou1�B
	 */
	public void setKaitou1(String kaitou1) {
		this.kaitou1 = kaitou1;
	}

	/**
	 * @return kaitou10 ��߂��܂��B
	 */
	public String getKaitou10() {
		return kaitou10;
	}

	/**
	 * @param kaitou10 �ݒ肷�� kaitou10�B
	 */
	public void setKaitou10(String kaitou10) {
		this.kaitou10 = kaitou10;
	}

	/**
	 * @return kaitou2 ��߂��܂��B
	 */
	public String getKaitou2() {
		return kaitou2;
	}

	/**
	 * @param kaitou2 �ݒ肷�� kaitou2�B
	 */
	public void setKaitou2(String kaitou2) {
		this.kaitou2 = kaitou2;
	}

	/**
	 * @return kaitou3 ��߂��܂��B
	 */
	public String getKaitou3() {
		return kaitou3;
	}

	/**
	 * @param kaitou3 �ݒ肷�� kaitou3�B
	 */
	public void setKaitou3(String kaitou3) {
		this.kaitou3 = kaitou3;
	}

	/**
	 * @return kaitou4 ��߂��܂��B
	 */
	public String getKaitou4() {
		return kaitou4;
	}

	/**
	 * @param kaitou4 �ݒ肷�� kaitou4�B
	 */
	public void setKaitou4(String kaitou4) {
		this.kaitou4 = kaitou4;
	}

	/**
	 * @return kaitou5 ��߂��܂��B
	 */
	public String getKaitou5() {
		return kaitou5;
	}

	/**
	 * @param kaitou5 �ݒ肷�� kaitou5�B
	 */
	public void setKaitou5(String kaitou5) {
		this.kaitou5 = kaitou5;
	}

	/**
	 * @return kaitou6 ��߂��܂��B
	 */
	public String getKaitou6() {
		return kaitou6;
	}

	/**
	 * @param kaitou6 �ݒ肷�� kaitou6�B
	 */
	public void setKaitou6(String kaitou6) {
		this.kaitou6 = kaitou6;
	}

	/**
	 * @return kaitou7 ��߂��܂��B
	 */
	public String getKaitou7() {
		return kaitou7;
	}

	/**
	 * @param kaitou7 �ݒ肷�� kaitou7�B
	 */
	public void setKaitou7(String kaitou7) {
		this.kaitou7 = kaitou7;
	}

	/**
	 * @return kaitou8 ��߂��܂��B
	 */
	public String getKaitou8() {
		return kaitou8;
	}

	/**
	 * @param kaitou8 �ݒ肷�� kaitou8�B
	 */
	public void setKaitou8(String kaitou8) {
		this.kaitou8 = kaitou8;
	}

	/**
	 * @return kaitou9 ��߂��܂��B
	 */
	public String getKaitou9() {
		return kaitou9;
	}

	/**
	 * @param kaitou9 �ݒ肷�� kaitou9�B
	 */
	public void setKaitou9(String kaitou9) {
		this.kaitou9 = kaitou9;
	}

	/**
	 * @return kamokuCode ��߂��܂��B
	 */
	public String getKamokuCode() {
		return kamokuCode;
	}

	/**
	 * @param kamokuCode �ݒ肷�� kamokuCode�B
	 */
	public void setKamokuCode(String kamokuCode) {
		this.kamokuCode = kamokuCode;
	}

	/**
	 * @return simeiNo ��߂��܂��B
	 */
	public String getSimeiNo() {
		return simeiNo;
	}

	/**
	 * @param simeiNo �ݒ肷�� simeiNo�B
	 */
	public void setSimeiNo(String simeiNo) {
		this.simeiNo = simeiNo;
	}
	
	public void setTableNameSub( String tableName ){
		setTableName( tableName );
	}

	/**
	 * @return status ��߂��܂��B
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status �ݒ肷�� status�B
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
}
