/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����   ���O            ���e
 *   2005/01/21  01.00       ���� ��F		  �V�K�쐬
 */
package jp.co.hisas.career.learning.base.servlet;

import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;

import java.rmi.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;

import javax.servlet.http.*;

/**
 *<PRE>
 *
 * �N���X���F
 *   ���C���[�h�}�b�v�o�^�󋵊m�F�T�[�u���b�g�N���X
 *
 * �@�\�����F
 *   �Ȗڏ����������A���C���[�h�}�b�v�o�^�󋵈ꗗ�\�����s���B
 *
 *</PRE>
 */
public class PCY350_KensyuLoadMapKakuninServlet extends PCY010_ControllerServlet {
	/**
	 *   ���N�G�X�g����L�[���擾���A�Ȗڏ����擾���܂��B
	 *   �Ȗڏ��͑������F"PCY_ClassBean")�Ɋi�[���܂��B
	 *
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(
	 *          javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 *          jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean
	 *      )
	 */
	protected String execute( HttpServletRequest request, HttpServletResponse response,
		PCY_PersonalBean loginuser ) throws NamingException, CreateException, RemoteException , Exception {
		/*���\�b�h�g���[�X�o��*/
		Log.method( "", "IN", "" );

		PCY_SearchKeyBean searchKey = new PCY_SearchKeyBean( request );
		String searchFlg = request.getParameter("searchFlg");
		if(searchFlg == null || searchFlg.equals("true")){
			PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
	
			PCY_KanrenKyoikuKamokuEJBHome kanren_home = ( PCY_KanrenKyoikuKamokuEJBHome )locator
				.getServiceLocation( "PCY_KanrenKyoikuKamokuEJB",
					PCY_KanrenKyoikuKamokuEJBHome.class );
			PCY_KanrenKyoikuKamokuEJB kanren_ejb = kanren_home.create(  );
	
			PCY_KanrenKyoikuKamokuBean[] kanrenBeans = null;
			List kanrenList = new ArrayList(  );
			PCY_KanrenKyoikuKamokuBean[] SortkanrenBeans = null;
	
			String[] kamokuCodesTemp   = null;
			/* �ȖڃR�[�h�J���}��؂��z��ɂ��� */
			if ( ( searchKey.getKamokuCodes(  ) != null ) && ( searchKey.getKamokuCodes(  ).length == 1 ) ) {
				String kamokuCodesLineTemp = searchKey.getKamokuCodes(  )[0];
				kamokuCodesTemp   = kamokuCodesLineTemp.split( "," );
	
				for ( int i = 0; i < kamokuCodesTemp.length; i++ ) {
					kamokuCodesTemp[i] = kamokuCodesTemp[i].trim(  );
				}
				searchKey.setKamokuCodes( kamokuCodesTemp );
			}
	
	
			//�����������Ȃ��i�S�������j������
			if ( ( searchKey.getKamokuGroupCode() == null || searchKey.getKamokuGroupCode().equals("")) &&
				 ( searchKey.getCategoryCode1() == null || searchKey.getCategoryCode1().equals("")) &&
				 ( searchKey.getCategoryCode2() == null || searchKey.getCategoryCode2().equals("")) &&
				 ( searchKey.getKanrimotoCode() == null || searchKey.getKanrimotoCode().equals("")) &&
				 ( kamokuCodesTemp[0] == null || kamokuCodesTemp[0].equals("") ) &&
				 ( searchKey.getKamokuMei1() == null || searchKey.getKamokuMei1().equals("")) )
			{
				//�֘A����Ȗڃ}�X�^�e�[�u�� �iP16_C_KANREN_KYOIKU_KAMOKU_TBL�j���Q��
				PCY_KanrenKyoikuKamokuBean[] kanren  = kanren_ejb.doSelect( loginuser );
				for ( int j = 0; j < kanren.length; j++ ) {
					if ( kanren[j] != null ){
						kanrenList.add( kanren[j] );
					}
				}
	
			}else{
	
				//�����������i�[����
				String kamoku_mei1 = request.getParameter("kamoku_mei1");
				if ( null != kamoku_mei1 && !kamoku_mei1.equals("")){
					searchKey.setKamokuMei1( kamoku_mei1 );
				}
	
				/* ���x���R�[�h���P���Z���� */
				if ( ( searchKey.getLevelCode(  ) != null ) && !searchKey.getLevelCode(  ).equals( "" ) ) {
					searchKey.setLevelCode( String.valueOf( Integer.parseInt( searchKey.getLevelCode(  ) )
							- 1 ) );
				}
	
				/* EJB�Ăяo��Bean�̃C���X�^���X���� */
				//�N���X���擾
				PCY_ClassEJBHome home = (PCY_ClassEJBHome)locator.getServiceLocation(
										"PCY_ClassEJB",
										PCY_ClassEJBHome.class );
				PCY_ClassEJB ejb = home.create();
				PCY_ClassBean[] ClassBeans = ejb.getClassList( searchKey , loginuser );
	
				//�\�[�g
				Arrays.sort( ClassBeans, new KamokuCodeComparator(  ) );
	
				for ( int i = 0; i < ClassBeans.length; i++ ) {
					PCY_KanrenKyoikuKamokuBean[] kanren  = kanren_ejb.doSelectByKamokuCode(
													ClassBeans[i].getKamokuBean().getKamokuCode() , loginuser );
					for ( int j = 0; j < kanren.length; j++ ) {
						if ( kanren[j] != null ){
							kanrenList.add( kanren[j] );
						}
					}
				}
			}
	
			//�\�[�g
			SortkanrenBeans = new PCY_KanrenKyoikuKamokuBean[kanrenList.size(  )];
			kanrenList.toArray( SortkanrenBeans );
			Arrays.sort( SortkanrenBeans, new kanrenKamokuCodeComparator(  ) );
	
			List kanrenList2 = new ArrayList(  );
			String hikaku1 = "";
			String hikaku2 = "";
			for ( int k = 0; k < SortkanrenBeans.length; k++ ) {
				hikaku2 = 	SortkanrenBeans[k].getKamokuCode() +
							SortkanrenBeans[k].getSyokusyuCode() + 
							SortkanrenBeans[k].getSenmonCode() +
							SortkanrenBeans[k].getLevelCode();
				// �ȖځE�E��E���E���x���̊e�R�[�h�������ꍇ�̓J�E���g���Ȃ�
				if ( !hikaku1.equals( hikaku2 ) ){
					kanrenList2.add( SortkanrenBeans[k] );
				}
				hikaku1 = 	SortkanrenBeans[k].getKamokuCode() +
							SortkanrenBeans[k].getSyokusyuCode() + 
							SortkanrenBeans[k].getSenmonCode() +
							SortkanrenBeans[k].getLevelCode();
			}
	
			kanrenBeans = new PCY_KanrenKyoikuKamokuBean[kanrenList2.size(  )];
			kanrenList2.toArray( kanrenBeans );
	
			request.setAttribute( "kanrenBeans", kanrenBeans );
			request.setAttribute( "SearchKey", searchKey );
		}else{
			PCY_KanrenKyoikuKamokuBean[] kanrens = new PCY_KanrenKyoikuKamokuBean[0];
		
			request.setAttribute( "kanrenBeans", kanrens );
			request.setAttribute( "SearchKey", searchKey );
		}

		/*���\�b�h�g���[�X�o��*/
		Log.method( "", "OUT", "" );

		return getForwardPath(  );
	}

	/**
	 *   �ȖڃR�[�h���L�[�Ƀ\�[�g���܂��B
	 */
	private class KamokuCodeComparator implements Comparator {
		public int compare( Object o1, Object o2 ) {
			PCY_ClassBean class1 = ( PCY_ClassBean )o1;
			PCY_ClassBean class2 = ( PCY_ClassBean )o2;

			if ( class1.getKamokuBean(  ).getKamokuCode(  ).equals( class2.getKamokuBean(  )
																		  .getKamokuCode(  ) ) ) {
				return class1.getClassCode(  ).compareTo( class2.getClassCode(  ) );
			}

			return class1.getKamokuBean(  ).getKamokuCode(  ).compareTo( class2.getKamokuBean(  )
																			   .getKamokuCode(  ) );
		}
	}
	

	/**
	 *   �ȖڃR�[�h�A�E��R�[�h�A���R�[�h�A���x�����L�[�Ƀ\�[�g���܂��B
	 */
	private class kanrenKamokuCodeComparator implements Comparator {
		public int compare( Object o1, Object o2 ) {
			PCY_KanrenKyoikuKamokuBean kanren1 = ( PCY_KanrenKyoikuKamokuBean )o1;
			PCY_KanrenKyoikuKamokuBean kanren2 = ( PCY_KanrenKyoikuKamokuBean )o2;

			int ret = 0;


			/* ��P�\�[�g�L�[�@�ȖڃR�[�h */
			if ( ( kanren1.getKamokuCode(  ) != null ) && ( kanren2.getKamokuCode(  ) != null ) ) {
				ret = kanren1.getKamokuCode(  ).compareTo( kanren2.getKamokuCode(  ) );
			} else if ( ( kanren1.getKamokuCode(  ) == null ) && ( kanren2.getKamokuCode(  ) != null ) ) {
				return 1;
			} else if ( ( kanren1.getKamokuCode(  ) != null ) && ( kanren2.getKamokuCode(  ) == null ) ) {
				return -1;
			}

			if ( ret != 0 ) {
				return ret;
			}

			/* ��Q�\�[�g�L�[�@�E��R�[�h */
			if ( ( kanren1.getSyokusyuCode(  ) != null ) && ( kanren2.getSyokusyuCode(  ) != null ) ) {
				ret = kanren1.getSyokusyuCode(  ).compareTo( kanren2.getSyokusyuCode(  ) );
			} else if ( ( kanren1.getSyokusyuCode(  ) == null ) && ( kanren2.getSyokusyuCode(  ) != null ) ) {
				return 1;
			} else if ( ( kanren1.getSyokusyuCode(  ) != null ) && ( kanren2.getSyokusyuCode(  ) == null ) ) {
				return -1;
			}

			if ( ret != 0 ) {
				return ret;
			}

			/* ��R�\�[�g�L�[�@���R�[�h */
			if ( ( kanren1.getSenmonCode(  ) != null ) && ( kanren2.getSenmonCode(  ) != null ) ) {
				ret = kanren1.getSenmonCode(  ).compareTo( kanren2.getSenmonCode(  ) );
			} else if ( ( kanren1.getSenmonCode(  ) == null ) && ( kanren2.getSenmonCode(  ) != null ) ) {
				return 1;
			} else if ( ( kanren1.getSenmonCode(  ) != null ) && ( kanren2.getSenmonCode(  ) == null ) ) {
				return -1;
			}

			if ( ret != 0 ) {
				return ret;
			}

			/* ��S�\�[�g�L�[�@���x�� */
			if ( ( kanren1.getLevelCode(  ) != null ) && ( kanren2.getLevelCode(  ) != null ) ) {
				ret = kanren1.getLevelCode(  ).compareTo( kanren2.getLevelCode(  ) );
			} else if ( ( kanren1.getLevelCode(  ) == null ) && ( kanren2.getLevelCode(  ) != null ) ) {
				return 1;
			} else if ( ( kanren1.getLevelCode(  ) != null ) && ( kanren2.getLevelCode(  ) == null ) ) {
				return -1;
			}

			if ( ret != 0 ) {
				return ret;
			}

			return ret;
		}
	}

}