/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/03/08  01.00       ���� ��F    �V�K�쐬
 */
package jp.co.hisas.career.learning.base.valuebean;

import jp.co.hisas.career.learning.base.bean.*;
import jp.co.hisas.career.util.common.*;

import java.io.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY_KensyuRirekiBeanForMail �N���X
 *
 * �@�\�����F
 *   ���[���@�\�p�Ɍ��C��������ێ�����ValueBean�ł��B
 *
 *</PRE>
 */
public class PCY_KensyuRirekiBeanForMail implements Serializable {

	private String simeiNo             = null;
	private String kamokuCode          = null;
	private String kamokuMei1          = null;
	private String classCode           = null;
	private String classMei            = null;
	private String kaisibi             = null;
	private String syuryobi            = null;
	private String tensu               = null;
	private String seiseki             = null;
	private String syuryoHantei        = null;
	private String syussekiNissuu      = null;
	private String seisekiBikou 	    = null;

    public PCY_KensyuRirekiBeanForMail( PCY_KensyuRirekiBean kensyuRirekiBean ) {

		//����NO
		setSimeiNo( kensyuRirekiBean.getSimeiNo());
		//�ȖڃR�[�h
		if ( kensyuRirekiBean.getKamokuCode(  ) != null && !kensyuRirekiBean.getKamokuCode(  ).equals("")){
			setKamokuCode( kensyuRirekiBean.getKamokuCode());
		}else{
			setKamokuCode( "" );
		}
		//�Ȗږ�1
		if ( kensyuRirekiBean.getKamokuMei1(  ) != null && !kensyuRirekiBean.getKamokuMei1(  ).equals("")){
			setKamokuMei1( kensyuRirekiBean.getKamokuMei1(  ) );
		}else{
			setKamokuMei1( "" );
		}
		//�N���X�R�[�h
		if ( kensyuRirekiBean.getClassCode(  ) != null && !kensyuRirekiBean.getClassCode(  ).equals("")){
			setClassCode( kensyuRirekiBean.getClassCode());
		}else{
			setClassCode( "" );
		}
        //�N���X��
		if ( kensyuRirekiBean.getClassMei(  ) != null && !kensyuRirekiBean.getClassMei(  ).equals("")){
			setClassMei( kensyuRirekiBean.getClassMei(  ) );
		}else{
			setClassMei( "" );
		}
        //�J�n��
        if ( kensyuRirekiBean.getKaisibi(  ) != null && !kensyuRirekiBean.getKaisibi(  ).equals("")){
			setKaisibi( PZZ010_CharacterUtil.ChangeYmd( kensyuRirekiBean.getKaisibi(  ) ) );
        }else{
			setKaisibi( "" );
		}
        //�I����
		if ( kensyuRirekiBean.getSyuryobi(  ) != null && !kensyuRirekiBean.getSyuryobi(  ).equals("")){
			setSyuryobi( PZZ010_CharacterUtil.ChangeYmd( kensyuRirekiBean.getSyuryobi(  ) ) );
		}else{
			setSyuryobi( "" );
		}
		//�_��
		if ( kensyuRirekiBean.getTensu() != null ){
			setTensu( kensyuRirekiBean.getTensu().toString());
		}else{
			setTensu( "" );
		}
		//����
		if ( kensyuRirekiBean.getSeiseki(  ) != null && !kensyuRirekiBean.getSeiseki(  ).equals("")){
			setSeiseki( kensyuRirekiBean.getSeiseki());
		}else{
			setSeiseki( "" );
		}
		//�o�ȓ���
		if (kensyuRirekiBean.getSyussekiNissuu() != null){
			setSyussekiNissuu( kensyuRirekiBean.getSyussekiNissuu().toString());
		}else{
			setSyussekiNissuu( "" );
		}
		//���є��l
		if ( kensyuRirekiBean.getSeisekiBikou(  ) != null && !kensyuRirekiBean.getSeisekiBikou(  ).equals("")){
			setSeisekiBikou( kensyuRirekiBean.getSeisekiBikou());
		}else{
			setSeisekiBikou( "" );
		}
		//�C������
		if ( kensyuRirekiBean.getSyuryoHantei(  )  != null && !kensyuRirekiBean.getSyuryoHantei(  ).equals("")){
	        setSyuryoHantei( PCY_CodeBean.getInstance(  ).getValue( 
        						PCY_CodeBean.SYURYO_HANTEI , kensyuRirekiBean.getSyuryoHantei(  ) ) );
		}else{
			setSyuryoHantei( "" );
		}
    }

	/**
	 * @return
	 */
	public String getClassCode() {
		return classCode;
	}

	/**
	 * @return
	 */
	public String getClassMei() {
		return classMei;
	}

	/**
	 * @return
	 */
	public String getKaisibi() {
		return kaisibi;
	}

	/**
	 * @return
	 */
	public String getKamokuCode() {
		return kamokuCode;
	}

	/**
	 * @return
	 */
	public String getKamokuMei1() {
		return kamokuMei1;
	}

	/**
	 * @return
	 */
	public String getSeiseki() {
		return seiseki;
	}

	/**
	 * @return
	 */
	public String getSeisekiBikou() {
		return seisekiBikou;
	}

	/**
	 * @return
	 */
	public String getSimeiNo() {
		return simeiNo;
	}

	/**
	 * @return
	 */
	public String getSyuryobi() {
		return syuryobi;
	}

	/**
	 * @return
	 */
	public String getSyuryoHantei() {
		return syuryoHantei;
	}

	/**
	 * @return
	 */
	public String getSyussekiNissuu() {
		return syussekiNissuu;
	}

	/**
	 * @return
	 */
	public String getTensu() {
		return tensu;
	}

	/**
	 * @param string
	 */
	public void setClassCode(String string) {
		classCode = string;
	}

	/**
	 * @param string
	 */
	public void setClassMei(String string) {
		classMei = string;
	}

	/**
	 * @param string
	 */
	public void setKaisibi(String string) {
		kaisibi = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuCode(String string) {
		kamokuCode = string;
	}

	/**
	 * @param string
	 */
	public void setKamokuMei1(String string) {
		kamokuMei1 = string;
	}

	/**
	 * @param string
	 */
	public void setSeiseki(String string) {
		seiseki = string;
	}

	/**
	 * @param string
	 */
	public void setSeisekiBikou(String string) {
		seisekiBikou = string;
	}

	/**
	 * @param string
	 */
	public void setSimeiNo(String string) {
		simeiNo = string;
	}

	/**
	 * @param string
	 */
	public void setSyuryobi(String string) {
		syuryobi = string;
	}

	/**
	 * @param string
	 */
	public void setSyuryoHantei(String string) {
		syuryoHantei = string;
	}

	/**
	 * @param string
	 */
	public void setSyussekiNissuu(String string) {
		syussekiNissuu = string;
	}

	/**
	 * @param string
	 */
	public void setTensu(String string) {
		tensu = string;
	}

}
