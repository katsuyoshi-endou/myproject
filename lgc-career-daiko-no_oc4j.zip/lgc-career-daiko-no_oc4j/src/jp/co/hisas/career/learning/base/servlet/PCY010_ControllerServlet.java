/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/01/09  01.00       ���� �a��    �V�K�쐬
 *   2004/06/18              ����@���V   �A�N�Z�X���O�J�E���g�����ǉ�
 *   2004/06/19              ����@���V   �x����O���A���O�ɏo�͂���悤�C��
 *   2004/06/23              ����@���V   execute���\�b�h����̖߂�l��null�̏ꍇ�������Ƀt�H���[�h���Ȃ��悤�ɏC��
 *   2004/06/28              �n�� ��q    ���O�C���҂̎���No�擾������getLoginNo()�ɏC��
 *   2004/07/09              ����@���V   PCY020_SetCharacterEncodingFilter�ɂăG���R�[�h�������s������setCharacterEncoding����������
 *   2005/11/08             QUANLA       sendRedirect���\�b�h��forward���\�b�h�ɕύX���Ďg�p����B
 */
package jp.co.hisas.career.learning.base.servlet;

import jp.co.hisas.career.base.userinfo.bean.*;
import jp.co.hisas.career.learning.base.*;
import jp.co.hisas.career.learning.base.bean.PCY_AccessLogBean;
import jp.co.hisas.career.learning.base.ejb.*;
import jp.co.hisas.career.learning.base.valuebean.*;
import jp.co.hisas.career.util.log.*;
import jp.co.hisas.career.util.property.*;

import java.io.*;

import java.rmi.*;

import java.util.*;

import javax.ejb.*;

import javax.naming.*;

import javax.servlet.*;
import javax.servlet.http.*;


/**
 *<PRE>
 *
 * �N���X���F
 *   PCY010_ControllerServlet
 *
 * �@�\�����F
 *   ���C�Ǘ��@�\�̃T�[�u���b�g�̃X�[�p�[�N���X�ƂȂ�܂��B
 *   �{�T�[�u���b�g�̃T�u�N���X���쐬����Ƃ��́A
 *   <code>protected String execute(HttpServletRequest, HttpServletResponse)</code>
 *   ���\�b�h���I�[�o�[���C�h���Ă��������B
 *   �{�N���X�̓r�W�l�X���W�b�N���������s���Ȃ��� JSP �ɏ�����]�����܂��B
 *
 *</PRE>
 */
public class PCY010_ControllerServlet extends HttpServlet {
    //private static final String errorPage   = "/" + HcdbDef.root + "/view/base/error/VYY_Error.jsp";	//2005/11/08_LYCE_R_QUANLA
    private static final String errorPage = "/view/base/error/VYY_Error.jsp"; //2005/11/08_LYCE_A_QUANLA
    private static final String warningPage = "/view/learning/VCY020_Warning.jsp";
    private Properties maps                 = new Properties(  );
    private Properties props                = new Properties(  );

    /**
     * �������������s���B
     *
     * @param config
     * @throws javax.servlet.ServletException
     * @see javax.servlet.Servlet#init(javax.servlet.ServletConfig)
     */
    public void init( ServletConfig config ) throws ServletException {
        super.init( config );

        // ���\�b�h�g���[�X�o��
        Log.method( "", "IN", "" );

        for ( Enumeration enume = config.getInitParameterNames(  ); enume.hasMoreElements(  ); ) {
            String name = ( String )enume.nextElement(  );

            if ( name.startsWith( "forward." ) ) {
                maps.setProperty( name.replaceAll( "^forward\\.", "" ),
                    config.getInitParameter( name ) );
            } else if ( name.startsWith( "property." ) ) {
                props.setProperty( name.replaceAll( "^property\\.", "" ),
                    config.getInitParameter( name ) );
            }
        }

        // ���\�b�h�g���[�X�o��
        Log.method( "", "OUT", "" );
    }

    /**
     * �u���E�U����̌����v�����󂯎��A�{�N���X�̎��s���\�b�h���Ăяo���܂��B
     *
     * @param request ���N�G�X�g
     * @param response ���X�|���X
     * @throws ServletException �T�[�u���b�g��O
     * @throws IOException ���o�͗�O
     * @see javax.servlet.http.HttpServlet#service( javax.servlet.http.HttpServletRequest,
     *                                              javax.servlet.http.HttpServletResponse )
     */
    protected void service( HttpServletRequest request, HttpServletResponse response )
        throws ServletException, IOException {
        String simeiNo = "";

        try {
            // ���\�b�h�g���[�X�o��
            Log.method( simeiNo, "IN", "" );

            // session ���Ȃ�������G���[��ʂ֑J��
            HttpSession session = request.getSession( false );

            if ( session == null ) {
                //response.sendRedirect( errorPage );	//2005/11/08_LYCE_R_QUANLA
                this.getServletConfig( ).getServletContext( ).getRequestDispatcher( errorPage ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA

                return;
            }

            // userinfo ���Ȃ����Auserinfo �� ����NO ���Ȃ�������G���[��ʂ֑J��
            UserInfoBean userinfo = ( UserInfoBean )session.getAttribute( "userinfo" );

            if ( ( userinfo == null ) || ( userinfo.getLogin_no(  ) == null )
                || userinfo.getLogin_no(  ).equals( "" ) ) {
                session.invalidate(  );
                //response.sendRedirect( errorPage );	//2005/11/08_LYCE_R_QUANLA
                this.getServletConfig( ).getServletContext( ).getRequestDispatcher( errorPage ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA

                return;
            }

            simeiNo = userinfo.getLogin_no(  );  // CHG#P-PLP40-013-001

            // ���C�Ǘ����O�C�����[�U��񂪂Ȃ�������쐬
            PCY_PersonalBean loginuser = ( PCY_PersonalBean )session.getAttribute( 
                    "learning.userinfo" );

            if ( loginuser == null ) {
                synchronized ( session ) {
                    PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance(  );
                    PCY_PersonalEJBHome home   = ( PCY_PersonalEJBHome )locator.getServiceLocation( "PCY_PersonalEJB",
                            PCY_PersonalEJBHome.class );
                    PCY_PersonalEJB ejb = home.create(  );
                    loginuser = new PCY_PersonalBean(  );
                    loginuser.setSimeiNo( simeiNo );
                    loginuser = ejb.getPersonalInfo( simeiNo, loginuser );
                    session.setAttribute( "learning.userinfo", loginuser );
                }
            }

            // �p�t�H�[�}���X���O�o��
            Log.performance( simeiNo, true, "" );

            // �G���R�[�h�w��ƃ��N�G�X�g�I�u�W�F�N�g�̃��b�s���O
//            request.setCharacterEncoding( "Windows-31J" );
            request = new LearningRequest( request );

            // �Ɩ��������s�Ɖ�ʑJ��
            String next = null;

            try {
                next = execute( request, response, loginuser );
            } catch ( PCY_WarningException e ) {
                Log.error( simeiNo, "HJE-xxxx", e );
                next = warningPage;
            }

            /* �A�N�Z�X���O���L�^ */
            if ( request.getRequestURI(  ) != null ) {
                countAccessLog( ( PCY_AccessLogBean )session.getAttribute( "learning.accesslog" ),
                    request.getRequestURI(  ).substring( request.getRequestURI(  ).lastIndexOf( "/" )
                        + 1 ) );
            }

            request.setAttribute( "properties", props );
			if ( next != null ) {
				getServletContext().getRequestDispatcher( next ).forward( request, response );
			}
            // �p�t�H�[�}���X���O�o��
            Log.performance( simeiNo, false, "" );

            // ���\�b�h�g���[�X�o��
            Log.method( simeiNo, "OUT", "" );
        } catch ( UnsupportedEncodingException e ) {
            Log.error( simeiNo, "HJE-0007", e );
            //response.sendRedirect( errorPage );	//2005/11/08_LYCE_R_QUANLA
            this.getServletConfig( ).getServletContext( ).getRequestDispatcher( errorPage ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( IllegalArgumentException e ) {
            Log.error( simeiNo, "HJE-0009", e );
            //response.sendRedirect( errorPage );	//2005/11/08_LYCE_R_QUANLA
            this.getServletConfig( ).getServletContext( ).getRequestDispatcher( errorPage ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( IllegalStateException e ) {
            Log.error( simeiNo, "HJE-0010", e );
            //response.sendRedirect( errorPage );	//2005/11/08_LYCE_R_QUANLA
            this.getServletConfig( ).getServletContext( ).getRequestDispatcher( errorPage ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( ServletException e ) {
            Log.error( simeiNo, "HJE-0015", e );
            //response.sendRedirect( errorPage );	//2005/11/08_LYCE_R_QUANLA
            this.getServletConfig( ).getServletContext( ).getRequestDispatcher( errorPage ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( IOException e ) {
            Log.error( simeiNo, "HJE-0012", e );
            //response.sendRedirect( errorPage );	//2005/11/08_LYCE_R_QUANLA
            this.getServletConfig( ).getServletContext( ).getRequestDispatcher( errorPage ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        } catch ( Exception e ) {
            Log.error( simeiNo, "HJE-0017", e );
            //response.sendRedirect( errorPage );	//2005/11/08_LYCE_R_QUANLA
            this.getServletConfig( ).getServletContext( ).getRequestDispatcher( errorPage ).forward( request, response ); //2005/11/08_LYCE_A_QUANLA
        }
    }

    /**
     * �T�u�N���X�ł͂��̃��\�b�h���I�[�o�[���C�h���ĉ������B
     * �{�N���X�ł͉������s���� JSP �ɓ]�����܂��B
     *
     * @param request ���N�G�X�g
     * @param response ���X�|���X
     * @param loginuser ���O�C�����[�U���
     * @return �J�ڐ�p�X
     * @throws ServletException �T�[�u���b�g��O
     * @throws IOException ���o�͗�O
     * @throws NamingException ���O������O
     * @throws RemoteException �����[�g��O
     * @throws CreateException �N���G�C�g��O
     * @throws PCY_WarningException ���[�j���O
     * @throws Exception ���̑��̗�O
     */
    protected String execute( HttpServletRequest request, HttpServletResponse response,
        PCY_PersonalBean loginuser )
        throws ServletException, IOException, NamingException, RemoteException, CreateException, 
            PCY_WarningException, Exception {
        return getForwardPath(  );
    }

    /**
     * �f�t�H���g�̃X�e�[�^�X(success)�œ]���p�X���擾���܂��B
     *
     * @return �f�t�H���g�̑J�ڐ�p�X
     * @exception IllegalStateException �f�t�H���g�̃X�e�[�^�X(success)�����݂��Ȃ��ꍇ
     */
    protected String getForwardPath(  ) throws IllegalStateException {
        try {
            return getForwardPath( "success" );
        } catch ( IllegalArgumentException iae ) {
            IllegalStateException e = new IllegalStateException( "�T�[�u���b�g��:" + getServletName(  ) );
            Log.error( "", "HJE-0010", e );
            throw e;
        }
    }

    /**
     * �w�肵���X�e�[�^�X�œ]���p�X���擾���܂��B
     *
     * @param status �X�e�[�^�X
     * @return �w�肳�ꂽ�X�e�[�^�X�̑J�ڐ�p�X
     * @exception IllegalArgumentException null �܂��͑��݂��Ȃ��X�e�[�^�X���n���ꂽ�ꍇ
     */
    protected String getForwardPath( String status ) throws IllegalArgumentException {
        if ( ( status == null ) || !maps.containsKey( status ) ) {
            IllegalArgumentException e = new IllegalArgumentException( "�T�[�u���b�g��:"
                    + getServletName(  ) + ",�X�e�[�^�X:" + status );
            Log.error( "", "HJE-0009", e );
            throw e;
        }

        return maps.getProperty( status );
    }

    /**
     * �w�肵���L�[�Ńv���p�e�B���擾���܂��B
     *
     * @param key �L�[
     * @return �w�肳�ꂽ�L�[�̃v���p�e�B
     */
    protected String getProperty( String key ) {
        if ( ( key == null ) || !props.containsKey( key ) ) {
            return null;
        }

        return props.getProperty( key );
    }

    /**
     * �A�N�Z�X���O���擾����
     * @param accessLogBean
     * @param gamen_id
     * @return
     */
    private boolean countAccessLog( PCY_AccessLogBean accessLogBean, String gamen_id ) {
        /* �{�l���C��� */
        if ( gamen_id.equals( "PCA010_HonninKensyuJyohouFrameServlet" ) ) {
            accessLogBean.setHonninKensyuJyohou( accessLogBean.getHonninKensyuJyohou(  ) + 1 );

            return true;
        }

        /* ���C���ǉ� */
        if ( gamen_id.equals( "PCA024_KensyuJyohouTuikaKanryoServlet" ) ) {
            accessLogBean.setKensyuJyohouTuika( accessLogBean.getKensyuJyohouTuika(  ) + 1 );

            return true;
        }

        /* ���C���X�V */
        if ( gamen_id.equals( "PCA027_KensyuJyohouKousinKanryoServlet" ) ) {
            accessLogBean.setKensyuJyohouKousin( accessLogBean.getKensyuJyohouKousin(  ) + 1 );

            return true;
        }

        /* ���C���폜 */
        if ( gamen_id.equals( "PCA029_KensyuJyohouSakujyoKanryoServlet" ) ) {
            accessLogBean.setKensyuJyohouSakujyo( accessLogBean.getKensyuJyohouSakujyo(  ) + 1 );

            return true;
        }

        /* ���C�������X�V */
        if ( gamen_id.equals( "PCA032_KensyuKanryobiKousinKanryoServlet" )
            || gamen_id.equals( "PCA032_KensyuKanryobiKousinKanryoServlet" ) ) {
            accessLogBean.setKensyuKanryobiKousin( accessLogBean.getKensyuKanryobiKousin(  ) + 1 );

            return true;
        }

        /* ���C�ڍ� */
        if ( gamen_id.equals( "PCA015_KamokuSyosaiServlet" ) ) {
            accessLogBean.setKensyuSyosai( accessLogBean.getKensyuSyosai(  ) + 1 );

            return true;
        }

        /* ���Ȑ\���ڍ� */
        if ( gamen_id.equals( "PCA017_JikosinkokuSyosaiServlet" ) ) {
            accessLogBean.setJikosinkokuSyosai( accessLogBean.getJikosinkokuSyosai(  ) + 1 );

            return true;
        }

        /* ���C�҃N���X�ڍ� */
        if ( gamen_id.equals( "PCA018_ClassSyosaiServlet" ) ) {
            accessLogBean.setKensyusyaClassSyosai( accessLogBean.getKensyusyaClassSyosai(  ) + 1 );

            return true;
        }

        /* ���C�\�� */
        if ( gamen_id.equals( "PCA014_KensyuMousikomiKanryoServlet" ) ) {
            accessLogBean.setKensyuMousikomi( accessLogBean.getKensyuMousikomi(  ) + 1 );

            return true;
        }

        /* �\����� */
        if ( gamen_id.equals( "PCA021_MousikomiTorikesiServlet" ) ) {
            accessLogBean.setMousikomiTorikesi( accessLogBean.getMousikomiTorikesi(  ) + 1 );

            return true;
        }

        /* ��u�� */
        if ( gamen_id.equals( "PCA034_JyukouHoukokuServlet" )
            || gamen_id.equals( "PCA034_JyukouHoukokuOnlyServlet" )
            || gamen_id.equals( "PCA034_JyukouHoukokuServlet" ) ) {
            accessLogBean.setJyukouHoukoku( accessLogBean.getJyukouHoukoku(  ) + 1 );

            return true;
        }

        /* ES�F�� */
        if ( gamen_id.equals( "PCA037_ReportTeisyutuEsNinsyoServlet" )
            || gamen_id.equals( "PCA037_ReportEsNinsyoReturnServlet" )
            || gamen_id.equals( "PCA081_JikohyokaEsNinsyoServlet" )
            || gamen_id.equals( "PCA081_SitumonEsNinsyoServlet" )
            || gamen_id.equals( "PCA081_JyukouSinkokuEsNinsyoServlet" )
            || gamen_id.equals( "PCA033_KensyuKanryobiKousinEsNinsyoServlet" ) ) {
            accessLogBean.setEsNinsyo( accessLogBean.getEsNinsyo(  ) + 1 );

            return true;
        }

        /* ���|�[�g��o */
        if ( gamen_id.equals( "PCA035_ReportTeisyutuServlet" )
            || gamen_id.equals( "PCA036_ReportTeisyutuKanryoServlet" ) ) {
            accessLogBean.setReportTeisyutu( accessLogBean.getReportTeisyutu(  ) + 1 );

            return true;
        }

        /* ������� */
        if ( gamen_id.equals( "PCA087_SitumonNyuryokuServlet" )
            || gamen_id.equals( "PCA089_SitumonKanryoServlet" ) ) {
            accessLogBean.setSitumonNyuryoku( accessLogBean.getSitumonNyuryoku(  ) + 1 );

            return true;
        }

        /* ���ȕ]������ */
        if ( gamen_id.equals( "PCA084_JikohyokaNyuryokuServlet" )
            || gamen_id.equals( "PCA086_JikohyokaKanryoServlet" ) ) {
            accessLogBean.setJikohyokaNyuryoku( accessLogBean.getJikohyokaNyuryoku(  ) + 1 );

            return true;
        }

        /* ��u�\������ */
        if ( gamen_id.equals( "PCA08a_JyukouSinkokuNyuryokuServlet" )
            || gamen_id.equals( "PCA08c_JyukouSinkokuKanryoServlet" ) ) {
            accessLogBean.setJyukouSinkokuNyuryoku( accessLogBean.getJyukouSinkokuNyuryoku(  ) + 1 );

            return true;
        }

        /* �Ȗڈꗗ */
        if ( gamen_id.equals( "PCA091_KamokuIchiranServlet" ) ) {
            accessLogBean.setKamokuItiran( accessLogBean.getKamokuItiran(  ) + 1 );

            return true;
        }

        /* ���F�Ҋm�F�E�ύX */
        if ( gamen_id.equals( "PCA170_SyoninsyaKakuninHenkouFrameServlet" ) ) {
            accessLogBean.setSyoninsyaKakuninHenkou( accessLogBean.getSyoninsyaKakuninHenkou(  )
                + 1 );

            return true;
        }

        /* ���F�ґI�� */
        if ( gamen_id.equals( "PCA182_SyoninsyaSentakuServlet" ) ) {
            accessLogBean.setSyoninsyaSentaku( accessLogBean.getSyoninsyaSentaku(  ) + 1 );

            return true;
        }

        /* ���F�Ґݒ� */
        if ( gamen_id.equals( "PCA183_SyoninsyaSetteiKanryoServlet" ) ) {
            accessLogBean.setSyoninsyaSettei( accessLogBean.getSyoninsyaSettei(  ) + 1 );

            return true;
        }

        /* ���F�ҍ폜 */
        if ( gamen_id.equals( "PCA191_SyoninsyaSakujyoKanryoServlet" ) ) {
            accessLogBean.setSyoninsyaSakujyo( accessLogBean.getSyoninsyaSakujyo(  ) + 1 );

            return true;
        }

        /* ���F */
        if ( gamen_id.equals( "PCB145_SyoninServlet" ) ) {
            accessLogBean.setSyonin( accessLogBean.getSyonin(  ) + 1 );

            return true;
        }

        /* ���F���� */
        if ( gamen_id.equals( "PCB146_SasimodosiServlet" ) ) {
            accessLogBean.setSyoninSasimodosi( accessLogBean.getSyoninSasimodosi(  ) + 1 );

            return true;
        }

        /* ���C�Ǘ���� */
        if ( gamen_id.equals( "PCC010_KensyuKanriJyohouFrameServlet" ) ) {
            accessLogBean.setKensyukanriJyohou( accessLogBean.getKensyukanriJyohou(  ) + 1 );

            return true;
        }

        /* ���C�Ǘ��N���X�ڍ� */
        if ( gamen_id.equals( "PCC020_ClassSyosaiServlet" ) ) {
            accessLogBean.setKensyukanriJyohou( accessLogBean.getKensyukanriJyohou(  ) + 1 );

            return true;
        }

        /* �N���X���� */
        if ( gamen_id.equals( "PCC015_ClassCyoseiFrameServlet" ) ) {
            accessLogBean.setClassCyosei( accessLogBean.getClassCyosei(  ) + 1 );

            return true;
        }

        /* ��t */
        if ( gamen_id.equals( "PCC018_ClassCyoseiUketukeServlet" ) ) {
            accessLogBean.setUketuke( accessLogBean.getUketuke(  ) + 1 );

            return true;
        }

        /* ��t���� */
        if ( gamen_id.equals( "PCC018_ClassCyoseiSasimodosiServlet" ) ) {
            accessLogBean.setUketukeSasimodosi( accessLogBean.getUketukeSasimodosi(  ) + 1 );

            return true;
        }

        /* �N���X���~ */
        if ( gamen_id.equals( "PCC019_ClassCyusiServlet" ) ) {
            accessLogBean.setClassCyusi( accessLogBean.getClassCyusi(  ) + 1 );

            return true;
        }

        /* ���ѓ��� */
        if ( gamen_id.equals( "PCC072_SeisekiNyuryokuKanryoServlet" ) ) {
            accessLogBean.setSeisekiNyuryoku( accessLogBean.getSeisekiNyuryoku(  ) + 1 );

            return true;
        }

        /* �N���X�I�� */
        if ( gamen_id.equals( "PCC074_ClassSyuryoServlet" ) ) {
            accessLogBean.setClassSyuryo( accessLogBean.getClassSyuryo(  ) + 1 );

            return true;
        }

        /* ��s���� */
        if ( gamen_id.equals( "PCC242_DaikoNyuryokuSetteiServlet" ) ) {
            accessLogBean.setDaikouNyuryoku( accessLogBean.getDaikouNyuryoku(  ) + 1 );

            return true;
        }

        /* ����\�� */
        if ( gamen_id.equals( "PCC076_KenryuRirekiHoukokusyoDownloadServlet" )
            || gamen_id.equals( "PCC076_MousikomiHoukokusyoDownloadServlet" )
            || gamen_id.equals( "PCC076_MousikomiHoukokusyoHyojiServlet" )
            || gamen_id.equals( "PCC076_KenryuRirekiHoukokusyoHyojiServlet" ) ) {
            accessLogBean.setSitumonHyoji( accessLogBean.getSitumonHyoji(  ) + 1 );

            return true;
        }

        /* �N���X�ĊJ */
        if ( gamen_id.equals( "PCC079_ClassSaikaiServlet" ) ) {
            accessLogBean.setClassSaikai( accessLogBean.getClassSaikai(  ) + 1 );

            return true;
        }

        /* �Ȗړo�^ */
        if ( gamen_id.equals( "PCC082_KamokuTourokuKanryoServlet" ) ) {
            accessLogBean.setKamokuTouroku( accessLogBean.getKamokuTouroku(  ) + 1 );

            return true;
        }

        /* �ȖڕύX */
        if ( gamen_id.equals( "PCC084_KamokuHenkouKanryoServlet" ) ) {
            accessLogBean.setKamokuHenkou( accessLogBean.getKamokuHenkou(  ) + 1 );

            return true;
        }

        /* �Ȗڍ폜 */
        if ( gamen_id.equals( "PCC086_KamokuSakujyoKanryoServlet" ) ) {
            accessLogBean.setKamokuSakujyo( accessLogBean.getKamokuSakujyo(  ) + 1 );

            return true;
        }

        /* �ȖڑI�� */
        if ( gamen_id.equals( "PCC080_KamokuSentakuKakuteiServlet" ) ) {
            accessLogBean.setKamokuSentaku( accessLogBean.getKamokuSentaku(  ) + 1 );

            return true;
        }

        /* �N���X�o�^ */
        if ( gamen_id.equals( "PCC092_ClassTourokuKanryoServlet" ) ) {
            accessLogBean.setClassTouroku( accessLogBean.getClassTouroku(  ) + 1 );

            return true;
        }

        /* �N���X�ύX */
        if ( gamen_id.equals( "PCC095_ClassHenkouKanryoServlet" ) ) {
            accessLogBean.setClassHenkou( accessLogBean.getClassHenkou(  ) + 1 );

            return true;
        }

        /* �N���X�폜 */
        if ( gamen_id.equals( "PCC097_ClassSakujyoKanryoServlet" ) ) {
            accessLogBean.setClassSakujyo( accessLogBean.getClassSakujyo(  ) + 1 );

            return true;
        }

        /* ���C���[�h�}�b�v�o�^ */
        if ( gamen_id.equals( "PCC100_CurriculumMapTourokuServlet" ) ) {
            accessLogBean.setCurriculumMapTouroku( accessLogBean.getCurriculumMapTouroku(  ) + 1 );

            return true;
        }

        /* �Ώە���ݒ� */
        if ( gamen_id.equals( "PCC110_TaisyososikiAddServlet" ) ) {
            accessLogBean.setTaisyoBumonSettei( accessLogBean.getTaisyoBumonSettei(  ) + 1 );

            return true;
        }

        /* �ΏېE��ݒ� */
        if ( gamen_id.equals( "PCC120_TaisyosyokusyuAddServlet" ) ) {
            accessLogBean.setTaisyoSyokusyuSettei( accessLogBean.getTaisyoSyokusyuSettei(  ) + 1 );

            return true;
        }

        /* �ΏێҐݒ� */
        if ( gamen_id.equals( "PCC130_TaisyosyaSetteiServlet" ) ) {
            accessLogBean.setTaisyosyaSettei( accessLogBean.getTaisyosyaSettei(  ) + 1 );

            return true;
        }

        /* �ΏێҐݒ茟������ */
        if ( gamen_id.equals( "PCC140_TaisyosyaKensakuServlet" ) ) {
            accessLogBean.setTaisyosyaSetteiKensakukekka( accessLogBean
                .getTaisyosyaSetteiKensakukekka(  ) + 1 );

            return true;
        }

        /* ��u�� */
        if ( gamen_id.equals( "PCC190_JyukoJyokyoFrameServlet" ) ) {
            accessLogBean.setJyukouJyokyo( accessLogBean.getJyukouJyokyo(  ) + 1 );

            return true;
        }

        /* ��u�t�H���[ */
        if ( gamen_id.equals( "PCC193_SendJyukouFollowMailServlet" ) ) {
            accessLogBean.setJyukouFollow( accessLogBean.getJyukouFollow(  ) + 1 );

            return true;
        }

        /* �F��ΏێҌ��� */
        if ( gamen_id.equals( "PCC182_JyukouNinteiTaisyoFrameServlet" ) ) {
            accessLogBean.setNinteiTaisyosyaKensaku( accessLogBean.getNinteiTaisyosyaKensaku(  )
                + 1 );

            return true;
        }

        /* �F��Ώێ҈ꗗ  ��ʂ����݂��Ȃ��̂ŃJ�E���g���Ȃ� */
        /* ��u�F��o�^ */
        if ( gamen_id.equals( "PCC184_JukouNinteiSetteiServlet" ) ) {
            accessLogBean.setJyukouNinteiTouroku( accessLogBean.getJyukouNinteiTouroku(  ) + 1 );

            return true;
        }

        /* ��u�F����� */
        if ( gamen_id.equals( "PCC186_JukouNinteiTorikesiServlet" ) ) {
            accessLogBean.setJyukouNinteiKaijyo( accessLogBean.getJyukouNinteiKaijyo(  ) + 1 );

            return true;
        }

		/* �f�t�H���g�ݒ� */
		if ( gamen_id.equals( "PCC400_DefaultSetteiFrameServlet" ) ) {
			accessLogBean.setDefaultSettei( accessLogBean.getDefaultSettei(  ) + 1 );

			return true;
		}

        return false;
    }

    private class LearningRequest extends HttpServletRequestWrapper {
        public LearningRequest( HttpServletRequest request ) {
            super( request );
        }

        public String getParameter( String name ) {
            Enumeration names = getParameterNames(  );

            while ( names.hasMoreElements(  ) ) {
                String tmp = ( String )names.nextElement(  );

                if ( tmp.equals( name ) || tmp.matches( "[FBTARSCH]\\d\\d\\d_" + name ) ) {
                    return super.getParameter( tmp );
                }
            }

            return null;
        }

        public String[] getParameterValues( String name ) {
            Collection ret    = new ArrayList(  );
            Enumeration names = getParameterNames(  );

            while ( names.hasMoreElements(  ) ) {
                String tmp = ( String )names.nextElement(  );

                if ( tmp.equals( name ) || tmp.matches( "[FBTARSCH]\\d\\d\\d_" + name ) ) {
                    ret.addAll( Arrays.asList( super.getParameterValues( tmp ) ) );
                }
            }

            return ( ret.size(  ) == 0 ) ? null : ( String[] )ret.toArray( new String[0] );
        }
    }
}
