/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.soshikiupdate.ejb;

/**
 * Home interface for ContencyCheckerEJB.
 * @xdoclet-generated at 2005/11/07
 */
public interface ContencyCheckerEJBHome extends javax.ejb.EJBHome {
	public static final String COMP_NAME = "java:comp/env/ejb/ContencyCheckerEJB";

	public static final String JNDI_NAME = "ContencyCheckerEJB";

	public jp.co.hisas.addon.batch.soshikiupdate.ejb.ContencyCheckerEJB create() throws javax.ejb.CreateException, java.rmi.RemoteException;

}
