/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.addon.batch.learning.result;

import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/** �捞���̃��O�P�s�ɑ�������f�[�^ */
public class ImportErrorLog {
	private String messageID;

	private Long row;

	private String kamokuCode;

	private String classCode;

	private String simeiNo;

	private String message;

	/** �f�[�^��CSV�`���ɂ��ĕԂ� */
	public String toCSV() {
		final StringBuffer ret = new StringBuffer();
		ret.append("\"");
		ret.append(this.messageID == null ? "" : this.messageID);
		ret.append("\"");
		ret.append(",");
		ret.append("\"");
		ret.append(this.row == null ? "" : this.row.toString());
		ret.append("\"");
		ret.append(",");
		ret.append("\"");
		ret.append(this.kamokuCode == null ? "" : this.kamokuCode);
		ret.append("\"");
		ret.append(",");
		ret.append("\"");
		ret.append(this.classCode == null ? "" : this.classCode);
		ret.append("\"");
		ret.append(",");
		ret.append("\"");
		ret.append(this.simeiNo == null ? "" : this.simeiNo);
		ret.append("\"");
		ret.append(",");
		ret.append("\"");
		ret.append(this.message == null ? "" : this.message);
		ret.append("\"");
		return ret.toString();
	}

	public String toString() {
		final StringBuffer ret = new StringBuffer();
		ret.append(this.messageID == null ? "" : this.messageID);
		ret.append(":");
		ret.append(this.message == null ? "" : this.message);
		return ret.toString();
	}

	public static ImportErrorLog getInstance(final String messageID) {
		return ImportErrorLog.getInstance(messageID, null, null, null, null);
	}

	public static ImportErrorLog getInstance(final String messageID, final Long row, final String kamokuCode, final String classCode, final String simeiNo) {

		final ImportErrorLog ret = new ImportErrorLog();

		ret.messageID = messageID;
		ret.row = row;
		ret.kamokuCode = kamokuCode;
		ret.classCode = classCode;
		ret.simeiNo = simeiNo;
		ret.message = (String) ReadFile.getMsgMapData(HcdbDef.MESSAGE_FILE_PATH).get(messageID);
		return ret;
	}

	// Setter & Getter
	public String getClassCode() {
		return this.classCode;
	}

	public String getKamokuCode() {
		return this.kamokuCode;
	}

	public String getMessage() {
		return this.message;
	}

	public String getMessageID() {
		return this.messageID;
	}

	public Long getRow() {
		return this.row;
	}

	public String getSimeiNo() {
		return this.simeiNo;
	}

	public void setClassCode(final String string) {
		this.classCode = string;
	}

	public void setKamokuCode(final String string) {
		this.kamokuCode = string;
	}

	public void setMessage(final String string) {
		this.message = string;
	}

	public void setMessageID(final String string) {
		this.messageID = string;
	}

	public void setRow(final Long long1) {
		this.row = long1;
	}

	public void setSimeiNo(final String string) {
		this.simeiNo = string;
	}

}
