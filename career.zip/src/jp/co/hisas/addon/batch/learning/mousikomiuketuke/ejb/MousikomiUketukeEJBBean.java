package jp.co.hisas.addon.batch.learning.mousikomiuketuke.ejb;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.common.exception.CareerException;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;

/**
 * <PRE>
 * 
 * �N���X���F MousikomiUketukeEJBBean�N���X �@�\�����F���͉�А\���ݎ�t���������s����
 * 
 * </PRE>
 * 
 * @ejb.bean name="MousikomiUketukeEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class MousikomiUketukeEJBBean implements SessionBean {
	private SessionContext context = null;

	/**
	 * @throws CareerException 
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int execute() throws CareerException {
		int exitCd = 0;
		
		Connection conn = null;
		CallableStatement cstmt = null;

		try {
			conn = PZZ040_SQLUtility.getConnection("");
			
			String sql = "{?=call BATCH_MOUSIKOMI_UKETUKE.MAIN(?)}";
			cstmt = conn.prepareCall( sql );
			cstmt.registerOutParameter( 1, java.sql.Types.INTEGER );
			cstmt.setString( 2, "BATCH" );
			cstmt.execute();
			exitCd = cstmt.getInt( 1 );
			
			return exitCd;
		} catch (SQLException e) {
			throw new CareerException(e);
		} catch (NamingException e) {
			throw new CareerException(e);
		} finally {
			PZZ040_SQLUtility.closeConnection( "", conn, cstmt, null );
		}
	}
	
	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {

	}
}
