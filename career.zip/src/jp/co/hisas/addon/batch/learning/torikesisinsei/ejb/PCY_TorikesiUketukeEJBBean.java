/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/10/22  01.00      ���� ���V    �V�K�쐬
 */
package jp.co.hisas.addon.batch.learning.torikesisinsei.ejb;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.addon.batch.learning.torikesisinsei.valuebean.PCY_TorikesiSinseiWorkTableBean;
import jp.co.hisas.career.learning.base.PCY_ServiceLocator;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY_TorikesiUketukeEJBBean�N���X �@�\�����F ���C�Ǘ��Ҏ����t�@�\
 * 
 * </PRE>
 * 
 * @ejb.bean name="PCY_TorikesiUketukeEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_TorikesiUketukeEJBBean implements SessionBean {
	/**
	 * �����t�������s���܂��B
	 * @param loginuser
	 * @return
	 * @throws PCY_WarningException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_TorikesiSinseiWorkTableBean[] execTorikesi(final PCY_PersonalBean loginuser) throws PCY_WarningException {
		try {
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();

			/* PCY_TorikesiUketukeDaoEJB */
			final PCY_TorikesiUketukeDaoEJBHome torikesiDao_home = (PCY_TorikesiUketukeDaoEJBHome) locator.getServiceLocation("PCY_TorikesiUketukeDaoEJB", PCY_TorikesiUketukeDaoEJBHome.class);
			final PCY_TorikesiUketukeDaoEJB torikesiDao_ejb = torikesiDao_home.create();

			/* �����t�Ώۃf�[�^�擾�i�\���󋵃e�[�u���ƌ������Ď擾����j */
			final PCY_TorikesiSinseiWorkTableBean kensaku_torikesiBean = new PCY_TorikesiSinseiWorkTableBean();
			kensaku_torikesiBean.setSousinFlg("0");

			final PCY_TorikesiSinseiWorkTableBean[] torikesiBeans = torikesiDao_ejb.doSelectWithMousikomiJyokyo(kensaku_torikesiBean, loginuser);

			/* �����t���s���\���󋵏����擾���� */
			final ArrayList mousikomiBeanList = new ArrayList();

			for (int i = 0; i < torikesiBeans.length; i++) {
				mousikomiBeanList.add(torikesiBeans[i].getMousikomiBean());
			}

			/* MousikomiEJB */
			final PCY_MousikomiJyokyoEJBHome mousikomi_home = (PCY_MousikomiJyokyoEJBHome) locator.getServiceLocation("PCY_MousikomiJyokyoEJB", PCY_MousikomiJyokyoEJBHome.class);
			final PCY_MousikomiJyokyoEJB mousikomi_ejb = mousikomi_home.create();

			/* �����t�������s�� */
			mousikomi_ejb.doCancel((PCY_MousikomiJyokyoBean[]) mousikomiBeanList.toArray(new PCY_MousikomiJyokyoBean[0]), loginuser);
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return torikesiBeans;
		} catch (final NamingException e) {
			throw new EJBException(e);
		} catch (final CreateException e) {
			throw new EJBException(e);
		} catch (final RemoteException e) {
			throw new EJBException(e);
		} catch (final PCY_WarningException e) {
			throw e;
		}
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
}
