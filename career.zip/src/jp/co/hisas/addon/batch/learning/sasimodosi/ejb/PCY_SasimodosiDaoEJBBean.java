/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/09/09  01.00      ���� ���V    �V�K�쐬
 */
package jp.co.hisas.addon.batch.learning.sasimodosi.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.addon.batch.learning.sasimodosi.valuebean.PCY_SasimodosiWorkTableBean;
import jp.co.hisas.career.learning.base.PCY_ServiceLocator;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KyosituBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PCY_SasimodosiDaoEJBBean�N���X �@�\�����F L54���߂����[�N�e�[�u���̃f�[�^�A�N�Z�X���s���N���X
 * 
 * </PRE>
 * 
 * @ejb.bean name="PCY_SasimodosiDaoEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_SasimodosiDaoEJBBean implements SessionBean {
	private SessionContext context = null;

	/**
	 * L54���߂����[�N�e�[�u���������ɁA�����œn���ꂽ���������ɏ]�� �E���߂���� �E�\���� �E�p�[�\�i����� �E�Ȗڏ�� �E�N���X��� ���Z�b�g�����z����擾���܂��B
	 * @param sasimodosiBean
	 * @param loginuser
	 * @return
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_SasimodosiWorkTableBean[] doSelectWithMousikomiJyokyo(final PCY_SasimodosiWorkTableBean sasimodosiBean, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final StringBuffer sql = new StringBuffer();
			sql.append("SELECT ");
			sql.append(PCY_KamokuBean.getColumns("KAMOKU") + ", ");
			sql.append(PCY_ClassBean.getColumns("CLASS") + ", ");
			sql.append(PCY_MousikomiJyokyoBean.getColumns("MOUSIKOMI") + ", ");
			sql.append(PCY_PersonalBean.getColumns("PERSONAL") + ", ");
			sql.append(PCY_SasimodosiWorkTableBean.getColumns("SASIMODOSI") + ", ");
			sql.append(PCY_KyosituBean.getColumns("KYOSITU"));
			sql.append(" FROM ");
			sql.append(HcdbDef.L01_TBL + " KAMOKU, ");
			sql.append(HcdbDef.L02_TBL + " CLASS, ");
			sql.append(HcdbDef.L15_TBL + " MOUSIKOMI, ");
			sql.append(HcdbDef.personalTbl + " PERSONAL, ");
			sql.append(HcdbDef.L54_TBL + " SASIMODOSI, ");
			sql.append(HcdbDef.L10_TBL + " KYOSITU ");
			sql.append(" WHERE KAMOKU.KAMOKU_CODE = CLASS.KAMOKU_CODE");
			sql.append("   AND CLASS.KAMOKU_CODE  = MOUSIKOMI.KAMOKU_CODE");
			sql.append("   AND CLASS.CLASS_CODE   = MOUSIKOMI.CLASS_CODE");
			sql.append("   AND CLASS.KAMOKU_CODE  = SASIMODOSI.KAMOKU_CODE");
			sql.append("   AND CLASS.CLASS_CODE   = SASIMODOSI.CLASS_CODE");
			sql.append("   AND MOUSIKOMI.SIMEI_NO = SASIMODOSI.SIMEI_NO");
			sql.append("   AND MOUSIKOMI.SIMEI_NO = PERSONAL.SIMEI_NO");
			sql.append("   AND PERSONAL.HONMU_FLG = '" + HcdbDef.HONMU + "'");

			final Map extract = sasimodosiBean.extractConditions();

			for (final Iterator ite = extract.keySet().iterator(); ite.hasNext();) {
				final Object key = ite.next();
				sql.append("   AND SASIMODOSI." + key.toString() + "=?");
			}

			sql.append(" AND CLASS.KYOSITU_CODE=KYOSITU.KYOSITU_CODE(+)");
			
			// �R�l�N�V�����擾
			final PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
			con = locator.getDataSource().getConnection();

			Log.debug(sql.toString());
			ps = con.prepareStatement(sql.toString());

			int ps_setCount = 1;

			for (final Iterator ite = extract.keySet().iterator(); ite.hasNext();) {
				final Object key = ite.next();
				ps.setObject(ps_setCount++, extract.get(key));
			}

			final ResultSet rs = ps.executeQuery();
			final ArrayList ret = new ArrayList();

			while (rs.next()) {
				final PCY_SasimodosiWorkTableBean sasimodosiBeanTemp = new PCY_SasimodosiWorkTableBean(rs, "SASIMODOSI");
				sasimodosiBeanTemp.setMousikomiBean(new PCY_MousikomiJyokyoBean(rs, "KAMOKU", "CLASS", "PERSONAL", "MOUSIKOMI"));

				ret.add(sasimodosiBeanTemp);
			}

			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return (PCY_SasimodosiWorkTableBean[]) ret.toArray(new PCY_SasimodosiWorkTableBean[0]);
		} catch (final NamingException e) {
			Log.error(loginuser.getSimeiNo(), "HJE-0002", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			throw new EJBException(e);

			// INS#P-ALH41-001-007-S
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (final SQLException e) {
					// �������Ȃ�
				}
			}

			if (con != null) {
				try {
					con.close();
				} catch (final SQLException e) {
					// �������Ȃ�
				}
			}
		}

		// INS#P-ALH41-001-007-E
	}

	/**
	 * �ȖڃR�[�h�A�N���X�R�[�h�A�����ԍ��������Ƃ��āA���M�t���O���X�V����B �����œn���ꂽ�z�񐔂ƍX�V�������قȂ�ꍇ�A���[���o�b�N���s���B
	 * @param sasimodosiBeans
	 * @param loginuser
	 * @return
	 * @throws PCY_WarningException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdateSousinFlg(final PCY_SasimodosiWorkTableBean[] sasimodosiBeans, final PCY_PersonalBean loginuser) throws PCY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// SQL�쐬
			final StringBuffer sql = new StringBuffer();
			sql.append("UPDATE " + HcdbDef.L54_TBL);
			sql.append(" SET   SOUSIN_FLG=? ");
			sql.append(" WHERE KAMOKU_CODE=?");
			sql.append("   AND CLASS_CODE=?");
			sql.append("   AND SIMEI_NO=?");

			// �R�l�N�V�����擾
			final PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
			con = locator.getDataSource().getConnection();

			// �X�V���s
			ps = con.prepareStatement(sql.toString());

			int ret_count = 0;

			for (int i = 0; i < sasimodosiBeans.length; i++) {
				ps.setString(1, sasimodosiBeans[i].getSousinFlg());
				ps.setString(2, sasimodosiBeans[i].getKamokuCode());
				ps.setString(3, sasimodosiBeans[i].getClassCode());
				ps.setString(4, sasimodosiBeans[i].getSimeiNo());

				ret_count += ps.executeUpdate();

				ps.clearParameters();
			}

			if (ret_count != sasimodosiBeans.length) {
				this.context.setRollbackOnly();
				throw new PCY_WarningException();
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return ret_count;
		} catch (final NamingException e) {
			Log.error(loginuser.getSimeiNo(), "HJE-0002", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser.getSimeiNo(), "HJE-0001", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser.getSimeiNo(), "", e);
			throw e;
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (final SQLException e) {
					// �������Ȃ�
				}
			}

			if (con != null) {
				try {
					con.close();
				} catch (final SQLException e) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * �����Ŏw�肳�ꂽ�����ɏ]���AL54���߂����[�N�e�[�u���̃��R�[�h���폜���܂��B
	 * @param sasimodosiBean
	 * @param loginuser
	 * @return �폜�������R�[�h����
	 * @throws PCY_WarningException
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doDelete(final PCY_SasimodosiWorkTableBean sasimodosiBean, final PCY_PersonalBean loginuser) throws PCY_WarningException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// SQL�쐬
			final StringBuffer sql = new StringBuffer();
			sql.append("DELETE FROM " + HcdbDef.L54_TBL);

			final StringBuffer where = new StringBuffer();
			final Map extract = sasimodosiBean.extractConditions();

			for (final Iterator ite = extract.keySet().iterator(); ite.hasNext();) {
				final Object column = ite.next();
				where.append(" AND " + column.toString() + "=?");
			}

			sql.append(where.toString().replaceFirst("AND", "WHERE"));

			// �R�l�N�V�����擾
			final PCY_ServiceLocator locator = PCY_ServiceLocator.getInstance();
			con = locator.getDataSource().getConnection();

			// �X�V���s
			ps = con.prepareStatement(sql.toString());

			int index = 1;

			for (final Iterator ite = extract.keySet().iterator(); ite.hasNext();) {
				final Object key = ite.next();
				ps.setObject(index++, extract.get(key));
			}

			final int ret = ps.executeUpdate();

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return ret;
		} catch (final NamingException e) {
			Log.error(loginuser.getSimeiNo(), "HJE-0002", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser.getSimeiNo(), "HJE-0001", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser.getSimeiNo(), "", e);
			throw e;
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (final SQLException e) {
					// �������Ȃ�
				}
			}

			if (con != null) {
				try {
					con.close();
				} catch (final SQLException e) {
					// �������Ȃ�
				}
			}
		}
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
}
