/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.base.portal.controller;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;

import jp.co.hisas.career.base.portal.ejb.PYB_PortalEJB;
import jp.co.hisas.career.base.portal.ejb.PYB_PortalEJBHome;
import jp.co.hisas.career.base.portal.model.PYB_KenshuShoninConfigModel;
import jp.co.hisas.career.base.portal.model.PYB_KenshuShoninModel;
import jp.co.hisas.career.base.portal.model.PYB_PortalConfigModel;
import jp.co.hisas.career.base.portal.model.PYB_PortalModel;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.plan.base.VelocityHelper;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

public class PYB_KenshuShoninController implements PYB_PortalBlockControllerImpl {

	public PYB_PortalConfigModel getConfigData(final String shimeiNo, final String soshikiCode) {
		final PYB_KenshuShoninConfigModel model = new PYB_KenshuShoninConfigModel();

		model.setShimeiNo(shimeiNo);
		model.setSoshikiCode(soshikiCode);
		model.setParameter(new HashMap());

		try {
			final PYB_PortalEJBHome my_home = (PYB_PortalEJBHome) EJBHomeFactory.getInstance().lookup(PYB_PortalEJBHome.class);
			final PYB_PortalEJB userSession = (PYB_PortalEJB) my_home.create();

			// �l�ݒ�̐ݒ�
			final HashMap configMap = userSession.getProtalPersonal(model.getPortalID(), shimeiNo, soshikiCode);
			initializePortalPersonal(configMap);
			model.setDispFlag(((String) configMap.get("HYOJI_FLAG")).equals("1") ? true : false);
			model.setSortOrder(((Integer) configMap.get("HYOJI_JUNJO")).intValue());
			model.setControllFlag(((String) configMap.get("SOUSA_FLAG")).equals("1") ? true : false);

			// �p�����[�^�̐ݒ�
			model.setParameter(userSession.getPortalParameter(model.getPortalID(), shimeiNo, soshikiCode));
		} catch (final RemoteException e) {
			Log.error(shimeiNo, e);
		} catch (final NamingException e) {
			Log.error(shimeiNo, e);
		} catch (final CreateException e) {
			Log.error(shimeiNo, e);
		} catch (final SQLException e) {
			Log.error(shimeiNo, e);
		}

		return model;
	}

	public PYB_PortalModel getData(final String shimeiNo, final String soshikiCode) {
		final PYB_KenshuShoninModel model = new PYB_KenshuShoninModel();

		// ���F�ΏێҎ�u�����擾����B��Q���Ŏ擾�ł��Ȃ������ꍇ�̓X�L�b�v
		try {
			final PYB_PortalEJBHome my_home = (PYB_PortalEJBHome) EJBHomeFactory.getInstance().lookup(PYB_PortalEJBHome.class);
			final PYB_PortalEJB userSession = (PYB_PortalEJB) my_home.create();

			// �l�ݒ�̐ݒ�
			final HashMap dataMap = userSession.getProtalPersonal(model.getPortalID(), shimeiNo, soshikiCode);
			initializePortalPersonal(dataMap);
			model.setDispFlag(((String) dataMap.get("HYOJI_FLAG")).equals("1") ? true : false);
			model.setSortOrder(((Integer) dataMap.get("HYOJI_JUNJO")).intValue());
			model.setControllFlag(((String) dataMap.get("SOUSA_FLAG")).equals("1") ? true : false);

			// �\������
			final HashMap paramMap = userSession.getPortalParameter(model.getPortalID(), shimeiNo, soshikiCode);
			int searchMonth = 1;
			try {
				searchMonth = Integer.parseInt((String) paramMap.get("SearchMonth"));
			} catch (final NumberFormatException e) {
				// ���l�ϊ��ł��Ȃ��Ȃ�0�Ō���
			}

			model.setJukoList(userSession.getKenshusyaKenshuYoteiList(shimeiNo, shimeiNo, searchMonth));
		} catch (final RemoteException e) {
			Log.error(shimeiNo, e);
		} catch (final NamingException e) {
			Log.error(shimeiNo, e);
		} catch (final CreateException e) {
			Log.error(shimeiNo, e);
		} catch (final SQLException e) {
			Log.error(shimeiNo, e);
		}
		return model;
	}

	public void setConfigData(final PYB_PortalConfigModel configData) {
		try {
			final PYB_PortalEJBHome my_home = (PYB_PortalEJBHome) EJBHomeFactory.getInstance().lookup(PYB_PortalEJBHome.class);
			final PYB_PortalEJB userSession = (PYB_PortalEJB) my_home.create();
			userSession.updateProtalConfig(configData);
		} catch (final RemoteException e) {
			Log.error(PZZ010_CharacterUtil.normalizedStr(configData.getShimeiNo()), e);
		} catch (final NamingException e) {
			Log.error(PZZ010_CharacterUtil.normalizedStr(configData.getShimeiNo()), e);
		} catch (final CreateException e) {
			Log.error(PZZ010_CharacterUtil.normalizedStr(configData.getShimeiNo()), e);
		} catch (final SQLException e) {
			Log.error(PZZ010_CharacterUtil.normalizedStr(configData.getShimeiNo()), e);
		}
	}

	public void updateConfigData(final HttpServletRequest request, final PYB_PortalConfigModel configData) {
		// �p�[�\�i��
		final String dispFlag = request.getParameter(configData.getPortalID() + "_disp");
		final String sortOrder = request.getParameter(configData.getPortalID() + "_sort");

		configData.setDispFlag((dispFlag != null && dispFlag.toLowerCase().equals("on")) ? true : false);
		configData.setSortOrder(Integer.parseInt(sortOrder));

		// �p�����[�^
		final String searchMonth = request.getParameter(configData.getPortalID() + "_SearchMonth");
		if (searchMonth != null && searchMonth.length() > 0) {
			configData.getParameter().put("SearchMonth", searchMonth);
		}
	}

	/**
	 * �|�[�^���\���p���f�[�^����Velocity��ʂ������ʂ��擾����
	 * @return �e���v���[�g�G���W�����s����
	 */
	public String getVelocityData(final PYB_PortalModel model) {
		final StringBuffer buf = new StringBuffer("");
		if (model.isDispFlag()) {
			final VelocityHelper velocity = new VelocityHelper(model.getTemplateFileName());
			velocity.setParameter("kenshu", model);

			try {
				buf.append(velocity.getWriter().toString());
			} catch (final Exception e) {
				Log.error("", e);
			}
		}
		return buf.toString();
	}

	/**
	 * �|�[�^���ݒ���f�[�^����Velocity��ʂ������ʂ��擾����
	 * @return �e���v���[�g�G���W�����s����
	 */
	public String getVelocityConfigData(final PYB_PortalConfigModel configModel) {
		final StringBuffer buf = new StringBuffer("");
		final VelocityHelper velocity = new VelocityHelper(configModel.getTemplateConfigFileName());
		velocity.setParameter("config", configModel);
		
		try {
			buf.append(velocity.getWriter().toString());
		} catch (final Exception e) {
			Log.error("", e);
		}
		return buf.toString();
	}

	/**
	 * �|�[�^���l�ݒ�ɒl�����ݒ肳��Ă��Ȃ��ꍇ�̏����l�ݒ���s��<br>
	 * ���C���F�ҏ�� (�v���N�e�B�X���W���[���g�p�I�v�V����)
	 * @param personalMap �|�[�^���l�ݒ��MAP
	 */
	private void initializePortalPersonal(final HashMap personalMap) {
		String dispFlagString = (String) personalMap.get("HYOJI_FLAG");
		Integer sortOrderNum = (Integer) personalMap.get("HYOJI_JUNJO");
		String controllFlagString = (String) personalMap.get("SOUSA_FLAG");

		if (dispFlagString == null) {
			dispFlagString = (String) ReadFile.fileMapData.get(HcdbDef.learningOption);
		}
		if (sortOrderNum == null) {
			sortOrderNum = new Integer(904);
		}
		if (controllFlagString == null) {
			controllFlagString = (String) ReadFile.fileMapData.get(HcdbDef.learningOption);
		}

		personalMap.put("HYOJI_FLAG", dispFlagString);
		personalMap.put("HYOJI_JUNJO", sortOrderNum);
		personalMap.put("SOUSA_FLAG", controllFlagString);
	}
}
