/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.base.portal.servlet;

import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.portal.bean.PYB020_PortalSettingBean;
import jp.co.hisas.career.base.portal.controller.PYB_PortalController;
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.personal.personal.ejb.SearchEmpEJB;
import jp.co.hisas.career.personal.personal.ejb.SearchEmpEJBHome;
import jp.co.hisas.career.util.log.Log;

/**
 * ������ʐݒ�
 */
public class PYB020_PortalSettingServlet extends HttpServlet {

	/** �G���[�y�[�W */
	private static final String ERROR_PAGE = "/view/base/error/VYY_Error.jsp";

	/** ����y�[�W */
	private static final String SUCCESS_PAGE = "/view/base/portal/VYB020_PortalSetting.jsp";

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * �������������s���B
	 * @param config
	 * @throws javax.servlet.ServletException
	 * @see javax.servlet.Servlet#init(javax.servlet.ServletConfig)
	 */
	public void init(final ServletConfig config) throws ServletException {
		super.init(config);

		// ���\�b�h�g���[�X�o��
		Log.method("", "IN", "");

		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
		// ���\�b�h�g���[�X�o��
		Log.method("", "OUT", "");
	}

	/**
	 * �u���E�U����̌����v�����󂯎��A�{�N���X�̎��s���\�b�h���Ăяo���܂��B
	 * @param request ���N�G�X�g
	 * @param response ���X�|���X
	 * @throws ServletException �T�[�u���b�g��O
	 * @throws IOException ���o�͗�O
	 * @see javax.servlet.http.HttpServlet#service( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse )
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {

		final HttpSession session = request.getSession(false);

		String pageUrl = "";
		// �Z�b�V�����A�܂���userinfo���擾�ł��Ȃ��ꍇ�A�G���[�y�[�W�֑J��
		if (session == null || (UserInfoBean) session.getAttribute("userinfo") == null) {
			this.ctx.getRequestDispatcher(PYB020_PortalSettingServlet.ERROR_PAGE).forward(request, response);
		} else {
			String loginNo = null;
			try {
				final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");

				// ���O�C�����[�U�擾
				loginNo = userinfo.getLogin_no();
				Log.performance(loginNo, true, "");

				String action = request.getParameter("Action_key");

				if (action == null || action.length() == 0) {
					action = PYB020_PortalSettingBean.ACTION_INIT;
				}

				pageUrl = PYB020_PortalSettingServlet.SUCCESS_PAGE;

				final PYB_PortalController controller = new PYB_PortalController();
				PYB020_PortalSettingBean viewBean = null;

				if (action.equals(PYB020_PortalSettingBean.ACTION_INIT)) {
					viewBean = initPYB020Bean(controller, loginNo, userinfo.getSosiki_code());
					session.setAttribute("VYB020_ViewBean", viewBean);
				} else if (action.equals(PYB020_PortalSettingBean.ACTION_UPDATE)) {
					viewBean = (PYB020_PortalSettingBean) session.getAttribute("VYB020_ViewBean");
					if (viewBean == null) {
						viewBean = initPYB020Bean(controller, loginNo, userinfo.getSosiki_code());
						session.setAttribute("VYB020_ViewBean", viewBean);
					} else {
						controller.updateConfigParameter(viewBean.getPortalMap(), request);
						controller.updateConfigData(loginNo, userinfo.getSosiki_code(), viewBean.getPortalMap());
						viewBean.setPortalMap(controller.sortPortalConfigData(controller.getAllConfigData(loginNo, userinfo.getSosiki_code())));
					}
				}

				// �����������A�Y��JSP�y�[�W�֑J��
				final RequestDispatcher rd = this.ctx.getRequestDispatcher(pageUrl);
				rd.forward(request, response);
				Log.performance(loginNo, false, "");
				Log.method(loginNo, "OUT", "");

			} catch (final Exception e) {
				Log.error(loginNo, e);
				this.ctx.getRequestDispatcher(PYB020_PortalSettingServlet.ERROR_PAGE).forward(request, response);
			}
		}
	}

	/**
	 * VYB020�̉�ʗpBean�̐�������я����l�ݒ���s��
	 * @param controller
	 * @param shimeiNo �ΏێҎ���No
	 * @param soshikiCode �Ώێґg�D�R�[�h
	 * @return VYB020��ʗpBean
	 */
	private PYB020_PortalSettingBean initPYB020Bean(final PYB_PortalController controller, final String shimeiNo, final String soshikiCode) {
		final PYB020_PortalSettingBean bean = new PYB020_PortalSettingBean();
		bean.setShimeiNo(shimeiNo);
		bean.setSoshikiCode(soshikiCode);
		bean.setPortalMap(controller.sortPortalConfigData(controller.getAllConfigData(shimeiNo, soshikiCode)));

		// ���O�C�����[�U���擾
		try {
			final SearchEmpEJBHome my_home = (SearchEmpEJBHome) EJBHomeFactory.getInstance().lookup(SearchEmpEJBHome.class);
			final SearchEmpEJB userSession = (SearchEmpEJB) my_home.create();

			final ArrayList t01Column = new ArrayList();
			t01Column.add("KANJI_SIMEI");
			final HashMap user = userSession.getPersonalInfo(shimeiNo, shimeiNo, soshikiCode, t01Column);

			// ���������͌��J�t���O�ł���ŏ���1��������
			final String shimei = (String) user.get("KANJI_SIMEI");
			bean.setShimei(shimei != null && shimei.length() > 2 ? shimei.substring(1) : "");
			bean.setSoshikiName((String) user.get("T19_BUSYO_RYAKUSYO_MEI"));
		} catch (final RemoteException e) {
			Log.error(shimeiNo, e);
		} catch (final NamingException e) {
			Log.error(shimeiNo, e);
		} catch (final CreateException e) {
			Log.error(shimeiNo, e);
		} catch (final SQLException e) {
			Log.error(shimeiNo, e);
		}

		return bean;
	}
}
