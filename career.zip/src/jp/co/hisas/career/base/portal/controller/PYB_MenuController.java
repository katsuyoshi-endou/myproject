package jp.co.hisas.career.base.portal.controller;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;

import jp.co.hisas.career.base.portal.ejb.PYB_PortalEJB;
import jp.co.hisas.career.base.portal.ejb.PYB_PortalEJBHome;
import jp.co.hisas.career.base.portal.model.PYB_MenuConfigModel;
import jp.co.hisas.career.base.portal.model.PYB_MenuModel;
import jp.co.hisas.career.base.portal.model.PYB_PortalConfigModel;
import jp.co.hisas.career.base.portal.model.PYB_PortalModel;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

public class PYB_MenuController implements PYB_PortalBlockControllerImpl {

	public PYB_PortalConfigModel getConfigData(final String shimeiNo, final String soshikiCode) {
		final PYB_MenuConfigModel model = new PYB_MenuConfigModel();

		model.setShimeiNo(shimeiNo);
		model.setSoshikiCode(soshikiCode);
		model.setParameter(new HashMap());

		try {
			final PYB_PortalEJBHome my_home = (PYB_PortalEJBHome) EJBHomeFactory.getInstance().lookup(PYB_PortalEJBHome.class);
			final PYB_PortalEJB userSession = (PYB_PortalEJB) my_home.create();

			// �l�ݒ�̐ݒ�
			final HashMap configMap = userSession.getProtalPersonal(model.getPortalID(), shimeiNo, soshikiCode);
			initializePortalPersonal(configMap);
			model.setDispFlag(((String) configMap.get("HYOJI_FLAG")).equals("1") ? true : false);
			model.setSortOrder(((Integer) configMap.get("HYOJI_JUNJO")).intValue());
			model.setControllFlag(((String) configMap.get("SOUSA_FLAG")).equals("1") ? true : false);

			// �p�����[�^�̐ݒ�
			model.setParameter(userSession.getPortalParameter(model.getPortalID(), shimeiNo, soshikiCode));
		} catch (final RemoteException e) {
			Log.error(shimeiNo, e);
		} catch (final NamingException e) {
			Log.error(shimeiNo, e);
		} catch (final CreateException e) {
			Log.error(shimeiNo, e);
		} catch (final SQLException e) {
			Log.error(shimeiNo, e);
		}

		return model;
	}

	public PYB_PortalModel getData(final String shimeiNo, final String soshikiCode) {
		final PYB_MenuModel model = new PYB_MenuModel();

		// �����\�����郁�j���[�̃��j���[ID���擾����B��Q���Ŏ擾�ł��Ȃ������ꍇ�̓X�L�b�v
		try {
			// �f�t�H���g�Ń|�[�^����ʂ�ݒ�
			model.setPortalMenuId("DMU192");

			final PYB_PortalEJBHome my_home = (PYB_PortalEJBHome) EJBHomeFactory.getInstance().lookup(PYB_PortalEJBHome.class);
			final PYB_PortalEJB userSession = (PYB_PortalEJB) my_home.create();

			// �l�ݒ�̐ݒ�
			final HashMap dataMap = userSession.getProtalPersonal(model.getPortalID(), shimeiNo, soshikiCode);
			initializePortalPersonal(dataMap);
			model.setDispFlag(((String) dataMap.get("HYOJI_FLAG")).equals("1") ? true : false);
			model.setSortOrder(((Integer) dataMap.get("HYOJI_JUNJO")).intValue());
			model.setControllFlag(((String) dataMap.get("SOUSA_FLAG")).equals("1") ? true : false);

			// �\���y�[�W�ݒ�
			final HashMap paramMap = userSession.getPortalParameter(model.getPortalID(), shimeiNo, soshikiCode);
			if (paramMap.containsKey("ShowPage")) {
				model.setPortalMenuId((String) paramMap.get("ShowPage"));
			}
		} catch (final RemoteException e) {
			Log.error(shimeiNo, e);
		} catch (final NamingException e) {
			Log.error(shimeiNo, e);
		} catch (final CreateException e) {
			Log.error(shimeiNo, e);
		} catch (final SQLException e) {
			Log.error(shimeiNo, e);
		}
		return model;
	}

	public void setConfigData(final PYB_PortalConfigModel configData) {
		try {
			final PYB_PortalEJBHome my_home = (PYB_PortalEJBHome) EJBHomeFactory.getInstance().lookup(PYB_PortalEJBHome.class);
			final PYB_PortalEJB userSession = (PYB_PortalEJB) my_home.create();
			userSession.updateProtalConfig(configData);
		} catch (final RemoteException e) {
			Log.error(PZZ010_CharacterUtil.normalizedStr(configData.getShimeiNo()), e);
		} catch (final NamingException e) {
			Log.error(PZZ010_CharacterUtil.normalizedStr(configData.getShimeiNo()), e);
		} catch (final CreateException e) {
			Log.error(PZZ010_CharacterUtil.normalizedStr(configData.getShimeiNo()), e);
		} catch (final SQLException e) {
			Log.error(PZZ010_CharacterUtil.normalizedStr(configData.getShimeiNo()), e);
		}
	}

	public void updateConfigData(final HttpServletRequest request, final PYB_PortalConfigModel configData) {
		final String menuId = request.getParameter("selectMenu");
		if (menuId != null && menuId.length() > 0) {
			configData.getParameter().put("ShowPage", menuId);
		}
	}

	public String getVelocityData(final PYB_PortalModel model) {
		return "";
	}

	/**
	 * �|�[�^���ݒ���f�[�^����Velocity��ʂ������ʂ��擾����
	 * @return �e���v���[�g�G���W�����s����
	 */
	public String getVelocityConfigData(final PYB_PortalConfigModel configModel) {
		return "";
	}

	/**
	 * �|�[�^���l�ݒ�ɒl���ݒ肳��Ă��Ȃ��ꍇ�̏����l�ݒ���s��<br>
	 * ���j���[ (�\��, ���[�U����\)
	 * @param personalMap �|�[�^���l�ݒ��MAP
	 */
	private void initializePortalPersonal(final HashMap personalMap) {
		String dispFlagString = (String) personalMap.get("HYOJI_FLAG");
		Integer sortOrderNum = (Integer) personalMap.get("HYOJI_JUNJO");
		String controllFlagString = (String) personalMap.get("SOUSA_FLAG");

		if (dispFlagString == null) {
			dispFlagString = "1";
		}
		if (sortOrderNum == null) {
			sortOrderNum = new Integer(999);
		}
		if (controllFlagString == null) {
			controllFlagString = "1";
		}

		personalMap.put("HYOJI_FLAG", dispFlagString);
		personalMap.put("HYOJI_JUNJO", sortOrderNum);
		personalMap.put("SOUSA_FLAG", controllFlagString);
	}
}
