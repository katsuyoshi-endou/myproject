/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.personal.kyoiku.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Writer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.personal.accesslog.bean.AccesslogBean;
import jp.co.hisas.career.personal.kyoiku.bean.KyoikuBean;
import jp.co.hisas.career.personal.kyoiku.bean.KyoikuCsvValueBean;
import jp.co.hisas.career.personal.util.CsvConditionHeaderValueBean;
import jp.co.hisas.career.personal.util.CsvValueBeanList;
import jp.co.hisas.career.plan.base.VelocityHelper;
import jp.co.hisas.career.search.jiyukensaku.bean.JiyuKensakuBean;
import jp.co.hisas.career.util.common.PZZ050_FileUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �p�[�\�i�� ���猤�C��CSV�f�[�^���o�͂���
 */
public class CsvKyoikuServlet extends HttpServlet {
	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
	 * @param response Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet�̐���ȏ������W����ꂽ���ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = null;
		try {
			String simei_no;
			String simeiNo2 = "";
			String kanji_simei;
			String busyo_ryakusyou;

			int kyoiku_count;
			String[][] kyoiku_data = null;
			final String hikokai = "����J";

			String syoriID = "";
			final String passfilter = request.getParameter("H999_PassFilter");
			String logsimei = "";
			String logjouken = "";

			final HttpSession session = request.getSession(false);

			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");

				login_no = bean.getLogin_no();
				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				/* CSV�o�̓t���O�̎擾 */
				final String csv_flg = request.getParameter("Csv_flg");
				
				//ValueBeanList�̍쐬�i�e�ʁj
				CsvValueBeanList valueBeanList = new CsvValueBeanList();
				
				//�w�b�_�̐ݒ�
				KyoikuCsvValueBean header = new KyoikuCsvValueBean();
				header.setShimeiNo((String) ReadFile.paramMapData.get("DZZ002"));
				header.setShimei((String) ReadFile.paramMapData.get("DZZ001"));
				header.setBusyo((String) ReadFile.paramMapData.get("DZZ013"));
				header.setKamokuCode((String) ReadFile.paramMapData.get("DZZ076"));
				header.setKamokuName((String) ReadFile.paramMapData.get("DZZ078"));
				header.setShusaimoto((String) ReadFile.paramMapData.get("DZZ079"));
				header.setClassName((String) ReadFile.paramMapData.get("DZZ077"));
				header.setKaishiBi((String) ReadFile.paramMapData.get("DZZ080"));
				header.setShuryoBi((String) ReadFile.paramMapData.get("DZZ081"));
				header.setSeiseki((String) ReadFile.paramMapData.get("DZZ129"));
				header.setTanka((String) ReadFile.paramMapData.get("DZZ298"));
				header.setNissu((String) ReadFile.paramMapData.get("DZZ304"));
				//�w�b�_�̊i�[
				valueBeanList.setHeader(header);
				

				KyoikuBean kyoikubean = (KyoikuBean) session.getAttribute("kyoiku");

				if (kyoikubean == null) {
					kyoikubean = new KyoikuBean();
					session.setAttribute("kyoiku", kyoikubean);
				}
				final AccesslogBean accesslogbean = (AccesslogBean) session.getAttribute("accesslog");

				if ("1".equals(csv_flg)) {
					int count = 0;

					simei_no = bean.getSimei_no_flg(); // ����NO
					kanji_simei = bean.getKanji_simei(); // �����i�����j

					final String server = bean.getServer();
					String simei_no_flg = "";
					String busyo_ryakusyo = "";

					final JiyuKensakuBean kensakubean = (JiyuKensakuBean) session.getAttribute("jiyukensaku");

					/* �K�{���� */
					final String[][] kekka = kensakubean.getKekka();

					if (kekka != null) {
						/*
						 * JiyuKensakuEJB��search���\�b�h�ɂ�����,���ʔz������Ƃ��� ���������{�P�̒����ɂ��Ă���̂�,������-1����B
						 */
						count = kekka.length - 1;
					} else {
						count = 0;
					}

					/* �����������w�b�_�ɏo�� */
					logjouken = kensakubean.getSQL1JP() + " " + kensakubean.getSQL2JP() + " " + kensakubean.getSQL3JP() + " " + kensakubean.getSQL4JP() + " " + kensakubean.getSQL5JP();
					if (request.getParameter("kensakujyoken") != null) {
						final String SQL1JP = kensakubean.getSQL1JP();
						final String SQL2JP = kensakubean.getSQL2JP();
						final String SQL3JP = kensakubean.getSQL3JP();
						final String SQL4JP = kensakubean.getSQL4JP();
						final String SQL5JP = kensakubean.getSQL5JP();

						//�ǉ��w�b�_���i�[����ValueBeanList
						CsvValueBeanList addHeaderList = new CsvValueBeanList();
						CsvConditionHeaderValueBean addHeader = null;

						if (SQL1JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL1JP);
							addHeaderList.add(addHeader);
						}
						if (SQL2JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL2JP);
							addHeaderList.add(addHeader);
						}
						if (SQL3JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL3JP);
							addHeaderList.add(addHeader);
						}
						if (SQL4JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL4JP);
							addHeaderList.add(addHeader);
						}
						if (SQL5JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL5JP);
							addHeaderList.add(addHeader);
						}

						//�e��ValueBeanList�ɒǉ��w�b�_��ݒ�
						valueBeanList.setAdditionalHeader(addHeaderList);
					}

					for (int i = 0; i < count; i++) {
						simei_no = kekka[i][0]; // ����NO
						bean.searchsansyo(simei_no, server, "1");
						simei_no_flg = bean.getSimei_no_flg();
						kanji_simei = bean.getKanji_simei();

						if (!simei_no_flg.equals(hikokai)) {
							/* ����NO�̓��ꌅ�폜 */
							simei_no_flg = simei_no_flg.substring(1, simei_no_flg.length());
						}

						if (!kanji_simei.equals(hikokai)) {
							/* �����i�����j�̓��ꌅ�폜 */
							final int kanji_simei_length = kanji_simei.length();
							kanji_simei = kanji_simei.substring(1, kanji_simei_length);
						}

						if (!bean.getBusyo_ryakusyo_mei().equals(hikokai)) {
							/* �������̖��̓��ꌅ�폜 */
							final int busyo_ryakusyou_length = bean.getBusyo_ryakusyo_mei().length();
							busyo_ryakusyo = bean.getBusyo_ryakusyo_mei().substring(1, busyo_ryakusyou_length);
						} else {
							busyo_ryakusyo = bean.getBusyo_ryakusyo_mei();
						}

						if (bean.getKyoiku_kokai_flg().equals(hikokai)) {
							/* �f�[�^�o�� */
							KyoikuCsvValueBean valueBean = new KyoikuCsvValueBean();
							valueBean.setShimeiNo(simei_no_flg);
							valueBean.setShimei(kanji_simei);
							valueBean.setBusyo(busyo_ryakusyo);
							//����J
							valueBean.setHikokai(hikokai);

							//�e�ʂɊi�[
							valueBeanList.add(valueBean);
						} else {
							/* ���猤�C�������������s�� */
							kyoikubean.searchkyoiku(simei_no, login_no, server);

							/* ���R�[�h�� */
							kyoiku_count = kyoikubean.getCount();

							/* ���猤�C���ꗗ�f�[�^ */
							kyoiku_data = kyoikubean.getKyoiku();

							/* �f�[�^�o�� */
							KyoikuCsvValueBean valueBean = null;
							for (int k = 0; k < kyoiku_count; k++) {
								/* �f�[�^�o�� */
								valueBean = new KyoikuCsvValueBean();
								valueBean.setShimeiNo(simei_no_flg);
								valueBean.setShimei(kanji_simei);
								valueBean.setBusyo(busyo_ryakusyo);
								valueBean.setKamokuCode(kyoiku_data[k][5].trim());
								valueBean.setKamokuName(kyoiku_data[k][0]);
								valueBean.setShusaimoto(kyoiku_data[k][3]);
								valueBean.setClassName(kyoiku_data[k][6]);
								valueBean.setKaishiBi(kyoiku_data[k][1].trim());
								valueBean.setShuryoBi(kyoiku_data[k][2].trim());
// BC0405-01-007  �C��  2009/9/28  yoshida START
//								valueBean.setSeiseki(kyoiku_data[k][4]);
                                valueBean.setSeiseki(kyoiku_data[k][4] != null ? kyoiku_data[k][4].trim() : "");
// BC0405-01-007  �C��  2009/9/28  yoshida END
								valueBean.setTanka(kyoiku_data[k][12]);
								valueBean.setNissu(kyoiku_data[k][13]);

								//�e�ʂɊi�[
								valueBeanList.add(valueBean);
							}
						}
					}

					syoriID = "PPP048";
					OutLogBean.sousaKojinJohoLog(syoriID, login_no, logsimei, logjouken);
				} else {

					/* UserInfoBean���f�[�^�擾 */
					simei_no = bean.getSimei_no_flg(); // ����NO
					simeiNo2 = bean.getSimei_no();
					kanji_simei = bean.getKanji_simei(); // �����i�����j
					busyo_ryakusyou = bean.getBusyo_ryakusyo_mei();// �������̖�

					if (!simei_no.equals(hikokai)) {
						/* ����NO�̓��ꌅ�폜 */
						simei_no = simei_no.substring(1, simei_no.length());
					}

					// ���猤�C���̌���
					kyoikubean.searchkyoiku(simeiNo2, login_no, bean.getServer());

					if(!hikokai.equals( kanji_simei )){
						/* �����i�����j�̓��ꌅ�폜 */
						final int kanji_simei_length = kanji_simei.length();
						kanji_simei = kanji_simei.substring(1, kanji_simei_length);
					}
					if(!hikokai.equals( busyo_ryakusyou )){
						/* �������̖��̓��ꌅ�폜 */
						final int busyo_ryakusyou_length = busyo_ryakusyou.length();
						busyo_ryakusyou = busyo_ryakusyou.substring(1, busyo_ryakusyou_length);
					}
					if (bean.getKyoiku_kokai_flg().equals(hikokai)) {
						/* �f�[�^�o�� */
						KyoikuCsvValueBean valueBean = new KyoikuCsvValueBean();
						valueBean.setShimeiNo(simei_no);
						valueBean.setShimei(kanji_simei);
						valueBean.setBusyo(busyo_ryakusyou);
						//����J
						valueBean.setHikokai(hikokai);
						
						//�e�ʂɊi�[
						valueBeanList.add(valueBean);
						
					} else {
						/* KyoikuBean���f�[�^�擾 */
						// ���R�[�h��
						kyoiku_count = kyoikubean.getCount();
						// �����u���f�[�^
						kyoiku_data = kyoikubean.getKyoiku();

						/** ���猤�C���f�[�^�o�� */
						KyoikuCsvValueBean valueBean = null;
						for (int k = 0; k < kyoiku_count; k++) {
							/** �f�[�^�o�� */
							valueBean = new KyoikuCsvValueBean();
							valueBean.setShimeiNo(simei_no);
							valueBean.setShimei(kanji_simei);
							valueBean.setBusyo(busyo_ryakusyou);
							valueBean.setKamokuCode(kyoiku_data[k][5].trim());
							valueBean.setKamokuName(kyoiku_data[k][0]);
							valueBean.setShusaimoto(kyoiku_data[k][3]);
							valueBean.setClassName(kyoiku_data[k][6]);
							valueBean.setKaishiBi(kyoiku_data[k][1].trim());
							valueBean.setShuryoBi(kyoiku_data[k][2].trim());
// BC0405-01-007  �C��  2009/9/28  yoshida START
//							valueBean.setSeiseki(kyoiku_data[k][4]);
                            valueBean.setSeiseki(kyoiku_data[k][4] != null ? kyoiku_data[k][4].trim() : "");
// BC0405-01-007  �C��  2009/9/28  yoshida END
							valueBean.setTanka(kyoiku_data[k][12]);
							valueBean.setNissu(kyoiku_data[k][13]);

							//�e�ʂɊi�[
							valueBeanList.add(valueBean);
						}
					}

					final String req = request.getParameter("H002_requestFrom");
					if (req != null && req.equals("VCA010")) {
						syoriID = "LNG003";
						logsimei = "";
						logjouken = simei_no;
					} else if (passfilter != null && passfilter.equals("a")) {
						syoriID = "PPP031";
						logsimei = simei_no;
					} else {
						syoriID = "PPP013";
						logsimei = simei_no;
					}
					OutLogBean.sousaKojinJohoLog(syoriID, login_no, logsimei, logjouken);
				}

				/* �A�N�Z�X���O�b�r�u�o�͉񐔂��P���₷ */
				accesslogbean.kyoikuCsvCount();

				/* Velocity��p���āA�o�̓t�@�C���e���v���[�g�Ƀf�[�^��ݒ肷�� */
				final VelocityHelper vh = new VelocityHelper(HcdbDef.KYOIKU_CSV_TEMPLATE);
				vh.setParameter("BeanList", valueBeanList);
				final Writer w = vh.getWriter();
				final ByteArrayInputStream bais = new ByteArrayInputStream(w.toString().getBytes());
				request.setAttribute("H080_FileName", PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_PERSONAL_KYOIKU_CSV, new String[] { login_no }));
				request.setAttribute("H081_ContentType", HcdbDef.CONTENT_TYPE);
				request.setAttribute("STREAM", bais);
				
				final RequestDispatcher rd = this.ctx.getRequestDispatcher("/servlet/PYE010_FileDownloadServlet");
				rd.forward(request, response);

				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}
}