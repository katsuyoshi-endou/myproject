package jp.co.hisas.career.personal.kyoiku.bean;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.hisas.career.learning.base.valuebean.PCY_ValueBean;

public class KyoikuValueBean extends PCY_ValueBean implements Serializable {

	/** �V�[�P���XNO */
	private String seqNo;

	/** �����ԍ� */
	private String simei_no;

	/** �ȖڃR�[�h */
	private String kamokuCode;

	/** �Ȗږ��P */
	private String kamokuMei1;

	/** �Ȗږ��Q */
	private String kamokuMei2;

	/** �Ȗږ��R */
	private String kamokuMei3;

	/** �Ȗږ��S */
	private String kamokuMei4;

	/** �ȖڃO���[�v�� */
	private String kamoku_group_mei;

	/** ���C���ޖ��P */
	private String category_mei1;

	/** ���C���ޖ��Q */
	private String category_mei2;

	/** ���C���ޖ��R */
	private String category_mei3;

	/** ���C���ޖ��S */
	private String category_mei4;

	/** ���C���ޖ��T */
	private String category_mei5;

	/** �Ǘ����� */
	private String kanrimoto_mei;

	/** �N���X�� */
	private String class_mei;

	/** �J�n�� */
	private String kaisibi;

	/** �I���� */
	private String syuryobi;

	/** ���|�[�g�t�@�C���� */
	private String report_filename;

	/** ���|�[�g�t�@�C���`�� */
	private String report_content_type;

	/** �� */
	private String houkoku;

	/** ���� */
	private String seiseki;

	/** �C������ */
	private String syuryo_hantei;

	/** �{�l�C���\�t���O */
	private String honnin_syusei_flg;

	/** ���J����J�t���O */
	private String kokai_flg;

	/** �N���X�R�[�h */
	private String classCode;

	public String getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}

	public String getSimei_no() {
		return simei_no;
	}

	public void setSimei_no(String simei_no) {
		this.simei_no = simei_no;
	}

	public String getKamokuCode() {
		return kamokuCode;
	}

	public void setKamokuCode(String kamokuCode) {
		this.kamokuCode = kamokuCode;
	}

	public String getKamokuMei1() {
		return kamokuMei1;
	}

	public void setKamokuMei1(String kamokuMei1) {
		this.kamokuMei1 = kamokuMei1;
	}

	public String getKamokuMei2() {
		return kamokuMei2;
	}

	public void setKamokuMei2(String kamokuMei2) {
		this.kamokuMei2 = kamokuMei2;
	}

	public String getKamokuMei3() {
		return kamokuMei3;
	}

	public void setKamokuMei3(String kamokuMei3) {
		this.kamokuMei3 = kamokuMei3;
	}

	public String getKamokuMei4() {
		return kamokuMei4;
	}

	public void setKamokuMei4(String kamokuMei4) {
		this.kamokuMei4 = kamokuMei4;
	}

	public String getKamoku_group_mei() {
		return kamoku_group_mei;
	}

	public void setKamoku_group_mei(String kamoku_group_mei) {
		this.kamoku_group_mei = kamoku_group_mei;
	}

	public String getCategory_mei1() {
		return category_mei1;
	}

	public void setCategory_mei1(String category_mei1) {
		this.category_mei1 = category_mei1;
	}

	public String getCategory_mei2() {
		return category_mei2;
	}

	public void setCategory_mei2(String category_mei2) {
		this.category_mei2 = category_mei2;
	}

	public String getCategory_mei3() {
		return category_mei3;
	}

	public void setCategory_mei3(String category_mei3) {
		this.category_mei3 = category_mei3;
	}

	public String getCategory_mei4() {
		return category_mei4;
	}

	public void setCategory_mei4(String category_mei4) {
		this.category_mei4 = category_mei4;
	}

	public String getCategory_mei5() {
		return category_mei5;
	}

	public void setCategory_mei5(String category_mei5) {
		this.category_mei5 = category_mei5;
	}

	public String getKanrimoto_mei() {
		return kanrimoto_mei;
	}

	public void setKanrimoto_mei(String kanrimoto_mei) {
		this.kanrimoto_mei = kanrimoto_mei;
	}

	public String getClass_mei() {
		return class_mei;
	}

	public void setClass_mei(String class_mei) {
		this.class_mei = class_mei;
	}

	public String getKaisibi() {
		return kaisibi;
	}

	public void setKaisibi(String kaisibi) {
		this.kaisibi = kaisibi;
	}

	public String getSyuryobi() {
		return syuryobi;
	}

	public void setSyuryobi(String syuryobi) {
		this.syuryobi = syuryobi;
	}

	public String getReport_filename() {
		return report_filename;
	}

	public void setReport_filename(String report_filename) {
		this.report_filename = report_filename;
	}

	public String getReport_content_type() {
		return report_content_type;
	}

	public void setReport_content_type(String report_content_type) {
		this.report_content_type = report_content_type;
	}

	public String getHoukoku() {
		return houkoku;
	}

	public void setHoukoku(String houkoku) {
		this.houkoku = houkoku;
	}

	public String getSeiseki() {
		return seiseki;
	}

	public void setSeiseki(String seiseki) {
		this.seiseki = seiseki;
	}

	public String getSyuryo_hantei() {
		return syuryo_hantei;
	}

	public void setSyuryo_hantei(String syuryo_hantei) {
		this.syuryo_hantei = syuryo_hantei;
	}

	public String getHonnin_syusei_flg() {
		return honnin_syusei_flg;
	}

	public void setHonnin_syusei_flg(String honnin_syusei_flg) {
		this.honnin_syusei_flg = honnin_syusei_flg;
	}

	public String getKokai_flg() {
		return kokai_flg;
	}

	public void setKokai_flg(String kokai_flg) {
		this.kokai_flg = kokai_flg;
	}

	public String getClassCode() {
		return classCode;
	}

	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}

	public KyoikuValueBean() {
		super();
	}

	/**
	 * ResultSet ����l���擾���ă��|�[�g��o���ԃ}�X�^��ValueBean���쐬���܂��B
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param reportSubmitKikanTableName ���|�[�g��o���ԃ}�X�^�̕ʖ�
	 * @throws SQLException SQL��O
	 */
	public KyoikuValueBean(final ResultSet rs, final String tableName, String classCode) throws SQLException {
		this.setTableName(tableName);
		
		this.setSeqNo(rs.getString(this.getIdentifier() + "SEQ_NO"));
		this.setSimei_no(rs.getString(this.getIdentifier() + "simei_no"));
		this.setKamokuCode(rs.getString(this.getIdentifier() + "kamoku_code"));
		this.setKamokuMei1(rs.getString(this.getIdentifier() + "kamoku_mei1"));
		this.setKamokuMei2(rs.getString(this.getIdentifier() + "kamoku_mei2"));
		this.setKamokuMei3(rs.getString(this.getIdentifier() + "kamoku_mei3"));
		this.setKamokuMei4(rs.getString(this.getIdentifier() + "kamoku_mei4"));
		this.setKamoku_group_mei(rs.getString(this.getIdentifier() + "kamoku_group_mei"));
		this.setCategory_mei1(rs.getString(this.getIdentifier() + "category_mei1"));
		this.setCategory_mei2(rs.getString(this.getIdentifier() + "category_mei2"));
		this.setCategory_mei3(rs.getString(this.getIdentifier() + "category_mei3"));
		this.setCategory_mei4(rs.getString(this.getIdentifier() + "category_mei4"));
		this.setCategory_mei5(rs.getString(this.getIdentifier() + "category_mei5"));
		this.setKanrimoto_mei(rs.getString(this.getIdentifier() + "kanrimoto_mei"));
		this.setClass_mei(rs.getString(this.getIdentifier() + "class_mei"));
		this.setKaisibi(rs.getString(this.getIdentifier() + "kaisibi"));
		this.setSyuryobi(rs.getString(this.getIdentifier() + "syuryobi"));
		this.setReport_filename(rs.getString(this.getIdentifier() + "report_filename"));
		this.setReport_content_type(rs.getString(this.getIdentifier() + "report_content_type"));
// DEL 2019/02/26 COMTURE phase7-2018S-���C_CT_014 START
//		this.setHoukoku(rs.getString(this.getIdentifier() + "houkoku"));
// DEL 2019/02/26 COMTURE phase7-2018S-���C_CT_014 END
		this.setSeiseki(rs.getString(this.getIdentifier() + "seiseki"));
		this.setSyuryo_hantei(rs.getString(this.getIdentifier() + "syuryo_hantei"));
		this.setHonnin_syusei_flg(rs.getString(this.getIdentifier() + "honnin_syusei_flg"));
		this.setKokai_flg(rs.getString(this.getIdentifier() + "kokai_flg"));
		this.setClassCode(classCode);

	}

	/**
	 * �J�����̕ʖ����`���� SQL ����Ԃ��܂��B ���̃N���X�̃R���X�g���N�^�� ResultSet �������Ƃ��ēn�����ƂŁA �f�[�^���擾�ł��܂��B
	 * @param tableName �e�[�u���̕ʖ�
	 * @return �J�����̕ʖ����`���� SQL ��
	 * @see jp.co.hisas.career.learning.base.valuebean.PCY_MasterBean#getColumns(java.lang.String)
	 */
	public static String getColumns(final String tableName) {
		if (tableName == null) {
			return "*";
		}

		final StringBuffer ret = new StringBuffer();
		ret.append(tableName + ".seq_no as " + tableName + "_seq_no, ");
		ret.append(tableName + ".simei_no as " + tableName + "_simei_no, ");
		ret.append(tableName + ".kamoku_code as " + tableName + "_kamoku_code, ");
		ret.append(tableName + ".kamoku_mei1 as " + tableName + "_kamoku_mei1, ");
		ret.append(tableName + ".kamoku_mei2 as " + tableName + "_kamoku_mei2, ");
		ret.append(tableName + ".kamoku_mei3 as " + tableName + "_kamoku_mei3, ");
		ret.append(tableName + ".kamoku_mei4 as " + tableName + "_kamoku_mei4, ");
		ret.append(tableName + ".kamoku_group_mei as " + tableName + "_kamoku_group_mei, ");
		ret.append(tableName + ".category_mei1 as " + tableName + "_category_mei1, ");
		ret.append(tableName + ".category_mei2 as " + tableName + "_category_mei2, ");
		ret.append(tableName + ".category_mei3 as " + tableName + "_category_mei3, ");
		ret.append(tableName + ".category_mei4 as " + tableName + "_category_mei4, ");
		ret.append(tableName + ".category_mei5 as " + tableName + "_category_mei5, ");
		ret.append(tableName + ".kanrimoto_mei as " + tableName + "_kanrimoto_mei, ");
		ret.append(tableName + ".class_mei as " + tableName + "_class_mei, ");
		ret.append(tableName + ".kaisibi as " + tableName + "_kaisibi, ");
		ret.append(tableName + ".syuryobi as " + tableName + "_syuryobi, ");
		ret.append(tableName + ".report_filename as " + tableName + "_report_filename, ");
		ret.append(tableName + ".report_content_type as " + tableName + "_report_content_type, ");
		ret.append(tableName + ".houkoku as " + tableName + "_houkoku, ");
		ret.append(tableName + ".seiseki as " + tableName + "_seiseki, ");
		ret.append(tableName + ".syuryo_hantei as " + tableName + "_syuryo_hantei, ");
		ret.append(tableName + ".honnin_syusei_flg as " + tableName + "_honnin_syusei_flg, ");
		ret.append(tableName + ".kokai_flg as " + tableName + "_kokai_flg");

		return ret.toString();
	}
}
