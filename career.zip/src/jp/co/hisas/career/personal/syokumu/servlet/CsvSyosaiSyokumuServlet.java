/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.personal.syokumu.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Writer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.personal.accesslog.bean.AccesslogBean;
import jp.co.hisas.career.personal.syokumu.bean.SyokumuBean;
import jp.co.hisas.career.personal.syokumu.bean.SyokumuCsvValueBean;
import jp.co.hisas.career.personal.util.CsvConditionHeaderValueBean;
import jp.co.hisas.career.personal.util.CsvValueBeanList;
import jp.co.hisas.career.plan.base.VelocityHelper;
import jp.co.hisas.career.search.jiyukensaku.bean.JiyuKensakuBean;
import jp.co.hisas.career.util.common.PZZ050_FileUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �p�[�\�i���E�����e��CSV�f�[�^�o�͂��s��
 */
public class CsvSyosaiSyokumuServlet extends HttpServlet {

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
	 * @param response Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet�̐���ȏ������W����ꂽ���ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = null;
		try {
			final HttpSession session = request.getSession(false);
			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
				final AccesslogBean accesslogbean = (AccesslogBean) session.getAttribute("accesslog");
				login_no = bean.getLogin_no(); /* �J�n���O�o�� */
				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				String simei_no = "";
				String simeiNo2 = "";
				String kanji_simei = "";
				String busyo_ryakusyou = "";
				String server = "";
				final String hikokai = "����J";
				String syoriID = "";
				String logsimei = "";
				String logjouken = "";

				final String passfilter = request.getParameter("H999_PassFilter");

				/* CSV�o�̓t���O�̎擾 */
				final String csv_flg = request.getParameter("Csv_flg");

				/* �E�����e��Bean�擾 */
				SyokumuBean syokumubean = (SyokumuBean) session.getAttribute("syokumu");

				String uriagegakuLbl = (String) ReadFile.paramMapData.get("AZZ021");
				String sojininLbl = (String) ReadFile.paramMapData.get("AZZ022");
				String kaihatsu_stepLbl = (String) ReadFile.paramMapData.get("AZZ023");
				if (uriagegakuLbl == null) {
					uriagegakuLbl = "";
				}
				if (sojininLbl == null) {
					sojininLbl = "";
				}
				if (kaihatsu_stepLbl == null) {
					kaihatsu_stepLbl = "";
				}

				//CsvValueBeanList�̍쐬�i�e�ʁj
				CsvValueBeanList valueBeanList = new CsvValueBeanList();
				
				//�w�b�_�̐ݒ�
				SyokumuCsvValueBean header = new SyokumuCsvValueBean();
				header.setShimeiNo((String) ReadFile.paramMapData.get("DZZ002"));
				header.setShimei((String) ReadFile.paramMapData.get("DZZ001"));
				header.setBusyo((String) ReadFile.paramMapData.get("DZZ014"));
				header.setProjectName((String) ReadFile.paramMapData.get("DZZ055"));
				header.setKokyakuName((String) ReadFile.paramMapData.get("DZZ056"));
				header.setUriagegaku(uriagegakuLbl);
				header.setSojinin(sojininLbl);
				header.setKaihatsuStep(kaihatsu_stepLbl);
				header.setKaishiBi((String) ReadFile.paramMapData.get("DZZ067"));
				header.setShuryoBi((String) ReadFile.paramMapData.get("DZZ068"));
				header.setSyokumuBusyo((String) ReadFile.paramMapData.get("DZZ014"));
				header.setSyokuiLevel1((String) ReadFile.paramMapData.get("DZZ060"));
				header.setSyokuiLevel2((String) ReadFile.paramMapData.get("DZZ061"));
				header.setSyokumuGaiyo((String) ReadFile.paramMapData.get("DZZ059"));
				header.setPre((String) ReadFile.paramMapData.get("DAC001"));
				header.setConsul((String) ReadFile.paramMapData.get("DAC002"));
				header.setSekkei((String) ReadFile.paramMapData.get("DAC003"));
				header.setKankyoSettei((String) ReadFile.paramMapData.get("DAC004"));
				header.setJisso((String) ReadFile.paramMapData.get("DAC005"));
				header.setKumiawase((String) ReadFile.paramMapData.get("DAC006"));
				header.setTest((String) ReadFile.paramMapData.get("DAC007"));
				header.setIko((String) ReadFile.paramMapData.get("DAC008"));
				header.setHyoka((String) ReadFile.paramMapData.get("DAC009"));
				header.setFollow((String) ReadFile.paramMapData.get("DAC010"));
				header.setKenkyu((String) ReadFile.paramMapData.get("DAC011"));
				header.setOs1((String) ReadFile.paramMapData.get("DAC055"));
				header.setOs1Ver((String) ReadFile.paramMapData.get("DAC056"));
				header.setOs2((String) ReadFile.paramMapData.get("DAC057"));
				header.setOs2Ver((String) ReadFile.paramMapData.get("DAC058"));
				header.setOnline1((String) ReadFile.paramMapData.get("DAC061"));
				header.setOnline1Ver((String) ReadFile.paramMapData.get("DAC062"));
				header.setOnline2((String) ReadFile.paramMapData.get("DAC063"));
				header.setOnline2Ver((String) ReadFile.paramMapData.get("DAC064"));
				header.setDbms1((String) ReadFile.paramMapData.get("DAC067"));
				header.setDbms1Ver((String) ReadFile.paramMapData.get("DAC068"));
				header.setDbms2((String) ReadFile.paramMapData.get("DAC069"));
				header.setDbms2Ver((String) ReadFile.paramMapData.get("DAC070"));
				header.setProgram1((String) ReadFile.paramMapData.get("DAC073"));
				header.setProgram1Step((String) ReadFile.paramMapData.get("DAC074"));
				header.setProgram2((String) ReadFile.paramMapData.get("DAC075"));
				header.setProgram2Step((String) ReadFile.paramMapData.get("DAC076"));
				header.setSonotaSeihin1((String) ReadFile.paramMapData.get("DAC079"));
				header.setSonotaSeihin2((String) ReadFile.paramMapData.get("DAC080"));
				header.setSonotaSeihin3((String) ReadFile.paramMapData.get("DAC081"));
				header.setSeihinSyosai((String) ReadFile.paramMapData.get("DAB007"));
				header.setJinkoChino((String) ReadFile.paramMapData.get("DAC012"));
				header.setManMachineSystem((String) ReadFile.paramMapData.get("DAC013"));
				header.setDatabaseSystem((String) ReadFile.paramMapData.get("DAC014"));
				header.setBunsanSystem((String) ReadFile.paramMapData.get("DAC015"));
				header.setComputerNetwork((String) ReadFile.paramMapData.get("DAC016"));
				header.setComputerVision((String) ReadFile.paramMapData.get("DAC017"));
				header.setImageProcessing((String) ReadFile.paramMapData.get("DAC018"));
				header.setOperatingSystem((String) ReadFile.paramMapData.get("DAC019"));
				header.setSystemHyoka((String) ReadFile.paramMapData.get("DAC020"));
				header.setKeisankiArc((String) ReadFile.paramMapData.get("DAC021"));
				header.setGraphic((String) ReadFile.paramMapData.get("DAC022"));
				header.setBunshoShori((String) ReadFile.paramMapData.get("DAC023"));
				header.setSuchiKaiseki((String) ReadFile.paramMapData.get("DAC024"));
				header.setArgorithm((String) ReadFile.paramMapData.get("DAC025"));
				header.setGroupware((String) ReadFile.paramMapData.get("DAC026"));
				header.setComputerSecurity((String) ReadFile.paramMapData.get("DAC027"));
				header.setKigoShori((String) ReadFile.paramMapData.get("DAC028"));
				header.setProgramLanguage((String) ReadFile.paramMapData.get("DAC029"));
				header.setJohoShori1((String) ReadFile.paramMapData.get("DAC083"));
				header.setJohoShori2((String) ReadFile.paramMapData.get("DAC084"));
				header.setJohoShori3((String) ReadFile.paramMapData.get("DAC085"));
				header.setKokyakuGyoshuName((String) ReadFile.paramMapData.get("DZZ065"));
				header.setTogaiGyoshuName((String) ReadFile.paramMapData.get("DZZ066"));
				header.setGyoshuShosaiNaiyo((String) ReadFile.paramMapData.get("DZZ052"));
				header.setLeaderShip((String) ReadFile.paramMapData.get("DAC030"));
				header.setComunication((String) ReadFile.paramMapData.get("DAC031"));
				header.setNego((String) ReadFile.paramMapData.get("DAC032"));
				header.setMondaiKaiketsu((String) ReadFile.paramMapData.get("DAC033"));
				header.setSoshikika((String) ReadFile.paramMapData.get("DAC034"));
				header.setHyojun((String) ReadFile.paramMapData.get("DAC035"));
				header.setKokusaika((String) ReadFile.paramMapData.get("DAC036"));
				header.setTogoManagement((String) ReadFile.paramMapData.get("DAC037"));
				header.setScopeManagement((String) ReadFile.paramMapData.get("DAC038"));
				header.setTimeManagement((String) ReadFile.paramMapData.get("DAC039"));
				header.setCostManagement((String) ReadFile.paramMapData.get("DAC040"));
				header.setHinsitsuManagement((String) ReadFile.paramMapData.get("DAC041"));
				header.setSoshikiManagement((String) ReadFile.paramMapData.get("DAC042"));
				header.setRiskManagement((String) ReadFile.paramMapData.get("DAC043"));
				header.setComunicationManagement((String) ReadFile.paramMapData.get("DAC044"));
				header.setTyotatsuManagement((String) ReadFile.paramMapData.get("DAC045"));
				header.setJohoShushu((String) ReadFile.paramMapData.get("DAC046"));
				header.setKokyakuSessho((String) ReadFile.paramMapData.get("DAC047"));
				header.setTeianKatsudo((String) ReadFile.paramMapData.get("DAC048"));
				header.setPresentation((String) ReadFile.paramMapData.get("DAC049"));
				header.setChangeManagement((String) ReadFile.paramMapData.get("DAC050"));
				header.setShinkiKikaku((String) ReadFile.paramMapData.get("DAC051"));
				header.setJinmyakuKochiku((String) ReadFile.paramMapData.get("DAC052"));
				header.setTroubleTaio((String) ReadFile.paramMapData.get("DAC053"));
				header.setGogaku((String) ReadFile.paramMapData.get("DAC054"));
				header.setBuisinessSkillSyosaiNaiyo((String) ReadFile.paramMapData.get("DAC089"));
				
				valueBeanList.setHeader(header);

				simei_no = bean.getSimei_no();
				server = bean.getServer();

				if ("1".equals(csv_flg)) {
					if (syokumubean == null) {
						syokumubean = new SyokumuBean();
					}

					int count = 0;

					String simei_no_flg = "";
					String busyo_ryakusyo = "";

					final JiyuKensakuBean kensakubean = (JiyuKensakuBean) session.getAttribute("jiyukensaku");

					/* �K�{���� */
					final String[][] kekka = kensakubean.getKekka();

					if (kekka != null) {
						/*
						 * JiyuKensakuEJB��search���\�b�h�ɂ�����,���ʔz������Ƃ��� ���������{�P�̒����ɂ��Ă���̂�,������-1����B
						 */
						count = kekka.length - 1;
					} else {
						count = 0;
					}

					/* �����������w�b�_�ɏo�� */
					logjouken = kensakubean.getSQL1JP() + " " + kensakubean.getSQL2JP() + " " + kensakubean.getSQL3JP() + " " + kensakubean.getSQL4JP() + " " + kensakubean.getSQL5JP();
					if (request.getParameter("kensakujyoken") != null) {
						final String SQL1JP = kensakubean.getSQL1JP();
						final String SQL2JP = kensakubean.getSQL2JP();
						final String SQL3JP = kensakubean.getSQL3JP();
						final String SQL4JP = kensakubean.getSQL4JP();
						final String SQL5JP = kensakubean.getSQL5JP();

						//�ǉ��w�b�_���i�[����ValueBeanList
						CsvValueBeanList addHeaderList = new CsvValueBeanList();
						CsvConditionHeaderValueBean addHeader = null;

						if (SQL1JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL1JP);
							addHeaderList.add(addHeader);
						}
						if (SQL2JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL2JP);
							addHeaderList.add(addHeader);
						}
						if (SQL3JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL3JP);
							addHeaderList.add(addHeader);
						}
						if (SQL4JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL4JP);
							addHeaderList.add(addHeader);
						}
						if (SQL5JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL5JP);
							addHeaderList.add(addHeader);
						}

						//�e��ValueBeanList�ɒǉ��w�b�_��ݒ�
						valueBeanList.setAdditionalHeader(addHeaderList);

					}

					for (int j = 0; j < count; j++) {
						simei_no = kekka[j][0]; // ����NO

						bean.searchsansyo(simei_no, server, "1");
						simei_no_flg = bean.getSimei_no_flg();
						kanji_simei = bean.getKanji_simei();

						if (!simei_no_flg.equals(hikokai)) {
							/* ����NO�̓��ꌅ�폜 */
							simei_no_flg = simei_no_flg.substring(1, simei_no_flg.length());
						}

						if (!kanji_simei.equals(hikokai)) {
							/* �����i�����j�̓��ꌅ�폜 */
							final int kanji_simei_length = kanji_simei.length();
							kanji_simei = kanji_simei.substring(1, kanji_simei_length);
						}

						if (!bean.getBusyo_ryakusyo_mei().equals(hikokai)) {
							/* �������̖��̓��ꌅ�폜 */
							final int busyo_ryakusyou_length = bean.getBusyo_ryakusyo_mei().length();
							busyo_ryakusyo = bean.getBusyo_ryakusyo_mei().substring(1, busyo_ryakusyou_length);
						} else {
							busyo_ryakusyo = bean.getBusyo_ryakusyo_mei();
						}

						if (bean.getSyokumu_kokai_flg().equals(hikokai)) {
							
							SyokumuCsvValueBean valueBean = new SyokumuCsvValueBean();
							valueBean.setShimeiNo(simei_no_flg);
							valueBean.setShimei(kanji_simei);
							valueBean.setBusyo(busyo_ryakusyo);
							//����J
							valueBean.setHikokai(hikokai);
							
							valueBeanList.add(valueBean);
							
						} else {
							/* �E�����e�����������s�� */
							syokumubean.searchsyokumu(simei_no, login_no, server);

							if (syokumubean.getCount() > 0) {
								final String[][] syokumuargs = syokumubean.getSyokumuitiran();
								/* ���R�[�h�� */
								final int syokumu_count = syokumubean.getCount();

								for (int m = 0; m < syokumu_count; m++) {
									final String id = syokumuargs[m][11];

									/* �E�����e���ڍ׌����������s�� */
									syokumubean.syousai(id);
									
									//CSV�o�̓f�[�^���擾
									SyokumuCsvValueBean valueBean = syokumubean.getCsvValue();
									valueBean.setShimeiNo(simei_no_flg);
									valueBean.setShimei(kanji_simei);
									valueBean.setBusyo(busyo_ryakusyo);
									valueBeanList.add(valueBean);

								}
							}
						}
					}

					syoriID = "PPP047";
					OutLogBean.sousaKojinJohoLog(syoriID, login_no, logsimei, logjouken);
				} else {

					/* UserInfoBean���f�[�^�擾 */
					simei_no = bean.getSimei_no_flg(); // ����NO
					simeiNo2 = bean.getSimei_no();
					kanji_simei = bean.getKanji_simei(); // �����i�����j
					busyo_ryakusyou = bean.getBusyo_ryakusyo_mei(); // �������̖�

					if (!simei_no.equals(hikokai)) {
						/* ����NO�̓��ꌅ�폜 */
						simei_no = simei_no.substring(1, simei_no.length());
					}
					if(!hikokai.equals( kanji_simei )){
						/* �����i�����j�̓��ꌅ�폜 */
						final int kanji_simei_length = kanji_simei.length();
						kanji_simei = kanji_simei.substring(1, kanji_simei_length);
					}
					if(!hikokai.equals( busyo_ryakusyou )){
						/* �������̖��̓��ꌅ�폜 */
						final int busyo_ryakusyou_length = busyo_ryakusyou.length();
						busyo_ryakusyou = busyo_ryakusyou.substring(1, busyo_ryakusyou_length);
					}					
					if (bean.getSyokumu_kokai_flg().equals(hikokai)) {
						// �f�[�^�o��
						SyokumuCsvValueBean valueBean = new SyokumuCsvValueBean();
						valueBean.setShimeiNo(simei_no);
						valueBean.setShimei(kanji_simei);
						valueBean.setBusyo(busyo_ryakusyou);
						//����J
						valueBean.setHikokai(hikokai);
						
						valueBeanList.add(valueBean);
						
					} else {
						/* �E�����e�����������s�� */
						syokumubean = new SyokumuBean();
						syokumubean.searchsyokumu(simeiNo2, login_no, server);

						/* ���R�[�h�� */
						final int syokumu_count = syokumubean.getCount();
						/* �E�����e����� */

						for (int j = 0; j < syokumu_count; j++) {

							final String[][] syokumuargs = syokumubean.getSyokumuitiran();
							final String id = syokumuargs[j][11];
							/* �E�����e���ڍ׌����������s�� */
							syokumubean.syousai(id);

							SyokumuCsvValueBean valueBean = syokumubean.getCsvValue();
							valueBean.setShimeiNo(simei_no);
							valueBean.setShimei(kanji_simei);
							valueBean.setBusyo(busyo_ryakusyou);

							valueBeanList.add(valueBean);
							
						}
					}

					if (passfilter != null && passfilter.equalsIgnoreCase("a")) {
						syoriID = "PPP027";
					} else {
						syoriID = "PPP012";
					}
					logsimei = simei_no;
					OutLogBean.sousaKojinJohoLog(syoriID, login_no, logsimei, logjouken);

				}
				
				/* Velocity��p���āA�o�̓t�@�C���e���v���[�g�Ƀf�[�^��ݒ肷�� */
				final VelocityHelper vh = new VelocityHelper(HcdbDef.SYOKUMU_CSV_TEMPLATE);
				vh.setParameter("BeanList", valueBeanList);
				final Writer w = vh.getWriter();
				final ByteArrayInputStream bais = new ByteArrayInputStream(w.toString().getBytes());
				request.setAttribute("H080_FileName", PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_PERSONAL_SYOKUMU_CSV, new String[] { login_no }));
				request.setAttribute("H081_ContentType", HcdbDef.CONTENT_TYPE);
				request.setAttribute("STREAM", bais);
				
				final RequestDispatcher rd = this.ctx.getRequestDispatcher("/servlet/PYE010_FileDownloadServlet");
				rd.forward(request, response);

				/* �A�N�Z�X���O�b�r�u�o�͉񐔂��P���₷ */
				accesslogbean.syokumuSyosaiCsvCount();
				/* �I�����O�o�� */
				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}
}