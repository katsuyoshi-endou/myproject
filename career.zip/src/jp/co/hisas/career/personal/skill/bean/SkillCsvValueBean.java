package jp.co.hisas.career.personal.skill.bean;

import jp.co.hisas.career.personal.util.CsvValueBean;

/**
 * �X�L���Ǘ�CSV�̏o�͓��e�i�P���R�[�h���j��ێ�����
 *
 */
public class SkillCsvValueBean extends CsvValueBean {

	/** ����NO */
	private String shimeiNo = null;

	/** ���� */
	private String shimei = null;

	/** ������ */
	private String busyo = null;

	/** �n�r�P���� */
	private String os1Name = null;

	/** �n�r�P���x�� */
	private String os1Level = null;

	/** �n�r�Q���� */
	private String os2Name = null;

	/** �n�r�Q���x�� */
	private String os2Level = null;

	/** �n�r�R���� */
	private String os3Name = null;

	/** �n�r�R���x�� */
	private String os3Level = null;

	/** �I�����C���^�l�b�g���[�N�P���� */
	private String online1Name = null;

	/** �I�����C���^�l�b�g���[�N�P���x�� */
	private String online1Level = null;

	/** �I�����C���^�l�b�g���[�N�Q���� */
	private String online2Name = null;

	/** �I�����C���^�l�b�g���[�N�Q���x�� */
	private String online2Level = null;

	/** �I�����C���^�l�b�g���[�N�R���� */
	private String online3Name = null;

	/** �I�����C���^�l�b�g���[�N�R���x�� */
	private String online3Level = null;

	/** �c�a�l�r�P���� */
	private String dbms1Name = null;

	/** �c�a�l�r�P���x�� */
	private String dbms1Level = null;

	/** �c�a�l�r�Q���� */
	private String dbms2Name = null;

	/** �c�a�l�r�Q���x�� */
	private String dbms2Level = null;

	/** �c�a�l�r�R���� */
	private String dbms3Name = null;

	/** �c�a�l�r�R���x�� */
	private String dbms3Level = null;

	/** �v���O��������P���� */
	private String program1Name = null;

	/** �v���O��������P���x�� */
	private String program1Level = null;

	/** �v���O��������Q���� */
	private String program2Name = null;

	/** �v���O��������Q���x�� */
	private String program2Level = null;

	/** �v���O��������R���� */
	private String program3Name = null;

	/** �v���O��������R���x�� */
	private String program3Level = null;

	/** ���̑����i�E�Z�p�P */
	private String sonotaSeihin1 = null;

	/** ���̑����i�E�Z�p�P���x�� */
	private String sonotaSeihin1Level = null;

	/** ���̑����i�E�Z�p�Q */
	private String sonotaSeihin2 = null;

	/** ���̑����i�E�Z�p�Q���x�� */
	private String sonotaSeihin2Level = null;

	/** ���̑����i�E�Z�p�R */
	private String sonotaSeihin3 = null;

	/** ���̑����i�E�Z�p�R���x�� */
	private String sonotaSeihin3Level = null;

	/** ���̑����i�E�Z�p�S */
	private String sonotaSeihin4 = null;

	/** ���̑����i�E�Z�p�S���x�� */
	private String sonotaSeihin4Level = null;

	/** ���̑����i�E�Z�p�T */
	private String sonotaSeihin5 = null;

	/** ���̑����i�E�Z�p�T���x�� */
	private String sonotaSeihin5Level = null;

	/** ���̑����i�E�Z�p�U */
	private String sonotaSeihin6 = null;

	/** ���̑����i�E�Z�p�U���x�� */
	private String sonotaSeihin6Level = null;

	/** ���i�E�Z�p�m���̏ڍד��e */
	private String seihinShosaiNaiyo = null;

	/** �l�H�m�\ */
	private String jinkoChino = null;

	/** �}���E�}�V���E�V�X�e�� */
	private String manMachineSystem = null;

	/** �f�[�^�x�[�X�V�X�e�� */
	private String databaseSystem = null;

	/** ���U�����V�X�e�� */
	private String bunsanSystem = null;

	/** �R���s���[�^�l�b�g���[�N */
	private String computerNetwork = null;

	/** �R���s���[�^�r�W���� */
	private String computerVision = null;

	/** �C���[�W�v���Z�b�V���O */
	private String imageProcessing = null;

	/** �I�y���[�e�B���O�V�X�e�� */
	private String operatingSystem = null;

	/** �V�X�e�����\�]�� */
	private String systemHyoka = null;

	/** �v�Z�@�A�[�L�e�N�`�� */
	private String keisankiArch = null;

	/** �O���t�B�b�N�X�E�b�`�c */
	private String graphics = null;

	/** �������� */
	private String bunshoShori = null;

	/** ���l��� */
	private String suchiKaiseki = null;

	/** �A���S���Y�� */
	private String argorithm = null;

	/** �O���[�v�E�F�A */
	private String groupware = null;

	/** �R���s���[�^�Z�L�����e�B */
	private String computerSecurity = null;

	/** �L������ */
	private String kigoShori = null;

	/** �v���O�������� */
	private String programLanguage = null;

	/** ���̑���񏈗��Z�p�m���P���� */
	private String sonotaJohoShori1Name = null;

	/** ���̑���񏈗��Z�p�m���P���x�� */
	private String sonotaJohoShori1Level = null;

	/** ���̑���񏈗��Z�p�m���Q���� */
	private String sonotaJohoShori2Name = null;

	/** ���̑���񏈗��Z�p�m���Q���x�� */
	private String sonotaJohoShori2Level = null;

	/** ���̑���񏈗��Z�p�m���R���� */
	private String sonotaJohoShori3Name = null;

	/** ���̑���񏈗��Z�p�m���R���x�� */
	private String sonotaJohoShori3Level = null;

	/** ��񏈗��Z�p�m���̏ڍד��e */
	private String johoShoriChishikiShosaiNaiyo = null;

	/** �Ǝ�E�Ɩ����P�Ǝ햼 */
	private String gyoshu1GyoshuName = null;

	/** �Ǝ�E�Ɩ����P�Ɩ��� */
	private String gyoshu1GyomuName = null;

	/** �Ǝ�E�Ɩ����P���x�� */
	private String gyoshu1Level = null;

	/** �Ǝ�E�Ɩ����P�Ǝ�E�Ɩ��m���̏ڍד��e */
	private String gyoshu1ShosaiNaiyo = null;

	/** �Ǝ�E�Ɩ����Q�Ǝ햼 */
	private String gyoshu2GyoshuName = null;

	/** �Ǝ�E�Ɩ����Q�Ɩ��� */
	private String gyoshu2GyomuName = null;

	/** �Ǝ�E�Ɩ����Q���x�� */
	private String gyoshu2Level = null;

	/** �Ǝ�E�Ɩ����Q�Ǝ�E�Ɩ��m���̏ڍד��e */
	private String gyoshu2ShosaiNaiyo = null;

	/** �Ǝ�E�Ɩ����R�Ǝ햼 */
	private String gyoshu3GyoshuName = null;

	/** �Ǝ�E�Ɩ����R�Ɩ��� */
	private String gyoshu3GyomuName = null;

	/** �Ǝ�E�Ɩ����R���x�� */
	private String gyoshu3Level = null;

	/** �Ǝ�E�Ɩ����R�Ǝ�E�Ɩ��m���̏ڍד��e */
	private String gyoshu3ShosaiNaiyo = null;

	/** ���[�_�V�b�v */
	private String leaderShip = null;

	/** �R�~���j�P�[�V���� */
	private String comunication = null;

	/** �l�S�V�G�[�V���� */
	private String negotiation = null;

	/** ������ */
	private String mondaiKaiketsu = null;

	/** �g�D�� */
	private String soshikika = null;

	/** �W��(�K�i)�Ɩ@�K */
	private String hyojunka = null;

	/** ���ۉ� */
	private String kokusaika = null;

	/** �����}�l�[�W�����g */
	private String sogoManagement = null;

	/** �X�R�[�v�}�l�[�W�����g */
	private String scopeManagement = null;

	/** �^�C���}�l�[�W�����g */
	private String timeManagement = null;

	/** �R�X�g�}�l�[�W�����g */
	private String costManagement = null;

	/** �i���}�l�[�W�����g */
	private String qualityManagement = null;

	/** �g�D�}�l�[�W�����g */
	private String soshikiManagement = null;

	/** ���X�N�}�l�[�W�����g */
	private String riskManagement = null;

	/** �R�~���j�P�[�V�����}�l�[�W�����g */
	private String comunicationManagement = null;

	/** ���B�}�l�[�W�����g */
	private String chotatsuManagement = null;

	/** �����W */
	private String johoShushu = null;

	/** �ڋq�܏� */
	private String kokyakuSessho = null;

	/** ��Ċ��� */
	private String teianKatsudo = null;

	/** �v���[���e�[�V���� */
	private String presentation = null;

	/** �`�F���W�}�l�[�W�����g */
	private String changeManagement = null;

	/** �V�K��� */
	private String shinkiKikaku = null;

	/** �l���\�z */
	private String jinmyakuKochiku = null;

	/** �g���u���Ή� */
	private String trouble = null;

	/** ��w */
	private String gogaku = null;

	/** �r�W�l�X�X�L���̏ڍד��e */
	private String buisinessSkillSyosaiNaiyo = null;

	/** ����J */
	private String hikokai = null;

	public String getArgorithm() {
		return argorithm;
	}

	public void setArgorithm(String argorithm) {
		this.argorithm = argorithm;
	}

	public String getBuisinessSkillSyosaiNaiyo() {
		return buisinessSkillSyosaiNaiyo;
	}

	public void setBuisinessSkillSyosaiNaiyo(String buisinessSkillSyosaiNaiyo) {
		this.buisinessSkillSyosaiNaiyo = buisinessSkillSyosaiNaiyo;
	}

	public String getBunsanSystem() {
		return bunsanSystem;
	}

	public void setBunsanSystem(String bunsanSystem) {
		this.bunsanSystem = bunsanSystem;
	}

	public String getBunshoShori() {
		return bunshoShori;
	}

	public void setBunshoShori(String bunshoShori) {
		this.bunshoShori = bunshoShori;
	}

	public String getBusyo() {
		return busyo;
	}

	public void setBusyo(String busyo) {
		this.busyo = busyo;
	}

	public String getChangeManagement() {
		return changeManagement;
	}

	public void setChangeManagement(String changeManagement) {
		this.changeManagement = changeManagement;
	}

	public String getChotatsuManagement() {
		return chotatsuManagement;
	}

	public void setChotatsuManagement(String chotatsuManagement) {
		this.chotatsuManagement = chotatsuManagement;
	}

	public String getComputerNetwork() {
		return computerNetwork;
	}

	public void setComputerNetwork(String computerNetwork) {
		this.computerNetwork = computerNetwork;
	}

	public String getComputerSecurity() {
		return computerSecurity;
	}

	public void setComputerSecurity(String computerSecurity) {
		this.computerSecurity = computerSecurity;
	}

	public String getComputerVision() {
		return computerVision;
	}

	public void setComputerVision(String computerVision) {
		this.computerVision = computerVision;
	}

	public String getComunication() {
		return comunication;
	}

	public void setComunication(String comunication) {
		this.comunication = comunication;
	}

	public String getComunicationManagement() {
		return comunicationManagement;
	}

	public void setComunicationManagement(String comunicationManagement) {
		this.comunicationManagement = comunicationManagement;
	}

	public String getCostManagement() {
		return costManagement;
	}

	public void setCostManagement(String costManagement) {
		this.costManagement = costManagement;
	}

	public String getDatabaseSystem() {
		return databaseSystem;
	}

	public void setDatabaseSystem(String databaseSystem) {
		this.databaseSystem = databaseSystem;
	}

	public String getDbms1Level() {
		return dbms1Level;
	}

	public void setDbms1Level(String dbms1Level) {
		this.dbms1Level = dbms1Level;
	}

	public String getDbms1Name() {
		return dbms1Name;
	}

	public void setDbms1Name(String dbms1Name) {
		this.dbms1Name = dbms1Name;
	}

	public String getDbms2Level() {
		return dbms2Level;
	}

	public void setDbms2Level(String dbms2Level) {
		this.dbms2Level = dbms2Level;
	}

	public String getDbms2Name() {
		return dbms2Name;
	}

	public void setDbms2Name(String dbms2Name) {
		this.dbms2Name = dbms2Name;
	}

	public String getDbms3Level() {
		return dbms3Level;
	}

	public void setDbms3Level(String dbms3Level) {
		this.dbms3Level = dbms3Level;
	}

	public String getDbms3Name() {
		return dbms3Name;
	}

	public void setDbms3Name(String dbms3Name) {
		this.dbms3Name = dbms3Name;
	}

	public String getGogaku() {
		return gogaku;
	}

	public void setGogaku(String gogaku) {
		this.gogaku = gogaku;
	}

	public String getGraphics() {
		return graphics;
	}

	public void setGraphics(String graphics) {
		this.graphics = graphics;
	}

	public String getGroupware() {
		return groupware;
	}

	public void setGroupware(String groupware) {
		this.groupware = groupware;
	}

	public String getGyoshu1GyomuName() {
		return gyoshu1GyomuName;
	}

	public void setGyoshu1GyomuName(String gyoshu1GyomuName) {
		this.gyoshu1GyomuName = gyoshu1GyomuName;
	}

	public String getGyoshu1GyoshuName() {
		return gyoshu1GyoshuName;
	}

	public void setGyoshu1GyoshuName(String gyoshu1GyoshuName) {
		this.gyoshu1GyoshuName = gyoshu1GyoshuName;
	}

	public String getGyoshu1Level() {
		return gyoshu1Level;
	}

	public void setGyoshu1Level(String gyoshu1Level) {
		this.gyoshu1Level = gyoshu1Level;
	}

	public String getGyoshu1ShosaiNaiyo() {
		return gyoshu1ShosaiNaiyo;
	}

	public void setGyoshu1ShosaiNaiyo(String gyoshu1ShosaiNaiyo) {
		this.gyoshu1ShosaiNaiyo = gyoshu1ShosaiNaiyo;
	}

	public String getGyoshu2GyomuName() {
		return gyoshu2GyomuName;
	}

	public void setGyoshu2GyomuName(String gyoshu2GyomuName) {
		this.gyoshu2GyomuName = gyoshu2GyomuName;
	}

	public String getGyoshu2GyoshuName() {
		return gyoshu2GyoshuName;
	}

	public void setGyoshu2GyoshuName(String gyoshu2GyoshuName) {
		this.gyoshu2GyoshuName = gyoshu2GyoshuName;
	}

	public String getGyoshu2Level() {
		return gyoshu2Level;
	}

	public void setGyoshu2Level(String gyoshu2Level) {
		this.gyoshu2Level = gyoshu2Level;
	}

	public String getGyoshu2ShosaiNaiyo() {
		return gyoshu2ShosaiNaiyo;
	}

	public void setGyoshu2ShosaiNaiyo(String gyoshu2ShosaiNaiyo) {
		this.gyoshu2ShosaiNaiyo = gyoshu2ShosaiNaiyo;
	}

	public String getGyoshu3GyomuName() {
		return gyoshu3GyomuName;
	}

	public void setGyoshu3GyomuName(String gyoshu3GyomuName) {
		this.gyoshu3GyomuName = gyoshu3GyomuName;
	}

	public String getGyoshu3GyoshuName() {
		return gyoshu3GyoshuName;
	}

	public void setGyoshu3GyoshuName(String gyoshu3GyoshuName) {
		this.gyoshu3GyoshuName = gyoshu3GyoshuName;
	}

	public String getGyoshu3Level() {
		return gyoshu3Level;
	}

	public void setGyoshu3Level(String gyoshu3Level) {
		this.gyoshu3Level = gyoshu3Level;
	}

	public String getGyoshu3ShosaiNaiyo() {
		return gyoshu3ShosaiNaiyo;
	}

	public void setGyoshu3ShosaiNaiyo(String gyoshu3ShosaiNaiyo) {
		this.gyoshu3ShosaiNaiyo = gyoshu3ShosaiNaiyo;
	}

	public String getHikokai() {
		return hikokai;
	}

	public void setHikokai(String hikokai) {
		this.hikokai = hikokai;
	}

	public String getHyojunka() {
		return hyojunka;
	}

	public void setHyojunka(String hyojunka) {
		this.hyojunka = hyojunka;
	}

	public String getImageProcessing() {
		return imageProcessing;
	}

	public void setImageProcessing(String imageProcessing) {
		this.imageProcessing = imageProcessing;
	}

	public String getJinkoChino() {
		return jinkoChino;
	}

	public void setJinkoChino(String jinkoChino) {
		this.jinkoChino = jinkoChino;
	}

	public String getJinmyakuKochiku() {
		return jinmyakuKochiku;
	}

	public void setJinmyakuKochiku(String jinmyakuKochiku) {
		this.jinmyakuKochiku = jinmyakuKochiku;
	}

	public String getJohoShoriChishikiShosaiNaiyo() {
		return johoShoriChishikiShosaiNaiyo;
	}

	public void setJohoShoriChishikiShosaiNaiyo(String johoShoriChishikiShosaiNaiyo) {
		this.johoShoriChishikiShosaiNaiyo = johoShoriChishikiShosaiNaiyo;
	}

	public String getJohoShushu() {
		return johoShushu;
	}

	public void setJohoShushu(String johoShushu) {
		this.johoShushu = johoShushu;
	}

	public String getKeisankiArch() {
		return keisankiArch;
	}

	public void setKeisankiArch(String keisankiArch) {
		this.keisankiArch = keisankiArch;
	}

	public String getKigoShori() {
		return kigoShori;
	}

	public void setKigoShori(String kigoShori) {
		this.kigoShori = kigoShori;
	}

	public String getKokusaika() {
		return kokusaika;
	}

	public void setKokusaika(String kokusaika) {
		this.kokusaika = kokusaika;
	}

	public String getKokyakuSessho() {
		return kokyakuSessho;
	}

	public void setKokyakuSessho(String kokyakuSessho) {
		this.kokyakuSessho = kokyakuSessho;
	}

	public String getLeaderShip() {
		return leaderShip;
	}

	public void setLeaderShip(String leaderShip) {
		this.leaderShip = leaderShip;
	}

	public String getManMachineSystem() {
		return manMachineSystem;
	}

	public void setManMachineSystem(String manMachineSystem) {
		this.manMachineSystem = manMachineSystem;
	}

	public String getMondaiKaiketsu() {
		return mondaiKaiketsu;
	}

	public void setMondaiKaiketsu(String mondaiKaiketsu) {
		this.mondaiKaiketsu = mondaiKaiketsu;
	}

	public String getNegotiation() {
		return negotiation;
	}

	public void setNegotiation(String negotiation) {
		this.negotiation = negotiation;
	}

	public String getOnline1Level() {
		return online1Level;
	}

	public void setOnline1Level(String online1Level) {
		this.online1Level = online1Level;
	}

	public String getOnline1Name() {
		return online1Name;
	}

	public void setOnline1Name(String online1Name) {
		this.online1Name = online1Name;
	}

	public String getOnline2Level() {
		return online2Level;
	}

	public void setOnline2Level(String online2Level) {
		this.online2Level = online2Level;
	}

	public String getOnline2Name() {
		return online2Name;
	}

	public void setOnline2Name(String online2Name) {
		this.online2Name = online2Name;
	}

	public String getOnline3Level() {
		return online3Level;
	}

	public void setOnline3Level(String online3Level) {
		this.online3Level = online3Level;
	}

	public String getOnline3Name() {
		return online3Name;
	}

	public void setOnline3Name(String online3Name) {
		this.online3Name = online3Name;
	}

	public String getOperatingSystem() {
		return operatingSystem;
	}

	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}

	public String getOs1Level() {
		return os1Level;
	}

	public void setOs1Level(String os1Level) {
		this.os1Level = os1Level;
	}

	public String getOs1Name() {
		return os1Name;
	}

	public void setOs1Name(String os1Name) {
		this.os1Name = os1Name;
	}

	public String getOs2Level() {
		return os2Level;
	}

	public void setOs2Level(String os2Level) {
		this.os2Level = os2Level;
	}

	public String getOs2Name() {
		return os2Name;
	}

	public void setOs2Name(String os2Name) {
		this.os2Name = os2Name;
	}

	public String getOs3Level() {
		return os3Level;
	}

	public void setOs3Level(String os3Level) {
		this.os3Level = os3Level;
	}

	public String getOs3Name() {
		return os3Name;
	}

	public void setOs3Name(String os3Name) {
		this.os3Name = os3Name;
	}

	public String getPresentation() {
		return presentation;
	}

	public void setPresentation(String presentation) {
		this.presentation = presentation;
	}

	public String getProgram1Level() {
		return program1Level;
	}

	public void setProgram1Level(String program1Level) {
		this.program1Level = program1Level;
	}

	public String getProgram1Name() {
		return program1Name;
	}

	public void setProgram1Name(String program1Name) {
		this.program1Name = program1Name;
	}

	public String getProgram2Level() {
		return program2Level;
	}

	public void setProgram2Level(String program2Level) {
		this.program2Level = program2Level;
	}

	public String getProgram2Name() {
		return program2Name;
	}

	public void setProgram2Name(String program2Name) {
		this.program2Name = program2Name;
	}

	public String getProgram3Level() {
		return program3Level;
	}

	public void setProgram3Level(String program3Level) {
		this.program3Level = program3Level;
	}

	public String getProgram3Name() {
		return program3Name;
	}

	public void setProgram3Name(String program3Name) {
		this.program3Name = program3Name;
	}

	public String getProgramLanguage() {
		return programLanguage;
	}

	public void setProgramLanguage(String programLanguage) {
		this.programLanguage = programLanguage;
	}

	public String getQualityManagement() {
		return qualityManagement;
	}

	public void setQualityManagement(String qualityManagement) {
		this.qualityManagement = qualityManagement;
	}

	public String getRiskManagement() {
		return riskManagement;
	}

	public void setRiskManagement(String riskManagement) {
		this.riskManagement = riskManagement;
	}

	public String getScopeManagement() {
		return scopeManagement;
	}

	public void setScopeManagement(String scopeManagement) {
		this.scopeManagement = scopeManagement;
	}

	public String getSeihinShosaiNaiyo() {
		return seihinShosaiNaiyo;
	}

	public void setSeihinShosaiNaiyo(String seihinShosaiNaiyo) {
		this.seihinShosaiNaiyo = seihinShosaiNaiyo;
	}

	public String getShimei() {
		return shimei;
	}

	public void setShimei(String shimei) {
		this.shimei = shimei;
	}

	public String getShimeiNo() {
		return shimeiNo;
	}

	public void setShimeiNo(String shimeiNo) {
		this.shimeiNo = shimeiNo;
	}

	public String getShinkiKikaku() {
		return shinkiKikaku;
	}

	public void setShinkiKikaku(String shinkiKikaku) {
		this.shinkiKikaku = shinkiKikaku;
	}

	public String getSogoManagement() {
		return sogoManagement;
	}

	public void setSogoManagement(String sogoManagement) {
		this.sogoManagement = sogoManagement;
	}

	public String getSonotaJohoShori1Level() {
		return sonotaJohoShori1Level;
	}

	public void setSonotaJohoShori1Level(String sonotaJohoShori1Level) {
		this.sonotaJohoShori1Level = sonotaJohoShori1Level;
	}

	public String getSonotaJohoShori1Name() {
		return sonotaJohoShori1Name;
	}

	public void setSonotaJohoShori1Name(String sonotaJohoShori1Name) {
		this.sonotaJohoShori1Name = sonotaJohoShori1Name;
	}

	public String getSonotaJohoShori2Level() {
		return sonotaJohoShori2Level;
	}

	public void setSonotaJohoShori2Level(String sonotaJohoShori2Level) {
		this.sonotaJohoShori2Level = sonotaJohoShori2Level;
	}

	public String getSonotaJohoShori2Name() {
		return sonotaJohoShori2Name;
	}

	public void setSonotaJohoShori2Name(String sonotaJohoShori2Name) {
		this.sonotaJohoShori2Name = sonotaJohoShori2Name;
	}

	public String getSonotaJohoShori3Level() {
		return sonotaJohoShori3Level;
	}

	public void setSonotaJohoShori3Level(String sonotaJohoShori3Level) {
		this.sonotaJohoShori3Level = sonotaJohoShori3Level;
	}

	public String getSonotaJohoShori3Name() {
		return sonotaJohoShori3Name;
	}

	public void setSonotaJohoShori3Name(String sonotaJohoShori3Name) {
		this.sonotaJohoShori3Name = sonotaJohoShori3Name;
	}

	public String getSonotaSeihin1() {
		return sonotaSeihin1;
	}

	public void setSonotaSeihin1(String sonotaSeihin1) {
		this.sonotaSeihin1 = sonotaSeihin1;
	}

	public String getSonotaSeihin1Level() {
		return sonotaSeihin1Level;
	}

	public void setSonotaSeihin1Level(String sonotaSeihin1Level) {
		this.sonotaSeihin1Level = sonotaSeihin1Level;
	}

	public String getSonotaSeihin2() {
		return sonotaSeihin2;
	}

	public void setSonotaSeihin2(String sonotaSeihin2) {
		this.sonotaSeihin2 = sonotaSeihin2;
	}

	public String getSonotaSeihin2Level() {
		return sonotaSeihin2Level;
	}

	public void setSonotaSeihin2Level(String sonotaSeihin2Level) {
		this.sonotaSeihin2Level = sonotaSeihin2Level;
	}

	public String getSonotaSeihin3() {
		return sonotaSeihin3;
	}

	public void setSonotaSeihin3(String sonotaSeihin3) {
		this.sonotaSeihin3 = sonotaSeihin3;
	}

	public String getSonotaSeihin3Level() {
		return sonotaSeihin3Level;
	}

	public void setSonotaSeihin3Level(String sonotaSeihin3Level) {
		this.sonotaSeihin3Level = sonotaSeihin3Level;
	}

	public String getSonotaSeihin4() {
		return sonotaSeihin4;
	}

	public void setSonotaSeihin4(String sonotaSeihin4) {
		this.sonotaSeihin4 = sonotaSeihin4;
	}

	public String getSonotaSeihin4Level() {
		return sonotaSeihin4Level;
	}

	public void setSonotaSeihin4Level(String sonotaSeihin4Level) {
		this.sonotaSeihin4Level = sonotaSeihin4Level;
	}

	public String getSonotaSeihin5() {
		return sonotaSeihin5;
	}

	public void setSonotaSeihin5(String sonotaSeihin5) {
		this.sonotaSeihin5 = sonotaSeihin5;
	}

	public String getSonotaSeihin5Level() {
		return sonotaSeihin5Level;
	}

	public void setSonotaSeihin5Level(String sonotaSeihin5Level) {
		this.sonotaSeihin5Level = sonotaSeihin5Level;
	}

	public String getSonotaSeihin6() {
		return sonotaSeihin6;
	}

	public void setSonotaSeihin6(String sonotaSeihin6) {
		this.sonotaSeihin6 = sonotaSeihin6;
	}

	public String getSonotaSeihin6Level() {
		return sonotaSeihin6Level;
	}

	public void setSonotaSeihin6Level(String sonotaSeihin6Level) {
		this.sonotaSeihin6Level = sonotaSeihin6Level;
	}

	public String getSoshikika() {
		return soshikika;
	}

	public void setSoshikika(String soshikika) {
		this.soshikika = soshikika;
	}

	public String getSoshikiManagement() {
		return soshikiManagement;
	}

	public void setSoshikiManagement(String soshikiManagement) {
		this.soshikiManagement = soshikiManagement;
	}

	public String getSuchiKaiseki() {
		return suchiKaiseki;
	}

	public void setSuchiKaiseki(String suchiKaiseki) {
		this.suchiKaiseki = suchiKaiseki;
	}

	public String getSystemHyoka() {
		return systemHyoka;
	}

	public void setSystemHyoka(String systemHyoka) {
		this.systemHyoka = systemHyoka;
	}

	public String getTeianKatsudo() {
		return teianKatsudo;
	}

	public void setTeianKatsudo(String teianKatsudo) {
		this.teianKatsudo = teianKatsudo;
	}

	public String getTimeManagement() {
		return timeManagement;
	}

	public void setTimeManagement(String timeManagement) {
		this.timeManagement = timeManagement;
	}

	public String getTrouble() {
		return trouble;
	}

	public void setTrouble(String trouble) {
		this.trouble = trouble;
	}
	
	
}
