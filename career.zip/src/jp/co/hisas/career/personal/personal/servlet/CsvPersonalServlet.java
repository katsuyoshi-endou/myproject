/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.personal.personal.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Writer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.personal.accesslog.bean.AccesslogBean;
import jp.co.hisas.career.personal.personal.bean.PersonalCsvAssessmentValueBean;
import jp.co.hisas.career.personal.personal.bean.PersonalCsvOutputFlgValueBean;
import jp.co.hisas.career.personal.personal.bean.PersonalCsvValueBean;
import jp.co.hisas.career.personal.util.CsvConditionHeaderValueBean;
import jp.co.hisas.career.personal.util.CsvValueBeanList;
import jp.co.hisas.career.plan.base.VelocityHelper;
import jp.co.hisas.career.plan.base.bean.PBY_SkillStandardBean;
import jp.co.hisas.career.search.jiyukensaku.bean.JiyuKensakuBean;
import jp.co.hisas.career.util.common.PZZ050_FileUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �p�[�\�i���v���t�@�C����CSV�f�[�^���o�͂���
 */
public class CsvPersonalServlet extends HttpServlet {
	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/** �\���I����� */
	private final int SHIMEINO_OUTPUT = 0;

	private final int GROUPNO_OUTPUT = 1;

	private final int SHIMEIKANJI_OUTPUT = 2;

	private final int SHIMEIKANA_OUTPUT = 3;

	private final int SHIMEIEIJI_OUTPUT = 4;

	private final int NYUSHANENGAPPI_OUTPUT = 5;

	private final int JIKOPR_OUTPUT = 6;

	private final int SHOZOKU_OUTPUT = 7;

	private final int BUSHO_OUTPUT = 8;

	private final int YAKUSHOKU_OUTPUT = 9;

	private final int GAISEN_OUTPUT = 10;

	private final int NAISEN_OUTPUT = 11;

	private final int FAX_OUTPUT = 12;

	private final int MAIL_OUTPUT = 13;

	private final int SHOKUI_OUTPUT = 14;

	private final int SEIBETSU_OUTPUT = 15;

	private final int SEINENGAPPI_OUTPUT = 16;

	private final int JOB_OUTPUT = 17;

	private final int SUPERVISOR_OUTPUT = 18;

	private final int ASSESSMENT_OUTPUT = 19;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U����CSV�t�@�C���쐬�v�����󂯎��A�N���C�A���gBean��CSV�t�@�C���쐬���\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequset�I�u�W�F�N�g
	 * @param response Servlet����̂̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet�̐���ȏ������W����ꂽ���ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = null;

		try {
			/* �ϐ� */
			int count = 0;

			final HttpSession session = request.getSession(false);

			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");
				final AccesslogBean accesslogbean = (AccesslogBean) session.getAttribute("accesslog");
				login_no = userinfo.getLogin_no();

				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				/* CSV�o�̓t���O�̎擾 */
				final String csv_flg = request.getParameter("Csv_flg");

				final String[] checked_num = request.getParameterValues("C001_komoku");

				// ValueBeanList
				final CsvValueBeanList valueBeanList = new CsvValueBeanList();

				final PersonalCsvValueBean header = new PersonalCsvValueBean();

				header.setShimeiNo((String) ReadFile.paramMapData.get("DZZ002"));
				header.setGroupNo((String) ReadFile.paramMapData.get("DZZ189"));
				header.setKanjiShimei((String) ReadFile.paramMapData.get("DZZ003"));
				header.setKanaShimei((String) ReadFile.paramMapData.get("DZZ004"));
				header.setEijiShimei((String) ReadFile.paramMapData.get("DZZ005"));
				header.setNyushaNengappi((String) ReadFile.paramMapData.get("DZZ015"));
				header.setJikoPR((String) ReadFile.paramMapData.get("DZZ016"));
				header.setShozoku((String) ReadFile.paramMapData.get("DZZ007"));
				header.setBusho((String) ReadFile.paramMapData.get("DZZ014"));
				header.setYakushoku((String) ReadFile.paramMapData.get("DZZ017"));
				header.setGaisen((String) ReadFile.paramMapData.get("DZZ018"));
				header.setNaisen((String) ReadFile.paramMapData.get("DZZ019"));
				header.setFax((String) ReadFile.paramMapData.get("DZZ020"));
				header.setMail((String) ReadFile.paramMapData.get("DZZ021"));
				header.setShokui((String) ReadFile.paramMapData.get("DZZ022"));
				header.setSeibetsu((String) ReadFile.paramMapData.get("DZZ023"));
				header.setSeinengappi((String) ReadFile.paramMapData.get("DZZ024"));
				header.setJob((String) ReadFile.paramMapData.get("DZZ112"));
				header.setSupervisor((String) ReadFile.paramMapData.get("DZZ113"));
				PersonalCsvAssessmentValueBean assessment = new PersonalCsvAssessmentValueBean();
				assessment.setShokushu((String) ReadFile.paramMapData.get("DAA001"));
				assessment.setSenmonbunya((String) ReadFile.paramMapData.get("DAA004"));
				assessment.setLevel((String) ReadFile.paramMapData.get("DAA007"));
				assessment.setSogoTasaeido((String) ReadFile.paramMapData.get("DAA010"));
				header.addAssessment(assessment);
				assessment = new PersonalCsvAssessmentValueBean();
				assessment.setShokushu((String) ReadFile.paramMapData.get("DAA002"));
				assessment.setSenmonbunya((String) ReadFile.paramMapData.get("DAA005"));
				assessment.setLevel((String) ReadFile.paramMapData.get("DAA008"));
				assessment.setSogoTasaeido((String) ReadFile.paramMapData.get("DAA011"));
				header.addAssessment(assessment);
				assessment = new PersonalCsvAssessmentValueBean();
				assessment.setShokushu((String) ReadFile.paramMapData.get("DAA003"));
				assessment.setSenmonbunya((String) ReadFile.paramMapData.get("DAA006"));
				assessment.setLevel((String) ReadFile.paramMapData.get("DAA009"));
				assessment.setSogoTasaeido((String) ReadFile.paramMapData.get("DAA012"));
				header.addAssessment(assessment);

				valueBeanList.setHeader(header);

				// ��ʂőI�����ꂽ�o�͑Ώۂ̐ݒ�
				valueBeanList.setAdditionalValue(checkOutput(checked_num));

				/* ���O�o�͏���ID */
				String syoriID = "";
				String logsimei = "";
				String logjouken = "";

				/* ���R������������CSV�o�͂̏ꍇ */
				if (csv_flg.equals("1")) {
					final JiyuKensakuBean kensakubean = (JiyuKensakuBean) session.getAttribute("jiyukensaku");

					/* �������ʂ��f�[�^�擾 */
					final String[][] kekka = kensakubean.getKekka();

					if (kekka != null) {
						count = kekka.length - 1;
					} else {
						count = 0;
					}

					/* �����������w�b�_�ɏo�� */
					logjouken = kensakubean.getSQL1JP() + " " + kensakubean.getSQL2JP() + " " + kensakubean.getSQL3JP() + " " + kensakubean.getSQL4JP() + " " + kensakubean.getSQL5JP();
					if (request.getParameter("kensakujyoken") != null) {
						final String SQL1JP = kensakubean.getSQL1JP();
						final String SQL2JP = kensakubean.getSQL2JP();
						final String SQL3JP = kensakubean.getSQL3JP();
						final String SQL4JP = kensakubean.getSQL4JP();
						final String SQL5JP = kensakubean.getSQL5JP();

						// �ǉ��w�b�_���i�[����ValueBeanList
						final CsvValueBeanList addHeaderList = new CsvValueBeanList();
						CsvConditionHeaderValueBean addHeader = null;

						if (SQL1JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL1JP);
							addHeaderList.add(addHeader);
						}
						if (SQL2JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL2JP);
							addHeaderList.add(addHeader);
						}
						if (SQL3JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL3JP);
							addHeaderList.add(addHeader);
						}
						if (SQL4JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL4JP);
							addHeaderList.add(addHeader);
						}
						if (SQL5JP.length() != 0) {
							addHeader = new CsvConditionHeaderValueBean();
							addHeader.setCondition(SQL5JP);
							addHeaderList.add(addHeader);
						}

						// �e��ValueBeanList�ɒǉ��w�b�_��ݒ�
						valueBeanList.setAdditionalHeader(addHeaderList);
					}

					for (int i = 0; i < count; i++) {
						final String simei_no = kekka[i][0]; // ����NO

						/* �p�[�\�i����񌟍��������s */
						userinfo.searchsansyo(simei_no, HcdbDef.jndi, "1");

						/* �f�[�^ */
						valueBeanList.add(this.makeCVSrecord(userinfo, checked_num, login_no));

						/* �A�N�Z�X���O�b�r�u�o�͉񐔂��P���₷ */
						accesslogbean.personalCsvCount();
					}

					syoriID = "PPP042";
					OutLogBean.sousaKojinJohoLog(syoriID, login_no, logsimei, logjouken);
				} else {
					/* �߰������̧�ق��o�͂���ꍇ */
					/* 1���R�[�h�f�[�^���擾 */
					valueBeanList.add(this.makeCVSrecord(userinfo, checked_num, login_no));

					/* �A�N�Z�X���O�b�r�u�o�͉񐔂��P���₷ */
					accesslogbean.personalCsvCount();

					syoriID = "PPP007";
					logsimei = userinfo.getSimei_no();
					OutLogBean.sousaKojinJohoLog(syoriID, login_no, logsimei, logjouken);
				}

				/* Velocity��p���āA�o�̓t�@�C���e���v���[�g�Ƀf�[�^��ݒ肷�� */
				final VelocityHelper vh = new VelocityHelper(HcdbDef.PERSONAL_CSV_TEMPLATE);
				vh.setParameter("BeanList", valueBeanList);
				final Writer w = vh.getWriter();
				// �s���̗]���ȃJ���}������
				final String csvData = w.toString().replaceAll(",\\r\\n", "\r\n");
				final ByteArrayInputStream bais = new ByteArrayInputStream(csvData.getBytes());
				request.setAttribute("H080_FileName", PZZ050_FileUtil.getFileName(PZZ050_FileUtil.FILE_ID_PERSONAL_PROFILE_CSV, new String[] { login_no }));
				request.setAttribute("H081_ContentType", HcdbDef.CONTENT_TYPE);
				request.setAttribute("STREAM", bais);

				final RequestDispatcher rd = this.ctx.getRequestDispatcher("/servlet/PYE010_FileDownloadServlet");
				rd.forward(request, response);

				Log.debug("�b�r�u�f�[�^�]������");

				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}

	/**
	 * CSV�o�͍s���쐬���郁�\�b�h
	 * @param uib UserInfoBean �o�͏����擾����
	 * @param checked_num �I�����ꂽ�o�͍��ڂ�ێ����Ă���B
	 * @return CSV1���R�[�h
	 */
	private PersonalCsvValueBean makeCVSrecord(final UserInfoBean uib, final String[] checked_num, final String loginNo) {
		final String hikokai = "����J";

		/** �ő�A�Z�X�����g�� */
		final int assessmentNum = 3;

		// �P�s����ێ�����N���X
		final PersonalCsvValueBean valueBean = new PersonalCsvValueBean();

		/* �p�[�\�i���T�C�g���擾 */
		final String[] flg_param = { uib.getSimei_no_flg(), // ����NO
				uib.getKanji_simei(), // ��������
				uib.getKana_simei(), // �J�i����
				uib.getEiji_simei(), // �p������
				uib.getBusyo_ryakusyo_mei(), // �������̖�
				uib.getSeibetu(), // ����
				uib.getJiko_pr(), // ����PR
				uib.getSeinengappi(), // ���N����
				uib.getNyusya_nengetu(), // ���ДN����
				uib.getYobi1(), // �O���[�vNO
				uib.getYobi2(), // Job���{�ꖼ��
				uib.getYobi3(), // Job�p�ꖼ��
				uib.getYobi4(), // �X�[�p�o�C�U�[���{�ꖼ��
				uib.getYobi5() // �X�[�p�o�C�U�[�p�ꖼ��
		};

		/* �擪1�o�C�g���`�F�b�N���A���J�𔻒f���� */
		for (int i = 0; i < flg_param.length; i++) {
			if (!flg_param[i].equals(hikokai)) {
				/* ���J�t���O������ */
				if (flg_param[i] != null && flg_param[i].length() > 0) {
					flg_param[i] = flg_param[i].substring(1);
				}
			}
		}

		/* ���� �o�͌^�ύX */
		if (flg_param[5].length() == 1) {
			if (flg_param[5].equals(HcdbDef.MALE)) {
				flg_param[5] = "�j��";
			} else {
				flg_param[5] = "����";
			}
		}

		final String[][] jyuji_syokusyu = uib.getJyuji_syokusyu();

		if (jyuji_syokusyu != null && !jyuji_syokusyu[0][0].equals("����J")) {
			for (int i = 0; i < jyuji_syokusyu.length; i++) {
				String syoku_name = PBY_SkillStandardBean.getSyokuName(jyuji_syokusyu[i][0]);
				String senmon_name = PBY_SkillStandardBean.getSenmonName(jyuji_syokusyu[i][0], jyuji_syokusyu[i][1]);
				String level_name = PBY_SkillStandardBean.getLevelName(jyuji_syokusyu[i][0], jyuji_syokusyu[i][1], jyuji_syokusyu[i][2]);
				String sogo_do = jyuji_syokusyu[i][3] + "%";

				/* NULL�̏ꍇ�A�o�͒�~ */
				if (syoku_name == null || syoku_name.equals("")) {
					syoku_name = "";
					senmon_name = "";
					level_name = "";
					sogo_do = "";
				}

				final PersonalCsvAssessmentValueBean assessment = new PersonalCsvAssessmentValueBean();
				assessment.setShokushu(syoku_name);
				assessment.setSenmonbunya(senmon_name);
				assessment.setLevel(level_name);
				assessment.setSogoTasaeido(sogo_do);
				// �A�Z�X�����g�����i�[
				valueBean.addAssessment(assessment);
			}
		} else {
			for (int i = 0; i < assessmentNum; i++) {
				final PersonalCsvAssessmentValueBean assessment = new PersonalCsvAssessmentValueBean();
				assessment.setShokushu(hikokai);
				assessment.setSenmonbunya(hikokai);
				assessment.setLevel(hikokai);
				assessment.setSogoTasaeido(hikokai);
				// �A�Z�X�����g�����i�[
				valueBean.addAssessment(assessment);
			}
		}

		valueBean.setShimeiNo(flg_param[0]);
		valueBean.setGroupNo(flg_param[9]);
		valueBean.setKanjiShimei(flg_param[1]);
		valueBean.setKanaShimei(flg_param[2]);
		valueBean.setEijiShimei(flg_param[3]);
		valueBean.setNyushaNengappi(flg_param[8]);
		valueBean.setJikoPR(flg_param[6]);
		valueBean.setShozoku(uib.getSyozoku());
		valueBean.setBusho(flg_param[4]);
		valueBean.setYakushoku(uib.getYakusyoku());
		valueBean.setGaisen(uib.getGaisen());
		valueBean.setNaisen(uib.getNaisen());
		valueBean.setFax(uib.getFax_no());
		valueBean.setMail(uib.getMail());
		valueBean.setShokui(uib.getSyokui());
		valueBean.setSeibetsu(flg_param[5]);
		valueBean.setSeinengappi(flg_param[7]);
		valueBean.setJob(flg_param[10] + " " + flg_param[11]);
		valueBean.setSupervisor(flg_param[12] + " " + flg_param[13]);

		return valueBean;
	}

	private PersonalCsvOutputFlgValueBean checkOutput(final String[] checkNum) {

		final PersonalCsvOutputFlgValueBean valueBean = new PersonalCsvOutputFlgValueBean();

		for (int i = 0; i < checkNum.length; i++) {
			switch (Integer.parseInt(checkNum[i])) {
			case SHIMEINO_OUTPUT:
				valueBean.setShimeiNo_output("1");
				break;
			case GROUPNO_OUTPUT:
				valueBean.setGroupNo_output("1");
				break;
			case SHIMEIKANJI_OUTPUT:
				valueBean.setShimeiKanji_output("1");
				break;
			case SHIMEIKANA_OUTPUT:
				valueBean.setShimeiKana_output("1");
				break;
			case SHIMEIEIJI_OUTPUT:
				valueBean.setShimeiEiji_output("1");
				break;
			case NYUSHANENGAPPI_OUTPUT:
				valueBean.setNyushaNengappi_output("1");
				break;
			case JIKOPR_OUTPUT:
				valueBean.setJikoPR_output("1");
				break;
			case SHOZOKU_OUTPUT:
				valueBean.setShozoku_output("1");
				break;
			case BUSHO_OUTPUT:
				valueBean.setBusho_output("1");
				break;
			case YAKUSHOKU_OUTPUT:
				valueBean.setYakushoku_output("1");
				break;
			case GAISEN_OUTPUT:
				valueBean.setGaisen_output("1");
				break;
			case NAISEN_OUTPUT:
				valueBean.setNaisen_output("1");
				break;
			case FAX_OUTPUT:
				valueBean.setFax_output("1");
				break;
			case MAIL_OUTPUT:
				valueBean.setMail_output("1");
				break;
			case SHOKUI_OUTPUT:
				valueBean.setShokui_output("1");
				break;
			case SEIBETSU_OUTPUT:
				valueBean.setSeibetsu_output("1");
				break;
			case SEINENGAPPI_OUTPUT:
				valueBean.setSeinengappi_output("1");
				break;
			case JOB_OUTPUT:
				valueBean.setJob_output("1");
				break;
			case SUPERVISOR_OUTPUT:
				valueBean.setSupervisor_output("1");
				break;
			case ASSESSMENT_OUTPUT:
				valueBean.setAssessment_output("1");
				break;
			}

		}

		return valueBean;
	}

}