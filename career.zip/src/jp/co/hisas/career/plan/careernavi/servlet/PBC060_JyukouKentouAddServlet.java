/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.plan.careernavi.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KamokuEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_KanrenKyoikuKamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �T�v: ��u�����Ȗڂ̒ǉ����s���܂��B ����ȖڂŁA����X�L���̉Ȗڂ͒ǉ�����܂���B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PBC060_JyukouKentouAddServlet extends HttpServlet {
	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/**
	 * ServletContext�I�u�W�F�N�g���擾����B
	 * @param config Servlet�̐ݒ�⏉�����p�����[�^���܂܂�Ă���ServletConfig�I�u�W�F�N�g
	 */
	public void init(final ServletConfig config) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}

	/**
	 * �u���E�U���瑗�M���ꂽ�l���󂯎��A���猤�C�����\�b�h���Ăяo���B
	 * @param request �N���C�A���g�̃��N�G�X�g��\��HttpServletRequest�I�u�W�F�N�g
	 * @param response Servlet ����̃��X�|���X��\��HttpServletResponse�I�u�W�F�N�g
	 * @exception IOException ���o�͊֘A�����Ŕ��������O
	 * @exception ServletException Servlet �̐���ȏ������W����ꂽ�Ƃ��ɔ��������O
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {
		String login_no = "";
		
		try {
			final HttpSession session = request.getSession(false);

			if (session == null) {
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			} else {
				final UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
				login_no = bean.getLogin_no();

				Log.method(login_no, "IN", "");
				Log.performance(login_no, true, "");

				final String[] kamoku_codes = request.getParameterValues("kamoku_codes");

				if (kamoku_codes != null) {
					for (int i = 0; i < kamoku_codes.length; i++) {
						kamoku_codes[i] = PZZ010_CharacterUtil.strEncode(kamoku_codes[i]);
					}
				}

				final String syoku_code = PZZ010_CharacterUtil.strEncode(request.getParameter("syoku_code"));
				final String senmon_code = PZZ010_CharacterUtil.strEncode(request.getParameter("senmon_code"));
				final String level_code = PZZ010_CharacterUtil.strEncode(request.getParameter("level_code"));
				final String skill_code = PZZ010_CharacterUtil.strEncode(request.getParameter("skill_code"));
				final String kamoku_group_code = PZZ010_CharacterUtil.strEncode(request.getParameter("kamoku_group_code"));
				final String kyoiku_kubun_code = PZZ010_CharacterUtil.strEncode(request.getParameter("kyoiku_kubun_code"));

				// EJBHome�Ǘ��N���X�̎擾
				final EJBHomeFactory fact = EJBHomeFactory.getInstance();
				final PCY_KamokuEJBHome kamoku_home = (PCY_KamokuEJBHome) fact.lookup(PCY_KamokuEJBHome.class);
				final PCY_KamokuEJB kamoku_ejb = kamoku_home.create();

				final PCY_KanrenKyoikuKamokuBean kensakuBean = new PCY_KanrenKyoikuKamokuBean();
				kensakuBean.setSyokusyuCode(syoku_code);
				kensakuBean.setSenmonCode(senmon_code);
				kensakuBean.setLevelCode(String.valueOf(Integer.parseInt(level_code) - 1));
				kensakuBean.setSkillCode(skill_code);
				kensakuBean.setKamokuGroupCode(kamoku_group_code);
				kensakuBean.setKyoikuKubunCode(kyoiku_kubun_code);

				final PCY_KamokuBean[] kamokuBeans = kamoku_ejb.doSelectByKanrenKyoiku(kensakuBean, new PCY_PersonalBean());

				final Collection col = new ArrayList();

				if (kamoku_codes != null) {
					for (int i = 0; i < kamoku_codes.length; i++) {
						for (int j = 0; j < kamokuBeans.length; j++) {
							if (kamoku_codes[i].equals(kamokuBeans[j].getKamokuCode())) {
								col.add(kamokuBeans[j]);
							}
						}
					}
				}

				final PCY_KamokuBean[] sessionKamokuBeans = (PCY_KamokuBean[]) session.getAttribute("careernavi.kamokuBeans");

				if (sessionKamokuBeans != null) {
					final PCY_KamokuBean[] check_kamokuBeans = (PCY_KamokuBean[]) col.toArray(new PCY_KamokuBean[0]);
					col.clear();

					/* �d�������ȖڃR�[�h�A�X�L���R�[�h�̂��̂̓J�[�g�ɑ}�����Ȃ� */
					for (int i = 0; i < check_kamokuBeans.length; i++) {
						boolean flg = true;

						for (int j = 0; j < sessionKamokuBeans.length; j++) {
							if (check_kamokuBeans[i].getKamokuCode().equals(sessionKamokuBeans[j].getKamokuCode())
									&& check_kamokuBeans[i].getKanrenKamokuBeans()[0].getSkillCode().equals(sessionKamokuBeans[j].getKanrenKamokuBeans()[0].getSkillCode())) {
								/* �ȖڃR�[�h�A�X�L���R�[�h������̂��̂����ɓo�^����Ă��� */
								flg = false;
								break;
							}
						}
						if (flg) {
							col.add(check_kamokuBeans[i]);
						}
					}
					col.addAll(Arrays.asList(sessionKamokuBeans));
				}

				session.setAttribute("careernavi.kamokuBeans", col.toArray(new PCY_KamokuBean[0]));

				/* JSP�y�[�W���Ăяo�� */
				final RequestDispatcher rd = this.ctx.getRequestDispatcher("/view/plan/careernavi/VBC040_KamokuListMain.jsp");
				rd.forward(request, response);
				Log.performance(login_no, false, "");
				Log.method(login_no, "OUT", "");
			}
		} catch (final Exception e) {
			Log.error(login_no, e);
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
		}
	}
}
