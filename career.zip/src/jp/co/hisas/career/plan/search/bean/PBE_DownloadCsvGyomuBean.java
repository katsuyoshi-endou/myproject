/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i�g�D�n �_�E�����[�h�@�\�@�Ɩ��p�̃f�[�^�i�[�p�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2005/08/11  03-00  ���H�� �G�F    �V�K�쐬
 */
package jp.co.hisas.career.plan.search.bean;

import java.io.Serializable;

/**
 * @author h-nerome ���̐������ꂽ�R�����g�̑}�������e���v���[�g��ύX���邽�� �E�B���h�E > �ݒ� > Java > �R�[�h���� > �R�[�h�ƃR�����g
 */
public class PBE_DownloadCsvGyomuBean extends PBE_ValueBean implements Serializable {

	/** �f�f�� */
	private String sindansya = "";

	/** �f�f�Ҏ��� */
	private String sindansya_kanji_simei = "";

	private String sindansya_kana_simei = "";

	private String sindansya_eiji_simei = "";

	/** �]���� */
	private String hyokasya = "";

	/** �]���Ҏ��� */
	private String hyokasya_kanji_simei = "";

	private String hyokasya_kana_simei = "";

	private String hyokasya_eiji_simei = "";

	/** �E�� */
	private String syoku_code = "";

	private String syoku_name = "";

	/** ��� */
	private String senmon_code = "";

	private String senmon_name = "";

	/** ���x�� */
	private String level_code = "";

	private String level_name = "";

	/** ���{�� */
	private String jissi_kaisu = "";

	/** �B���x�敪�R�[�h */
	private String tasseido_kubun_code = "";

	/** �B���x�敪 */
	private String tasseido_kubun = "";

	/** �B���x�w�W�R�[�h */
	private String tasseido_sihyo_code = "";

	/** �B���x�w�W */
	private String tasseido_sihyo = "";

	/** �敪 */
	private String kubun = "";

	/** �I���t���O */
	private String sentaku_flg_sindansya = "";

	private String sentaku_flg_hyokasya = "";

	/**
	 * @return
	 */
	public String getJissi_kaisu() {
		return this.jissi_kaisu;
	}

	/**
	 * @return
	 */
	public String getKubun() {
		return this.kubun;
	}

	/**
	 * @return
	 */
	public String getLevel_code() {
		return this.level_code;
	}

	public String getLevelName() {
		return this.level_name;
	}

	/**
	 * @return
	 */
	public String getSenmon_code() {
		return this.senmon_code;
	}

	public String getSenmonName() {
		return this.senmon_name;
	}

	/**
	 * @return
	 */
	public String getSentakuFlgSindansya() {
		return this.sentaku_flg_sindansya;
	}

	/**
	 * @return
	 */
	public String getSentakuFlgHyokasya() {
		return this.sentaku_flg_hyokasya;
	}

	/**
	 * @return
	 */
	public String getSindansya() {
		return this.sindansya;
	}

	/**
	 * @return
	 */
	public String getSindansyaKanjiSimei() {
		return this.sindansya_kanji_simei;
	}

	/**
	 * @return
	 */
	public String getSindansyaKanaSimei() {
		return this.sindansya_kana_simei;
	}

	/**
	 * @return
	 */
	public String getSindansyaEijiSimei() {
		return this.sindansya_eiji_simei;
	}

	public String getHyokasya() {
		return this.hyokasya;
	}

	public String getHyokasyaKanjiSimei() {
		return this.hyokasya_kanji_simei;
	}

	public String getHyokasyaKanaSimei() {
		return this.hyokasya_kana_simei;
	}

	public String getHyokasyaEijiSimei() {
		return this.hyokasya_eiji_simei;
	}

	/**
	 * @return
	 */
	public String getSyoku_code() {
		return this.syoku_code;
	}

	public String getSyokuName() {
		return this.syoku_name;
	}

	/**
	 * @return
	 */
	public String getTasseido_kubun() {
		return this.tasseido_kubun;
	}

	/**
	 * @return
	 */
	public String getTasseido_kubun_code() {
		return this.tasseido_kubun_code;
	}

	/**
	 * @return
	 */
	public String getTasseido_sihyo() {
		return this.tasseido_sihyo;
	}

	/**
	 * @return
	 */
	public String getTasseido_sihyo_code() {
		return this.tasseido_sihyo_code;
	}

	/**
	 * @param string
	 */
	public void setJissi_kaisu(final String string) {
		this.jissi_kaisu = string;
	}

	/**
	 * @param string
	 */
	public void setKubun(final String string) {
		this.kubun = string;
	}

	/**
	 * @param string
	 */
	public void setLevel_code(final String string) {
		this.level_code = string;
	}

	public void setLevelName(final String string) {
		this.level_name = string;
	}

	/**
	 * @param string
	 */
	public void setSenmon_code(final String string) {
		this.senmon_code = string;
	}

	public void setSenmonName(final String string) {
		this.senmon_name = string;
	}

	/**
	 * @param string
	 */
	public void setSentakuFlgSindansya(final String string) {
		this.sentaku_flg_sindansya = string;
	}

	public void setSentakuFlgHyokasya(final String string) {
		this.sentaku_flg_hyokasya = string;
	}

	/**
	 * @param string
	 */
	public void setSindansya(final String string) {
		this.sindansya = string;
	}

	public void setSindansyaKanjiSime(final String string) {
		this.sindansya_kanji_simei = string;
	}

	public void setSindansyaKanaSimei(final String string) {
		this.sindansya_kana_simei = string;
	}

	public void setSindansyaEijiSimei(final String string) {
		this.sindansya_eiji_simei = string;
	}

	public void setHyokasya(final String string) {
		this.hyokasya = string;
	}

	public void setHyokasyaKanjiSimei(final String string) {
		this.hyokasya_kanji_simei = string;
	}

	public void setHyokasyaKanaSimei(final String string) {
		this.hyokasya_kana_simei = string;
	}

	public void setHyokasyaEijiSimei(final String string) {
		this.hyokasya_eiji_simei = string;
	}

	/**
	 * @param string
	 */
	public void setSyoku_code(final String string) {
		this.syoku_code = string;
	}

	public void setSyokuName(final String string) {
		this.syoku_name = string;
	}

	/**
	 * @param string
	 */
	public void setTasseido_kubun(final String string) {
		this.tasseido_kubun = string;
	}

	/**
	 * @param string
	 */
	public void setTasseido_kubun_code(final String string) {
		this.tasseido_kubun_code = string;
	}

	/**
	 * @param string
	 */
	public void setTasseido_sihyo(final String string) {
		this.tasseido_sihyo = string;
	}

	/**
	 * @param string
	 */
	public void setTasseido_sihyo_code(final String string) {
		this.tasseido_sihyo_code = string;
	}

}
