/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyososikiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyokusyuBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY131_TaisyoSyutokuServlet �N���X �@�\�����F �Ώېݒ���̎擾���s���܂��B
 * 
 * </PRE>
 */
public class PCY130_TaisyoSyutokuServlet extends PCY010_ControllerServlet {
	/**
	 * �Ώېݒ�����擾���A�Z�b�V�����Ɋi�[���܂��B �Ώێ�Bean�z�� : taisyosyaBeans �ΏېE��Bean�z�� : taisyosyokusyuBeans �Ώۑg�DBean�z�� : taisyososikiBeans
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		final HttpSession session = request.getSession();

		PCY_TaisyosyokusyuBean[] taisyosyokusyuBeans = (PCY_TaisyosyokusyuBean[]) session.getAttribute("taisyosyokusyuBeans");
		PCY_TaisyososikiBean[] taisyososikiBeans = (PCY_TaisyososikiBean[]) session.getAttribute("taisyososikiBeans");
		PCY_TaisyosyaBean[] taisyosyaBeans = (PCY_TaisyosyaBean[]) session.getAttribute("taisyosyaBeans");
		/* �Ώێ�(�l)�����Ń\�[�g���s�Ȃ� */
		final boolean sort = true;

		if (taisyosyokusyuBeans == null || taisyososikiBeans == null || taisyosyaBeans == null) {
			taisyosyokusyuBeans = new PCY_TaisyosyokusyuBean[0];
			taisyososikiBeans = new PCY_TaisyososikiBean[0];
			taisyosyaBeans = new PCY_TaisyosyaBean[0];

			final String kamokuCode = request.getParameter("kamoku_code");
			final String classCode = request.getParameter("class_code");

			if (classCode != null && !classCode.trim().equals("")) {
				final PCY_TaisyoEJBHome home = (PCY_TaisyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_TaisyoEJBHome.class);
				final PCY_TaisyoEJB ejb = home.create();

				taisyosyokusyuBeans = ejb.getTaisyosyokusyu(kamokuCode, classCode, loginuser);
				taisyososikiBeans = ejb.getTaisyososiki(kamokuCode, classCode, loginuser);
				taisyosyaBeans = ejb.getTaisyosya(kamokuCode, classCode, loginuser, sort);
			}

			session.setAttribute("taisyosyokusyuBeans", taisyosyokusyuBeans);
			session.setAttribute("taisyososikiBeans", taisyososikiBeans);
			session.setAttribute("taisyosyaBeans", taisyosyaBeans);
		}

		session.setAttribute("taisyo_kubun", request.getParameter("taisyo_kubun"));

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
