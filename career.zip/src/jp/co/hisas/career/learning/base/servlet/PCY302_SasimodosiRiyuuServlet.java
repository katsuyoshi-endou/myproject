/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_MousikomiJyokyoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY302_SasimodosiRiyuuServlet �N���X �@�\�����F ���߂����R���͊m�F��ʂɑJ�ڂ��܂��B
 * 
 * </PRE>
 */
public class PCY302_SasimodosiRiyuuServlet extends PCY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {

		// Log�o��
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final String[] check = request.getParameterValues("syonin");
		String kamokuCode = "";
		String classCode = "";
		String simeiNo = "";
		String status = "";

		final PCY_MousikomiJyokyoEJBHome home = (PCY_MousikomiJyokyoEJBHome) EJBHomeFactory.getInstance().lookup(PCY_MousikomiJyokyoEJBHome.class);
		final PCY_MousikomiJyokyoEJB ejb = home.create();

		final PCY_ClassEJBHome homeClass = (PCY_ClassEJBHome) EJBHomeFactory.getInstance().lookup(PCY_ClassEJBHome.class);
		final PCY_ClassEJB ejbClass = homeClass.create();

		for (int i = 0; i < check.length; i++) {

			kamokuCode = request.getParameter("kamoku_code_" + check[i]);
			classCode = request.getParameter("class_code_" + check[i]);
			simeiNo = request.getParameter("simei_no_" + check[i]);
			status = request.getParameter("status_" + check[i]);
			final String uketsuke = request.getParameter("uketsuke_" + check[i]);

			// �I���������R�[�h�̃N���X�����擾����
			PCY_ClassBean classBeanDummy = new PCY_ClassBean();
			classBeanDummy.getKamokuBean().setKamokuCode(kamokuCode);
			classBeanDummy.setClassCode(classCode);
			Log.transaction(loginuser.getSimeiNo(), true, "");
			final PCY_ClassBean classBean = ejbClass.doSelectByPrimaryKey(classBeanDummy, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");

			/* �I���������R�[�h�̏��(�\����)���擾���� */
			PCY_MousikomiJyokyoBean mousikomiJyokyoBean = new PCY_MousikomiJyokyoBean();
			mousikomiJyokyoBean.setKamokuCode(kamokuCode);
			mousikomiJyokyoBean.setClassCode(classCode);
			mousikomiJyokyoBean.setSimeiNo(simeiNo);
			mousikomiJyokyoBean.setStatus(status);

			Log.transaction(loginuser.getSimeiNo(), true, "");
			final PCY_MousikomiJyokyoBean[] mousikomiJyokyoBeans = ejb.getList(mousikomiJyokyoBean, loginuser);
			Log.transaction(loginuser.getSimeiNo(), false, "");

			// ���F�s�v�̏ꍇ
			if (classBean.getSyoninKubun().equals("0")) {
				request.setAttribute("warningID", "WCB050");
				throw new PCY_WarningException();
			}
			// ��t�敪��"�v"�̃N���X�̏ꍇ
			if (classBean.getUketukeKubun().equals("1")) {
				// �񍐑҂��A����҂��̏ꍇ
				if (Integer.parseInt(mousikomiJyokyoBeans[0].getStatus()) >= 2) {
					request.setAttribute("warningID", "WCB060");
					throw new PCY_WarningException();
				}
				// ��t�҂��̏ꍇ
				if (Integer.parseInt(mousikomiJyokyoBeans[0].getStatus()) == 1) {
					request.setAttribute("warningID", "WCB070");
					throw new PCY_WarningException();
				}
				// ��t�s�v�E�񍐋敪��"�v"�̃N���X�̏ꍇ
			} else if (!classBean.getHoukokuKubun().equals("0")) {
				if (Integer.parseInt(mousikomiJyokyoBeans[0].getStatus()) == 3) {
					request.setAttribute("warningID", "WCB080");
					throw new PCY_WarningException();
				}
			}
			// ���̑��p�^�[���ŏ��F�ς݂̏ꍇ
			if (Integer.parseInt(mousikomiJyokyoBeans[0].getStatus()) != 0) {
				request.setAttribute("warningID", "WCB070");
				throw new PCY_WarningException();
			}
			classBeanDummy = null;
			mousikomiJyokyoBean = null;
		}
		return this.getForwardPath();
	}
}
