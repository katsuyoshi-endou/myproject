/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJB;
import jp.co.hisas.career.base.blob.ejb.PYF_BlobDBAccessEJBHome;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_JizenkadaiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_JizenkadaiEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_JizenkadaiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * �N���X���F PCY400_JizenkadaiDownloadServlet �N���X �@�\�����F ���O�ۑ���o�͂��܂��B
 * </PRE>
 * ADD 2017/05/15 COMTURE VCA400_���O�ۑ�ҏW�iver.02-00�j
 */
public class PCY400_JizenkadaiDownloadServlet extends PCY010_ControllerServlet {

    /**
     * ���N�G�X�g����v���C�}���L�[���擾���A�N���X�����擾���܂��B �N���X���̓��N�G�X�g(�������F"classBean")�Ɋi�[���܂��B �N���X��񂪑��݂��Ȃ��ꍇ�A���N�G�X�g�ɂ� null ���i�[����܂��B
     * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
     * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean )
     */
    protected String execute(final HttpServletRequest request, final HttpServletResponse response,
            final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException, Exception {

        // ���\�b�h�g���[�X�o��
        Log.method(loginuser.getSimeiNo(), "IN", "");

        final EJBHomeFactory fact = EJBHomeFactory.getInstance();

        // ���O�ۑ�}�X�^���擾
        final PCY_JizenkadaiEJBHome home = (PCY_JizenkadaiEJBHome)fact.lookup(PCY_JizenkadaiEJBHome.class);
        final PCY_JizenkadaiEJB ejb = home.create();
        final PCY_JizenkadaiBean jizenkadaiBean = ejb.doSelectByPrimaryKey(new PCY_JizenkadaiBean(request), loginuser);

        // ���O�ۑ�}�X�^���݃`�F�b�N
        if (jizenkadaiBean == null) {
            request.setAttribute("warningID", "WCC271");
            throw new PCY_WarningException("WCC271");
        }

        // �L�[
        final String[] primaryKey = { "KAMOKU_CODE", "CLASS_CODE" };

        // �L�[�l
        final String[] keyValue = { jizenkadaiBean.getKamokuCode(), jizenkadaiBean.getClassCode() };

        // �t�@�C�����擾
        final PYF_BlobDBAccessEJBHome blobHome = (PYF_BlobDBAccessEJBHome)fact.lookup(PYF_BlobDBAccessEJBHome.class);
        final PYF_BlobDBAccessEJB blobSession = blobHome.create();
        final byte[] jizenkadai =
                blobSession.SelectBLOB(loginuser.getSimeiNo(), HcdbDef.L02_JIZENKADAI_TBL, "JIZENKADAI_HINAGATA",
                        primaryKey, keyValue);

        // �t�@�C�����݃`�F�b�N
        if ((jizenkadai == null) || (jizenkadai.length == 0)) {
            request.setAttribute("warningID", "WCC271");
            throw new PCY_WarningException("WCC271");
        }

        // �t�@�C�����
// DEL 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2) START
//        request.setAttribute("H080_FileName",
//        		URLEncoder.encode(PZZ010_CharacterUtil.normalizedStr(jizenkadaiBean.getJizenkadaiFilename()), "UTF-8"));
// DEL 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2) END
// ADD 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2) START
        String filename = PZZ010_CharacterUtil.normalizedStr(jizenkadaiBean.getJizenkadaiFilename()).replaceAll(" ", "-");
        request.setAttribute("H080_FileName",URLEncoder.encode(filename, "UTF-8"));
// ADD 2018/04/04 COMTURE phase5-LN-OVS-Ph2_CT_009 (Ph.2-2) END
        request.setAttribute("H081_ContentType", jizenkadaiBean.getJizenkadaiContentType());
        request.setAttribute("STREAM", new ByteArrayInputStream(jizenkadai));

        // ���\�b�h�g���[�X�o��
        Log.method(loginuser.getSimeiNo(), "OUT", "");

        return this.getForwardPath();
    }
}
