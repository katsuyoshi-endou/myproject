/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.learning.base.valuebean.PCY_KanrenKyoikuKamokuBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PCY_KanrenKyoikuKamokuEJBBean�N���X �@�\�����F �֘A����Ȗڃ}�X�^�ւ̑�����s���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="PCY_KanrenKyoikuKamokuEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_KanrenKyoikuKamokuEJBBean implements SessionBean {
	private SessionContext context = null;

	/**
	 * �֘A����Ȗڃ}�X�^���ȖڃR�[�h�Ō������ē��錋�ʂ�Ԃ��܂��B
	 * @param kamokuCode �ȖڃR�[�h
	 * @param loginuser ���O�C�����[�U
	 * @return ��������
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_KanrenKyoikuKamokuBean[] doSelectByKamokuCode(final String kamokuCode, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final List kanrenList = new ArrayList();
			final String sql = "SELECT KAMOKU.KAMOKU_GROUP AS KAMOKU_KAMOKU_GROUP, " + PCY_KanrenKyoikuKamokuBean.getColumns("KANREN") + " FROM " + HcdbDef.L01_TBL + " KAMOKU, "
					+ HcdbDef.p_kanren_kyoikuTbl + " KANREN" + " WHERE KANREN.KAMOKU_CODE=?" + " AND KAMOKU.KAMOKU_CODE = KANREN.KAMOKU_CODE " + " ORDER BY KANREN.SYOKU_CODE, "
					+ " KANREN.SENMON_CODE, " + " KANREN.LEVEL_CODE," + " KANREN.SKILL_CODE";

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �������s
			ps = con.prepareStatement(sql);
			ps.setString(1, kamokuCode);

			rs = ps.executeQuery();

			while (rs.next()) {
				final PCY_KanrenKyoikuKamokuBean kanren = new PCY_KanrenKyoikuKamokuBean(rs, "KANREN");
				kanren.setKamokuGroupCode(rs.getString("KAMOKU_KAMOKU_GROUP"));
				kanrenList.add(kanren);
			}

			final PCY_KanrenKyoikuKamokuBean[] ret = new PCY_KanrenKyoikuKamokuBean[kanrenList.size()];
			kanrenList.toArray(ret);

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return ret;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * �֘A����Ȗڃ}�X�^���쐬���܂��B
	 * @param kanrenBeans �쐬���e
	 * @param loginuser ���O�C�����[�U
	 * @return �쐬����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doInsert(final PCY_KanrenKyoikuKamokuBean[] kanrenBeans, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final String sql = "INSERT INTO " + HcdbDef.p_kanren_kyoikuTbl + " (" + " SYOKU_CODE," + " SENMON_CODE," + " SKILL_CODE," + " LEVEL_CODE," + " KYOIKU_KUBUN_CODE," + " KAMOKU_CODE,"
					+ " SUISYO_KUBUN," + " SYOKUBA_FLG," + " SOSIKI_CODE," + " TOUROKUBI," + " TOUROKUJIKOKU," + " TOUROKUSYA," + " KOUSINBI," + " KOUSINJIKOKU," + " KOUSINSYA"
					+ " ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, " + "?, ?, ?, ?, ?)";

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// SQL�ݒ�
			ps = con.prepareStatement(sql);

			// �����Ώۂ̊֘A�Ȗڐ��������[�v���ď���
			int count = 0;
			for (int i = 0; i < kanrenBeans.length; i++) {
				// �p�����[�^�ݒ�
				ps.setString(1, kanrenBeans[i].getSyokusyuCode());
				ps.setString(2, kanrenBeans[i].getSenmonCode());
				ps.setString(3, kanrenBeans[i].getSkillCode());
				if (kanrenBeans[i].getLevelCode() != null) {
					ps.setString(4, Integer.toString(Integer.parseInt(kanrenBeans[i].getLevelCode()) - 1));
				} else {
					ps.setString(4, kanrenBeans[i].getLevelCode());
				}
				ps.setString(5, kanrenBeans[i].getKyoikuKubunCode());
				ps.setString(6, kanrenBeans[i].getKamokuCode());
				ps.setString(7, kanrenBeans[i].getSuisyoKubun());
				ps.setString(8, kanrenBeans[i].getSyokubaTeigiFlg());
				ps.setString(9, kanrenBeans[i].getSosikiCode());
				ps.setString(10, PZZ010_CharacterUtil.GetDay());
				ps.setString(11, PZZ010_CharacterUtil.GetTime());
				ps.setString(12, loginuser.getSimeiNo());
				ps.setString(13, "        ");
				ps.setString(14, "      ");
				ps.setString(15, "          ");
				// SQL���s
				count += ps.executeUpdate();
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * �ȖڃR�[�h���L�[�Ƃ��Ċ֘A����Ȗڃ}�X�^���폜���܂��B
	 * @param kamokuCode �폜�ΏۂƂ���ȖڃR�[�h
	 * @param loginuser ���O�C�����[�U
	 * @return �폜����
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doDeleteByKamokuCode(final String kamokuCode, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			// SQL�쐬
			final String sql = "DELETE FROM " + HcdbDef.p_kanren_kyoikuTbl + " WHERE KAMOKU_CODE=?";

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �폜���s
			ps = con.prepareStatement(sql);
			ps.setString(1, kamokuCode);

			final int count = ps.executeUpdate();

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return count;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * �֘A����Ȗڃ}�X�^���������ē��錋�ʂ�Ԃ��܂��B
	 * @param loginuser ���O�C�����[�U
	 * @return ��������
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_KanrenKyoikuKamokuBean[] doSelect(final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final List kanrenList = new ArrayList();
			final String sql = "SELECT " + PCY_KanrenKyoikuKamokuBean.getColumns("KANREN") + " FROM " + HcdbDef.p_kanren_kyoikuTbl + " KANREN " + " ORDER BY " + " KANREN.KAMOKU_CODE ";

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �������s
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();

			while (rs.next()) {
				final PCY_KanrenKyoikuKamokuBean kanren = new PCY_KanrenKyoikuKamokuBean(rs, "KANREN");
				kanrenList.add(kanren);
			}

			final PCY_KanrenKyoikuKamokuBean[] ret = new PCY_KanrenKyoikuKamokuBean[kanrenList.size()];
			kanrenList.toArray(ret);

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return ret;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} finally {
			// DB�ڑ�close
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException {
	}

	/**
	 * �������Ȃ��B
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException {
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException {
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException {
	}

	/**
	 * SessionContext�����擾����B
	 * @return SessionContext���
	 */
	public SessionContext getSessionContext() {
		return this.context;
	}

	/**
	 * EJB�R���e�i���Ǘ�����SessionContext����SessionBean�ɓn���BSessionBean�̍쐬���ɌĂяo�����B
	 * @param context SessionContext���
	 * @exception RemoteException
	 */
	public void setSessionContext(final SessionContext context) throws RemoteException {
		this.context = context;
	}
}
