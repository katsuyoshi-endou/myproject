/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY132_TaisyosyaSetteiServlet �N���X �@�\�����F �Ώێ҂̒ǉ����s���܂��B
 * 
 * </PRE>
 */
public class PCY132_TaisyosyaSetteiServlet extends PCY010_ControllerServlet {
	/**
	 * �Ώێ҂̒ǉ����s���܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		final HttpSession session = request.getSession();

		final PCY_TaisyosyaBean[] taisyosyaBeans = (PCY_TaisyosyaBean[]) session.getAttribute("taisyosyaBeans");

		final HashMap taisyosyaMap = new HashMap();

		for (int i = 0; i < taisyosyaBeans.length; i++) {
			taisyosyaMap.put(taisyosyaBeans[i].getSimeiNo(), taisyosyaBeans[i]);
		}

		final int length = Integer.parseInt(request.getParameter("count"));

		final ArrayList simei_no_list = new ArrayList();
		final HashMap taisyokubunMap = new HashMap();

		for (int i = 0; i < length; i++) {
			final String taisyoKubun = request.getParameter("taisyo_kubun_" + i);

			if (!taisyoKubun.equals("9")) {
				final String simei_no = request.getParameter("simei_no_" + i);
				simei_no_list.add(simei_no);
				taisyokubunMap.put(simei_no, taisyoKubun);
			}
		}

		/* �ꗗ�ɕ\������Ă���p�[�\�i�������擾 */
		final PCY_PersonalEJBHome home = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
		final PCY_PersonalEJB ejb = home.create();
		final PCY_PersonalBean[] personalBeans = ejb.getPersonalInfo((String[]) simei_no_list.toArray(new String[0]), loginuser);

		/* �Ώۋ敪�����擾���A�I������Ă�����̂��Z�b�g����B���ɑI���ς݂̂��̂�����΁A�㏑������B */
		for (int i = 0; i < personalBeans.length; i++) {
			final PCY_TaisyosyaBean taisyosyaBean = new PCY_TaisyosyaBean();
			taisyosyaBean.setPersonalBean(personalBeans[i]);
			taisyosyaBean.setTaisyoKubun((String) taisyokubunMap.get(personalBeans[i].getSimeiNo()));
			taisyosyaMap.put(personalBeans[i].getSimeiNo(), taisyosyaBean);
		}

		/* HashMap����z��ɕϊ����� */
		final PCY_TaisyosyaBean[] ret = new PCY_TaisyosyaBean[taisyosyaMap.size()];
		int j = 0;

		for (final Iterator ite = taisyosyaMap.keySet().iterator(); ite.hasNext(); j++) {
			final Object key = ite.next();
			ret[j] = (PCY_TaisyosyaBean) taisyosyaMap.get(key);
		}

		session.setAttribute("taisyosyaBeans", ret);

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
