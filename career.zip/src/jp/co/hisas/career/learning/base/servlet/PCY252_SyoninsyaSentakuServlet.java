/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_PersonalEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_SyoninsyaBean;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;

/**
 * <PRE>
 * 
 * �N���X���F PCY250_SyoninsyaKensakuServlet �N���X �@�\�����F ���O�C�����[�U�̏��F�Ҍ������s���B
 * 
 * </PRE>
 */
public class PCY252_SyoninsyaSentakuServlet extends PCY010_ControllerServlet {

	/**
	 * ���O�C�����[�U�̏��F�Ҍ������s�Ȃ��܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean)
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {

		final PCY_SyoninsyaBean syoninsyaBean = new PCY_SyoninsyaBean(request);
		request.setAttribute("syoninsyaBean", syoninsyaBean);
		final String syoninsya = request.getParameter("simei_no");
		final String[] simeiNo = new String[1];
		simeiNo[0] = syoninsya;
		/* ���\�b�h�g���[�X�E�p�t�H�[�}���X�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		final PCY_PersonalEJBHome home = (PCY_PersonalEJBHome) EJBHomeFactory.getInstance().lookup(PCY_PersonalEJBHome.class);
		final PCY_PersonalEJB ejb = home.create();
		Log.transaction(loginuser.getSimeiNo(), true, "");
		final PCY_PersonalBean[] personalBeans = ejb.getPersonalInfo(simeiNo, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		request.setAttribute("personalBeans", personalBeans);
		try {
			OutLogBean.sousaKojinJohoLog("VCC371", loginuser.getSimeiNo(), syoninsya, null);
		} catch (final Exception e) {
		}
		/* ���\�b�h�g���[�X�E�p�t�H�[�}���X�g���[�X�o�� */
		Log.performance(loginuser.getSimeiNo(), false, "");
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}

}