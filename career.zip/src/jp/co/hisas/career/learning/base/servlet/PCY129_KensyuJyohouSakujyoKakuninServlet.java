/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.ejb.PCY_KensyuRirekiEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_KensyuRirekiEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_KensyuRirekiBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F ���C���폜�m�F�T�[�u���b�g�N���X �@�\�����F ���C���i�����j�̌������s���܂��B
 * 
 * </PRE>
 */
public class PCY129_KensyuJyohouSakujyoKakuninServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		final String[] key = request.getParameterValues("jikosinkoku");
		final PCY_KensyuRirekiBean[] rirekiBeans = new PCY_KensyuRirekiBean[key.length];

		for (int i = 0; i < key.length; i++) {
			rirekiBeans[i] = new PCY_KensyuRirekiBean();

			final StringTokenizer st = new StringTokenizer(key[i], ",");
			rirekiBeans[i].setSeqNo(st.nextToken());
			rirekiBeans[i].setKousinbi(st.nextToken());
			rirekiBeans[i].setKousinjikoku(st.nextToken());
			rirekiBeans[i].setSimeiNo(loginuser.getSimeiNo());
		}
		// EJB�擾
		final PCY_KensyuRirekiEJBHome home = (PCY_KensyuRirekiEJBHome) EJBHomeFactory.getInstance().lookup(PCY_KensyuRirekiEJBHome.class);
		final PCY_KensyuRirekiEJB ejb = home.create();

		final PCY_KensyuRirekiBean[] ret = ejb.getList(rirekiBeans, loginuser);
		request.getSession().setAttribute("rirekiBeans", ret);

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();
	}
}
