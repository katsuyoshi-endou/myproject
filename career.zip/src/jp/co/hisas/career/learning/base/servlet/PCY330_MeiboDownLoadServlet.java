/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Writer;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lowagie.text.DocumentException;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.VelocityHelper;
import jp.co.hisas.career.learning.base.bean.PCY_CodeBean;
import jp.co.hisas.career.learning.base.bean.PCY_KensyuKanriJohoBean;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_ClassEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_MousikomiJyokyoEJBHome;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_TaisyoEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBeanForDL;
import jp.co.hisas.career.learning.base.valuebean.PCY_KamokuBeanForDL;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_SosikiBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.log.bean.OutLogBean;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �T�v�F �����CVS�쐬���s���B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PCY330_MeiboDownLoadServlet extends PCY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			PCY_WarningException, IOException, DocumentException, Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		try {

			final HttpSession session = request.getSession(false);
			final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");

			/* �g�D�}�b�v�擾 */
			final Map sosikiMap = PCY_CodeBean.getInstance().getCodeMap(PCY_CodeBean.SOSIKI);

			// EJBHome�Ǘ��N���X�̎擾
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();

			// �N���X���
			final PCY_ClassEJBHome classHome = (PCY_ClassEJBHome) fact.lookup(PCY_ClassEJBHome.class);
			final PCY_ClassEJB classEJB = classHome.create();
			final PCY_ClassBean classBean = classEJB.doSelectByPrimaryKey(new PCY_ClassBean(request), loginuser);

			final PCY_TaisyoEJBHome home_taisyo = (PCY_TaisyoEJBHome) fact.lookup(PCY_TaisyoEJBHome.class);
			final PCY_TaisyoEJB ejb_taisyo = home_taisyo.create();
			final PCY_SosikiBean[] sosikiBeens = ejb_taisyo.getSosiki(loginuser);

			// �\����
			PCY_KensyuKanriJohoBean[] taisyosyaBeans = null;
			final PCY_MousikomiJyokyoEJBHome mousikomihome = (PCY_MousikomiJyokyoEJBHome) fact.lookup(PCY_MousikomiJyokyoEJBHome.class);
			final PCY_MousikomiJyokyoEJB mousikomiejb = mousikomihome.create();
			taisyosyaBeans = mousikomiejb.getListWithClass(classBean.getKamokuBean().getKamokuCode(), classBean.getClassCode(), null, loginuser);

			// �\�[�g
			final List taisyosyaList = new ArrayList();
			for (int i = 0; i < taisyosyaBeans.length; i++) {
				taisyosyaList.add(taisyosyaBeans[i]);
			}
			PCY_KensyuKanriJohoBean[] SorttaisyosyaBeans = new PCY_KensyuKanriJohoBean[taisyosyaList.size()];
			SorttaisyosyaBeans = (PCY_KensyuKanriJohoBean[]) taisyosyaList.toArray(SorttaisyosyaBeans);
			
			/* �\�[�g���� */
			Arrays.sort(SorttaisyosyaBeans, new MeiboComparator(classBean.getSyoninKubun()));

			final Vector lines = new Vector();
			for (int i = 0; i < SorttaisyosyaBeans.length; i++) {
				final Vector columns = new Vector();

				// �_�E�����[�h�ΏۃX�e�[�^�X (��u�ҁA�񍐑ҁA����ҁA���C���A�C��)
				// ��u��(�\���󋵃X�e�[�^�X1:��t���2)
				if (SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null && SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("1")
						&& SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() != null && SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai().equals("2")
						|| SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null && SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("2")
						&& SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() == null || SorttaisyosyaBeans[i].getMousikomiBean().getStatus() != null
						&& SorttaisyosyaBeans[i].getMousikomiBean().getStatus().equals("3") && SorttaisyosyaBeans[i].getMousikomiBean().getUketsukeJyotai() == null
						|| SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei() != null && SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei().equals("0")
						|| SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei() != null && SorttaisyosyaBeans[i].getKensyurirekiBean().getSyuryoHantei().equals("1")) {

					/* �l���擾 */
					String busyoRyakusyo = "";
					for (int j = 0; j < sosikiBeens.length; j++) {
						if (sosikiBeens[j].getSosikiCode() != null && SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSosikiCode() != null) {
							if (sosikiBeens[j].getSosikiCode().trim().equals(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSosikiCode().trim())) {
								busyoRyakusyo = sosikiBeens[j].getBusyoRyakusyoMei();
								break;
							}
						}
					}
					// �\���Ώێ҂̌��E�ސE�t���O��2(�ސE)�ł���Ε\�����Ȃ�
					final String gensyokuTaisyoku = SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getGensyokuTaisyokuFlg();
					if (gensyokuTaisyoku == null || gensyokuTaisyoku.equals("2")) {
						continue;
					}
					columns.add(busyoRyakusyo);
					columns.add(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSimeiNo());
					columns.add(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getKanjiSimei());
					columns.add(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getEigoSimei());
					columns.add(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getKanaSimei());
					columns.add(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.TAISYO_KUBUN, SorttaisyosyaBeans[i].getTaisyousyaBean().getTaisyoKubun()));
					columns.add(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getMail());
					columns.add(SorttaisyosyaBeans[i].getMousikomiBean().getPersonalBean().getSosikiCode());

                    columns.add(SorttaisyosyaBeans[i].getStatusLabelForMeibo()); // �X�e�[�^�X
                    columns.add(PZZ010_CharacterUtil.ChangeYmdHm(SorttaisyosyaBeans[i].getSyoninNichijiForSort(classBean.getSyoninKubun()))); // ���F����

					lines.add(columns);
				}
			}

			// ���݂̓��t�Ǝ���
			final String dateTime = PZZ010_CharacterUtil.getDayTime();
			// �_�E�����[�h�e���v���[�g��
			final String tableName = request.getParameter("download_templete");
			String DLtableName = "";
			if (null != tableName && !tableName.equals("") && tableName.length() >= 4) {
				if (tableName.indexOf("HTML") != -1) {
					DLtableName = "Template_HTML";
				} else if (tableName.indexOf("CVS") != -1) {
					DLtableName = "Template_CVS";
				} else {
					DLtableName = "Template";
				}
			} else {
				DLtableName = "Template";
			}

			/* ���샍�O�o�� */
			final String login_no = userinfo.getLogin_no();
			final String simei_no = userinfo.getSimei_no();
			OutLogBean.sousaKojinJohoLog("LNG004", login_no, simei_no, ("�ȖڃR�[�h:" + classBean.getKamokuBean().getKamokuCode() + ",�N���X�R�[�h:" + classBean.getClassCode()));

			// �t�@�C����
			String fileName = dateTime + "_" + DLtableName;
			// �_�E�����[�h�`��
			final String downloadKeisiki = request.getParameter("download_keisiki");
			if (downloadKeisiki.equals("HTML")) {
				fileName += ".html";
			} else {
				fileName += ".csv";
			}

			/* �w�b�_�������� */
			final VelocityHelper vh = new VelocityHelper(tableName);

			vh.setParameter("classBean", new PCY_ClassBeanForDL(classBean));
			vh.setParameter("kamokuBean", new PCY_KamokuBeanForDL(classBean.getKamokuBean()));
			vh.setParameter("lines", lines);
			vh.setParameter("date", dateTime.substring(0, 4) + "/" + dateTime.substring(4, 6) + "/" + dateTime.substring(6, 8));
			vh.setParameter("time", dateTime.substring(8, 10) + ":" + dateTime.substring(10, 12));
			vh.setParameter("kaisibi", PZZ010_CharacterUtil.ChangeYmd(classBean.getKaisibi()));
			vh.setParameter("syuryobi", PZZ010_CharacterUtil.ChangeYmd(classBean.getSyuryobi()));
			vh.setParameter("kaisijikoku", PZZ010_CharacterUtil.ChangeHm(classBean.getKaisijikoku()));
			vh.setParameter("syuryojikoku", PZZ010_CharacterUtil.ChangeHm(classBean.getSyuryojikoku()));
			final Writer w = vh.getWriter();
// MOD 2018/01/26 COMTURE UTF-8�Ή� START
//			final ByteArrayInputStream bais = new ByteArrayInputStream(w.toString().getBytes());
//			final ByteArrayInputStream bais = new ByteArrayInputStream(w.toString().getBytes("UTF-8"));
			final ByteArrayInputStream bais = new ByteArrayInputStream(w.toString().getBytes("SJIS"));
// MOD 2018/01/26 COMTURE UTF-8�Ή� END
			request.setAttribute("H080_FileName", fileName);
			request.setAttribute("H081_ContentType", HcdbDef.CONTENT_TYPE);
			request.setAttribute("STREAM", bais);

			Log.performance(loginuser.getSimeiNo(), false, "");
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return this.getForwardPath();

		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RemoteException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final IOException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final DocumentException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		}
	}

	/**
	 * ���F�����i�\�[�g�p�j�A�g�D�R�[�h�A����No���L�[�Ƀ\�[�g���܂��B
	 */
    private class MeiboComparator implements Comparator<PCY_KensyuKanriJohoBean> {
        
        /** ���F�敪 */
        String syoninKubun = null;
        public MeiboComparator(String syoninKubun){
            this.syoninKubun = syoninKubun;
        }
        
        public int compare(final PCY_KensyuKanriJohoBean taisyou1,
                final PCY_KensyuKanriJohoBean taisyou2) {

			int ret = 0;

            /* ��P�\�[�g�L�[ �\�[�g�p���F���� */
            ret =
                    taisyou1.getSyoninNichijiForSort(this.syoninKubun).compareTo(
                            taisyou2.getSyoninNichijiForSort(this.syoninKubun));

            if (ret != 0) {
                return ret;
            }
			
			
			/* ��Q�\�[�g�L�[ �g�D�R�[�h */
			if (taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode() != null && taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode() != null) {
				ret = taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode().compareTo(taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode());
			} else if (taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode() == null && taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode() != null) {
				return 1;
			} else if (taisyou1.getMousikomiBean().getPersonalBean().getSosikiCode() != null && taisyou2.getMousikomiBean().getPersonalBean().getSosikiCode() == null) {
				return -1;
			}

			if (ret != 0) {
				return ret;
			}

			/* ��R�\�[�g�L�[ ����No */
			if (taisyou1.getMousikomiBean().getPersonalBean().getSimeiNo() != null && taisyou2.getMousikomiBean().getPersonalBean().getSimeiNo() != null) {
				ret = taisyou1.getMousikomiBean().getPersonalBean().getSimeiNo().compareTo(taisyou2.getMousikomiBean().getPersonalBean().getSimeiNo());
			} else if (taisyou1.getMousikomiBean().getPersonalBean().getSimeiNo() == null && taisyou2.getMousikomiBean().getPersonalBean().getSimeiNo() != null) {
				return 1;
			} else if (taisyou1.getMousikomiBean().getPersonalBean().getSimeiNo() != null && taisyou2.getMousikomiBean().getPersonalBean().getSimeiNo() == null) {
				return -1;
			}

			if (ret != 0) {
				return ret;
			}

			return ret;
		}
	}
}
