/*
 * All Rights Reserved. Copyright (C) 2004, Hitachi Systems & Services, Ltd.
 *
 * �v���W�F�N�g���@�F
 *   ���V�e�ACareer�i���C�Ǘ��@�\�j
 *
 * ���l�@�F
 *   �Ȃ�
 *
 * �����@�F
 *   ���t        �o�[�W����  ���O         ���e
 *   2004/04/19  01.00       ���� ����    �V�K�쐬
 *   2004/06/27              ���� ���V�@�@�e���v���[�g�C���Ή�
 *   2004/10/29              ���� ���V    �Ȗڏ��ێ��ɑΉ�
 */
package jp.co.hisas.career.learning.base.valuebean;

import java.io.Serializable;

import jp.co.hisas.career.learning.base.bean.PCY_CodeBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F PCY_ClassBeanForMail �N���X �@�\�����F ���[���@�\�p�ɃN���X����ێ�����ValueBean�ł��B
 * 
 * </PRE>
 */
public class PCY_ClassBeanForMail implements Serializable {
	private PCY_KamokuBeanForMail kamokuBeanForMail = null;

	private String classMei = null;

	private String kaisibi = null;

	private String syuryobi = null;

	private String kaisijikoku = null;

	private String syuryojikoku = null;

	private String chikuMei = null;

	private String kyosituMei = null;

	private String kousiMei = null;

	private String mousikomiKubun = null;

	private String mousikomiKubunMei = null;

	private String mousikomiKaisibi = null;

	private String mousikomiSyuryobi = null;

	private String teiin = null;

	private String houkokuKubunMei = null;

	private String syoninKubunMei = null;

	private String nissu = null;

    private final String HENKOU = (String) ReadFile.paramMapData.get("DZZ995");

	public PCY_ClassBeanForMail(final PCY_ClassBean classBean) {
		/* �Ȗڏ����Z�b�g���� */
		this.setKamokuBeanForMail(new PCY_KamokuBeanForMail(classBean.getKamokuBean()));

		/* �N���X�����Z�b�g���� */
		this.setClassMei(classBean.getClassMei());

		/* �J�n�����Z�b�g���� */
        this.setKaisibi(PZZ010_CharacterUtil.ChangeYmd(classBean.getKaisibi()));

		/* �I�������Z�b�g���� */
		this.setSyuryobi(PZZ010_CharacterUtil.ChangeYmd(classBean.getSyuryobi()));

        // �J�Ó����ύX���ꂽ�ꍇ
        if (classBean.getKaisaibiFlg().equals("1")){
        	this.setSyuryobi(this.getSyuryobi() + HENKOU);
        }

		/* �J�Î������Z�b�g���� */
		this.setKaisijikoku(PZZ010_CharacterUtil.ChangeHm(classBean.getKaisijikoku()));

		/* �I�����������Z�b�g���� */
		this.setSyuryojikoku(PZZ010_CharacterUtil.ChangeHm(classBean.getSyuryojikoku()));

		// �J�Î������ύX���ꂽ�ꍇ
		if (classBean.getKaisaijikokuFlg().equals("1")){
			this.setSyuryojikoku(PZZ010_CharacterUtil.normalizedStr(this.getSyuryojikoku()) + HENKOU);
		}

		/* �n�於���Z�b�g���� */
		this.setChikuMei(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.CHIKU, classBean.getChikuCode()));

		if (this.getChikuMei() == null) {
			this.setChikuMei(classBean.getChikuMei());
		}

		// �J�Ïꏊ���ύX���ꂽ�ꍇ
		if (classBean.getChikuMeiFlg().equals("1")) {
			this.setChikuMei(PZZ010_CharacterUtil.normalizedStr(this.getChikuMei()) + HENKOU);
		}

		/* ���������Z�b�g���� */
		this.setKyosituMei(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.KYOSITU, classBean.getKyosituCode()));

		if (this.getKyosituMei() == null) {
			this.setKyosituMei(classBean.getKyosituMei());
		}

		// �������ύX���ꂽ�ꍇ
		if (classBean.getKyosituFlg().equals("1")) {
			this.setKyosituMei(PZZ010_CharacterUtil.normalizedStr(this.getKyosituMei()) + HENKOU);
		}

		/* �u�t�����Z�b�g���� */
		this.setKousiMei(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.KOUSI, classBean.getKousiCode()));

		if (this.getKousiMei() == null) {
			this.setKousiMei(classBean.getKousiMei());
		}

		/* �\���敪���Z�b�g���� */
		this.setMousikomiKubun(classBean.getMousikomiKubun());

		/* �\���敪�����Z�b�g���� */
		this.setMousikomiKubunMei(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.MOUSIKOMI_KUBUN, classBean.getMousikomiKubun()));

		/* �\���J�n�����Z�b�g���� */
		this.setMousikomiKaisibi(PZZ010_CharacterUtil.ChangeYmd(classBean.getMousikomiKaisibi()));

		/* �\���I�������Z�b�g���� */
		this.setMousikomiSyuryobi(PZZ010_CharacterUtil.ChangeYmd(classBean.getMousikomiSyuryobi()));

		/* ������Z�b�g���� */
		this.setTeiin(classBean.getTeiin() != null ? classBean.getTeiin().toString() : "");

		/* �񍐋敪�����Z�b�g���� */
		this.setHoukokuKubunMei(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.HOUKOKU_KUBUN, classBean.getHoukokuKubun()));

		/* ���F�敪�����Z�b�g���� */
		this.setSyoninKubunMei(PCY_CodeBean.getInstance().getValue(PCY_CodeBean.SYONIN_KUBUN, classBean.getSyoninKubun()));

		/* �������Z�b�g���� */
		this.setNissu(classBean.getNissuu() != null ? classBean.getNinsyoKubun().toString() : "");


	}

	public static String getClassTitle() {
		return (String) ReadFile.paramMapData.get("DZZ077");
	}

	public static String getKaisaibiTitle() {
		return (String) ReadFile.paramMapData.get("DZZ303");
	}

	public static String getKaisaijikokuTitle() {
		return (String) ReadFile.paramMapData.get("DZZ305");
	}

	public static String getKaisaibasyoTitle() {
		return (String) ReadFile.paramMapData.get("DZZ312");
	}

	public static String getKyosituTitle() {
		return (String) ReadFile.paramMapData.get("DZZ313");
	}

	public static String getMousikomikubunTitle() {
		return (String) ReadFile.paramMapData.get("DZZ317");
	}

	public static String getMousikomikikanTitle() {
		return (String) ReadFile.paramMapData.get("DZZ308");
	}

	/**
	 * @return
	 */
	public String getChikuMei() {
		return this.chikuMei;
	}

	/**
	 * @return
	 */
	public String getClassMei() {
		return this.classMei;
	}

	/**
	 * @return
	 */
	public String getKaisibi() {
		return this.kaisibi;
	}

	/**
	 * @return
	 */
	public String getKaisijikoku() {
		return this.kaisijikoku;
	}

	/**
	 * @return
	 */
	public String getKousiMei() {
		return this.kousiMei;
	}

	/**
	 * @return
	 */
	public String getKyosituMei() {
		return this.kyosituMei;
	}

	/**
	 * @return
	 */
	public String getMousikomiKaisibi() {
		return this.mousikomiKaisibi;
	}

	/**
	 * @return
	 */
	public String getMousikomiKubun() {
		return this.mousikomiKubun;
	}

	/**
	 * @return
	 */
	public String getMousikomiSyuryobi() {
		return this.mousikomiSyuryobi;
	}

	/**
	 * @return
	 */
	public String getSyuryobi() {
		return this.syuryobi;
	}

	/**
	 * @return
	 */
	public String getSyuryojikoku() {
		return this.syuryojikoku;
	}

	/**
	 * @return
	 */
	public String getTeiin() {
		return this.teiin;
	}

	/**
	 * @param string
	 */
	public void setChikuMei(final String string) {
		this.chikuMei = string;
	}

	/**
	 * @param string
	 */
	public void setClassMei(final String string) {
		this.classMei = string;
	}

	/**
	 * @param string
	 */
	public void setKaisibi(final String string) {
		this.kaisibi = string;
	}

	/**
	 * @param string
	 */
	public void setKaisijikoku(final String string) {
		this.kaisijikoku = string;
	}

	/**
	 * @param string
	 */
	public void setKousiMei(final String string) {
		this.kousiMei = string;
	}

	/**
	 * @param string
	 */
	public void setKyosituMei(final String string) {
		this.kyosituMei = string;
	}

	/**
	 * @param string
	 */
	public void setMousikomiKaisibi(final String string) {
		this.mousikomiKaisibi = string;
	}

	/**
	 * @param string
	 */
	public void setMousikomiKubun(final String string) {
		this.mousikomiKubun = string;
	}

	/**
	 * @param string
	 */
	public void setMousikomiSyuryobi(final String string) {
		this.mousikomiSyuryobi = string;
	}

	/**
	 * @param string
	 */
	public void setSyuryobi(final String string) {
		this.syuryobi = string;
	}

	/**
	 * @param string
	 */
	public void setSyuryojikoku(final String string) {
		this.syuryojikoku = string;
	}

	/**
	 * @param string
	 */
	public void setTeiin(final String string) {
		this.teiin = string;
	}

	/**
	 * @return
	 */
	public String getHoukokuKubunMei() {
		return this.houkokuKubunMei;
	}

	/**
	 * @param string
	 */
	public void setHoukokuKubunMei(final String string) {
		this.houkokuKubunMei = string;
	}

	/**
	 * @return
	 */
	public String getSyoninKubunMei() {
		return this.syoninKubunMei;
	}

	/**
	 * @param string
	 */
	public void setSyoninKubunMei(final String string) {
		this.syoninKubunMei = string;
	}

	/**
	 * @return
	 */
	public String getMousikomiKubunMei() {
		return this.mousikomiKubunMei;
	}

	/**
	 * @param string
	 */
	public void setMousikomiKubunMei(final String string) {
		this.mousikomiKubunMei = string;
	}

	/**
	 * �Ȗڏ��ForMail���擾���܂��B
	 * @return
	 */
	public PCY_KamokuBeanForMail getKamokuBeanForMail() {
		return this.kamokuBeanForMail;
	}

	/**
	 * �Ȗڏ��ForMail��ݒ肵�܂��B
	 * @param mail
	 */
	public void setKamokuBeanForMail(final PCY_KamokuBeanForMail mail) {
		this.kamokuBeanForMail = mail;
	}

	/**
	 * �������擾���܂��B
	 * @return
	 */
	public String getNissu() {
		return this.nissu;
	}

	/**
	 * ������ݒ肵�܂��B
	 * @param string
	 */
	public void setNissu(final String string) {
		this.nissu = string;
	}
}
