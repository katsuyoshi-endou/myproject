/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.servlet;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.learning.base.ejb.PCY_UserDefaultEJB;
import jp.co.hisas.career.learning.base.ejb.PCY_UserDefaultEJBHome;
import jp.co.hisas.career.learning.base.valuebean.PCY_DefaultBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PCY080_KamokuNyuryokuServlet �N���X �@�\�����F �Ȗړ��̓��[�U�[�f�t�H���g�l���擾���܂��B
 * 
 * </PRE>
 */
public class PCY080_KamokuNyuryokuServlet extends PCY010_ControllerServlet {
	/**
	 * ���N�G�X�g����擾���A�f�t�H���g�ݒ���X�V���܂��B
	 * @see jp.co.hisas.career.learning.base.servlet.PCY010_ControllerServlet#execute( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean )
	 */
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PCY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException,
			SQLException, Exception {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		final PCY_DefaultBean defaultBean = new PCY_DefaultBean(request);

		final PCY_UserDefaultEJBHome home = (PCY_UserDefaultEJBHome) EJBHomeFactory.getInstance().lookup(PCY_UserDefaultEJBHome.class);
		final PCY_UserDefaultEJB ejb = home.create();

		try {

			Log.transaction(loginuser.getSimeiNo(), true, "");

			// ���݂̃��O�C�����[�U�[�̏����擾
			final PCY_DefaultBean getdefaultBean = ejb.doGetData(loginuser.getSimeiNo(), "VCC080", loginuser);
			request.setAttribute("defaultBean", getdefaultBean);

			Log.transaction(loginuser.getSimeiNo(), false, "");

		} catch (final Exception e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		}

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return this.getForwardPath();
	}
}
