/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.learning.base.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.learning.base.PCY_WarningException;
import jp.co.hisas.career.learning.base.valuebean.PCY_MansekiKouryoBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PCY_MansekiKouryoEJBBean�N���X �@�\�����F ���ȍl���Ȗڃ}�X�^�e�[�u������ꗗ���擾���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="PCY_MansekiKouryoEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PCY_MansekiKouryoEJBBean implements SessionBean {
	private SessionContext context = null;
	
	/**
	 * ZZ_���ȍl���Ȗڃ}�X�^�e�[�u���f�[�^�擾���s���B
	 * @param loginuser ���O�C�����[�U
	 * @return ���ȍl���Ȗڃ}�X�^�f�[�^
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public PCY_MansekiKouryoBean[] doSelect(final PCY_MansekiKouryoBean mansekiKouryo, final PCY_PersonalBean loginuser) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");

			final Collection ret = new ArrayList();

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// SQL�쐬
			final StringBuffer sql = new StringBuffer();
			sql.append("SELECT ");
			sql.append(PCY_MansekiKouryoBean.getColumns());
			sql.append(" FROM ");
			sql.append(HcdbDef.ZZ_MANSEKI_KOURYO_TBL);
			sql.append(" WHERE ");
			sql.append(" KAMOKU_CODE = ? ");

			ps = con.prepareStatement(sql.toString());
			Log.debug(sql.toString());

			ps.setString(1, mansekiKouryo.getKamokuCode());

			Log.debug("1:" + mansekiKouryo.getKamokuCode());

			rs = ps.executeQuery();

			while (rs.next()) {
				ret.add(new PCY_MansekiKouryoBean(rs));
			}

			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return (PCY_MansekiKouryoBean[]) ret.toArray(new PCY_MansekiKouryoBean[0]);

		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, rs);
		}
	}

	
	
	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}

}
