package jp.co.hisas.career.common.servlet;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.code.bean.CodeBean;
import jp.co.hisas.career.base.sosiki.bean.SosikiBean;
import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.base.yakusyoku.bean.YakusyokuBean;
import jp.co.hisas.career.learning.base.bean.PCY_AccessLogBean;
import jp.co.hisas.career.personal.accesslog.bean.AccesslogBean;
import jp.co.hisas.career.plan.base.bean.PBY_AccessLogBean;
import jp.co.hisas.career.util.log.Log;

public class ViaGateServlet extends HttpServlet {
	
	private ServletContext ctx = null;
	boolean isAppAuth;
	
	private static volatile boolean codeflg = false;

	/** �g�D�}�X�^���ǂݍ��݃t���O */
	private static volatile boolean sosikiflg = false;

	/** ��E�}�X�^���ǂݍ��݃t���O */
	private static volatile boolean yakusyokuflg = false;

	public void init( final ServletConfig config ) {
		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
	}
	
	public void service( final HttpServletRequest req, final HttpServletResponse res ) throws ServletException, IOException {
		
		Log.method( "", "IN", "" );
		Log.performance( "", true, "" );
		
		String guid = null;
		try {
			// �F�؂��ʂ����Ɖ��肵��
			HttpSession session = req.getSession( true );
			
			// ���N�G�X�g
			req.setAttribute( "LDAP_ERR_MSG", null);
			
			
			// �Z�b�V����
			session.setAttribute( "DB_ERR_MSG", null );
			
			UserInfoBean bean = (UserInfoBean) session.getAttribute("userinfo");
			if (bean == null) {
				bean = new UserInfoBean();
			}
			bean.setLogin_no("j2170023");
			bean.kokai_teigi("");
			if (!ViaGateServlet.codeflg) {
				/* �R�[�h�擾 */
				ViaGateServlet.codeflg = CodeBean.searchcode("j2170023");

				/* ���J��`�R�[�h���擾 */
				CodeBean.kokai_teigi("");
			}
			/* �g�D�}�X�^���擾 */
			if (!ViaGateServlet.sosikiflg) {
				ViaGateServlet.sosikiflg = SosikiBean.searchsosiki("j2170023");
			}

			/* ��E�}�X�^���擾 */
			if (!ViaGateServlet.yakusyokuflg) {
				ViaGateServlet.yakusyokuflg = YakusyokuBean.searchyakusyoku(null);
			}

			final String flg = "0";
			bean.setFlg2("0");
			bean.setLogin_no("j2170023");
			bean.searchemp("j2170023", "", flg);
			
			session.setAttribute("userinfo", bean);
			

			PCY_AccessLogBean learningAccessLogBean = (PCY_AccessLogBean) session.getAttribute("learning.accesslog");
			final DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
			final String loginTime = df.format(new java.util.Date(Calendar.getInstance().getTimeInMillis()));
			final String sosiki_code = bean.getSosiki_code().trim();
			
			learningAccessLogBean = new PCY_AccessLogBean();
			learningAccessLogBean.setSessionId(session.getId());
			learningAccessLogBean.setLoginJikoku(loginTime);
			learningAccessLogBean.setSimeiNo("j2170023");
			learningAccessLogBean.setSosikiCode(sosiki_code);
			
			AccesslogBean accesslogbean = (AccesslogBean) session.getAttribute("accesslog");
			accesslogbean = new AccesslogBean();

			// �v��n�A�N�Z�X���Obean���擾
			PBY_AccessLogBean planAccessLogBean = (PBY_AccessLogBean) session.getAttribute("planAccessLog");
			planAccessLogBean = new PBY_AccessLogBean(session.getId(), loginTime, "j2170023", sosiki_code);

			session.setAttribute("accesslog", accesslogbean);
			session.setAttribute("planAccessLog", planAccessLogBean);
			session.setAttribute("learning.accesslog", learningAccessLogBean);
			
			req.setAttribute("login_kakunin", "0");
			req.setAttribute("modeFlg", "0");
			
			this.ctx.getRequestDispatcher("/servlet/LoginMenuServlet").forward(req, res);
			
//			Tray tray = new Tray( req, res, false );
//			Line line = new Line( req, res );
//			line.resetSession();
//			
//			// ���O�C���O����
//			LoginLogic.prepareLoginBefore( tray, line, "Login" );
//			
//			/* SSO�F�� */
//			Map<String, String> args = LoginLogic.authGateSecret( line );
//			
//			// ���O�C���㏈��
//			prepareLoginAfter( tray, args );
//			
//			/* �z�[���Ƀ��_�C���N�g */
//			res.sendRedirect( "/" + AppDef.CTX_ROOT + AppDef.HOME_URL );
			
//			Log.performance( guid, false, "" );
//			Log.method( guid, "OUT", "" );
			
//		} catch (final CareerException e) {
//			Log.error( guid, e );
//			/* �F�؎��s */
//			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(req, res);
			
		} catch (final Exception e) {
			Log.error( guid, e );
			/* �F�؏����ŗ\�����ʃG���[���� */
//			String label = CommonLabel.getLabel( "FW_MSG_AUTH_UNEXPECTED_ERR" );
//			String msg = SU.isNotBlank( label ) ? label : "�F�؏����ŗ\�����ʃG���[���������܂����B";
//			forwardToErrorPage( req, res, e, msg );
			this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(req, res);
		}
	}
	
//	private void prepareLoginAfter( Tray tray, Map<String, String> args ) throws CareerException {
//		
//		// Pass the parameters via request attributes.
//		tray.request.setAttribute( "p", args.get( "party" ) );
//		tray.request.setAttribute( "lang", args.get( "lang" ) );
//		
//		LoginLogic.prepareLoginAfter( tray, args.get( "guid" ) );
//	}
//	
//	private void forwardToErrorPage( HttpServletRequest req, HttpServletResponse res, Exception e, String msg ) throws ServletException, IOException {
//		req.setAttribute( "DB_ERR_MSG", msg );
//		req.setAttribute( "Exception", e );
//		String nextPage = "";
//		if (isAppAuth) {
//			nextPage = "/view/auth/VYA_AppLogin.jsp";
//		}
//		else {
//			nextPage = "/view/error.jsp";
//		}
//		this.ctx.getRequestDispatcher( nextPage ).forward( req, res );
//	}
	
}
