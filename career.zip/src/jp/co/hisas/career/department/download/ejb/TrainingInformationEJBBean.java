/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.download.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.download.valuebean.TrainingInformationBean;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * <PRE>
 * 
 * �N���X���F TrainingInformationEJBBean�N���X �@�\�����F �e��Ώۃ}�X�^����ꗗ���擾���܂��B
 * 
 * </PRE>
 * 
 * @ejb.bean name="TrainingInformationEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class TrainingInformationEJBBean implements SessionBean {
	private SessionContext my_ssc = null;

	private static final String L51_HANTEI_0 = "���C��";

	private static final String L51_HANTEI_1 = "�C��";

	private static final String L51_HANTEI_2 = "�F��";

	private static final String L15_STATUS_0 = "���F��";

	private static final String L15_STATUS_2 = "�񍐑�";

	private static final String L15_STATUS_3 = "�����";

	private static final String L15_UKESUKE_JYOTAI_0 = "��t��";

	private static final String L15_UKESUKE_JYOTAI_1 = "��t������";

	private static final String L15_UKESUKE_JYOTAI_2 = "��u�\��";

	private static final String L15_UKESUKE_JYOTAI_3 = "�����t��";

	private static final String L15_UKESUKE_JYOTAI_4 = "���������";

	private static final String FUNCTION_CODE = "VEC101";

	/**
	 * ���O�C���҂̊K�w���擾����
	 * @param simei_no �����ԍ�
	 * @param sosikiCode �����R�[�h
	 * @return ���O�C���҂̊K�w
	 * @exception SQLException SQL�G���[�����������ꍇ
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public String getKaisou(final String loginNo, final String sosikiCode) throws NamingException {
		Log.method(loginNo, "IN", "");
		/* DB�ڑ��I�u�W�F�N�g�̊l�� */
		Connection cn = null;
		/* SQL�𑗂邽�߂�PreparedStatement�I�u�W�F�N�g */
		PreparedStatement pre = null;
		/* �f�[�^�x�[�X�̌��ʃZ�b�g���i�[����ResultSet�I�u�W�F�N�g */
		ResultSet rs = null;

		try {
			// DB�ڑ��I�u�W�F�N�g�̊l��
			cn = PZZ040_SQLUtility.getConnection(loginNo);
			final String sql = "SELECT kaisou FROM " + HcdbDef.sosikiTbl + " WHERE sosiki_code = ?";
			pre = cn.prepareStatement(sql);
			pre.setString(1, sosikiCode);
			rs = pre.executeQuery();
			String kaisou = "";
			if (rs.next()) {
				kaisou = rs.getString(1);
			}
			Log.method(loginNo, "OUT", "");
			return kaisou;
		} catch (final SQLException e) {
			Log.error("", e);
			throw new EJBException(e);
		} catch (final NamingException e) {
			Log.error("", e);
			throw new EJBException(e);
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, cn, pre, rs);
		}
	}

	/**
	 * �������̖�
	 * @param simei_no �����ԍ�
	 * @param kengenCode �����R�[�h
	 * @param flag ���C�Ǘ��҃t���O
	 * @param sosikiCode ���C�Ǘ��҃t���O
	 * @return �������̖�
	 * @exception SQLException SQL�G���[�����������ꍇ
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public String[][] getBusyoRyakusyoMei(final PEY_PersonalBean loginuser) throws NamingException {
		final String loginNo = loginuser.getSimeiNo();

		Log.method(loginNo, "IN", "");

		/* DB�ڑ��I�u�W�F�N�g�̊l�� */
		Connection cn = null;
		/* SQL�𑗂邽�߂�PreparedStatement�I�u�W�F�N�g */
		PreparedStatement ps = null;
		PreparedStatement psCount = null;
		/* �f�[�^�x�[�X�̌��ʃZ�b�g���i�[����ResultSet�I�u�W�F�N�g */
		ResultSet rs = null;
		ResultSet rsCount = null;

		final String[][] load = new String[3][];
		String sql = null;

		final String s1 = (String) ReadFile.fileMapData.get("SOSIKI_LIST_KAISO1");
		final String s2 = (String) ReadFile.fileMapData.get("SOSIKI_LIST_KAISO2");
		final String s3 = (String) ReadFile.fileMapData.get("SOSIKI_LIST_KAISO3");
		final String s4 = (String) ReadFile.fileMapData.get("SOSIKI_LIST_KAISO4");
		final String min = (String) ReadFile.fileMapData.get("SOSIKI_LIST_KAISO_MIN2");
		final String max = (String) ReadFile.fileMapData.get("SOSIKI_LIST_KAISO_MAX2");

		try {
			final int min_int = Integer.parseInt(min);
			final int max_int = Integer.parseInt(max);
		} catch (final NumberFormatException nfe) {
			Log.error(loginNo, nfe);
			throw nfe;
		}
		try {
			final String kengenCode = loginuser.getKengenCode();
			final String kenpoFlag = loginuser.getKenpoMainteFlg();
			// DB�ڑ��I�u�W�F�N�g�̊l��
			cn = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");
			if (!"1".equals(kenpoFlag) && !"0".equals(kengenCode)) {
				sql = "SELECT * FROM T19_SOSIKI_TBL WHERE sosiki_code = ? ";
				ps = cn.prepareStatement(sql);
				ps.setString(1, loginuser.getSosikiCode());
				rs = ps.executeQuery();
				if (!rs.next()) {
					return load;
				}
			}
			PZZ040_SQLUtility.closeConnection(loginNo, null, ps, rs);

			String sqlCount = "SELECT COUNT(*) FROM " + HcdbDef.sosikiTbl;
			sql = "SELECT sosiki_code, busyo_ryakusyo_mei, kaisou FROM " + HcdbDef.sosikiTbl;
			String syozokuCode = null;
			if (!"1".equals(kenpoFlag) && !"0".equals(kengenCode)) {
				if (s1 != null && kengenCode.equals(s1)) {
					syozokuCode = loginuser.getSyozokuCode1();
					Log.debug("syozoku_code1 = " + syozokuCode);
				} else if (s2 != null && kengenCode.equals(s2)) {
					syozokuCode = loginuser.getSyozokuCode2();
					Log.debug("syozoku_code2 = " + syozokuCode);
				} else if (s3 != null && kengenCode.equals(s3)) {
					Log.debug("syozoku_code2 = " + syozokuCode);
					syozokuCode = loginuser.getSyozokuCode3();
				} else if (s4 != null && Integer.parseInt(kengenCode) >= Integer.parseInt(s4)) {
					Log.debug("syozoku_code4 = " + syozokuCode);
					syozokuCode = loginuser.getSyozokuCode4();
				}
				sql = sql + " START WITH  sosiki_code = ? " + "CONNECT BY PRIOR sosiki_code = joui_sosiki_code " + "AND kaisou BETWEEN ? AND ?";
				sqlCount = sqlCount + " START WITH  sosiki_code  = ? " + "CONNECT BY PRIOR sosiki_code = joui_sosiki_code " + "AND kaisou BETWEEN ? AND ?";
			} else {
				sql = sql + " WHERE kaisou BETWEEN ? AND ? ";
				sqlCount = sqlCount + " WHERE kaisou BETWEEN ? AND ? ";
			}

			sql = sql + " ORDER BY sosiki_code";
			psCount = cn.prepareStatement(sqlCount);

			ps = cn.prepareStatement(sql);
			if (!"1".equals(kenpoFlag) && !"0".equals(kengenCode)) {
				ps.setString(1, syozokuCode);
				ps.setString(2, min);
				ps.setString(3, max);
				psCount.setString(1, syozokuCode);
				psCount.setString(2, min);
				psCount.setString(3, max);
			} else {
				ps.setString(1, min);
				ps.setString(2, max);
				psCount.setString(1, min);
				psCount.setString(2, max);
			}
			rsCount = psCount.executeQuery();
			rsCount.next();
			final int count = rsCount.getInt(1);
			if (count == 0) {
				return load;
			}
			load[0] = new String[count];
			load[1] = new String[count];
			load[2] = new String[count];
			rs = ps.executeQuery();
			int i = 0;
			while (rs.next()) {
				load[0][i] = rs.getString(1);
				load[1][i] = rs.getString(2);
				load[2][i] = rs.getString(3);
				i++;
			}
			Log.method(loginNo, "OUT", "");
			return load;
		} catch (final SQLException e) {
			Log.error(loginNo, e);
			throw new EJBException(e);
		} catch (final NamingException e) {
			Log.error(loginNo, e);
			throw new EJBException(e);
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, null, psCount, rsCount);
			PZZ040_SQLUtility.closeConnection(loginNo, cn, ps, rs);
		}
	}

	/**
	 * �������哝�v
	 * @param loginuser ���O�C����ID
	 * @param sosiki_code �����R�[�h
	 * @param kaisou �K�w
	 * @param kaisibi �J�n��
	 * @param syuryobi �I����
	 * @return ��������̌��C�҂̏��
	 * @exception SQLException SQL�G���[�����������ꍇ
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public Vector getCsvShozokuBumonTokei(final PEY_PersonalBean loginuser, final String sosiki_code, final String kaisou, final String kaisibi, final String syuryobi) throws NamingException,
			RemoteException {

		Log.method(loginuser.getSimeiNo(), "IN", "");
		/* DB�ڑ��I�u�W�F�N�g�̊l�� */
		Connection cn = null;
		/** SQL�𑗂邽�߂�PreparedStatement�I�u�W�F�N�g */
		PreparedStatement pre = null;
		/** �f�[�^�x�[�X�̌��ʃZ�b�g���i�[����ResultSet�I�u�W�F�N�g */
		ResultSet rs = null;

		TrainingInformationBean csvData = null;

		final Vector v_result = new Vector();

		try {
			cn = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			final String kengen_code = loginuser.getKengenCode();
			final String kenpo_flag = loginuser.getKenpoMainteFlg();
			String temp;

			if ("".equals(sosiki_code) && ("0".equals(kengen_code) || "1".equals(kenpo_flag))) {
				temp = "";
			} else {
				temp = "AND t01.syozoku_code_" + kaisou + " = ?";
			}
			final StringBuffer sql = new StringBuffer(" SELECT").append("           syozoku_code_1, ").append("           sosiki_mei_1, ").append("           syozoku_code_2, ").append(
					"           sosiki_mei_2,").append("           syozoku_code_3,").append("           sosiki_mei_3,").append("           syozoku_code_4,").append("           sosiki_mei_4,").append(
					"           syozoku_code_5,").append("           sosiki_mei_5,").append("           yakusyoku_code,").append("           yakusyoku_mei,").append("           simei_no,").append(
					"           kanji_simei,").append("           SUM (tanka) AS sum_tanka,").append("           SUM (nissuu) AS sum_nissuu, ").append(
					"           DECODE (syozoku_code_1, NULL, '0', '1') AS sort_code_1,  ").append("           DECODE (syozoku_code_2, NULL, '0', '1') AS sort_code_2,  ").append(
					"           DECODE (syozoku_code_3, NULL, '0', '1') AS sort_code_3,  ").append("           DECODE (syozoku_code_4, NULL, '0', '1') AS sort_code_4,  ").append(
					"           DECODE (syozoku_code_5, NULL, '0', '1') AS sort_code_5  ").append("FROM (SELECT    t01.syozoku_code_1,").append(
					"                t19_1.BUSYO_RYAKUSYO_MEI AS sosiki_mei_1,").append("                t01.syozoku_code_2,").append("                t19_2.BUSYO_RYAKUSYO_MEI AS sosiki_mei_2,")
					.append("                t01.syozoku_code_3,").append("                t19_3.BUSYO_RYAKUSYO_MEI AS sosiki_mei_3,").append("                t01.syozoku_code_4,").append(
							"                t19_4.BUSYO_RYAKUSYO_MEI AS sosiki_mei_4,").append("                t01.syozoku_code_5,      ").append(
							"                t19_5.BUSYO_RYAKUSYO_MEI AS sosiki_mei_5,").append("                CASE  ").append("                    WHEN a91.kinou_code = ? THEN A91.group_code ")
					.append("                    ELSE null ").append("                END as yakusyoku_code,").append("                CASE  ").append(
							"                    WHEN a91.kinou_code = ? THEN A91.group_mei ").append("                    ELSE null ").append("                END as yakusyoku_mei, ").append(
							"                t01.simei_no,").append("                substr(t01.kanji_simei,2,length(t01.kanji_simei)) AS kanji_simei,").append("                l51.tanka AS tanka,")
					.append("                l51.nissuu AS nissuu  ").append("       FROM    T01_PERSONAL_TBL t01,").append("               L51_KYOIKU_TBL l51,").append(
							"               T15_YAKUSYOKU_TBL t15,").append("               A91_SYUKEI_GROUP_TBL a91,").append("               T19_SOSIKI_TBL t19_1,").append(
							"               T19_SOSIKI_TBL t19_2,").append("               T19_SOSIKI_TBL t19_3,").append("               T19_SOSIKI_TBL t19_4,").append(
							"               T19_SOSIKI_TBL t19_5, ").append("               T19_SOSIKI_TBL t19_S ").append("    WHERE t01.gensyoku_taisyoku_flg = ? ").append(
							"           AND t01.honmu_flg = ? ").append("           AND t01.simei_no = l51.simei_no ").append(temp).append("           AND l51.syuryobi BETWEEN ? AND ? ").append(
							"           AND t01.yakusyoku_code = t15.yakusyoku_code(+) ").append("           AND t15.kaisou = a91.yakusyoku_kaisou(+) ").append(
							"           AND t01.sosiki_code = t19_S.sosiki_code ").append("           AND t01.syozoku_code_1 = t19_1.sosiki_code(+) ").append(
							"           AND t01.syozoku_code_2 = t19_2.sosiki_code(+) ").append("           AND t01.syozoku_code_3 = t19_3.sosiki_code(+) ").append(
							"           AND t01.syozoku_code_4 = t19_4.sosiki_code(+) ").append("           AND t01.syozoku_code_5 = t19_5.sosiki_code(+) ")
					.append("   UNION ALL                     ").append("       SELECT      t01.syozoku_code_1,").append("                   t19_1.BUSYO_RYAKUSYO_MEI,").append(
							"                   t01.syozoku_code_2,").append("                   t19_2.BUSYO_RYAKUSYO_MEI,").append("                   t01.syozoku_code_3,").append(
							"                   t19_3.BUSYO_RYAKUSYO_MEI,").append("                   t01.syozoku_code_4,").append("                   t19_4.BUSYO_RYAKUSYO_MEI,").append(
							"                   t01.syozoku_code_5,").append("                   t19_5.BUSYO_RYAKUSYO_MEI,").append("                CASE  ").append(
							"                    WHEN a91.kinou_code = ? THEN A91.group_code ").append("                    ELSE null ").append("                END as yakusyoku_code,").append(
							"                CASE  ").append("                    WHEN a91.kinou_code = ? THEN A91.group_mei ").append("                    ELSE null ").append(
							"                END as yakusyoku_mei, ").append("                   t01.simei_no AS simei_no,").append(
							"                   substr(t01.kanji_simei,2,length(t01.kanji_simei)) AS kanji_simei,").append("                   l02.tanka, l02.nissuu ").append( // CHG#2007/3/6 s-hiura
							"       FROM    T01_PERSONAL_TBL t01,").append("               L15_MOUSIKOMI_JYOKYO_TBL l15,").append("               T15_YAKUSYOKU_TBL t15,").append(
							"               A91_SYUKEI_GROUP_TBL a91,").append("               L01_KAMOKU_TBL l01,").append("               L02_CLASS_TBL l02,").append(
							"               T19_SOSIKI_TBL t19_1,").append("               T19_SOSIKI_TBL t19_2,").append("               T19_SOSIKI_TBL t19_3,").append(
							"               T19_SOSIKI_TBL t19_4,").append("               T19_SOSIKI_TBL t19_5, ").append("               T19_SOSIKI_TBL t19_S ").append(
							"    WHERE t01.gensyoku_taisyoku_flg = ? ").append("                AND t01.honmu_flg = ? ").append("                AND t01.simei_no = l15.simei_no ").append(
							"                AND l15.kamoku_code = l01.kamoku_code ").append("                AND l15.class_code = l02.class_code ").append(
							"                AND l15.kamoku_code = l02.kamoku_code ").append(temp).append("                AND l02.syuryobi BETWEEN ? AND ? ").append(
							"                AND t01.yakusyoku_code = t15.yakusyoku_code(+) ").append("                AND t15.kaisou = a91.yakusyoku_kaisou(+) ").append(
							"                AND t01.sosiki_code = t19_S.sosiki_code ").append("                AND t01.syozoku_code_1 = t19_1.sosiki_code(+) ").append(
							"                AND t01.syozoku_code_2 = t19_2.sosiki_code(+) ").append("                AND t01.syozoku_code_3 = t19_3.sosiki_code(+) ").append(
							"                AND t01.syozoku_code_4 = t19_4.sosiki_code(+) ").append("                AND t01.syozoku_code_5 = t19_5.sosiki_code(+) ").append(
							"                 )          ").append("GROUP BY   syozoku_code_1,").append("           sosiki_mei_1,").append("           syozoku_code_2,").append(
							"           sosiki_mei_2,").append("           syozoku_code_3,").append("           sosiki_mei_3,").append("           syozoku_code_4,").append("           sosiki_mei_4,")
					.append("           syozoku_code_5,").append("           sosiki_mei_5,").append("           yakusyoku_code,").append("           yakusyoku_mei,").append("           simei_no,")
					.append("           kanji_simei ").append("ORDER BY   sort_code_1,").append("           syozoku_code_1,").append("           sort_code_2,").append("           syozoku_code_2,")
					.append("           sort_code_3,").append("           syozoku_code_3, ").append("           sort_code_4,").append("           syozoku_code_4, ").append("           sort_code_5,")
					.append("           syozoku_code_5, ").append("           yakusyoku_code,").append("           simei_no");

			/* �f�o�b�O���O */
			Log.debug("getCsvShozokuBumonTokei:SQL = " + sql);

			pre = cn.prepareStatement(sql.toString());
			if ("".equals(sosiki_code) && ("0".equals(kengen_code) || "1".equals(kenpo_flag))) {
				pre.setString(1, TrainingInformationEJBBean.FUNCTION_CODE);
				pre.setString(2, TrainingInformationEJBBean.FUNCTION_CODE);
				pre.setString(3, HcdbDef.GENSYOKU_TAISYOKU);
				pre.setString(4, HcdbDef.HONMU);
				pre.setString(5, kaisibi);
				pre.setString(6, syuryobi);
				pre.setString(7, TrainingInformationEJBBean.FUNCTION_CODE);
				pre.setString(8, TrainingInformationEJBBean.FUNCTION_CODE);
				pre.setString(9, HcdbDef.GENSYOKU_TAISYOKU);
				pre.setString(10, HcdbDef.HONMU);
				pre.setString(11, kaisibi);
				pre.setString(12, syuryobi);
			} else {
				pre.setString(1, TrainingInformationEJBBean.FUNCTION_CODE);
				pre.setString(2, TrainingInformationEJBBean.FUNCTION_CODE);
				pre.setString(3, HcdbDef.GENSYOKU_TAISYOKU);
				pre.setString(4, HcdbDef.HONMU);
				pre.setString(5, sosiki_code);
				pre.setString(6, kaisibi);
				pre.setString(7, syuryobi);
				pre.setString(8, TrainingInformationEJBBean.FUNCTION_CODE);
				pre.setString(9, TrainingInformationEJBBean.FUNCTION_CODE);
				pre.setString(10, HcdbDef.GENSYOKU_TAISYOKU);
				pre.setString(11, HcdbDef.HONMU);
				pre.setString(12, sosiki_code);
				pre.setString(13, kaisibi);
				pre.setString(14, syuryobi);
			}

			Log.performance(loginuser.getSimeiNo(), true, "getCsvShozokuBumonTokei performance: START");
			rs = pre.executeQuery();
			Log.performance(loginuser.getSimeiNo(), false, "getCsvShozokuBumonTokei performance: END");

			int i_row = 0;

			while (rs.next()) {
				i_row++;

				csvData = new TrainingInformationBean();

				csvData.setSyozokuCode1(rs.getString("syozoku_code_1"));
				csvData.setSosikiMei1(rs.getString("sosiki_mei_1"));
				csvData.setSyozokuCode2(rs.getString("syozoku_code_2"));
				csvData.setSosikiMei2(rs.getString("sosiki_mei_2"));
				csvData.setSyozokuCode3(rs.getString("syozoku_code_3"));
				csvData.setSosikiMei3(rs.getString("sosiki_mei_3"));
				csvData.setSyozokuCode4(rs.getString("syozoku_code_4"));
				csvData.setSosikiMei4(rs.getString("sosiki_mei_4"));
				csvData.setSyozokuCode5(rs.getString("syozoku_code_5"));
				csvData.setSosikiMei5(rs.getString("sosiki_mei_5"));
				csvData.setYakusyokuCode(rs.getString("yakusyoku_code"));
				csvData.setYakusyoku(rs.getString("yakusyoku_mei"));
				csvData.setSimeiNo(rs.getString("simei_no"));
				csvData.setKanjiSimei(rs.getString("kanji_simei"));
				csvData.setTanka(rs.getString("sum_tanka"));
				csvData.setNissuu(rs.getString("sum_nissuu"));

				v_result.add(csvData);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return v_result;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", cn, pre, rs);
		}
	}

	/**
	 * �������喾��
	 * @param loginuser ���O�C����ID
	 * @param sosiki_code �����R�[�h
	 * @param kaisou �K�w
	 * @param kaisibi �J�n��
	 * @param syuryobi �I����
	 * @return �������喾�ׂ̌��C�҂̏��
	 * @exception SQLException SQL�G���[�����������ꍇ
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public Vector getCsvShozokuBumonMeisai(final PEY_PersonalBean loginuser, final String sosiki_code, final String kaisou, final String kaisibi, final String syuryobi) throws NamingException,
			RemoteException {

		Log.method(loginuser.getSimeiNo(), "IN", "");
		/* DB�ڑ��I�u�W�F�N�g�̊l�� */
		Connection cn = null;
		/** SQL�𑗂邽�߂�PreparedStatement�I�u�W�F�N�g */
		PreparedStatement pre = null;
		/** �f�[�^�x�[�X�̌��ʃZ�b�g���i�[����ResultSet�I�u�W�F�N�g */
		ResultSet rs = null;

		TrainingInformationBean csvData = null;

		final Vector v_result = new Vector();

		try {
			cn = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			final String kengen_code = loginuser.getKengenCode();
			final String kenpo_flag = loginuser.getKenpoMainteFlg();
			String temp;

			if ("".equals(sosiki_code) && ("0".equals(kengen_code) || "1".equals(kenpo_flag))) {
				temp = "";
			} else {
				temp = "AND t01.syozoku_code_" + kaisou + " = ?";
			}

			final StringBuffer sql = new StringBuffer("SELECT t01.syozoku_code_1 AS syozoku_code1, ").append("        t19_code1.BUSYO_RYAKUSYO_MEI AS sosiki_mei1, ").append(
					"        t01.syozoku_code_2 AS syozoku_code2, ").append("        t19_code2.BUSYO_RYAKUSYO_MEI AS sosiki_mei2, ").append("        t01.syozoku_code_3 AS syozoku_code3, ").append(
					"        t19_code3.BUSYO_RYAKUSYO_MEI AS sosiki_mei3, ").append("        t01.syozoku_code_4 AS syozoku_code4, ").append("        t19_code4.BUSYO_RYAKUSYO_MEI AS sosiki_mei4, ")
					.append("        t01.syozoku_code_5 AS syozoku_code5, ").append("        t19_code5.BUSYO_RYAKUSYO_MEI AS sosiki_mei5,  ").append("        t01.yakusyoku_code AS yakusyoku_code, ")
					.append("        t15.yakusyoku AS yakusyoku, ").append("        t01.simei_no AS simei_no,  ").append("        substr(t01.kanji_simei,2,length(t01.kanji_simei)) AS kanji_simei, ")
					.append("        l51.kamoku_group AS kamoku_group, ").append("        l51.kamoku_group_mei as kamoku_group_mei, ").append("        l51.kamoku_code AS kamoku_code,  ").append(
							"        l51.kamoku_mei1 AS kamoku_mei, ").append("        l51.kaisibi AS kaisibi,  ").append("        l51.syuryobi AS syuryobi, ").append(
							"        DECODE (l51.syuryo_hantei, ").append("                  '0', ?, ").append("                  '1', ?, ").append("                  '2', ? ").append(
							"                 ) AS situation, ").append("         DECODE (t01.syozoku_code_1, NULL, '0', '1') AS sort_code_1,  ").append(
							"         DECODE (t01.syozoku_code_2, NULL, '0', '1') AS sort_code_2,  ").append("         DECODE (t01.syozoku_code_3, NULL, '0', '1') AS sort_code_3,  ").append(
							"         DECODE (t01.syozoku_code_4, NULL, '0', '1') AS sort_code_4,  ").append("         DECODE (t01.syozoku_code_5, NULL, '0', '1') AS sort_code_5  ").append(
							"     FROM T01_PERSONAL_TBL t01, ").append("          L51_KYOIKU_TBL l51, ").append("          T19_SOSIKI_TBL t19_code1, ").append("          T19_SOSIKI_TBL t19_code2, ")
					.append("          T19_SOSIKI_TBL t19_code3, ").append("          T19_SOSIKI_TBL t19_code4, ").append("          T19_SOSIKI_TBL t19_code5, ").append(
							"          T19_SOSIKI_TBL t19_S, ").append("          T15_YAKUSYOKU_TBL t15 ").append("    WHERE t01.gensyoku_taisyoku_flg = ? ").append("        AND t01.honmu_flg = ? ")
					.append("       AND t01.simei_no = l51.simei_no ").append(temp).append("       AND l51.syuryobi BETWEEN ? AND ? ").append("       AND t01.sosiki_code = t19_S.sosiki_code ")
					.append("       AND t01.syozoku_code_1 = t19_code1.sosiki_code(+) ").append("       AND t01.syozoku_code_2 = t19_code2.sosiki_code(+) ").append(
							"       AND t01.syozoku_code_3 = t19_code3.sosiki_code(+) ").append("       AND t01.syozoku_code_4 = t19_code4.sosiki_code(+) ").append(
							"       AND t01.syozoku_code_5 = t19_code5.sosiki_code(+) ").append("       AND t01.yakusyoku_code = t15.yakusyoku_code(+)  ").append(" UNION ALL ").append(
							" SELECT t01.syozoku_code_1, ").append("        t19_code1.BUSYO_RYAKUSYO_MEI,  ").append("        t01.syozoku_code_2, ").append("        t19_code2.BUSYO_RYAKUSYO_MEI,  ")
					.append("        t01.syozoku_code_3, ").append("        t19_code3.BUSYO_RYAKUSYO_MEI,  ").append("        t01.syozoku_code_4, ").append("        t19_code4.BUSYO_RYAKUSYO_MEI, ")
					.append("        t01.syozoku_code_5, ").append("        t19_code5.BUSYO_RYAKUSYO_MEI, ").append("        t01.yakusyoku_code,  ").append("        t15.yakusyoku,  ").append(
							"        t01.simei_no,  ").append("        substr(t01.kanji_simei,2,length(t01.kanji_simei)), ").append("        l01.kamoku_group, ").append("        p15.kamoku_group, ")
					.append("        l15.kamoku_code,  ").append("        l01.kamoku_mei1,  ").append("        l02.kaisibi,  ").append("        l02.syuryobi,          ").append(
							"        DECODE (l15.status, ").append("                 '0', ?, ").append("                 '2', ?, ").append("                 '3', ?, ").append(
							"                 '1', DECODE (l15.uketsuke_jyotai, ").append("                              '0', ?, ").append("                              '1', ?, ").append(
							"                              '2', ?, ").append("                              '3', ?, ").append("                              '4', ? ").append(
							"                             ) ").append("                ), ").append("         DECODE (t01.syozoku_code_1, NULL, '0', '1') AS sort_code_1,  ").append(
							"         DECODE (t01.syozoku_code_2, NULL, '0', '1') AS sort_code_2,  ").append("         DECODE (t01.syozoku_code_3, NULL, '0', '1') AS sort_code_3,  ").append(
							"         DECODE (t01.syozoku_code_4, NULL, '0', '1') AS sort_code_4,  ").append("         DECODE (t01.syozoku_code_5, NULL, '0', '1') AS sort_code_5  ").append(
							"     FROM T01_PERSONAL_TBL t01, ").append("          L15_MOUSIKOMI_JYOKYO_TBL l15, ").append("          T19_SOSIKI_TBL t19_code1, ").append(
							"          T19_SOSIKI_TBL t19_code2, ").append("          T19_SOSIKI_TBL t19_code3, ").append("          T19_SOSIKI_TBL t19_code4, ").append(
							"          T19_SOSIKI_TBL t19_code5, ").append("          T19_SOSIKI_TBL t19_S, ").append("          T15_YAKUSYOKU_TBL t15, ").append("          L01_KAMOKU_TBL l01, ")
					.append("          L02_CLASS_TBL l02, ").append("          P15_C_KAMOKU_GROUP_TBL p15 ").append("    WHERE t01.gensyoku_taisyoku_flg = ? ")
					.append("        AND t01.honmu_flg = ? ").append("       AND t01.simei_no = l15.simei_no ").append(temp).append("       AND l15.kamoku_code = l01.kamoku_code ").append(
							"       AND l15.class_code = l02.class_code ").append("       AND l15.kamoku_code = l02.kamoku_code ").append("       AND l02.syuryobi BETWEEN ? AND ? ").append(
							"       AND t01.sosiki_code = t19_S.sosiki_code ").append("       AND t01.syozoku_code_1 = t19_code1.sosiki_code(+) ").append(
							"       AND t01.syozoku_code_2 = t19_code2.sosiki_code(+) ").append("       AND t01.syozoku_code_3 = t19_code3.sosiki_code(+) ").append(
							"       AND t01.syozoku_code_4 = t19_code4.sosiki_code(+) ").append("       AND t01.syozoku_code_5 = t19_code5.sosiki_code(+) ").append(
							"       AND t01.yakusyoku_code = t15.yakusyoku_code(+) ").append("       AND l01.kamoku_group = p15.kamoku_group_code(+) ").append("ORDER BY   sort_code_1,").append(
							"           syozoku_code1,").append("           sort_code_2,").append("           syozoku_code2,").append("           sort_code_3,").append("           syozoku_code3, ")
					.append("           sort_code_4,").append("           syozoku_code4, ").append("           sort_code_5,").append("           syozoku_code5, ").append("          yakusyoku_code, ")
					.append("          simei_no, ").append("          kamoku_code ");

			/* �f�o�b�O���O */
			Log.debug("getCsvShozokuBumonMeisai:SQL = " + sql);

			pre = cn.prepareStatement(sql.toString());
			if ("".equals(sosiki_code) && ("0".equals(kengen_code) || "1".equals(kenpo_flag))) {
				pre.setString(1, TrainingInformationEJBBean.L51_HANTEI_0);
				pre.setString(2, TrainingInformationEJBBean.L51_HANTEI_1);
				pre.setString(3, TrainingInformationEJBBean.L51_HANTEI_2);
				pre.setString(4, HcdbDef.GENSYOKU_TAISYOKU);
				pre.setString(5, HcdbDef.HONMU);
				pre.setString(6, kaisibi);
				pre.setString(7, syuryobi);
				pre.setString(8, TrainingInformationEJBBean.L15_STATUS_0);
				pre.setString(9, TrainingInformationEJBBean.L15_STATUS_2);
				pre.setString(10, TrainingInformationEJBBean.L15_STATUS_3);
				pre.setString(11, TrainingInformationEJBBean.L15_UKESUKE_JYOTAI_0);
				pre.setString(12, TrainingInformationEJBBean.L15_UKESUKE_JYOTAI_1);
				pre.setString(13, TrainingInformationEJBBean.L15_UKESUKE_JYOTAI_2);
				pre.setString(14, TrainingInformationEJBBean.L15_UKESUKE_JYOTAI_3);
				pre.setString(15, TrainingInformationEJBBean.L15_UKESUKE_JYOTAI_4);
				pre.setString(16, HcdbDef.GENSYOKU_TAISYOKU);
				pre.setString(17, HcdbDef.HONMU);
				pre.setString(18, kaisibi);
				pre.setString(19, syuryobi);
			} else {
				pre.setString(1, TrainingInformationEJBBean.L51_HANTEI_0);
				pre.setString(2, TrainingInformationEJBBean.L51_HANTEI_1);
				pre.setString(3, TrainingInformationEJBBean.L51_HANTEI_2);
				pre.setString(4, HcdbDef.GENSYOKU_TAISYOKU);
				pre.setString(5, HcdbDef.HONMU);
				pre.setString(6, sosiki_code);
				pre.setString(7, kaisibi);
				pre.setString(8, syuryobi);
				pre.setString(9, TrainingInformationEJBBean.L15_STATUS_0);
				pre.setString(10, TrainingInformationEJBBean.L15_STATUS_2);
				pre.setString(11, TrainingInformationEJBBean.L15_STATUS_3);
				pre.setString(12, TrainingInformationEJBBean.L15_UKESUKE_JYOTAI_0);
				pre.setString(13, TrainingInformationEJBBean.L15_UKESUKE_JYOTAI_1);
				pre.setString(14, TrainingInformationEJBBean.L15_UKESUKE_JYOTAI_2);
				pre.setString(15, TrainingInformationEJBBean.L15_UKESUKE_JYOTAI_3);
				pre.setString(16, TrainingInformationEJBBean.L15_UKESUKE_JYOTAI_4);
				pre.setString(17, HcdbDef.GENSYOKU_TAISYOKU);
				pre.setString(18, HcdbDef.HONMU);
				pre.setString(19, sosiki_code);
				pre.setString(20, kaisibi);
				pre.setString(21, syuryobi);

			}

			Log.performance(loginuser.getSimeiNo(), true, "getCsvShozokuBumonMeisai performance: START");
			rs = pre.executeQuery();
			Log.performance(loginuser.getSimeiNo(), false, "getCsvShozokuBumonMeisai performance: END");

			int i_row = 0;

			while (rs.next()) {
				i_row++;

				csvData = new TrainingInformationBean();
				csvData.setSyozokuCode1(rs.getString("syozoku_code1"));
				csvData.setSosikiMei1(rs.getString("sosiki_mei1"));
				csvData.setSyozokuCode2(rs.getString("syozoku_code2"));
				csvData.setSosikiMei2(rs.getString("sosiki_mei2"));
				csvData.setSyozokuCode3(rs.getString("syozoku_code3"));
				csvData.setSosikiMei3(rs.getString("sosiki_mei3"));
				csvData.setSyozokuCode4(rs.getString("syozoku_code4"));
				csvData.setSosikiMei4(rs.getString("sosiki_mei4"));
				csvData.setSyozokuCode5(rs.getString("syozoku_code5"));
				csvData.setSosikiMei5(rs.getString("sosiki_mei5"));
				csvData.setYakusyokuCode(rs.getString("yakusyoku_code"));
				csvData.setYakusyoku(rs.getString("yakusyoku"));
				csvData.setSimeiNo(rs.getString("simei_no"));
				csvData.setKanjiSimei(rs.getString("kanji_simei"));
				csvData.setKamokuGroup(rs.getString("kamoku_group"));
				csvData.setKamokuGroupMei(rs.getString("kamoku_group_mei"));
				csvData.setKamokuCode(rs.getString("kamoku_code"));
				csvData.setKamokuMei(rs.getString("kamoku_mei"));
				csvData.setKaisibi(rs.getString("kaisibi"));
				csvData.setSyuryobi(rs.getString("syuryobi"));
				csvData.setSituation(rs.getString("situation"));

				v_result.add(csvData);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return v_result;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", cn, pre, rs);
		}
	}

	/**
	 * �S�Г��v
	 * @param loginuser ���O�C����ID
	 * @param sosiki_code �����R�[�h
	 * @param kaisibi �J�n��
	 * @param syuryobi �I����
	 * @return �S�Ђ̌��C�҂̏��
	 * @exception SQLException SQL�G���[�����������ꍇ
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public Vector getCsvZenshaTokei(final PEY_PersonalBean loginuser, final String kaisibi, final String syuryobi) throws NamingException, RemoteException {

		Log.method(loginuser.getSimeiNo(), "IN", "");
		/* DB�ڑ��I�u�W�F�N�g�̊l�� */
		Connection cn = null;
		/** SQL�𑗂邽�߂�PreparedStatement�I�u�W�F�N�g */
		PreparedStatement pre = null;
		/** �f�[�^�x�[�X�̌��ʃZ�b�g���i�[����ResultSet�I�u�W�F�N�g */
		ResultSet rs = null;

		TrainingInformationBean csvData = null;

		final Vector v_result = new Vector();

		try {
			cn = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");
			final StringBuffer sqlSelect = new StringBuffer("SELECT ").append("                    syozoku_code_1, sosiki_mei_1, syozoku_code_2, sosiki_mei_2,").append(
					"                    group_code, group_mei,  ").append("                    (SELECT   COUNT (t1.simei_no) ").append("                         FROM T01_PERSONAL_TBL t1, ").append(
					"                                   A91_SYUKEI_GROUP_TBL a91, ").append("                                   T15_YAKUSYOKU_TBL t15 ").append(
					"                         WHERE t1.honmu_flg = ? ").append("                         AND t1.gensyoku_taisyoku_flg = ? ").append(
					"                         AND t1.yakusyoku_code = t15.yakusyoku_code ").append("                         AND t15.kaisou = a91.yakusyoku_kaisou ").append(
					"                         AND a91.kinou_code = ? ").append(
					"                         AND (   (    (tbl1.syozoku_code_1 IS NOT NULL) AND (t1.syozoku_code_1 = tbl1.syozoku_code_1) ) ").append(
					"                              OR (    (tbl1.syozoku_code_1 IS NULL) AND (t1.syozoku_code_1 IS NULL)  ) ").append("                              ) ").append(
					"                         AND (   (    (tbl1.syozoku_code_2 IS NOT NULL) AND (t1.syozoku_code_2 = tbl1.syozoku_code_2) ) ").append(
					"                              OR (    (tbl1.syozoku_code_2 IS NULL) AND (t1.syozoku_code_2 IS NULL) ) ").append("                             ) ").append(
					"                         AND (   (    (tbl1.group_code IS NOT NULL) AND (a91.group_code = tbl1.group_code) ) ").append(
					"                              OR (    (tbl1.group_code IS NULL) AND (a91.group_code IS NULL) ) ").append("                             ) ) AS candidates, ").append(
					"                    COUNT (DISTINCT simei_no) AS proposers, SUM (tanka) AS money, ").append("                    SUM (nissuu) AS days, ").append(
					"                    DECODE (syozoku_code_1, NULL, '0', '1') AS sort_code_1,  ").append("                    DECODE (syozoku_code_2, NULL, '0', '1') AS sort_code_2  ").append(
					"               FROM (SELECT t01.simei_no AS simei_no, t01.syozoku_code_1,").append("                            t19_1.BUSYO_RYAKUSYO_MEI AS sosiki_mei_1, t01.syozoku_code_2,")
					.append("                            t19_2.BUSYO_RYAKUSYO_MEI AS sosiki_mei_2, l51.tanka AS tanka,").append("                            l51.nissuu AS nissuu,").append(
							"                            CASE  ").append("                                WHEN a91.kinou_code = ? THEN A91.group_code ").append(
							"                                ELSE null ").append("                            END as group_code,").append("                            CASE  ").append(
							"                                WHEN a91.kinou_code = ? THEN A91.group_mei ").append("                                ELSE null ").append(
							"                            END as group_mei ").append("                       FROM T01_PERSONAL_TBL t01,").append("                            L51_KYOIKU_TBL l51,")
					.append("                            T15_YAKUSYOKU_TBL t15,").append("                            A91_SYUKEI_GROUP_TBL a91,").append(
							"                            T19_SOSIKI_TBL t19_1,").append("                            T19_SOSIKI_TBL t19_2,").append("                            T19_SOSIKI_TBL t19_S")
					.append("                     WHERE t01.gensyoku_taisyoku_flg = ? ").append("                        AND t01.honmu_flg = ? ").append(
							"                        AND t01.simei_no = l51.simei_no ").append("                        AND l51.syuryobi BETWEEN ? AND ? ").append(
							"                        AND t01.yakusyoku_code = t15.yakusyoku_code(+) ").append("                        AND t15.kaisou = a91.yakusyoku_kaisou(+) ").append(
							"                        AND t01.sosiki_code = t19_S.sosiki_code ").append("                        AND t01.syozoku_code_1 = t19_1.sosiki_code(+) ").append(
							"                        AND t01.syozoku_code_2 = t19_2.sosiki_code(+) ").append("                     UNION ALL ")

					.append("                     SELECT t01.simei_no, t01.syozoku_code_1, t19_1.BUSYO_RYAKUSYO_MEI,")
					.append("                            t01.syozoku_code_2, t19_2.BUSYO_RYAKUSYO_MEI, l02.tanka, l02.nissuu,")
					// CHG#2007/3/6 s-hiura
					.append("                            CASE  ").append("                                WHEN a91.kinou_code = ? THEN A91.group_code ").append(
							"                                ELSE null ").append("                            END as group_code,").append("                            CASE  ").append(
							"                                WHEN a91.kinou_code = ? THEN A91.group_mei ").append("                                ELSE null ").append(
							"                            END as group_mei ").append("                       FROM T01_PERSONAL_TBL t01,").append(
							"                            L15_MOUSIKOMI_JYOKYO_TBL l15,").append("                            T15_YAKUSYOKU_TBL t15,").append(
							"                            L01_KAMOKU_TBL l01,").append("                            L02_CLASS_TBL l02,").append("                            A91_SYUKEI_GROUP_TBL a91,")
					.append("                            T19_SOSIKI_TBL t19_1,").append("                            T19_SOSIKI_TBL t19_2,").append("                            T19_SOSIKI_TBL t19_S")
					.append("                     WHERE t01.gensyoku_taisyoku_flg = ? ").append("                        AND t01.honmu_flg = ? ").append(
							"                        AND t01.simei_no = l15.simei_no ").append("                        AND l15.kamoku_code = l01.kamoku_code ").append(
							"                        AND l15.class_code = l02.class_code ").append("                        AND l15.kamoku_code = l02.kamoku_code ").append(
							"                        AND l02.syuryobi BETWEEN ? AND ? ").append("                        AND t01.yakusyoku_code = t15.yakusyoku_code(+) ").append(
							"                        AND t15.kaisou = a91.yakusyoku_kaisou(+) ").append("                        AND t01.sosiki_code = t19_S.sosiki_code ").append(
							"                        AND t01.syozoku_code_1 = t19_1.sosiki_code(+) ").append("                        AND t01.syozoku_code_2 = t19_2.sosiki_code(+)) tbl1 ").append(
							"           GROUP BY syozoku_code_1,").append("                    sosiki_mei_1,").append("                    syozoku_code_2,")
					.append("                    sosiki_mei_2,").append("                    group_code,").append("                    group_mei ").append(
							"           ORDER BY sort_code_1, syozoku_code_1, sort_code_2, syozoku_code_2, group_code"); // 2006/06/01_LYCE_M_THANHDH //CHG#BP1-009

			/* �f�o�b�O���O */
			Log.debug("getCsvZenshaTokei:SQL = " + sqlSelect);

			pre = cn.prepareStatement(sqlSelect.toString());
			pre.setString(1, HcdbDef.HONMU);
			pre.setString(2, HcdbDef.GENSYOKU_TAISYOKU);
			pre.setString(3, TrainingInformationEJBBean.FUNCTION_CODE);
			pre.setString(4, TrainingInformationEJBBean.FUNCTION_CODE);
			pre.setString(5, TrainingInformationEJBBean.FUNCTION_CODE);
			pre.setString(6, HcdbDef.GENSYOKU_TAISYOKU);
			pre.setString(7, HcdbDef.HONMU);
			pre.setString(8, kaisibi);
			pre.setString(9, syuryobi);
			pre.setString(10, TrainingInformationEJBBean.FUNCTION_CODE);
			pre.setString(11, TrainingInformationEJBBean.FUNCTION_CODE);
			pre.setString(12, HcdbDef.GENSYOKU_TAISYOKU);
			pre.setString(13, HcdbDef.HONMU);
			pre.setString(14, kaisibi);
			pre.setString(15, syuryobi);

			Log.performance(loginuser.getSimeiNo(), true, "getCsvZenshaTokei performance: START");
			rs = pre.executeQuery();
			Log.performance(loginuser.getSimeiNo(), false, "getCsvZenshaTokei performance: END");

			int i_row = 0;

			while (rs.next()) {
				i_row++;
				csvData = new TrainingInformationBean();
				csvData.setSyozokuCode1(rs.getString("syozoku_code_1"));
				csvData.setSosikiMei1(rs.getString("sosiki_mei_1"));
				csvData.setSyozokuCode2(rs.getString("syozoku_code_2"));
				csvData.setSosikiMei2(rs.getString("sosiki_mei_2"));
				csvData.setYakusyokuCode(rs.getString("group_code"));
				csvData.setYakusyokuMei(rs.getString("group_mei"));
				csvData.setTaishoshaKazu(rs.getString("candidates"));
				csvData.setMoshikomiNinzu(rs.getString("proposers"));
				csvData.setMoshikomiKingaku(rs.getString("money"));
				csvData.setMoshikomiNissu(rs.getString("days"));

				v_result.add(csvData);
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return v_result;
		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", cn, pre, rs);
		}
	}

	/**
	 * SessionContext�����擾����B
	 * @return SessionContext���
	 */
	public SessionContext getSessionContext() {
		return this.my_ssc;
	}

	/**
	 * EJB�R���e�i���Ǘ�����SessionContext����SessionBean�ɓn���BSessionBean�̍쐬���ɌĂяo�����B
	 * @param val SessionContext���
	 * @exception RemoteException
	 */
	public void setSessionContext(final SessionContext val) throws RemoteException {
		this.my_ssc = val;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}

}