/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.base.valuebean;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletRequest;

import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X��: PEY_KouboOubosyaAssessBean �N���X �@�\����: ����_�����_�A�Z�X�����g���ʃe�[�u���̃f�[�^�ێ����s���B
 * 
 * </PRE>
 */
public class PEY_KouboOubosyaAssessBean extends PEY_MasterBean implements Serializable {
	private String kouboankenid = null;

	private String simeino = null;

	private String jissi_nengappi = null;

	private String seqno = null;

	private String syokucode = null;

	private String senmoncode = null;

	private String levelcode = null;

	private String syokuname = null;

	private String senmonname = null;

	private String levelname = null;

	private String jikosougoutdo = null;

	private String hyokasyasougoutdo = null;

	private String tourokubi = null;

	private String tourokujikoku = null;

	private String tourokusya = null;

	private String kousinbi = null;

	private String kousinjikoku = null;

	private String kousinsya = null;

	/**
	 * �f�t�H���g�̃R���X�g���N�^
	 */
	public PEY_KouboOubosyaAssessBean() {
	}

	/**
	 * �f�t�H���g�̃R���X�g���N�^
	 */
	public PEY_KouboOubosyaAssessBean(final ServletRequest request) {
		this.setKouboankenid(request.getParameter("koubo_anken_id"));
		this.setSimeino(request.getParameter("simei_no"));
	}

	/**
	 * ResultSet ����l���擾���Č���_�����_�A�Z�X�����gValueBean���쐬���܂��B
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param TableName ���m�点���̃e�[�u����
	 */
	public PEY_KouboOubosyaAssessBean(final ResultSet rs) throws SQLException {

		try {
			this.setJissi_nengappi(rs.getString(this.getIdentifier() + "JISSI_NENGAPPI"));
			this.setSyokucode(rs.getString(this.getIdentifier() + "SYOKU_CODE"));
			this.setSenmoncode(rs.getString(this.getIdentifier() + "SENMON_CODE"));
			this.setLevelcode(rs.getString(this.getIdentifier() + "LEVEL_CODE"));
			this.setJikosougoutdo(rs.getString(this.getIdentifier() + "JIKO_SOUGOU_T_DO"));
			this.setSyokuname(rs.getString(this.getIdentifier() + "SYOKU_NAME"));
			this.setSenmonname(rs.getString(this.getIdentifier() + "SENMON_NAME"));
			this.setLevelname(rs.getString(this.getIdentifier() + "LEVEL_NAME"));
			this.setHyokasyasougoutdo(rs.getString(this.getIdentifier() + "HYOKASYA_SOUGOU_T_DO"));
		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		}
	}

	/**
	 * ResultSet ����l���擾���Č���_�����_�A�Z�X�����gValueBean���쐬���܂��B
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param TableName ���m�点���̃e�[�u����
	 */
	public PEY_KouboOubosyaAssessBean(final ResultSet rs, final String TableName) throws SQLException {

		super(rs, TableName);

		try {
			this.setKouboankenid(rs.getString(this.getIdentifier() + "KOUBO_ANKEN_ID"));
			this.setSimeino(rs.getString(this.getIdentifier() + "SIMEI_NO"));
			this.setSeqno(rs.getString(this.getIdentifier() + "SEQ_NO"));
			this.setSyokucode(rs.getString(this.getIdentifier() + "SYOKU_CODE"));
			this.setSenmoncode(rs.getString(this.getIdentifier() + "SENMON_CODE"));
			this.setLevelcode(rs.getString(this.getIdentifier() + "LEVEL_CODE"));
			this.setJikosougoutdo(rs.getString(this.getIdentifier() + "JIKO_SOUGOU_T_DO"));
			this.setHyokasyasougoutdo(rs.getString(this.getIdentifier() + "HYOKASYA_SOUGOU_T_DO"));
			this.setTourokubi(rs.getString(this.getIdentifier() + "TOUROKUBI"));
			this.setTourokujikoku(rs.getString(this.getIdentifier() + "TOUROKUJIKOKU"));
			this.setTourokusya(rs.getString(this.getIdentifier() + "TOUROKUSYA"));
			this.setKousinbi(rs.getString(this.getIdentifier() + "KOUSINBI"));
			this.setKousinjikoku(rs.getString(this.getIdentifier() + "KOUSINJIKOKU"));
			this.setKousinsya(rs.getString(this.getIdentifier() + "KOUSINSYA"));
		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		}
	}

	/**
	 * <pre>
	 *     ����_�����_�A�Z�X�����g���ʃe�[�u���̌��������𒊏o���܂��B
	 *     �ȉ��̍��ڂ����������Ƃ��Ďg�p�ł��܂��B
	 *     �E����Č�ID
	 * </pre>
	 * 
	 * @return ���o���ꂽ��������
	 */
	public Map extractConditions() {
		final Map conditions = new LinkedHashMap();

		if (this.getKouboankenid() != null && !this.getKouboankenid().equals("")) {
			conditions.put("KOUBO_ANKEN_ID", this.getKouboankenid());
		}
		if (this.getSimeino() != null && !this.getSimeino().equals("")) {
			conditions.put("SIMEI_NO", this.getSimeino());
		}

		return conditions;
	}

	/**
	 * @return
	 */
	public String getKouboankenid() {
		return this.kouboankenid;
	}

	/**
	 * @return
	 */
	public String getSimeino() {
		return this.simeino;
	}

	/**
	 * @return
	 */
	public String getSeqno() {
		return this.seqno;
	}

	/**
	 * @return
	 */
	public String getSyokucode() {
		return this.syokucode;
	}

	/**
	 * @return
	 */
	public String getSenmoncode() {
		return this.senmoncode;
	}

	/**
	 * @return
	 */
	public String getLevelcode() {
		return this.levelcode;
	}

	/**
	 * @return
	 */
	public String getJikosougoutdo() {
		return this.jikosougoutdo;
	}

	/**
	 * @return
	 */
	public String getHyokasyasougoutdo() {
		return this.hyokasyasougoutdo;
	}

	/**
	 * @return
	 */
	public String getTourokubi() {
		return this.tourokubi;
	}

	/**
	 * @return
	 */
	public String getTourokujikoku() {
		return this.tourokujikoku;
	}

	/**
	 * @return
	 */
	public String getTourokusya() {
		return this.tourokusya;
	}

	/**
	 * @return
	 */
	public String getKousinbi() {
		return this.kousinbi;
	}

	/**
	 * @return
	 */
	public String getKousinjikoku() {
		return this.kousinjikoku;
	}

	/**
	 * @return
	 */
	public String getKousinsya() {
		return this.kousinsya;
	}

	/**
	 * @param string
	 */
	public void setKouboankenid(final String string) {
		this.kouboankenid = string;
	}

	/**
	 * @param string
	 */
	public void setSimeino(final String string) {
		this.simeino = string;
	}

	/**
	 * @param string
	 */
	public void setSeqno(final String string) {
		this.seqno = string;
	}

	/**
	 * @param string
	 */
	public void setSyokucode(final String string) {
		this.syokucode = string;
	}

	/**
	 * @param string
	 */
	public void setSenmoncode(final String string) {
		this.senmoncode = string;
	}

	/**
	 * @param string
	 */
	public void setLevelcode(final String string) {
		this.levelcode = string;
	}

	/**
	 * @param string
	 */
	public void setJikosougoutdo(final String string) {
		this.jikosougoutdo = string;
	}

	/**
	 * @param string
	 */
	public void setHyokasyasougoutdo(final String string) {
		this.hyokasyasougoutdo = string;
	}

	/**
	 * @param string
	 */
	public void setTourokubi(final String string) {
		this.tourokubi = string;
	}

	/**
	 * @param string
	 */
	public void setTourokujikoku(final String string) {
		this.tourokujikoku = string;
	}

	/**
	 * @param string
	 */
	public void setTourokusya(final String string) {
		this.tourokusya = string;
	}

	/**
	 * @param string
	 */
	public void setKousinbi(final String string) {
		this.kousinbi = string;
	}

	/**
	 * @param string
	 */
	public void setKousinjikoku(final String string) {
		this.kousinjikoku = string;
	}

	/**
	 * @param string
	 */
	public void setKousinsya(final String string) {
		this.kousinsya = string;
	}

	/**
	 * @return
	 */
	public String getJissi_nengappi() {
		return this.jissi_nengappi;
	}

	/**
	 * @param string
	 */
	public void setJissi_nengappi(final String string) {
		this.jissi_nengappi = string;
	}

	/**
	 * @return
	 */
	public String getLevelname() {
		return this.levelname;
	}

	/**
	 * @return
	 */
	public String getSenmonname() {
		return this.senmonname;
	}

	/**
	 * @return
	 */
	public String getSyokuname() {
		return this.syokuname;
	}

	/**
	 * @param string
	 */
	public void setLevelname(final String string) {
		this.levelname = string;
	}

	/**
	 * @param string
	 */
	public void setSenmonname(final String string) {
		this.senmonname = string;
	}

	/**
	 * @param string
	 */
	public void setSyokuname(final String string) {
		this.syokuname = string;
	}

}