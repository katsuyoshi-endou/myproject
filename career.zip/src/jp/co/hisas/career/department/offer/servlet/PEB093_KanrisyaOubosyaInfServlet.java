/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_OubosyaJyohoBean;
import jp.co.hisas.career.department.offer.ejb.PEB_SuccessOrFailureEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_SuccessOrFailureEJBHome;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F �Ǘ��҉�ʃT�[�u���b�g�N���X �@�\�����F ������e�[�u�����f�[�^���擾����
 * 
 * </PRE>
 */
public class PEB093_KanrisyaOubosyaInfServlet extends PEY010_ControllerServlet {
	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws NamingException, CreateException, RemoteException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		/* request ����A�l���擾 */
		final String koubo_anken_id = PZZ010_CharacterUtil.changeAnkenIdLength(request.getParameter("anken_id"));

		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEB_SuccessOrFailureEJBHome home = (PEB_SuccessOrFailureEJBHome) fact.lookup(PEB_SuccessOrFailureEJBHome.class);
		final PEB_SuccessOrFailureEJB ejb = home.create();

		/* �f�[�^���擾���� */
		final PEB_OubosyaJyohoBean[] koubooubosyaBeans = ejb.getGouhi(koubo_anken_id);
		request.setAttribute("koubooubosyaBean", koubooubosyaBeans);

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();
	}
}
