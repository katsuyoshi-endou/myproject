/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * <PRE>
 * 
 * �N���X���F PEB_SaiyousyaKetteiEJBBean�N���X �@�\�����F (�l��)�{�l�ʒm���c�a�Ɋi�[����@�\�ł��B �i�[����f�[�^�͍��ۃX�e�[�^�X
 * 
 * </PRE>
 * 
 * @ejb.bean name="PEB_SaiyousyaKetteiEJB" type="Stateless" transaction-type="Container" view-type="remote"
 * @ejb.resource-ref res-ref-name="jdbc/HCDB" res-type="javax.sql.DataSource" res-auth="Container"
 */
public class PEB_SaiyousyaKetteiEJBBean implements SessionBean {
	private SessionContext context = null;

	/**
	 * SAIYO_STATUS�ɑΉ����郌�R�[�h�̍X�V���s���܂��B
	 * @param koubooubosyaBean
	 * @param loginuser
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 */
	public int doUpdate(final PEY_KouboOubosyaBean koubooubosyaBean, final PEY_PersonalBean loginuser) throws PEY_WarningException, RemoteException, NamingException, CreateException {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "IN", "");
			// SQL�쐬
			final StringBuffer sql = new StringBuffer();
			sql.append("UPDATE ");
			sql.append(HcdbDef.D03_TBL);
			sql.append(" SET ");
			sql.append("SAIYO_STATUS = ?,");
			sql.append(" KOUSINBI = ?,");
			sql.append(" KOUSINJIKOKU = ?,");
			sql.append(" KOUSINSYA = ?");
			sql.append(" WHERE KOUBO_ANKEN_ID = ?");
			sql.append(" AND SIMEI_NO = ?");
			sql.append(" AND KOUSINBI = ?");
			sql.append(" AND KOUSINJIKOKU = ?");

			// �R�l�N�V�����擾
			con = PZZ040_SQLUtility.getConnection(loginuser != null ? loginuser.getSimeiNo() : "");

			// �f�o�b�O���O���o��
			Log.debug(sql.toString());

			// �X�V���s
			ps = con.prepareStatement(sql.toString());

			ps.clearParameters();
			ps.setString(1, koubooubosyaBean.getSaiyostatus().trim());
			ps.setString(2, PZZ010_CharacterUtil.GetDay());
			ps.setString(3, PZZ010_CharacterUtil.GetTime());
			ps.setString(4, loginuser.getSimeiNo());
			ps.setString(5, koubooubosyaBean.getKouboankenid());
			ps.setString(6, koubooubosyaBean.getSimeino());
			ps.setString(7, koubooubosyaBean.getKousinbi());
			ps.setString(8, koubooubosyaBean.getKousinjikoku());

			final int count = ps.executeUpdate();
			// ���\�b�h�g���[�X�o��
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			if (count != 1) {
				this.context.setRollbackOnly();
				throw new PEY_WarningException();
			}
			return count;

		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final SQLException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new EJBException(e);
		} catch (final RuntimeException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginuser != null ? loginuser.getSimeiNo() : "", con, ps, null);
		}
	}

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(final SessionContext context) throws EJBException, RemoteException {
		this.context = context;
	}

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}
}
