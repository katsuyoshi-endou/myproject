/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.offer.servlet;

import java.io.IOException;
import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboBean;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaAssessBean;
import jp.co.hisas.career.department.base.valuebean.PEY_KouboOubosyaBean;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.offer.bean.PEB_KouboAnkenOuboBean;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenOuboEJB;
import jp.co.hisas.career.department.offer.ejb.PEB_KouboAnkenOuboEJBHome;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �T�v�F ����Č������ʏo�͗p�f�[�^���擾���A����Č������ʂɑJ�ڂ���B �g�p���@: JSP����Ăяo���B
 * 
 * </PRE>
 */
public class PEB080_KouboAnkenOuboShowServlet extends PEY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws Exception {

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");
		Log.performance(loginuser.getSimeiNo(), true, "");

		// �p�����[�^�usearchFlg�v�̈Ӗ�
		// 1:�f�[�^��request���猟������B
		// ��L�ȊO�܂��̓p�����[�^����:�f�[�^���f�[�^�x�[�X���猟������B
		final String searchFlg = request.getParameter("searchFlg");

		try {
			PEB_KouboAnkenOuboBean ouboBean = null;

			if (searchFlg == null) {
				ouboBean = this.editFromDatabase(request, response, loginuser);
			} else {
				if (searchFlg.equals("1") == true) {
					ouboBean = this.editFromRequest(request, response, loginuser);
				} else {
					ouboBean = this.editFromDatabase(request, response, loginuser);
				}
			}

			if (ouboBean != null) {
				request.setAttribute("ouboBeans", ouboBean);
			} else {
				this.redirectErrorView(request, response, loginuser);
				return null;
			}

			/* ���\�b�h�g���[�X�o�� */
			Log.performance(loginuser.getSimeiNo(), false, "");
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			/* JSP�y�[�W���Ăяo�� */
			return this.getForwardPath();

		} catch (final NamingException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final CreateException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final RemoteException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		}
	}

	/**
	 * �f�[�^�x�[�X�������Č������ʏo�͗p�f�[�^��ҏW����B
	 */
	private PEB_KouboAnkenOuboBean editFromDatabase(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws Exception {

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		final String kouboAnkenId = request.getParameter("koubo_anken_id");
		final String simeiNo = loginuser.getSimeiNo();

		if (kouboAnkenId == null || kouboAnkenId.length() <= 0) {
			return null;
		}

		try {
			final EJBHomeFactory fact = EJBHomeFactory.getInstance();
			final PEB_KouboAnkenOuboEJBHome kouboAnkenOuboEJBHome = (PEB_KouboAnkenOuboEJBHome) fact.lookup(PEB_KouboAnkenOuboEJBHome.class);
			final PEB_KouboAnkenOuboEJB ouboEJB = kouboAnkenOuboEJBHome.create();

			final PEB_KouboAnkenOuboBean oubo = ouboEJB.getKouboAnkenOubo(kouboAnkenId, simeiNo);

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");

			return oubo;
		} catch (final NamingException e) {
			throw e;
		} catch (final CreateException e) {
			throw e;
		} catch (final RemoteException e) {
			throw e;
		}
	}

	/**
	 * request�������Č������ʏo�͗p�f�[�^��ҏW����B
	 */
	private PEB_KouboAnkenOuboBean editFromRequest(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		PEY_KouboBean kouboBean = null;
		PEY_KouboOubosyaBean kouboOubosyaBean = null;
		PEY_KouboOubosyaAssessBean kouboOubosyaAssessBean = null;
		PEB_KouboAnkenOuboBean ouboBean = null;

		ouboBean = new PEB_KouboAnkenOuboBean();

		// ����f�[�^���Z�b�g
		kouboBean = new PEY_KouboBean();
		kouboBean.setKouboankenid(request.getParameter("koubo_anken_id"));
		kouboBean.setKouboankenmei(request.getParameter("koubo_anken_mei"));
		ouboBean.setKouboBean(kouboBean);

		// ���剞��҃f�[�^���Z�b�g
		kouboOubosyaBean = new PEY_KouboOubosyaBean();
		kouboOubosyaBean.setKouboankenid(request.getParameter("koubo_anken_id"));
		kouboOubosyaBean.setSimeino(request.getParameter("simei_no"));
		kouboOubosyaBean.setSosikicode(request.getParameter("sosiki_code"));
		kouboOubosyaBean.setOubosyagrade(request.getParameter("oubosya_grade"));
		kouboOubosyaBean.setOubosyarate(request.getParameter("oubosya_rate"));
		kouboOubosyaBean.setKibougyomu(request.getParameter("kibou_gyomu"));
		kouboOubosyaBean.setSiboudouki(request.getParameter("sibou_douki"));
		kouboOubosyaBean.setJikopr(request.getParameter("jiko_pr"));
		kouboOubosyaBean.setGouhistatus(request.getParameter("gouhi_status"));
		kouboOubosyaBean.setSaiyostatus(request.getParameter("saiyo_status"));
		kouboOubosyaBean.setToiawasesyozoku(request.getParameter("toiawase_syozoku"));
		kouboOubosyaBean.setToiawasesimei(request.getParameter("toiawase_simei"));
		kouboOubosyaBean.setToiawasegaisen(request.getParameter("toiawase_gaisen"));
		kouboOubosyaBean.setToiawasenaisen(request.getParameter("toiawase_naisen"));
		kouboOubosyaBean.setToiawasemail(request.getParameter("toiawase_mail"));
		kouboOubosyaBean.setRenrakujikou(request.getParameter("renraku_jikou"));
		kouboOubosyaBean.setTourokubi(request.getParameter("tourokubi"));
		kouboOubosyaBean.setTourokujikoku(request.getParameter("tourokujikoku"));
		kouboOubosyaBean.setTourokusya(request.getParameter("tourokusya"));
		kouboOubosyaBean.setKousinbi(request.getParameter("kousinbi"));
		kouboOubosyaBean.setKousinjikoku(request.getParameter("kousinjikoku"));
		kouboOubosyaBean.setKousinsya(request.getParameter("kousinsya"));
		ouboBean.setKouboOubosyaBean(kouboOubosyaBean);

		// ���剞��҃A�Z�X�����g�f�[�^���Z�b�g
		// �A�Z�X�����g�������牺�L�̃p�����[�^���Z�b�g����邱�Ƃ�z�肵�Ă���
		// syoku_code1�`3
		// senmon_code1�`3
		// level_code1�`3
		// jiko_sougou_t_do1�`3
		// hyokasya_sougou_t_do1�`3
		final String SYOKU_CODE = "syoku_code";
		final String SENMON_CODE = "senmon_code";
		final String LEVEL_CODE = "level_code";
		final String JIKO_T_DO = "jiko_sougou_t_do";
		final String HYOKA_T_DO = "hyokasya_sougou_t_do";
		final int ARRAY_MAX_PREFIX = 3;
		int seqNo = 0;

		for (int i = 1; i <= ARRAY_MAX_PREFIX; i++) {
			if (request.getParameter(SYOKU_CODE + Integer.toString(i)) != null) {
				if (request.getParameter(SYOKU_CODE + Integer.toString(i)).equals("") != true) {
					kouboOubosyaAssessBean = new PEY_KouboOubosyaAssessBean();
					kouboOubosyaAssessBean.setKouboankenid(request.getParameter("koubo_anken_id"));
					kouboOubosyaAssessBean.setSimeino(request.getParameter("simei_no"));
					kouboOubosyaAssessBean.setSeqno(Integer.toString(++seqNo));
					kouboOubosyaAssessBean.setSyokucode(request.getParameter(SYOKU_CODE + Integer.toString(i)));
					kouboOubosyaAssessBean.setSenmoncode(request.getParameter(SENMON_CODE + Integer.toString(i)));
					kouboOubosyaAssessBean.setLevelcode(request.getParameter(LEVEL_CODE + Integer.toString(i)));
					kouboOubosyaAssessBean.setJikosougoutdo(request.getParameter(JIKO_T_DO + Integer.toString(i)));
					kouboOubosyaAssessBean.setHyokasyasougoutdo(request.getParameter(HYOKA_T_DO + Integer.toString(i)));
					ouboBean.addKouboOubosyaAssessBean(kouboOubosyaAssessBean);
				}
			}
		}

		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "OUT", "");

		return ouboBean;
	}

	/**
	 * �G���[��ʂ�\������B
	 */
	private void redirectErrorView(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws ServletException {
		/* ���\�b�h�g���[�X�o�� */
		Log.method(loginuser.getSimeiNo(), "IN", "");

		try {
			this.getServletConfig().getServletContext().getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);

			/* ���\�b�h�g���[�X�o�� */
			Log.method(loginuser.getSimeiNo(), "OUT", "");
		} catch (final IOException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw new RuntimeException(e);
		}
	}
}
