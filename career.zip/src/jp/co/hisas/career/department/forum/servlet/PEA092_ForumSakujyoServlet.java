/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.forum.servlet;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.forum.ejb.PEA_ForumEJB;
import jp.co.hisas.career.department.forum.ejb.PEA_ForumEJBHome;
import jp.co.hisas.career.department.forum.valuebean.PEA_ForumBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PEA092_ForumSakujyoServlet �@�\�����F �t�H�[�����폜�����̐�����s���B
 * 
 * </PRE>
 */
public class PEA092_ForumSakujyoServlet extends PEY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws NamingException, CreateException, PEY_WarningException,
			RemoteException, PEY_WarningException {

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");
		final EJBHomeFactory fact = EJBHomeFactory.getInstance();

		final PEA_ForumEJBHome home = (PEA_ForumEJBHome) fact.lookup(PEA_ForumEJBHome.class);
		final PEA_ForumEJB ejb = home.create();

		/* �폜�Ώۂ̃t�H�[���������擾 */
		final Collection forumList = new ArrayList();
		for (int i = 0; i < Integer.parseInt(request.getParameter("forumCount")); i++) {
			final PEA_ForumBean forumBean = new PEA_ForumBean();
			forumBean.setForumId(request.getParameter("forum_id" + i));
			forumList.add(ejb.forumKensaku(forumBean, loginuser)[0]);
		}

		Log.transaction(loginuser.getSimeiNo(), true, "");
		ejb.forumSakujyo((PEA_ForumBean[]) forumList.toArray(new PEA_ForumBean[0]), loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();

	}
}
