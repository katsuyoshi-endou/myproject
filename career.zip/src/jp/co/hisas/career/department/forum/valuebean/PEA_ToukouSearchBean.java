/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.forum.valuebean;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PEA_ForumSearchBean �N���X �@�\�����F
 * 
 * </PRE>
 */
public class PEA_ToukouSearchBean extends PEA_MasterBean implements Serializable {
	private String forumId = null;

	private String wadaiId = null;

	private String toukouId = null;

	private String daimei = null;

	private String toukouNaiyoMeta = null;

	private String toukouNaiyo = null;

	private String simeiNo = null;

	private String kanjiSimei = null;

	private String syozoku = null;

	private String mail = null;

	private String toukoubi = null;

	private String toukoujikoku = null;

	private String sakujyoFlg = null;

	private String forumMei = null;

	/**
	 * �f�t�H���g�̃R���X�g���N�^�ł��B
	 */
	public PEA_ToukouSearchBean() {
		super();
	}

	/**
	 * ResultSet ����l���擾���ăt�H�[����ValueBean���쐬���܂��B
	 * @param rs �f�[�^�x�[�X�A�N�Z�X�̌���
	 * @param tableName �t�H�[�����e�[�u���̕ʖ�
	 * @throws SQLException SQLException�����������ꍇ
	 */
	public PEA_ToukouSearchBean(final ResultSet rs) throws SQLException {
		super(rs, null);
		Log.debug(this.getIdentifier());

		try {
			this.setForumId(rs.getString(this.getIdentifier() + "forum_id"));
			this.setWadaiId(rs.getString(this.getIdentifier() + "wadai_id"));
			this.setToukouId(rs.getString(this.getIdentifier() + "toukou_id"));
			this.setDaimei(rs.getString(this.getIdentifier() + "daimei"));
			this.setToukouNaiyoMeta(rs.getString(this.getIdentifier() + "toukou_naiyo_meta"));
			this.setToukouNaiyo(rs.getString(this.getIdentifier() + "toukou_naiyo"));
			this.setSimeiNo(rs.getString(this.getIdentifier() + "simei_no"));
			this.setKanjiSimei(rs.getString(this.getIdentifier() + "kanji_simei"));
			this.setSyozoku(rs.getString(this.getIdentifier() + "syozoku"));
			this.setMail(rs.getString(this.getIdentifier() + "mail"));
			this.setToukoubi(rs.getString(this.getIdentifier() + "toukoubi"));
			this.setToukoujikoku(rs.getString(this.getIdentifier() + "toukoujikoku"));
			this.setSakujyoFlg(rs.getString(this.getIdentifier() + "sakujyo_flg"));
			this.setForumMei(rs.getString(this.getIdentifier() + "forum_mei"));
		} catch (final SQLException e) {
			Log.error("", e);
			throw e;
		}
	}

	/**
	 * @return forumMei
	 */
	public String getForumMei() {
		return this.forumMei;
	}

	/**
	 * @param forumMei forumMei ��ݒ肵�܂��B
	 */
	public void setForumMei(final String forumMei) {
		this.forumMei = forumMei;
	}

	/**
	 * @return daimei
	 */
	public String getDaimei() {
		return this.daimei;
	}

	/**
	 * @param daimei daimei ��ݒ肵�܂��B
	 */
	public void setDaimei(final String daimei) {
		this.daimei = daimei;
	}

	/**
	 * @return forumId
	 */
	public String getForumId() {
		return this.forumId;
	}

	/**
	 * @param forumId forumId ��ݒ肵�܂��B
	 */
	public void setForumId(final String forumId) {
		this.forumId = forumId;
	}

	/**
	 * @return kanjiSimei
	 */
	public String getKanjiSimei() {
		return this.kanjiSimei;
	}

	/**
	 * @param kanjiSimei kanjiSimei ��ݒ肵�܂��B
	 */
	public void setKanjiSimei(final String kanjiSimei) {
		this.kanjiSimei = kanjiSimei;
	}

	/**
	 * @return mail
	 */
	public String getMail() {
		return this.mail;
	}

	/**
	 * @param mail mail ��ݒ肵�܂��B
	 */
	public void setMail(final String mail) {
		this.mail = mail;
	}

	/**
	 * @return sakujyoFlg
	 */
	public String getSakujyoFlg() {
		return this.sakujyoFlg;
	}

	/**
	 * @param sakujyoFlg sakujyoFlg ��ݒ肵�܂��B
	 */
	public void setSakujyoFlg(final String sakujyoFlg) {
		this.sakujyoFlg = sakujyoFlg;
	}

	/**
	 * @return simeiNo
	 */
	public String getSimeiNo() {
		return this.simeiNo;
	}

	/**
	 * @param simeiNo simeiNo ��ݒ肵�܂��B
	 */
	public void setSimeiNo(final String simeiNo) {
		this.simeiNo = simeiNo;
	}

	/**
	 * @return syozoku
	 */
	public String getSyozoku() {
		return this.syozoku;
	}

	/**
	 * @param syozoku syozoku ��ݒ肵�܂��B
	 */
	public void setSyozoku(final String syozoku) {
		this.syozoku = syozoku;
	}

	/**
	 * @return toukoubi
	 */
	public String getToukoubi() {
		return this.toukoubi;
	}

	/**
	 * @param toukoubi toukoubi ��ݒ肵�܂��B
	 */
	public void setToukoubi(final String toukoubi) {
		this.toukoubi = toukoubi;
	}

	/**
	 * @return toukouId
	 */
	public String getToukouId() {
		return this.toukouId;
	}

	/**
	 * @param toukouId toukouId ��ݒ肵�܂��B
	 */
	public void setToukouId(final String toukouId) {
		this.toukouId = toukouId;
	}

	/**
	 * @return toukoujikoku
	 */
	public String getToukoujikoku() {
		return this.toukoujikoku;
	}

	/**
	 * @param toukoujikoku toukoujikoku ��ݒ肵�܂��B
	 */
	public void setToukoujikoku(final String toukoujikoku) {
		this.toukoujikoku = toukoujikoku;
	}

	/**
	 * @return toukouNaiyo
	 */
	public String getToukouNaiyo() {
		return this.toukouNaiyo;
	}

	/**
	 * @param toukouNaiyo toukouNaiyo ��ݒ肵�܂��B
	 */
	public void setToukouNaiyo(final String toukouNaiyo) {
		this.toukouNaiyo = toukouNaiyo;
	}

	/**
	 * @return toukouNaiyoMeta
	 */
	public String getToukouNaiyoMeta() {
		return this.toukouNaiyoMeta;
	}

	/**
	 * @param toukouNaiyoMeta toukouNaiyoMeta ��ݒ肵�܂��B
	 */
	public void setToukouNaiyoMeta(final String toukouNaiyoMeta) {
		this.toukouNaiyoMeta = toukouNaiyoMeta;
	}

	/**
	 * @return wadaiId
	 */
	public String getWadaiId() {
		return this.wadaiId;
	}

	/**
	 * @param wadaiId wadaiId ��ݒ肵�܂��B
	 */
	public void setWadaiId(final String wadaiId) {
		this.wadaiId = wadaiId;
	}
}
