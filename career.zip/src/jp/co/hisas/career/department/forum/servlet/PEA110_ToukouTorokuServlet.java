/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.department.forum.servlet;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hisas.career.common.EJBHomeFactory;
import jp.co.hisas.career.department.base.PEY_WarningException;
import jp.co.hisas.career.department.base.servlet.PEY010_ControllerServlet;
import jp.co.hisas.career.department.base.valuebean.PEY_PersonalBean;
import jp.co.hisas.career.department.forum.ejb.PEA_ToukouEJB;
import jp.co.hisas.career.department.forum.ejb.PEA_ToukouEJBHome;
import jp.co.hisas.career.department.forum.valuebean.PEA_ToukouBean;
import jp.co.hisas.career.util.log.Log;

/**
 * <PRE>
 * 
 * �N���X���F PEA110_ToukouTorokuServlet �@�\�����F �t�H�[�����f���̐V�K�b�蓊�e�ƃt�H���[���e�̐�����s���B
 * 
 * </PRE>
 */
public class PEA110_ToukouTorokuServlet extends PEY010_ControllerServlet {

	protected String execute(final HttpServletRequest request, final HttpServletResponse response, final PEY_PersonalBean loginuser) throws NamingException, CreateException, PEY_WarningException,
			RemoteException, PEY_WarningException {

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "IN", "");

		final EJBHomeFactory fact = EJBHomeFactory.getInstance();
		final PEA_ToukouEJBHome home = (PEA_ToukouEJBHome) fact.lookup(PEA_ToukouEJBHome.class);
		final PEA_ToukouEJB ejb = home.create();

		/* �ǉ����铊�e���̐ݒ� */
		final PEA_ToukouBean toukoumBean = new PEA_ToukouBean(request);

		/* �o�^���������s */
		Log.transaction(loginuser.getSimeiNo(), true, "");
		ejb.toukouToroku(toukoumBean, loginuser);
		Log.transaction(loginuser.getSimeiNo(), false, "");

		/* ���\�b�h�g���[�X�o�� */
		Log.method("", "OUT", "");

		return this.getForwardPath();
	}
}
