/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.util.pdf;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;

import jp.co.hisas.career.util.log.Log;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class PZE040_SkillStandardPDF {

	/* ���O�C��No */
	private String login_no;

	/**
	 * �R���X�g���N�^
	 * @param login_no
	 */
	public PZE040_SkillStandardPDF(final String login_no) {
		this.login_no = login_no;
	}

	private String syoku_header;

	private String senmon_header;

	private String level_header;

	private String[] level_name_header;

	private String[][] skill;

	/** �X�L���X�^���_�[�hPDF�̗� */
	private static final float[] PDF_COLUMN_WIDTHS = { 20f, 80f };

	/** ��啪��A���x���̃T�u�e�[�u���̗� */
	private static final float[] SENOMON_LEVEL_TABLE_COMMN_WIDTHS = { 45f, 35f };

	/**
	 * �X�L���X�^���_�[�h�����擾����
	 * @param syoku_header
	 * @param senmon_header
	 * @param level_header
	 * @param level_name_header
	 * @param skill
	 */
	public void setSkill(final String syoku_header, final String senmon_header, final String level_header, final String[] level_name_header, final String[][] skill) {
		this.syoku_header = syoku_header;
		this.senmon_header = senmon_header;
		this.level_header = level_header;
		this.level_name_header = level_name_header;
		this.skill = skill;
	}

	public void executePDF(final OutputStream ops) throws Exception {
		/*
		 * Document�I�u�W�F�N�g�̐��� A4�c�́A Document document = new Document(PageSize.A4); A4���́ADocument document = new Document(PageSize.A4.rotate());
		 */
		final Document document = new Document(PageSize.A4);
		PdfWriter pw = null;

		try {
			/* PdfWriter�I�u�W�F�N�g�̐��� */
			pw = PdfWriter.getInstance(document, ops);
			pw.setCloseStream(true);

			/* �w�i�F */
			final Color BackColor = Color.white;

			/* �h�L�������g��OPEN */
			final HeaderFooter footer = new HeaderFooter(new Phrase("- "), new Phrase(" -"));
			footer.setBorderColor(BackColor);
			footer.setAlignment(Element.ALIGN_CENTER);
			document.setFooter(footer);
			document.open();

			/* �t�H���g�̐ݒ� */
			final float default_font_size = 10;
			final BaseFont bf = BaseFont.createFont("HeiseiMin-W3", "UniJIS-UCS2-HW-H", BaseFont.NOT_EMBEDDED);
			final Font font = new Font(bf, default_font_size, Font.NORMAL);

			/* �������p�t�H���g�ݒ� */
			final Font font_white = new Font(bf, default_font_size, Font.NORMAL);
			font_white.setColor(255, 255, 255);

			/* �R���e���c�̋L�q */
			final PdfPTable pTable = new PdfPTable(PZE040_SkillStandardPDF.PDF_COLUMN_WIDTHS);
			PdfPCell cell = null;

			// Table�����ݒ�

			pTable.setHeaderRows(1);
			pTable.setWidthPercentage(100);
			pTable.setHorizontalAlignment(100);

			// Padding�f�t�H���g�l
			final float defaultPaddingTop = pTable.getDefaultCell().getPaddingTop();
			final float defaultPaddingLeft = pTable.getDefaultCell().getPaddingLeft();
			final float defaultPaddingRight = pTable.getDefaultCell().getPaddingRight();
			final float defaultPaddingButtom = pTable.getDefaultCell().getPaddingBottom();

			/* �w�b�_�[�� */
			final Color headerBgColor = new Color(39, 64, 139);
			// �E��
			cell = new PdfPCell(new Phrase(this.syoku_header, font_white));
			cell.setBackgroundColor(headerBgColor);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			pTable.addCell(cell);

			// ��啪��
			final PdfPTable headerSenmonLevelPTable = new PdfPTable(PZE040_SkillStandardPDF.SENOMON_LEVEL_TABLE_COMMN_WIDTHS);
			cell = new PdfPCell(new Phrase(this.senmon_header, font_white));
			cell.setBackgroundColor(headerBgColor);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			headerSenmonLevelPTable.addCell(cell);
			// ���x��
			final PdfPTable headerLevelPTable = new PdfPTable(1);
			cell = new PdfPCell(new Phrase(this.level_header, font_white));
			cell.setBackgroundColor(headerBgColor);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			headerLevelPTable.addCell(cell);
			// ���x���̊e���x��
			final PdfPTable headerLevelVaulePTable = new PdfPTable(this.level_name_header.length);
			for (int i = 0; i < this.level_name_header.length; i++) {
				cell = new PdfPCell(new Phrase(this.level_name_header[i], font_white));
				cell.setBackgroundColor(headerBgColor);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				headerLevelVaulePTable.addCell(cell);
			}
			// �e���x�������x���ɒǉ�
			headerLevelPTable.getDefaultCell().setPadding(0f);
			headerLevelPTable.addCell(headerLevelVaulePTable);

			// ���x�����啪��E���x���e�[�u���ɒǉ�
			headerSenmonLevelPTable.getDefaultCell().setPadding(0f);
			headerSenmonLevelPTable.addCell(headerLevelPTable);

			// ��啪��E���x�����o�̓e�[�u���ɒǉ�
			pTable.getDefaultCell().setPadding(0f);
			pTable.addCell(headerSenmonLevelPTable);

			// Padding���f�t�H���g�l�ɖ߂�
			pTable.getDefaultCell().setPaddingTop(defaultPaddingTop);
			pTable.getDefaultCell().setPaddingLeft(defaultPaddingLeft);
			pTable.getDefaultCell().setPaddingRight(defaultPaddingRight);
			pTable.getDefaultCell().setPaddingBottom(defaultPaddingButtom);

			// �f�[�^��
			final Color dataBgColor = new Color(255, 255, 255);
			final Color dataLevelColor = new Color(124, 125, 191);

			/*
			 * �E��̐������s���쐬 ��啪��̐�������啪��̓���q�e�[�u���̍s���쐬 ��啪��̐��������x���̓���q�e�[�u�����쐬
			 */
			for (int i = 0; i < this.skill.length; i++) {
				// �Ǝ햼
				cell = new PdfPCell(new Phrase(this.skill[i][1], font));
				cell.setBackgroundColor(dataBgColor);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				pTable.addCell(cell);

				final PdfPTable senmonLevelPTable = new PdfPTable(PZE040_SkillStandardPDF.SENOMON_LEVEL_TABLE_COMMN_WIDTHS);
				final int tempi = i;
				for (int count = 0; i < this.skill.length && (count == 0 || this.skill[i][0].equals(this.skill[i - 1][0])); i++) {
					count++;

					// ��啪�얼
					cell = new PdfPCell(new Phrase(this.skill[i][3], font));
					cell.setBackgroundColor(dataBgColor);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
					senmonLevelPTable.addCell(cell);

					// ���x��
					final PdfPTable dataLevelValuePTable = new PdfPTable(this.level_name_header.length);
					for (int m = 4; m < this.level_name_header.length + 4; m++) {
						cell = new PdfPCell(new Phrase("�@", font));
						/* ���x�������݂���ꍇ */
						if (this.skill[i][m].equals("1")) {
							cell.setBackgroundColor(dataLevelColor);
						} else {
							cell.setBackgroundColor(dataBgColor);
						}
						dataLevelValuePTable.addCell(cell);
					}
					senmonLevelPTable.getDefaultCell().setPadding(0);
					senmonLevelPTable.addCell(dataLevelValuePTable);
				}

				if (tempi < i) {
					i--;
				}

				// ��啪��A���x���̒ǉ�
				pTable.getDefaultCell().setPadding(0);
				pTable.addCell(senmonLevelPTable);

				// Padding���f�t�H���g�l�ɖ߂�
				pTable.getDefaultCell().setPaddingTop(defaultPaddingTop);
				pTable.getDefaultCell().setPaddingLeft(defaultPaddingLeft);
				pTable.getDefaultCell().setPaddingRight(defaultPaddingRight);
				pTable.getDefaultCell().setPaddingBottom(defaultPaddingButtom);
			}

			// �h�L�������g�ɏo�̓e�[�u����ǉ�
			document.add(pTable);

		} catch (final BadElementException e) {
			Log.error(this.login_no, e);
			throw e;
		} catch (final DocumentException e) {
			Log.error(this.login_no, e);
			throw e;
		} catch (final IOException e) {
			Log.error(this.login_no, e);
			throw e;
		} catch (final Exception e) {
			Log.error(this.login_no, e);
			throw e;
		} finally {
			/* �h�L�������g����� */
			if (document != null) {
				try {
					document.close();
				} catch (final Exception e) {
					Log.error(this.login_no, e);
					throw e;
				}
			}
			if (pw != null) {
				try {
					pw.close();
				} catch (final Exception e) {
					Log.error(this.login_no, e);
					throw e;
				}
			}
		}
	}
}
