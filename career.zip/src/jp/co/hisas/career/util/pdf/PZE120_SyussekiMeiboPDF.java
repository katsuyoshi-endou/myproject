/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.util.pdf;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;

import jp.co.hisas.career.learning.base.valuebean.PCY_ClassBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_PersonalBean;
import jp.co.hisas.career.learning.base.valuebean.PCY_TaisyosyaBean;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;
import jp.co.hisas.career.util.property.ReadFile;

import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfWriter;

public class PZE120_SyussekiMeiboPDF {

	/**
	 * �o�ȎҖ���̂o�c�e���쐬����
	 * @param os �o�̓X�g���[��
	 * @param classBean �N���X�i�[�I�u�W�F�N�g
	 * @param taisyosyaBeans �ΏێҊi�[�I�u�W�F�N�g
	 * @param sosikiMei �g�D���i�[�z��
	 * @param loginuser ���O�C�����[�U���i�[�I�u�W�F�N�g
	 * @return �����̏ꍇ�Ftrue�A���s�̏ꍇ�Ffalse
	 * @exception DocumentException
	 * @exception IOException
	 */
	public boolean makePDF(final OutputStream os, final PCY_ClassBean classBean, final PCY_TaisyosyaBean[] taisyosyaBeans, final String[] sosikiMei, final PCY_PersonalBean loginuser)
			throws DocumentException, IOException {
		Log.method(loginuser.getSimeiNo(), "IN", "");

		/*
		 * Document�I�u�W�F�N�g�̐��� A4�c�́ADocument document = new Document(PageSize.A4); A4���́ADocument document = new Document(PageSize.A4.rotate());
		 */
		final Document document = new Document(PageSize.A4, 20, 20, 20, 20);
		PdfWriter pw = null;
		Table table;
		try {
			/* PdfWriter�I�u�W�F�N�g�̐��� */
			pw = PdfWriter.getInstance(document, os);
			pw.setCloseStream(true);

			/* �t�H���g�̐ݒ� */
			final float defaultFontSize = 8;
			final BaseFont baseFont = BaseFont.createFont("HeiseiKakuGo-W5", "UniJIS-UCS2-HW-H", false);
			final Font japanese = new Font(baseFont, defaultFontSize);

			final Color tableHeaderColor = new Color(110, 150, 255);

			/* �t�b�^�[�ɏo�͂�����t�̎擾 */
			final String date = PZZ010_CharacterUtil.getPrintDate();

			/* �t�b�^�[�̐ݒ� */
			final HeaderFooter footer = new HeaderFooter(new Paragraph((String) ReadFile.paramMapData.get("DZZ400") + (String) ReadFile.paramMapData.get("DZZ431") + date, japanese), false);
			footer.setAlignment(Element.ALIGN_RIGHT);
			footer.setBorder(Rectangle.TOP);
			document.setFooter(footer);

			/* �h�L�������g��OPEN */
			document.open();

			/*
			 * �^�C�g��
			 */
			/* �e�[�u����̕� */
			final int[] rowWidthsTitle = { 100 };

			/* �e�[�u���쐬 */
			table = PZZ010_CharacterUtil.createNewTable(100, rowWidthsTitle, Table.ALIGN_CENTER, Table.ALIGN_LEFT);

			/* �g�������� */
			table.setBorderColor(Color.WHITE);
			table.setDefaultCellBorderColor(Color.WHITE);

			/* �o�ȎҖ��� */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ415"), new Font(baseFont, 20))));

			/* �e�[�u���쐬�I�� */
			document.add(table);

			/* ��s��}�� */
			document.add(new Phrase(HcdbDef.CR_CODE));

			/*
			 * ���C���\��
			 */
			/* �e�[�u����̕� */
			final int[] rowWidthsKensyu = { 50, 22, 28 };

			/* �e�[�u���쐬 */
			table = PZZ010_CharacterUtil.createNewTable(100, rowWidthsKensyu, Table.ALIGN_LEFT, Table.ALIGN_LEFT);

			/* �g�������� */
			table.setBorderColor(Color.WHITE);
			table.setDefaultCellBorderColor(Color.WHITE);

			final String kamokuMei = classBean.getKamokuBean().getKamokuMei1();
			final String kamokuCode = classBean.getKamokuBean().getKamokuCode();
			String yobi1 = classBean.getKamokuBean().getYobi1();
			String yobi2 = classBean.getKamokuBean().getYobi2();
			String kaisibi = classBean.getKaisibi();
			String syuryobi = classBean.getSyuryobi();
			String kaisijikoku = classBean.getKaisijikoku();
			String syuryojikoku = classBean.getSyuryojikoku();
			final String classMei = classBean.getClassMei();
			String chikuMei = classBean.getChikuMei();
			String kyosituMei = classBean.getKyosituMei();
			String kousiMei = classBean.getKousiMei();

			if (kaisibi.length() == 8) {
				kaisibi = kaisibi.substring(0, 4) + "/" + kaisibi.substring(4, 6) + "/" + kaisibi.substring(6, 8);
			}
			if (syuryobi.length() == 8) {
				syuryobi = syuryobi.substring(0, 4) + "/" + syuryobi.substring(4, 6) + "/" + syuryobi.substring(6, 8);
			}
			if (kaisijikoku != null && kaisijikoku.length() == 4) {
				kaisijikoku = kaisijikoku.substring(0, 2) + ":" + kaisijikoku.substring(2, 4);
			}
			if (syuryojikoku != null && syuryojikoku.length() == 4) {
				syuryojikoku = syuryojikoku.substring(0, 2) + ":" + syuryojikoku.substring(2, 4);
			}
			if (yobi1 == null) {
				yobi1 = "";
			}
			if (yobi2 == null) {
				yobi2 = "";
			}
			if (chikuMei == null) {
				chikuMei = "";
			}
			if (kyosituMei == null) {
				kyosituMei = "";
			}
			if (kousiMei == null) {
				kousiMei = "";
			}

			/* ���C�� */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ078") + "�F�@" + kamokuMei, new Font(baseFont, 10))));

			/* ���C�R�[�h */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ076") + "�F�@" + kamokuCode, japanese)));

			/* ��Z�� */
			table.addCell(new Cell(new Phrase("")));

			/* ��Z�� */
			table.addCell(new Cell(new Phrase("")));

			/* BET ID */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ301") + "�F�@" + yobi1, japanese)));

			/* ��Z�� */
			table.addCell(new Cell(new Phrase("")));

			/* ��Z�� */
			table.addCell(new Cell(new Phrase("")));

			/* Abbreviation */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ302") + "�F�@" + yobi2, japanese)));

			/* ��Z�� */
			table.addCell(new Cell(new Phrase("")));

			/* �J�Ó� */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ303") + "�F�@" + kaisibi + "�`" + syuryobi, japanese)));

			/* �J�n���� */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ306") + "�F�@" + kaisijikoku, japanese)));

			/* �I������ */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ307") + "�F�@" + syuryojikoku, japanese)));

			/* �N���X */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ077") + "�F�@" + classMei, japanese)));

			table.addCell(new Cell(new Phrase("")));

			table.addCell(new Cell(new Phrase("")));

			/* �J�Ïꏊ */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ312") + "�F�@" + chikuMei, japanese)));

			/* ���� */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ313") + "�F�@" + kyosituMei, japanese)));

			/* �u�t */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ316") + "�F�@" + kousiMei, japanese)));

			/* �e�[�u���쐬�I�� */
			document.add(table);

			/*
			 * ����
			 */
			/* �e�[�u����̕� */
			final int[] rowWidthsMeibo = { 50, 10, 12, 15, 13 };

			/* �e�[�u���쐬 */
			table = PZZ010_CharacterUtil.createNewTable(100, rowWidthsMeibo, Table.ALIGN_LEFT, Table.ALIGN_CENTER);

			/* �Z���̐F���w�� */
			table.setDefaultCellBackgroundColor(tableHeaderColor);

			/* ���� */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ007"), japanese)));

			/* Emp.No. */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ002"), japanese)));

			/* ���� */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ001"), japanese)));

			/* NAME */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ005"), japanese)));

			/* �o���i��u���j */
			table.addCell(new Cell(new Phrase((String) ReadFile.paramMapData.get("DZZ416"), japanese)));

			/* �w�b�_�[���I�� */
			table.endHeaders();

			/* �Z���̐F���w�� */
			table.setDefaultCellBackgroundColor(Color.WHITE);

			/* �f�[�^���쐬 */
			for (int i = 0; i < taisyosyaBeans.length; i++) {
				String simeiNo = "";
				String kanjiSimei = "";
				String eigoSimei = "";

				if (taisyosyaBeans[i].getSimeiNo() != null) {
					simeiNo = taisyosyaBeans[i].getSimeiNo();
				}

				if (taisyosyaBeans[i].getKanjiSimei() != null) {
					kanjiSimei = taisyosyaBeans[i].getKanjiSimei();
				}

				if (taisyosyaBeans[i].getEigoSimei() != null) {
					eigoSimei = taisyosyaBeans[i].getEigoSimei();
				}

				/* ������ */
				table.addCell(new Cell(new Phrase(sosikiMei[i], japanese)));

				/* Emp.No */
				table.addCell(new Cell(new Phrase(simeiNo, japanese)));

				/* ���� */
				table.addCell(new Cell(new Phrase(kanjiSimei, japanese)));

				/* �p������ */
				table.addCell(new Cell(new Phrase(eigoSimei, japanese)));

				/* �� */
				table.addCell(new Cell(new Phrase("")));
			}

			/* �e�[�u���쐬�I�� */
			document.add(table);

			Log.method(loginuser.getSimeiNo(), "OUT", "");
		} catch (final DocumentException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} catch (final IOException e) {
			Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
			throw e;
		} finally {
			/* �h�L�������g����� */
			if (document != null) {
				try {
					document.close();
				} catch (final Exception e) {
					Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
				}
			}

			if (pw != null) {
				try {
					pw.close();
				} catch (final Exception e) {
					Log.error(loginuser != null ? loginuser.getSimeiNo() : "", e);
				}
			}
		}

		return true;
	}
}
