/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.util.property.ejb;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.HashMap;

import javax.ejb.EJBObject;
import javax.naming.NamingException;

public interface CommonParameterEJB extends EJBObject {

	/**
	 * �ėp�p�����[�^�̑S�Ă̒l���擾����B
	 */
	public HashMap find() throws NamingException, SQLException, RemoteException;

}
