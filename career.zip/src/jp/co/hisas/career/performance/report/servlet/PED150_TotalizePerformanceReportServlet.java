/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.report.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hisas.career.base.userinfo.bean.UserInfoBean;
import jp.co.hisas.career.performance.maintenance.bean.PED_QuestionnaireAnkenKanriBean;
import jp.co.hisas.career.performance.report.bean.PED_TotalizePerformanceReportBean;
import jp.co.hisas.career.performance.report.bean.PED_TotalizePerformanceReportBeanThread;
import jp.co.hisas.career.performance.report.bean.PED_TotalizePerformanceReportPDFThread;
import jp.co.hisas.career.performance.report.bean.PED_TotalizePerformanceReportValueBean;
import jp.co.hisas.career.performance.util.bean.PED_BatchExclusiveLogic;
import jp.co.hisas.career.performance.util.bean.PED_PerformanceBean;
import jp.co.hisas.career.util.common.ExclusiveManager;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.ReadFile;

/**
 * �W�v�E����T�[�u���b�g
 * @author Kobayashi
 */
public class PED150_TotalizePerformanceReportServlet extends HttpServlet {

	/** �G���[�y�[�W */
	private static final String ERROR_PAGE = "/view/base/error/VYY_Error.jsp";

	/** �J�ڐ�y�[�W */
	private static final String SUCCESS_PAGE = "/view/performance/report/VED150_TotalizePerformanceReportMain.jsp";

	/** �߂��y�[�W */
	private static final String BACK_PAGE = "/view/performance/maintenance/VED110_QuestionnaireAnkenKanriFrame.jsp";

	/** ServletContext�I�u�W�F�N�g */
	private ServletContext ctx = null;

	/** �A�N�V������ێ����邽�߂̃L�[ */
	private static final String ACTION_KEY = "ACTION_KEY";

	/** �W�v�Ώۂ̑S�Ă̏������W�v����`�F�b�N�{�b�N�X�̒l */
	private static final String ALL_SOSHIKI = "on";

	/** ���[�_�̎����ݒ� */
	private static final String AUTO_LEADER = "RADIO";

	/** �I������ */
	private static final String CHOICE_SOSHIKI = "selectSoshikiID";

	/** �o�b�`������� */
	private static final String TYPE_LEADER = "Leader";

	private static final String TYPE_ERROR = "ErrorCheck";

	private static final String TYPE_SHUKEI = "Shukei";

	private static final String TYPE_TORIKESHI = "ShukeiTorikeshi";

	private static final String TYPE_REPORT = "Report";

	/** �G���[�e�[�u����� */
	private static final String TYPE_CSV_LEADER = "P11";

	private static final String TYPE_CSV_ERROR = "P12";

	private static final String TYPE_CSV_SHUKEI = "P13";

	private static final String TYPE_CSV_TORIKESHI = "P14";

	private static final String TYPE_CSV_REPORT = "P15";

	/** ���{��G���R�[�h */
	public static final String JAPANESE_ENCODING = "Windows-31J";

	/** UNICODE�G���R�[�h */
	public static final String UNICODE_ENCODING = "ISO-8859-1";

	/** PL/SQL���ŗ\�����ʃG���[�����������ꍇ�̖߂�l */
	private static final int SQL_ERROR = -1;

	/** �o�b�`���s���X�e�[�^�X */
	private static final int BATCH_START = 2;

	/** �G���[CSV�t�@�C������ */
	public static final String LEADER_ERROR_CSV_FILE_NAME = "LeaderError.csv";

	public static final String CHECK_ERROR_CSV_FILE_NAME = "CheckError.csv";

	public static final String SHUKEI_ERROR_CSV_FILE_NAME = "ShukeiError.csv";

	public static final String REPORT_ERROR_CSV_FILE_NAME = "ReportError.csv";

	/**
	 * �������������s���B
	 * @param config
	 * @throws javax.servlet.ServletException
	 * @see javax.servlet.Servlet#init(javax.servlet.ServletConfig)
	 */
	public void init(final ServletConfig config) throws ServletException {
		super.init(config);

		// ���\�b�h�g���[�X�o��
		Log.method("", "IN", "");

		synchronized (this) {
			if (this.ctx == null) {
				this.ctx = config.getServletContext();
			}
		}
		// ���\�b�h�g���[�X�o��
		Log.method("", "OUT", "");
	}

	/**
	 * �u���E�U����̌����v�����󂯎��A�{�N���X�̎��s���\�b�h���Ăяo���܂��B
	 * @param request ���N�G�X�g
	 * @param response ���X�|���X
	 * @throws ServletException �T�[�u���b�g��O
	 * @throws IOException ���o�͗�O
	 * @see javax.servlet.http.HttpServlet#service( javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse )
	 */
	public void service(final HttpServletRequest request, final HttpServletResponse response) throws IOException, ServletException {

		final HttpSession session = request.getSession(false);

		String pageUrl = PED150_TotalizePerformanceReportServlet.SUCCESS_PAGE;
		// �Z�b�V�����A�܂���userinfo���擾�ł��Ȃ��ꍇ�A�G���[�y�[�W�֑J��
		if (session == null || (UserInfoBean) session.getAttribute("userinfo") == null) {
			this.ctx.getRequestDispatcher(PED150_TotalizePerformanceReportServlet.ERROR_PAGE).forward(request, response);
		} else {

			String loginNo = null;
			try {

				// �V�X�e�����t���擾
				final String sysdate = PZZ010_CharacterUtil.GetDay();
				final String systime = PZZ010_CharacterUtil.GetTime();

				final UserInfoBean userinfo = (UserInfoBean) session.getAttribute("userinfo");

				// ���O�C�����[�U�擾
				loginNo = userinfo.getLogin_no();

				Log.performance(loginNo, true, "");

				// �Z�b�V�������擾
				PED_PerformanceBean performanceBean = (PED_PerformanceBean) session.getAttribute(PED_PerformanceBean.SESSION_KEY);

				// �g�pBean
				PED_TotalizePerformanceReportValueBean valueBean = new PED_TotalizePerformanceReportValueBean();
				final PED_QuestionnaireAnkenKanriBean ped = new PED_QuestionnaireAnkenKanriBean(loginNo);

				// performanceBean���擾�ł��Ȃ�����
				if (performanceBean == null) {
					performanceBean = new PED_PerformanceBean();
				}

				// �A���P�[�g�ԍ��擾
				final String enqueteNo = performanceBean.getEnqueteNo();
				// �A���P�[�g���̎擾
				final String enqueteNm = performanceBean.getEnqueteNm();
				valueBean = performanceBean.getReportBean();
				if (valueBean == null) {
					valueBean = new PED_TotalizePerformanceReportValueBean();
				}
				// ��ʏ��̎擾
				final Map userAction = request.getParameterMap();
				// ���[�U�̃A�N�V�������擾
				final String[] actionTmp = (String[]) userAction.get(PED150_TotalizePerformanceReportServlet.ACTION_KEY);
				int action = -1;
				if (actionTmp != null) {
					action = new Integer(actionTmp[0]).intValue();
				}
				// ��ʏ��̕ێ�
				if (action != PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_BATCH && action != PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_BATCH_END) {
					valueBean = this.setGamenValue(userAction, valueBean);
				}
				final PED_TotalizePerformanceReportBean bean = new PED_TotalizePerformanceReportBean();

				// �A���P�[�g�X�e�[�^�X�擾
				final HashMap map = bean.getEnqueteStatus(loginNo, enqueteNo, session.getId());

				// �A���P�[�g��ԏ�񂪎擾�ł����ꍇ
				if (map.containsKey("enqueteNo")) {
					valueBean.setErrorCheckCsv(((Boolean) map.get("isErrorCheckCsv")).booleanValue());
					valueBean.setLeaderErrorCsv(((Boolean) map.get("isLeaderErrorCsv")).booleanValue());
					valueBean.setShukeiErrorCsv(((Boolean) map.get("isShukeiErrorCsv")).booleanValue());
					valueBean.setErrorCheckStatus((String) map.get("errorCheckStatus"));
					valueBean.setLeaderStatus((String) map.get("leaderStatus"));
					valueBean.setStatus((String) map.get("shukeiStatus"));
				} else {
					valueBean.setErrorCheckCsv(false);
					valueBean.setLeaderErrorCsv(false);
					valueBean.setShukeiErrorCsv(false);
					valueBean.setErrorCheckStatus("");
					valueBean.setLeaderStatus("");
					valueBean.setStatus("");
				}

				// ���[�_�[�ݒ�{�^��������
				if (action == PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_LEADER) {

					PED_TotalizePerformanceReportBeanThread.setUserSession(null);
					final String status = ped.getStatus(enqueteNo);
					if (!ExclusiveManager.getInstance().getExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY)) {
						valueBean.setErrorMsg((String) ReadFile.messageMapData.get("CPM-VED150-E033"));
					} else if (!(status.equals("1") || status.equals("2"))) {
						try {
							valueBean.setErrorMsg((String) ReadFile.messageMapData.get("CPM-VED150-E001"));
						} finally {
							ExclusiveManager.getInstance().releaseExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY);
						}
					} else {
						try {
							PED_TotalizePerformanceReportBeanThread.setJotaiFlg(session.getId(), String.valueOf(PED150_TotalizePerformanceReportServlet.BATCH_START));
							bean.executeLeader(loginNo, session.getId(), enqueteNo, valueBean.isAutoLeader());
							bean.createBatchStatusStart(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_LEADER);
							valueBean.setBatchStatus(PED_TotalizePerformanceReportValueBean.BATCH_STATUS_BATCH_START);
							valueBean.setBatchAction(PED_TotalizePerformanceReportValueBean.BATCH_ACTION_LEADER);
							valueBean.setBatchStartMessage(valueBean.getBatchAction());
						} catch (final Exception e) {
							ExclusiveManager.getInstance().releaseExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY);
							throw e;
						}
					}
				}
				// �G���[CSV�o�̓{�^��������(���[�_�[�ݒ�)
				else if (action == PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_ERROR_CSV1) {
					// �G���[CSV���擾
					final String csvData = bean.errorCsvDownload(enqueteNo, loginNo, session.getId(), new String[] { PED150_TotalizePerformanceReportServlet.TYPE_CSV_LEADER });

					/* �G���[CSV�t�@�C�����o�� */
					final PrintWriter out = response.getWriter();
					response.setContentType("application/csv");

					String filename = sysdate + systime + PED150_TotalizePerformanceReportServlet.LEADER_ERROR_CSV_FILE_NAME;
					filename = new String(filename.getBytes(PED150_TotalizePerformanceReportServlet.JAPANESE_ENCODING), PED150_TotalizePerformanceReportServlet.UNICODE_ENCODING);
					response.setHeader("Content-Disposition", "attachment; filename=" + filename);

					/* ���e��UNICODE�ɕϊ� */
					final String str = new String(csvData.getBytes(PED150_TotalizePerformanceReportServlet.JAPANESE_ENCODING), PED150_TotalizePerformanceReportServlet.UNICODE_ENCODING);

					out.write(str);
					out.close();
					response.flushBuffer();
					return;
				}
				// �G���[�`�F�b�N�{�^��������
				else if (action == PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_ERROR_CHECK) {

					PED_TotalizePerformanceReportBeanThread.setUserSession(null);
					if (!ExclusiveManager.getInstance().getExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY)) {
						valueBean.setErrorMsg((String) ReadFile.messageMapData.get("CPM-VED150-E034"));
					} else {
						try {
							PED_TotalizePerformanceReportBeanThread.setJotaiFlg(session.getId(), String.valueOf(PED150_TotalizePerformanceReportServlet.BATCH_START));
							bean.executeErrorCheck(loginNo, session.getId(), enqueteNo);
							bean.createBatchStatusStart(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_ERROR);
							valueBean.setBatchStatus(PED_TotalizePerformanceReportValueBean.BATCH_STATUS_BATCH_START);
							valueBean.setBatchAction(PED_TotalizePerformanceReportValueBean.BATCH_ACTION_ERROR);
							valueBean.setBatchStartMessage(valueBean.getBatchAction());
						} catch (final Exception e) {
							ExclusiveManager.getInstance().releaseExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY);
							throw e;
						}
					}
				}
				// �G���[CSV�o�̓{�^��������(�G���[�`�F�b�N)
				else if (action == PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_ERROR_CSV2) {
					// �G���[CSV���擾
					final String csvData = bean.errorCsvDownload(enqueteNo, loginNo, session.getId(), new String[] { PED150_TotalizePerformanceReportServlet.TYPE_CSV_ERROR });

					/* �G���[CSV�t�@�C�����o�� */
					final PrintWriter out = response.getWriter();
					response.setContentType("application/csv");
					/* �t�@�C������UNICODE�ɕϊ� */

					String filename = sysdate + systime + PED150_TotalizePerformanceReportServlet.CHECK_ERROR_CSV_FILE_NAME;
					filename = new String(filename.getBytes(PED150_TotalizePerformanceReportServlet.JAPANESE_ENCODING), PED150_TotalizePerformanceReportServlet.UNICODE_ENCODING);
					response.setHeader("Content-Disposition", "attachment; filename=" + filename);

					/* ���e��UNICODE�ɕϊ� */
					final String str = new String(csvData.getBytes(PED150_TotalizePerformanceReportServlet.JAPANESE_ENCODING), PED150_TotalizePerformanceReportServlet.UNICODE_ENCODING);

					out.write(str);
					out.close();
					response.flushBuffer();
					return;
				}
				// �I���{�^��������
				else if (action == PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_CHOICE) {
					final ArrayList choicedList = new ArrayList();
					// �ꌏ�I��
					try {
						final String choiceSoshiki = (String) userAction.get(PED150_TotalizePerformanceReportServlet.CHOICE_SOSHIKI);

					} catch (final Exception e) {
						// �����I��
						final String[] choiceSoshiki = (String[]) userAction.get(PED150_TotalizePerformanceReportServlet.CHOICE_SOSHIKI);
						for (int i = 0, num = choiceSoshiki.length; i < num; i++) {
							choicedList.add(choiceSoshiki[i]);
						}
					}
					final ArrayList tmp = valueBean.getChoiceSoshikiID();
					for (int i = 0, num = tmp.size(); i < num; i++) {
						final HashMap choiced = new HashMap((HashMap) tmp.get(i));
						choicedList.add(choiced.get("id"));
					}
					// �\�[�g����
					valueBean.setChoiceSoshikiID(bean.getShozokuSort(loginNo, choicedList, enqueteNo));

				}
				// �I�������{�^��������
				else if (action == PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_CHOICE_RELEASE) {
					final ArrayList selectedList = new ArrayList();
					final ArrayList tmp = valueBean.getChoiceSoshikiID();
					final ArrayList delList = new ArrayList();
					// �ꌏ�I��
					try {
						final String choiceSoshiki = (String) userAction.get("selectedSoshikiID");
						delList.add(choiceSoshiki);
					} catch (final Exception e) {
						// �����I��
						final String[] choiceSoshiki = (String[]) userAction.get("selectedSoshikiID");
						for (int j = 0, jNum = choiceSoshiki.length; j < jNum; j++) {
							delList.add(choiceSoshiki[j]);
						}
					}
					for (int i = 0, num = tmp.size(); i < num; i++) {
						final HashMap selected = new HashMap((HashMap) tmp.get(i));
						final String id = (String) selected.get("id");

						boolean isDel = false;
						for (int j = 0, jNum = delList.size(); j < jNum; j++) {
							if (id.equals(delList.get(j))) {
								isDel = true;
							}
						}
						if (!isDel) {
							selectedList.add(selected);
						}

					}
					valueBean.setChoiceSoshikiID(selectedList);
				}
				// �W�v�{�^��������
				else if (action == PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_TOTALISE) {

					PED_TotalizePerformanceReportBeanThread.setUserSession(null);
					final String status = ped.getStatus(enqueteNo);

					// �A���P�[�g��Ԏ擾
					final ArrayList enqueteStatus = ped.searchQuestionnaire(enqueteNo, "", null, "", "");
					final String[] statusArray = (String[]) enqueteStatus.get(0);
					// �o�b�`���s��
					if (!ExclusiveManager.getInstance().getExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY)) {
						valueBean.setErrorMsg((String) ReadFile.messageMapData.get("CPM-VED150-E035"));
						// �X�e�[�^�X��2,3�ȊO
					} else if (!("3".equals(status) || "2".equals(status))) {
						try {
							valueBean.setErrorMsg((String) ReadFile.messageMapData.get("CPM-VED150-E002"));
						} finally {
							ExclusiveManager.getInstance().releaseExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY);
						}
						// �p�t�H�[�}���X���͑ΏۂłȂ�
					} else if (!statusArray[8].equals("1")) {
						try {
							valueBean.setErrorMsg((String) ReadFile.messageMapData.get("CPM-VED150-E004"));
						} finally {
							ExclusiveManager.getInstance().releaseExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY);
						}
					} else {
						try {
							if (userAction.containsKey(PED150_TotalizePerformanceReportServlet.ALL_SOSHIKI)) {
								bean.executeShukei(loginNo, session.getId(), bean.getShozokuSort(loginNo, this.sortList(valueBean.getSoshikiList()), enqueteNo), enqueteNo);
							} else {

								bean.executeShukei(loginNo, session.getId(), valueBean.getChoiceSoshikiID(), enqueteNo);
							}
							PED_TotalizePerformanceReportBeanThread.setJotaiFlg(session.getId(), String.valueOf(PED150_TotalizePerformanceReportServlet.BATCH_START));
							bean.createBatchStatusStart(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_SHUKEI);
							valueBean.setBatchStatus(PED_TotalizePerformanceReportValueBean.BATCH_STATUS_BATCH_START);
							valueBean.setBatchAction(PED_TotalizePerformanceReportValueBean.BATCH_ACTION_SHUKEI);
							valueBean.setBatchStartMessage(valueBean.getBatchAction());
						} catch (final Exception e) {
							ExclusiveManager.getInstance().releaseExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY);
							throw e;
						}
					}
				}
				// �W�v����{�^��������
				else if (action == PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_TOTALISE_RELEASE) {

					PED_TotalizePerformanceReportBeanThread.setUserSession(null);
					if (!ExclusiveManager.getInstance().getExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY)) {
						valueBean.setErrorMsg((String) ReadFile.messageMapData.get("CPM-VED150-E036"));
					} else if (!ped.getStatus(enqueteNo).equalsIgnoreCase("3")) {
						try {
							valueBean.setErrorMsg((String) ReadFile.messageMapData.get("CPM-VED150-E003"));
						} finally {
							ExclusiveManager.getInstance().releaseExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY);
						}
					} else {
						try {
							PED_TotalizePerformanceReportBeanThread.setJotaiFlg(session.getId(), String.valueOf(PED150_TotalizePerformanceReportServlet.BATCH_START));
							bean.executeShukeiTorikeshi(loginNo, session.getId(), enqueteNo);
							bean.createBatchStatusStart(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_TORIKESHI);
							valueBean.setBatchStatus(PED_TotalizePerformanceReportValueBean.BATCH_STATUS_BATCH_START);
							valueBean.setBatchAction(PED_TotalizePerformanceReportValueBean.BATCH_ACTION_TORIKESHI);
							valueBean.setBatchStartMessage(valueBean.getBatchAction());
						} catch (final Exception e) {
							ExclusiveManager.getInstance().releaseExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY);
							throw e;
						}
					}
				}
				// ���|�[�g�쐬�{�^��������
				else if (action == PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_REPORT) {
					final String status = ped.getStatus(enqueteNo);
					if (!ExclusiveManager.getInstance().getExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY)) {
						valueBean.setErrorMsg((String) ReadFile.messageMapData.get("CPM-VED150-E040"));
					} else if (!(status.equals("2") || status.equals("3"))) {
						try {
							valueBean.setErrorMsg((String) ReadFile.messageMapData.get("CPM-VED150-E039"));
						} finally {
							ExclusiveManager.getInstance().releaseExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY);
						}
					} else {
						try {
							PED_TotalizePerformanceReportPDFThread.setJotaiFlg(session.getId(), String.valueOf(PED150_TotalizePerformanceReportServlet.BATCH_START));
							if (userAction.containsKey(PED150_TotalizePerformanceReportServlet.ALL_SOSHIKI)) {
								bean.makeReportPDF(loginNo, session.getId(), enqueteNo, enqueteNm, bean.getShozokuSort(loginNo, this.sortList(valueBean.getSoshikiList()), enqueteNo),
										PED150_TotalizePerformanceReportServlet.TYPE_REPORT);
							} else {
								bean.makeReportPDF(loginNo, session.getId(), enqueteNo, enqueteNm, valueBean.getChoiceSoshikiID(), PED150_TotalizePerformanceReportServlet.TYPE_REPORT);
							}
							final String test = PED_TotalizePerformanceReportPDFThread.getJotaiFlg(session.getId());
							bean.createBatchStatusStart(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_REPORT);
							valueBean.setBatchStatus(PED_TotalizePerformanceReportValueBean.BATCH_STATUS_BATCH_START);
							valueBean.setBatchAction(PED_TotalizePerformanceReportValueBean.BATCH_ACTION_REPORT);
							valueBean.setBatchStartMessage(valueBean.getBatchAction());
						} catch (final Exception e) {
							ExclusiveManager.getInstance().releaseExclusiveLock(PED_BatchExclusiveLogic.getInstance(), PED_BatchExclusiveLogic.LOCK_KEY);
							throw e;
						}
					}
				}
				// �G���[CSV�{�^��������(�W�v�A�W�v����A���|�[�g)
				else if (action == PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_ERROR_CSV3) {
					// �G���[CSV���擾
					final String csvData = bean.errorCsvDownload(enqueteNo, loginNo, session.getId(), new String[] {
							PED150_TotalizePerformanceReportServlet.TYPE_CSV_SHUKEI,
							PED150_TotalizePerformanceReportServlet.TYPE_CSV_TORIKESHI,
							PED150_TotalizePerformanceReportServlet.TYPE_CSV_REPORT });

					/* �G���[CSV�t�@�C�����o�� */
					final PrintWriter out = response.getWriter();
					response.setContentType("application/csv");

					final boolean shukeiError = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_SHUKEI, session.getId());
					String filename = sysdate + systime + PED150_TotalizePerformanceReportServlet.REPORT_ERROR_CSV_FILE_NAME;
					if (shukeiError) {
						filename = sysdate + systime + PED150_TotalizePerformanceReportServlet.SHUKEI_ERROR_CSV_FILE_NAME;
					}
					/* �t�@�C������UNICODE�ɕϊ� */

					filename = new String(filename.getBytes(PED150_TotalizePerformanceReportServlet.JAPANESE_ENCODING), PED150_TotalizePerformanceReportServlet.UNICODE_ENCODING);
					response.setHeader("Content-Disposition", "attachment; filename=" + filename);

					/* ���e��UNICODE�ɕϊ� */
					final String str = new String(csvData.getBytes(PED150_TotalizePerformanceReportServlet.JAPANESE_ENCODING), PED150_TotalizePerformanceReportServlet.UNICODE_ENCODING);

					out.write(str);
					out.close();
					response.flushBuffer();
					return;
				}
				// �߂�{�^������
				else if (action == PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_BACK) {

					pageUrl = PED150_TotalizePerformanceReportServlet.BACK_PAGE;
				}
				// �ĕ\�������N����
				else if (action == PED_TotalizePerformanceReportValueBean.ACTION_TEIGI_BATCH) {

					valueBean.setBatchStatus(PED_TotalizePerformanceReportValueBean.BATCH_STATUS_BATCH_START);
					// �X���b�h�I����̏���
					final int actionFlg = valueBean.getBatchAction();
					final String test = PED_TotalizePerformanceReportPDFThread.getJotaiFlg(session.getId());
					boolean isError = false;
					boolean isBatchStatus = true;
					// PDF�쐬�X���b�h�ȊO�̃X���b�h�̏�Ԃ��擾
					String tmpErrorNo = PED_TotalizePerformanceReportBeanThread.getJotaiFlg(session.getId());
					int errorNo = 0;
					if (tmpErrorNo != null) {
						errorNo = new Integer(tmpErrorNo).intValue();
					}
					// ���[�_�[�ݒ�
					if (actionFlg == PED_TotalizePerformanceReportValueBean.BATCH_ACTION_LEADER) {

						if (errorNo == PED150_TotalizePerformanceReportServlet.SQL_ERROR) {
							bean.createBatchStatusEnd(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_LEADER);
							throw new Exception();
							// �X���b�h���I�����Ă���ꍇ
						} else if (errorNo != PED150_TotalizePerformanceReportServlet.BATCH_START) {
							isError = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_LEADER, session.getId());
							valueBean.setBatchStatus(PED_TotalizePerformanceReportValueBean.BATCH_STATUS_BATCH_END);
							isBatchStatus = bean.isBatch(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_LEADER);
						}

					}
					// �G���[�`�F�b�N
					else if (actionFlg == PED_TotalizePerformanceReportValueBean.BATCH_ACTION_ERROR) {
						if (errorNo == PED150_TotalizePerformanceReportServlet.SQL_ERROR) {
							bean.createBatchStatusEnd(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_ERROR);
							throw new Exception();
							// �X���b�h���I�����Ă���ꍇ
						} else if (errorNo != PED150_TotalizePerformanceReportServlet.BATCH_START) {
							isError = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_ERROR, session.getId());
							valueBean.setBatchStatus(PED_TotalizePerformanceReportValueBean.BATCH_STATUS_BATCH_END);
							isBatchStatus = bean.isBatch(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_ERROR);
							if (isError) {
								valueBean.setErrorCheckFlg(true);
							}

						}
					}
					// ���|�[�g�o��
					else if (actionFlg == PED_TotalizePerformanceReportValueBean.BATCH_ACTION_REPORT) {
						// PDF�X���b�h�̃X���b�h�̏�Ԃ��擾
						tmpErrorNo = PED_TotalizePerformanceReportPDFThread.getJotaiFlg(session.getId());
						if (tmpErrorNo != null) {
							errorNo = new Integer(tmpErrorNo).intValue();
						}
						if (errorNo == PED150_TotalizePerformanceReportServlet.SQL_ERROR) {
							bean.createBatchStatusEnd(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_REPORT);
							throw new Exception();
							// �X���b�h���I�����Ă���ꍇ
						} else if (errorNo != PED150_TotalizePerformanceReportServlet.BATCH_START) {
							isError = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_REPORT, session.getId());
							valueBean.setBatchStatus(PED_TotalizePerformanceReportValueBean.BATCH_STATUS_BATCH_END);
							isBatchStatus = bean.isBatch(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_REPORT);
							final ArrayList shozokuList = bean.getShozoku(loginNo, enqueteNo);
							valueBean.setSoshikiList(shozokuList);

							// �W�v�G���[�܂��̓��|�[�g�쐬�G���[�����݂��邩
							final String status = ped.getStatus(enqueteNo);
							if ("3".equals(status) || "2".equals(status)) {
								final boolean isBatchShukeiStatus = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_SHUKEI, session.getId());
								final boolean isBatchReportStatus = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_REPORT, session.getId());

								if (isBatchShukeiStatus || isBatchReportStatus) {
									valueBean.setBatchShukeiReportError(true);
								} else {
									valueBean.setBatchShukeiReportError(false);
								}
							} else {
								valueBean.setBatchShukeiReportError(false);
							}
						}
					}
					// �W�v
					else if (actionFlg == PED_TotalizePerformanceReportValueBean.BATCH_ACTION_SHUKEI) {
						if (errorNo == PED150_TotalizePerformanceReportServlet.SQL_ERROR) {
							bean.createBatchStatusEnd(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_SHUKEI);
							throw new Exception();
							// �X���b�h���I�����Ă���ꍇ
						} else if (errorNo != PED150_TotalizePerformanceReportServlet.BATCH_START) {
							isError = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_SHUKEI, session.getId());
							valueBean.setBatchStatus(PED_TotalizePerformanceReportValueBean.BATCH_STATUS_BATCH_END);
							isBatchStatus = bean.isBatch(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_SHUKEI);
							final ArrayList shozokuList = bean.getShozoku(loginNo, enqueteNo);
							valueBean.setSoshikiList(shozokuList);

							// �W�v�G���[�܂��̓��|�[�g�쐬�G���[�����݂��邩
							final String status = ped.getStatus(enqueteNo);
							if ("3".equals(status) || "2".equals(status)) {
								final boolean isBatchShukeiStatus = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_SHUKEI, session.getId());
								final boolean isBatchReportStatus = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_REPORT, session.getId());

								if (isBatchShukeiStatus || isBatchReportStatus) {
									valueBean.setBatchShukeiReportError(true);
								} else {
									valueBean.setBatchShukeiReportError(false);
								}
							} else {
								valueBean.setBatchShukeiReportError(false);
							}
						}
					}
					// �W�v���
					else if (actionFlg == PED_TotalizePerformanceReportValueBean.BATCH_ACTION_TORIKESHI) {
						if (errorNo == PED150_TotalizePerformanceReportServlet.SQL_ERROR) {
							bean.createBatchStatusEnd(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_TORIKESHI);
							throw new Exception();
							// �X���b�h���I�����Ă���ꍇ
						} else if (errorNo != PED150_TotalizePerformanceReportServlet.BATCH_START) {
							isError = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_TORIKESHI, session.getId());
							valueBean.setBatchStatus(PED_TotalizePerformanceReportValueBean.BATCH_STATUS_BATCH_END);
							isBatchStatus = bean.isBatch(loginNo, enqueteNo, PED150_TotalizePerformanceReportServlet.TYPE_TORIKESHI);
							final ArrayList shozokuList = bean.getShozoku(loginNo, enqueteNo);
							valueBean.setSoshikiList(shozokuList);
						}
					}
					if (!isBatchStatus) {
						// �I�������b�Z�[�W�i�[
						valueBean.setBatchEndMessage(valueBean.getBatchAction(), isError);
					}
				}

				final String delShubetsu = bean.isBatchAll(loginNo, enqueteNo, new String[] {
						PED150_TotalizePerformanceReportServlet.TYPE_ERROR,
						PED150_TotalizePerformanceReportServlet.TYPE_LEADER,
						PED150_TotalizePerformanceReportServlet.TYPE_REPORT,
						PED150_TotalizePerformanceReportServlet.TYPE_SHUKEI,
						PED150_TotalizePerformanceReportServlet.TYPE_TORIKESHI });
				if (delShubetsu != null) {
					bean.createBatchStatusEnd(loginNo, enqueteNo, delShubetsu);
					throw new Exception();
				}

				// ��ʍĕ`��

				// �W�v���|�[�g�G���[�{�^������
				final boolean isBatchShukeiStatus = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_SHUKEI, session.getId());
				final boolean isBatchReportStatus = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_REPORT, session.getId());

				if (isBatchShukeiStatus || isBatchReportStatus) {
					valueBean.setBatchShukeiReportError(true);
				} else {
					valueBean.setBatchShukeiReportError(false);
				}
				// ���[�_�[�G���[�{�^������
				valueBean.setLeaderSetFlg(false);
				boolean isBatchError = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_LEADER, session.getId());

				if (isBatchError) {
					valueBean.setLeaderSetFlg(true);
				}
				// �G���[�`�F�b�N�G���[CSV�{�^������
				valueBean.setErrorCheckFlg(false);
				if (map.containsKey("isErrorCheckCsv")) {
					isBatchError = bean.isBatchError(enqueteNo, loginNo, PED150_TotalizePerformanceReportServlet.TYPE_CSV_ERROR, session.getId());
					if (((Boolean) map.get("isErrorCheckCsv")).booleanValue() && isBatchError) {
						valueBean.setErrorCheckFlg(true);
					}
				}
				if (action == -1) {
					final ArrayList shozokuList = bean.getShozoku(loginNo, enqueteNo);
					valueBean.setSoshikiList(shozokuList);
				}
				performanceBean.setReportBean(valueBean);
				session.setAttribute(PED_PerformanceBean.SESSION_KEY, performanceBean);

				// �����������A�Y��JSP�y�[�W�֑J��
				final RequestDispatcher rd = this.ctx.getRequestDispatcher(pageUrl);
				rd.forward(request, response);
				Log.performance(loginNo, false, "");
				Log.method(loginNo, "OUT", "");
			} catch (final Exception e) {
				this.initializeThread(request.getSession().getId());
				Log.error(loginNo, e);
				this.ctx.getRequestDispatcher("/view/base/error/VYY_Error.jsp").forward(request, response);
			}
		}
	}

	/**
	 * ���[�U�����͂����l��ێ�
	 * @param userAction ���[�U�����͂����l�S��
	 */
	private PED_TotalizePerformanceReportValueBean setGamenValue(final Map userAction, final PED_TotalizePerformanceReportValueBean bean) {

		// �W�v�Ώۂ̑S�Ă̏������W�v����`�F�b�N�{�b�N�X
		if (userAction.containsKey(PED150_TotalizePerformanceReportServlet.ALL_SOSHIKI)) {
			bean.setTotaliseAllSoshiki(true);
		} else {
			bean.setTotaliseAllSoshiki(false);
		}
		if (bean.isInit()) {
			bean.setTotaliseAllSoshiki(true);
		}
		bean.setInit(false);
		// ���[�_�[�̎����ݒ�
		final String[] auto = (String[]) userAction.get(PED150_TotalizePerformanceReportServlet.AUTO_LEADER);

		if (userAction.containsKey(PED150_TotalizePerformanceReportServlet.AUTO_LEADER) && auto != null && new Integer(auto[0]).intValue() == 2) {
			bean.setAutoLeader(true);
		} else {
			bean.setAutoLeader(false);
		}

		return bean;
	}

	/**
	 * �����\�[�g�p�̃��X�g�擾
	 * @param sosikiList
	 * @return ArrayList
	 */
	private ArrayList sortList(final ArrayList sosikiList) {

		final ArrayList choiceList = new ArrayList();

		for (int i = 0, num = sosikiList.size(); i < num; i++) {
			final HashMap map = (HashMap) sosikiList.get(i);
			choiceList.add(map.get("id"));
		}
		return choiceList;
	}

	private void initializeThread(final String sessionNo) {
		// ���ׂẴX���b�h�p�����[�^��������
		PED_TotalizePerformanceReportPDFThread.removeException(sessionNo);
		PED_TotalizePerformanceReportPDFThread.removeJotaiFlg(sessionNo);
		PED_TotalizePerformanceReportBeanThread.removeJotaiFlg(sessionNo);
	}
}
