/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.report.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

/**
 * �p�t�H�[�}���X���|�[�g��DB�A�N�Z�X����
 */
public class PED_PerformanceReportEJBBean implements SessionBean {

	/**
	 * �p�t�H�[�}���X���|�[�g���擾
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�gNo
	 * @param sosikiCode �g�D�R�[�h
	 * @param status �X�e�[�^�X
	 * @return �p�t�H�[�}���X���|�[�g�̓��e
	 */
	public ArrayList getPerformanceReport(final String loginNo, final String enqueteNo, final String[] sosikiCode, final String[] status) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		final String[] column = HcdbDef.CPM_ENQUETE_COLUMNS;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			String sql = "SELECT " + "enq." + column[0];
			for (int i = 1; i < column.length; i++) {
				sql = sql + ", enq." + column[i];
			}
			sql = sql + ", rep." + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1] + " FROM " + HcdbDef.CPM_ENQUETE_TBL + " enq" + ", " + HcdbDef.CPG_SOSHIKI_REPORT_TBL + " rep" + " WHERE enq." + column[0]
					+ " = " + "rep." + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[0];

			if (status != null && status.length != 0) {
				sql = sql + " AND ( ";
				for (int i = 0; i < status.length; i++) {
					if (i != 0) {
						sql = sql + " OR ";
					}
					sql = sql + "enq." + column[7] + " ='" + status[i] + "'";
				}
				sql = sql + " )";
			}

			if (enqueteNo != null && !"".equals(enqueteNo)) {
				sql = sql + " AND enq." + column[0] + "='" + enqueteNo + "'";

			}

			if (sosikiCode != null && sosikiCode.length != 0) {

				sql = sql + " AND ( ";
				for (int i = 0; i < sosikiCode.length; i++) {
					if (i != 0) {
						sql = sql + " OR ";
					}
					sql = sql + "rep." + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1] + " ='" + sosikiCode[i] + "'";
				}
				sql = sql + " )";

			}

			sql = sql + " ORDER BY " + "enq." + column[4] + " DESC, " + "enq." + column[0] + ", " + "rep." + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1];

			// ���|�[�g�̓��e���i�[����ϐ�
			final ArrayList reportList = new ArrayList();

			stmt = dbConn.prepareStatement(sql);
			rs = stmt.executeQuery();

			// ���|�[�g�̓��e�̊i�[
			while (rs.next()) {
				final String[] report = new String[column.length + 1];
				for (int i = 0; i < column.length; i++) {
					if (rs.getString(column[i]) != null) {
						report[i] = rs.getString(column[i]);
					} else {
						report[i] = "";
					}
				}
				report[column.length] = rs.getString(HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1]);
				reportList.add(report);
			}

			Log.method(loginNo, "OUT", "");
			return reportList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, stmt, rs);
		}
	}

	/**
	 * �p�t�H�[�}���X���|�[�g(�����e�i���X�p)���擾
	 * @param logiNo ���O�I���ԍ�
	 * @param status �X�e�[�^�X
	 * @return �p�t�H�[�}���X���|�[�g�̓��e
	 */
	public ArrayList getM_PerformanceReport(final String loginNo, final String[] status) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		final String[] column = HcdbDef.CPM_ENQUETE_COLUMNS;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			String sql = "SELECT " + "enq." + column[0];
			for (int i = 1; i < column.length; i++) {
				sql = sql + ", enq." + column[i];
			}
			sql = sql + ", rep." + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1] + " FROM " + HcdbDef.CPM_ENQUETE_TBL + " enq" + ", " + HcdbDef.CPG_SOSHIKI_REPORT_TBL + " rep" + " WHERE enq." + column[0]
					+ " = " + "rep." + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[0];

			if (status != null && status.length != 0) {
				sql = sql + " AND ( ";
				for (int i = 0; i < status.length; i++) {
					if (i != 0) {
						sql = sql + " OR ";
					}
					sql = sql + "enq." + column[7] + " = ?";
				}
				sql = sql + " )";
			}

			sql = sql + " ORDER BY " + "enq." + column[4] + " DESC, " + "enq." + column[0];

			// ���|�[�g�̓��e���i�[����ϐ�
			final ArrayList reportList = new ArrayList();
			stmt = dbConn.prepareStatement(sql);
			if (status != null && status.length != 0) {
				for (int i = 0; i < status.length; i++) {
					stmt.setString(i + 1, status[i]);
				}
			}

			rs = stmt.executeQuery();

			// ���|�[�g�̓��e�̊i�[
			while (rs.next()) {
				final String[] report = new String[column.length + 1];
				for (int i = 0; i < column.length; i++) {
					if (rs.getString(column[i]) != null) {
						report[i] = rs.getString(column[i]);
					} else {
						report[i] = "";
					}
				}
				report[column.length] = rs.getString(HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1]);
				reportList.add(report);
			}

			Log.method(loginNo, "OUT", "");
			return reportList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, stmt, rs);
		}
	}

	/**
	 * �p�t�H�[�}���X���|�[�g���擾
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�gNo
	 * @param sosikiCode �g�D�R�[�h
	 * @param status �X�e�[�^�X
	 * @return �p�t�H�[�}���X���|�[�g�̓��e
	 */
	public ArrayList getM_PerformanceReport1(final String loginNo, final String enqueteNo, final String[] sosikiCode, final String[] status) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		final String[] column = HcdbDef.CPM_ENQUETE_COLUMNS;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			String sql = "SELECT " + "enq." + column[0];
			for (int i = 1; i < column.length; i++) {
				sql = sql + ", enq." + column[i];
			}
			sql = sql + ", rep." + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1] + " FROM " + HcdbDef.CPM_ENQUETE_TBL + " enq" + ", " + HcdbDef.CPG_SOSHIKI_REPORT_TBL + " rep" + " WHERE enq." + column[0]
					+ " = " + "rep." + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[0];

			if (status != null && status.length != 0) {
				sql = sql + " AND ( ";
				for (int i = 0; i < status.length; i++) {
					if (i != 0) {
						sql = sql + " OR ";
					}
					sql = sql + "enq." + column[7] + " ='" + status[i] + "'";
				}
				sql = sql + " )";
			}

			if (enqueteNo != null && !"".equals(enqueteNo)) {
				sql = sql + " AND enq." + column[0] + "= ?";

			}

			if (sosikiCode != null && sosikiCode.length != 0) {

				sql = sql + " AND ( ";
				for (int i = 0; i < sosikiCode.length; i++) {
					if (i != 0) {
						sql = sql + " OR ";
					}
					sql = sql + "rep." + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1] + " = ?";
				}
				sql = sql + " )";

			}

			sql = sql + " ORDER BY " + "enq." + column[4] + " DESC, " + "enq." + column[0] + ", " + "rep." + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1];

			// ���|�[�g�̓��e���i�[����ϐ�
			final ArrayList reportList = new ArrayList();

			stmt = dbConn.prepareStatement(sql);
			stmt.setString(1, enqueteNo);
			if (sosikiCode != null && sosikiCode.length != 0) {
				for (int i = 0; i < sosikiCode.length; i++) {
					stmt.setString(i + 2, sosikiCode[i]);
				}
			}

			rs = stmt.executeQuery();

			// ���|�[�g�̓��e�̊i�[
			while (rs.next()) {
				final String[] report = new String[column.length + 1];
				for (int i = 0; i < column.length; i++) {
					if (rs.getString(column[i]) != null) {
						report[i] = rs.getString(column[i]);
					} else {
						report[i] = "";
					}
				}
				report[column.length] = rs.getString(HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1]);
				reportList.add(report);
			}

			Log.method(loginNo, "OUT", "");
			return reportList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, stmt, rs);
		}
	}

	/**
	 * �A���P�[�g�X�e�[�^�X�}�X�^�̓��e���擾
	 * @param logiNo ���O�I���ԍ�
	 * @param statusType �X�e�[�^�X�^�C�v
	 * @param status �X�e�[�^�X
	 * @return �A���P�[�g�X�e�[�^�X�}�X�^�̓��e
	 */
	public ArrayList getEnqueteStatusMaster(final String loginNo, final String statusType, final String status) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		final String[] column = HcdbDef.CPM_STATUS_COLUMNS;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �}�X�^�̓��e���i�[����ϐ�
			final ArrayList masterList = new ArrayList();

			// �}�X�^�̓��e���擾
			String sql = "SELECT " + column[0];
			for (int i = 1; i < column.length; i++) {
				sql = sql + "," + column[i];
			}
			sql = sql + " FROM " + HcdbDef.CPM_STATUS_TBL;

			if (statusType != null && status != null) {
				sql = sql + " WHERE " + column[0] + "= '" + statusType + "' AND " + column[1] + "= '" + status + "'";
			}

			stmt = dbConn.prepareStatement(sql);
			rs = stmt.executeQuery();

			// �}�X�^�̓��e�̊i�[
			while (rs.next()) {
				final String[] master = new String[column.length];
				for (int i = 0; i < column.length; i++) {
					if (rs.getString(column[i]) != null) {
						master[i] = rs.getString(column[i]);
					} else {
						master[i] = "";
					}
				}

				masterList.add(master);
			}

			Log.method(loginNo, "OUT", "");
			return masterList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, stmt, rs);
		}
	}

	/**
	 * �������X�g�̓��e���擾
	 * @param logiNo ���O�I���ԍ�
	 * @param sosikiCode �g�D�R�[�h
	 * @return �������X�g�̓��e
	 */
	public ArrayList getSyozokuList(final String loginNo, final String sosikiCode) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		final String[] column = HcdbDef.T19_SOSIKI_COLUMNS;
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �}�X�^�̓��e���i�[����ϐ�
			final ArrayList masterList = new ArrayList();

			// �}�X�^�̓��e���擾
			String sql = "SELECT " + column[0];
			for (int i = 1; i < column.length; i++) {
				sql = sql + "," + column[i];
			}
			sql = sql + " FROM " + HcdbDef.sosikiTbl;

			sql = sql + " START WITH " + column[0];
			if (sosikiCode == null) {
				sql = sql + " = '0'";
			} else {
				sql = sql + "= '" + sosikiCode + "'";
			}
			sql = sql + " CONNECT BY PRIOR " + column[0] + " = " + column[3] + " ORDER SIBLINGS BY " + column[0];

			stmt = dbConn.prepareStatement(sql);
			rs = stmt.executeQuery();

			// �}�X�^�̓��e�̊i�[
			while (rs.next()) {
				final String[] master = new String[column.length];
				for (int i = 0; i < column.length; i++) {
					if (rs.getString(column[i]) != null) {
						master[i] = rs.getString(column[i]);
					} else {
						master[i] = "";
					}
				}
				masterList.add(master);
			}

			Log.method(loginNo, "OUT", "");
			return masterList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, stmt, rs);
		}
	}

	/**
	 * �������X�g�̓��e���擾(�����e�i���X�p)�ꗗ���i�f�[�^�j���擾�̍ێg�p
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�gNO
	 * @param sosikiCode �g�D�R�[�h
	 * @return �������X�g�̓��e
	 */
	public ArrayList getM_SyozokuList(final String loginNo, final String enqueteNo, final String sosikiCode) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		final String[] column = HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS;
		final HashMap sosikiMap = new HashMap();
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �}�X�^�̓��e���i�[����ϐ�
			final ArrayList masterList = new ArrayList();

			// �}�X�^�̓��e���擾
			String sql = "SELECT GRP." + column[0];
			for (int i = 1; i < column.length; i++) {
				sql = sql + ",GRP." + column[i];
			}
			sql = sql + " FROM ( SELECT ";
			sql = sql + column[0];
			for (int i = 1; i < column.length; i++) {
				sql = sql + "," + column[i];
			}
			sql = sql + " FROM " + HcdbDef.CPM_ENQUETE_SOSHIKI_TBL;
			sql = sql + " WHERE " + column[0] + " = ? )GRP";

			sql = sql + " START WITH " + column[2];
			if (sosikiCode == null) {
				sql = sql + " = ? ";
			} else {
				sql = sql + "= ? ";
			}
			sql = sql + " CONNECT BY PRIOR " + column[2] + " = " + column[5] + " ORDER SIBLINGS BY " + column[2];

			stmt = dbConn.prepareStatement(sql);
			stmt.setString(1, enqueteNo);
			if (sosikiCode == null) {
				stmt.setString(2, "0");
			} else {
				stmt.setString(2, sosikiCode);
			}
			rs = stmt.executeQuery();
			// �}�X�^�̓��e�̊i�[
			while (rs.next()) {

				final String[] master = new String[column.length];
				for (int i = 0; i < column.length; i++) {
					if (rs.getString(column[i]) != null) {
						master[i] = rs.getString(column[i]);
					} else {
						master[i] = "";
					}
				}
				// ����̑g�D���i�[����Ă��Ȃ��ꍇ
				if (sosikiMap.get(master[2]) == null) {
					masterList.add(master);
					sosikiMap.put(master[2], master[2]);
				}
			}

			Log.method(loginNo, "OUT", "");
			return masterList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, stmt, rs);
		}
	}

	/**
	 * �v���_�E���ɕ\�����鏊�����X�g�̓��e���擾
	 * @param logiNo ���O�I���ԍ�
	 * @param sosikiCode �g�D�R�[�h
	 * @param enqueteMainteFlg �A���P�[�g�Ǘ��҃t���O
	 * @return �������X�g�̓��e
	 */
	public ArrayList getSyozokuListWithStatus(final String loginNo, final String sosikiCode, final boolean enqueteMainteFlg) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		final String[] column = HcdbDef.T19_SOSIKI_COLUMNS;
		final HashMap sosikiMap = new HashMap();
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �}�X�^�̓��e���i�[����ϐ�
			final ArrayList masterList = new ArrayList();

			// �}�X�^�̓��e���擾
			String sql = "SELECT GRP." + column[0];
			for (int i = 1; i < column.length; i++) {
				sql = sql + "," + column[i];
			}
			sql = sql + " FROM ( SELECT ROWNUM AS SEQ," + column[0];
			for (int i = 1; i < column.length; i++) {
				sql = sql + "," + column[i];
			}
			sql = sql + " FROM " + HcdbDef.sosikiTbl;

			sql = sql + " START WITH " + column[0];
			if (sosikiCode == null) {
				sql = sql + " = '0'";
			} else {
				sql = sql + "= '" + sosikiCode + "'";
			}
			sql = sql + " CONNECT BY PRIOR " + column[0] + " = " + column[3] + " ORDER SIBLINGS BY " + column[0];
			sql = sql + " ) GRP, " + HcdbDef.CPG_SOSHIKI_REPORT_TBL + ", " + HcdbDef.CPM_ENQUETE_TBL;
			sql = sql + " WHERE " + HcdbDef.CPM_ENQUETE_TBL + "." + HcdbDef.CPM_ENQUETE_COLUMNS[0] + " = ";
			sql = sql + HcdbDef.CPG_SOSHIKI_REPORT_TBL + "." + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[0];
			sql = sql + " AND GRP." + HcdbDef.T19_SOSIKI_COLUMNS[0] + " = " + HcdbDef.CPG_SOSHIKI_REPORT_TBL + ".";
			sql = sql + HcdbDef.CPG_SOSHIKI_REPORT_COLUMNS[1] + " AND " + HcdbDef.CPM_ENQUETE_TBL + "." + HcdbDef.CPM_ENQUETE_COLUMNS[0];
			sql = sql + " IN ( SELECT " + HcdbDef.CPM_ENQUETE_COLUMNS[0] + " FROM " + HcdbDef.CPM_ENQUETE_TBL;
			sql = sql + " WHERE " + HcdbDef.CPM_ENQUETE_COLUMNS[7] + " = '" + HcdbDef.KOKAI_STATUS + "'";
			// �A���P�[�g�Ǘ��҂̏ꍇ
			if (enqueteMainteFlg) {
				sql = sql + " OR " + HcdbDef.CPM_ENQUETE_COLUMNS[7] + " = '" + HcdbDef.TEISI_STATUS + "'";
			}
			sql = sql + " )";
			sql = sql + " ORDER BY SEQ";
			stmt = dbConn.prepareStatement(sql);
			rs = stmt.executeQuery();

			// �}�X�^�̓��e�̊i�[
			while (rs.next()) {
				final String[] master = new String[column.length];
				for (int i = 0; i < column.length; i++) {
					if (rs.getString(column[i]) != null) {
						master[i] = rs.getString(column[i]);
					} else {
						master[i] = "";
					}
				}
				// ����̑g�D���i�[����Ă��Ȃ��ꍇ
				if (sosikiMap.get(master[0]) == null) {
					masterList.add(master);
					sosikiMap.put(master[0], master[0]);
				}
			}

			Log.method(loginNo, "OUT", "");
			return masterList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, stmt, rs);
		}
	}

	/**
	 * �v���_�E���ɕ\�����鏊�����X�g�̓��e���擾(�����e�i���X�p)
	 * @param logiNo ���O�I���ԍ�
	 * @param enqueteNo �A���P�[�gNO
	 * @return �������X�g�̓��e
	 */
	public ArrayList getM_SyozokuListWithStatus(final String loginNo, final String enqueteNo) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		final String[] column = HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS;
		final HashMap sosikiMap = new HashMap();
		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �}�X�^�̓��e���i�[����ϐ�
			final ArrayList masterList = new ArrayList();

			// �}�X�^�̓��e���擾
			String sql = "SELECT GRP." + column[0];
			for (int i = 1; i < column.length; i++) {
				sql = sql + "," + column[i];
			}
			sql = sql + " FROM ( SELECT " + column[0];
			for (int i = 1; i < column.length; i++) {
				sql = sql + "," + column[i];
			}
			sql = sql + " FROM " + HcdbDef.CPM_ENQUETE_SOSHIKI_TBL;
			sql = sql + " WHERE " + column[0] + " = ? ) GRP ";

			sql = sql + " START WITH " + " GRP." + column[6] + " = ? ";
			sql = sql + " CONNECT BY PRIOR " + "GRP." + column[2] + " = " + "GRP." + column[5] + " ORDER SIBLINGS BY " + "GRP." + column[2];
			stmt = dbConn.prepareStatement(sql);

			stmt.setString(1, enqueteNo);
			stmt.setString(2, "0");
			rs = stmt.executeQuery();

			// �}�X�^�̓��e�̊i�[
			while (rs.next()) {
				final String[] master = new String[column.length];
				for (int i = 0; i < column.length; i++) {
					if (rs.getString(column[i]) != null) {
						master[i] = rs.getString(column[i]);
					} else {
						master[i] = "";
					}
				}
				// ����̑g�D���i�[����Ă��Ȃ��ꍇ
				if (sosikiMap.get(master[2]) == null) {
					masterList.add(master);
					sosikiMap.put(master[2], master[2]);
				}
			}
			Log.method(loginNo, "OUT", "");
			return masterList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, stmt, rs);
		}
	}

	/**
	 * �A���P�[�g�g�D�}�X�^�̓��e���擾
	 * @param logiNo ���O�I���ԍ�
	 * @param statusType �X�e�[�^�X�^�C�v
	 * @param sosikiCode �g�D�R�[�h
	 * @return �A���P�[�g�g�D�}�X�^�̓��e
	 */
	public ArrayList getEnqueteSosikiMaster(final String loginNo, final String enqueteNo, final String sosikiCode) throws SQLException, NamingException {

		Log.method(loginNo, "IN", "");
		Connection dbConn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		final String[] column = HcdbDef.CPM_ENQUETE_SOSHIKI_COLUMNS;

		try {
			dbConn = PZZ040_SQLUtility.getConnection(loginNo);

			// �}�X�^�̓��e���i�[����ϐ�
			final ArrayList masterList = new ArrayList();

			// �}�X�^�̓��e���擾
			String sql = "SELECT " + column[0];
			for (int i = 1; i < column.length; i++) {
				sql = sql + "," + column[i];
			}
			sql = sql + " FROM " + HcdbDef.CPM_ENQUETE_SOSHIKI_TBL;

			sql = sql + " WHERE " + column[0] + "= ?";

			if (sosikiCode != null) {
				sql = sql + " AND " + column[2] + "= ?";
			}

			stmt = dbConn.prepareStatement(sql);
			stmt.setString(1, enqueteNo);
			if (sosikiCode != null) {
				stmt.setString(2, sosikiCode);
			}
			rs = stmt.executeQuery();

			// �}�X�^�̓��e�̊i�[
			while (rs.next()) {
				final String[] master = new String[column.length];
				for (int i = 0; i < column.length; i++) {
					if (rs.getString(column[i]) != null) {
						master[i] = rs.getString(column[i]);
					} else {
						master[i] = "";
					}
				}

				masterList.add(master);
			}

			Log.method(loginNo, "OUT", "");
			return masterList;
		} catch (final SQLException sqle) {
			Log.error(loginNo, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(loginNo, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(loginNo, dbConn, stmt, rs);
		}
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbActivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception CreateException
	 * @exception RemoteException
	 */
	public void ejbCreate() throws CreateException, RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbPassivate() throws RemoteException {/* �������܂��� */
	}

	/**
	 * �������Ȃ��B
	 * @exception RemoteException
	 */
	public void ejbRemove() throws RemoteException {/* �������܂��� */
	}

	public void setSessionContext(final SessionContext arg0) throws EJBException, RemoteException {/* �������܂��� */
	}

}
