/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.answer.bean;

import java.io.Serializable;

/**
 * �A���P�[�g�I��Bean�N���X
 * @author Shimura
 */
public class PED_QuestionnaireSelectionBean implements Serializable {

	// �A���P�[�g�ԍ�
	private String enqueteNo = null;

	// �A���P�[�g����
	private String enqueteNm = null;

	// �J�n��
	private String kaishiNgp = null;

	// �J�n����
	private String kaishiTime = null;

	// �I���N����
	private String shuryoNgp = null;

	// �I������
	private String shuryoTime = null;

	// �񓚏�
	private String kaitoStatus = null;

	// �񓚃X�e�[�^�X
	private String kaitoStatus2 = null;

	// �ŏI�񓚔N����
	private String kaitoNgp = null;

	// �ŏI�񓚎���
	private String kaitoTime = null;

	public String getEnqueteNm() {
		return this.enqueteNm;
	}

	public void setEnqueteNm(final String enqueteNm) {
		this.enqueteNm = enqueteNm;
	}

	public String getEnqueteNo() {
		return this.enqueteNo;
	}

	public void setEnqueteNo(final String enqueteNo) {
		this.enqueteNo = enqueteNo;
	}

	public String getKaishiNgp() {
		return this.kaishiNgp;
	}

	public void setKaishiNgp(final String kaishiNgp) {
		this.kaishiNgp = kaishiNgp;
	}

	public String getKaitoNgp() {
		return this.kaitoNgp;
	}

	public void setKaitoNgp(final String kaitoNgp) {
		this.kaitoNgp = kaitoNgp;
	}

	public String getKaitoStatus() {
		return this.kaitoStatus;
	}

	public void setKaitoStatus(final String kaitoStatus) {
		this.kaitoStatus = kaitoStatus;
	}

	public String getKaitoStatus2() {
		return this.kaitoStatus2;
	}

	public void setKaitoStatus2(final String kaitoStatus2) {
		this.kaitoStatus2 = kaitoStatus2;
	}

	public String getKaitoTime() {
		return this.kaitoTime;
	}

	public void setKaitoTime(final String kaitoTime) {
		this.kaitoTime = kaitoTime;
	}

	public String getShuryoNgp() {
		return this.shuryoNgp;
	}

	public void setShuryoNgp(final String shuryoNgp) {
		this.shuryoNgp = shuryoNgp;
	}

	/**
	 * @return shuryoTime ��߂��܂��B
	 */
	public String getShuryoTime() {
		return this.shuryoTime;
	}

	/**
	 * @param shuryoTime �ݒ肷�� shuryoTime�B
	 */
	public void setShuryoTime(final String shuryoTime) {
		this.shuryoTime = shuryoTime;
	}

	/**
	 * @return kaishiTime ��߂��܂��B
	 */
	public String getKaishiTime() {
		return this.kaishiTime;
	}

	/**
	 * @param kaishiTime �ݒ肷�� kaishiTime�B
	 */
	public void setKaishiTime(final String kaishiTime) {
		this.kaishiTime = kaishiTime;
	}

}
