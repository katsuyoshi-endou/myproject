/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import jp.co.hisas.career.performance.maintenance.servlet.PED110_QuestionnaireAnkenKanriDownServlet;
import jp.co.hisas.career.util.common.PZZ010_CharacterUtil;
import jp.co.hisas.career.util.common.PZZ040_SQLUtility;
import jp.co.hisas.career.util.log.Log;
import jp.co.hisas.career.util.property.HcdbDef;

public class PED_QuestionnaireAnkenKanriEJBBean implements SessionBean {
	/** �A���P�[�g���ރe�[�u�� */
	private final String eBunruiTbl = HcdbDef.CPM_ENQUETE_BUNRUI_TBL;

	/* �A���P�[�g���ރJ���� */
	/** ����No. */
	private final String eBunruiNoClm = HcdbDef.CPM_ENQUETE_BUNRUI_COLUMNS[0];

	/** ���ޖ��� */
	private final String eBunruiNameClm = HcdbDef.CPM_ENQUETE_BUNRUI_COLUMNS[1];

	/** �A���P�[�g�X�e�[�^�X�e�[�u�� */
	private final String eStatusTbl = HcdbDef.CPM_STATUS_TBL;

	/** �A���P�[�g�X�e�[�^�X�J���� */
	/** �X�e�[�^�X���� */
	private final String eStatusTypeClm = HcdbDef.CPM_STATUS_COLUMNS[0];

	/** �X�e�[�^�X */
	private final String eStatusClm = HcdbDef.CPM_STATUS_COLUMNS[1];

	/** �X�e�[�^�X���� */
	private final String eStatusNameClm = HcdbDef.CPM_STATUS_COLUMNS[2];

	/** �A���P�[�g�}�X�^�e�[�u�� */
	private final String qTbl = HcdbDef.CPM_ENQUETE_TBL;

	/** �A���P�[�g�X�e�[�^�X�e�[�u�� */
	private final String qStatuTbl = HcdbDef.CPM_STATUS_TBL;

	/** �Ј��ʃA���P�[�g�󋵃e�[�u�� */
	private final String qJokyoTbl = HcdbDef.CPS_ENQUETE_JOKYO_TBL;

	private String login_no = "";

	private final String SEPARATOR = PED110_QuestionnaireAnkenKanriDownServlet.SEPARATOR;

	private final String HEAD = PED110_QuestionnaireAnkenKanriDownServlet.HEAD;

	/**
	 * EJB�I�u�W�F�N�g�̐������s���܂��B
	 * @throws CreateException EJB�I�u�W�F�N�g�̐����Ɏ��s�����ꍇ
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}

	public void setSessionContext(final SessionContext arg0) throws EJBException, RemoteException {/* �������܂��� */
	}

	public void PED_QuestionnaireAnkenKanriBean(final String login_no) {
		this.login_no = login_no;
	}

	/**
	 * �f�[�^�x�[�X���A���P�[�g���ރ��X�g���擾����B
	 * @return ArrayList �A���P�[�g���ރ��X�g
	 * @exception SQLException SQL�G���[�����������ꍇ
	 * @exception NamingException �f�[�^�\�[�X�̎Q�Ǝ擾�Ɏ��s�����ꍇ
	 */
	public ArrayList getBunruiList() throws SQLException, NamingException {
		Log.method(this.login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);

			/* �A���P�[�g���ނ��擾 */
			final String sql = "SELECT " + this.eBunruiNoClm + "," + this.eBunruiNameClm + " FROM " + this.eBunruiTbl + " ORDER BY " + this.eBunruiNoClm;
			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			rs = pstmt.executeQuery();

			final ArrayList rBunrui = new ArrayList();
			while (rs.next()) {
				final String tmp[] = new String[2];
				tmp[0] = rs.getString(1);
				tmp[1] = rs.getString(2);
				rBunrui.add(tmp);

			}
			Log.method(this.login_no, "OUT", "");

			return rBunrui;
		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * �f�[�^�x�[�X���A���P�[�g�X�e�[�^�X���X�g���擾����
	 * @return ArrayList �A���P�[�g�X�e�[�^�X���X�g
	 * @throws SQLException
	 * @throws NamingException
	 */
	public ArrayList getStatusList() throws SQLException, NamingException {
		Log.method(this.login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);

			/* �A���P�[�g�X�e�[�^�X���擾 */
			final String sql = "SELECT " + this.eStatusTypeClm + "," + this.eStatusClm + "," + this.eStatusNameClm + " FROM " + this.eStatusTbl + " WHERE " + this.eStatusTypeClm + " = '01' ORDER BY "
					+ this.eStatusClm;
			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			rs = pstmt.executeQuery();

			final ArrayList rStatus = new ArrayList();
			while (rs.next()) {
				final String tmp[] = new String[2];
				tmp[0] = rs.getString(2);
				tmp[1] = rs.getString(3);
				rStatus.add(tmp);

			}
			Log.method(this.login_no, "OUT", "");

			return rStatus;
		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * �����Ŏw�肵�������ɍ��v����A���P�[�g�Č����擾 ���ׂ�String �w�肵�Ȃ��ꍇ�͋󕶎���n��
	 * @param no
	 * @param bunrui
	 * @param status
	 * @param kikanKaisi
	 * @param kikanSyuryo
	 * @return String[]�A���P�[�g�Č������i�[����ArrayList
	 * @throws RemoteException
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public ArrayList searchQuestionnaire(final String no, final String bunrui, final String[] status, final String kikanKaisi, final String kikanSyuryo) throws SQLException, NamingException {
		Log.method(this.login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);

			/* �A���P�[�g����SQL�𐶐����擾 */
			String sql = "SELECT EM.ENQUETE_NO, EM.ENQUETE_NAME, S.STATUS_NAME, TAISHO_CNT, KAITO_CNT, EM.KAITO_KAISHI_NENGAPPI, EM.KAITOSHURYO_NENGAPPI, EM.STATUS, EM.BUNSEKI_FLG" + " FROM "
					+ this.qTbl + " EM, " + this.qStatuTbl + " S," + "(SELECT ENQUETE_NO,COUNT(PERSON_ID) TAISHO_CNT FROM CPM_ENQUETE_SHAIN GROUP BY ENQUETE_NO) TAISHO,"
					+ "(SELECT ENQUETE_NO,COUNT(PERSON_ID) KAITO_CNT FROM " + this.qJokyoTbl + " WHERE STATUS = '2' GROUP BY ENQUETE_NO) KAITO";
			String where = " WHERE S.STATUS_TYPE = '01' AND EM.STATUS = S.STATUS (+) AND EM.ENQUETE_NO = TAISHO.ENQUETE_NO (+) AND EM.ENQUETE_NO = KAITO.ENQUETE_NO (+)";
			final String order = " ORDER BY TO_NUMBER(EM.KAITOSHURYO_NENGAPPI) DESC, EM.ENQUETE_NO";

			// �����������X�g
			final ArrayList conditions = new ArrayList();

			// �A���P�[�g�i���o�[�����ݒ�
			if (!no.equals("")) {
				where += " AND EM.ENQUETE_NO = ?";
				conditions.add(no);
			}
			// �A���P�[�g���ޏ����ݒ�
			if (!bunrui.equals("")) {
				where += " AND EM.ENQUETE_BUNRUI_NO = ?";
				conditions.add(bunrui);
			}
			// ���ԊJ�n�����ݒ�
			if (!kikanKaisi.equals("")) {
				where += " AND EM.KAITOSHURYO_NENGAPPI >= ?";
				conditions.add(kikanKaisi);
			}
			// ���ԏI�������ݒ�
			if (!kikanSyuryo.equals("")) {
				where += " AND EM.KAITO_KAISHI_NENGAPPI <= ?";
				conditions.add(kikanSyuryo);
			}
			// �A���P�[�g�X�e�[�^�X�����ݒ�
			if (status.length > 0) {
				where += " AND EM.STATUS IN ( ?";
				conditions.add(status[0]);
				for (int k = 1; k < status.length; k++) {
					where += ",?";
					conditions.add(status[k]);
				}
				where += ")";
			}

			// SQL�d�グ
			sql += where + order;

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			for (int i = 0; i < conditions.size(); i++) {
				pstmt.setString(i + 1, (String) conditions.get(i));
			}
			rs = pstmt.executeQuery();

			final ArrayList rQuestionnaireInfo = new ArrayList();
			// �擾�J������
			final int clms = 9;
			while (rs.next()) {
				final String tmp[] = new String[clms];
				for (int j = 0; j < clms; j++) {
					tmp[j] = rs.getString(j + 1);
				}
				rQuestionnaireInfo.add(tmp);
			}
			Log.method(this.login_no, "OUT", "");

			return rQuestionnaireInfo;
		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * �A���P�[�g�Č��X�e�[�^�X�̍X�V
	 * @param no �ΏۃA���P�[�g�i���o�[
	 * @param upValue �X�V�l
	 * @return String true|false
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String updateStatus(final String no, final String upValue) throws SQLException, NamingException {
		Log.method(this.login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;

		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);

			final String sql = "UPDATE CPM_ENQUETE SET STATUS = ? WHERE ENQUETE_NO = ?";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, upValue);
			pstmt.setString(2, no);
			String returnVal = "";
			if (pstmt.executeUpdate() == 1) {
				returnVal = "true";
			} else {
				returnVal = "false";
			}
			Log.method(this.login_no, "OUT", "");
			return returnVal;
		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, null);
		}
	}

	/**
	 * �A���P�[�g�X�e�[�^�X���擾
	 * @param no �ΏۃA���P�[�g�i���o�[
	 * @return String�X�e�[�^�X�i���o�[
	 * @throws SQLException
	 * @throws NamingException
	 * @throws Exception
	 */
	public String getStatus(final String no) throws SQLException, NamingException {
		Log.method(this.login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);

			// �����ΏۃA���P�[�g�̌��݂̃X�e�[�^�X���擾
			final String sql = "SELECT (SELECT COUNT(*) FROM CPM_ENQUETE WHERE ENQUETE_NO = CPM1.ENQUETE_NO) CNT, STATUS FROM  CPM_ENQUETE CPM1 WHERE ENQUETE_NO = ?";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();
			pstmt.setString(1, no);
			rs = pstmt.executeQuery();

			// �ΏۃA���P�[�g�̌��݂̃X�e�[�^�X
			rs.next();

			final int cnt = Integer.parseInt(rs.getString("CNT"));
			if (cnt < 1) {
				// �ΏۃA���P�[�g�����݂��Ȃ�
				return "false";
			}

			Log.method(this.login_no, "OUT", "");

			return rs.getString("STATUS");

		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, rs);
		}

	}

	/**
	 * �A���P�[�gNo����A���P�[�g�����擾����
	 * @param enqueteNo
	 * @return String �A���P�[�g��
	 * @throws SQLException
	 * @throws NamingException
	 */
	public String getEnqueteName(final String enqueteNo) throws SQLException, NamingException {
		Log.method(this.login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String str = "";

		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);

			final String sql = "SELECT ENQUETE_NAME FROM CPM_ENQUETE WHERE ENQUETE_NO=?";
			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();

			pstmt.setString(1, enqueteNo);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				str = rs.getString(1);
			}

			Log.method(this.login_no, "OUT", "");
			return str;

		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * �񓚏�CSV�o�͗p�̃f�[�^���擾����
	 * @param enqueteNo
	 * @return String[] �񓚏�CSV�̃f�[�^
	 * @throws SQLException
	 * @throws NamingException
	 */
	public String[] getKaitoJokyo(final String enqueteNo) throws SQLException, NamingException {
		Log.method(this.login_no, "IN", "");

		Connection dbConn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			// �R�l�N�V�����擾
			dbConn = PZZ040_SQLUtility.getConnection(this.login_no);

			final String sql = " SELECT DISTINCT " + " CPM_ENQUETE_SHAIN.SIMEI_NO, " + " CPM_ENQUETE_SHAIN.KANJI_SIMEI, " + " SOSIKI.SOSIKI_CODE, " + " SOSIKI.SOSIKI__RENKETSU_MEI, "
					+ " YAKUSYOKU.YAKUSYOKU_CODE, " + " YAKUSYOKU.YAKUSYOKU, " + " T01_PERSONAL_TBL.NAISEN, " + " T01_PERSONAL_TBL.GAISEN, " + " CPM_ENQUETE_SHAIN.Mail, "
					+ " CASE WHEN CPS_ENQUETE_JOKYO.STATUS='0' THEN '����' " + " WHEN CPS_ENQUETE_JOKYO.STATUS='1' THEN '�񓚒�' " + " WHEN CPS_ENQUETE_JOKYO.STATUS='2' THEN '����' " + " ELSE '' END, "
					+ " CPS_ENQUETE_JOKYO.SAISHU_KAITO_NENGAPPI, " + " CPS_ENQUETE_JOKYO.SAISHU_KAITO_JIKOKU " + " FROM " + " CPM_ENQUETE_SHAIN, " + " ( SELECT "
					+ " CPS_ENQUETE_JOKYO.PERSON_ID P01, " + " CPM_ENQUETE_SOSHIKI.SOSIKI_CODE, " + " CPM_ENQUETE_SOSHIKI.SOSIKI__RENKETSU_MEI "
					+ " FROM CPM_ENQUETE_SOSHIKI, CPM_ENQUETE_SHAIN_ZOKUSEI, CPS_ENQUETE_JOKYO " + " WHERE CPS_ENQUETE_JOKYO.PERSON_ID=CPM_ENQUETE_SHAIN_ZOKUSEI.PERSON_ID "
					+ " AND   CPS_ENQUETE_JOKYO.ENQUETE_NO=? " + " AND   CPM_ENQUETE_SHAIN_ZOKUSEI.ENQUETE_NO=? " + " AND   CPM_ENQUETE_SOSHIKI.ENQUETE_NO=? "
					+ " AND   CPM_ENQUETE_SHAIN_ZOKUSEI.ZOKUSEI_ID='HonmuSoshiki' " + " AND   CPM_ENQUETE_SHAIN_ZOKUSEI.MASTER_ID=CPM_ENQUETE_SOSHIKI.GROUP_ID ) SOSIKI, " + " ( SELECT "
					+ " CPS_ENQUETE_JOKYO.PERSON_ID P02, " + " CPM_ENQUETE_YAKUSHOKU.YAKUSYOKU_CODE, " + " CPM_ENQUETE_YAKUSHOKU.YAKUSYOKU "
					+ " FROM CPM_ENQUETE_YAKUSHOKU, CPM_ENQUETE_SHAIN_ZOKUSEI, CPS_ENQUETE_JOKYO " + " WHERE CPS_ENQUETE_JOKYO.PERSON_ID=CPM_ENQUETE_SHAIN_ZOKUSEI.PERSON_ID "
					+ " AND   CPS_ENQUETE_JOKYO.ENQUETE_NO=? " + " AND   CPM_ENQUETE_SHAIN_ZOKUSEI.ENQUETE_NO=? " + " AND   CPM_ENQUETE_YAKUSHOKU.ENQUETE_NO=? "
					+ " AND   CPM_ENQUETE_SHAIN_ZOKUSEI.ZOKUSEI_ID='HonmuYakushoku' " + " AND   CPM_ENQUETE_SHAIN_ZOKUSEI.MASTER_ID=CPM_ENQUETE_YAKUSHOKU.POST_ID ) YAKUSYOKU, "
					+ " (SELECT TRIM(SIMEI_NO)SIMEI_NO,NAISEN,GAISEN FROM T01_PERSONAL_TBL WHERE HONMU_FLG = '1')T01_PERSONAL_TBL, " + " CPS_ENQUETE_JOKYO, " + " CPM_ENQUETE_SHAIN_ZOKUSEI "
					+ " WHERE " + " CPS_ENQUETE_JOKYO.PERSON_ID=CPM_ENQUETE_SHAIN.PERSON_ID " + " AND CPS_ENQUETE_JOKYO.ENQUETE_NO=? " + " AND CPM_ENQUETE_SHAIN.ENQUETE_NO=? "
					+ " AND CPM_ENQUETE_SHAIN_ZOKUSEI.ENQUETE_NO=? " + " AND CPS_ENQUETE_JOKYO.PERSON_ID=CPM_ENQUETE_SHAIN_ZOKUSEI.PERSON_ID " + " AND CPS_ENQUETE_JOKYO.PERSON_ID=SOSIKI.P01 "
					+ " AND CPS_ENQUETE_JOKYO.PERSON_ID=YAKUSYOKU.P02 " + " AND TRIM(CPM_ENQUETE_SHAIN.SIMEI_NO)=T01_PERSONAL_TBL.SIMEI_NO(+) " + " AND CPS_ENQUETE_JOKYO.PERSON_ID IN ( "
					+ " SELECT PERSON_ID FROM CPS_ENQUETE_JOKYO WHERE ENQUETE_NO=?) " + " ORDER BY SOSIKI.SOSIKI_CODE ASC, YAKUSYOKU.YAKUSYOKU_CODE ASC, CPM_ENQUETE_SHAIN.SIMEI_NO ASC ";

			pstmt = dbConn.prepareStatement(sql);
			pstmt.clearParameters();

			pstmt.setString(1, enqueteNo);
			pstmt.setString(2, enqueteNo);
			pstmt.setString(3, enqueteNo);
			pstmt.setString(4, enqueteNo);
			pstmt.setString(5, enqueteNo);
			pstmt.setString(6, enqueteNo);
			pstmt.setString(7, enqueteNo);
			pstmt.setString(8, enqueteNo);
			pstmt.setString(9, enqueteNo);
			pstmt.setString(10, enqueteNo);
			rs = pstmt.executeQuery();

			final ArrayList array = new ArrayList();
			while (rs.next()) {
				final String tmp[] = new String[11];

				tmp[0] = PZZ010_CharacterUtil.normalizedStr(rs.getString(1)).trim();
				tmp[1] = PZZ010_CharacterUtil.normalizedStr(rs.getString(2));
				tmp[2] = PZZ010_CharacterUtil.normalizedStr(rs.getString(3));
				tmp[3] = PZZ010_CharacterUtil.normalizedStr(rs.getString(4));
				tmp[4] = PZZ010_CharacterUtil.normalizedStr(rs.getString(5));
				tmp[5] = PZZ010_CharacterUtil.normalizedStr(rs.getString(6));
				tmp[6] = PZZ010_CharacterUtil.normalizedStr(rs.getString(7));
				tmp[7] = PZZ010_CharacterUtil.normalizedStr(rs.getString(8));
				tmp[8] = PZZ010_CharacterUtil.normalizedStr(rs.getString(9));
				tmp[9] = PZZ010_CharacterUtil.normalizedStr(rs.getString(10));
				tmp[10] = this.formatYYYYMMDDHHMMSS(PZZ010_CharacterUtil.normalizedStr(rs.getString(11)), PZZ010_CharacterUtil.normalizedStr(rs.getString(12)));

				final String buff = this.HEAD + tmp[0] + this.SEPARATOR + tmp[1] + this.SEPARATOR + tmp[2] + this.SEPARATOR + tmp[3] + this.SEPARATOR + tmp[4] + this.SEPARATOR + tmp[5]
						+ this.SEPARATOR + tmp[6] + this.SEPARATOR + tmp[7] + this.SEPARATOR + tmp[8] + this.SEPARATOR + tmp[9] + this.SEPARATOR + tmp[10] + this.HEAD;

				array.add(buff);
			}

			Log.method(this.login_no, "OUT", "");
			return (String[]) array.toArray(new String[0]);

		} catch (final SQLException sqle) {
			Log.error(this.login_no, sqle);
			throw sqle;
		} catch (final NamingException ne) {
			Log.error(this.login_no, ne);
			throw ne;
		} finally {
			PZZ040_SQLUtility.closeConnection(this.login_no, dbConn, pstmt, rs);
		}
	}

	/**
	 * ���t������yyyy/mm/dd hh:mm:ss�ɕϊ�����
	 * @param str1
	 * @param str2
	 * @return
	 */
	private String formatYYYYMMDDHHMMSS(final String str1, final String str2) {
		String str = "";
		final String ymd = PZZ010_CharacterUtil.normalizedStr(str1);
		final String hms = PZZ010_CharacterUtil.normalizedStr(str2);

		if (ymd.trim().length() != 8) {
			return str;
		}

		if (hms.trim().length() != 6) {
			return str;
		}

		str = ymd.substring(0, 4) + "/" + ymd.substring(4, 6) + "/" + ymd.substring(6, 8) + " " + hms.substring(0, 2) + ":" + hms.substring(2, 4) + ":" + hms.substring(4, 6);

		return str;
	}

}
