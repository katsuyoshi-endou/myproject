/*
 * All Rights Reserved. Copyright (C) 2003,2007, Hitachi Systems & Services, Ltd.
 */
package jp.co.hisas.career.performance.maintenance.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

/**
 * ���M�Ώېݒ�Bean
 * @author �Β�
 */
public class PED_SousinTaisyoValueBean implements Serializable {

	/** �A���P�[�gNO */
	private String enqueteNo;

	/** �A���P�[�g���� */
	private String enqueteNm;

	/** �A���P�[�g��� */
	private String enqueteStatus;

	/** �������X�g */
	private ArrayList soshikiList;

	/** �������X�g */
	private HashMap soshikiMap;

	/** ��E���X�g */
	private TreeMap yakushokuMap;

	/** ���M�Ώێ҃��X�g�i�\���p�j */
	private ArrayList sousinTaisyosyaList;

	/** ���M�Ώێ҃��X�g�i�ێ��p�j */
	private ArrayList sousinPersonList;

	/** ���_�����R�[�h */
	private String soshiki;

	/** ���_��E�R�[�h�i�J�n�j */
	private String startYakushoku;

	/** ���_��E�R�[�h�i�I���j */
	private String endYakushoku;

	/** ���_����NO */
	private String simeiNo;

	/** ���_�ΏێґS���`�F�b�N */
	private String taishoshaCheck;

	/** ���_�������҃`�F�b�N */
	private String mikanryoshaCheck;

	/** ���b�Z�[�WID */
	private String messageID;

	/** ���M�Ώێҁi�S�Ј��j */
	private ArrayList allTaishoshaList;

	/** �����Œǉ������ꍇ�̐l�}�b�v */
	private HashMap addShimeiMap;

	/**
	 * @return addShimeiMap ��߂��܂��B
	 */
	public HashMap getAddShimeiMap() {
		return this.addShimeiMap;
	}

	/**
	 * @param addShimeiMap �ݒ肷�� addShimeiMap�B
	 */
	public void setAddShimeiMap(final HashMap addShimeiMap) {
		this.addShimeiMap = addShimeiMap;
	}

	/**
	 * @return allTaishoshaList ��߂��܂��B
	 */
	public ArrayList getAllTaishoshaList() {
		return this.allTaishoshaList;
	}

	/**
	 * @param allTaishoshaList �ݒ肷�� allTaishoshaList�B
	 */
	public void setAllTaishoshaList(final ArrayList allTaishoshaList) {
		this.allTaishoshaList = allTaishoshaList;
	}

	/**
	 * @return soshikiMap ��߂��܂��B
	 */
	public HashMap getSoshikiMap() {
		return this.soshikiMap;
	}

	/**
	 * @param soshikiMap �ݒ肷�� soshikiMap�B
	 */
	public void setSoshikiMap(final HashMap soshikiMap) {
		this.soshikiMap = soshikiMap;
	}

	public ArrayList getSousinPersonList() {
		return this.sousinPersonList;
	}

	public void setSousinPersonList(final ArrayList sousinPersonList) {
		this.sousinPersonList = sousinPersonList;
	}

	public String getEnqueteNm() {
		return this.enqueteNm;
	}

	public void setEnqueteNm(final String enqueteNm) {
		this.enqueteNm = enqueteNm;
	}

	public String getEnqueteNo() {
		return this.enqueteNo;
	}

	public void setEnqueteNo(final String enqueteNo) {
		this.enqueteNo = enqueteNo;
	}

	public String getEnqueteStatus() {
		return this.enqueteStatus;
	}

	public void setEnqueteStatus(final String enqueteStatus) {
		this.enqueteStatus = enqueteStatus;
	}

	public ArrayList getSoshikiList() {
		return this.soshikiList;
	}

	public void setSoshikiList(final ArrayList soshikiMap) {
		this.soshikiList = soshikiMap;
	}

	public TreeMap getYakushokuMap() {
		return this.yakushokuMap;
	}

	public void setYakushokuMap(final TreeMap yakushokuMap) {
		this.yakushokuMap = yakushokuMap;
	}

	public String getEndYakushoku() {
		return this.endYakushoku;
	}

	public void setEndYakushoku(final String endYakushoku) {
		this.endYakushoku = endYakushoku;
	}

	public String getMikanryoshaCheck() {
		return this.mikanryoshaCheck;
	}

	public void setMikanryoshaCheck(final String mikanryoshaCheck) {
		this.mikanryoshaCheck = mikanryoshaCheck;
	}

	public String getSimeiNo() {
		return this.simeiNo;
	}

	public void setSimeiNo(final String simeiNo) {
		this.simeiNo = simeiNo;
	}

	public String getSoshiki() {
		return this.soshiki;
	}

	public void setSoshiki(final String soshiki) {
		this.soshiki = soshiki;
	}

	public ArrayList getSousinTaisyosyaList() {
		return this.sousinTaisyosyaList;
	}

	public void setSousinTaisyosyaList(final ArrayList sousinTaisyosyaList) {
		this.sousinTaisyosyaList = sousinTaisyosyaList;
	}

	public String getStartYakushoku() {
		return this.startYakushoku;
	}

	public void setStartYakushoku(final String startYakushoku) {
		this.startYakushoku = startYakushoku;
	}

	public String getTaishoshaCheck() {
		return this.taishoshaCheck;
	}

	public void setTaishoshaCheck(final String taishoshaCheck) {
		this.taishoshaCheck = taishoshaCheck;
	}

	public String getMessageID() {
		return this.messageID;
	}

	public void setMessageID(final String messageID) {
		this.messageID = messageID;
	}

}
